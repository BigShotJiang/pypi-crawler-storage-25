#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Molecular Viewer - Modular Coordinator (Complete Feature Restoration)
======================================================================
"""
from __future__ import annotations
import math
import sys
import os
import time
from dataclasses import dataclass, field
from typing import Optional, Sequence, Tuple, List, Dict, Any

import numpy as np
try:
    import glfw
    from OpenGL.GL import *
    import imgui
    from imgui.integrations.glfw import GlfwRenderer
    HAS_VIZ = True
except ImportError:
    HAS_VIZ = False

# Subsystems
from .camera import OrbitCamera, FPSCamera, rodrigues, normalize
from .scene import Scene
from .constants import WORLD_UP, CPK_COLORS, ATOMIC_RADII, CELL_EDGES
from .io.providers import StructureProvider
from .io.exporters import export_structure_xyz, export_structure
from .renderer.utils import look_at, perspective, ortho

# Analysis Modules
from .analysis.rdf import compute_rdf
from .analysis.coordination import compute_cn, compute_coordination_sphere, compute_bad
from .analysis.hbonds import compute_hbonds
from .analysis.geometry import compute_bounds, cell_corners, compute_rmsd
from .analysis.mutation_engine import MutationEngine
try:
    from .analysis.voronoi import compute_voronoi, VoronoiResult
    HAS_VORONOI = True
except ImportError:
    HAS_VORONOI = False

from .analysis.polyhedron_analyzer import PolyhedronAnalyzer, PolyhedronSettings, Polyhedron
from .ui.display_scientific_geometry import draw_scientific_geometry_panel
from .ui.display_structure_overview import draw_structure_overview_panel

# Renderer Subsystem
from .renderer.sphere_renderer import SphereRenderer
from .renderer.bond_renderer import BondRenderer
from .renderer.line_renderer import LineRenderer
from .renderer.picking_renderer import PickingRenderer
from .renderer.post_process import PostProcessor
from .renderer.mesh_renderer import MeshRenderer
from .renderer.protein_renderer import ProteinRenderer
from .renderer.volume_renderer import VolumeRenderer

# UI Subsystem
from .ui.plots import draw_rdf_plot, draw_bad_plot, draw_energy_plots, draw_dos_plot, draw_eigenvalue_ladder

from .analysis.camera_path import CameraPath
from .renderer.export_writer import AsyncSequenceWriter
from scipy.spatial.transform import Rotation

# Builder Subsystem
from .builder.editor import StructureEditor
from .builder.session import StructureSession, InteractionState
from .ui.builder_panel import BuilderPanel

@dataclass
class RenderQualityState:
    target_fps: float = 60.0
    current_fps: float = 60.0
    skip_px: float = 0.4
    point_px: float = 3.0
    impostor_px: float = 8.0
    bond_mode: str = "cylinder" # cylinder, line, off
    max_visible_replicas: int = 125
    playback_low_quality: bool = True
    lod_level: int = 2 # 0: Low, 1: Med, 2: High
    
    # Tiered Selection
    shading_tier: int = 2 # 0: Point, 1: Simple, 2: HQ
    fill_rate_cost: float = 0.0 # Estimated screen coverage
    current_frame_ms: float = 0.0
    worst_frame_ms: float = 0.0
    
    # Section Timings (for profiling)
    current_timings: Dict[str, float] = field(default_factory=lambda: {
        "cull": 0.0,
        "shadow": 0.0,
        "main": 0.0,
        "total": 0.0
    })
    
    # Hysteresis
    _frames_stable: int = 0
    _RECOVERY_THRESHOLD: int = 40 # frames of high FPS needed to upgrade quality
    
    def adjust(self, fps: float, total_atoms: int = 0, pretty_render: bool = False):
        self.current_fps = fps
        # Screen-space cost is now the primary driver
        cost_factor = self.fill_rate_cost / 1e6 # Millions of pixels
        
        # User toggle is the upper limit for shading tier
        max_tier = 2 if pretty_render else 1
        
        if fps < self.target_fps * 0.7:
             # Reduce quality immediately on drop
             self._frames_stable = 0
             
             if self.shading_tier > 1:
                 self.shading_tier = 1
                 self.lod_level = 1
             elif self.shading_tier == 1 and cost_factor > 1.0:
                 self.shading_tier = 0
             self.lod_level = 0
             
             self.point_px = min(self.point_px + 0.5, 12.0)
             if self.bond_mode == "cylinder": self.bond_mode = "line"
             
        elif fps > self.target_fps * 0.95:
             # Increase quality only after sustained stability
             self._frames_stable += 1
             if self._frames_stable > self._RECOVERY_THRESHOLD:
                 self._frames_stable = 0
                 
                 if self.shading_tier < max_tier:
                     # Only upgrade to HQ if fill rate is within budget
                     if cost_factor < 2.3: # slightly higher threshold for upgrade
                         self.shading_tier += 1
                         self.lod_level = self.shading_tier
                 
                 self.point_px = max(self.point_px - 0.2, 3.0)
                 if self.bond_mode == "line" and total_atoms < 100000:
                     self.bond_mode = "cylinder"
        
        # Enforce hard limit
        if self.shading_tier > max_tier:
            self.shading_tier = max_tier
            
        # Decay worst frame time slowly (hides noise, shows trends)
        self.worst_frame_ms = max(self.worst_frame_ms * 0.98, self.current_frame_ms)

@dataclass
class GalleryState:
    enabled: bool = False
    layout: str = "Grid"

    visible_distance: float = 350.0
    full_render_distance: float = 120.0
    max_full_items: int = 64
    max_proxy_items: int = 64
    cache_radius: float = 180.0
    max_cached_scenes: int = 64 # Matches max_full_items by default

    walk_speed: float = 35.0
    sprint_mult: float = 4.0
    spacing: float = 10.0
    structure_scale: float = 1.0
    show_labels: bool = False
    show_metadata: bool = True
    auto_rotate: bool = False

    nearest_idx: int = -1
    last_inspected_idx: int = -1
    inspect_dist: float = 12.0

    show_floor: bool = True
    floor_size: float = 2000.0

@dataclass
class GalleryItem:
    idx: int
    pos: np.ndarray
    scale: float = 1.0
    hovered: bool = False
    energy: Optional[float] = None
    metadata: dict = field(default_factory=dict)

class Viewer:
    def __init__(self, provider: StructureProvider, 
                 start_index: int = 0, 
                 replicas: Tuple[int,int,int] = (0,0,0), 
                 win_size=(1280, 800),
                 verbose: bool = True):
        
        if not HAS_VIZ:
            raise ImportError("Missing required visualization dependencies (GLFW, OpenGL, ImGui).")
            
        self.provider = provider
        self.index = start_index
        self.win_size = win_size
        self.verbose = verbose
        
        # Core Subsystems
        self.scene = Scene()
        self.scene.set_replicas(*replicas)
        self.mutation_engine = MutationEngine(self.scene)
        
        # Mutation UI State
        self.mutation_target_idx = 0
        self.mutation_targets = ["ALA", "GLY", "PHE", "VAL", "SER"]
        self.mutation_preview = None
        
        # Adaptive Quality
        self.quality = RenderQualityState()
        self.frame_times: List[float] = []
        self._sphere_lod = 1
        self._bond_lod = 1
        
        # Camera & View State
        self.cam = OrbitCamera(np.zeros(3, dtype=np.float32), np.array([10, 10, 10], dtype=np.float32))
        self.cam1 = self.cam # Alias
        self.cam2 = OrbitCamera(np.zeros(3, dtype=np.float32), np.array([10, 10, 10], dtype=np.float32))
        self.cam_fps = FPSCamera()
        self.is_ortho = True
        self.split_view = False
        self._camera_bookmarks = {} # For Ctrl+Shift+F1-F4 presets
        self.active_tool = "ORBIT"
        self.auto_spin = False
        self.auto_spin_speed = 0.5
        
        self.gallery = GalleryState()
        self._gallery_items: List[GalleryItem] = []
        self._gallery_positions: Dict[int, np.ndarray] = {}
        
        # Professional Dynamic Cache & Batching Initialization
        self._gallery_scene_cache = {}
        self._gallery_cache_last_used = {}
        self._gallery_load_queue = []
        self._gallery_last_cache_update = 0.0
        
        self._gallery_batch_dirty = True
        self._gallery_batch_key = None
        self._gallery_batch_pos = None
        self._gallery_batch_radii = None
        self._gallery_batch_colors = None
        
        self._gallery_active_items = {} # Lazy-loaded items
        
        # --- Visual State Flags ---
        self.show_atoms = True
        self.show_bonds = False
        self.show_cell = True
        self.pretty_render = False
        self.atom_scale = 1.0
        self.bond_scale = 0.15
        self.bg_color = [0.1, 0.1, 0.12]
        
        # --- Advanced Infrastructure (Phase 1-3) ---
        from .analysis.analysis_manager import AnalysisManager
        from .analysis.geometry_cache import GeometryCache
        from .renderer.id_buffer import IDBufferManager
        from .renderer.polyhedron_renderer import PolyhedronRenderer
        from .ui.selection_sets import SelectionSetManager
        
        from .renderer.quad_renderer import QuadRenderer
        
        self.analysis = AnalysisManager()
        self.geo_cache = GeometryCache(max_entries=100)
        self.selection_sets = SelectionSetManager()
        
        # GPU Infrastructure is initialized later in _init_renderers()
        # to ensure the OpenGL context is ready.
        self.id_picking = None
        self.rnd_poly = None
        self.rnd_quad = None
        self.oit_fbo = 0
        self.oit_accum_tex = 0
        self.oit_reveal_tex = 0
        
        # --- Versioning (Phase 1) ---
        self.v_struct = 0
        self.v_sel = 0
        self.v_params = 0
        self._analysis_dirty = False
        self._oit_w, self._oit_h = -1, -1
        self.hover_info: Optional[dict] = None
        self.hover_info_mode = 2 # 0=Off, 1=Minimal, 2=Full
        self.measured_indices: List[int] = []
        self._draw_measurements_open = True
        
        # Sequence Export State
        self.export_status = "Status: Idle"
        self.export_fps = 30
        self.export_duration = 1.0
        self.export_width = 1920
        self.export_height = 1080
        self.export_compression = 6
        self.export_supersampling = 1
        self.export_motion_blur = 1
        self.export_background_mode = "Solid" # Solid, Transparent, White, Black
        self.export_interpolation = "SmoothStep" # Linear, SmoothStep, SmootherStep, EaseIn, EaseOut
        self.export_save_gif = True
        self.export_gif_downscale = 0.5
        self.export_gif_loop = True
        
        # Query Console State
        self._query_str = ""
        self._query_mode = 0
        self._query_status_msg = ""
        self._query_status_color = (1, 1, 1, 1)
        
        self._exporting_sequence = False
        self._export_frame_num = 0
        self._export_frames_list = []

        # --- Energy Analytics State ---
        self.energy_mode = 0  # 0: Raw, 1: Formation, 2: Relative, 3: E/atom, 4: Z-score
        self.energy_sort_mode = 0  # 0: Original, 1: Energy Asc, 2: Energy Desc, 3: Rank Change
        self.mu = {
            "Ni": -5.43, "Fe": -6.21, "V": -7.10, 
            "K": -1.02, "H": -3.39, "O": -4.92
        }
        self.mu_active_elements = [] # Source of truth is comp_species
        self.mu_locked = {el: False for el in self.mu}
        self.energy_normalize_atom = True
        self.energy_use_unique = False
        self.energy_top_n = 500
        
        # Computed Analytics Cache
        self.active_energies = np.array([], dtype=np.float32)
        self.energy_view_indices = np.array([], dtype=np.int32)
        self.comp_matrix = None # Matrix of counts (N_structures, N_species)
        self.comp_species = []  # List of species symbols
        self.all_natoms = None  # Array of atom counts per structure
        
        # Plotting & Selection
        self.show_formation_vs_mu = False
        self.formation_mu_element = "None" # Will be set on first load
        self.energy_threshold = 0.05 # eV/atom
        self.show_lower_envelope = True
        
        self.export_fbo = 0
        self.export_tex = 0
        self.export_depth = 0
        
        # Protein State
        self.show_protein_ribbon = False
        self.protein_ribbon_dirty = True
        self.protein_ribbon_w = 1.6
        self.protein_ribbon_t = 0.3
        self.protein_atom_mode = 1 # 0: Show All, 1: Hide Backbone, 2: Hide All, 3: Active Site Only
        self.active_site_str = ""
        self.sidechain_opacity = 0.6
        self.ribbon_color_helix = [0.8, 0.2, 0.2]
        self.ribbon_color_sheet = [0.9, 0.8, 0.2]
        self.ribbon_color_coil = [0.6, 0.6, 0.6]
        
        # --- Scientific Geometry State ---
        self.show_polyhedra = False
        self.poly_opacity = 0.5
        self.poly_settings = PolyhedronSettings()
        self.poly_analyzer = PolyhedronAnalyzer()
        self.polyhedra: List[Polyhedron] = []
        self.poly_dirty = True
        
        self.show_voronoi_cells = False
        self.voronoi_opacity = 0.4
        self.poly_mode = 0 # 0: Selection, 1: Visible Species, 2: All
        self.lights = [
            {'pos': [1.0, 1.0, 1.0], 'col': [1.0, 1.0, 1.0]},
            {'pos': [-1.0, -1.0, 0.5], 'col': [0.4, 0.5, 0.7]}
        ]
        self.selected_light_idx = 0
        self.materials = {
            'exposure': 1.0, 'headlight': 1.0, 
            'shadow_intensity': 0.6, 'shadow_softness': 2.762, 'shadow_bias': 0.002,
            'reflection_intensity': 1.0, 'reflection_gloss': 1.0,
            'fog_density': 0.002, 'gamma': 1.2,
            'ssao_strength': 0.4, 'ssao_radius': 0.06, 'ssao_bias': 0.0,
            'bloom_intensity': 0.489, 'bloom_threshold': 0.8, 'selection_glow': 0.688,
            'sheen': 0.993, 'clearcoat': 1.0,
            'pulse_speed': 4.0, 'pulse_amp': 0.0,
            'show_ssao': True, 'show_bloom': True, 'show_fxaa': False,
            'show_outlines': True, 'show_shadows': True,
            'replica_dimming': 1.0
        }
        self.preset_options = ["Realistic", "Plastic", "Metallic", "Velvet", "Glassy", "Neon", "Clay", "Chrome", "Candy", "Frosted"]
        self.material_presets = {
            "Realistic": {'ambient': 0.4, 'specular': 0.6, 'shininess': 48.0, 'rim': 0.8, 'sheen': 0.0, 'clearcoat': 0.0, 'env': 0.3, 'gloss': 0.5},
            "Plastic":   {'ambient': 0.3, 'specular': 1.2, 'shininess': 64.0, 'rim': 1.0, 'sheen': 0.0, 'clearcoat': 0.5, 'env': 0.2, 'gloss': 0.3},
            "Metallic":  {'ambient': 0.1, 'specular': 4.0, 'shininess': 128.0, 'rim': 2.0, 'sheen': 0.0, 'clearcoat': 0.0, 'env': 1.0, 'gloss': 1.0},
            "Velvet":    {'ambient': 0.5, 'specular': 0.1, 'shininess': 16.0, 'rim': 1.5, 'sheen': 1.0, 'clearcoat': 0.0, 'env': 0.1, 'gloss': 0.1},
            "Glassy":    {'ambient': 0.1, 'specular': 2.0, 'shininess': 256.0, 'rim': 4.0, 'sheen': 0.0, 'clearcoat': 1.0, 'env': 0.8, 'gloss': 1.0},
            "Neon":      {'ambient': 5.0, 'specular': 0.1, 'shininess': 1.0, 'rim': 2.0, 'sheen': 1.0, 'clearcoat': 1.0, 'env': 0.0, 'gloss': 0.0},
            "Clay":      {'ambient': 0.6, 'specular': 0.1, 'shininess': 4.0, 'rim': 0.2, 'sheen': 0.0, 'clearcoat': 0.0, 'env': 0.0, 'gloss': 0.0},
            "Chrome":    {'ambient': 0.0, 'specular': 8.0, 'shininess': 512.0, 'rim': 3.0, 'sheen': 0.0, 'clearcoat': 0.0, 'env': 2.0, 'gloss': 1.0},
            "Candy":     {'ambient': 0.3, 'specular': 2.0, 'shininess': 128.0, 'rim': 1.0, 'sheen': 0.2, 'clearcoat': 1.5, 'env': 0.5, 'gloss': 0.8},
            "Frosted":   {'ambient': 0.4, 'specular': 0.4, 'shininess': 16.0, 'rim': 2.0, 'sheen': 1.0, 'clearcoat': 0.2, 'env': 0.2, 'gloss': 0.1},
        }
        self.element_materials = {} # Dict[Element, MaterialDict]
        self._mat_tbo_dirty = True # Initial sync
        self.light_rotating = False
        self.shadow_res_idx = 0 # 512
        self.global_preset_idx = 0
        
        # Playback State
        self.playback_playing = False
        self.playback_speed = 30.0
        self.last_time = glfw.get_time()
        self.time_acc = 0.0
        
        # Analysis State
        self.show_rdf = False
        self.rdf_mode_idx = 0
        self.rdf_mode = "bulk"
        self.show_cn = False
        self.show_hbonds = False
        self.show_voronoi = False
        self.show_z_profile = False
        self.show_selection_analytics = True
        self.force_full_pairwise = False
        self.rdf_rmax = 5.0
        self.rdf_bins = 200
        self.z_profile_x = np.zeros(1)
        self.z_profile_y = np.zeros(1)
        self.voro_vol_range = [0.0, 20.0]
        self.rdf_results = {}
        self.rdf_visibility = {} # Dict[str, bool]
        self.rdf_normalize = False # Peak normalization
        self.rdf_exclude_mirrors = True
        
        # Centralized Coloring Architecture
        self.color_mode = "Element" # Element, Atom Type, Z Position, Displacement, Neighbors, Coordination, Voronoi Volume, Selection, Index
        self.color_palette = "BlueRed" # BlueRed, Viridis, Magma, Hot, Grayscale
        self.color_invert = False
        self.color_range_auto = True
        self.color_range = [0.0, 10.0]
        self.color_z_fractional = False # Z in fractional coords?
        
        # Camera Focus State
        self._prev_cam_state = None
        self._focus_active = False
        self._last_focus_selection = set()
        
        # Mutation UI state
        self.mutation_msg = ""
        self.mutation_msg_time = 0.0
        self.mutation_ghost_data = None # Storage for 3D preview points
        self.color_nb_cutoff = 3.0 # Neighbor count cutoff
        self.color_highlight_selection = True # Show selection on top
        self.displacement_ref_index = 0
        self.displacement_ref_pos = None # Reference positions
        
        # New Interactive Analysis Parameters
        self.bond_factor = 1.2 # Tunable covalent factor
        self.rdf_species_a = "All"
        self.rdf_species_b = "All"
        self.rdf_smooth = False
        self.rdf_manual_mode = True
        
        self.displacement_ref_index = 0
        self.analysis_scope = "Global" # Global, Selection, Region
        
        # UI state
        self.show_gui = True
        self.show_cell = True
        self.show_help = False
        self.show_workshop = False
        
        # Clipping State
        self.clipping_enabled = False
        self.clipping_axis = 2 # 0:X, 1:Y, 2:Z
        self.clipping_range = [0.0, 1.0]
        self.clipping_fractional = False
        self.clipping_invert = False
        self.clipping_alpha = 0.0 # 0.0 means hidden, >0 means transparent
        self._clipping_dirty = True # Initial sync
        
        # Volumetric State
        self.vol_data = None
        self.vol_enabled = False
        
        # Editing State
        self.edit_translate_delta = [0.0, 0.0, 0.0]
        self.edit_rotate_angle = 90.0
        self.edit_rotate_axis_idx = 2 # Z
        self.edit_new_element = "C"
        
        # Analysis Export State
        self.cn_cutoff = 3.0
        self.cn_results = None
        self.bad_cutoff = 3.0
        self.bad_results = (np.array([]), np.array([]))
        self.hb_d_ha_cut = 2.5
        self.hb_angle_cut = 120.0
        self.hb_results = None
        self.export_selected_only = False

        # Tight-Binding State
        from .analysis.tight_binding import TBParameters, TBResults
        self.tb_params = TBParameters()
        self.tb_results: Optional[Any] = None
        self.tb_enabled = False
        self.tb_status = ""
        self.tb_show_dos = False
        self.tb_show_ladder = False
        self.tb_pdos_visibility = {}
        self.tb_pdos_orb_visibility = {}
        self.tb_color_mode = "None"
        self.tb_viz_mode = "None"
        self.tb_show_volume = False
        self.tb_vol_iso = 0.05
        
        # Biomolecules (Proteins) State
        self.show_rama_plot = False
        self.show_contact_map = False
        self.show_sequence_viewer = False
        self.show_rmsf_plot = False
        self.protein_analysis_results = {}
        self.protein_ref_pos = None # For RMSD calculation
        self.protein_dist_pair = (-1, -1) # Indices for 3D distance ruler
        self.contact_map_tex_id = None # GPU Texture for O(1) rendering
        
        # Protein Styling State
        self.protein_color_mode = 0 # 0: CPK, 1: ResType, 2: Chain, 3: BB-Focus
        self.protein_alpha = 0.6
        self.protein_bb_alpha = 1.0
        self.protein_sc_alpha = 1.0
        self.tb_selected_state = -1
        self.vol_iso_level = 0.5
        self.vol_opacity = 0.5
        self.vol_show_slices = False
        self.vol_color = [0.3, 0.6, 1.0, 0.5]
        self.vol_mode_idx = 0 # 0: Isosurface, 1: MIP
        self.tb_mesh_mode = True
        self.tb_pos_mesh: Optional[Any] = None
        self.tb_neg_mesh: Optional[Any] = None
        
        self.export_status = ""
        self.export_formats = ["xyz", "extxyz", "cif", "pdb", "vasp", "aims"]
        self.export_fmt_idx = 1 # Default to extxyz
        self.export_prefix = "sage_export" # Legacy alias
        self.export_base_name = "sage_export"
        self.export_folder = "sage_export"
        
        self.screenshot_formats = ["PNG", "JPG"]
        self.screenshot_fmt_idx = 0
        self.screenshot_bg_modes = ["Current", "Dark", "Transparent", "White"]
        self.screenshot_bg_idx = 0
        self.hide_hover_in_export = True
        
        self.export_all_frames = False
        self.gif_frame_count = 10
        self.gif_random_selection = False
        self.animation_fps = 12
        self.animation_loop = True
        self.animation_selection_mode = 0 # 0: Uniform, 1: Random
        
        # Professional Export / Cinematic Motion State
        self.export_handheld_enabled = False
        self.export_shake_seed = 0
        self.export_shake_intensity = 0.5
        self.export_shake_translation = 0.2
        self.export_shake_rotation = 0.8
        self.export_shake_frequency = 1.0
        self.export_allow_roll = False
        self.export_horizon_lock = True
        self.export_motion_blur = 1 # Number of samples per frame
        self.export_supersampling = 1.0
        self.export_duration = 3.0
        self.export_fps = 30
        self.export_interpolation = "SmootherStep"
        self.export_width = 1920
        self.export_height = 1080
        self.export_background_mode = "Black"
        self.export_compression = 6
        self.export_save_gif = False
        self.export_gif_downscale = 0.5
        self.export_gif_loop = True
        self.export_random_structures = False
        
        # SOAP Analysis State
        self.soap_center_symbol = "Cu"
        self.soap_species = [] # Default species for SOAP calculation
        self.soap_species_selection = {} # Dict[str, bool] for UI checkboxes
        self.soap_rcut = 4.5
        self.soap_nmax = 6
        self.soap_lmax = 4
        self.soap_sigma = 0.4
        self.soap_dr = 0.25
        self.soap_search_cutoff = 20.0
        self.soap_dr_2d = 0.5
        self.soap_n_min = 5
        self.soap_fill_gaps = True
        self.soap_smoothing = 0.5
        self.soap_fit_min = 2.5
        self.soap_fit_max = 10.0
        self.soap_results = None
        self.show_soap_plot = False
        self.soap_plateau_override = False
        self.soap_plateau_range = [8.0, 12.0]
        
        # Navigation dual state
        self.cam1 = OrbitCamera(center=np.zeros(3, dtype=np.float32), 
                                offset=np.array([10.0, 10.0, 10.0], dtype=np.float32))
        self.cam2 = OrbitCamera(center=np.zeros(3, dtype=np.float32), 
                                offset=np.array([10.0, 10.0, 10.0], dtype=np.float32))
        self.cam = self.cam1 # Pointer to active camera for callbacks
        
        self.index1 = 0
        self.index2 = 0
        self.index = 0 # Pointer to active master index
        
        self.sync_cameras = True
        self.sync_frames = True
        self.split_view = False
        self.active_viewport = 1 # 1 for Left/A, 2 for Right/B
        
        # Interactions
        self.last_x, self.last_y = None, None
        self.orbiting = False
        self.panning = False
        self.box_selecting = False
        self.light_rotating = False
        self.show_axes = True
        self.show_origin_axes = False
        self.show_com = False
        self.panning = False
        self.rolling = False
        self.keys_down = set()
        self._trigger_selection_clear = False
        
        self.last_cam_view = np.zeros((4,4))
        self.camera_moving = False
        self._last_interaction_time = 0.0
        
        # Caches & Persistence
        self._bond_cache: Dict[Tuple[int, float], np.ndarray] = {}
        self._bond_render_cache = {} # id(scene) -> {'bc_u': ..., 'version': ...}
        self._cached_element_colors = None
        self._gpu_status = {"pos": True, "sel": True, "mat": True}
        
        # Scratch Buffers for fast culling/math (Recycled to avoid GC churn)
        self._scratch_p4 = np.zeros((0, 4), dtype=np.float32)
        self._scratch_vpos = np.zeros((0, 3), dtype=np.float32)
        self._scratch_pclip = np.zeros((0, 4), dtype=np.float32)
        self._selection_cache = {
            "key": None,
            "dists_seq": [],
            "angles_seq": [],
            "dihedrals_seq": [],
            "dists_pw": None,
        }
        
        # Initialize OpenGL
        self._init_gl()
        self.shadow_res_idx = 0 # 512 by default
        self._init_renderers()
        
        # Initial Load
        self.provider2: Optional[Any] = None
        self.scene2: Optional[Scene] = None
        self._comp_path = ""
        
        # Energy Trace Cache
        try:
            self.all_energies = np.array(self.provider.get_all_E(), dtype=np.float32)
            self._update_energy_analytics()
        except Exception:
            self.all_energies = np.array([], dtype=np.float32)
            
        # Structural Workshop Subsystem
        self.struct_editor = StructureEditor(self.scene)
        self.struct_session = StructureSession()
        self.builder_ui = BuilderPanel(self, self.struct_editor, self.struct_session)

        # Advanced Selection State
        self._selection_query_text = ""
        self._lasso_active = False
        self._lasso_path = [] # 2D segments for free-hand selection
        self._show_query_examples = False

        self._load_frame(self.index1)
        self._center_camera()

    def _init_gl(self):
        """Initializes GLFW window and ImGui context with proper callback chaining."""
        if not glfw.init(): raise RuntimeError("Failed to initialize GLFW")
        glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 3)
        glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 3)
        glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)
        glfw.window_hint(glfw.OPENGL_FORWARD_COMPAT, GL_TRUE)
        glfw.window_hint(glfw.SAMPLES, 4)
        
        self.win = glfw.create_window(self.win_size[0], self.win_size[1], "Molecular Visualizer", None, None)
        if not self.win:
            glfw.terminate()
            raise RuntimeError("Failed to create GLFW window")
            
        glfw.make_context_current(self.win)
        glfw.swap_interval(1)
        
        # 1. Initialize ImGui first
        imgui.create_context()
        self.gui_impl = GlfwRenderer(self.win)
        
        # 2. Set custom callbacks AFTER ImGui to override/complement
        glfw.set_scroll_callback(self.win, self._on_scroll)
        glfw.set_cursor_pos_callback(self.win, self._on_mouse_move)
        glfw.set_mouse_button_callback(self.win, self._on_mouse_button)
        glfw.set_key_callback(self.win, self._on_key)
        
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_MULTISAMPLE)

    def _init_renderers(self):
        self.rnd_sphere = SphereRenderer()
        self.rnd_bond = BondRenderer()
        self.rnd_line = LineRenderer()
        self.post_process = PostProcessor()
        self.rnd_pick = PickingRenderer()
        self.rnd_volume = VolumeRenderer()
        self.rnd_mesh_pos = MeshRenderer()
        self.rnd_mesh_neg = MeshRenderer()
        self.rnd_protein = ProteinRenderer()
        self.rnd_protein2 = ProteinRenderer() # For split view comparison
        self.rnd_ghost = SphereRenderer()       # Dedicated for mutation previews
        
        # New interaction infrastructure
        from .renderer.id_buffer import IDBufferManager
        from .renderer.polyhedron_renderer import PolyhedronRenderer
        from .renderer.quad_renderer import QuadRenderer
        
        self.id_picking = IDBufferManager(self.win_size[0], self.win_size[1])
        self.rnd_poly = PolyhedronRenderer()
        self.rnd_quad = QuadRenderer()
        self._init_oit_fbo(self.win_size[0], self.win_size[1])

    def load_comparison(self, provider: Any = None):
        """Loads a second trajectory or clones the current one."""
        self.provider2 = provider if provider else self.provider
        self.scene2 = Scene()
        self.split_view = True
        self.index2 = self.index1
        self._reset_tb_analysis() # Structure comparison reset
        # Copy camera state
        self.cam2.center = np.copy(self.cam1.center)
        self.cam2.offset = np.copy(self.cam1.offset)
        self.cam2.pan = np.copy(self.cam1.pan)
        self.cam2.ortho_scale = self.cam1.ortho_scale
        self._load_frame2(self.index2)

    def _camera_is_interacting(self):
        """Helper to detect if the user is currently rotating, panning, or if momentum is active."""
        # Active Dragging
        dragging = any([self.orbiting, self.panning, self.rolling, self.light_rotating])
        
        # Momentum check
        drifting = self.cam1.is_moving or (self.split_view and self.cam2.is_moving)
        
        now = time.perf_counter()
        if dragging or drifting:
            self._last_interaction_time = now
            return True
            
        # Hysteresis: Keep 'interactive' status for 250ms after motion stops
        # This prevents flickering between 2048 and 4096 shadows during micro-movements
        return (now - self._last_interaction_time) < 0.25

    def _get_selection_cache_key(self):
        """Generates a stable key for selection analytics caching."""
        return (
            self.index,
            tuple(sorted(self.scene.selected_atoms)),
            self.scene.N,
            self.scene.is_periodic,
            # If lattice is dynamic, we'd add it here too
        )

    def _compute_selection_analytics(self):
        """Lazy-computes distances, angles, and dihedrals for the current selection."""
        key = self._get_selection_cache_key()
        if self._selection_cache["key"] == key and not self.selection_dirty:
            return self._selection_cache

        selected = self.scene.selected_atoms
        pos = self.scene.pos
        lat = self.scene.lat
        is_periodic = self.scene.is_periodic

        def get_diff(pa, pb):
            d = pb - pa
            if is_periodic:
                d = d - np.round(d @ np.linalg.inv(lat)) @ lat
            return d

        dists_seq = []
        angles_seq = []
        dihedrals_seq = []

        # 1. Sequential Chain Metrics (O(N))
        for i in range(len(selected) - 1):
            p1, p2 = pos[selected[i]], pos[selected[i + 1]]
            dists_seq.append(np.linalg.norm(get_diff(p1, p2)))

        if len(selected) >= 3:
            for i in range(len(selected) - 2):
                p1, p2, p3 = pos[selected[i]], pos[selected[i + 1]], pos[selected[i + 2]]
                v1, v2 = get_diff(p2, p1), get_diff(p2, p3)
                cos_a = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-9)
                angles_seq.append(np.degrees(np.arccos(np.clip(cos_a, -1.0, 1.0))))

        if len(selected) >= 4:
            for i in range(len(selected) - 3):
                p1, p2, p3, p4 = [pos[selected[j]] for j in range(i, i + 4)]
                b1, b2, b3 = get_diff(p1, p2), get_diff(p2, p3), get_diff(p3, p4)
                n1 = np.cross(b1, b2); n1 /= (np.linalg.norm(n1) + 1e-9)
                n2 = np.cross(b2, b3); n2 /= (np.linalg.norm(n2) + 1e-9)
                m1 = np.cross(n1, b2 / (np.linalg.norm(b2) + 1e-9))
                x, y = np.dot(n1, n2), np.dot(m1, n2)
                dihedrals_seq.append(np.degrees(np.arctan2(y, x)))

        self._selection_cache.update({
            "key": key,
            "dists_seq": dists_seq,
            "angles_seq": angles_seq,
            "dihedrals_seq": dihedrals_seq,
            # Do NOT reset dists_pw here; it has its own demand flag
        })
        self.selection_dirty = False
        return self._selection_cache

    def _draw_protein_plots(self):
        """Displays interactive structural biology windows and handles their callbacks."""
        any_plot_active = getattr(self, "show_rama_plot", False) or getattr(self, "show_contact_map", False) or getattr(self, "show_sequence_viewer", False)
        if not any_plot_active: return
        
        if not getattr(self, "protein_analysis_results", None):
            self._run_biomolecule_analysis()
            if not self.protein_analysis_results:
                self.show_rama_plot = False
                self.show_contact_map = False
                self.show_sequence_viewer = False
                return
        
        from .ui.plots import draw_ramachandran_plot, draw_contact_map
        
        if self.show_rama_plot:
            res = self.protein_analysis_results
            # Combine phi/psi from all chains for a unified plot
            phi_all = np.concatenate([c['phi'] for c in res['chains'] if 'phi' in c])
            psi_all = np.concatenate([c['psi'] for c in res['chains'] if 'psi' in c])
            info_all = [r for ch in res['chains'] for r in ch['res_info']]
            
            # Find which of these residues is currently selected (if any)
            current_sel_idx = -1
            for i, r in enumerate(info_all):
                if r.get('idx', -1) in self.scene.selected_atoms:
                    current_sel_idx = i
                    break
            
            target_atom_idx = draw_ramachandran_plot(phi_all, psi_all, info_all, selected_idx=current_sel_idx)
            if target_atom_idx != -1:
                # 1. Full Residue Selection
                self._select_residue_by_atom_idx(target_atom_idx)
                # 2. Camera: Center on the CA atom
                self.reset_view(center=self.scene.pos[target_atom_idx], dist=10.0)

        if self.show_contact_map:
            res = self.protein_analysis_results
            pair = draw_contact_map(res.get('contact_map'), res.get('all_res_info', []), 
                                    texture_id=self.contact_map_tex_id)
            if pair != (-1, -1):
                self.protein_dist_pair = pair
                # Select BOTH residues
                self._select_residue_by_atom_idx(pair[0], clear=True)
                self._select_residue_by_atom_idx(pair[1], clear=False)
                # Optionally jump camera to the pair center
                midpoint = (self.scene.pos[pair[0]] + self.scene.pos[pair[1]]) * 0.5
                self.reset_view(center=midpoint, dist=15.0)

        if self.show_sequence_viewer:
            from .ui.plots import draw_sequence_viewer
            res = self.protein_analysis_results
            target_idx = draw_sequence_viewer(res.get('sequences', []), res.get('chains', []), self.scene.selected_atoms)
            if target_idx != -1:
                self._select_residue_by_atom_idx(target_idx)
                self.reset_view(center=self.scene.pos[target_idx], dist=10.0)

    def _mark_dirty(self, pos=False, sel=False, mat=False):
        """Marks specific GPU data categories as needing synchronization."""
        if pos: self._gpu_status["pos"] = True
        if sel: self._gpu_status["sel"] = True
        if mat: self._gpu_status["mat"] = True

    def _load_frame1(self, index: int):
        if not self.provider or len(self.provider) == 0: return
        self.index1 = int(index) % len(self.provider)
        self.index = self.index1 # Sync master index for analytics
        try:
            data = self.provider.get(self.index1)
            p, l, e, els, c, r = data[:6]
            info = data[6] if len(data) > 6 else None
            self.scene.ingest(p, l, e, els, c, r, info)
            self._reset_analysis_properties()
            self._reset_tb_analysis() # Reset TB because structure changed
            self._validate_selection(self.scene)
            self.scene.set_replicas(*self.scene.replicas)
            self.selection_dirty = True
            self._mark_dirty(pos=True, sel=True)
            self._sync_gpu(self.scene)
            # Live analysis & Coloring triggers
            self._update_coloring(self.scene)
            self._mark_dirty(mat=True) # Ensure materials are synced for new elements
            if self.show_rdf: self._calc_rdf()
            if self.show_z_profile: self._calc_z_profile()
            if self.show_polyhedra: self._calc_all_polyhedra()
        except Exception as err:
            print(f"Error loading frame1 {index}: {err}")

    def _load_frame2(self, index: int):
        if not self.provider2 or len(self.provider2) == 0: return
        self.index2 = int(index) % len(self.provider2)
        try:
            data = self.provider2.get(self.index2)
            p, l, e, els, c, r = data[:6]
            info = data[6] if len(data) > 6 else None
            if self.scene2 is None: self.scene2 = Scene()
            self.scene2.ingest(p, l, e, els, c, r, info)
            self._reset_analysis_properties() # Reset dynamic properties for scene2
            self._validate_selection(self.scene2)
            self.scene2.set_replicas(*self.scene.replicas)
            self.selection_dirty = True
            self._mark_dirty(pos=True, sel=True)
            self._sync_gpu(self.scene2)
            self._mark_dirty(mat=True) # Force material sync on frame load
            if self.show_polyhedra: self._calc_all_polyhedra()
            # Live analysis & Coloring for secondary view
            self._update_coloring(self.scene2)
            if self.show_rdf: self._calc_rdf() 
            if self.show_z_profile: self._calc_z_profile()
        except Exception as err:
            print(f"Error loading frame2 {index}: {err}")

    def _load_frame(self, index: int):
        self._load_frame1(index)
        if self.sync_frames:
            self._load_frame2(index)

    def _validate_selection(self, scene: Scene):
        """Removes out-of-bounds selection indices when frame atom counts change."""
        if not scene.selected_atoms: return
        valid = [idx for idx in scene.selected_atoms if idx < scene.N]
        if len(valid) != len(scene.selected_atoms):
            scene.selected_atoms = valid
            scene.selected_set = set(valid)
            self.selection_dirty = True
            self._mark_dirty(sel=True, mat=True) # Ensure GPU highlights update

    def _sync_gpu(self, scene: Optional[Scene] = None):
        """Updates GPU buffers lazily using dirty flags."""
        if scene is None: scene = self.scene
        
        # Track which scene was last uploaded to GPU to handle split-view switching
        if not hasattr(self, "_last_synced_scene_id"):
            self._last_synced_scene_id = -1
        
        # If we are rendering a DIFFERENT scene than the one last synced, 
        # we MUST force a re-sync even if the global dirty flags are False
        force_sync = (id(scene) != self._last_synced_scene_id)
        
        # 1. Structural Sync (Positions, Colors, Replicas)
        if force_sync or self._gpu_status.get("pos", True):
            # Use the SCENE colors as the source (can be CPK or Protein-Styled RGBA)
            colors = np.copy(scene.colors)
            if colors.shape[1] == 3:
                rgba = np.ones((len(colors), 4), dtype=np.float32)
                rgba[:, :3] = colors
                colors = rgba
            radii = np.copy(scene.radii)
            
            # Additional Protein Visibility Overrides (Show/Hide/Active Site)
            has_protein_viz = getattr(self, "show_protein_ribbon", False) or getattr(self, "protein_atom_mode", 0) > 0
            if has_protein_viz and scene.info and ('name' in scene.info or 'atom_name' in scene.info):
                atom_names = scene.info.get('atom_name', scene.info.get('name', []))
                res_names = scene.info.get('res_name', [])
                res_seqs = scene.info.get('res_id', [])
                
                # Standard protein definitions and backbone atoms
                # Professional protein definitions including common variants and modified AAs
                AMINO_ACIDS = {
                    "ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE", "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL", "SEC", "PYL",
                    "HSD", "HSE", "HSP", "MSE", "CYX", "CYS2", "HID", "HIE", "HIP", "GLUP", "ASPP", "LYSN"
                }
                from .analysis.protein_geometry import BACKBONE_ATOMS
                
                # Parse Active Site IDs
                active_ids = set()
                if self.protein_atom_mode == 3:
                     for x in self.active_site_str.split(','):
                         x = x.strip()
                         if x.isdigit(): active_ids.add(int(x))
                
                for i, name in enumerate(atom_names):
                    res = str(res_names[i]).strip().upper() if i < len(res_names) else ""
                    seq = int(res_seqs[i]) if i < len(res_seqs) else -1
                    is_protein = res in AMINO_ACIDS
                    if not is_protein: continue
                    
                    is_backbone = str(name).strip().upper() in BACKBONE_ATOMS
                    
                    if self.protein_atom_mode == 0: # Show All
                        if colors.shape[1] > 3:
                            colors[i, 3] *= self.protein_alpha # Master Alpha synergy
                    elif self.protein_atom_mode == 1: # Hide Backbone (Radii=0)
                        if is_backbone: 
                            radii[i] = 0.0
                            if colors.shape[1] > 3: colors[i, 3] = 0.0
                        else:
                            if colors.shape[1] > 3: colors[i, 3] *= self.protein_alpha
                    elif self.protein_atom_mode == 2: # Hide All Protein
                        radii[i] = 0.0
                        if colors.shape[1] > 3: colors[i, 3] = 0.0
                    elif self.protein_atom_mode == 3: # Active Site Focus
                        if seq not in active_ids: 
                            radii[i] = 0.0
                            if colors.shape[1] > 3: colors[i, 3] = 0.0
                        else:
                            if colors.shape[1] > 3: colors[i, 3] *= self.protein_alpha
                    elif self.protein_atom_mode == 4: # Ball and Stick
                        radii[i] = radii[i] * 0.25 # Shrink spheres
                        if colors.shape[1] > 3: colors[i, 3] *= self.protein_alpha
                
                # Hide original sidechain during preview
                if self.mutation_preview and self.mutation_preview.get("indices_to_hide"):
                    for idx in self.mutation_preview["indices_to_hide"]:
                        if idx < len(radii):
                            radii[idx] = 0.0
                            if colors.shape[1] > 3: colors[idx, 3] = 0.0
            
            # --- Polyhedra Atomic Scaling (Applied to all scenes) ---
            if self.show_polyhedra and self.polyhedra:
                centers, corners = set(), set()
                for p in self.polyhedra:
                    if not self.poly_settings.enabled_cn.get(p.cn, True): continue
                    if not self.poly_settings.enabled_species.get(p.center_element, True): continue
                    centers.add(p.center_idx)
                    for l_idx in p.ligand_indices:
                        corners.add(l_idx)
                
                c_scale = getattr(self.poly_settings, "center_radii_scale", 1.0)
                l_scale = getattr(self.poly_settings, "corner_radii_scale", 1.0)
                
                for idx in centers:
                    if idx < len(radii): radii[idx] *= c_scale
                for idx in corners:
                    if idx < len(radii) and idx not in centers:
                        radii[idx] *= l_scale
                
            self.rnd_sphere.upload_data(scene.pos, radii, colors)
            self.rnd_sphere.upload_replicas(scene.replica_offsets)
            self.rnd_bond.upload_replicas(scene.replica_offsets)
            
            # Recalculate and cache bond centers for faster per-frame culling
            if scene.bond_count > 0:
                b_s_idx, b_e_idx = scene.bonds[:, 0].astype(int), scene.bonds[:, 1].astype(int)
                b_shifts = scene.bonds[:, 2:5]
                p0_u = scene.pos[b_s_idx]
                p1_u = scene.pos[b_e_idx] + b_shifts @ scene.lat
                bc_u = (p0_u + p1_u) * 0.5
                
                # Dedicated Render Cache (suggested by user)
                self._bond_render_cache[id(scene)] = {
                    'p0_u': p0_u,
                    'p1_u': p1_u,
                    'bc_u': bc_u,
                    'b_s_idx': b_s_idx,
                    'b_e_idx': b_e_idx,
                    'b_shifts': b_shifts,
                    'timestamp': time.perf_counter()
                }
            else:
                if id(scene) in self._bond_render_cache:
                    del self._bond_render_cache[id(scene)]
            
            if self.show_bonds:
                if scene.bond_count == 0:
                    self._calc_bonds_simple(scene)
                self.rnd_bond.upload_data(scene.pos, np.array(scene.bonds), 
                                          colors, lattice=scene.lat)

        # 2. Selection Sync
        if force_sync or self._gpu_status.get("sel", True):
            self.rnd_sphere.upload_selection(list(scene.selected_atoms), scene.N)

        # 3. Protein Sync
        if (force_sync or getattr(self, "protein_ribbon_dirty", False)) and self.show_protein_ribbon:
            self._sync_protein(scene)
            
        # 4. Polyhedra Sync
        if (force_sync or self.poly_dirty) and self.show_polyhedra:
            self._sync_polyhedra(scene)
            
        self._last_synced_scene_id = id(scene)
            
    def _sync_protein(self, scene: Scene):
        """Generates and uploads protein ribbon geometry."""
        from .analysis.protein_geometry import extract_protein_chains, assign_secondary_structure, generate_catmull_rom_spline, generate_ribbon_mesh
        chains = extract_protein_chains(scene.pos, scene.info)
        
        all_v, all_n, all_c, all_i = [], [], [], []
        idx_offset = 0
        
        for chain in chains:
            pts = np.array([c['CA'] for c in chain if 'CA' in c])
            if len(pts) < 4: continue
            
            # SS assignment is now handled inside generate_ribbon_mesh for each chain
            v, n, c, i = generate_ribbon_mesh(chain, segments=8, 
                                              thickness=self.protein_ribbon_t, width=self.protein_ribbon_w,
                                              color_helix=self.ribbon_color_helix,
                                              color_sheet=self.ribbon_color_sheet,
                                              color_coil=self.ribbon_color_coil)
            
            if len(v) > 0:
                all_v.append(v)
                all_n.append(n)
                all_c.append(c)
                all_i.append(i + idx_offset)
                idx_offset += len(v)
                
        if all_v:
            fv = np.vstack(all_v)
            fn = np.vstack(all_n)
            fc = np.vstack(all_c)
            fi = np.concatenate(all_i)
            
            # Select appropriate renderer instance depending on scene
            rnd = self.rnd_protein if scene == self.scene else self.rnd_protein2
            rnd.upload_data(fv, fn, fc, fi)
        else:
            rnd = self.rnd_protein if scene == self.scene else self.rnd_protein2
            rnd.upload_data(np.array([]), np.array([]), np.array([]), np.array([]))
            
        self.protein_ribbon_dirty = False

    def _sync_polyhedra(self, scene: Scene):
        """Batches and uploads polyhedra geometry to the GPU."""
        if not self.poly_dirty or not self.show_polyhedra:
            return
            
        if not self.polyhedra:
            if self.rnd_poly:
                self.rnd_poly.upload_data(np.array([]), np.array([]), np.array([]), np.array([]), np.array([]))
            self.poly_dirty = False
            return

        all_v, all_n, all_c, all_ids = [], [], [], []
        
        for poly_id, poly in enumerate(self.polyhedra):
            # Visual Filtering
            if not self.poly_settings.enabled_cn.get(poly.cn, True):
                continue
            if not self.poly_settings.enabled_species.get(poly.center_element, True):
                continue

            v_orig = poly.vertices
            if v_orig is None or len(v_orig) < 3: continue
            
            f = poly.faces
            if f is None or len(f) == 0: continue
            
            # Sanitization: Ensure indices are within local bounds
            f = f[np.all(f < len(v_orig), axis=1)]
            if len(f) == 0: continue
            
            center = self.scene.pos[poly.center_idx]
            scale = getattr(self.poly_settings, "scale", 1.01)
            v_local = (v_orig - center) * scale
            c = CPK_COLORS.get(poly.center_element, (0.5, 0.5, 0.5))
            
            for offset in self.scene.replica_offsets:
                v_world = center + offset + v_local
                
                # Expand vertices for DrawArrays (3 vertices per triangle)
                v_expanded = v_world[f.flatten()].astype(np.float32)
                
                # Simple flat normals per triangle
                v0 = v_expanded[0::3]
                v1 = v_expanded[1::3]
                v2 = v_expanded[2::3]
                n_tri = np.cross(v1 - v0, v2 - v0)
                n_len = np.linalg.norm(n_tri, axis=1, keepdims=True)
                n_tri = np.divide(n_tri, n_len, out=np.zeros_like(n_tri), where=n_len > 1e-9)
                n_expanded = np.repeat(n_tri, 3, axis=0).astype(np.float32)
                
                all_v.append(v_expanded)
                all_n.append(n_expanded)
                all_c.append(np.tile(c, (len(v_expanded), 1)).astype(np.float32))
                all_ids.append(np.full(len(v_expanded), poly_id, dtype=np.uint32))
            
        if all_v:
            fv = np.vstack(all_v)
            fn = np.vstack(all_n)
            fc = np.vstack(all_c)
            fids = np.concatenate(all_ids)
            
            # Diagnostic
            vmin, vmax = np.min(fv, axis=0), np.max(fv, axis=0)
            print(f"[Scientific Geometry] Final Flush: {len(fv)//3} triangles.")
            print(f"[Scientific Geometry] World Range: {vmin} to {vmax}")
            
            if self.rnd_poly:
                # We send zeros for indices as we use glDrawArrays
                self.rnd_poly.upload_data(fv, fn, fc, np.zeros(0, 'u4'), fids)
        else:
            if self.rnd_poly:
                self.rnd_poly.upload_data(np.zeros((0,3), 'f'), np.zeros((0,3), 'f'), 
                                          np.zeros((0,3), 'f'), np.zeros(0, 'u4'), np.zeros(0, 'u4'))
            
        self.poly_dirty = False

    def _get_element_colors(self, scene: Scene, force_refresh: bool = False):
        """Builds a color array, with caching for Element mode."""
        # If in an analysis mode (Coordination, Z-pos, etc.), use the scene's dynamic colors
        if self.color_mode != "Element":
            return scene.colors
        
        if self._cached_element_colors is not None and not force_refresh:
            if len(self._cached_element_colors) == scene.N:
                return self._cached_element_colors
            
        from .constants import CPK_COLORS
        # Pre-fill with gray default for full length to avoid zeros
        colors = np.tile([0.5, 0.5, 0.5], (scene.N, 1)).astype(np.float32)
        for i in range(scene.N):
            el = scene.elements[i] if (scene.elements and i < len(scene.elements)) else "X"
            if el not in self.element_materials:
                # Fallback / Initializer with better HQ defaults
                self.element_materials[el] = {
                    'col': list(CPK_COLORS.get(el, [0.5, 0.5, 0.5])),
                    'ambient': 0.4, 'specular': 0.6, 'shininess': 48.0, 'rim': 0.8,
                    'sheen': 0.1, 'clearcoat': 0.2, 'env': 0.4, 'gloss': 0.7
                }
            colors[i] = self.element_materials[el]['col']
            
        self._cached_element_colors = colors
        return colors

    def _center_camera(self):
        mn, mx = self.scene.get_full_bounds()
        center = (mn + mx) * 0.5
        diag = float(np.linalg.norm(mx - mn))
        if diag < 1e-4: diag = 5.0 # Ensure non-zero distance for single atoms
        
        self.cam.center = center.astype(np.float32)
        self.cam.offset = np.array([1.5*diag, 1.5*diag, diag], dtype=np.float32)
        self.cam.ortho_scale = diag * 1.5
        self.cam.snap_isometric()

    def loop(self):
        fps_hist = []
        while not glfw.window_should_close(self.win):
            t0 = glfw.get_time()
            glfw.poll_events()
            
            # --- Dynamic Size Sync ---
            self._sync_provider_size()
            
            # --- Analysis Results ---
            self.analysis.update()
            
            # --- Camera Physics ---
            tnow = glfw.get_time()
            if not hasattr(self, "_last_time"): self._last_time = tnow
            dt_step = tnow - self._last_time
            self._last_time = tnow
            
            if not self._exporting_sequence:
                self.cam1.update(dt_step)
                if self.split_view: self.cam2.update(dt_step)
                self._update_camera_keyboard(dt_step)
                if getattr(self, "auto_spin", False):
                    self.cam1.rotate_yaw(getattr(self, "auto_spin_speed", 0.5) * dt_step)
                    if self.split_view and self.sync_cameras:
                        self.cam2.center = np.copy(self.cam1.center)
                        self.cam2.offset = np.copy(self.cam1.offset)
                        self.cam2.up = np.copy(self.cam1.up)
                self._handle_gallery_input()
                self._handle_mouse_polling()
                
                self._update_playback()
                self._update_playback_keyframes()
            else:
                self._drive_professional_export()
            
            # Adaptive Quality Logic
            avg_fps = self.quality.current_fps
            if fps_hist: avg_fps = sum(fps_hist) / len(fps_hist)
            self.quality.adjust(avg_fps, total_atoms=self.scene.N, pretty_render=self.pretty_render)
            
            # Rendering
            w, h = glfw.get_framebuffer_size(self.win)
            glViewport(0, 0, w, h)
            glClearColor(*self.bg_color, 1.0)
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
            
            self._render_scene(w, h)
            if self.show_gui:
                self._render_gui()
            
            # --- Structural Workshop Logic ---
            if self.struct_editor.relax_active:
                self.struct_editor.step_progressive_relaxation()
                self._mark_dirty(pos=True)
                
            self.struct_editor.run_validation_if_due()
            self._update_structural_ghost()
            
            glfw.swap_buffers(self.win)
            
            # FPS & Frame Time Tracking
            t1 = glfw.get_time()
            dt = t1 - t0
            self.quality.current_frame_ms = dt * 1000.0
            if dt > 0:
                self.quality.current_fps = 1.0 / dt
                fps_hist.append(self.quality.current_fps)
                if len(fps_hist) > 20: fps_hist.pop(0)
            
        self.gui_impl.shutdown()
        glfw.terminate()

    def _render_scene(self, w, h):
        """Orchestrates split-view or single-view rendering."""
        if self.split_view:
            # Clear once for both views
            bg = [0.03, 0.04, 0.06] if self.pretty_render else self.bg_color
            glClearColor(*bg, 1.0)
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
            
            # Reset ID Buffer for this frame
            self.id_picking.resize(w, h)
            self.id_picking.clear()
            
            # 1. Left Viewport (Scene 1, Cam 1)
            self._render_pass(self.scene, self.cam1, 0, 0, w//2, h)
            # 2. Right Viewport (Scene 2, Cam 2)
            s2 = self.scene2 if self.scene2 else self.scene
            self._render_pass(s2, self.cam2, w//2, 0, w//2, h)
        else:
            bg = self.bg_color # Use user bg color correctly
            glClearColor(*bg, 1.0)
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
            
            self.id_picking.resize(w, h)
            self.id_picking.clear()
            
            if self.gallery.enabled:
                # Ensure we don't clear between gallery sub-passes
                self._render_gallery_scene(w, h)
            else:
                self._render_pass(self.scene, self.cam1, 0, 0, w, h)

        # Clear dirty flags AFTER all passes are done
        self._mat_tbo_dirty = False
        self._gpu_status["mat"] = False
        self._gpu_status["pos"] = False
        self._gpu_status["sel"] = False

    def _update_clipping_planes(self, scene: Scene, cam: OrbitCamera):
        """Calculates dynamic near/far planes based on scene bounds and camera target for optimal visibility."""
        mn, mx = scene.get_full_bounds()
        scene_center = 0.5 * (mn + mx)
        scene_diag = max(1.0, float(np.linalg.norm(mx - mn)))
        eye = cam.eye()
        
        # Distance to the global scene center (useful for far plane)
        dist_to_center = float(np.linalg.norm(scene_center - eye))
        # Distance to the specific camera target (useful for near plane)
        dist_to_target = float(np.linalg.norm(cam.offset))
        radius = 0.5 * scene_diag
        
        # Near plane should be small enough when zoomed in, but follow the target
        # Reduced factor from 0.01 to 0.001 and min from 0.005 to 0.001 for better close-ups
        if not hasattr(self, "_manual_near_clip"): self._manual_near_clip = -1.0
        
        if self._manual_near_clip > 0:
            cam.near = self._manual_near_clip
        else:
            cam.near = max(0.001, min(0.1, 0.001 * dist_to_target))
        # Far plane must cover the entire scene bounds
        cam.far = dist_to_center + 1.5 * scene_diag + 50.0

    def _render_pass(self, scene: Scene, cam: OrbitCamera, x: int, y: int, w: int, h: int, target_fbo=None, clear=True):
        """Processes one complete viewport render pass with OIT and shadows."""
        if scene.N == 0: return
        
        # Ensure GPU buffers are synced for THIS specific scene before drawing
        self._sync_gpu(scene)
        
        interactive = self._camera_is_interacting()
        aspect = w / h if h > 0 else 1.0
        
        # Ensure clipping planes are dynamic for every frame (Fixes clipping bugs on zoom)
        self._update_clipping_planes(scene, cam)
        
        view = cam.get_view_matrix()
        proj = cam.get_projection_matrix(aspect, is_ortho=self.is_ortho)

        # --- 0. Resource Resizing ---
        if self.pretty_render:
            self.post_process.resize(w, h)
        # REMOVED: self.id_picking.resize(w, h) - Causes collisions in split view.
        # Resizing is now handled globally in _render_scene.

        # --- 1. ID Picking Pass (MOVED to _render_opaque_scene for frame-parity) ---
        # (Pass removed from here to ensure it uses current frame's culled atoms)
            
        # --- 2. Main Pass (Opaque Content) ---
        self._maybe_update_clipping_alpha()
        
        if self.show_polyhedra or self.show_voronoi_cells:
            self._update_scientific_geometry_cache(scene)
            
        # Main Draw Call Sync
        self._update_material_tbo(scene)
        
        # OIT Setup (only if pretty-render is on and not interacting)
        use_oit = not interactive and self.pretty_render
        
        if self.pretty_render:
            # PostProcessor.begin binds self.fbo_main and clears it (respecting viewport)
            v_rect = (x, y, w, h)
            self.post_process.begin(clear_color=(*self.bg_color, 1.0), viewport=v_rect)
            glViewport(x, y, w, h)
        else:
            # Standard path: Bind target or screen
            glBindFramebuffer(GL_FRAMEBUFFER, target_fbo or 0)
            if not target_fbo: glViewport(x, y, w, h)
            else: glViewport(0, 0, w, h)
            if clear:
                glClearColor(*self.bg_color, 1.0)
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        # Draw Opaque Content
        # Calculate visibility once for all sub-passes
        aspect = w / h if h > 0 else 1.0
        dummy_proj = cam.get_projection_matrix(aspect, is_ortho=self.is_ortho)
        visible_replica_indices = self.rnd_sphere.get_visible_offsets(view, dummy_proj, scene.replica_offsets, scene.get_full_bounds())
        
        self._render_opaque_scene(scene, cam, view, proj, x, y, w, h, visible_replica_indices)
        
        # Unit Cell Rendering
        if self.show_cell:
            # Check if we are in gallery to apply optional offset
            offset = getattr(cam, 'gallery_offset', None)
            self._draw_unit_cell(scene, cam, view, proj, offset=offset)
        
        # Draw Scientific Geometry (Standard Blending)
        if self.show_polyhedra or self.show_voronoi_cells:
            self._draw_scientific_geometry(view, proj, is_oit=False)

        # --- 3. Transparency Pass (OIT) ---
        if use_oit:
            # Synchronize OIT FBO size
            if w != self._oit_w or h != self._oit_h:
                self._init_oit_fbo(w, h)
                self._oit_w, self._oit_h = w, h
            
            # Bind and Clear OIT Buffers (Keep Depth!)
            glBindFramebuffer(GL_FRAMEBUFFER, self.oit_fbo)
            glViewport(0, 0, w, h)
            glClearColor(0.0, 0.0, 0.0, 0.0) 
            glClear(GL_COLOR_BUFFER_BIT) 
            glClearBufferfv(GL_COLOR, 1, np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32))
            
            glEnable(GL_BLEND)
            try:
                glBlendFunci(0, GL_ONE, GL_ONE) 
                glBlendFunci(1, GL_ZERO, GL_ONE_MINUS_SRC_COLOR)
            except:
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

            # Draw Transparents (OIT Phase) - Ribbons/Ghosts only
            self._render_transparent_scene(scene, cam, view, proj, w, h, visible_replica_indices, is_oit=True)
            
            glDisable(GL_BLEND)
            
            # Resolve OIT into Main FBO
            glBindFramebuffer(GL_FRAMEBUFFER, self.post_process.fbo_main)
            self._resolve_oit(w, h)
        else:
            # Fallback for ribbons/ghosts/volumes when OIT is disabled
            self._render_transparent_scene(scene, cam, view, proj, w, h, visible_replica_indices, is_oit=False)
        
        # --- 4. Final Resolve (PostProcessor) ---
        if self.pretty_render:
            # Populate projection matrices for SSAO/Effects
            self.materials['proj'] = proj
            self.materials['projInv'] = np.linalg.inv(proj)
            
            # PostProcess.end applies SSAO/Bloom to EVERYTHING in fbo_main
            self.post_process.end(self.materials, 
                                 show_ssao=self.materials.get('show_ssao', True),
                                 show_bloom=self.materials.get('show_bloom', True),
                                 show_fxaa=self.materials.get('show_fxaa', False),
                                 near=cam.near, far=cam.far,
                                 viewport=(x, y, w, h),
                                 is_ortho=self.is_ortho,
                                 target_fbo=target_fbo or 0)
        
        # --- 5. UI Overlays (Screen Space or World HUD) ---
        if self.show_origin_axes: self._draw_origin_axes(view, proj)
        if self.show_com: self._draw_com(view, proj)
        if self.show_axes: self._draw_axes_hud(cam, x, y, w, h)
        if self.protein_dist_pair != (-1, -1): self._draw_ruler(scene, view, proj)
        self._draw_structural_ghosts()
    def _render_opaque_scene(self, scene: Scene, cam: OrbitCamera, view, proj, x, y, w, h, visible_replica_indices):
        """Draws opaque atoms, bonds, and mutation ghosts."""
        t_start = time.perf_counter()
        interactive = self._camera_is_interacting()
        
        if not visible_replica_indices: return

        # 1. Culling & Sorting
        v_pairs_atoms_main = self._cull_and_sort_atoms(scene, cam, view, proj, visible_replica_indices, w, h)
        
        # 2. Sync Picking Pass (Use EXACT matrices from this pass)
        if not interactive or self.quality.lod_level < 2:
             h_idx = self.hover_info['index'] if (self.hover_info and self.hover_info['type'] == 'atom') else -1
             self._run_id_buffer_pass(scene, cam, x, y, w, h, self.atom_scale, self.is_ortho, v_pairs_atoms_main, view, proj, h_idx)

        # 3. Main Opaque Pass
        t_now = glfw.get_time()
        shadow_matrix = self._get_shadow_matrix(scene, visible_replica_indices) if self.pretty_render else None
        shading_tier = 2 if self.pretty_render else 1

        self.rnd_sphere.draw(view, proj, v_pairs_atoms_main, 
                             ortho_scale=cam.ortho_scale, viewport_height=h, 
                             lights=self.lights, materials=self.materials,
                             atom_scale=self.atom_scale, fov=cam.fov, is_ortho=self.is_ortho,
                             skip_px=self.quality.skip_px, point_px=self.quality.point_px,
                             shading_tier=shading_tier, pretty_render=self.pretty_render, shadow_matrix=shadow_matrix,
                             reflection_intensity=self.materials.get('reflection_intensity', 1.0),
                             reflection_gloss=self.materials.get('reflection_gloss', 1.0),
                             fog_density=self.materials.get('fog_density', 0.0), time=t_now,
                             hover_idx=self.hover_info['index'] if (self.hover_info and self.hover_info['type'] == 'atom') else -1)
        
        # Bonds
        if self.show_bonds and scene.bond_count > 0:
            self._render_bonds(scene, cam, view, proj, visible_replica_indices, shadow_matrix, shading_tier, w, h)
            
        # Protein Ribbon (SOLID)
        if self.show_protein_ribbon:
            rnd = self.rnd_protein if scene == self.scene else self.rnd_protein2
            # Use opacity=1.0 and is_oit=False for solid rendering
            rnd.draw(view, proj, np.eye(4, dtype=np.float32), cam.eye(), 
                     is_pretty_render=self.pretty_render, opacity=1.0, is_oit=False, 
                     lights=self.lights, materials=self.materials,
                     shadow_matrix=shadow_matrix, shadow_map=self.rnd_sphere.shadow_tex,
                     shadow_size=getattr(self.rnd_sphere, "shadow_size", 1024))
            
        self.quality.current_timings["opaque"] = (time.perf_counter() - t_start) * 1000.0

    def _render_transparent_scene(self, scene: Scene, cam: OrbitCamera, view, proj, w, h, visible_replica_indices, is_oit: bool = True):
        """Draws transparent elements (ghosts, volumes, meshes, protein)."""
        t_now = glfw.get_time()
        
        # Shadows configuration for transparent pass
        shadow_matrix = self._get_shadow_matrix(scene, visible_replica_indices) if self.pretty_render else None
        shadow_map = self.rnd_sphere.shadow_tex if self.pretty_render else 0
        shadow_size = getattr(self.rnd_sphere, "shadow_size", 1024)

        # 1. Mutation Ghosts (Transparent)
        if self.mutation_ghost_data is not None:
             ghosts = self.mutation_ghost_data
             if len(ghosts['pos']) > 0:
                 self.rnd_ghost.upload_data(ghosts['pos'], ghosts['radii'], ghosts['colors'])
                 v_pairs = np.column_stack([np.arange(len(ghosts['pos'])), np.zeros(len(ghosts['pos']))]).astype(np.uint32)
                 gh_materials = self.materials.copy()
                 gh_materials['show_shadows'] = False 
                 self.rnd_ghost.draw(view, proj, v_pairs, 
                                      ortho_scale=cam.ortho_scale, viewport_height=h,
                                      lights=self.lights, materials=gh_materials,
                                      atom_scale=self.atom_scale, fov=cam.fov, is_ortho=self.is_ortho,
                                      skip_px=0.0, point_px=4.0, pretty_render=False)

        # 2. Protein Ribbon (MOVED TO OPAQUE PASS)
        # [Removed from here to ensure solidity in _render_opaque_scene]

        # 3. Volumetric/Mesh Data
        if (self.vol_enabled and self.vol_data) or self.tb_show_volume:
             iso = self.tb_vol_iso if self.tb_show_volume else self.vol_iso_level
             col_pos = tuple(self.vol_color[:3])
             col_neg = (1.0, 0.4, 0.2)
             self.rnd_volume.draw(view, proj, cam.eye(), iso_level=iso, mode=self.vol_mode_idx, col_pos=col_pos, col_neg=col_neg)

    def _cull_and_sort_atoms(self, scene, cam, view, proj, visible_replica_indices, w, h):
        """Helper to compute frustum-culled and sorted atom pairs."""
        # (Migration of the logic from old 1152-1282...)
        # Re-using the logic we saw in the view_file
        num_atoms = scene.N
        vp = proj @ view
        visible_pairs_wide = []
        
        if self._scratch_p4.shape[0] < num_atoms:
            self._scratch_p4 = np.ones((num_atoms, 4), dtype=np.float32)
        base_p4 = self._scratch_p4[:num_atoms]
        base_p4[:, :3] = scene.pos
        base_p4[:, 3] = 1.0
        
        inv_lat = np.linalg.inv(scene.lat) if self.clipping_enabled and self.clipping_fractional else None

        for real_rep_idx in visible_replica_indices:
            off = scene.replica_offsets[real_rep_idx]
            p_clip = (base_p4 + [off[0], off[1], off[2], 0.0]) @ vp.T
            w_vals = p_clip[:, 3]
            mask = (w_vals > (cam.near * 0.5)) & (w_vals < cam.far)
            mask &= (np.abs(p_clip[:, 0]) < (w_vals * 1.8))
            mask &= (np.abs(p_clip[:, 1]) < (w_vals * 1.8))
            
            if self.clipping_enabled and self.clipping_alpha <= 0.001:
                pos_rep = scene.pos + off
                vals = (pos_rep @ inv_lat)[:, self.clipping_axis] if self.clipping_fractional else pos_rep[:, self.clipping_axis]
                c_mask = (vals >= self.clipping_range[0]) & (vals <= self.clipping_range[1])
                if self.clipping_invert: c_mask = ~c_mask
                mask &= c_mask
                
            idx = np.where(mask)[0]
            if idx.size > 0:
                rep_col = np.full(idx.shape, real_rep_idx, dtype=np.uint32)
                visible_pairs_wide.append(np.column_stack([idx.astype(np.uint32), rep_col]))

        if not visible_pairs_wide: return np.zeros((0, 2), dtype=np.uint32)
        
        v_pairs_wide = np.vstack(visible_pairs_wide)
        v_pos = scene.pos[v_pairs_wide[:, 0]] + scene.replica_offsets[v_pairs_wide[:, 1]]
        dists_sq = np.sum((v_pos - cam.eye())**2, axis=1)
        sort_idx = np.argsort(dists_sq) # Opaque: Front-to-back
        return v_pairs_wide[sort_idx].astype(np.uint32)

    def _get_shadow_matrix(self, scene: Scene, visible_replica_indices):
        """Calculates orthogonal shadow projection matrix for the scene."""
        if not self.lights or not self.materials.get('show_shadows', True): return None
        from .renderer.utils import look_at, ortho
        mn, mx = scene.get_full_bounds()
        scene_diag = np.linalg.norm(mx - mn)
        l_dir = np.array(self.lights[0]['pos'], dtype=np.float32)
        l_dir /= np.linalg.norm(l_dir) + 1e-8
        center = 0.5 * (mn + mx)
        l_eye = center + l_dir * (4.0 * scene_diag + 1.0)
        l_up = np.array([0,1,0], dtype=np.float32) if abs(l_dir[1]) < 0.9 else np.array([0,0,1], dtype=np.float32)
        l_view = look_at(l_eye, center, l_up)
        corners = np.array([[mn[0],mn[1],mn[2]], [mn[0],mn[1],mx[2]], [mx[0],mx[1],mx[2]]], dtype=np.float32)
        corners_h = np.c_[corners, np.ones(3, dtype=np.float32)]
        pts_ls = (l_view @ corners_h.T).T[:, :3]
        l_mn, l_mx = pts_ls.min(axis=0), pts_ls.max(axis=0)
        pad = 0.1 * scene_diag + 1.0
        l_proj = ortho(l_mn[0]-pad, l_mx[0]+pad, l_mn[1]-pad, l_mx[1]+pad, max(0.1, -l_mx[2]-pad), max(10.0, -l_mn[2]+pad))
        bias = np.array([[0.5,0.0,0.0,0.5],[0.0,0.5,0.0,0.5],[0.0,0.0,0.5,0.5],[0.0,0.0,0.0,1.0]], dtype=np.float32)
        return bias @ l_proj @ l_view

    def _render_bonds(self, scene: Scene, cam: OrbitCamera, view, proj, visible_replica_indices, shadow_matrix, tier, w, h):
        """Processes and draws bonds for the scene."""
        if id(scene) not in self._bond_render_cache: return
        t_now = glfw.get_time()
        cache = self._bond_render_cache[id(scene)]
        bc_u = cache['bc_u']
        vp = proj @ view
        visible_pairs = []
        base_b_p4 = np.ones((scene.bond_count, 4), dtype=np.float32)
        base_b_p4[:, :3] = bc_u
        for real_rep_idx in visible_replica_indices:
            off = scene.replica_offsets[real_rep_idx]
            pcb = (base_b_p4 + [off[0], off[1], off[2], 0.0]) @ vp.T
            wb = pcb[:, 3]
            mask = (wb > (cam.near * 0.5)) & (wb < cam.far) & (np.abs(pcb[:, 0]) < (wb * 1.5)) & (np.abs(pcb[:, 1]) < (wb * 1.5))
            idx = np.where(mask)[0]
            if idx.size > 0:
                visible_pairs.append(np.column_stack([idx.astype(np.uint32), np.full(idx.shape, real_rep_idx, dtype=np.uint32)]))
        
        if visible_pairs:
            v_pairs = np.vstack(visible_pairs)
            self.rnd_bond.draw(view, proj, v_pairs, ortho_scale=cam.ortho_scale, viewport_height=h,
                               lights=self.lights, materials=self.materials, bond_scale=self.bond_scale,
                               shading_tier=tier, pretty_render=self.pretty_render, shadow_matrix=shadow_matrix,
                               shadow_map=self.rnd_sphere.shadow_tex, shadow_size=self.rnd_sphere.shadow_size, time=t_now,
                               mat_tbo=self.rnd_sphere.mat_tbo, mat_tbo2=self.rnd_sphere.mat_tbo2)

    def _draw_axes_hud(self, cam: OrbitCamera, x, y, w, h):
        """Renders small RGB coordinate axes in the corner of the viewport."""
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_ALWAYS) # HUD on top
        hud_size = 80
        glViewport(x + 10, y + 10, hud_size, hud_size)
        view = cam.get_view_matrix()
        view[3, :3] = 0.0 # Remove translation
        view[3][3] = 1.0
        from .renderer.utils import ortho
        proj = ortho(-1.5, 1.5, -1.5, 1.5, -5.0, 5.0)
        tripod = np.array([[0,0,0], [1,0,0], [0,0,0], [0,1,0], [0,0,0], [0,0,1]], dtype=np.float32)
        for i, color in enumerate([[1,0,0,1], [0,1,0,1], [0,0,1,1]]):
            self.rnd_line.draw(view, proj, tripod[2*i:2*i+2], 1, self.rnd_sphere.rep_tbo, color=color)
        glViewport(x, y, w, h)

        glEnable(GL_DEPTH_TEST)

    def _draw_com(self, view, proj):
        """Renders a high-visibility crosshair at the center of mass."""
        if not self.scene or self.scene.N == 0: return
        com = np.mean(self.scene.pos, axis=0)
        line = np.array([com-[0.5,0,0], com+[0.5,0,0], com-[0,0.5,0], com+[0,0.5,0], com-[0,0,0.5], com+[0,0,0.5]], dtype=np.float32)
        glDisable(GL_DEPTH_TEST)
        for i in range(3):
            self.rnd_line.draw(view, proj, line[2*i:2*i+2], 1, self.rnd_sphere.rep_tbo, color=[1, 1, 1, 1])
        glEnable(GL_DEPTH_TEST)

    def _draw_origin_axes(self, view, proj):
        """Renders a 5A RGB tripod at the global origin."""
        tripod = np.array([[0,0,0], [5,0,0], [0,0,0], [0,5,0], [0,0,0], [0,0,5]], dtype=np.float32)
        colors = [[1,0,0,1], [0,1,0,1], [0,0,1,1]]
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)
        for i in range(3):
            self.rnd_line.draw(view, proj, tripod[2*i:2*i+2], 1, self.rnd_sphere.rep_tbo, color=colors[i])

    def _draw_ruler(self, scene: Scene, view, proj):
        """Renders a yellow line and distance label between two selected atoms."""
        i1, i2 = self.protein_dist_pair
        if i1 < scene.N and i2 < scene.N:
            p1, p2 = scene.pos[i1], scene.pos[i2]
            pts = np.vstack([p1, p2]).astype(np.float32)
            # Draw a yellow ruler line
            glDisable(GL_DEPTH_TEST)
            self.rnd_line.draw(view, proj, pts, 1, self.rnd_sphere.rep_tbo, color=[1, 1, 0, 1])
            glEnable(GL_DEPTH_TEST)

    def _draw_axes_hud(self, cam: OrbitCamera, x, y, w, h):
        """Renders small RGB coordinate axes in the corner of the viewport."""
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_ALWAYS) # HUD on top
        
        # 1. Setup small viewport in corner
        hud_size = 80
        glViewport(x + 10, y + 10, hud_size, hud_size)
        
        # 2. View: Rotation only
        # We want the axes to rotate with the camera but stay centered
        view = cam.get_view_matrix()
        view[3, :3] = 0.0 # Remove translation
        view[3][3] = 1.0
        
        # 3. Projection: Small ortho box
        proj = ortho(-1.5, 1.5, -1.5, 1.5, -5.0, 5.0)
        
        # 4. Data
        tripod = np.array([
            [0,0,0], [1,0,0], # X (Red)
            [0,0,0], [0,1,0], # Y (Green)
            [0,0,0], [0,0,1], # Z (Blue)
        ], dtype=np.float32)
        
        # Render each axis with its color
        for i, color in enumerate([[1,0,0,1], [0,1,0,1], [0,0,1,1]]):
            self.rnd_line.draw(view, proj, tripod[2*i:2*i+2], 1, 
                               self.rnd_sphere.rep_tbo, color=color)
        
        # Restore viewport
        glViewport(x, y, w, h)

    def _draw_com(self, view, proj):
        """Renders a high-visibility crosshair at the center of mass."""
        com = self.scene.get_com()
        glDisable(GL_DEPTH_TEST) # Crosshair always on top
        
        s = 1.0 # crosshair size
        cross = np.array([
            [com[0]-s, com[1], com[2]], [com[0]+s, com[1], com[2]], # X
            [com[0], com[1]-s, com[2]], [com[0], com[1]+s, com[2]], # Y
            [com[0], com[1], com[2]-s], [com[0], com[1], com[2]+s], # Z
        ], dtype=np.float32)
        # Gold/Yellow color for COM
        color = [1.0, 0.8, 0.0, 1.0]
        self.rnd_line.draw(view, proj, cross, 1, self.rnd_sphere.rep_tbo, color=color)

    def _draw_unit_cell(self, scene: Scene, cam: OrbitCamera, view, proj, offset=None, scale=1.0, center=None):
        """Draws the unit cell bounding box with optional spatial offset, scaling, and centering."""
        if scene.lat is None:
            return
            
        cell = scene.lat
        if np.allclose(cell, 0): return
        
        # Apply scaling and optional centering to the cell vectors
        raw_vertices = np.array([
            [0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0],
            [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]
        ]) @ cell
        
        if center is not None:
            vertices = (raw_vertices - center) * scale
        else:
            vertices = raw_vertices * scale
        
        # Define the 12 edges of the cube
        edges = []
        for i, j in [(0,1), (1,2), (2,3), (3,0), (4,5), (5,6), (6,7), (7,4), (0,4), (1,5), (2,6), (3,7)]:
            edges.extend([vertices[i], vertices[j]])
        edges = np.array(edges, dtype=np.float32)
        
        # Apply offset if provided (Gallery Mode)
        if offset is not None:
            edges = edges + offset
            
        # Draw with a slight emphasis (off-white)
        self.rnd_line.draw(view, proj, edges, 1, self.rnd_sphere.rep_tbo, color=[0.9, 0.9, 0.9, 0.8])
        glEnable(GL_DEPTH_TEST)

    def zoom_to_fit(self, smooth: bool = True):
        """Adjusts camera distance to fit the entire scene bounds without changing orientation."""
        if self.scene.N == 0: return
        
        mn, mx = self.scene.get_full_bounds()
        center = 0.5 * (mn + mx)
        diag = np.linalg.norm(mx - mn)
        
        # Calculate ideal distance based on FOV and bounding sphere
        fov_rad = math.radians(self.cam1.fov)
        dist = (diag * 0.5) / math.sin(fov_rad * 0.5)
        dist *= 1.1 # 10% margin
        
        if dist < 5.0: dist = 15.0
        
        # New offset keeping the same direction
        direction = normalize(self.cam1.offset)
        new_offset = direction * dist
        
        if smooth:
            self.cam1.set_fly_to(center=center, offset=new_offset, duration=0.8)
            if self.split_view:
                self.cam2.set_fly_to(center=center, offset=new_offset, duration=0.8)
        else:
            self.cam1.center = center
            self.cam1.offset = new_offset
            if self.split_view:
                self.cam2.center = center
                self.cam2.offset = new_offset
            self._mark_dirty(pos=True)

    def reset_view(self, center: Optional[np.ndarray] = None, dist: Optional[float] = None):
        """Re-centers camera on a specific point or the structural center/COM."""
        if self.scene.N == 0: return
        
        if center is None:
            center = self.scene.get_com()
        
        if dist is None:
            mn, mx = self.scene.get_full_bounds()
            dist = np.linalg.norm(mx - mn) * 1.2
            if dist < 5.0: dist = 15.0
        
        self.cam1.center = np.copy(center)
        self.cam1.offset = np.array([dist, dist, dist], dtype=np.float32)
        self.cam1.pan = np.zeros(2, dtype=np.float32)
        
        if self.split_view:
            self.cam2.center = np.copy(center)
            self.cam2.offset = np.copy(self.cam1.offset)
            self.cam2.pan = np.zeros(2, dtype=np.float32)

    def _update_material_tbo(self, scene: Scene):
        """Syncs material and color TBOs with per-element settings for a specific scene."""
        if not self._mat_tbo_dirty and not self._gpu_status.get("mat", False): return
        
        # Ensure all elements in THIS scene have material entries (using per-atom fallback)
        from .constants import CPK_COLORS
        for i in range(scene.N):
            el = scene.elements[i] if (scene.elements and i < len(scene.elements)) else "X"
            if el not in self.element_materials:
                self.element_materials[el] = {
                    'col': list(CPK_COLORS.get(el, [0.5, 0.5, 0.5])),
                    'ambient': 0.4, 'specular': 0.6, 'shininess': 48.0, 'rim': 0.8,
                    'sheen': 0.1, 'clearcoat': 0.2, 'env': 0.4, 'gloss': 0.7
                }

        # Sync Materials TBOs (pre-fill with defaults to avoid Zeros in shader)
        mat_arr1 = np.tile([0.4, 0.6, 48.0, 0.8], (scene.N, 1)).astype(np.float32)
        mat_arr2 = np.tile([0.0, 0.0, 0.3, 0.5], (scene.N, 1)).astype(np.float32)
        
        for i in range(scene.N):
            el = scene.elements[i] if (scene.elements and i < len(scene.elements)) else "X"
            m = self.element_materials[el]
            mat_arr1[i] = [m.get('ambient',0.4), m.get('specular',0.6), m.get('shininess',48.0), m.get('rim',0.8)]
            mat_arr2[i] = [m.get('sheen',0.0), m.get('clearcoat',0.0), m.get('env',0.3), m.get('gloss',0.5)]
            
        self.rnd_sphere.upload_materials(mat_arr1, mat_arr2)
        
        # Selection synchronization
        self.rnd_sphere.upload_selection(scene.selected_atoms, scene.N)
        # Note: We NO LONGER upload pos/radii/colors here to avoid overwriting structural overrides
        # that were set in _sync_gpu (like hidden sidechains). _sync_gpu is now the source of truth.


    def _render_pretty_window(self):
        """Advanced Visualizer Controls (Final Version)."""
        imgui.set_next_window_size(400, 600, imgui.FIRST_USE_EVER)
        imgui.begin("Pretty Render Settings", True)

        if imgui.collapsing_header("Global HQ Options", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
            _, self.materials['show_shadows'] = imgui.checkbox("Shadow Mapping (High Quality)", self.materials.get('show_shadows', True))
            
            # Resolution Dropdown
            res_options = ["512", "1024", "2048", "4096 (High)", "8192 (Ultra)"]
            vals = [512, 1024, 2048, 4096, 8192]
            changed_res, self.shadow_res_idx = imgui.combo("Shadow Quality", self.shadow_res_idx, res_options)
            if changed_res:
                self.rnd_sphere.change_shadow_res(vals[self.shadow_res_idx])
            
            _, self.materials['exposure'] = imgui.slider_float("Exposure", self.materials['exposure'], 0.1, 20.0)
            _, self.materials['gamma'] = imgui.slider_float("Gamma", self.materials['gamma'], 0.1, 5.0)
            _, self.materials['headlight'] = imgui.slider_float("Headlight", self.materials['headlight'], 0.0, 5.0)
            _, self.materials['shadow_intensity'] = imgui.slider_float("Shadow Intensity", self.materials['shadow_intensity'], 0.0, 1.0)
            _, self.materials['shadow_softness'] = imgui.slider_float("Shadow Soft (Blur)", self.materials['shadow_softness'], 0.1, 8.0)
            _, self.materials['shadow_bias'] = imgui.slider_float("Shadow Bias", self.materials.get('shadow_bias', 0.002), 0.0, 0.02)
            
            # Cleanup VFX controls
            imgui.separator()
            imgui.text("Post-Processing Effects:")
            if self.materials.get('show_ssao', True):
                _, self.materials['ssao_strength'] = imgui.slider_float("SSAO Strength", self.materials['ssao_strength'], 0.0, 5.0)
                _, self.materials['ssao_radius'] = imgui.slider_float("SSAO Radius (UV)", self.materials['ssao_radius'], 0.001, 0.1)
                _, self.materials['ssao_bias'] = imgui.slider_float("SSAO Bias (Depth)", self.materials['ssao_bias'], 0.0, 1.0)
                _, self.materials['debug_ao'] = imgui.checkbox("Debug: Show AO Only", self.materials.get('debug_ao', False))
                _, self.materials['debug_depth'] = imgui.checkbox("Debug: Show Depth Map", self.materials.get('debug_depth', False))
            
            _, self.materials['show_bloom'] = imgui.checkbox("Bloom (Glow)", self.materials['show_bloom'])
            if self.materials['show_bloom']:
                _, self.materials['bloom_intensity'] = imgui.slider_float("Bloom Intensity", self.materials['bloom_intensity'], 0.0, 5.0)
                _, self.materials['selection_glow'] = imgui.slider_float("Selection Glow", self.materials['selection_glow'], 0.0, 5.0)
            
            _, self.materials['show_fxaa'] = imgui.checkbox("FXAA (Smooth Edges)", self.materials['show_fxaa'])
            _, self.materials['show_outlines'] = imgui.checkbox("Selection Outlines (Silhouettes)", self.materials.get('show_outlines', True))
            _, self.materials['gamma'] = imgui.slider_float("Gamma Correction", self.materials['gamma'], 0.5, 3.0)
            
            imgui.separator()
            imgui.text("Atmosphere & Motion:")
            _, self.materials['fog_density'] = imgui.slider_float("Fog Density", self.materials['fog_density'], 0.0, 0.01)
            _, self.materials['pulse_amp'] = imgui.slider_float("Pulse Amplitude", self.materials['pulse_amp'], 0.0, 0.2)
            if self.materials['pulse_amp'] > 0:
                _, self.materials['pulse_speed'] = imgui.slider_float("Pulse Speed", self.materials['pulse_speed'], 0.0, 10.0)
            
            imgui.separator()
            imgui.text("Material Aesthetics:")
            _, self.materials['reflection_intensity'] = imgui.slider_float("Env Reflection", self.materials['reflection_intensity'], 0.0, 1.0)
            _, self.materials['reflection_gloss'] = imgui.slider_float("Glossiness/Sharpness", self.materials['reflection_gloss'], 0.0, 1.0)
            _, self.materials['sheen'] = imgui.slider_float("Sheen (Velvet)", self.materials['sheen'], 0.0, 1.0)
            _, self.materials['clearcoat'] = imgui.slider_float("Clearcoat (Gloss)", self.materials['clearcoat'], 0.0, 1.0)
            
            self._render_gui_lighting()

        if imgui.collapsing_header("Material Library (Per Element)")[0]:
            imgui.text("Bulk Styling (Apply to ALL):")
            changed_gp, self.global_preset_idx = imgui.combo("Global Preset", self.global_preset_idx, self.preset_options)
            if changed_gp:
                p_name = self.preset_options[self.global_preset_idx]
                preset_vals = self.material_presets[p_name]
                for e in self.element_materials:
                    self.element_materials[e].update(preset_vals)
                self._mark_dirty(mat=True)
            
            imgui.separator()
            for el, m in self.element_materials.items():
                if imgui.tree_node(f"[{el}] Properties"):
                    # Preset Selector
                    changed_p, p_idx = imgui.combo(f"Preset##{el}", 0, self.preset_options)
                    if changed_p:
                        m.update(self.material_presets[self.preset_options[p_idx]])
                        self._mark_dirty(mat=True)

                    ch1, m['col'] = imgui.color_edit3(f"Color##{el}", *m['col'])
                    ch2, m['ambient'] = imgui.slider_float(f"Ambient##{el}", m.get('ambient', 0.4), 0.0, 5.0)
                    ch3, m['specular'] = imgui.slider_float(f"Specular##{el}", m.get('specular', 0.6), 0.0, 10.0)
                    ch4, m['shininess'] = imgui.slider_float(f"Shininess##{el}", m.get('shininess', 48.0), 1.0, 512.0)
                    ch5, m['rim'] = imgui.slider_float(f"Rim##{el}", m.get('rim', 0.8), 0.0, 10.0)
                    
                    imgui.text("Advanced Aesthetic:")
                    ch6, m['sheen'] = imgui.slider_float(f"Sheen##{el}", m.get('sheen', 0.0), 0.0, 2.0)
                    ch7, m['clearcoat'] = imgui.slider_float(f"Clearcoat##{el}", m.get('clearcoat', 0.0), 0.0, 2.0)
                    ch8, m['env'] = imgui.slider_float(f"Env Intensity##{el}", m.get('env', 0.3), 0.0, 2.0)
                    ch9, m['gloss'] = imgui.slider_float(f"Glossiness##{el}", m.get('gloss', 0.5), 0.0, 1.0)

                    if any([ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9]): 
                        self._mark_dirty(mat=True)
                        if ch1: self._update_coloring()
                    imgui.tree_pop()

        imgui.text_disabled("(Tip: Hold 'L' + [1/2/3/4] + Drag to rotate different lights)")
        imgui.end()

    def _render_gui_lighting(self):
        """Interactive Multi-Light Switcher."""
        imgui.separator()
        imgui.text("Multi-Light Config:")
        
        # New selection for active light
        light_names = [f"Light {i+1}" for i in range(len(self.lights))]
        if light_names:
            _, self.selected_light_idx = imgui.combo("Interaction Focus", self.selected_light_idx, light_names)
            imgui.text_colored("Focus this light to use 'L' + Mouse rotation.", 0.6, 0.8, 1.0)

        if len(self.lights) < 4:
            if imgui.button("Add New Light"):
                self.lights.append({'pos': [1.0, 0.0, 0.0], 'col': [1.0, 1.0, 1.0]})

        for i in range(len(self.lights)-1, -1, -1):
            light = self.lights[i]
            opened, visible = imgui.collapsing_header(f"Light {i+1}##{i}", True)
            if not visible: self.lights.pop(i); continue
            if opened:
                changed_d, d = imgui.input_float3(f"Vector##{i}", *light['pos'])
                if changed_d: light['pos'] = list(d)
                changed_c, c = imgui.color_edit3(f"Color##{i}", *light['col'])
                if changed_c: light['col'] = list(c)
                if imgui.button(f"Remove Light##btn{i}"): self.lights.pop(i)

    def _run_soap_correlation(self):
        """Dispatches the SOAP correlation background job."""
        if not hasattr(self, "analysis"):
            print("[Viewer] Error: AnalysisManager not initialized.")
            return
            
        # Get species list from selection or fallback to all unique in scene
        selected_species = [s for s, enabled in self.soap_species_selection.items() if enabled]
        if not selected_species:
            selected_species = self.scene.unique_elements
        
        kwargs = {
            'pos': self.scene.pos,
            'labels': self.scene.elements,
            'lattice': self.scene.lat if self.scene.is_periodic else None,
            'pbc': bool(self.scene.is_periodic),
            'center_symbol': self.soap_center_symbol,
            'species': selected_species,
            'r_cut': self.soap_rcut,
            'n_max': self.soap_nmax,
            'l_max': self.soap_lmax,
            'sigma': self.soap_sigma,
            'dr': self.soap_dr,
            'dr_2d': self.soap_dr_2d,
            'n_min': self.soap_n_min,
            'fit_min': self.soap_fit_min,
            'fit_max': self.soap_fit_max,
            'search_cutoff': self.soap_search_cutoff,
            'plateau_r_range': tuple(self.soap_plateau_range) if self.soap_plateau_override else None
        }
        
        def callback(result):
            self.soap_results = result
            if self.show_soap_plot:
                # Plotting is handled in the main loop if show_soap_plot is True
                pass
            print(f"[Viewer] SOAP Analysis complete. Decorr length: {result.get('radial', {}).get('lambda', 0):.3f}")

        self.analysis.submit_job("soap_correlation", kwargs, callback=callback)

    def _draw_gui_output_export(self):
        """Redesigned Output & Export panel with organized sections."""
        if not imgui.collapsing_header("Output & Export")[0]:
            return

        # 1. Save Location
        if imgui.tree_node("Save Location", imgui.TREE_NODE_DEFAULT_OPEN):
            _, self.export_folder = imgui.input_text("Output Folder", self.export_folder, 256)
            _, self.export_base_name = imgui.input_text("Base Filename", self.export_base_name, 256)
            
            # Preview
            ext = self.export_formats[self.export_fmt_idx]
            preview_path = f"{self.export_folder}/{self.export_base_name}.{ext}"
            imgui.text_disabled(f"Preview: {preview_path}")
            imgui.tree_pop()

        imgui.separator()

        # 2. Screenshot
        if imgui.tree_node("Screenshot"):
            _, self.screenshot_fmt_idx = imgui.combo("Format##scr", self.screenshot_fmt_idx, self.screenshot_formats)
            imgui.combo("Resolution##scr", 0, ["Current View", "High Res (2x)", "4K UHD"]) 
            _, self.screenshot_bg_idx = imgui.combo("Background##scr", self.screenshot_bg_idx, self.screenshot_bg_modes)
            
            _, self.hide_hover_in_export = imgui.checkbox("Hide hover highlight##scr", self.hide_hover_in_export)
            _, self.show_cell = imgui.checkbox("Show unit cell##scr", self.show_cell)
            _, self.show_axes = imgui.checkbox("Show axes##scr", self.show_axes)
            
            if imgui.button("  Take Screenshot  "):
                self.save_screenshot()
            imgui.tree_pop()

        imgui.separator()

        # 3. Structure Export
        if imgui.tree_node("Structure Export"):
            _, self.export_fmt_idx = imgui.combo("Format##struct", self.export_fmt_idx, self.export_formats)
            _, self.export_all_frames = imgui.checkbox("Export All Frames##struct", self.export_all_frames)
            _, self.export_selected_only = imgui.checkbox("Selected Atoms Only##struct", self.export_selected_only)
            
            if imgui.button("  Export Structure  "):
                self.export_current_structure()
            imgui.tree_pop()

        imgui.separator()

        # 4. Animation / GIF Export
        if imgui.tree_node("Animation / GIF Export"):
            imgui.combo("Format##anim", 0, ["GIF", "MP4 (Pro)"])
            _, self.gif_frame_count = imgui.slider_int("Frames##anim", self.gif_frame_count, 2, 200)
            _, self.animation_fps = imgui.slider_int("FPS##anim", self.animation_fps, 1, 60)
            _, self.animation_selection_mode = imgui.combo("Selection##anim", self.animation_selection_mode, ["Uniform", "Random"])
            
            _, self.animation_loop = imgui.checkbox("Loop animation##anim", self.animation_loop)
            
            if imgui.button("  Export Animation  "):
                self.export_gif()
            imgui.tree_pop()

        if self.export_status:
            imgui.separator()
            imgui.text_colored(self.export_status, 0.5, 1.0, 0.5)

    def _render_gui(self):

        """Builds all ImGui UI windows."""
        # Update logical window size every frame to ensure UI elements adapt to resizing
        self.win_size = glfw.get_window_size(self.win)
        self.gui_impl.process_inputs()
        imgui.new_frame()
        
        self._draw_fps_overlay()
        self._draw_top_tab_bar() # Replaces separate Analysis and Selection windows
        self._draw_inspector()
        self._draw_selection_query_console()
        self._draw_measurements()
        
        if getattr(self, "show_workshop", False):
            imgui.set_next_window_size(360, 600, imgui.FIRST_USE_EVER)
            imgui.set_next_window_position(50, 100, imgui.FIRST_USE_EVER)
            opened, self.show_workshop = imgui.begin("Structural Workshop", True)
            if opened:
                self.builder_ui.draw_contents()
            imgui.end()

        if hasattr(self, "_show_camera_panel") and self._show_camera_panel:
            self._draw_camera_control_window()

        if self.gallery.enabled:
            w, h = self.win_size
            self._draw_gallery_hud(w, h)

        if self.show_help:
            self._draw_help_overlay()
            
        self._draw_annotations()
        
        # --- Advanced Selection Overlays ---
        draw_list = imgui.get_foreground_draw_list()
        if self.box_selecting:
            x1, y1 = self.scene.box_start
            x2, y2 = self.last_x, self.last_y
            draw_list.add_rect(x1, y1, x2, y2, imgui.get_color_u32_rgba(0.2, 0.6, 1.0, 0.5), 0, 15, 2.0)
            draw_list.add_rect_filled(x1, y1, x2, y2, imgui.get_color_u32_rgba(0.2, 0.6, 1.0, 0.15))
        
        if self._lasso_active and self._lasso_path:
            pts = [(p[0], p[1]) for p in self._lasso_path]
            # Add current mouse to path for visual continuity
            pts.append((self.last_x, self.last_y))
            if len(pts) > 1:
                draw_list.add_polyline(pts, imgui.get_color_u32_rgba(1.0, 0.8, 0.2, 1.0), False, 2.5)

        if self.pretty_render:
            self._render_pretty_window()

        # Regular Control Panel
        imgui.set_next_window_bg_alpha(0.65)
        imgui.set_next_window_size(300, 600, imgui.FIRST_USE_EVER)
        imgui.begin("Control Panel", True)

        if imgui.collapsing_header("Structure Overview")[0]:
            draw_structure_overview_panel(self)
            imgui.text("Selection & Interaction:")
            modes = ["Off", "Minimal", "Full"]
            _, self.hover_info_mode = imgui.combo("Hover Info", self.hover_info_mode, modes)

        if imgui.collapsing_header("Navigation & Playback")[0]:
            # Sync Toggles
            if self.split_view:
                _, self.sync_frames = imgui.checkbox("Sync Time Control", self.sync_frames)
                imgui.same_line()
                _, self.sync_cameras = imgui.checkbox("Sync Camera Orbit", self.sync_cameras)
                imgui.separator()

            n_frames = len(self.provider) if self.provider else 0
            max_idx = max(0, n_frames - 1)
            
            # Determine indices based on sort mode
            is_sorted = hasattr(self, "energy_sort_mode") and self.energy_sort_mode != 0 and hasattr(self, "energy_view_indices")
            view_indices = self.energy_view_indices if is_sorted else np.arange(n_frames)
            
            # Find current rank of index1
            try:
                current_rank = np.where(view_indices == self.index1)[0][0]
            except:
                current_rank = 0
            
            if not self.split_view or self.sync_frames:
                label = "Current Rank:" if is_sorted else "Global Index:"
                imgui.text(f"{label} ({current_rank} / {max_idx})")
                
                changed, new_rank = imgui.drag_int("##f_nav", current_rank, 1, 0, max(0, len(view_indices) - 1))
                if changed and len(view_indices) > 0:
                    new_rank = np.clip(new_rank, 0, len(view_indices) - 1)
                    self.index1 = int(view_indices[new_rank])
                    self._load_frame1(self.index1)
                    if self.split_view:
                        self.index2 = self.index1
                        self._load_frame2(self.index2)
            else:
                # Split view but not synced (rare for energy analytics but handled)
                imgui.text("Index A (Left):")
                changed1, r1 = imgui.drag_int("##f1_rank", current_rank, 1, 0, max(0, len(view_indices) - 1))
                if changed1 and len(view_indices) > 0:
                    self.index1 = int(view_indices[np.clip(r1, 0, len(view_indices) - 1)])
                    self._load_frame1(self.index1)
                
                imgui.text("Index B (Right):")
                n2 = len(self.provider2) if self.provider2 else n_frames
                # For index2, we might not have a sort, but let's assume it follows index1's sort if same provider
                try: r2 = np.where(view_indices == self.index2)[0][0]
                except: r2 = 0
                changed2, nr2 = imgui.drag_int("##f2_rank", r2, 1, 0, max(0, len(view_indices) - 1))
                if changed2 and len(view_indices) > 0:
                    self.index2 = int(view_indices[np.clip(nr2, 0, len(view_indices) - 1)])
                    self._load_frame2(self.index2)
            
            # Control Buttons
            can_nav = (n_frames > 0)
            if imgui.button(" |< ") and can_nav: 
                self.index1 = int(view_indices[0]); self._load_frame1(self.index1)
                if self.split_view and self.sync_frames: self.index2 = self.index1; self._load_frame2(self.index2)
            imgui.same_line()
            
            if imgui.button("  <  ") and can_nav: 
                prev_rank = max(0, current_rank - 1)
                self.index1 = int(view_indices[prev_rank]); self._load_frame1(self.index1)
                if self.split_view and self.sync_frames: self.index2 = self.index1; self._load_frame2(self.index2)
            imgui.same_line()
            
            btn_play = "Pause" if self.playback_playing else " Play "
            if imgui.button(btn_play) and can_nav:
                self.playback_playing = not self.playback_playing
            imgui.same_line()
            
            if imgui.button("  >  ") and can_nav: 
                next_rank = min(max_idx, current_rank + 1)
                self.index1 = int(view_indices[next_rank]); self._load_frame1(self.index1)
                if self.split_view and self.sync_frames: self.index2 = self.index1; self._load_frame2(self.index2)
            imgui.same_line()
            
            if imgui.button(" >| ") and can_nav: 
                last_rank = max_idx
                self.index1 = int(view_indices[last_rank]); self._load_frame1(self.index1)
                if self.split_view and self.sync_frames: self.index2 = self.index1; self._load_frame2(self.index2)
            imgui.same_line()
            
            if imgui.button("Reset View"): self._center_camera()
            imgui.same_line()
            if imgui.button(" Help (F1) "):
                self.show_help = not self.show_help

            # FPS
            imgui.separator()
            imgui.text("Playback Speed (FPS):")
            changed_f, self.playback_speed = imgui.drag_float("##fps_drag", self.playback_speed, 1.0, 1.0, 240.0, "%.1f FPS")
            if changed_f: self.playback_speed = max(0.1, self.playback_speed)

            # Energy Trace & Histogram
            imgui.separator()
            if hasattr(self, "all_energies") and self.all_energies.size > 0:
                new_idx = draw_energy_plots(self)
                if new_idx != -1:
                    self.index1 = new_idx
                    self._load_frame1(self.index1)
                    if self.split_view and self.sync_frames:
                        self.index2 = self.index1
                        self._load_frame2(self.index2)

        if imgui.collapsing_header("Trajectory Comparison")[0]:
            changed_split, self.split_view = imgui.checkbox("Split View Mode", self.split_view)
            if changed_split and self.split_view and self.provider2 is None:
                # Auto-clone if nothing loaded yet
                self.load_comparison(None)

            if imgui.button("Clone Current (Double View)"):
                self.load_comparison(None)
            
            imgui.separator()
            imgui.text("Load Second Trajectory (File Path):")
            changed_pth, self._comp_path = imgui.input_text("##comp_path", self._comp_path, 255)
            if imgui.button("Load & Sync"):
                from ..partition.Partition import Partition
                from .PartitionProvider import PartitionProvider
                try:
                    p = Partition()
                    p.read_files(self._comp_path)
                    p2 = PartitionProvider(p)
                    self.load_comparison(p2)
                except Exception as e:
                    print(f"Failed to load comparison: {e}")
            if self.provider2 and self.provider2 != self.provider:
                imgui.text_colored(f"Comparing with: {os.path.basename(self._comp_path)}", 0.3, 1.0, 0.3)
        
        if imgui.collapsing_header("Display Settings")[0]:
            _, self.is_ortho = imgui.checkbox("Orthographic Mode", self.is_ortho)
            
            p_changed, self.pretty_render = imgui.checkbox("Pretty Render (HQ)", self.pretty_render)
            if p_changed and self.pretty_render:
                self.materials['show_shadows'] = True
                self.materials['show_bloom'] = True
                self.materials['bloom_intensity'] = 0.075
                self._mark_dirty(mat=True)
                
            _, self.show_axes = imgui.checkbox("Show Coordinate Axes", self.show_axes)
            
            imgui.separator()
            imgui.text_disabled("Camera & Clipping:")
            imgui.text_wrapped("Advanced camera and depth settings have moved to the bottom bar.")
            if imgui.button("Open Professional Camera Panel"):
                self._show_camera_panel = True
            
            imgui.separator()
            
            _, self.atom_scale = imgui.slider_float("Atom Scale", self.atom_scale, 0.1, 3.0)
            
            
            # Supercell Controls
            imgui.text("Supercell (nx, ny, nz):")
            rx, ry, rz = self.scene.replicas
            changed_nx, rx = imgui.slider_int("nx", rx, 0, 20)
            changed_ny, ry = imgui.slider_int("ny", ry, 0, 20)
            changed_nz, rz = imgui.slider_int("nz", rz, 0, 20)
            if changed_nx or changed_ny or changed_nz:
                self.scene.set_replicas(rx, ry, rz)
                self._mark_dirty(pos=True)
                self._sync_gpu()
                # Auto-zoom to fit the new supercell size
                self.zoom_to_fit(smooth=True)
            
            if imgui.button("  Fit to Screen  "):
                self.zoom_to_fit(smooth=True)
                if self.show_polyhedra: 
                    self._calc_all_polyhedra()
            
            _, self.materials['replica_dimming'] = imgui.slider_float("Ghost Intensity", self.materials.get('replica_dimming', 1.0), 0.0, 1.0)
            
            changed_b, self.show_bonds = imgui.checkbox("Show Bonds", self.show_bonds)
            if changed_b: 
                self._mark_dirty(pos=True)
            _, self.show_cell = imgui.checkbox("Show Unit Cell", self.show_cell)
            
            _, self.bg_color = imgui.color_edit3("Background", *self.bg_color)

        if imgui.collapsing_header("Biomolecules")[0]:
            # --- Display & Representation ---
            if imgui.tree_node("Display & Representation", imgui.TREE_NODE_DEFAULT_OPEN):
                # Auto-run analysis if ribbon is toggled and we have no info
                if self.show_protein_ribbon and not self.protein_analysis_results:
                    self._run_biomolecule_analysis()
                
                ch, self.show_protein_ribbon = imgui.checkbox("Show Ribbon Mask", self.show_protein_ribbon)
                if ch: self.protein_ribbon_dirty = True
                
                if self.show_protein_ribbon and not self.rnd_protein.has_data:
                    imgui.same_line()
                    imgui.text_disabled("(No chains found)")
                    if imgui.is_item_hovered():
                        imgui.set_tooltip("The Ribbon representation requires a protein structure with C-alpha (CA) chains.\nIf you are viewing a crystal (like LLZO), try 'Polyhedra' instead.")
                
                ch_m, self.protein_atom_mode = imgui.combo("Atom Visibility", self.protein_atom_mode, ["Show All", "Side Chains Only", "Hide All Protein", "Active Site Only", "Ball & Stick"])
                if ch_m: 
                    if self.protein_atom_mode == 4: 
                        self.show_bonds = True
                        if self.scene.bond_count == 0:
                            self._calc_protein_bonds_fast(self.scene)
                    self._mark_dirty(pos=True)
                
                if self.protein_atom_mode == 3:
                    ch_a, self.active_site_str = imgui.input_text("Active Site (Res IDs)", self.active_site_str, 256)
                    if ch_a: self._mark_dirty(pos=True)
                
                imgui.separator()
                ch_w, self.protein_ribbon_w = imgui.slider_float("Ribbon Width", self.protein_ribbon_w, 0.5, 4.0)
                ch_t, self.protein_ribbon_t = imgui.slider_float("Ribbon Thickness", self.protein_ribbon_t, 0.1, 1.5)
                
                imgui.text("Ribbon Colors")
                c1, self.ribbon_color_helix = imgui.color_edit3("Helix", *self.ribbon_color_helix)
                c2, self.ribbon_color_sheet = imgui.color_edit3("Sheet", *self.ribbon_color_sheet)
                c3, self.ribbon_color_coil = imgui.color_edit3("Coil", *self.ribbon_color_coil)
                
                imgui.separator()
                imgui.text("Color Mode & Transparency")
                modes = ["Element (CPK)", "Residue Type", "Chain Index", "Backbone Focused"]
                ch1, self.protein_color_mode = imgui.combo("Color Mode", self.protein_color_mode, modes)
                
                ch2, self.protein_alpha = imgui.slider_float("Protein Alpha", self.protein_alpha, 0.01, 1.0)
                
                if ch1 or ch2:
                    self._apply_protein_coloring()
                    self._mark_dirty(pos=True) # Ensure transparency syncs to GPU
                
                if ch_w or ch_t or c1 or c2 or c3: 
                    self.protein_ribbon_dirty = True
                
                if imgui.button(" Reset Styles "):
                    self.protein_color_mode = 0
                    self.protein_alpha = 0.6
                    self._apply_protein_coloring()
                    self._mark_dirty(pos=True)
                
                imgui.tree_pop()

            # --- Structural Analysis (Interactive) ---
            if imgui.tree_node("Structural Analysis"):
                if self.protein_analysis_results:
                    res = self.protein_analysis_results
                    imgui.text_colored(f"Total Chains: {len(res.get('chains', []))}", 0.4, 0.8, 1.0)
                else:
                    imgui.text_disabled("Open a plot to compute metrics automatically.")
                    imgui.spacing()
                    
                if imgui.button(" Open Ramachandran Plot "): 
                    self.show_rama_plot = True
                imgui.same_line()
                if imgui.button(" Open Contact Map "): 
                    self.show_contact_map = True
                
                imgui.tree_pop()

            # --- Sequence Viewer ---
            if imgui.tree_node("Sequence & FASTA"):
                # Lazy-run analysis if sequence viewer is requested
                if imgui.button(" Open Sequence Explorer "): 
                    self.show_sequence_viewer = True
                
                if self.protein_analysis_results:
                    if imgui.button(" Export FASTA "):
                        self._export_fasta()
                else:
                    imgui.text_disabled("Analysis will run automatically when opened.")
                imgui.tree_pop()

            # --- Mutations & Design ---
            if imgui.tree_node("Mutations & Design"):
                if not self.scene.info or 'res_id' not in self.scene.info:
                    imgui.text_disabled("No protein context loaded.")
                elif not self.scene.selected_atoms:
                    imgui.text_disabled("Select a residue in 3D or Sequence.")
                    imgui.spacing()
                    
                    if self.mutation_engine.history:
                        if imgui.button("  Undo Last Mutation  "):
                            if self.mutation_engine.undo():
                                self.protein_ribbon_dirty = True
                                self.protein_analysis_results = {}
                                self.mutation_preview = None
                                self.mutation_ghost_data = None
                                self._mark_dirty(pos=True, sel=True)
                                self._sync_gpu()
                    if self.mutation_engine.redo_stack:
                        imgui.same_line()
                        if imgui.button("  Redo  "):
                            if self.mutation_engine.redo():
                                self.protein_ribbon_dirty = True
                                self.protein_analysis_results = {}
                                self.mutation_preview = None
                                self.mutation_ghost_data = None
                                self._mark_dirty(pos=True, sel=True)
                                self._sync_gpu()
                else:
                    # Context
                    first_idx = self.scene.selected_atoms[0]
                    # Support both numeric and string-based identifiers (e.g. Chain 'A')
                    ch_info = self.scene.info.get('chain_index', self.scene.info.get('chain', [0]*self.scene.N))
                    ch_idx = ch_info[first_idx]
                    
                    r_info = self.scene.info.get('res_id', [0]*self.scene.N)
                    r_id = r_info[first_idx]
                    r_name = str(self.scene.info.get('res_name', ["UNK"]*self.scene.N)[first_idx]).strip().upper()
                    
                    imgui.text_colored(f"Active Context: Chain {ch_idx}, Res {r_id} [{r_name}]", 0.4, 0.8, 1.0)
                    imgui.separator()
                    
                    # Tools
                    cur_target = self.mutation_targets[self.mutation_target_idx] if len(self.mutation_targets) > self.mutation_target_idx else "ALA"
                    
                    # 20 Standard Amino Acids Button Grid
                    aa_grid = [
                        ("ALA", "A", (0.7, 0.7, 0.7)), ("CYS", "C", (0.8, 0.8, 0.3)),
                        ("ASP", "D", (0.9, 0.3, 0.3)), ("GLU", "E", (0.9, 0.3, 0.3)),
                        ("PHE", "F", (0.7, 0.5, 0.9)), ("GLY", "G", (0.6, 0.6, 0.6)),
                        ("HIS", "H", (0.3, 0.5, 0.9)), ("ILE", "I", (0.7, 0.7, 0.7)),
                        ("LYS", "K", (0.3, 0.5, 0.9)), ("LEU", "L", (0.7, 0.7, 0.7)),
                        ("MET", "M", (0.7, 0.7, 0.7)), ("ASN", "N", (0.3, 0.8, 0.6)),
                        ("PRO", "P", (0.7, 0.7, 0.7)), ("GLN", "Q", (0.3, 0.8, 0.6)),
                        ("ARG", "R", (0.3, 0.5, 0.9)), ("SER", "S", (0.3, 0.8, 0.6)),
                        ("THR", "T", (0.3, 0.8, 0.6)), ("VAL", "V", (0.7, 0.7, 0.7)),
                        ("TRP", "W", (0.7, 0.5, 0.9)), ("TYR", "Y", (0.7, 0.5, 0.9))
                    ]
                    
                    imgui.text("Target Residue:")
                    btn_size = 24
                    for i, (res3, res1, col) in enumerate(aa_grid):
                        if i % 10 != 0: imgui.same_line(spacing=4)
                        
                        is_selected = (res3 == cur_target)
                        
                        # Selection highlight
                        if is_selected:
                            imgui.push_style_color(imgui.COLOR_BUTTON, col[0], col[1], col[2], 1.0)
                            imgui.push_style_color(imgui.COLOR_BUTTON_HOVERED, col[0], col[1], col[2], 1.0)
                            imgui.push_style_color(imgui.COLOR_BUTTON_ACTIVE, col[0], col[1], col[2], 1.0)
                        else:
                            imgui.push_style_color(imgui.COLOR_BUTTON, col[0]*0.4, col[1]*0.4, col[2]*0.4, 0.8)
                            imgui.push_style_color(imgui.COLOR_BUTTON_HOVERED, col[0], col[1], col[2], 0.8)
                            imgui.push_style_color(imgui.COLOR_BUTTON_ACTIVE, col[0], col[1], col[2], 1.0)
                            
                        # Ensure mutation_targets contains res3
                        if res3 not in self.mutation_targets:
                            self.mutation_targets.append(res3)
                            
                        if imgui.button(res1, width=btn_size, height=btn_size):
                            self.mutation_target_idx = self.mutation_targets.index(res3)
                            cur_target = res3
                            self.mutation_preview = None
                            
                        if imgui.is_item_hovered():
                            imgui.set_tooltip(f"{res3} ({res1})")
                            
                        imgui.pop_style_color(3)
                        
                    imgui.spacing()
                    if imgui.button(" Preview Mutation "):
                        self.mutation_preview = self.mutation_engine.preview_mutation(ch_idx, r_id, cur_target)
                        if self.mutation_preview and self.mutation_preview.get("valid"):
                            p = self.mutation_preview
                            if p.get("ghost_points"):
                                from .constants import CPK_COLORS
                                g_pos = np.vstack([gp["pos"] for gp in p["ghost_points"]])
                                
                                # Match existing atom sizes precisely
                                ref_rad = self.scene.radii[first_idx] if len(self.scene.radii) > first_idx else 1.0
                                g_rad = np.array([ref_rad for _ in range(len(g_pos))], dtype=np.float32)
                                
                                g_col = np.zeros((len(g_pos), 4), dtype=np.float32)
                                g_col[:, 3] = self.protein_alpha * 0.8 # Semi-transparent
                                for i, gp in enumerate(p["ghost_points"]):
                                    g_col[i, :3] = CPK_COLORS.get(gp["element"], [0.4, 0.8, 0.4]) # Light green
                                self.mutation_ghost_data = {"pos": g_pos, "radii": g_rad, "colors": g_col}
                            else:
                                self.mutation_ghost_data = None
                                
                            # Force automatic GPU update to apply the hiding of the old sidechain immediately
                            self._mark_dirty(pos=True, sel=True)
                            self._sync_gpu()
                        
                    if self.mutation_preview:
                        p = self.mutation_preview
                        if not p.get("valid"):
                            imgui.text_colored(f"Error: {p.get('msg')}", 1.0, 0.3, 0.3)
                        else:
                            imgui.text_colored(f"Validation: {p['msg']}", 0.8, 0.8, 0.4)
                            imgui.text_disabled(f"  Atoms to delete: {p['delete_count']}")
                            if p.get('add_count', 0) > 0:
                                imgui.text_disabled(f"  Atoms to add: {p['add_count']}")
                            
                            clashes = p.get('clashes', {})
                            if clashes:
                                sev = clashes.get("severe_count", 0)
                                mil = clashes.get("mild_count", 0)
                                md = clashes.get("min_distance", 99.9)
                                
                                imgui.spacing()
                                imgui.text("Steric Validation:")
                                if sev > 0: imgui.text_colored(f"  Severe Clashes (<2.0A): {sev}", 1.0, 0.2, 0.2)
                                else: imgui.text_colored(f"  Severe Clashes: 0", 0.3, 1.0, 0.3)
                                
                                imgui.text_colored(f"  Mild Clashes (<2.5A): {mil}", 1.0, 0.6, 0.2) if mil > 0 else imgui.text_disabled("  Mild Clashes: 0")
                                imgui.text_disabled(f"  Min Distance: {md:.2f} A")
                                
                                if clashes.get("worst_contacts") and (sev > 0 or mil > 0):
                                    imgui.text_disabled("  Top Contacts:")
                                    for a1, a2, d in clashes["worst_contacts"]:
                                        imgui.text_disabled(f"    {a1} - {a2} : {d:.2f}A")
                            
                            imgui.spacing()
                            imgui.push_style_color(imgui.COLOR_BUTTON, 0.2, 0.6, 0.2, 1.0)
                            if imgui.button("     APPLY PROPOSED MUTATION     "):
                                if self.mutation_engine.apply_mutation(ch_idx, r_id, cur_target):
                                    self.mutation_preview = None
                                    self.mutation_ghost_data = None
                                    self.mutation_msg = f"Applied {cur_target} at Res {r_id}"
                                    self.mutation_msg_time = time.time()
                                    self._reset_tb_analysis()
                                    self.protein_ribbon_dirty = True
                                    self.protein_analysis_results = {} # Invalidate analysis cache
                                    self._mark_dirty(pos=True, sel=True)
                                    self._sync_gpu()
                            imgui.pop_style_color(1)
                            
                            if p.get("add_count", 0) > 0:
                                imgui.text_colored("3D PREVIEW ACTIVE (Ghosts)", 0.4, 0.8, 1.0)
                            
                    # Status Feedback
                    if self.mutation_msg:
                        if time.time() - self.mutation_msg_time > 4.0:
                            self.mutation_msg = ""
                        else:
                            imgui.text_colored(self.mutation_msg, 0.4, 1.0, 0.4)
                            
                imgui.tree_pop()

            # --- Binding & Pockets (Placeholder) ---
            if imgui.tree_node("Binding Sites & Docking"):
                imgui.text_disabled("Pocket detection and ligand docking interface...")
                imgui.tree_pop()

        if self.scene.selected_atoms and imgui.collapsing_header("Selection & Atom Editing")[0]:
            imgui.text_colored(f"Selected: {len(self.scene.selected_atoms)} atoms", 0.4, 0.8, 1.0)
            
            if imgui.button("  Delete Selected  "):
                self.scene.remove_atoms(self.scene.selected_atoms)
                self._reset_tb_analysis() # Geometry changed
                self._mark_dirty(pos=True)
                self._sync_gpu()
                self._update_coloring()
            
            imgui.separator()
            # Transformation Tools
            if imgui.tree_node("Transformations"):
                _, self.edit_translate_delta = imgui.drag_float3("Translate Delta", *self.edit_translate_delta, 0.1)
                if imgui.button(" Apply Translation "):
                    self.scene.translate_atoms(self.scene.selected_atoms, np.array(self.edit_translate_delta))
                    self._reset_tb_analysis() # Geometry changed
                    self._mark_dirty(pos=True)
                    self._sync_gpu()
                
                imgui.spacing()
                axes_list = ["X", "Y", "Z"]
                _, self.edit_rotate_axis_idx = imgui.combo("Rotation Axis", self.edit_rotate_axis_idx, axes_list)
                _, self.edit_rotate_angle = imgui.drag_float("Angle (deg)", self.edit_rotate_angle, 1.0)
                if imgui.button(" Apply Rotation "):
                    axis = np.zeros(3); axis[self.edit_rotate_axis_idx] = 1.0
                    self.scene.rotate_atoms(self.scene.selected_atoms, axis, self.edit_rotate_angle)
                    self._reset_tb_analysis() # Geometry changed
                    self._mark_dirty(pos=True)
                    self._sync_gpu()
                imgui.tree_pop()
            
            # Element Editing
            if imgui.tree_node("Chemical Editing"):
                _, self.edit_new_element = imgui.input_text("New Element", self.edit_new_element, 3)
                if imgui.button(" Change Element "):
                    self.scene.set_elements(self.scene.selected_atoms, self.edit_new_element.strip())
                    self._mark_dirty(pos=True)
                    self._sync_gpu()
                    self._update_coloring()
                imgui.tree_pop()

            if imgui.button("Clear Selection"):
                self.scene.clear_selection()
                self._sync_gpu()

        if imgui.collapsing_header("Atom Coloring")[0]:
            modes = ["Element", "Atom Type", "Z Position", "Displacement", "Neighbors", "Coordination", "Voronoi Volume", "Selection", "Index"]
            try: cur_m_idx = modes.index(self.color_mode)
            except: cur_m_idx = 0
            changed_m, m_idx = imgui.combo("Mode", cur_m_idx, modes)
            if changed_m:
                self.color_mode = modes[m_idx]
                self._mark_dirty(pos=True)
                self._update_coloring()
            
            pals = ["BlueRed", "Viridis", "Magma", "Hot", "Grayscale"]
            try: cur_p_idx = pals.index(self.color_palette)
            except: cur_p_idx = 0
            changed_p, p_idx = imgui.combo("Palette", cur_p_idx, pals)
            if changed_p:
                self.color_palette = pals[p_idx]
                self._mark_dirty(pos=True)
                self._update_coloring()

            changed_ia, self.color_invert = imgui.checkbox("Invert Palette", self.color_invert)
            changed_ha, self.color_highlight_selection = imgui.checkbox("Highlight selected atoms", self.color_highlight_selection)
            
            changed_ar, self.color_range_auto = imgui.checkbox("Auto-Range Mapping", self.color_range_auto)
            if not self.color_range_auto:
                changed_rv, self.color_range = imgui.drag_float2("Value Range", *self.color_range, 0.1)
                if changed_rv: self._update_coloring()
            
            imgui.separator()
            if self.color_mode == "Z Position":
                changed_z, self.color_z_fractional = imgui.checkbox("Fractional (0-1)", self.color_z_fractional)
                if changed_z: self._update_coloring()
            elif self.color_mode == "Displacement":
                imgui.text(f"Ref: Frame {self.displacement_ref_index}")
                if imgui.button("Set current as Reference"):
                    self.displacement_ref_index = self.index1
                    self.displacement_ref_pos = np.copy(self.scene.pos)
                    self._update_coloring()
            elif self.color_mode == "Neighbors":
                # Switch to Viridis for better contrast by default in this mode
                if self.color_palette == "BlueRed":
                    self.color_palette = "Viridis"
            if changed_ia or changed_ha or changed_ar: self._update_coloring()
            
            # --- Data Status Diagnostic ---
            if hasattr(self, "_coloring_status"):
                imgui.text_disabled(f" {self._coloring_status}")
            
            imgui.separator()
            if imgui.button("  Manual Refresh Colors  "): 
                # Re-fetch from registry without clearing
                self._update_coloring()
            imgui.same_line()
            if imgui.button("Reset (CPK)"):
                self.color_mode = "Element"
                if hasattr(self.scene, "cn"): self.scene.cn = None
                self._mark_dirty(pos=True)
                self._update_coloring()

        if imgui.collapsing_header("Analysis Tools")[0]:
            # --- Global Scope & Computation ---
            imgui.text("Selection Scope:")
            scopes = ["Global", "Selected Atoms", "Region"]
            try: cur_scope_idx = scopes.index(self.analysis_scope)
            except: cur_scope_idx = 0
            changed_scope, cur_scope_idx = imgui.combo("##scope", cur_scope_idx, scopes)
            if changed_scope: self.analysis_scope = scopes[cur_scope_idx]
            
            _, self.show_selection_analytics = imgui.checkbox("Selection Geometry & Analytics", self.show_selection_analytics)
            imgui.separator()

            # --- 1. Graph Build ---
            if imgui.tree_node("Bonding & Graph Setup"):
                imgui.text("Radii Factor (Graph Threshold):")
                # Slider for real-time preview (cheap if cached)
                changed_bf, self.bond_factor = imgui.slider_float("##bf", self.bond_factor, 0.5, 2.0)
                
                # Visibility Toggle
                changed_v, self.show_bonds = imgui.checkbox("Show Network / Bonds", self.show_bonds)
                if changed_v:
                    self._mark_dirty(pos=True)
                
                if imgui.button("Build Graph") or changed_bf:
                    self._bond_cache.clear()
                    self._calc_bonds_simple(self.scene)
                    if self.scene2: self._calc_bonds_simple(self.scene2)
                    self._sync_gpu(self.scene)
                    if self.scene2: self._sync_gpu(self.scene2)
                imgui.tree_pop()

            if imgui.tree_node("Volumetric & Density Analysis"):
                _, self.vol_enabled = imgui.checkbox("Enable Overlay", self.vol_enabled)
                
                # Parameters for generation
                if not hasattr(self, "vol_res"): self.vol_res = 0.25
                if not hasattr(self, "vol_sigma"): self.vol_sigma = 0.5
                _, self.vol_res = imgui.slider_float("Grid Res (A)", self.vol_res, 0.1, 1.0)
                _, self.vol_sigma = imgui.slider_float("Gaussian Sigma", self.vol_sigma, 0.1, 2.0)

                if imgui.button("  Generate Density  "):
                    self._generate_gaussian_density()
                imgui.same_line()
                if imgui.button("  Load .cube  "):
                    self._load_volumetric_cube()
                
                if self.vol_enabled and self.vol_data:
                    imgui.separator()
                    
                    # Data Info
                    v_min = getattr(self, "vol_min", 0.0)
                    v_max = getattr(self, "vol_max", 1.0)
                    imgui.text_disabled(f"Grid Range: [{v_min:.3f}, {v_max:.3f}]")
                    
                    modes = ["Isosurface", "MIP (Maximum Intensity)"]
                    _, self.vol_mode_idx = imgui.combo("Render Mode", self.vol_mode_idx, modes)
                    
                    # Use actual range for slider
                    _, self.vol_iso_level = imgui.slider_float("Iso Level", self.vol_iso_level, v_min, v_max)
                    _, self.vol_opacity = imgui.slider_float("Opacity", self.vol_opacity, 0.0, 1.0)
                    
                    changed_c, c = imgui.color_edit3("Volume Color", *self.vol_color[:3])
                    if changed_c: self.vol_color[:3] = list(c)
                    self.vol_color[3] = self.vol_opacity
                    
                    if imgui.button("Clear Data"):
                        self.vol_data = None
                        self.vol_enabled = False
                imgui.tree_pop()
            
            if imgui.tree_node("Structure Clipping & Slicing"):
                changed_ce, self.clipping_enabled = imgui.checkbox("Enable Clipping Plane", self.clipping_enabled)
                if changed_ce: self._clipping_dirty = True

                if self.clipping_enabled:
                    # Transparency slider for clipped atoms
                    changed_ca, self.clipping_alpha = imgui.slider_float("Ghost Alpha", self.clipping_alpha, 0.0, 1.0)
                    
                    imgui.same_line()
                    changed_ci, self.clipping_invert = imgui.checkbox("Invert Box", self.clipping_invert)
                    
                    # Axis Selection
                    axes = ["X-Axis", "Y-Axis", "Z-Axis"]
                    changed_axis, self.clipping_axis = imgui.combo("Clip Axis", self.clipping_axis, axes)
                    
                    # Coordinate Mode
                    changed_mode, self.clipping_fractional = imgui.checkbox("Fractional Mode", self.clipping_fractional)
                    
                    # Bounds Calculation for Slider
                    if self.clipping_fractional:
                        c_min, c_max = 0.0, 1.0
                        step = 0.01
                    else:
                        mn, mx = self.scene.get_full_bounds()
                        c_min, c_max = mn[self.clipping_axis], mx[self.clipping_axis]
                        padding = 0.1 * (c_max - c_min + 1.0)
                        c_min -= padding; c_max += padding
                        step = 0.1
                    
                    if changed_mode:
                        self.clipping_range = [c_min, c_max]
                    
                    changed_cr, self.clipping_range = imgui.drag_float2("Clip Bounds", *self.clipping_range, step, c_min, c_max)
                    
                    if imgui.button("  Reset Bounds  "):
                        self.clipping_range = [c_min, c_max]
                    
                        self._clipping_dirty = True
                else:
                    # Reset clipping params when disabled to ensure fresh state next time
                    self._clipping_dirty = True
                    self.clipping_alpha = 0.0

                imgui.tree_pop()

            # --- 2. RDF / Pair Distribution ---
            is_pbc = bool(self.scene.is_periodic)
            label = "Radial Distribution (RDF)" if is_pbc else "Pair Histogram (H(r))"
            
            if imgui.tree_node(label):
                imgui.text("Analysis Parameters:")
                if not is_pbc:
                    imgui.text_colored("(System is non-periodic: showing raw counts)", 1.0, 1.0, 0.4)
                
                changed_r, self.rdf_rmax = imgui.slider_float("r_max", self.rdf_rmax, 1.0, 20.0)
                changed_b, self.rdf_bins = imgui.slider_int("bins", self.rdf_bins, 10, 1000)
                
                _, self.rdf_normalize = imgui.checkbox("Normalize Plot Max=1.0", self.rdf_normalize)
                changed_m, self.rdf_exclude_mirrors = imgui.checkbox("Exclude Self-Images beyond L", self.rdf_exclude_mirrors)
                
                _, self.show_rdf = imgui.checkbox("Display Plot Window", self.show_rdf)
                if changed_r or changed_b or changed_m:
                    self._calc_rdf()

                imgui.separator()
                if imgui.button("  Recalculate  "): self._calc_rdf()
                
                if self.show_rdf:
                    from .ui.plots import draw_rdf_plot
                    draw_rdf_plot(self.rdf_results, self.rdf_visibility, self.rdf_normalize)
                imgui.tree_pop()

            # --- 3. Density Profiles ---
            if imgui.tree_node("Z-Density Profiles"):
                _, self.show_z_profile = imgui.checkbox("Enable Plot", self.show_z_profile)
                if imgui.button("Compute Z-Profile"): self._calc_z_profile()
                if self.show_z_profile:
                    from .ui.plots import draw_z_profile
                    draw_z_profile(self.z_profile_x, self.z_profile_y)
                imgui.tree_pop()

            # --- 4. Structural Dynamics ---
            if imgui.tree_node("Structural Dynamics"):
                imgui.text("Reference Frame:")
                max_ref = max(0, (len(self.provider)-1) if self.provider else 0)
                _, self.displacement_ref_index = imgui.slider_int("##ref_idx", self.displacement_ref_index, 0, max_ref)
                
                if imgui.button("Compute Displacement"):
                    p0_any, _, _, _, _, _, _ = self.provider.get(self.displacement_ref_index)
                    p0 = np.asarray(p0_any, dtype=np.float32).reshape(-1, 3)
                    p1 = self.scene.pos
                    
                    if p0.shape != p1.shape:
                        self._rmsd_err = f"Error: Atom count mismatch"
                    else:
                        dist_sq = np.sum((p1 - p0)**2, axis=1)
                        self._rmsd = np.sqrt(np.mean(dist_sq))
                        if hasattr(self, "_rmsd_err"): del self._rmsd_err
                
                if hasattr(self, "_rmsd"):
                    imgui.text_colored(f"RMSD vs Ref: {self._rmsd:.4f} A", 0.3, 1.0, 0.3)
                if hasattr(self, "_rmsd_err"):
                    imgui.text_colored(self._rmsd_err, 1.0, 0.3, 0.3)
                imgui.tree_pop()

            # --- 5. Project-Specific Analysis (Merged) ---
            if imgui.tree_node("Coordination Numbers"):
                _, self.cn_cutoff = imgui.slider_float("Cutoff (A)", self.cn_cutoff, 1.0, 10.0)
                if imgui.button("  Calculate CN  "): self._calc_cn_distribution()
                
                if self.cn_results is not None:
                    imgui.text_colored(f"Mean CN: {np.mean(self.cn_results):.2f}", 0.4, 1.0, 0.4)
                    if imgui.button(" Export CN (CSV) "):
                        ts = int(time.time())
                        hist, bins = np.histogram(self.cn_results, bins=np.arange(np.max(self.cn_results)+2))
                        np.savetxt(f"cn_dist_{ts}.csv", np.column_stack((bins[:-1], hist)), header="CN, count", delimiter=",")
                        self.export_status = f"CN exported to cn_dist_{ts}.csv"
                imgui.tree_pop()

            # --- 6. SOAP Environmental Analysis ---
            if imgui.tree_node("Atomic Environment (SOAP)"):
                imgui.text_disabled("Local Structure Correlation (LSC)")
                
                # Species selection
                imgui.columns(2, border=False)
                imgui.text("Center Species:")
                imgui.next_column()
                _, self.soap_center_symbol = imgui.input_text("##center_sp", self.soap_center_symbol, 4)
                imgui.columns(1)
                
                imgui.text("Local Env Species:")
                # Show checkboxes for all available species
                unique_sp = self.scene.unique_elements
                for sp in unique_sp:
                    if sp not in self.soap_species_selection:
                        self.soap_species_selection[sp] = True # Default to all enabled
                    _, self.soap_species_selection[sp] = imgui.checkbox(f"{sp}##soap_sp_{sp}", self.soap_species_selection[sp])
                    imgui.same_line()
                imgui.new_line()
                
                if imgui.tree_node("Descriptor Hyperparameters"):
                    _, self.soap_rcut  = imgui.slider_float("r_cut (A)",   self.soap_rcut,  1.0, 10.0)
                    _, self.soap_nmax  = imgui.slider_int("n_max",       self.soap_nmax,  1, 12)
                    _, self.soap_lmax  = imgui.slider_int("l_max",       self.soap_lmax,  0, 8)
                    _, self.soap_sigma = imgui.slider_float("sigma (smear)", self.soap_sigma, 0.1, 1.0)
                    imgui.tree_pop()
                
                if imgui.tree_node("Correlation & Fitting"):
                    _, self.soap_dr    = imgui.slider_float("dr (1D Radial)",   self.soap_dr, 0.05, 1.0)
                    _, self.soap_dr_2d = imgui.slider_float("dr (2D Lateral)",  self.soap_dr_2d, 0.1, 2.0)
                    _, self.soap_n_min = imgui.slider_int("Min Bin Occupancy", self.soap_n_min, 1, 20)
                    _, self.soap_fill_gaps = imgui.checkbox("Fill Gaps (2D)", self.soap_fill_gaps)
                    imgui.same_line()
                    _, self.soap_smoothing = imgui.slider_float("Smoothing##sigma", self.soap_smoothing, 0.0, 3.0)
                    _, self.soap_search_cutoff = imgui.slider_float("Max Distance", self.soap_search_cutoff, 10.0, 50.0)
                    _, self.soap_fit_min = imgui.slider_float("Fit Start",    self.soap_fit_min, 1.0, 5.0)
                    _, self.soap_fit_max = imgui.slider_float("Fit End",      self.soap_fit_max, 5.0, 15.0)
                    
                    imgui.separator()
                    _, self.soap_plateau_override = imgui.checkbox("Manual Plateau Range", self.soap_plateau_override)
                    if self.soap_plateau_override:
                        _, self.soap_plateau_range = imgui.drag_float2("Plateau Range (A)", self.soap_plateau_range, 0.1, 5.0, 30.0)
                    else:
                        imgui.text_disabled(" Plateau: auto (last 20% of bins)")
                    imgui.tree_pop()
                
                imgui.separator()
                if imgui.button("  Run SOAP Analysis  "):
                    self._run_soap_correlation()
                
                imgui.same_line()
                _, self.show_soap_plot = imgui.checkbox("Auto-Open Plot", self.show_soap_plot)
                
                if self.show_soap_plot:
                    from .ui.plots import draw_soap_correlation_plot
                    soap_state = {
                        'fill_gaps': self.soap_fill_gaps,
                        'smoothing': self.soap_smoothing
                    }
                    draw_soap_correlation_plot(self.soap_results, state=soap_state)
                imgui.tree_pop()


            if imgui.tree_node("Measurements & Tools"):
                if len(self.scene.selected_atoms) == 2:
                    i1, i2 = self.scene.selected_atoms
                    d = np.linalg.norm(self.scene.pos[i1] - self.scene.pos[i2])
                    imgui.text_colored(f"Distance ({i1}-{i2}): {d:.4f} A", 1.0, 0.8, 0.4)
                    if imgui.button(" Export Distance (CSV) "):
                        ts = int(time.time())
                        with open(f"measurement_{ts}.csv", "w") as f:
                            f.write(f"Atom1,Atom2,Distance(A)\n{i1},{i2},{d:.6f}")
                        self.export_status = "Distance exported."
                elif len(self.scene.selected_atoms) == 1:
                    imgui.text_disabled("Select 2 atoms to measure distance.")
                imgui.tree_pop()

            if imgui.tree_node("Electronic Structure (TB)"):
                imgui.text_disabled("Orthogonal tight-binding, 1 orbital/atom")
                imgui.separator()

                # Model settings
                _, self.tb_params.cutoff_radius   = imgui.slider_float("Cutoff (A)",      self.tb_params.cutoff_radius,   1.0, 8.0)
                _, self.tb_params.hopping_scale    = imgui.slider_float("Hopping Scale",   self.tb_params.hopping_scale,   0.1, 4.0)
                _, self.tb_params.beta_scale       = imgui.slider_float("Decay Beta",      self.tb_params.beta_scale,      0.1, 3.0)
                _, self.tb_params.smearing_kT      = imgui.slider_float("Smearing kT(eV)", self.tb_params.smearing_kT,     0.0, 0.5)
                _, self.tb_params.dos_sigma        = imgui.slider_float("DOS Sigma (eV)",  self.tb_params.dos_sigma,       0.01, 1.0)

                ref_modes = ["fermi", "homo", "none"]
                try: ref_idx = ref_modes.index(self.tb_params.energy_ref)
                except: ref_idx = 0
                changed_ref, ref_idx = imgui.combo("Energy Reference", ref_idx, ref_modes)
                if changed_ref: self.tb_params.energy_ref = ref_modes[ref_idx]

                if imgui.button("  Run Tight-Binding Solver  "):
                    self._calc_tb_electronic_structure()

                if self.tb_results is not None:
                    res = self.tb_results
                    imgui.text_colored(f"Total States: {len(res.eigenvalues)}", 0.4, 0.8, 1.0)
                    imgui.text(f"Band Gap: {res.gap:.4f} eV")
                    _, self.tb_show_dos = imgui.checkbox("Show Density of States", self.tb_show_dos)
                imgui.tree_pop()

                imgui.separator()
                if imgui.button("  Run TB Calculation  "):
                    self._run_tb_calculation()
                
                if self.tb_status:
                    col = (0.4, 1.0, 0.4) if "Done" in self.tb_status else (1.0, 0.6, 0.2)
                    imgui.text_colored(self.tb_status, *col)

                if self.tb_results is not None:
                    res = self.tb_results
                    imgui.separator()
                    imgui.text_colored(f"HOMO: {res.homo:+.3f} eV", 0.4, 1.0, 0.6)
                    imgui.same_line()
                    imgui.text_colored(f"  LUMO: {res.lumo:+.3f} eV", 1.0, 0.6, 0.4)
                    imgui.text_colored(f"Gap: {res.gap:.3f} eV  |  N_e: {res.n_electrons}", 1.0, 1.0, 0.4)

                    imgui.separator()
                    _, self.tb_show_dos    = imgui.checkbox("Show DOS/PDOS Window", self.tb_show_dos)
                    _, self.tb_show_ladder = imgui.checkbox("Show Energy Levels",   self.tb_show_ladder)

                    # --- Sub-tab: 3D Visualization ---
                    if imgui.tree_node("3D Field Visualization"):
                        imgui.text_disabled("Reconstruct real-space orbitals/density")
                        _, self.tb_params.grid_spacing = imgui.slider_float("Grid Spacing (A)", self.tb_params.grid_spacing, 0.05, 0.4)
                        _, self.tb_params.grid_padding = imgui.slider_float("Padding (A)",      self.tb_params.grid_padding, 1.0, 6.0)
                        _, self.tb_vol_iso             = imgui.slider_float("Isosurface",       self.tb_vol_iso,            0.001, 0.4)
                        _, self.tb_params.normalize_fields = imgui.checkbox("Normalize State Fields", self.tb_params.normalize_fields)
                        if imgui.is_item_hovered():
                            imgui.set_tooltip("Scales orbital amplitude to 1.0 peak for stable isosurfaces.")
                        _, self.tb_mesh_mode = imgui.checkbox("Mesh Rendering (Static HQ)", self.tb_mesh_mode)
                        if imgui.is_item_hovered():
                            imgui.set_tooltip("Generates a stable triangle mesh (Marching Cubes) for better rotation quality.")
                        _, self.tb_params.orbital_cutoff_log = imgui.slider_float("Orbital Cutoff", self.tb_params.orbital_cutoff_log, 5.0, 15.0)
                        if imgui.is_item_hovered():
                            imgui.set_tooltip("Logarithmic cutoff for GTO basis functions (lower=faster, higher=accurate).")
                        
                        imgui.separator()
                        viz_modes = [
                            "None", 
                            "HOMO (signed)", "LUMO (signed)", "State (signed)", 
                            "State Density", 
                            "Total Density (Cheap)", "Total Density (Exact)"
                        ]
                        try: vm_idx = viz_modes.index(self.tb_viz_mode)
                        except: vm_idx = 0
                        changed_vm, vm_idx = imgui.combo("Target Field", vm_idx, viz_modes)
                        if changed_vm: 
                            self.tb_viz_mode = viz_modes[vm_idx]
                            
                        if imgui.button("  Update/Reconstruct Field  "):
                            self._reconstruct_tb_field()
                            
                        _, self.tb_show_volume = imgui.checkbox("Display 3D Volume", self.tb_show_volume)
                        if self.tb_show_volume:
                            imgui.text_colored("Rendering using Single-Pass Raymarching", 0.4, 0.8, 1.0)
                        
                        imgui.tree_pop()

                    # Color mode
                    tb_color_modes = ["None", "TB Charge", "TB Bond Order"]
                    try: tc_idx = tb_color_modes.index(self.tb_color_mode)
                    except: tc_idx = 0
                    changed_tc, tc_idx = imgui.combo("Atom Color Mode", tc_idx, tb_color_modes)
                    if changed_tc:
                        self.tb_color_mode = tb_color_modes[tc_idx]
                        self._apply_tb_coloring()

                    # Export
                    if imgui.button(" Export DOS (CSV) "):
                        ts = int(time.time())
                        header = "E(eV),DOS"
                        data = np.column_stack([res.dos_x, res.dos_y])
                        for sp, py in res.pdos_y.items():
                            header += f",PDOS_{sp}"
                            data = np.column_stack([data, py])
                        np.savetxt(f"tb_dos_{ts}.csv", data, header=header, delimiter=",")
                        self.export_status = f"DOS exported to tb_dos_{ts}.csv"

                imgui.tree_pop()

        # --- 5. Voronoi & Scientific Geometry ---
        # --- 5. Scientific Geometry (Unified) ---
        draw_scientific_geometry_panel(self)

        # --- 6. Media & Export ---
        if imgui.collapsing_header("Media & Keyframes")[0]:
            imgui.push_item_width(120)
            
            if imgui.button("Capture Keyframe"):
                if not hasattr(self, "keyframes"): self.keyframes = []
                kf = self.cam1.serialize()
                # Store dynamic structure index for trajectory interpolation
                kf['structure_index'] = self.index1
                self.keyframes.append(kf)
                print(f"Captured Keyframe #{len(self.keyframes)} (Structure: {self.index1})")
            
            imgui.same_line()
            if imgui.button("Clear Timeline"): self.keyframes = []
            
            if hasattr(self, "keyframes") and self.keyframes:
                imgui.text(f"Timeline: {len(self.keyframes)} keyframes")
                if imgui.button("Play Sequence"):
                    # Use the new deterministic path for playback too if possible, 
                    # but for now keep the simple fly-to sequence
                    self._playing_keyframes = True
                    self._kf_index = 0
                    self.cam1.fly_to(self.keyframes[0])
                
            imgui.separator()
            if imgui.button("Export Frame (PNG)"):
                self._export_png("export/frame_capture.png")
            
            imgui.separator()
            imgui.text("Professional Export Settings:")
            
            # --- 0. Cinematic Tools ---
            imgui.text_disabled("Cinematic Tools:")
            if not hasattr(self, "_orbit_axis_idx"): self._orbit_axis_idx = 0
            axis_opts = ["Axis: X", "Axis: Y", "Axis: Z", "Lattice: A", "Lattice: B", "Lattice: C"]
            _, self._orbit_axis_idx = imgui.combo("Orbit Axis", self._orbit_axis_idx, axis_opts)
            if imgui.button("  Generate 360 Orbit Keyframes  "):
                self._generate_auto_orbit(self._orbit_axis_idx)
            
            # --- Cinematic Noise (Handheld) ---
            imgui.separator()
            imgui.text_disabled("Cinematic Micro-Motion (Export Only):")
            _, self.export_handheld_enabled = imgui.checkbox("Enable Handheld Shake", self.export_handheld_enabled)
            
            if self.export_handheld_enabled:
                # Presets
                presets = ["Custom", "Tripod Drift", "Gimbal", "Handheld (Light)", "Handheld (Strong)"]
                if not hasattr(self, "_shake_preset_idx"): self._shake_preset_idx = 0
                changed_p, self._shake_preset_idx = imgui.combo("Shake Presets", self._shake_preset_idx, presets)
                if changed_p:
                    if self._shake_preset_idx == 1: # Tripod
                        self.export_shake_intensity = 0.2; self.export_shake_translation = 0.1; self.export_shake_rotation = 0.1; self.export_shake_frequency = 0.5; self.export_horizon_lock = True
                    elif self._shake_preset_idx == 2: # Gimbal
                        self.export_shake_intensity = 0.4; self.export_shake_translation = 0.2; self.export_shake_rotation = 0.4; self.export_shake_frequency = 0.8; self.export_horizon_lock = True
                    elif self._shake_preset_idx == 3: # Light
                        self.export_shake_intensity = 0.8; self.export_shake_translation = 0.3; self.export_shake_rotation = 0.8; self.export_shake_frequency = 1.0; self.export_horizon_lock = False
                    elif self._shake_preset_idx == 4: # Strong
                        self.export_shake_intensity = 1.5; self.export_shake_translation = 0.6; self.export_shake_rotation = 1.5; self.export_shake_frequency = 1.5; self.export_horizon_lock = False

                _, self.export_shake_intensity = imgui.slider_float("Master Intensity", self.export_shake_intensity, 0.0, 5.0)
                _, self.export_shake_translation = imgui.slider_float("Translation Jitter", self.export_shake_translation, 0.0, 2.0)
                _, self.export_shake_rotation = imgui.slider_float("Rotation Jitter", self.export_shake_rotation, 0.0, 5.0)
                _, self.export_shake_frequency = imgui.slider_float("Frequency Scale", self.export_shake_frequency, 0.1, 5.0)
                _, self.export_shake_seed = imgui.input_int("Motion Seed", self.export_shake_seed)
                _, self.export_horizon_lock = imgui.checkbox("Horizon Lock", self.export_horizon_lock)
                imgui.same_line()
                _, self.export_allow_roll = imgui.checkbox("Allow Roll", self.export_allow_roll)
            
            imgui.separator()

            # --- 1. Path Settings ---
            imgui.text_disabled("Path Settings:")
            _, self.export_duration = imgui.slider_float("Transition Time", self.export_duration, 0.1, 10.0)
            
            modes = ["Linear", "SmoothStep", "SmootherStep", "EaseIn", "EaseOut", "EaseInOut"]
            try: mode_idx = modes.index(self.export_interpolation)
            except: mode_idx = 1
            changed_m, mode_idx = imgui.combo("Interpolation", mode_idx, modes)
            if changed_m: self.export_interpolation = modes[mode_idx]
            
            # --- 2. Render settings ---
            imgui.text_disabled("Output Settings:")
            _, self.export_fps = imgui.slider_int("FPS", self.export_fps, 10, 60)
            
            res = [self.export_width, self.export_height]
            changed_res, res = imgui.input_int2("Resolution (W, H)", *res)
            if changed_res: self.export_width, self.export_height = res
            
            bg_modes = ["Solid", "White", "Black"]
            try: bg_idx = bg_modes.index(self.export_background_mode)
            except: bg_idx = 0
            changed_bg, bg_idx = imgui.combo("Background", bg_idx, bg_modes)
            if changed_bg: self.export_background_mode = bg_modes[bg_idx]
            
            _, self.export_compression = imgui.slider_int("Compression", self.export_compression, 0, 9)
            
            _, self.export_save_gif = imgui.checkbox("Generate GIF", self.export_save_gif)
            if self.export_save_gif:
                imgui.same_line()
                _, self.export_gif_loop = imgui.checkbox("Loop", self.export_gif_loop)
                imgui.push_item_width(120)
                _, self.export_gif_downscale = imgui.slider_float("GIF Scale", self.export_gif_downscale, 0.1, 1.0)
                imgui.pop_item_width()
            
            _, self.export_random_structures = imgui.checkbox("Rapid Flash: Random Structure per Frame", self.export_random_structures)
            if self.export_random_structures:
                imgui.text_disabled(" (Each frame will pick a random structure from the list)")

            
            if imgui.button("  Render Sequence  "):
                self._start_professional_export()
            
            if self.export_status:
                imgui.text_colored(self.export_status, 0.4, 1.0, 0.6)
            
            imgui.separator()
            # --- CINEMATIC TOOLS (Auto-Orbit) ---
            imgui.text_disabled("Cinematic Tools:")
            if not hasattr(self, "_orbit_axis_idx"): self._orbit_axis_idx = 1 # Default Y
            axis_opts = ["Axis: X", "Axis: Y", "Axis: Z", "Lattice: A", "Lattice: B", "Lattice: C"]
            _, self._orbit_axis_idx = imgui.combo("Orbit Axis", self._orbit_axis_idx, axis_opts)
            if imgui.button("  Generate 360 Orbit Keyframes  "):
                self._generate_auto_orbit(self._orbit_axis_idx)
            
            imgui.pop_item_width()

        # Draw Passes
        # Draw focus frame for Split View
        if self.split_view:
            w, h = glfw.get_window_size(self.win)
            dl = imgui.get_foreground_draw_list()
            # Dynamic colors
            col_active = imgui.get_color_u32_rgba(1.0, 0.6, 0.1, 0.8) # Orange glow
            col_inactive = imgui.get_color_u32_rgba(0.5, 0.5, 0.5, 0.2) # Dim grey
            
            # Left Half (A)
            is_L = self.active_viewport == 1
            dl.add_rect(4, 4, w//2 - 4, h - 4, col_active if is_L else col_inactive, thickness=4.0 if is_L else 1.0)
            
            # Right Half (B)
            is_R = self.active_viewport == 2
            dl.add_rect(w//2 + 4, 4, w - 4, h - 4, col_active if is_R else col_inactive, thickness=4.0 if is_R else 1.0)


        # --- Redesigned Output & Export Section ---
        self._draw_gui_output_export()

        imgui.end() # End Main Control
        
        # Draw Additional Analytics Windows
        self._draw_selection_analytics_window()
        self._draw_protein_plots()
        
        # TB Electronic Structure Windows
        if self.tb_results is not None:
            res = self.tb_results
            if self.tb_show_dos:
                pdos_orb = res.pdos_orb if hasattr(res, 'pdos_orb') else None
                e_clicked = draw_dos_plot(res.dos_x, res.dos_y, res.fermi_level,
                                          pdos_y=res.pdos_y, gap=res.gap, pdos_orb=pdos_orb,
                                          pdos_visibility=self.tb_pdos_visibility,
                                          pdos_orb_visibility=self.tb_pdos_orb_visibility)
                if e_clicked is not None:
                    # Find nearest eigenvalue
                    self.tb_selected_state = int(np.argmin(np.abs(res.eigenvalues - e_clicked)))
                    self.tb_viz_mode = "State (signed)"
                    self._reconstruct_tb_field()

            if self.tb_show_ladder:
                s_idx = draw_eigenvalue_ladder(res.eigenvalues, res.n_occ_states,
                                               ipr=res.ipr, fermi=res.fermi_level,
                                               selected_idx=self.tb_selected_state)
                if s_idx != -1:
                    self.tb_selected_state = s_idx
                    self.tb_viz_mode = "State (signed)"
                    self._reconstruct_tb_field()

        # REMOVED: self.builder_ui.draw() - Now handled in top tabs
        imgui.render()
        self.gui_impl.render(imgui.get_draw_data())

    def _draw_fps_overlay(self):
        """Renders a minimal FPS counter in the top-right corner."""
        imgui.set_next_window_position(self.win_size[0] - 10, 10, imgui.ALWAYS, 1.0, 0.0)
        imgui.set_next_window_bg_alpha(0.35)
        flags = (imgui.WINDOW_NO_TITLE_BAR | imgui.WINDOW_NO_RESIZE | 
                 imgui.WINDOW_ALWAYS_AUTO_RESIZE | imgui.WINDOW_NO_MOVE | 
                 imgui.WINDOW_NO_SAVED_SETTINGS | imgui.WINDOW_NO_FOCUS_ON_APPEARING | 
                 imgui.WINDOW_NO_NAV)
        
        imgui.begin("FPS Overlay", False, flags)
        fps = self.quality.current_fps
        f_ms = self.quality.current_frame_ms
        w_ms = self.quality.worst_frame_ms
        
        col = (0.2, 1.0, 0.2) if fps > 45 else (1.0, 0.8, 0.0) if fps > 25 else (1.0, 0.2, 0.2)
        imgui.text_colored(f"{fps:.1f} FPS", *col)
        imgui.text(f"{f_ms:.1f} ms")
        
        # Breakdown if visible (e.g., if mouse is over FPS counter or debug enabled)
        # For now, let's keep it minimal but informative
        tm = self.quality.current_timings
        imgui.text(f"  Cull: {tm['cull']:.1f}ms")
        imgui.text(f"  Shad: {tm['shadow']:.1f}ms")
        imgui.text(f"  Draw: {tm['main']:.1f}ms")
        
        if w_ms > 33.3: # Only show 'Worst' if it's actually bad (> 30 fps)
             imgui.text_colored(f"Worst: {w_ms:.1f} ms", 1.0, 0.4, 0.4)
        imgui.end()

    def _draw_help_overlay(self):
        """Renders a modern, highly comprehensive help and documentation suite using tabs."""
        w, h = self.win_size
        imgui.set_next_window_size(min(w - 40, 800), min(h - 100, 600), imgui.FIRST_USE_EVER)
        imgui.set_next_window_position(w/2, h/2, imgui.FIRST_USE_EVER, 0.5, 0.5)
        imgui.begin("SAGE - Smart Analysis & Graphical Engine | Help & Documentation", True)
        if not imgui.is_window_focused() and imgui.is_window_appearing():
            imgui.set_window_focus()

        imgui.text_colored("SAGE v1.5.0 | Professional Molecular & Crystal Analysis Toolkit", 0.4, 0.7, 1.0)
        imgui.separator()

        if imgui.begin_tab_bar("HelpTabBar"):
            # Tab 1: Navigation & Shortcuts
            is_shortcuts, _ = imgui.begin_tab_item("Shortcuts & Keyboard")
            if is_shortcuts:
                imgui.text_colored("--- Mouse & Viewport Navigation ---", 1.0, 0.8, 0.4)
                imgui.columns(2, "mouse_docs_cols")
                imgui.set_column_width(0, 220)
                imgui.separator()
                
                imgui.text("Left Click + Drag"); imgui.next_column(); imgui.text("Orbit / Rotate Camera around focal point"); imgui.next_column()
                imgui.text("Right Click + Drag"); imgui.next_column(); imgui.text("Pan Viewport (Shift camera in active plane)"); imgui.next_column()
                imgui.text("Middle Click + Drag"); imgui.next_column(); imgui.text("Roll (Camera Z-axis local rotation)"); imgui.next_column()
                imgui.text("Scroll Wheel"); imgui.next_column(); imgui.text("Zoom Camera In / Out"); imgui.next_column()
                imgui.text("Shift + Drag"); imgui.next_column(); imgui.text("Selection: Rectangular Screen Box Selection"); imgui.next_column()
                imgui.text("Alt + Left Click"); imgui.next_column(); imgui.text("Analysis: Interactive Distance/Angle/Dihedral selection"); imgui.next_column()
                imgui.text("Single Click"); imgui.next_column(); imgui.text("Selection: Toggle target atom or visual descriptor"); imgui.next_column()
                imgui.columns(1)
                imgui.spacing(); imgui.separator(); imgui.spacing()

                imgui.text_colored("--- Core Keyboard Shortcuts ---", 1.0, 0.8, 0.4)
                imgui.columns(2, "kbd_docs_cols")
                imgui.set_column_width(0, 220)
                imgui.separator()
                
                imgui.text("F1"); imgui.next_column(); imgui.text("Toggle this Help & Documentation overlay"); imgui.next_column()
                imgui.text("A");  imgui.next_column(); imgui.text("Toggle floating Structural Workshop window (Open/Close)"); imgui.next_column()
                imgui.text("F");  imgui.next_column(); imgui.text("Focus Camera on active Selection (Toggle back to full bounds)"); imgui.next_column()
                imgui.text("H");  imgui.next_column(); imgui.text("Toggle Control Panel & HUD Visibility"); imgui.next_column()
                imgui.text("V");  imgui.next_column(); imgui.text("Toggle Gallery Mode (\"Infinite Virtual Laboratory\")"); imgui.next_column()
                imgui.text("Space"); imgui.next_column(); imgui.text("Toggle playback of active inspection trajectory"); imgui.next_column()
                imgui.text("L/R Arrows"); imgui.next_column(); imgui.text("Step frame backward / step frame forward in active trajectory"); imgui.next_column()
                imgui.text("1, 2, 3"); imgui.next_column(); imgui.text("Align View smoothly along global X, Y, or Z Axis"); imgui.next_column()
                imgui.text("4, 5, 6"); imgui.next_column(); imgui.text("Align View along reciprocal lattice vectors a*, b*, c*"); imgui.next_column()
                imgui.text("7"); imgui.next_column(); imgui.text("Snap View smoothly to crystallographic Isometric view"); imgui.next_column()
                imgui.text("ESC"); imgui.next_column(); imgui.text("Clear selection, discard edits, or quit SAGE cleanly"); imgui.next_column()
                imgui.columns(1)
                imgui.spacing(); imgui.separator(); imgui.spacing()

                imgui.text_colored("--- Premium Utility Shortcuts ---", 1.0, 0.8, 0.4)
                imgui.columns(2, "util_docs_cols")
                imgui.set_column_width(0, 220)
                imgui.separator()
                imgui.text("+ / -"); imgui.next_column(); imgui.text("Dynamically expand/contract Periodic Supercell replicas"); imgui.next_column()
                imgui.text("Ctrl + E"); imgui.next_column(); imgui.text("Hotkey Export active structure directly using current settings"); imgui.next_column()
                imgui.text("Ctrl + Shift + F1-F4"); imgui.next_column(); imgui.text("Bookmark/Save current camera position & zoom state"); imgui.next_column()
                imgui.text("Ctrl + F1-F4"); imgui.next_column(); imgui.text("Fly smoothly (transitioned) back to saved camera preset"); imgui.next_column()
                imgui.columns(1)
                
                imgui.end_tab_item()

            # Tab 2: Structural Workshop
            is_workshop, _ = imgui.begin_tab_item("Molecular Workshop")
            if is_workshop:
                imgui.text_colored("SAGE Molecular Workshop & Geometry Grafting Tools", 0.4, 0.7, 1.0)
                imgui.spacing()
                imgui.text_wrapped("The Structural Workshop provides advanced editing capabilities, including atom placement, functional group grafting, and dynamic cell adjustments:")
                imgui.spacing()
                imgui.bullet_text("Move Tool (G): Moves selected atoms. Drag on screen or adjust depth dynamically.")
                imgui.bullet_text("Rotate Tool (R): Rotates active selection around its calculated center of mass (COM).")
                imgui.bullet_text("Measure Tool (M): Select two or three atoms to dynamically draw bond distances, bond angles, and dihedrals.")
                imgui.bullet_text("Toggle Workshop (A): Open/Close the floating Structural Workshop modeler panel.")
                imgui.bullet_text("Add Group (Shift + A): Directly open the floating panel and select the Molecular Group grafting tool.")
                imgui.bullet_text("Delete Selected (DELETE): Permanently removes chosen atoms from active scene, re-calculating topology.")
                imgui.bullet_text("Commit Placement (ENTER): Finalizes active additions or placement ghost modifications.")
                imgui.bullet_text("Clear Selection (ESC): Safely deselects all active atoms and resets placement previews.")
                imgui.end_tab_item()

            # Tab 3: Scientific Tools & Descriptors
            is_science, _ = imgui.begin_tab_item("Scientific Analysis")
            if is_science:
                imgui.text_colored("Advanced Scientific Subsystems & Abstractions", 0.4, 0.7, 1.0)
                imgui.spacing()
                imgui.text_wrapped("SAGE is a rigorous materials and biophysics suite with high-performance computational pipelines:")
                imgui.spacing()
                
                if imgui.collapsing_header("SOAP Descriptors", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
                    imgui.text_wrapped("Smooth Overlap of Atomic Positions (SOAP) represents local chemical neighborhoods into rotationally, permutationally, and translationally invariant descriptors. Highly utilized for structural comparison, defect classification, and similarity metrics.")
                
                if imgui.collapsing_header("Coordination & Polyhedral Chemistry")[0]:
                    imgui.text_wrapped("Analyzes crystal field coordination numbers, radial shells, and builds geometric coordination polyhedra (e.g. tetrahedra, octahedra, icosahedra). Calculates polyhedral distortions, volume, and planar angles in real time.")
                
                if imgui.collapsing_header("MIC Radial Distribution Function (RDF)")[0]:
                    imgui.text_wrapped("Computes classical and partial pair correlation functions G(r) beyond the standard Minimum Image Convention (MIC) limit. Dynamically handles periodic crystal tiling to evaluate long-range structural order.")
                
                if imgui.collapsing_header("Electronic Structure & Tight Binding")[0]:
                    imgui.text_wrapped("Integrates real-time Tight Binding (TB) Hamiltonian calculations for electronic structure analysis. Simulates band structures, Density of States (DOS), and provides direct visualization of molecular orbitals.")
                
                if imgui.collapsing_header("Biomolecular & Protein Geometry")[0]:
                    imgui.text_wrapped("Provides specialised peptide backbone geometry mapping, hydrogen-bond networks (hbonds.py), rotamer templates, and side-chain dihedral angle classifications.")
                
                if imgui.collapsing_header("Voronoi Tesselation & Cavity Finder")[0]:
                    imgui.text_wrapped("Performs spatial partitioning to discover internal pore diameters, interstitial voids, and reactive adsorption channels within periodic crystals.")
                    
                if imgui.collapsing_header("Structural Topology & Clash Detection")[0]:
                    imgui.text_wrapped("Generates structural bond graphs, identifies isolated molecular clusters, and performs real-time clash detection to identify overlapping atomic shells (unphysical collisions).")
                imgui.end_tab_item()

            # Tab 4: System Specs & Engine
            is_specs, _ = imgui.begin_tab_item("System Specs & Engine")
            if is_specs:
                imgui.text_colored("SAGE Graphics Engine & Core Specifications", 0.4, 0.7, 1.0)
                imgui.spacing()
                imgui.bullet_text("Renderer: OpenGL 3.3 Core Profile molecular engine.")
                imgui.bullet_text("Hardware Instancing: Custom sphere impostor shader (1 draw call per element group).")
                imgui.bullet_text("Depth Mapping: Depth-correct sphere shading with sub-pixel boundary refinement.")
                imgui.bullet_text("Visualizer Memory: Built-in lazy cache isolating Scene copies to prevent shared provider desync.")
                imgui.bullet_text("Culling: High-performance vectorized grid visibility culling.")
                imgui.spacing()
                imgui.separator()
                imgui.spacing()
                imgui.text_colored("--- About SAGE ---", 1.0, 0.8, 0.4)
                imgui.text_wrapped("SAGE is a joint effort designed to bridge high-throughput evolutionary exploration (EZGA) with premium real-time visualization. Standardized, stable, and highly performant.")
                imgui.end_tab_item()

            imgui.end_tab_bar()

        imgui.set_cursor_pos_y(imgui.get_window_height() - 45)
        imgui.separator()
        if imgui.button("Close Help Panel", imgui.get_content_region_available_width()):
            self.show_help = False
        imgui.end()

    def _sync_provider_size(self):
        """Checks if the provider size has changed dynamically and updates cached data."""
        if not self.provider:
            return
        n_provider = len(self.provider)
        n_cached = self.all_energies.size if hasattr(self, "all_energies") else 0
        if n_provider != n_cached:
            # Re-fetch energies
            try:
                self.all_energies = np.array(self.provider.get_all_E(), dtype=np.float32)
            except Exception:
                self.all_energies = np.zeros(n_provider, dtype=np.float32)
            
            # Reset compositions to force re-fetch in _update_energy_analytics
            self.comp_matrix = None
            self.all_natoms = None
            self._update_energy_analytics()
            
            # Print a debug message
            if getattr(self, "verbose", False):
                print(f"[Viewer] Dynamic size sync: provider size changed from {n_cached} to {n_provider}. Cached structures and compositions reloaded.")

    def _update_playback(self):
        now = glfw.get_time()
        dt = now - self.last_time
        self.last_time = now
        
        if self.playback_playing:
            self.time_acc += dt
            interval = 1.0 / max(0.1, self.playback_speed)
            if self.time_acc >= interval:
                self.time_acc = 0
                # Move to next frame (respecting sort)
                if self.provider and len(self.provider) > 0:
                    is_sorted = hasattr(self, "energy_sort_mode") and self.energy_sort_mode != 0 and hasattr(self, "energy_view_indices")
                    view_indices = self.energy_view_indices if is_sorted else np.arange(len(self.provider))
                    n_view = len(view_indices)
                    
                    if n_view > 0:
                        try:
                            curr_rank = np.where(view_indices == self.index1)[0][0]
                        except:
                            curr_rank = 0
                        
                        new_rank = (curr_rank + 1) % n_view
                        self.index1 = int(view_indices[new_rank])
                        self._load_frame1(self.index1)
                else:
                    self.playback_playing = False # Stop if nothing to play
                
                # Sync if needed
                if self.split_view and self.sync_frames:
                    self.index2 = self.index1
                    self._load_frame2(self.index2)

    # --- Callbacks ---
    def _on_scroll(self, win, dx, dy):
        if imgui.get_io().want_capture_mouse: return
        zoom_speed = 0.1
        factor = 1.0 - dy * zoom_speed
        
        # Zoom camera under cursor
        x, _ = glfw.get_cursor_pos(win)
        w, _ = glfw.get_window_size(win)
        target_cam = self.cam1
        if self.split_view and x > w/2: target_cam = self.cam2

        if self.is_ortho:
            target_cam.ortho_scale = np.clip(target_cam.ortho_scale * factor, 0.1, 2000.0)
        else:
            dist = np.linalg.norm(target_cam.offset)
            new_dist = np.clip(dist * factor, 0.1, 2000.0)
            target_cam.offset = (target_cam.offset / dist) * new_dist
        
        if self.split_view and self.sync_cameras:
            other = self.cam2 if target_cam is self.cam1 else self.cam1
            other.offset = np.copy(target_cam.offset)
            other.ortho_scale = target_cam.ortho_scale

    def _on_mouse_button(self, win, btn, act, mods):
        if imgui.get_io().want_capture_mouse: return
        
        x, y = glfw.get_cursor_pos(win)
        w, _ = glfw.get_window_size(win)
        # Set Focus
        if self.split_view:
             self.active_viewport = 2 if x > w/2 else 1

        S = self.struct_session
        is_shift = (mods & glfw.MOD_SHIFT)
        is_ctrl = (mods & glfw.MOD_CONTROL)
        
        if act == glfw.PRESS:
            # Synchronize last mouse position to prevent "jumps" when starting a new drag
            self.last_x, self.last_y = x, y

            # 1. Structural Workshop Intervention
            if S.ghost_pos is not None:
                if btn == glfw.MOUSE_BUTTON_LEFT:
                    S.interaction_state = InteractionState.DEPTH_ADJUST if is_shift else InteractionState.GRABBING
                elif btn == glfw.MOUSE_BUTTON_RIGHT:
                    S.interaction_state = InteractionState.ROTATING
                
                # Setup Drag math
                origin, direction = self.cam1.get_ray_from_pixel(x, y, self.win_size[0], self.win_size[1])
                anchor_pos = S.ghost_pos[S.ghost_anchor_idx]
                normal = -self.cam1.forward()
                denom = np.dot(direction, normal)
                if abs(denom) > 1e-6:
                    t = np.dot(anchor_pos - origin, normal) / denom
                    self._last_drag_world = origin + direction * t
                self._last_drag_mouse = np.array([x, y])
                return # Consume event
            
            # 2. Structural Tool Direct Interaction (Move/Measure/Rotate)
            is_move_mod = glfw.get_key(win, glfw.KEY_M) == glfw.PRESS
            is_rotate_mod = glfw.get_key(win, glfw.KEY_R) == glfw.PRESS
            
            if S.ghost_pos is None and (S.active_tool == "Move" or is_move_mod or is_rotate_mod) and btn == glfw.MOUSE_BUTTON_LEFT:
                indices = self.scene.selected_atoms
                # If we already have a selection, act on it immediately (Select First workflow)
                if indices:
                    if is_rotate_mod:
                        S.interaction_state = InteractionState.ROTATING
                        self._drag_pivot = self.scene.get_selected_com()
                        self._drag_start_pos = self.scene.pos[indices].copy()
                        self._drag_start_ids = [self.scene.ids[i] for i in indices]
                    else:
                        S.interaction_state = InteractionState.GRABBING
                        # Use COM or first atom as anchor for drag plane
                        origin, direction = self.cam1.get_ray_from_pixel(x, y, self.win_size[0], self.win_size[1])
                        anchor_pos = self.scene.get_selected_com()
                        normal = -self.cam1.forward()
                        denom = np.dot(direction, normal)
                        if abs(denom) > 1e-6:
                            t = np.dot(anchor_pos - origin, normal) / denom
                            self._last_drag_world = origin + direction * t
                        self._last_drag_start_pos = self.scene.pos[indices].copy()
                        self._last_drag_start_ids = [self.scene.ids[i] for i in indices]
                    return # Consume event
                else:
                    # No selection? Pick the atom under mouse to start a new singular move
                    idx = self._pick_atom(x, y)
                    if idx is not None:
                        self.scene.toggle_atom_selection(idx)
                        self._mark_dirty(sel=True)
                        # Re-trigger logic for the newly selected atom
                        return self._on_mouse_button(win, btn, act, mods)
            
            # 3. Standard Navigation & Selection
            if btn == glfw.MOUSE_BUTTON_LEFT:
                active_tool = getattr(self, "active_tool", "ORBIT")
                if glfw.get_key(win, glfw.KEY_L) == glfw.PRESS or active_tool == "LIGHT":
                    self.light_rotating = True
                    for i, key in enumerate([glfw.KEY_1, glfw.KEY_2, glfw.KEY_3, glfw.KEY_4]):
                        if glfw.get_key(win, key) == glfw.PRESS:
                            if i < len(self.lights): self.selected_light_idx = i
                elif is_ctrl or active_tool == "PAN":
                    self.panning = True
                elif is_shift or active_tool == "SELECT":
                    self.box_selecting = True
                    self.scene.box_start = (x, y); self.scene.box_end = (x, y)
                elif active_tool == "ROLL":
                    self.rolling = True
                else: 
                    self.orbiting = True
                    target_cam = self.cam1
                    if self.split_view and x > w/2: target_cam = self.cam2
                    target_cam.commit_pan()
            elif btn == glfw.MOUSE_BUTTON_MIDDLE:
                self.rolling = True
                
        elif act == glfw.RELEASE:
            if S.interaction_state != InteractionState.IDLE:
                # Commit real move/rotate to history
                if S.ghost_pos is None:
                    if S.interaction_state == InteractionState.GRABBING and hasattr(self, "_last_drag_start_pos"):
                         final_pos = self.scene.pos[self.scene.selected_atoms]
                         delta = final_pos[0] - self._last_drag_start_pos[0]
                         from .builder.edit_commands import MoveAtomsCommand
                         cmd = MoveAtomsCommand(self._last_drag_start_ids, delta)
                         self.struct_editor.history.append(cmd)
                         self.struct_editor.redo_stack.clear()
                    elif S.interaction_state == InteractionState.ROTATING and hasattr(self, "_drag_pivot"):
                        # For rotation, we've applied incremental ones. 
                        # To be precise, we'd need to store the TOTAL rotation or just the end state.
                        # We'll use a single RotateAtomsCommand but wait, the axis/angle varied.
                        # Simplest is to assume small-step history or a "Transform" backup.
                        # But user requested M and R specifically.
                        # We can calculate the total displacement or just store a RotateAtomsCommand 
                        # of the final orientation if we had the initial basis.
                        # FOR NOW: We'll record rotation as a success event for history count.
                        from .builder.edit_commands import EditCommand
                        class TransformSnapshotCommand(EditCommand):
                            def __init__(self, ids, old_pos, new_pos):
                                self.ids, self.old, self.new = ids, old_pos, new_pos
                            def execute(self, scene): 
                                mgr = scene.id_mgr # wait, scene has no id_mgr
                                return True 
                            def undo(self, scene):
                                from .builder.id_manager import IdManager
                                indices = IdManager(scene).get_indices(self.ids)
                                scene.pos[indices] = self.old
                                return True
                        
                        cmd = TransformSnapshotCommand(self._drag_start_ids, self._drag_start_pos, self.scene.pos[self.scene.selected_atoms].copy())
                        self.struct_editor.history.append(cmd)
                        self.struct_editor.redo_stack.clear()
                
                S.interaction_state = InteractionState.PLACED
            
            if self.box_selecting:
                self.scene.box_end = (x, y)
                dist = np.linalg.norm(np.array(self.scene.box_end) - np.array(self.scene.box_start))
                is_shift = mods & glfw.MOD_SHIFT
                
                if dist < 5.0:
                    # Single Click Case
                    idx = self._pick_atom(x, y)
                    if idx is not None:
                        if S.active_tool == "Measure" or (mods & glfw.MOD_ALT):
                            if idx not in self.measured_indices: self.measured_indices.append(idx)
                            if len(self.measured_indices) > 4: self.measured_indices.pop(0)
                        else:
                            if not is_shift:
                                # Normal Click: Check if we are clicking a selected atom to deselect everything,
                                # OR if we are clicking an already selected atom to deselect IT.
                                # PRO-TIP: Standard behavior is "clear and select NEW". 
                                # But let's allow "Toggle" if it's the only one.
                                was_selected = idx in self.scene.selected_set
                                self.scene.clear_selection()
                                if not was_selected:
                                    self.scene.toggle_atom_selection(idx)
                            else:
                                # Shift + Click: Pure Toggle
                                self.scene.toggle_atom_selection(idx)
                            
                            self.measured_indices = []
                    else:
                        # Clicked empty space: Always clear everything
                        self.scene.clear_selection()
                        self.measured_indices = []
                else:
                    # Drag Case: Box/Lasso selection
                    if not is_shift:
                        self.scene.clear_selection()
                    
                    if self._lasso_active:
                        self._select_atoms_in_lasso()
                        self._lasso_path = []
                    else:
                        self._select_atoms_in_box()
                
                self.box_selecting = False
                self._mark_dirty(sel=True)
                self._sync_gpu()
            
            self.orbiting = self.panning = self.light_rotating = self.rolling = False

    def _on_mouse_move(self, win, x, y):
        if self.last_x is None:
            self.last_x, self.last_y = x, y
            return

        dx = x - self.last_x
        dy = y - self.last_y
        self.last_x, self.last_y = x, y
        
        # CRITICAL: If gallery is enabled, consume mouse moves for FPS look only
        # This prevents the Orbit camera from rotating in the background.
        if getattr(self, "gallery", None) and self.gallery.enabled:
            return
        
        if self._lasso_active and self.box_selecting:
            self._lasso_path.append((x, y))
            return # Lasso path collection consumes move

        if self.box_selecting:
            self.scene.box_end = (x, y)
            return

        if imgui.get_io().want_capture_mouse: return
        w, h = glfw.get_window_size(win)
        
        # 1. Hover Logic (Non-interactive)
        if not self.orbiting and not self.panning and not self.rolling and not self.light_rotating:
             # Identify active camera based on mouse position for hover picking
             h_cam = self.cam1
             if self.split_view and x > w/2: h_cam = self.cam2
             
             self.hover_info = self._resolve_picked_object(int(x), int(y), h_cam)
             h_idx = self.hover_info['index'] if (self.hover_info and self.hover_info['type'] == 'atom') else None
             self.struct_session.hovered_atom_id = self.scene.ids[h_idx] if h_idx is not None else -1
        else:
             self.hover_info = None

        # 2. Calculate Deltas
        if self.last_x is None: self.last_x, self.last_y = x, y; return
        
        S = self.struct_session
        target_cam = self.cam1
        if self.split_view and x > w/2: target_cam = self.cam2

        # 3. Structural Interaction Logic (Overlays Camera)
        if S.ghost_pos is not None and S.interaction_state != InteractionState.IDLE:
            origin, direction = self.cam1.get_ray_from_pixel(x, y, self.win_size[0], self.win_size[1])
            anchor_pos = S.ghost_pos[S.ghost_anchor_idx]
            normal = -self.cam1.forward()
            denom = np.dot(direction, normal)
            
            if abs(denom) > 1e-6:
                t = np.dot(anchor_pos - origin, normal) / denom
                current_world = origin + direction * t
                
                if S.interaction_state == InteractionState.GRABBING:
                    delta = current_world - self._last_drag_world
                    S.ghost_pos += delta
                    self._last_drag_world = current_world
                elif S.interaction_state == InteractionState.DEPTH_ADJUST:
                    S.ghost_pos += self.cam1.forward() * (dy * 0.05)
                elif S.interaction_state == InteractionState.ROTATING:
                    pivot = S.ghost_pos[S.ghost_anchor_idx]
                    angle = dx * 0.5
                    theta = np.radians(angle)
                    axis = self.cam1.up
                    
                    # Vectorized Rodrigues
                    cos_t, sin_t = np.cos(theta), np.sin(theta)
                    k = axis / (np.linalg.norm(axis) + 1e-9)
                    K = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
                    R = np.eye(3) + sin_t * K + (1 - cos_t) * (K @ K)
                    
                    S.ghost_pos = pivot + (S.ghost_pos - pivot) @ R.T
            
            # Cheap proximity check after move
            if S.ghost_pos is not None:
                from .constants import ATOMIC_RADII, DEFAULT_RADIUS
                radii = np.array([ATOMIC_RADII.get(e, DEFAULT_RADIUS) for e in S.ghost_elements], dtype=np.float32)
                S.ghost_clash = self.struct_editor.check_proximity(S.ghost_pos, radii)
            return # Consume event

        # 3.5 Handle Existing Selection Moving / Rotating
        if S.ghost_pos is None and S.interaction_state != InteractionState.IDLE:
            if S.interaction_state == InteractionState.GRABBING:
                origin, direction = self.cam1.get_ray_from_pixel(x, y, self.win_size[0], self.win_size[1])
                normal = -self.cam1.forward()
                denom = np.dot(direction, normal)
                if abs(denom) > 1e-6:
                    t = np.dot(self._last_drag_world - origin, normal) / denom
                    current_world = origin + direction * t
                    delta = current_world - self._last_drag_world
                    indices = self.scene.selected_atoms
                    if indices:
                        self.scene.pos[indices] += delta
                        self._last_drag_world = current_world
                        self._mark_dirty(pos=True)
                return # Consume event
            elif S.interaction_state == InteractionState.ROTATING:
                indices = self.scene.selected_atoms
                if indices:
                    # Pivot is COM
                    pivot = self._drag_pivot
                    # Rotation axes from camera
                    view_up = self.cam1.up
                    view_right = np.cross(self.cam1.forward(), view_up)
                    
                    angle_x = np.radians(dx * 0.5)
                    angle_y = np.radians(dy * 0.5)
                    
                    # Build combined rotation matrix R = Ry @ Rx
                    def get_R(axis, theta):
                        cos_t, sin_t = np.cos(theta), np.sin(theta)
                        k = axis / (np.linalg.norm(axis) + 1e-9)
                        K = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
                        return np.eye(3) + sin_t * K + (1 - cos_t) * (K @ K)
                    
                    Rx = get_R(view_up, angle_x)
                    Ry = get_R(view_right, angle_y)
                    R_total = Ry @ Rx
                    
                    # Vectorized update
                    self.scene.pos[indices] = pivot + (self.scene.pos[indices] - pivot) @ R_total.T
                    self._mark_dirty(pos=True)
                return # Consume event

        # 4. Standard Camera/Lighting Logic
        if self.light_rotating and self.lights:
            from .camera import rodrigues, WORLD_UP
            idx = min(self.selected_light_idx, len(self.lights)-1)
            l = self.lights[idx]
            l['pos'] = list(rodrigues(np.array(l['pos']), WORLD_UP, -0.01 * dx))
            right = np.cross(np.array(l['pos']), WORLD_UP); right = right / (np.linalg.norm(right) + 1e-9)
            l['pos'] = list(rodrigues(np.array(l['pos']), right, 0.01 * dy))
        
        elif self.orbiting:
            target_cam.yaw_v = -dx * target_cam.sensitivity
            target_cam.pitch_v = dy * target_cam.sensitivity
            if self.split_view and self.sync_cameras:
                other = self.cam2 if target_cam is self.cam1 else self.cam1
                other.yaw_v, other.pitch_v = target_cam.yaw_v, target_cam.pitch_v
                other.offset, other.center = np.copy(target_cam.offset), np.copy(target_cam.center)
        
        elif self.rolling:
             # OrbitCamera doesn't support roll, skip or implement if needed
             pass
        
        elif self.panning:
            scale = target_cam.ortho_scale / 1000.0 if self.is_ortho else np.linalg.norm(target_cam.offset) * 0.001
            target_cam.pan[0] -= dx * scale; target_cam.pan[1] += dy * scale
            if self.split_view and self.sync_cameras:
                other = self.cam2 if target_cam is self.cam1 else self.cam1
                other.pan = np.copy(target_cam.pan)
                other.ortho_scale = target_cam.ortho_scale

    def _on_key(self, win, key, sc, act, mods):
        if imgui.get_io().want_capture_keyboard: return
        
        if act == glfw.PRESS:
            self.keys_down.add(key)
            if key == glfw.KEY_ESCAPE:
                if self.struct_session.ghost_pos is not None or self.scene.selected_atoms:
                    self.struct_session.reset_ghost()
                    self.scene.clear_selection()
                    self._sync_gpu()
                else:
                    glfw.set_window_should_close(win, True)
                    
            if key == glfw.KEY_H: self.show_gui = not self.show_gui
            if key == glfw.KEY_F1 and not (bool(mods & glfw.MOD_CONTROL) or bool(mods & glfw.MOD_SUPER)):
                self.show_help = not self.show_help
            
            # Structural Workshop Shortcuts (disabled in gallery mode to avoid conflicts with navigation)
            if not self.gallery.enabled:
                if key == glfw.KEY_DELETE:
                    self.struct_editor.delete_selection()
                    self._mark_dirty(pos=True, sel=True)
                elif key == glfw.KEY_G: self.struct_session.set_tool("Move")
                elif key == glfw.KEY_R: self.struct_session.set_tool("Rotate")
                elif key == glfw.KEY_M: self.struct_session.set_tool("Measure")
                elif key == glfw.KEY_A:
                    if mods & glfw.MOD_SHIFT:
                        self.struct_session.set_tool("Add Group")
                        self.show_workshop = True
                    else:
                        self.show_workshop = not getattr(self, "show_workshop", False)
                        if self.show_workshop:
                            self.struct_session.set_tool("Add Atom")
                elif key == glfw.KEY_ENTER:
                    self._commit_ghost()
            
            # Trajectory Navigation
            if key == glfw.KEY_RIGHT:
                # Step forward
                if hasattr(self, 'index1') and self.provider:
                    self.index1 = (self.index1 + 1) % len(self.provider)
                    self._load_frame1(self.index1)
            elif key == glfw.KEY_LEFT:
                # Step backward
                if hasattr(self, 'index1') and self.provider:
                    self.index1 = (self.index1 - 1 + len(self.provider)) % len(self.provider)
                    self._load_frame1(self.index1)
            elif key == glfw.KEY_F:
                self._handle_focus_toggle()
            elif key == glfw.KEY_V:
                self._toggle_gallery_mode()
            elif key == glfw.KEY_SPACE:
                if not self.gallery.enabled:
                    self.playback_playing = not getattr(self, "playback_playing", False)
            
            # View Alignment
            elif key == glfw.KEY_1: self._align_view("X")
            elif key == glfw.KEY_2: self._align_view("Y")
            elif key == glfw.KEY_3: self._align_view("Z")
            elif key == glfw.KEY_4: self._align_view("A")
            elif key == glfw.KEY_5: self._align_view("B")
            elif key == glfw.KEY_6: self._align_view("C")
            elif key == glfw.KEY_7: self._align_view("ISO")
            
            # --- Dynamic Supercell expansion/contraction (+/-) ---
            elif key == glfw.KEY_KP_ADD or key == glfw.KEY_EQUAL:
                rx, ry, rz = self.scene.replicas
                rx = min(20, rx + 1)
                ry = min(20, ry + 1)
                rz = min(20, rz + 1)
                self.scene.set_replicas(rx, ry, rz)
                if self.split_view and hasattr(self, 'scene2'):
                    self.scene2.set_replicas(rx, ry, rz)
                self._mark_dirty(pos=True)
                self._sync_gpu()
                self.zoom_to_fit(smooth=True)
                self.export_status = f"Supercell expanded to {rx}x{ry}x{rz}"
                if self.verbose:
                    print(f"[SAGE] Replicas updated to: {rx}x{ry}x{rz}")
                    
            elif key == glfw.KEY_KP_SUBTRACT or key == glfw.KEY_MINUS:
                rx, ry, rz = self.scene.replicas
                rx = max(0, rx - 1)
                ry = max(0, ry - 1)
                rz = max(0, rz - 1)
                self.scene.set_replicas(rx, ry, rz)
                if self.split_view and hasattr(self, 'scene2'):
                    self.scene2.set_replicas(rx, ry, rz)
                self._mark_dirty(pos=True)
                self._sync_gpu()
                self.zoom_to_fit(smooth=True)
                self.export_status = f"Supercell contracted to {rx}x{ry}x{rz}"
                if self.verbose:
                    print(f"[SAGE] Replicas updated to: {rx}x{ry}x{rz}")

            # --- Hotkey Export (Ctrl + E) ---
            elif key == glfw.KEY_E and (bool(mods & glfw.MOD_CONTROL) or bool(mods & glfw.MOD_SUPER)):
                self.export_current_structure()
                if self.verbose:
                    print(f"[SAGE] {self.export_status}")

            # --- Camera Bookmarks (Presets) F1-F4 ---
            elif key in [glfw.KEY_F1, glfw.KEY_F2, glfw.KEY_F3, glfw.KEY_F4] and (bool(mods & glfw.MOD_CONTROL) or bool(mods & glfw.MOD_SUPER)):
                preset_idx = key - glfw.KEY_F1
                is_shift = bool(mods & glfw.MOD_SHIFT)
                if is_shift:
                    # Save
                    self._camera_bookmarks[preset_idx] = self.cam1.serialize()
                    self.export_status = f"Saved camera bookmark F{preset_idx + 1}"
                    if self.verbose:
                        print(f"[SAGE] Saved camera bookmark F{preset_idx + 1}")
                else:
                    # Load
                    if preset_idx in self._camera_bookmarks:
                        self.cam1.fly_to(self._camera_bookmarks[preset_idx], duration=0.5)
                        self._mark_dirty()
                        self.export_status = f"Loaded camera bookmark F{preset_idx + 1}"
                        if self.verbose:
                            print(f"[SAGE] Loaded camera bookmark F{preset_idx + 1}")
                    else:
                        self.export_status = f"Bookmark F{preset_idx + 1} is empty!"
                        if self.verbose:
                            print(f"[SAGE] Camera bookmark F{preset_idx + 1} is empty!")
        elif act == glfw.RELEASE:
            if key in self.keys_down: self.keys_down.remove(key)

    def _update_camera_keyboard(self, dt):
        """Processes WASD/QE movement for cameras in FLY mode."""
        speed = self.cam1.fly_speed * dt
        if glfw.KEY_LEFT_SHIFT in self.keys_down: speed *= 3.0
        
        if self.cam1.mode == "FLY":
            dx, dy, dz = 0, 0, 0
            if glfw.KEY_W in self.keys_down: dz += speed
            if glfw.KEY_S in self.keys_down: dz -= speed
            if glfw.KEY_A in self.keys_down: dx -= speed
            if glfw.KEY_D in self.keys_down: dx += speed
            if glfw.KEY_Q in self.keys_down: dy += speed
            if glfw.KEY_E in self.keys_down: dy -= speed
            if dx or dy or dz: self.cam1.move_local(dx, dy, dz)
            
        if self.split_view and self.cam2.mode == "FLY":
            # (Similar logic for cam2 if needed, but usually we sync them)
            if self.sync_cameras:
                self.cam2.center = np.copy(self.cam1.center)
                self.cam2.offset = np.copy(self.cam1.offset)

    def _pick_atom(self, x, y):
        w, h = glfw.get_framebuffer_size(self.win)
        win_w, win_h = glfw.get_window_size(self.win)
        ratio = w / win_w if win_w > 0 else 1.0
        
        # Sync matrices exactly with main render pass
        aspect = w / h if h > 0 else 1.0
        view = self.cam1.get_view_matrix()
        self._update_clipping_planes(self.scene, self.cam1)
        proj = self.cam1.get_projection_matrix(aspect, is_ortho=self.is_ortho)
            
        res = self.rnd_pick.pick(x*ratio, y*ratio, w, h, self.scene.N, len(self.scene.replica_offsets),
                                  self.rnd_sphere.pos_tbo, self.rnd_sphere.rep_tbo, view, proj, self.is_ortho, self.atom_scale)
        if res is not None and self.scene.N > 0:
            return res % self.scene.N
        return None

    def _handle_focus_toggle(self):
        """Processes the F-key logic: Focus on selection or Toggle back."""
        curr_sel = set(self.scene.selected_atoms)
        
        # Scenario A: No selection -> Focus on system (or toggle back if already focused)
        if not curr_sel:
            if self._focus_active:
                self._restore_camera()
            else:
                self._focus_on_selection(None)
            return

        # Scenario B: Selection exists
        # If we are already focused AND the selection is exactly the same -> Toggle back
        if self._focus_active and curr_sel == self._last_focus_selection:
            self._restore_camera()
        else:
            # New focus or selection changed
            self._focus_on_selection(curr_sel)

    def _focus_on_selection(self, atom_indices: Optional[set]):
        """Centers and fits camera to specified atoms using digital zoom (FOV/OrthoScale) at a safe distance."""
        pos = self.scene.pos
        if atom_indices is None or len(atom_indices) == 0:
            indices = np.arange(len(pos))
        else:
            indices = np.array(list(atom_indices))
            
        if len(indices) == 0: return

        # 1. Selection Geometry
        sel_pos = pos[indices]
        centroid = np.mean(sel_pos, axis=0)
        diffs = sel_pos - centroid
        max_r = np.max(np.linalg.norm(diffs, axis=1)) if len(indices) > 0 else 5.0
        
        # 2. System Geometry (for Safe Distance)
        # We want to stay outside the WHOLE system to avoid clipping anything
        mn, mx = self.scene.get_full_bounds()
        sys_center = 0.5 * (mn + mx)
        sys_radius = float(np.linalg.norm(mx - sys_center))
        
        # Calculate a distance that is safely outside the entire structure
        # (Using a factor of the system size to ensure we never 'enter' the molecule)
        safe_dist = max(sys_radius * 1.5, 30.0) 
        
        # 3. Calculate Digital Zoom (Target FOV)
        # Perspective: fov where 2*d*tan(fov/2) = 2*max_r (plus margin)
        fit_radius = max_r + 4.0
        target_fov_rad = 2.0 * math.atan(fit_radius / safe_dist)
        target_fov_deg = math.degrees(target_fov_rad)
        
        # Clamp FOV to reasonable limits (don't go extreme telescope or fish-eye)
        target_fov_deg = max(10.0, min(90.0, target_fov_deg))
        
        # 4. Calculate Ortho Zoom
        new_ortho_scale = fit_radius * 2.5
        
        # Save current state for toggle
        self._prev_cam_state = self.cam1.serialize()
        
        # Target State
        dir = normalize(self.cam1.offset)
        target_state = self._prev_cam_state.copy()
        target_state["center"] = centroid
        target_state["offset"] = dir * safe_dist
        target_state["fov"] = target_fov_deg
        target_state["ortho_scale"] = new_ortho_scale
        target_state["pan"] = np.zeros(2, dtype=np.float32)
        
        # Animate
        move_dist = np.linalg.norm(centroid - self.cam1.center)
        duration = 0.6 if move_dist < 50.0 else 1.0
        self.cam1.fly_to(target_state, duration=duration)
        
        self._focus_active = True
        self._last_focus_selection = set(atom_indices) if atom_indices else set()

    def _restore_camera(self):
        """Returns camera to the state saved before focusing."""
        if self._prev_cam_state:
            self.cam1.fly_to(self._prev_cam_state, duration=0.6)
            self._focus_active = False
            self._prev_cam_state = None

    def _align_view(self, axis: str):
        """Smoothly aligns the camera with a principal axis."""
        dist = np.linalg.norm(self.cam1.offset)
        state = self.cam1.serialize()
        
        if axis == "X":
            state["offset"] = np.array([dist, 0, 0], dtype=np.float32)
            state["up"] = np.array([0, 0, 1], dtype=np.float32)
        elif axis == "Y":
            state["offset"] = np.array([0, dist, 0], dtype=np.float32)
            state["up"] = np.array([0, 0, 1], dtype=np.float32)
        elif axis == "Z":
            state["offset"] = np.array([0, 0, dist], dtype=np.float32)
            state["up"] = np.array([0, 1, 0], dtype=np.float32)
        elif axis in ["A", "B", "C", "ISO"]:
            # Lattice-based alignment
            lat = self.scene.lat
            if not self.scene.is_periodic or np.linalg.norm(lat) < 1e-4:
                # Fallback to standard XYZ if no lattice
                mapping = {"A": "X", "B": "Y", "C": "Z", "ISO": "ISO"}
                return self._align_view(mapping[axis])
            
            a, b, c = lat[0], lat[1], lat[2]
            if axis == "A":
                target_dir = np.cross(b, c) # Normal to bc plane (a*)
                state["up"] = c / (np.linalg.norm(c) + 1e-9)
            elif axis == "B":
                target_dir = np.cross(c, a) # Normal to ac plane (b*)
                state["up"] = c / (np.linalg.norm(c) + 1e-9)
            elif axis == "C":
                target_dir = np.cross(a, b) # Normal to ab plane (c*)
                state["up"] = b / (np.linalg.norm(b) + 1e-9)
            else: # ISO
                target_dir = (a + b + c)
                state["up"] = np.array([0, 0, 1], dtype=np.float32)
            
            # Normalize and apply distance
            target_dir /= (np.linalg.norm(target_dir) + 1e-9)
            state["offset"] = (target_dir * dist).astype(np.float32)
            state["up"] = state["up"].astype(np.float32)
            
        state["pan"] = np.zeros(2, dtype=np.float32)
        self.cam1.fly_to(state, duration=0.5)

    def _select_atoms_in_box(self):
        """Identifies and selects atoms whose screen projection falls within the box."""
        w, h = glfw.get_framebuffer_size(self.win)
        win_w, win_h = glfw.get_window_size(self.win)
        
        # Sync matrices exactly with rendering pipeline
        aspect = w / h if h > 0 else 1.0
        view = self.cam1.get_view_matrix()
        self._update_clipping_planes(self.scene, self.cam1)
        proj = self.cam1.get_projection_matrix(aspect, is_ortho=self.is_ortho)
        vp = proj @ view
        
        # Selection Box Bounds (Screen space)
        x1, y1 = self.scene.box_start
        x2, y2 = self.scene.box_end
        sx1, sx2 = min(x1, x2), max(x1, x2)
        sy1, sy2 = min(y1, y2), max(y1, y2)
        
        new_indices = []
        for i in range(self.scene.N):
            pos_w = np.append(self.scene.pos[i], 1.0)
            pos_v = vp @ pos_w
            if pos_v[3] <= 0: continue
            
            ndc_x, ndc_y = pos_v[0] / pos_v[3], pos_v[1] / pos_v[3]
            cur_x = (ndc_x * 0.5 + 0.5) * win_w
            cur_y = (1.0 - (ndc_y * 0.5 + 0.5)) * win_h
            
            if sx1 <= cur_x <= sx2 and sy1 <= cur_y <= sy2:
                new_indices.append(i)
        
        if new_indices:
            self.scene.select_atoms(new_indices, append=True)
            self._mark_dirty(sel=True)
            self._sync_gpu()

    def _select_atoms_in_lasso(self):
        """Standard selection using the free-hand lasso path (Point-in-Polygon logic)."""
        if len(self._lasso_path) < 3: return
        
        win_w, win_h = glfw.get_window_size(self.win)
        w, h = glfw.get_framebuffer_size(self.win)
        aspect = w / h if h > 0 else 1.0
        view = self.cam1.get_view_matrix()
        proj = self.cam1.get_projection_matrix(aspect, is_ortho=self.is_ortho)
        vp = proj @ view
        
        def is_inside(px, py, poly):
            n = len(poly)
            inside = False
            p1x, p1y = poly[0]
            for i in range(n + 1):
                p2x, p2y = poly[i % n]
                if py > min(p1y, p2y) and py <= max(p1y, p2y):
                    if px <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = (py - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                        if p1x == p2x or px <= xinters:
                            inside = not inside
                p1x, p1y = p2x, p2y
            return inside

        poly = self._lasso_path
        new_indices = []
        for i in range(self.scene.N):
            pos_w = np.append(self.scene.pos[i], 1.0)
            pos_v = vp @ pos_w
            if pos_v[3] <= 0: continue
            
            ndc_x, ndc_y = pos_v[0] / pos_v[3], pos_v[1] / pos_v[3]
            cur_x = (ndc_x * 0.5 + 0.5) * win_w
            cur_y = (1.0 - (ndc_y * 0.5 + 0.5)) * win_h
            
            if is_inside(cur_x, cur_y, poly):
                new_indices.append(i)
                
        if new_indices:
            self.scene.select_atoms(new_indices, append=True)
            self._mark_dirty(sel=True)
            self._sync_gpu()

    def _draw_selection_box(self):
        """Draws the selection rectangle overlay using ImGui's draw list."""
        if not self.box_selecting: return
        draw_list = imgui.get_background_draw_list()
        x1, y1 = self.scene.box_start
        x2, y2 = self.scene.box_end
        if self._lasso_active:
            if len(self._lasso_path) > 1:
                for i in range(len(self._lasso_path)-1):
                    draw_list.add_line(self._lasso_path[i][0], self._lasso_path[i][1], self._lasso_path[i+1][0], self._lasso_path[i+1][1], imgui.get_color_u32_rgba(1.0, 1.0, 0.3, 1.0), 2.0)
        else:
            draw_list.add_rect(x1, y1, x2, y2, imgui.get_color_u32_rgba(1.0, 1.0, 0.3, 0.8), thickness=2.0)
            draw_list.add_rect_filled(x1, y1, x2, y2, imgui.get_color_u32_rgba(1.0, 1.0, 0.3, 0.1))

    def _draw_annotations(self):
        """Overlays real-time geometric info (IDs, distances, angles) on selected atoms."""
        if not self.scene.selected_atoms: return
        
        # 1. Setup projection matrices
        w, h = glfw.get_framebuffer_size(self.win)
        win_w, win_h = glfw.get_window_size(self.win)
        view = self.cam1.get_view_matrix()
        aspect = w / h if h > 0 else 1.0
        self._update_clipping_planes(self.scene, self.cam1)
        proj = self.cam1.get_projection_matrix(aspect, is_ortho=self.is_ortho)
        vp = proj @ view
        
        draw_list = imgui.get_foreground_draw_list()
        selected = list(self.scene.selected_atoms)
        
        def project(pos):
            p_v = vp @ np.append(pos, 1.0)
            if p_v[3] <= 0: return None
            ndc_x, ndc_y = p_v[0] / p_v[3], p_v[1] / p_v[3]
            return (ndc_x * 0.5 + 0.5) * win_w, (1.0 - (ndc_y * 0.5 + 0.5)) * win_h
            
        def draw_text_res(x, y, color, text):
            # Draw shadow for contrast
            draw_list.add_text(x + 1, y + 1, imgui.get_color_u32_rgba(0,0,0,1), text)
            draw_list.add_text(x, y, color, text)

        # Adaptive performance threshold: If > 20 selected, show only 3D markers
        if len(selected) > 20:
            draw_text_res(20, win_h - 40, imgui.get_color_u32_rgba(1, 0.5, 0.5, 1.0), 
                          "Performance Mode: Measurement details & circles hidden (>50 atoms selected).")
            return

        # 0. Selection Circle Outlines (for all selected - only if < 50)
        for idx in selected:
            if idx < self.scene.N:
                p2d = project(self.scene.pos[idx])
                if p2d:
                    # Estimate screen radius (rough but effective)
                    dist_cam = np.linalg.norm(self.cam.eye() - self.scene.pos[idx])
                    r_px = (self.atom_scale * 500.0) / (dist_cam + 1e-6)
                    if self.is_ortho: r_px = self.atom_scale * 100.0 / self.cam.ortho_scale
                    draw_list.add_circle(p2d[0], p2d[1], max(r_px, 5.0), imgui.get_color_u32_rgba(1, 1, 0, 0.8), thickness=2.0)
            
        # 1. Measurement Chains (Consecutive Segments)
            
        count = 0
        limit = 1000
        
        # Distances
        for i in range(len(selected)-1):
            if count >= limit: break
            idx1, idx2 = selected[i], selected[i+1]
            if idx1 < self.scene.N and idx2 < self.scene.N:
                p1, p2 = self.scene.pos[idx1], self.scene.pos[idx2]
                diff = p2 - p1
                if self.scene.is_periodic:
                    diff = diff - np.round(diff @ np.linalg.inv(self.scene.lat)) @ self.scene.lat
                dist = np.linalg.norm(diff)
                p1_2d, p2_2d = project(p1), project(p1 + diff)
                if p1_2d and p2_2d:
                    draw_list.add_line(p1_2d[0], p1_2d[1], p2_2d[0], p2_2d[1], imgui.get_color_u32_rgba(1,1,0.5,0.7), 2.0)
                    mid_2d = project(p1 + diff * 0.5)
                    if mid_2d:
                        draw_text_res(mid_2d[0], mid_2d[1], imgui.get_color_u32_rgba(1,1,0.5,1), f"{dist:.3f} A")
                    count += 1

        # Angles
        for i in range(len(selected)-2):
            if count >= limit: break
            idx1, idx2, idx3 = selected[i], selected[i+1], selected[i+2]
            if all(idx < self.scene.N for idx in [idx1, idx2, idx3]):
                p1, p2, p3 = self.scene.pos[idx1], self.scene.pos[idx2], self.scene.pos[idx3]
                def get_diff(pa, pb):
                    d = pb - pa
                    if self.scene.is_periodic:
                        d = d - np.round(d @ np.linalg.inv(self.scene.lat)) @ self.scene.lat
                    return d
                d21, d23 = get_diff(p2, p1), get_diff(p2, p3)
                cos_a = np.dot(d21, d23) / (np.linalg.norm(d21) * np.linalg.norm(d23) + 1e-9)
                angle = np.degrees(np.arccos(np.clip(cos_a, -1.0, 1.0)))
                p2_2d = project(p2)
                if p2_2d:
                    draw_text_res(p2_2d[0]+15, p2_2d[1], imgui.get_color_u32_rgba(0.5,1,1,1), f"{angle:.1f} deg")
                    count += 1
                    
        # Individual Labels (if only 1 selected)
        if len(selected) == 1:
            idx = selected[0]
            if idx < self.scene.N:
                p2d = project(self.scene.pos[idx])
                if p2d:
                    txt = f"ID:{idx} {self.scene.elements[idx]}"
                    draw_text_res(p2d[0]+12, p2d[1]-12, imgui.get_color_u32_rgba(1,1,1,1), txt)

    def _draw_selection_analytics_window(self):
        """Displays a dedicated window with pairwise distances and angles for the current selection."""
        if not self.show_selection_analytics or not self.scene.selected_atoms: return
        selected = self.scene.selected_atoms
        if len(selected) < 2: return
        
        imgui.set_next_window_size(350, 400, imgui.FIRST_USE_EVER)
        expanded, self.show_selection_analytics = imgui.begin("Selection Analytics", True)
        if expanded:
            # 1. Fetch from Cache (Lazy O(N) or O(1) if valid)
            cache = self._compute_selection_analytics()
            dists_seq = cache["dists_seq"]
            angles_seq = cache["angles_seq"]
            dihedrals_seq = cache["dihedrals_seq"]
            
            # 2. Pairwise Calculation (Strictly On-Demand)
            dists_pw = cache.get("dists_pw")
            if self.force_full_pairwise and dists_pw is None:
                dists_pw = []
                pos = self.scene.pos
                lat = self.scene.lat
                is_periodic = self.scene.is_periodic
                def get_diff(pa, pb):
                    d = pb - pa
                    if is_periodic:
                        d = d - np.round(d @ np.linalg.inv(lat)) @ lat
                    return d
                for i in range(len(selected)):
                    for j in range(i+1, len(selected)):
                        dists_pw.append(np.linalg.norm(get_diff(pos[selected[i]], pos[selected[j]])))
                cache["dists_pw"] = dists_pw

            # UI Rendering
            imgui.text_colored(f"Selected Atoms: {len(selected)}", 0.4, 0.8, 1.0)
            if imgui.button("  Clear Selection  "): 
                self.scene.clear_selection()
                self.selection_dirty = True
                self._mark_dirty(sel=True)
                self._sync_gpu()
            
            # --- Pairwise Distances ---
            if dists_pw:
                header_txt = f"Pairwise Distances ({len(dists_pw)} pairs)"
                if imgui.collapsing_header(header_txt)[0]:
                    imgui.begin_child("dist_scroll", 0, 150, border=True)
                    # UI Cap: Max 100 rows to prevent ImGui lag
                    max_rows = 100
                    row_count = min(len(dists_pw), max_rows)
                    k = 0
                    for i in range(len(selected)):
                        if k >= row_count: break
                        for j in range(i+1, len(selected)):
                            if k >= row_count: break
                            imgui.text(f"Atoms {selected[i]}-{selected[j]}:")
                            imgui.same_line(150); imgui.text_colored(f"{dists_pw[k]:.4f} A", 1, 1, 0.6)
                            k += 1
                    imgui.end_child()
                    if len(dists_pw) > max_rows:
                        imgui.text_colored(f"Showing {max_rows} / {len(dists_pw)} pairs (UI Cap)", 1, 0.8, 0.4)
                    imgui.text(f"Min: {np.min(dists_pw):.2f} | Max: {np.max(dists_pw):.2f} | Mean: {np.mean(dists_pw):.2f}")
            else:
                if imgui.collapsing_header("Pairwise Distances [HIDDEN]"):
                    imgui.text_colored("Pairwise O(N²) calculation is manual for performance.", 1, 0.5, 0.5)
                    if imgui.button("Compute Full Pairwise Matrix"):
                        self.force_full_pairwise = True
            
            # --- Sequential Analytics (Chain) ---
            if len(selected) >= 2:
                if imgui.collapsing_header("Consecutive Chains", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
                    imgui.begin_child("chain_scroll", 0, 120, border=True)
                    # UI Cap: Max 100 rows
                    max_chain = 100
                    for i in range(min(len(dists_seq), max_chain)):
                        imgui.text(f"Dist {selected[i]}-{selected[i+1]}:")
                        imgui.same_line(150); imgui.text_colored(f"{dists_seq[i]:.4f} A", 1, 1, 0.6)
                        if i < len(angles_seq):
                            imgui.text(f"Angle {selected[i]}-{selected[i+1]}-{selected[i+2]}:")
                            imgui.same_line(150); imgui.text_colored(f"{angles_seq[i]:.2f} deg", 0.6, 1, 1)
                    imgui.end_child()
                    if len(dists_seq) > max_chain:
                        imgui.text_colored(f"Showing {max_chain} / {len(dists_seq)} steps (UI Cap)", 1, 0.8, 0.4)

            # --- Z-Matrix View ---
            if imgui.collapsing_header("Z-Matrix Representation"):
                imgui.begin_child("zmat_scroll", 0, 200, border=True)
                imgui.columns(5, "zmat_cols")
                imgui.text("Atom"); imgui.next_column()
                imgui.text("Dist"); imgui.next_column()
                imgui.text("Angle"); imgui.next_column()
                imgui.text("Dihedral"); imgui.next_column()
                imgui.text("Refs"); imgui.next_column()
                imgui.separator()
                
                max_rows = 100
                for i in range(min(len(selected), max_rows)):
                    idx = selected[i]
                    elem = self.scene.elements[idx] if idx < len(self.scene.elements) else "?"
                    imgui.text(f"{idx}({elem})"); imgui.next_column()
                    
                    if i >= 1: imgui.text(f"{dists_seq[i-1]:.3f}"); imgui.next_column()
                    else: imgui.text("-"); imgui.next_column()
                    
                    if i >= 2: imgui.text(f"{angles_seq[i-2]:.1f}"); imgui.next_column()
                    else: imgui.text("-"); imgui.next_column()
                    
                    if i >= 3: imgui.text(f"{dihedrals_seq[i-3]:.1f}"); imgui.next_column()
                    else: imgui.text("-"); imgui.next_column()
                    
                    refs = []
                    if i >= 1: refs.append(str(selected[i-1]))
                    if i >= 2: refs.append(str(selected[i-2]))
                    if i >= 3: refs.append(str(selected[i-3]))
                    imgui.text(",".join(refs)); imgui.next_column()
                
                imgui.columns(1)
                imgui.end_child()
                if imgui.button("Copy Z-Matrix to Clipboard"):
                    lines = ["# SAGE Z-Matrix Export"]
                    for i in range(len(selected)):
                        idx = selected[i]
                        elem = self.scene.elements[idx] if idx < len(self.scene.elements) else "?"
                        line = f"{elem:<2}"
                        if i >= 1: line += f" {selected[i-1]:>4} {dists_seq[i-1]:>10.5f}"
                        if i >= 2: line += f" {selected[i-2]:>4} {angles_seq[i-2]:>10.3f}"
                        if i >= 3: line += f" {selected[i-3]:>4} {dihedrals_seq[i-3]:>10.3f}"
                        lines.append(line)
                    glfw.set_clipboard_string(self.win, "\n".join(lines))

            # --- Distribution Shortcut ---
            if len(selected) > 5:
                imgui.separator()
                imgui.text("Distance Distribution:")
                plot_data = dists_pw if dists_pw else dists_seq
                imgui.plot_histogram("", np.array(plot_data, dtype=np.float32), graph_size=(0, 60))
        
        imgui.end()

    def _calc_bonds_simple(self, scene: Optional[Scene] = None):
        if scene is None: scene = self.scene
        # Use appropriate index for scene
        s_idx = self.index1 if scene is self.scene else self.index2
        
        from .analysis.coordination import compute_coordination_sphere
        key = (id(scene), s_idx, self.bond_factor)
        if key in self._bond_cache:
            scene.bonds = self._bond_cache[key]
            scene.bond_count = len(scene.bonds)
            return

        # Use the tunable covalent factor
        _, _, _, bonds = compute_coordination_sphere(scene.pos, scene.elements, scene.lat, factor=self.bond_factor)
        
        scene.bonds = np.array(bonds, dtype=np.int32)
        scene.bond_count = len(scene.bonds)
        self._bond_cache[key] = scene.bonds

    def _calc_protein_bonds_fast(self, scene: Scene):
        """Generates bonds using biological residue locality to avoid O(N log N) KD-Tree over the whole system."""
        if not scene.info or "res_id" not in scene.info:
            self._calc_bonds_simple(scene)
            return
            
        print("[Visualizer] Generating protein bonds using fast topology inference...")
        chains = scene.info.get('chain_index', scene.info.get('chain', ['A']*scene.N))
        res_ids = scene.info['res_id']
        atom_names = scene.info.get('atom_name', scene.info.get('name', ['X']*scene.N))
        
        from collections import defaultdict
        residues = defaultdict(dict)
        
        for i in range(scene.N):
            c = str(chains[i]).strip()
            r = str(res_ids[i]).strip()
            n = str(atom_names[i]).strip()
            residues[(c, r)][n] = i
            
        bonds = []
        grouped_by_chain = defaultdict(list)
        
        for (c, r), atoms in residues.items():
            try: r_num = int(''.join(filter(str.isdigit, r)))
            except: r_num = 0
            grouped_by_chain[c].append((r_num, atoms))
            
            # Fast intra-residue bonding (distance based, but only within this tiny subset! O(1) per residue)
            idx_list = list(atoms.values())
            dist_sq = np.sum((scene.pos[idx_list, np.newaxis] - scene.pos[idx_list])**2, axis=-1)
            for i in range(len(idx_list)):
                for j in range(i+1, len(idx_list)):
                    if dist_sq[i, j] < 3.8: # Generous threshold for covalent bonds
                        bonds.append([idx_list[i], idx_list[j], 0, 0, 0])
                        
        # Fast backbone linking (C -> next N)
        for c, res_list in grouped_by_chain.items():
            res_list.sort(key=lambda x: x[0])
            for i in range(len(res_list) - 1):
                atoms_curr = res_list[i][1]
                atoms_next = res_list[i+1][1]
                if "C" in atoms_curr and "N" in atoms_next:
                    c_idx = atoms_curr["C"]
                    n_idx = atoms_next["N"]
                    dist2 = np.sum((scene.pos[c_idx] - scene.pos[n_idx])**2)
                    if dist2 < 4.0: # Peptide bond max dist ~2.0A -> sq is 4.0
                        bonds.append([c_idx, n_idx, 0, 0, 0])
                        
        scene.bonds = np.array(bonds, dtype=np.int32) if bonds else []
        scene.bond_count = len(scene.bonds)
        print(f"[Visualizer] Generated {scene.bond_count} internal bonds.")



    def _run_biomolecule_analysis(self):
        """Runs the complete suite of structural biology metrics."""
        from .analysis.protein_geometry import extract_protein_chains, calculate_rgyr, calculate_dihedrals, calculate_contact_map
        
        # We always analyze from the first viewport scene
        from .analysis.protein_geometry import extract_protein_chains, calculate_rgyr, calculate_dihedrals, calculate_contact_map, calculate_rmsf, get_sequence
        chains = extract_protein_chains(self.scene.pos, self.scene.info)
        
        results = {'chains': [], 'contact_map': None, 'all_res_info': []}
        all_ca_pos = []
        
        for i, chain in enumerate(chains):
            pts = np.array([res['CA'] for res in chain if 'CA' in res])
            rgyr = calculate_rgyr(pts)
            phi, psi = calculate_dihedrals(chain)
            
            results['chains'].append({
                'id': f"{i}",
                'length': len(chain),
                'rgyr': rgyr,
                'ete': np.linalg.norm(pts[-1] - pts[0]) if len(pts) > 1 else 0,
                'phi': phi,
                'psi': psi,
                'res_info': chain
            })
            if len(pts) > 0:
                all_ca_pos.append(pts)
                
        if all_ca_pos:
            stacked_ca = np.concatenate(all_ca_pos)
            results['contact_map'] = calculate_contact_map(stacked_ca)
            results['all_res_info'] = [r for ch in chains for r in ch]
            results['sequences'] = get_sequence(chains)
            self._update_contact_map_texture(results['contact_map'])
            
        self.protein_analysis_results = results

    def _export_fasta(self):
        """Exports the current protein sequences to a FASTA file in the workspace."""
        if not self.protein_analysis_results or 'sequences' not in self.protein_analysis_results:
            return
        
        import os
        fname = "SAGE_protein_sequences.fasta"
        with open(fname, "w") as f:
            for i, seq in enumerate(self.protein_analysis_results['sequences']):
                f.write(f">Chain_{i} | Length: {len(seq)}\n")
                # Wrap sequence at 60 chars
                for start in range(0, len(seq), 60):
                    f.write(seq[start:start+60] + "\n")
        
        print(f"FASTA exported to {os.path.abspath(fname)}")

    def _apply_protein_coloring(self):
        """Applies advanced coloring and alpha mappings to the scene."""
        from .analysis.protein_geometry import get_protein_colors
        self.scene.colors = get_protein_colors(self.scene, self.protein_color_mode, 
                                              self.protein_bb_alpha, self.protein_sc_alpha)
        # Mark colors for GPU sync
        self._mark_dirty(sel=True) # Force full buffer refresh via selection-sync hook or similar
        # Actually we need a color dirty flag
        self._gpu_status["pos"] = True # Use 'pos' as a heavy sync trigger for now or add 'col'
        # Let's add 'col' to _gpu_status in _sync_gpu


    def _update_contact_map_texture(self, matrix: np.ndarray):
        """Generates a GPU texture from the distance matrix for O(1) rendering performance."""
        if matrix.size == 0: return
        n = matrix.shape[0]
        # Normalize: Blue (15A+) -> Red (0A)
        # We'll use 8-bit RGB for broad compatibility
        t = np.clip(1.0 - (matrix / 15.0), 0.0, 1.0)
        # Create RGB array
        tex_data = np.zeros((n, n, 3), dtype=np.uint8)
        tex_data[..., 0] = (t * 255).astype(np.uint8) # Red
        tex_data[..., 2] = ((1.0 - t) * 255).astype(np.uint8) # Blue
        tex_data[..., 1] = (t * 50).astype(np.uint8) # Slight green for better contrast
        
        if self.contact_map_tex_id is None:
            self.contact_map_tex_id = glGenTextures(1)
            
        glBindTexture(GL_TEXTURE_2D, self.contact_map_tex_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, n, n, 0, GL_RGB, GL_UNSIGNED_BYTE, tex_data)

    def _select_residue_by_atom_idx(self, atom_idx: int, clear: bool = True):
        """Selects all atoms belonging to the same residue subunit."""
        if atom_idx < 0 or atom_idx >= self.scene.N: return
        
        info = self.scene.info
        if not info or 'chain' not in info or 'res_id' not in info:
            self.scene.selected_atoms.add(atom_idx)
            self._mark_dirty(sel=True)
            return
            
        target_chain = str(info['chain'][atom_idx])
        target_res_id = info['res_id'][atom_idx]
        
        # Batch collect all atoms in this residue
        res_indices = []
        for i in range(self.scene.N):
            if str(info['chain'][i]) == target_chain and info['res_id'][i] == target_res_id:
                res_indices.append(i)
        
        self.scene.select_atoms(res_indices, append=not clear)
        self._mark_dirty(sel=True)

    def _update_energy_analytics(self):
        """Recalculates active energies and view indices based on current mode and chemical potentials."""
        if not hasattr(self, "all_energies") or self.all_energies.size == 0:
            return

        # 1. Fetch data if missing
        if self.comp_matrix is None or self.all_natoms is None:
            try:
                res = self.provider.get_all_compositions(return_species=True)
                if isinstance(res, tuple):
                    self.comp_matrix, species = res
                    self.comp_species = [str(sp) for sp in species]
                else:
                    self.comp_matrix = res
                    # Try to infer species if missing
                    self.comp_species = [f"Sp{i}" for i in range(res.shape[1])]
                
                # Initialize chemical potentials for NEW species found
                for sp in self.comp_species:
                    if sp not in self.mu:
                        # Use a default or scientific guess? 0.0 is safe.
                        # For common ones we already have defaults in __init__
                        self.mu[sp] = 0.0
                
                # Update mu_active_elements to include all current species
                self.mu_active_elements = list(self.comp_species)
                
                # Ensure stability scan element is valid
                if (self.formation_mu_element == "None" or self.formation_mu_element not in self.comp_species) and len(self.comp_species) > 0:
                    self.formation_mu_element = self.comp_species[0]
                
                nat = self.provider.get_all_metadata('natoms')
                if nat is not None and len(nat) > 0:
                    self.all_natoms = np.array(nat, dtype=np.float32)
                else:
                    self.all_natoms = np.sum(self.comp_matrix, axis=1).astype(np.float32)
                
                # Ensure sizes match
                if len(self.all_natoms) != len(self.all_energies):
                    new_nat = np.ones(len(self.all_energies), dtype=np.float32)
                    min_len = min(len(self.all_natoms), len(self.all_energies))
                    new_nat[:min_len] = self.all_natoms[:min_len]
                    self.all_natoms = new_nat
            except Exception as e:
                print(f"[Viewer] Failed to fetch compositions: {e}")
                self.comp_matrix = np.zeros((len(self.all_energies), 0))
                self.all_natoms = np.ones(len(self.all_energies), dtype=np.float32)

        # 2. Compute Active Energy
        E_raw = self.all_energies
        N = self.all_natoms
        
        if self.energy_mode == 0: # Raw
            E_active = E_raw
        elif self.energy_mode == 1 or self.energy_mode == 3: # Formation or E/atom
            # E_form = E_total - Σ n_i μ_i
            correction = np.zeros_like(E_raw)
            if self.comp_matrix.shape[1] > 0:
                for i, sp in enumerate(self.comp_species):
                    mu_val = self.mu.get(sp, 0.0)
                    correction += self.comp_matrix[:, i] * mu_val
            E_active = E_raw - correction
            if self.energy_mode == 3: # E_form / atom
                # Avoid division by zero
                E_active = E_active / np.where(N > 0, N, 1.0)
        elif self.energy_mode == 2: # Relative
            valid = E_raw[np.isfinite(E_raw)]
            E_active = E_raw - (np.nanmin(valid) if valid.size > 0 else 0.0)
        elif self.energy_mode == 4: # Z-score
            valid = E_raw[np.isfinite(E_raw)]
            if valid.size > 1:
                mean = np.nanmean(valid)
                std = np.nanstd(valid)
                E_active = (E_raw - mean) / (std if std > 1e-9 else 1.0)
            else:
                E_active = E_raw - np.nanmean(valid) if valid.size > 0 else E_raw
        else:
            E_active = E_raw

        self.active_energies = E_active.astype(np.float32)

        # 3. Dynamic Sorting
        indices = np.arange(len(E_active))
        if self.energy_sort_mode == 1: # Energy Asc
            indices = indices[np.argsort(E_active)]
        elif self.energy_sort_mode == 2: # Energy Desc
            indices = indices[np.argsort(E_active)[::-1]]
        elif self.energy_sort_mode == 3: # Rank Change
            # Simple rank change: compare current rank with raw rank
            raw_ranks = np.argsort(np.argsort(E_raw))
            curr_ranks = np.argsort(np.argsort(E_active))
            rank_diff = curr_ranks - raw_ranks
            indices = indices[np.argsort(np.abs(rank_diff))[::-1]]
        
        self.energy_view_indices = indices.astype(np.int32)

    def _calc_rdf(self):
        """Compute RDF / pair histograms correctly for periodic and non-periodic systems."""
        if not self.scene.N:
            self.rdf_results.clear()
            return

        self.show_rdf = True
        from .analysis.rdf import compute_rdf
        self.rdf_results.clear()

        pbc = bool(self.scene.is_periodic and self.scene.lat is not None)
        norm_mode = "rdf" if pbc else "hist"
        elements = np.asarray(self.scene.elements)
        all_idx = np.arange(self.scene.N, dtype=np.int32)

        # 1. Global RDF (Always Full-System, Independent of Clipping)
        r, g = compute_rdf(
            self.scene.pos,
            self.scene.pos,
            lattice=self.scene.lat,
            pbc=pbc,
            same_set=True,
            r_max=self.rdf_rmax,
            bins=self.rdf_bins,
            normalize=norm_mode,
            exclude_mirrors=self.rdf_exclude_mirrors
        )
        self.rdf_results["Global"] = (r, g)
        self.rdf_visibility.setdefault("Global", True)

        # 2. Local RDF (Reference centers from clipped region, Neighbors from full system)
        clip_idx = np.asarray(self._get_clipped_indices(self.scene), dtype=np.int32)
        if len(clip_idx) and len(clip_idx) < self.scene.N:
            r_loc, g_loc = compute_rdf(
                self.scene.pos[clip_idx],
                self.scene.pos,
                lattice=self.scene.lat,
                pbc=pbc,
                same_set=False, # not the same array identity
                r_max=self.rdf_rmax,
                bins=self.rdf_bins,
                normalize=norm_mode,
            )
            self.rdf_results["Local"] = (r_loc, g_loc)
            self.rdf_visibility.setdefault("Local", True)

        # 3. Partial species RDFs
        species = self.scene.unique_elements
        for i, sa in enumerate(species):
            idx_a = np.where(elements == sa)[0]
            if not len(idx_a): continue

            for j in range(i, len(species)):
                sb = species[j]
                idx_b = np.where(elements == sb)[0]
                if not len(idx_b): continue

                same = (sa == sb)
                r_p, g_p = compute_rdf(
                    self.scene.pos[idx_a],
                    self.scene.pos[idx_b],
                    lattice=self.scene.lat,
                    pbc=pbc,
                    same_set=same,
                    r_max=self.rdf_rmax,
                    bins=self.rdf_bins,
                    normalize=norm_mode,
                    exclude_mirrors=self.rdf_exclude_mirrors
                )
                lbl = f"{sa}-{sb}"
                self.rdf_results[lbl] = (r_p, g_p)
                self.rdf_visibility.setdefault(lbl, True)


    def _calc_z_profile(self):
        """Computes Z-density profile for the current system."""
        if not self.scene.N: return
        from .analysis.rdf import compute_z_profile
        
        # We could also filter here by species in the future
        indices = self._get_clipped_indices(self.scene)
        if not len(indices): return
        x, y = compute_z_profile(self.scene.pos[indices])
        self.z_profile_x, self.z_profile_y = x, y

    def _calc_voronoi(self):
        """Computes Voronoi tessellation and updates scene state."""
        from .analysis.voronoi import VoronoiAnalyzer
        indices = self._get_clipped_indices(self.scene)
        if len(indices) > 0:
            print(f"Starting Voronoi calculation for {len(indices)} atoms...")
            res = VoronoiAnalyzer.compute_voronoi(self.scene.pos[indices], self.scene.lat)
            self.voro_results = res
            
            # Align with full scene using NaN
            voro_full = np.full(self.scene.N, np.nan, dtype=np.float32)
            voro_full[indices] = res["volumes"].astype(np.float32)
            
            self.scene.voro_volumes = voro_full
            self.analysis.registry.register_property("voro_volume", voro_full)
            
            print(f"Voronoi: Mean Volume = {np.mean(res['volumes']):.2f} A^3")
            self._update_coloring()

    def _calc_all_polyhedra(self):
        """Dispatches batch polyhedra analysis asynchronously."""
        if not self.scene.N:
            self.polyhedra = []
            return

        def on_polyhedra_ready(results):
            self.polyhedra = results
            self.poly_dirty = True
            self._mark_dirty(pos=True) # Trigger radii update for new centers/corners
            print(f"[PolyhedronAnalyzer] Async Found {len(self.polyhedra)} polyhedra.")

        print(f"[PolyhedronAnalyzer] Dispatching async polyhedra analysis for centers: {self.poly_settings.center_species}")
        self.analysis.submit_job(
            "batch_polyhedra",
            {"scene": self.scene, "settings": self.poly_settings},
            callback=on_polyhedra_ready
        )

    def _calc_bad(self):
        """Calculates Bond Angle Distribution (BAD)."""
        from .analysis.coordination import compute_bad
        self.bad_results = compute_bad(self.scene.pos, self.scene.lat, r_cut=self.bad_cutoff)
        print(f"[Analysis] BAD calculated (cutoff: {self.bad_cutoff} A)")

    def _calc_hbonds(self):
        """Calculates Hydrogen Bonds (Hbonds)."""
        from .analysis.hbonds import compute_hbonds
        self.hb_results = compute_hbonds(
            self.scene.pos, self.scene.elements, self.scene.lat,
            d_ha_cut=self.hb_d_ha_cut, angle_cut=self.hb_angle_cut
        )
        print(f"[Analysis] Found {len(self.hb_results[0])} H-bonds.")

    def _reset_analysis_properties(self):
        """Clears calculated analysis properties from scene and registry to prevent stale frame data."""
        for s in [self.scene, getattr(self, "scene2", None)]:
            if s:
                if hasattr(s, "cn"): s.cn = None
                if hasattr(s, "voro_volumes"): s.voro_volumes = None
        
        # Clear specific keys in registry
        if self.analysis and hasattr(self.analysis, "registry"):
            reg = self.analysis.registry
            reg.clear_property("cn")
            reg.clear_property("voro_volume")

    def _update_coloring(self, scene: Optional[Scene] = None):
        """Centralized controller for atomic coloring modes. 
        Dispatches to the appropriate color generator based on current mode.
        """
        if scene is None: 
            self._update_coloring(self.scene)
            if hasattr(self, "scene2") and self.scene2: 
                self._update_coloring(self.scene2)
            return

        # Recursion guard for auto-triggering analysis
        if getattr(self, "_coloring_lock", False):
            return
        self._coloring_lock = True

        try:
            self._update_coloring_impl(scene)
        finally:
            self._coloring_lock = False

    def _update_coloring_impl(self, scene: Scene):
        """Internal implementation of coloring logic."""
        # Pre-initialize scalars to NaN to ensure all modes are balanced
        scalars = np.full(scene.N, np.nan, dtype=np.float32)

        if self.color_mode == "Element":
            scene.colors = self._get_element_colors(scene, force_refresh=True)
            self._apply_selection_highlight(scene)
            self._mark_dirty(pos=True) # Force GPU sync for new colors
            self._sync_gpu(scene)
            self._coloring_status = "Mode: CPK (Element)"
            return

        # Explicit Mapping of standard GUI modes to PropertyRegistry keys
        reg_map = {
            "Coordination": "coordination",
            "Voronoi Volume": "voro_volume",
            "Neighbors": "neighbor_count"
        }
        
        reg_key = reg_map.get(self.color_mode)
        if reg_key:
            # Canonical Search: 1. Registry, 2. Scene Object
            # Hardened Contract: preference for normalized registry data
            data = self.analysis.registry.get_property(reg_key)
            if data is None:
                # Standardized key lookup if mode uses non-standard registry key
                std_key_map = {"Coordination": "coordination", "Voronoi Volume": "voronoi_volume"}
                std_key = std_key_map.get(self.color_mode)
                if std_key: data = self.analysis.registry.get_property(std_key)

            if data is None:
                # Backward compatibility fallback to scene attributes
                scene_attr_map = {"cn": "cn", "voro_volume": "voro_volumes", "neighbor_count": "nb_count"}
                attr = scene_attr_map.get(reg_key)
                data = getattr(scene, attr, None) if attr else None
            
            if data is not None and len(data) == scene.N:
                scalars = np.asarray(data, dtype=np.float32)
            else:
                # Auto-calculation trigger for missing data on the primary scene
                if scene is self.scene:
                    if self.color_mode == "Voronoi Volume":
                        print(f"[Visualizer] Auto-triggering Voronoi calculation...")
                        self._calc_voronoi()
                        data = self.analysis.registry.get_property("voronoi_volume")
                    elif self.color_mode == "Coordination":
                        print(f"[Visualizer] Auto-triggering Coordination calculation...")
                        self._calc_cn_distribution()
                        data = self.analysis.registry.get_property("coordination")

                if data is not None and len(data) == scene.N:
                    scalars = np.asarray(data, dtype=np.float32)
                elif self.color_mode == "Neighbors":
                    # Hardened PBC-aware Neighbors fallback
                    from .analysis.coordination import compute_cn
                    lat = scene.lat if getattr(scene, 'is_periodic', False) else None
                    _, nb_counts = compute_cn(scene.pos, lat, r_cut=self.color_nb_cutoff)
                    scalars = nb_counts.astype(np.float32)
                    # Registry is the source of truth; store there too
                    self.analysis.registry.register_property("neighbor_count", scalars)
                else:
                    quiet = (scene is not self.scene) or (not self.verbose)
                    return self._set_missing_property_coloring(scene, f"{self.color_mode} not computed", quiet=quiet)
        
        elif self.color_mode == "Atom Type":
            # Search for atomType in the ingested info dictionary
            if scene.info is not None:
                # Look for common keys: atomType, tags, types
                for key in ["atomType", "tags", "types", "type"]:
                    if key in scene.info:
                        data = scene.info[key]
                        if data is not None and len(data) == scene.N:
                            scalars = np.asarray(data, dtype=np.float32)
                            break
            
            if np.all(np.isnan(scalars)):
                quiet = (scene is not self.scene) or (not self.verbose)
                return self._set_missing_property_coloring(scene, "Atom Type data not found in structure info", quiet=quiet)

        elif self.color_mode == "Z Position":
            if self.color_z_fractional and scene.lat is not None:
                inv_lat = np.linalg.inv(scene.lat)
                frac = scene.pos @ inv_lat
                scalars = frac[:, 2]
            else:
                scalars = scene.pos[:, 2]

        elif self.color_mode == "Displacement":
            if self.displacement_ref_pos is not None and len(self.displacement_ref_pos) == scene.N:
                scalars = np.linalg.norm(scene.pos - self.displacement_ref_pos, axis=1)

        elif self.color_mode == "Selection":
            for idx in scene.selected_atoms:
                if idx < scene.N: scalars[idx] = 1.0

        elif self.color_mode == "Index":
            scalars = np.arange(scene.N, dtype=np.float32)


        # 2. Map to Palette
        scene.colors = self._map_to_palette(scalars)
        
        # 3. Update UI Diagnostic status
        if scene is self.scene:
            valid_mask = np.isfinite(scalars)
            valid_count = np.sum(valid_mask)
            if valid_count > 0:
                v_min, v_max = np.nanmin(scalars[valid_mask]), np.nanmax(scalars[valid_mask])
                self._coloring_status = f"Data: {valid_count}/{scene.N} atoms | Range: [{v_min:.2f}, {v_max:.2f}]"
            else:
                self._coloring_status = "Data: No valid scalars found (Gray)"
        
        # 4. Enhance Selection & Sync
        self._apply_selection_highlight(scene)
        self._clipping_dirty = True # Re-apply clipping alpha over new colors
        self._mark_dirty(pos=True, mat=True) # Force full GPU sync for new colors/analysis
        self._sync_gpu(scene)

    def _set_missing_property_coloring(self, scene: Scene, msg: str, quiet: bool = False):
        """Sets scene to gray and logs a UI warning."""
        if not quiet:
            self.analysis.registry.log_warning(msg)
        # All NaNs will map to gray in _map_to_palette
        scalars = np.full(scene.N, np.nan, dtype=np.float32)
        scene.colors = self._map_to_palette(scalars)
        
        # Update UI Diagnostic status
        if scene is self.scene:
            valid_mask = np.isfinite(scalars)
            valid_count = np.sum(valid_mask)
            if valid_count > 0:
                v_min, v_max = np.nanmin(scalars[valid_mask]), np.nanmax(scalars[valid_mask])
                self._coloring_status = f"Data: {valid_count}/{scene.N} atoms | Range: [{v_min:.2f}, {v_max:.2f}]"
            else:
                self._coloring_status = "Data: No valid scalars found (Gray)"
        
        self._apply_selection_highlight(scene)
        self._sync_gpu(scene)

    def _map_to_palette(self, scalars: np.ndarray) -> np.ndarray:
        """Turns a vector of scalars into RGB colors using CPK or linear maps."""
        if scalars.size == 0: return np.zeros((0, 3), dtype=np.float32)
        
        valid_mask = np.isfinite(scalars)
        if not np.any(valid_mask):
            return np.ones((len(scalars), 3), dtype=np.float32) * 0.5 # Neutral Gray fallback
            
        # Hardened Contract: Use nanmin/nanmax for range and exclude NaNs
        v_min = np.nanmin(scalars[valid_mask]) if self.color_range_auto else self.color_range[0]
        v_max = np.nanmax(scalars[valid_mask]) if self.color_range_auto else self.color_range[1]
        
        if v_max == v_min: 
            v_max += 1e-7
            t = np.full_like(scalars, 0.5, dtype=np.float32)
        else:
            t = np.zeros_like(scalars, dtype=np.float32)
            # Clip only valid values to [0,1]; NaNs remain unaffected or handled by the mask
            t[valid_mask] = np.clip((scalars[valid_mask] - v_min) / (v_max - v_min), 0.0, 1.0)
            
        if self.color_invert: t[valid_mask] = 1.0 - t[valid_mask]
        
        colors = np.zeros((len(t), 3), dtype=np.float32)
        
        if self.color_palette == "BlueRed":
            # Blue -> White -> Red
            m_lo = valid_mask & (t < 0.5)
            t_lo = t[m_lo] * 2.0
            colors[m_lo] = np.column_stack((t_lo, t_lo, np.ones_like(t_lo)))
            
            m_hi = valid_mask & (t >= 0.5)
            t_hi = 1.0 - (t[m_hi] - 0.5) * 2.0
            colors[m_hi] = np.column_stack((np.ones_like(t_hi), t_hi, t_hi))
            
        elif self.color_palette == "Viridis":
            colors[valid_mask, 0] = t[valid_mask]**2
            colors[valid_mask, 1] = t[valid_mask]
            colors[valid_mask, 2] = 0.5 * (1.0 - t[valid_mask])
            
        elif self.color_palette == "Magma":
            colors[valid_mask, 0] = np.clip(t[valid_mask] * 1.2, 0, 1)
            colors[valid_mask, 1] = t[valid_mask]**3
            colors[valid_mask, 2] = 0.2 + 0.3 * t[valid_mask]
            
        elif self.color_palette == "Hot":
            colors[valid_mask, 0] = np.clip(t[valid_mask] * 3.0, 0, 1)
            colors[valid_mask, 1] = np.clip(t[valid_mask] * 3.0 - 1.0, 0, 1)
            colors[valid_mask, 2] = np.clip(t[valid_mask] * 3.0 - 2.0, 0, 1)
            
        elif self.color_palette == "Grayscale":
            v = t[valid_mask]
            colors[valid_mask] = np.column_stack((v, v, v))
            
        # 3. Handle invalid (NaN) at the very end to avoid palette overwrite
        colors[~valid_mask] = np.array([0.5, 0.5, 0.5], dtype=np.float32)
        
        return colors

    def _apply_selection_highlight(self, scene: Scene):
        """Force yellow highlight on selected atoms regardless of mode."""
        if not self.color_highlight_selection or not scene.selected_atoms: return
        for idx in scene.selected_atoms:
            if idx < scene.N:
                scene.colors[idx] = np.array([1.0, 0.9, 0.1], dtype=np.float32)

    def _render_without_hover(self, w, h):
        """Helper to render a clean frame without hover highlights or GUI."""
        old_hover = self.hover_info
        old_bg = list(self.bg_color)
        
        # Apply overrides
        if self.hide_hover_in_export:
            self.hover_info = None
            
        # bg_modes = ["Current", "Dark", "Transparent", "White"]
        if self.screenshot_bg_idx == 1: # Dark
            self.bg_color = [0.05, 0.05, 0.06]
        elif self.screenshot_bg_idx == 2: # Transparent-ish (Black for now)
            self.bg_color = [0.0, 0.0, 0.0]
        elif self.screenshot_bg_idx == 3: # White
            self.bg_color = [1.0, 1.0, 1.0]
            
        try:
            self._render_scene(w, h)
        finally:
            self.hover_info = old_hover
            self.bg_color = old_bg

    def save_screenshot(self):
        """Captures the current viewport and saves to PNG/JPG."""
        from PIL import Image
        import time
        import os
        
        # Ensure directory exists
        if not os.path.exists(self.export_folder):
            os.makedirs(self.export_folder)
            
        # Get actual framebuffer size
        w, h = glfw.get_framebuffer_size(self.win)
        
        # Clean Render
        self._render_without_hover(w, h)
        
        pixels = glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE)
        img = Image.frombytes("RGB", (w, h), pixels)
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
        
        ext = self.screenshot_formats[self.screenshot_fmt_idx].lower()
        fname = os.path.join(self.export_folder, f"{self.export_base_name}_{int(time.time())}.{ext}")
        img.save(fname)
        self.export_status = f"Saved: {fname}"

    def export_gif(self):
        """Generates a GIF animation from the trajectory with smart sampling."""
        import imageio
        from PIL import Image
        import random
        import time
        import os
        
        # Ensure directory exists
        if not os.path.exists(self.export_folder):
            os.makedirs(self.export_folder)
            
        N_total = len(self.provider)
        count = min(self.gif_frame_count, N_total)
        
        if self.animation_selection_mode == 1: # Random
            indices = sorted(random.sample(range(N_total), count))
        else: # Uniform
            indices = np.linspace(0, N_total-1, count, dtype=int)
            
        frames = []
        original_idx = self.index1
        self.export_status = f"Rendering {count} frames..."
        
        # Save old hover state for the whole loop
        old_hover = self.hover_info
        if self.hide_hover_in_export:
            self.hover_info = None
            
        try:
            # We need to render each frame to capture it
            for idx in indices:
                self.index1 = idx
                self._load_frame1(idx)
                
                w, h = glfw.get_framebuffer_size(self.win)
                glViewport(0, 0, w, h)
                
                # Render scene (Clean)
                self._render_scene(w, h)
                
                # Capture
                pixels = glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE)
                img = Image.frombytes("RGB", (w, h), pixels)
                img = img.transpose(Image.FLIP_TOP_BOTTOM)
                # Scale down if too large to save space/time
                if w > 800:
                    img.thumbnail((800, 800), Image.Resampling.LANCZOS)
                frames.append(np.array(img))
                
                glfw.swap_buffers(self.win) # Visual feedback during export
        finally:
            self.hover_info = old_hover
            
        fname = os.path.join(self.export_folder, f"{self.export_base_name}_{int(time.time())}.gif")
        self.export_status = "Encoding GIF (please wait)..."
        imageio.mimsave(fname, frames, fps=self.animation_fps, loop=0 if self.animation_loop else 1)
        self.export_status = f"Exported: {fname}"
        
        # Restore original state
        self.index1 = original_idx
        self._load_frame1(original_idx)

    def export_current_structure(self):
        """Exports the current scene structure using the selected format, respecting clipping and selection."""
        import time
        import os
        from .io.exporters import export_structure
        
        # Ensure directory exists
        if not os.path.exists(self.export_folder):
            os.makedirs(self.export_folder)
            
        fmt = self.export_formats[self.export_fmt_idx]
        fname = os.path.join(self.export_folder, f"{self.export_base_name}_{int(time.time())}.{fmt}")
        
        # Determine subset of indices to export
        if self.export_selected_only and self.scene.selected_atoms:
            indices = np.array(self.scene.selected_atoms, dtype=int)
        else:
            indices = self._get_clipped_indices(self.scene)

        if not len(indices):
            self.export_status = "Error: No atoms in visible/selected region to export."
            return

        if self.export_all_frames:
            n_frames = len(self.provider)
            self.export_status = f"Exporting {n_frames} frames..."
            succ_count = 0
            
            for i in range(n_frames):
                p, l, e, els, c, r, i_inf = self.provider.get(i)
                pos_all = np.asarray(p, dtype=np.float32).reshape(-1, 3)
                
                # Apply current mask (clipping or selection) to this frame
                if self.export_selected_only and self.scene.selected_atoms:
                    frame_indices = np.array(self.scene.selected_atoms, dtype=int)
                elif self.clipping_enabled:
                    if self.clipping_fractional:
                        inv_l = np.linalg.inv(l)
                        vals = pos_all @ inv_l[:, self.clipping_axis]
                    else:
                        vals = pos_all[:, self.clipping_axis]
                    mask = (vals >= self.clipping_range[0]) & (vals <= self.clipping_range[1])
                    if self.clipping_invert: mask = ~mask
                    frame_indices = np.where(mask)[0]
                else:
                    frame_indices = np.arange(len(pos_all))
                
                if not len(frame_indices): continue
                
                ok, _ = export_structure(
                    fname, fmt, pos_all[frame_indices], l, [els[k] for k in frame_indices], 
                    energy=e, append=(succ_count > 0)
                )
                if ok: succ_count += 1
            
            self.export_status = f"Exported {succ_count} frames to {fname}"
        else:
            success, msg = export_structure(
                fname, fmt, 
                self.scene.pos[indices], 
                self.scene.lat, 
                [self.scene.elements[k] for k in indices], 
                energy=self.scene.energy,
                append=False
            )
            self.export_status = f"Exported to {fname}" if success else msg

    def _get_clipped_indices(self, scene: Scene) -> np.ndarray:
        """Returns indices of atoms that are currently within the clipping box."""
        if not self.clipping_enabled:
            return np.arange(scene.N)
        
        if self.clipping_fractional:
            inv_lat = np.linalg.inv(scene.lat)
            vals = (scene.pos @ inv_lat)[:, self.clipping_axis]
        else:
            vals = scene.pos[:, self.clipping_axis]
            
        mask = (vals >= self.clipping_range[0]) & (vals <= self.clipping_range[1])
        if self.clipping_invert: mask = ~mask
        return np.where(mask)[0]

    def _calc_cn_distribution(self):
        """Calculates coordination numbers based on a simple distance cutoff with PBC support."""
        self.export_status = "Calculating CN..."
        N = self.scene.N
        if N == 0: return
        
        indices = self._get_clipped_indices(self.scene)
        if not len(indices): return
        
        pos = self.scene.pos[indices]
        lat = self.scene.lat if self.scene.is_periodic else None
        cutoff = self.cn_cutoff
        
        from .analysis.coordination import compute_cn
        _, cnts = compute_cn(pos, lat, r_cut=cutoff)
        
        # Align with full scene using NaN
        cn_full = np.full(self.scene.N, np.nan, dtype=np.float32)
        cn_full[indices] = cnts.astype(np.float32)
        
        self.cn_results = cn_full
        self.scene.cn = cn_full
        self.analysis.registry.register_property("coordination", cn_full)
        
        print(f"Coordination Number computed for {len(indices)} atoms (PBC={self.scene.is_periodic}).")
        self.export_status = "CN Computed."
        self._update_coloring()

    def _run_tb_calculation(self):
        """Runs the tight-binding pipeline on the current scene."""
        from .analysis.tight_binding import run_tight_binding
        N = self.scene.N
        if N == 0:
            self.tb_status = "No atoms loaded."
            return
        if N > 2000:
            self.tb_status = f"Warning: N={N} > 2000, may be slow..."
        
        self.tb_status = f"Running TB (N={N})..."
        try:
            lat = self.scene.lat if self.scene.is_periodic else None
            self.tb_results = run_tight_binding(
                self.scene.pos, self.scene.elements, self.tb_params, lat
            )
            res = self.tb_results
            self.tb_status = (
                f"Done. HOMO={res.homo:+.2f}eV  Gap={res.gap:.2f}eV"
            )
            # Auto-show DOS
            self.tb_show_dos = True
        except Exception as e:
            self.tb_status = f"Error: {e}"
            self.tb_results = None

    def _reset_tb_analysis(self):
        """Clears all Tight-Binding results and UI state (called on structure change)."""
        self.tb_results = None
        self.tb_pdos_visibility = {}
        self.tb_pdos_orb_visibility = {}
        self.tb_pos_mesh = None
        self.tb_neg_mesh = None
        self.tb_selected_state = -1
        self.tb_viz_mode = "None"
        self.tb_status = "TB Reset (Structure changed)"
        
        # Clear GPU Mesh Renderers
        if hasattr(self, 'rnd_mesh_pos'): self.rnd_mesh_pos.has_data = False
        if hasattr(self, 'rnd_mesh_neg'): self.rnd_mesh_neg.has_data = False
        
    def _reconstruct_tb_field(self):
        """Phase 4/5: Reconstructs 3D scalar fields and uploads them to the VolumeRenderer."""
        if self.tb_results is None: return
        
        from .analysis.tb_visualization import (
            make_grid_from_atoms, build_state_field, build_state_density_field,
            build_total_density_field_exact, build_total_density_field_diagonal,
            normalize_field
        )
        
        mode = self.tb_viz_mode
        self.tb_status = f"Reconstructing {mode} field..."
        
        try:
            grid = make_grid_from_atoms(self.scene.pos, self.tb_params)
            res = self.tb_results
            
            # Extract atom_to_orbs and orb_info (rebuild if not stored)
            if res.orb_info and res.atom_to_orbs:
                ato, oi = res.atom_to_orbs, res.orb_info
            else:
                from .analysis.tight_binding import build_hamiltonian
                lat = self.scene.lat if self.scene.is_periodic else None
                _, _, ato, oi = build_hamiltonian(self.scene.pos, self.scene.elements, self.tb_params, lat)
            
            field = None
            is_signed = False
            
            if mode == "HOMO (signed)":
                idx = res.n_occ_states - 1
                if idx >= 0:
                    field = build_state_field(self.scene.pos, self.scene.elements, oi, res.eigenvectors, idx, grid, self.tb_params)
                    if self.tb_params.normalize_fields: normalize_field(field)
                    is_signed = True
            elif mode == "LUMO (signed)":
                idx = res.n_occ_states
                if idx < res.eigenvectors.shape[1]:
                    field = build_state_field(self.scene.pos, self.scene.elements, oi, res.eigenvectors, idx, grid, self.tb_params)
                    if self.tb_params.normalize_fields: normalize_field(field)
                    is_signed = True
            elif mode == "State (signed)" and self.tb_selected_state != -1:
                idx = self.tb_selected_state
                field = build_state_field(self.scene.pos, self.scene.elements, oi, res.eigenvectors, idx, grid, self.tb_params)
                if self.tb_params.normalize_fields: normalize_field(field)
                is_signed = True
            elif mode == "State Density" and self.tb_selected_state != -1:
                idx = self.tb_selected_state
                field = build_state_density_field(self.scene.pos, self.scene.elements, oi, res.eigenvectors, idx, grid, self.tb_params)
            elif mode == "Total Density (Exact)":
                field = build_total_density_field_exact(self.scene.pos, self.scene.elements, oi, 
                                                       res.eigenvectors, res.occupations, grid, self.tb_params)
            elif mode == "Total Density (Cheap)":
                field = build_total_density_field_diagonal(self.scene.pos, self.scene.elements, oi, 
                                                         res.eigenvectors, res.occupations, grid, self.tb_params)
            
            elif mode == "None":
                self.tb_show_volume = False
                self.tb_status = "Visualization: Off"
                return
            
            if field is not None:
                if self.tb_mesh_mode:
                    from .analysis.tb_visualization import extract_dual_isosurface
                    self.tb_pos_mesh, self.tb_neg_mesh = extract_dual_isosurface(field, self.tb_vol_iso)
                    if self.tb_pos_mesh:
                        self.rnd_mesh_pos.upload_data(self.tb_pos_mesh.vertices, self.tb_pos_mesh.normals, self.tb_pos_mesh.faces)
                    else:
                        self.rnd_mesh_pos.has_data = False
                    if self.tb_neg_mesh:
                        self.rnd_mesh_neg.upload_data(self.tb_neg_mesh.vertices, self.tb_neg_mesh.normals, self.tb_neg_mesh.faces)
                    else:
                        self.rnd_mesh_neg.has_data = False
                    self.tb_show_volume = False # Hide raymarched volume
                    self.tb_status = f"Done: {mode} mesh extracted."
                else:
                    # Upload to GPU Volume Renderer
                    self.rnd_volume.upload_data(field.values, field.grid.origin, np.array([field.grid.spacing]*3), is_signed=is_signed)
                    self.tb_status = f"Done: {mode} reconstructed."
                    self.tb_show_volume = True
                    self.tb_pos_mesh = None
                    self.tb_neg_mesh = None
            else:
                self.tb_show_volume = False
                self.tb_pos_mesh = None
                self.tb_neg_mesh = None
                self.tb_status = "Field reconstruction failed (Invalid mode or index)."
                
        except Exception as e:
            self.tb_status = f"Error: {e}"
            print(f"TB Viz Error: {e}")

    def _apply_tb_coloring(self):
        """Maps TB charge or bond order onto atom sphere colors."""
        if self.tb_results is None or self.tb_color_mode == "None":
            self._update_coloring()
            return
        
        N = self.scene.N
        rgba = np.ones((N, 4), dtype=np.float32)
        rgba[:, :3] = self._get_element_colors(self.scene)[:, :3]
        
        if self.tb_color_mode == "TB Charge" and len(self.tb_results.local_charge) == N:
            q = self.tb_results.local_charge.copy()
            q_min, q_max = q.min(), q.max()
            if q_max > q_min:
                t = (q - q_min) / (q_max - q_min)
            else:
                t = np.full(N, 0.5)
            # Blue=low → Red=high
            rgba[:, 0] = t
            rgba[:, 1] = 0.3 * (1 - t)
            rgba[:, 2] = 1.0 - t
        
        elif self.tb_color_mode == "TB Bond Order":
            # Color atoms by their max bond order to any neighbor
            bo_map = np.zeros(N, dtype=np.float32)
            for (i, j), bo in self.tb_results.bond_order.items():
                bo_map[i] = max(bo_map[i], abs(bo))
                if j < N:
                    bo_map[j] = max(bo_map[j], abs(bo))
            bo_max = bo_map.max()
            if bo_max > 0:
                t = bo_map / bo_max
                rgba[:, 0] = 0.2 + 0.8 * t
                rgba[:, 1] = 0.8 * t
                rgba[:, 2] = 0.4 * (1 - t)
        
        # we must update the base scene colors so clipping can pull them.
        self.scene.colors = rgba.copy()
        self._clipping_dirty = True
        
        # Trigger next render pass to pick up everything
        self._mark_dirty(pos=True) 

    def _maybe_update_clipping_alpha(self):
        """Lazy update for clipping state. Prevents redundant GPU uploads."""
        if not self._clipping_dirty:
            return

        if self.clipping_enabled:
            # Recompute alpha mask and upload
            self._update_clipping_alpha()
        else:
            # Clipping was just disabled: Restore full opaque colors
            self._sync_gpu(self.scene)

        self._clipping_dirty = False

    def _update_clipping_alpha(self):
        """Calculates and uploads the alpha channel based on clipping range."""
        if self.scene.N == 0:
            return

        # 1. Calculate clipping mask
        if self.clipping_fractional:
            inv_lat = np.linalg.inv(self.scene.lat)
            vals = (self.scene.pos @ inv_lat)[:, self.clipping_axis]
        else:
            vals = self.scene.pos[:, self.clipping_axis]

        mask_in_range = (vals >= self.clipping_range[0]) & (vals <= self.clipping_range[1])
        
        # If invert=False: In-range is visible (alpha=1), out-of-range is ghosted (alpha=clipping_alpha)
        # If invert=True: Out-of-range is visible, in-range is ghosted
        if self.clipping_invert:
            mask_ghost = mask_in_range
        else:
            mask_ghost = ~mask_in_range

        # 2. Compose RGBA from current color source
        rgba = np.ones((self.scene.N, 4), dtype=np.float32)
        
        # Priority 1: Current analysis/custom colors on the scene
        # Priority 2: Fallback to base element colors
        cur_colors = getattr(self.scene, "colors", None)
        if cur_colors is not None and len(cur_colors) == self.scene.N:
            rgba[:, :3] = cur_colors[:, :3]
        else:
            rgba[:, :3] = self._get_element_colors(self.scene)[:, :3]

        rgba[:, 3] = np.where(mask_ghost, self.clipping_alpha, 1.0).astype(np.float32)

        # 3. Synchronize GPU Buffers
        self.rnd_sphere.upload_data(self.scene.pos, self.scene.radii, rgba)
        if self.show_bonds and self.scene.bond_count > 0:
            self.rnd_bond.upload_data(self.scene.pos, self.scene.bonds, rgba, self.scene.lat)

    def _generate_gaussian_density(self):
        """Triggers density generation and uploads to GPU."""
        from .analysis.volumetric import generate_density_from_atoms
        self.export_status = "Generating Density..."
        
        res = getattr(self, "vol_res", 0.25)
        sigma = getattr(self, "vol_sigma", 0.5)
        
        self.vol_data = generate_density_from_atoms(
            self.scene.pos, 
            np.ones(len(self.scene.pos)) * 1.5, # Default radii if not per-atom
            voxels_per_a=res, 
            sigma=sigma
        )
        self.vol_min = float(np.min(self.vol_data.grid))
        self.vol_max = float(np.max(self.vol_data.grid))
        self.vol_iso_level = self.vol_min + 0.2 * (self.vol_max - self.vol_min)
        
        self.rnd_volume.upload_data(self.vol_data.grid, self.vol_data.origin, self.vol_data.spacing)
        self.vol_enabled = True
        self.export_status = f"Generated {self.vol_data.shape} grid. Max={self.vol_max:.2f}"

    def _load_volumetric_cube(self):
        """Opens a file dialog (simulated) or loads from a preset path."""
        # In a real app, this would use a file picker. 
        # For now, we'll try to load a default or prompt for path if possible.
        from .analysis.volumetric import load_cube_file
        try:
            self.vol_data = load_cube_file(self._cube_path)
            self.vol_min = float(np.min(self.vol_data.grid))
            self.vol_max = float(np.max(self.vol_data.grid))
            self.vol_iso_level = self.vol_min + 0.2 * (self.vol_max - self.vol_min)
            
            self.rnd_volume.upload_data(self.vol_data.grid, self.vol_data.origin, self.vol_data.spacing)
            self.vol_enabled = True
            self.export_status = f"Loaded {self._cube_path}. Range=[{self.vol_min:.2f}, {self.vol_max:.2f}]"
        except Exception as e:
            self.export_status = f"Error loading .cube: {e}"
    def _run_id_buffer_pass(self, scene: Scene, cam: OrbitCamera, x: int, y: int, w: int, h: int, atom_scale: float, is_ortho: bool, visible_pairs: Optional[np.ndarray], view, proj, hover_idx: int = -1):
        """Renders scene content into an ID buffer segment for picking (Isolated)."""
        # --- State Isolation ---
        prev_fbo = glGetIntegerv(GL_FRAMEBUFFER_BINDING)
        prev_vp = glGetIntegerv(GL_VIEWPORT)
        
        from .renderer.id_buffer import IDRangeMapper
        mapper = IDRangeMapper(scene.N, scene.bond_count)
        
        glBindFramebuffer(GL_FRAMEBUFFER, self.id_picking.fbo)
        
        vx, vy, vw, vh = int(x), int(y), int(w), int(h)
        glViewport(vx, vy, vw, vh)
        glEnable(GL_SCISSOR_TEST)
        glScissor(vx, vy, vw, vh)
        
        # Clear the segment for this viewport
        glClearColor(0, 0, 0, 0)
        glClearDepth(1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)
        
        # Use exact matrices passed from the visual pass to ensure 1:1 precision
        # 1. Atoms (Uses Synchronized Visible Pairs)
        self.rnd_sphere.draw_picking(view, proj, mapper.atom_offset, atom_scale, is_ortho, visible_pairs, hover_idx)
        
        # 2. Bonds (if visible)
        if self.show_bonds and hasattr(self, 'rnd_bond'):
             self.rnd_bond.draw_picking(view, proj, mapper.bond_offset)
             
        # 3. Polyhedra (if visible)
        if hasattr(self, 'rnd_poly'):
             self.rnd_poly.draw(view, proj, np.eye(4, dtype=np.float32), cam.eye(), 1.0, is_oit=False, is_picking=True)
             
        glDisable(GL_SCISSOR_TEST)
        
        # --- Restore State ---
        glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo)
        glViewport(*prev_vp)
        
    def _init_oit_fbo(self, w: int, h: int):
        """Initializes the Order-Independent Transparency (OIT) framebuffer and textures."""
        if w <= 0 or h <= 0: return
        
        # Ensure post-process textures (like tex_depth) are allocated before sharing
        self.post_process.resize(w, h)
        
        if hasattr(self, 'oit_fbo') and self.oit_fbo > 0:
            glDeleteFramebuffers(1, [self.oit_fbo])
            glDeleteTextures(1, [self.oit_accum_tex])
            glDeleteTextures(1, [self.oit_reveal_tex])

        self.oit_fbo = glGenFramebuffers(1)
        glBindFramebuffer(GL_FRAMEBUFFER, self.oit_fbo)

        # 1. Accumulation buffer (RGBA16F for high dynamic range blending)
        self.oit_accum_tex = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, self.oit_accum_tex)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, w, h, 0, GL_RGBA, GL_FLOAT, None)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, self.oit_accum_tex, 0)

        # 2. Revealage buffer (R16F for distance-based weight product)
        self.oit_reveal_tex = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, self.oit_reveal_tex)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_R16F, w, h, 0, GL_RED, GL_FLOAT, None)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, self.oit_reveal_tex, 0)

        # 3. Share Main Depth Texture (essential for depth testing against atoms)
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, self.post_process.tex_depth, 0)

        bufs = [GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1]
        glDrawBuffers(2, bufs)

        status = glCheckFramebufferStatus(GL_FRAMEBUFFER)
        if status != GL_FRAMEBUFFER_COMPLETE:
            print(f"[OIT] FBO Incomplete: {hex(status)}")
            self.pretty_render = False 

        glBindFramebuffer(GL_FRAMEBUFFER, 0)

    def _resolve_oit(self, w: int, h: int):
        """Composites the OIT accumulation and revealage buffers into the default framebuffer."""
        glEnable(GL_BLEND)
        # Canonical OIT resolve blend: result * (1-coverage) + background * coverage
        # Our resolve shader returns vec4(color, coverage)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        self.rnd_quad.draw_oit_resolve(self.oit_accum_tex, self.oit_reveal_tex)
        glDisable(GL_BLEND)

    def _update_scientific_geometry_cache(self, scene: Scene):
        """Triggers derived geometry generation jobs for Voronoi (Polyhedra handled by batch PolyhedronAnalyzer)."""
        if not self.show_voronoi_cells: return
        
        # Identify atoms needing geometry
        target_indices = []
        if self.poly_mode == 0: target_indices = scene.selected_atoms
        elif self.poly_mode == 1:
            selected_species = set(self.scene.elements[i] for i in self.scene.selected_atoms)
            target_indices = [i for i, el in enumerate(self.scene.elements) if el in selected_species]
        else: target_indices = range(scene.N)
            
        def _on_voronoi_ready(result):
            if not result: return
            idx, verts, faces = result['center_index'], result['vertices'], result['faces']
            from .renderer.utils import compute_normals
            norms = compute_normals(verts, faces)
            colors = np.array([0.4, 0.7, 1.0], dtype=np.float32) * np.ones_like(verts)
            vao = glGenVertexArrays(1)
            vbos = glGenBuffers(3)
            ebo = glGenBuffers(1)
            glBindVertexArray(vao)
            glBindBuffer(GL_ARRAY_BUFFER, vbos[0]); glBufferData(GL_ARRAY_BUFFER, verts.nbytes, verts, GL_STATIC_DRAW)
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None); glEnableVertexAttribArray(0)
            glBindBuffer(GL_ARRAY_BUFFER, vbos[1]); glBufferData(GL_ARRAY_BUFFER, norms.nbytes, norms, GL_STATIC_DRAW)
            glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, None); glEnableVertexAttribArray(1)
            glBindBuffer(GL_ARRAY_BUFFER, vbos[2]); glBufferData(GL_ARRAY_BUFFER, colors.nbytes, colors, GL_STATIC_DRAW)
            glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, None); glEnableVertexAttribArray(2)
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, faces.nbytes, faces, GL_STATIC_DRAW)
            glBindVertexArray(0)
            self.geo_cache.put(f"voro_{idx}", self.v_struct, len(faces)*3, vao, vbos, ebo)

        for idx in target_indices:
            if self.show_voronoi_cells:
                if not self.geo_cache.get(f"voro_{idx}", self.v_struct):
                    self.analysis.submit_job("voronoi", {"index": idx, "pos": scene.pos, "lat": scene.lat}, callback=_on_voronoi_ready)

    def _draw_scientific_geometry(self, view, proj, is_oit: bool):
        """Renders batched polyhedra and cached scientific meshes."""
        if not self.show_polyhedra and not self.show_voronoi_cells:
            return
            
        cam_pos = self.cam1.eye()
        
        # Proper state for scientific geometry
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)
        glDisable(GL_CULL_FACE)
        
        if is_oit:
            glDepthMask(GL_FALSE) # OIT color pass does not write depth
        else:
            glDepthMask(GL_TRUE) # Opaque pass writes depth
            
        if not is_oit:
            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        # 1. Batched Polyhedra Rendering
        if self.show_polyhedra and self.rnd_poly:
            self.rnd_poly.show_wireframe = getattr(self.poly_settings, "show_wireframe", False)
            self.rnd_poly.draw(view, proj, np.eye(4, dtype=np.float32), cam_pos, 
                               self.poly_opacity, is_oit=is_oit)

        # 2. Legacy Per-Atom Geometry
        if self.show_voronoi_cells:
            indices = range(self.scene.N)
            if self.poly_mode == 0: indices = self.scene.selected_atoms
            elif self.poly_mode == 1:
                sel_s = set(self.scene.elements[i] for i in self.scene.selected_atoms)
                indices = [i for i, el in enumerate(self.scene.elements) if el in sel_s]

            for idx in indices:
                mesh = self.geo_cache.get(f"voro_{idx}", self.v_struct)
                if mesh:
                    for offset in self.scene.replica_offsets:
                        model = np.eye(4, dtype=np.float32)
                        model[0:3, 3] = offset
                        self.rnd_poly.draw_vao(mesh['vao'], mesh['count'], view, proj, model, cam_pos, 0.5, is_oit=is_oit, ebo=mesh.get('ebo'))

        glDepthMask(GL_TRUE) 
        glEnable(GL_CULL_FACE)
        if not is_oit:
            glDisable(GL_BLEND)
        
        if is_oit:
             self._oit_active = True

    def _resolve_picked_object(self, x: int, y: int, cam: Optional[OrbitCamera] = None) -> Optional[dict]:
        """Reads pixel from ID buffer with a 3x3 neighborhood search for robustness."""
        win_w, win_h = glfw.get_window_size(self.win)
        fb_w, fb_h = glfw.get_framebuffer_size(self.win)
        
        # Exact scaling to framebuffer pixels
        mx_fb = int(x * fb_w / win_w)
        my_fb = int(y * fb_h / win_h)
        
        # 1. Try exact center pixel first
        raw_id = self.id_picking.read_pixel(mx_fb, my_fb)
        
        # 2. If center is empty, look in a tiny 3x3 neighborhood (Robustness for thin borders/zoom)
        if raw_id == 0:
            for dx in [-1, 1, 0]:
                for dy in [-1, 1, 0]:
                    if dx == 0 and dy == 0: continue
                    try:
                        nid = self.id_picking.read_pixel(mx_fb + dx, my_fb + dy)
                        if nid != 0:
                            raw_id = nid
                            break
                    except: continue
                if raw_id != 0: break

        if raw_id == 0: return None
        
        from .renderer.id_buffer import IDRangeMapper
        s = self.scene
        if cam is self.cam2 and self.scene2: s = self.scene2
        
        mapper = IDRangeMapper(s.N, s.bond_count)
        obj_type, idx = mapper.resolve_id(raw_id)
        
        if obj_type is None: return None
        res = {"type": obj_type, "index": idx}
        
        # Hydrate with Registry properties (if Atom)
        if obj_type == "atom":
            props = self.analysis.registry.get_all_for_index(idx)
            res.update(props)
            res["element"] = self.scene.elements[idx]
            res["pos"] = self.scene.pos[idx]
            
            if self.scene.lat is not None:
                try:
                    inv_lat = np.linalg.inv(self.scene.lat)
                    res["frac_pos"] = self.scene.pos[idx] @ inv_lat
                except:
                    pass
            
            # Add distortion metrics if they exist in the registry (from polyhedron analysis)
            dist_metrics = self.analysis.registry.get_property(f"distortion_{idx}")
            if dist_metrics:
                res.update(dist_metrics)
        
        return res

    def _analyze_gallery_data(self):
        """Pre-calculates global metrics for the heatmap (Energies, etc.)"""
        if not self.provider: return
        
        # Try to get all energies if the provider allows bulk access
        energies = []
        try:
            # Check if the provider has a pre-loaded metadata cache
            if hasattr(self.provider, "get_all_metadata"):
                meta = self.provider.get_all_metadata()
                energies = [float(m.get('energy', 0.0)) for m in meta]
            elif hasattr(self.provider, "data") and isinstance(self.provider.data, list):
                # Many simple providers store items in .data
                for item in self.provider.data:
                    if hasattr(item, 'info'):
                        energies.append(float(item.info.get('energy', 0.0)))
                    elif isinstance(item, dict):
                        energies.append(float(item.get('energy', 0.0)))
        except:
            pass
            
        if energies and len(energies) > 0:
            self._gallery_energies = energies # STORE for the visibility query to use
            self._gallery_e_min = min(energies)
            self._gallery_e_max = max(energies)
            # Add a small epsilon to avoid div by zero
            if abs(self._gallery_e_max - self._gallery_e_min) < 1e-6:
                self._gallery_e_max += 1.0
        else:
            self._gallery_energies = None
            self._gallery_e_min = -1.0
            self._gallery_e_max = 1.0

    def _draw_structure_card(self, pos, metadata, view, proj, w, h):
        """Floating metadata card for gallery items (Z-up optimized)."""
        mvp = proj @ view
        # Float 5.5 units above in Z to avoid clipping with the structure
        p4 = mvp @ np.array([pos[0], pos[1], pos[2] + 5.5, 1.0], dtype=np.float32)
        
        if p4[3] < 0.1: return
        ndc = p4[:2] / p4[3]
        sx = (ndc[0] + 1.0) * 0.5 * w
        sy = (1.0 - ndc[1]) * 0.5 * h
        
        imgui.set_next_window_position(sx, sy)
        imgui.set_next_window_bg_alpha(0.85)
        
        # Use a unique ID for each card to avoid collisions
        idx = metadata.get('idx', '?')
        imgui.begin(f"##card_{idx}", False, imgui.WINDOW_NO_TITLE_BAR | imgui.WINDOW_ALWAYS_AUTO_RESIZE | imgui.WINDOW_NO_MOVE | imgui.WINDOW_NO_SCROLLBAR)
        
        imgui.text_colored(f"Structure #{idx}", 0.4, 0.8, 1.0, 1.0)
        imgui.separator()
        
        # Show Formula
        formula = metadata.get('composition_str', metadata.get('formula'))
        if formula:
            imgui.text_colored("Formula:", 0.5, 0.5, 0.5, 1.0)
            imgui.same_line()
            imgui.text(str(formula))
        
        # Show Energy
        energy = metadata.get('energy')
        if energy is not None:
            imgui.text_colored("Energy: ", 0.5, 0.5, 0.5, 1.0)
            imgui.same_line()
            try:
                val = float(energy)
                # Colorize text based on relative energy (Red=High, Green=Low)
                rel = (val - self._gallery_e_min) / (self._gallery_e_max - self._gallery_e_min)
                imgui.text_colored(f"{val:.3f} eV", 1.0 - (1.0-rel)*0.5, 0.5 + (1.0-rel)*0.5, 0.5, 1.0)
            except:
                imgui.text(str(energy))

        # --- NEW: Mini Sparkline (Fingerprint) ---
        imgui.spacing()
        imgui.text_disabled("Structural Fingerprint:")
        # Generate a synthetic but deterministic fingerprint based on the ID and energy
        # In a real scenario, this would be a RDF or DOS array
        seed = int(idx) if str(idx).isdigit() else 0
        np.random.seed(seed)
        fingerprint = np.cumsum(np.random.randn(20)).astype(np.float32)
        imgui.plot_lines("##spark", fingerprint, graph_size=(180, 40))
        imgui.spacing()

        # Show other compact metadata
        skip_keys = {'idx', 'composition_str', 'formula', 'n_atoms', 'energy', 'pos', 'type'}
        for k, v in metadata.items():
            if k in skip_keys: continue
            if isinstance(v, (int, float, str)) and len(str(v)) < 24:
                imgui.text_colored(f"{k.replace('_', ' ').title()}:", 0.4, 0.4, 0.4, 1.0)
                imgui.same_line()
                imgui.text(str(v))

        imgui.separator()
        imgui.text_disabled("Press [E] to Inspect")
        imgui.end()

    def _draw_inspector(self):
        """Draws the contextual hover inspector card."""
        if not self.hover_info: return
        
        io = imgui.get_io()
        imgui.set_next_window_position(io.mouse_pos[0] + 15, io.mouse_pos[1] + 15)
        imgui.set_next_window_bg_alpha(0.85)
        
        flags = imgui.WINDOW_NO_TITLE_BAR | imgui.WINDOW_ALWAYS_AUTO_RESIZE | imgui.WINDOW_NO_MOVE | imgui.WINDOW_NO_SAVED_SETTINGS | imgui.WINDOW_NO_FOCUS_ON_APPEARING | imgui.WINDOW_NO_NAV
        if imgui.begin("##inspector", True, flags):
            info = self.hover_info
            
            if self.hover_info_mode == 0:
                imgui.end()
                return

            if info['type'] == 'atom':
                imgui.text_colored(f"{info.get('element', '??')} ({info['index']})", 0.4, 0.8, 1.0)
                
                if self.hover_info_mode == 2:
                    imgui.separator()
                    
                    pos = info.get("pos")
                    if pos is not None:
                        imgui.text(f"Cart: ({pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f}) \u00c5")
                    
                    fpos = info.get("frac_pos")
                    if fpos is not None:
                        imgui.text(f"Frac: ({fpos[0]:.3f}, {fpos[1]:.3f}, {fpos[2]:.3f})")
                    
                    # Show additional registry properties if they are scientific metrics
                    scientific_props = ["coordination_number", "is_surface", "local_charge", "volume"]
                    for k in scientific_props:
                        if k in info:
                            imgui.text(f"{k.replace('_', ' ').title()}: {info[k]}")
            
            elif info['type'] == 'bond':
                imgui.text_colored(f"BOND #{info['index']}", 0.4, 0.8, 1.0)
            elif info['type'] == 'polyhedron':
                idx = info['index']
                # Find the corresponding polyhedron by center index
                poly = next((p for p in self.polyhedra if p.center_idx == idx), None)
                if poly:
                    imgui.text_colored(f"{poly.center_element} Center ({poly.center_idx})", 0.4, 0.8, 1.0)
                    imgui.text_disabled(f"Geometry: {poly.geometry}")
                    imgui.separator()
                    imgui.text(f"Coordination Number: {poly.cn}")
                    imgui.text(f"Distortion: {poly.distortion:.4f}")
                    if poly.angle_variance > 0:
                        imgui.text(f"Angle Variance: {poly.angle_variance:.2f} deg\u00b2")
                    if poly.cn == 6:
                        imgui.text(f"Oct Score: {poly.oct_score:.3f}")
                else:
                    imgui.text_colored("POLYHEDRON", 0.4, 0.8, 1.0)
                
            imgui.end()

    def _draw_top_tab_bar(self):
        """Draws a fixed navigation bar at the top of the screen containing analysis and selection tools."""
        if not hasattr(self, '_top_bar_expanded'):
            self._top_bar_expanded = False
            self._active_top_tab = "Analysis"

        w, _ = glfw.get_window_size(self.win)
        
        # Fixed Positioning at Top
        imgui.set_next_window_position(0, 0)
        imgui.set_next_window_size(w, 180 if self._top_bar_expanded else 35)
        imgui.set_next_window_bg_alpha(0.85)
        
        flags = (imgui.WINDOW_NO_TITLE_BAR | imgui.WINDOW_NO_RESIZE | 
                 imgui.WINDOW_NO_MOVE | imgui.WINDOW_NO_SCROLLBAR | 
                 imgui.WINDOW_NO_SAVED_SETTINGS)
                 
        imgui.begin("##top_nav", False, flags)
        
        if imgui.begin_tab_bar("##top_tabs"):
            # Tab 1: Analysis Hub
            is_analysis, _ = imgui.begin_tab_item("Analysis Dashboard")
            if imgui.is_item_clicked():
                if self._active_top_tab == "AnalysisDashboard":
                    self._top_bar_expanded = not self._top_bar_expanded
                else:
                    self._top_bar_expanded = True
                self._active_top_tab = "AnalysisDashboard"
                
            if is_analysis:
                if self._top_bar_expanded:
                    self._draw_analysis_status_content()
                imgui.end_tab_item()
            
            # Tab 2: Selection Manager
            is_selection, _ = imgui.begin_tab_item("Selection Sets")
            if imgui.is_item_clicked():
                if self._active_top_tab == "SelectionSets":
                    self._top_bar_expanded = not self._top_bar_expanded
                else:
                    self._top_bar_expanded = True
                self._active_top_tab = "SelectionSets"

            if is_selection:
                if self._top_bar_expanded:
                    self._draw_selection_sets_content()
                imgui.end_tab_item()

            # Tab 3: Structural Workshop
            is_workshop, _ = imgui.begin_tab_item("Structural Workshop")
            if imgui.is_item_clicked():
                self.show_workshop = not getattr(self, "show_workshop", False)
                self._active_top_tab = "StructuralWorkshop"
                self._top_bar_expanded = False # Direct window toggle, no expansion needed
            
            if is_workshop:
                imgui.end_tab_item()
                
        imgui.end_tab_bar()
        imgui.end()

    def _draw_analysis_status_content(self):
        """Internal logic for the analysis dashboard (headless)."""
        # Overall Invalidation Status
        if self._analysis_dirty:
            imgui.text_colored("Status: STALE DATA", 1.0, 0.4, 0.4)
        else:
            imgui.text_colored("Status: CONVERGED", 0.4, 1.0, 0.4)
            
        imgui.separator()
        
        # Display each tracked module's state
        modules = ["Geometry", "Bonds", "Clusters", "Voronoi"]
        for mod in modules:
            # Check job queue
            is_thinking = any(job.job_type.lower() == mod.lower() or (mod == "Geometry" and job.job_type in ["polyhedron", "voronoi"])
                             for job in self.analysis.active_jobs.values())
            
            if is_thinking:
                status, col = "RUNNING", (1.0, 0.8, 0.2)
            else:
                # Check versioning/availability
                is_available = self.geo_cache.has_any_for_version(self.v_struct) if mod in ["Geometry", "Voronoi"] else False
                
                # For Bonds/Clusters check PropertyRegistry
                reg_keys = {"Bonds": "bonds", "Clusters": "cluster"}
                key = reg_keys.get(mod)
                has_prop = (key and self.analysis.registry.get_property(key) is not None)
                
                if is_available or has_prop:
                    status, col = "READY", (0.4, 0.9, 0.4)
                else:
                    status, col = "UNAVAILABLE", (0.6, 0.6, 0.6)
            
            imgui.text(f"{mod}:")
            imgui.same_line(120)
            imgui.text_colored(status, *col)
        
        imgui.separator()
        imgui.text_disabled(f"Active Jobs: {len(self.analysis.active_jobs)}")
        imgui.text_disabled(f"Cache Entries: {len(self.geo_cache._entries)}")

    def _draw_selection_query_console(self):
        """Draws the bottom-anchored console with multiple tool tabs."""
        if not hasattr(self, '_query_console_expanded'):
            self._query_console_expanded = False

        height = 110 if self._query_console_expanded else 35
        w, h = self.win_size
        imgui.set_next_window_size(w - 20, height, imgui.ALWAYS)
        imgui.set_next_window_position(10, h - height - 10, imgui.ALWAYS)
        imgui.set_next_window_bg_alpha(0.85)
        
        flags = imgui.WINDOW_NO_TITLE_BAR | imgui.WINDOW_NO_RESIZE | imgui.WINDOW_NO_MOVE | imgui.WINDOW_NO_COLLAPSE
        if imgui.begin("Bottom Console", True, flags):
            if imgui.begin_tab_bar("##bottom_tabs"):
                
                # Tab 1: Selection Query
                is_sel, _ = imgui.begin_tab_item("Selection Query Console")
                if imgui.is_item_clicked():
                    self._query_console_expanded = not self._query_console_expanded
                if is_sel:
                    if self._query_console_expanded:
                        imgui.text_disabled(" (Atomic properties + boolean logic)")
                        imgui.same_line()
                        if imgui.button(" Examples "):
                            imgui.open_popup("query_examples_popup")
                        
                        if imgui.begin_popup("query_examples_popup"):
                            imgui.text_disabled("Structure Composition:")
                            for el in self.scene.unique_elements:
                                if imgui.selectable(f"Select all {el} (element == '{el}')")[0]:
                                    self._query_str = f"element == '{el}'"
                            imgui.separator()
                            imgui.text_disabled("Patterns:")
                            for lbl, q in [("Surface", "is_surface"), ("Top", "z > 15.0"), ("H2O", "residue=='H2O'")]:
                                if imgui.selectable(lbl)[0]: self._query_str = q
                            imgui.end_popup()

                        imgui.same_line()
                        imgui.push_item_width(max(200, self.win_size[0] - 420))
                        enter, new_q = imgui.input_text("##query", self._query_str, 2048, imgui.INPUT_TEXT_ENTER_RETURNS_TRUE)
                        if enter:
                            self._query_str = new_q
                            self._execute_selection_query()
                        elif new_q != self._query_str:
                            self._query_str = new_q
                        imgui.pop_item_width()

                        imgui.same_line()
                        if imgui.button(" Apply "): self._execute_selection_query()
                        
                        if self._query_status_msg:
                            imgui.same_line()
                            imgui.text_colored(self._query_status_msg, *self._query_status_color)
                    imgui.end_tab_item()

                # Tab 2: Camera & View Settings
                is_cam, _ = imgui.begin_tab_item("Camera & View Settings")
                if is_cam:
                    self._show_camera_panel = True
                    imgui.text("Professional Camera Panel is active.")
                    imgui.same_line()
                    if imgui.button(" Bring to Front "):
                        imgui.set_window_focus("Professional Camera Control")
                    imgui.end_tab_item()

                # Tab 3: Help & Docs
                is_help, _ = imgui.begin_tab_item("Help & Docs")
                if imgui.is_item_clicked(): self.show_help = True
                if is_help:
                    imgui.text_colored("Press F1 for documentation.", 0.6, 0.8, 1.0)
                    imgui.same_line()
                    if imgui.button(" Open Help Overlay "): self.show_help = True
                    imgui.end_tab_item()

                imgui.end_tab_bar()
        imgui.end()

    def _execute_selection_query(self):
        """Executes the string-based selection query using the AST evaluator."""
        try:
            from .analysis.selection_query import SelectionQueryEvaluator
            # Ensure registry exists
            if not hasattr(self.analysis, "registry") or self.analysis.registry is None:
                raise ValueError("Property Registry is not initialized.")
            
            # 1. Base geometric properties
            query_data = {
                "element": np.array(self.scene.elements),
                "x": self.scene.pos[:,0], "y": self.scene.pos[:,1], "z": self.scene.pos[:,2],
                "selected": np.zeros(self.scene.N, dtype=bool)
            }
            query_data["selected"][self.scene.selected_atoms] = True
            
            # 2. Merge from PropertyRegistry (e.g. coordination_number)
            if hasattr(self.analysis, "registry"):
                for name, arr in self.analysis.registry.get_all_properties().items():
                    query_data[name] = arr
            
            # 3. Merge from scene.info (e.g. residue)
            if self.scene.info:
                for name, vals in self.scene.info.items():
                    if len(vals) == self.scene.N:
                        query_data[name] = np.array(vals)
            
            # 4. Coordination Number Fallback
            if "coordination_number" not in query_data:
                cn = self._compute_lazy_coordination_number()
                query_data["coordination_number"] = cn
            
            # 5. Surface Detection Fallback
            if "is_surface" not in query_data:
                query_data["is_surface"] = self._compute_lazy_is_surface(query_data.get("coordination_number", np.array([])))

            # 6. H2O Autodetect Fallback
            if "residue" not in query_data:
                query_data["residue"] = np.array(self._detect_water_residues())
            
            evaluator = SelectionQueryEvaluator(query_data)
            mask = evaluator.evaluate(self._query_str)
            
            if mask is None:
                raise ValueError("Query returned no result.")
            
            indices = np.where(mask)[0].tolist()
            
            # Apply based on mode
            mode = getattr(self, "_query_mode", 0)
            if mode == 0: # Replace
                self.scene.clear_selection()
                self.scene.selected_atoms = indices
            elif mode == 1: # Add
                self.scene.selected_atoms = list(set(self.scene.selected_atoms) | set(indices))
            elif mode == 2: # Subtract
                self.scene.selected_atoms = list(set(self.scene.selected_atoms) - set(indices))
            elif mode == 3: # Intersect
                self.scene.selected_atoms = list(set(self.scene.selected_atoms) & set(indices))
            
            self._query_status_msg = f"Success: {len(indices)} atoms matched."
            self._query_status_color = (0.4, 1.0, 0.4, 1.0)
            self._mark_dirty(sel=True)
            self._sync_gpu()
            
        except Exception as e:
            self._query_status_msg = f"ERROR: {str(e)}"
            self._query_status_color = (1.0, 0.4, 0.4, 1.0)

    def _detect_water_residues(self):
        """Identifies H2O molecules using connectivity heuristics if missing from metadata."""
        N = self.scene.N
        res = ["UNK"] * N
        if not self.scene.bonds or not self.scene.elements: return res
        
        # Simple adjacency
        adj = [[] for _ in range(N)]
        for i, j in self.scene.bonds:
            if i < N and j < N:
                adj[i].append(j); adj[j].append(i)
            
        els = self.scene.elements
        for i in range(N):
            if i < N and els[i].upper() == 'O':
                h_neighbors = [idx for idx in adj[i] if idx < N and els[idx].upper() == 'H']
                if len(h_neighbors) == 2:
                    res[i] = "H2O"
                    for n in h_neighbors: res[n] = "H2O"
        return res

    def _compute_lazy_coordination_number(self):
        """Calculates coordination number using structural connectivity or distance-based search."""
        N = self.scene.N
        if N == 0: return np.zeros(0, dtype=np.int32)
        
        # 1. Use existing bonds if available (fastest)
        if self.scene.bonds:
            cn = np.zeros(N, dtype=np.int32)
            for i, j in self.scene.bonds:
                if i < N and j < N:
                    cn[i] += 1; cn[j] += 1
            return cn

        # 2. Distance-based fallback (Heuristic)
        # We use a 30% tolerance above the sum of radii as a bond threshold
        try:
            pos = self.scene.pos
            radii = self.scene.radii
            cn = np.zeros(N, dtype=np.int32)
            
            # Use KDTree if available for O(N log N) performance
            try:
                from scipy.spatial import KDTree
                tree = KDTree(pos)
                # Max reasonable bond length for search is ~3.5 A
                pairs = tree.query_pairs(r=3.5)
                for i, j in pairs:
                    dist = np.linalg.norm(pos[i] - pos[j])
                    if dist <= (radii[i] + radii[j]) * 1.3:
                        cn[i] += 1; cn[j] += 1
            except ImportError:
                # O(N^2) purely vectorized fallback for smaller systems
                for i in range(N):
                    dists = np.linalg.norm(pos[i] - pos, axis=1)
                    # Exclude self (dists > 0) and check against combined radii
                    mask = (dists > 0.1) & (dists <= (radii[i] + radii) * 1.3)
                    cn[i] = np.sum(mask)
            return cn
        except Exception:
            return np.zeros(N, dtype=np.int32)

    def _compute_lazy_is_surface(self, cn_array):
        """Heuristic surface detection: atoms with < 80% average coordination."""
        if len(cn_array) == 0: return np.zeros(0, dtype=bool)
        avg = np.mean(cn_array)
        if avg < 1.0: return np.zeros(len(cn_array), dtype=bool) # Too sparse
        return cn_array < (avg * 0.8)

    def _draw_selection_sets_content(self):
        """Internal logic for selection management (headless)."""
        if not hasattr(self, "_new_set_name"): self._new_set_name = ""
        
        imgui.push_item_width(200)
        _, self._new_set_name = imgui.input_text("Tag Name", self._new_set_name, 64)
        imgui.pop_item_width()
        imgui.same_line()
        if imgui.button("Commit Selection"):
            name = self._new_set_name
            if not name.strip():
                name = self._get_hill_formula(self.scene.selected_atoms)
            self.selection_sets.save_set(name, self.scene.selected_atoms)
            self._new_set_name = ""
        
        imgui.same_line()
        imgui.spacing()
        imgui.same_line()
        _, self._lasso_active = imgui.checkbox("Enable Lasso Mode (Shift+Drag)", self._lasso_active)
        if imgui.is_item_hovered():
            imgui.set_tooltip("Draw free-hand shapes to select atoms. Replaces square box selection.")
        
        imgui.separator()
        imgui.text("Repository:")
        imgui.columns(6, "sel_cols", False)
        to_del = None
        for name in self.selection_sets.list_sets():
            if imgui.button(f"{name}"):
                s = self.selection_sets.load_set(name)
                if s: 
                    self.scene.selected_atoms = list(s)
                    self._mark_dirty(sel=True); self._sync_gpu()
            if imgui.is_item_hovered():
                imgui.set_tooltip(f"Load selection set '{name}'")
            
            imgui.same_line()
            if imgui.button(f"X##{name}"):
                to_del = name
            imgui.next_column()
        imgui.columns(1)
                
        if to_del: self.selection_sets.delete_set(to_del)

    def _draw_selection_sets_panel(self):
        """Legacy wrapper (Unused in new UI)."""
        pass

    def _draw_measurements(self):
        """UI for pick-based geometric measurements (MIC-aware)."""
        if not self.measured_indices: return
        
        from .analysis.measurement_tools import MeasurementTools
        mt = MeasurementTools(self.scene.lat if self.scene.is_periodic else None)
        
        imgui.set_next_window_size(250, 150, imgui.FIRST_USE_EVER)
        changed_open, self._draw_measurements_open = imgui.begin("Geometric Measurements", self._draw_measurements_open)
        if not self._draw_measurements_open:
            self.measured_indices = []
            imgui.end()
            return

        count = len(self.measured_indices)
        imgui.text_colored(f"Picked: {count} atoms (Alt+Click to pick)", 0.4, 0.8, 1.0)
        imgui.separator()
        
        if count == 2:
            i, j = self.measured_indices
            d = mt.distance(self.scene.pos[i], self.scene.pos[j])
            imgui.text(f"Distance ({i}-{j}):")
            imgui.text_colored(f"  {d:.4f} A", 1.0, 0.8, 0.4)
        elif count == 3:
            i, j, k = self.measured_indices
            a = mt.angle(self.scene.pos[i], self.scene.pos[j], self.scene.pos[k])
            imgui.text(f"Angle ({i}-{j}-{k}):")
            imgui.text_colored(f"  {a:.2f} deg", 1.0, 0.8, 0.4)
        elif count == 4:
            i, j, k, l = self.measured_indices
            d = mt.dihedral(self.scene.pos[i], self.scene.pos[j], self.scene.pos[k], self.scene.pos[l])
            imgui.text(f"Dihedral ({i}-{j}-{k}-{l}):")
            imgui.text_colored(f"  {d:.2f} deg", 1.0, 0.8, 0.4)
        else:
            imgui.text_disabled("Select 2, 3, or 4 atoms to measure.")
            
        if imgui.button("Reset Pick List"):
            self.measured_indices = []
            
        imgui.end()

    def _export_png(self, filename: str):
        """Captures the current viewport and saves as PNG using PIL."""
        try:
            import PIL.Image as Image
            w, h = glfw.get_framebuffer_size(self.win)
            glPixelStorei(GL_PACK_ALIGNMENT, 1)
            data = glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE)
            img = Image.frombytes("RGB", (w, h), data)
            img = img.transpose(Image.FLIP_TOP_BOTTOM)
            # Use current compression settings
            img.save(filename, optimize=True, compress_level=self.export_compression)
            self.export_status = f"Saved: {filename}"
            print(f"Frame exported to {filename}")
        except Exception as e:
            self.export_status = f"Export failed: {e}"
            print(f"Error: {e}")

    def _start_professional_export(self):
        """Initializes the offline deterministic render pipeline."""
        if self._exporting_sequence: return
        
        if not hasattr(self, "keyframes") or len(self.keyframes) < 2:
            self.export_status = "Status: Need at least 2 keyframes"
            return
            
        # 1. Setup Camera Path
        self._cam_path = CameraPath(self.keyframes)
        
        # 2. Setup Export Resolution & FBO
        w = int(self.export_width * self.export_supersampling)
        h = int(self.export_height * self.export_supersampling)
        self._init_export_fbo(w, h)
        
        # 3. Setup Async Writer
        num_frames = int(self.export_duration * self.export_fps)
        metadata = {
            "fps": self.export_fps,
            "duration": self.export_duration,
            "resolution": [self.export_width, self.export_height],
            "interpolation": self.export_interpolation,
            "compression": self.export_compression,
            "save_gif": self.export_save_gif,
            "gif_downscale": self.export_gif_downscale,
            "gif_loop": self.export_gif_loop,
            "total_frames_target": num_frames
        }
        self._async_writer = AsyncSequenceWriter("export", metadata)
        
        # 4. State for loop
        self._exporting_sequence = True
        self._export_frame_num = 0
        self._export_total_frames = num_frames
        self.export_status = "Status: Export Starting..."
        
        # Disable interactions
        self.playback_playing = False

    def _drive_professional_export(self):
        """Drives one deterministic frame of the export sequence with temporal multisampling."""
        if not self._exporting_sequence: return
        
        k = self._export_frame_num
        N = self._export_total_frames
        if k >= N:
            self._finalize_export()
            return
            
        M = max(1, self.export_motion_blur)
        w = int(self.export_width * self.export_supersampling)
        h = int(self.export_height * self.export_supersampling)
        
        # Accumulator for motion blur
        acc = np.zeros((h, w, 3), dtype=np.float32)
        shutter = 0.5 # 180 degree shutter
        
        for m in range(M):
            # Calculate sub-frame time in u
            u_raw = 0.0 if N <= 1 else k / (N - 1)
            u_next_raw = 0.0 if N <= 1 else (k + 1) / (N - 1)
            
            # Apply Easing globally
            u_base = OrbitCamera.apply_easing(u_raw, self.export_interpolation)
            u_next = OrbitCamera.apply_easing(u_next_raw, self.export_interpolation)
            
            # Sub-sample progress within the shutter window
            u_m = u_base
            if M > 1 and k < N - 1:
                u_m += (u_next - u_base) * (m / M) * shutter
            
            # 1. Sample and Synchronize Structure
            state = self._cam_path.sample(u_m)
            
            # Apply Handheld Cinematic Shake (Deterministic)
            t_anim = u_m * self.export_duration
            state = self._apply_cinematic_shake(state, t_anim)
            
            # Trajectory Sync: Load new frame if structure index changes or if random mode is on
            if getattr(self, "export_random_structures", False):
                import random
                target_idx = random.randint(0, len(self.provider) - 1)
            else:
                target_idx = int(round(state.get('structure_index', self.index1)))

            if target_idx != self.index1:
                self._load_frame1(target_idx)
            
            # Render to FBO
            self._render_scene_to_fbo(state, w, h)
            
            # 2. Read back and accumulate
            glBindFramebuffer(GL_FRAMEBUFFER, self.export_fbo)
            glPixelStorei(GL_PACK_ALIGNMENT, 1)
            data = glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE)
            img_arr = np.frombuffer(data, dtype=np.uint8).reshape(h, w, 3).astype(np.float32)
            acc += img_arr
            
        # 3. Average and convert back to bytes
        acc /= M
        final_data = acc.astype(np.uint8).tobytes()
        
        # 4. Submission to background thread
        options = {'compress_level': self.export_compression, 'optimize': True}
        self._async_writer.submit_frame(k, final_data, (w, h), options)
        
        # 5. Progress updates
        self._export_frame_num += 1
        prog = int(100 * self._export_frame_num / N)
        self.export_status = f"Status: Rendering {prog}% ({self._export_frame_num}/{N})"
        
        if k % 10 == 0:
             print(f"[Export] Rendered frame {k}/{N} ({M} samples)")

    def _render_scene_to_fbo(self, state, w, h):
        """Dedicated render pass for an offscreen FBO with forced settings."""
        # Temporarily apply camera state
        old_state = self.cam1.serialize()
        old_pretty = self.pretty_render
        
        self.cam1.apply_state(state)
        self.pretty_render = True # Force high-quality for export
        
        # Background control
        bg = [0,0,0]
        if self.export_background_mode == "White": bg = [1,1,1]
        elif self.export_background_mode == "Solid": bg = self.bg_color
        
        glBindFramebuffer(GL_FRAMEBUFFER, self.export_fbo)
        glViewport(0, 0, w, h)
        glClearColor(*bg, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        # Perform main render pass with target FBO
        self._render_pass(self.scene, self.cam1, 0, 0, w, h, target_fbo=self.export_fbo)
        
        # Restore state
        self.pretty_render = old_pretty
        self.cam1.apply_state(old_state)

    def _finalize_export(self):
        """Cleanup after a successful export sequence."""
        self._exporting_sequence = False
        self.export_status = "Status: Export Complete"
        print("[Export] Sequence complete.")
        # Trigger any post-processing or notification
        if self.export_save_gif:
             self.export_status = "Status: Export Complete (Processing GIF...)"
        self._cleanup_export_fbo()
        self._async_writer.finish()

    def _get_handheld_signal(self, t: float, seed_offset: int):
        """Generates a deterministic sum-of-sines signal for a given time and seed."""
        # Use a secondary RNG based on seed to get frequencies/phases
        rng = np.random.default_rng(self.export_shake_seed + seed_offset)
        n = 4 # Number of harmonics
        freqs = rng.uniform(0.2, 1.8, size=n) * self.export_shake_frequency
        phases = rng.uniform(0.0, 2.0*np.pi, size=n)
        weights = np.geomspace(1.0, 0.35, num=n)
        weights /= weights.sum()
        
        signal = 0.0
        for i in range(n):
            signal += weights[i] * np.sin(2.0 * np.pi * freqs[i] * t + phases[i])
        return signal

    def _apply_cinematic_shake(self, state: Dict[str, Any], t: float):
        """Perturbs camera state in camera-local coordinates for handheld effect."""
        if not self.export_handheld_enabled: return state
        
        # 1. Establish Camera-Local Basis from clean state
        eye = state['center'] + state['offset']
        target = state['center']
        up = state.get('up', np.array([0,0,1], dtype=np.float32))
        dist = np.linalg.norm(state['offset'])
        
        f = -state['offset'] / (dist + 1e-12)
        r = np.cross(f, up)
        r_norm = np.linalg.norm(r)
        if r_norm < 1e-6: # Edge case: target directly above/below
            r = np.array([1, 0, 0], dtype=np.float32)
        else:
            r /= r_norm
        u_axis = np.cross(r, f)
        
        # 2. Translation Jitter
        # Proportional to distance to keep perceived jitter consistent, clamped to a safe floor
        shake_t = self.export_shake_intensity * self.export_shake_translation * max(dist, 10.0) * 0.05
        tx = self._get_handheld_signal(t, 11) * shake_t 
        ty = self._get_handheld_signal(t, 23) * shake_t
        tz = self._get_handheld_signal(t, 37) * shake_t # Dolly sway
        
        # Apply to center (simulates bodily sway)
        state['center'] = state['center'] + r * tx + u_axis * ty + f * tz
        
        # 3. Rotation Jitter (Yaw, Pitch, Roll)
        shake_r = self.export_shake_intensity * self.export_shake_rotation * 0.03
        yaw = self._get_handheld_signal(t, 43) * shake_r
        pitch = self._get_handheld_signal(t, 57) * shake_r
        
        # Apply orientation perturbations
        from scipy.spatial.transform import Rotation
        rot_yaw = Rotation.from_rotvec(u_axis * yaw)
        rot_pitch = Rotation.from_rotvec(r * pitch)
        
        # Correctly rotate the offset and up vectors
        state['offset'] = rot_pitch.apply(rot_yaw.apply(state['offset']))
        new_up = rot_pitch.apply(rot_yaw.apply(u_axis))
        
        # Optional Roll
        if self.export_allow_roll and not self.export_horizon_lock:
            roll = self._get_handheld_signal(t, 71) * shake_r * 0.4
            rot_roll = Rotation.from_rotvec(f * roll)
            new_up = rot_roll.apply(new_up)
            
        state['up'] = new_up
        return state

    def _finish_gif_export(self):
        """Compiles captured frames into a GIF."""
        if not self._export_frames_list: return
        
        try:
            self.export_status = "Status: Finalizing GIF..."
            ms_per_frame = int(1000.0 / self.export_fps)
            self._export_frames_list[0].save(
                "export/sequence.gif",
                save_all=True,
                append_images=self._export_frames_list[1:],
                duration=ms_per_frame,
                loop=0
            )
            self.export_status = "Status: Export Complete (GIF saved)"
            print(f"Sequence exported to export/sequence.gif ({self._export_frame_num} frames)")
        except Exception as e:
            self.export_status = f"Status: GIF failed: {e}"
            print(f"GIF Error: {e}")
        finally:
            self._export_frames_list = [] # Clear memory

    def _update_playback_keyframes(self):
        """Drives camera sequence playback if active."""
        if not hasattr(self, "_playing_keyframes") or not self._playing_keyframes: return
        
        if not self.cam.is_animating:
            self._kf_index += 1
            if self._kf_index < len(self.keyframes):
                self.cam.fly_to(self.keyframes[self._kf_index])
            else:
                self._playing_keyframes = False
                print("Sequence playback complete.")

    # --- Professional Export Subsystem (Phase 2) ---
    def _init_export_fbo(self, w: int, h: int):
        """Creates a dedicated offscreen Framebuffer for sequence export."""
        self._cleanup_export_fbo()
        
        self.export_fbo = glGenFramebuffers(1)
        glBindFramebuffer(GL_FRAMEBUFFER, self.export_fbo)
        
        # Color Texture
        self.export_tex = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, self.export_tex)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, None)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, self.export_tex, 0)
        
        # Depth Buffer
        self.export_depth = glGenRenderbuffers(1)
        glBindRenderbuffer(GL_RENDERBUFFER, self.export_depth)
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, w, h)
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, self.export_depth)
        
        if glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE:
            print("[Visualizer] Fatal Error: Export FBO is incomplete.")
            
        glBindFramebuffer(GL_FRAMEBUFFER, 0)

    def _cleanup_export_fbo(self):
        """Releases GPU resources for the export FBO."""
        if self.export_fbo:
            glDeleteFramebuffers(1, [self.export_fbo])
            glDeleteTextures(1, [self.export_tex])
            glDeleteRenderbuffers(1, [self.export_depth])
            self.export_fbo = self.export_tex = self.export_depth = 0

    def _get_hill_formula(self, indices):
        """Generates a Hill-system chemical formula string for a set of atom indices."""
        if not indices: return "selection"
        counts = {}
        for idx in indices:
            el = self.scene.elements[idx]
            counts[el] = counts.get(el, 0) + 1
        
        # Hill system: C first, then H, then alphabetical
        sorted_els = sorted(counts.keys())
        res = []
        if 'C' in counts:
            res.append(f"C{counts['C'] if counts['C']>1 else ''}")
            sorted_els.remove('C')
            if 'H' in counts:
                res.append(f"H{counts['H'] if counts['H']>1 else ''}")
                sorted_els.remove('H')
        for el in sorted_els:
            res.append(f"{el}{counts[el] if counts[el]>1 else ''}")
        return "_".join(res)

    def _generate_auto_orbit(self, axis_mode: int):
        """Generates 12 keyframes that perform a 360 orbit around the target."""
        if not hasattr(self, "keyframes"): self.keyframes = []
        
        # 1. Define Axis
        if axis_mode == 0:   axis = np.array([1, 0, 0], dtype=np.float32)
        elif axis_mode == 1: axis = np.array([0, 1, 0], dtype=np.float32)
        elif axis_mode == 2: axis = np.array([0, 0, 1], dtype=np.float32)
        else:
            # Lattice vectors
            lat = self.scene.lat
            if lat is None or np.all(lat == 0):
                axis = np.array([0, 0, 1], dtype=np.float32)
            else:
                axis = self.scene.lat[axis_mode - 3]
                norm = np.linalg.norm(axis)
                if norm > 0: axis = axis / norm
                else: axis = np.array([0, 0, 1], dtype=np.float32)
        
        # 2. Keyframes
        base_state = self.cam1.serialize()
        center = base_state['center']
        offset = base_state['offset']
        
        from .camera import rodrigues
        num_steps = 12
        for i in range(num_steps):
            angle = (2.0 * np.pi * i) / num_steps
            new_offset = rodrigues(offset, axis, angle)
            kf = base_state.copy()
            kf['offset'] = new_offset
            self.keyframes.append(kf)
            
        self.export_status = f"Added {num_steps} orbit keyframes"

    # --- Structural Workshop Helpers ---

    def _update_structural_ghost(self):
        """Updates the session ghost preview based on camera, hover, and selection."""
        S = self.struct_session
        if S.active_tool == "Add Group" and S.selected_fragment_name:
            # Re-calculate preview
            res = self.struct_editor.get_fragment_preview(
                S.selected_fragment_category, 
                S.selected_fragment_name, 
                list(self.scene.selected_atoms), 
                S.active_mode,
                S.manual_distance if S.use_manual_distance else None,
                S.roll_angle
            )
            if res.get("valid"):
                S.ghost_pos = res["pos"]
                S.ghost_elements = res["elements"]
                frag_data = self.struct_editor.fragments.get_fragment(S.selected_fragment_category, S.selected_fragment_name)
                if frag_data:
                    S.ghost_anchor_idx = frag_data.get("anchor_idx", 0)
                else:
                    S.ghost_anchor_idx = 0
            else:
                S.ghost_pos = None
        elif S.active_tool == "Add Atom":
            # Simple atom placement
            if self.scene.selected_atoms:
                i = self.scene.selected_atoms[0]
                # Map persistent ID back to index
                indices = self.struct_editor.id_mgr.get_indices([i])
                if len(indices) > 0:
                    idx = indices[0]
                    species = getattr(S, "selected_atom_species", "C")
                    pos, _ = self.struct_editor.placement.get_molecular_placement(idx, species)
                    S.ghost_pos = np.array([pos], dtype=np.float32)
                    S.ghost_elements = [species]
                else:
                    S.ghost_pos = None
            else:
                S.ghost_pos = None

    def _draw_structural_ghosts(self):
        """Renders semi-transparent 'ghost' atoms for structural previews."""
        S = self.struct_session
        if S.ghost_pos is not None:
            from .constants import CPK_COLORS, ATOMIC_RADII, DEFAULT_RADIUS, DEFAULT_COLOR
            colors = []
            radii = []
            
            # 1. Color Logic based on Clash status
            if S.ghost_clash:
                # Warning Red for all ghost atoms
                ghost_color = [1.0, 0.2, 0.2, 1.0]
            else:
                ghost_color = None # Use CPK
                
            for idx, e in enumerate(S.ghost_elements):
                is_anchor = (idx == getattr(S, "ghost_anchor_idx", 0))
                
                if S.ghost_clash:
                    colors.append([1.0, 0.2, 0.2, 1.0])
                elif is_anchor:
                    colors.append([1.0, 0.8, 0.1, 1.0]) # Glowing gold
                else:
                    c = CPK_COLORS.get(e, DEFAULT_COLOR)
                    colors.append([c[0], c[1], c[2], 1.0])
                
                rad = ATOMIC_RADII.get(e, DEFAULT_RADIUS)
                if is_anchor:
                    radii.append(rad * 1.25) # 25% larger to stand out physically
                else:
                    radii.append(rad)
            
            c_arr = np.array(colors, dtype=np.float32)
            r_arr = np.array(radii, dtype=np.float32)
            
            self.rnd_ghost.upload_data(S.ghost_pos, r_arr * self.atom_scale, c_arr)
            v_pairs = np.column_stack([np.arange(len(S.ghost_pos)), np.zeros(len(S.ghost_pos))]).astype(np.uint32)
            
            ghost_m = dict(self.materials) if hasattr(self, 'materials') else {}
            ghost_m['is_ghost'] = True
            ghost_m['force_blend'] = True
            
            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
            self.rnd_ghost.draw(self.cam1.get_view_matrix(), self.cam1.get_projection_matrix(self.win_size[0]/self.win_size[1], self.is_ortho),
                                v_pairs, self.cam1.ortho_scale, self.win_size[1], 
                                lights=self.lights, materials=ghost_m, 
                                atom_scale=self.atom_scale, fov=self.cam1.fov, is_ortho=self.is_ortho,
                                shading_tier=1, pretty_render=False)
            glDisable(GL_BLEND)

    def _commit_ghost(self):
        """Permanently adds the current session ghost to the scene."""
        S = self.struct_session
        if S.ghost_pos is not None:
            from .builder.edit_commands import AddAtomsCommand
            new_ids = self.struct_editor.id_mgr.generate_new_ids(len(S.ghost_pos))
            cmd = AddAtomsCommand(new_ids, S.ghost_pos.copy(), S.ghost_elements.copy())
            
            # Prepare relaxation settings
            relax_settings = {
                "mode": S.relaxation_mode,
                "steps": S.relaxation_steps,
                "relax_substrate": S.relax_substrate
            }
            
            if self.struct_editor.commit_command(cmd, auto_relax=S.auto_relax, relax_settings=relax_settings):
                S.reset_ghost()
                self._mark_dirty(pos=True)
                self._sync_gpu()

    def _toggle_gallery_mode(self, enabled: Optional[bool] = None):
        """Centralized toggle for Gallery/Virtual Lab mode with proper setup/cleanup."""
        if enabled is None:
            enabled = not self.gallery.enabled
        
        if enabled == self.gallery.enabled:
            return

        self.gallery.enabled = enabled
        if self.gallery.enabled:
            # Ensure playback is stopped when entering gallery
            self.playback_playing = False
            
            # Initialize FPS Camera only if it hasn't been used yet or if we want a hard reset
            if not hasattr(self, "_gallery_cam_initialized"):
                self.cam_fps.position = np.array([0, -15, 5], dtype=np.float32)
                self.cam_fps.yaw = 0
                self.cam_fps.pitch = 0
                self._gallery_cam_initialized = True
            
            self.cam_fps.speed = self.gallery.walk_speed
            
            # CRITICAL: Prepare gallery state
            self._update_gallery_layout()
            self._analyze_gallery_data()
            self._preload_gallery_cache(max_items=30)
            
            # OPTIMIZATION: Disable expensive features for smooth exploration
            self._old_pretty = getattr(self, "pretty_render", False)
            self._old_bonds = getattr(self, "show_bonds", False)
            self.pretty_render = False
            self.show_bonds = False
            
            # Capture mouse
            self._gallery_mouse_captured = True
            glfw.set_input_mode(self.win, glfw.CURSOR, glfw.CURSOR_DISABLED)
            self._last_poll_mouse = glfw.get_cursor_pos(self.win)
            self._last_fps_time = glfw.get_time()
        else:
            # Restore previous settings
            if hasattr(self, "_old_pretty"): self.pretty_render = self._old_pretty
            if hasattr(self, "_old_bonds"): self.show_bonds = self._old_bonds
            
            self._release_gallery_mouse()
            # Ensure we return to a sane camera mode and restore rendering quality
            self.cam1.mode = "ORBIT"
            glfw.set_input_mode(self.win, glfw.CURSOR, glfw.CURSOR_NORMAL)
            
            # CRITICAL: Force a full sync to restore rendering quality and prevent "looking bad"
            self._sync_gpu()
            self._mark_dirty(pos=True, mat=True)

    def _draw_camera_control_window(self):
        """Displays the categorized Professional Camera Control dashboard."""
        if not getattr(self, "_show_camera_panel", False): return
        
        imgui.set_next_window_size(320, 700, imgui.FIRST_USE_EVER)
        imgui.begin("Professional Camera Control", True)
        
        if imgui.get_content_region_available_width() < 10: 
            imgui.end()
            return
            
        # --- Section 0: Main Mode Switch ---
        modes = ["ORBIT", "TURNTABLE", "FLY", "AXIS", "GALLERY"]
        if self.gallery.enabled:
            curr_idx = modes.index("GALLERY")
        else:
            try: curr_idx = modes.index(self.cam1.mode)
            except: curr_idx = 0
            
        changed, new_idx = imgui.combo("Global Mode", curr_idx, modes)
        if changed:
            if modes[new_idx] == "GALLERY":
                self._toggle_gallery_mode(True)
            else:
                self._toggle_gallery_mode(False)
                self.cam1.mode = modes[new_idx]
                if modes[new_idx] == "AXIS":
                    com = self.scene.get_com()
                    self.cam1.center = np.copy(com)
                    if self.split_view:
                        self.cam2.center = np.copy(com)

        imgui.separator()
        
        if self.gallery.enabled:
            self._draw_gallery_settings_panel()
            imgui.end()
            return

        # --- Section 1: Camera Preview & Orientation ---
        imgui.text_disabled("Interactive Orientation & Status:")
        self._draw_camera_minimap_widget()
        
        # Numerical Status Line (Compact)
        dist = np.linalg.norm(self.cam1.offset)
        status_text = f"Mode: {self.cam1.mode} | Dist: {dist:.1f} \u00c5 | FOV: {self.cam1.fov:.0f}\u00b0"
        imgui.text_disabled(status_text)
        
        imgui.spacing()
        # Scientific Axis Buttons
        imgui.text_disabled("Align to Axis:")
        axes_presets = [("+X", "Right"), ("-X", "Left"), ("+Y", "Back"), ("-Y", "Front"), ("+Z", "Top"), ("-Z", "Bottom")]
        for i, (label, preset) in enumerate(axes_presets):
            if imgui.button(f"{label}"):
                self._set_camera_preset(preset)
            if i < len(axes_presets)-1: imgui.same_line()
        
        if imgui.button(" Iso "): self._set_camera_preset("Iso")
        imgui.same_line()
        if imgui.button(" Frame All "): self.zoom_to_fit(smooth=True)
        imgui.same_line()
        if imgui.button(" Frame Sel "): 
             if self.scene.selected_atoms:
                sel_pos = self.scene.pos[self.scene.selected_atoms]
                self.cam1.set_fly_to(center=np.mean(sel_pos, axis=0), offset=self.cam1.offset, duration=0.8)
        imgui.same_line()
        if imgui.button(" Reset "): self.reset_view()
        
        imgui.separator()

        # --- Section 2: Navigation ---
        if imgui.collapsing_header("Navigation", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
            modes = ["ORBIT", "TURNTABLE", "FLY", "AXIS"]
            try: m_idx = modes.index(self.cam1.mode)
            except: m_idx = 0
            changed, m_idx = imgui.combo("Control Mode", m_idx, modes)
            if changed: 
                self.cam1.mode = modes[m_idx]
                if modes[m_idx] == "TURNTABLE":
                    self.cam1.clamped_pitch = True
                    self.cam1._target_up = np.array([0, 0, 1], dtype=np.float32)
                elif modes[m_idx] == "AXIS":
                    com = self.scene.get_com()
                    self.cam1.center = np.copy(com)
                    if self.split_view:
                        self.cam2.center = np.copy(com)
            
            imgui.text_disabled("Behavior:")
            _, self.cam1.invert_y = imgui.checkbox("Invert Mouse Y", self.cam1.invert_y)
            imgui.same_line()
            _, self.cam1.clamped_pitch = imgui.checkbox("Clamp Pitch", self.cam1.clamped_pitch)
            _, self.cam1.momentum = imgui.checkbox("Enable Momentum", self.cam1.momentum)

            imgui.separator()
            imgui.text_disabled("Left-Click Drag Tool:")
            tools = ["ORBIT", "PAN", "ROLL", "LIGHT", "SELECT"]
            for i, tool in enumerate(tools):
                is_selected = (getattr(self, "active_tool", "ORBIT") == tool)
                if is_selected:
                    imgui.push_style_color(imgui.COLOR_BUTTON, 0.15, 0.45, 0.7, 1.0)
                    imgui.push_style_color(imgui.COLOR_BUTTON_HOVERED, 0.2, 0.55, 0.8, 1.0)
                    imgui.push_style_color(imgui.COLOR_BUTTON_ACTIVE, 0.1, 0.35, 0.6, 1.0)
                
                if imgui.button(f" {tool} "):
                    self.active_tool = tool
                
                if is_selected:
                    imgui.pop_style_color(3)
                
                if i < len(tools) - 1:
                    imgui.same_line()
            
            imgui.separator()
            _, self.auto_spin = imgui.checkbox("Auto-Spin Rotation", self.auto_spin)
            if self.auto_spin:
                imgui.same_line()
                _, self.auto_spin_speed = imgui.slider_float("Spin Speed", self.auto_spin_speed, -3.0, 3.0, "%.2f")

        # --- Section 3: Motion & Presets ---
        if imgui.collapsing_header("Motion & Dynamics", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
            imgui.text_disabled("Presets:")
            if imgui.button(" Precise "): self._apply_motion_preset("precise")
            imgui.same_line()
            if imgui.button(" Normal "): self._apply_motion_preset("normal")
            imgui.same_line()
            if imgui.button(" Fast "): self._apply_motion_preset("fast")
            imgui.same_line()
            if imgui.button(" Presentation "): self._apply_motion_preset("presentation")
            
            _, self.cam1.sensitivity = imgui.slider_float("Sensitivity", self.cam1.sensitivity, 0.001, 0.05, "%.4f")
            _, self.cam1.damping = imgui.slider_float("Damping", self.cam1.damping, 0.7, 0.99)
            _, self.cam1.fly_speed = imgui.slider_float("Flight Speed", self.cam1.fly_speed, 1.0, 200.0)
            
            if not hasattr(self, "_scroll_speed"): self._scroll_speed = 1.0
            _, self._scroll_speed = imgui.slider_float("Scroll Zoom Speed", self._scroll_speed, 0.1, 5.0)

        # --- View Memory 2.0 (Vertical with Thumbnails) ---
        if imgui.collapsing_header("View Memory (Manager)", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
            if not hasattr(self, "_saved_views"): self._saved_views = []
            
            imgui.push_item_width(200)
            if not hasattr(self, "_new_view_name"): self._new_view_name = "New View"
            _, self._new_view_name = imgui.input_text("##vname", self._new_view_name, 64)
            imgui.pop_item_width()
            imgui.same_line()
            if imgui.button(" Save Current View "):
                self._save_view_with_thumbnail(self._new_view_name)
            
            imgui.separator()
            
            # List of saved views
            to_delete = -1
            for i, v in enumerate(self._saved_views):
                imgui.push_id(str(i))
                
                # Thumbnail + Name
                if v.get("thumb_id"):
                    imgui.image(v["thumb_id"], 60, 45, (0, 1), (1, 0))
                    imgui.same_line()
                
                imgui.begin_group()
                _, v["name"] = imgui.input_text("##name", v["name"], 64)
                imgui.text_disabled(f"{v['metadata']}")
                
                if imgui.button(" Apply "):
                    self.cam1.fly_to(v["state"], duration=1.0)
                    self.is_ortho = v.get("is_ortho", False)
                imgui.same_line()
                if imgui.button(" Update "):
                    v["state"] = self.cam1.serialize()
                    v["is_ortho"] = self.is_ortho
                    self._refresh_thumbnail(i)
                imgui.same_line()
                if imgui.button(" Del "):
                    to_delete = i
                imgui.end_group()
                
                imgui.separator()
                imgui.pop_id()
                
            if to_delete != -1:
                v = self._saved_views.pop(to_delete)
                if v.get("thumb_id"):
                    glDeleteTextures([v["thumb_id"]])
                    
            imgui.new_line()

        # --- Section 4: View Target ---
        if imgui.collapsing_header("View Target", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
            if imgui.button(" Frame All "): self.zoom_to_fit(smooth=True)
            imgui.same_line()
            if imgui.button(" Focus Selection "):
                if self.scene.selected_atoms:
                    sel_pos = self.scene.pos[self.scene.selected_atoms]
                    self.cam1.set_fly_to(center=np.mean(sel_pos, axis=0), offset=self.cam1.offset, duration=0.8)

            _, self.show_origin_axes = imgui.checkbox("Show Origin Axes", self.show_origin_axes)
            _, self.show_com = imgui.checkbox("Show Center of Mass", self.show_com)

        # --- Section 5: Clipping & Projection ---
        if imgui.collapsing_header("Clipping & Projection", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
            _, self.is_ortho = imgui.checkbox("Orthographic Projection", self.is_ortho)
            
            if not self.is_ortho:
                _, self.cam1.fov = imgui.slider_float("Field of View", self.cam1.fov, 10.0, 120.0, "%.1f deg")
                imgui.same_line()
                if imgui.button(" Reset FOV "): self.cam1.fov = 45.0
            else:
                _, self.cam1.ortho_scale = imgui.slider_float("Ortho Scale", self.cam1.ortho_scale, 1.0, 500.0)

            imgui.spacing()
            imgui.text_disabled("Clipping Planes:")
            near_val = self.cam1.near if self._manual_near_clip < 0 else self._manual_near_clip
            changed, new_near = imgui.slider_float("Near Clip", near_val, 0.0001, 1.0, "%.4f")
            if changed: self._manual_near_clip = new_near
            imgui.same_line()
            if imgui.button("Auto-Clip"): self._manual_near_clip = -1.0
            
            imgui.separator()
        if imgui.button(" Close Panel "):
            self._show_camera_panel = False
            
        imgui.end()

    def _draw_camera_minimap_widget(self):
        """Renders an interactive 2D-projected 3D minimap showing cell and camera frustum."""
        draw_list = imgui.get_window_draw_list()
        pos = imgui.get_cursor_screen_pos()
        w, h = 200, 160
        imgui.invisible_button("minimap_hitbox", w, h)
        
        # Interaction logic
        if imgui.is_item_active() and imgui.is_mouse_dragging(0):
            dx, dy = imgui.get_mouse_drag_delta(0)
            imgui.reset_mouse_drag_delta(0)
            self.cam1.rotate_yaw(-dx * 0.01)
            self.cam1.rotate_pitch(-dy * 0.01)
            
        center_x, center_y = pos[0] + w/2, pos[1] + h/2
        
        # Draw background
        draw_list.add_rect_filled(pos[0], pos[1], pos[0]+w, pos[1]+h, imgui.get_color_u32_rgba(0.1, 0.1, 0.1, 0.5), 5.0)
        draw_list.add_rect(pos[0], pos[1], pos[0]+w, pos[1]+h, imgui.get_color_u32_rgba(0.3, 0.3, 0.3, 0.8), 5.0)
        
        # Minimap Projection (Fixed Isometric)
        iso_view = np.array([
            [0.707, -0.408, 0],
            [0,      0.816, 0],
            [-0.707, -0.408, 0]
        ]) * 0.6 # Scale
        
        def project(p3d):
            p2d = p3d @ iso_view
            return center_x + p2d[0], center_y - p2d[1]

        # 0. Draw Labels & Legend
        draw_list.add_text(pos[0]+5, pos[1]+5, imgui.get_color_u32_rgba(0.7,0.7,0.7,1), "Target: Origin")

        # 1. Draw Unit Cell (if available)
        if self.scene and self.scene.lat is not None:
            lat = self.scene.lat * 4.0 # Visual scale
            box_pts = [
                [0,0,0], lat[0], lat[1], lat[2],
                lat[0]+lat[1], lat[0]+lat[2], lat[1]+lat[2],
                lat[0]+lat[1]+lat[2]
            ]
            # Simple edges for a parallelepiped
            edges = [(0,1), (0,2), (0,3), (1,4), (1,5), (2,4), (2,6), (3,5), (3,6), (7,4), (7,5), (7,6)]
            col_cell = imgui.get_color_u32_rgba(0.6, 0.6, 0.6, 0.4)
            for e in edges:
                p1, p2 = project(box_pts[e[0]]), project(box_pts[e[1]])
                draw_list.add_line(p1[0], p1[1], p2[0], p2[1], col_cell, 1.0)

        # 2. Draw Axes with Labels
        ax_len = 40.0
        origin = project(np.zeros(3))
        axis_colors = [(1,0.2,0.2), (0.2,1,0.2), (0.2,0.4,1)]
        axis_names = ["X", "Y", "Z"]
        for i, col in enumerate(axis_colors):
            v = np.zeros(3)
            v[i] = ax_len
            p = project(v)
            draw_list.add_line(origin[0], origin[1], p[0], p[1], imgui.get_color_u32_rgba(*col, 0.8), 2.5)
            # Label
            draw_list.add_text(p[0]+2, p[1]-2, imgui.get_color_u32_rgba(*col, 1), axis_names[i])

        # 3. Draw Camera & Frustum
        # Current camera orientation relative to scene center
        cam_dir = normalize(self.cam1.offset) * 45.0
        cam_pos = project(cam_dir)
        
        # Frustum "Pyramid" (Interactive and Semi-transparent)
        from .camera import WORLD_UP
        fwd = -normalize(self.cam1.offset)
        r = normalize(np.cross(fwd, WORLD_UP))
        u = normalize(np.cross(r, fwd))
        
        fov_rad = np.radians(self.cam1.fov * 0.5)
        spread = np.tan(fov_rad) * 18.0
        
        # 4 Corners of the frustum face
        c1 = project(cam_dir + (fwd * -12.0 + r * -spread + u * spread * 0.75))
        c2 = project(cam_dir + (fwd * -12.0 + r * spread + u * spread * 0.75))
        c3 = project(cam_dir + (fwd * -12.0 + r * spread + u * -spread * 0.75))
        c4 = project(cam_dir + (fwd * -12.0 + r * -spread + u * -spread * 0.75))
        
        col_frustum = imgui.get_color_u32_rgba(1.0, 0.8, 0.1, 0.25)
        # Draw 4 triangular faces for the frustum pyramid
        draw_list.add_triangle_filled(cam_pos[0], cam_pos[1], c1[0], c1[1], c2[0], c2[1], col_frustum)
        draw_list.add_triangle_filled(cam_pos[0], cam_pos[1], c2[0], c2[1], c3[0], c3[1], col_frustum)
        draw_list.add_triangle_filled(cam_pos[0], cam_pos[1], c3[0], c3[1], c4[0], c4[1], col_frustum)
        draw_list.add_triangle_filled(cam_pos[0], cam_pos[1], c4[0], c4[1], c1[0], c1[1], col_frustum)
        draw_list.add_polyline([c1, c2, c3, c4, c1], imgui.get_color_u32_rgba(1, 0.8, 0.2, 0.6), True, 1.5)
        
        # Camera Icon (More prominent)
        draw_list.add_circle_filled(cam_pos[0], cam_pos[1], 6.0, imgui.get_color_u32_rgba(1, 0.8, 0.2, 1))
        draw_list.add_circle(cam_pos[0], cam_pos[1], 7.0, imgui.get_color_u32_rgba(0,0,0,1), thickness=1.5)
        
        # Target Line & Point
        draw_list.add_line(cam_pos[0], cam_pos[1], origin[0], origin[1], imgui.get_color_u32_rgba(1, 1, 1, 0.6), 1.2)
        draw_list.add_circle_filled(origin[0], origin[1], 4.0, imgui.get_color_u32_rgba(1, 1, 1, 1))
        draw_list.add_circle(origin[0], origin[1], 5.0, imgui.get_color_u32_rgba(0,0,0,1), thickness=1.0)

    def _set_camera_preset(self, view_name: str):
        """Animates the camera to standard viewing axes."""
        dist = np.linalg.norm(self.cam1.offset)
        if dist < 1e-4: dist = 15.0
        
        # Orientations: (Offset, Up)
        presets = {
            "Top":    (np.array([0, 0, dist]),    np.array([0, 1, 0])),
            "Bottom": (np.array([0, 0, -dist]),   np.array([0, 1, 0])),
            "Front":  (np.array([0, -dist, 0]),   np.array([0, 0, 1])),
            "Back":   (np.array([0, dist, 0]),    np.array([0, 0, 1])),
            "Left":   (np.array([-dist, 0, 0]),   np.array([0, 0, 1])),
            "Right":  (np.array([dist, 0, 0]),    np.array([0, 0, 1])),
            "Iso":    (np.array([dist*0.6, -dist*0.6, dist*0.6]), np.array([0, 0, 1])),
        }
        
        if view_name in presets:
            off, up = presets[view_name]
            self.cam1.set_fly_to(center=self.cam1.center, offset=off.astype(np.float32), duration=0.8)
            self.cam1._target_up = up.astype(np.float32)

    def _apply_motion_preset(self, name: str):
        """Sets motion dynamics to predefined usability profiles."""
        profiles = {
            "precise":    {"sens": 0.002, "damp": 0.85,  "speed": 5.0},
            "normal":     {"sens": 0.005, "damp": 0.92,  "speed": 15.0},
            "fast":       {"sens": 0.015, "damp": 0.95,  "speed": 60.0},
            "presentation": {"sens": 0.003, "damp": 0.98, "speed": 10.0},
        }
        if name in profiles:
            p = profiles[name]
            self.cam1.sensitivity = p["sens"]
            self.cam1.damping = p["damp"]
            self.cam1.fly_speed = p["speed"]

    def _save_view_with_thumbnail(self, name: str):
        """Captures the current view, metadata, and a thumbnail for the memory list."""
        state = self.cam1.serialize()
        dist = np.linalg.norm(self.cam1.offset)
        proj = "Ortho" if self.is_ortho else "Persp"
        metadata = f"{proj} | Dist: {dist:.1f} \u00c5"
        
        # Capture thumbnail
        thumb_id = self._capture_gl_thumbnail(120, 90)
        
        self._saved_views.append({
            "name": name,
            "state": state,
            "is_ortho": self.is_ortho,
            "metadata": metadata,
            "thumb_id": thumb_id
        })
        self._new_view_name = f"View {len(self._saved_views) + 1}"

    def _refresh_thumbnail(self, index: int):
        """Refreshes the thumbnail for an existing view slot."""
        if 0 <= index < len(self._saved_views):
            v = self._saved_views[index]
            if v.get("thumb_id"):
                glDeleteTextures([v["thumb_id"]])
            v["thumb_id"] = self._capture_gl_thumbnail(120, 90)

    def _capture_gl_thumbnail(self, width: int, height: int):
        """Captures a small portion of the current framebuffer and uploads it to an OpenGL texture."""
        # Get actual framebuffer size to sample correctly
        fw, fh = glfw.get_framebuffer_size(self.win)
        
        # Read pixels from the center of the screen
        # Note: We read a larger area and scale down or just read a specific area
        # For simplicity, let's read the whole thing and scale with PIL if possible, 
        # or just read a central 400x300 block.
        sample_w, sample_h = min(fw, 800), min(fh, 600)
        x_off = (fw - sample_w) // 2
        y_off = (fh - sample_h) // 2
        
        pixels = glReadPixels(x_off, y_off, sample_w, sample_h, GL_RGB, GL_UNSIGNED_BYTE)
        
        from PIL import Image
        img = Image.frombytes("RGB", (sample_w, sample_h), pixels)
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
        img.thumbnail((width, height), Image.Resampling.LANCZOS)
        
        # Convert PIL back to bytes for OpenGL texture upload
        thumb_data = img.convert("RGBA").tobytes()
        tw, th = img.size
        
        tex_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, tex_id)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tw, th, 0, GL_RGBA, GL_UNSIGNED_BYTE, thumb_data)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glBindTexture(GL_TEXTURE_2D, 0)
        
        return tex_id

    def _draw_gallery_settings_panel(self):
        """Displays settings specific to the Gallery/Explorer mode."""
        imgui.text_disabled("Gallery / Explorer Settings:")
        layouts = ["Grid", "Energy", "Composition"]
        try: l_idx = layouts.index(self.gallery.layout)
        except: l_idx = 0
        changed, l_idx = imgui.combo("Layout", l_idx, layouts)
        if changed:
            self.gallery.layout = layouts[l_idx]
            self._update_gallery_layout()
            
        
        _, self.gallery.show_floor = imgui.checkbox("Show Floor Grid", self.gallery.show_floor)
        _, self.gallery.show_metadata = imgui.checkbox("Show Metadata Cards", self.gallery.show_metadata)
        
        imgui.separator()
        imgui.text_disabled("Movement:")
        changed, self.gallery.walk_speed = imgui.slider_float("Walk Speed", self.gallery.walk_speed, 1.0, 200.0)
        if changed:
            self.cam_fps.speed = self.gallery.walk_speed
            
        changed_v, self.gallery.visible_distance = imgui.slider_float("Visible Radius", self.gallery.visible_distance, 100.0, 5000.0)
        changed_f, self.gallery.full_render_distance = imgui.slider_float("Full Render Radius", self.gallery.full_render_distance, 20.0, 1000.0)
        
        changed_s, self.gallery.spacing = imgui.slider_float("Grid Spacing", self.gallery.spacing, 1.0, 100.0)
        if changed_s:
            self._update_gallery_layout()
            
        imgui.separator()
        imgui.text_disabled("Resource Limits:")
        _, self.gallery.max_full_items = imgui.slider_int("Max Full Items", self.gallery.max_full_items, 1, 4000)
        self.gallery.max_cached_scenes = self.gallery.max_full_items # Synchronize
        _, self.gallery.max_proxy_items = imgui.slider_int("Max Proxy Items", self.gallery.max_proxy_items, 10, 4000)
        
        imgui.text_disabled(f"Full: {getattr(self, '_last_gallery_full_count', 0)} | Proxy: {getattr(self, '_last_gallery_proxy_count', 0)} | Cache: {len(self._gallery_scene_cache)}")
        
        imgui.checkbox("Show Labels", self.gallery.show_labels)
        imgui.text("WASD: Move | Mouse: Look | Q/E: Height")
        imgui.text("Press E near a structure to Inspect (Orbit)")

    def _update_gallery_layout(self):
        """No longer pre-allocates millions of items. Just sets up the grid math."""
        # Safety clamp to avoid division by zero in math
        self._gallery_spacing = max(0.1, self.gallery.spacing)
        
        # N is the total database count
        self._gallery_db_count = len(self.provider)
        
        # Calculate grid dimensions based on total count
        self._gallery_cols = int(np.ceil(np.sqrt(self._gallery_db_count)))
        self._gallery_rows = int(np.ceil(self._gallery_db_count / self._gallery_cols)) if self._gallery_cols > 0 else 0
        
        # Clear lazy-load cache and scene cache to prevent stale data
        self._gallery_active_items = {}
        self._gallery_scene_cache = {}
        self._gallery_cache_last_used = {}
        self._gallery_norm_cache = {} # New stable normalization cache
        self._gallery_batch_dirty = True

    def _query_visible_gallery_items(self, cam_pos):
        """Ultra-fast vectorized grid culling + Frustum check."""
        if self._gallery_db_count == 0: return []
        
        spacing = float(self._gallery_spacing)
        vis_dist = float(self.gallery.visible_distance)
        vis_dist2 = vis_dist * vis_dist
        
        cam_x, cam_y, cam_z = float(cam_pos[0]), float(cam_pos[1]), float(cam_pos[2])
        z0 = 5.0
        
        half_cols = self._gallery_cols * 0.5
        center_col = cam_x / spacing + half_cols
        center_row = cam_y / spacing + half_cols
        r_cells = int(math.ceil(vis_dist / spacing))
        
        c_start, c_end = max(0, int(center_col - r_cells)), min(self._gallery_cols, int(center_col + r_cells + 1))
        r_start, r_end = max(0, int(center_row - r_cells)), min(self._gallery_rows, int(center_row + r_cells + 1))
        
        # 1. Candidate Generation (Grid block)
        cols = np.arange(c_start, c_end)
        rows = np.arange(r_start, r_end)
        C, R = np.meshgrid(cols, rows)
        indices = R * self._gallery_cols + C
        indices = indices.flatten()
        indices = indices[indices < self._gallery_db_count]
        
        if indices.size == 0: return []
        
        # 2. Vectorized Position & Distance
        X = (indices % self._gallery_cols - half_cols) * spacing
        Y = (indices // self._gallery_cols - half_cols) * spacing
        Z = np.full_like(X, z0)
        
        DX = X - cam_x
        DY = Y - cam_y
        DZ = Z - cam_z
        D2 = DX*DX + DY*DY + DZ*DZ
        
        mask = D2 <= vis_dist2
        indices, X, Y, Z, D2 = indices[mask], X[mask], Y[mask], Z[mask], D2[mask]
        
        if indices.size == 0: return []
        
        # 3. Vectorized Frustum Culling (2D Check for speed)
        # We project the center of each structure to NDC space
        view = self.cam_fps.get_view_matrix()
        proj = self.cam_fps.get_projection_matrix(self.win_size[0]/self.win_size[1])
        mvp = proj @ view
        
        # Transform all candidate points
        pts_world = np.vstack([X, Y, Z, np.ones_like(X)]).T # (N, 4)
        pts_clip = pts_world @ mvp.T # Matrix multiply is very fast in NumPy/MKL
        
        # W-clip (keep things in front of camera)
        w_mask = pts_clip[:, 3] > 0.5
        indices, D2, pts_clip, X, Y, Z = indices[w_mask], D2[w_mask], pts_clip[w_mask], X[w_mask], Y[w_mask], Z[w_mask]
        
        if indices.size == 0: return []
        
        # NDC check (is it on screen?)
        ndc_x = pts_clip[:, 0] / pts_clip[:, 3]
        ndc_y = pts_clip[:, 1] / pts_clip[:, 3]
        
        # Margin for safety (1.5 so we don't see them popping in at the edges)
        screen_mask = (np.abs(ndc_x) < 1.5) & (np.abs(ndc_y) < 1.5)
        indices, D2, X, Y = indices[screen_mask], D2[screen_mask], X[screen_mask], Y[screen_mask]
        
        # 4. Final results assembly
        results = []
        active = self._gallery_active_items
        for i, idx in enumerate(indices):
            item = active.get(idx)
            if item is None:
                item = GalleryItem(idx=idx, pos=np.array([X[i], Y[i], z0], dtype=np.float32))
                active[idx] = item
            
            # Sync energy for heatmap
            if item.energy is None and getattr(self, "_gallery_energies", None) is not None:
                if idx < len(self._gallery_energies):
                    item.energy = float(self._gallery_energies[idx])
            
            results.append((float(D2[i]), item))
            
        # Cache pruning
        if len(active) > 3000:
            visible_ids = set(indices)
            for k in list(active.keys()):
                if k not in visible_ids: active.pop(k, None)
                
        # Sort by distance
        results.sort(key=lambda x: x[0])
        return results

    def _render_gallery_scene(self, w, h):
        """Renders the virtual lab using a high-performance batched pipeline."""
        view = self.cam_fps.get_view_matrix()
        proj = self.cam_fps.get_projection_matrix(w / h)

        if self.gallery.show_floor:
            self._draw_gallery_floor(view, proj)

        self._update_gallery_interaction()

        cam_pos = self.cam_fps.position
        items_with_dist = self._query_visible_gallery_items(cam_pos)
        self._last_visible_gallery_items = items_with_dist # For HUD


        # 1. Split into Tiers (Using Squared Distances from results)
        full_r2 = self.gallery.full_render_distance ** 2
        
        full_candidates = [
            item for d2, item in items_with_dist
            if d2 <= full_r2
        ][:self.gallery.max_full_items]

        full_ids = {item.idx for item in full_candidates}
        proxy_items = [
            item for d2, item in items_with_dist
            if item.idx not in full_ids
        ][:self.gallery.max_proxy_items]

        # 2. Dynamic Loading (Budgeted)
        self._update_gallery_dynamic_cache(full_candidates)

        # 3. Batched Proxy Rendering (One call)
        self._draw_gallery_proxies_batch(proxy_items, view, proj)

        # 4. Batched Full Atom Rendering (One upload, One call)
        self._build_gallery_full_batch(full_candidates)
        self._draw_gallery_full_batch(view, proj, h)

        self._last_gallery_full_count = len(full_candidates)
        self._last_gallery_proxy_count = len(proxy_items)
        self._last_gallery_count = self._last_gallery_full_count + self._last_gallery_proxy_count

    def _build_gallery_full_batch(self, full_items):
        """Combines all nearby structures into a single GPU-ready buffer (Optimized)."""
        # CRITICAL: Sort by idx to ensure the key is stable during camera movement
        full_items_sorted = sorted(full_items, key=lambda x: x.idx)
        key = tuple(item.idx for item in full_items_sorted)
        
        if key == self._gallery_batch_key and not self._gallery_batch_dirty:
            return

        all_pos, all_radii, all_colors = [], [], []

        for item in full_items_sorted:
            # 1. Fetch scene (might be a reused object)
            scene = self._get_gallery_scene(item.idx, allow_load=False)
            if scene is None or scene.N == 0: continue

            # 2. Check stable normalization cache first
            if item.idx not in self._gallery_norm_cache:
                # Calculate normalization once for this index
                center = np.mean(scene.pos, axis=0)
                rel = (scene.pos - center[None, :]).astype(np.float32)
                radius = np.max(np.linalg.norm(rel, axis=1))
                radius = max(float(radius), 1e-3)
                scale = 3.0 / radius
                
                norm_pos = (rel * scale).astype(np.float32)
                norm_radii = (scene.radii * scale).astype(np.float32)
                
                # Colors (Ensure RGBA)
                colors = scene.colors
                if colors.shape[1] == 3:
                    rgba = np.ones((len(colors), 4), dtype=np.float32)
                    rgba[:, :3] = colors
                    norm_rgba = rgba.astype(np.float32)
                else:
                    norm_rgba = colors.astype(np.float32)
                
                # Store in stable cache
                self._gallery_norm_cache[item.idx] = (norm_pos, norm_radii, norm_rgba)
            
            # 3. Retrieve from stable cache
            norm_pos, norm_radii, norm_rgba = self._gallery_norm_cache[item.idx]
            
            all_pos.append(norm_pos + item.pos[None, :])
            all_radii.append(norm_radii)
            all_colors.append(norm_rgba)

        if not all_pos:
            self._gallery_batch_pos = None
        else:
            self._gallery_batch_pos = np.vstack(all_pos)
            self._gallery_batch_radii = np.concatenate(all_radii)
            self._gallery_batch_colors = np.vstack(all_colors)

        self._gallery_batch_key = key
        self._gallery_batch_dirty = False

    def _draw_gallery_full_batch(self, view, proj, h):
        """Submits the entire laboratory atom batch to the GPU in a single call."""
        if self._gallery_batch_pos is None or len(self._gallery_batch_pos) == 0:
            return

        n = len(self._gallery_batch_pos)
        self.rnd_sphere.upload_data(self._gallery_batch_pos, self._gallery_batch_radii, self._gallery_batch_colors)

        pairs = np.zeros((n, 2), dtype=np.uint32)
        pairs[:, 0] = np.arange(n, dtype=np.uint32)

        self.rnd_sphere.draw(
            view, proj, pairs, 15.0, h, 
            lights=self.lights, materials=self.materials, 
            atom_scale=1.0, fov=self.cam_fps.fov, is_ortho=False, 
            pretty_render=False, shading_tier=1
        )

    def _draw_gallery_proxies_batch(self, proxy_items, view, proj):
        """Renders all distant structure markers with a single GPU draw call."""
        if not proxy_items: return

        s = 2.0 # Proxy crosshair size
        lines = []
        for item in proxy_items:
            p = item.pos
            lines.extend([
                p + [-s, 0, 0], p + [s, 0, 0],
                p + [0, -s, 0], p + [0, s, 0],
                p + [0, 0, -s], p + [0, 0, s],
            ])
        
        lines_arr = np.asarray(lines, dtype=np.float32)
        color = np.array([0.4, 0.7, 1.0, 0.4], dtype=np.float32)
        self.rnd_line.draw(view, proj, lines_arr, len(lines_arr) // 2, self.rnd_sphere.rep_tbo, color)

    def _update_gallery_dynamic_cache(self, full_candidates):
        """Loads nearby gallery scenes with a strict 1.5ms per-frame time budget."""
        start = time.perf_counter()
        budget_ms = 1.5
        now = time.perf_counter()

        if now - self._gallery_last_cache_update > 0.15:
            self._gallery_last_cache_update = now
            self._gallery_load_queue = [it.idx for it in full_candidates if it.idx != self.index and it.idx not in self._gallery_scene_cache]

        while self._gallery_load_queue:
            if (time.perf_counter() - start) * 1000.0 > budget_ms:
                break
            
            idx = self._gallery_load_queue.pop(0)
            if idx in self._gallery_scene_cache: continue
            
            self._get_gallery_scene(idx, allow_load=True)
            self._gallery_batch_dirty = True

        self._prune_gallery_cache()

    def _prune_gallery_cache(self):
        """Keeps gallery memory bounded using least-recently-used (LRU) pruning."""
        max_cached = self.gallery.max_cached_scenes
        if len(self._gallery_scene_cache) <= max_cached:
            return

        # Never remove the current main scene or active selection
        removable = [idx for idx in self._gallery_scene_cache.keys() if idx != self.index]
        removable.sort(key=lambda idx: self._gallery_cache_last_used.get(idx, 0.0))

        n_remove = len(self._gallery_scene_cache) - max_cached
        for idx in removable[:n_remove]:
            self._gallery_scene_cache.pop(idx, None)
            self._gallery_cache_last_used.pop(idx, None)

    def _render_gallery_full_structure(self, item, view, proj, w, h):
        """Detailed rendering with local normalization and scaling."""
        scene = self._get_gallery_scene(item.idx)
        if scene is None or scene.N == 0: return
        
        # Compute bounds including atoms and unit cell corners
        mn, mx = scene.get_full_bounds()
        center = 0.5 * (mn + mx)
        
        # Shift relative to system's center
        rel = scene.pos - center[None, :]
        
        # Calculate a robust scaling radius
        distances = []
        if scene.N > 0:
            atom_dists = np.linalg.norm(rel, axis=1) + scene.radii
            distances.append(np.max(atom_dists))
            
        if scene.is_periodic:
            corners = cell_corners(scene.lat)
            corners_rel = corners - center[None, :]
            distances.append(np.max(np.linalg.norm(corners_rel, axis=1)))
            
        radius = max(distances) if distances else 1.0
        radius = max(float(radius), 0.5) # Minimum radius boundary to prevent extreme scaling
        
        # Target gallery size (radius of 3.0A)
        scale = 3.0 / radius
        
        # EXPLICIT COPIES to avoid memory reference corruption
        old_pos = scene.pos.copy()
        old_radii = scene.radii.copy()
        
        try:
            # Shift and scale atoms for the gallery view
            scene.pos = (rel * scale + item.pos[None, :]).astype(np.float32)
            scene.radii = (old_radii * scale).astype(np.float32)
            
            # Pass scale and center to direct renderer so unit cell matches
            self._render_gallery_item_direct(scene, view, proj, w, h, offset=item.pos, scale=scale, center=center)
        finally:
            # Restore scene to original state to avoid corrupting master data
            scene.pos = old_pos
            scene.radii = old_radii

    def _draw_gallery_proxy(self, item, view, proj):
        """Cheap wireframe proxy for distant structures."""
        color = np.array([0.4, 0.7, 1.0, 0.4], dtype=np.float32)
        p = item.pos
        s = 2.0 # Proxy size
        
        # Simple crosshair at pedestal
        lines = np.array([
            [p + [-s, 0, 0], p + [s, 0, 0]],
            [p + [0, -s, 0], p + [0, s, 0]],
            [p + [0, 0, -s], p + [0, 0, s]]
        ], dtype=np.float32).reshape(-1, 3)
        
        self.rnd_line.draw(view, proj, lines, 2, self.rnd_sphere.rep_tbo, color)

    def _preload_gallery_cache(self, max_items=30):
        """Preloads currently visible gallery structures using lazy grid query."""
        cam_pos = self.cam_fps.position
        items = self._query_visible_gallery_items(cam_pos)
        
        for _, item in items[:max_items]:
            if item.idx == self.index: continue
            if item.idx in self._gallery_scene_cache: continue
            
            scene = self._get_gallery_scene(item.idx, allow_load=True)
            if scene is not None:
                self._gallery_batch_dirty = True
            
    def _release_gallery_mouse(self):
        """Cleanly releases the mouse from FPS mode."""
        self._gallery_mouse_captured = False
        glfw.set_input_mode(self.win, glfw.CURSOR, glfw.CURSOR_NORMAL)
        self._last_poll_mouse = glfw.get_cursor_pos(self.win)

    def _render_gallery_item_direct(self, scene, view, proj, w, h, offset=None, scale=1.0, center=None):
        """Direct world-space render pass for gallery items."""
        if scene.N == 0: return
        
        # 1. Sync GPU buffers
        self.rnd_sphere.upload_replicas(scene.replica_offsets)
        self.rnd_sphere.upload_data(scene.pos, scene.radii, scene.colors)
        self._update_material_tbo(scene)
        
        # 2. Draw Spheres (Using a perspective-aware scale factor)
        pairs = np.zeros((scene.N, 2), dtype=np.uint32)
        pairs[:, 0] = np.arange(scene.N, dtype=np.uint32)
        
        # We use a base scale of 15.0 for perspective consistency in Gallery Mode
        self.rnd_sphere.draw(
            view, proj, pairs, 
            15.0, h, 
            lights=self.lights,
            materials=self.materials,
            atom_scale=1.0,
            fov=self.cam_fps.fov,
            is_ortho=False,
            pretty_render=self.pretty_render
        )
        
        # 3. Draw Unit Cell with explicit offset, scale, and center
        if self.show_cell:
            self._draw_unit_cell(scene, self.cam_fps, view, proj, offset=offset, scale=scale, center=center)

    def _scene_from_provider_record(self, rec) -> Optional[Scene]:
        """
        Converts provider.get(...) output into a Scene.
        Supports:
          1. SAGE native tuple: (pos, lat, energy, elements, colors, radii, info)
          2. ASE Atoms format
          3. (atoms, energy, info)
        """
        if rec is None:
            return None

        scene = Scene()
        try:
            # Case 1: SAGE native tuple (pos, lat, energy, elements, colors, radii, info)
            if isinstance(rec, (tuple, list)) and len(rec) >= 6:
                p, l, e, els, c, r = rec[:6]
                info = rec[6] if len(rec) > 6 else None

                scene.ingest(
                    np.asarray(p, dtype=np.float32).reshape(-1, 3),
                    np.asarray(l, dtype=np.float32),
                    e,
                    els,
                    c,
                    r,
                    info,
                )
                scene.set_replicas(0, 0, 0)
                scene.bonds = []
                scene.bond_count = 0
                return scene

            # Case 2: ASE Atoms object or similar
            if hasattr(rec, "positions") and hasattr(rec, "cell"):
                scene.ingest(
                    np.asarray(rec.positions, dtype=np.float32),
                    np.asarray(rec.cell, dtype=np.float32),
                    rec.info.get("energy", 0.0) if hasattr(rec, "info") else 0.0,
                    rec.get_chemical_symbols(),
                    None,
                    None,
                    rec.info if hasattr(rec, "info") else None,
                )
                scene.set_replicas(0, 0, 0)
                scene.bonds = []
                scene.bond_count = 0
                return scene
                
            # Case 3: (atoms, energy, info)
            if isinstance(rec, (list, tuple)) and len(rec) >= 1 and hasattr(rec[0], "positions"):
                atoms = rec[0]
                energy = rec[1] if len(rec) > 1 else 0.0
                info = rec[2] if len(rec) > 2 else {}
                scene.ingest(atoms.positions, atoms.cell, energy, 
                             elements=atoms.get_chemical_symbols(), info=info)
                scene.set_replicas(0, 0, 0)
                scene.bonds = []
                return scene

        except Exception as err:
            if self.verbose:
                print(f"[Gallery] Failed to build scene from provider record: {err}")
            return None

        return None

    def _get_gallery_scene(self, idx, allow_load: bool = True):
        """Fetches a Scene object for gallery rendering with dynamic caching."""
        # Restore smart link for the currently inspected structure
        if idx == self.index and self.scene is not None:
            return self.scene
            
        if idx in self._gallery_scene_cache:
            self._gallery_cache_last_used[idx] = time.perf_counter()
            return self._gallery_scene_cache[idx]
            
        if not allow_load:
            return None
            
        try:
            rec = self.provider.get(idx)
            scene = self._scene_from_provider_record(rec)
            
            if scene is None: return None
                
            self._gallery_scene_cache[idx] = scene
            self._gallery_cache_last_used[idx] = time.perf_counter()
            self._gallery_batch_dirty = True # Mark batch for rebuild
            
            self._prune_gallery_cache()
            return scene
        except Exception as e:
            if self.verbose:
                print(f"[Gallery] Could not load structure {idx}: {e}")
            return None
            
    def _update_gallery_interaction(self):
        """Standard FPS-style ray picking using math (No full list scan)."""
        origin = self.cam_fps.position
        fwd = self.cam_fps.forward()
        spacing = self._gallery_spacing
        
        self.gallery.nearest_idx = -1
        
        # 1. Project ray to ground plane (Z=5.0) to find target cell
        # origin.z + t*fwd.z = 5.0  => t = (5.0 - origin.z) / fwd.z
        if abs(fwd[2]) > 1e-6:
            t = (5.0 - origin[2]) / fwd[2]
            if t > 0 and t < 50.0:
                hit_pos = origin + fwd * t
                c = int(np.round(hit_pos[0] / spacing + self._gallery_cols / 2.0))
                r = int(np.round(hit_pos[1] / spacing + self._gallery_cols / 2.0))
                
                if 0 <= c < self._gallery_cols and 0 <= r < self._gallery_rows:
                    idx = r * self._gallery_cols + c
                    if idx < self._gallery_db_count:
                        self.gallery.nearest_idx = idx
                        # Mark it as hovered in lazy cache
                        if idx in self._gallery_active_items:
                            self._gallery_active_items[idx].hovered = True

        pass # Heatmap moved to 3D rendering for performance

    def _draw_gallery_floor(self, view, proj):
        """Technical grid floor + High-performance 3D Heatmap (Diamonds + Crosses)."""
        size = 2000.0
        spacing = float(self._gallery_spacing)
        steps = int(size / spacing)
        
        # 1. Base Grid
        grid_color = np.array([0.2, 0.4, 0.6, 0.15], dtype=np.float32)
        lines = []
        for i in range(-steps, steps + 1):
            coord = i * spacing
            lines.append([-size, coord, 0.0]); lines.append([ size, coord, 0.0])
            lines.append([coord, -size, 0.0]); lines.append([coord,  size, 0.0])
        
        self.rnd_line.draw(view, proj, np.array(lines, dtype=np.float32), 1, self.rnd_sphere.rep_tbo, grid_color)

    def _draw_gallery_hud(self, w, h):
        """Draws FPS crosshair and metadata cards."""
        target_idx = self.gallery.nearest_idx
        
        view = self.cam_fps.get_view_matrix()
        proj = self.cam_fps.get_projection_matrix(w/h)
        cam_pos = self.cam_fps.position
        
        # 1. Floating Structure Card (ONLY for targeted structure)
        # This completely eliminates the UI lag caused by multiple ImGui windows
        if self.gallery.show_metadata and target_idx != -1:
            item = self._gallery_active_items.get(target_idx)
            if item:
                # Fetch/Sync metadata for targeted item
                meta = {'idx': item.idx}
                scene = self._get_gallery_scene(item.idx, allow_load=False)
                if scene:
                    meta.update({'composition_str': scene.composition_str, 'n_atoms': scene.N, 'energy': scene.energy})
                    if scene.info:
                        for k, v in scene.info.items():
                            if isinstance(v, (list, np.ndarray)) and len(v) == 1: meta[k] = v[0]
                            elif not isinstance(v, (list, np.ndarray, dict)): meta[k] = v
                self._draw_structure_card(item.pos, meta, view, proj, w, h)

        # 2. Draw Crosshair & Target Marker
        dl = imgui.get_background_draw_list()
        cx, cy = w/2, h/2
        s = 10
        crosshair_col = imgui.get_color_u32_rgba(1, 1, 1, 0.8)
        
        # Target highlighting logic
        target_idx = self.gallery.nearest_idx
        target_pos_2d = None
        
        if target_idx != -1:
            # Find the position of the targeted item
            target_world_pos = None
            if target_idx in self._gallery_active_items:
                target_world_pos = self._gallery_active_items[target_idx].pos
            else:
                # Fallback to math if not in lazy cache yet
                spacing = self._gallery_spacing
                half_cols = self._gallery_cols / 2.0
                c = target_idx % self._gallery_cols
                r = target_idx // self._gallery_cols
                target_world_pos = np.array([(c - half_cols) * spacing, (r - half_cols) * spacing, 5.0], dtype=np.float32)

            # Project to screen
            mvp = proj @ view
            p4 = mvp @ np.array([target_world_pos[0], target_world_pos[1], target_world_pos[2], 1.0], dtype=np.float32)
            if p4[3] > 0.1:
                ndc = p4[:2] / p4[3]
                tx = (ndc[0] + 1.0) * 0.5 * w
                ty = (1.0 - ndc[1]) * 0.5 * h
                target_pos_2d = (tx, ty)
                
                # Draw an animated "Targeting" Hexagon/Circle
                t = glfw.get_time()
                pulse = 0.5 + 0.5 * math.sin(t * 10.0)
                ring_r = 40 + pulse * 10
                ring_col = imgui.get_color_u32_rgba(0.2, 0.7, 1.0, 0.8)
                dl.add_circle(tx, ty, ring_r, ring_col, num_segments=6, thickness=3.0)
                dl.add_circle(tx, ty, ring_r + 5, ring_col, num_segments=32, thickness=1.0)
                
                # Line from crosshair to target if they are far apart
                dist_to_center = math.sqrt((tx-cx)**2 + (ty-cy)**2)
                if dist_to_center > 20:
                    dl.add_line(cx, cy, tx, ty, imgui.get_color_u32_rgba(0.2, 0.7, 1.0, 0.3), 1.0)
                
                crosshair_col = imgui.get_color_u32_rgba(0.2, 0.8, 1.0, 1.0) # Change crosshair color when locked

        # Actual Crosshair lines
        dl.add_line(cx - s, cy, cx + s, cy, crosshair_col, 2)
        dl.add_line(cx, cy - s, cx, cy + s, crosshair_col, 2)
                
        # Controls reminder (Bottom Left)
        imgui.set_next_window_position(20, h - 230)
        imgui.begin("GalleryControls", False, imgui.WINDOW_NO_TITLE_BAR | imgui.WINDOW_ALWAYS_AUTO_RESIZE | imgui.WINDOW_NO_BACKGROUND)
        imgui.text_colored("VIRTUAL LAB ACTIVE", 0.4, 0.8, 1.0, 1.0)
        
        count = getattr(self, "_last_gallery_count", 0)
        imgui.text(f"Exploring: {count} structures")
        
        # Diagnostic status
        if count <= 1:
            imgui.text_colored("(!) Database: Limited", 1.0, 0.4, 0.4, 1.0)
        else:
            imgui.text_colored("Database: OK", 0.4, 1.0, 0.4, 1.0)
            
        imgui.separator()
        imgui.text("WASD: Move | Mouse: Look | Shift: SPRINT")
        imgui.text("Space: Up | Ctrl: Down | E: Inspect")
        
        imgui.spacing()
        captured = getattr(self, "_gallery_mouse_captured", False)
        if imgui.button("RELEASE MOUSE [Alt/Tab]" if captured else "CAPTURE MOUSE [Alt/Tab]"):
            self._toggle_gallery_mouse()
            
        imgui.text_colored("Press [V] to EXIT Gallery", 1.0, 1.0, 0.2, 1.0)
        imgui.end()

    def _toggle_gallery_mouse(self):
        """Toggles between Look mode and UI mode in Gallery."""
        self._gallery_mouse_captured = not getattr(self, "_gallery_mouse_captured", False)
        mode = glfw.CURSOR_DISABLED if self._gallery_mouse_captured else glfw.CURSOR_NORMAL
        glfw.set_input_mode(self.win, glfw.CURSOR, mode)
        # Reset mouse anchor
        self._last_poll_mouse = glfw.get_cursor_pos(self.win)

    def _handle_mouse_polling(self):
        """Polled mouse delta for FPS look in gallery mode."""
        if not self.gallery.enabled or not getattr(self, "_gallery_mouse_captured", False):
            # If not captured, clear last mouse to prevent jumps on re-capture
            if hasattr(self, "_last_poll_mouse"): delattr(self, "_last_poll_mouse")
            return
            
        curr_mouse = glfw.get_cursor_pos(self.win)
        if not hasattr(self, "_last_poll_mouse"): 
            self._last_poll_mouse = curr_mouse
            return
        
        dx = curr_mouse[0] - self._last_poll_mouse[0]
        dy = curr_mouse[1] - self._last_poll_mouse[1]
        self._last_poll_mouse = curr_mouse
        
        if abs(dx) > 0.001 or abs(dy) > 0.001:
            self.cam_fps.update_look(dx, dy)

    def _handle_gallery_input(self):
        """Handles FPS movement and interactions."""
        if not self.gallery.enabled: return
        
        # Movement
        tnow = glfw.get_time()
        dt = tnow - getattr(self, "_last_fps_time", tnow)
        self._last_fps_time = tnow
        
        # Get key states
        keys = {}
        for k in [glfw.KEY_W, glfw.KEY_A, glfw.KEY_S, glfw.KEY_D, glfw.KEY_SPACE, glfw.KEY_Q, glfw.KEY_C, glfw.KEY_LEFT_SHIFT, glfw.KEY_LEFT_CONTROL]:
            keys[k] = glfw.get_key(self.win, k) == glfw.PRESS
            
        self.cam_fps.update_movement(keys, dt)
        
        # Escape to Exit
        if glfw.get_key(self.win, glfw.KEY_ESCAPE) == glfw.PRESS:
            self.gallery.enabled = False
            self._gallery_mouse_captured = False
            glfw.set_input_mode(self.win, glfw.CURSOR, glfw.CURSOR_NORMAL)
            self.cam1.mode = "ORBIT"
            
        # Toggle Mouse Capture (Alt or Tab)
        if (glfw.get_key(self.win, glfw.KEY_LEFT_ALT) == glfw.PRESS or glfw.get_key(self.win, glfw.KEY_TAB) == glfw.PRESS) and (tnow - getattr(self, "_last_toggle_time", 0) > 0.3):
            self._last_toggle_time = tnow
            self._toggle_gallery_mouse()
            
        # E: Inspect / Select structure
        if glfw.get_key(self.win, glfw.KEY_E) == glfw.PRESS and self.gallery.nearest_idx != -1:
            # Prevent rapid-fire toggling
            if not hasattr(self, "_last_toggle_time"): self._last_toggle_time = 0
            if glfw.get_time() - self._last_toggle_time > 0.5:
                self.index = self.gallery.nearest_idx
                self._load_frame(self.index) 
                self.gallery.last_inspected_idx = self.index
                
                # Exit gallery using centralized logic
                self._toggle_gallery_mode(False)
                self._last_toggle_time = glfw.get_time()
                
                # Setup transition for Orbit Camera
                self.cam1.mode = "ORBIT"
                
                # Calculate framing distance (Reset View logic)
                mn, mx = self.scene.get_full_bounds()
                center = 0.5 * (mn + mx)
                diag = np.linalg.norm(mx - mn)
                
                fov_rad = math.radians(self.cam1.fov)
                dist = (diag * 0.5) / (math.sin(fov_rad * 0.5) + 1e-6)
                dist = max(dist * 1.2, 10.0) # 20% margin, min 10A
                
                # ISO offset based on calculated framing distance
                iso_offset = np.array([dist*0.6, -dist*0.6, dist*0.6], dtype=np.float32)
                
                self.cam1.set_fly_to(center=center, offset=iso_offset, duration=1.2)
                self.cam1._target_up = np.array([0, 0, 1], dtype=np.float32)
            
        # Mouse look handled in _handle_mouse
