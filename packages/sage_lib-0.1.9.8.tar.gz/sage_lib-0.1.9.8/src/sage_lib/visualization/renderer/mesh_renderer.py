from __future__ import annotations
from OpenGL.GL import *
import numpy as np
from typing import Optional, Tuple
from .shaders import MESH_VS, MESH_FS
from .utils import link_program

class MeshRenderer:
    """
    Generic OpenGL renderer for triangle meshes (vertices, normals, indices).
    Used for high-fidelity isosurface rendering of orbitals.
    """
    def __init__(self):
        self.prog = link_program(MESH_VS, MESH_FS)
        self.vao = glGenVertexArrays(1)
        self.vbo = glGenBuffers(1) # Positions
        self.nbo = glGenBuffers(1) # Normals
        self.ebo = glGenBuffers(1) # Indices
        self.count = 0
        self.has_data = False

    def upload_data(self, vertices: np.ndarray, normals: np.ndarray, indices: np.ndarray):
        """Uploads mesh data to the GPU."""
        if vertices.size == 0 or indices.size == 0:
            self.has_data = False
            return
            
        self.count = indices.size
        
        glBindVertexArray(self.vao)
        
        # Positions
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        glBufferData(GL_ARRAY_BUFFER, vertices.nbytes, vertices.astype(np.float32), GL_STATIC_DRAW)
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
        
        # Normals
        glBindBuffer(GL_ARRAY_BUFFER, self.nbo)
        glBufferData(GL_ARRAY_BUFFER, normals.nbytes, normals.astype(np.float32), GL_STATIC_DRAW)
        glEnableVertexAttribArray(1)
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, None)
        
        # Indices
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.ebo)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.nbytes, indices.astype(np.uint32), GL_STATIC_DRAW)
        
        glBindVertexArray(0)
        self.has_data = True

    def draw(self, view: np.ndarray, proj: np.ndarray, model: np.ndarray, cam_pos: np.ndarray,
             color: Tuple[float, float, float] = (1.0, 1.0, 1.0), 
             opacity: float = 1.0):
        if not self.has_data: return
        
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        glUseProgram(self.prog)
        
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uView"),  1, GL_FALSE, view.T)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uProj"),  1, GL_FALSE, proj.T)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uModel"), 1, GL_FALSE, model.T)
        glUniform3f(glGetUniformLocation(self.prog, "uCamPos"), *cam_pos)
        glUniform3f(glGetUniformLocation(self.prog, "uColor"),  *color)
        glUniform1f(glGetUniformLocation(self.prog, "uOpacity"), opacity)
        
        glBindVertexArray(self.vao)
        glDrawElements(GL_TRIANGLES, self.count, GL_UNSIGNED_INT, None)
        glBindVertexArray(0)
