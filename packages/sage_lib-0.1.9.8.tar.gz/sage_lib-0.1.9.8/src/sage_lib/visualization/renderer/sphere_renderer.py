# ============================
# sphere_renderer.py — GPU Impostor Spheres
# ============================
from __future__ import annotations
from OpenGL.GL import *
import numpy as np
from typing import Optional, Tuple, List, Dict
from .shaders import SPHERE_VS, SPHERE_FS
from .utils import link_program

class SphereRenderer:
    """
    High-performance GPU renderer for atomic spheres using
    impostor billboards and raycasting. Supports per-atom and per-element
    material properties through TBOs.
    """
    def __init__(self):
        from .shaders import SPHERE_VS, SPHERE_FS, PICK_SPHERE_VS, PICK_SPHERE_FS
        self.prog = link_program(SPHERE_VS, SPHERE_FS)
        self.pick_prog = link_program(PICK_SPHERE_VS, PICK_SPHERE_FS)
        
        # Attribute Buffers (Screen Quad)
        self.quad_vao = glGenVertexArrays(1)
        glBindVertexArray(self.quad_vao)
        quad = np.array([[-1,-1],[1,-1],[-1,1],[1,1]], dtype=np.float32)
        vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, quad.nbytes, quad, GL_STATIC_DRAW)
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, None)
        glBindVertexArray(0)
        
        # Texture Buffer Objects (TBOs)
        self.pos_bo, self.pos_tbo = glGenBuffers(1), glGenTextures(1)
        self.col_bo, self.col_tbo = glGenBuffers(1), glGenTextures(1)
        self.rep_bo, self.rep_tbo = glGenBuffers(1), glGenTextures(1)
        self.mat_bo, self.mat_tbo = glGenBuffers(1), glGenTextures(1)
        self.sel_bo, self.sel_tbo = glGenBuffers(1), glGenTextures(1)

        # Shadow Mapping Pass
        self.shadow_size = 4096
        self.shadow_fbo = glGenFramebuffers(1)
        self.shadow_tex = glGenTextures(1)
        self.shadow_compare = True # Hardware comparison by default
        glBindTexture(GL_TEXTURE_2D, self.shadow_tex)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, self.shadow_size, self.shadow_size, 0, GL_DEPTH_COMPONENT, GL_FLOAT, None)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER)
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, [1.0, 1.0, 1.0, 1.0])
        
        # Add shadow comparison mode for HW-accelerated percentage-closer filtering (PCF)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL)

        glBindFramebuffer(GL_FRAMEBUFFER, self.shadow_fbo)
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, self.shadow_tex, 0)
        glDrawBuffer(GL_NONE)
        glReadBuffer(GL_NONE)
        
        if glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE:
            print("Warning: Shadow FBO incomplete!")
        glBindFramebuffer(GL_FRAMEBUFFER, 0)
        
        # Shadow Shader (Specific for depth pass)
        from .shaders import SHADOW_VS, SHADOW_FS
        self.shadow_prog = link_program(SHADOW_VS, SHADOW_FS)
        
        # Material Data TBOs (M1: Amb/Spec/Shin/Rim, M2: Sheen/CC/Env/Gloss)
        self.mat_bo, self.mat_tbo = glGenBuffers(1), glGenTextures(1)
        self.mat_bo2, self.mat_tbo2 = glGenBuffers(1), glGenTextures(1)
        
        # Selection Pass Data
        self.sel_bo, self.sel_tbo = glGenBuffers(1), glGenTextures(1)
        self.sel_full_bo, self.sel_full_tbo = glGenBuffers(1), glGenTextures(1)
        
        # Visibility Pass Data
        self.vis_bo, self.vis_tbo = glGenBuffers(1), glGenTextures(1)

        # Cached uniform locations
        self.u = {name: glGetUniformLocation(self.prog, name) for name in [
            "uView", "uProj", "uViewInv", "uShadowMatrix",
            "uNumLights",
            "uExposure", "uHeadlight",
            "uShowShadows", "uShowGroundShadow",
            "uShadowIntensity", "uShadowSoftness", "uShadowBias", "uShadowSize",
            "uReflectionIntensity", "uReflectionGloss",
            "uSelectionGlow", "uSheen", "uClearcoat",
            "uFogDensity",
            "uTime", "uPulseSpeed", "uPulseAmp",
            "uVisibleCount",
            "uIsOrtho", "uAtomScale", "uProjScale", "uViewportHeight",
            "uSkipPx", "uPointPx",
            "uShadingTier", "uPrettyRender",
            "uSelectedCount",
            "uAtomPosRad", "uAtomColor", "uReplicaOffsets",
            "uAtomMaterial", "uAtomMaterial2",
            "uShadowMap",
            "uVisiblePairs",
            "uSelectedAtoms",
            "uSelectionMaskFull",
            "uSelectionOnly",
            "uHoverAtomIdx",
            "uReplicaDimming",
            "uIsGhost",
        ]}

        self.shadow_u = {name: glGetUniformLocation(self.shadow_prog, name) for name in [
            "uView", "uProj", "uVisibleCount", "uAtomScale",
            "uAtomPosRad", "uReplicaOffsets", "uVisiblePairs"
        ]}
        
        self.u_light_dir = [glGetUniformLocation(self.prog, f"uLightDir[{i}]") for i in range(4)]
        self.u_light_col = [glGetUniformLocation(self.prog, f"uLightCol[{i}]") for i in range(4)]
        
        # Picking program uniforms
        self.pick_u = {name: glGetUniformLocation(self.pick_prog, name) for name in [
            "uView", "uProj", "uAtomPosRad", "uReplicaOffsets", 
            "uVisiblePairs", "uVisibleCount", "uIsOrtho", "uAtomScale", "uIDOffset", "uHoverAtomIdx"
        ]}

        # Track capacities to avoid glBufferData every frame
        self._vis_capacity_bytes = 0
        self._pos_capacity_bytes = 0
        self._col_capacity_bytes = 0
        self._sel_capacity_bytes = 0
        self._sel_full_capacity_bytes = 0
        self.visible_count = 0
        self.atom_count = 0
        self.selected_count = 0

    def upload_visible_pairs(self, pairs: np.ndarray):
        """Uploads list of (atomIdx, replicaIdx) currently visible."""
        if pairs.size == 0:
            p_data = np.zeros((1, 2), dtype=np.uint32)
            self.visible_count = 0
        else:
            p_data = np.ascontiguousarray(pairs.astype(np.uint32))
            self.visible_count = len(pairs)

        nbytes = p_data.nbytes
        glBindBuffer(GL_TEXTURE_BUFFER, self.vis_bo)

        # Allocate only when capacity is insufficient
        if nbytes > self._vis_capacity_bytes:
            new_cap = max(nbytes, int(max(1024, 1.5 * nbytes)))
            glBufferData(GL_TEXTURE_BUFFER, new_cap, None, GL_STREAM_DRAW)
            self._vis_capacity_bytes = new_cap

        glBufferSubData(GL_TEXTURE_BUFFER, 0, nbytes, p_data)
        glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RG32UI, self.vis_bo)
        
    def begin_shadow_pass(self, light_dir: Tuple[float, float, float], center=(0,0,0), size=20.0):
        """Prepares the shadow FBO and view/projection matrices for a light source."""
        glBindFramebuffer(GL_FRAMEBUFFER, self.shadow_fbo)
        glViewport(0, 0, self.shadow_size, self.shadow_size)
        glClear(GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        glDisable(GL_CULL_FACE) # Quads don't cull efficiently here
        
        # Build Ortho Projection for the light
        from .utils import look_at, ortho
        up = [0,1,0] if abs(light_dir[1]) < 0.9 else [1,0,0]
        self.shadow_view = look_at(np.array(light_dir) + np.array(center), np.array(center), np.array(up))
        self.shadow_proj = ortho(-size, size, -size, size, -size*2, size*2)
        self.shadow_matrix = self.shadow_proj @ self.shadow_view

    def draw_shadows(self, view: np.ndarray, proj: np.ndarray, 
                     visible_pairs: np.ndarray, atom_scale: float):
        """Pass 1: Render depth to shadow map."""
        count = visible_pairs.shape[0]
        if count == 0: return
        self.upload_visible_pairs(visible_pairs)

        # Save current state
        prev_viewport = glGetIntegerv(GL_VIEWPORT)
        prev_fbo = glGetIntegerv(GL_FRAMEBUFFER_BINDING)

        glBindFramebuffer(GL_FRAMEBUFFER, self.shadow_fbo)
        glViewport(0, 0, self.shadow_size, self.shadow_size)
        glDepthMask(GL_TRUE)
        glClear(GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        glUseProgram(self.shadow_prog)
        # For 2D impostors, we don't need culling in the shadow pass
        glDisable(GL_CULL_FACE) 
        
        glUniformMatrix4fv(self.shadow_u["uView"], 1, GL_FALSE, view.T)
        glUniformMatrix4fv(self.shadow_u["uProj"], 1, GL_FALSE, proj.T)
        glUniform1i(self.shadow_u["uVisibleCount"], count)
        glUniform1f(self.shadow_u["uAtomScale"], atom_scale)
        
        glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_BUFFER, self.pos_tbo)
        glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_BUFFER, self.rep_tbo)
        glActiveTexture(GL_TEXTURE5); glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)
        
        glUniform1i(self.shadow_u["uAtomPosRad"], 0)
        glUniform1i(self.shadow_u["uReplicaOffsets"], 2)
        glUniform1i(self.shadow_u["uVisiblePairs"], 5)

        glBindVertexArray(self.quad_vao)
        glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, count)
        glBindVertexArray(0)
        # Restore viewport and Framebuffer
        glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo)
        glViewport(prev_viewport[0], prev_viewport[1], prev_viewport[2], prev_viewport[3])

    def upload_materials(self, mat_data1: np.ndarray, mat_data2: np.ndarray):
        """Uploads per-atom material constants across two TBOs."""
        # Buffer 1: [Ambient, Specular, Shininess, Rim]
        glBindBuffer(GL_TEXTURE_BUFFER, self.mat_bo)
        glBufferData(GL_TEXTURE_BUFFER, mat_data1.nbytes, mat_data1, GL_DYNAMIC_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.mat_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.mat_bo)
        
        # Buffer 2: [Sheen, Clearcoat, EnvIntensity, Glossiness]
        glBindBuffer(GL_TEXTURE_BUFFER, self.mat_bo2)
        glBufferData(GL_TEXTURE_BUFFER, mat_data2.nbytes, mat_data2, GL_DYNAMIC_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.mat_tbo2)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.mat_bo2)

    def upload_selection(self, selected_ids: list, total_count: int):
        """Uploads list of atom indices currently selected for glowing."""
        if not selected_ids:
            data = np.array([0], dtype=np.uint32)
            full_data = np.zeros(max(total_count, 1), dtype=np.uint8)
            self.selected_count = 0
        else:
            # Defensive guard: filter out any None values that might have leaked in
            valid_ids = [i for i in selected_ids if i is not None]
            if not valid_ids:
                data = np.array([0], dtype=np.uint32)
                full_data = np.zeros(max(total_count, 1), dtype=np.uint8)
                self.selected_count = 0
            else:
                selected_ids = np.asarray(valid_ids, dtype=np.int64)
                data = np.ascontiguousarray(selected_ids.astype(np.uint32))
                full_data = np.zeros(max(total_count, 1), dtype=np.uint8)
                full_data[selected_ids] = 1
                full_data = np.ascontiguousarray(full_data)
                self.selected_count = len(selected_ids)

        glBindBuffer(GL_TEXTURE_BUFFER, self.sel_bo)
        if data.nbytes > self._sel_capacity_bytes:
            new_cap = max(data.nbytes, int(max(256, 1.5 * data.nbytes)))
            glBufferData(GL_TEXTURE_BUFFER, new_cap, None, GL_DYNAMIC_DRAW)
            self._sel_capacity_bytes = new_cap
        glBufferSubData(GL_TEXTURE_BUFFER, 0, data.nbytes, data)
        glBindTexture(GL_TEXTURE_BUFFER, self.sel_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_R32UI, self.sel_bo)

        glBindBuffer(GL_TEXTURE_BUFFER, self.sel_full_bo)
        if full_data.nbytes > self._sel_full_capacity_bytes:
            new_cap = max(full_data.nbytes, int(max(256, 1.5 * full_data.nbytes)))
            glBufferData(GL_TEXTURE_BUFFER, new_cap, None, GL_DYNAMIC_DRAW)
            self._sel_full_capacity_bytes = new_cap
        glBufferSubData(GL_TEXTURE_BUFFER, 0, full_data.nbytes, full_data)
        glBindTexture(GL_TEXTURE_BUFFER, self.sel_full_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_R8UI, self.sel_full_bo)

    def upload_data(self, positions: np.ndarray, radii: np.ndarray, colors: np.ndarray):
        """Uploads positions/radii and colors to GPU buffers."""
        pos_arr = np.asarray(positions, dtype=np.float32)
        rad_arr = np.asarray(radii, dtype=np.float32)
        col_arr = np.asarray(colors, dtype=np.float32)

        N = pos_arr.shape[0]
        if N == 0:
            pos_rad = np.zeros((1, 4), dtype=np.float32)
            rgba = np.zeros((1, 4), dtype=np.float32)
            self.atom_count = 0
        else:
            pos_rad = np.ascontiguousarray(np.hstack([pos_arr, rad_arr[:, None]]).astype(np.float32))
            if col_arr.shape[1] == 4:
                rgba = np.ascontiguousarray(col_arr)
            else:
                rgba = np.ones((N, 4), dtype=np.float32)
                rgba[:, :3] = col_arr
                rgba = np.ascontiguousarray(rgba)
            self.atom_count = N

        # Position/radius buffer
        glBindBuffer(GL_TEXTURE_BUFFER, self.pos_bo)
        if pos_rad.nbytes > self._pos_capacity_bytes:
            new_cap = max(pos_rad.nbytes, int(max(1024, 1.5 * pos_rad.nbytes)))
            glBufferData(GL_TEXTURE_BUFFER, new_cap, None, GL_DYNAMIC_DRAW)
            self._pos_capacity_bytes = new_cap
        glBufferSubData(GL_TEXTURE_BUFFER, 0, pos_rad.nbytes, pos_rad)
        glBindTexture(GL_TEXTURE_BUFFER, self.pos_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.pos_bo)

        # Color buffer
        glBindBuffer(GL_TEXTURE_BUFFER, self.col_bo)
        if rgba.nbytes > self._col_capacity_bytes:
            new_cap = max(rgba.nbytes, int(max(1024, 1.5 * rgba.nbytes)))
            glBufferData(GL_TEXTURE_BUFFER, new_cap, None, GL_DYNAMIC_DRAW)
            self._col_capacity_bytes = new_cap
        glBufferSubData(GL_TEXTURE_BUFFER, 0, rgba.nbytes, rgba)
        glBindTexture(GL_TEXTURE_BUFFER, self.col_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.col_bo)

    def upload_replicas(self, offsets: np.ndarray):
        offsets_padded = np.hstack([offsets, np.zeros((offsets.shape[0], 1))]).astype(np.float32)
        glBindBuffer(GL_TEXTURE_BUFFER, self.rep_bo)
        glBufferData(GL_TEXTURE_BUFFER, offsets_padded.nbytes, offsets_padded, GL_STATIC_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.rep_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.rep_bo)

    def change_shadow_res(self, res: int):
        """Re-initializes shadow texture with new resolution."""
        if res == self.shadow_size: return
        self.shadow_size = res
        glBindTexture(GL_TEXTURE_2D, self.shadow_tex)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, res, res, 0, GL_DEPTH_COMPONENT, GL_FLOAT, None)
        glBindTexture(GL_TEXTURE_2D, 0)

    def set_shadow_debug(self, enabled: bool):
        """Toggles hardware comparison. True = Normal shadows, False = Raw Depth Debug."""
        if self.shadow_compare == (not enabled): return
        self.shadow_compare = not enabled
        glBindTexture(GL_TEXTURE_2D, self.shadow_tex)
        if enabled:
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_NONE)
        else:
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE)
        glBindTexture(GL_TEXTURE_2D, 0)

    def get_visible_offsets(self, view: np.ndarray, proj: np.ndarray,
                            all_replica_offsets: np.ndarray,
                            scene_bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None) -> List[int]:
        """Returns list of indices of replica offsets likely visible in the frustum."""
        vp = proj @ view
        visible_indices = []

        mn, mx = scene_bounds if scene_bounds else (np.zeros(3, dtype=np.float32), np.ones(3, dtype=np.float32) * 10.0)
        cell_size = mx - mn
        center_cell = mn + 0.5 * cell_size
        radius_cell = max(1e-6, np.linalg.norm(cell_size) * 0.6)

        for i, off in enumerate(all_replica_offsets):
            c_world = center_cell + off
            cp = vp @ np.array([c_world[0], c_world[1], c_world[2], 1.0], dtype=np.float32)

            w = cp[3]
            if abs(w) < 1e-8:
                continue

            ndc = cp[:3] / w
            margin = radius_cell / max(abs(w), 1.0)

            if (
                ndc[0] >= -1.0 - margin and ndc[0] <= 1.0 + margin and
                ndc[1] >= -1.0 - margin and ndc[1] <= 1.0 + margin and
                ndc[2] >= -1.0 - margin and ndc[2] <= 1.0 + margin
            ):
                visible_indices.append(i)

        return visible_indices

    def draw(self, view, proj, visible_pairs, 
             ortho_scale, viewport_height,
             lights=[], materials={},
             atom_scale=1.0, fov=45.0, is_ortho=False,
             skip_px=0.5, point_px=4.0, shading_tier=2, pretty_render=True,
             shadow_matrix=None, shadow_map=0, shadow_size=512,
             selection_only=False,
             reflection_intensity=0.0, reflection_gloss=0.5,
             fog_density=0.0, time=0.0,
             hover_idx=-1):
        """Renders spheres with multi-light support and per-atom materials."""
        count = visible_pairs.shape[0]
        self._last_vis_count = count
        self._last_atom_scale = atom_scale
        self._last_ortho = is_ortho
        if count == 0: return
        self.upload_visible_pairs(visible_pairs)
        
        glUseProgram(self.prog)
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)

        # Enable blending only when needed
        needs_blend = selection_only or materials.get('force_blend', False)
        if needs_blend:
            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        else:
            glDisable(GL_BLEND)
        
        # 1. Lights
        glUniform1i(self.u["uNumLights"], len(lights))
        vr = view[:3, :3]
        for i, l in enumerate(lights[:4]):
             lv = vr @ np.array(l['pos'], dtype=np.float32)
             glUniform3f(self.u_light_dir[i], *lv)
             glUniform3f(self.u_light_col[i], *l['col'])
            
        # 2. Materials & VFX
        glUniform1f(self.u["uExposure"], materials.get('exposure', 1.5))
        glUniform1f(self.u["uHeadlight"], materials.get('headlight', 0.8))
        sh_enabled = materials.get('show_shadows', True)
        glUniform1i(self.u["uShowShadows"], 1 if (sh_enabled and shadow_matrix is not None) else 0)
        glUniform1f(self.u["uShadowIntensity"], materials.get('shadow_intensity', 0.6))
        glUniform1f(self.u["uShadowBias"], materials.get('shadow_bias', 0.01))
        
        softness = materials.get('shadow_softness', 1.5) / float(max(self.shadow_size, 1))
        glUniform1f(self.u["uShadowSoftness"], softness)

        glUniform1f(self.u["uReflectionIntensity"], reflection_intensity)
        glUniform1f(self.u["uReflectionGloss"], reflection_gloss)
        glUniform1f(self.u["uSelectionGlow"], materials.get('selection_glow', 1.0))
        glUniform1f(self.u["uSheen"], materials.get('sheen', 0.0))
        glUniform1f(self.u["uClearcoat"], materials.get('clearcoat', 0.0))
        glUniform1f(self.u["uFogDensity"], fog_density)
        
        # Atom Motion
        glUniform1f(self.u["uPulseSpeed"], materials.get('pulse_speed', 4.0))
        glUniform1f(self.u["uPulseAmp"], materials.get('pulse_amp', 0.0))
        glUniform1f(self.u["uTime"], time)

        # 3. Matrices
        glUniformMatrix4fv(self.u["uView"], 1, GL_FALSE, view.T)
        glUniformMatrix4fv(self.u["uProj"], 1, GL_FALSE, proj.T)
        if shadow_matrix is not None:
             glUniformMatrix4fv(self.u["uShadowMatrix"], 1, GL_FALSE, shadow_matrix.T)
        
        # rigid-matrix inverse is faster for camera matrices
        view_inv = np.linalg.inv(view).astype(np.float32)
        glUniformMatrix4fv(self.u["uViewInv"], 1, GL_FALSE, view_inv.T)
        
        import math
        ps = viewport_height / (ortho_scale if is_ortho else (2.0 * math.tan(math.radians(fov)/2.0)))
        glUniform1f(self.u["uProjScale"], ps)

        # 4. State
        glUniform1i(self.u["uVisibleCount"], count)
        glUniform1i(self.u["uIsOrtho"], 1 if is_ortho else 0)
        glUniform1f(self.u["uAtomScale"], atom_scale)
        glUniform1f(self.u["uViewportHeight"], float(viewport_height))

        # Safer skip threshold in normal mode to prevent disappearing atoms
        safe_skip_px = skip_px
        if not pretty_render:
             safe_skip_px = min(skip_px, 0.15)
        glUniform1f(self.u["uSkipPx"], safe_skip_px)

        glUniform1f(self.u["uPointPx"], point_px) 
        glUniform1f(self.u["uShadowSize"], float(shadow_size))
        glUniform1i(self.u["uShadingTier"], int(shading_tier))
        glUniform1i(self.u["uPrettyRender"], 1 if pretty_render else 0)
        glUniform1i(self.u["uSelectedCount"], getattr(self, 'selected_count', 0))
        glUniform1i(self.u["uHoverAtomIdx"], int(hover_idx))
        glUniform1f(self.u["uReplicaDimming"], materials.get('replica_dimming', 1.0))
        glUniform1i(self.u["uIsGhost"], 1 if materials.get('is_ghost', False) else 0)

        # 5. Textures (Units 0-7)
        glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_BUFFER, self.pos_tbo)
        glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_BUFFER, self.col_tbo)
        glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_BUFFER, self.rep_tbo)
        glActiveTexture(GL_TEXTURE3); glBindTexture(GL_TEXTURE_BUFFER, self.mat_tbo)
        glActiveTexture(GL_TEXTURE4); glBindTexture(GL_TEXTURE_2D, shadow_map if shadow_map != 0 else self.shadow_tex)
        glActiveTexture(GL_TEXTURE5); glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)
        glActiveTexture(GL_TEXTURE6); glBindTexture(GL_TEXTURE_BUFFER, self.sel_tbo)
        glActiveTexture(GL_TEXTURE7); glBindTexture(GL_TEXTURE_BUFFER, self.mat_tbo2) 
        glActiveTexture(GL_TEXTURE8); glBindTexture(GL_TEXTURE_BUFFER, self.sel_full_tbo)

        glUniform1i(self.u["uAtomPosRad"], 0)
        glUniform1i(self.u["uAtomColor"], 1)
        glUniform1i(self.u["uReplicaOffsets"], 2)
        glUniform1i(self.u["uAtomMaterial"], 3)
        glUniform1i(self.u["uShadowMap"], 4)
        glUniform1i(self.u["uVisiblePairs"], 5)
        glUniform1i(self.u["uSelectedAtoms"], 6)
        glUniform1i(self.u["uAtomMaterial2"], 7) 
        glUniform1i(self.u["uSelectionMaskFull"], 8)
        
        glUniform1i(self.u["uSelectionOnly"], 1 if selection_only else 0)

        # 6. Draw
        glBindVertexArray(self.quad_vao)
        glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, count)
        glBindVertexArray(0)

    def draw_picking(self, view: np.ndarray, proj: np.ndarray, id_offset: int, atom_scale: float, is_ortho: bool, visible_pairs: Optional[np.ndarray] = None, hover_idx: int = -1):
        """Pass 3: Render atom IDs into the picking buffer."""
        if visible_pairs is not None:
            self.upload_visible_pairs(visible_pairs)
            self._last_vis_count = visible_pairs.shape[0]
            
        if getattr(self, '_last_vis_count', 0) == 0: return
        
        glUseProgram(self.pick_prog)
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)  # Ensure closest object wins
        glDepthMask(GL_TRUE)
        glDisable(GL_BLEND)
        
        glUniformMatrix4fv(self.pick_u["uView"], 1, GL_FALSE, view.T)
        glUniformMatrix4fv(self.pick_u["uProj"], 1, GL_FALSE, proj.T)
        glUniform1i(self.pick_u["uIsOrtho"], 1 if is_ortho else 0)
        glUniform1f(self.pick_u["uAtomScale"], atom_scale)
        glUniform1ui(self.pick_u["uIDOffset"], id_offset)
        glUniform1i(self.pick_u["uHoverAtomIdx"], hover_idx)
        
        glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_BUFFER, self.pos_tbo)
        glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_BUFFER, self.rep_tbo)
        glActiveTexture(GL_TEXTURE5); glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)
        
        glUniform1i(self.pick_u["uAtomPosRad"], 0)
        glUniform1i(self.pick_u["uReplicaOffsets"], 2)
        glUniform1i(self.pick_u["uVisiblePairs"], 5)

        glBindVertexArray(self.quad_vao)
        glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, self._last_vis_count)
        glBindVertexArray(0)
