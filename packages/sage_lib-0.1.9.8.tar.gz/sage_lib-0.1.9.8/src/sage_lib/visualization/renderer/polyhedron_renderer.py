from __future__ import annotations
from OpenGL.GL import *
import numpy as np
from typing import Tuple, List, Optional, Dict
from .utils import link_program
from .shaders import POLY_VS, POLY_FS

class PolyhedronRenderer:
    """
    Renders derived geometries like coordination polyhedra and Voronoi cells.
    Supports transparency (OIT), picking, and batching.
    """
    def __init__(self):
        self.vao = glGenVertexArrays(1)
        self.vbos = glGenBuffers(4) # pos, normal, color, id
        self.ebo = glGenBuffers(1)
        self.count = 0
        self.recompile()

    def recompile(self):
        """Recompiles and re-links shaders from the current source in shaders.py."""
        from .shaders import POLY_VS, POLY_FS, PICK_POLY_FS
        if hasattr(self, 'prog') and self.prog: glDeleteProgram(self.prog)
        if hasattr(self, 'prog_pick') and self.prog_pick: glDeleteProgram(self.prog_pick)
        
        self.prog = link_program(POLY_VS, POLY_FS)
        self.prog_pick = link_program(POLY_VS, PICK_POLY_FS)
        
        # Re-fetch Shader Uniforms
        self.uView = glGetUniformLocation(self.prog, "uView")
        self.uProj = glGetUniformLocation(self.prog, "uProj")
        self.uModel = glGetUniformLocation(self.prog, "uModel")
        self.uCamPos = glGetUniformLocation(self.prog, "uCamPos")
        self.uOpacity = glGetUniformLocation(self.prog, "uOpacity")
        self.uIsOIT = glGetUniformLocation(self.prog, "uIsOIT")
        self.uIsPicking = glGetUniformLocation(self.prog, "uIsPicking")

    def upload_data(self, 
                    vertices: np.ndarray, 
                    normals: np.ndarray, 
                    colors: np.ndarray, 
                    indices: np.ndarray,
                    ids: np.ndarray):
        """
        Uploads batched geometry data to GPU.
        Expects flat arrays representing multiple polyhedra.
        """
        if len(vertices) == 0:
            self.count = 0
            return

        self.count = len(vertices) # DrawArrays uses vertex count
        
        # Ensure VAO is ready
        if not self.vao or not glIsVertexArray(self.vao):
            self.vao = glGenVertexArrays(1)
            
        glBindVertexArray(self.vao)
        
        import ctypes
        void_ptr = ctypes.c_void_p(0)
        
        # Position (Location 0)
        glBindBuffer(GL_ARRAY_BUFFER, self.vbos[0])
        glBufferData(GL_ARRAY_BUFFER, vertices.nbytes, vertices, GL_DYNAMIC_DRAW)
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, void_ptr)
        
        # Normal (Location 1)
        glBindBuffer(GL_ARRAY_BUFFER, self.vbos[1])
        glBufferData(GL_ARRAY_BUFFER, normals.nbytes, normals, GL_DYNAMIC_DRAW)
        glEnableVertexAttribArray(1)
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, void_ptr)
        
        # Color (Location 2)
        glBindBuffer(GL_ARRAY_BUFFER, self.vbos[2])
        glBufferData(GL_ARRAY_BUFFER, colors.nbytes, colors, GL_DYNAMIC_DRAW)
        glEnableVertexAttribArray(2)
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, void_ptr)
        
        # ID (Location 3)
        glBindBuffer(GL_ARRAY_BUFFER, self.vbos[3])
        glBufferData(GL_ARRAY_BUFFER, ids.nbytes, ids, GL_DYNAMIC_DRAW)
        glEnableVertexAttribArray(3)
        glVertexAttribIPointer(3, 1, GL_UNSIGNED_INT, 0, void_ptr)
        
        glBindVertexArray(0)
        glBindBuffer(GL_ARRAY_BUFFER, 0)

    def draw(self, 
             view: np.ndarray, 
             proj: np.ndarray, 
             model: np.ndarray, 
             cam_pos: np.ndarray, 
             opacity: float = 0.5, 
             is_oit: bool = False,
             is_picking: bool = False):
        """Draws the uploaded polyhedra."""
        if self.count == 0: return
        
        prog = self.prog_pick if is_picking else self.prog
        glUseProgram(prog)
        
        # Matrices MUST be transposed for OpenGL (.T)
        glUniformMatrix4fv(glGetUniformLocation(prog, "uView"), 1, GL_FALSE, view.T)
        glUniformMatrix4fv(glGetUniformLocation(prog, "uProj"), 1, GL_FALSE, proj.T)
        glUniformMatrix4fv(glGetUniformLocation(prog, "uModel"), 1, GL_FALSE, model.T)
        
        if not is_picking:
            glUniform3fv(glGetUniformLocation(prog, "uCamPos"), 1, cam_pos)
            glUniform1f(glGetUniformLocation(prog, "uOpacity"), opacity)
            glUniform1i(glGetUniformLocation(prog, "uIsOIT"), 1 if is_oit else 0)
        
        glBindVertexArray(self.vao)
        
        # Draw Arrays (Correct path for expanded vertices)
        glDrawArrays(GL_TRIANGLES, 0, self.count)
        
        # Optional Wireframe pass
        if not is_picking and hasattr(self, "show_wireframe") and self.show_wireframe:
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
            glLineWidth(1.0) 
            glDrawArrays(GL_TRIANGLES, 0, self.count)
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
            
        glBindVertexArray(0)
        glUseProgram(0)

    def draw_vao(self, 
                 vao: int, 
                 count: int,
                 view: np.ndarray, 
                 proj: np.ndarray, 
                 model: np.ndarray, 
                 cam_pos: np.ndarray, 
                 opacity: float = 0.5, 
                 is_oit: bool = False,
                 ebo: Optional[int] = None):
        """Draws a specific VAO using the polyhedron shader."""
        if count == 0: return
        
        glUseProgram(self.prog)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uView"), 1, GL_FALSE, view)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uProj"), 1, GL_FALSE, proj)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uModel"), 1, GL_FALSE, model)
        glUniform3fv(glGetUniformLocation(self.prog, "uCamPos"), 1, cam_pos)
        glUniform1f(glGetUniformLocation(self.prog, "uOpacity"), opacity)
        glUniform1i(glGetUniformLocation(self.prog, "uIsOIT"), 1 if is_oit else 0)
        
        glBindVertexArray(vao)
        if ebo is not None:
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo)
            glDrawElements(GL_TRIANGLES, count, GL_UNSIGNED_INT, None)
        else:
            glDrawArrays(GL_TRIANGLES, 0, count)
        
        glBindVertexArray(0)
        glUseProgram(0)

    @staticmethod
    def calculate_distortion_metrics(center: np.ndarray, vertices: np.ndarray) -> Dict[str, float]:
        """
        Calculates scientific distortion metrics for a coordination polyhedron.
        """
        if len(vertices) == 0:
            return {}
            
        # Distances from center to ligands
        dists = np.linalg.norm(vertices - center, axis=1)
        avg_dist = np.mean(dists)
        
        # Bond Length Distortion (variance)
        # D = 1/N * sum(|d_i - d_avg| / d_avg)
        dist_distortion = np.mean(np.abs(dists - avg_dist) / (avg_dist + 1e-9))
        
        # Simple volume calculation (expects convex hull vertices)
        from scipy.spatial import ConvexHull
        try:
            hull = ConvexHull(vertices)
            volume = hull.volume
        except:
            volume = 0.0
            
        return {
            'avg_dist': float(avg_dist),
            'dist_distortion': float(dist_distortion),
            'volume': float(volume)
        }

    def cleanup(self):
        glDeleteProgram(self.prog)
        glDeleteVertexArrays(1, [self.vao])
        glDeleteBuffers(len(self.vbos), self.vbos)
        glDeleteBuffers(1, [self.ebo])
