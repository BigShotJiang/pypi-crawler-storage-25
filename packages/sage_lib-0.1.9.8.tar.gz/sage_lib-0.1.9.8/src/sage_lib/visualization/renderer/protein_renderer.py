# ============================
# protein_renderer.py — Protein Representation Rendering
# ============================
from __future__ import annotations
from OpenGL.GL import *
import numpy as np
from typing import Optional, Tuple, List
from .shaders import MESH_VS, MESH_FS
from .utils import link_program

class ProteinRenderer:
    """
    Renders protein secondary structures (ribbons) using colored triangle meshes.
    Handles multiple chains gracefully.
    """
    def __init__(self):
        self.prog = link_program(MESH_VS, MESH_FS)
        self.vao = glGenVertexArrays(1)
        self.vbo = glGenBuffers(1) # Positions
        self.nbo = glGenBuffers(1) # Normals
        self.cbo = glGenBuffers(1) # Vertex colors
        self.ebo = glGenBuffers(1) # Indices
        self.count = 0
        self.has_data = False

    def upload_data(self, vertices: np.ndarray, normals: np.ndarray, colors: np.ndarray, indices: np.ndarray):
        """Uploads ribbon mesh data to the GPU."""
        if vertices.size == 0 or indices.size == 0:
            self.has_data = False
            return
            
        self.count = indices.size
        
        glBindVertexArray(self.vao)
        
        # Positions
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        glBufferData(GL_ARRAY_BUFFER, vertices.nbytes, vertices.astype(np.float32), GL_STATIC_DRAW)
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
        
        # Normals
        glBindBuffer(GL_ARRAY_BUFFER, self.nbo)
        glBufferData(GL_ARRAY_BUFFER, normals.nbytes, normals.astype(np.float32), GL_STATIC_DRAW)
        glEnableVertexAttribArray(1)
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, None)
        
        # Colors
        glBindBuffer(GL_ARRAY_BUFFER, self.cbo)
        glBufferData(GL_ARRAY_BUFFER, colors.nbytes, colors.astype(np.float32), GL_STATIC_DRAW)
        glEnableVertexAttribArray(2)
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, None)
        
        # Indices
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.ebo)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.nbytes, indices.astype(np.uint32), GL_STATIC_DRAW)
        
        glBindVertexArray(0)
        self.has_data = True

    def draw(self, view: np.ndarray, proj: np.ndarray, model: np.ndarray, cam_pos: np.ndarray,
             is_pretty_render: bool = True, opacity: float = 1.0, is_oit: bool = False,
             shadow_matrix: Optional[np.ndarray] = None, shadow_map: int = 0, shadow_size: float = 2048.0,
             lights: List[dict] = None, materials: dict = None):
        if not self.has_data: return
        
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_BLEND)
        if is_oit:
            # For OIT, we want depth testing against atoms, but no depth writing
            # to let all transparency layers be accumulated.
            glDepthMask(GL_FALSE)
        else:
            glDepthMask(GL_TRUE)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        # Make ribbons double sided for interior loops/sheets viewing
        glDisable(GL_CULL_FACE)
        
        glUseProgram(self.prog)
        
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uView"),  1, GL_FALSE, view.T)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uProj"),  1, GL_FALSE, proj.T)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uModel"), 1, GL_FALSE, model.T)
        glUniform3f(glGetUniformLocation(self.prog, "uCamPos"), *cam_pos)
        
        glUniform1i(glGetUniformLocation(self.prog, "uPrettyRender"), 1 if is_pretty_render else 0)
        glUniform1i(glGetUniformLocation(self.prog, "uUseVertexColors"), 1)
        glUniform1f(glGetUniformLocation(self.prog, "uOpacity"), opacity)
        glUniform1i(glGetUniformLocation(self.prog, "uIsOIT"), 1 if is_oit else 0)

        # Advanced Lighting
        if is_pretty_render:
            l_pos = np.array(lights[0]['pos'] if lights else [0, 100, 100], dtype=np.float32)
            l_dir = l_pos / (np.linalg.norm(l_pos) + 1e-8)
            glUniform3f(glGetUniformLocation(self.prog, "uLightDir"), l_dir[0], l_dir[1], l_dir[2])
            glUniform1f(glGetUniformLocation(self.prog, "uShadowIntensity"), 
                        materials.get("shadow_intensity", 0.6) if materials else 0.6)
            glUniform1f(glGetUniformLocation(self.prog, "uShadowBias"), 
                        materials.get("shadow_bias", 0.002) if materials else 0.002)
            
            if shadow_matrix is not None and materials and materials.get("show_shadows", True):
                glUniform1i(glGetUniformLocation(self.prog, "uUseShadows"), 1)
                glUniformMatrix4fv(glGetUniformLocation(self.prog, "uShadowMatrix"), 1, GL_FALSE, shadow_matrix.T)
                glUniform1f(glGetUniformLocation(self.prog, "uShadowSize"), float(shadow_size))
                
                glActiveTexture(GL_TEXTURE0)
                glBindTexture(GL_TEXTURE_2D, shadow_map)
                glUniform1i(glGetUniformLocation(self.prog, "uShadowMap"), 0)
            else:
                glUniform1i(glGetUniformLocation(self.prog, "uUseShadows"), 0)
        else:
            glUniform1i(glGetUniformLocation(self.prog, "uUseShadows"), 0)
        
        glBindVertexArray(self.vao)
        glDrawElements(GL_TRIANGLES, self.count, GL_UNSIGNED_INT, None)
        glBindVertexArray(0)
