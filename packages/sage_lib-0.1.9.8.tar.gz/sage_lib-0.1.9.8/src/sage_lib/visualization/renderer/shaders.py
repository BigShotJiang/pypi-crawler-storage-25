from __future__ import annotations
# ============================
# shaders.py — GLSL Shader Sources
# ============================

# -- Sphere Vertex Shader --
SPHERE_VS = r"""#version 330 core
layout(location=0) in vec2 aQuad;
uniform mat4 uView; uniform mat4 uProj;
uniform samplerBuffer uAtomPosRad; uniform samplerBuffer uAtomColor;
uniform samplerBuffer uReplicaOffsets;
uniform usamplerBuffer uVisiblePairs; 
uniform usamplerBuffer uSelectionMaskFull; 
uniform int uSelectionOnly;
uniform int uVisibleCount;
uniform int uIsOrtho;
uniform float uAtomScale;
uniform float uProjScale;
uniform float uViewportHeight;
uniform float uTime;
uniform int uPrettyRender;
uniform float uPulseSpeed;
uniform float uPulseAmp;
uniform float uPointPx;

out vec3 v_centerVS; 
out float v_radiusVS; 
out vec4 v_color; 
out vec3 v_posVS; 
out float v_pixelRadius; 
out vec2 v_quadCoord;
flat out int v_atomIdx;
flat out int v_repIdx;

void main(){
    int inst = gl_InstanceID;
    uvec2 pair = texelFetch(uVisiblePairs, inst).rg;
    int atomIdx = int(pair.x);
    int repIdx = int(pair.y);
    
    vec4 posRad = texelFetch(uAtomPosRad, atomIdx);
    vec4 color = texelFetch(uAtomColor, atomIdx);
    vec3 offset = texelFetch(uReplicaOffsets, repIdx).xyz;

    if (uSelectionOnly != 0) {
        uint selected = texelFetch(uSelectionMaskFull, atomIdx).r;
        if (selected == 0u) {
            gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
            return;
        }
    }

    vec3 centerWorld = posRad.xyz + offset;
    float radius = posRad.w * uAtomScale;
    if (uPrettyRender != 0 && uPulseAmp > 0.0) {
        radius *= (1.0 + uPulseAmp * sin(uTime * uPulseSpeed + float(atomIdx) * 0.5));
    }
    vec4 centerView4 = uView * vec4(centerWorld, 1.0);
    vec3 centerView = centerView4.xyz;
    
    float pixel_radius;
    if (uIsOrtho != 0) {
        pixel_radius = radius * uProjScale; 
    } else {
        pixel_radius = radius * uProjScale / abs(centerView.z);
    }
    
    vec3 posVS = centerView + vec3(aQuad * radius * 1.05, 0.0);
    v_centerVS = centerView; v_radiusVS = radius; v_color = color; v_posVS = posVS; 
    v_pixelRadius = pixel_radius;
    v_quadCoord = aQuad * 1.05; 
    v_atomIdx = atomIdx;
    v_repIdx = repIdx;
    
    gl_Position = uProj * vec4(posVS, 1.0);
}
"""

# -- Sphere Picking Vertex Shader (Hardened) --
PICK_SPHERE_VS = r"""#version 330 core
layout(location=0) in vec2 aQuad;
uniform mat4 uView; uniform mat4 uProj;
uniform samplerBuffer uAtomPosRad;
uniform samplerBuffer uReplicaOffsets;
uniform usamplerBuffer uVisiblePairs; 
uniform int uIsOrtho;
uniform float uAtomScale;
uniform int uHoverAtomIdx;

out vec3 v_centerVS; 
out float v_radiusVS; 
out vec3 v_posVS; 
out vec2 v_quadCoord;
flat out int v_atomIdx;
flat out int v_repIdx;

void main(){
    int inst = gl_InstanceID;
    uvec2 pair = texelFetch(uVisiblePairs, inst).rg;
    int atomIdx = int(pair.x);
    int repIdx = int(pair.y);
    
    vec4 posRad = texelFetch(uAtomPosRad, atomIdx);
    vec3 offset = texelFetch(uReplicaOffsets, repIdx).xyz;

    vec3 centerWorld = posRad.xyz + offset;
    bool isHovered = (atomIdx == uHoverAtomIdx);
    float radius = posRad.w * uAtomScale * (isHovered ? 1.12 : 1.0); // 12% size boost for hover
    
    vec4 centerView4 = uView * vec4(centerWorld, 1.0);
    vec3 centerView = centerView4.xyz;
    
    vec3 posVS = centerView + vec3(aQuad * radius * 1.05, 0.0);
    v_centerVS = centerView; v_radiusVS = radius; v_posVS = posVS; 
    v_quadCoord = aQuad * 1.05; 
    v_atomIdx = atomIdx;
    
    gl_Position = uProj * vec4(posVS, 1.0);
}
"""

# -- Sphere Fragment Shader --
SPHERE_FS = r"""#version 330 core
in vec3 v_centerVS; 
in float v_radiusVS; 
in vec4 v_color; 
in vec3 v_posVS; 
in float v_pixelRadius; 
in vec2 v_quadCoord;
flat in int v_atomIdx;
flat in int v_repIdx;

uniform mat4 uProj; 
uniform mat4 uViewInv;
uniform mat4 uShadowMatrix;
uniform int uIsOrtho;
uniform usamplerBuffer uSelectedAtoms; 
uniform usamplerBuffer uSelectionMaskFull;
uniform int uSelectedCount;
uniform int uHoverAtomIdx;
out vec4 FragColor;

const int MAX_LIGHTS = 4;
uniform vec3 uLightDir[MAX_LIGHTS];
uniform vec3 uLightCol[MAX_LIGHTS];
uniform int uNumLights;
uniform samplerBuffer uAtomPosRad; 
uniform int uAtomCount;
uniform samplerBuffer uAtomMaterial; 
uniform sampler2DShadow uShadowMap;
uniform float uExposure;
uniform float uHeadlight;
uniform int uShowShadows;
uniform int uShowGroundShadow;
uniform float uShadowIntensity;
uniform float uShadowSoftness;
uniform float uShadowBias;
uniform float uShadowSize;
uniform float uSkipPx;
uniform float uPointPx;
uniform int uPrettyRender;
uniform float uReflectionIntensity;
uniform float uReflectionGloss;
uniform float uFogDensity;
uniform samplerBuffer uAtomMaterial2;
uniform float uSelectionGlow;
uniform float uTime;
uniform int uShadingTier; // 0: Fast (Point), 1: Simple, 2: HQ
uniform float uReplicaDimming;

uniform int uSelectionOnly;
uniform int uIsGhost;

void main(){
    if (uSelectionOnly != 0) {
        float distSq_unit = dot(v_quadCoord, v_quadCoord);
        if (distSq_unit > 1.0) discard;
        FragColor = vec4(1.0); 
        return; 
    }
    
    if (v_pixelRadius < 0.02) discard; // Safe minimum
    if (v_color.a < 0.01) discard;     // Alpha discard

    float rSq = dot(v_quadCoord, v_quadCoord);
    if (rSq > 1.0) discard;

    // ---------------------------------------------------------
    // Shared Sphere Surface Reconstruction
    // ---------------------------------------------------------
    vec3 rayDir, sphereCenter, surfVS;
    float r = v_radiusVS;
    sphereCenter = v_centerVS;

    if (uIsOrtho != 0) {
        float z_local = sqrt(1.0 - rSq) * r;
        surfVS = vec3(v_posVS.xy, sphereCenter.z + z_local);
        rayDir = vec3(0.0, 0.0, -1.0);
    } else {
        rayDir = normalize(v_posVS);
        float b = dot(rayDir, sphereCenter);
        float c = dot(sphereCenter, sphereCenter) - r*r;
        float h = b*b - c;
        if (h < 0.0) discard;
        float t = b - sqrt(h);
        surfVS = rayDir * t;
    }
    
    // Always write correct sphere depth, even in normal/LOD modes
    vec4 clipPos = uProj * vec4(surfVS, 1.0);
    gl_FragDepth = (clipPos.z / clipPos.w) * 0.5 + 0.5 - 1e-6;

    vec3 N = normalize(surfVS - sphereCenter);
    vec3 V = -rayDir;

    // ---------------------------------------------------------
    // Hover & Selection Highlight (Applied before tiered returns)
    // ---------------------------------------------------------
    bool hovered = (v_atomIdx == uHoverAtomIdx);
    float pulse = 1.0;
    if (hovered) {
        pulse = 0.5 + 0.5 * sin(uTime * 4.0);
    }
    
    // ---------------------------------------------------------
    // Tier 0: Ultra-Cheap Flat Shading
    // ---------------------------------------------------------
    if (uPrettyRender == 0 && uShadingTier == 0) {
        vec3 base = v_color.rgb * 0.92;
        if (uint(texelFetch(uSelectionMaskFull, v_atomIdx).r) > 0u) {
            base = mix(base, vec3(1.0, 0.9, 0.1), 0.35);
        }
        if (hovered) {
            base = mix(base, vec3(1.0, 0.8, 0.1), 0.2 + 0.3 * pulse);
        }
        FragColor = vec4(base, v_color.a);
        return;
    }

    // ---------------------------------------------------------
    // Tier 1: Balanced Shaded Sphere
    // ---------------------------------------------------------
    if (uPrettyRender == 0 && (uShadingTier == 1 || uShadingTier == 2)) {
        vec3 L = normalize(vec3(-0.35, 0.35, 1.0));
        float diff = max(dot(N, L), 0.0);
        float light = 0.22 + 0.78 * diff;
        vec3 base = v_color.rgb * light;

        vec3 H = normalize(L + vec3(0.0, 0.0, 1.0));
        float spec = pow(max(dot(N, H), 0.0), 10.0);
        base += vec3(0.08) * spec;

        if (uint(texelFetch(uSelectionMaskFull, v_atomIdx).r) > 0u) {
            base = mix(base, vec3(1.0, 0.9, 0.1), 0.35);
        }
        if (hovered) {
            base = mix(base, vec3(1.0, 0.8, 0.1), 0.2 + 0.3 * pulse);
        }
        FragColor = vec4(base, v_color.a);
        return;
    }

    // ---------------------------------------------------------
    // Tier 2: HQ Ray-Sphere Path (Reserved for Pretty Render)
    // ---------------------------------------------------------
    if (uPrettyRender == 0) {
         FragColor = vec4(v_color.rgb * (0.3 + 0.7*max(dot(N, vec3(0,0,1)),0.0)), v_color.a);
         return;
    }

    float visibility = 1.0;
    // --- Tiered Shadow Pass ---
    if (uShowShadows != 0) {
        vec3 worldPos = (uViewInv * vec4(surfVS, 1.0)).xyz;
        vec4 sc = uShadowMatrix * vec4(worldPos, 1.0);
        vec3 shadowCoord = sc.xyz / sc.w;
        
        vec3 L0 = normalize(uLightDir[0]);
        float rawNdotL = dot(N, L0);
        float bias = max(uShadowBias * (1.0 - rawNdotL), 0.005);
        
        if (uShadingTier >= 2) {
            float texelSize = 1.0 / (uShadowSize + 1e-9);
            float shadow = 0.0;
            for (int x = -1; x <= 1; ++x) {
                for (int y = -1; y <= 1; ++y) {
                    vec2 offs = vec2(x, y) * uShadowSoftness * texelSize;
                    shadow += texture(uShadowMap, vec3(shadowCoord.xy + offs, shadowCoord.z - bias));
                }
            }
            visibility = shadow / 9.0;
        } else {
            visibility = texture(uShadowMap, vec3(shadowCoord.xy, shadowCoord.z - bias));
        }
        
        float fade = clamp(rawNdotL * 1.5 + 0.5, 0.0, 1.0);
        visibility = mix(1.0, visibility, uShadowIntensity * fade);
    }

    vec4 m1 = texelFetch(uAtomMaterial, v_atomIdx);
    float ambient = (uShadingTier >= 2) ? max(0.25, m1.r) : 0.4;
    float specular = (uShadingTier >= 2) ? m1.g : 0.6;
    float shininess = (uShadingTier >= 2) ? m1.b : 48.0;
    
    vec3 totalDiff = vec3(0.0);
    vec3 totalSpec = vec3(0.0);
    
    // Light Passes
    {
        vec3 L = vec3(0.0, 0.0, 1.0);
        float d = dot(N, L) * 0.5 + 0.5;
        d = d * d;
        totalDiff += d * uHeadlight * vec3(1.0);
        if (uShadingTier >= 2) {
            float s = pow(max(dot(N, normalize(L + V)), 0.0), shininess);
            totalSpec += s * specular * uHeadlight * vec3(1.0);
        }
    }

    for(int i = 0; i < uNumLights; i++){
        vec3 L = normalize(uLightDir[i]); 
        float rawNdotL = dot(N, L);
        float d = rawNdotL * 0.5 + 0.5;
        d = d * d; 
        float l_vis = (i == 0) ? visibility : 1.0;
        totalDiff += l_vis * d * uLightCol[i];
        if (uShadingTier >= 2) {
            vec3 H = normalize(L + V);
            float s = pow(max(dot(N, H), 0.0), shininess);
            totalSpec += l_vis * s * specular * uLightCol[i];
        }
    }
    
    vec3 finalCol;
    if (uShadingTier >= 2) {
        finalCol = v_color.rgb * (vec3(ambient) + totalDiff) + totalSpec;
        finalCol *= uExposure;
    } else {
        finalCol = v_color.rgb * (ambient + totalDiff);
    }

    float z_f = abs(surfVS.z);
    float fog = exp(-z_f * uFogDensity * 2.0);
    finalCol = mix(vec3(0.01, 0.01, 0.02), finalCol, fog);

    if (uint(texelFetch(uSelectionMaskFull, v_atomIdx).r) > 0u) {
        finalCol = mix(finalCol, vec3(1.0, 0.9, 0.1), 0.3) * 1.2;
    }
    
    if (v_atomIdx == uHoverAtomIdx) {
        float pulse = 0.5 + 0.5 * sin(uTime * 4.0); // 4 rad/s pulse
        
        // Prominent Amber/Yellow glow
        finalCol = mix(finalCol, vec3(1.0, 0.8, 0.1), 0.2 + 0.3 * pulse);
        
        // Brighter Yellow Ring with breathing effect
        float ringThresh = 0.81 - 0.05 * pulse; 
        if (rSq > ringThresh) {
            FragColor = vec4(1.0, 0.9 + 0.1 * pulse, 0.2, 1.0);
            return;
        }
    }
    
    if (v_repIdx > 0) {
        finalCol *= uReplicaDimming;
    }
    
    if (uIsGhost != 0) {
        if (rSq > 0.86) {
            FragColor = vec4(1.0, 0.1, 0.1, 1.0); // Vibrant red glowing outline
            return;
        }
    }
    
    FragColor = vec4(finalCol, v_color.a);
}
"""

# -- Sphere Picking Fragment Shader (Writes 32-bit uint ID) --
PICK_SPHERE_FS = r"""#version 330 core
in vec3 v_centerVS; 
in float v_radiusVS; 
in vec2 v_quadCoord;
in vec3 v_posVS;
flat in int v_atomIdx;

uniform mat4 uProj;
uniform int uIsOrtho;
uniform uint uIDOffset;

layout (location = 0) out uint FragID;

void main(){
    float rSq = dot(v_quadCoord, v_quadCoord);
    if (rSq > 1.0) discard;

    // Same raycasting as standard pass to ensure depth parity
    vec3 sphereCenter = v_centerVS;
    float r = v_radiusVS;
    vec3 surfVS;
    if (uIsOrtho != 0) {
        float z_local = sqrt(1.0 - rSq) * r;
        surfVS = vec3(v_posVS.xy, sphereCenter.z + z_local);
    } else {
        vec3 rayDir = normalize(v_posVS);
        float b = dot(rayDir, sphereCenter);
        float c = dot(sphereCenter, sphereCenter) - r*r;
        float h = b*b - c;
        if (h < 0.0) discard;
        surfVS = rayDir * (b - sqrt(h));
    }
    vec4 clipPos = uProj * vec4(surfVS, 1.0);
    gl_FragDepth = (clipPos.z / clipPos.w) * 0.5 + 0.5 - 1e-6;

    FragID = uIDOffset + uint(v_atomIdx);
}
"""

SHADOW_VS = r"""#version 330 core
layout(location=0) in vec2 aQuad;
uniform mat4 uView; uniform mat4 uProj;
uniform samplerBuffer uAtomPosRad;
uniform samplerBuffer uReplicaOffsets;
uniform usamplerBuffer uVisiblePairs;
uniform int uVisibleCount;
uniform float uAtomScale;
out VS_OUT { vec3 centerVS; float radiusVS; vec3 posVS; } v;
void main(){
    int inst = gl_InstanceID;
    uvec2 pair = texelFetch(uVisiblePairs, inst).rg;
    int atomIdx = int(pair.x);
    int repIdx = int(pair.y);
    vec4 posRad = texelFetch(uAtomPosRad, atomIdx);
    vec3 offset = texelFetch(uReplicaOffsets, repIdx).xyz;
    vec3 centerWorld = posRad.xyz + offset;
    float radius = posRad.w * uAtomScale;
    vec4 centerView4 = uView * vec4(centerWorld, 1.0);
    v.centerVS = centerView4.xyz;
    v.radiusVS = radius;
    v.posVS = v.centerVS + vec3(aQuad * radius, 0.0);
    gl_Position = uProj * vec4(v.posVS, 1.0);
}
"""

SHADOW_FS = r"""#version 330 core
in VS_OUT { 
    vec3 centerVS; 
    float radiusVS; 
    vec3 posVS; 
} v;
uniform mat4 uProj; 
void main() {
    vec2 coord = v.posVS.xy - v.centerVS.xy;
    float distSq = dot(coord, coord);
    float rSq = v.radiusVS * v.radiusVS;
    if (distSq > rSq) discard;
    float zw = sqrt(rSq - distSq);
    vec3 surfVS = v.centerVS + vec3(coord, zw);
    vec4 clipPos = uProj * vec4(surfVS, 1.0);
    gl_FragDepth = (clipPos.z / clipPos.w) * 0.5 + 0.5;
}
"""

# -- Ground Shaders --
# -- Line Shaders --
LINE_VS = r"""#version 330 core
layout(location=0) in vec3 aPos;
uniform mat4 uView; uniform mat4 uProj; uniform samplerBuffer uReplicaOffsets;
void main(){
    int inst = gl_InstanceID;
    vec3 offset = texelFetch(uReplicaOffsets, inst).xyz;
    gl_Position = uProj * uView * vec4(aPos + offset, 1.0);
}
"""
LINE_FS = r"""#version 330 core
uniform vec4 uRGBA;
out vec4 FragColor;
void main(){
    FragColor = uRGBA;
}
"""

SHADOW_CYLINDER_VS = r"""#version 330 core
layout(location=0) in vec3 aPos;     
uniform mat4 uView; uniform mat4 uProj;
uniform samplerBuffer uReplicaOffsets;
uniform samplerBuffer uBondData; 
uniform usamplerBuffer uVisiblePairs; // .r = bondIdx, .g = repIdx
uniform float uBondScale; 
void main(){
    int inst = gl_InstanceID;
    int pairIdx = inst / 2;
    int side = inst % 2;

    uvec2 pair     = texelFetch(uVisiblePairs, pairIdx).rg;
    int physIdx   = int(pair.r);
    int repIdx    = int(pair.g);
    int halfIdx   = 2 * physIdx + side;
    
    vec3 offset   = texelFetch(uReplicaOffsets, repIdx).xyz;
    vec3 iStart   = texelFetch(uBondData, 4 * halfIdx + 0).xyz;
    vec3 iEnd     = texelFetch(uBondData, 4 * halfIdx + 1).xyz;
    float iAlpha  = texelFetch(uBondData, 4 * halfIdx + 2).a;
    
    if (iAlpha < 0.01) { gl_Position = vec4(2.0); return; }
    
    vec3 p0 = iStart + offset;
    vec3 p1 = iEnd + offset;
    vec3 dir = p1 - p0;
    float h = length(dir);
    if(h < 0.0001) { gl_Position = vec4(2.0); return; }
    
    vec3 v = normalize(dir);
    vec3 a = (abs(v.y) < 0.999) ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 u = normalize(cross(a, v));
    vec3 w = normalize(cross(v, u));

    vec3 centerPoint = mix(p0, p1, aPos.y); 
    vec3 offsetCenter = aPos.x * uBondScale * u + aPos.z * uBondScale * w;
    
    vec3 worldPos = centerPoint + offsetCenter;

    gl_Position = uProj * uView * vec4(worldPos, 1.0);
}
"""
SHADOW_CYLINDER_FS = r"""#version 330 core
void main() {}
"""

# -- Bond Picking Vertex Shader (Hardened) --
PICK_BOND_VS = r"""#version 330 core
layout(location=0) in vec3 aPos;     
uniform mat4 uView; uniform mat4 uProj;
uniform samplerBuffer uReplicaOffsets;
uniform samplerBuffer uBondData; 
uniform usamplerBuffer uVisiblePairs;
uniform float uBondScale;   
flat out int vAtomIdx;

void main(){
    int inst = gl_InstanceID;
    int pairIdx = inst / 2;
    int side = inst % 2;

    uvec2 pair      = texelFetch(uVisiblePairs, pairIdx).rg;
    int physIdx   = int(pair.r);
    int repIdx    = int(pair.g);
    int halfIdx  = 2 * physIdx + side;
    
    vec3 offset  = texelFetch(uReplicaOffsets, repIdx).xyz;
    vec3 iStart  = texelFetch(uBondData, 4 * halfIdx + 0).xyz;
    vec3 iEnd    = texelFetch(uBondData, 4 * halfIdx + 1).xyz;
    vec4 iMeta   = texelFetch(uBondData, 4 * halfIdx + 3);
    
    int atomIdx   = int(iMeta.x + 0.5);

    vec3 p0 = iStart + offset;
    vec3 p1 = iEnd + offset;
    vec3 dir = p1 - p0;
    float h = length(dir);
    if(h < 0.0001) { gl_Position = vec4(2.0); return; }
    
    vec3 v = normalize(dir);
    vec3 a = (abs(v.y) < 0.999) ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 u = normalize(cross(a, v));
    vec3 w = normalize(cross(v, u));
    
    vec3 centerPoint = mix(p0, p1, aPos.y); 
    vec3 offsetCenter = aPos.x * uBondScale * u + aPos.z * uBondScale * w;
    
    vec3 worldPos = centerPoint + offsetCenter;
    vAtomIdx = atomIdx;
    
    gl_Position = uProj * uView * vec4(worldPos, 1.0);
}
"""

# -- Cylinder Shader (Instanced) --
CYLINDER_VS = r"""#version 330 core
layout(location=0) in vec3 aPos;     
layout(location=1) in vec3 aNormal;
uniform mat4 uView; uniform mat4 uProj;
uniform samplerBuffer uReplicaOffsets;
uniform samplerBuffer uBondData; 
uniform usamplerBuffer uVisiblePairs; // .r = bondIdx, .g = repIdx
uniform float uBondScale;   
uniform usamplerBuffer uSelectionMaskFull; 
uniform int uSelectionOnly;
out vec3 vNormal; out vec4 vColor; out vec3 vPos;
out float vSelected;
flat out int vAtomIdx;
flat out int v_repIdx;
void main(){
    int inst = gl_InstanceID;
    int pairIdx = inst / 2;
    int side = inst % 2;

    uvec2 pair      = texelFetch(uVisiblePairs, pairIdx).rg;
    int physIdx   = int(pair.r);
    int repIdx    = int(pair.g);
    int halfIdx  = 2 * physIdx + side;
    
    vec3 offset  = texelFetch(uReplicaOffsets, repIdx).xyz;
    vec3 iStart  = texelFetch(uBondData, 4 * halfIdx + 0).xyz;
    vec3 iEnd    = texelFetch(uBondData, 4 * halfIdx + 1).xyz;
    vec4 iCol    = texelFetch(uBondData, 4 * halfIdx + 2);
    vec4 iMeta   = texelFetch(uBondData, 4 * halfIdx + 3);
    
    int atomIdx   = int(iMeta.x + 0.5);
    float selFlag = iMeta.z;

    if (uSelectionOnly != 0 && selFlag < 0.5) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        return;
    }

    vec3 p0 = iStart + offset;
    vec3 p1 = iEnd + offset;
    vec3 dir = p1 - p0;
    float h = length(dir);
    if(h < 0.0001) { gl_Position = vec4(2.0); return; }
    
    vec3 v = normalize(dir);
    vec3 a = (abs(v.y) < 0.999) ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 u = normalize(cross(a, v));
    vec3 w = normalize(cross(v, u));
    
    vec3 centerPoint = mix(p0, p1, aPos.y); 
    vec3 offsetCenter = aPos.x * uBondScale * u + aPos.z * uBondScale * w;
    
    vec3 worldPos = centerPoint + offsetCenter;

    // Normal calculation:
    // The normal is simply aPos.x * u + aPos.z * w mapped exactly like the outward radial vector
    vec3 outwardNormal = normalize(aPos.x * u + aPos.z * w);
    vNormal = outwardNormal;
    
    vColor = iCol;
    vPos = worldPos;
    vAtomIdx = atomIdx;
    vSelected = selFlag;
    v_repIdx = repIdx;
    
    gl_Position = uProj * uView * vec4(worldPos, 1.0);
}
"""

CYLINDER_FS = r"""#version 330 core
in vec3 vNormal; in vec4 vColor; in vec3 vPos;
in float vSelected;
flat in int vAtomIdx;
flat in int v_repIdx;
uniform mat4 uView;
uniform mat4 uViewInv;
uniform mat4 uShadowMatrix;
uniform sampler2DShadow uShadowMap;
uniform int uPrettyRender;
uniform int uShowShadows;
uniform float uShadowIntensity;
uniform float uShadowSoftness;
uniform float uShadowBias;
uniform float uShadowSize;
uniform float uReflectionIntensity;
uniform float uReflectionGloss;
uniform float uFogDensity;
uniform float uExposure;
uniform float uHeadlight;
uniform int uShadingTier;
uniform float uReplicaDimming;

const int MAX_LIGHTS = 4;
uniform vec3 uLightDir[MAX_LIGHTS];
uniform vec3 uLightCol[MAX_LIGHTS];
uniform int uNumLights;

uniform vec3 uLightDirVS; 
uniform samplerBuffer uAtomMaterial;
uniform samplerBuffer uAtomMaterial2;
uniform usamplerBuffer uSelectionMaskFull;
uniform int uSelectedCount;
out vec4 FragColor;
uniform int uSelectionOnly;

void main(){
    if (uSelectionOnly != 0) { FragColor = vec4(1.0); return; }
    if (vColor.a < 0.01) discard; // Alpha discard
    
    // ---------------------------------------------------------
    // Tier 0: Flat Shading
    // ---------------------------------------------------------
    if (uPrettyRender == 0 && uShadingTier == 0) {
        FragColor = vec4(vColor.rgb * 0.6, vColor.a);
        return;
    }

    // ---------------------------------------------------------
    // Tier 1: Basic Balanced Lambert
    // ---------------------------------------------------------
    vec4 posView4 = uView * vec4(vPos, 1.0);
    float zVS = -posView4.z; 
    vec3 N = normalize(mat3(uView) * vNormal); 

    if (uPrettyRender == 0 && uShadingTier == 1) {
        vec3 L = vec3(0.0, 0.0, 1.0);
        float diff = 0.4 + 0.6 * max(dot(N, L), 0.0);
        FragColor = vec4(vColor.rgb * diff, vColor.a);
        return;
    }
    
    // ---------------------------------------------------------
    // Tier 2: High-Quality Path (Reserved for Pretty Render)
    // ---------------------------------------------------------
    if (uPrettyRender == 0) {
        // Fallback safety
        FragColor = vec4(vColor.rgb * (0.4 + 0.6 * max(dot(N, vec3(0,0,1)), 0.0)), vColor.a);
        return;
    }

    vec3 V = normalize(-posView4.xyz);
    
    float visibility = 1.0;
    if (uShowShadows != 0) {
        vec4 sc = uShadowMatrix * vec4(vPos, 1.0);
        vec3 shadowCoord = sc.xyz / sc.w;
        vec3 L0 = normalize(uLightDir[0]);
        float rawNdotL = dot(N, L0);
        float bias = max(uShadowBias * (1.0 - rawNdotL), 0.005);
        
        if (uShadingTier >= 2) {
            float texelSize = 1.0 / (uShadowSize + 1e-9);
            float shadow = 0.0;
            for (int x = -1; x <= 1; ++x) {
                for (int y = -1; y <= 1; ++y) {
                    vec2 offs = vec2(x, y) * uShadowSoftness * texelSize;
                    shadow += texture(uShadowMap, vec3(shadowCoord.xy + offs, shadowCoord.z - bias));
                }
            }
            visibility = shadow / 9.0;
        } else {
            visibility = texture(uShadowMap, vec3(shadowCoord.xy, shadowCoord.z - bias));
        }
        
        float fade = clamp(rawNdotL * 1.5 + 0.5, 0.0, 1.0);
        visibility = mix(1.0, visibility, uShadowIntensity * fade);
    }
 
    vec4 m1 = texelFetch(uAtomMaterial, vAtomIdx);
    
    float ambient   = (uShadingTier >= 2) ? max(0.25, m1.r) : 0.4;
    float specular  = (uShadingTier >= 2) ? m1.g : 0.6;
    float shininess = (uShadingTier >= 2) ? m1.b : 48.0;
    
    vec3 totalDiff = vec3(0.0);
    vec3 totalSpec = vec3(0.0);
    
    // 1. Headlight
    {
        vec3 L = vec3(0.0, 0.0, 1.0);
        float d = dot(N, L) * 0.5 + 0.5;
        d = d * d;
        totalDiff += d * uHeadlight * vec3(1.0);
        if (uShadingTier >= 2) {
            float s = pow(max(dot(N, normalize(L + V)), 0.0), shininess);
            totalSpec += s * specular * uHeadlight * vec3(1.0);
        }
    }
 
    // 2. Directional Lights
    for(int i = 0; i < uNumLights; i++){
        vec3 L = normalize(uLightDir[i]); 
        float rawNdotL = dot(N, L);
        float d = rawNdotL * 0.5 + 0.5;
        d = d * d; 
         
        float l_vis = (i == 0) ? visibility : 1.0;
        totalDiff += l_vis * d * uLightCol[i];
        if (uShadingTier >= 2) {
            vec3 H = normalize(L + V);
            float s = pow(max(dot(N, H), 0.0), shininess);
            totalSpec += l_vis * s * specular * uLightCol[i];
        }
    }
    
    vec3 baseColor;
    if (uShadingTier >= 2) {
        baseColor = vColor.rgb * (vec3(ambient) + totalDiff) + totalSpec;
        baseColor *= uExposure;
    } else {
        baseColor = vColor.rgb * (ambient + totalDiff);
    }
    
    // Fog
    float fog = exp(-zVS * uFogDensity * 2.0);
    baseColor = mix(vec3(0.01, 0.01, 0.02), baseColor, fog);
 
    if (vSelected > 0.5) {
        baseColor = mix(baseColor, vec3(1.0, 0.9, 0.1), 0.4) * 1.2;
    }
 
    if (v_repIdx > 0) {
        baseColor *= uReplicaDimming;
    }
 
    FragColor = vec4(baseColor, vColor.a);
}
"""

PICK_BOND_FS = r"""#version 330 core
flat in int vAtomIdx;
uniform uint uIDOffset;
layout (location = 0) out uint FragID;
void main(){
    FragID = uIDOffset + uint(vAtomIdx);
}
"""

# -- Post-Processing Shaders --

FULLSCREEN_VS = r"""#version 330 core
layout(location=0) in vec2 aPos;
out vec2 vUV;
void main(){
    vUV = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

# 1. SSAO Shader (Fast 8-sample
SSAO_FS = r"""#version 330 core
in vec2 vUV;
uniform sampler2D uDepthTex;
uniform mat4 uProj;
uniform mat4 uProjInv;
uniform float uNear;
uniform float uFar;
uniform float uRadius;
uniform float uStrength;
uniform float uBias;
out vec4 FragColor;

uniform int uIsOrtho;

vec3 getViewPos(vec2 uv) {
    float z = texture(uDepthTex, uv).r;
    vec4 clip = vec4(uv * 2.0 - 1.0, z * 2.0 - 1.0, 1.0);
    vec4 view = uProjInv * clip;
    if (uIsOrtho == 0) {
        return view.xyz / max(view.w, 1e-6);
    } else {
        return view.xyz; // w is 1.0 in ortho
    }
}

float rand(vec2 co){
    return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    float zRaw = texture(uDepthTex, vUV).r;
    if (zRaw >= 0.999999) {
        FragColor = vec4(1.0);
        return;
    }

    vec3 fragPos = getViewPos(vUV);

    vec2 texel = 1.0 / vec2(textureSize(uDepthTex, 0));
    float rotation = rand(vUV) * 6.2831853;
    mat2 R = mat2(cos(rotation), -sin(rotation),
                  sin(rotation),  cos(rotation));

    const int SAMPLES = 32;
    float occ = 0.0;

    // Derived world-space radius for distance check
    float worldRadius;
    if (uIsOrtho == 0) {
        worldRadius = uRadius * abs(fragPos.z) * 2.0;
    } else {
        worldRadius = uRadius * (2.0 / uProj[0][0]);
    }

    for (int i = 0; i < SAMPLES; ++i) {
        float t = (float(i) + 0.5) / float(SAMPLES);
        float ang = float(i) * 2.39996323;
        vec2 dir2 = R * vec2(cos(ang), sin(ang));

        vec2 sampleUV = vUV + dir2 * (uRadius * t);
        if (sampleUV.x < 0.0 || sampleUV.x > 1.0 || sampleUV.y < 0.0 || sampleUV.y > 1.0)
            continue;

        vec3 samplePos = getViewPos(sampleUV);
        float diff = samplePos.z - fragPos.z;
        float dist = distance(samplePos, fragPos);

        // Simple robust occlusion: Is the sample closer than frag?
        if (diff > uBias && dist < worldRadius * 2.0) {
            float rangeCheck = smoothstep(0.0, 1.0, worldRadius / dist);
            occ += 1.0 * rangeCheck;
        }
    }

    float ao = 1.0 - uStrength * (occ / float(SAMPLES));
    FragColor = vec4(vec3(clamp(ao, 0.0, 1.0)), 1.0);
}
"""

# 2. Bloom Extract & Blur
BLOOM_EXTRACT_FS = r"""#version 330 core
in vec2 vUV;
uniform sampler2D uColorTex;
uniform float uThreshold;
out vec4 FragColor;
void main(){
    vec3 col = texture(uColorTex, vUV).rgb;
    float brightness = dot(col, vec3(0.2126, 0.7152, 0.0722));
    if (brightness > uThreshold) FragColor = vec4(col, 1.0);
    else FragColor = vec4(0, 0, 0, 1);
}
"""

GAUSSIAN_BLUR_FS = r"""#version 330 core
in vec2 vUV;
uniform sampler2D uImage;
uniform bool uHorizontal;
uniform float uSize;
out vec4 FragColor;
void main(){
    float weight[5] = float[](0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216);
    vec2 tex_offset = 1.0 / textureSize(uImage, 0);
    vec3 result = texture(uImage, vUV).rgb * weight[0];
    if(uHorizontal){
        for(int i=1; i<5; ++i){
            result += texture(uImage, vUV + vec2(tex_offset.x * i, 0.0)).rgb * weight[i];
            result += texture(uImage, vUV - vec2(tex_offset.x * i, 0.0)).rgb * weight[i];
        }
    } else {
        for(int i=1; i<5; ++i){
            result += texture(uImage, vUV + vec2(0.0, tex_offset.y * i)).rgb * weight[i];
            result += texture(uImage, vUV - vec2(0.0, tex_offset.y * i)).rgb * weight[i];
        }
    }
    FragColor = vec4(result, 1.0);
}
"""
GAUSSIAN_BILATERAL_FS = r"""#version 330 core
in vec2 vUV;
uniform sampler2D uImage;
uniform sampler2D uDepthTex;
uniform bool uHorizontal;
uniform float uNear;
uniform float uFar;
out vec4 FragColor;

float getLinearDepth(vec2 uv) {
    float z = texture(uDepthTex, uv).r;
    return (2.0 * uNear * uFar) / (uFar + uNear - (z * 2.0 - 1.0) * (uFar - uNear));
}

void main(){
    float weight[5] = float[](0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216);
    vec2 tex_offset = 1.0 / textureSize(uImage, 0);
    float centerAO = texture(uImage, vUV).r;
    float centerDepth = getLinearDepth(vUV);
    
    float result = centerAO * weight[0];
    float normalization = weight[0];
    
    for(int i=1; i<5; ++i){
        vec2 off = uHorizontal ? vec2(tex_offset.x * i, 0.0) : vec2(0.0, tex_offset.y * i);
        
        // Positive side
        float depthP = getLinearDepth(vUV + off);
        float weightP = weight[i] * max(0.0, 1.0 - abs(centerDepth - depthP) * 2.0);
        result += texture(uImage, vUV + off).r * weightP;
        normalization += weightP;
        
        // Negative side
        float depthN = getLinearDepth(vUV - off);
        float weightN = weight[i] * max(0.0, 1.0 - abs(centerDepth - depthN) * 2.0);
        result += texture(uImage, vUV - off).r * weightN;
        normalization += weightN;
    }
    FragColor = vec4(vec3(result / normalization), 1.0);
}
"""

# 3. Final Resolve (Combine + FXAA + Gamma)
RESOLVE_FS = r"""#version 330 core
in vec2 vUV;
uniform sampler2D uSceneTex;
uniform sampler2D uSSAO;
uniform sampler2D uBloom;
uniform float uBloomIntensity;
uniform bool uEnableSSAO;
uniform bool uEnableBloom;
uniform bool uEnableFXAA;
uniform bool uDebugAO;
uniform sampler2D uDepthTex;
uniform sampler2D uSelectionMask;
uniform int uDebugMode; // 0: None, 1: AO, 2: Raw Depth, 3: Linear Depth
uniform float uGamma;
uniform float uNear;
uniform float uFar;
out vec4 FragColor;

float getLinearDepth(float z) {
    return (2.0 * uNear * uFar) / (uFar + uNear - (z * 2.0 - 1.0) * (uFar - uNear));
}

void main(){
    if (uDebugMode == 1) { // AO Only
        float ao = texture(uSSAO, vUV).r;
        FragColor = vec4(vec3(pow(ao, 2.0)), 1.0);
        return;
    }
    if (uDebugMode == 2) { // Raw Depth (Non-linear)
        float z = texture(uDepthTex, vUV).r;
        FragColor = vec4(vec3(z), 1.0);
        return;
    }
    if (uDebugMode == 3) { // Linear Depth (Normalized)
        float z = texture(uDepthTex, vUV).r;
        float d = getLinearDepth(z);
        float d_norm = clamp((d - uNear) / max(uFar - uNear, 1e-6), 0.0, 1.0);
        FragColor = vec4(vec3(d_norm), 1.0);
        return;
    }
    if (uDebugMode == 4) { // Amplified depth contrast
        float z = texture(uDepthTex, vUV).r;
        float d = getLinearDepth(z);
        float d_norm = clamp((d - uNear) / max(uFar - uNear, 1e-6), 0.0, 1.0);
        float vis = pow(1.0 - d_norm, 6.0);
        FragColor = vec4(vec3(vis), 1.0);
        return;
    }
    
    vec3 color = texture(uSceneTex, vUV).rgb;
    
    if (uEnableSSAO) {
        float ao = texture(uSSAO, vUV).r;
        color *= pow(ao, 4.0); // Extreme AO contrast for 'punchy' look
    }
    
    if (uEnableBloom) {
        vec3 bloom = texture(uBloom, vUV).rgb;
        color += bloom * uBloomIntensity;
    }
    
    if (uEnableFXAA) {
        vec2 off = 1.0 / textureSize(uSceneTex, 0);
        vec3 n = texture(uSceneTex, vUV + vec2(0, off.y)).rgb;
        vec3 s = texture(uSceneTex, vUV - vec2(0, off.y)).rgb;
        vec3 e = texture(uSceneTex, vUV + vec2(off.x, 0)).rgb;
        vec3 w = texture(uSceneTex, vUV - vec2(off.x, 0)).rgb;
        color = (color + n + s + e + w) * 0.2;
    }

    // color = color / (color + vec3(1.0)); // Removed Reinhard compression
    
    // ACES Filmic Tonemapping
    float a = 2.51;
    float b = 0.03;
    float c = 2.43;
    float d = 0.59;
    float e = 0.14;
    vec3 toneMapped = clamp((color*(a*color+b))/(color*(c*color+d)+e), 0.0, 1.0);
    
    // Vignette
    vec2 dist = (vUV - 0.5) * 2.0;
    float vignette = clamp(1.0 - dot(dist, dist) * 0.3, 0.0, 1.0);
    toneMapped *= vignette;

    // Dithering
    float noise = fract(sin(dot(vUV, vec2(12.9898, 78.233))) * 43758.5453) * 0.005;
    toneMapped += noise;

    // Gamma
    vec3 finalColor = pow(toneMapped, vec3(1.0/uGamma));
    
    // 4. Selection Silhouette (Outline)
    // Sobel-ish filter on selection mask
    vec2 tSz = 1.0 / textureSize(uSelectionMask, 0);
    float mask = texture(uSelectionMask, vUV).r;
    float edge = 0.0;
    if (mask == 0.0) {
        float m1 = texture(uSelectionMask, vUV + vec2(tSz.x, 0)).r;
        float m2 = texture(uSelectionMask, vUV - vec2(tSz.x, 0)).r;
        float m3 = texture(uSelectionMask, vUV + vec2(0, tSz.y)).r;
        float m4 = texture(uSelectionMask, vUV - vec2(0, tSz.y)).r;
        if (m1 > 0.0 || m2 > 0.0 || m3 > 0.0 || m4 > 0.0) edge = 1.0;
    }
    
    if (edge > 0.5) {
        finalColor = mix(finalColor, vec3(0.0), 1.0); // Black outline
    }

    FragColor = vec4(finalColor, 1.0);
}
"""

# -- Picking Shaders --
PICK_VS = r"""#version 330 core
layout(location=0) in vec2 aQuad;
uniform mat4 uView;
uniform mat4 uProj;
uniform samplerBuffer uAtomPosRad;
uniform samplerBuffer uReplicaOffsets;
uniform int uAtomCount;
uniform float uAtomScale;

out vec2 vCoord;
out vec3 vCenterVS;
out float vRadiusVS;
out vec3 vPosVS;
flat out vec4 vColor;

void main(){
    int inst = gl_InstanceID;
    int atomIdx = inst % uAtomCount;
    int repIdx  = inst / uAtomCount;

    vec4 posRad = texelFetch(uAtomPosRad, atomIdx);
    vec3 offset = texelFetch(uReplicaOffsets, repIdx).xyz;

    vec3 centerWorld = posRad.xyz + offset;
    float r = posRad.w * uAtomScale;

    vec4 centerView4 = uView * vec4(centerWorld, 1.0);
    vec3 centerView = centerView4.xyz;

    // Match SPHERE_VS footprint exactly (including expansion)
    vec3 posVS = centerView + vec3(aQuad * r * 1.05, 0.0);

    gl_Position = uProj * vec4(posVS, 1.0);

    vCoord = aQuad * 1.05;
    vCenterVS = centerView;
    vRadiusVS = r;
    vPosVS = posVS;

    int id = inst + 1;
    float R = float(id & 0xFF) / 255.0;
    float G = float((id >> 8) & 0xFF) / 255.0;
    float B = float((id >> 16) & 0xFF) / 255.0;
    vColor = vec4(R, G, B, 1.0);
}
"""
PICK_FS = r"""#version 330 core
in vec2 vCoord;
in vec3 vCenterVS;
in float vRadiusVS;
in vec3 vPosVS;
flat in vec4 vColor;

uniform mat4 uProj;

out vec4 FragColor;

void main() {
    float rSqUnit = dot(vCoord, vCoord);
    if (rSqUnit > 1.0) discard;

    // Reconstruct sphere surface depth exactly like visual SPHERE_FS
    // This solves the 'picking furthest atom' bug by providing correct Z occlusions
    float zLocal = sqrt(max(0.0, 1.0 - rSqUnit)) * vRadiusVS;
    vec3 surfVS = vec3(vPosVS.xy, vCenterVS.z + zLocal);

    vec4 clipPos = uProj * vec4(surfVS, 1.0);
    gl_FragDepth = (clipPos.z / clipPos.w) * 0.5 + 0.5 - 1e-6;

    FragColor = vColor;
}
"""

# -- Volume Render Shaders (Raymarching) --
VOLUME_VS = r"""#version 330 core
layout(location=0) in vec3 aPos;
uniform mat4 uView; uniform mat4 uProj;
uniform vec3 uOrigin; uniform vec3 uSize;
out vec3 vPos;
void main(){
    vec3 worldPos = uOrigin + aPos * uSize;
    vPos = worldPos;
    gl_Position = uProj * uView * vec4(worldPos, 1.0);
}
"""

VOLUME_FS = r"""#version 330 core
in vec3 vPos;
uniform vec3 uCamPos;
uniform vec3 uOrigin;
uniform vec3 uSize;
uniform float uIsoLevel;
uniform float uOpacity;
uniform float uStepSize;
uniform int uMode; // 0=Isosurface, 1=MIP 
uniform int uIsSigned;
uniform vec3 uBaseColor;
uniform vec3 uNegColor;
uniform sampler3D uVolume;
out vec4 FragColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void main(){
    vec3 dir = normalize(vPos - uCamPos);
    
    // Ray-box intersection
    vec3 invDir = 1.0 / (dir + 1e-9);
    vec3 t0 = (uOrigin - uCamPos) * invDir;
    vec3 t1 = (uOrigin + uSize - uCamPos) * invDir;
    vec3 tmax = max(t0, t1);
    float tExit = min(min(tmax.x, tmax.y), tmax.z);
    
    float tStart = length(vPos - uCamPos);
    float tEnd = tExit;
    float rayLen = tEnd - tStart;
    if (rayLen <= 0.0) discard;

    // Dithering (Stochastic Jitter) to eliminate banding
    float startOff = hash(gl_FragCoord.xy) * uStepSize;
    
    vec4 accum = vec4(0.0);
    float maxVal = 0.0;
    
    int maxSteps = int(min(256.0, rayLen / uStepSize));
    float lastVal = texture(uVolume, (vPos - uOrigin) / uSize).r;

    for(int i=0; i < maxSteps; i++){
        float t = startOff + float(i) * uStepSize;
        vec3 p = vPos + dir * t;
        vec3 texCoord = (p - uOrigin) / uSize;
        float val = texture(uVolume, texCoord).r;
        
        if (uMode == 0) { // Isosurface
            bool inside = false;
            float targetIso = 0.0;
            
            if (uIsSigned != 0) {
                if (val > (0.5 + uIsoLevel) || val < (0.5 - uIsoLevel)) {
                    inside = true;
                    targetIso = (val > 0.5) ? (0.5 + uIsoLevel) : (0.5 - uIsoLevel);
                }
            } else {
                if (val >= uIsoLevel) {
                    inside = true;
                    targetIso = uIsoLevel;
                }
            }

            if (inside) {
                // Linear Refinement of intersection point
                float f = (targetIso - lastVal) / (val - lastVal + 1e-6);
                vec3 hitP = vPos + dir * (t - uStepSize + f * uStepSize);
                vec3 hitTex = (hitP - uOrigin) / uSize;
                
                vec3 col = (uIsSigned != 0 && val < 0.5) ? uNegColor : uBaseColor;
                
                // Normal Estimation (Central Difference)
                vec3 tSz = vec3(textureSize(uVolume, 0));
                vec3 off = 1.0 / tSz;
                float v_x = texture(uVolume, hitTex + vec3(off.x, 0, 0)).r - texture(uVolume, hitTex - vec3(off.x, 0, 0)).r;
                float v_y = texture(uVolume, hitTex + vec3(0, off.y, 0)).r - texture(uVolume, hitTex - vec3(0, off.y, 0)).r;
                float v_z = texture(uVolume, hitTex + vec3(0, 0, off.z)).r - texture(uVolume, hitTex - vec3(0, 0, off.z)).r;
                vec3 N = -normalize(vec3(v_x, v_y, v_z));
                
                // Blinn-Phong Lighting
                vec3 L = -dir; // Headlamp
                float diff = max(dot(N, L), 0.3);
                
                vec3 H = normalize(L - dir);
                float spec = pow(max(dot(N, H), 0.0), 32.0);
                
                accum = vec4(col * diff + vec3(0.4 * spec), uOpacity);
                break;
            }
        } else { // MIP
            maxVal = max(maxVal, val);
        }
        lastVal = val;
    }
    
    if (uMode == 1) { // MIP Finalize
        if (maxVal < 0.01) discard;
        accum = vec4(uBaseColor * maxVal, maxVal * uOpacity);
    }
    
    if(accum.a < 0.01) discard;
    FragColor = accum;
}
"""

MESH_VS = r"""#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec3 aColor;

uniform mat4 uView;
uniform mat4 uProj;
uniform mat4 uModel;
uniform mat4 uShadowMatrix;
uniform int uUseShadows;

out vec3 vPos;
out vec3 vNormal;
out vec3 vColor;
out vec4 vShadowCoord;

void main(){
    vec4 worldPos = uModel * vec4(aPos, 1.0);
    vPos = worldPos.xyz;
    vNormal = mat3(transpose(inverse(uModel))) * aNormal;
    vColor = aColor;
    
    // Always initialize varying to prevent NaNs on Metal/Apple Silicon
    vShadowCoord = uShadowMatrix * worldPos;
    
    gl_Position = uProj * uView * worldPos;
}
"""

MESH_FS = r"""#version 330 core
in vec3 vPos;
in vec3 vNormal;
in vec3 vColor;
in vec4 vShadowCoord;

uniform vec3 uCamPos;
uniform vec3 uColor; // Fallback or tint
uniform float uOpacity;
uniform int uPrettyRender;
uniform int uUseVertexColors;

// New Lighting and Material parameters
uniform vec3 uLightDir;
uniform int uUseShadows;
uniform float uShadowIntensity;
uniform float uShadowBias;
uniform sampler2DShadow uShadowMap;
uniform float uShadowSize;
uniform int uIsOIT;

layout(location = 0) out vec4 oitAccum;
layout(location = 1) out float oitReveal;
layout(location = 2) out vec4 oitFragColor;

// PCF Shadow computation function
float ShadowCalculation(vec4 fragPosLightSpace, vec3 N, vec3 L) {
    if (uUseShadows == 0) return 0.0;
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    if(projCoords.z > 1.0) return 0.0;
    
    // Slight normal bias to avoid acne
    float bias = max(uShadowBias * (1.0 - dot(N, L)), uShadowBias * 0.1);
    
    float shadow = 0.0;
    vec2 texelSize = vec2(1.0 / uShadowSize);
    
    // Very simple 3x3 PCF
    for(int x = -1; x <= 1; ++x) {
        for(int y = -1; y <= 1; ++y) {
            float pcfDepth = texture(uShadowMap, vec3(projCoords.xy + vec2(x, y) * texelSize, projCoords.z - bias)); 
            shadow += pcfDepth;
        }    
    }
    shadow /= 9.0;
    return 1.0 - shadow; // Returns occlusion
}

void main(){
    vec3 N = normalize(vNormal);
    vec3 V = normalize(uCamPos - vPos);
    
    // Light is either fixed or headlight
    vec3 L = (uPrettyRender != 0) ? normalize(uLightDir) : normalize(uCamPos - vPos);
    
    vec3 baseColor = (uUseVertexColors != 0) ? vColor : uColor;
    
    vec3 finalRGB;
    if (uPrettyRender != 0) {
        // High quality shading
        float shadowOcclusion = ShadowCalculation(vShadowCoord, N, L);
        float occlusion = mix(1.0, 0.2, shadowOcclusion * uShadowIntensity);
        
        float diff = max(dot(N, L), 0.0) * 0.5 + 0.5; // Half-lambert for softer look
        diff *= occlusion;
        
        vec3 H = normalize(L + V);
        float spec = pow(max(dot(N, H), 0.0), 48.0) * occlusion;
        
        float rim = 1.0 - max(dot(V, N), 0.0);
        rim = smoothstep(0.6, 1.0, rim) * occlusion;
        
        vec3 ambient = baseColor * 0.4;
        vec3 diffuse = baseColor * 0.6 * diff;
        vec3 specular = vec3(1.0) * spec * 0.5;
        vec3 rimColor = vec3(1.0) * rim * 0.3;
        
        finalRGB = ambient + diffuse + specular + rimColor;
    } else {
        // Basic shading
        float diff = max(abs(dot(N, L)), 0.2); 
        finalRGB = baseColor * diff;
    }

    if (uIsOIT != 0) {
        // Simplified Linear OIT Weight (synchronized with Polyhedra)
        float alpha = uOpacity;
        float z = gl_FragCoord.z;
        float weight = clamp(alpha * 100.0 * pow(1.0 - z * 0.9, 3.0), 0.01, 3000.0);
        
        oitAccum = vec4(finalRGB * alpha, alpha) * weight;
        oitReveal = alpha;
        oitFragColor = vec4(0.0);
    } else {
        // Standard Opaque/Alpha Blended Path
        oitAccum = vec4(finalRGB, uOpacity);
        oitReveal = 0.0;
        oitFragColor = vec4(0.0);
    }
}
"""

# -- Polyhedron Vertex Shader --
POLY_VS = r"""#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec3 aColor;
layout(location = 3) in uint aID;

uniform mat4 uView;
uniform mat4 uProj;
uniform mat4 uModel;

out vec3 vPos;
out vec3 vNormal;
out vec3 vColor;
flat out uint vID;

void main(){
    vec4 worldPos = uModel * vec4(aPos, 1.0);
    vPos = worldPos.xyz;
    // Simple normal transform (assuming uModel has no non-uniform scale)
    vNormal = mat3(uModel) * aNormal;
    vColor = aColor;
    vID = aID;
    gl_Position = uProj * uView * worldPos;
}
"""

# -- Polyhedron Fragment Shader (OIT Supported) --
POLY_FS = r"""#version 330 core
layout(location = 0) out vec4 oitAccum;
layout(location = 1) out float oitReveal;
layout(location = 2) out vec4 oitFragColor;

in vec3 vPos;
in vec3 vNormal;
in vec3 vColor;
flat in uint vID;

uniform vec3 uCamPos;
uniform float uOpacity;
uniform int uIsOIT;

void main(){
    float alpha = uOpacity;
    vec3 N = vNormal;
    float n_len = length(N);
    if (n_len > 1e-6) {
        N /= n_len;
    } else {
        N = vec3(0, 1, 0); // Fallback
    }
    
    vec3 V = normalize(uCamPos - vPos);
    vec3 L = normalize(vec3(0.5, 0.8, 1.0)); // Fixed Directional Light
    if (!gl_FrontFacing) N = -N; 
    
    float diff = max(dot(N, L), 0.0) * 0.7 + 0.3;
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 32.0) * 0.4;
    
    vec3 finalColor = vColor * diff + vec3(spec);

    if (uIsOIT != 0) {
        float z = gl_FragCoord.z;
        // Simplified Linear OIT Weight for Maximum Stability
        float weight = clamp(alpha * 100.0 * pow(1.0 - z * 0.9, 3.0), 0.01, 3000.0);
        oitAccum = vec4(finalColor * alpha, alpha) * weight;
        oitReveal = alpha;
        oitFragColor = vec4(0.0);
    } else {
        oitAccum = vec4(finalColor, alpha);
        oitReveal = 0.0;
        oitFragColor = vec4(0.0);
    }
}
"""

# -- Polyhedron Picking Fragment Shader --
PICK_POLY_FS = r"""#version 330 core
layout(location = 0) out uint FragID;
flat in uint vID;
void main(){
    FragID = vID;
}
"""

# -- OIT Composition Shader --
OIT_COMPOSITE_FS = r"""#version 330 core
uniform sampler2D uAccum;
uniform sampler2D uReveal;
out vec4 FragColor;

void main() {
    ivec2 coords = ivec2(gl_FragCoord.xy);
    vec4 accum = texelFetch(uAccum, coords, 0);
    float reveal = texelFetch(uReveal, coords, 0).r;

    if (reveal >= 1.0) discard;
    
    vec3 avgColor = accum.rgb / max(accum.a, 0.00001);
    FragColor = vec4(avgColor, 1.0 - reveal);
}
"""
