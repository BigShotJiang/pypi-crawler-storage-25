"""
bond_renderer.py — GPU Impostor Cylinders for Molecular Bonds.
Uses instanced raycasting for high-performance cylinder rendering.
"""
from __future__ import annotations
from OpenGL.GL import *
import numpy as np
from typing import Optional, Tuple, List, Dict
from .shaders import CYLINDER_VS, CYLINDER_FS, SHADOW_CYLINDER_VS, SHADOW_CYLINDER_FS
from .utils import link_program
import ctypes

class BondRenderer:
    """
    Renders bonds as cylinders using GPU raycasting into impostor billboards.
    Supports periodic boundaries and instanced rendering.
    """
    def __init__(self):
        from .shaders import CYLINDER_VS, CYLINDER_FS, SHADOW_CYLINDER_VS, SHADOW_CYLINDER_FS, PICK_BOND_VS, PICK_BOND_FS
        self.prog = link_program(CYLINDER_VS, CYLINDER_FS)
        self.prog_shadow = link_program(SHADOW_CYLINDER_VS, SHADOW_CYLINDER_FS)
        self.prog_pick = link_program(PICK_BOND_VS, PICK_BOND_FS)
        
        # Generation of a Cylinder Mesh (Low-poly for performance)
        res = 12
        vertices = []
        for i in range(res + 1):
            theta = 2.0 * np.pi * i / res
            c, s = np.cos(theta), np.sin(theta)
            # Two vertices per slice (bottom and top)
            # Pos1: (c, 0, s), Normal1: (c, 0, s)
            vertices.extend([c, 0, s, c, 0, s])
            # Pos2: (c, 1, s), Normal2: (c, 0, s)
            vertices.extend([c, 1, s, c, 0, s])
            
        v_data = np.array(vertices, dtype=np.float32)
        self.v_count = (res + 1) * 2
        
        self.vao = glGenVertexArrays(1)
        glBindVertexArray(self.vao)
        self.vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        glBufferData(GL_ARRAY_BUFFER, v_data.nbytes, v_data, GL_STATIC_DRAW)
        
        # Attribute 0: Position (3 floats)
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, ctypes.c_void_p(0))
        # Attribute 1: Normal (3 floats)
        glEnableVertexAttribArray(1)
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, ctypes.c_void_p(12))
        
        glBindVertexArray(0)
        
        # Texture Buffer Objects (TBOs)
        self.pos_bo, self.pos_tbo = glGenBuffers(1), glGenTextures(1)
        self.bond_bo, self.bond_tbo = glGenBuffers(1), glGenTextures(1)
        self.col_bo, self.col_tbo = glGenBuffers(1), glGenTextures(1)
        self.rep_bo, self.rep_tbo = glGenBuffers(1), glGenTextures(1)
        # Selection Pass Data
        self.sel_full_bo, self.sel_full_tbo = glGenBuffers(1), glGenTextures(1)
        
        # Visibility Pass Data (Pre-allocated to avoid Gen/Delete overhead and leaks)
        self.vis_bo, self.vis_tbo = glGenBuffers(1), glGenTextures(1)
        
        # Initialization of state variables to avoid AttributeErrors
        self.num_bonds = 0
        self.replica_count = 0
        self._last_vis_count = 0
        self._last_bond_scale = 0.2

    def upload_data(self, pos: np.ndarray, bonds: np.ndarray, 
                    colors: np.ndarray, lattice: Optional[np.ndarray] = None):
        """
        Packs bond metadata into a TBO-friendly format (4 texels per half-bond).
        Each half-bond needs:
        T0: vec4(start_pos, 1.0)
        T1: vec4(end_pos, 1.0)
        T2: vec4(color_rgba)
        T3: vec4(atom_idx, unused, selected_flag, unused)
        """
        bonds_arr = np.asarray(bonds)
        num_phys_bonds = len(bonds_arr)
        self.num_bonds = num_phys_bonds
        if num_phys_bonds == 0: return

        # 1. Expand to 2 half-bonds per physical bond
        # Each half-bond has 4 texels (RGBA32F)
        bond_data = np.zeros((num_phys_bonds * 2 * 4, 4), dtype=np.float32)
        
        pos_arr = np.asarray(pos)
        col_arr = np.asarray(colors)
        if col_arr.shape[1] == 3:
            # Add alpha
            tmp = np.ones((col_arr.shape[0], 4), dtype=np.float32)
            tmp[:, :3] = col_arr
            col_arr = tmp

        for b in range(num_phys_bonds):
            row = bonds_arr[b]
            i, j = int(row[0]), int(row[1])
            
            # Extract fractional shift (dx, dy, dz) if present, else zero
            shift_idx = row[2:5] if len(row) >= 5 else np.zeros(3, dtype=np.float32)
            
            # World-space shift (using fractional indices vs lattice vectors)
            shift_vec = np.zeros(3, dtype=np.float32)
            if lattice is not None and len(shift_idx) == 3:
                # Fractional to Cartesian: shift_idx @ lattice (if lattice rows are vectors)
                shift_vec = (shift_idx @ lattice).astype(np.float32)
            
            p_i = pos_arr[i]
            p_j = pos_arr[j] + shift_vec
            p_mid = (p_i + p_j) * 0.5
            
            # Half-bond 1 (from i to mid)
            idx1 = b * 8
            bond_data[idx1 + 0, :3] = p_i
            bond_data[idx1 + 0, 3] = 1.0
            bond_data[idx1 + 1, :3] = p_mid
            bond_data[idx1 + 1, 3] = 1.0
            bond_data[idx1 + 2] = col_arr[i]
            bond_data[idx1 + 3, 0] = float(i)
            bond_data[idx1 + 3, 2] = 0.0 # Will be updated by selection later? No, usually static
            
            # Half-bond 2 (from j+shift to mid)
            idx2 = b * 8 + 4
            bond_data[idx2 + 0, :3] = p_j
            bond_data[idx2 + 0, 3] = 1.0
            bond_data[idx2 + 1, :3] = p_mid
            bond_data[idx2 + 1, 3] = 1.0
            bond_data[idx2 + 2] = col_arr[j]
            bond_data[idx2 + 3, 0] = float(j)
            bond_data[idx2 + 3, 2] = 0.0

        # Upload to GPU
        glBindBuffer(GL_TEXTURE_BUFFER, self.bond_bo)
        glBufferData(GL_TEXTURE_BUFFER, bond_data.nbytes, bond_data, GL_DYNAMIC_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.bond_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.bond_bo)
        
        # Atoms positions (RGBA32F is safer than RGB32F on macOS)
        pos_rgba = np.zeros((pos_arr.shape[0], 4), dtype=np.float32)
        pos_rgba[:, :3] = pos_arr
        pos_rgba[:, 3] = 1.0 # unused
        
        glBindBuffer(GL_TEXTURE_BUFFER, self.pos_bo)
        glBufferData(GL_TEXTURE_BUFFER, pos_rgba.nbytes, pos_rgba, GL_DYNAMIC_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.pos_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.pos_bo)

        # Colors
        glBindBuffer(GL_TEXTURE_BUFFER, self.col_bo)
        glBufferData(GL_TEXTURE_BUFFER, colors.nbytes, colors, GL_DYNAMIC_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.col_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.col_bo)

    def upload_replicas(self, offsets: List[np.ndarray]):
        self.replica_count = len(offsets)
        # Use RGBA32F (4-component) for best macOS TBO compatibility
        offsets_rgba = np.zeros((self.replica_count, 4), dtype=np.float32)
        if self.replica_count > 0:
            offsets_arr = np.atleast_2d(offsets)
            offsets_rgba[:, :3] = offsets_arr
            offsets_rgba[:, 3] = 1.0

        glBindBuffer(GL_TEXTURE_BUFFER, self.rep_bo)
        glBufferData(GL_TEXTURE_BUFFER, offsets_rgba.nbytes, offsets_rgba, GL_STATIC_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.rep_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, self.rep_bo)

    def upload_selection(self, selected_ids: list, total_count: int):
        """Uploads list of atom indices currently selected for glowing."""
        # Use RGBA32UI (4-component) for selection mask
        full_rgba = np.zeros((total_count, 4), dtype=np.uint32)
        if selected_ids:
            full_rgba[selected_ids, 0] = 1
            
        glBindBuffer(GL_TEXTURE_BUFFER, self.sel_full_bo)
        glBufferData(GL_TEXTURE_BUFFER, full_rgba.nbytes, full_rgba, GL_DYNAMIC_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.sel_full_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32UI, self.sel_full_bo)

    def draw(self, view: np.ndarray, proj: np.ndarray, vis_pairs: np.ndarray, 
             lights: list, materials: dict, bond_scale: float = 0.2,
             shading_tier: int = 2, pretty_render: bool = True,
             shadow_matrix: Optional[np.ndarray] = None,
             shadow_map: Optional[int] = None, shadow_size: int = 4096,
             reflection_intensity: float = 1.0, reflection_gloss: float = 1.0,
             fog_density: float = 0.002, time: float = 0.0,
             mat_tbo: Optional[int] = None, mat_tbo2: Optional[int] = None,
             ortho_scale: float = 1.0, viewport_height: int = 1000,
             atom_scale: float = 1.0, fov: float = 45.0, is_ortho: bool = False,
             selection_only: bool = False, sel_full_tbo: Optional[int] = None):
        
        vis_pairs_arr = np.asarray(vis_pairs)
        self._last_vis_count = vis_pairs_arr.shape[0]
        self._last_bond_scale = bond_scale
        if self.num_bonds == 0 or self._last_vis_count == 0: return

        glUseProgram(self.prog)
        
        # Matrix and Scalar Uniforms
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uView"), 1, GL_FALSE, view.T)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uProj"), 1, GL_FALSE, proj.T)
        glUniformMatrix4fv(glGetUniformLocation(self.prog, "uViewInv"), 1, GL_FALSE, np.linalg.inv(view).T)
        
        glUniform1f(glGetUniformLocation(self.prog, "uBondScale"), bond_scale)
        glUniform1f(glGetUniformLocation(self.prog, "uTime"), time)
        glUniform1i(glGetUniformLocation(self.prog, "uShadingTier"), int(shading_tier))
        glUniform1i(glGetUniformLocation(self.prog, "uPrettyRender"), 1 if pretty_render else 0)
        glUniform1i(glGetUniformLocation(self.prog, "uSelectionOnly"), 1 if selection_only else 0)
        glUniform1i(glGetUniformLocation(self.prog, "uSelectionFocus"), -1)
        glUniform1f(glGetUniformLocation(self.prog, "uFogDensity"), fog_density)
        glUniform1f(glGetUniformLocation(self.prog, "uReflectionIntensity"), reflection_intensity)
        glUniform1f(glGetUniformLocation(self.prog, "uReflectionGloss"), reflection_gloss)
        glUniform1f(glGetUniformLocation(self.prog, "uReplicaDimming"), materials.get('replica_dimming', 1.0))

        import math
        ps = viewport_height / (ortho_scale if is_ortho else (2.0 * math.tan(math.radians(fov)/2.0)))
        glUniform1f(glGetUniformLocation(self.prog, "uProjScale"), ps)
        glUniform1i(glGetUniformLocation(self.prog, "uIsOrtho"), 1 if is_ortho else 0)
        glUniform1f(glGetUniformLocation(self.prog, "uViewportHeight"), float(viewport_height))

        if shadow_matrix is not None:
             glUniformMatrix4fv(glGetUniformLocation(self.prog, "uShadowMatrix"), 1, GL_FALSE, shadow_matrix.T)
             glUniform1i(glGetUniformLocation(self.prog, "uShowShadows"), 1)
             glUniform1f(glGetUniformLocation(self.prog, "uShadowIntensity"), materials.get('shadow_intensity', 0.6))
             glUniform1f(glGetUniformLocation(self.prog, "uShadowSoftness"), materials.get('shadow_softness', 2.0))
             glUniform1f(glGetUniformLocation(self.prog, "uShadowBias"), materials.get('shadow_bias', 0.001))
             glActiveTexture(GL_TEXTURE11); glBindTexture(GL_TEXTURE_2D, shadow_map)
             glUniform1i(glGetUniformLocation(self.prog, "uShadowMap"), 11)
        else:
             glUniform1i(glGetUniformLocation(self.prog, "uShowShadows"), 0)

        # 1. Multi-Lights
        glUniform1i(glGetUniformLocation(self.prog, "uNumLights"), len(lights))
        vr = view[:3, :3]
        for i, l in enumerate(lights[:4]):
             lv = vr @ np.array(l['pos'], dtype=np.float32)
             glUniform3f(glGetUniformLocation(self.prog, f"uLightDir[{i}]"), *lv)
             glUniform3f(glGetUniformLocation(self.prog, f"uLightCol[{i}]"), *l['col'])
             
        # 2. Materials & Ambient Params
        glUniform1f(glGetUniformLocation(self.prog, "uExposure"), materials.get('exposure', 1.5))
        glUniform1f(glGetUniformLocation(self.prog, "uHeadlight"), materials.get('headlight', 0.8))

        # uVisiblePairs logic - using RGBA32UI (4-component) for macOS TBO stability
        vis_rgba = np.zeros((vis_pairs_arr.shape[0], 4), dtype=np.uint32)
        vis_rgba[:, :2] = vis_pairs_arr.astype(np.uint32)
        
        glBindBuffer(GL_TEXTURE_BUFFER, self.vis_bo)
        glBufferData(GL_TEXTURE_BUFFER, vis_rgba.nbytes, vis_rgba, GL_STREAM_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32UI, self.vis_bo)

        # 5. TBOs (Explicit Units to avoid driver ambiguity)
        glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_BUFFER, self.pos_tbo)
        glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_BUFFER, self.bond_tbo)
        glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_BUFFER, self.col_tbo)
        glActiveTexture(GL_TEXTURE3); glBindTexture(GL_TEXTURE_BUFFER, self.rep_tbo)
        
        # Use provided sel_full_tbo if available, otherwise fallback to internal
        s_tbo = sel_full_tbo if sel_full_tbo is not None else self.sel_full_tbo
        glActiveTexture(GL_TEXTURE4); glBindTexture(GL_TEXTURE_BUFFER, s_tbo)
        glActiveTexture(GL_TEXTURE5); glBindTexture(GL_TEXTURE_BUFFER, mat_tbo if mat_tbo is not None else self.pos_tbo)
        glActiveTexture(GL_TEXTURE6); glBindTexture(GL_TEXTURE_BUFFER, mat_tbo2 if mat_tbo2 is not None else self.pos_tbo)
        glActiveTexture(GL_TEXTURE7); glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)

        glUniform1i(glGetUniformLocation(self.prog, "uAtomPos"), 0)
        glUniform1i(glGetUniformLocation(self.prog, "uBondData"), 1)
        glUniform1i(glGetUniformLocation(self.prog, "uAtomCol"), 2)
        glUniform1i(glGetUniformLocation(self.prog, "uReplicaOffsets"), 3)
        glUniform1i(glGetUniformLocation(self.prog, "uSelectionMaskFull"), 4)
        glUniform1i(glGetUniformLocation(self.prog, "uAtomMaterial"), 5)
        glUniform1i(glGetUniformLocation(self.prog, "uAtomMaterial2"), 6)
        glUniform1i(glGetUniformLocation(self.prog, "uVisiblePairs"), 7)

        glBindVertexArray(self.vao)
        glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, self.v_count, vis_pairs_arr.shape[0] * 2)

    def draw_shadows(self, view: np.ndarray, proj: np.ndarray, vis_pairs: np.ndarray, 
                     scale: float, shadow_fbo: int, shadow_size: int):
        vis_pairs_arr = np.asarray(vis_pairs)
        if self.num_bonds == 0 or vis_pairs_arr.shape[0] == 0: return

        # Save current state
        prev_viewport = glGetIntegerv(GL_VIEWPORT)
        prev_fbo = glGetIntegerv(GL_FRAMEBUFFER_BINDING)

        glBindFramebuffer(GL_FRAMEBUFFER, shadow_fbo)
        glViewport(0, 0, shadow_size, shadow_size)
        glUseProgram(self.prog_shadow)
        
        glUniformMatrix4fv(glGetUniformLocation(self.prog_shadow, "uView"), 1, GL_FALSE, view.T)
        glUniformMatrix4fv(glGetUniformLocation(self.prog_shadow, "uProj"), 1, GL_FALSE, proj.T)
        glUniform1f(glGetUniformLocation(self.prog_shadow, "uBondScale"), scale)
        
        # TBOs
        glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_BUFFER, self.pos_tbo)
        glUniform1i(glGetUniformLocation(self.prog_shadow, "uAtomPos"), 0)
        glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_BUFFER, self.bond_tbo)
        glUniform1i(glGetUniformLocation(self.prog_shadow, "uBondData"), 1)
        glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_BUFFER, self.rep_tbo)
        glUniform1i(glGetUniformLocation(self.prog_shadow, "uReplicaOffsets"), 2)

        # uVisiblePairs for shadows (using RGBA32UI)
        vis_rgba = np.zeros((vis_pairs_arr.shape[0], 4), dtype=np.uint32)
        vis_rgba[:, :2] = vis_pairs_arr.astype(np.uint32)
        
        glBindBuffer(GL_TEXTURE_BUFFER, self.vis_bo)
        glBufferData(GL_TEXTURE_BUFFER, vis_rgba.nbytes, vis_rgba, GL_STREAM_DRAW)
        glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32UI, self.vis_bo)
        
        glActiveTexture(GL_TEXTURE3); glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)
        glUniform1i(glGetUniformLocation(self.prog_shadow, "uVisiblePairs"), 3)

        glBindVertexArray(self.vao)
        glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, self.v_count, vis_pairs_arr.shape[0] * 2)
        glBindVertexArray(0)
        
        # Restore state
        glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo)
        glViewport(*prev_viewport)

    def draw_picking(self, view: np.ndarray, proj: np.ndarray, id_offset: int):
        """Renders bond IDs into the picking buffer."""
        if self.num_bonds == 0: return
        
        glUseProgram(self.prog_pick)
        glEnable(GL_DEPTH_TEST)
        glDepthMask(GL_TRUE)
        glDisable(GL_BLEND)
        
        glUniformMatrix4fv(glGetUniformLocation(self.prog_pick, "uView"), 1, GL_FALSE, view.T)
        glUniformMatrix4fv(glGetUniformLocation(self.prog_pick, "uProj"), 1, GL_FALSE, proj.T)
        glUniform1ui(glGetUniformLocation(self.prog_pick, "uIDOffset"), id_offset)
        glUniform1f(glGetUniformLocation(self.prog_pick, "uBondScale"), getattr(self, '_last_bond_scale', 0.2))
        
        glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_BUFFER, self.pos_tbo)
        glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_BUFFER, self.bond_tbo)
        glActiveTexture(GL_TEXTURE3); glBindTexture(GL_TEXTURE_BUFFER, self.rep_tbo)
        glActiveTexture(GL_TEXTURE7); glBindTexture(GL_TEXTURE_BUFFER, self.vis_tbo)
        
        glUniform1i(glGetUniformLocation(self.prog_pick, "uAtomPos"), 0)
        glUniform1i(glGetUniformLocation(self.prog_pick, "uBondData"), 1)
        glUniform1i(glGetUniformLocation(self.prog_pick, "uReplicaOffsets"), 3)
        glUniform1i(glGetUniformLocation(self.prog_pick, "uVisiblePairs"), 7)

        glBindVertexArray(self.vao)
        # Assuming vis_pairs is still valid or we use the last count
        # Wait, I need to know the instance count. I'll use the one from the last upload.
        count = getattr(self, '_last_vis_count', 0)
        if count > 0:
            glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, self.v_count, count * 2)
        glBindVertexArray(0)
