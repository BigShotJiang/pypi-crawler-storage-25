from __future__ import annotations
from OpenGL.GL import *
import numpy as np
from .utils import link_program
from .shaders import OIT_COMPOSITE_FS

# Simple vertex shader for full-screen quad
QUAD_VS = """#version 330 core
layout (location = 0) in vec2 aPos;
layout (location = 1) in vec2 aTexCoords;
out vec2 vTexCoords;
void main() {
    vTexCoords = aTexCoords;
    gl_Position = vec4(aPos.x, aPos.y, 0.0, 1.0);
}
"""

class QuadRenderer:
    """Utility for rendering full-screen quads (OIT Resolve, post-processing)."""
    def __init__(self):
        # Program for OIT Resolve
        self.oit_prog = link_program(QUAD_VS, OIT_COMPOSITE_FS)
        
        # Geometry: Full-screen quad
        # pos (x, y), uv (u, v)
        verts = np.array([
            -1.0,  1.0, 0.0, 1.0,
            -1.0, -1.0, 0.0, 0.0,
             1.0,  1.0, 1.0, 1.0,
             1.0, -1.0, 1.0, 0.0,
        ], dtype=np.float32)
        
        self.vao = glGenVertexArrays(1)
        self.vbo = glGenBuffers(1)
        
        glBindVertexArray(self.vao)
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        glBufferData(GL_ARRAY_BUFFER, verts.nbytes, verts, GL_STATIC_DRAW)
        
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * 4, ctypes.c_void_p(0))
        glEnableVertexAttribArray(1)
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * 4, ctypes.c_void_p(2 * 4))
        
        glBindVertexArray(0)
        
        # Uniforms
        self.uAccum = glGetUniformLocation(self.oit_prog, "uAccum")
        self.uReveal = glGetUniformLocation(self.oit_prog, "uReveal")

    def draw_oit_resolve(self, accum_tex: int, reveal_tex: int):
        """Composites OIT buffers into the current framebuffer."""
        glUseProgram(self.oit_prog)
        
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, accum_tex)
        glUniform1i(self.uAccum, 0)
        
        glActiveTexture(GL_TEXTURE1)
        glBindTexture(GL_TEXTURE_2D, reveal_tex)
        glUniform1i(self.uReveal, 1)
        
        glBindVertexArray(self.vao)
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4)
        glBindVertexArray(0)
        glUseProgram(0)

    def cleanup(self):
        glDeleteProgram(self.oit_prog)
        glDeleteVertexArrays(1, [self.vao])
        glDeleteBuffers(1, [self.vbo])
