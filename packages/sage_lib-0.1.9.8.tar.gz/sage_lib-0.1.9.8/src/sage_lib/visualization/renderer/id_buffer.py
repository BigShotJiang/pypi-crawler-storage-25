from __future__ import annotations
from OpenGL.GL import *
import numpy as np
from typing import Tuple, Optional

class IDBufferManager:
    """
    Manages an off-screen FBO for picking.
    Substantially improves interaction by allowing selection of 
    discrete primitives (atoms, bonds, polyhedra).
    """
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.fbo = 0
        self.tex_id = 0
        self.depth_rb = 0
        self._init_fbo()

    def _init_fbo(self):
        """Initializes the FBO with a 32-bit unsigned integer color attachment."""
        self.fbo = glGenFramebuffers(1)
        glBindFramebuffer(GL_FRAMEBUFFER, self.fbo)

        # ID Texture (Store 32-bit UI)
        self.tex_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, self.tex_id)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_R32UI, self.width, self.height, 0, GL_RED_INTEGER, GL_UNSIGNED_INT, None)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, self.tex_id, 0)

        # Depth Buffer
        self.depth_rb = glGenRenderbuffers(1)
        glBindRenderbuffer(GL_RENDERBUFFER, self.depth_rb)
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, self.width, self.height)
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, self.depth_rb)

        if glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE:
            raise RuntimeError("ID Pick Framebuffer is incomplete")
            
        glBindFramebuffer(GL_FRAMEBUFFER, 0)

    def resize(self, width: int, height: int):
        if width == self.width and height == self.height:
            return
        self.width, self.height = width, height
        self.cleanup()
        self._init_fbo()

    def bind(self):
        glBindFramebuffer(GL_FRAMEBUFFER, self.fbo)
        glViewport(0, 0, self.width, self.height)
        
        # Clear with 0 (ID 0 = background)
        glClearBufferuiv(GL_COLOR, 0, [0])
        glClear(GL_DEPTH_BUFFER_BIT)

    def unbind(self):
        glBindFramebuffer(GL_FRAMEBUFFER, 0)

    def clear(self):
        """Specifically clears the ID buffer without affecting main rendering state."""
        prev_fbo = glGetIntegerv(GL_FRAMEBUFFER_BINDING)
        glBindFramebuffer(GL_FRAMEBUFFER, self.fbo)
        # Clear with 0 (ID 0 = background)
        glClearBufferuiv(GL_COLOR, 0, [0])
        glClear(GL_DEPTH_BUFFER_BIT)
        glBindFramebuffer(GL_FRAMEBUFFER, prev_fbo)

    def read_pixel(self, x: int, y: int) -> int:
        """Reads the ID value at screen coordinate (x, y)."""
        glBindFramebuffer(GL_READ_FRAMEBUFFER, self.fbo)
        glReadBuffer(GL_COLOR_ATTACHMENT0)
        
        # Flip Y for OpenGL coords (Corrected for 0-based pixel indexing)
        flipped_y = self.height - 1 - y
        
        data = glReadPixels(x, flipped_y, 1, 1, GL_RED_INTEGER, GL_UNSIGNED_INT)
        glBindFramebuffer(GL_READ_FRAMEBUFFER, 0)
        
        # PyOpenGL might return a multidimensional array; use .item() for scalar extraction
        return int(data.item())

    def cleanup(self):
        if self.fbo: glDeleteFramebuffers(1, [self.fbo])
        if self.tex_id: glDeleteTextures(1, [self.tex_id])
        if self.depth_rb: glDeleteRenderbuffers(1, [self.depth_rb])
        self.fbo = 0


class IDRangeMapper:
    """
    Standardizes ID ranges for different objects to avoid collisions.
    """
    def __init__(self, N_atoms: int, n_bonds: int = 0):
        # 0: Background
        # 1..N: Atoms
        # N+1..N+B: Bonds
        # N+B+1..: Derived (Polyhedra, etc.)
        self.atom_offset = 1
        self.bond_offset = self.atom_offset + N_atoms
        self.poly_offset = self.bond_offset + n_bonds
        self.voro_offset = self.poly_offset + N_atoms # assuming 1 poly per atom max

    def get_atom_id(self, idx: int) -> int:
        return self.atom_offset + idx

    def get_bond_id(self, idx: int) -> int:
        return self.bond_offset + idx

    def get_poly_id(self, idx: int) -> int:
        return self.poly_offset + idx
        
    def resolve_id(self, picking_id: int) -> Tuple[str, int]:
        """Maps a picking ID back to a category and index."""
        if picking_id == 0:
            return "background", -1
        if picking_id < self.bond_offset:
            return "atom", picking_id - self.atom_offset
        if picking_id < self.poly_offset:
            return "bond", picking_id - self.bond_offset
        if picking_id < self.voro_offset:
             return "polyhedron", picking_id - self.poly_offset
        return "unknown", picking_id
