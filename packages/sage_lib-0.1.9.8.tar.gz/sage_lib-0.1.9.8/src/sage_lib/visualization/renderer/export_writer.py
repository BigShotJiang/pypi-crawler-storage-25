from __future__ import annotations
import os
import json
import queue
import threading
import time
from typing import List, Dict, Any, Optional
import PIL.Image as Image

class AsyncSequenceWriter:
    """
    Handles asynchronous encoding and saving of images to disk.
    Prevents the render thread from stalling during expensive PNG compression.
    """
    def __init__(self, output_dir: str, metadata: Optional[Dict[str, Any]] = None):
        self.output_dir = output_dir
        self.metadata = metadata or {}
        self.queue = queue.Queue(maxsize=120) # Buffer up to 2-4 seconds of frames
        self.active = True
        self.total_submitted = 0
        self.total_written = 0
        
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        # Start the worker thread
        self.thread = threading.Thread(target=self._worker_loop, daemon=True)
        self.thread.start()
        
        # Save initial manifest
        self._save_manifest()

    def submit_frame(self, frame_num: int, image_data: bytes, size: tuple[int, int], options: Dict[str, Any]):
        """
        Submits a raw RGB buffer for encoding.
        
        Args:
            frame_num: Target frame number (used for zero-padded filename)
            image_data: Raw bytes from glReadPixels
            size: (width, height)
            options: Save options (compression_level, optimize, etc.)
        """
        if not self.active: return
        
        # We push the raw data to the queue. The worker thread handles conversion to PIL.
        self.queue.put((frame_num, image_data, size, options))
        self.total_submitted += 1

    def finish(self):
        """Signals the worker to finish and waits for all writes to complete."""
        print(f"[ExportWriter] Finalizing... ({self.total_written}/{self.total_submitted} frames written)")
        self.active = False
        self.queue.put(None) # Sentinel to stop worker
        self.thread.join()
        
        # Final manifest update
        self.metadata["total_frames"] = self.total_written
        self._save_manifest()
        
        # Post-process: GIF generation
        if self.metadata.get("save_gif", False) and self.total_written > 1:
            self._compile_gif()
            
        print(f"[ExportWriter] Export complete. Saved to {self.output_dir}")

    def _compile_gif(self):
        """Compiles the saved PNG frames into a single GIF."""
        try:
            print("[ExportWriter] Compiling GIF...")
            fps = self.metadata.get("fps", 30)
            ms_per_frame = int(1000.0 / fps)
            scale = self.metadata.get("gif_downscale", 1.0)
            
            gif_frames = []
            for i in range(self.total_written):
                filename = f"frame_{i:06d}.png"
                path = os.path.join(self.output_dir, filename)
                if not os.path.exists(path): continue
                
                img = Image.open(path)
                if scale < 0.99:
                    w, h = img.size
                    img = img.resize((int(w * scale), int(h * scale)), Image.Resampling.LANCZOS)
                
                gif_frames.append(img)
            
            if gif_frames:
                gif_path = os.path.join(self.output_dir, "sequence.gif")
                gif_frames[0].save(
                    gif_path,
                    save_all=True,
                    append_images=gif_frames[1:],
                    duration=ms_per_frame,
                    loop=0 if self.metadata.get("gif_loop", True) else None,
                    optimize=True
                )
                print(f"[ExportWriter] GIF saved to {gif_path}")
                
        except Exception as e:
            print(f"[ExportWriter] GIF compilation failed: {e}")

    def _save_manifest(self):
        manifest_path = os.path.join(self.output_dir, "manifest.json")
        with open(manifest_path, "w") as f:
            json.dump(self.metadata, f, indent=4)

    def _worker_loop(self):
        while True:
            item = self.queue.get()
            if item is None:
                break
                
            frame_num, data, size, options = item
            try:
                # Convert raw RGB to PIL
                img = Image.frombytes("RGB", size, data)
                img = img.transpose(Image.FLIP_TOP_BOTTOM)
                
                filename = f"frame_{frame_num:06d}.png"
                path = os.path.join(self.output_dir, filename)
                
                # PNG Save
                img.save(
                    path, 
                    optimize=options.get('optimize', True),
                    compress_level=options.get('compress_level', 6)
                )
                self.total_written += 1
                
            except Exception as e:
                print(f"[ExportWriter] Error writing frame {frame_num}: {e}")
            finally:
                self.queue.task_done()
