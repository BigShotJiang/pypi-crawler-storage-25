# ============================
# scene.py — Structural State
# ============================
from __future__ import annotations
import numpy as np
from typing import List, Tuple, Optional, Sequence, Dict
from collections import Counter
from .constants import CPK_COLORS, ATOMIC_RADII, DEFAULT_COLOR, DEFAULT_RADIUS, ATOMIC_MASSES, DEFAULT_MASS
from .analysis.geometry import compute_bounds, cell_corners

class Scene:
    """
    Manages the current structural state, including atom positions, 
    lattice, selection, and element-based properties.
    """
    def __init__(self):
        self.N = 0
        self.pos = np.empty((0, 3), dtype=np.float32)
        self.elements: List[str] = []
        self.radii = np.empty((0,), dtype=np.float32)
        self.colors = np.empty((0, 4), dtype=np.float32)
        self.info: Optional[Dict[str, List[Any]]] = None
        
        # Unit Cell
        self.lat = np.eye(3, dtype=np.float32)
        self.is_periodic = False
        
        # Metadata
        self.composition_str = "N/A"
        self.energy = 0.0
        
        # Selections (Dual-Storage: List for order, Set for O(1) lookup)
        self.selected_atoms: List[int] = []
        self.selected_set: Set[int] = set()
        self.box_selecting = False
        self.box_start = None
        self.box_end = None
        
        # Bonds (Adjacency)
        self.bonds: List[Tuple[int, int]] = []
        self.bond_count = 0
        
        # Replicas (Supercells)
        self.replicas = (0, 0, 0)
        self.replica_offsets = np.zeros((1, 3), dtype=np.float32)

        # Persistent Atom IDs
        self.ids = np.array([], dtype=np.int64)
        self.id_counter = 0

    def ingest(self, positions: np.ndarray, lattice: np.ndarray, energy: float, 
               elements: Optional[List[str]] = None, 
               colors: Optional[np.ndarray] = None, 
               radii: Optional[np.ndarray] = None,
               info: Optional[Dict[str, List[Any]]] = None):
        """Standardizes and loads new atomic data into the scene."""
        self.pos = np.asarray(positions, dtype=np.float32).reshape(-1, 3)
        self.N = self.pos.shape[0]
        self.energy = energy
        self.info = info
        
        try:
            self.lat = np.asarray(lattice, dtype=np.float32).reshape(3, 3)
            # Use a more robust check for periodicity: non-zero determinant or explicit flag
            self.is_periodic = (np.linalg.norm(self.lat) > 1e-4)
        except Exception:
            self.lat = np.zeros((3, 3), dtype=np.float32)
            self.is_periodic = False
            
        self.elements = elements if elements else []
        
        # Reset topology for the new structure
        self.bonds = []
        self.bond_count = 0
        
        # Update Composition string
        if self.elements:
            counts = Counter(self.elements)
            self.composition_str = " ".join([f"{k}{v}" for k, v in sorted(counts.items())])
        else:
            self.composition_str = "Unknown"

        # Apply default coloring/radii if not provided
        if radii is None:
            if self.elements:
                self.radii = np.array([ATOMIC_RADII.get(e, DEFAULT_RADIUS) for e in self.elements], dtype=np.float32)
            else:
                self.radii = np.full(self.N, DEFAULT_RADIUS, dtype=np.float32)
        else:
            self.radii = np.asarray(radii, dtype=np.float32)
            
        if colors is None:
            if self.elements:
                c_base = np.array([CPK_COLORS.get(e, DEFAULT_COLOR) for e in self.elements], dtype=np.float32)
            else:
                c_base = np.tile(DEFAULT_COLOR, (self.N, 1)).astype(np.float32)
            # Default to opaque (alpha=1)
            self.colors = np.hstack([c_base, np.ones((self.N, 1), dtype=np.float32)])
        else:
            c_in = np.asarray(colors, dtype=np.float32)
            if c_in.shape[1] == 3:
                self.colors = np.hstack([c_in, np.ones((self.N, 1), dtype=np.float32)])
            else:
                self.colors = c_in
            
        # Manage Persistent IDs
        # If new structure is loaded, we reset IDs starting from current counter
        self.ids = np.arange(self.id_counter, self.id_counter + self.N, dtype=np.int64)
        self.id_counter += self.N

        # Re-calc bounding boxes for initial camera positioning helpers (exterior logic)
        return self.get_full_bounds()

    def get_full_bounds(self) -> Tuple[np.ndarray, np.ndarray]:
        """Returns the AABB (min, max) including atoms and the unit cell corners."""
        if self.N == 0:
            return np.array([-5, -5, -5]), np.array([5, 5, 5])
        
        all_pts = [self.pos]
        if self.is_periodic:
            all_pts.append(cell_corners(self.lat))
        
        full_cloud = np.vstack(all_pts)
        mn, mx = compute_bounds(full_cloud)
        
        if len(self.replica_offsets) > 0:
            off_mn = np.min(self.replica_offsets, axis=0)
            off_mx = np.max(self.replica_offsets, axis=0)
            mn = mn + off_mn
            mx = mx + off_mx
            
        return mn, mx

    @property
    def unique_elements(self) -> List[str]:
        """Returns sorted list of unique chemical species present in the scene."""
        if not self.elements: return []
        return sorted(list(set(self.elements)))

    def set_replicas(self, rx: int, ry: int, rz: int):
        """Updates replica grid and pre-calculates the offset matrix."""
        self.replicas = (int(rx), int(ry), int(rz))
        a, b, c = self.lat[0], self.lat[1], self.lat[2]
        
        # Ensure (0,0,0) is always the first replica so it is the one "marked" or focused
        offs = [np.zeros(3, dtype=np.float32)]
        for i in range(-rx, rx+1):
            for j in range(-ry, ry+1):
                for k in range(-rz, rz+1):
                    if i == 0 and j == 0 and k == 0: continue
                    offs.append(i*a + j*b + k*c)
                    
        self.replica_offsets = np.array(offs, dtype=np.float32)
        return self.replica_offsets

    def clear_selection(self):
        self.selected_atoms = []
        self.selected_set = set()
        self.box_selecting = False

    def toggle_atom_selection(self, idx: int):
        """Toggles a single atom's selection state, maintaining dual-storage sync."""
        if idx in self.selected_set:
            self.selected_set.remove(idx)
            try:
                self.selected_atoms.remove(idx)
            except ValueError:
                pass # Already gone from list, but set cleanup is good
        else:
            self.selected_set.add(idx)
            self.selected_atoms.append(idx)

    def select_atoms(self, indices: List[int], append: bool = True):
        """Adds multiple atoms to selection, ensuring no duplicates and dual-storage sync."""
        if not append:
            self.clear_selection()
        
        for idx in indices:
            if idx not in self.selected_set:
                self.selected_set.add(idx)
                self.selected_atoms.append(idx)

    def get_com(self) -> np.ndarray:
        """Calculates mass-weighted Center of Mass of the whole scene."""
        if self.N == 0: return np.zeros(3, dtype=np.float32)
        
        masses = np.array([ATOMIC_MASSES.get(e, DEFAULT_MASS) for e in self.elements], dtype=np.float32)
        if len(masses) != self.N:
            return np.mean(self.pos, axis=0) # Fallback if elements desynced
            
        return np.average(self.pos, axis=0, weights=masses)

    def get_selected_com(self) -> np.ndarray:
        """Calculates mass-weighted COM of the current selection."""
        indices = self.selected_atoms
        if not indices: return self.get_com()
        
        masses = np.array([ATOMIC_MASSES.get(self.elements[i], DEFAULT_MASS) for i in indices], dtype=np.float32)
        return np.average(self.pos[indices], axis=0, weights=masses)

    # --- Manipulation Tools ---

    def remove_atoms(self, indices: Sequence[int]):
        """Permanently removes atoms from the scene and cleans up state."""
        if len(indices) == 0: return
        mask = np.ones(self.N, dtype=bool)
        mask[indices] = False
        
        self.pos = self.pos[mask]
        self.radii = self.radii[mask]
        self.colors = self.colors[mask]
        self.ids = self.ids[mask]
        self.elements = [e for i, e in enumerate(self.elements) if mask[i]]
        self.N = self.pos.shape[0]
        
        # Clear/Update selection
        # Since indices change, all selections are invalidated for simplicity
        # or we could map them. Simple clear is safer for destructive edits.
        self.clear_selection()
        
        # Invalidate bonds
        self.bonds = []
        self.bond_count = 0
        
    def translate_atoms(self, indices: Sequence[int], delta: np.ndarray):
        """Moves a group of atoms by a vector."""
        if len(indices) == 0 or self.N == 0: return
        self.pos[indices] += delta
        
    def rotate_atoms(self, indices: Sequence[int], axis: np.ndarray, angle_deg: float):
        """Rotates a group of atoms around their center of mass."""
        if len(indices) == 0 or self.N == 0: return
        
        subset = self.pos[indices]
        # COM of the selection
        com = np.mean(subset, axis=0)
        
        # Rotation Matrix (Rodrigues)
        axis = axis / np.linalg.norm(axis)
        theta = np.radians(angle_deg)
        cos_t, sin_t = np.cos(theta), np.sin(theta)
        
        ux, uy, uz = axis
        K = np.array([[0, -uz, uy], [uz, 0, -ux], [-uy, ux, 0]])
        R = np.eye(3) + sin_t * K + (1 - cos_t) * (K @ K)
        
        self.pos[indices] = com + (subset - com) @ R.T

    def set_elements(self, indices: Sequence[int], species: str):
        """Updates chemical types and re-applies default radii/colors."""
        if len(indices) == 0 or self.N == 0: return
        for idx in indices:
            self.elements[idx] = species
            self.radii[idx] = ATOMIC_RADII.get(species, DEFAULT_RADIUS)
            self.colors[idx] = CPK_COLORS.get(species, DEFAULT_COLOR)
        
        # Re-calc composition string
        counts = Counter(self.elements)
        self.composition_str = " ".join([f"{k}{v}" for k, v in sorted(counts.items())])
