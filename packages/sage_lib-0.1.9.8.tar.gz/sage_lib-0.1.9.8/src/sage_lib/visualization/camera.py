from __future__ import annotations
from dataclasses import dataclass, field
import math
import numpy as np
from typing import Optional, Tuple, List, Dict, Any, Union

WORLD_UP = np.array([0, 0, 1], dtype=np.float32)

def normalize(v: np.ndarray) -> np.ndarray:
    """Returns the normalized vector v."""
    norm = np.linalg.norm(v)
    if norm < 1e-10:
        return v
    return v / norm

def rodrigues(v: np.ndarray, axis: np.ndarray, angle: float) -> np.ndarray:
    """Rotates vector v around axis by angle radians using Rodrigues' formula."""
    axis = normalize(axis)
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    return v * cos_a + np.cross(axis, v) * sin_a + axis * np.dot(axis, v) * (1 - cos_a)

@dataclass
class OrbitCamera:
    """
    Precision camera for scientific inspection.
    Features: Orbit, Pan, Zoom, and Smooth Transitions.
    """
    center: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float32))
    offset: np.ndarray = field(default_factory=lambda: np.array([10, 10, 10], dtype=np.float32))
    up: np.ndarray = field(default_factory=lambda: np.array([0, 1, 0], dtype=np.float32))
    pan: np.ndarray = field(default_factory=lambda: np.zeros(2, dtype=np.float32))
    
    fov: float = 45.0
    near: float = 0.1
    far: float = 1000.0
    ortho_scale: float = 15.0
    is_ortho: bool = False
    
    # Dynamics
    sensitivity: float = 0.005
    damping: float = 0.85
    momentum: bool = True
    invert_x: bool = False
    invert_y: bool = False
    clamped_pitch: bool = False
    
    yaw_v: float = 0.0
    pitch_v: float = 0.0
    fly_speed: float = 10.0
    
    mode: str = "ORBIT" # ORBIT, TURNTABLE, FLY, AXIS
    
    # Internal state for smooth flying
    _fly_active: bool = False
    _fly_t: float = 0.0
    _fly_duration: float = 1.0
    _start_center: np.ndarray = field(default_factory=lambda: np.zeros(3))
    _target_center: np.ndarray = field(default_factory=lambda: np.zeros(3))
    _start_offset: np.ndarray = field(default_factory=lambda: np.zeros(3))
    _target_offset: np.ndarray = field(default_factory=lambda: np.zeros(3))
    _start_up: np.ndarray = field(default_factory=lambda: np.array([0,1,0]))
    _target_up: np.ndarray = field(default_factory=lambda: np.array([0,1,0]))
    _start_fov: float = 45.0
    _target_fov: float = 45.0
    _start_pan: np.ndarray = field(default_factory=lambda: np.zeros(2))
    _target_pan: np.ndarray = field(default_factory=lambda: np.zeros(2))
    _start_ortho_scale: float = 15.0
    _target_ortho_scale: float = 15.0

    def serialize(self) -> dict:
        return {
            "center": self.center.tolist(),
            "offset": self.offset.tolist(),
            "up": self.up.tolist(),
            "pan": self.pan.tolist(),
            "fov": self.fov,
            "ortho_scale": self.ortho_scale,
            "is_ortho": self.is_ortho,
            "mode": self.mode
        }

    def deserialize(self, data: dict):
        self.center = np.array(data["center"], dtype=np.float32)
        self.offset = np.array(data["offset"], dtype=np.float32)
        self.up = np.array(data["up"], dtype=np.float32)
        self.pan = np.array(data["pan"], dtype=np.float32)
        self.fov = data.get("fov", 45.0)
        self.ortho_scale = data.get("ortho_scale", 15.0)
        self.is_ortho = data.get("is_ortho", False)
        self.mode = data.get("mode", "ORBIT")

    def set_fly_to(self, center: np.ndarray, offset: np.ndarray, duration: float = 1.0, fov: Optional[float] = None, up: Optional[np.ndarray] = None, ortho_scale: Optional[float] = None):
        self._start_center = np.copy(self.center)
        self._target_center = np.copy(center)
        self._start_offset = np.copy(self.offset)
        self._target_offset = np.copy(offset)
        self._start_pan = np.copy(self.pan)
        self._target_pan = np.zeros(2, dtype=np.float32)
        self._start_fov = self.fov
        self._target_fov = fov if fov is not None else self.fov
        self._start_up = np.copy(self.up)
        self._target_up = up if up is not None else np.array([0, 1, 0], dtype=np.float32)
        self._start_ortho_scale = self.ortho_scale
        self._target_ortho_scale = ortho_scale if ortho_scale is not None else self.ortho_scale
        
        self._fly_t = 0.0
        self._fly_duration = duration
        self._fly_active = True

    def fly_to(self, state: dict, duration: float = 1.0):
        """Flys smoothly to a serialized camera state."""
        self.set_fly_to(
            center=np.array(state["center"]),
            offset=np.array(state["offset"]),
            up=np.array(state.get("up", [0, 1, 0])),
            fov=state.get("fov"),
            ortho_scale=state.get("ortho_scale"),
            duration=duration
        )

    @property
    def is_moving(self) -> bool:
        return self._fly_active or abs(self.yaw_v) > 1e-4 or abs(self.pitch_v) > 1e-4

    def update(self, dt: float):
        """Processes momentum and interpolation logic."""
        if self._fly_active:
            self._fly_t += dt
            t = min(1.0, self._fly_t / self._fly_duration)
            ease = t * t * (3.0 - 2.0 * t)
            
            self.center = self._start_center + (self._target_center - self._start_center) * ease
            self.offset = self._start_offset + (self._target_offset - self._start_offset) * ease
            self.fov = self._start_fov + (self._target_fov - self._start_fov) * ease
            self.up = normalize(self._start_up + (self._target_up - self._start_up) * ease)
            self.pan = self._start_pan + (self._target_pan - self._start_pan) * ease
            self.ortho_scale = self._start_ortho_scale + (self._target_ortho_scale - self._start_ortho_scale) * ease
            
            if t >= 1.0:
                self._fly_active = False
            return

        if not self.momentum:
            self.yaw_v = self.pitch_v = 0.0
            return

        # Apply velocities
        if abs(self.yaw_v) > 1e-5:
            self.rotate_yaw(self.yaw_v * dt * 60.0)
        if abs(self.pitch_v) > 1e-5:
            self.rotate_pitch(self.pitch_v * dt * 60.0)

        # Decay
        d = math.pow(self.damping, dt * 60.0)
        self.yaw_v *= d
        self.pitch_v *= d
        
        if abs(self.yaw_v) < 1e-5: self.yaw_v = 0.0
        if abs(self.pitch_v) < 1e-5: self.pitch_v = 0.0

    def get_pan_vector(self) -> np.ndarray:
        # Convert 2D pan (X, Y) to 3D vector in camera basis
        right = self.right()
        # Up vector relative to camera view (Screen Up)
        up = np.cross(right, self.forward())
        return right * self.pan[0] + up * self.pan[1]

    def commit_pan(self):
        """Merges current pan offset into the world-space center and resets pan to zero."""
        if np.linalg.norm(self.pan) < 1e-8: return
        self.center = self.target()
        self.pan = np.zeros(2, dtype=np.float32)

    def eye(self) -> np.ndarray:
        # Eye is center + offset + pan (in camera plane)
        return self.center + self.offset + self.get_pan_vector()

    def target(self) -> np.ndarray:
        # Target is center + pan
        return self.center + self.get_pan_vector()

    def forward(self) -> np.ndarray:
        return normalize(-self.offset)

    def move_local(self, dx: float, dy: float, dz: float):
        """Moves both center and eye along local camera axes (WASD style)."""
        fwd = self.forward()
        r = self.right()
        u = normalize(np.cross(r, fwd))
        
        shift = r * dx + u * dy + fwd * dz
        self.center += shift

    def right(self) -> np.ndarray:
        """Returns the world-space 'right' vector (perpendicular to forward and up)."""
        r = np.cross(self.forward(), self.up)
        if np.linalg.norm(r) < 1e-6:
            # Fallback if at pole: use X-axis or Y-axis
            r = np.array([1, 0, 0], dtype=np.float32)
        return normalize(r)

    def rotate_yaw(self, angle: float):
        if self.invert_x: angle = -angle
        if self.mode == "ORBIT":
            # If not clamped, we rotate around the CURRENT up vector to feel free
            # If clamped, we rotate around the GLOBAL up to stay upright
            rot_axis = self.up
            self.offset = rodrigues(self.offset, rot_axis, angle)
            # In free mode, we don't need to change UP for yaw
        elif self.mode == "AXIS":
            # Axis mode: always rotate strictly around the global Z-axis
            global_z = np.array([0, 0, 1], dtype=np.float32)
            self.offset = rodrigues(self.offset, global_z, angle)
            self.up = normalize(rodrigues(self.up, global_z, angle))
        else:
            # FLY mode: pivot around eye
            eye_fixed = self.eye()
            self.offset = rodrigues(self.offset, self.up, -angle)
            self.center = eye_fixed - (self.offset + self.get_pan_vector())

    def rotate_pitch(self, angle: float):
        if self.invert_y: angle = -angle
        
        if self.mode == "AXIS":
            # Axis mode: always rotate strictly around the global X-axis
            global_x = np.array([1, 0, 0], dtype=np.float32)
            self.offset = rodrigues(self.offset, global_x, -angle)
            self.up = normalize(rodrigues(self.up, global_x, -angle))
            return
            
        # 1. Get stable right vector
        right = self.right()
        
        # 2. Apply rotation to the offset (the 'look' vector)
        new_offset = rodrigues(self.offset, right, -angle)
        
        # 3. Handle clamping or free rotation
        if self.clamped_pitch:
            # Prevent going over the poles (hard stop at ~89 degrees)
            # Use a fixed reference UP for clamping (e.g. [0,0,1] or initial self.up)
            # For SAGE, let's assume the initial UP is the reference.
            dot = np.dot(normalize(new_offset), self.up)
            if abs(dot) > 0.995:
                return # Block rotation
            self.offset = new_offset
        else:
            # FREE MODE: Update both offset AND up vector to stay unconfined
            self.offset = new_offset
            self.up = normalize(rodrigues(self.up, right, -angle))

    def get_view_matrix(self) -> np.ndarray:
        from .renderer.utils import look_at
        return look_at(self.eye(), self.target(), self.up)
        
    def get_projection_matrix(self, aspect: float, is_ortho: Optional[bool] = None) -> np.ndarray:
        from .renderer.utils import perspective, ortho
        if is_ortho is None: is_ortho = self.is_ortho
        
        if is_ortho:
            s = self.ortho_scale / 2.0
            return ortho(-s * aspect, s * aspect, -s, s, self.near, self.far)
        else:
            return perspective(self.fov, aspect, self.near, self.far)

    def snap_isometric(self):
        dist = np.linalg.norm(self.offset)
        iso_pitch = math.radians(35.264)
        c, s = math.cos(iso_pitch), math.sin(iso_pitch)
        v = np.array([0, -dist*c, dist*s], dtype=np.float32)
        rot_z = math.radians(-45.0)
        v = rodrigues(v, np.array([0, 0, 1], dtype=np.float32), rot_z)
        self.offset = v
        self.up = np.array([0, 0, 1], dtype=np.float32)

    def get_ray_from_pixel(self, x: float, y: float, win_w: int, win_h: int) -> Tuple[np.ndarray, np.ndarray]:
        ndc_x = (2.0 * x) / win_w - 1.0
        ndc_y = 1.0 - (2.0 * y) / win_h
        origin = self.eye()
        aspect = win_w / win_h
        forward = self.forward()
        right = self.right()
        up = normalize(np.cross(right, forward))
        
        if self.is_ortho:
            s = self.ortho_scale / 2.0
            world_pos = self.target() + right * (ndc_x * s * aspect) + up * (ndc_y * s)
            direction = forward
            origin = world_pos - forward * (self.far * 0.5)
        else:
            tan_fov = math.tan(math.radians(self.fov) / 2.0)
            ray_dir_cam = normalize(np.array([ndc_x * tan_fov * aspect, ndc_y * tan_fov, -1.0]))
            direction = normalize(right * ray_dir_cam[0] + up * ray_dir_cam[1] + forward * (-ray_dir_cam[2]))
            
        return origin, direction

@dataclass
class FPSCamera:
    """Standard game-style First Person camera."""
    position: np.ndarray = field(default_factory=lambda: np.array([0.0, 2.0, -10.0], dtype=np.float32))
    yaw: float = 0.0   # Radians
    pitch: float = 0.0 # Radians
    
    speed: float = 8.0
    sprint_mult: float = 2.5
    sensitivity: float = 0.0025
    
    fov: float = 70.0
    near: float = 0.05
    far: float = 2000.0
    
    def forward(self) -> np.ndarray:
        """Standard FPS forward vector for Z-up systems."""
        return np.array([
            math.cos(self.pitch) * math.sin(self.yaw),
            math.cos(self.pitch) * math.cos(self.yaw),
            math.sin(self.pitch)
        ], dtype=np.float32)

    def horizontal_forward(self) -> np.ndarray:
        """Forward vector projected onto the XY plane."""
        return normalize(np.array([math.sin(self.yaw), math.cos(self.yaw), 0.0], dtype=np.float32))

    def horizontal_right(self) -> np.ndarray:
        """Right vector on the XY plane."""
        return normalize(np.array([math.cos(self.yaw), -math.sin(self.yaw), 0.0], dtype=np.float32))

    def update_movement(self, keys: Dict[int, bool], dt: float):
        move = np.zeros(3, dtype=np.float32)
        h_fwd = self.horizontal_forward()
        h_right = self.horizontal_right()
        
        import glfw
        if keys.get(glfw.KEY_W): move += h_fwd
        if keys.get(glfw.KEY_S): move -= h_fwd
        if keys.get(glfw.KEY_A): move -= h_right
        if keys.get(glfw.KEY_D): move += h_right
        
        # Height control (Z-axis)
        if keys.get(glfw.KEY_SPACE): move += np.array([0, 0, 1], dtype=np.float32)
        if keys.get(glfw.KEY_LEFT_CONTROL) or keys.get(glfw.KEY_C): move -= np.array([0, 0, 1], dtype=np.float32)
        
        if np.linalg.norm(move) > 1e-6:
            move = normalize(move)
            
        # 4x Sprint speed as requested
        s = self.speed * (4.0 if keys.get(glfw.KEY_LEFT_SHIFT) else 1.0)
        self.position += move * s * dt

    def update_look(self, dx: float, dy: float):
        # Yaw: Rotate around Z (Standard: Mouse Right -> Turn Right)
        self.yaw += dx * self.sensitivity
        # Pitch: Rotate up/down (clamped)
        self.pitch -= dy * self.sensitivity
        self.pitch = np.clip(self.pitch, math.radians(-89.0), math.radians(89.0))

    def get_view_matrix(self) -> np.ndarray:
        from .renderer.utils import look_at
        eye = self.position
        target = eye + self.forward()
        up = np.array([0, 0, 1], dtype=np.float32) # Z-up
        return look_at(eye, target, up)

    def get_projection_matrix(self, aspect: float) -> np.ndarray:
        from .renderer.utils import perspective
        return perspective(self.fov, aspect, self.near, self.far)

    def get_view_matrix(self) -> np.ndarray:
        from .renderer.utils import look_at
        eye = self.position
        target = eye + self.forward()
        up = np.array([0, 0, 1], dtype=np.float32) # Z-up
        return look_at(eye, target, up)

    def get_projection_matrix(self, aspect: float) -> np.ndarray:
        from .renderer.utils import perspective
        return perspective(self.fov, aspect, self.near, self.far)
