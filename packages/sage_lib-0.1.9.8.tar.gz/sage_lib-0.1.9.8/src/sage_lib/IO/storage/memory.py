# ============================
# memory.py — In-memory (list/dict) backend
# ============================
from __future__ import annotations

import numpy as np
from typing import Any, Dict, List, Optional, Union, Sequence, Tuple
from .backend import StorageBackend, StorageType

# -----------------------------
# In-memory (list/dict) backend
# -----------------------------
class MemoryStorage(StorageBackend):
    """
    Generic in-memory storage.

    Notes
    -----
    - The container can be either a list (sequential storage) or a dict mapping
      integer IDs to objects.
    - IDs are always integers, automatically assigned if using a list.
    """

    def __init__(self, initial: StorageType | None = None) -> None:
        self._data: StorageType = initial if initial is not None else []
        self._meta: Dict[int, Dict[str, Any]] = {}

    # ---------------------------------------
    # Core CRUD interface
    # ---------------------------------------
    def add(self, obj: Any, metadata: Optional[Dict[str, Any]] = None) -> int:
        if isinstance(self._data, list):
            self._data.append(obj)
            idx = len(self._data) - 1
        else:
            idx = max(self._data.keys(), default=-1) + 1
            self._data[idx] = obj
        if metadata is not None:
            self._meta[idx] = metadata
        return idx

    def update(self, obj_id: int, obj: Any) -> None:
        if isinstance(self._data, list):
            self._data[obj_id] = obj
        else:
            self._data[obj_id] = obj

    def add_many(self, objs: List[Any], metadata: Optional[List[Dict[str, Any]]] = None) -> List[int]:
        if not objs:
            return []
            
        if isinstance(self._data, list):
            start_idx = len(self._data)
            self._data.extend(objs)
            new_ids = list(range(start_idx, start_idx + len(objs)))
        else:
            # dict storage path (less efficient but correct)
            new_ids = []
            current_max = max(self._data.keys(), default=-1)
            for i, obj in enumerate(objs):
                idx = current_max + 1 + i
                self._data[idx] = obj
                new_ids.append(idx)
        
        if metadata:
            # metadata is a list of dicts corresponding to objs
            for i, meta in enumerate(metadata):
                if meta:
                    self._meta[new_ids[i]] = meta
                    
        return new_ids

    def set(self, container: StorageType) -> int:
        if not isinstance(container, (list, dict)):
            raise TypeError("container must be a list or a dict[int, Any]")
        self._data = container
        self._meta.clear()
        return len(self._data) - 1 if isinstance(self._data, list) else (max(self._data.keys(), default=-1))

    def remove(self, obj_id: int) -> None:
        try:
            del self._data[obj_id]
        except (IndexError, KeyError):
            raise KeyError(f"No object found with id {obj_id}") from None
        self._meta.pop(obj_id, None)

    def get(self, obj_id: Optional[int] = None):
        if obj_id is None:
            return self._data
        try:
            return self._data[obj_id]
        except (IndexError, KeyError):
            raise KeyError(f"No object found with id {obj_id}") from None

    def list_ids(self) -> List[int]:
        return list(range(len(self._data))) if isinstance(self._data, list) else list(self._data.keys())

    def count(self) -> int:
        return len(self._data)

    def clear(self) -> None:
        if isinstance(self._data, list):
            self._data.clear()
        else:
            self._data = {}
        self._meta.clear()

    # Optional metadata helpers
    def get_meta(self, obj_id: int) -> Dict[str, Any]:
        return dict(self._meta.get(obj_id, {}))

    def set_meta(self, obj_id: int, meta: Dict[str, Any]) -> None:
        self.set_meta_bulk({obj_id: meta})

    def set_meta_bulk(self, id_meta_map: Dict[int, Dict[str, Any]]) -> None:
        """
        Bulk update metadata for multiple objects.

        Parameters
        ----------
        id_meta_map : dict
            Mapping of object IDs to their full metadata dictionaries.
        """
        if not id_meta_map:
            return
        for oid, meta in id_meta_map.items():
            self._meta[int(oid)] = dict(meta)

    def get_all_natoms(self) -> np.ndarray:
        """Return a 1D array of atom counts for all objects."""
        if isinstance(self._data, list):
            objs = self._data
        else:
            objs = [self._data[i] for i in sorted(self._data.keys())]

        def _get_n(o):
            try:
                return float(o.AtomPositionManager.atomCount)
            except (AttributeError, TypeError, ValueError):
                return np.nan
        return np.fromiter(map(_get_n, objs), dtype=float)

    def get_all_energies(self) -> np.ndarray:
        """Return a 1D array of energies for all objects."""
        if isinstance(self._data, list):
            objs = self._data
        else:
            objs = [self._data[i] for i in sorted(self._data.keys())]

        def _get_e(o):
            try:
                return float(o.AtomPositionManager.E)
            except (AttributeError, TypeError, ValueError):
                return np.nan
        return np.fromiter(map(_get_e, objs), dtype=float)

    def get_all_compositions(self, species_order: Optional[Sequence[str]] = None, return_species: bool = False) -> Union[np.ndarray, Tuple[np.ndarray, List[str]]]:
        """Return compositions for all objects."""
        if isinstance(self._data, list):
            objs = self._data
        else:
            objs = [self._data[i] for i in sorted(self._data.keys())]

        comps = []
        all_species = set()
        for o in objs:
            try:
                apm = getattr(o, "AtomPositionManager", None)
                c = apm.atomCountDict if apm is not None else {}
                comps.append(c)
                all_species.update(c.keys())
            except (AttributeError, TypeError):
                comps.append({})

        if species_order is None:
            species_order = sorted(list(all_species))
        
        n = len(objs)
        m = len(species_order)
        out = np.zeros((n, m))
        s2i = {s: i for i, s in enumerate(species_order)}
        
        for i, c in enumerate(comps):
            for s, val in c.items():
                if s in s2i:
                    out[i, s2i[s]] = val
        
        if return_species:
            return out, list(species_order)
        return out

    def get_all_lattice_vectors(self, missing="nan", *, fill_missing=True) -> np.ndarray:
        """Return a (N, 3, 3) array of lattice vectors."""
        if isinstance(self._data, list):
            objs = self._data
        else:
            objs = [self._data[i] for i in sorted(self._data.keys())]
            
        n = len(objs)
        if missing == "nan":
            out = np.full((n, 3, 3), np.nan, dtype=float)
        elif missing == "zero":
            out = np.zeros((n, 3, 3), dtype=float)
        else:
            out = np.empty((n,), dtype=object)

        for i, o in enumerate(objs):
            try:
                l = np.asarray(o.AtomPositionManager.latticeVectors).reshape(3, 3)
                if out.ndim == 3:
                    out[i] = l
                else:
                    out[i] = l
            except (AttributeError, ValueError):
                pass
        return out

    def get_all_hashes(self, with_ids: bool = False) -> Union[List[str], List[Tuple[int, str]]]:
        """Return hashes for all objects."""
        ids = self.list_ids()
        hashes = []
        for cid in ids:
            obj = self.get(cid)
            h = getattr(obj, "hash", None)
            if h is None and hasattr(obj, "AtomPositionManager"):
                h = getattr(obj.AtomPositionManager, "metadata", {}).get("hash")
            hashes.append(h)
            
        if with_ids:
            return list(zip(ids, hashes))
        return hashes

    def get_all_metadata(self, key: str) -> np.ndarray:
        """Return metadata values for the given key."""
        ids = self.list_ids()
        out = np.empty(len(ids), dtype=object)
        out[:] = None
        for i, cid in enumerate(ids):
            m = self._meta.get(cid, {})
            if key in m:
                out[i] = m[key]
            else:
                # Fallback to object attribute if not in meta dict
                obj = self.get(cid)
                if hasattr(obj, "AtomPositionManager"):
                    out[i] = getattr(obj.AtomPositionManager, "metadata", {}).get(key)
        return out

    def get_keys(self) -> List[str]:
        """Return a list of all available metadata keys across all objects."""
        keys = set()
        for m in self._meta.values():
            keys.update(m.keys())
            
        ids = self.list_ids()
        for cid in ids:
            obj = self.get(cid)
            if hasattr(obj, "AtomPositionManager"):
                m = getattr(obj.AtomPositionManager, "metadata", {})
                if isinstance(m, dict):
                    keys.update(m.keys())
        return sorted(list(keys))

    def get_all_scalars(self, keys: Optional[Sequence[str]] = None, return_keys: bool = False) -> Union[np.ndarray, Tuple[np.ndarray, List[str]]]:
        """Return multiple scalar values for all objects."""
        if keys is None:
            # Try to discover keys from metadata
            discovered = set()
            for m in self._meta.values():
                discovered.update(m.keys())
            keys = sorted(list(discovered))
            
        n = len(self._data)
        m = len(keys)
        out = np.zeros((n, m))
        
        for j, k in enumerate(keys):
            vals = self.get_all_metadata(k)
            for i, v in enumerate(vals):
                if v is not None:
                    try:
                        out[i, j] = float(v)
                    except (TypeError, ValueError):
                        pass
        
        if return_keys:
            return out, list(keys)
        return out
