# ============================
# sqlite.py — SQLite (pickle BLOB) backend
# ============================
from __future__ import annotations

import os
import sqlite3
import pickle
import numpy as np
from typing import Any, Dict, Iterator, List, Optional, Sequence, Union, Tuple

from .backend import StorageBackend

# -----------------------------
# SQLite (pickle BLOB) backend
# -----------------------------
class SQLiteStorage(StorageBackend):
    """SQLite-based storage, pickling objects into a BLOB."""

    def __init__(self, db_path: str):
        dir_path = os.path.dirname(db_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self._init_schema()

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def _init_schema(self) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS containers (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                data BLOB NOT NULL
            );
            """
        )
        self.conn.commit()

    def add(self, obj: Any, metadata: Optional[Dict[str, Any]] = None) -> int:
        blob = pickle.dumps(obj)
        cur = self.conn.cursor()
        cur.execute("INSERT INTO containers (data) VALUES (?);", (blob,))
        self.conn.commit()
        return int(cur.lastrowid)

    def update(self, obj_id: int, obj: Any) -> None:
        blob = pickle.dumps(obj)
        cur = self.conn.cursor()
        cur.execute("UPDATE containers SET data = ? WHERE id = ?;", (blob, int(obj_id)))
        self.conn.commit()

    def get(self, obj_id: Optional[int] = None):
        if obj_id is None:
            # Return a lightweight proxy of all objects (loads on iteration)
            return _LazySQLiteView(self)
        cur = self.conn.cursor()
        cur.execute("SELECT data FROM containers WHERE id = ?;", (obj_id,))
        row = cur.fetchone()
        if row is None:
            raise KeyError(f"No container with id {obj_id}")
        return pickle.loads(row[0])

    def remove(self, obj_id: int | Sequence[int]) -> None:
        if isinstance(obj_id, (int, np.integer)):
            ids = [int(obj_id)]
        else:
            ids = [int(x) for x in obj_id]
            
        if not ids:
            return

        cur = self.conn.cursor()
        with self.conn:  # Single transaction
            if len(ids) == 1:
                cur.execute("DELETE FROM containers WHERE id = ?;", (ids[0],))
            else:
                # Chunk to avoid SQLite parameter limits (~999)
                for i in range(0, len(ids), 900):
                    chunk = ids[i:i+900]
                    q = "DELETE FROM containers WHERE id IN (%s);" % ",".join("?" for _ in chunk)
                    cur.execute(q, chunk)

    def list_ids(self) -> List[int]:
        cur = self.conn.cursor()
        cur.execute("SELECT id FROM containers ORDER BY id ASC;")
        return [int(row[0]) for row in cur.fetchall()]

    def count(self) -> int:
        cur = self.conn.cursor()
        cur.execute("SELECT COUNT(*) FROM containers;")
        return int(cur.fetchone()[0])

    def clear(self) -> None:
        cur = self.conn.cursor()
        cur.execute("DELETE FROM containers;")
        self.conn.commit()

    def iter_ids(self, batch_size: Optional[int] = 1000) -> Iterator[int]:
        cur = self.conn.cursor()
        last = 0
        while True:
            if batch_size:
                cur.execute(
                    "SELECT id FROM containers WHERE id > ? ORDER BY id ASC LIMIT ?;",
                    (last, batch_size),
                )
            else:
                cur.execute(
                    "SELECT id FROM containers WHERE id > ? ORDER BY id ASC;",
                    (last,),
                )
            rows = cur.fetchall()
            if not rows:
                break
            for (cid,) in rows:
                yield int(cid)
            last = int(rows[-1][0])

    def add_many(self, objs: List[Any], metadata: Optional[List[Dict[str, Any]]] = None) -> List[int]:
        """
        Add multiple objects in a single transaction.
        """
        if not objs:
            return []
        
        ids = []
        cur = self.conn.cursor()
        
        # Use simple iteration inside a transaction.
        # This is strictly slower than executemany but reliably returns IDs
        # and is still orders of magnitude faster than commit-per-insert.
        try:
            # We can use the connection context manager if isolation_level is not autocommit, 
            # or explicit BEGIN/COMMIT. 
            # To be safe with existing code logic:
            self.conn.execute("BEGIN")
            
            for obj in objs:
                blob = pickle.dumps(obj)
                cur.execute("INSERT INTO containers (data) VALUES (?);", (blob,))
                ids.append(cur.lastrowid)
                
            self.conn.commit()
        except:
            self.conn.rollback()
            raise

        return ids
    
    def get_all_natoms(self) -> np.ndarray:
        """Return a 1D array of atom counts for all objects."""
        counts = []
        for cid in self.iter_ids():
            obj = self.get(cid)
            try:
                apm = getattr(obj, "AtomPositionManager", None)
                counts.append(float(apm.atomCount) if apm is not None else np.nan)
            except Exception:
                counts.append(np.nan)
        return np.array(counts, dtype=float)

    def get_all_energies(self) -> np.ndarray:
        """Return a 1D array of energies for all objects."""
        energies = []
        for cid in self.iter_ids():
            obj = self.get(cid)
            try:
                apm = getattr(obj, "AtomPositionManager", None)
                energies.append(float(apm.E) if apm is not None else np.nan)
            except Exception:
                energies.append(np.nan)
        return np.array(energies, dtype=float)

    def get_all_compositions(self, species_order: Optional[Sequence[str]] = None, return_species: bool = False) -> Union[np.ndarray, Tuple[np.ndarray, List[str]]]:
        """Return compositions for all objects."""
        comps = []
        all_species = set()
        for cid in self.iter_ids():
            obj = self.get(cid)
            try:
                apm = getattr(obj, "AtomPositionManager", None)
                c = apm.atomCountDict if apm is not None else {}
                comps.append(c)
                all_species.update(c.keys())
            except Exception:
                comps.append({})

        if species_order is None:
            species_order = sorted(list(all_species))
        
        n = len(comps)
        m = len(species_order)
        out = np.zeros((n, m))
        s2i = {s: i for i, s in enumerate(species_order)}
        
        for i, c in enumerate(comps):
            for s, val in c.items():
                if s in s2i:
                    out[i, s2i[s]] = val
        
        if return_species:
            return out, list(species_order)
        return out

    def get_all_lattice_vectors(self, missing="nan", *, fill_missing=True) -> np.ndarray:
        """Return a (N, 3, 3) array of lattice vectors."""
        ids = self.list_ids()
        n = len(ids)
        if missing == "nan":
            out = np.full((n, 3, 3), np.nan, dtype=float)
        elif missing == "zero":
            out = np.zeros((n, 3, 3), dtype=float)
        else:
            out = np.empty((n,), dtype=object)

        for i, cid in enumerate(ids):
            obj = self.get(cid)
            try:
                apm = getattr(obj, "AtomPositionManager", None)
                if apm is not None:
                    l = np.asarray(apm.latticeVectors).reshape(3, 3)
                    if out.ndim == 3:
                        out[i] = l
                    else:
                        out[i] = l
            except Exception:
                pass
        return out

    def get_all_hashes(self, with_ids: bool = False) -> Union[List[str], List[Tuple[int, str]]]:
        """Return hashes for all objects."""
        ids = self.list_ids()
        hashes = []
        for cid in ids:
            obj = self.get(cid)
            h = getattr(obj, "hash", None)
            if h is None and hasattr(obj, "AtomPositionManager"):
                h = getattr(obj.AtomPositionManager, "metadata", {}).get("hash")
            hashes.append(h)
            
        if with_ids:
            return list(zip(ids, hashes))
        return hashes

    def get_all_metadata(self, key: str) -> np.ndarray:
        """Return metadata values for the given key."""
        ids = self.list_ids()
        out = np.empty(len(ids), dtype=object)
        out[:] = None
        for i, cid in enumerate(ids):
            obj = self.get(cid)
            apm = getattr(obj, "AtomPositionManager", None)
            if apm is not None:
                meta = getattr(apm, "metadata", {})
                if key in meta:
                    out[i] = meta[key]
        return out

    def get_keys(self) -> List[str]:
        """Return a list of all available metadata keys across all objects."""
        discovered = set()
        for cid in self.list_ids():
            obj = self.get(cid)
            apm = getattr(obj, "AtomPositionManager", None)
            if apm is not None:
                discovered.update(getattr(apm, "metadata", {}).keys())
        return sorted(list(discovered))

    def get_all_scalars(self, keys: Optional[Sequence[str]] = None, return_keys: bool = False) -> Union[np.ndarray, Tuple[np.ndarray, List[str]]]:
        """Return multiple scalar values for all objects."""
        ids = self.list_ids()
        if keys is None:
            # Discovery is expensive for SQLite as it requires loading all objects
            discovered = set()
            for cid in ids:
                obj = self.get(cid)
                apm = getattr(obj, "AtomPositionManager", None)
                if apm is not None:
                    discovered.update(getattr(apm, "metadata", {}).keys())
            keys = sorted(list(discovered))
            
        n = len(ids)
        m = len(keys)
        out = np.zeros((n, m))
        
        for j, k in enumerate(keys):
            vals = self.get_all_metadata(k)
            for i, v in enumerate(vals):
                if v is not None:
                    try:
                        out[i, j] = float(v)
                    except (TypeError, ValueError):
                        pass
        
        if return_keys:
            return out, list(keys)
        return out

class _LazySQLiteView:
    """Lazy sequence-like view over all objects in SQLiteStorage."""

    def __init__(self, store: SQLiteStorage):
        self._s = store

    def __len__(self) -> int:
        return self._s.count()

    def __iter__(self):
        for cid in self._s.iter_ids():
            yield self._s.get(cid)

    def __getitem__(self, i):
        if isinstance(i, slice):
            ids = self._s.list_ids()[i]
            return [self._s.get(cid) for cid in ids]
        else:
            cid = self._s.list_ids()[i]
            return self._s.get(cid)

