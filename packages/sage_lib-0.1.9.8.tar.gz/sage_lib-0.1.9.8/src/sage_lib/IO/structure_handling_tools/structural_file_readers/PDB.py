from __future__ import annotations
import numpy as np
import os
from collections import defaultdict
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, field

@dataclass
class AtomRecord:
    """
    Structured container for PDB/PDBQT atom metadata.
    Ensures consistent field access and strict alignment during export.
    """
    record: str = "ATOM"
    serial: int = 0
    name: str = ""
    altLoc: str = " "
    resName: str = "MOL"
    chain: str = "A"
    resSeq: int = 1
    iCode: str = " "
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    occ: float = 1.0
    temp: float = 0.0
    element: str = ""
    formal_charge: str = ""
    # PDBQT specific
    q: Optional[float] = None
    type: Optional[str] = None

class PDB:
    def __init__(self, file_location: str = None, name: str = None, **kwargs):
        self.file_location = file_location
        self.name = name
        self.atomCount = 0
        self.atomLabelsList = []
        self.atomPositions = None
        self.info_atoms = {}
        self.connection_list = []
        self._connections = defaultdict(list) # Adjacency dict for internal use

    def _infer_element(self, atom_name: str) -> str:
        """
        Conservative element inference from PDB atom name.
        Uses a whitelist of common two-letter elements.
        """
        s = atom_name.strip()
        if not s: return "X"

        # Remove leading digits (e.g., '1H' -> 'H')
        filtered = "".join([c for c in s if not c.isdigit()])
        if not filtered: return "X"

        # Predefined list of common two-letter elements in structural chemistry
        two_letter_elements = {
            "He", "Li", "Be", "Ne", "Na", "Mg", "Al", "Si", "Cl", "Ar", "Ca",
            "Sc", "Ti", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge",
            "As", "Se", "Br", "Kr", "Rb", "Sr", "Zr", "Nb", "Mo", "Tc", "Ru",
            "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "Xe", "Cs", "Ba",
            "La", "Ce", "Pr", "Nd", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er",
            "Tm", "Yb", "Lu", "Hf", "Ta", "Re", "Os", "Ir", "Pt", "Au", "Hg",
            "Tl", "Pb", "Bi"
        }

        if len(filtered) >= 2:
            candidate = filtered[:2].capitalize()
            if candidate in two_letter_elements:
                return candidate

        return filtered[0].upper()

    def _parse_pdb_line(self, line: str) -> Optional[AtomRecord]:
        """
        Parses PDB ATOM/HETATM fields strictly by fixed width, then parses
        the tail (PDBQT/metadata) more flexibly if space permits.
        """
        if len(line) < 54:
            return None

        record = line[0:6].strip()
        if record not in {"ATOM", "HETATM"}:
            return None

        try:
            # Fixed-width PDB standard parsing
            atom = AtomRecord(
                record=record,
                serial=int(line[6:11].strip() or 0),
                name=line[12:16],           # Preserved spacing for alignment checks
                altLoc=line[16:17],
                resName=line[17:20].strip(),
                chain=line[21:22].strip(),
                resSeq=int(line[22:26].strip() or 0),
                iCode=line[26:27],
                x=float(line[30:38].strip()),
                y=float(line[38:46].strip()),
                z=float(line[46:54].strip()),
                occ=float(line[54:60].strip() or 1.0),
                temp=float(line[60:66].strip() or 0.0),
                element=line[76:78].strip() if len(line) >= 78 else "",
                formal_charge=line[78:80].strip() if len(line) >= 80 else ""
            )

            # PDBQT Tail Parsing (Only if the line length suggests extra data beyond 70)
            if len(line) > 70:
                # We skip columns 76-80 which are standard PDB element/charge
                tail_str = line[66:76] + line[80:]
                tail = tail_str.split()
                for tok in tail:
                    if atom.q is None:
                        try:
                            atom.q = float(tok)
                            continue
                        except ValueError:
                            pass
                    if atom.type is None:
                        if any(c.isalpha() for c in tok):
                            atom.type = tok
                            break

            if not atom.element:
                atom.element = self._infer_element(atom.name)

            return atom
        except (ValueError, IndexError):
            return None

    def _format_pdb_line_standard(self, idx: int, pos: np.ndarray, label: str, info: dict) -> str:
        """
        Formats a standard PDB ATOM line with strict alignment rules.
        """
        r_type = info.get("record", "ATOM") or "ATOM"
        
        # Validation for serial/resSeq
        serial = idx + 1
        if serial > 99999:
            raise ValueError(f"Atom serial {serial} exceeds PDB width (99999).")
            
        resSeq = info.get("res_id", 1) or 1
        if resSeq > 9999 or resSeq < -999:
             raise ValueError(f"Residue sequence {resSeq} exceeds PDB width (4 chars).")

        name = info.get("atom_name", label) or label
        name = name.strip()
        element = label[:2].upper().strip()
        
        # Atom name alignment:
        # Rule: 4 chars total. 
        # If element is 1-char (e.g. 'C'), name is 1-3 chars, start at column 14 (idx 13).
        # If element is 2-char (e.g. 'FE'), or name is 4-char, start at column 13 (idx 12).
        if len(name) >= 4:
            name_field = name[:4]
        elif len(element) == 2:
            name_field = f"{name:<4}"[:4]
        else:
            name_field = f" {name:<3}"[:4]

        alt = info.get("alt_loc", " ") or " "
        resName = info.get("res_name", "MOL") or "MOL"
        chain = info.get("chain", "A") or "A"
        icode = info.get("insertion", " ") or " "
        
        occ = info.get("occupancy") if info.get("occupancy") is not None else 1.0
        temp = info.get("temp_factor") if info.get("temp_factor") is not None else 0.0
        f_charge = info.get("formal_charge", "") or ""

        return (
            f"{r_type:<6}"
            f"{serial:>5} "
            f"{name_field}"
            f"{alt:1}"
            f"{resName:>3} "
            f"{chain:1}"
            f"{resSeq:>4}"
            f"{icode:1}   "
            f"{pos[0]:>8.3f}"
            f"{pos[1]:>8.3f}"
            f"{pos[2]:>8.3f}"
            f"{occ:>6.2f}"
            f"{temp:>6.2f}"
            f"{'':>10}"
            f"{element:>2}"
            f"{f_charge:>2}"
        )

    def _format_pdbqt_line(self, idx: int, pos: np.ndarray, label: str, info: dict) -> str:
        """
        Formats a PDBQT-style ATOM line.
        Partial charge at 71-76 (6.3f), Atom type at 78-79.
        """
        # Start with standard PDB up to column 66 (idx 66)
        base = self._format_pdb_line_standard(idx, pos, label, info)
        base = base[:66].ljust(70)

        q = info.get("partial_charge", 0.0) if info.get("partial_charge") is not None else 0.0
        atype = info.get("type_pdbqt", label) or label
        
        return base + f"{q:>6.3f} " + f"{atype:>2}"

    def _format_pdb_line(self, idx: int, pos: np.ndarray, label: str, info: dict, pdbqt: bool = False) -> str:
        """ Dispatcher for formatting. """
        if pdbqt:
            return self._format_pdbqt_line(idx, pos, label, info)
        return self._format_pdb_line_standard(idx, pos, label, info)

    def read_PDB(self, filename: str, save: bool = True, verbose: bool = False) -> dict:
        """
        Reads a PDB/PDBQT file with multi-model (trajectory) and metadata support.
        """
        models: List[List[AtomRecord]] = []
        current_atoms: List[AtomRecord] = []
        connections = defaultdict(list)
        
        if not os.path.exists(filename):
            if verbose: print(f"File not found: {filename}")
            return {}

        try:
            with open(filename, 'r', encoding='utf-8', errors='replace') as f:
                for line in f:
                    if len(line) < 6: continue
                    rec = line[0:6].strip()
                    
                    if rec == "MODEL":
                        if current_atoms:
                            models.append(current_atoms)
                        current_atoms = []
                    
                    elif rec in {"ATOM", "HETATM"}:
                        atom = self._parse_pdb_line(line)
                        if atom:
                            current_atoms.append(atom)
                    
                    elif rec == "ENDMDL":
                        if current_atoms:
                            models.append(current_atoms)
                            current_atoms = []
                    
                    elif rec == "END":
                        if current_atoms:
                            models.append(current_atoms)
                            current_atoms = []
                    
                    elif rec == "CONECT":
                        toks = line.split()[1:]
                        if len(toks) >= 2:
                            try:
                                src = int(toks[0]) - 1
                                for t in toks[1:]:
                                    target = int(t) - 1
                                    connections[src].append(target)
                            except ValueError:
                                pass
        except Exception as e:
            if verbose: print(f"Error reading PDB '{filename}': {e}")
            return {}

        # Final flush
        if current_atoms:
            models.append(current_atoms)
        
        if not models:
            return {}

        # Model consistency check
        n_atoms_ref = len(models[0])
        consistent = True
        for i, m in enumerate(models):
            if len(m) != n_atoms_ref:
                if verbose: 
                    print(f"Warning: Model {i+1} has {len(m)} atoms, but Model 1 has {n_atoms_ref}.")
                consistent = False

        # Process first model for SAGE object state
        first_frame = models[0]
        N = len(first_frame)
        pos = np.zeros((N, 3))
        labels = []
        charges = np.zeros(N)
        
        info = {k: [] for k in [
            "record", "atom_name", "alt_loc", "res_name", "res_id", 
            "insertion", "chain", "occupancy", "temp_factor", 
            "formal_charge", "type_pdbqt", "partial_charge"
        ]}
        
        for i, a in enumerate(first_frame):
            pos[i] = [a.x, a.y, a.z]
            labels.append(a.element)
            charge_val = a.q if a.q is not None else 0.0
            charges[i] = charge_val
            
            info["record"].append(a.record)
            info["atom_name"].append(a.name)
            info["alt_loc"].append(a.altLoc)
            info["res_name"].append(a.resName)
            info["res_id"].append(a.resSeq)
            info["insertion"].append(a.iCode)
            info["chain"].append(a.chain)
            info["occupancy"].append(a.occ)
            info["temp_factor"].append(a.temp)
            info["formal_charge"].append(a.formal_charge)
            info["type_pdbqt"].append(a.type)
            info["partial_charge"].append(charge_val)

        if save:
            try:
                # Prepare all data before modifying self to ensure atomic update
                self._update_state(pos, labels, N, charges, info, connections)
            except Exception as e:
                if verbose: print(f"Error updating PDB state: {e}")

        return {
            "n_models": len(models),
            "models": models,
            "consistent": consistent,
            "connections": connections,
            "first_model_data": {
                "positions": pos,
                "labels": labels,
                "charges": charges,
                "info_atoms": info
            }
        }

    def _update_state(self, pos, labels, N, charges, info, connections):
        """ Atomic update of object state. """
        if hasattr(self, "configure"):
            self.configure(
                atomPositions=pos,
                atomLabels=labels,
                latticeVectors=np.zeros((3, 3)),
            )
        else:
            self.atomPositions = pos
            self.atomLabelsList = labels
            self.atomCount = N
        
        self.charge = charges
        self.info_atoms = info
        self._connections = connections
        self.connection_list = [(s, t) for s, ts in connections.items() for t in ts]

    def export_as_PDB(self, file_location: str = None, save_to_file: bool = True, 
                      verbose: bool = False, pdbqt: bool = False) -> str:
        """
        Exports the current structure to PDB or PDBQT format.
        Ensures strict field alignment and correctly handles file extensions and TER records.
        """
        pos = getattr(self, "atomPositions", None)
        labels = getattr(self, "atomLabelsList", None)
        if pos is None or labels is None:
             raise AttributeError("Structure is missing positions or labels for export.")
             
        n_atoms = len(pos)
        path = file_location or getattr(self, "file_location", "output.pdb")
        
        if not path.lower().endswith((".pdb", ".pdbqt")):
            path += ".pdbqt" if pdbqt else ".pdb"

        info = getattr(self, "info_atoms", {})
        pdb_lines = []
        
        last_chain = None
        
        # Write Atoms
        for i in range(n_atoms):
            # Extract metadata safely (NumPy compatible)
            atom_info = {
                k: v[i] if (v is not None and len(v) > i) else None 
                for k, v in info.items()
            }
            
            # TER Record insertion logic
            current_chain = atom_info.get("chain")
            if i > 0 and last_chain is not None and current_chain != last_chain:
                # Insert TER before chain change
                ter_line = f"TER   {i:>5}      {info.get('res_name', ['MOL'])[i-1]:>3} {last_chain:1}{info.get('res_id', [1])[i-1]:>4}"
                pdb_lines.append(ter_line)
            
            line = self._format_pdb_line(i, pos[i], labels[i], atom_info, pdbqt)
            pdb_lines.append(line)
            last_chain = current_chain

        # Final TER if we have chains
        if last_chain is not None:
             ter_line = f"TER   {n_atoms+1:>5}      {info.get('res_name', ['MOL'])[-1]:>3} {last_chain:1}{info.get('res_id', [1])[-1]:>4}"
             pdb_lines.append(ter_line)

        # Write Connections (CONECT)
        conn_dict = getattr(self, "_connections", None)
        if not conn_dict and hasattr(self, "connection_list") and self.connection_list:
            conn_dict = defaultdict(list)
            for s, t in self.connection_list:
                conn_dict[s].append(t)
                
        if conn_dict:
            for src in sorted(conn_dict.keys()):
                targets = sorted(set(conn_dict[src]))
                for i in range(0, len(targets), 4):
                    chunk = targets[i:i+4]
                    conn_line = f"CONECT{src+1:>5}" + "".join(f"{t+1:>5}" for t in chunk)
                    pdb_lines.append(conn_line)

        pdb_lines.append("END")
        pdb_str = "\n".join(pdb_lines) + "\n"

        if save_to_file:
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(pdb_str)
                if verbose: print(f"Structure saved to: {path}")
            except Exception as e:
                if verbose: print(f"Failed to save file: {e}")

        return pdb_str