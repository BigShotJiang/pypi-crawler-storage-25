from __future__ import annotations
class BasePartition:
    def __init__(self, *args, **kwargs):
        # Inicialización propia de BasePartition
        # Consume arguments if this is the end of the chain before object
        pass
        