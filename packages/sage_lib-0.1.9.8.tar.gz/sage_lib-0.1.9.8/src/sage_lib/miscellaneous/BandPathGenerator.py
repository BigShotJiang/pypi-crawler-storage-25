from __future__ import annotations
import sys
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional, Any

try:
    import numpy as np
except ImportError as e:
    sys.stderr.write(f"An error occurred while importing numpy: {str(e)}\n")

try:
    from ..IO.structure_handling_tools.AtomPosition import AtomPosition
except ImportError as e:
    # Fallback inheritance if AtomPosition is not easily imported directly
    class AtomPosition:
        def __init__(self, name: str = None, file_location: str = None):
            self.name = name
            self.file_location = file_location
            self.latticeVectors = None
            self.latticeType = "CUB"

@dataclass(frozen=True)
class SpecialPoint:
    label: str
    frac_coords: Tuple[float, float, float]

@dataclass(frozen=True)
class BandPathDefinition:
    points: Dict[str, Tuple[float, float, float]]
    path: List[Tuple[str, str]]

class BandPathGenerator(AtomPosition):
    def __init__(self, file_location: str = None, name: str = None, Periodic_Object: Any = None, **kwargs):
        if Periodic_Object is not None:
            self.__dict__.update(Periodic_Object.__dict__)
        else:
            super().__init__(name=name, file_location=file_location)
            
        self._high_symmetry_points = None 
        self._high_symmetry_points_path = None
        
        # Load standard paths (both static and dynamically parsed from ASE)
        self.paths = self._load_standard_paths()
        
        # Legacy compatibility database mappings
        self.lattice_points = {}
        for lat_name, bp_def in self.paths.items():
            legacy_entry = {"path": []}
            path_labels = []
            for start, end in bp_def.path:
                if not path_labels or path_labels[-1] != start:
                    path_labels.append(start)
                path_labels.append(end)
            legacy_entry["path"] = [("Gamma" if x in ("G", "Gamma") else x) for x in path_labels]
            
            for lbl, coords in bp_def.points.items():
                lbl_name = "Gamma" if lbl in ("G", "Gamma") else lbl
                legacy_entry[lbl_name] = np.array([coords[0], coords[1], coords[2], lbl_name], dtype=object)
            self.lattice_points[lat_name] = legacy_entry

    def _load_standard_paths(self) -> Dict[str, BandPathDefinition]:
        paths = {}
        
        # 1. Attempt to load dynamically from system's ASE library to get 20+ exact Bravais subcases
        try:
            import ase.lattice as lat
            for v in lat.all_variants():
                variant_name = v.variant.upper()
                points = {lbl: tuple(map(float, coords)) for lbl, coords in v.get_special_points().items()}
                
                # Parse the path segments
                segments = []
                for subpath in v.special_path.split(","):
                    labels = sorted(list(points.keys()), key=len, reverse=True)
                    idx = 0
                    parsed_labels = []
                    while idx < len(subpath):
                        matched = False
                        for label in labels:
                            if subpath[idx:].startswith(label):
                                parsed_labels.append(label)
                                idx += len(label)
                                matched = True
                                break
                        if not matched:
                            parsed_labels.append(subpath[idx])
                            idx += 1
                    
                    for start, end in zip(parsed_labels[:-1], parsed_labels[1:]):
                        segments.append((start, end))
                
                bp_def = BandPathDefinition(points=points, path=segments)
                paths[variant_name] = bp_def
                
                # Add friendly family name as fallback
                family_name = v.name.upper()
                if family_name not in paths:
                    paths[family_name] = bp_def
        except Exception:
            pass

        # 2. Complete, robust Setyawan-Curtarolo static fallbacks to guarantee basic support
        fallbacks = {
            "CUB": BandPathDefinition(
                points={"G": (0.0, 0.0, 0.0), "X": (0.0, 0.5, 0.0), "M": (0.5, 0.5, 0.0), "R": (0.5, 0.5, 0.5)},
                path=[("G", "X"), ("X", "M"), ("M", "G"), ("G", "R"), ("R", "X"), ("M", "R")]
            ),
            "FCC": BandPathDefinition(
                points={
                    "G": (0.0, 0.0, 0.0), "X": (0.5, 0.0, 0.5), "W": (0.5, 0.25, 0.75),
                    "K": (0.375, 0.375, 0.75), "L": (0.5, 0.5, 0.5), "U": (0.625, 0.25, 0.625)
                },
                path=[
                    ("G", "X"), ("X", "W"), ("W", "K"), ("K", "G"), ("G", "L"),
                    ("L", "U"), ("U", "W"), ("W", "L"), ("L", "K")
                ]
            ),
            "BCC": BandPathDefinition(
                points={"G": (0.0, 0.0, 0.0), "H": (0.5, -0.5, 0.5), "P": (0.25, 0.25, 0.25), "N": (0.0, 0.0, 0.5)},
                path=[("G", "H"), ("H", "N"), ("N", "G"), ("G", "P"), ("P", "H"), ("P", "N")]
            ),
            "HEX": BandPathDefinition(
                points={
                    "G": (0.0, 0.0, 0.0), "M": (0.5, 0.0, 0.0), "K": (1.0/3.0, 1.0/3.0, 0.0),
                    "A": (0.0, 0.0, 0.5), "L": (0.5, 0.0, 0.5), "H": (1.0/3.0, 1.0/3.0, 0.5)
                },
                path=[
                    ("G", "M"), ("M", "K"), ("K", "G"), ("G", "A"), ("A", "L"),
                    ("L", "H"), ("H", "A"), ("L", "M"), ("K", "H")
                ]
            ),
            "TET": BandPathDefinition(
                points={
                    "G": (0.0, 0.0, 0.0), "X": (0.0, 0.5, 0.0), "M": (0.5, 0.5, 0.0),
                    "Z": (0.0, 0.0, 0.5), "R": (0.0, 0.5, 0.5), "A": (0.5, 0.5, 0.5)
                },
                path=[
                    ("G", "X"), ("X", "M"), ("M", "G"), ("G", "Z"), ("Z", "R"),
                    ("R", "A"), ("A", "Z"), ("X", "R"), ("M", "A")
                ]
            ),
            "ORC": BandPathDefinition(
                points={
                    "G": (0.0, 0.0, 0.0), "X": (0.5, 0.0, 0.0), "Y": (0.0, 0.5, 0.0),
                    "Z": (0.0, 0.0, 0.5), "S": (0.5, 0.5, 0.0), "T": (0.0, 0.5, 0.5),
                    "U": (0.5, 0.0, 0.5), "R": (0.5, 0.5, 0.5)
                },
                path=[
                    ("G", "X"), ("X", "S"), ("S", "Y"), ("Y", "G"), ("G", "Z"),
                    ("Z", "U"), ("U", "R"), ("R", "T"), ("T", "Z"), ("Y", "T"),
                    ("U", "X"), ("S", "R")
                ]
            )
        }

        # Backwards compatible alias mapping
        for k, v in fallbacks.items():
            if k not in paths:
                paths[k] = v
            alias = k
            if k == "CUB": alias = "SIMPLECUBIC"
            elif k == "TET": alias = "TETRAGONAL"
            elif k == "ORC": alias = "ORTHORHOMBIC"
            elif k == "HEX": alias = "HEXAGONAL"
            elif k == "MCL": alias = "MONOCLINIC"
            elif k == "TRI1": alias = "TRICLINIC"
            
            if alias not in paths:
                paths[alias] = v
                
        return paths

    def register_path(self, name: str, points: Dict[str, Tuple[float, float, float]], path: List[Tuple[str, str]]) -> None:
        name = name.upper()
        self._validate_path(points, path)
        bp_def = BandPathDefinition(points=points, path=path)
        self.paths[name] = bp_def
        
        # Sync with legacy compatibility database
        legacy_entry = {"path": []}
        path_labels = []
        for start, end in path:
            if not path_labels or path_labels[-1] != start:
                path_labels.append(start)
            path_labels.append(end)
        legacy_entry["path"] = [("Gamma" if x in ("G", "Gamma") else x) for x in path_labels]
        for lbl, coords in points.items():
            lbl_name = "Gamma" if lbl in ("G", "Gamma") else lbl
            legacy_entry[lbl_name] = np.array([coords[0], coords[1], coords[2], lbl_name], dtype=object)
        self.lattice_points[name] = legacy_entry

    def _validate_path(self, points: Dict[str, Tuple[float, float, float]], path: List[Tuple[str, str]]) -> None:
        for start, end in path:
            if start not in points:
                raise ValueError(f"Unknown k-point label: {start}")
            if end not in points:
                raise ValueError(f"Unknown k-point label: {end}")

    def get_definition(self, lattice: str) -> BandPathDefinition:
        lattice = lattice.upper()
        # Common user variants mapping
        mapping = {
            "SC": "CUB",
            "SIMPLECUBIC": "CUB",
            "TETRAGONAL": "TET",
            "ORTHORHOMBIC": "ORC",
            "HEXAGONAL": "HEX",
            "MONOCLINIC": "MCL",
            "TRICLINIC": "TRI1A",
            "TRI": "TRI1A"
        }
        lattice = mapping.get(lattice, lattice)
        if lattice not in self.paths:
            available = ", ".join(sorted(self.paths.keys()))
            raise ValueError(f"Unsupported lattice '{lattice}'. Available: {available}")
        return self.paths[lattice]

    def get_lattice_definition(self) -> BandPathDefinition:
        """
        Dynamically extracts structural lattice vectors (if defined on this object) and detects
        the exact Setyawan-Curtarolo variant. Falls back to default 'CUB' if no lattice is available.
        """
        lat_vecs = getattr(self, "latticeVectors", None)
        if lat_vecs is not None:
            try:
                from ase.cell import Cell
                cell = Cell(lat_vecs)
                bravais = cell.get_bravais_lattice()
                variant_name = bravais.variant.upper()
                
                # Fetch points and path segments computed dynamically for this exact cell parameters!
                points = {lbl: tuple(map(float, coords)) for lbl, coords in bravais.get_special_points().items()}
                
                segments = []
                for subpath in bravais.special_path.split(","):
                    labels = sorted(list(points.keys()), key=len, reverse=True)
                    idx = 0
                    parsed_labels = []
                    while idx < len(subpath):
                        matched = False
                        for label in labels:
                            if subpath[idx:].startswith(label):
                                parsed_labels.append(label)
                                idx += len(label)
                                matched = True
                                break
                        if not matched:
                            parsed_labels.append(subpath[idx])
                            idx += 1
                    
                    for start, end in zip(parsed_labels[:-1], parsed_labels[1:]):
                        segments.append((start, end))
                        
                return BandPathDefinition(points=points, path=segments)
            except Exception:
                pass
                
        # Default fallback
        lattice_type = getattr(self, "latticeType", "CUB")
        return self.get_definition(lattice_type)

    def interpolate(self, lattice: str = None, points_per_segment: int = 20, include_endpoint: bool = True) -> List[Tuple[float, float, float, str]]:
        if lattice is None:
            definition = self.get_lattice_definition()
        else:
            definition = self.get_definition(lattice)
            
        output = []
        for start_label, end_label in definition.path:
            start = np.array(definition.points[start_label], dtype=float)
            end = np.array(definition.points[end_label], dtype=float)

            for i in range(points_per_segment):
                t = i / points_per_segment
                k = (1.0 - t) * start + t * end
                label = start_label if i == 0 else ""
                output.append((float(k[0]), float(k[1]), float(k[2]), label))

        if include_endpoint:
            final_label = definition.path[-1][1]
            final = definition.points[final_label]
            output.append((float(final[0]), float(final[1]), float(final[2]), final_label))

        return output

    def to_vasp_kpoints(self, lattice: str = None, points_per_segment: int = 20, comment: str = "Band path generated by SAGE") -> str:
        if lattice is None:
            definition = self.get_lattice_definition()
        else:
            definition = self.get_definition(lattice)

        lines = [
            comment,
            str(points_per_segment),
            "Line-mode",
            "reciprocal",
        ]

        for start_label, end_label in definition.path:
            start = definition.points[start_label]
            end = definition.points[end_label]

            lines.append(f"{start[0]: .8f} {start[1]: .8f} {start[2]: .8f} ! {start_label}")
            lines.append(f"{end[0]: .8f} {end[1]: .8f} {end[2]: .8f} ! {end_label}")
            lines.append("")

        return "\n".join(lines)

    def to_qe_kpoints(self, lattice: str = None, points_per_segment: int = 20) -> str:
        if lattice is None:
            definition = self.get_lattice_definition()
        else:
            definition = self.get_definition(lattice)

        lines = [
            "K_POINTS crystal_b",
            str(len(definition.points))
        ]

        for lbl, coords in definition.points.items():
            lines.append(f"{coords[0]: .8f} {coords[1]: .8f} {coords[2]: .8f} {points_per_segment} ! {lbl}")

        return "\n".join(lines)

    # =========================================================================
    # LEGACY API COMPATIBILITY LAYER
    # =========================================================================

    @property
    def high_symmetry_points_path(self) -> List[List[np.ndarray]]:
        if self._high_symmetry_points_path is not None:
            return self._high_symmetry_points_path
        self._high_symmetry_points_path = self.get_high_symmetry_points_path()
        return self._high_symmetry_points_path

    @property
    def high_symmetry_points(self) -> Dict[str, Any]:
        if self._high_symmetry_points is not None:
            return self._high_symmetry_points
        self._high_symmetry_points = self.get_high_symmetry_points()
        return self._high_symmetry_points

    def get_high_symmetry_points(self, latticeType: str = None) -> Dict[str, Any]:
        latticeType = latticeType if latticeType is not None else getattr(self, "latticeType", None)
        if not latticeType:
            try:
                def_path = self.get_lattice_definition()
            except Exception:
                def_path = self.get_definition("CUB")
        else:
            def_path = self.get_definition(latticeType)

        legacy_dict = {}
        path_labels = []
        for start, end in def_path.path:
            if not path_labels or path_labels[-1] != start:
                path_labels.append(start)
            path_labels.append(end)

        legacy_dict['path'] = [("Gamma" if x in ("G", "Gamma") else x) for x in path_labels]
        for lbl, coords in def_path.points.items():
            lbl_name = "Gamma" if lbl in ("G", "Gamma") else lbl
            legacy_dict[lbl_name] = np.array([coords[0], coords[1], coords[2], lbl_name], dtype=object)

        self._high_symmetry_points = legacy_dict
        return legacy_dict

    def get_high_symmetry_points_path(self, high_symmetry_points: dict = None) -> List[List[np.ndarray]]:
        hsp = high_symmetry_points if high_symmetry_points is not None else self.high_symmetry_points
        segments = []
        for hsp_n, hsp_n1 in zip(hsp['path'][:-1], hsp['path'][1:]):
            segments.append([hsp[hsp_n], hsp[hsp_n1]])
        self._high_symmetry_points_path = segments
        return segments
