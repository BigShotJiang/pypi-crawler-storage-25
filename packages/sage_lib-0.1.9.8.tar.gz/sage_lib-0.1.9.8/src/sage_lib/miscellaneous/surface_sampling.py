from __future__ import annotations
import numpy as np
from sage_lib.miscellaneous.marching_cubes import generate_offset_mesh
from sage_lib.miscellaneous.fibonacci_surface import generate_fibonacci_offset_surface

def generate_offset_surface(
    positions: np.ndarray,
    d: float,
    method: str = "marching_cubes",
    resolution: int = 50,
    padding: float = 0.1,
    lattice: np.ndarray | None = None,
    pbc: tuple[bool, bool, bool] = (True, True, True),
    slab: bool = False,
    per_atom: bool = True,
    remove_duplicates: bool = True,
    min_sep: float | None = None,
    rng_seed: int | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Unified entry point for SAGE offset surface sampling.
    
    Parameters
    ----------
    positions : np.ndarray
        Shape (N, 3), coordinate anchor positions.
    d : float
        Offset distance.
    method : str
        Sampling backend: 'marching_cubes' (default) or 'fibonacci'.
    resolution : int
        Grid density for marching cubes or Fibonacci directions per anchor.
    padding : float
        Padding factor for marching cubes (ignored for Fibonacci).
    lattice : np.ndarray | None
        Unit cell vectors (ignored for Fibonacci).
    pbc : tuple of bool
        Periodic boundaries along axes (ignored for Fibonacci).
    slab : bool
        If True, only keep directions in +z hemisphere (Fibonacci only).
    per_atom : bool
        If True, sample directions per anchor atom (Fibonacci only).
    remove_duplicates : bool
        If True, prune overlapping vertices (Fibonacci only).
    min_sep : float | None
        Minimum pairwise distance threshold for thinning (Fibonacci only).
    rng_seed : int | None
        Optional seed for randomization (Fibonacci only).
        
    Returns
    -------
    verts : (M, 3) ndarray
        Generated candidates.
    faces : (F, 3) ndarray
        Mesh faces (empty for Fibonacci).
    normals : (M, 3) ndarray
        Surface normals pointing outwards.
    """
    method_lower = str(method).lower()
    
    if method_lower == "fibonacci":
        return generate_fibonacci_offset_surface(
            positions=positions,
            d=d,
            resolution=resolution,
            slab=slab,
            per_atom=per_atom,
            remove_duplicates=remove_duplicates,
            min_sep=min_sep,
            rng_seed=rng_seed,
        )
    else:
        return generate_offset_mesh(
            points=positions,
            d=d,
            resolution=resolution,
            padding=padding,
            lattice=lattice,
            pbc=pbc,
        )
