from __future__ import annotations
import numpy as np

def _fibonacci_directions(m: int, slab: bool = False) -> np.ndarray:
    """
    Evenly distributed unit vectors on the sphere using a spherical Fibonacci grid.
    If slab=True, keep only +z hemisphere (guaranteeing at least one vector).
    """
    m = max(1, int(m))
    i = np.arange(m, dtype=np.float64) + 0.5
    phi = (1.0 + 5.0**0.5) / 2.0  # golden ratio
    theta = (2.0 * np.pi) * ((i / phi) % 1.0)
    z = 1.0 - 2.0 * i / m
    r = np.sqrt(np.maximum(0.0, 1.0 - z*z))
    dirs = np.stack([r*np.cos(theta), r*np.sin(theta), z], axis=1)
    if slab:
        dirs = dirs[dirs[:, 2] >= 0.0]
        if dirs.size == 0:
            dirs = np.array([[0.0, 0.0, 1.0]], dtype=np.float64)
    # normalize for safety
    dirs /= (np.linalg.norm(dirs, axis=1, keepdims=True) + 1e-15)
    return dirs

def _poisson_disk_thin(
    verts: np.ndarray,
    min_sep: float,
    cell_size: float | None = None,
    rng_seed: int | None = None
) -> np.ndarray:
    """
    Poisson-disk thinning via 3D grid-hash. Returns a subset of `verts`
    such that all pairwise distances are >= min_sep.
    """
    verts = np.asarray(verts, dtype=np.float64)
    N = len(verts)
    if N == 0 or min_sep <= 0.0:
        return verts

    rng = np.random.RandomState(rng_seed)
    order = rng.permutation(N)

    cs = float(cell_size) if cell_size is not None else (min_sep / np.sqrt(3.0))
    inv = 1.0 / cs

    # Grid: tuple(i,j,k) -> list of accepted indices that live in this cell
    grid: dict[tuple[int, int, int], list[int]] = {}
    accepted_idx: list[int] = []

    # Neighbor offsets (3x3x3 Moore neighborhood)
    offs = [(dx, dy, dz) for dx in (-1, 0, 1)
                       for dy in (-1, 0, 1)
                       for dz in (-1, 0, 1)]

    r2_min = min_sep * min_sep

    for idx in order:
        p = verts[idx]
        key = tuple(np.floor(p * inv).astype(int))
        ok = True
        for dx, dy, dz in offs:
            nb_key = (key[0] + dx, key[1] + dy, key[2] + dz)
            cell = grid.get(nb_key)
            if not cell:
                continue
            # Check against all points accepted in neighbor cell(s)
            q = verts[cell]  # shape (K, 3)
            d2 = np.einsum('ij,ij->i', q - p, q - p)
            if np.any(d2 < r2_min):
                ok = False
                break
        if ok:
            accepted_idx.append(idx)
            grid.setdefault(key, []).append(idx)

    return verts[np.asarray(accepted_idx, dtype=int)]

def generate_fibonacci_offset_surface(
    positions: np.ndarray,
    d: float,
    resolution: int = 50,
    slab: bool = False,
    per_atom: bool = True,
    remove_duplicates: bool = True,
    min_sep: float | None = None,
    rng_seed: int | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate adsorption candidate points using Fibonacci directions.

    Interface compatible with generate_offset_mesh output style.

    Parameters
    ----------
    positions : (N, 3) ndarray
        Anchor atom positions.
    d : float
        Offset distance from each anchor atom.
    resolution : int
        Number of Fibonacci directions per anchor atom.
    slab : bool
        If True, only keep +z hemisphere directions.
    per_atom : bool
        If True, generate directions around every anchor atom.
        If False, generate around the geometric center of all anchors.
    remove_duplicates : bool
        If True, apply Poisson-disk thinning.
    min_sep : float | None
        Minimum distance between retained surface points.
        If None, uses 0.5 * d.
    rng_seed : int | None
        Optional seed for thinning order.

    Returns
    -------
    verts : (M, 3) ndarray
        Candidate adsorption sites.
    faces : (0, 3) ndarray
        Empty array, for compatibility with marching-cubes interface.
    normals : (M, 3) ndarray
        Outward directions associated with each point.
    """
    positions = np.atleast_2d(np.asarray(positions, dtype=np.float64))

    if positions.shape[1] != 3:
        raise ValueError("positions must have shape (N, 3).")

    if d <= 0.0:
        raise ValueError("d must be positive.")

    resolution = max(1, int(resolution))

    dirs = _fibonacci_directions(resolution, slab=slab)

    if per_atom:
        verts = positions[:, None, :] + d * dirs[None, :, :]
        normals = np.broadcast_to(dirs[None, :, :], verts.shape)

        verts = verts.reshape(-1, 3)
        normals = normals.reshape(-1, 3)
    else:
        center = positions.mean(axis=0)
        verts = center[None, :] + d * dirs
        normals = dirs.copy()

    if remove_duplicates and len(verts) > 0:
        if min_sep is None:
            min_sep = 0.5 * d

        verts = _poisson_disk_thin(
            verts=verts,
            min_sep=float(min_sep),
            rng_seed=rng_seed,
        )

        # Recompute normals from nearest anchor/center
        if per_atom:
            diff = verts[:, None, :] - positions[None, :, :]
            dist2 = np.einsum("mni,mni->mn", diff, diff)
            nearest = np.argmin(dist2, axis=1)
            normals = verts - positions[nearest]
        else:
            center = positions.mean(axis=0)
            normals = verts - center

        normals /= np.linalg.norm(normals, axis=1, keepdims=True) + 1e-15

    faces = np.empty((0, 3), dtype=int)

    return verts, faces, normals
