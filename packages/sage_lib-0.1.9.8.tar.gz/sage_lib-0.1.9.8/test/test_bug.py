import numpy as np

# Suppose num_bonds = 2
p0 = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]], dtype=np.float32)
col = np.array([[0.1, 0.2, 0.3, 0.4], [0.5, 0.6, 0.7, 0.8]], dtype=np.float32)
i_idx = np.array([0, 1])
sel_i = np.array([1, 0])

h0 = np.zeros((2, 16), dtype=np.float32)
h0[:, 0:3] = p0
h0[:, 8:12] = col
h0[:, 12] = i_idx.astype(np.float32)
h0[:, 14] = sel_i

print("H0 array:")
print(h0)

packed = np.empty((2, 2, 16), dtype=np.float32)
packed[:, 0, :] = h0
packed[:, 1, :] = h0 * 2

p1d = np.ascontiguousarray(packed.ravel(), dtype=np.float32)
print("P1D flat layout:")
print(p1d[:32])
