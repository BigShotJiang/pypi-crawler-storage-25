import numpy as np

idx = np.array([1, 2, 3], dtype=np.uint32)
rep = np.array([0, 0, 0], dtype=np.uint32)

stacked = np.column_stack([idx, rep])
print("Is C contiguous?", stacked.flags['C_CONTIGUOUS'])
print("Is F contiguous?", stacked.flags['F_CONTIGUOUS'])

stacked_cast = stacked.astype(np.uint32)
print("Cast C contiguous?", stacked_cast.flags['C_CONTIGUOUS'])
