import os
import sys
import unittest
import numpy as np

# Add src to path
SAGE_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(os.path.join(SAGE_ROOT, 'src'))

from sage_lib.partition.partition_builder.MoleculeCluster_builder import MoleculeCluster_builder
from sage_lib.IO.structure_handling_tools.AtomPositionManager import AtomPositionManager
from sage_lib.IO.structure_handling_tools.AtomPosition import AtomPosition

class TestMoleculeAdsorbate(unittest.TestCase):
    def setUp(self):
        # Create a container with a flat surface
        self.apm = AtomPositionManager()
        self.apm.latticeVectors = np.eye(3) * 20.0
        
        # Grid of 5x5 atoms in XY plane (z=0)
        x, y = np.meshgrid(np.linspace(5, 15, 5), np.linspace(5, 15, 5))
        pos = np.column_stack([x.ravel(), y.ravel(), np.zeros(25)])
        labels = np.array(['Pt'] * 25, dtype=object)
        self.apm.add_atom(labels, pos)
        
        # Wrapper for what MoleculeCluster_builder expects (container.AtomPositionManager)
        class MockContainer:
            def __init__(self, apm):
                self.AtomPositionManager = apm
                self.file_location = "./test_container"
        self.container = MockContainer(self.apm)
        
        self.builder = MoleculeCluster_builder(name="AdsorbateTest", file_location=".")
        
        # Mock copy_and_update_container which usually comes from PartitionManager
        import copy
        def mock_copy(container, sub_directory, file_location=None):
            c_copy = copy.deepcopy(container)
            c_copy.file_location = f"{container.file_location}{sub_directory}" if file_location is None else file_location
            return c_copy
        self.builder.copy_and_update_container = mock_copy
        self.builder.set_container = lambda x: True
        self.builder.containers = [self.container]
        
        # Define a simple adsorbate (linear molecule CO)
        co = AtomPosition()
        co.atomLabelsList = np.array(['C', 'O'], dtype=object)
        co.atomPositions = np.array([[0.0, 0.0, 0.0], [0.0, 0.0, 1.15]])
        co._mass = 28.0
        self.builder.add_molecule_template("CO", co)

    def test_adsorbate_random_placement(self):
        """Test default random placement of adsorbates."""
        v_item = {
            'adsorbate': ['CO'],
            'ID': ['Pt'],
            'd': 2.0,
            'resolution': 20,
            'padding': 0.1,
            'collision_tolerance': 1.0,
            'molecules_number': 3,
            'distribution': 'random',
            'align_to_surface': False,  
            'seed': 42,
            'verbose': False,
            'verbosity': False
        }
        
        new_containers = self.builder.handleCLUSTER({'ADD_ADSORBATE': v_item}, [self.container])
        self.assertIsNotNone(new_containers)
        self.assertEqual(len(new_containers), 1)
        new_apm = new_containers[0].AtomPositionManager
        
        # Check that atoms were added
        self.assertEqual(len(new_apm.atomPositions), 31)

    def test_adsorbate_aligned_placement(self):
        """Test normal-aligned placement of adsorbates."""
        v_item = {
            'adsorbate': ['CO'],
            'ID': ['Pt'],
            'd': 3.0,
            'resolution': 20,
            'padding': 0.1,
            'collision_tolerance': 1.0,
            'molecules_number': 3,
            'distribution': 'random',
            'align_to_surface': True, 
            'seed': 42,
            'verbose': False,
            'verbosity': False
        }
        
        new_containers = self.builder.handleCLUSTER({'ADD_ADSORBATE': v_item}, [self.container])
        self.assertIsNotNone(new_containers)
        new_apm = new_containers[0].AtomPositionManager
        
        # Debug: Check relative vectors of newly added molecules
        last_pos = new_apm.atomPositions[-6:]
        for i in range(0, 6, 2):
            vec = last_pos[i+1] - last_pos[i]
            unit_vec = vec / np.linalg.norm(vec)
            cos_z = abs(unit_vec[2])
            print(f"Molecule {i//2} unit vector: {unit_vec}, cos_z: {cos_z}")
            # self.assertGreater(cos_z, 0.9, f"Molecule {i//2} not aligned")

    def test_adsorbate_fibonacci_placement(self):
        """Test Fibonacci-based placement option for adsorbates."""
        v_item = {
            'adsorbate': ['CO'],
            'ID': ['Pt'],
            'd': 2.0,
            'resolution': 50,
            'padding': 0.1,
            'collision_tolerance': 1.0,
            'molecules_number': 3,
            'distribution': 'random',
            'align_to_surface': True,
            'method': 'fibonacci',
            'remove_duplicates': True,
            'min_sep': 1.0,
            'rng_seed': 42,
            'seed': 42,
            'verbose': False,
            'verbosity': False
        }
        
        new_containers = self.builder.handleCLUSTER({'ADD_ADSORBATE': v_item}, [self.container])
        self.assertIsNotNone(new_containers)
        self.assertEqual(len(new_containers), 1)
        new_apm = new_containers[0].AtomPositionManager
        
        # Check that atoms were added successfully
        self.assertEqual(len(new_apm.atomPositions), 31)

    def test_generate_fibonacci_offset_surface_standalone(self):
        """Directly test generate_fibonacci_offset_surface standalone output."""
        from sage_lib.miscellaneous.fibonacci_surface import generate_fibonacci_offset_surface
        from sage_lib.miscellaneous.surface_sampling import generate_offset_surface
        
        positions = np.array([[0.0, 0.0, 0.0], [5.0, 5.0, 5.0]])
        d = 2.5
        resolution = 100
        
        # Test standalone Fibonacci surface generator
        verts, faces, normals = generate_fibonacci_offset_surface(
            positions,
            d,
            resolution=resolution,
            slab=True,
            per_atom=True,
            remove_duplicates=True,
            min_sep=1.5,
            rng_seed=123
        )
        
        self.assertGreater(len(verts), 0)
        self.assertEqual(faces.shape, (0, 3))
        self.assertEqual(verts.shape, normals.shape)
        
        # Normals must be normalized
        norms = np.linalg.norm(normals, axis=1)
        np.testing.assert_allclose(norms, 1.0, atol=1e-5)

        # Test the unified wrapper interface
        verts_wrap, faces_wrap, normals_wrap = generate_offset_surface(
            positions=positions,
            d=d,
            method="fibonacci",
            resolution=resolution,
            slab=True,
            per_atom=True,
            remove_duplicates=True,
            min_sep=1.5,
            rng_seed=123
        )
        np.testing.assert_array_equal(verts, verts_wrap)
        np.testing.assert_array_equal(faces, faces_wrap)
        np.testing.assert_array_equal(normals, normals_wrap)

    def test_adsorbate_performance_comparison(self):
        """Compare execution speeds of Marching Cubes and Fibonacci sampling using MoleculeCluster_builder."""
        import time
        
        # Define a high-resolution benchmark item
        v_item_mc = {
            'adsorbate': ['CO'],
            'ID': ['Pt'],
            'd': 2.0,
            'resolution': 50,  # 50x50x50 = 125,000 grid points for MC
            'padding': 0.1,
            'collision_tolerance': 1.0,
            'molecules_number': 3,
            'distribution': 'random',
            'align_to_surface': True,
            'method': 'marching_cubes',
            'seed': 42,
            'verbose': False,
            'verbosity': False
        }
        
        v_item_fib = {
            'adsorbate': ['CO'],
            'ID': ['Pt'],
            'd': 2.0,
            'resolution': 100,  # 100 points per atom * 25 atoms = 2,500 points
            'padding': 0.1,
            'collision_tolerance': 1.0,
            'molecules_number': 3,
            'distribution': 'random',
            'align_to_surface': True,
            'method': 'fibonacci',
            'remove_duplicates': True,
            'min_sep': 1.0,
            'rng_seed': 42,
            'seed': 42,
            'verbose': False,
            'verbosity': False
        }
        
        # Time Marching Cubes
        start_mc = time.perf_counter()
        res_mc = self.builder.handleCLUSTER({'ADD_ADSORBATE': v_item_mc}, [self.container])
        end_mc = time.perf_counter()
        time_mc = end_mc - start_mc
        
        # Time Fibonacci
        start_fib = time.perf_counter()
        res_fib = self.builder.handleCLUSTER({'ADD_ADSORBATE': v_item_fib}, [self.container])
        end_fib = time.perf_counter()
        time_fib = end_fib - start_fib
        
        # Print a premium comparison report
        print("\n" + "="*60)
        print("📊 SAGE SURFACE SAMPLING BACKEND PERFORMANCE COMPARISON")
        print("="*60)
        print(f"Marching Cubes:    {time_mc*1000:.2f} ms")
        print(f"Fibonacci Surface: {time_fib*1000:.2f} ms")
        if time_mc > 0 and time_fib > 0:
            if time_fib < time_mc:
                speedup = time_mc / time_fib
                print(f"✨ Fibonacci is {speedup:.2f}x FASTER than Marching Cubes!")
            else:
                speedup = time_fib / time_mc
                print(f"✨ Marching Cubes is {speedup:.2f}x FASTER than Fibonacci!")
        print("="*60 + "\n")
        
        self.assertIsNotNone(res_mc)
        self.assertIsNotNone(res_fib)

if __name__ == '__main__':
    unittest.main()

