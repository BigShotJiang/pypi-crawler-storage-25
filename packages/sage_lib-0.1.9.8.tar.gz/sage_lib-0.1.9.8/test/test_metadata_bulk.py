import os
import shutil
import numpy as np
from sage_lib.IO.storage.memory import MemoryStorage
from sage_lib.IO.storage.hybrid import HybridStorage
from sage_lib.IO.storage.composite import CompositeHybridStorage
from sage_lib.partition.PartitionManager import PartitionManager
from sage_lib.single_run.SingleRun import SingleRun

TEST_DIR = "test_metadata_bulk_store"

def cleanup():
    if os.path.exists(TEST_DIR):
        shutil.rmtree(TEST_DIR)

def test_memory_storage_metadata_bulk():
    store = MemoryStorage()
    
    # Add dummy objects
    id0 = store.add("obj0")
    id1 = store.add("obj1")
    
    # Bulk update
    metadata = {
        id0: {"key1": "val1", "energy": 12.3},
        id1: {"key2": "val2", "energy": 45.6}
    }
    store.set_meta_bulk(metadata)
    
    # Check results
    meta0 = store.get_meta(id0)
    meta1 = store.get_meta(id1)
    
    assert meta0["key1"] == "val1"
    assert meta0["energy"] == 12.3
    assert meta1["key2"] == "val2"
    assert meta1["energy"] == 45.6
    
    # Individual set_meta should call set_meta_bulk and also work
    store.set_meta(id0, {"new_key": "new_val"})
    assert store.get_meta(id0) == {"new_key": "new_val"}

def test_hybrid_storage_metadata_bulk():
    cleanup()
    os.makedirs(TEST_DIR, exist_ok=True)
    
    store = HybridStorage(root_dir=TEST_DIR, access="rw")
    
    # Need actual SingleRun objects because HybridStorage parses them
    sr0 = SingleRun(name="sr0")
    sr1 = SingleRun(name="sr1")
    
    id0 = store.add(sr0)
    id1 = store.add(sr1)
    
    metadata = {
        id0: {"key1": "val1"},
        id1: {"key2": "val2"}
    }
    
    store.set_meta_bulk(metadata)
    
    meta0 = store.get_meta(id0)
    meta1 = store.get_meta(id1)
    
    assert meta0["apm_metadata"]["key1"] == "val1"
    assert meta1["apm_metadata"]["key2"] == "val2"
    
    store.close()
    cleanup()

def test_composite_storage_metadata_bulk():
    cleanup()
    os.makedirs(TEST_DIR, exist_ok=True)
    
    base_dir = os.path.join(TEST_DIR, "base")
    local_dir = os.path.join(TEST_DIR, "local")
    os.makedirs(base_dir, exist_ok=True)
    os.makedirs(local_dir, exist_ok=True)
    
    base_store = HybridStorage(root_dir=base_dir, access="rw")
    local_store = HybridStorage(root_dir=local_dir, access="rw")
    
    sr_base = SingleRun(name="base_sr")
    sr_local = SingleRun(name="local_sr")
    
    base_store.add(sr_base)
    local_store.add(sr_local)
    
    base_store.close()
    local_store.close()
    
    # Re-open in composite mode
    base_ro = HybridStorage(root_dir=base_dir, access="ro")
    local_rw = HybridStorage(root_dir=local_dir, access="rw")
    
    composite = CompositeHybridStorage(base_ro, local_rw)
    
    # Logical composite IDs: base has 1 object (ID 0), local has 1 object (ID 1)
    assert composite.count() == 2
    
    metadata = {
        0: {"key_base": "val_base"}, # Should be ignored because it is read-only (base)
        1: {"key_local": "val_local"} # Should be written to local store
    }
    
    composite.set_meta_bulk(metadata)
    
    # Verify local store has it
    meta1 = composite.get_meta(1)
    assert meta1["apm_metadata"]["key_local"] == "val_local"
    
    composite.close()
    cleanup()

def test_partition_manager_metadata_bulk():
    cleanup()
    
    # Test memory mode
    pm_mem = PartitionManager(storage="memory")
    sr0 = SingleRun(name="sr0")
    sr1 = SingleRun(name="sr1")
    
    id0 = pm_mem.add(sr0)
    id1 = pm_mem.add(sr1)
    
    metadata = {
        id0: {"key1": "val1"},
        id1: {"key2": "val2"}
    }
    
    pm_mem.set_metadata_bulk(metadata)
    
    assert pm_mem._store.get_meta(id0) == {"key1": "val1"}
    assert pm_mem._store.get_meta(id1) == {"key2": "val2"}
    
    pm_mem.close()
    cleanup()
