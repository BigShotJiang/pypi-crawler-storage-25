import os
import shutil
import unittest
import numpy as np
import sqlite3
import h5py
import sys

# Ensure sage_lib is in path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))
from sage_lib.IO.storage.hybrid import HybridStorage

class DummyAPM:
    def __init__(self):
        self.metadata = {}
        self.atomLabelsList = ['H']

class MockObj:
    """Mock object representing an atomistic structure with energy and hash."""
    def __init__(self, e=0.0, h=None):
        self.E = e
        self.hash = h or str(e)
        # Mocking AtomPositionManager to avoid errors in add()
        self.AtomPositionManager = DummyAPM()

class TestHybridMergeFAISS(unittest.TestCase):
    def setUp(self):
        self.test_dir = os.path.abspath("test_merge_faiss_workdir")
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
        os.makedirs(self.test_dir)
        
        self.src1_dir = os.path.join(self.test_dir, "src1")
        self.src2_dir = os.path.join(self.test_dir, "src2")
        self.dst_dir = os.path.join(self.test_dir, "merged")

    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def create_db(self, db_path, n_items, start_e, dim=3):
        store = HybridStorage(db_path, access="rw", use_faiss=True, faiss_dim=dim)
        for i in range(n_items):
            e = start_e + i
            oid = store.add(MockObj(e=float(e), h=f"hash_{e}"))
            vec = np.zeros(dim, dtype=np.float32)
            vec[0] = float(e)
            store.add_vector(oid, vec)
        store.close()

    def test_merge_with_faiss(self):
        """Verify that merge_roots_recursive_attach works correctly with FAISS and doesn't raise NameError."""
        dim = 4
        n1, n2 = 5, 3
        
        # 1. Create source databases
        self.create_db(self.src1_dir, n1, start_e=0, dim=dim)
        self.create_db(self.src2_dir, n2, start_e=100, dim=dim)
        
        # 2. Perform merge
        try:
            report = HybridStorage.merge_roots_recursive_attach(
                root_dir=self.test_dir,  # Search for sources under this dir
                dst_root=self.dst_dir,
                use_faiss=True,
                faiss_dim=dim,
                quiet=True
            )
        except NameError as e:
            self.fail(f"merge_roots_recursive_attach raised NameError: {e}")
        except Exception as e:
            self.fail(f"merge_roots_recursive_attach raised unexpected exception: {e}")

        # 3. Verify results
        self.assertEqual(report["objects_added"], n1 + n2)
        
        # 4. Open merged DB and check FAISS
        merged_store = HybridStorage(self.dst_dir, access="ro", use_faiss=True)
        self.assertEqual(merged_store.faiss_index.ntotal, n1 + n2)
        
        # Check a sample vector
        # e=100 should be present
        vec_query = np.zeros(dim, dtype=np.float32)
        vec_query[0] = 100.0
        matches = merged_store.search_vector(vec_query, threshold=0.0001)
        self.assertTrue(len(matches) >= 1)
        
        merged_store.close()

    def test_merge_with_list_and_glob(self):
        """Verify that merge_roots_recursive_attach works correctly when root_dir is a list and contains glob patterns."""
        dim = 4
        n1, n2 = 5, 3
        
        # 1. Create source databases
        self.create_db(self.src1_dir, n1, start_e=0, dim=dim)
        self.create_db(self.src2_dir, n2, start_e=100, dim=dim)
        
        # 2. Perform merge using a list with glob pattern
        report = HybridStorage.merge_roots_recursive_attach(
            root_dir=[self.src1_dir, os.path.join(self.test_dir, "src*")],
            dst_root=self.dst_dir,
            use_faiss=True,
            faiss_dim=dim,
            quiet=True
        )

        # 3. Verify results (should find both src1 and src2; duplicates are deduped by hash so total will be n1 + n2)
        self.assertEqual(report["objects_added"], n1 + n2)
        
        # 4. Open merged DB and check total
        merged_store = HybridStorage(self.dst_dir, access="ro", use_faiss=True)
        self.assertEqual(merged_store.faiss_index.ntotal, n1 + n2)
        merged_store.close()

if __name__ == "__main__":
    unittest.main()
