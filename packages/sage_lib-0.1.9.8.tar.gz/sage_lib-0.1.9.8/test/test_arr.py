import numpy as np

p0 = np.array([[1.0, 2.0, 3.0]], dtype=np.float32)
col = np.array([[0.1, 0.2, 0.3, 0.4]], dtype=np.float32)

h0 = np.zeros((1, 16), dtype=np.float32)
h0[:, 0:3] = p0
h0[:, 8:12] = col

print("H0 array:")
print(h0)
