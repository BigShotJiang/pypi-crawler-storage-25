from __future__ import annotations
import numpy as np
import pytest
from sage_lib.miscellaneous.BandPathGenerator import BandPathGenerator, BandPathDefinition

def test_bandpath_basic():
    # Instantiate without periodic object or POSCAR to test static fallback / ASE loading
    gen = BandPathGenerator()
    
    # 1. Test get_definition for standard systems
    cub_def = gen.get_definition("CUB")
    assert "G" in cub_def.points
    assert "X" in cub_def.points
    assert ("G", "X") in cub_def.path
    
    fcc_def = gen.get_definition("FCC")
    assert "W" in fcc_def.points
    assert "K" in fcc_def.points
    
    # 2. Test registration of custom paths
    custom_points = {"G": (0.0, 0.0, 0.0), "X": (0.5, 0.0, 0.0)}
    custom_path = [("G", "X")]
    gen.register_path("MY_CUSTOM_PATH", custom_points, custom_path)
    
    registered = gen.get_definition("MY_CUSTOM_PATH")
    assert registered.points == custom_points
    assert registered.path == custom_path

def test_bandpath_interpolation_and_exporters():
    gen = BandPathGenerator()
    
    # Test interpolation
    interp = gen.interpolate("CUB", points_per_segment=5, include_endpoint=True)
    # 6 segments in CUB default path -> 6 * 5 + 1 = 31 points
    assert len(interp) == 31
    assert interp[0][3] == "G" # First label is Gamma/G
    assert interp[-1][3] == "R" # End label is last point in path (for CUB it ends at 'R' in default segments)
    
    # Test VASP KPOINTS exporter
    vasp = gen.to_vasp_kpoints("CUB", points_per_segment=15)
    assert "Line-mode" in vasp
    assert "reciprocal" in vasp
    assert " 0.00000000  0.00000000  0.00000000 ! G" in vasp
    
    # Test Quantum ESPRESSO exporter
    qe = gen.to_qe_kpoints("CUB", points_per_segment=15)
    assert "K_POINTS crystal_b" in qe
    assert "4" in qe # CUB has 4 special points

def test_bandpath_legacy_compatibility():
    gen = BandPathGenerator()
    
    # Access legacy properties
    hsp = gen.high_symmetry_points
    assert "path" in hsp
    assert "Gamma" in hsp
    assert isinstance(hsp["Gamma"], np.ndarray)
    assert hsp["Gamma"][3] == "Gamma" # 4th element holds label
    
    hsp_path = gen.high_symmetry_points_path
    assert len(hsp_path) > 0
    assert len(hsp_path[0]) == 2 # Pair of start/end points
    assert hsp_path[0][0][3] == "Gamma"
    assert hsp_path[0][1][3] == "X"

def test_bandpath_bravais_subcases():
    gen = BandPathGenerator()
    
    # Test that Setyawan-Curtarolo subcases exist and can be loaded
    for subcase in ["BCT1", "BCT2", "ORCF1", "ORCF2", "ORCF3", "MCLC1", "TRI1A"]:
        try:
            bp_def = gen.get_definition(subcase)
            assert len(bp_def.points) > 0
            assert len(bp_def.path) > 0
        except ValueError:
            # If not in ASE or fallbacks (e.g. some extremely flat variations), it is fine,
            # but BCT1 and BCT2 should definitely load!
            if subcase in ["BCT1", "BCT2"]:
                pytest.fail(f"Subcase {subcase} must be supported!")
