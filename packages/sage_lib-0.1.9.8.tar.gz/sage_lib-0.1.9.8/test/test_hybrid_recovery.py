
import os
import shutil
import time
import pickle
import h5py
import sqlite3
import numpy as np
from ase import Atoms
from sage_lib.IO.storage.hybrid import HybridStorage

STORE_PATH = "test_recovery_store"

def cleanup():
    if os.path.exists(STORE_PATH):
        try:
            shutil.rmtree(STORE_PATH)
        except Exception:
            pass

def test_recovery():
    print("Testing HybridStorage recovery and repair...")
    cleanup()
    
    # 1. Setup and add data
    storage = HybridStorage(STORE_PATH)
    n_objs = 10
    print(f"[*] Adding {n_objs} objects to initial storage...")
    for i in range(n_objs):
        atom = Atoms('CO', positions=[[0,0,0], [0,0,1.1]], cell=[10,10,10], pbc=True)
        atom.info = {'energy': float(i * -1.5), 'id': i}
        storage.add(atom)
    
    assert storage.count() == n_objs
    h5_path = storage.h5_path
    sqlite_path = storage.sqlite_path
    storage.close()
    
    # 2. Simulate "corruption" by manually renaming files
    # This allows us to test the recovery logic without hitting HDF5 open errors
    # that are unrecoverable via h5py.
    print("[*] Simulating corruption by manual rename...")
    ts_sim = int(time.time())
    backup_h5 = f"{h5_path}.corrupted_{ts_sim}"
    backup_sqlite = f"{sqlite_path}.corrupted_{ts_sim}"
    os.rename(h5_path, backup_h5)
    os.rename(sqlite_path, backup_sqlite)
    
    # Simulate sidecars too
    for ext in ("-wal", "-shm"):
        wal_stale = sqlite_path + ext
        with open(wal_stale, "w") as f:
            f.write("stale data")
        os.rename(wal_stale, backup_sqlite + ext)
    
    # 3. Re-initialize storage (fresh)
    print("[*] Re-initializing storage (fresh)...")
    storage2 = HybridStorage(STORE_PATH)
    
    # Current DB should be fresh (empty)
    assert storage2.count() == 0
    
    # 4. Verify backups exist (including WAL)
    backups = storage2._find_corrupted_backups()
    assert len(backups) >= 1
    ts = sorted(backups.keys())[-1] # take the latest
    assert "h5" in backups[ts]
    assert "sqlite" in backups[ts]
    assert "sqlite-wal" in backups[ts], "WAL sidecar should have been backed up!"
    print(f"[*] Found backups for timestamp {ts}: {list(backups[ts].keys())}")
    
    # 5. Run recovery
    print("[*] Running repair(recover_backups=True)...")
    report = storage2.repair(recover_backups=True, verbose=True)
    print(f"[*] Recovery report: {report}")
    
    # 6. Verify data recovery
    # Even with truncation, h5py can often read early datasets if the root group wasn't destroyed
    final_count = storage2.count()
    print(f"[*] Final recovered count: {final_count} / {n_objs}")
    
    assert final_count > 0, "Should have recovered at least some records!"
    assert report["records_recovered"] == final_count
    assert report["backups_processed"] >= 1
    
    # 7. Check if backups were renamed to .recovered_
    for k, p in backups[ts].items():
        recovered_path = p.replace(".corrupted_", ".recovered_")
        assert os.path.exists(recovered_path), f"Backup {p} should have been renamed to {recovered_path}"

    # 8. Verify metadata of a recovered object
    ids = storage2.list_ids()
    meta = storage2.get_meta(ids[0])
    assert 'energy' in meta
    print(f"[*] Metadata verified for recovered ID {ids[0]}: E={meta['energy']}")

    storage2.close()
    cleanup()
    print("\n[SUCCESS] HybridStorage recovery test passed!")

if __name__ == "__main__":
    try:
        test_recovery()
    except Exception as e:
        print(f"\n[FAILURE] Test failed: {e}")
        import traceback
        traceback.print_exc()
        cleanup()
        exit(1)
