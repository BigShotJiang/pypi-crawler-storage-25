import numpy as np

# Mock visual state
N = 2
pos = np.array([[0.0, 0.0, 0.0], [1.5, 0.0, 0.0]], dtype=np.float32)
colors = np.array([[1,0,0,1], [0,0,1,1]], dtype=np.float32)
bonds = np.array([[0, 1]], dtype=np.int32) 

print("pos", pos)

i_idx, j_idx = bonds[:, 0].astype(int), bonds[:, 1].astype(int)
p0 = pos[i_idx]
p1 = pos[j_idx]
dist = np.linalg.norm(p1 - p0, axis=1)
print("dist", dist)

mid = (p0 + p1) * 0.5
num_bonds = 1
h0 = np.zeros((num_bonds, 16), dtype=np.float32)
h0[:, 0:3], h0[:, 4:7], h0[:, 8:12] = p0, mid, colors[i_idx]
print(h0)
