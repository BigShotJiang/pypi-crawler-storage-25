import numpy as np

num_bonds = 2
h0 = np.zeros((num_bonds, 16), dtype=np.float32)
h1 = np.ones((num_bonds, 16), dtype=np.float32)

packed = np.empty((num_bonds, 2, 16), dtype=np.float32)
packed[:, 0, :] = h0
packed[:, 1, :] = h1

print("Packed shape before ravel:", packed.shape)
p = packed.ravel()
print("Packed shape after ravel:", p.shape)
print("First bond:", p[0:32])
print("Is contiguous?", p.flags['C_CONTIGUOUS'])
