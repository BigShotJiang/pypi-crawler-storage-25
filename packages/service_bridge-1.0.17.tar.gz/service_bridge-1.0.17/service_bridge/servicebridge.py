"""ServiceBridge Python SDK main module.

Quick start::

    import asyncio
    from service_bridge import ServiceBridge

    svc = ServiceBridge("localhost:14445", "my-key", "my-service")

    @svc.handle_rpc("my.fn")
    async def my_handler(payload: dict) -> dict:
        return {"ok": True}

    @svc.handle_event("my.topic", group_name="my.group")
    async def my_event(payload: dict, ec) -> None:
        pass

    asyncio.run(svc.serve())
"""

from __future__ import annotations

import asyncio
import base64
import binascii
import hashlib
import json
import logging
import random
import re
import threading
import time
from collections import deque
from concurrent import futures
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable, Optional

import grpc

from service_bridge.pb import servicebridge_pb2 as pb
from service_bridge.pb import servicebridge_pb2_grpc as pb_grpc
from service_bridge.http_catalog import (
    HttpSpan,
    extract_trace_from_headers,
    _new_hex_id,
)

logger = logging.getLogger(__name__)
_sdk_logger = logging.getLogger(__name__ + ".internal")

_DEFAULT_RPC_TIMEOUT_MS = 30_000
_DEFAULT_RPC_RETRIES = 3
_DEFAULT_RPC_RETRY_DELAY_MS = 300


def _outbound_ip() -> str:
    """Detect the IP the OS would use for outbound traffic (UDP dial trick).

    Works in Docker containers (returns the container's network IP) and on the
    host (returns the LAN/Wi-Fi interface IP).  No traffic is actually sent.
    """
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 53))
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return ""


@dataclass
class _TLSMaterials:
    ca_cert: bytes
    client_cert: bytes
    client_key: bytes


_PEM_CERT_RE = re.compile(
    rb"-----BEGIN CERTIFICATE-----[\s\S]+?-----END CERTIFICATE-----"
)


def _decode_b64url(segment: str, *, field_name: str) -> bytes:
    if not segment:
        raise RuntimeError(f"invalid service key: missing {field_name}")
    padded = segment + "=" * (-len(segment) % 4)
    try:
        return base64.urlsafe_b64decode(padded.encode())
    except (binascii.Error, ValueError) as exc:
        raise RuntimeError(f"invalid service key: malformed {field_name}") from exc


def _parse_service_key_v2(service_key: str) -> tuple[str, str, bytes]:
    parts = service_key.strip().split(".")
    if len(parts) != 4 or parts[0] != "sbv2":
        raise RuntimeError("legacy service keys are disabled: expected sbv2 key")
    key_id = parts[1].strip()
    if not key_id:
        raise RuntimeError("invalid service key: missing key id")
    secret_bytes = _decode_b64url(parts[2], field_name="secret segment")
    if len(secret_bytes) < 16:
        raise RuntimeError("invalid service key: malformed secret segment")
    ca_pem = _decode_b64url(parts[3], field_name="ca segment")
    _validate_ca_pem(ca_pem, error_message="invalid service key: malformed embedded ca pem")
    secret_hash = hashlib.sha256(secret_bytes).hexdigest()
    return key_id, secret_hash, ca_pem


def _resolve_ca_pem(service_key: str, explicit_ca_pem: str) -> bytes:
    _, _, key_ca_pem = _parse_service_key_v2(service_key)
    if explicit_ca_pem.strip():
        return _validate_ca_pem(
            explicit_ca_pem.encode(),
            error_message="invalid control-plane ca cert: malformed pem",
        )
    return key_ca_pem


def _validate_ca_pem(ca_pem: bytes, *, error_message: str) -> bytes:
    cert_blocks = _PEM_CERT_RE.findall(ca_pem)
    if not cert_blocks:
        raise RuntimeError(error_message)
    try:
        from cryptography import x509
    except ImportError as exc:
        raise RuntimeError("install 'cryptography' package for x509 validation") from exc
    try:
        for block in cert_blocks:
            x509.load_pem_x509_certificate(block)
    except Exception as exc:
        raise RuntimeError(error_message) from exc
    return ca_pem


def _validate_worker_cert_and_key(cert_pem: bytes, key_pem: bytes) -> None:
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import serialization
    except ImportError as exc:
        raise RuntimeError("install 'cryptography' package for x509 validation") from exc
    try:
        cert = x509.load_pem_x509_certificate(cert_pem)
    except Exception as exc:
        raise RuntimeError("invalid worker tls cert: malformed pem") from exc
    try:
        key = serialization.load_pem_private_key(key_pem, password=None)
    except Exception as exc:
        raise RuntimeError("invalid worker tls key: malformed pem") from exc
    cert_pub = cert.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    key_pub = key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    if cert_pub != key_pub:
        raise RuntimeError("worker tls cert/key pair mismatch")


# ─── Error types ──────────────────────────────────────────────────────────────

class ServiceBridgeError(Exception):
    """Typed error raised by all ServiceBridge SDK operations.

    Attributes:
        component: SDK subsystem that produced the error (e.g. "event", "job").
        operation: Specific operation that failed.
        severity: One of "fatal", "retriable", "ignorable".
        retryable: Whether the caller should retry.
        code: gRPC status code string (if applicable).
    """

    def __init__(
        self,
        message: str,
        *,
        component: str = "",
        operation: str = "",
        severity: str = "retriable",
        retryable: bool = True,
        code: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.component = component
        self.operation = operation
        self.severity = severity
        self.retryable = retryable
        self.code = code

    def __repr__(self) -> str:
        return (
            f"ServiceBridgeError({self!s}, component={self.component!r}, "
            f"operation={self.operation!r}, severity={self.severity!r})"
        )


# ─── Public types ──────────────────────────────────────────────────────────────

class StreamWriter:
    """Allows a handler to push incremental data chunks to ServiceBridge
    during execution (AppendStream). Writes are silently dropped when offline.
    """

    def __init__(self, run_id: str, client: "ServiceBridge") -> None:
        self._run_id = run_id
        self._client = client

    async def write(self, data: Any, key: str = "default") -> None:
        """Push a data chunk to the named stream lane.

        Args:
            data: JSON-serialisable payload.
            key: Stream lane name (default: "default").
        """
        if not self._run_id or not self._client._stub:
            return
        with self._client._queue_lock:
            online = self._client._is_online
        if not online:
            return  # stream writes are not buffered offline
        payload = json.dumps(data).encode()
        try:
            await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._client._stub.AppendStream(
                    pb.AppendStreamRequest(run_id=self._run_id, key=key, data=payload),
                    metadata=self._client._metadata(),
                    timeout=5,
                ),
            )
        except Exception:
            pass  # best-effort


@dataclass
class EventContext:
    """Delivery metadata and control methods passed to event handlers."""

    trace_id: str
    span_id: str
    topic: str
    group_name: str
    message_id: str
    attempt: int
    headers: dict[str, str]
    stream: StreamWriter = field(repr=False, default=None)  # type: ignore[assignment]
    _retry_fn: Callable[[int], None] = field(repr=False, default=None)  # type: ignore[assignment]
    _reject_fn: Callable[[str], None] = field(repr=False, default=None)  # type: ignore[assignment]

    def retry(self, delay_ms: int = 1000) -> None:
        """Request a retry after delay_ms milliseconds."""
        if self._retry_fn:
            self._retry_fn(delay_ms)

    def reject(self, reason: str = "rejected_by_consumer") -> None:
        """Permanently reject this message (moves to DLQ)."""
        if self._reject_fn:
            self._reject_fn(reason)


@dataclass
class ScheduleOpts:
    """Configuration for a scheduled job."""

    cron: str = ""
    """Cron expression (e.g. "0 * * * *"). Mutually exclusive with delay_ms."""
    delay_ms: int = 0
    """One-shot delay in milliseconds."""
    timezone: str = "UTC"
    """IANA timezone name."""
    misfire: str = "fire_now"
    """Misfire policy: "fire_now" (default) or "skip"."""
    via: str = "rpc"
    """Trigger mechanism: "rpc" (default), "event", or "workflow"."""
    retry_policy_json: str = ""
    """JSON-encoded retry policy."""


@dataclass
class WorkflowStep:
    """One step in a workflow DAG."""

    id: str
    type: str
    """One of "rpc", "event", "event_wait", "sleep", "workflow"."""
    ref: str = ""
    """Function, event topic, or sub-workflow name."""
    deps: list[str] = field(default_factory=list)
    """Step IDs that must complete before this step runs."""
    if_expr: str = ""
    """Optional server-side filter expression."""
    timeout_ms: int = 0
    duration_ms: int = 0
    """Used only for type="sleep"."""


@dataclass
class WorkflowOpts:
    """Optional limits for a workflow definition."""

    state_limit_bytes: int = 0
    """Maximum serialized state size in bytes. Defaults to 262144 (256 KB) if zero."""
    step_timeout_ms: int = 0
    """Default per-step timeout in milliseconds. Defaults to 30000 (30 s) if zero."""


@dataclass
class WatchRunOpts:
    """Options for watch_run()."""

    key: str = ""
    """Filter to a specific stream lane. Empty = all keys."""
    from_sequence: int = 0
    """Replay chunks with sequence > from_sequence (0 = full replay)."""


@dataclass
class RunStreamEvent:
    """One chunk or terminal event from watch_run()."""

    sequence: int
    key: str
    data: Any
    done: bool
    run_status: str = ""


@dataclass
class WorkerTLSOpts:
    """Explicit worker mTLS materials.

    When omitted, SDK auto-provisions worker certificates via
    ProvisionWorkerCertificate.
    """

    ca_cert: str = ""
    cert: str = ""
    key: str = ""
    server_name: str = ""


# ─── Schema types ─────────────────────────────────────────────────────────────

@dataclass
class RpcFieldDef:
    """Describes one field in an inline Protobuf schema."""

    type: str
    """Protobuf scalar type: "string", "int32", "int64", "float", "double",
    "bool", "bytes", "uint32", "uint64", "fixed32", "fixed64", "sint32",
    "sint64"."""
    id: int
    """Protobuf field number (must be unique within the message)."""
    repeated: bool = False
    """True for repeated (array) fields."""


# RpcSchema maps field names to their RpcFieldDef.
RpcSchema = dict[str, RpcFieldDef]


@dataclass
class RpcSchemaOpts:
    """Inline Protobuf schemas for an RPC function's input and output."""

    input: Optional[RpcSchema] = None
    output: Optional[RpcSchema] = None


@dataclass
class Options:
    """SDK configuration options."""

    ca_cert: str = ""
    """Optional control-plane CA PEM override. By default CA is read from sbv2 service key."""
    heartbeat_interval_ms: int = 10_000
    capture_logs: bool = True
    """When True (default), attaches a ServiceBridgeLogHandler to the root logger."""
    queue_max_size: int = 1_000
    """Maximum operations buffered in the offline queue (default: 1000)."""
    queue_overflow: str = "drop-oldest"
    """Overflow policy: "drop-oldest" (default), "drop-newest", or "error"."""
    discovery_refresh_ms: int = 10_000
    """How often per-function endpoint lists are refreshed (ms, default: 10000)."""
    timeout_ms: int = 30_000
    """Global default RPC timeout in milliseconds (default: 30000). Per-call overrides take priority."""
    retries: int = 3
    """Global default retry count for RPC calls (default: 3). Per-call overrides take priority."""
    retry_delay_ms: int = 300
    """Base delay between retries in ms (default: 300). Uses exponential backoff: delay * 2^(attempt-1)."""
    worker_tls: Optional[WorkerTLSOpts] = None
    """Global explicit worker mTLS materials (optional)."""


class _InProcessWorkerContext:
    """Minimal grpc.ServicerContext shim for in-process worker session dispatch."""

    def __init__(self, run_id: str = "") -> None:
        self._run_id = run_id

    def invocation_metadata(self):
        if not self._run_id:
            return []
        return [("servicebridge-run-id", self._run_id)]

    def peer_identities(self):
        return []

    def abort(self, _code, details):
        raise RuntimeError(details)


@dataclass
class _FnChannelEntry:
    channels: list[grpc.Channel]
    stubs: list[Any]
    endpoints: list[str]
    next_index: int = 0


# Context variable that propagates trace context through async code.
import contextvars as _cv
_trace_ctx: _cv.ContextVar[dict[str, str]] = _cv.ContextVar("_sb_trace_ctx", default={})


# ─── Helper: is gRPC error a connection error? ────────────────────────────────

def _is_connection_error(exc: Exception) -> bool:
    """Return True for gRPC UNAVAILABLE / UNKNOWN status codes."""
    if isinstance(exc, grpc.RpcError):
        code = exc.code()  # type: ignore[attr-defined]
        return code in (grpc.StatusCode.UNAVAILABLE, grpc.StatusCode.UNKNOWN)
    return False


def _normalize_non_negative_int(value: Any, fallback: int) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return max(0, int(fallback))
    if n < 0:
        return max(0, int(fallback))
    return n


def _normalize_positive_int(value: Any, fallback: int) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        n = 0
    if n > 0:
        return n
    try:
        f = int(fallback)
    except (TypeError, ValueError):
        f = 0
    if f > 0:
        return f
    return 1


def _worker_handle_fn(fn: str) -> str:
    """Return worker handler name for rpc target (canonical service/fn -> fn)."""
    raw = (fn or "").strip()
    if "/" not in raw:
        return raw
    _, short = raw.split("/", 1)
    return short or raw


# ─── ServiceBridge client ──────────────────────────────────────────────────────

class ServiceBridge:
    """ServiceBridge SDK client.

    Args:
        grpc_url: Address of the ServiceBridge gRPC server (e.g. ``"localhost:14445"``).
        service_key: Service authentication key.
        service_name: Logical name for this service.
        opts: Optional :class:`Options`.
    """

    def __init__(
        self,
        grpc_url: str,
        service_key: str,
        service_name: str,
        opts: Optional[Options] = None,
    ) -> None:
        self._grpc_url = grpc_url
        self._service_key = service_key
        self._service_name = service_name
        self._opts = opts or Options()
        self._instance_id = _new_hex_id(3)

        self._rpc_handlers: dict[str, Any] = {}
        self._rpc_opts: dict[str, dict[str, Any]] = {}  # fn -> {allowed_callers, schema}
        self._event_handlers: dict[str, dict[str, Any]] = {}

        self._channel: Optional[grpc.Channel] = None
        self._stub: Optional[pb_grpc.ServiceBridgeStub] = None
        self._worker_server: Optional[grpc.Server] = None
        self._worker_servicer: Any = None
        self._worker_address: str = ""
        self._worker_tls_creds: Any = None
        self._worker_tls_server_name: str = ""
        self._session_thread: Optional[threading.Thread] = None
        self._session_max_in_flight: int = 128
        self._registration_weight: int = 1

        # Per-function gRPC channel cache with manual endpoint round-robin.
        self._fn_channels: dict[str, _FnChannelEntry] = {}
        self._fn_channels_lock = threading.Lock()

        # Schema registry (fn -> RpcSchemaOpts).
        self._schemas: dict[str, RpcSchemaOpts] = {}
        self._compiled_schemas: dict[str, Any] = {}  # fn -> compiled cache

        # Offline queue.
        self._is_online: bool = False
        self._queue: deque[dict[str, Any]] = deque()
        self._queue_lock = threading.Lock()
        self._online_restore_timer: Optional[threading.Timer] = None

        # Heartbeat / lifecycle.
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._stopped = False

        # Log batching.
        self._log_batch: list[pb.LogEntry] = []
        self._log_lock = threading.Lock()
        self._log_timer: Optional[threading.Timer] = None

        if self._opts.capture_logs:
            self.attach_logging_handler()

    # ─── Schema registration ───────────────────────────────────────────────────

    def register_schema(self, fn: str, opts: RpcSchemaOpts) -> None:
        """Compile and cache Protobuf schemas for the named function.

        Call before ``serve()`` to enable binary Protobuf encoding.
        The schema JSON is also published to the control plane via RegisterFunction.
        """
        self._schemas[fn] = opts
        # Lazy compilation happens on first encode/decode.

    # ─── Registration API ──────────────────────────────────────────────────────

    def handle_rpc(
        self,
        fn: str,
        *,
        allowed_callers: Optional[list[str]] = None,
        schema: Optional[RpcSchemaOpts] = None,
        timeout_ms: int = 0,
        retryable: Optional[bool] = None,
        concurrency: int = 0,
    ) -> Callable:
        """Decorator that registers an RPC handler.

        Usage::

            @svc.handle_rpc("order.create")
            async def create_order(payload: dict) -> dict:
                return {"id": "123"}

            # With full context (stream + trace):
            @svc.handle_rpc("order.create", allowed_callers=["payments"])
            async def create_order(payload: dict, ctx) -> dict:
                await ctx.stream.write({"progress": 50})
                return {"id": "123"}
        """
        def decorator(func: Callable) -> Callable:
            self._rpc_handlers[fn] = func
            self._rpc_opts[fn] = {
                "allowed_callers": allowed_callers or [],
                "schema": schema,
                # Advisory hints for runtime scheduling/semantics.
                "timeout_ms": _normalize_non_negative_int(timeout_ms, 0),
                "retryable": retryable if isinstance(retryable, bool) else None,
                "concurrency": _normalize_non_negative_int(concurrency, 0),
            }
            if schema:
                self._schemas[fn] = schema
            return func
        return decorator

    def handle_event(
        self,
        topic: str,
        group_name: str = "",
        retry_policy_json: str = "",
        filter_expr: str = "",
        concurrency: int = 0,
        prefetch: int = 0,
    ) -> Callable:
        """Decorator that registers an event handler.

        If the same group_name is registered twice, a warning is logged and
        the existing handler is kept (the duplicate registration is ignored).

        Usage::

            @svc.handle_event("order.created", group_name="payments.order.created")
            async def on_order_created(payload: dict, ec: EventContext) -> None:
                pass
        """
        gname = group_name or f"{self._service_name}.{topic}"

        def decorator(func: Callable) -> Callable:
            if gname in self._event_handlers:
                logger.warning(
                    "handle_event: duplicate group name %r — keeping existing handler", gname
                )
                return func
            self._event_handlers[gname] = {
                "handler": func,
                "group_name": gname,
                "topic": topic,
                "retry_policy_json": retry_policy_json,
                "filter_expr": filter_expr,
                # Advisory hints for runtime scheduling/semantics.
                "concurrency": _normalize_non_negative_int(concurrency, 0),
                "prefetch": _normalize_non_negative_int(prefetch, 0),
            }
            return func

        return decorator

    # ─── Serve ────────────────────────────────────────────────────────────────

    async def serve(
        self,
        *,
        host: str = "localhost",
        max_in_flight: int = 128,
        instance_id: str = "",
        weight: int = 1,
        tls: Optional[WorkerTLSOpts] = None,
    ) -> None:
        """Start the worker server and block until cancelled.

        This is the main entrypoint — call it with ``asyncio.run(svc.serve())``.
        """
        if max_in_flight < 1:
            raise ValueError("max_in_flight must be >= 1")
        if instance_id.strip():
            self._instance_id = instance_id.strip()
        self._registration_weight = _normalize_positive_int(weight, 1)
        self._session_max_in_flight = int(max_in_flight)
        # 1. Connect control plane
        await self._connect_control_plane()
        self._worker_tls_creds = None
        self._worker_tls_server_name = ""
        explicit_tls = self._resolve_explicit_worker_tls(tls)
        if explicit_tls is None:
            explicit_tls = self._resolve_explicit_worker_tls(self._opts.worker_tls)
        if explicit_tls is not None:
            self._worker_tls_creds, self._worker_tls_server_name = explicit_tls

        # Mark online and flush any queued operations.
        with self._queue_lock:
            self._is_online = True
        threading.Thread(target=self._flush_queue, daemon=True).start()

        # 2. Start worker gRPC server
        self._worker_address = await self._start_worker_server(host)
        logger.info("[servicebridge] worker listening at %s", self._worker_address)
        self._start_worker_session()

        # 3. Register + heartbeat
        await self._sync_registrations()
        self._start_heartbeat()

        # 4. Block until cancelled
        try:
            await asyncio.Event().wait()
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        finally:
            await self.stop()

    async def stop(self) -> None:
        """Gracefully shut down the SDK: flush logs, close channels, stop servers."""
        with self._queue_lock:
            if self._stopped:
                return
            self._stopped = True
            self._is_online = False
            self._queue.clear()
            if self._online_restore_timer is not None:
                self._online_restore_timer.cancel()
                self._online_restore_timer = None

        self._stop_event.set()
        self._log_flush()

        if self._worker_server:
            self._worker_server.stop(grace=2)
        if self._session_thread and self._session_thread.is_alive():
            self._session_thread.join(timeout=2)
            self._session_thread = None
        if self._channel:
            self._channel.close()

        # Close per-function channels.
        with self._fn_channels_lock:
            for entry in self._fn_channels.values():
                for ch in entry.channels:
                    ch.close()
            self._fn_channels.clear()

    # ─── Rpc ──────────────────────────────────────────────────────────────────

    async def rpc(
        self,
        fn: str,
        payload: Any = None,
        *,
        retries: Optional[int] = None,
        timeout_ms: Optional[int] = None,
        retry_delay_ms: Optional[int] = None,
        trace_id: str = "",
    ) -> Any:
        """Call an RPC function on a remote worker.

        Uses a persistent gRPC channel per function with round-trip endpoint
        caching and background refresh (``discovery_refresh_ms``).

        Args:
            fn: Function name (e.g. ``"orders/order.create"``).
            payload: JSON-serialisable payload.
            retries: Number of retry attempts (default: ``Options.retries``).
            timeout_ms: Per-call timeout in milliseconds (default: ``Options.timeout_ms``).
            retry_delay_ms: Base retry delay in ms (default: ``Options.retry_delay_ms``).
                Uses exponential backoff: ``delay * 2^(attempt-1)``.
            trace_id: Override trace ID.

        Returns:
            Parsed JSON response from the worker.
        """
        default_retries = _normalize_non_negative_int(
            self._opts.retries, _DEFAULT_RPC_RETRIES
        )
        default_timeout_ms = _normalize_positive_int(
            self._opts.timeout_ms, _DEFAULT_RPC_TIMEOUT_MS
        )
        default_retry_delay_ms = _normalize_positive_int(
            self._opts.retry_delay_ms, _DEFAULT_RPC_RETRY_DELAY_MS
        )
        retries = (
            default_retries
            if retries is None
            else _normalize_non_negative_int(retries, default_retries)
        )
        timeout_ms = (
            default_timeout_ms
            if timeout_ms is None
            else _normalize_positive_int(timeout_ms, default_timeout_ms)
        )
        retry_delay_ms = (
            default_retry_delay_ms
            if retry_delay_ms is None
            else _normalize_positive_int(retry_delay_ms, default_retry_delay_ms)
        )
        if self._stub is None:
            raise ServiceBridgeError(
                "ServiceBridge not started — call serve() first",
                component="rpc", operation=fn, severity="fatal", retryable=False,
            )

        tc = _trace_ctx.get({})
        effective_trace_id = trace_id or tc.get("trace_id", "") or _new_hex_id()
        parent_span_id = tc.get("span_id", "")
        span_id = _new_hex_id()

        worker_fn = _worker_handle_fn(fn)
        # Encode payload for worker call (binary Protobuf if schema is registered).
        payload_bytes = self._encode_payload(fn, payload)

        # Telemetry payloads must always be valid JSON for runtime ingestion.
        def _telemetry_json_bytes(value: Any) -> bytes:
            try:
                return json.dumps(value if value is not None else {}).encode()
            except TypeError:
                return json.dumps(str(value)).encode()

        telemetry_input_buf = _telemetry_json_bytes(payload)
        started_at = int(time.time() * 1000)
        go_report = asyncio.get_event_loop().run_in_executor(
            None,
            lambda: self._report_call_start(
                effective_trace_id,
                span_id,
                parent_span_id,
                fn,
                started_at,
                telemetry_input_buf,
                1,
            ),
        )
        asyncio.ensure_future(go_report)

        # Get (or lazily create) a persistent channel for this function.
        _, worker_stub = await self._get_fn_channel(fn)

        last_err: Optional[Exception] = None
        last_attempt = 1

        for attempt in range(retries + 1):
            attempt_no = attempt + 1
            last_attempt = attempt_no
            try:
                attempt_timeout_ms = timeout_ms
                attempt_timeout_sec = max(0.001, attempt_timeout_ms / 1000.0)
                watchdog_slack_sec = max(0.25, attempt_timeout_sec * 0.1)
                request = pb.HandleRequest(
                    fn=worker_fn,
                    payload=payload_bytes,
                    trace_id=effective_trace_id,
                    span_id=span_id,
                )

                loop = asyncio.get_event_loop()
                handle_callable = worker_stub.Handle
                result: Any

                # Prefer grpc.Future API so we can cancel explicitly when the
                # local watchdog fires and avoid hanging spans.
                if hasattr(handle_callable, "future"):
                    try:
                        unary_call = handle_callable.future(
                            request,
                            timeout=attempt_timeout_sec,
                            wait_for_ready=True,
                        )
                    except TypeError:
                        unary_call = handle_callable.future(
                            request,
                            timeout=attempt_timeout_sec,
                        )

                    def _await_call_result() -> Any:
                        return unary_call.result(timeout=attempt_timeout_sec)

                    try:
                        result = await asyncio.wait_for(
                            loop.run_in_executor(None, _await_call_result),
                            timeout=attempt_timeout_sec + watchdog_slack_sec,
                        )
                    except asyncio.TimeoutError as exc:
                        unary_call.cancel()
                        raise TimeoutError(
                            f"rpc attempt timeout after {attempt_timeout_ms}ms"
                        ) from exc
                    except Exception as exc:
                        future_timeout_error = getattr(grpc, "FutureTimeoutError", None)
                        if future_timeout_error and isinstance(exc, future_timeout_error):
                            unary_call.cancel()
                            raise TimeoutError(
                                f"rpc attempt timeout after {attempt_timeout_ms}ms"
                            ) from exc
                        raise
                else:
                    result = await asyncio.wait_for(
                        loop.run_in_executor(
                            None,
                            lambda: handle_callable(
                                request,
                                timeout=attempt_timeout_sec,
                            ),
                        ),
                        timeout=attempt_timeout_sec + watchdog_slack_sec,
                    )
                if not result.success:
                    raise ServiceBridgeError(
                        result.error or "handler returned failure",
                        component="rpc", operation=fn,
                    )
                # Decode output (binary Protobuf → JSON if schema present).
                out = self._decode_output(fn, result.output)
                telemetry_output_buf = _telemetry_json_bytes(out)
                go_finish = asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda a=attempt_no, out_buf=telemetry_output_buf: self._report_call(
                        effective_trace_id,
                        span_id,
                        fn,
                        started_at,
                        telemetry_input_buf,
                        True,
                        a,
                        out_buf,
                        "",
                    ),
                )
                asyncio.ensure_future(go_finish)
                return out
            except Exception as exc:
                last_err = exc
                if _is_connection_error(exc):
                    self._mark_offline()
                if attempt < retries:
                    await asyncio.sleep(retry_delay_ms / 1000 * 2 ** attempt)
        err_msg = str(last_err) if last_err is not None else "rpc failed"
        go_finish = asyncio.get_event_loop().run_in_executor(
            None,
            lambda a=last_attempt, msg=err_msg: self._report_call(
                effective_trace_id,
                span_id,
                fn,
                started_at,
                telemetry_input_buf,
                False,
                a,
                b"",
                msg,
            ),
        )
        asyncio.ensure_future(go_finish)

        if last_err is not None:
            raise last_err
        raise ServiceBridgeError(
            f"rpc {fn!r} failed",
            component="rpc",
            operation=fn,
            severity="retriable",
            retryable=True,
        )

    # ─── Event ────────────────────────────────────────────────────────────────

    async def event(
        self,
        topic: str,
        payload: Any = None,
        *,
        idempotency_key: str = "",
        trace_id: str = "",
        parent_span_id: str = "",
        headers: Optional[dict[str, str]] = None,
    ) -> str:
        """Publish an event to a topic.

        When the control plane is offline, the operation is buffered in the
        offline queue and retried transparently on reconnect.

        Returns:
            Assigned message ID (empty string when buffered offline).
        """
        effective_trace_id = trace_id or _new_hex_id()
        parent_span_id = parent_span_id or _trace_ctx.get({}).get("span_id", "")
        payload_bytes = json.dumps(payload).encode() if payload is not None else b"{}"

        with self._queue_lock:
            online = self._is_online

        if not online:
            self._enqueue_offline({
                "kind": "event",
                "topic": topic,
                "payload": payload_bytes,
                "idempotency_key": idempotency_key,
                "trace_id": effective_trace_id,
                "parent_span_id": parent_span_id,
                "headers": headers or {},
            })
            return ""

        try:
            resp = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._stub.Publish(
                    pb.PublishRequest(
                        topic=topic,
                        payload=payload_bytes,
                        trace_id=effective_trace_id,
                        parent_span_id=parent_span_id,
                        producer_service=self._service_name,
                        idempotency_key=idempotency_key,
                        headers=headers or {},
                    ),
                    metadata=self._metadata(),
                    timeout=10,
                ),
            )
            return resp.message_id
        except Exception as exc:
            if _is_connection_error(exc):
                self._mark_offline()
                self._enqueue_offline({
                    "kind": "event",
                    "topic": topic,
                    "payload": payload_bytes,
                    "idempotency_key": idempotency_key,
                    "trace_id": effective_trace_id,
                    "parent_span_id": parent_span_id,
                    "headers": headers or {},
                })
                return ""
            raise ServiceBridgeError(
                f"publish event {topic!r}: {exc}",
                component="event", operation="publish",
            ) from exc

    # ─── Job ──────────────────────────────────────────────────────────────────

    async def job(self, target: str, opts: Optional[ScheduleOpts] = None) -> str:
        """Register a scheduled job with the control plane.

        When offline, the operation is buffered and retried on reconnect.

        Returns:
            Assigned job ID (empty string when buffered offline).
        """
        o = opts or ScheduleOpts()
        misfire = o.misfire or "fire_now"
        via = o.via or "rpc"
        tz = o.timezone or "UTC"

        with self._queue_lock:
            online = self._is_online

        if not online:
            self._enqueue_offline({"kind": "job", "target": target, "opts": o})
            return ""

        try:
            resp = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._stub.RegisterJob(
                    pb.RegisterJobRequest(
                        cron_expr=o.cron,
                        timezone=tz,
                        misfire_policy=misfire,
                        target_type=via,
                        target_ref=target,
                        delay_ms=o.delay_ms,
                        service_name=self._service_name,
                        retry_policy_json=o.retry_policy_json,
                    ),
                    metadata=self._metadata(),
                    timeout=10,
                ),
            )
            return resp.id
        except Exception as exc:
            if _is_connection_error(exc):
                self._mark_offline()
                self._enqueue_offline({"kind": "job", "target": target, "opts": o})
                return ""
            raise ServiceBridgeError(
                f"register job {target!r}: {exc}",
                component="job", operation="register",
            ) from exc

    # ─── Workflow ─────────────────────────────────────────────────────────────

    async def workflow(
        self,
        name: str,
        steps: list[WorkflowStep],
        opts: Optional["WorkflowOpts"] = None,
    ) -> str:
        """Register a workflow DAG with the control plane.

        When offline, the operation is buffered and retried on reconnect.

        Args:
            name: Workflow name.
            steps: Ordered list of :class:`WorkflowStep` definitions.
            opts: Optional :class:`WorkflowOpts` for per-workflow limits.

        Returns:
            Assigned workflow run ID (empty string when buffered offline).
        """
        definition = json.dumps([_step_to_dict(s) for s in steps])
        opts_json = _workflow_opts_json(opts)

        with self._queue_lock:
            online = self._is_online

        if not online:
            self._enqueue_offline({"kind": "workflow", "name": name, "steps": steps, "opts": opts})
            return ""

        try:
            req = pb.RegisterWorkflowRequest(
                name=name,
                definition=definition,
                service_name=self._service_name,
            )
            if opts_json:
                req.opts = opts_json
            resp = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._stub.RegisterWorkflow(req, metadata=self._metadata(), timeout=10),
            )
            return resp.id
        except Exception as exc:
            if _is_connection_error(exc):
                self._mark_offline()
                self._enqueue_offline({"kind": "workflow", "name": name, "steps": steps, "opts": opts})
                return ""
            raise ServiceBridgeError(
                f"register workflow {name!r}: {exc}",
                component="workflow", operation="register",
            ) from exc

    async def run_workflow(self, name: str, input: Any = None) -> dict[str, str]:
        """Start a workflow run by name with optional input payload.

        Returns:
            Dict with ``runId`` and ``traceId`` keys.
        """
        payload = json.dumps(input if input is not None else {}).encode()
        try:
            resp = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._stub.RunWorkflow(
                    pb.RunWorkflowRequest(
                        name=name,
                        input=payload,
                        service_name=self._service_name,
                    ),
                    metadata=self._metadata(),
                    timeout=10,
                ),
            )
            return {"runId": resp.run_id, "traceId": resp.trace_id}
        except Exception as exc:
            raise ServiceBridgeError(
                f"run workflow {name!r}: {exc}",
                component="workflow",
                operation="run",
            ) from exc

    async def cancel_workflow_run(self, run_id: str) -> None:
        """Cancel an in-progress workflow run by ID."""
        try:
            resp = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._stub.CancelWorkflowRun(
                    pb.CancelWorkflowRunRequest(run_id=run_id),
                    metadata=self._metadata(),
                    timeout=10,
                ),
            )
            if not resp.cancelled:
                raise ServiceBridgeError(
                    f"cancel workflow run {run_id!r}: not cancelled",
                    component="workflow", operation="cancel",
                )
        except Exception as exc:
            if isinstance(exc, ServiceBridgeError):
                raise
            raise ServiceBridgeError(
                f"cancel workflow run {run_id!r}: {exc}",
                component="workflow",
                operation="cancel",
            ) from exc

    # ─── WatchRun ─────────────────────────────────────────────────────────────

    async def watch_run(
        self,
        run_id: str,
        opts: Optional[WatchRunOpts] = None,
    ) -> AsyncIterator[RunStreamEvent]:
        """Subscribe to a realtime stream of chunks for a workflow/job run.

        Auto-reconnects with exponential backoff (0.5s → 5s) on transient errors.
        Deduplicates chunks by sequence number.

        Usage::

            async for event in svc.watch_run(run_id):
                print(event.data)
                if event.done:
                    break
        """
        key = opts.key if opts else ""
        from_seq = opts.from_sequence if opts else 0

        backoff = 0.5
        last_seq = from_seq
        loop = asyncio.get_event_loop()

        def _metadata_value(exc: Exception, key_name: str) -> str:
            key_lower = key_name.lower()
            providers: list[Any] = []

            trailing = getattr(exc, "trailing_metadata", None)
            if callable(trailing):
                try:
                    md = trailing()
                    if md:
                        providers.append(md)
                except Exception:
                    pass

            meta_attr = getattr(exc, "metadata", None)
            if meta_attr:
                providers.append(meta_attr)

            for md in providers:
                if hasattr(md, "get") and callable(md.get):
                    try:
                        values = md.get(key_name)
                    except Exception:
                        values = None
                    if values:
                        first = values[0]
                        return (
                            first.decode(errors="ignore")
                            if isinstance(first, bytes)
                            else str(first)
                        )
                for item in md:
                    if not isinstance(item, tuple) or len(item) != 2:
                        continue
                    k, v = item
                    if str(k).lower() != key_lower:
                        continue
                    return v.decode(errors="ignore") if isinstance(v, bytes) else str(v)
            return ""

        def _maybe_resume_from(exc: Exception) -> None:
            nonlocal last_seq
            raw = _metadata_value(exc, "servicebridge-run-stream-resume-from")
            if not raw:
                return
            try:
                resume = int(raw)
            except ValueError:
                return
            if resume > last_seq:
                last_seq = resume

        def _should_retry(exc: Exception) -> bool:
            retryable_flag = _metadata_value(exc, "servicebridge-run-stream-retryable")
            if retryable_flag.lower() == "true":
                return True
            if not isinstance(exc, grpc.RpcError):
                return False
            code = exc.code()  # type: ignore[attr-defined]
            return code in (
                grpc.StatusCode.UNAVAILABLE,
                grpc.StatusCode.UNKNOWN,
                grpc.StatusCode.DEADLINE_EXCEEDED,
                grpc.StatusCode.RESOURCE_EXHAUSTED,
            )

        while True:
            if self._stub is None:
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 5.0)
                continue

            try:
                request = pb.WatchRunRequest(
                    run_id=run_id,
                    key=key,
                    from_sequence=last_seq,
                )
                stream_call = self._stub.WatchRun(request, metadata=self._metadata())
                backoff = 0.5

                async for chunk in _aiter_grpc_stream(
                    stream_call,
                    loop,
                    queue_limit=256,
                    overflow_error_factory=lambda: ServiceBridgeError(
                        f"watch run {run_id!r}: consumer is not draining fast enough",
                        component="stream",
                        operation="watch_run",
                        severity="fatal",
                        retryable=False,
                    ),
                ):
                    if chunk.sequence > 0 and chunk.sequence <= last_seq:
                        continue
                    if chunk.sequence > last_seq:
                        last_seq = chunk.sequence

                    data: Any = None
                    if chunk.type == "chunk" and chunk.data:
                        try:
                            data = json.loads(chunk.data)
                        except json.JSONDecodeError as exc:
                            raise ServiceBridgeError(
                                f"watch run {run_id!r}: non-json chunk payload at sequence {chunk.sequence}",
                                component="stream",
                                operation="watch_run",
                                severity="fatal",
                                retryable=False,
                            ) from exc
                    elif chunk.data:
                        try:
                            data = json.loads(chunk.data)
                        except json.JSONDecodeError:
                            data = None

                    event = RunStreamEvent(
                        sequence=chunk.sequence,
                        key=chunk.key or key,
                        data=data,
                        done=chunk.type == "run_complete",
                        run_status=chunk.run_status,
                    )
                    yield event
                    if event.done:
                        return
                return

            except asyncio.CancelledError:
                return
            except Exception as exc:
                if isinstance(exc, ServiceBridgeError) and exc.severity == "fatal":
                    raise
                _maybe_resume_from(exc)
                if not _should_retry(exc):
                    raise ServiceBridgeError(
                        f"watch run {run_id!r}: {exc}",
                        component="stream",
                        operation="watch_run",
                        severity="fatal",
                        retryable=False,
                    ) from exc
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 5.0)

    # ─── HTTP helpers ──────────────────────────────────────────────────────────

    def start_http_span(
        self,
        method: str,
        path: str,
        trace_id: str = "",
        parent_span_id: str = "",
    ) -> HttpSpan:
        """Create a tracing span for an incoming HTTP request."""
        effective_trace_id = trace_id or _new_hex_id()
        span_id = _new_hex_id()
        fn = f"http:{method}:{path}"
        started_at = int(time.time() * 1000)
        input_buf = json.dumps({"method": method, "path": path}).encode()

        self._report_call_start(effective_trace_id, span_id, parent_span_id, fn, started_at, input_buf, 1)

        return HttpSpan(
            trace_id=effective_trace_id,
            span_id=span_id,
            _fn=fn,
            _started_at=started_at,
            _client=self,
            _input_buf=input_buf,
        )

    def register_http_endpoint(
        self,
        method: str,
        route: str,
        instance_id: str = "",
        endpoint: str = "",
        allowed_callers: Optional[list[str]] = None,
        request_schema_json: str = "",
        response_schema_json: str = "",
        transport: str = "",
    ) -> None:
        """Register an HTTP route in the ServiceBridge catalog."""
        if self._stub is None:
            raise ServiceBridgeError(
                "ServiceBridge not started — call serve() first",
                component="http",
                operation="register_http_endpoint",
                severity="fatal",
                retryable=False,
            )
        req = pb.RegisterHttpEndpointRequest(
            service_name=self._service_name,
            method=method,
            route_pattern=route,
            request_schema_json=request_schema_json,
            response_schema_json=response_schema_json,
            instance_id=instance_id or self._instance_id,
            endpoint=endpoint or self._worker_address,
            transport=transport or "http",
            allowed_callers=allowed_callers or [],
        )
        resp = self._stub.RegisterHttpEndpoint(req, metadata=self._metadata(), timeout=10)
        if not resp.ok:
            raise ServiceBridgeError(
                "register_http_endpoint rejected by runtime",
                component="http",
                operation="register_http_endpoint",
            )

    # ─── Offline queue ────────────────────────────────────────────────────────

    def _enqueue_offline(self, op: dict[str, Any]) -> None:
        with self._queue_lock:
            max_size = self._opts.queue_max_size
            policy = self._opts.queue_overflow

            if len(self._queue) >= max_size:
                if policy == "error":
                    raise ServiceBridgeError(
                        "ServiceBridge offline queue is full",
                        component="queue", operation="enqueue",
                        severity="retriable", retryable=True,
                    )
                elif policy == "drop-newest":
                    return
                else:  # "drop-oldest"
                    self._queue.popleft()

            self._queue.append(op)

    def _mark_offline(self) -> None:
        with self._queue_lock:
            if not self._is_online or self._stopped:
                return
            self._is_online = False
        self._schedule_online_restore()

    def _schedule_online_restore(self) -> None:
        with self._queue_lock:
            if self._stopped or self._is_online or self._online_restore_timer is not None:
                return

        def _restore() -> None:
            with self._queue_lock:
                self._online_restore_timer = None
                if self._stopped:
                    return
                self._is_online = True
            threading.Thread(target=self._flush_queue, daemon=True).start()

        with self._queue_lock:
            t = threading.Timer(2.0, _restore)
            t.daemon = True
            self._online_restore_timer = t
        t.start()

    def _flush_queue(self) -> None:
        """Drain the offline queue FIFO when online. Runs in a background thread."""
        while True:
            with self._queue_lock:
                if not self._is_online or len(self._queue) == 0 or self._stopped:
                    return
                op = self._queue[0]

            try:
                self._flush_op(op)
            except Exception as exc:
                if _is_connection_error(exc):
                    self._mark_offline()
                    return
                _sdk_logger.debug("flush offline queue op %r: %s (skipping)", op.get("kind"), exc)

            with self._queue_lock:
                if self._queue and self._queue[0] is op:
                    self._queue.popleft()

    def _flush_op(self, op: dict[str, Any]) -> None:
        kind = op["kind"]
        md = self._metadata()

        if kind == "event":
            self._stub.Publish(
                pb.PublishRequest(
                    topic=op["topic"],
                    payload=op["payload"],
                    trace_id=op.get("trace_id", ""),
                    parent_span_id=op.get("parent_span_id", ""),
                    producer_service=self._service_name,
                    idempotency_key=op.get("idempotency_key", ""),
                    headers=op.get("headers", {}),
                ),
                metadata=md,
                timeout=10,
            )
        elif kind == "job":
            o: ScheduleOpts = op["opts"]
            self._stub.RegisterJob(
                pb.RegisterJobRequest(
                    cron_expr=o.cron,
                    timezone=o.timezone or "UTC",
                    misfire_policy=o.misfire or "fire_now",
                    target_type=o.via or "rpc",
                    target_ref=op["target"],
                    delay_ms=o.delay_ms,
                    service_name=self._service_name,
                    retry_policy_json=o.retry_policy_json,
                ),
                metadata=md,
                timeout=10,
            )
        elif kind == "workflow":
            steps: list[WorkflowStep] = op["steps"]
            definition = json.dumps([_step_to_dict(s) for s in steps])
            wf_req = pb.RegisterWorkflowRequest(
                name=op["name"],
                definition=definition,
                service_name=self._service_name,
            )
            wf_opts_json = _workflow_opts_json(op.get("opts"))
            if wf_opts_json:
                wf_req.opts = wf_opts_json
            self._stub.RegisterWorkflow(wf_req, metadata=md, timeout=10)
        elif kind == "reportCallStart":
            self._stub.ReportCallStart(
                pb.ReportCallStartRequest(
                    trace_id=op["trace_id"],
                    span_id=op["span_id"],
                    parent_span_id=op.get("parent_span_id", ""),
                    fn=op["fn"],
                    service_name=self._service_name,
                    instance_id=self._instance_id,
                    started_at=op["started_at"],
                    input=op["input"],
                    attempt=op["attempt"],
                ),
                metadata=md,
                timeout=5,
            )
        elif kind == "reportCall":
            duration_ms = op.get("duration_ms")
            if duration_ms is None:
                duration_ms = int(time.time() * 1000) - op["started_at"]
            self._stub.ReportCall(
                pb.ReportCallRequest(
                    trace_id=op["trace_id"],
                    span_id=op["span_id"],
                    fn=op["fn"],
                    service_name=self._service_name,
                    instance_id=self._instance_id,
                    started_at=op["started_at"],
                    duration_ms=duration_ms,
                    success=op["success"],
                    error=op.get("error", ""),
                    input=op["input"],
                    output=op.get("output", b""),
                    attempt=op["attempt"],
                ),
                metadata=md,
                timeout=5,
            )

    # ─── Per-function channel cache ────────────────────────────────────────────

    async def _get_fn_channel(
        self, fn: str
    ) -> tuple[grpc.Channel, "pb_grpc.ServiceBridgeWorkerStub"]:
        """Return (or lazily create) a worker channel for ``fn`` with endpoint RR."""
        with self._fn_channels_lock:
            entry = self._fn_channels.get(fn)
            if entry is not None:
                return self._pick_fn_channel(entry)

        # Lookup endpoints for this function.
        loop = asyncio.get_event_loop()
        resp = await loop.run_in_executor(
            None,
            lambda: self._stub.LookupFunction(
                pb.LookupFunctionRequest(fn_name=fn),
                metadata=self._metadata(),
                timeout=10,
            ),
        )
        if not resp.found or not resp.endpoints.endpoints:
            raise ServiceBridgeError(
                f"no endpoints for '{fn}'",
                component="rpc", operation=fn, severity="retriable", retryable=True,
            )

        endpoints = self._resolve_lookup_endpoints(resp.endpoints.endpoints)
        if not endpoints:
            raise ServiceBridgeError(
                f"no endpoints for '{fn}'",
                component="rpc", operation=fn, severity="retriable", retryable=True,
            )
        new_entry = self._build_fn_channel_entry(endpoints)

        with self._fn_channels_lock:
            existing = self._fn_channels.get(fn)
            if existing is not None:
                self._close_fn_channel_entry(new_entry)
                return self._pick_fn_channel(existing)
            self._fn_channels[fn] = new_entry

        # Start background endpoint refresh for this function.
        threading.Thread(
            target=self._refresh_fn_channel_loop,
            args=(fn,),
            daemon=True,
        ).start()

        return self._pick_fn_channel(new_entry)

    def _build_fn_channel_entry(self, endpoints: list[str]) -> _FnChannelEntry:
        channels: list[grpc.Channel] = []
        stubs: list[Any] = []
        for endpoint in endpoints:
            ch = self._make_worker_channel(endpoint)
            channels.append(ch)
            stubs.append(pb_grpc.ServiceBridgeWorkerStub(ch))
        return _FnChannelEntry(channels=channels, stubs=stubs, endpoints=endpoints)

    def _pick_fn_channel(
        self, entry: _FnChannelEntry
    ) -> tuple[grpc.Channel, "pb_grpc.ServiceBridgeWorkerStub"]:
        if not entry.channels or not entry.stubs:
            raise RuntimeError("worker channel entry is empty")
        idx = entry.next_index % len(entry.channels)
        entry.next_index = (idx + 1) % len(entry.channels)
        return entry.channels[idx], entry.stubs[idx]

    def _close_fn_channel_entry(self, entry: _FnChannelEntry) -> None:
        for ch in entry.channels:
            try:
                ch.close()
            except Exception:
                pass

    def _refresh_fn_channel_loop(self, fn: str) -> None:
        """Periodically refresh endpoints for a function and recreate channel if changed."""
        refresh_ms = self._opts.discovery_refresh_ms
        while not self._stop_event.wait(refresh_ms / 1000):
            if self._stub is None:
                continue
            try:
                resp = self._stub.LookupFunction(
                    pb.LookupFunctionRequest(fn_name=fn),
                    metadata=self._metadata(),
                    timeout=10,
                )
                if not resp.found or not resp.endpoints.endpoints:
                    continue
                new_eps = self._resolve_lookup_endpoints(resp.endpoints.endpoints)
                if not new_eps:
                    continue
                old_entry: Optional[_FnChannelEntry] = None
                with self._fn_channels_lock:
                    current = self._fn_channels.get(fn)
                    if current is None:
                        break
                    if set(new_eps) == set(current.endpoints):
                        continue
                candidate = self._build_fn_channel_entry(new_eps)
                with self._fn_channels_lock:
                    current = self._fn_channels.get(fn)
                    if current is None:
                        self._close_fn_channel_entry(candidate)
                        break
                    if set(new_eps) == set(current.endpoints):
                        self._close_fn_channel_entry(candidate)
                        continue
                    old_entry = current
                    self._fn_channels[fn] = candidate
                if old_entry is not None:
                    self._close_fn_channel_entry(old_entry)
            except Exception:
                pass

    # ─── Telemetry ────────────────────────────────────────────────────────────

    def _report_call_start(
        self, trace_id, span_id, parent_span_id, fn, started_at, input_buf, attempt
    ) -> None:
        if self._stub is None:
            return

        with self._queue_lock:
            online = self._is_online

        if not online:
            self._enqueue_offline({
                "kind": "reportCallStart",
                "trace_id": trace_id, "span_id": span_id,
                "parent_span_id": parent_span_id,
                "fn": fn, "started_at": started_at,
                "input": input_buf, "attempt": attempt,
            })
            return

        try:
            self._stub.ReportCallStart(
                pb.ReportCallStartRequest(
                    trace_id=trace_id, span_id=span_id,
                    parent_span_id=parent_span_id, fn=fn,
                    service_name=self._service_name, instance_id=self._instance_id,
                    started_at=started_at, input=input_buf, attempt=attempt,
                ),
                metadata=self._metadata(), timeout=5,
            )
        except Exception as exc:
            if _is_connection_error(exc):
                self._mark_offline()
                self._enqueue_offline({
                    "kind": "reportCallStart",
                    "trace_id": trace_id,
                    "span_id": span_id,
                    "parent_span_id": parent_span_id,
                    "fn": fn,
                    "started_at": started_at,
                    "input": input_buf,
                    "attempt": attempt,
                })

    def _report_call(
        self, trace_id, span_id, fn, started_at, input_buf, success, attempt, output_buf, error_msg
    ) -> None:
        if self._stub is None:
            return
        duration_ms = int(time.time() * 1000) - started_at

        with self._queue_lock:
            online = self._is_online

        if not online:
            self._enqueue_offline({
                "kind": "reportCall",
                "trace_id": trace_id, "span_id": span_id, "fn": fn,
                "duration_ms": duration_ms,
                "started_at": started_at, "input": input_buf, "success": success,
                "attempt": attempt, "output": output_buf or b"", "error": error_msg,
            })
            return

        try:
            self._stub.ReportCall(
                pb.ReportCallRequest(
                    trace_id=trace_id, span_id=span_id, fn=fn,
                    service_name=self._service_name, instance_id=self._instance_id,
                    started_at=started_at, duration_ms=duration_ms,
                    success=success, error=error_msg,
                    input=input_buf, output=output_buf or b"", attempt=attempt,
                ),
                metadata=self._metadata(), timeout=5,
            )
        except Exception as exc:
            if _is_connection_error(exc):
                self._mark_offline()
                self._enqueue_offline({
                    "kind": "reportCall",
                    "trace_id": trace_id,
                    "span_id": span_id,
                    "fn": fn,
                    "duration_ms": duration_ms,
                    "started_at": started_at,
                    "input": input_buf,
                    "success": success,
                    "attempt": attempt,
                    "output": output_buf or b"",
                    "error": error_msg,
                })

    # ─── Schema encode/decode helpers ─────────────────────────────────────────

    def _encode_payload(self, fn: str, payload: Any) -> bytes:
        """Encode payload to bytes. Uses binary Protobuf if a schema is registered."""
        opts = self._schema_opts_for_fn(fn)
        if opts and opts.input:
            try:
                from service_bridge.schema import compile_schema, encode_with_schema
                md = self._get_compiled_schema(fn, "input", opts.input)
                if md:
                    return encode_with_schema(md, payload)
            except Exception as exc:
                _sdk_logger.debug("schema encode failed for %r: %s — falling back to JSON", fn, exc)
        return json.dumps(payload).encode() if payload is not None else b"{}"

    def _decode_output(self, fn: str, raw: bytes) -> Any:
        """Decode output bytes. Uses binary Protobuf if a schema is registered."""
        if not raw:
            return {}
        opts = self._schema_opts_for_fn(fn)
        if opts and opts.output:
            try:
                from service_bridge.schema import decode_with_schema
                md = self._get_compiled_schema(fn, "output", opts.output)
                if md:
                    return decode_with_schema(md, raw)
            except Exception as exc:
                _sdk_logger.debug("schema decode failed for %r: %s — falling back to JSON", fn, exc)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {}

    def _get_compiled_schema(self, fn: str, direction: str, schema: RpcSchema) -> Any:
        key = f"{fn}:{direction}"
        if key not in self._compiled_schemas:
            try:
                from service_bridge.schema import compile_schema
                self._compiled_schemas[key] = compile_schema(f"{fn}_{direction}", schema)
            except Exception:
                self._compiled_schemas[key] = None
        return self._compiled_schemas[key]

    # ─── Internal helpers ──────────────────────────────────────────────────────

    def _metadata(self) -> list[tuple[str, str]]:
        return [("x-service-key", self._service_key)]

    def _schema_opts_for_fn(self, fn: str) -> Optional[RpcSchemaOpts]:
        opts = self._schemas.get(fn)
        if opts is not None:
            return opts
        short_fn = _worker_handle_fn(fn)
        if short_fn != fn:
            return self._schemas.get(short_fn)
        return None

    def _worker_channel_credentials(self) -> Optional[grpc.ChannelCredentials]:
        creds = self._worker_tls_creds
        if creds is None:
            return None
        return grpc.ssl_channel_credentials(
            root_certificates=creds.ca_cert,
            private_key=creds.client_key,
            certificate_chain=creds.client_cert,
        )

    def _make_worker_channel(self, target: str) -> grpc.Channel:
        options = [("grpc.service_config", '{"loadBalancingConfig":[{"round_robin":{}}]}')]
        if self._worker_tls_server_name:
            options.append(("grpc.ssl_target_name_override", self._worker_tls_server_name))
            options.append(("grpc.default_authority", self._worker_tls_server_name))
        creds = self._worker_channel_credentials()
        if creds is None:
            raise RuntimeError("worker TLS is not configured")
        return grpc.secure_channel(target, creds, options=options)

    def _resolve_lookup_endpoints(self, raw_endpoints: Any) -> list[str]:
        endpoints: list[str] = []
        seen: set[str] = set()
        for ep in raw_endpoints:
            endpoint = (getattr(ep, "endpoint", "") or "").strip()
            if endpoint:
                endpoint = endpoint.replace("grpc://", "").replace("tls://", "")
                if endpoint in seen:
                    continue
                seen.add(endpoint)
                endpoints.append(endpoint)
        return endpoints

    async def _connect_control_plane(self) -> None:
        ca_pem = _resolve_ca_pem(self._service_key, self._opts.ca_cert)
        channel_creds = grpc.ssl_channel_credentials(root_certificates=ca_pem)
        self._channel = grpc.secure_channel(self._grpc_url, channel_creds)
        self._stub = pb_grpc.ServiceBridgeStub(self._channel)

    def _provision_worker_tls(self, extra_ips: Optional[list[str]] = None) -> _TLSMaterials:
        if self._stub is None:
            raise RuntimeError("control plane is not connected")
        try:
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric import ec
        except ImportError as exc:
            raise RuntimeError(
                "Install 'cryptography' package for mTLS worker provisioning"
            ) from exc

        key = ec.generate_private_key(ec.SECP256R1())
        private_key_pem = key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        public_key_pem = key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        resp = self._stub.ProvisionWorkerCertificate(
            pb.ProvisionWorkerCertificateRequest(
                service_name=self._service_name,
                public_key_pem=public_key_pem.decode(),
                extra_ips=extra_ips or [],
            ),
            metadata=self._metadata(),
            timeout=15,
        )
        if not resp.cert_pem or not resp.ca_pem:
            raise RuntimeError("ProvisionWorkerCertificate returned empty cert/ca payload")
        return _TLSMaterials(
            ca_cert=_validate_ca_pem(
                resp.ca_pem.encode(),
                error_message="invalid worker provisioned ca pem",
            ),
            client_cert=resp.cert_pem.encode(),
            client_key=private_key_pem,
        )

    def _resolve_explicit_worker_tls(
        self, worker_tls: Optional[WorkerTLSOpts]
    ) -> Optional[tuple[_TLSMaterials, str]]:
        if worker_tls is None:
            return None
        cert_pem = worker_tls.cert.strip()
        key_pem = worker_tls.key.strip()
        if bool(cert_pem) != bool(key_pem):
            raise RuntimeError("worker_tls.cert and worker_tls.key must be provided together")
        if not cert_pem:
            return None
        ca_pem = (
            _validate_ca_pem(
                worker_tls.ca_cert.encode(),
                error_message="invalid worker tls ca cert: malformed pem",
            )
            if worker_tls.ca_cert.strip()
            else _resolve_ca_pem(self._service_key, self._opts.ca_cert)
        )
        cert_bytes = cert_pem.encode()
        key_bytes = key_pem.encode()
        _validate_worker_cert_and_key(cert_bytes, key_bytes)
        return (
            _TLSMaterials(
                ca_cert=ca_pem,
                client_cert=cert_bytes,
                client_key=key_bytes,
            ),
            worker_tls.server_name.strip(),
        )

    async def _start_worker_server(self, host: str) -> str:
        from service_bridge.worker import WorkerServicer

        bind_host = host or "localhost"

        advertise_host = bind_host
        try:
            import ipaddress
            if ipaddress.ip_address(bind_host).is_unspecified:
                detected = _outbound_ip()
                if detected:
                    advertise_host = detected
        except ValueError:
            pass

        if self._worker_tls_creds is None:
            extra_ips = [advertise_host] if advertise_host != bind_host else None
            self._worker_tls_creds = self._provision_worker_tls(extra_ips=extra_ips)

        server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
        self._worker_servicer = WorkerServicer(self)
        pb_grpc.add_ServiceBridgeWorkerServicer_to_server(self._worker_servicer, server)
        server_creds = grpc.ssl_server_credentials(
            private_key_certificate_chain_pairs=[(
                self._worker_tls_creds.client_key,
                self._worker_tls_creds.client_cert,
            )],
            root_certificates=self._worker_tls_creds.ca_cert,
            require_client_auth=True,
        )
        port = server.add_secure_port(f"{bind_host}:0", server_creds)
        if port <= 0:
            raise RuntimeError("failed to bind worker gRPC server")
        server.start()
        self._worker_server = server
        return f"{advertise_host}:{port}"

    async def _sync_registrations(self) -> None:
        if self._stub is None:
            return
        md = self._metadata()
        fn_names = []
        group_names = []

        for fn, handler in self._rpc_handlers.items():
            opts = self._rpc_opts.get(fn, {})
            schema_opts = opts.get("schema")
            input_schema_json = ""
            output_schema_json = ""
            if schema_opts and schema_opts.input:
                input_schema_json = json.dumps({
                    k: {"type": v.type, "id": v.id, "repeated": v.repeated}
                    for k, v in schema_opts.input.items()
                })
            if schema_opts and schema_opts.output:
                output_schema_json = json.dumps({
                    k: {"type": v.type, "id": v.id, "repeated": v.repeated}
                    for k, v in schema_opts.output.items()
                })
            try:
                self._stub.RegisterFunction(
                    pb.RegisterFunctionRequest(
                        fn_name=fn,
                        service_name=self._service_name,
                        instance_id=self._instance_id,
                        endpoint=self._worker_address,
                        transport="tls",
                        weight=max(1, int(self._registration_weight)),
                        input_schema_json=input_schema_json,
                        output_schema_json=output_schema_json,
                    ),
                    metadata=md,
                    timeout=15,
                )
                fn_names.append(fn)
            except Exception as exc:
                logger.warning("RegisterFunction '%s': %s", fn, exc)

        for gname, entry in self._event_handlers.items():
            try:
                self._stub.RegisterConsumerGroup(
                    pb.RegisterConsumerGroupRequest(
                        name=gname,
                        pattern=entry["topic"],
                        mode="shared",
                        retry_policy_json=entry["retry_policy_json"],
                        active=True,
                        filter_expr=entry["filter_expr"],
                    ),
                    metadata=md,
                    timeout=15,
                )
                self._stub.RegisterGroupMember(
                    pb.RegisterGroupMemberRequest(
                        group_name=gname,
                        service_name=self._service_name,
                        instance_id=self._instance_id,
                        endpoint=self._worker_address,
                        transport="tls",
                        weight=max(1, int(self._registration_weight)),
                    ),
                    metadata=md,
                    timeout=15,
                )
                group_names.append(gname)
            except Exception as exc:
                logger.warning("RegisterConsumerGroup '%s': %s", gname, exc)

        # Process metrics (RAM via resource module, CPU best-effort).
        cpu_pct, ram_mb = _get_process_metrics()

        hb_req = pb.HeartbeatRequest(
            service_name=self._service_name,
            instance_id=self._instance_id,
            endpoint=self._worker_address,
            group_names=group_names,
            function_names=fn_names,
            transport="tls",
        )
        if cpu_pct > 0:
            hb_req.cpu_percent = cpu_pct
        if ram_mb > 0:
            hb_req.ram_mb = ram_mb

        try:
            self._stub.Heartbeat(hb_req, metadata=md, timeout=15)
        except Exception as exc:
            if isinstance(exc, grpc.RpcError):
                code = exc.code()  # type: ignore[attr-defined]
                if code in (grpc.StatusCode.NOT_FOUND, grpc.StatusCode.FAILED_PRECONDITION):
                    logger.warning(
                        "Heartbeat: re-registration required (%s) — will re-sync on next cycle", code
                    )
                    return
            if _is_connection_error(exc):
                self._mark_offline()
            logger.warning("Heartbeat: %s", exc)
            return

        try:
            self._stub.HeartbeatHttpEndpoint(
                pb.HeartbeatHttpEndpointRequest(
                    service_name=self._service_name,
                    instance_id=self._instance_id,
                ),
                metadata=md,
                timeout=15,
            )
        except Exception as exc:
            logger.warning("HTTP heartbeat: %s", exc)

    def _start_worker_session(self) -> None:
        if self._session_thread and self._session_thread.is_alive():
            return
        ready = threading.Event()
        ready_state: dict[str, Any] = {"error": None}
        self._session_thread = threading.Thread(
            target=self._worker_session_loop,
            args=(ready, ready_state),
            daemon=True,
        )
        self._session_thread.start()
        if not ready.wait(timeout=15.0):
            raise RuntimeError("OpenWorkerSession initial connect timed out")
        if ready_state["error"] is not None:
            raise RuntimeError(
                f"OpenWorkerSession initial connect failed: {ready_state['error']}"
            )

    def _worker_session_loop(
        self,
        ready: Optional[threading.Event] = None,
        ready_state: Optional[dict[str, Any]] = None,
    ) -> None:
        backoff = 1.0
        ready_reported = False
        while not self._stop_event.is_set():
            if self._stub is None:
                if self._stop_event.wait(backoff):
                    return
                backoff = min(backoff * 2, 15.0)
                continue

            q: deque[Any] = deque()
            q_cond = threading.Condition()

            def _enqueue(frame: Any) -> None:
                with q_cond:
                    q.append(frame)
                    q_cond.notify()

            def _request_iter():
                while not self._stop_event.is_set():
                    with q_cond:
                        while not q and not self._stop_event.is_set():
                            q_cond.wait(timeout=0.5)
                        if not q:
                            continue
                        item = q.popleft()
                    if item is None:
                        return
                    yield item

            try:
                stream = self._stub.OpenWorkerSession(_request_iter(), metadata=self._metadata())
                if not ready_reported and ready is not None:
                    if ready_state is not None:
                        ready_state["error"] = None
                    ready.set()
                    ready_reported = True
                _enqueue(
                    pb.WorkerSessionRequest(
                        hello=pb.WorkerSessionHello(
                            service_name=self._service_name,
                            instance_id=self._instance_id,
                            max_inflight=self._session_max_in_flight,
                        )
                    )
                )

                ping_stop = threading.Event()

                def _ping_loop() -> None:
                    while not ping_stop.wait(10.0):
                        _enqueue(
                            pb.WorkerSessionRequest(
                                ping=pb.WorkerSessionPing(
                                    timestamp_unix_ms=int(time.time() * 1000)
                                )
                            )
                        )

                ping_thread = threading.Thread(target=_ping_loop, daemon=True)
                ping_thread.start()
                backoff = 1.0

                for resp in stream:
                    if self._stop_event.is_set():
                        break
                    if resp.WhichOneof("payload") != "command":
                        continue
                    result = self._process_worker_session_command(resp.command)
                    _enqueue(pb.WorkerSessionRequest(command_result=result))

                ping_stop.set()
                ping_thread.join(timeout=1)
                _enqueue(None)
            except Exception as exc:
                if not ready_reported and ready is not None:
                    if ready_state is not None:
                        ready_state["error"] = exc
                    ready.set()
                    return
                logger.warning("worker session error: %s", exc)

            if self._stop_event.wait(backoff):
                return
            backoff = min(backoff * 2, 15.0)

    def _process_worker_session_command(
        self, command: pb.WorkerSessionCommand
    ) -> pb.WorkerSessionCommandResult:
        result = pb.WorkerSessionCommandResult(command_id=command.command_id)
        if command.deadline_unix_ms and int(time.time() * 1000) > command.deadline_unix_ms:
            result.error = "command deadline exceeded"
            return result
        if self._worker_servicer is None:
            result.error = "worker servicer is not initialized"
            return result

        if command.kind == pb.WorkerCommandKind.WORKER_COMMAND_KIND_RPC:
            rpc_cmd = command.rpc
            try:
                rpc_resp = self._worker_servicer.Handle(
                    pb.HandleRequest(
                        fn=rpc_cmd.fn,
                        payload=rpc_cmd.payload,
                        trace_id=rpc_cmd.trace_id,
                        span_id=rpc_cmd.span_id,
                    ),
                    _InProcessWorkerContext(rpc_cmd.run_id),
                )
                result.success = rpc_resp.success
                result.output = rpc_resp.output
                result.error = rpc_resp.error
                return result
            except Exception as exc:
                result.error = str(exc)[:2048]
                return result

        if command.kind == pb.WorkerCommandKind.WORKER_COMMAND_KIND_EVENT:
            event_cmd = command.event
            try:
                ack = self._dispatch_event_command(event_cmd)
                result.success = ack.ack
                result.ack = ack.ack
                result.retry_after_ms = ack.retry_after_ms
                result.reject_reason = ack.reject_reason
                result.error = ack.error
                return result
            except Exception as exc:
                result.error = str(exc)[:2048]
                return result

        result.error = f"unsupported command kind: {command.kind}"
        return result

    def _dispatch_event_command(self, event_cmd: pb.WorkerEventCommand) -> pb.DeliveryAck:
        return self._dispatch_event(
            group_name=event_cmd.group_name,
            topic=event_cmd.topic,
            message_id=event_cmd.message_id,
            attempt=event_cmd.attempt,
            payload=event_cmd.payload,
            headers=dict(event_cmd.headers),
            trace_id=event_cmd.trace_id,
            parent_span_id=event_cmd.parent_span_id,
            run_id=event_cmd.run_id,
        )

    def _dispatch_event(
        self,
        *,
        group_name: str,
        topic: str,
        message_id: str,
        attempt: int,
        payload: bytes,
        headers: dict[str, str],
        trace_id: str,
        parent_span_id: str,
        run_id: str,
    ) -> pb.DeliveryAck:
        entry = self._event_handlers.get(group_name)
        if entry is None:
            return pb.DeliveryAck(ack=False, error="consumer_group_handler_missing")

        raw_payload = payload if payload else b"{}"
        try:
            parsed_payload = json.loads(raw_payload)
        except json.JSONDecodeError:
            return pb.DeliveryAck(ack=False, reject_reason="invalid_json_payload")

        should_retry = False
        retry_after_ms = 1000
        reject_reason = ""

        def retry_fn(delay_ms: int = 1000) -> None:
            nonlocal should_retry, retry_after_ms
            should_retry = True
            retry_after_ms = delay_ms

        def reject_fn(reason: str) -> None:
            nonlocal reject_reason
            reject_reason = reason

        stream_writer = StreamWriter(run_id=run_id, client=self)
        ec = EventContext(
            trace_id=trace_id,
            span_id=parent_span_id,
            topic=topic,
            group_name=group_name,
            message_id=message_id,
            attempt=attempt,
            headers=headers,
            stream=stream_writer,
            _retry_fn=retry_fn,
            _reject_fn=reject_fn,
        )

        handler = entry["handler"]
        handler_err = ""
        try:
            loop = asyncio.new_event_loop()
            try:
                if asyncio.iscoroutinefunction(handler):
                    loop.run_until_complete(handler(parsed_payload, ec))
                else:
                    handler(parsed_payload, ec)
            finally:
                loop.close()
        except Exception as exc:
            handler_err = str(exc)[:2048]
            should_retry = True

        if reject_reason:
            return pb.DeliveryAck(ack=False, reject_reason=reject_reason, error=handler_err)
        if should_retry:
            return pb.DeliveryAck(ack=False, retry_after_ms=retry_after_ms, error=handler_err)
        return pb.DeliveryAck(ack=True)

    def _start_heartbeat(self) -> None:
        interval_ms = max(1000, int(self._opts.heartbeat_interval_ms or 10_000))

        def _loop() -> None:
            while not self._stop_event.is_set():
                # ±20% jitter on the heartbeat interval.
                jitter = random.uniform(-0.2, 0.2)
                delay = (interval_ms / 1000) * (1.0 + jitter)
                if self._stop_event.wait(delay):
                    return
                try:
                    asyncio.run(self._sync_registrations())
                except Exception as exc:
                    logger.warning("heartbeat error: %s", exc)
                    if _is_connection_error(exc):
                        self._mark_offline()

        self._heartbeat_thread = threading.Thread(target=_loop, daemon=True)
        self._heartbeat_thread.start()

    def _log_push(self, level: str, msg: str, attrs: dict[str, str]) -> None:
        """Internal: enqueue a log entry for batched delivery."""
        if not hasattr(self, "_log_batch"):
            self._log_batch = []
            self._log_lock = threading.Lock()
            self._log_timer = None

        tc = _trace_ctx.get({})
        entry = pb.LogEntry(
            service_name=self._service_name,
            instance_id=self._instance_id,
            level=level,
            message=msg,
            timestamp_ns=time.time_ns(),
            attributes=attrs,
            trace_id=tc.get("trace_id", ""),
            span_id=tc.get("span_id", ""),
        )
        flush_now = False
        with self._log_lock:
            self._log_batch.append(entry)
            if len(self._log_batch) >= 100:
                flush_now = True
            elif self._log_timer is None:
                t = threading.Timer(0.5, self._log_flush)
                t.daemon = True
                self._log_timer = t
                t.start()
        if flush_now:
            self._log_flush()

    def _log_flush(self) -> None:
        with self._log_lock:
            if not self._log_batch:
                return
            entries = list(self._log_batch)
            self._log_batch.clear()
            if self._log_timer is not None:
                self._log_timer.cancel()
                self._log_timer = None
        stub = self._stub
        if stub is None:
            return
        try:
            stub.ReportLog(
                pb.ReportLogRequest(entries=entries),
                metadata=self._metadata(),
                timeout=5,
            )
        except Exception as exc:
            _sdk_logger.debug("Log flush failed: %s", exc)

    def attach_logging_handler(
        self,
        logger_name: str = "",
        level: int = logging.NOTSET,
    ) -> "ServiceBridgeLogHandler":
        """Attach a :class:`ServiceBridgeLogHandler` to a Python standard logger.

        All records emitted by that logger (and its children) are forwarded to
        ServiceBridge automatically.  Original handlers are **not** removed.

        Args:
            logger_name: Name of the logger (empty = root logger = capture all).
            level: Minimum log level to forward (default: NOTSET = everything).

        Returns:
            The installed :class:`ServiceBridgeLogHandler` instance.
        """
        handler = ServiceBridgeLogHandler(self, level=level)
        logging.getLogger(logger_name).addHandler(handler)
        return handler


# ─── Process metrics ──────────────────────────────────────────────────────────

def _get_process_metrics() -> tuple[float, int]:
    """Return (cpu_percent, ram_mb). Best-effort; zero if unavailable."""
    ram_mb = 0
    cpu_pct = 0.0
    try:
        import resource
        usage = resource.getrusage(resource.RUSAGE_SELF)
        # ru_maxrss is in bytes on Linux, KB on macOS
        import sys
        if sys.platform == "darwin":
            ram_mb = int(usage.ru_maxrss / (1024 * 1024))
        else:
            ram_mb = int(usage.ru_maxrss / 1024)
    except Exception:
        pass
    return cpu_pct, ram_mb


# ─── Async gRPC stream helper ─────────────────────────────────────────────────

async def _aiter_grpc_stream(
    stream_call: Any,
    loop: asyncio.AbstractEventLoop,
    *,
    queue_limit: int = 256,
    overflow_error_factory: Optional[Callable[[], Exception]] = None,
) -> AsyncIterator:
    """Wrap a synchronous gRPC server-streaming call as an async generator.

    Runs the blocking iteration in a background thread and communicates via
    an asyncio.Queue with a 256-item backpressure limit.
    """
    q: asyncio.Queue = asyncio.Queue(maxsize=max(1, queue_limit) + 2)
    _sentinel = object()
    overflowed = threading.Event()

    def _overflow_error() -> Exception:
        if overflow_error_factory is not None:
            return overflow_error_factory()
        return RuntimeError("grpc stream queue overflow")

    def _emit(item: Any) -> None:
        if item is _sentinel:
            if q.full():
                try:
                    q.get_nowait()
                except Exception:
                    pass
            q.put_nowait(_sentinel)
            return
        if overflowed.is_set():
            return
        if not isinstance(item, Exception) and q.qsize() >= max(1, queue_limit):
            overflowed.set()
            try:
                q.put_nowait(_overflow_error())
            except Exception:
                pass
            try:
                q.put_nowait(_sentinel)
            except Exception:
                pass
            try:
                stream_call.cancel()
            except Exception:
                pass
            return
        try:
            q.put_nowait(item)
        except asyncio.QueueFull:
            overflowed.set()
            try:
                q.put_nowait(_overflow_error())
            except Exception:
                pass
            try:
                q.put_nowait(_sentinel)
            except Exception:
                pass

    def _reader() -> None:
        try:
            for chunk in stream_call:
                loop.call_soon_threadsafe(_emit, chunk)
        except Exception as exc:
            loop.call_soon_threadsafe(_emit, exc)
        finally:
            loop.call_soon_threadsafe(_emit, _sentinel)

    threading.Thread(target=_reader, daemon=True).start()

    while True:
        item = await q.get()
        if item is _sentinel:
            return
        if isinstance(item, Exception):
            raise item
        yield item


# ─── Workflow helpers ─────────────────────────────────────────────────────────

def _workflow_opts_json(opts: "Optional[WorkflowOpts]") -> str:
    """Serialize WorkflowOpts to a JSON string, omitting zero-value fields."""
    if opts is None:
        return ""
    d: dict[str, Any] = {}
    if opts.state_limit_bytes:
        d["stateLimitBytes"] = opts.state_limit_bytes
    if opts.step_timeout_ms:
        d["stepTimeoutMs"] = opts.step_timeout_ms
    return json.dumps(d) if d else ""


def _step_to_dict(s: WorkflowStep) -> dict[str, Any]:
    d: dict[str, Any] = {"id": s.id, "type": s.type}
    if s.ref:
        d["ref"] = s.ref
    if s.deps:
        d["deps"] = s.deps
    if s.if_expr:
        d["if"] = s.if_expr
    if s.timeout_ms:
        d["timeoutMs"] = s.timeout_ms
    if s.duration_ms:
        d["durationMs"] = s.duration_ms
    return d


# ─── Standard logging handler ─────────────────────────────────────────────────

_LEVEL_MAP: dict[int, str] = {
    logging.DEBUG: "DEBUG",
    logging.INFO: "INFO",
    logging.WARNING: "WARN",
    logging.ERROR: "ERROR",
    logging.CRITICAL: "ERROR",
}


class ServiceBridgeLogHandler(logging.Handler):
    """A :class:`logging.Handler` that ships Python log records to ServiceBridge.

    Records are batched and flushed every 500ms or when 100 records accumulate.
    Original handlers are preserved — logs still appear on the console.
    """

    def __init__(self, svc: "ServiceBridge", level: int = logging.NOTSET) -> None:
        super().__init__(level)
        self._svc = svc

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            sb_level = _LEVEL_MAP.get(record.levelno, "INFO")
            attrs: dict[str, str] = {"logger": record.name}
            if record.exc_info:
                import traceback as _tb
                attrs["exception"] = "".join(_tb.format_exception(*record.exc_info)).strip()
            self._svc._log_push(sb_level, msg, attrs)
        except Exception:
            self.handleError(record)
