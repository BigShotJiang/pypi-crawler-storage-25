import os as _os
import sys as _sys

# gRPC-generated stubs use bare `import servicebridge_pb2` without package path.
# Add this directory to sys.path so those bare imports resolve correctly.
_pb_dir = _os.path.dirname(__file__)
if _pb_dir not in _sys.path:
    _sys.path.insert(0, _pb_dir)
