# -*- coding: utf-8 -*-
"""Utility modules for AtendentePro library."""

from .logging_config import JSONFormatter, configure_logging
from .max_turns import DEFAULT_MAX_TURNS, ONE_SHOT_MAX_TURNS, get_default_max_turns
from .openai_client import (
    AsyncClient,
    Provider,
    build_model_for_agent,
    clear_client_cache,
    clear_provider_clients,
    get_async_client,
    get_provider,
)
from .rate_limiter import RateLimiter, RateLimitExceededError
from .token_budget import TokenBudgetExceededError, TokenBudgetLimiter
from .tracing import (  # MonkAI Trace (recommended); Application Insights (Azure); Legacy
    configure_application_insights,
    configure_monkai_trace,
    configure_tracing,
    get_monkai_hooks,
    run_with_monkai_tracking,
    set_monkai_input,
    set_monkai_user,
)
from .user_loader import (
    create_user_loader,
    extract_email_from_messages,
    extract_phone_from_messages,
    extract_user_id_from_messages,
    load_user_from_csv,
    run_with_user_context,
)

__all__ = [
    # OpenAI Client
    "get_async_client",
    "get_provider",
    "clear_client_cache",
    "build_model_for_agent",
    "clear_provider_clients",
    "AsyncClient",
    "Provider",
    # MonkAI Trace
    "configure_monkai_trace",
    "get_monkai_hooks",
    "set_monkai_user",
    "set_monkai_input",
    "run_with_monkai_tracking",
    # Application Insights
    "configure_application_insights",
    # Legacy
    "configure_tracing",
    # User Loader
    "create_user_loader",
    "run_with_user_context",
    "extract_phone_from_messages",
    "extract_email_from_messages",
    "extract_user_id_from_messages",
    "load_user_from_csv",
    # Rate Limiter
    "RateLimiter",
    "RateLimitExceededError",
    # Token Budget (issue #180)
    "TokenBudgetLimiter",
    "TokenBudgetExceededError",
    # Logging
    "configure_logging",
    "JSONFormatter",
    # Max turns (issue #176)
    "DEFAULT_MAX_TURNS",
    "ONE_SHOT_MAX_TURNS",
    "get_default_max_turns",
]
