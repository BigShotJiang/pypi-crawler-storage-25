# -*- coding: utf-8 -*-
"""Guardrails module for AtendentePro library."""

from .manager import (
    GuardrailCallable,
    GuardrailManager,
    InputGuardrailDecision,
    clear_guardrail_cache,
    get_guardrails_for_agent,
    get_out_of_scope_message,
    load_guardrail_config,
    run_input_guardrails,
    set_guardrails_client,
)
from .specialist import (
    LegacyVerdict,
    SpecialistConfig,
    SpecialistGuardrailVerdict,
    apply_thresholds,
    build_specialist_agent,
    parse_verdict,
    run_specialist_guardrail,
)
from .specialist_tools import classify_intent, detect_pii

__all__ = [
    "GuardrailManager",
    "GuardrailCallable",
    "InputGuardrailDecision",
    "get_guardrails_for_agent",
    "get_out_of_scope_message",
    "load_guardrail_config",
    "set_guardrails_client",
    "clear_guardrail_cache",
    "run_input_guardrails",
    # Specialist (opt-in, multi-dimensional verdict — see
    # docs/setup_passo_a_passo/22_opcionais_specialist_guardrail.md).
    "SpecialistGuardrailVerdict",
    "LegacyVerdict",
    "SpecialistConfig",
    "build_specialist_agent",
    "parse_verdict",
    "apply_thresholds",
    "run_specialist_guardrail",
    "detect_pii",
    "classify_intent",
]
