# -*- coding: utf-8 -*-
"""Request and response models for the AtendentePro service API."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

# Tenant IDs become directory names under ``_templates_dir`` and must not be
# used to escape the templates root via path traversal (``../victim``) or
# alias another tenant's directory. Restrict to a conservative alphanumeric
# charset that matches every observed in-prod tenant id (e.g. ``t1``, ``acme``,
# ``deploy_test``, ``ensemble_tenant``). Defense-in-depth ``is_relative_to``
# is enforced server-side in ``service/manager.py``. Issue #167.
TENANT_ID_PATTERN = r"^[A-Za-z0-9_\-]+$"


class SetupRequest(BaseModel):
    """Payload for POST /setup — registers or updates a tenant's agent network."""

    tenant_id: str = Field(..., min_length=1, max_length=128, pattern=TENANT_ID_PATTERN)
    yamls: Dict[str, str] = Field(
        ...,
        description="Map of config name to YAML content, e.g. {'flow_config': '...', 'triage_config': '...'}",
    )
    include_agents: Optional[Dict[str, bool]] = Field(
        default=None,
        description=(
            "Agent inclusion overrides. Keys: flow, interview, answer, knowledge, "
            "confirmation, usage, onboarding, escalation, feedback."
        ),
    )
    network_config: Optional[Dict[str, List[str]]] = Field(
        default=None,
        description=(
            "Custom handoff graph. Maps agent name to list of handoff target names. "
            "When set, uses create_custom_network instead of create_standard_network."
        ),
    )
    network_type: Optional[str] = Field(
        default=None,
        description=(
            "Strategy for assembling the AgentNetwork. Accepts 'standard', "
            "'custom_module' or 'parallel'. Defaults to 'standard' inside the "
            "manager. Use 'custom_module' together with network_module / "
            "network_factory to plug a client-specific factory at /setup time "
            "instead of pre-registering it in code."
        ),
    )
    network_module: Optional[str] = Field(
        default=None,
        description=(
            "Dotted import path of the module that exposes the custom network "
            "factory (only used when network_type='custom_module'). Must match "
            "the ATENDENTEPRO_NETWORK_MODULE_PREFIX allowlist (default: "
            "'client_resources.')."
        ),
    )
    network_factory: Optional[str] = Field(
        default=None,
        description=(
            "Name of the callable inside network_module that returns an "
            "AgentNetwork (only used when network_type='custom_module'). "
            "The callable receives network_params as kwargs."
        ),
    )
    network_params: Optional[Dict[str, Any]] = Field(
        default=None,
        description=(
            "Extra kwargs forwarded to the custom factory (only used when "
            "network_type='custom_module'). Typical use: pass 'templates_root' "
            "so the factory knows where the YAMLs live on disk."
        ),
    )
    availability_schedule: Optional[Dict[str, Any]] = Field(
        default=None,
        description=(
            "Optional business-hours gate (issue #136). Shape: "
            "{'timezone': 'America/Sao_Paulo', "
            "'hours': {'monday': {'start': '08:00', 'end': '18:00'}, ...}, "
            "'out_of_hours_message': '...'}. When configured, /chat "
            "short-circuits with the OOH message outside the windows."
        ),
    )
    memory_context_block_tag: Optional[str] = Field(
        default=None,
        description=(
            "Long-term memory context block tag (issue #271/#288). When "
            "set (e.g. 'long_term_memory'), every agent in the network "
            "gets a canonical instruction appended to its prompt telling "
            "it that a `<{tag}>...</{tag}>` block may be present in the "
            "conversation and how to consume it. Eliminates the drift of "
            "duplicating the read directive across each agent's "
            "`custom_prompt_*`. Default null and empty-string preserve "
            "pre-#271 behavior byte-for-byte. See "
            "docs/setup_passo_a_passo/19_opcionais_memory_context_block_tag.md "
            "and docs/setup_passo_a_passo/21_long_term_memory_canonical_pattern.md."
        ),
    )


class UserContextPayload(BaseModel):
    """User identity for role-based access filtering."""

    user_id: Optional[str] = None
    role: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class ChatRequest(BaseModel):
    """Payload for POST /chat — sends a message to a tenant's agent network."""

    # Upper bounds on text inputs prevent log flooding and memory spikes
    # from a malicious or buggy caller. tenant_id/session_id are routing
    # keys so a hard cap of 128 is plenty; message is the LLM input so
    # we allow a generous 64 KB (~16k tokens).
    tenant_id: str = Field(..., min_length=1, max_length=128, pattern=TENANT_ID_PATTERN)
    session_id: str = Field(..., min_length=1, max_length=128)
    message: str = Field(..., min_length=1, max_length=65_536)
    metadata: Optional[Dict[str, Any]] = None
    user_context: Optional[UserContextPayload] = Field(
        default=None,
        description="User identity for RBAC filtering (user_id, role, metadata).",
    )
    context_injection: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description=(
            "Per-request system messages PREPENDED to the conversation "
            "before the runner is invoked (issue #272/#290). Use to add "
            "external context (e.g. patient profile, session metadata, "
            "long-term memory block) without polluting the user message "
            "or mutating the build-time prompt. The injection does NOT "
            "persist in session history — it is per-request only. "
            "Default null and empty list preserve pre-#290 behavior "
            "byte-for-byte. See "
            "docs/setup_passo_a_passo/20_opcionais_context_injection.md."
        ),
    )

    # Note: per-request prompt_dialect / prompt_dialect_enabled fields
    # were removed. Agent instructions are baked at tenant setup time,
    # so a payload toggle had no real effect and surfaced as a false API
    # contract (the server would silently log + drop). For real A/B
    # switching, set PROMPT_DIALECT_ENABLED / PROMPT_DIALECT in the
    # service env and rebuild tenants.


class ToolCallPayload(BaseModel):
    """A single function-tool call emitted by an agent during a /chat run.

    Exposed so consumers running tools client-side (e.g. an edge function
    persisting to its own database) can replay the call with their own
    credentials. The server has already executed the registered Python tool
    and fed the output back to the model — ``tool_results`` carries that
    output, also for client transparency.
    """

    call_id: Optional[str] = Field(
        default=None,
        description="Provider-assigned identifier; pairs the call with its entry in tool_results.",
    )
    name: str = Field(..., description="Function-tool name (e.g. 'register_meal').")
    arguments: str = Field(
        ...,
        description="Arguments as a JSON-encoded string, exactly as the model produced them.",
    )


class ToolResultPayload(BaseModel):
    """The output the server's tool implementation returned for a tool call."""

    call_id: Optional[str] = None
    output: str = Field(..., description="String output of the tool (often JSON).")


class ChatResponse(BaseModel):
    """Response from POST /chat."""

    response: str
    agent_name: Optional[str] = None
    handoff_to: Optional[str] = None
    tool_calls: List[ToolCallPayload] = Field(
        default_factory=list,
        description=(
            "Function-tool calls produced during the run. Empty when the agent "
            "answered with text only."
        ),
    )
    tool_results: List[ToolResultPayload] = Field(
        default_factory=list,
        description=("Outputs of the tools executed by the server, paired with calls via call_id."),
    )
    no_reply: bool = Field(
        default=False,
        description=(
            "True when the server intentionally did not invoke the agent network "
            "(e.g. staff takeover via UserContext.metadata.human_active). When set, "
            "``response`` is empty and ``no_reply_reason`` carries the reason code."
        ),
    )
    no_reply_reason: Optional[str] = Field(
        default=None,
        description=("Reason code when ``no_reply`` is true. Known values: 'human_active'."),
    )


class HealthResponse(BaseModel):
    """Response from GET /health."""

    status: str = "ok"
    version: str
    tenants_loaded: List[str] = Field(default_factory=list)
