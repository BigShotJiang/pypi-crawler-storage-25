# -*- coding: utf-8 -*-
"""
Template Manager for AtendentePro.

Provides dynamic client-specific configuration loading from external template directories.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from functools import lru_cache, wraps
from pathlib import Path


def _path_normalized_cache(maxsize: int = 4) -> Any:  # type: ignore[no-untyped-def]
    """lru_cache wrapper that normalizes Path args to resolved strings for consistent
    cache keys across platforms (issue #31: Windows path separator mismatch)."""

    def decorator(func: Any) -> Any:
        @lru_cache(maxsize=maxsize)
        def _cached(cls: Any, path_str: str) -> Any:
            return func(cls, Path(path_str))

        @wraps(func)
        def wrapper(cls: Any, path: Path) -> Any:
            return _cached(cls, str(path.resolve()))

        wrapper.cache_clear = _cached.cache_clear  # type: ignore[attr-defined]
        wrapper.cache_info = _cached.cache_info  # type: ignore[attr-defined]
        return wrapper

    return decorator


from typing import TYPE_CHECKING, Any, Callable, Dict, List, Literal, Optional

import yaml
from pydantic import BaseModel, Field, model_validator
from typing_extensions import NotRequired, TypedDict

if TYPE_CHECKING:
    from atendentepro.multiagent.metadata import AgentMetadata

logger = logging.getLogger(__name__)

_KNOWLEDGE_YAML_ALLOWED_TOP_KEYS = frozenset(
    {
        "about",
        "template",
        "format",
        "embeddings_path",
        "documents",
        "data_source",
        "data_sources",
        "instructions",
        "rag_config",
    }
)

# Issue #225: warn on unknown top-level keys in YAML configs so clients catch
# typos and misuse early instead of debugging silently-ignored blocks.
_TRIAGE_YAML_ALLOWED_TOP_KEYS = frozenset(
    {
        "agent_name",
        "keywords",
        "agent_keywords",
        "routing_rules",
        "custom_prompt",
        "custom_prompt_prefix",
        "custom_prompt_suffix",
    }
)
_INTERVIEW_YAML_ALLOWED_TOP_KEYS = frozenset({"agent_name", "interview_questions", "topics"})
_CONFIRMATION_YAML_ALLOWED_TOP_KEYS = frozenset({"agent_name", "about", "template", "format"})
_SCHEDULING_YAML_ALLOWED_TOP_KEYS = frozenset(
    {
        "agent_name",
        "about",
        "template",
        "format",
        "allow_create",
        "allow_reschedule",
        "allow_cancel",
        # Issue #265: declarative scheduling schema. Consumers describe their
        # available physical/virtual sites, professionals and appointment
        # types so the agent can route bookings deterministically. Today the
        # library consumes ``locations`` (multi-location prompt branch);
        # ``professionals`` / ``appointment_types`` are accepted in the
        # canonical schema so consumers can declare them without spurious
        # "unknown top-level key" warnings, even when downstream tools own
        # the lookup.
        "locations",
        "professionals",
        "appointment_types",
    }
)
_STYLE_YAML_ALLOWED_TOP_KEYS = frozenset({"global", "agents"})

# Issue #235: extend ``_warn_unknown_top_keys`` coverage to the remaining
# eight ``*Config.load`` paths so typos in client YAML surface as warnings
# instead of silently disabling the feature.
_FLOW_YAML_ALLOWED_TOP_KEYS = frozenset({"topics", "keywords"})
_ONBOARDING_YAML_ALLOWED_TOP_KEYS = frozenset({"required_fields"})
_FEEDBACK_YAML_ALLOWED_TOP_KEYS = frozenset(
    {
        "protocol_prefix",
        "ticket_types",
        "priorities",
        "email",
        "messages",
        "auto_priority",
        "categories",
        "instructions",
    }
)
_ESCALATION_YAML_ALLOWED_TOP_KEYS = frozenset(
    {
        "triggers",
        "channels",
        "business_hours",
        "priority",
        "messages",
        "notifications",
        "instructions",
    }
)
_ANSWER_YAML_ALLOWED_TOP_KEYS = frozenset({"instructions", "response_format", "context_defaults"})
_USAGE_YAML_ALLOWED_TOP_KEYS = frozenset(
    {
        "description",
        "contact_channels",
        "faq",
        "how_to_order",
        "system_context",
        "instructions",
    }
)
_SINGLE_REPLY_YAML_ALLOWED_TOP_KEYS = frozenset({"global", "agents"})
_ACCESS_YAML_ALLOWED_TOP_KEYS = frozenset({"agent_filters", "conditional_prompts", "tool_access"})
# ``provider_config.yaml`` allow-list — referenced by ``ProviderTemplateConfig``
# (issue #240 logs YAML errors instead of swallowing).
_PROVIDER_YAML_ALLOWED_TOP_KEYS = frozenset({"agent_models", "agent_providers"})


def _warn_unknown_top_keys(
    config_name: str,
    path: Path,
    data: Dict[str, Any],
    allowed: frozenset,
) -> None:
    """Log a warning when YAML contains top-level keys outside the allowlist.

    Mirrors the pattern introduced for ``KnowledgeConfig`` so unknown keys
    surface in client logs instead of being silently dropped (issue #225).
    """
    unknown = [k for k in data if k not in allowed]
    if unknown:
        logger.warning(
            "%s (%s): chaves de topo nao usadas pela biblioteca serao ignoradas: %s",
            config_name,
            path,
            ", ".join(sorted(unknown)),
        )


@dataclass
class ClientTemplate:
    """Metadata required to load and configure a client profile."""

    key: str
    template_name: str
    aliases: tuple[str, ...] = ()
    configurator: Optional[Callable[[str], None]] = None


class FlowTopic(BaseModel):
    """Model for a flow topic."""

    id: str
    label: str
    keywords: List[str] = Field(default_factory=list)


class FlowConfig(BaseModel):
    """Configuration model for Flow Agent."""

    topics: List[FlowTopic] = Field(default_factory=list)
    keywords: List[Dict[str, Any]] = Field(default_factory=list)

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "FlowConfig":
        """Load flow configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Flow config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys("flow_config.yaml", path, data, _FLOW_YAML_ALLOWED_TOP_KEYS)

        topics = []
        for topic_data in data.get("topics", []):
            topics.append(
                FlowTopic(
                    id=topic_data.get("id", ""),
                    label=topic_data.get("label", ""),
                    keywords=topic_data.get("keywords", []),
                )
            )

        return cls(
            topics=topics,
            keywords=data.get("keywords", []),
        )

    def get_flow_template(self) -> str:
        """Generate formatted topic template."""
        return "\n".join(f"{idx}. {topic.label}" for idx, topic in enumerate(self.topics, start=1))

    def get_flow_keywords(self) -> str:
        """Generate formatted keywords text."""
        lines = []
        for topic in self.topics:
            if topic.keywords:
                formatted_terms = ", ".join(f'"{term}"' for term in topic.keywords)
                lines.append(f"- {topic.label}: {formatted_terms}")
        return "\n".join(lines)


class InterviewConfig(BaseModel):
    """Configuration model for Interview Agent."""

    interview_questions: str = ""
    topics: List[Dict[str, Any]] = Field(default_factory=list)

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "InterviewConfig":
        """Load interview configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Interview config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys(
            "interview_config.yaml", path, data, _INTERVIEW_YAML_ALLOWED_TOP_KEYS
        )

        return cls(
            interview_questions=data.get("interview_questions", ""),
            topics=data.get("topics", []),
        )


class TriageRoutingRules(BaseModel):
    """Optional routing hints from triage_config.yaml.

    ``priority_order`` and ``default_agent`` are **non-deterministic** hints
    surfaced under the ``## Orientações de roteamento`` heading. They inform
    the LLM but do not force a handoff.

    ``deterministic_agents`` (issue #246) is the **deterministic** counterpart:
    each agent listed here gets its own ``## Roteamento de <agent>
    (DETERMINÍSTICO)`` block built from ``keywords.<agent>`` in the same
    YAML. The block instructs the Triage Agent to hand off IMMEDIATELY when
    any of the configured triggers appears. ``escalation`` keeps its
    legacy auto-fire behavior even when omitted (backward compatibility).
    """

    priority_order: List[str] = Field(default_factory=list)
    default_agent: Optional[str] = None
    deterministic_agents: List[str] = Field(default_factory=list)


class TriageConfig(BaseModel):
    """Configuration model for Triage Agent keywords, routing hints and prompt overrides.

    Reads ``triage_config.yaml`` from a client template directory.

    Example YAML::

        keywords:
          flow:        ["preço", "produto"]
          knowledge:   ["documentação", "manual"]
          escalation:  ["urgência", "falar com humano"]   # auto-builds deterministic block

        routing_rules:
          priority_order: [knowledge, flow]
          default_agent: onboarding                       # fallback when intent is unclear

        # Issue #226: optional Triage prompt overrides driven by YAML
        custom_prompt_suffix: |
          ## Regras adicionais
          - Quando o usuário pergunta sobre serviços, encaminhe para knowledge.
        # Issue #247: prefix has stronger weight than suffix because it is
        # prepended BEFORE the base prompt anchors the model.
        custom_prompt_prefix: |
          ## REGRAS DE ROTEAMENTO PRIORITARIAS
          Saudações ambíguas → onboarding imediatamente.
        # Or replace the whole Triage prompt:
        # custom_prompt: "..."

    Unknown top-level keys are logged at WARNING level (issue #225).
    """

    keywords: Dict[str, List[str]] = Field(default_factory=dict)
    routing_rules: Optional[TriageRoutingRules] = None
    # Issue #226 / #247: optional prompt overrides exposed via YAML.
    # ``custom_prompt`` replaces the default Triage instructions entirely
    # (mirrors the ``triage_custom_instructions`` Python kwarg).
    # ``custom_prompt_prefix`` is prepended BEFORE the resolved base prompt
    # (stronger weight, for override-style routing rules).
    # ``custom_prompt_suffix`` is appended after the default keywords + routing
    # block so clients can layer extra rules without redeploying the server.
    custom_prompt: Optional[str] = None
    custom_prompt_prefix: Optional[str] = None
    custom_prompt_suffix: Optional[str] = None

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "TriageConfig":
        """Load triage configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Triage config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys("triage_config.yaml", path, data, _TRIAGE_YAML_ALLOWED_TOP_KEYS)

        raw_keywords = data.get("keywords") or data.get("agent_keywords") or {}
        keywords: Dict[str, List[str]] = {}
        for agent, entry in raw_keywords.items():
            if isinstance(entry, dict):
                keywords[agent] = entry.get("keywords", [])
            elif isinstance(entry, list):
                keywords[agent] = entry

        routing_rules: Optional[TriageRoutingRules] = None
        rr = data.get("routing_rules")
        if isinstance(rr, dict):
            routing_rules = TriageRoutingRules(
                priority_order=list(rr.get("priority_order") or []),
                default_agent=rr.get("default_agent"),
                deterministic_agents=list(rr.get("deterministic_agents") or []),
            )

        custom_prompt = data.get("custom_prompt")
        custom_prompt_prefix = data.get("custom_prompt_prefix")
        custom_prompt_suffix = data.get("custom_prompt_suffix")

        return cls(
            keywords=keywords,
            routing_rules=routing_rules,
            custom_prompt=(custom_prompt.strip() if isinstance(custom_prompt, str) else None)
            or None,
            custom_prompt_prefix=(
                custom_prompt_prefix.strip() if isinstance(custom_prompt_prefix, str) else None
            )
            or None,
            custom_prompt_suffix=(
                custom_prompt_suffix.strip() if isinstance(custom_prompt_suffix, str) else None
            )
            or None,
        )

    def get_routing_hint_text(self) -> str:
        """Human-readable routing hints for triage instructions (from routing_rules).

        Produces a short block appended to the Triage prompt under the
        ``## Orientações de roteamento`` heading. It is **non-deterministic**:
        it instructs the LLM rather than forcing a handoff (use
        ``keywords.escalation`` if you need a deterministic block — see
        :meth:`_get_escalation_routing_text`).

        Example::

            >>> cfg = TriageConfig(routing_rules=TriageRoutingRules(default_agent="onboarding"))
            >>> cfg.get_routing_hint_text()
            'Quando a intenção não estiver clara, direcione para o agente: onboarding.'
        """
        if not self.routing_rules:
            return ""
        lines: List[str] = []
        rr = self.routing_rules
        if rr.priority_order:
            order = ", ".join(rr.priority_order)
            lines.append(
                f"Ordem de preferência ao escolher entre agentes (quando aplicável): {order}."
            )
        if rr.default_agent:
            lines.append(
                f"Quando a intenção não estiver clara, direcione para o agente: {rr.default_agent}."
            )
        return "\n".join(lines)

    def get_keywords_text(self) -> str:
        """Format keywords and optional routing hints for agent instructions.

        Each agent named in ``routing_rules.deterministic_agents`` (issue
        #246) gets its own ``## Roteamento de <agent> (DETERMINÍSTICO)``
        block built from ``keywords.<agent>``. The ``escalation`` key keeps
        its legacy auto-fire behavior (issue #88) — a deterministic block
        is emitted whenever ``keywords.escalation`` is present, even if
        ``deterministic_agents`` is omitted, so existing configs continue
        to work byte-for-byte.
        """
        lines: List[str] = []
        for agent, kws in self.keywords.items():
            if kws:
                formatted = ", ".join(f'"{kw}"' for kw in kws)
                lines.append(f"- {agent}: {formatted}")
        body = "\n".join(lines)
        sections: List[str] = []
        if body:
            sections.append(body)

        sections.extend(self._get_deterministic_routing_blocks())

        hint = self.get_routing_hint_text()
        if hint:
            sections.append(f"## Orientações de roteamento\n{hint}")

        return "\n\n".join(sections)

    # ------------------------------------------------------------------
    # Deterministic routing blocks (issue #88 + #246)
    # ------------------------------------------------------------------

    # Friendly PT-BR labels for the heading and the Agent name in the
    # instruction body. Agents not listed here fall back to the generic
    # format ``## Roteamento de <key>`` and ``<key.title()> Agent``.
    _DETERMINISTIC_AGENT_LABELS: Dict[str, Dict[str, str]] = {
        "escalation": {
            "heading": "Roteamento de escalonamento",
            "target": "Escalation Agent",
        },
        "onboarding": {
            "heading": "Roteamento de onboarding",
            "target": "Onboarding Agent",
        },
        "knowledge": {
            "heading": "Roteamento de knowledge",
            "target": "Knowledge Agent",
        },
        "farewell": {
            "heading": "Roteamento de despedida",
            "target": "Farewell Agent",
        },
        "flow": {
            "heading": "Roteamento de flow",
            "target": "Flow Agent",
        },
        "confirmation": {
            "heading": "Roteamento de confirmação",
            "target": "Confirmation Agent",
        },
        "answer": {
            "heading": "Roteamento de answer",
            "target": "Answer Agent",
        },
        "usage": {
            "heading": "Roteamento de usage",
            "target": "Usage Agent",
        },
        "scheduling": {
            "heading": "Roteamento de agendamento",
            "target": "Scheduling Agent",
        },
        "feedback": {
            "heading": "Roteamento de feedback",
            "target": "Feedback Agent",
        },
    }

    def _deterministic_agents(self) -> List[str]:
        """Return the ordered list of agents that need a deterministic block.

        Combines the explicit ``routing_rules.deterministic_agents`` list
        (preserving its order) with the implicit ``escalation`` legacy
        auto-fire (issue #88) when ``keywords.escalation`` is present and
        ``escalation`` is not already in the explicit list. Skips agents
        without configured ``keywords``.
        """
        explicit: List[str] = []
        if self.routing_rules and self.routing_rules.deterministic_agents:
            explicit = list(self.routing_rules.deterministic_agents)

        agents: List[str] = []
        for agent in explicit:
            if agent not in agents and (self.keywords.get(agent) or []):
                agents.append(agent)

        if "escalation" not in agents and (self.keywords.get("escalation") or []):
            agents.append("escalation")

        return agents

    def _format_deterministic_block(self, agent: str) -> str:
        """Render a single ``## Roteamento de <agent> (DETERMINÍSTICO)`` block."""
        triggers = self.keywords.get(agent) or []
        if not triggers:
            return ""
        label = self._DETERMINISTIC_AGENT_LABELS.get(
            agent,
            {
                "heading": f"Roteamento de {agent}",
                "target": f"{agent.title()} Agent",
            },
        )
        heading = label["heading"]
        # ``escalation`` keeps its pre-#246 heading verbatim (no marker)
        # so existing snapshots/templates that look for the heading text
        # continue to work byte-for-byte.
        is_legacy_escalation = agent == "escalation" and not (
            self.routing_rules and "escalation" in (self.routing_rules.deterministic_agents or [])
        )
        if not is_legacy_escalation:
            heading = f"{heading} (DETERMINÍSTICO)"
        triggers_text = ", ".join(f'"{kw}"' for kw in triggers)
        return (
            f"## {heading}\n"
            f"Quando a mensagem do usuário contiver qualquer um dos sinais abaixo, "
            f"transfira IMEDIATAMENTE para o {label['target']} sem responder antes. "
            f"Não tente resolver o pedido nem fazer perguntas adicionais — apenas "
            f"encaminhe.\n"
            f"Sinais: {triggers_text}"
        )

    def _get_deterministic_routing_blocks(self) -> List[str]:
        """Return all deterministic routing blocks in declaration order."""
        blocks: List[str] = []
        for agent in self._deterministic_agents():
            block = self._format_deterministic_block(agent)
            if block:
                blocks.append(block)
        return blocks

    def _get_escalation_routing_text(self) -> str:
        """Legacy alias preserved for callers that import this method directly.

        Returns the escalation deterministic block when ``keywords.escalation``
        is set, otherwise an empty string. New code should rely on the
        generic ``_get_deterministic_routing_blocks`` via ``get_keywords_text``
        instead — this shim exists only for backward compatibility (issue #88).
        """
        if not (self.keywords.get("escalation") or []):
            return ""
        return self._format_deterministic_block("escalation")

    def get_escalation_triggers(self) -> List[str]:
        """Return the configured escalation triggers (issue #88).

        Public accessor so other components (e.g. guardrails) can reuse the
        same trigger list without re-parsing the YAML.
        """
        return list(self.keywords.get("escalation") or [])


class DataSourceColumn(BaseModel):
    """Model for a data source column."""

    name: str
    description: str = ""
    type: str = "string"  # string, number, date, boolean


class DataSourceConfig(BaseModel):
    """Configuration for structured data sources."""

    type: str = "csv"  # csv, database, api
    path: Optional[str] = None  # For CSV files
    connection_env: Optional[str] = None  # For database connections
    api_url: Optional[str] = None  # For API endpoints
    encoding: str = "utf-8"
    columns: List[DataSourceColumn] = Field(default_factory=list)
    tables: List[Dict[str, str]] = Field(default_factory=list)  # For databases


class DocumentConfig(BaseModel):
    """Configuration for a knowledge document."""

    name: str
    path: str
    description: str = ""


class RagConfig(BaseModel):
    """Optional RAG search tuning (read from ``rag_config`` in ``knowledge_config.yaml``)."""

    max_results: Optional[int] = None
    similarity_threshold: Optional[float] = None


class KnowledgeConfig(BaseModel):
    """Configuration model for Knowledge Agent.

    Supports both document-based RAG and structured data sources.
    """

    about: str = ""
    template: str = ""
    format: str = ""
    instructions: str = ""

    # Document-based RAG
    embeddings_path: Optional[str] = None
    documents: List[DocumentConfig] = Field(default_factory=list)
    rag_config: Optional[RagConfig] = None

    # Structured data sources
    data_sources: List[DataSourceConfig] = Field(default_factory=list)

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "KnowledgeConfig":
        """Load knowledge configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Knowledge config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        unknown = [k for k in data if k not in _KNOWLEDGE_YAML_ALLOWED_TOP_KEYS]
        if unknown:
            logger.warning(
                "knowledge_config.yaml (%s): chaves de topo nao usadas pela biblioteca serao ignoradas: %s",
                path,
                ", ".join(sorted(unknown)),
            )

        # Parse documents
        documents = []
        for doc_data in data.get("documents", []):
            documents.append(
                DocumentConfig(
                    name=doc_data.get("name", ""),
                    path=doc_data.get("path", ""),
                    description=doc_data.get("description", ""),
                )
            )

        # Parse data sources
        data_sources = []

        # Check for single data_source (backwards compatibility)
        if "data_source" in data:
            ds = data["data_source"]
            columns = [
                DataSourceColumn(
                    name=c.get("name", ""),
                    description=c.get("description", ""),
                    type=c.get("type", "string"),
                )
                for c in ds.get("columns", [])
            ]
            data_sources.append(
                DataSourceConfig(
                    type=ds.get("type", "csv"),
                    path=ds.get("path"),
                    connection_env=ds.get("connection_env"),
                    api_url=ds.get("api_url"),
                    encoding=ds.get("encoding", "utf-8"),
                    columns=columns,
                    tables=ds.get("tables", []),
                )
            )

        # Check for multiple data_sources
        for ds in data.get("data_sources", []):
            columns = [
                DataSourceColumn(
                    name=c.get("name", ""),
                    description=c.get("description", ""),
                    type=c.get("type", "string"),
                )
                for c in ds.get("columns", [])
            ]
            data_sources.append(
                DataSourceConfig(
                    type=ds.get("type", "csv"),
                    path=ds.get("path"),
                    connection_env=ds.get("connection_env"),
                    api_url=ds.get("api_url"),
                    encoding=ds.get("encoding", "utf-8"),
                    columns=columns,
                    tables=ds.get("tables", []),
                )
            )

        rag_config: Optional[RagConfig] = None
        raw_rag = data.get("rag_config")
        if isinstance(raw_rag, dict):
            rag_config = RagConfig(
                max_results=raw_rag.get("max_results"),
                similarity_threshold=raw_rag.get("similarity_threshold"),
            )

        return cls(
            about=data.get("about", ""),
            template=data.get("template", ""),
            format=data.get("format", ""),
            instructions=(data.get("instructions") or "").strip(),
            embeddings_path=data.get("embeddings_path"),
            documents=documents,
            rag_config=rag_config,
            data_sources=data_sources,
        )

    def has_documents(self) -> bool:
        """Check if document-based RAG is configured."""
        return bool(self.embeddings_path or self.documents)

    def has_data_sources(self) -> bool:
        """Check if structured data sources are configured."""
        return bool(self.data_sources)

    def get_data_source_description(self) -> str:
        """Generate description of available data sources."""
        parts = []

        if self.documents:
            doc_list = ", ".join(d.name for d in self.documents)
            parts.append(f"Documentos: {doc_list}")

        for ds in self.data_sources:
            if ds.type == "csv":
                cols = ", ".join(c.name for c in ds.columns)
                parts.append(f"CSV ({ds.path}): {cols}")
            elif ds.type == "database":
                tables = ", ".join(t.get("name", "") for t in ds.tables)
                parts.append(f"Database: {tables}")
            elif ds.type == "api":
                parts.append(f"API: {ds.api_url}")

        return "\n".join(parts)


class ConfirmationConfig(BaseModel):
    """Configuration model for Confirmation Agent."""

    about: str = ""
    template: str = ""
    format: str = ""

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "ConfirmationConfig":
        """Load confirmation configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Confirmation config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys(
            "confirmation_config.yaml", path, data, _CONFIRMATION_YAML_ALLOWED_TOP_KEYS
        )

        return cls(
            about=data.get("about", ""),
            template=data.get("template", ""),
            format=data.get("format", ""),
        )


class Location(BaseModel):
    """A physical or virtual scheduling location (issue #265).

    Generic across tenants — placeholder fields only, no client-specific
    semantics. Used by ``SchedulingConfig.locations`` to drive the
    multi-location proactive prompt branch in
    :func:`atendentepro.prompts.scheduling.get_scheduling_prompt`.

    ``window_start`` / ``window_end`` accept any ISO-8601 date string and
    are surfaced verbatim in the prompt; the LLM uses them as a hint
    rather than as a hard validator.

    Optional fields default to ``None`` so external generators that produce
    YAML dynamically from nullable database columns (issue #268) can emit
    ``null`` without tripping ``ValidationError``. The prompt builder in
    :func:`atendentepro.prompts.scheduling._location_field` already coerces
    ``None`` to an empty string, so the rendered output is byte-for-byte
    identical to omitting the field.
    """

    id: str
    name: str
    city: Optional[str] = None
    address_full: Optional[str] = None
    maps_url: Optional[str] = None
    window_start: Optional[str] = None
    window_end: Optional[str] = None

    def to_yaml_dict(self) -> Dict[str, Any]:
        """Serialize to a plain dict round-trippable through ``SchedulingConfig.load`` (issue #270).

        ``id`` and ``name`` are always emitted (required by the model).
        Optional fields are skipped when ``None`` to keep the rendered YAML
        clean — ``_location_field`` in :mod:`atendentepro.prompts.scheduling`
        treats omitted and ``None`` as equivalent, so the prompt block is
        identical either way.
        """
        data: Dict[str, Any] = {"id": self.id, "name": self.name}
        for field_name in ("city", "address_full", "maps_url", "window_start", "window_end"):
            value = getattr(self, field_name)
            if value is not None:
                data[field_name] = value
        return data


# ``LocationDict`` is declared via the functional syntax because the
# module uses ``from __future__ import annotations`` (PEP 563). Under
# PEP 563, every class-body annotation is a string at runtime, which
# strips ``NotRequired[...]`` markers and breaks ``__required_keys__``
# detection. The functional form evaluates ``NotRequired`` eagerly.
#
# Structural type documenting the keys ``get_scheduling_prompt`` reads
# (issue #269). External consumers that build ``locations`` as plain
# dicts (instead of Pydantic :class:`Location` instances) get
# autocomplete and type-checking for the contract — typos like
# ``address`` instead of ``address_full`` surface at type-check time
# rather than as a silently-empty prompt field.
#
# At runtime ``LocationDict`` is a plain ``dict``; the lib continues
# to accept both ``Mapping`` and Pydantic-style objects via
# ``_location_field`` in :mod:`atendentepro.prompts.scheduling`.
#
# ``id`` and ``name`` are required by the contract; the other 5 fields
# are optional and behave identically when omitted or set to ``None``
# (issue #268).
LocationDict = TypedDict(
    "LocationDict",
    {
        "id": str,
        "name": str,
        "city": NotRequired[Optional[str]],
        "address_full": NotRequired[Optional[str]],
        "maps_url": NotRequired[Optional[str]],
        "window_start": NotRequired[Optional[str]],
        "window_end": NotRequired[Optional[str]],
    },
)


class SchedulingConfig(BaseModel):
    """Configuration model for Scheduling Agent (issue #133).

    Mirrors :class:`ConfirmationConfig` because both agents follow the same
    about/template/format prompt shape. A missing ``scheduling_config.yaml``
    is **not** an error — the loader returns an empty config and the agent
    falls back to canonical defaults from ``get_scheduling_prompt``.
    """

    about: str = ""
    template: str = ""
    format: str = ""
    # Per-action capability toggles (issue #217). When False, the matching
    # tool is filtered out of the agent's tool set and the prompt is
    # extended with a restrictions block. Defaults preserve pre-#217
    # behavior (all write actions enabled). ``list_available_slots`` is a
    # read-only consultation and is not toggleable.
    allow_create: bool = True
    allow_reschedule: bool = True
    allow_cancel: bool = True
    # Issue #265: declarative list of scheduling locations. When two or
    # more entries are declared, the prompt is extended with a [LOCAIS]
    # block that instructs the agent to list locations and ask the user
    # to pick BEFORE asking type / date / time. Empty list preserves the
    # legacy single-site flow byte-for-byte.
    locations: List[Location] = Field(default_factory=list)

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "SchedulingConfig":
        """Load scheduling configuration from YAML file (returns empty when missing)."""
        if not path.exists():
            return cls()

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys(
            "scheduling_config.yaml", path, data, _SCHEDULING_YAML_ALLOWED_TOP_KEYS
        )

        raw_locations = data.get("locations") or []
        locations = [Location(**entry) for entry in raw_locations]

        return cls(
            about=data.get("about", ""),
            template=data.get("template", ""),
            format=data.get("format", ""),
            allow_create=bool(data.get("allow_create", True)),
            allow_reschedule=bool(data.get("allow_reschedule", True)),
            allow_cancel=bool(data.get("allow_cancel", True)),
            locations=locations,
        )

    def to_yaml_dict(self) -> Dict[str, Any]:
        """Serialize to a plain dict round-trippable through :meth:`load` (issue #270).

        Emits the canonical shape that ``scheduling_config.yaml`` expects so
        external generators (Supabase edge functions, scripts, CMS exporters)
        can dump a ready-to-load YAML using ``yaml.safe_dump`` without
        re-implementing the lib's defaults. Round-trip is guaranteed:
        ``SchedulingConfig.load(path)`` over the dumped YAML produces an
        equal ``SchedulingConfig``.

        Only fields the lib actively consumes are included — ``professionals``
        and ``appointment_types`` are accepted at load time (no warning) but
        not consumed today, so they live outside this helper.
        """
        return {
            "about": self.about,
            "template": self.template,
            "format": self.format,
            "allow_create": self.allow_create,
            "allow_reschedule": self.allow_reschedule,
            "allow_cancel": self.allow_cancel,
            "locations": [loc.to_yaml_dict() for loc in self.locations],
        }


class OnboardingField(BaseModel):
    """Model for an onboarding required field."""

    name: str
    prompt: str
    priority: int = 0


class AgentStyleConfig(BaseModel):
    """Configuration for individual agent style."""

    tone: str = ""
    language_style: str = ""  # formal, informal, neutro
    response_length: str = ""  # conciso, moderado, detalhado
    custom_rules: str = ""


class StyleConfig(BaseModel):
    """Configuration model for agent communication styles.

    Allows customizing tone, language, and response style globally
    or per-agent through YAML configuration.

    Example YAML:
        global:
          tone: "profissional e cordial"
          language_style: "formal"
          response_length: "moderado"

        agents:
          escalation:
            tone: "empático e acolhedor"
            custom_rules: "Demonstre compreensão"
    """

    global_style: AgentStyleConfig = Field(default_factory=AgentStyleConfig)
    agents: Dict[str, AgentStyleConfig] = Field(default_factory=dict)

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "StyleConfig":
        """Load style configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Style config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys("style_config.yaml", path, data, _STYLE_YAML_ALLOWED_TOP_KEYS)

        # Parse global style
        global_data = data.get("global", {})
        global_style = AgentStyleConfig(
            tone=global_data.get("tone", ""),
            language_style=global_data.get("language_style", ""),
            response_length=global_data.get("response_length", ""),
            custom_rules=global_data.get("custom_rules", ""),
        )

        # Parse agent-specific styles
        agents = {}
        for agent_name, agent_data in data.get("agents", {}).items():
            agents[agent_name] = AgentStyleConfig(
                tone=agent_data.get("tone", ""),
                language_style=agent_data.get("language_style", ""),
                response_length=agent_data.get("response_length", ""),
                custom_rules=agent_data.get("custom_rules", ""),
            )

        return cls(global_style=global_style, agents=agents)

    def get_style_for_agent(self, agent_name: str) -> AgentStyleConfig:
        """Get style configuration for a specific agent."""
        # Agent-specific style takes precedence
        if agent_name in self.agents:
            agent_style = self.agents[agent_name]
            # Merge with global (agent-specific overrides global)
            return AgentStyleConfig(
                tone=agent_style.tone or self.global_style.tone,
                language_style=agent_style.language_style or self.global_style.language_style,
                response_length=agent_style.response_length or self.global_style.response_length,
                custom_rules=agent_style.custom_rules or self.global_style.custom_rules,
            )
        # Fall back to global
        return self.global_style


class SingleReplyConfig(BaseModel):
    """Configuration model for single reply mode.

    When single_reply is enabled for an agent, it will respond once
    and automatically transfer back to the Triage agent. This prevents
    conversations from getting stuck in a specific agent.

    Example YAML:
        global: false

        agents:
          knowledge: true
          confirmation: true
          answer: true
    """

    global_enabled: bool = False
    agents: Dict[str, bool] = Field(default_factory=dict)

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "SingleReplyConfig":
        """Load single reply configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Single reply config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys(
            "single_reply_config.yaml", path, data, _SINGLE_REPLY_YAML_ALLOWED_TOP_KEYS
        )

        return cls(
            global_enabled=data.get("global", False),
            agents=data.get("agents", {}),
        )

    def get_single_reply_for_agent(self, agent_name: str) -> bool:
        """Get single_reply setting for a specific agent."""
        # Agent-specific setting takes precedence
        if agent_name in self.agents:
            return self.agents[agent_name]
        # Fall back to global
        return self.global_enabled


# =============================================================================
# ACCESS FILTER CONFIGURATION (Role/User based access control)
# =============================================================================


class AccessFilterConfig(BaseModel):
    """Configuration for a single access filter."""

    allowed_roles: Optional[List[str]] = None
    denied_roles: Optional[List[str]] = None
    allowed_users: Optional[List[str]] = None
    denied_users: Optional[List[str]] = None


class ConditionalPromptConfig(BaseModel):
    """Configuration for a conditional prompt section."""

    content: str = ""
    filter: AccessFilterConfig = Field(default_factory=AccessFilterConfig)


class AccessConfig(BaseModel):
    """
    Configuration model for role/user based access control.

    Allows controlling access to agents, prompts, and tools based on
    user identity or role. Supports both whitelist and blacklist patterns.

    Example YAML:
        # Filter entire agents by role
        agent_filters:
          knowledge:
            allowed_roles: ["admin", "vendedor"]
          escalation:
            denied_roles: ["cliente"]

        # Conditional prompt sections
        conditional_prompts:
          knowledge:
            - content: |
                ## Admin Tools
                You have access to admin features.
              filter:
                allowed_roles: ["admin"]
            - content: |
                ## Sales Tools
                You can offer up to 15% discount.
              filter:
                allowed_roles: ["vendedor"]

        # Tool access control
        tool_access:
          delete_user:
            allowed_roles: ["admin"]
          approve_discount:
            allowed_roles: ["gerente", "admin"]
    """

    agent_filters: Dict[str, AccessFilterConfig] = Field(default_factory=dict)
    conditional_prompts: Dict[str, List[ConditionalPromptConfig]] = Field(default_factory=dict)
    tool_access: Dict[str, AccessFilterConfig] = Field(default_factory=dict)

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "AccessConfig":
        """Load access configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Access config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys("access_config.yaml", path, data, _ACCESS_YAML_ALLOWED_TOP_KEYS)

        # Parse agent filters
        # Use `or {}` to handle YAML keys with null value (empty block with only comments)
        agent_filters = {}
        for agent_name, filter_data in (data.get("agent_filters") or {}).items():
            agent_filters[agent_name] = AccessFilterConfig(
                allowed_roles=filter_data.get("allowed_roles"),
                denied_roles=filter_data.get("denied_roles"),
                allowed_users=filter_data.get("allowed_users"),
                denied_users=filter_data.get("denied_users"),
            )

        # Parse conditional prompts
        conditional_prompts = {}
        for agent_name, prompts_data in (data.get("conditional_prompts") or {}).items():
            prompts_list = []
            for prompt_data in prompts_data:
                filter_data = prompt_data.get("filter", {})
                prompts_list.append(
                    ConditionalPromptConfig(
                        content=prompt_data.get("content", ""),
                        filter=AccessFilterConfig(
                            allowed_roles=filter_data.get("allowed_roles"),
                            denied_roles=filter_data.get("denied_roles"),
                            allowed_users=filter_data.get("allowed_users"),
                            denied_users=filter_data.get("denied_users"),
                        ),
                    )
                )
            conditional_prompts[agent_name] = prompts_list

        # Parse tool access
        tool_access = {}
        for tool_name, filter_data in (data.get("tool_access") or {}).items():
            tool_access[tool_name] = AccessFilterConfig(
                allowed_roles=filter_data.get("allowed_roles"),
                denied_roles=filter_data.get("denied_roles"),
                allowed_users=filter_data.get("allowed_users"),
                denied_users=filter_data.get("denied_users"),
            )

        return cls(
            agent_filters=agent_filters,
            conditional_prompts=conditional_prompts,
            tool_access=tool_access,
        )

    def get_agent_filter(self, agent_name: str) -> Optional[AccessFilterConfig]:
        """Get access filter for a specific agent."""
        return self.agent_filters.get(agent_name)

    def get_conditional_prompts(self, agent_name: str) -> List[ConditionalPromptConfig]:
        """Get conditional prompts for a specific agent."""
        return self.conditional_prompts.get(agent_name, [])

    def get_tool_filter(self, tool_name: str) -> Optional[AccessFilterConfig]:
        """Get access filter for a specific tool."""
        return self.tool_access.get(tool_name)


class FeedbackConfig(BaseModel):
    """Configuration model for Feedback Agent."""

    protocol_prefix: str = "TKT"
    ticket_types: List[Dict[str, Any]] = Field(default_factory=list)
    priorities: List[Dict[str, Any]] = Field(default_factory=list)
    email: Dict[str, Any] = Field(default_factory=dict)
    messages: Dict[str, str] = Field(default_factory=dict)
    auto_priority: Dict[str, Any] = Field(default_factory=dict)
    categories: List[str] = Field(default_factory=list)
    instructions: str = ""

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "FeedbackConfig":
        """Load feedback configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Feedback config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys("feedback_config.yaml", path, data, _FEEDBACK_YAML_ALLOWED_TOP_KEYS)

        return cls(
            protocol_prefix=data.get("protocol_prefix", "TKT"),
            ticket_types=data.get("ticket_types", []),
            priorities=data.get("priorities", []),
            email=data.get("email", {}),
            messages=data.get("messages", {}),
            auto_priority=data.get("auto_priority", {}),
            categories=data.get("categories", []),
            instructions=(data.get("instructions") or "").strip(),
        )

    def get_ticket_type_names(self) -> List[str]:
        """Get list of allowed ticket type names."""
        return [t.get("name", "") for t in self.ticket_types if t.get("name")]


class EscalationConfig(BaseModel):
    """Configuration model for Escalation Agent."""

    triggers: Dict[str, Any] = Field(default_factory=dict)
    channels: Dict[str, Any] = Field(default_factory=dict)
    business_hours: Dict[str, Any] = Field(default_factory=dict)
    priority: Dict[str, Any] = Field(default_factory=dict)
    messages: Dict[str, str] = Field(default_factory=dict)
    notifications: Dict[str, Any] = Field(default_factory=dict)
    instructions: str = ""

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "EscalationConfig":
        """Load escalation configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Escalation config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys(
            "escalation_config.yaml", path, data, _ESCALATION_YAML_ALLOWED_TOP_KEYS
        )

        return cls(
            triggers=data.get("triggers", {}),
            channels=data.get("channels", {}),
            business_hours=data.get("business_hours", {}),
            priority=data.get("priority", {}),
            messages=data.get("messages", {}),
            notifications=data.get("notifications", {}),
            instructions=(data.get("instructions") or "").strip(),
        )

    def get_business_hours_days(self) -> List[int]:
        """Convert YAML day names to weekday numbers (0=Monday, 6=Sunday)."""
        day_map = {
            "monday": 0,
            "tuesday": 1,
            "wednesday": 2,
            "thursday": 3,
            "friday": 4,
            "saturday": 5,
            "sunday": 6,
        }
        days = self.business_hours.get("days", [])
        return [
            day_map[day.lower()] for day in days if isinstance(day, str) and day.lower() in day_map
        ]

    def get_all_triggers(self) -> List[str]:
        """Return every escalation trigger phrase as a flat, deduplicated list.

        The YAML schema groups triggers by reason (``explicit_request``,
        ``frustration``, ``topics_requiring_human``, etc.). For deterministic
        substring checks (issue #58 — guardrail escalation bypass) callers
        only need the flat list.
        """
        flat: List[str] = []
        seen: set[str] = set()
        for value in self.triggers.values():
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, str) and item.strip():
                        normalized = item.strip()
                        key = normalized.lower()
                        if key not in seen:
                            seen.add(key)
                            flat.append(normalized)
        return flat


class AnswerContextDefaults(BaseModel):
    """Structured defaults applied when ``user_context.metadata`` is incomplete.

    Issue #256: clients used to bury "DEFAULTS QUANDO DADOS NAO ESTAO
    DISPONIVEIS" rules as prose in ``answer_config.yaml::instructions``. This
    schema makes those defaults explicit, versionable and testable. The
    library does NOT mutate ``user_context.metadata`` at runtime — defaults
    are rendered as a dedicated top-level section in the Answer prompt so
    the LLM treats them as explicit assumptions.

    Fields:
        values: mapping ``<field_name> -> default_value`` used when the
            corresponding metadata field is absent.
        announce_template: optional one-line message the LLM prepends to the
            response when any default is applied. ``{field}`` placeholders
            are filled by the LLM with the values actually assumed.
    """

    values: Dict[str, Any] = Field(default_factory=dict)
    announce_template: Optional[str] = None


class AnswerConfig(BaseModel):
    """Configuration model for Answer Agent."""

    instructions: str = ""
    response_format: Dict[str, Any] = Field(default_factory=dict)
    # Issue #256: structured defaults rendered into the Answer prompt.
    context_defaults: Optional[AnswerContextDefaults] = None

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "AnswerConfig":
        """Load answer configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Answer config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys("answer_config.yaml", path, data, _ANSWER_YAML_ALLOWED_TOP_KEYS)

        context_defaults: Optional[AnswerContextDefaults] = None
        raw_ctx = data.get("context_defaults")
        if isinstance(raw_ctx, dict):
            values = raw_ctx.get("values") or {}
            announce = raw_ctx.get("announce_template")
            announce_clean = announce.strip() if isinstance(announce, str) else None
            if isinstance(values, dict) and (values or announce_clean):
                context_defaults = AnswerContextDefaults(
                    values=values,
                    announce_template=announce_clean or None,
                )

        return cls(
            instructions=data.get("instructions", ""),
            response_format=data.get("response_format", {}),
            context_defaults=context_defaults,
        )

    def get_answer_template(self) -> str:
        """Get answer template from instructions."""
        return self.instructions


class UsageConfig(BaseModel):
    """Configuration model for Usage Agent."""

    description: str = ""
    contact_channels: List[Dict[str, Any]] = Field(default_factory=list)
    faq: List[Dict[str, str]] = Field(default_factory=list)
    how_to_order: str = ""
    system_context: str = ""
    instructions: str = ""

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "UsageConfig":
        """Load usage configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Usage config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys("usage_config.yaml", path, data, _USAGE_YAML_ALLOWED_TOP_KEYS)

        return cls(
            description=data.get("description", ""),
            contact_channels=data.get("contact_channels", []),
            faq=data.get("faq", []),
            how_to_order=data.get("how_to_order", ""),
            system_context=data.get("system_context", ""),
            instructions=(data.get("instructions") or "").strip(),
        )

    def get_contact_channels_text(self) -> str:
        """Format contact channels as readable text."""
        if not self.contact_channels:
            return ""
        parts = []
        for ch in self.contact_channels:
            name = ch.get("name", "")
            value = ch.get("value", "")
            hours = ch.get("hours", "")
            line = f"- {name}: {value}"
            if hours:
                line += f" ({hours})"
            parts.append(line)
        return "\n".join(parts)

    def get_faq_text(self) -> str:
        """Format FAQ as readable text."""
        if not self.faq:
            return ""
        parts = []
        for item in self.faq:
            q = item.get("question", item.get("q", ""))
            a = item.get("answer", item.get("a", ""))
            if q and a:
                parts.append(f"P: {q}\nR: {a}")
        return "\n\n".join(parts)


class OnboardingConfig(BaseModel):
    """Configuration model for Onboarding Agent."""

    required_fields: List[OnboardingField] = Field(default_factory=list)

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "OnboardingConfig":
        """Load onboarding configuration from YAML file."""
        if not path.exists():
            raise FileNotFoundError(f"Onboarding config not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        _warn_unknown_top_keys(
            "onboarding_config.yaml", path, data, _ONBOARDING_YAML_ALLOWED_TOP_KEYS
        )

        fields = []
        for field_data in data.get("required_fields", []):
            fields.append(
                OnboardingField(
                    name=field_data.get("name", ""),
                    prompt=field_data.get("prompt", ""),
                    priority=field_data.get("priority", 0),
                )
            )

        # Sort by priority
        fields.sort(key=lambda x: x.priority)

        return cls(required_fields=fields)


class ProviderTemplateConfig(BaseModel):
    """Configuration for per-agent provider/model overrides loaded from YAML.

    Example YAML (provider_config.yaml):

        agent_models:
          triage: "gpt-4.1-mini"

        agent_providers:
          interview:
            provider: "gemini"
            model: "gemini-2.5-flash"
            api_key_env: "GEMINI_API_KEY"
    """

    agent_models: Dict[str, str] = Field(default_factory=dict)
    agent_providers: Dict[str, Dict[str, Any]] = Field(default_factory=dict)

    @classmethod
    def load(cls, path: Path) -> "ProviderTemplateConfig":
        """Load provider configuration from YAML file.

        Returns an empty config when ``path`` does not exist (legitimate
        single-provider deployments without per-agent overrides) or when
        the YAML is unparseable. Issue #240: failures now log at WARNING
        level with the file path + exception so silent typos no longer
        masquerade as "no overrides configured".
        """
        if not path.exists():
            return cls()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
        except Exception as exc:
            logger.warning(
                "Failed to load provider_config.yaml at %s — falling back to defaults: %s",
                path,
                exc,
            )
            return cls()

        _warn_unknown_top_keys("provider_config.yaml", path, data, _PROVIDER_YAML_ALLOWED_TOP_KEYS)

        return cls(
            agent_models=data.get("agent_models") or {},
            agent_providers=data.get("agent_providers") or {},
        )

    def to_provider_configs(self) -> Dict[str, Any]:
        """Convert raw dicts to ProviderConfig instances."""
        from atendentepro.config.settings import ProviderConfig

        result: Dict[str, Any] = {}
        for agent_name, raw in self.agent_providers.items():
            api_key = raw.get("api_key")
            api_key_env = raw.get("api_key_env")
            if not api_key and api_key_env:
                api_key = os.environ.get(api_key_env)
            result[agent_name] = ProviderConfig(
                provider=raw["provider"],
                model=raw["model"],
                api_key=api_key,
                base_url=raw.get("base_url"),
            )
        return result


class MultiAgentEntryConfig(BaseModel):
    """Per-agent hierarchy metadata loaded from multiagent_config.yaml.

    Mirrors :class:`atendentepro.multiagent.metadata.AgentMetadata` field
    by field. Pure-Python (this file is intentionally NOT Cython-compiled
    so Pydantic introspection works at runtime).
    """

    exposed_to_user: bool = True
    can_call: List[str] = Field(default_factory=list)
    output_schema: Optional[str] = None
    # Sentinel names for multi-agent built-in tools (e.g. ``["call_agent"]``).
    # Expanded at network-factory time by ``atendentepro.multiagent.tools``.
    # Empty list (default) preserves legacy behaviour.
    builtin_tools: List[str] = Field(default_factory=list)


class MultiAgentConfig(BaseModel):
    """Hierarchy metadata for the multi-agent network.

    Example YAML (``multiagent_config.yaml``)::

        agents:
          valuation_specialist:
            exposed_to_user: false
            can_call: ["risk_specialist"]
            output_schema: client_resources.signals.MySignal

    Defaults preserve byte-for-byte pre-hierarchy behaviour: a missing
    file or empty ``agents`` map yields zero metadata, and downstream
    code skips the new filtering paths.

    Top-level fields ``network_type``, ``fanout``, ``coordinator``,
    ``parallel_timeout_s``, ``parallel_max_concurrency`` and
    ``parallel_partial_ok`` describe the *ensemble* shape (PR2 of the
    multi-agent epic). They default to ``network_type="sequential"`` so
    existing clients are unaffected. When ``network_type="parallel"``,
    callers must use :func:`atendentepro.network.create_parallel_network`
    rather than :func:`atendentepro.network.create_standard_network`.
    """

    # Per-agent hierarchy metadata.
    agents: Dict[str, MultiAgentEntryConfig] = Field(default_factory=dict)

    # Ensemble-shape configuration (PR2 — Task 2.3).
    network_type: Literal["sequential", "parallel"] = "sequential"
    fanout: List[str] = Field(default_factory=list)
    coordinator: Optional[str] = None
    parallel_timeout_s: float = 30.0
    parallel_max_concurrency: int = 10
    parallel_partial_ok: bool = False
    # Optional override for the SDK ``max_turns`` knob; propagated to
    # every fanout + coordinator invoke_agent call. ``None`` keeps the
    # SDK default of 10. Bump for ensembles with strict-schema agents
    # plus multiple tools (closes #190).
    parallel_per_agent_max_turns: Optional[int] = None

    @classmethod
    @_path_normalized_cache(maxsize=4)
    def load(cls, path: Path) -> "MultiAgentConfig":
        """Load multi-agent configuration from YAML.

        Returns an empty :class:`MultiAgentConfig` when the file is
        missing — this is the legacy default. Validation errors raised
        by Pydantic propagate so a malformed YAML fails loudly.

        Parallel-mode consistency (``fanout`` + ``coordinator`` required)
        is enforced automatically by the ``@model_validator`` on the
        class itself, so any direct ``MultiAgentConfig(...)`` call gets
        the same check.
        """
        if not path.exists():
            return cls()

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        agents_raw = data.get("agents") or {}
        agents: Dict[str, MultiAgentEntryConfig] = {}
        for agent_name, agent_data in agents_raw.items():
            if not isinstance(agent_data, dict):
                raise ValueError(
                    f"multiagent_config.yaml: entry for agent {agent_name!r} "
                    f"must be a mapping (got {type(agent_data).__name__})."
                )
            agents[agent_name] = MultiAgentEntryConfig(
                exposed_to_user=agent_data.get("exposed_to_user", True),
                can_call=list(agent_data.get("can_call") or []),
                output_schema=agent_data.get("output_schema"),
                builtin_tools=list(agent_data.get("builtin_tools") or []),
            )

        network_type = data.get("network_type", "sequential")
        if network_type not in ("sequential", "parallel"):
            raise ValueError(
                f"multiagent_config.yaml: network_type must be 'sequential' "
                f"or 'parallel' (got {network_type!r})."
            )

        return cls(
            agents=agents,
            network_type=network_type,
            fanout=list(data.get("fanout") or []),
            coordinator=data.get("coordinator"),
            parallel_timeout_s=float(data.get("parallel_timeout_s", 30.0)),
            parallel_max_concurrency=int(data.get("parallel_max_concurrency", 10)),
            parallel_partial_ok=bool(data.get("parallel_partial_ok", False)),
            parallel_per_agent_max_turns=(
                int(data["parallel_per_agent_max_turns"])
                if data.get("parallel_per_agent_max_turns") is not None
                else None
            ),
        )

    @model_validator(mode="after")
    def _validate_parallel_consistency(self) -> "MultiAgentConfig":
        """Validate that ensemble-shape fields are mutually consistent.

        Raises ``ValueError`` when ``network_type=parallel`` but ``fanout``
        or ``coordinator`` is missing. Sequential networks skip this
        check entirely so legacy templates behave identically.
        """
        if self.network_type != "parallel":
            return self
        problems: List[str] = []
        if not self.fanout:
            problems.append(
                "'fanout' must be a non-empty list of agent names when " "network_type='parallel'"
            )
        if not self.coordinator:
            problems.append("'coordinator' is required when network_type='parallel'")
        if problems:
            raise ValueError(
                "multiagent_config.yaml: invalid parallel network configuration: "
                + "; ".join(problems)
            )
        return self

    def to_metadata_registry(self) -> Dict[str, "AgentMetadata"]:
        """Build a ``{agent_name: AgentMetadata}`` dict.

        Validates ``output_schema`` against the allowlist eagerly — a
        misconfigured prefix raises before the network is built. The
        actual dotted-path resolution to a Pydantic class is deferred
        (Task 1.2 / 2.1 will need it); here we only enforce the
        allowlist so YAML problems surface at load time.
        """
        from atendentepro.multiagent.metadata import (
            AgentMetadata,
            OutputSchemaNotAllowedError,
            check_output_schema_allowed,
        )

        registry: Dict[str, AgentMetadata] = {}
        for agent_name, entry in self.agents.items():
            schema = entry.output_schema
            if schema:
                try:
                    check_output_schema_allowed(schema)
                except OutputSchemaNotAllowedError as exc:
                    raise OutputSchemaNotAllowedError(
                        f"multiagent_config.yaml: agent {agent_name!r} declares "
                        f"output_schema={schema!r} which is outside the allowlist. "
                        "See AgentMetadata docs for the escape hatch."
                    ) from exc
            registry[agent_name] = AgentMetadata(
                exposed_to_user=entry.exposed_to_user,
                can_call=list(entry.can_call),
                output_schema=schema,
                builtin_tools=list(entry.builtin_tools),
            )
        return registry


# Global template manager instance
_template_manager: Optional["TemplateManager"] = None


class TemplateManager:
    """
    Coordinates dynamic client-specific configuration loading.

    The manager handles loading configuration files from external template
    directories and provides access to client-specific settings.
    """

    def __init__(
        self,
        templates_root: Optional[Path] = None,
        default_client: str = "standard",
    ) -> None:
        """
        Initialize the TemplateManager.

        Args:
            templates_root: Root directory for template configurations.
            default_client: Default client key to use.
        """
        self.templates_root = templates_root
        self.default_client = default_client

        self._client_templates: Dict[str, ClientTemplate] = {}
        self._client_aliases: Dict[str, str] = {}
        self._configured_clients: Dict[str, bool] = {}

    def register_client(self, template: ClientTemplate) -> None:
        """Register or update a client template."""
        self._client_templates[template.key] = template
        for alias in template.aliases:
            normalized = alias.strip().lower()
            if normalized:
                self._client_aliases[normalized] = template.key

    def normalize_client_key(self, client: Optional[str]) -> str:
        """Normalize client aliases to a canonical key."""
        if not client:
            return self.default_client
        key = client.strip().lower()
        return self._client_aliases.get(key, key)

    def get_template_folder(self, client: Optional[str] = None) -> Path:
        """Return the Path for the requested client's template directory."""
        if not self.templates_root:
            raise ValueError("templates_root not configured")

        client_key = self.normalize_client_key(client)
        template = self._client_templates.get(client_key)

        if template:
            return self.templates_root / template.template_name

        return self.templates_root / client_key

    def load_flow_config(self, client: Optional[str] = None) -> FlowConfig:
        """Load flow configuration for the specified client."""
        folder = self.get_template_folder(client)
        return FlowConfig.load(folder / "flow_config.yaml")

    def load_interview_config(self, client: Optional[str] = None) -> InterviewConfig:
        """Load interview configuration for the specified client."""
        folder = self.get_template_folder(client)
        return InterviewConfig.load(folder / "interview_config.yaml")

    def load_triage_config(self, client: Optional[str] = None) -> TriageConfig:
        """Load triage configuration for the specified client."""
        folder = self.get_template_folder(client)
        return TriageConfig.load(folder / "triage_config.yaml")

    def load_knowledge_config(self, client: Optional[str] = None) -> KnowledgeConfig:
        """Load knowledge configuration for the specified client."""
        folder = self.get_template_folder(client)
        return KnowledgeConfig.load(folder / "knowledge_config.yaml")

    def load_confirmation_config(self, client: Optional[str] = None) -> ConfirmationConfig:
        """Load confirmation configuration for the specified client."""
        folder = self.get_template_folder(client)
        return ConfirmationConfig.load(folder / "confirmation_config.yaml")

    def load_scheduling_config(self, client: Optional[str] = None) -> SchedulingConfig:
        """Load scheduling configuration for the specified client (#133)."""
        folder = self.get_template_folder(client)
        return SchedulingConfig.load(folder / "scheduling_config.yaml")

    def load_onboarding_config(self, client: Optional[str] = None) -> OnboardingConfig:
        """Load onboarding configuration for the specified client."""
        folder = self.get_template_folder(client)
        return OnboardingConfig.load(folder / "onboarding_config.yaml")

    def load_style_config(self, client: Optional[str] = None) -> StyleConfig:
        """Load style configuration for the specified client."""
        folder = self.get_template_folder(client)
        return StyleConfig.load(folder / "style_config.yaml")

    def load_single_reply_config(self, client: Optional[str] = None) -> SingleReplyConfig:
        """Load single reply configuration for the specified client."""
        folder = self.get_template_folder(client)
        return SingleReplyConfig.load(folder / "single_reply_config.yaml")

    def load_provider_config(self, client: Optional[str] = None) -> ProviderTemplateConfig:
        """Load provider configuration for the specified client."""
        folder = self.get_template_folder(client)
        return ProviderTemplateConfig.load(folder / "provider_config.yaml")

    def load_access_config(self, client: Optional[str] = None) -> AccessConfig:
        """Load access configuration for the specified client."""
        folder = self.get_template_folder(client)
        return AccessConfig.load(folder / "access_config.yaml")

    def load_feedback_config(self, client: Optional[str] = None) -> FeedbackConfig:
        """Load feedback configuration for the specified client."""
        folder = self.get_template_folder(client)
        return FeedbackConfig.load(folder / "feedback_config.yaml")

    def load_escalation_config(self, client: Optional[str] = None) -> EscalationConfig:
        """Load escalation configuration for the specified client."""
        folder = self.get_template_folder(client)
        return EscalationConfig.load(folder / "escalation_config.yaml")

    def load_answer_config(self, client: Optional[str] = None) -> AnswerConfig:
        """Load answer configuration for the specified client."""
        folder = self.get_template_folder(client)
        return AnswerConfig.load(folder / "answer_config.yaml")

    def load_usage_config(self, client: Optional[str] = None) -> UsageConfig:
        """Load usage configuration for the specified client."""
        folder = self.get_template_folder(client)
        return UsageConfig.load(folder / "usage_config.yaml")

    def load_multiagent_config(self, client: Optional[str] = None) -> MultiAgentConfig:
        """Load multi-agent hierarchy configuration for the specified client.

        Returns an empty :class:`MultiAgentConfig` when the file is
        absent so legacy templates without hierarchy metadata keep
        their pre-#147 behaviour.
        """
        folder = self.get_template_folder(client)
        return MultiAgentConfig.load(folder / "multiagent_config.yaml")

    def clear_caches(self) -> None:
        """Clear all configuration caches."""
        FlowConfig.load.cache_clear()
        InterviewConfig.load.cache_clear()
        TriageConfig.load.cache_clear()
        KnowledgeConfig.load.cache_clear()
        ConfirmationConfig.load.cache_clear()
        OnboardingConfig.load.cache_clear()
        StyleConfig.load.cache_clear()
        SingleReplyConfig.load.cache_clear()
        AccessConfig.load.cache_clear()
        FeedbackConfig.load.cache_clear()
        EscalationConfig.load.cache_clear()
        AnswerConfig.load.cache_clear()
        MultiAgentConfig.load.cache_clear()
        SchedulingConfig.load.cache_clear()
        UsageConfig.load.cache_clear()


def get_template_manager() -> TemplateManager:
    """Get the global template manager instance."""
    global _template_manager
    if _template_manager is None:
        _template_manager = TemplateManager()
    return _template_manager


def configure_template_manager(
    templates_root: Path,
    default_client: str = "standard",
) -> TemplateManager:
    """
    Configure the global template manager.

    Args:
        templates_root: Root directory for template configurations.
        default_client: Default client key to use.

    Returns:
        Configured TemplateManager instance.
    """
    global _template_manager
    _template_manager = TemplateManager(
        templates_root=templates_root,
        default_client=default_client,
    )
    return _template_manager


def configure_client(
    client: Optional[str] = None,
    templates_root: Optional[Path] = None,
) -> str:
    """
    Configure the template manager for a specific client.

    Args:
        client: Client key or alias.
        templates_root: Optional templates root to configure.

    Returns:
        Normalized client key.
    """
    manager = get_template_manager()

    if templates_root:
        manager.templates_root = templates_root

    return manager.normalize_client_key(client)


def get_template_folder(client: Optional[str] = None) -> Path:
    """Get the template folder for the specified client."""
    return get_template_manager().get_template_folder(client)


def load_flow_config(client: Optional[str] = None) -> FlowConfig:
    """Load flow configuration for the specified client."""
    return get_template_manager().load_flow_config(client)


def load_interview_config(client: Optional[str] = None) -> InterviewConfig:
    """Load interview configuration for the specified client."""
    return get_template_manager().load_interview_config(client)


def load_triage_config(client: Optional[str] = None) -> TriageConfig:
    """Load triage configuration for the specified client."""
    return get_template_manager().load_triage_config(client)


def load_knowledge_config(client: Optional[str] = None) -> KnowledgeConfig:
    """Load knowledge configuration for the specified client."""
    return get_template_manager().load_knowledge_config(client)


def load_confirmation_config(client: Optional[str] = None) -> ConfirmationConfig:
    """Load confirmation configuration for the specified client."""
    return get_template_manager().load_confirmation_config(client)


def load_scheduling_config(client: Optional[str] = None) -> SchedulingConfig:
    """Load scheduling configuration for the specified client (issue #133)."""
    return get_template_manager().load_scheduling_config(client)


def load_onboarding_config(client: Optional[str] = None) -> OnboardingConfig:
    """Load onboarding configuration for the specified client."""
    return get_template_manager().load_onboarding_config(client)


def load_style_config(client: Optional[str] = None) -> StyleConfig:
    """Load style configuration for the specified client."""
    return get_template_manager().load_style_config(client)


def load_single_reply_config(client: Optional[str] = None) -> SingleReplyConfig:
    """Load single reply configuration for the specified client."""
    return get_template_manager().load_single_reply_config(client)


def load_provider_config(client: Optional[str] = None) -> ProviderTemplateConfig:
    """Load provider configuration for the specified client."""
    return get_template_manager().load_provider_config(client)


def load_access_config(client: Optional[str] = None) -> AccessConfig:
    """Load access configuration for the specified client."""
    return get_template_manager().load_access_config(client)


def load_feedback_config(client: Optional[str] = None) -> FeedbackConfig:
    """Load feedback configuration for the specified client."""
    return get_template_manager().load_feedback_config(client)


def load_escalation_config(client: Optional[str] = None) -> EscalationConfig:
    """Load escalation configuration for the specified client."""
    return get_template_manager().load_escalation_config(client)


def load_answer_config(client: Optional[str] = None) -> AnswerConfig:
    """Load answer configuration for the specified client."""
    return get_template_manager().load_answer_config(client)


def load_usage_config(client: Optional[str] = None) -> UsageConfig:
    """Load usage configuration for the specified client."""
    return get_template_manager().load_usage_config(client)


def load_multiagent_config(client: Optional[str] = None) -> MultiAgentConfig:
    """Load multi-agent hierarchy configuration for the specified client."""
    return get_template_manager().load_multiagent_config(client)
