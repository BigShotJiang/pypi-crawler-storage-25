# -*- coding: utf-8 -*-
"""
AtendentePro - Sistema de Atendimento Inteligente com Múltiplos Agentes IA

Uma biblioteca Python modular para criar sistemas de atendimento automatizado
usando múltiplos agentes de IA especializados.

⚠️ ATIVAÇÃO NECESSÁRIA:

    Esta biblioteca requer um token de licença para funcionar.

    Opção 1 - Ativar programaticamente:

        from atendentepro import activate
        activate("seu-token-de-acesso")

    Opção 2 - Variável de ambiente:

        export ATENDENTEPRO_LICENSE_KEY="seu-token-de-acesso"

Exemplo de uso básico:

    from atendentepro import activate, create_standard_network, configure
    from pathlib import Path

    # 1. Ativar a biblioteca
    activate("seu-token-de-acesso")

    # 2. Configurar a biblioteca (OpenAI, Azure ou custom)
    configure(provider="openai", openai_api_key="sua-chave")
    # Ou: configure(provider="custom", custom_api_key="sk-...", custom_base_url="https://api.deepseek.com/v1", default_model="deepseek-chat")

    # 3. Criar rede de agentes
    network = create_standard_network(
        templates_root=Path("./client_templates"),
        client="standard"
    )

    # 4. Usar o agente de triagem como ponto de entrada
    triage_agent = network.triage

Para obter um token de licença, entre em contato: contato@monkai.com.br
Para mais informações, consulte a documentação.
"""

__version__ = "0.43.0"
__author__ = "BeMonkAI"
__email__ = "contato@monkai.com.br"
__license__ = "Proprietary"

# Agents
from atendentepro.agents import (
    ESCALATION_TOOLS,
    FEEDBACK_TOOLS,
    SCHEDULING_TOOLS,
    AnswerAgent,
    ConfirmationAgent,
    EscalationAgent,
    FarewellAgent,
    FeedbackAgent,
    FlowAgent,
    InterviewAgent,
    KnowledgeAgent,
    OnboardingAgent,
    SchedulingAgent,
    TriageAgent,
    UsageAgent,
    configure_feedback_storage,
    create_answer_agent,
    create_confirmation_agent,
    create_escalation_agent,
    create_farewell_agent,
    create_feedback_agent,
    create_flow_agent,
    create_interview_agent,
    create_knowledge_agent,
    create_onboarding_agent,
    create_scheduling_agent,
    create_triage_agent,
    create_usage_agent,
    go_to_rag,
    make_escalation_tools,
    make_feedback_tools,
    make_go_to_rag,
    set_agent_instructions,
)

# Availability schedule (issue #136)
from atendentepro.availability import DEFAULT_OUT_OF_HOURS_MESSAGE, AvailabilitySchedule

# Configuration
from atendentepro.config import (
    DEFAULT_MODEL,
    KNOWN_PROVIDERS,
    RECOMMENDED_PROMPT_PREFIX,
    AtendenteProConfig,
    AtendentProConfig,
    ProviderConfig,
    configure,
    get_config,
)

# Guardrails
from atendentepro.guardrails import (
    GuardrailManager,
    InputGuardrailDecision,
    LegacyVerdict,
    SpecialistConfig,
    SpecialistGuardrailVerdict,
    apply_thresholds,
    build_specialist_agent,
    classify_intent,
    detect_pii,
    get_guardrails_for_agent,
    get_out_of_scope_message,
    parse_verdict,
    run_input_guardrails,
    run_specialist_guardrail,
    set_guardrails_client,
)

# License (deve ser importado primeiro)
from atendentepro.license import (
    InvalidTokenError,
    LicenseError,
    LicenseExpiredError,
    LicenseInfo,
    LicenseNotActivatedError,
    LicenseTimeoutError,
    activate,
    deactivate,
    get_license_info,
    has_feature,
    is_activated,
    require_activation,
)

# Multi-turn history helper (issue #119)
from atendentepro.memory.runner import end_session, run_with_history

# Models
from atendentepro.models import (  # Access filtering
    AccessFilter,
    AccessFilterResolver,
    ContextNote,
    FilteredPromptSection,
    FilteredTool,
    FlowOutput,
    FlowTopic,
    GuardrailValidationOutput,
    InterviewOutput,
    KnowledgeToolResult,
    UserContext,
)

# Multi-agent hierarchy (issues #147 / #148 / #149) +
# multi-agent ensemble (issues #150 / #151)
from atendentepro.multiagent import (
    AgentMetadata,
    AgentOutputSchemaError,
    AgentSignal,
    BaseNetwork,
    CallAgentForbidden,
    CoordinatorError,
    HasAgentMetadata,
    MultiAgentState,
    OutputSchemaNotAllowedError,
    ParallelFanoutError,
    ParallelNetwork,
    ParallelNetworkConfigError,
    UnknownAgentError,
    build_call_agent_tool,
    check_output_schema_allowed,
    invoke_agent,
    resolve_output_schema,
    signal_subclass,
)

# Network
from atendentepro.network import (
    AgentNetwork,
    AgentStyle,
    HistoryWindow,
    NetworkConfig,
    apply_history_window,
    apply_pre_run_hook,
    create_custom_network,
    create_parallel_network,
    create_standard_network,
)

# Providers
from atendentepro.providers import (
    PROVIDER_CAPABILITIES,
    AdapterClient,
    get_provider_capabilities,
    register_adapter,
    resolve_client_for_provider,
)

# Setup Copilot (para usuários PyPI)
# Setup Copilot (PyPI users)
from atendentepro.setup_copilot import setup

# Templates
from atendentepro.templates import (
    ClientTemplate,
    Location,
    LocationDict,
    ProviderTemplateConfig,
    SchedulingConfig,
    TemplateManager,
    configure_client,
    get_template_folder,
    get_template_manager,
    load_confirmation_config,
    load_flow_config,
    load_interview_config,
    load_knowledge_config,
    load_onboarding_config,
    load_provider_config,
    load_scheduling_config,
    load_triage_config,
)

# Utils
from atendentepro.utils import (  # MonkAI Trace; Application Insights; User Loader; Rate Limiter; Logging
    JSONFormatter,
    RateLimiter,
    RateLimitExceededError,
    TokenBudgetExceededError,
    TokenBudgetLimiter,
    clear_client_cache,
    configure_application_insights,
    configure_logging,
    configure_monkai_trace,
    configure_tracing,
    create_user_loader,
    extract_email_from_messages,
    extract_phone_from_messages,
    extract_user_id_from_messages,
    get_async_client,
    get_monkai_hooks,
    get_provider,
    load_user_from_csv,
    run_with_monkai_tracking,
    run_with_user_context,
    set_monkai_input,
    set_monkai_user,
)

# generate_license_token foi movida para scripts/license_admin.py (uso administrativo interno).
# Nao faz parte da API publica do pacote distribuido.


__all__ = [
    # Version
    "__version__",
    # Setup Copilot
    "setup",
    "__author__",
    # License
    "activate",
    "deactivate",
    "is_activated",
    "get_license_info",
    "require_activation",
    "has_feature",
    "LicenseInfo",
    "LicenseError",
    "LicenseNotActivatedError",
    "LicenseExpiredError",
    "InvalidTokenError",
    "LicenseTimeoutError",
    # Configuration
    "AtendenteProConfig",
    "AtendentProConfig",
    "get_config",
    "configure",
    "RECOMMENDED_PROMPT_PREFIX",
    "DEFAULT_MODEL",
    "KNOWN_PROVIDERS",
    "ProviderConfig",
    # Models
    "ContextNote",
    "FlowTopic",
    "FlowOutput",
    "InterviewOutput",
    "KnowledgeToolResult",
    "GuardrailValidationOutput",
    # Access filtering
    "UserContext",
    "AccessFilter",
    "AccessFilterResolver",
    "FilteredPromptSection",
    "FilteredTool",
    # Agents
    "create_triage_agent",
    "create_flow_agent",
    "create_interview_agent",
    "create_answer_agent",
    "create_knowledge_agent",
    "create_confirmation_agent",
    "create_usage_agent",
    "create_onboarding_agent",
    "create_scheduling_agent",
    "create_escalation_agent",
    "create_farewell_agent",
    "create_feedback_agent",
    "TriageAgent",
    "FlowAgent",
    "InterviewAgent",
    "AnswerAgent",
    "KnowledgeAgent",
    "ConfirmationAgent",
    "UsageAgent",
    "OnboardingAgent",
    "SchedulingAgent",
    "EscalationAgent",
    "FarewellAgent",
    "FeedbackAgent",
    "go_to_rag",
    "make_go_to_rag",
    "ESCALATION_TOOLS",
    "FEEDBACK_TOOLS",
    "SCHEDULING_TOOLS",
    "configure_feedback_storage",
    "make_escalation_tools",
    "make_feedback_tools",
    "set_agent_instructions",
    # Setup Copilot
    "setup",
    # Network
    "AgentNetwork",
    "AgentStyle",
    "NetworkConfig",
    "create_standard_network",
    "create_custom_network",
    "create_parallel_network",
    # History windowing (issue #57)
    "HistoryWindow",
    "apply_history_window",
    # Pre-run hook (issue #195)
    "apply_pre_run_hook",
    # Availability schedule (issue #136)
    "AvailabilitySchedule",
    "DEFAULT_OUT_OF_HOURS_MESSAGE",
    # Multi-turn history helper (issue #119)
    "run_with_history",
    # Session lifecycle (issue #197)
    "end_session",
    # Multi-agent hierarchy (issues #147 / #148 / #149)
    "AgentMetadata",
    "AgentSignal",
    "MultiAgentState",
    "invoke_agent",
    "build_call_agent_tool",
    "CallAgentForbidden",
    "UnknownAgentError",
    "AgentOutputSchemaError",
    "OutputSchemaNotAllowedError",
    "resolve_output_schema",
    "check_output_schema_allowed",
    # Multi-agent ensemble (issues #150 / #151)
    "BaseNetwork",
    "CoordinatorError",
    "HasAgentMetadata",
    "ParallelFanoutError",
    "ParallelNetwork",
    "ParallelNetworkConfigError",
    "signal_subclass",
    # Templates
    "TemplateManager",
    "ClientTemplate",
    "configure_client",
    "get_template_folder",
    "get_template_manager",
    "load_flow_config",
    "load_interview_config",
    "load_triage_config",
    "load_knowledge_config",
    "load_confirmation_config",
    "load_scheduling_config",
    "Location",
    "LocationDict",
    "SchedulingConfig",
    "load_onboarding_config",
    "load_provider_config",
    "ProviderTemplateConfig",
    # Providers
    "AdapterClient",
    "PROVIDER_CAPABILITIES",
    "get_provider_capabilities",
    "register_adapter",
    "resolve_client_for_provider",
    # Guardrails
    "GuardrailManager",
    "get_guardrails_for_agent",
    "get_out_of_scope_message",
    "set_guardrails_client",
    # Standalone preflight guardrail (issue #122)
    "InputGuardrailDecision",
    "run_input_guardrails",
    # Specialist guardrail (opt-in, multi-dimensional verdict)
    "SpecialistGuardrailVerdict",
    "LegacyVerdict",
    "SpecialistConfig",
    "build_specialist_agent",
    "parse_verdict",
    "apply_thresholds",
    "run_specialist_guardrail",
    "detect_pii",
    "classify_intent",
    # Utils
    "get_async_client",
    "get_provider",
    "clear_client_cache",
    "configure_tracing",
    # MonkAI Trace
    "configure_monkai_trace",
    "get_monkai_hooks",
    "set_monkai_user",
    "set_monkai_input",
    "run_with_monkai_tracking",
    # Application Insights
    "configure_application_insights",
    # User Loader
    "create_user_loader",
    "run_with_user_context",
    "extract_phone_from_messages",
    "extract_email_from_messages",
    "extract_user_id_from_messages",
    "load_user_from_csv",
    # Rate Limiter
    "RateLimiter",
    "RateLimitExceededError",
    # Token Budget (issue #180)
    "TokenBudgetLimiter",
    "TokenBudgetExceededError",
    # Logging
    "configure_logging",
    "JSONFormatter",
    "setup",
]
