# Utilities API

Utility functions and helpers.

## Connection Management

### connect()

Establish a connection to the database.

```python
from ferro import connect

# SQLite
await connect("sqlite:example.db?mode=rwc")

# PostgreSQL
await connect("postgresql://user:password@localhost/dbname")

# Auto-migrate during development
await connect("postgresql://localhost/dbname", auto_migrate=True)
```

See [Database Setup Guide](../guide/database.md) for complete connection options.

### disconnect()

This function is not implemented yet.

```python
# Current pattern: connect once during startup
await connect("sqlite:example.db?mode=rwc")
```

### create_tables()

Manually create all registered model tables.

```python
from ferro import create_tables

await create_tables()
```

!!! note
    With `auto_migrate=True`, tables are created automatically on connect.

## Identity Map Management

### evict_instance()

Remove an instance from the identity map, forcing a fresh database fetch on next access.

```python
from ferro import evict_instance

# Evict user with ID=1
evict_instance("User", 1)

# Next fetch will hit database (raises ModelDoesNotExist if row was removed)
user = await User.get(1)
```

If the row may no longer exist, use `User.get_or_none(1)` or handle [`ModelDoesNotExist`](exceptions.md).

See [Identity Map Concept](../concepts/identity-map.md) for when and why to evict instances.

## See Also

- [Database Setup Guide](../guide/database.md) - Connection configuration
- [Identity Map Concept](../concepts/identity-map.md) - Instance caching details
- [Exceptions](exceptions.md) - `ModelDoesNotExist` and related types
- [Schema Management](../guide/migrations.md) - Production migrations
