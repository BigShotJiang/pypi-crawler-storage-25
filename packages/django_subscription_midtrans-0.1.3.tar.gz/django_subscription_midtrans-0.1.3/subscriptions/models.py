import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _


class TimeStampedModel(models.Model):
    """Abstract base model with created/updated timestamps."""

    created_at = models.DateTimeField(_("created at"), auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(_("updated at"), auto_now=True)

    class Meta:
        abstract = True


# ─── Plan ─────────────────────────────────────────────────────────────────────


class Plan(TimeStampedModel):
    """Subscription plan definition."""

    class IntervalUnit(models.TextChoices):
        DAY = "day", _("Day")
        WEEK = "week", _("Week")
        MONTH = "month", _("Month")

    class Status(models.TextChoices):
        ACTIVE = "active", _("Active")
        INACTIVE = "inactive", _("Inactive")
        ARCHIVED = "archived", _("Archived")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(_("plan name"), max_length=255)
    slug = models.SlugField(_("slug"), unique=True)
    description = models.TextField(_("description"), blank=True)
    price = models.DecimalField(_("price"), max_digits=12, decimal_places=2)
    currency = models.CharField(_("currency"), max_length=3, default="IDR")
    interval = models.PositiveIntegerField(_("interval"), default=1, help_text=_("Number of interval units between charges"))
    interval_unit = models.CharField(_("interval unit"), max_length=10, choices=IntervalUnit.choices, default=IntervalUnit.MONTH)
    trial_period_days = models.PositiveIntegerField(_("trial period (days)"), default=0)
    max_cycles = models.PositiveIntegerField(
        _("max billing cycles"),
        default=0,
        help_text=_("0 = unlimited"),
    )
    status = models.CharField(_("status"), max_length=10, choices=Status.choices, default=Status.ACTIVE)
    features = models.JSONField(_("features"), default=dict, blank=True, help_text=_("JSON dict of plan features"))
    metadata = models.JSONField(_("metadata"), default=dict, blank=True)
    sort_order = models.PositiveIntegerField(_("sort order"), default=0)

    class Meta:
        ordering = ["sort_order", "price"]
        verbose_name = _("plan")
        verbose_name_plural = _("plans")

    def __str__(self):
        return f"{self.name} ({self.get_interval_display()})"

    def get_interval_display(self):
        return f"Every {self.interval} {self.get_interval_unit_display().lower()}(s)"


# ─── Subscription ────────────────────────────────────────────────────────────


class Subscription(TimeStampedModel):
    """User subscription tied to a Plan, synced with Midtrans Subscription API."""

    class Status(models.TextChoices):
        PENDING = "pending", _("Pending")
        TRIALING = "trialing", _("Trialing")
        ACTIVE = "active", _("Active")
        PAST_DUE = "past_due", _("Past Due")
        PAUSED = "paused", _("Paused")
        CANCELLED = "cancelled", _("Cancelled")
        EXPIRED = "expired", _("Expired")

    class PaymentType(models.TextChoices):
        CREDIT_CARD = "credit_card", _("Credit Card")
        GOPAY = "gopay", _("GoPay")
        BANK_TRANSFER = "bank_transfer", _("Bank Transfer")
        ECHANNEL = "echannel", _("Mandiri Bill")
        QRIS = "qris", _("QRIS")
        SHOPEEPAY = "shopeepay", _("ShopeePay")
        WALLET = "wallet", _("Wallet Balance")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="subscriptions",
        verbose_name=_("user"),
    )
    plan = models.ForeignKey(
        Plan,
        on_delete=models.PROTECT,
        related_name="subscriptions",
        verbose_name=_("plan"),
    )
    status = models.CharField(_("status"), max_length=20, choices=Status.choices, default=Status.PENDING)
    payment_type = models.CharField(_("payment type"), max_length=20, choices=PaymentType.choices)

    # Midtrans subscription ID (from /v1/subscriptions response)
    midtrans_subscription_id = models.CharField(
        _("Midtrans subscription ID"), max_length=255, blank=True, db_index=True
    )
    # Midtrans token for card payments or GoPay account_id
    midtrans_token = models.CharField(_("Midtrans token"), max_length=500, blank=True)

    # Schedule
    current_period_start = models.DateTimeField(_("current period start"), null=True, blank=True)
    current_period_end = models.DateTimeField(_("current period end"), null=True, blank=True)
    trial_end = models.DateTimeField(_("trial end"), null=True, blank=True)

    # Billing
    billing_cycle_count = models.PositiveIntegerField(_("billing cycles completed"), default=0)
    next_billing_date = models.DateTimeField(_("next billing date"), null=True, blank=True)

    # Cancellation
    cancel_at_period_end = models.BooleanField(_("cancel at period end"), default=False)
    cancelled_at = models.DateTimeField(_("cancelled at"), null=True, blank=True)
    cancellation_reason = models.TextField(_("cancellation reason"), blank=True)

    # Customer details for Midtrans
    customer_first_name = models.CharField(_("first name"), max_length=100, blank=True)
    customer_last_name = models.CharField(_("last name"), max_length=100, blank=True)
    customer_email = models.EmailField(_("email"), blank=True)
    customer_phone = models.CharField(_("phone"), max_length=20, blank=True)

    metadata = models.JSONField(_("metadata"), default=dict, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = _("subscription")
        verbose_name_plural = _("subscriptions")
        indexes = [
            models.Index(fields=["user", "status"]),
            models.Index(fields=["status", "next_billing_date"]),
            models.Index(fields=["midtrans_subscription_id"]),
        ]

    def __str__(self):
        return f"{self.user} - {self.plan.name} ({self.get_status_display()})"

    @property
    def is_active(self):
        return self.status in (self.Status.ACTIVE, self.Status.TRIALING)

    @property
    def is_in_grace_period(self):
        if self.status != self.Status.PAST_DUE:
            return False
        grace_days = getattr(settings, "SUBSCRIPTION_SETTINGS", {}).get("GRACE_PERIOD_DAYS", 3)
        if self.current_period_end:
            grace_end = self.current_period_end + timezone.timedelta(days=grace_days)
            return timezone.now() <= grace_end
        return False

    @property
    def has_access(self):
        return self.is_active or self.is_in_grace_period


# ─── Payment ─────────────────────────────────────────────────────────────────


class Payment(TimeStampedModel):
    """Individual payment transaction, tracked via Midtrans Core API."""

    class Status(models.TextChoices):
        PENDING = "pending", _("Pending")
        CAPTURE = "capture", _("Captured")
        SETTLEMENT = "settlement", _("Settlement")
        DENY = "deny", _("Denied")
        CANCEL = "cancel", _("Cancelled")
        EXPIRE = "expire", _("Expired")
        REFUND = "refund", _("Refunded")
        PARTIAL_REFUND = "partial_refund", _("Partially Refunded")
        AUTHORIZE = "authorize", _("Authorized")
        FAILURE = "failure", _("Failed")

    class PaymentType(models.TextChoices):
        CREDIT_CARD = "credit_card", _("Credit Card")
        GOPAY = "gopay", _("GoPay")
        BANK_TRANSFER = "bank_transfer", _("Bank Transfer")
        ECHANNEL = "echannel", _("Mandiri Bill")
        QRIS = "qris", _("QRIS")
        SHOPEEPAY = "shopeepay", _("ShopeePay")
        OVO = "ovo", _("OVO")
        CSTORE = "cstore", _("Convenience Store")
        WALLET = "wallet", _("Wallet Balance")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    subscription = models.ForeignKey(
        Subscription,
        on_delete=models.CASCADE,
        related_name="payments",
        verbose_name=_("subscription"),
        null=True,
        blank=True,
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="payments",
        verbose_name=_("user"),
    )

    # Midtrans fields
    order_id = models.CharField(_("order ID"), max_length=255, unique=True, db_index=True)
    midtrans_transaction_id = models.CharField(_("Midtrans transaction ID"), max_length=255, blank=True, db_index=True)
    payment_type = models.CharField(_("payment type"), max_length=30, choices=PaymentType.choices)
    status = models.CharField(_("status"), max_length=20, choices=Status.choices, default=Status.PENDING)
    fraud_status = models.CharField(_("fraud status"), max_length=20, blank=True)

    # Amounts
    gross_amount = models.DecimalField(_("gross amount"), max_digits=12, decimal_places=2)
    currency = models.CharField(_("currency"), max_length=3, default="IDR")
    refund_amount = models.DecimalField(_("refund amount"), max_digits=12, decimal_places=2, default=0)

    # Payment details (VA numbers, QR codes, redirect URLs etc.)
    payment_details = models.JSONField(_("payment details"), default=dict, blank=True)

    # Timestamps from Midtrans
    transaction_time = models.DateTimeField(_("transaction time"), null=True, blank=True)
    settlement_time = models.DateTimeField(_("settlement time"), null=True, blank=True)
    expiry_time = models.DateTimeField(_("expiry time"), null=True, blank=True)

    # Midtrans raw response
    midtrans_response = models.JSONField(_("Midtrans response"), default=dict, blank=True)
    metadata = models.JSONField(_("metadata"), default=dict, blank=True)

    # retry tracking
    is_retry = models.BooleanField(_("is retry"), default=False)
    retry_count = models.PositiveIntegerField(_("retry count"), default=0)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = _("payment")
        verbose_name_plural = _("payments")
        indexes = [
            models.Index(fields=["order_id"]),
            models.Index(fields=["midtrans_transaction_id"]),
            models.Index(fields=["user", "status"]),
            models.Index(fields=["status", "created_at"]),
        ]

    def __str__(self):
        return f"{self.order_id} - {self.get_status_display()} ({self.gross_amount} {self.currency})"

    @property
    def is_successful(self):
        return self.status in (self.Status.SETTLEMENT, self.Status.CAPTURE)

    @property
    def is_paid(self):
        if self.status == self.Status.SETTLEMENT:
            return True
        if self.status == self.Status.CAPTURE and self.fraud_status == "accept":
            return True
        return False


# ─── Invoice ─────────────────────────────────────────────────────────────────


class Invoice(TimeStampedModel):
    """Invoice generated for each billing cycle."""

    class Status(models.TextChoices):
        DRAFT = "draft", _("Draft")
        ISSUED = "issued", _("Issued")
        PAID = "paid", _("Paid")
        VOID = "void", _("Void")
        OVERDUE = "overdue", _("Overdue")
        REFUNDED = "refunded", _("Refunded")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    invoice_number = models.CharField(_("invoice number"), max_length=50, unique=True, db_index=True)
    subscription = models.ForeignKey(
        Subscription,
        on_delete=models.CASCADE,
        related_name="invoices",
        verbose_name=_("subscription"),
    )
    payment = models.OneToOneField(
        Payment,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="invoice",
        verbose_name=_("payment"),
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="invoices",
        verbose_name=_("user"),
    )

    # Invoice details
    status = models.CharField(_("status"), max_length=10, choices=Status.choices, default=Status.DRAFT)
    subtotal = models.DecimalField(_("subtotal"), max_digits=12, decimal_places=2)
    tax_amount = models.DecimalField(_("tax amount"), max_digits=12, decimal_places=2, default=0)
    discount_amount = models.DecimalField(_("discount amount"), max_digits=12, decimal_places=2, default=0)
    total_amount = models.DecimalField(_("total amount"), max_digits=12, decimal_places=2)
    currency = models.CharField(_("currency"), max_length=3, default="IDR")

    # Dates
    issue_date = models.DateField(_("issue date"), default=timezone.now)
    due_date = models.DateField(_("due date"))
    paid_date = models.DateField(_("paid date"), null=True, blank=True)

    # Billing period
    period_start = models.DateTimeField(_("period start"))
    period_end = models.DateTimeField(_("period end"))

    # Notes
    notes = models.TextField(_("notes"), blank=True)
    void_reason = models.TextField(_("void reason"), blank=True)

    metadata = models.JSONField(_("metadata"), default=dict, blank=True)

    class Meta:
        ordering = ["-issue_date", "-created_at"]
        verbose_name = _("invoice")
        verbose_name_plural = _("invoices")
        indexes = [
            models.Index(fields=["invoice_number"]),
            models.Index(fields=["user", "status"]),
            models.Index(fields=["status", "due_date"]),
        ]

    def __str__(self):
        return f"{self.invoice_number} - {self.get_status_display()} ({self.total_amount} {self.currency})"


class InvoiceItem(TimeStampedModel):
    """Line item on an invoice."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name="items", verbose_name=_("invoice"))
    description = models.CharField(_("description"), max_length=500)
    quantity = models.PositiveIntegerField(_("quantity"), default=1)
    unit_price = models.DecimalField(_("unit price"), max_digits=12, decimal_places=2)
    total_price = models.DecimalField(_("total price"), max_digits=12, decimal_places=2)
    metadata = models.JSONField(_("metadata"), default=dict, blank=True)

    class Meta:
        ordering = ["created_at"]
        verbose_name = _("invoice item")
        verbose_name_plural = _("invoice items")

    def __str__(self):
        return f"{self.description} x{self.quantity}"

    def save(self, *args, **kwargs):
        self.total_price = self.quantity * self.unit_price
        super().save(*args, **kwargs)


# ─── Webhook / Notification Logs ──────────────────────────────────────────────


class WebhookLog(TimeStampedModel):
    """Log of every incoming Midtrans webhook/notification."""

    class Status(models.TextChoices):
        RECEIVED = "received", _("Received")
        PROCESSED = "processed", _("Processed")
        FAILED = "failed", _("Failed")
        INVALID = "invalid", _("Invalid Signature")
        DUPLICATE = "duplicate", _("Duplicate")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order_id = models.CharField(_("order ID"), max_length=255, db_index=True)
    midtrans_transaction_id = models.CharField(_("Midtrans transaction ID"), max_length=255, blank=True)
    transaction_status = models.CharField(_("transaction status"), max_length=30, blank=True)
    payment_type = models.CharField(_("payment type"), max_length=30, blank=True)
    fraud_status = models.CharField(_("fraud status"), max_length=20, blank=True)
    gross_amount = models.CharField(_("gross amount"), max_length=30, blank=True)
    signature_key = models.TextField(_("signature key"), blank=True)
    status = models.CharField(_("processing status"), max_length=20, choices=Status.choices, default=Status.RECEIVED)
    raw_payload = models.JSONField(_("raw payload"), default=dict)
    error_message = models.TextField(_("error message"), blank=True)
    ip_address = models.GenericIPAddressField(_("IP address"), null=True, blank=True)
    processed_at = models.DateTimeField(_("processed at"), null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = _("webhook log")
        verbose_name_plural = _("webhook logs")
        indexes = [
            models.Index(fields=["order_id", "transaction_status"]),
        ]

    def __str__(self):
        return f"{self.order_id} - {self.transaction_status} ({self.get_status_display()})"


# ─── Notification Log ─────────────────────────────────────────────────────────


class NotificationLog(TimeStampedModel):
    """Log of outgoing notifications (email, etc.) sent to users."""

    class NotificationType(models.TextChoices):
        PAYMENT_SUCCESS = "payment_success", _("Payment Success")
        PAYMENT_FAILED = "payment_failed", _("Payment Failed")
        PAYMENT_PENDING = "payment_pending", _("Payment Pending")
        SUBSCRIPTION_CREATED = "subscription_created", _("Subscription Created")
        SUBSCRIPTION_ACTIVATED = "subscription_activated", _("Subscription Activated")
        SUBSCRIPTION_CANCELLED = "subscription_cancelled", _("Subscription Cancelled")
        SUBSCRIPTION_EXPIRED = "subscription_expired", _("Subscription Expired")
        SUBSCRIPTION_RENEWED = "subscription_renewed", _("Subscription Renewed")
        SUBSCRIPTION_PAUSED = "subscription_paused", _("Subscription Paused")
        SUBSCRIPTION_RESUMED = "subscription_resumed", _("Subscription Resumed")
        INVOICE_ISSUED = "invoice_issued", _("Invoice Issued")
        INVOICE_PAID = "invoice_paid", _("Invoice Paid")
        INVOICE_OVERDUE = "invoice_overdue", _("Invoice Overdue")
        EXPIRY_REMINDER = "expiry_reminder", _("Expiry Reminder")
        PAYMENT_RETRY = "payment_retry", _("Payment Retry")
        REFUND_PROCESSED = "refund_processed", _("Refund Processed")

    class Channel(models.TextChoices):
        EMAIL = "email", _("Email")
        WEBHOOK = "webhook", _("Webhook")
        IN_APP = "in_app", _("In-App")

    class Status(models.TextChoices):
        QUEUED = "queued", _("Queued")
        SENT = "sent", _("Sent")
        FAILED = "failed", _("Failed")
        SKIPPED = "skipped", _("Skipped")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="notification_logs",
        verbose_name=_("user"),
    )
    subscription = models.ForeignKey(
        Subscription,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="notification_logs",
        verbose_name=_("subscription"),
    )
    payment = models.ForeignKey(
        Payment,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="notification_logs",
        verbose_name=_("payment"),
    )

    notification_type = models.CharField(_("type"), max_length=30, choices=NotificationType.choices)
    channel = models.CharField(_("channel"), max_length=10, choices=Channel.choices, default=Channel.EMAIL)
    status = models.CharField(_("status"), max_length=10, choices=Status.choices, default=Status.QUEUED)
    subject = models.CharField(_("subject"), max_length=500, blank=True)
    body = models.TextField(_("body"), blank=True)
    recipient = models.CharField(_("recipient"), max_length=255, blank=True)
    error_message = models.TextField(_("error message"), blank=True)
    sent_at = models.DateTimeField(_("sent at"), null=True, blank=True)
    metadata = models.JSONField(_("metadata"), default=dict, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = _("notification log")
        verbose_name_plural = _("notification logs")
        indexes = [
            models.Index(fields=["user", "notification_type"]),
            models.Index(fields=["status", "created_at"]),
        ]

    def __str__(self):
        return f"{self.get_notification_type_display()} → {self.recipient} ({self.get_status_display()})"


# ─── Wallet ──────────────────────────────────────────────────────────────────


class Wallet(TimeStampedModel):
    """User wallet for storing balance used to pay subscriptions."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="wallet",
        verbose_name=_("user"),
    )
    balance = models.DecimalField(
        _("balance"), max_digits=15, decimal_places=2, default=0,
        help_text=_("Current wallet balance"),
    )
    currency = models.CharField(_("currency"), max_length=3, default="IDR")
    is_active = models.BooleanField(_("is active"), default=True)
    metadata = models.JSONField(_("metadata"), default=dict, blank=True)

    class Meta:
        verbose_name = _("wallet")
        verbose_name_plural = _("wallets")

    def __str__(self):
        return f"{self.user} - {self.currency} {self.balance:,.0f}"

    @property
    def has_sufficient_balance(self):
        return self.balance > 0

    def can_afford(self, amount):
        return self.is_active and self.balance >= amount


class WalletTransaction(TimeStampedModel):
    """Record of every wallet balance change (top-up, debit, refund, adjustment)."""

    class TransactionType(models.TextChoices):
        TOP_UP = "top_up", _("Top Up")
        SUBSCRIPTION_PAYMENT = "subscription_payment", _("Subscription Payment")
        REFUND = "refund", _("Refund")
        ADJUSTMENT = "adjustment", _("Adjustment")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    wallet = models.ForeignKey(
        Wallet,
        on_delete=models.CASCADE,
        related_name="transactions",
        verbose_name=_("wallet"),
    )
    transaction_type = models.CharField(
        _("transaction type"), max_length=30, choices=TransactionType.choices
    )
    amount = models.DecimalField(
        _("amount"), max_digits=15, decimal_places=2,
        help_text=_("Positive = credit, negative = debit"),
    )
    balance_before = models.DecimalField(_("balance before"), max_digits=15, decimal_places=2)
    balance_after = models.DecimalField(_("balance after"), max_digits=15, decimal_places=2)
    reference_type = models.CharField(
        _("reference type"), max_length=50, blank=True,
        help_text=_("Type of related object: topup, subscription, payment"),
    )
    reference_id = models.CharField(
        _("reference ID"), max_length=255, blank=True,
        help_text=_("UUID of the related object"),
    )
    description = models.CharField(_("description"), max_length=500)
    metadata = models.JSONField(_("metadata"), default=dict, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = _("wallet transaction")
        verbose_name_plural = _("wallet transactions")
        indexes = [
            models.Index(fields=["wallet", "-created_at"]),
            models.Index(fields=["transaction_type"]),
            models.Index(fields=["reference_type", "reference_id"]),
        ]

    def __str__(self):
        sign = "+" if self.amount >= 0 else ""
        return f"{sign}{self.amount:,.0f} ({self.get_transaction_type_display()}) - {self.description}"


class TopUp(TimeStampedModel):
    """Top-up request linked to a Midtrans payment for crediting wallet."""

    class Status(models.TextChoices):
        PENDING = "pending", _("Pending")
        SUCCESS = "success", _("Success")
        FAILED = "failed", _("Failed")
        EXPIRED = "expired", _("Expired")

    class PaymentType(models.TextChoices):
        CREDIT_CARD = "credit_card", _("Credit Card")
        GOPAY = "gopay", _("GoPay")
        BANK_TRANSFER = "bank_transfer", _("Bank Transfer")
        ECHANNEL = "echannel", _("Mandiri Bill")
        QRIS = "qris", _("QRIS")
        SHOPEEPAY = "shopeepay", _("ShopeePay")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    wallet = models.ForeignKey(
        Wallet,
        on_delete=models.CASCADE,
        related_name="topups",
        verbose_name=_("wallet"),
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="topups",
        verbose_name=_("user"),
    )
    amount = models.DecimalField(_("amount"), max_digits=15, decimal_places=2)
    payment_type = models.CharField(_("payment type"), max_length=20, choices=PaymentType.choices)
    status = models.CharField(
        _("status"), max_length=20, choices=Status.choices, default=Status.PENDING
    )
    order_id = models.CharField(_("order ID"), max_length=255, unique=True, db_index=True)
    midtrans_transaction_id = models.CharField(
        _("Midtrans transaction ID"), max_length=255, blank=True, db_index=True
    )
    payment_details = models.JSONField(_("payment details"), default=dict, blank=True)
    midtrans_response = models.JSONField(_("Midtrans response"), default=dict, blank=True)
    metadata = models.JSONField(_("metadata"), default=dict, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = _("top up")
        verbose_name_plural = _("top ups")
        indexes = [
            models.Index(fields=["order_id"]),
            models.Index(fields=["user", "status"]),
            models.Index(fields=["status", "created_at"]),
        ]

    def __str__(self):
        return f"{self.order_id} - {self.amount:,.0f} ({self.get_status_display()})"
