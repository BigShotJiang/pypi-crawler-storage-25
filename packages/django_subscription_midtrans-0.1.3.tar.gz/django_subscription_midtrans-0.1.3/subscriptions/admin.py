"""
Django Admin configuration with Django Unfold integration.

Provides rich admin interface for managing:
- Plans, Subscriptions, Payments, Invoices
- Webhook Logs, Notification Logs
- Custom actions, filters, and display decorators
"""
from decimal import Decimal

from django.contrib import admin
from django.db.models import Count, QuerySet, Sum
from django.http import HttpRequest
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from unfold.admin import ModelAdmin, TabularInline, StackedInline
from unfold.contrib.filters.admin import (
    ChoicesDropdownFilter,
    RangeDateFilter,
    RangeDateTimeFilter,
)
from unfold.decorators import action, display
from unfold.enums import ActionVariant

from .models import (
    Invoice,
    InvoiceItem,
    NotificationLog,
    Payment,
    Plan,
    Subscription,
    TopUp,
    Wallet,
    WalletTransaction,
    WebhookLog,
)
from .services import SubscriptionService


# ─── Inlines ──────────────────────────────────────────────────────────────────


class InvoiceItemInline(TabularInline):
    model = InvoiceItem
    extra = 0
    fields = ["description", "quantity", "unit_price", "total_price"]
    readonly_fields = ["total_price"]


class PaymentInline(TabularInline):
    model = Payment
    extra = 0
    fields = ["order_id", "payment_type", "status", "gross_amount", "created_at"]
    readonly_fields = ["order_id", "payment_type", "status", "gross_amount", "created_at"]
    show_change_link = True
    max_num = 0  # No adding from inline


class InvoiceInline(TabularInline):
    model = Invoice
    extra = 0
    fields = ["invoice_number", "status", "total_amount", "issue_date", "due_date"]
    readonly_fields = ["invoice_number", "status", "total_amount", "issue_date", "due_date"]
    show_change_link = True
    max_num = 0


class SubscriptionInline(TabularInline):
    model = Subscription
    extra = 0
    fields = ["plan", "status", "payment_type", "current_period_end", "created_at"]
    readonly_fields = ["plan", "status", "payment_type", "current_period_end", "created_at"]
    show_change_link = True
    max_num = 0


# ─── Plan Admin ───────────────────────────────────────────────────────────────


@admin.register(Plan)
class PlanAdmin(ModelAdmin):
    list_display = [
        "name", "display_price", "display_interval", "display_status",
        "display_subscribers", "trial_period_days", "sort_order",
    ]
    list_filter = [
        ("status", ChoicesDropdownFilter),
        ("interval_unit", ChoicesDropdownFilter),
        ("created_at", RangeDateFilter),
    ]
    list_filter_submit = True
    search_fields = ["name", "slug", "description"]
    prepopulated_fields = {"slug": ("name",)}
    readonly_fields = ["id", "created_at", "updated_at"]
    ordering = ["sort_order", "price"]

    fieldsets = (
        (None, {
            "fields": ("name", "slug", "description", "status", "sort_order"),
        }),
        (_("Pricing"), {
            "fields": ("price", "currency"),
        }),
        (_("Billing Schedule"), {
            "fields": ("interval", "interval_unit", "trial_period_days", "max_cycles"),
        }),
        (_("Features & Metadata"), {
            "fields": ("features", "metadata"),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "created_at", "updated_at"),
            "classes": ("collapse",),
        }),
    )

    actions_list = ["activate_plans", "deactivate_plans"]

    @display(description=_("Price"), ordering="price")
    def display_price(self, obj):
        return f"{obj.currency} {obj.price:,.0f}"

    @display(description=_("Interval"))
    def display_interval(self, obj):
        return obj.get_interval_display()

    @display(
        description=_("Status"),
        ordering="status",
        label={
            Plan.Status.ACTIVE: "success",
            Plan.Status.INACTIVE: "warning",
            Plan.Status.ARCHIVED: "danger",
        },
    )
    def display_status(self, obj):
        return obj.status

    @display(description=_("Subscribers"))
    def display_subscribers(self, obj):
        return obj.subscriptions.filter(
            status__in=[Subscription.Status.ACTIVE, Subscription.Status.TRIALING]
        ).count()

    @action(description=_("Activate selected plans"), icon="check_circle", variant=ActionVariant.SUCCESS)
    def activate_plans(self, request: HttpRequest, queryset: QuerySet):
        queryset.update(status=Plan.Status.ACTIVE)

    @action(description=_("Deactivate selected plans"), icon="block", variant=ActionVariant.WARNING)
    def deactivate_plans(self, request: HttpRequest, queryset: QuerySet):
        queryset.update(status=Plan.Status.INACTIVE)


# ─── Subscription Admin ──────────────────────────────────────────────────────


@admin.register(Subscription)
class SubscriptionAdmin(ModelAdmin):
    list_display = [
        "user", "display_plan", "display_status", "display_payment_type",
        "display_period", "billing_cycle_count", "display_next_billing",
    ]
    list_filter = [
        ("status", ChoicesDropdownFilter),
        ("payment_type", ChoicesDropdownFilter),
        ("plan", admin.RelatedOnlyFieldListFilter),
        ("created_at", RangeDateFilter),
    ]
    list_filter_submit = True
    search_fields = [
        "user__username", "user__email", "customer_email",
        "midtrans_subscription_id", "plan__name",
    ]
    readonly_fields = [
        "id", "midtrans_subscription_id", "billing_cycle_count",
        "created_at", "updated_at",
    ]
    raw_id_fields = ["user"]
    ordering = ["-created_at"]

    inlines = [PaymentInline, InvoiceInline]

    fieldsets = (
        (None, {
            "fields": ("user", "plan", "status", "payment_type"),
        }),
        (_("Midtrans"), {
            "fields": ("midtrans_subscription_id", "midtrans_token"),
        }),
        (_("Schedule"), {
            "fields": (
                "current_period_start", "current_period_end",
                "trial_end", "next_billing_date", "billing_cycle_count",
            ),
        }),
        (_("Customer Details"), {
            "fields": (
                "customer_first_name", "customer_last_name",
                "customer_email", "customer_phone",
            ),
        }),
        (_("Cancellation"), {
            "fields": ("cancel_at_period_end", "cancelled_at", "cancellation_reason"),
            "classes": ("collapse",),
        }),
        (_("Metadata"), {
            "fields": ("metadata",),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "created_at", "updated_at"),
            "classes": ("collapse",),
        }),
    )

    actions_list = ["sync_from_midtrans"]
    actions_row = ["admin_pause_subscription", "admin_resume_subscription", "admin_cancel_subscription"]
    actions_detail = ["admin_pause_subscription_detail", "admin_cancel_subscription_detail", "admin_sync_detail"]

    @display(description=_("Plan"), ordering="plan__name")
    def display_plan(self, obj):
        return obj.plan.name

    @display(
        description=_("Status"),
        ordering="status",
        label={
            Subscription.Status.ACTIVE: "success",
            Subscription.Status.TRIALING: "info",
            Subscription.Status.PENDING: "warning",
            Subscription.Status.PAST_DUE: "danger",
            Subscription.Status.PAUSED: "warning",
            Subscription.Status.CANCELLED: "danger",
            Subscription.Status.EXPIRED: "danger",
        },
    )
    def display_status(self, obj):
        return obj.status

    @display(description=_("Payment"))
    def display_payment_type(self, obj):
        return obj.get_payment_type_display()

    @display(description=_("Period"))
    def display_period(self, obj):
        if obj.current_period_start and obj.current_period_end:
            return f"{obj.current_period_start.strftime('%Y-%m-%d')} → {obj.current_period_end.strftime('%Y-%m-%d')}"
        return "-"

    @display(description=_("Next Billing"))
    def display_next_billing(self, obj):
        if obj.next_billing_date:
            days = (obj.next_billing_date - timezone.now()).days
            return f"{obj.next_billing_date.strftime('%Y-%m-%d')} ({days}d)"
        return "-"

    @action(description=_("Sync from Midtrans"), icon="sync", variant=ActionVariant.PRIMARY)
    def sync_from_midtrans(self, request: HttpRequest, queryset: QuerySet):
        service = SubscriptionService()
        for sub in queryset.filter(midtrans_subscription_id__gt=""):
            service.sync_subscription_status(sub)

    @action(description=_("Pause"), icon="pause")
    def admin_pause_subscription(self, request: HttpRequest, object_id):
        sub = Subscription.objects.get(pk=object_id)
        SubscriptionService().pause_subscription(sub)
        return redirect(reverse_lazy("admin:subscriptions_subscription_changelist"))

    @action(description=_("Resume"), icon="play_arrow", variant=ActionVariant.SUCCESS)
    def admin_resume_subscription(self, request: HttpRequest, object_id):
        sub = Subscription.objects.get(pk=object_id)
        SubscriptionService().resume_subscription(sub)
        return redirect(reverse_lazy("admin:subscriptions_subscription_changelist"))

    @action(description=_("Cancel"), icon="cancel", variant=ActionVariant.DANGER)
    def admin_cancel_subscription(self, request: HttpRequest, object_id):
        sub = Subscription.objects.get(pk=object_id)
        SubscriptionService().cancel_subscription(sub, reason="Admin action", immediate=True)
        return redirect(reverse_lazy("admin:subscriptions_subscription_changelist"))

    @action(description=_("Pause Subscription"), icon="pause", variant=ActionVariant.WARNING)
    def admin_pause_subscription_detail(self, request: HttpRequest, object_id):
        sub = Subscription.objects.get(pk=object_id)
        SubscriptionService().pause_subscription(sub)
        return redirect(reverse_lazy("admin:subscriptions_subscription_change", args=[object_id]))

    @action(description=_("Cancel Subscription"), icon="cancel", variant=ActionVariant.DANGER)
    def admin_cancel_subscription_detail(self, request: HttpRequest, object_id):
        sub = Subscription.objects.get(pk=object_id)
        SubscriptionService().cancel_subscription(sub, reason="Admin action", immediate=True)
        return redirect(reverse_lazy("admin:subscriptions_subscription_change", args=[object_id]))

    @action(description=_("Sync from Midtrans"), icon="sync", variant=ActionVariant.PRIMARY)
    def admin_sync_detail(self, request: HttpRequest, object_id):
        sub = Subscription.objects.get(pk=object_id)
        SubscriptionService().sync_subscription_status(sub)
        return redirect(reverse_lazy("admin:subscriptions_subscription_change", args=[object_id]))


# ─── Payment Admin ────────────────────────────────────────────────────────────


@admin.register(Payment)
class PaymentAdmin(ModelAdmin):
    list_display = [
        "order_id", "user", "display_payment_type", "display_status",
        "display_amount", "display_fraud_status", "created_at",
    ]
    list_filter = [
        ("status", ChoicesDropdownFilter),
        ("payment_type", ChoicesDropdownFilter),
        ("fraud_status", ChoicesDropdownFilter),
        ("created_at", RangeDateFilter),
    ]
    list_filter_submit = True
    search_fields = ["order_id", "midtrans_transaction_id", "user__username", "user__email"]
    readonly_fields = [
        "id", "order_id", "midtrans_transaction_id", "midtrans_response",
        "payment_details", "created_at", "updated_at",
    ]
    raw_id_fields = ["user", "subscription"]
    ordering = ["-created_at"]

    fieldsets = (
        (None, {
            "fields": ("user", "subscription", "order_id", "payment_type", "status"),
        }),
        (_("Amounts"), {
            "fields": ("gross_amount", "currency", "refund_amount"),
        }),
        (_("Midtrans Details"), {
            "fields": (
                "midtrans_transaction_id", "fraud_status",
                "payment_details", "midtrans_response",
            ),
        }),
        (_("Timestamps"), {
            "fields": ("transaction_time", "settlement_time", "expiry_time"),
        }),
        (_("Retry Info"), {
            "fields": ("is_retry", "retry_count"),
            "classes": ("collapse",),
        }),
        (_("Metadata"), {
            "fields": ("metadata",),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "created_at", "updated_at"),
            "classes": ("collapse",),
        }),
    )

    actions_detail = ["admin_check_status", "admin_cancel_payment", "admin_expire_payment"]
    actions_row = ["admin_check_status_row"]

    @display(description=_("Type"))
    def display_payment_type(self, obj):
        return obj.get_payment_type_display()

    @display(
        description=_("Status"),
        ordering="status",
        label={
            Payment.Status.SETTLEMENT: "success",
            Payment.Status.CAPTURE: "success",
            Payment.Status.PENDING: "warning",
            Payment.Status.DENY: "danger",
            Payment.Status.CANCEL: "danger",
            Payment.Status.EXPIRE: "danger",
            Payment.Status.FAILURE: "danger",
            Payment.Status.REFUND: "info",
            Payment.Status.PARTIAL_REFUND: "info",
            Payment.Status.AUTHORIZE: "warning",
        },
    )
    def display_status(self, obj):
        return obj.status

    @display(description=_("Amount"), ordering="gross_amount")
    def display_amount(self, obj):
        return f"{obj.currency} {obj.gross_amount:,.0f}"

    @display(
        description=_("Fraud"),
        label={
            "accept": "success",
            "challenge": "warning",
            "deny": "danger",
        },
    )
    def display_fraud_status(self, obj):
        return obj.fraud_status or "-"

    @action(description=_("Check Midtrans Status"), icon="sync", variant=ActionVariant.PRIMARY)
    def admin_check_status(self, request: HttpRequest, object_id):
        payment = Payment.objects.get(pk=object_id)
        service = SubscriptionService()
        try:
            status_data = service.client.get_transaction_status(payment.order_id)
            service.process_notification(status_data)
        except Exception:
            pass
        return redirect(reverse_lazy("admin:subscriptions_payment_change", args=[object_id]))

    @action(description=_("Check Status"), icon="sync")
    def admin_check_status_row(self, request: HttpRequest, object_id):
        payment = Payment.objects.get(pk=object_id)
        service = SubscriptionService()
        try:
            status_data = service.client.get_transaction_status(payment.order_id)
            service.process_notification(status_data)
        except Exception:
            pass
        return redirect(reverse_lazy("admin:subscriptions_payment_changelist"))

    @action(description=_("Cancel Payment"), icon="cancel", variant=ActionVariant.DANGER)
    def admin_cancel_payment(self, request: HttpRequest, object_id):
        payment = Payment.objects.get(pk=object_id)
        service = SubscriptionService()
        try:
            service.client.cancel_transaction(payment.order_id)
            payment.status = Payment.Status.CANCEL
            payment.save(update_fields=["status", "updated_at"])
        except Exception:
            pass
        return redirect(reverse_lazy("admin:subscriptions_payment_change", args=[object_id]))

    @action(description=_("Expire Payment"), icon="timer_off", variant=ActionVariant.WARNING)
    def admin_expire_payment(self, request: HttpRequest, object_id):
        payment = Payment.objects.get(pk=object_id)
        service = SubscriptionService()
        try:
            service.client.expire_transaction(payment.order_id)
            payment.status = Payment.Status.EXPIRE
            payment.save(update_fields=["status", "updated_at"])
        except Exception:
            pass
        return redirect(reverse_lazy("admin:subscriptions_payment_change", args=[object_id]))


# ─── Invoice Admin ────────────────────────────────────────────────────────────


@admin.register(Invoice)
class InvoiceAdmin(ModelAdmin):
    list_display = [
        "invoice_number", "user", "display_status", "display_amount",
        "issue_date", "due_date", "paid_date",
    ]
    list_filter = [
        ("status", ChoicesDropdownFilter),
        ("issue_date", RangeDateFilter),
        ("due_date", RangeDateFilter),
    ]
    list_filter_submit = True
    search_fields = ["invoice_number", "user__username", "user__email"]
    readonly_fields = ["id", "invoice_number", "created_at", "updated_at"]
    raw_id_fields = ["user", "subscription", "payment"]
    ordering = ["-issue_date"]
    inlines = [InvoiceItemInline]

    fieldsets = (
        (None, {
            "fields": ("invoice_number", "user", "subscription", "payment", "status"),
        }),
        (_("Amounts"), {
            "fields": ("subtotal", "tax_amount", "discount_amount", "total_amount", "currency"),
        }),
        (_("Dates"), {
            "fields": ("issue_date", "due_date", "paid_date"),
        }),
        (_("Billing Period"), {
            "fields": ("period_start", "period_end"),
        }),
        (_("Notes"), {
            "fields": ("notes", "void_reason"),
            "classes": ("collapse",),
        }),
        (_("Metadata"), {
            "fields": ("metadata",),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "created_at", "updated_at"),
            "classes": ("collapse",),
        }),
    )

    actions_list = ["mark_as_paid", "void_invoices"]
    actions_detail = ["admin_void_invoice"]

    @display(
        description=_("Status"),
        ordering="status",
        label={
            Invoice.Status.DRAFT: "info",
            Invoice.Status.ISSUED: "warning",
            Invoice.Status.PAID: "success",
            Invoice.Status.VOID: "danger",
            Invoice.Status.OVERDUE: "danger",
            Invoice.Status.REFUNDED: "info",
        },
    )
    def display_status(self, obj):
        return obj.status

    @display(description=_("Amount"), ordering="total_amount")
    def display_amount(self, obj):
        return f"{obj.currency} {obj.total_amount:,.0f}"

    @action(description=_("Mark as Paid"), icon="check_circle", variant=ActionVariant.SUCCESS)
    def mark_as_paid(self, request: HttpRequest, queryset: QuerySet):
        queryset.update(
            status=Invoice.Status.PAID,
            paid_date=timezone.now().date(),
        )

    @action(description=_("Void selected invoices"), icon="block", variant=ActionVariant.DANGER)
    def void_invoices(self, request: HttpRequest, queryset: QuerySet):
        queryset.update(
            status=Invoice.Status.VOID,
            void_reason="Admin bulk void",
        )

    @action(description=_("Void Invoice"), icon="block", variant=ActionVariant.DANGER)
    def admin_void_invoice(self, request: HttpRequest, object_id):
        invoice = Invoice.objects.get(pk=object_id)
        SubscriptionService().void_invoice(invoice, reason="Admin action")
        return redirect(reverse_lazy("admin:subscriptions_invoice_change", args=[object_id]))


# ─── Webhook Log Admin ───────────────────────────────────────────────────────


@admin.register(WebhookLog)
class WebhookLogAdmin(ModelAdmin):
    list_display = [
        "order_id", "display_transaction_status", "display_processing_status",
        "payment_type", "gross_amount", "ip_address", "created_at",
    ]
    list_filter = [
        ("status", ChoicesDropdownFilter),
        ("transaction_status", ChoicesDropdownFilter),
        ("payment_type", ChoicesDropdownFilter),
        ("created_at", RangeDateTimeFilter),
    ]
    list_filter_submit = True
    search_fields = ["order_id", "midtrans_transaction_id"]
    readonly_fields = [
        "id", "order_id", "midtrans_transaction_id", "transaction_status",
        "payment_type", "fraud_status", "gross_amount", "signature_key",
        "raw_payload", "ip_address", "created_at",
    ]
    ordering = ["-created_at"]

    fieldsets = (
        (None, {
            "fields": ("order_id", "midtrans_transaction_id", "transaction_status", "payment_type"),
        }),
        (_("Details"), {
            "fields": ("fraud_status", "gross_amount", "signature_key"),
        }),
        (_("Processing"), {
            "fields": ("status", "error_message", "processed_at"),
        }),
        (_("Raw Data"), {
            "fields": ("raw_payload",),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "ip_address", "created_at"),
            "classes": ("collapse",),
        }),
    )

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    @display(description=_("Transaction Status"))
    def display_transaction_status(self, obj):
        return obj.transaction_status

    @display(
        description=_("Processing"),
        ordering="status",
        label={
            WebhookLog.Status.RECEIVED: "warning",
            WebhookLog.Status.PROCESSED: "success",
            WebhookLog.Status.FAILED: "danger",
            WebhookLog.Status.INVALID: "danger",
            WebhookLog.Status.DUPLICATE: "info",
        },
    )
    def display_processing_status(self, obj):
        return obj.status


# ─── Notification Log Admin ──────────────────────────────────────────────────


@admin.register(NotificationLog)
class NotificationLogAdmin(ModelAdmin):
    list_display = [
        "display_type", "user", "display_channel", "display_status",
        "recipient", "sent_at", "created_at",
    ]
    list_filter = [
        ("notification_type", ChoicesDropdownFilter),
        ("channel", ChoicesDropdownFilter),
        ("status", ChoicesDropdownFilter),
        ("created_at", RangeDateTimeFilter),
    ]
    list_filter_submit = True
    search_fields = ["user__username", "user__email", "recipient", "subject"]
    readonly_fields = ["id", "created_at", "updated_at"]
    raw_id_fields = ["user", "subscription", "payment"]
    ordering = ["-created_at"]

    fieldsets = (
        (None, {
            "fields": ("user", "subscription", "payment", "notification_type", "channel"),
        }),
        (_("Content"), {
            "fields": ("subject", "body", "recipient"),
        }),
        (_("Status"), {
            "fields": ("status", "error_message", "sent_at"),
        }),
        (_("Metadata"), {
            "fields": ("metadata",),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "created_at", "updated_at"),
            "classes": ("collapse",),
        }),
    )

    actions_list = ["resend_notifications"]

    @display(description=_("Type"))
    def display_type(self, obj):
        return obj.get_notification_type_display()

    @display(description=_("Channel"))
    def display_channel(self, obj):
        return obj.get_channel_display()

    @display(
        description=_("Status"),
        ordering="status",
        label={
            NotificationLog.Status.QUEUED: "warning",
            NotificationLog.Status.SENT: "success",
            NotificationLog.Status.FAILED: "danger",
            NotificationLog.Status.SKIPPED: "info",
        },
    )
    def display_status(self, obj):
        return obj.status

    @action(description=_("Resend selected"), icon="send", variant=ActionVariant.PRIMARY)
    def resend_notifications(self, request: HttpRequest, queryset: QuerySet):
        queryset.update(status=NotificationLog.Status.QUEUED)


# ─── Wallet Admin ─────────────────────────────────────────────────────────────


class WalletTransactionInline(TabularInline):
    model = WalletTransaction
    extra = 0
    fields = ["transaction_type", "amount", "balance_before", "balance_after", "description", "created_at"]
    readonly_fields = ["transaction_type", "amount", "balance_before", "balance_after", "description", "created_at"]
    show_change_link = True
    max_num = 0
    ordering = ["-created_at"]


@admin.register(Wallet)
class WalletAdmin(ModelAdmin):
    list_display = [
        "user", "display_balance", "currency", "display_status", "created_at",
    ]
    list_filter = [
        "is_active",
        "currency",
        ("created_at", RangeDateFilter),
    ]
    list_filter_submit = True
    search_fields = ["user__username", "user__email"]
    readonly_fields = ["id", "balance", "created_at", "updated_at"]
    raw_id_fields = ["user"]
    ordering = ["-created_at"]
    inlines = [WalletTransactionInline]

    fieldsets = (
        (None, {
            "fields": ("user", "balance", "currency", "is_active"),
        }),
        (_("Metadata"), {
            "fields": ("metadata",),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "created_at", "updated_at"),
            "classes": ("collapse",),
        }),
    )

    @display(description=_("Balance"), ordering="balance")
    def display_balance(self, obj):
        return f"{obj.currency} {obj.balance:,.0f}"

    @display(
        description=_("Status"),
        label={
            True: "success",
            False: "danger",
        },
    )
    def display_status(self, obj):
        return obj.is_active


@admin.register(WalletTransaction)
class WalletTransactionAdmin(ModelAdmin):
    list_display = [
        "display_user", "display_type", "display_amount",
        "display_balance_after", "description", "created_at",
    ]
    list_filter = [
        ("transaction_type", ChoicesDropdownFilter),
        ("created_at", RangeDateTimeFilter),
    ]
    list_filter_submit = True
    search_fields = ["wallet__user__username", "wallet__user__email", "description", "reference_id"]
    readonly_fields = [
        "id", "wallet", "transaction_type", "amount",
        "balance_before", "balance_after", "reference_type",
        "reference_id", "description", "metadata", "created_at",
    ]
    ordering = ["-created_at"]

    fieldsets = (
        (None, {
            "fields": ("wallet", "transaction_type", "amount"),
        }),
        (_("Balance"), {
            "fields": ("balance_before", "balance_after"),
        }),
        (_("Reference"), {
            "fields": ("reference_type", "reference_id", "description"),
        }),
        (_("Metadata"), {
            "fields": ("metadata",),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "created_at"),
            "classes": ("collapse",),
        }),
    )

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    @display(description=_("User"))
    def display_user(self, obj):
        return obj.wallet.user.username

    @display(description=_("Type"))
    def display_type(self, obj):
        return obj.get_transaction_type_display()

    @display(description=_("Amount"), ordering="amount")
    def display_amount(self, obj):
        prefix = "+" if obj.amount > 0 else ""
        return f"{prefix}{obj.amount:,.0f}"

    @display(description=_("Balance After"), ordering="balance_after")
    def display_balance_after(self, obj):
        return f"{obj.balance_after:,.0f}"


@admin.register(TopUp)
class TopUpAdmin(ModelAdmin):
    list_display = [
        "display_user", "display_amount", "display_payment_type",
        "display_status", "order_id", "created_at",
    ]
    list_filter = [
        ("status", ChoicesDropdownFilter),
        ("payment_type", ChoicesDropdownFilter),
        ("created_at", RangeDateFilter),
    ]
    list_filter_submit = True
    search_fields = ["user__username", "user__email", "order_id", "midtrans_transaction_id"]
    readonly_fields = [
        "id", "wallet", "user", "order_id", "midtrans_transaction_id",
        "midtrans_response", "payment_details", "created_at", "updated_at",
    ]
    raw_id_fields = ["user", "wallet"]
    ordering = ["-created_at"]

    fieldsets = (
        (None, {
            "fields": ("user", "wallet", "amount", "payment_type", "status"),
        }),
        (_("Midtrans"), {
            "fields": ("order_id", "midtrans_transaction_id", "payment_details", "midtrans_response"),
        }),
        (_("Metadata"), {
            "fields": ("metadata",),
            "classes": ("collapse",),
        }),
        (_("System"), {
            "fields": ("id", "created_at", "updated_at"),
            "classes": ("collapse",),
        }),
    )

    @display(description=_("User"))
    def display_user(self, obj):
        return obj.user.username

    @display(description=_("Amount"), ordering="amount")
    def display_amount(self, obj):
        return f"IDR {obj.amount:,.0f}"

    @display(description=_("Payment Type"))
    def display_payment_type(self, obj):
        return obj.get_payment_type_display()

    @display(
        description=_("Status"),
        ordering="status",
        label={
            TopUp.Status.PENDING: "warning",
            TopUp.Status.SUCCESS: "success",
            TopUp.Status.FAILED: "danger",
            TopUp.Status.EXPIRED: "danger",
        },
    )
    def display_status(self, obj):
        return obj.status
