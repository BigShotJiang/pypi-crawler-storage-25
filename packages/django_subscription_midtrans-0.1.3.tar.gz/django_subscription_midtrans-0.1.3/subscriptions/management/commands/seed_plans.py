"""
Management command to create seed subscription plans.
"""
from decimal import Decimal

from django.core.management.base import BaseCommand

from subscriptions.models import Plan


class Command(BaseCommand):
    help = "Create sample subscription plans for development and testing."

    def add_arguments(self, parser):
        parser.add_argument(
            "--reset",
            action="store_true",
            help="Delete all existing plans before creating seed plans.",
        )

    def handle(self, *args, **options):
        if options["reset"]:
            deleted, _ = Plan.objects.all().delete()
            self.stdout.write(self.style.WARNING(f"Deleted {deleted} existing plans."))

        plans = [
            {
                "name": "Basic Monthly",
                "slug": "basic-monthly",
                "description": "Basic plan billed monthly",
                "price": Decimal("99000"),
                "currency": "IDR",
                "interval": 1,
                "interval_unit": Plan.IntervalUnit.MONTH,
                "trial_period_days": 0,
                "features": {"max_users": 1, "storage_gb": 5, "support": "email"},
                "sort_order": 10,
            },
            {
                "name": "Pro Monthly",
                "slug": "pro-monthly",
                "description": "Professional plan billed monthly",
                "price": Decimal("299000"),
                "currency": "IDR",
                "interval": 1,
                "interval_unit": Plan.IntervalUnit.MONTH,
                "trial_period_days": 0,
                "features": {"max_users": 5, "storage_gb": 50, "support": "priority"},
                "sort_order": 20,
            },
            {
                "name": "Enterprise Monthly",
                "slug": "enterprise-monthly",
                "description": "Enterprise plan billed monthly",
                "price": Decimal("999000"),
                "currency": "IDR",
                "interval": 1,
                "interval_unit": Plan.IntervalUnit.MONTH,
                "trial_period_days": 0,
                "features": {"max_users": -1, "storage_gb": 500, "support": "dedicated"},
                "sort_order": 30,
            },
            {
                "name": "Basic Yearly",
                "slug": "basic-yearly",
                "description": "Basic plan billed yearly (2 months free)",
                "price": Decimal("990000"),
                "currency": "IDR",
                "interval": 1,
                "interval_unit": Plan.IntervalUnit.MONTH,
                "trial_period_days": 0,
                "features": {"max_users": 1, "storage_gb": 5, "support": "email"},
                "sort_order": 40,
            },
            {
                "name": "Pro Yearly",
                "slug": "pro-yearly",
                "description": "Professional plan billed yearly (2 months free)",
                "price": Decimal("2990000"),
                "currency": "IDR",
                "interval": 12,
                "interval_unit": Plan.IntervalUnit.MONTH,
                "trial_period_days": 0,
                "features": {"max_users": 5, "storage_gb": 50, "support": "priority"},
                "sort_order": 50,
            },
        ]

        for plan_data in plans:
            plan, created = Plan.objects.update_or_create(
                slug=plan_data["slug"],
                defaults=plan_data,
            )
            status = "Created" if created else "Updated"
            self.stdout.write(self.style.SUCCESS(f"  {status}: {plan.name} ({plan.price} {plan.currency})"))

        self.stdout.write(self.style.SUCCESS(f"\n{len(plans)} plans configured."))
