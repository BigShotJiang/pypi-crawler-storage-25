"""
Management command to set up periodic tasks for subscription management.
Creates Django Celery Beat PeriodicTask entries.
"""
import json

from django.core.management.base import BaseCommand

from django_celery_beat.models import CrontabSchedule, IntervalSchedule, PeriodicTask


class Command(BaseCommand):
    help = "Set up periodic tasks for subscription billing, retries, reminders, and syncing."

    def add_arguments(self, parser):
        parser.add_argument(
            "--reset",
            action="store_true",
            help="Delete existing subscription tasks before creating them.",
        )

    def handle(self, *args, **options):
        if options["reset"]:
            deleted, _ = PeriodicTask.objects.filter(
                name__startswith="subscriptions:"
            ).delete()
            self.stdout.write(self.style.WARNING(f"Deleted {deleted} existing tasks."))

        tasks = self._get_task_definitions()

        for task_def in tasks:
            name = task_def.pop("name")
            task = task_def.pop("task")
            schedule_type = task_def.pop("schedule_type")
            schedule_kwargs = task_def.pop("schedule_kwargs")
            task_kwargs = task_def.get("kwargs", {})

            if schedule_type == "interval":
                schedule, _ = IntervalSchedule.objects.get_or_create(**schedule_kwargs)
                pt, created = PeriodicTask.objects.update_or_create(
                    name=name,
                    defaults={
                        "task": task,
                        "interval": schedule,
                        "crontab": None,
                        "kwargs": json.dumps(task_kwargs),
                        "enabled": True,
                    },
                )
            elif schedule_type == "crontab":
                schedule, _ = CrontabSchedule.objects.get_or_create(**schedule_kwargs)
                pt, created = PeriodicTask.objects.update_or_create(
                    name=name,
                    defaults={
                        "task": task,
                        "crontab": schedule,
                        "interval": None,
                        "kwargs": json.dumps(task_kwargs),
                        "enabled": True,
                    },
                )

            status = "Created" if created else "Updated"
            self.stdout.write(self.style.SUCCESS(f"  {status}: {name}"))

        self.stdout.write(self.style.SUCCESS(f"\nAll {len(tasks)} periodic tasks configured."))

    def _get_task_definitions(self):
        return [
            {
                "name": "subscriptions:process-due-billing",
                "task": "subscriptions.tasks.process_due_subscriptions",
                "schedule_type": "interval",
                "schedule_kwargs": {"every": 1, "period": IntervalSchedule.HOURS},
            },
            {
                "name": "subscriptions:process-expired",
                "task": "subscriptions.tasks.process_expired_subscriptions",
                "schedule_type": "interval",
                "schedule_kwargs": {"every": 6, "period": IntervalSchedule.HOURS},
            },
            {
                "name": "subscriptions:process-past-due-expiration",
                "task": "subscriptions.tasks.process_past_due_expiration",
                "schedule_type": "interval",
                "schedule_kwargs": {"every": 12, "period": IntervalSchedule.HOURS},
            },
            {
                "name": "subscriptions:retry-failed-payments",
                "task": "subscriptions.tasks.retry_failed_payments",
                "schedule_type": "interval",
                "schedule_kwargs": {"every": 4, "period": IntervalSchedule.HOURS},
            },
            {
                "name": "subscriptions:mark-overdue-invoices",
                "task": "subscriptions.tasks.mark_overdue_invoices",
                "schedule_type": "crontab",
                "schedule_kwargs": {"minute": "0", "hour": "1"},
            },
            {
                "name": "subscriptions:send-expiry-reminders",
                "task": "subscriptions.tasks.send_expiry_reminders",
                "schedule_type": "crontab",
                "schedule_kwargs": {"minute": "0", "hour": "9"},
            },
            {
                "name": "subscriptions:sync-midtrans-subscriptions",
                "task": "subscriptions.tasks.sync_midtrans_subscriptions",
                "schedule_type": "interval",
                "schedule_kwargs": {"every": 6, "period": IntervalSchedule.HOURS},
            },
            {
                "name": "subscriptions:send-pending-emails",
                "task": "subscriptions.tasks.send_pending_email_notifications",
                "schedule_type": "interval",
                "schedule_kwargs": {"every": 5, "period": IntervalSchedule.MINUTES},
            },
        ]
