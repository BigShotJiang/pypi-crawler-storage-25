"""DRF ViewSets and Views for subscriptions package."""
import logging

from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters, mixins, permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from .client import MidtransAPIError
from .models import Invoice, NotificationLog, Payment, Plan, Subscription, TopUp, Wallet, WalletTransaction, WebhookLog
from .serializers import (
    InvoiceSerializer,
    NotificationLogSerializer,
    PaymentChargeSerializer,
    PaymentSerializer,
    PlanSerializer,
    RefundSerializer,
    SubscriptionCancelSerializer,
    SubscriptionChangePlanSerializer,
    SubscriptionCreateSerializer,
    SubscriptionSerializer,
    TopUpCreateSerializer,
    TopUpSerializer,
    WalletSerializer,
    WalletTransactionSerializer,
    WebhookLogSerializer,
    WebhookNotificationSerializer,
)
from .services import SubscriptionService, WalletService

logger = logging.getLogger("subscriptions")


# ─── Plan ViewSet ─────────────────────────────────────────────────────────────


class PlanViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint for viewing subscription plans.
    Public read-only access to active plans.
    """

    serializer_class = PlanSerializer
    permission_classes = [permissions.AllowAny]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["status", "interval_unit", "currency"]
    search_fields = ["name", "description"]
    ordering_fields = ["price", "sort_order", "created_at"]
    ordering = ["sort_order", "price"]
    lookup_field = "slug"

    def get_queryset(self):
        return Plan.objects.filter(status=Plan.Status.ACTIVE)


# ─── Subscription ViewSet ────────────────────────────────────────────────────


class SubscriptionViewSet(viewsets.GenericViewSet, mixins.ListModelMixin, mixins.RetrieveModelMixin):
    """
    API endpoint for managing subscriptions.

    list: List current user's subscriptions
    retrieve: Get subscription detail
    create: Create a new subscription
    cancel: Cancel a subscription
    pause: Pause a subscription
    resume: Resume a paused subscription
    change_plan: Change subscription plan
    """

    serializer_class = SubscriptionSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["status", "payment_type"]
    ordering_fields = ["created_at", "next_billing_date"]
    ordering = ["-created_at"]

    def get_queryset(self):
        return Subscription.objects.filter(
            user=self.request.user
        ).select_related("plan")

    def get_service(self) -> SubscriptionService:
        return SubscriptionService()

    def create(self, request):
        """Create a new subscription."""
        serializer = SubscriptionCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        plan = serializer.validated_data["plan_id"]
        payment_type = serializer.validated_data["payment_type"]
        token = serializer.validated_data.get("token", "")
        customer_details = serializer.validated_data.get("customer_details", {})
        metadata = serializer.validated_data.get("metadata", {})

        service = self.get_service()

        try:
            subscription = service.create_subscription(
                user=request.user,
                plan=plan,
                payment_type=payment_type,
                token=token if payment_type == "credit_card" else None,
                gopay_account_id=token if payment_type == "gopay" else None,
                customer_details=customer_details,
                metadata=metadata,
            )
        except MidtransAPIError as e:
            return Response(
                {"error": str(e), "details": e.response_data},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Get latest payment details
        latest_payment = subscription.payments.order_by("-created_at").first()
        payment_data = PaymentSerializer(latest_payment).data if latest_payment else None

        return Response(
            {
                "subscription": SubscriptionSerializer(subscription).data,
                "payment": payment_data,
            },
            status=status.HTTP_201_CREATED,
        )

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        """Cancel a subscription."""
        subscription = self.get_object()
        serializer = SubscriptionCancelSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        service = self.get_service()
        subscription = service.cancel_subscription(
            subscription=subscription,
            reason=serializer.validated_data["reason"],
            immediate=serializer.validated_data["immediate"],
        )
        return Response(SubscriptionSerializer(subscription).data)

    @action(detail=True, methods=["post"])
    def pause(self, request, pk=None):
        """Pause a subscription."""
        subscription = self.get_object()
        if subscription.status != Subscription.Status.ACTIVE:
            return Response(
                {"error": "Only active subscriptions can be paused."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        service = self.get_service()
        subscription = service.pause_subscription(subscription)
        return Response(SubscriptionSerializer(subscription).data)

    @action(detail=True, methods=["post"])
    def resume(self, request, pk=None):
        """Resume a paused subscription."""
        subscription = self.get_object()
        if subscription.status != Subscription.Status.PAUSED:
            return Response(
                {"error": "Only paused subscriptions can be resumed."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        service = self.get_service()
        subscription = service.resume_subscription(subscription)
        return Response(SubscriptionSerializer(subscription).data)

    @action(detail=True, methods=["post"], url_path="change-plan")
    def change_plan(self, request, pk=None):
        """Change subscription plan."""
        subscription = self.get_object()
        serializer = SubscriptionChangePlanSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        service = self.get_service()
        new_plan = serializer.validated_data["plan_id"]

        try:
            subscription = service.change_plan(
                subscription=subscription,
                new_plan=new_plan,
                immediate=serializer.validated_data["immediate"],
            )
        except MidtransAPIError as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(SubscriptionSerializer(subscription).data)

    @action(detail=True, methods=["get"])
    def sync(self, request, pk=None):
        """Sync subscription status from Midtrans."""
        subscription = self.get_object()
        service = self.get_service()
        subscription = service.sync_subscription_status(subscription)
        return Response(SubscriptionSerializer(subscription).data)

    @action(detail=False, methods=["get"])
    def active(self, request):
        """Get the current user's active subscription."""
        subscription = SubscriptionService.get_active_subscription(request.user)
        if not subscription:
            return Response(
                {"detail": "No active subscription found."},
                status=status.HTTP_404_NOT_FOUND,
            )
        return Response(SubscriptionSerializer(subscription).data)


# ─── Payment ViewSet ──────────────────────────────────────────────────────────


class PaymentViewSet(viewsets.GenericViewSet, mixins.ListModelMixin, mixins.RetrieveModelMixin):
    """
    API endpoint for viewing and managing payments.

    list: List user's payments
    retrieve: Get payment detail
    charge: Create a new charge for a subscription
    refund: Refund a payment
    status: Check payment status from Midtrans
    """

    serializer_class = PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["status", "payment_type"]
    ordering_fields = ["created_at", "gross_amount"]
    ordering = ["-created_at"]

    def get_queryset(self):
        return Payment.objects.filter(
            user=self.request.user
        ).select_related("subscription")

    @action(detail=False, methods=["post"])
    def charge(self, request):
        """Create a new charge for a subscription."""
        serializer = PaymentChargeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        subscription = serializer.validated_data["subscription_id"]
        if subscription.user != request.user:
            return Response(
                {"error": "You do not own this subscription."},
                status=status.HTTP_403_FORBIDDEN,
            )

        service = SubscriptionService()
        try:
            payment = service.create_charge_for_subscription(subscription)
        except MidtransAPIError as e:
            return Response(
                {"error": str(e), "details": e.response_data},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(PaymentSerializer(payment).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def refund(self, request, pk=None):
        """Refund a payment."""
        payment = self.get_object()
        if not payment.is_paid:
            return Response(
                {"error": "Only paid/settled payments can be refunded."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = RefundSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        service = SubscriptionService()
        try:
            payment = service.refund_payment(
                payment=payment,
                amount=serializer.validated_data.get("amount"),
                reason=serializer.validated_data.get("reason", ""),
                direct=serializer.validated_data.get("direct", False),
            )
        except MidtransAPIError as e:
            return Response(
                {"error": str(e), "details": e.response_data},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(PaymentSerializer(payment).data)

    @action(detail=True, methods=["get"], url_path="check-status")
    def check_status(self, request, pk=None):
        """Check payment status directly from Midtrans."""
        payment = self.get_object()
        service = SubscriptionService()
        try:
            midtrans_status = service.client.get_transaction_status(payment.order_id)
            return Response({
                "local_status": payment.status,
                "midtrans_status": midtrans_status,
            })
        except MidtransAPIError as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST,
            )


# ─── Invoice ViewSet ─────────────────────────────────────────────────────────


class InvoiceViewSet(viewsets.ReadOnlyModelViewSet):
    """API endpoint for viewing invoices."""

    serializer_class = InvoiceSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["status"]
    ordering_fields = ["issue_date", "due_date", "total_amount"]
    ordering = ["-issue_date"]

    def get_queryset(self):
        return Invoice.objects.filter(
            user=self.request.user
        ).select_related("subscription", "payment").prefetch_related("items")


# ─── Webhook View ─────────────────────────────────────────────────────────────


@method_decorator(csrf_exempt, name="dispatch")
class MidtransWebhookView(APIView):
    """
    Endpoint for receiving Midtrans payment notifications (webhooks).

    - No authentication required (Midtrans calls this)
    - Signature verification is done in the service layer
    - Returns 200 immediately to avoid Midtrans retries
    """

    permission_classes = [permissions.AllowAny]
    authentication_classes = []

    def post(self, request):
        serializer = WebhookNotificationSerializer(data=request.data)
        if not serializer.is_valid():
            logger.warning("Invalid webhook payload: %s", serializer.errors)
            # Still return 200 to avoid Midtrans retries for malformed payloads
            return Response({"status": "error", "errors": serializer.errors})

        ip_address = self._get_client_ip(request)
        service = SubscriptionService()
        webhook_log = service.process_notification(
            payload=request.data,
            ip_address=ip_address,
        )

        return Response({
            "status": "ok",
            "webhook_log_id": str(webhook_log.id),
        })

    def _get_client_ip(self, request):
        x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded_for:
            return x_forwarded_for.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR")


# ─── Notification ViewSet ────────────────────────────────────────────────────


class NotificationLogViewSet(viewsets.ReadOnlyModelViewSet):
    """API endpoint for viewing notification logs."""

    serializer_class = NotificationLogSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["notification_type", "channel", "status"]
    ordering = ["-created_at"]

    def get_queryset(self):
        return NotificationLog.objects.filter(user=self.request.user)

    @action(detail=False, methods=["get"])
    def unread(self, request):
        """Get unread/queued notifications."""
        notifications = NotificationLog.objects.filter(
            user=request.user,
            status=NotificationLog.Status.QUEUED,
        ).order_by("-created_at")[:50]
        return Response(NotificationLogSerializer(notifications, many=True).data)

    @action(detail=True, methods=["post"], url_path="mark-read")
    def mark_read(self, request, pk=None):
        """Mark a notification as read (sent)."""
        notification = self.get_object()
        notification.status = NotificationLog.Status.SENT
        notification.save(update_fields=["status", "updated_at"])
        return Response(NotificationLogSerializer(notification).data)


# ─── Wallet ViewSet ───────────────────────────────────────────────────────────


class WalletViewSet(viewsets.GenericViewSet):
    """
    API endpoint for wallet management.

    me: Get current user's wallet (creates if not exists)
    transactions: List wallet transactions
    """

    serializer_class = WalletSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Wallet.objects.filter(user=self.request.user)

    @action(detail=False, methods=["get"])
    def me(self, request):
        """Get or create the current user's wallet."""
        wallet = WalletService.get_or_create_wallet(request.user)
        return Response(WalletSerializer(wallet).data)

    @action(detail=False, methods=["get"])
    def transactions(self, request):
        """List wallet transactions."""
        wallet = WalletService.get_wallet(request.user)
        if not wallet:
            return Response([])
        transactions = wallet.transactions.order_by("-created_at")
        page = self.paginate_queryset(transactions)
        if page is not None:
            serializer = WalletTransactionSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        return Response(
            WalletTransactionSerializer(transactions, many=True).data
        )


# ─── TopUp ViewSet ───────────────────────────────────────────────────────────


class TopUpViewSet(viewsets.GenericViewSet, mixins.ListModelMixin, mixins.RetrieveModelMixin):
    """
    API endpoint for wallet top-ups.

    list: List user's top-ups
    retrieve: Get top-up detail
    create: Create a new top-up
    """

    serializer_class = TopUpSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ["status", "payment_type"]
    ordering = ["-created_at"]

    def get_queryset(self):
        return TopUp.objects.filter(user=self.request.user)

    def create(self, request):
        """Create a new top-up request."""
        serializer = TopUpCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        wallet_service = WalletService()
        callback_url = request.build_absolute_uri("/example/payment/callback/")
        customer_details = {
            "first_name": request.user.first_name or request.user.username,
            "last_name": request.user.last_name or "",
            "email": request.user.email,
        }

        try:
            topup = wallet_service.create_topup(
                user=request.user,
                amount=serializer.validated_data["amount"],
                payment_type=serializer.validated_data["payment_type"],
                bank=serializer.validated_data.get("bank"),
                callback_url=callback_url,
                customer_details=customer_details,
                token=serializer.validated_data.get("token"),
            )
        except MidtransAPIError as e:
            return Response(
                {"error": str(e), "details": e.response_data},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(TopUpSerializer(topup).data, status=status.HTTP_201_CREATED)
