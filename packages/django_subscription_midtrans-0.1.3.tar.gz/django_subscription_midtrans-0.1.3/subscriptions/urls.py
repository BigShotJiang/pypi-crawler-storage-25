"""URL routing for subscriptions package."""
from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import (
    InvoiceViewSet,
    MidtransWebhookView,
    NotificationLogViewSet,
    PaymentViewSet,
    PlanViewSet,
    SubscriptionViewSet,
    TopUpViewSet,
    WalletViewSet,
)

app_name = "subscriptions"

router = DefaultRouter()
router.register(r"plans", PlanViewSet, basename="plan")
router.register(r"subscriptions", SubscriptionViewSet, basename="subscription")
router.register(r"payments", PaymentViewSet, basename="payment")
router.register(r"invoices", InvoiceViewSet, basename="invoice")
router.register(r"notifications", NotificationLogViewSet, basename="notification")
router.register(r"wallet", WalletViewSet, basename="wallet")
router.register(r"topups", TopUpViewSet, basename="topup")

urlpatterns = [
    path("webhook/notification/", MidtransWebhookView.as_view(), name="webhook-notification"),
    path("", include(router.urls)),
]
