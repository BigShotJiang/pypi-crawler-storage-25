"""
Tests for the subscription service layer.
"""
from datetime import timedelta
from decimal import Decimal
from unittest.mock import patch

from django.test import TestCase, override_settings
from django.utils import timezone

from subscriptions.models import Invoice, Payment, Subscription, WebhookLog
from subscriptions.services import SubscriptionService

from .factories import (
    create_invoice,
    create_payment,
    create_plan,
    create_subscription,
    create_user,
    make_midtrans_notification,
)


@override_settings(
    MIDTRANS_SERVER_KEY="SB-Mid-server-TEST",
    MIDTRANS_IS_PRODUCTION=False,
)
class SubscriptionServiceTest(TestCase):
    def setUp(self):
        self.service = SubscriptionService()
        self.user = create_user()
        self.plan = create_plan(price=Decimal("100000"))

    def test_create_subscription_manual(self):
        with patch.object(self.service, "client") as mock_client:
            mock_client.charge_bank_transfer.return_value = {
                "transaction_id": "tx-123",
                "order_id": "test-order",
                "transaction_status": "pending",
                "status_code": "201",
                "gross_amount": "100000",
            }

            sub = self.service.create_subscription(
                user=self.user,
                plan=self.plan,
                payment_type="bank_transfer",
            )
            self.assertEqual(sub.status, Subscription.Status.PENDING)

    def test_activate_subscription(self):
        sub = create_subscription(user=self.user, plan=self.plan, status=Subscription.Status.PENDING)
        self.service.activate_subscription(sub)
        sub.refresh_from_db()
        self.assertEqual(sub.status, Subscription.Status.ACTIVE)

    def test_cancel_subscription_end_of_period(self):
        sub = create_subscription(user=self.user, plan=self.plan)
        self.service.cancel_subscription(sub, reason="Test", immediate=False)
        sub.refresh_from_db()
        self.assertTrue(sub.cancel_at_period_end)
        self.assertEqual(sub.status, Subscription.Status.ACTIVE)

    def test_cancel_subscription_immediate(self):
        with patch.object(self.service, "client") as mock_client:
            mock_client.cancel_subscription.return_value = {}
            sub = create_subscription(user=self.user, plan=self.plan)
            self.service.cancel_subscription(sub, reason="Test", immediate=True)
            sub.refresh_from_db()
            self.assertEqual(sub.status, Subscription.Status.CANCELLED)

    def test_expire_subscription(self):
        sub = create_subscription(user=self.user, plan=self.plan)
        self.service.expire_subscription(sub)
        sub.refresh_from_db()
        self.assertEqual(sub.status, Subscription.Status.EXPIRED)

    def test_pause_subscription(self):
        sub = create_subscription(user=self.user, plan=self.plan)
        self.service.pause_subscription(sub)
        sub.refresh_from_db()
        self.assertEqual(sub.status, Subscription.Status.PAUSED)

    def test_resume_subscription(self):
        sub = create_subscription(
            user=self.user,
            plan=self.plan,
            status=Subscription.Status.PAUSED,
        )
        self.service.resume_subscription(sub)
        sub.refresh_from_db()
        self.assertEqual(sub.status, Subscription.Status.ACTIVE)

    def test_mark_past_due(self):
        sub = create_subscription(user=self.user, plan=self.plan)
        self.service.mark_past_due(sub)
        sub.refresh_from_db()
        self.assertEqual(sub.status, Subscription.Status.PAST_DUE)

    def test_process_notification_settlement(self):
        sub = create_subscription(user=self.user, plan=self.plan, status=Subscription.Status.PENDING)
        payment = create_payment(
            subscription=sub,
            order_id="ORDER-SETTLE-001",
            gross_amount=Decimal("100000"),
        )

        notification = make_midtrans_notification(
            order_id="ORDER-SETTLE-001",
            status="settlement",
            gross_amount="100000.00",
        )

        self.service.process_notification(notification)

        payment.refresh_from_db()
        self.assertEqual(payment.status, Payment.Status.SETTLEMENT)

        sub.refresh_from_db()
        self.assertEqual(sub.status, Subscription.Status.ACTIVE)

    def test_process_notification_invalid_signature(self):
        payment = create_payment(order_id="ORDER-SIG-001")
        notification = make_midtrans_notification(
            order_id="ORDER-SIG-001",
            status="settlement",
        )
        notification["signature_key"] = "invalid"

        # Invalid signature returns webhook log with INVALID status (doesn't raise)
        from subscriptions.models import WebhookLog
        webhook_log = self.service.process_notification(notification)
        self.assertEqual(webhook_log.status, WebhookLog.Status.INVALID)

    def test_process_notification_expire(self):
        sub = create_subscription(user=self.user, plan=self.plan, status=Subscription.Status.PENDING)
        payment = create_payment(
            subscription=sub,
            order_id="ORDER-EXPIRE-001",
            gross_amount=Decimal("100000"),
        )
        notification = make_midtrans_notification(
            order_id="ORDER-EXPIRE-001",
            status="expire",
            gross_amount="100000.00",
        )

        self.service.process_notification(notification)

        payment.refresh_from_db()
        self.assertEqual(payment.status, Payment.Status.EXPIRE)

    def test_void_invoice(self):
        invoice = create_invoice()
        self.service.void_invoice(invoice, reason="Test void")
        invoice.refresh_from_db()
        self.assertEqual(invoice.status, Invoice.Status.VOID)
        self.assertEqual(invoice.void_reason, "Test void")

    def test_get_subscriptions_due_for_billing(self):
        now = timezone.now()
        sub_due = create_subscription(
            user=self.user,
            plan=self.plan,
            next_billing_date=now - timedelta(hours=1),
        )
        sub_not_due = create_subscription(
            plan=self.plan,
            next_billing_date=now + timedelta(days=5),
        )

        due = self.service.get_subscriptions_due_for_billing()
        self.assertIn(sub_due, due)
        self.assertNotIn(sub_not_due, due)

    def test_get_overdue_invoices(self):
        now = timezone.now()
        overdue = create_invoice(
            due_date=(now - timedelta(days=1)).date(),
            status=Invoice.Status.ISSUED,
        )
        not_overdue = create_invoice(
            due_date=(now + timedelta(days=5)).date(),
            status=Invoice.Status.ISSUED,
        )

        result = self.service.get_overdue_invoices()
        self.assertIn(overdue, result)
        self.assertNotIn(not_overdue, result)
