"""
Tests for subscription models.
"""
from datetime import timedelta
from decimal import Decimal

from django.test import TestCase, override_settings
from django.utils import timezone

from subscriptions.models import (
    Invoice,
    InvoiceItem,
    NotificationLog,
    Payment,
    Plan,
    Subscription,
    WebhookLog,
)

from .factories import create_invoice, create_payment, create_plan, create_subscription, create_user


class PlanModelTest(TestCase):
    def test_create_plan(self):
        plan = create_plan(name="Test Plan", slug="test-plan", price=Decimal("150000"))
        self.assertEqual(plan.name, "Test Plan")
        self.assertEqual(plan.price, Decimal("150000"))
        self.assertEqual(plan.status, Plan.Status.ACTIVE)

    def test_plan_str(self):
        plan = create_plan(name="Pro Plan")
        self.assertIn("Pro Plan", str(plan))

    def test_get_interval_display(self):
        plan_month = create_plan(interval=1, interval_unit=Plan.IntervalUnit.MONTH)
        self.assertIn("1", plan_month.get_interval_display())
        self.assertIn("month", plan_month.get_interval_display().lower())

        plan_week = create_plan(interval=2, interval_unit=Plan.IntervalUnit.WEEK)
        self.assertIn("2", plan_week.get_interval_display())
        self.assertIn("week", plan_week.get_interval_display().lower())

    def test_plan_slug_uniqueness(self):
        create_plan(slug="unique-slug")
        with self.assertRaises(Exception):
            create_plan(slug="unique-slug")


class SubscriptionModelTest(TestCase):
    def test_create_subscription(self):
        sub = create_subscription()
        self.assertEqual(sub.status, Subscription.Status.ACTIVE)
        self.assertIsNotNone(sub.user)
        self.assertIsNotNone(sub.plan)

    def test_is_active(self):
        sub = create_subscription(status=Subscription.Status.ACTIVE)
        self.assertTrue(sub.is_active)

        sub.status = Subscription.Status.CANCELLED
        self.assertFalse(sub.is_active)

    def test_is_in_grace_period(self):
        now = timezone.now()
        sub = create_subscription(
            status=Subscription.Status.PAST_DUE,
            current_period_end=now - timedelta(days=1),
        )
        self.assertTrue(sub.is_in_grace_period)

    def test_has_access_active(self):
        sub = create_subscription(status=Subscription.Status.ACTIVE)
        self.assertTrue(sub.has_access)

    def test_has_access_trialing(self):
        sub = create_subscription(status=Subscription.Status.TRIALING)
        self.assertTrue(sub.has_access)

    def test_has_no_access_expired(self):
        sub = create_subscription(status=Subscription.Status.EXPIRED)
        self.assertFalse(sub.has_access)

    def test_str_representation(self):
        sub = create_subscription()
        self.assertIn(sub.user.username, str(sub))
        self.assertIn(sub.plan.name, str(sub))


class PaymentModelTest(TestCase):
    def test_create_payment(self):
        payment = create_payment()
        self.assertEqual(payment.status, Payment.Status.PENDING)
        self.assertIsNotNone(payment.order_id)

    def test_order_id_uniqueness(self):
        payment = create_payment(order_id="UNIQUE-ORDER-001")
        with self.assertRaises(Exception):
            create_payment(order_id="UNIQUE-ORDER-001")

    def test_str_representation(self):
        payment = create_payment()
        self.assertIn(payment.order_id, str(payment))


class InvoiceModelTest(TestCase):
    def test_create_invoice(self):
        invoice = create_invoice()
        self.assertEqual(invoice.status, Invoice.Status.ISSUED)
        self.assertIsNotNone(invoice.invoice_number)

    def test_invoice_with_items(self):
        invoice = create_invoice()
        item = InvoiceItem.objects.create(
            invoice=invoice,
            description="Monthly subscription",
            quantity=1,
            unit_price=Decimal("100000"),
        )
        self.assertEqual(item.total_price, Decimal("100000"))

    def test_str_representation(self):
        invoice = create_invoice()
        self.assertIn(invoice.invoice_number, str(invoice))


class WebhookLogModelTest(TestCase):
    def test_create_webhook_log(self):
        log = WebhookLog.objects.create(
            order_id="ORDER-123",
            transaction_status="settlement",
            payment_type="bank_transfer",
            gross_amount="100000",
            signature_key="abc123",
            raw_payload={"test": True},
            ip_address="127.0.0.1",
        )
        self.assertEqual(log.status, WebhookLog.Status.RECEIVED)


class NotificationLogModelTest(TestCase):
    def test_create_notification_log(self):
        user = create_user()
        log = NotificationLog.objects.create(
            user=user,
            notification_type="subscription_created",
            channel="email",
            subject="Welcome!",
            recipient=user.email,
        )
        self.assertEqual(log.status, NotificationLog.Status.QUEUED)
