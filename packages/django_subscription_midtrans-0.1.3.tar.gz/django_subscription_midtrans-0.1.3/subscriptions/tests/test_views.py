"""
Tests for DRF API views.
"""
import json
from decimal import Decimal
from unittest.mock import patch

from django.test import TestCase, override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient

from subscriptions.models import Payment, Plan, Subscription
from subscriptions.services import SubscriptionService

from .factories import (
    create_payment,
    create_plan,
    create_subscription,
    create_user,
    make_midtrans_notification,
)


class PlanViewSetTest(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.plan = create_plan(name="Test Plan", slug="test-plan")

    def test_list_plans(self):
        response = self.client.get("/api/subscriptions/plans/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_retrieve_plan_by_slug(self):
        response = self.client.get(f"/api/subscriptions/plans/{self.plan.slug}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["name"], "Test Plan")

    def test_plans_are_read_only(self):
        response = self.client.post("/api/subscriptions/plans/", {"name": "New"})
        self.assertEqual(response.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)


class SubscriptionViewSetTest(TestCase):
    def setUp(self):
        self.user = create_user()
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.plan = create_plan()

    def test_list_subscriptions(self):
        create_subscription(user=self.user, plan=self.plan)
        response = self.client.get("/api/subscriptions/subscriptions/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_list_only_own_subscriptions(self):
        other_user = create_user()
        create_subscription(user=self.user, plan=self.plan)
        create_subscription(user=other_user, plan=self.plan)

        response = self.client.get("/api/subscriptions/subscriptions/")
        self.assertEqual(len(response.data["results"]), 1)

    @patch.object(SubscriptionService, "create_subscription")
    def test_create_subscription(self, mock_create):
        sub = create_subscription(user=self.user, plan=self.plan)
        create_payment(subscription=sub)
        mock_create.return_value = sub

        response = self.client.post(
            "/api/subscriptions/subscriptions/",
            {
                "plan_id": str(self.plan.id),
                "payment_type": "bank_transfer",
            },
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    @patch.object(SubscriptionService, "cancel_subscription")
    def test_cancel_subscription(self, mock_cancel):
        sub = create_subscription(user=self.user, plan=self.plan)
        mock_cancel.return_value = sub
        response = self.client.post(
            f"/api/subscriptions/subscriptions/{sub.pk}/cancel/",
            {"reason": "Testing", "immediate": False},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mock_cancel.assert_called_once()

    def test_unauthenticated_access(self):
        self.client.logout()
        response = self.client.get("/api/subscriptions/subscriptions/")
        self.assertIn(response.status_code, [status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN])


class PaymentViewSetTest(TestCase):
    def setUp(self):
        self.user = create_user()
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

    def test_list_payments(self):
        sub = create_subscription(user=self.user)
        create_payment(subscription=sub)
        response = self.client.get("/api/subscriptions/payments/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)


@override_settings(
    MIDTRANS_SERVER_KEY="SB-Mid-server-TEST",
    MIDTRANS_IS_PRODUCTION=False,
)
class WebhookViewTest(TestCase):
    def setUp(self):
        self.client = APIClient()

    @patch.object(SubscriptionService, "process_notification")
    def test_webhook_success(self, mock_process):
        from subscriptions.models import WebhookLog
        wl = WebhookLog.objects.create(
            order_id="ORDER-WH-001",
            transaction_status="settlement",
            payment_type="bank_transfer",
            gross_amount="100000",
            signature_key="test",
            raw_payload={},
            ip_address="127.0.0.1",
        )
        mock_process.return_value = wl
        notification = make_midtrans_notification(
            order_id="ORDER-WH-001",
            status="settlement",
        )
        response = self.client.post(
            "/api/subscriptions/webhook/notification/",
            data=json.dumps(notification),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        mock_process.assert_called_once()

    def test_webhook_empty_payload(self):
        response = self.client.post(
            "/api/subscriptions/webhook/notification/",
            data="{}",
            content_type="application/json",
        )
        self.assertIn(response.status_code, [status.HTTP_200_OK, status.HTTP_400_BAD_REQUEST])
