"""
Tests for the Midtrans API client.
"""
from unittest.mock import MagicMock, patch

from django.test import TestCase, override_settings

from subscriptions.client import MidtransAPIError, MidtransClient, get_midtrans_client


@override_settings(
    MIDTRANS_SERVER_KEY="SB-Mid-server-TEST",
    MIDTRANS_IS_PRODUCTION=False,
)
class MidtransClientTest(TestCase):
    def setUp(self):
        self.client = MidtransClient(
            server_key="SB-Mid-server-TEST",
            is_production=False,
        )

    def test_base_url_sandbox(self):
        self.assertIn("sandbox", self.client.base_url)

    @override_settings(
        MIDTRANS_IS_PRODUCTION=True,
        MIDTRANS_API_BASE_URL="https://api.midtrans.com",
    )
    def test_base_url_production(self):
        client = MidtransClient(server_key="key", is_production=True, base_url="https://api.midtrans.com")
        self.assertNotIn("sandbox", client.base_url)

    def test_verify_signature_valid(self):
        import hashlib
        order_id = "ORDER-001"
        status_code = "200"
        gross_amount = "100000"
        server_key = "SB-Mid-server-TEST"

        raw = f"{order_id}{status_code}{gross_amount}{server_key}"
        signature = hashlib.sha512(raw.encode()).hexdigest()

        result = MidtransClient.verify_signature(
            order_id=order_id,
            status_code=status_code,
            gross_amount=gross_amount,
            server_key=server_key,
            signature_key=signature,
        )
        self.assertTrue(result)

    def test_verify_signature_invalid(self):
        result = MidtransClient.verify_signature(
            order_id="ORDER-001",
            status_code="200",
            gross_amount="100000",
            server_key="SB-Mid-server-TEST",
            signature_key="invalid-signature",
        )
        self.assertFalse(result)

    @patch("subscriptions.client.requests.Session.request")
    def test_charge_bank_transfer(self, mock_request):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status_code": "201",
            "transaction_id": "tx-123",
            "order_id": "ORDER-001",
            "transaction_status": "pending",
        }
        mock_request.return_value = mock_response

        result = self.client.charge_bank_transfer(
            order_id="ORDER-001",
            amount=100000,
            bank="bca",
            customer_details={"first_name": "Test", "email": "test@test.com"},
        )
        self.assertEqual(result["transaction_status"], "pending")
        mock_request.assert_called_once()

    @patch("subscriptions.client.requests.Session.request")
    def test_get_transaction_status(self, mock_request):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status_code": "200",
            "transaction_status": "settlement",
            "order_id": "ORDER-001",
        }
        mock_request.return_value = mock_response

        result = self.client.get_transaction_status("ORDER-001")
        self.assertEqual(result["transaction_status"], "settlement")

    @patch("subscriptions.client.requests.Session.request")
    def test_api_error_handling(self, mock_request):
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.json.return_value = {
            "status_code": "400",
            "status_message": "Bad Request",
        }
        mock_request.return_value = mock_response

        with self.assertRaises(MidtransAPIError):
            self.client.get_transaction_status("INVALID-ORDER")


@override_settings(
    MIDTRANS_SERVER_KEY="SB-Mid-server-TEST",
    MIDTRANS_IS_PRODUCTION=False,
)
class GetMidtransClientTest(TestCase):
    def test_factory_returns_client(self):
        client = get_midtrans_client()
        self.assertIsInstance(client, MidtransClient)
