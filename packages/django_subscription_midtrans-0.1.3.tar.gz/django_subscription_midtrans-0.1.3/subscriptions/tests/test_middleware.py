"""
Tests for the subscription middleware.
"""
from django.test import TestCase, RequestFactory, override_settings

from subscriptions.middleware import SubscriptionAccessMiddleware
from subscriptions.models import Subscription

from .factories import create_subscription, create_user


@override_settings(
    SUBSCRIPTION_SETTINGS={
        "PROTECTED_PATHS": ["/api/premium/"],
        "SUBSCRIPTION_REQUIRED_REDIRECT": "/pricing/",
    }
)
class SubscriptionAccessMiddlewareTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.middleware = SubscriptionAccessMiddleware(lambda r: MagicMockResponse())
        self.user = create_user()

    def test_unprotected_path_allowed(self):
        request = self.factory.get("/api/public/data/")
        request.user = self.user
        response = self.middleware(request)
        self.assertEqual(response.status_code, 200)

    def test_protected_path_requires_auth(self):
        from django.contrib.auth.models import AnonymousUser
        request = self.factory.get("/api/premium/data/")
        request.user = AnonymousUser()
        response = self.middleware(request)
        self.assertEqual(response.status_code, 403)

    def test_protected_path_with_active_subscription(self):
        create_subscription(user=self.user, status=Subscription.Status.ACTIVE)
        request = self.factory.get("/api/premium/data/")
        request.user = self.user
        response = self.middleware(request)
        self.assertEqual(response.status_code, 200)

    def test_protected_path_without_subscription(self):
        request = self.factory.get("/api/premium/data/")
        request.user = self.user
        request.META["HTTP_ACCEPT"] = "application/json"
        response = self.middleware(request)
        self.assertEqual(response.status_code, 403)

    def test_staff_bypass(self):
        self.user.is_staff = True
        self.user.save()
        request = self.factory.get("/api/premium/data/")
        request.user = self.user
        response = self.middleware(request)
        self.assertEqual(response.status_code, 200)


class MagicMockResponse:
    status_code = 200
