"""
Test fixtures and helpers for subscription tests.
"""
import uuid
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.utils import timezone

from subscriptions.models import Invoice, InvoiceItem, Payment, Plan, Subscription

User = get_user_model()


def create_user(**kwargs):
    defaults = {
        "username": f"testuser_{uuid.uuid4().hex[:8]}",
        "email": f"test_{uuid.uuid4().hex[:8]}@example.com",
        "password": "testpass123",
    }
    defaults.update(kwargs)
    password = defaults.pop("password")
    user = User(**defaults)
    user.set_password(password)
    user.save()
    return user


def create_plan(**kwargs):
    defaults = {
        "name": f"Test Plan {uuid.uuid4().hex[:6]}",
        "slug": f"test-plan-{uuid.uuid4().hex[:6]}",
        "price": Decimal("100000"),
        "currency": "IDR",
        "interval": 1,
        "interval_unit": Plan.IntervalUnit.MONTH,
        "status": Plan.Status.ACTIVE,
    }
    defaults.update(kwargs)
    return Plan.objects.create(**defaults)


def create_subscription(user=None, plan=None, **kwargs):
    if user is None:
        user = create_user()
    if plan is None:
        plan = create_plan()

    now = timezone.now()
    defaults = {
        "user": user,
        "plan": plan,
        "status": Subscription.Status.ACTIVE,
        "payment_type": "bank_transfer",
        "current_period_start": now,
        "current_period_end": now + timedelta(days=30),
        "next_billing_date": now + timedelta(days=30),
        "customer_email": user.email,
    }
    defaults.update(kwargs)
    return Subscription.objects.create(**defaults)


def create_payment(subscription=None, **kwargs):
    if subscription is None:
        subscription = create_subscription()

    defaults = {
        "subscription": subscription,
        "user": subscription.user,
        "order_id": f"ORDER-{uuid.uuid4().hex[:12]}",
        "payment_type": "bank_transfer",
        "status": Payment.Status.PENDING,
        "gross_amount": subscription.plan.price,
        "currency": subscription.plan.currency,
    }
    defaults.update(kwargs)
    return Payment.objects.create(**defaults)


def create_invoice(subscription=None, **kwargs):
    if subscription is None:
        subscription = create_subscription()

    now = timezone.now()
    defaults = {
        "subscription": subscription,
        "user": subscription.user,
        "invoice_number": f"INV-{uuid.uuid4().hex[:10].upper()}",
        "status": Invoice.Status.ISSUED,
        "subtotal": subscription.plan.price,
        "total_amount": subscription.plan.price,
        "currency": subscription.plan.currency,
        "issue_date": now.date(),
        "due_date": (now + timedelta(days=7)).date(),
        "period_start": now.date(),
        "period_end": (now + timedelta(days=30)).date(),
    }
    defaults.update(kwargs)
    return Invoice.objects.create(**defaults)


def make_midtrans_notification(order_id, status="settlement", gross_amount="100000", **kwargs):
    """Create a mock Midtrans notification payload."""
    import hashlib
    from django.conf import settings

    server_key = getattr(settings, "MIDTRANS_SERVER_KEY", "test-server-key")
    status_code = {
        "capture": "200",
        "settlement": "200",
        "pending": "201",
        "deny": "202",
        "cancel": "202",
        "expire": "202",
        "refund": "200",
    }.get(status, "200")

    raw = f"{order_id}{status_code}{gross_amount}{server_key}"
    signature = hashlib.sha512(raw.encode()).hexdigest()

    payload = {
        "transaction_id": f"mt-{uuid.uuid4().hex[:16]}",
        "order_id": order_id,
        "transaction_status": status,
        "status_code": status_code,
        "gross_amount": gross_amount,
        "payment_type": "bank_transfer",
        "signature_key": signature,
        "fraud_status": "accept",
        "transaction_time": timezone.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    payload.update(kwargs)
    return payload
