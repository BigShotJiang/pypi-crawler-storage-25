"""
Middleware for subscription-based access control.
"""
from django.conf import settings
from django.http import JsonResponse
from django.utils import timezone

from .models import Subscription


class SubscriptionAccessMiddleware:
    """
    Middleware that checks if the authenticated user has an active subscription.

    Protected paths are configured via SUBSCRIPTION_SETTINGS["PROTECTED_PATHS"].
    Returns 403 JSON response for API requests and redirects for HTML requests.

    Usage in settings.py:

        MIDDLEWARE = [
            ...
            "subscriptions.middleware.SubscriptionAccessMiddleware",
        ]

        SUBSCRIPTION_SETTINGS = {
            ...
            "PROTECTED_PATHS": ["/api/premium/", "/dashboard/pro/"],
            "SUBSCRIPTION_REQUIRED_REDIRECT": "/pricing/",
        }
    """

    def __init__(self, get_response):
        self.get_response = get_response
        sub_settings = getattr(settings, "SUBSCRIPTION_SETTINGS", {})
        self.protected_paths = sub_settings.get("PROTECTED_PATHS", [])
        self.redirect_url = sub_settings.get("SUBSCRIPTION_REQUIRED_REDIRECT", "/pricing/")

    def __call__(self, request):
        if self.protected_paths and self._is_protected(request.path):
            if not request.user.is_authenticated:
                return self._deny(request, "Authentication required.")

            if not request.user.is_staff and not self._has_active_subscription(request.user):
                return self._deny(request, "Active subscription required.")

        return self.get_response(request)

    def _is_protected(self, path: str) -> bool:
        return any(path.startswith(p) for p in self.protected_paths)

    def _has_active_subscription(self, user) -> bool:
        return Subscription.objects.filter(
            user=user,
            status__in=[Subscription.Status.ACTIVE, Subscription.Status.TRIALING],
        ).exists()

    def _deny(self, request, message: str):
        is_api = (
            request.content_type == "application/json"
            or request.path.startswith("/api/")
            or request.headers.get("Accept", "").startswith("application/json")
        )
        if is_api:
            return JsonResponse(
                {"error": message, "code": "subscription_required"},
                status=403,
            )
        from django.shortcuts import redirect
        return redirect(self.redirect_url)
