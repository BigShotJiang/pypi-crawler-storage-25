"""
Subscription service layer.

Orchestrates all business logic between Django models and Midtrans API.
Designed to be the single entry point for subscription operations.
"""
import logging
import uuid
from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from .client import MidtransClient, MidtransAPIError, get_midtrans_client
from .models import (
    Invoice,
    InvoiceItem,
    NotificationLog,
    Payment,
    Plan,
    Subscription,
    TopUp,
    Wallet,
    WalletTransaction,
    WebhookLog,
)

logger = logging.getLogger("subscriptions")


def _get_subscription_settings():
    return getattr(settings, "SUBSCRIPTION_SETTINGS", {})


def _generate_order_id(prefix: str = "SUB") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12].upper()}"


def _generate_invoice_number() -> str:
    prefix = _get_subscription_settings().get("INVOICE_NUMBER_PREFIX", "INV")
    now = timezone.now()
    seq = Invoice.objects.filter(
        issue_date__year=now.year, issue_date__month=now.month
    ).count() + 1
    return f"{prefix}-{now.strftime('%Y%m')}-{seq:05d}"


def _calculate_next_period_end(start: timezone.datetime, plan: Plan) -> timezone.datetime:
    """Calculate next period end based on plan interval."""
    if plan.interval_unit == Plan.IntervalUnit.DAY:
        return start + timedelta(days=plan.interval)
    elif plan.interval_unit == Plan.IntervalUnit.WEEK:
        return start + timedelta(weeks=plan.interval)
    elif plan.interval_unit == Plan.IntervalUnit.MONTH:
        # Approximate month calculation
        return start + timedelta(days=30 * plan.interval)
    return start + timedelta(days=30)


class SubscriptionService:
    """
    High-level subscription management service.

    Usage:
        service = SubscriptionService()
        subscription = service.create_subscription(user, plan, payment_type, ...)
        service.pause_subscription(subscription)
        service.cancel_subscription(subscription, reason="...")
    """

    def __init__(self, client: MidtransClient = None):
        self.client = client or get_midtrans_client()

    # ─── Subscription Creation ────────────────────────────────────────────

    @transaction.atomic
    def create_subscription(
        self,
        user,
        plan: Plan,
        payment_type: str,
        token: str = None,
        gopay_account_id: str = None,
        customer_details: dict = None,
        metadata: dict = None,
    ) -> Subscription:
        """
        Create a new subscription and register it with Midtrans.

        For credit_card: requires a saved token_id from initial charge.
        For gopay: requires account_id from GoPay account linking.
        For bank_transfer/qris/etc.: creates a one-time charge per cycle (no native Midtrans subscription).
        """
        now = timezone.now()
        trial_end = None
        initial_status = Subscription.Status.PENDING

        if plan.trial_period_days > 0:
            trial_end = now + timedelta(days=plan.trial_period_days)
            initial_status = Subscription.Status.TRIALING

        cust = customer_details or {}

        subscription = Subscription.objects.create(
            user=user,
            plan=plan,
            status=initial_status,
            payment_type=payment_type,
            midtrans_token=token or gopay_account_id or "",
            current_period_start=now,
            current_period_end=trial_end or _calculate_next_period_end(now, plan),
            trial_end=trial_end,
            next_billing_date=trial_end or now,
            customer_first_name=cust.get("first_name", getattr(user, "first_name", "")),
            customer_last_name=cust.get("last_name", getattr(user, "last_name", "")),
            customer_email=cust.get("email", getattr(user, "email", "")),
            customer_phone=cust.get("phone", ""),
            metadata=metadata or {},
        )

        # For payment types that support native Midtrans subscriptions
        # Only GoPay with linked account_id supports native recurring
        if payment_type == "gopay" and gopay_account_id:
            try:
                midtrans_sub = self._create_midtrans_subscription(subscription, plan)
                subscription.midtrans_subscription_id = midtrans_sub.get("id", "")
                subscription.save(update_fields=["midtrans_subscription_id"])
            except MidtransAPIError as e:
                logger.error("Failed to create Midtrans subscription: %s", e)
                subscription.metadata["midtrans_error"] = str(e)
                subscription.save(update_fields=["metadata"])
        else:
            # One-time charge for all other payment types (including credit_card)
            self._create_initial_charge(subscription)

        return subscription

    def _create_midtrans_subscription(self, subscription: Subscription, plan: Plan) -> dict:
        sub_settings = _get_subscription_settings()
        schedule = {
            "interval": plan.interval,
            "interval_unit": plan.interval_unit,
        }
        if plan.max_cycles > 0:
            schedule["max_interval"] = plan.max_cycles

        retry_schedule = None
        if sub_settings.get("AUTO_RETRY_FAILED_PAYMENTS", True):
            retry_schedule = {
                "interval": sub_settings.get("RETRY_INTERVAL_DAYS", 1),
                "interval_unit": "day",
                "max_interval": sub_settings.get("MAX_RETRY_ATTEMPTS", 3),
            }

        customer_details = {
            "first_name": subscription.customer_first_name,
            "last_name": subscription.customer_last_name,
            "email": subscription.customer_email,
            "phone": subscription.customer_phone,
        }

        return self.client.create_subscription(
            name=f"{subscription.plan.name} - {subscription.user}",
            amount=int(plan.price),
            currency=plan.currency,
            payment_type=subscription.payment_type,
            token=subscription.midtrans_token if subscription.payment_type == "credit_card" else None,
            gopay_account_id=subscription.midtrans_token if subscription.payment_type == "gopay" else None,
            schedule=schedule,
            retry_schedule=retry_schedule,
            customer_details=customer_details,
            notification_url=settings.MIDTRANS_NOTIFICATION_URL or None,
        )

    def _create_initial_charge(self, subscription: Subscription) -> Payment:
        """Create initial payment charge for non-native subscription types."""
        return self.create_charge_for_subscription(subscription)

    # ─── Charge Creation ──────────────────────────────────────────────────

    @transaction.atomic
    def create_charge_for_subscription(
        self,
        subscription: Subscription,
        is_retry: bool = False,
        retry_count: int = 0,
    ) -> Payment:
        """
        Create a one-time charge for a subscription billing cycle.
        Used for payment types without native Midtrans subscription support.
        """
        order_id = _generate_order_id("SUB")
        amount = int(subscription.plan.price)
        payment_type = subscription.payment_type

        payment = Payment.objects.create(
            subscription=subscription,
            user=subscription.user,
            order_id=order_id,
            payment_type=payment_type,
            status=Payment.Status.PENDING,
            gross_amount=Decimal(str(amount)),
            currency=subscription.plan.currency,
            is_retry=is_retry,
            retry_count=retry_count,
            metadata={
                "subscription_id": str(subscription.id),
                "plan_id": str(subscription.plan.id),
                "billing_cycle": subscription.billing_cycle_count + 1,
            },
        )

        customer_details = {
            "first_name": subscription.customer_first_name,
            "last_name": subscription.customer_last_name,
            "email": subscription.customer_email,
            "phone": subscription.customer_phone,
        }

        item_details = [{
            "id": str(subscription.plan.id),
            "name": subscription.plan.name,
            "price": amount,
            "quantity": 1,
        }]

        notification_url = settings.MIDTRANS_NOTIFICATION_URL or None

        try:
            if payment_type == "credit_card":
                response = self.client.charge_credit_card(
                    order_id=order_id,
                    amount=amount,
                    token_id=subscription.midtrans_token,
                    customer_details=customer_details,
                    notification_url=notification_url,
                )
            elif payment_type == "bank_transfer":
                bank = subscription.metadata.get("bank", "bca")
                response = self.client.charge_bank_transfer(
                    order_id=order_id,
                    amount=amount,
                    bank=bank,
                    customer_details=customer_details,
                    item_details=item_details,
                    notification_url=notification_url,
                )
            elif payment_type == "echannel":
                response = self.client.charge_echannel(
                    order_id=order_id,
                    amount=amount,
                    customer_details=customer_details,
                    notification_url=notification_url,
                )
            elif payment_type == "gopay":
                response = self.client.charge_gopay(
                    order_id=order_id,
                    amount=amount,
                    customer_details=customer_details,
                    notification_url=notification_url,
                )
            elif payment_type == "shopeepay":
                callback_url = subscription.metadata.get("callback_url", "")
                response = self.client.charge_shopeepay(
                    order_id=order_id,
                    amount=amount,
                    callback_url=callback_url,
                    customer_details=customer_details,
                    notification_url=notification_url,
                )
            elif payment_type == "qris":
                response = self.client.charge_qris(
                    order_id=order_id,
                    amount=amount,
                    customer_details=customer_details,
                    notification_url=notification_url,
                )
            else:
                # Generic charge
                response = self.client.charge({
                    "payment_type": payment_type,
                    "transaction_details": {
                        "order_id": order_id,
                        "gross_amount": amount,
                    },
                    "customer_details": customer_details,
                })

            # Update payment with response
            payment.midtrans_transaction_id = response.get("transaction_id", "")
            payment.status = response.get("transaction_status", Payment.Status.PENDING)
            payment.fraud_status = response.get("fraud_status", "")
            payment.midtrans_response = response
            payment.payment_details = self._extract_payment_details(response, payment_type)

            if response.get("transaction_time"):
                from django.utils.dateparse import parse_datetime
                payment.transaction_time = parse_datetime(
                    response["transaction_time"].replace(" +0700", "+07:00")
                ) or timezone.now()

            payment.save()

        except MidtransAPIError as e:
            payment.status = Payment.Status.FAILURE
            payment.midtrans_response = e.response_data
            payment.metadata["error"] = str(e)
            payment.save()
            logger.error("Charge failed for order %s: %s", order_id, e)

        # Auto-generate invoice
        if _get_subscription_settings().get("AUTO_GENERATE_INVOICE", True):
            self._generate_invoice_for_payment(payment, subscription)

        return payment

    def _extract_payment_details(self, response: dict, payment_type: str) -> dict:
        """Extract user-facing payment details from Midtrans response."""
        details = {}
        if payment_type == "bank_transfer":
            va_numbers = response.get("va_numbers", [])
            if va_numbers:
                details["bank"] = va_numbers[0].get("bank", "")
                details["va_number"] = va_numbers[0].get("va_number", "")
            # Permata
            if response.get("permata_va_number"):
                details["bank"] = "permata"
                details["va_number"] = response["permata_va_number"]
        elif payment_type == "echannel":
            details["bill_key"] = response.get("bill_key", "")
            details["biller_code"] = response.get("biller_code", "")
        elif payment_type in ("gopay", "shopeepay", "qris"):
            actions = response.get("actions", [])
            for action in actions:
                # Convert hyphenated keys to underscored for Django template compatibility
                key = action["name"].replace("-", "_")
                details[key] = action["url"]
        elif payment_type == "credit_card":
            details["redirect_url"] = response.get("redirect_url", "")
        return details

    # ─── Subscription Management ──────────────────────────────────────────

    @transaction.atomic
    def activate_subscription(self, subscription: Subscription) -> Subscription:
        """Activate a subscription after successful payment."""
        now = timezone.now()
        subscription.status = Subscription.Status.ACTIVE
        subscription.current_period_start = now
        subscription.current_period_end = _calculate_next_period_end(now, subscription.plan)
        subscription.next_billing_date = subscription.current_period_end
        subscription.billing_cycle_count += 1
        subscription.save(update_fields=[
            "status", "current_period_start", "current_period_end",
            "next_billing_date", "billing_cycle_count", "updated_at",
        ])
        return subscription

    @transaction.atomic
    def renew_subscription(self, subscription: Subscription) -> Subscription:
        """Renew a subscription for the next billing cycle."""
        start = subscription.current_period_end or timezone.now()
        subscription.current_period_start = start
        subscription.current_period_end = _calculate_next_period_end(start, subscription.plan)
        subscription.next_billing_date = subscription.current_period_end
        subscription.billing_cycle_count += 1
        subscription.status = Subscription.Status.ACTIVE
        subscription.save(update_fields=[
            "status", "current_period_start", "current_period_end",
            "next_billing_date", "billing_cycle_count", "updated_at",
        ])
        return subscription

    @transaction.atomic
    def pause_subscription(self, subscription: Subscription) -> Subscription:
        """Pause (disable) a subscription."""
        if subscription.midtrans_subscription_id:
            try:
                self.client.disable_subscription(subscription.midtrans_subscription_id)
            except MidtransAPIError as e:
                logger.error("Failed to disable Midtrans subscription: %s", e)

        subscription.status = Subscription.Status.PAUSED
        subscription.save(update_fields=["status", "updated_at"])
        return subscription

    @transaction.atomic
    def resume_subscription(self, subscription: Subscription) -> Subscription:
        """Resume a paused subscription."""
        if subscription.midtrans_subscription_id:
            try:
                self.client.enable_subscription(subscription.midtrans_subscription_id)
            except MidtransAPIError as e:
                logger.error("Failed to enable Midtrans subscription: %s", e)

        subscription.status = Subscription.Status.ACTIVE
        subscription.save(update_fields=["status", "updated_at"])
        return subscription

    @transaction.atomic
    def cancel_subscription(
        self,
        subscription: Subscription,
        reason: str = "",
        immediate: bool = False,
    ) -> Subscription:
        """
        Cancel a subscription.
        If immediate=True, cancel now. Otherwise, cancel at period end.
        """
        if subscription.midtrans_subscription_id:
            try:
                self.client.cancel_subscription(subscription.midtrans_subscription_id)
            except MidtransAPIError as e:
                logger.error("Failed to cancel Midtrans subscription: %s", e)

        subscription.cancellation_reason = reason
        subscription.cancelled_at = timezone.now()

        if immediate:
            subscription.status = Subscription.Status.CANCELLED
        else:
            subscription.cancel_at_period_end = True

        subscription.save(update_fields=[
            "status", "cancel_at_period_end", "cancelled_at",
            "cancellation_reason", "updated_at",
        ])
        return subscription

    @transaction.atomic
    def expire_subscription(self, subscription: Subscription) -> Subscription:
        """Mark a subscription as expired."""
        subscription.status = Subscription.Status.EXPIRED
        subscription.save(update_fields=["status", "updated_at"])
        return subscription

    @transaction.atomic
    def mark_past_due(self, subscription: Subscription) -> Subscription:
        """Mark a subscription as past due (payment failed)."""
        subscription.status = Subscription.Status.PAST_DUE
        subscription.save(update_fields=["status", "updated_at"])
        return subscription

    @transaction.atomic
    def change_plan(
        self,
        subscription: Subscription,
        new_plan: Plan,
        immediate: bool = True,
    ) -> Subscription:
        """Change the subscription plan."""
        old_plan = subscription.plan
        subscription.plan = new_plan

        if immediate:
            now = timezone.now()
            subscription.current_period_start = now
            subscription.current_period_end = _calculate_next_period_end(now, new_plan)
            subscription.next_billing_date = subscription.current_period_end

        # Update on Midtrans if there's a native subscription
        if subscription.midtrans_subscription_id:
            try:
                self.client.update_subscription(
                    subscription.midtrans_subscription_id,
                    {
                        "name": f"{new_plan.name} - {subscription.user}",
                        "amount": str(int(new_plan.price)),
                        "schedule": {
                            "interval": new_plan.interval,
                            "interval_unit": new_plan.interval_unit,
                        },
                    },
                )
            except MidtransAPIError as e:
                logger.error("Failed to update Midtrans subscription: %s", e)

        subscription.metadata["plan_change_history"] = subscription.metadata.get("plan_change_history", [])
        subscription.metadata["plan_change_history"].append({
            "from": str(old_plan.id),
            "to": str(new_plan.id),
            "changed_at": timezone.now().isoformat(),
        })

        subscription.save()
        return subscription

    def sync_subscription_status(self, subscription: Subscription) -> Subscription:
        """Sync subscription status from Midtrans."""
        if not subscription.midtrans_subscription_id:
            return subscription

        try:
            data = self.client.get_subscription(subscription.midtrans_subscription_id)
            midtrans_status = data.get("status", "")
            status_map = {
                "active": Subscription.Status.ACTIVE,
                "inactive": Subscription.Status.PAUSED,
                "cancelled": Subscription.Status.CANCELLED,
            }
            if midtrans_status in status_map:
                subscription.status = status_map[midtrans_status]
                subscription.save(update_fields=["status", "updated_at"])
        except MidtransAPIError as e:
            logger.error("Failed syncing subscription %s: %s", subscription.id, e)

        return subscription

    # ─── Refund ───────────────────────────────────────────────────────────

    @transaction.atomic
    def refund_payment(
        self,
        payment: Payment,
        amount: int = None,
        reason: str = "",
        direct: bool = False,
    ) -> Payment:
        """Refund a payment (full or partial)."""
        refund_amount = amount or int(payment.gross_amount)

        try:
            if direct:
                response = self.client.direct_refund_transaction(
                    order_id=payment.order_id,
                    amount=refund_amount,
                    reason=reason,
                )
            else:
                response = self.client.refund_transaction(
                    order_id=payment.order_id,
                    amount=refund_amount,
                    reason=reason,
                )

            payment.refund_amount += Decimal(str(refund_amount))
            if payment.refund_amount >= payment.gross_amount:
                payment.status = Payment.Status.REFUND
            else:
                payment.status = Payment.Status.PARTIAL_REFUND
            payment.midtrans_response = response
            payment.save()

        except MidtransAPIError as e:
            logger.error("Refund failed for %s: %s", payment.order_id, e)
            raise

        return payment

    # ─── Invoice Generation ───────────────────────────────────────────────

    @transaction.atomic
    def _generate_invoice_for_payment(
        self,
        payment: Payment,
        subscription: Subscription,
    ) -> Invoice:
        """Generate invoice for a payment."""
        invoice_number = _generate_invoice_number()
        now = timezone.now()
        due_date = now.date() + timedelta(
            minutes=_get_subscription_settings().get("PAYMENT_EXPIRY_MINUTES", 60)
        )

        period_start = subscription.current_period_start or now
        period_end = subscription.current_period_end or _calculate_next_period_end(now, subscription.plan)

        invoice = Invoice.objects.create(
            invoice_number=invoice_number,
            subscription=subscription,
            payment=payment,
            user=subscription.user,
            status=Invoice.Status.ISSUED,
            subtotal=payment.gross_amount,
            total_amount=payment.gross_amount,
            currency=payment.currency,
            issue_date=now.date(),
            due_date=due_date,
            period_start=period_start,
            period_end=period_end,
        )

        InvoiceItem.objects.create(
            invoice=invoice,
            description=f"Subscription: {subscription.plan.name}",
            quantity=1,
            unit_price=payment.gross_amount,
            total_price=payment.gross_amount,
        )

        return invoice

    def mark_invoice_paid(self, payment: Payment) -> None:
        """Mark invoice as paid when payment succeeds."""
        try:
            invoice = payment.invoice
            if invoice:
                invoice.status = Invoice.Status.PAID
                invoice.paid_date = timezone.now().date()
                invoice.save(update_fields=["status", "paid_date", "updated_at"])
        except Invoice.DoesNotExist:
            pass

    def void_invoice(self, invoice: Invoice, reason: str = "") -> Invoice:
        """Void an invoice."""
        invoice.status = Invoice.Status.VOID
        invoice.void_reason = reason
        invoice.save(update_fields=["status", "void_reason", "updated_at"])
        return invoice

    # ─── Webhook Processing ───────────────────────────────────────────────

    @transaction.atomic
    def process_notification(self, payload: dict, ip_address: str = None) -> WebhookLog:
        """
        Process incoming Midtrans webhook notification.
        Verifies signature, updates payment status, and triggers side effects.
        """
        order_id = payload.get("order_id", "")
        transaction_status = payload.get("transaction_status", "")
        status_code = payload.get("status_code", "")
        gross_amount = payload.get("gross_amount", "")
        signature_key = payload.get("signature_key", "")
        fraud_status = payload.get("fraud_status", "")
        payment_type = payload.get("payment_type", "")
        transaction_id = payload.get("transaction_id", "")

        # Create webhook log
        webhook_log = WebhookLog.objects.create(
            order_id=order_id,
            midtrans_transaction_id=transaction_id,
            transaction_status=transaction_status,
            payment_type=payment_type,
            fraud_status=fraud_status,
            gross_amount=gross_amount,
            signature_key=signature_key,
            raw_payload=payload,
            ip_address=ip_address,
        )

        # Verify signature
        if not MidtransClient.verify_signature(
            order_id=order_id,
            status_code=status_code,
            gross_amount=gross_amount,
            signature_key=signature_key,
        ):
            webhook_log.status = WebhookLog.Status.INVALID
            webhook_log.error_message = "Invalid signature"
            webhook_log.save(update_fields=["status", "error_message"])
            logger.warning("Invalid signature for order_id=%s", order_id)
            return webhook_log

        # Check for duplicate
        existing = WebhookLog.objects.filter(
            order_id=order_id,
            transaction_status=transaction_status,
            status=WebhookLog.Status.PROCESSED,
        ).exclude(pk=webhook_log.pk).exists()

        if existing:
            webhook_log.status = WebhookLog.Status.DUPLICATE
            webhook_log.save(update_fields=["status"])
            return webhook_log

        # Process the notification
        try:
            self._handle_transaction_status(
                order_id=order_id,
                transaction_status=transaction_status,
                fraud_status=fraud_status,
                payment_type=payment_type,
                payload=payload,
            )
            webhook_log.status = WebhookLog.Status.PROCESSED
            webhook_log.processed_at = timezone.now()
        except Exception as e:
            webhook_log.status = WebhookLog.Status.FAILED
            webhook_log.error_message = str(e)
            logger.exception("Error processing webhook for order %s", order_id)

        webhook_log.save(update_fields=["status", "error_message", "processed_at"])
        return webhook_log

    def _handle_transaction_status(
        self,
        order_id: str,
        transaction_status: str,
        fraud_status: str,
        payment_type: str,
        payload: dict,
    ):
        """Handle various transaction status changes."""
        # Route top-up notifications to the wallet service
        if order_id.startswith("TOPUP-"):
            WalletService(self.client)._handle_topup_notification(
                order_id=order_id,
                transaction_status=transaction_status,
                fraud_status=fraud_status,
                payload=payload,
            )
            return

        try:
            payment = Payment.objects.select_related("subscription", "subscription__plan").get(
                order_id=order_id
            )
        except Payment.DoesNotExist:
            logger.warning("Payment not found for order_id=%s", order_id)
            return

        old_status = payment.status
        subscription = payment.subscription

        # Update payment
        payment.status = transaction_status
        payment.fraud_status = fraud_status
        payment.midtrans_transaction_id = payload.get("transaction_id", payment.midtrans_transaction_id)

        if payload.get("settlement_time"):
            from django.utils.dateparse import parse_datetime
            payment.settlement_time = parse_datetime(
                payload["settlement_time"].replace(" +0700", "+07:00")
            )

        payment.midtrans_response = payload
        payment.save()

        # Handle subscription side effects
        if not subscription:
            return

        if transaction_status == "capture":
            if payment_type == "credit_card" and fraud_status == "accept":
                self.activate_subscription(subscription)
                self.mark_invoice_paid(payment)
                self._create_notification(
                    subscription, payment, NotificationLog.NotificationType.PAYMENT_SUCCESS
                )
        elif transaction_status == "settlement":
            self.activate_subscription(subscription)
            self.mark_invoice_paid(payment)
            self._create_notification(
                subscription, payment, NotificationLog.NotificationType.PAYMENT_SUCCESS
            )
        elif transaction_status == "pending":
            self._create_notification(
                subscription, payment, NotificationLog.NotificationType.PAYMENT_PENDING
            )
        elif transaction_status in ("deny", "cancel", "expire"):
            self.mark_past_due(subscription)
            self._create_notification(
                subscription, payment, NotificationLog.NotificationType.PAYMENT_FAILED
            )
        elif transaction_status in ("refund", "partial_refund"):
            payment.refund_amount = Decimal(payload.get("refund_amount", "0") or "0")
            payment.save(update_fields=["refund_amount"])
            self._create_notification(
                subscription, payment, NotificationLog.NotificationType.REFUND_PROCESSED
            )

    def _create_notification(
        self,
        subscription: Subscription,
        payment: Payment,
        notification_type: str,
    ):
        """Create a notification log entry."""
        NotificationLog.objects.create(
            user=subscription.user,
            subscription=subscription,
            payment=payment,
            notification_type=notification_type,
            channel=NotificationLog.Channel.IN_APP,
            status=NotificationLog.Status.QUEUED,
            recipient=subscription.customer_email,
            subject=f"{notification_type.replace('_', ' ').title()} - {subscription.plan.name}",
            metadata={
                "order_id": payment.order_id if payment else None,
                "plan_name": subscription.plan.name,
                "amount": str(payment.gross_amount) if payment else None,
            },
        )

    # ─── Query Helpers ────────────────────────────────────────────────────

    @staticmethod
    def get_active_subscription(user) -> Subscription:
        """Get the user's active subscription."""
        return Subscription.objects.filter(
            user=user,
            status__in=[Subscription.Status.ACTIVE, Subscription.Status.TRIALING],
        ).select_related("plan").first()

    @staticmethod
    def get_subscriptions_due_for_billing():
        """Get subscriptions that need billing."""
        now = timezone.now()
        return Subscription.objects.filter(
            status=Subscription.Status.ACTIVE,
            next_billing_date__lte=now,
            cancel_at_period_end=False,
        ).select_related("plan", "user")

    @staticmethod
    def get_expiring_subscriptions(days: int):
        """Get subscriptions expiring within N days."""
        now = timezone.now()
        cutoff = now + timedelta(days=days)
        return Subscription.objects.filter(
            status=Subscription.Status.ACTIVE,
            current_period_end__lte=cutoff,
            current_period_end__gt=now,
        ).select_related("plan", "user")

    @staticmethod
    def get_subscriptions_to_cancel():
        """Get subscriptions marked for cancellation at period end."""
        now = timezone.now()
        return Subscription.objects.filter(
            cancel_at_period_end=True,
            current_period_end__lte=now,
            status__in=[Subscription.Status.ACTIVE, Subscription.Status.PAST_DUE],
        ).select_related("plan", "user")

    @staticmethod
    def get_overdue_invoices():
        """Get overdue invoices."""
        today = timezone.now().date()
        return Invoice.objects.filter(
            status=Invoice.Status.ISSUED,
            due_date__lt=today,
        ).select_related("subscription", "user")


# ─── Wallet Service ───────────────────────────────────────────────────────────


class WalletService:
    """
    Service for wallet/balance management.

    Handles:
    - Wallet creation and retrieval
    - Top-up via Midtrans payment
    - Balance crediting/debiting
    - Subscription payment from wallet
    - Top-up webhook processing
    """

    def __init__(self, client: MidtransClient = None):
        self.client = client or get_midtrans_client()

    # ─── Wallet Management ────────────────────────────────────────────────

    @staticmethod
    def get_or_create_wallet(user) -> Wallet:
        """Get or create a wallet for a user."""
        wallet, created = Wallet.objects.get_or_create(
            user=user,
            defaults={"currency": _get_subscription_settings().get("CURRENCY", "IDR")},
        )
        return wallet

    @staticmethod
    def get_wallet(user) -> Wallet:
        """Get wallet for user, returns None if not found."""
        try:
            return Wallet.objects.get(user=user)
        except Wallet.DoesNotExist:
            return None

    # ─── Top-Up ───────────────────────────────────────────────────────────

    @transaction.atomic
    def create_topup(
        self,
        user,
        amount: int,
        payment_type: str,
        bank: str = None,
        callback_url: str = None,
        customer_details: dict = None,
        token: str = None,
    ) -> TopUp:
        """
        Create a top-up request and charge via Midtrans.

        Returns a TopUp object with payment details (VA number, QR code, etc.).
        """
        wallet = self.get_or_create_wallet(user)
        order_id = _generate_order_id("TOPUP")

        topup = TopUp.objects.create(
            wallet=wallet,
            user=user,
            amount=Decimal(str(amount)),
            payment_type=payment_type,
            status=TopUp.Status.PENDING,
            order_id=order_id,
        )

        # Convert to int for Midtrans API (Decimal is not JSON serializable)
        charge_amount = int(amount)

        cust = customer_details or {}
        cust_details = {
            "first_name": cust.get("first_name", getattr(user, "first_name", "")),
            "last_name": cust.get("last_name", getattr(user, "last_name", "")),
            "email": cust.get("email", getattr(user, "email", "")),
            "phone": cust.get("phone", ""),
        }

        item_details = [{
            "id": "topup",
            "name": f"Wallet Top Up - {charge_amount:,}",
            "price": charge_amount,
            "quantity": 1,
        }]

        notification_url = settings.MIDTRANS_NOTIFICATION_URL or None

        try:
            if payment_type == "credit_card":
                response = self.client.charge_credit_card(
                    order_id=order_id,
                    amount=charge_amount,
                    token_id=token or "",
                    customer_details=cust_details,
                    item_details=item_details,
                    notification_url=notification_url,
                )
            elif payment_type == "bank_transfer":
                response = self.client.charge_bank_transfer(
                    order_id=order_id,
                    amount=charge_amount,
                    bank=bank or "bca",
                    customer_details=cust_details,
                    item_details=item_details,
                    notification_url=notification_url,
                )
            elif payment_type == "echannel":
                response = self.client.charge_echannel(
                    order_id=order_id,
                    amount=charge_amount,
                    customer_details=cust_details,
                    notification_url=notification_url,
                )
            elif payment_type == "gopay":
                response = self.client.charge_gopay(
                    order_id=order_id,
                    amount=charge_amount,
                    callback_url=callback_url or "",
                    customer_details=cust_details,
                    notification_url=notification_url,
                )
            elif payment_type == "shopeepay":
                response = self.client.charge_shopeepay(
                    order_id=order_id,
                    amount=charge_amount,
                    callback_url=callback_url or "",
                    customer_details=cust_details,
                    notification_url=notification_url,
                )
            elif payment_type == "qris":
                response = self.client.charge_qris(
                    order_id=order_id,
                    amount=charge_amount,
                    customer_details=cust_details,
                    notification_url=notification_url,
                )
            else:
                response = self.client.charge({
                    "payment_type": payment_type,
                    "transaction_details": {"order_id": order_id, "gross_amount": charge_amount},
                    "customer_details": cust_details,
                })

            topup.midtrans_transaction_id = response.get("transaction_id", "")
            topup.midtrans_response = response
            topup.payment_details = SubscriptionService()._extract_payment_details(
                response, payment_type
            )
            topup.save()

        except MidtransAPIError as e:
            topup.status = TopUp.Status.FAILED
            topup.midtrans_response = e.response_data
            topup.metadata["error"] = str(e)
            topup.save()
            logger.error("Top-up charge failed for %s: %s", order_id, e)

        return topup

    # ─── Balance Operations ───────────────────────────────────────────────

    @transaction.atomic
    def credit_wallet(
        self,
        wallet: Wallet,
        amount: Decimal,
        transaction_type: str,
        reference_type: str = "",
        reference_id: str = "",
        description: str = "",
    ) -> WalletTransaction:
        """
        Credit (add) funds to a wallet.

        Uses select_for_update to prevent race conditions.
        """
        wallet = Wallet.objects.select_for_update().get(pk=wallet.pk)
        balance_before = wallet.balance
        wallet.balance += amount
        wallet.save(update_fields=["balance", "updated_at"])

        txn = WalletTransaction.objects.create(
            wallet=wallet,
            transaction_type=transaction_type,
            amount=amount,
            balance_before=balance_before,
            balance_after=wallet.balance,
            reference_type=reference_type,
            reference_id=reference_id,
            description=description,
        )

        logger.info(
            "Wallet %s credited %s. Balance: %s -> %s",
            wallet.id, amount, balance_before, wallet.balance,
        )
        return txn

    @transaction.atomic
    def debit_wallet(
        self,
        wallet: Wallet,
        amount: Decimal,
        transaction_type: str,
        reference_type: str = "",
        reference_id: str = "",
        description: str = "",
    ) -> WalletTransaction:
        """
        Debit (deduct) funds from a wallet.

        Raises ValueError if insufficient balance.
        Uses select_for_update to prevent race conditions.
        """
        wallet = Wallet.objects.select_for_update().get(pk=wallet.pk)

        if wallet.balance < amount:
            raise ValueError(
                f"Insufficient wallet balance. Required: {amount}, Available: {wallet.balance}"
            )

        balance_before = wallet.balance
        wallet.balance -= amount
        wallet.save(update_fields=["balance", "updated_at"])

        txn = WalletTransaction.objects.create(
            wallet=wallet,
            transaction_type=transaction_type,
            amount=-amount,  # Negative for debit
            balance_before=balance_before,
            balance_after=wallet.balance,
            reference_type=reference_type,
            reference_id=reference_id,
            description=description,
        )

        logger.info(
            "Wallet %s debited %s. Balance: %s -> %s",
            wallet.id, amount, balance_before, wallet.balance,
        )
        return txn

    # ─── Subscription Payment from Wallet ─────────────────────────────────

    @transaction.atomic
    def pay_subscription_from_wallet(self, subscription: Subscription) -> WalletTransaction:
        """
        Pay a subscription from the user's wallet balance.

        Debits the wallet, activates the subscription, and generates an invoice.
        Returns the WalletTransaction if successful.
        Raises ValueError if balance is insufficient.
        """
        wallet = self.get_or_create_wallet(subscription.user)
        amount = subscription.plan.price

        if not wallet.can_afford(amount):
            raise ValueError(
                f"Insufficient balance. Required: {amount}, Available: {wallet.balance}"
            )

        # Debit wallet
        txn = self.debit_wallet(
            wallet=wallet,
            amount=amount,
            transaction_type=WalletTransaction.TransactionType.SUBSCRIPTION_PAYMENT,
            reference_type="subscription",
            reference_id=str(subscription.id),
            description=f"Subscription payment: {subscription.plan.name}",
        )

        # Activate or renew subscription
        sub_service = SubscriptionService(self.client)
        now = timezone.now()
        if subscription.status in (Subscription.Status.PENDING, Subscription.Status.PAST_DUE):
            sub_service.activate_subscription(subscription)
        elif subscription.status == Subscription.Status.ACTIVE:
            sub_service.renew_subscription(subscription)
        else:
            subscription.status = Subscription.Status.ACTIVE
            subscription.current_period_start = now
            subscription.current_period_end = _calculate_next_period_end(now, subscription.plan)
            subscription.next_billing_date = subscription.current_period_end
            subscription.billing_cycle_count += 1
            subscription.save(update_fields=[
                "status", "current_period_start", "current_period_end",
                "next_billing_date", "billing_cycle_count", "updated_at",
            ])

        # Create an internal payment record for tracking
        payment = Payment.objects.create(
            subscription=subscription,
            user=subscription.user,
            order_id=f"WALLET-{uuid.uuid4().hex[:12].upper()}",
            payment_type="wallet",
            status=Payment.Status.SETTLEMENT,
            gross_amount=amount,
            currency=subscription.plan.currency,
            settlement_time=now,
            transaction_time=now,
            payment_details={"wallet_transaction_id": str(txn.id)},
            metadata={"paid_from_wallet": True},
        )

        # Generate invoice
        if _get_subscription_settings().get("AUTO_GENERATE_INVOICE", True):
            sub_service._generate_invoice_for_payment(payment, subscription)
            sub_service.mark_invoice_paid(payment)

        logger.info(
            "Subscription %s paid from wallet. Amount: %s",
            subscription.id, amount,
        )
        return txn

    @transaction.atomic
    def create_subscription_from_wallet(
        self,
        user,
        plan: Plan,
        customer_details: dict = None,
        metadata: dict = None,
    ) -> Subscription:
        """
        Create a new subscription paid from wallet balance.

        Creates subscription, debits wallet, and activates immediately.
        """
        wallet = self.get_or_create_wallet(user)

        if not wallet.can_afford(plan.price):
            raise ValueError(
                f"Insufficient balance. Required: {plan.price}, Available: {wallet.balance}"
            )

        now = timezone.now()
        cust = customer_details or {}

        subscription = Subscription.objects.create(
            user=user,
            plan=plan,
            status=Subscription.Status.ACTIVE,
            payment_type="wallet",
            current_period_start=now,
            current_period_end=_calculate_next_period_end(now, plan),
            next_billing_date=_calculate_next_period_end(now, plan),
            billing_cycle_count=1,
            customer_first_name=cust.get("first_name", getattr(user, "first_name", "")),
            customer_last_name=cust.get("last_name", getattr(user, "last_name", "")),
            customer_email=cust.get("email", getattr(user, "email", "")),
            customer_phone=cust.get("phone", ""),
            metadata=metadata or {},
        )

        self.pay_subscription_from_wallet(subscription)
        return subscription

    # ─── Top-Up Webhook Processing ────────────────────────────────────────

    @transaction.atomic
    def _handle_topup_notification(
        self,
        order_id: str,
        transaction_status: str,
        fraud_status: str,
        payload: dict,
    ):
        """Handle Midtrans notification for a top-up payment."""
        try:
            topup = TopUp.objects.select_related("wallet", "user").get(order_id=order_id)
        except TopUp.DoesNotExist:
            logger.warning("TopUp not found for order_id=%s", order_id)
            return

        topup.midtrans_response = payload
        topup.midtrans_transaction_id = payload.get("transaction_id", topup.midtrans_transaction_id)

        if transaction_status in ("capture", "settlement"):
            if transaction_status == "capture" and fraud_status != "accept":
                topup.save(update_fields=["midtrans_response", "midtrans_transaction_id"])
                return

            if topup.status != TopUp.Status.SUCCESS:
                topup.status = TopUp.Status.SUCCESS
                topup.save(update_fields=["status", "midtrans_response", "midtrans_transaction_id"])

                # Credit the wallet
                self.credit_wallet(
                    wallet=topup.wallet,
                    amount=topup.amount,
                    transaction_type=WalletTransaction.TransactionType.TOP_UP,
                    reference_type="topup",
                    reference_id=str(topup.id),
                    description=f"Top up via {topup.get_payment_type_display()} ({topup.order_id})",
                )

                logger.info("Top-up %s completed. Wallet credited %s", topup.order_id, topup.amount)
            else:
                topup.save(update_fields=["midtrans_response", "midtrans_transaction_id"])

        elif transaction_status in ("deny", "cancel", "expire"):
            topup.status = TopUp.Status.FAILED if transaction_status != "expire" else TopUp.Status.EXPIRED
            topup.save(update_fields=["status", "midtrans_response", "midtrans_transaction_id"])
            logger.info("Top-up %s %s", topup.order_id, transaction_status)

        elif transaction_status == "pending":
            topup.save(update_fields=["midtrans_response", "midtrans_transaction_id"])

        else:
            topup.save(update_fields=["midtrans_response", "midtrans_transaction_id"])
