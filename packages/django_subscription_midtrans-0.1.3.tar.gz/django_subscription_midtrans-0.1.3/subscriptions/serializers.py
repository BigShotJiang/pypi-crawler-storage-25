"""DRF Serializers for subscriptions package."""
from rest_framework import serializers

from .models import (
    Invoice,
    InvoiceItem,
    NotificationLog,
    Payment,
    Plan,
    Subscription,
    TopUp,
    Wallet,
    WalletTransaction,
    WebhookLog,
)


# ─── Plan ─────────────────────────────────────────────────────────────────────


class PlanSerializer(serializers.ModelSerializer):
    interval_display = serializers.SerializerMethodField()

    class Meta:
        model = Plan
        fields = [
            "id", "name", "slug", "description", "price", "currency",
            "interval", "interval_unit", "interval_display",
            "trial_period_days", "max_cycles", "status", "features",
            "sort_order", "created_at",
        ]
        read_only_fields = ["id", "created_at"]

    def get_interval_display(self, obj):
        return obj.get_interval_display()


# ─── Subscription ─────────────────────────────────────────────────────────────


class SubscriptionCreateSerializer(serializers.Serializer):
    """Serializer for creating a subscription."""
    plan_id = serializers.UUIDField()
    payment_type = serializers.ChoiceField(choices=Subscription.PaymentType.choices)
    token = serializers.CharField(required=False, allow_blank=True, help_text="Credit card saved token or GoPay account ID")
    customer_details = serializers.DictField(required=False, default=dict)
    metadata = serializers.DictField(required=False, default=dict)

    def validate_plan_id(self, value):
        try:
            plan = Plan.objects.get(id=value, status=Plan.Status.ACTIVE)
        except Plan.DoesNotExist:
            raise serializers.ValidationError("Plan not found or inactive.")
        return plan

    def validate(self, attrs):
        payment_type = attrs["payment_type"]
        token = attrs.get("token", "")

        if payment_type in ("credit_card",) and not token:
            raise serializers.ValidationError(
                {"token": "Token is required for credit card subscriptions."}
            )
        return attrs


class SubscriptionSerializer(serializers.ModelSerializer):
    plan = PlanSerializer(read_only=True)
    is_active = serializers.BooleanField(read_only=True)
    has_access = serializers.BooleanField(read_only=True)
    user_email = serializers.CharField(source="user.email", read_only=True)

    class Meta:
        model = Subscription
        fields = [
            "id", "user_email", "plan", "status", "payment_type",
            "midtrans_subscription_id",
            "current_period_start", "current_period_end",
            "trial_end", "billing_cycle_count", "next_billing_date",
            "cancel_at_period_end", "cancelled_at", "cancellation_reason",
            "is_active", "has_access",
            "customer_first_name", "customer_last_name",
            "customer_email", "customer_phone",
            "metadata", "created_at", "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at"]


class SubscriptionCancelSerializer(serializers.Serializer):
    reason = serializers.CharField(required=False, allow_blank=True, default="")
    immediate = serializers.BooleanField(required=False, default=False)


class SubscriptionChangePlanSerializer(serializers.Serializer):
    plan_id = serializers.UUIDField()
    immediate = serializers.BooleanField(required=False, default=True)

    def validate_plan_id(self, value):
        try:
            plan = Plan.objects.get(id=value, status=Plan.Status.ACTIVE)
        except Plan.DoesNotExist:
            raise serializers.ValidationError("Plan not found or inactive.")
        return plan


# ─── Payment ──────────────────────────────────────────────────────────────────


class PaymentSerializer(serializers.ModelSerializer):
    is_paid = serializers.BooleanField(read_only=True)
    subscription_id = serializers.UUIDField(source="subscription.id", read_only=True, allow_null=True)

    class Meta:
        model = Payment
        fields = [
            "id", "subscription_id", "order_id", "midtrans_transaction_id",
            "payment_type", "status", "fraud_status",
            "gross_amount", "currency", "refund_amount",
            "payment_details",
            "transaction_time", "settlement_time", "expiry_time",
            "is_paid", "is_retry", "retry_count",
            "metadata", "created_at",
        ]
        read_only_fields = ["id", "created_at"]


class PaymentChargeSerializer(serializers.Serializer):
    """Serializer for creating a one-time charge for a subscription."""
    subscription_id = serializers.UUIDField()

    def validate_subscription_id(self, value):
        try:
            return Subscription.objects.get(id=value)
        except Subscription.DoesNotExist:
            raise serializers.ValidationError("Subscription not found.")


class RefundSerializer(serializers.Serializer):
    amount = serializers.IntegerField(required=False, min_value=1)
    reason = serializers.CharField(required=False, allow_blank=True, default="")
    direct = serializers.BooleanField(required=False, default=False)


# ─── Invoice ──────────────────────────────────────────────────────────────────


class InvoiceItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceItem
        fields = ["id", "description", "quantity", "unit_price", "total_price"]
        read_only_fields = ["id"]


class InvoiceSerializer(serializers.ModelSerializer):
    items = InvoiceItemSerializer(many=True, read_only=True)
    subscription_id = serializers.UUIDField(source="subscription.id", read_only=True)
    payment_id = serializers.UUIDField(source="payment.id", read_only=True, allow_null=True)

    class Meta:
        model = Invoice
        fields = [
            "id", "invoice_number", "subscription_id", "payment_id",
            "status", "subtotal", "tax_amount", "discount_amount",
            "total_amount", "currency",
            "issue_date", "due_date", "paid_date",
            "period_start", "period_end",
            "notes", "void_reason",
            "items", "metadata", "created_at",
        ]
        read_only_fields = ["id", "created_at"]


# ─── Webhook ──────────────────────────────────────────────────────────────────


class WebhookNotificationSerializer(serializers.Serializer):
    """Serializer for incoming Midtrans webhook notification."""
    order_id = serializers.CharField()
    transaction_status = serializers.CharField()
    status_code = serializers.CharField()
    gross_amount = serializers.CharField()
    signature_key = serializers.CharField()
    payment_type = serializers.CharField(required=False, default="")
    fraud_status = serializers.CharField(required=False, default="")
    transaction_id = serializers.CharField(required=False, default="")


class WebhookLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = WebhookLog
        fields = [
            "id", "order_id", "midtrans_transaction_id",
            "transaction_status", "payment_type", "fraud_status",
            "gross_amount", "status", "error_message",
            "ip_address", "processed_at", "created_at",
        ]
        read_only_fields = ["id", "created_at"]


# ─── Notification ─────────────────────────────────────────────────────────────


class NotificationLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationLog
        fields = [
            "id", "notification_type", "channel", "status",
            "subject", "body", "recipient",
            "error_message", "sent_at", "metadata", "created_at",
        ]
        read_only_fields = ["id", "created_at"]


# ─── Wallet ───────────────────────────────────────────────────────────────────


class WalletSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source="user.username", read_only=True)
    has_sufficient_balance = serializers.BooleanField(read_only=True)

    class Meta:
        model = Wallet
        fields = [
            "id", "username", "balance", "currency",
            "is_active", "has_sufficient_balance",
            "metadata", "created_at", "updated_at",
        ]
        read_only_fields = ["id", "balance", "currency", "created_at", "updated_at"]


class WalletTransactionSerializer(serializers.ModelSerializer):
    transaction_type_display = serializers.CharField(
        source="get_transaction_type_display", read_only=True
    )

    class Meta:
        model = WalletTransaction
        fields = [
            "id", "transaction_type", "transaction_type_display",
            "amount", "balance_before", "balance_after",
            "reference_type", "reference_id",
            "description", "metadata", "created_at",
        ]
        read_only_fields = ["id", "created_at"]


# ─── Top-Up ──────────────────────────────────────────────────────────────────


class TopUpSerializer(serializers.ModelSerializer):
    payment_type_display = serializers.CharField(
        source="get_payment_type_display", read_only=True
    )
    status_display = serializers.CharField(
        source="get_status_display", read_only=True
    )

    class Meta:
        model = TopUp
        fields = [
            "id", "amount", "payment_type", "payment_type_display",
            "status", "status_display", "order_id",
            "midtrans_transaction_id", "payment_details",
            "metadata", "created_at",
        ]
        read_only_fields = ["id", "created_at"]


class TopUpCreateSerializer(serializers.Serializer):
    """Serializer for creating a top-up request."""
    amount = serializers.IntegerField(min_value=10000, help_text="Top-up amount in IDR (min 10,000)")
    payment_type = serializers.ChoiceField(choices=TopUp.PaymentType.choices)
    bank = serializers.CharField(required=False, default="bca")
    token = serializers.CharField(required=False, allow_blank=True, default="")

    def validate_amount(self, value):
        max_amount = 50000000  # 50 million IDR
        if value > max_amount:
            raise serializers.ValidationError(
                f"Maximum top-up amount is {max_amount:,} IDR."
            )
        return value
