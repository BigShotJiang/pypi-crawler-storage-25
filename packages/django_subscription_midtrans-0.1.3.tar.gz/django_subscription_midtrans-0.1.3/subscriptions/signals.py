"""
Django signals for subscription events.

Dispatches custom signals for subscription lifecycle events.
Third-party apps can connect to these signals for custom behavior.
"""
import django.dispatch

# ─── Custom Signals ───────────────────────────────────────────────────────────

# Subscription lifecycle
subscription_created = django.dispatch.Signal()  # sender=Subscription, user=user
subscription_activated = django.dispatch.Signal()  # sender=Subscription
subscription_cancelled = django.dispatch.Signal()  # sender=Subscription
subscription_paused = django.dispatch.Signal()  # sender=Subscription
subscription_resumed = django.dispatch.Signal()  # sender=Subscription
subscription_expired = django.dispatch.Signal()  # sender=Subscription
subscription_renewed = django.dispatch.Signal()  # sender=Subscription
subscription_plan_changed = django.dispatch.Signal()  # sender=Subscription, old_plan=Plan, new_plan=Plan

# Payment lifecycle
payment_created = django.dispatch.Signal()  # sender=Payment
payment_success = django.dispatch.Signal()  # sender=Payment
payment_failed = django.dispatch.Signal()  # sender=Payment
payment_refunded = django.dispatch.Signal()  # sender=Payment

# Invoice lifecycle
invoice_created = django.dispatch.Signal()  # sender=Invoice
invoice_paid = django.dispatch.Signal()  # sender=Invoice
invoice_overdue = django.dispatch.Signal()  # sender=Invoice
invoice_voided = django.dispatch.Signal()  # sender=Invoice

# Webhook
webhook_received = django.dispatch.Signal()  # sender=WebhookLog
webhook_processed = django.dispatch.Signal()  # sender=WebhookLog

# Wallet lifecycle
topup_completed = django.dispatch.Signal()  # sender=TopUp
wallet_credited = django.dispatch.Signal()  # sender=WalletTransaction
wallet_debited = django.dispatch.Signal()  # sender=WalletTransaction


# ─── Signal Handlers ──────────────────────────────────────────────────────────

from django.db.models.signals import post_save
from django.dispatch import receiver


@receiver(post_save, sender="subscriptions.Subscription")
def on_subscription_status_change(sender, instance, created, **kwargs):
    """Dispatch appropriate signal based on subscription status changes."""
    if created:
        subscription_created.send(sender=instance.__class__, instance=instance)
        return

    # Check if status changed by looking at update_fields
    update_fields = kwargs.get("update_fields")
    if update_fields and "status" not in update_fields:
        return

    from .models import Subscription

    status_signal_map = {
        Subscription.Status.ACTIVE: subscription_activated,
        Subscription.Status.CANCELLED: subscription_cancelled,
        Subscription.Status.PAUSED: subscription_paused,
        Subscription.Status.EXPIRED: subscription_expired,
    }

    signal = status_signal_map.get(instance.status)
    if signal:
        signal.send(sender=instance.__class__, instance=instance)


@receiver(post_save, sender="subscriptions.Payment")
def on_payment_status_change(sender, instance, created, **kwargs):
    """Dispatch payment signals."""
    if created:
        payment_created.send(sender=instance.__class__, instance=instance)
        return

    from .models import Payment

    if instance.is_paid:
        payment_success.send(sender=instance.__class__, instance=instance)
    elif instance.status in (Payment.Status.DENY, Payment.Status.CANCEL, Payment.Status.EXPIRE, Payment.Status.FAILURE):
        payment_failed.send(sender=instance.__class__, instance=instance)
    elif instance.status in (Payment.Status.REFUND, Payment.Status.PARTIAL_REFUND):
        payment_refunded.send(sender=instance.__class__, instance=instance)


@receiver(post_save, sender="subscriptions.Invoice")
def on_invoice_status_change(sender, instance, created, **kwargs):
    """Dispatch invoice signals."""
    if created:
        invoice_created.send(sender=instance.__class__, instance=instance)
        return

    from .models import Invoice

    status_signal_map = {
        Invoice.Status.PAID: invoice_paid,
        Invoice.Status.OVERDUE: invoice_overdue,
        Invoice.Status.VOID: invoice_voided,
    }

    signal = status_signal_map.get(instance.status)
    if signal:
        signal.send(sender=instance.__class__, instance=instance)


@receiver(post_save, sender="subscriptions.WebhookLog")
def on_webhook_log_created(sender, instance, created, **kwargs):
    """Dispatch webhook signals."""
    if created:
        webhook_received.send(sender=instance.__class__, instance=instance)
    elif instance.status == "processed":
        webhook_processed.send(sender=instance.__class__, instance=instance)


@receiver(post_save, sender="subscriptions.TopUp")
def on_topup_status_change(sender, instance, created, **kwargs):
    """Dispatch topup signal when completed."""
    if not created and instance.status == "success":
        topup_completed.send(sender=instance.__class__, instance=instance)


@receiver(post_save, sender="subscriptions.WalletTransaction")
def on_wallet_transaction_created(sender, instance, created, **kwargs):
    """Dispatch wallet transaction signals."""
    if created:
        if instance.amount > 0:
            wallet_credited.send(sender=instance.__class__, instance=instance)
        elif instance.amount < 0:
            wallet_debited.send(sender=instance.__class__, instance=instance)
