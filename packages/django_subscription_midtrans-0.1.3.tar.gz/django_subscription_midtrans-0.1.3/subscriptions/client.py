"""
Midtrans Core API Client.

Handles all HTTP communication with Midtrans API endpoints:
- /v2/charge (Core API payments)
- /v1/subscriptions (Subscription management)
- /v1/invoices (Invoice management)
- /v2/{order_id}/status (Transaction status)
- /v2/{order_id}/cancel|expire|refund (Transaction management)

Uses Basic Auth with Server Key as per Midtrans documentation.
"""
import base64
import hashlib
import logging
from decimal import Decimal
from typing import Optional

import requests
from django.conf import settings

logger = logging.getLogger("subscriptions.midtrans")


class MidtransAPIError(Exception):
    """Raised when Midtrans API returns an error."""

    def __init__(self, status_code: int, message: str, response_data: dict = None):
        self.status_code = status_code
        self.message = message
        self.response_data = response_data or {}
        super().__init__(f"Midtrans API Error ({status_code}): {message}")


class MidtransClient:
    """
    Client for Midtrans Core API.

    Customizable via settings:
        MIDTRANS_SERVER_KEY
        MIDTRANS_CLIENT_KEY
        MIDTRANS_IS_PRODUCTION
        MIDTRANS_API_BASE_URL
    """

    def __init__(
        self,
        server_key: str = None,
        is_production: bool = None,
        base_url: str = None,
    ):
        self.server_key = server_key or settings.MIDTRANS_SERVER_KEY
        self.is_production = (
            is_production if is_production is not None else settings.MIDTRANS_IS_PRODUCTION
        )
        self.base_url = base_url or settings.MIDTRANS_API_BASE_URL
        self._session = requests.Session()
        self._session.headers.update(self._get_headers())

    def _get_headers(self) -> dict:
        auth_string = base64.b64encode(f"{self.server_key}:".encode()).decode()
        return {
            "Authorization": f"Basic {auth_string}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _request(self, method: str, path: str, data: dict = None, params: dict = None) -> dict:
        url = f"{self.base_url}{path}"
        logger.debug("Midtrans %s %s payload=%s", method.upper(), url, data)

        try:
            response = self._session.request(
                method=method,
                url=url,
                json=data,
                params=params,
                timeout=30,
            )
            response_data = response.json()
        except requests.exceptions.Timeout:
            logger.error("Midtrans API timeout: %s %s", method.upper(), url)
            raise MidtransAPIError(408, "Request timeout")
        except requests.exceptions.RequestException as e:
            logger.error("Midtrans API connection error: %s", str(e))
            raise MidtransAPIError(0, f"Connection error: {str(e)}")
        except ValueError:
            logger.error("Midtrans API invalid JSON response: %s", response.text[:500])
            raise MidtransAPIError(response.status_code, "Invalid JSON response")

        logger.debug("Midtrans response: status=%s data=%s", response.status_code, response_data)

        status_code = int(response_data.get("status_code", response.status_code))
        if response.status_code >= 400:
            error_msg = response_data.get("status_message", "Unknown error")
            logger.error("Midtrans API error: %s - %s", status_code, error_msg)
            raise MidtransAPIError(status_code, error_msg, response_data)

        return response_data

    # ─── Core API: Charge ─────────────────────────────────────────────────

    def charge(self, payload: dict) -> dict:
        """
        Create a charge transaction via Core API.
        POST /v2/charge

        Args:
            payload: Complete charge request body including payment_type,
                     transaction_details, and payment-method-specific fields.
        Returns:
            Midtrans charge response dict.
        """
        return self._request("POST", "/v2/charge", data=payload)

    def charge_credit_card(
        self,
        order_id: str,
        amount: int,
        token_id: str,
        authentication: bool = True,
        customer_details: dict = None,
        item_details: list = None,
        custom_expiry: dict = None,
        metadata: dict = None,
        notification_url: str = None,
    ) -> dict:
        payload = {
            "payment_type": "credit_card",
            "transaction_details": {
                "order_id": order_id,
                "gross_amount": amount,
            },
            "credit_card": {
                "token_id": token_id,
                "authentication": authentication,
            },
        }
        if customer_details:
            payload["customer_details"] = customer_details
        if item_details:
            payload["item_details"] = item_details
        if custom_expiry:
            payload["custom_expiry"] = custom_expiry
        if metadata:
            payload["metadata"] = metadata
        if notification_url:
            payload["notification_url"] = notification_url
        return self.charge(payload)

    def charge_bank_transfer(
        self,
        order_id: str,
        amount: int,
        bank: str,
        customer_details: dict = None,
        item_details: list = None,
        custom_expiry: dict = None,
        metadata: dict = None,
        notification_url: str = None,
    ) -> dict:
        payload = {
            "payment_type": "bank_transfer",
            "transaction_details": {
                "order_id": order_id,
                "gross_amount": amount,
            },
            "bank_transfer": {
                "bank": bank,
            },
        }
        if customer_details:
            payload["customer_details"] = customer_details
        if item_details:
            payload["item_details"] = item_details
        if custom_expiry:
            payload["custom_expiry"] = custom_expiry
        if metadata:
            payload["metadata"] = metadata
        if notification_url:
            payload["notification_url"] = notification_url
        return self.charge(payload)

    def charge_echannel(
        self,
        order_id: str,
        amount: int,
        bill_info1: str = "Payment:",
        bill_info2: str = "Online purchase",
        customer_details: dict = None,
        metadata: dict = None,
        notification_url: str = None,
    ) -> dict:
        payload = {
            "payment_type": "echannel",
            "transaction_details": {
                "order_id": order_id,
                "gross_amount": amount,
            },
            "echannel": {
                "bill_info1": bill_info1,
                "bill_info2": bill_info2,
            },
        }
        if customer_details:
            payload["customer_details"] = customer_details
        if metadata:
            payload["metadata"] = metadata
        if notification_url:
            payload["notification_url"] = notification_url
        return self.charge(payload)

    def charge_gopay(
        self,
        order_id: str,
        amount: int,
        callback_url: str = None,
        customer_details: dict = None,
        metadata: dict = None,
        notification_url: str = None,
    ) -> dict:
        payload = {
            "payment_type": "gopay",
            "transaction_details": {
                "order_id": order_id,
                "gross_amount": amount,
            },
        }
        if callback_url:
            payload["gopay"] = {
                "enable_callback": True,
                "callback_url": callback_url,
            }
        if customer_details:
            payload["customer_details"] = customer_details
        if metadata:
            payload["metadata"] = metadata
        if notification_url:
            payload["notification_url"] = notification_url
        return self.charge(payload)

    def charge_shopeepay(
        self,
        order_id: str,
        amount: int,
        callback_url: str = None,
        customer_details: dict = None,
        metadata: dict = None,
        notification_url: str = None,
    ) -> dict:
        payload = {
            "payment_type": "shopeepay",
            "transaction_details": {
                "order_id": order_id,
                "gross_amount": amount,
            },
        }
        if callback_url:
            payload["shopeepay"] = {"callback_url": callback_url}
        if customer_details:
            payload["customer_details"] = customer_details
        if metadata:
            payload["metadata"] = metadata
        if notification_url:
            payload["notification_url"] = notification_url
        return self.charge(payload)

    def charge_qris(
        self,
        order_id: str,
        amount: int,
        acquirer: str = "gopay",
        customer_details: dict = None,
        metadata: dict = None,
        notification_url: str = None,
    ) -> dict:
        payload = {
            "payment_type": "qris",
            "transaction_details": {
                "order_id": order_id,
                "gross_amount": amount,
            },
            "qris": {
                "acquirer": acquirer,
            },
        }
        if customer_details:
            payload["customer_details"] = customer_details
        if metadata:
            payload["metadata"] = metadata
        if notification_url:
            payload["notification_url"] = notification_url
        return self.charge(payload)

    # ─── Transaction Management ───────────────────────────────────────────

    def get_transaction_status(self, order_id: str) -> dict:
        """GET /v2/{order_id}/status"""
        return self._request("GET", f"/v2/{order_id}/status")

    def cancel_transaction(self, order_id: str) -> dict:
        """POST /v2/{order_id}/cancel"""
        return self._request("POST", f"/v2/{order_id}/cancel")

    def expire_transaction(self, order_id: str) -> dict:
        """POST /v2/{order_id}/expire"""
        return self._request("POST", f"/v2/{order_id}/expire")

    def capture_transaction(self, transaction_id: str, gross_amount: int) -> dict:
        """POST /v2/capture (credit card pre-auth)"""
        return self._request("POST", "/v2/capture", data={
            "transaction_id": transaction_id,
            "gross_amount": gross_amount,
        })

    def refund_transaction(
        self,
        order_id: str,
        amount: int,
        reason: str = "",
        refund_key: str = None,
    ) -> dict:
        """POST /v2/{order_id}/refund"""
        payload = {
            "refund_key": refund_key or f"refund-{order_id}-{amount}",
            "amount": amount,
            "reason": reason,
        }
        return self._request("POST", f"/v2/{order_id}/refund", data=payload)

    def direct_refund_transaction(
        self,
        order_id: str,
        amount: int,
        reason: str = "",
        refund_key: str = None,
    ) -> dict:
        """POST /v2/{order_id}/refund/online/direct"""
        payload = {
            "refund_key": refund_key or f"direct-refund-{order_id}-{amount}",
            "amount": amount,
            "reason": reason,
        }
        return self._request("POST", f"/v2/{order_id}/refund/online/direct", data=payload)

    def approve_transaction(self, order_id: str) -> dict:
        """POST /v2/{order_id}/approve"""
        return self._request("POST", f"/v2/{order_id}/approve")

    def deny_transaction(self, order_id: str) -> dict:
        """POST /v2/{order_id}/deny"""
        return self._request("POST", f"/v2/{order_id}/deny")

    # ─── Subscription API (/v1/subscriptions) ─────────────────────────────

    def create_subscription(
        self,
        name: str,
        amount: int,
        currency: str,
        payment_type: str,
        token: str = None,
        gopay_account_id: str = None,
        schedule: dict = None,
        retry_schedule: dict = None,
        customer_details: dict = None,
        metadata: dict = None,
        notification_url: str = None,
    ) -> dict:
        """
        POST /v1/subscriptions

        Create a recurring subscription on Midtrans.
        """
        payload = {
            "name": name,
            "amount": str(amount),
            "currency": currency,
            "payment_type": payment_type,
        }
        if payment_type == "credit_card" and token:
            payload["token"] = token
        elif payment_type == "gopay" and gopay_account_id:
            payload["gopay"] = {"account_id": gopay_account_id}

        if schedule:
            payload["schedule"] = schedule
        if retry_schedule:
            payload["retry_schedule"] = retry_schedule
        if customer_details:
            payload["customer_details"] = customer_details
        if metadata:
            payload["metadata"] = metadata
        if notification_url:
            payload["notification_url"] = notification_url

        return self._request("POST", "/v1/subscriptions", data=payload)

    def get_subscription(self, subscription_id: str) -> dict:
        """GET /v1/subscriptions/{subscription_id}"""
        return self._request("GET", f"/v1/subscriptions/{subscription_id}")

    def disable_subscription(self, subscription_id: str) -> dict:
        """POST /v1/subscriptions/{subscription_id}/disable (pause)"""
        return self._request("POST", f"/v1/subscriptions/{subscription_id}/disable")

    def enable_subscription(self, subscription_id: str) -> dict:
        """POST /v1/subscriptions/{subscription_id}/enable (resume)"""
        return self._request("POST", f"/v1/subscriptions/{subscription_id}/enable")

    def cancel_subscription(self, subscription_id: str) -> dict:
        """POST /v1/subscriptions/{subscription_id}/cancel (permanent)"""
        return self._request("POST", f"/v1/subscriptions/{subscription_id}/cancel")

    def update_subscription(self, subscription_id: str, data: dict) -> dict:
        """PATCH /v1/subscriptions/{subscription_id}"""
        return self._request("PATCH", f"/v1/subscriptions/{subscription_id}", data=data)

    # ─── Invoice API (/v1/invoices) ───────────────────────────────────────

    def create_invoice(
        self,
        order_id: str,
        invoice_number: str,
        due_date: str,
        customer_details: dict,
        item_details: list,
        notes: str = "",
        payment_type: str = "payment_link",
    ) -> dict:
        """POST /v1/invoices"""
        payload = {
            "order_id": order_id,
            "invoice_number": invoice_number,
            "due_date": due_date,
            "customer_details": customer_details,
            "item_details": item_details,
            "notes": notes,
            "payment_type": payment_type,
        }
        return self._request("POST", "/v1/invoices", data=payload)

    def get_invoice(self, invoice_id: str) -> dict:
        """GET /v1/invoices/{invoice_id}"""
        return self._request("GET", f"/v1/invoices/{invoice_id}")

    def void_invoice(self, invoice_id: str, reason: str = "") -> dict:
        """PATCH /v1/invoices/{invoice_id}"""
        return self._request("PATCH", f"/v1/invoices/{invoice_id}", data={
            "status": "void",
            "void_reason": reason,
        })

    # ─── GoPay Tokenization (Account Linking) ────────────────────────────

    def create_pay_account(self, payment_type: str, gopay_partner_info: dict) -> dict:
        """POST /v2/pay/account"""
        return self._request("POST", "/v2/pay/account", data={
            "payment_type": payment_type,
            "gopay_partner": gopay_partner_info,
        })

    def get_pay_account(self, account_id: str) -> dict:
        """GET /v2/pay/account/{account_id}"""
        return self._request("GET", f"/v2/pay/account/{account_id}")

    def unbind_pay_account(self, account_id: str) -> dict:
        """POST /v2/pay/account/{account_id}/unbind"""
        return self._request("POST", f"/v2/pay/account/{account_id}/unbind")

    # ─── Card Registration ────────────────────────────────────────────────

    def get_card_token(
        self,
        card_number: str,
        card_exp_month: str,
        card_exp_year: str,
        card_cvv: str,
        client_key: str = None,
    ) -> dict:
        """GET /v2/token"""
        params = {
            "card_number": card_number,
            "card_exp_month": card_exp_month,
            "card_exp_year": card_exp_year,
            "card_cvv": card_cvv,
            "client_key": client_key or settings.MIDTRANS_CLIENT_KEY,
        }
        return self._request("GET", "/v2/token", params=params)

    # ─── BIN API ──────────────────────────────────────────────────────────

    def check_bin(self, bin_number: str) -> dict:
        """GET /v1/bins/{bin_number}"""
        return self._request("GET", f"/v1/bins/{bin_number}")

    # ─── Signature Verification ───────────────────────────────────────────

    @staticmethod
    def verify_signature(
        order_id: str,
        status_code: str,
        gross_amount: str,
        signature_key: str,
        server_key: str = None,
    ) -> bool:
        """
        Verify Midtrans notification signature.
        SHA512(order_id + status_code + gross_amount + server_key) == signature_key
        """
        key = server_key or settings.MIDTRANS_SERVER_KEY
        raw = f"{order_id}{status_code}{gross_amount}{key}"
        calculated = hashlib.sha512(raw.encode()).hexdigest()
        return calculated == signature_key


# Singleton-like access
def get_midtrans_client(**kwargs) -> MidtransClient:
    """Factory function to get a configured MidtransClient instance."""
    return MidtransClient(**kwargs)
