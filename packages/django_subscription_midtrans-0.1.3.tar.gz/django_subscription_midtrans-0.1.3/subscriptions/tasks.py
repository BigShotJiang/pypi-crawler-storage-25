"""
Celery tasks for subscription management.

These tasks handle:
- Recurring billing (charging subscriptions that are due)
- Subscription expiration
- Failed payment retries
- Invoice overdue marking
- Expiry reminders
- Midtrans status syncing
"""
import logging

from celery import shared_task
from django.conf import settings
from django.utils import timezone

logger = logging.getLogger("subscriptions")


def _get_subscription_settings():
    return getattr(settings, "SUBSCRIPTION_SETTINGS", {})


# ─── Billing ──────────────────────────────────────────────────────────────────


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def process_due_subscriptions(self):
    """
    Process all subscriptions that are due for billing.
    Creates a charge for each due subscription.
    Run via Celery Beat (e.g., every hour).
    """
    from .models import Subscription
    from .services import SubscriptionService

    service = SubscriptionService()
    due_subscriptions = service.get_subscriptions_due_for_billing()

    processed = 0
    failed = 0

    for subscription in due_subscriptions:
        try:
            # Check max cycles
            if subscription.plan.max_cycles > 0 and subscription.billing_cycle_count >= subscription.plan.max_cycles:
                service.expire_subscription(subscription)
                logger.info("Subscription %s expired: max cycles reached", subscription.id)
                continue

            # For native Midtrans subscriptions, Midtrans handles billing
            if subscription.midtrans_subscription_id:
                logger.debug("Skipping native Midtrans subscription %s", subscription.id)
                continue

            payment = service.create_charge_for_subscription(subscription)
            processed += 1
            logger.info(
                "Created charge %s for subscription %s",
                payment.order_id, subscription.id,
            )
        except Exception as e:
            failed += 1
            logger.exception(
                "Failed billing subscription %s: %s", subscription.id, e
            )

    logger.info(
        "process_due_subscriptions: processed=%d, failed=%d", processed, failed
    )
    return {"processed": processed, "failed": failed}


# ─── Subscription Expiration ──────────────────────────────────────────────────


@shared_task
def process_expired_subscriptions():
    """
    Find and expire subscriptions that have passed their period end
    and are marked for cancellation.
    """
    from .models import NotificationLog
    from .services import SubscriptionService

    service = SubscriptionService()
    to_cancel = service.get_subscriptions_to_cancel()

    cancelled = 0
    for subscription in to_cancel:
        service.cancel_subscription(subscription, reason="Period ended", immediate=True)
        cancelled += 1
        logger.info("Auto-cancelled subscription %s at period end", subscription.id)

    logger.info("process_expired_subscriptions: cancelled=%d", cancelled)
    return {"cancelled": cancelled}


@shared_task
def process_past_due_expiration():
    """
    Expire subscriptions that are past due beyond the grace period.
    """
    from .models import Subscription
    from .services import SubscriptionService, _get_subscription_settings

    sub_settings = _get_subscription_settings()
    grace_days = sub_settings.get("GRACE_PERIOD_DAYS", 3)
    cutoff = timezone.now() - timezone.timedelta(days=grace_days)

    past_due = Subscription.objects.filter(
        status=Subscription.Status.PAST_DUE,
        current_period_end__lt=cutoff,
    )

    service = SubscriptionService()
    expired = 0
    for subscription in past_due:
        service.expire_subscription(subscription)
        expired += 1
        logger.info("Expired past-due subscription %s", subscription.id)

    logger.info("process_past_due_expiration: expired=%d", expired)
    return {"expired": expired}


# ─── Payment Retries ──────────────────────────────────────────────────────────


@shared_task
def retry_failed_payments():
    """
    Retry failed payments for past-due subscriptions.
    Respects MAX_RETRY_ATTEMPTS setting.
    """
    from .models import Payment, Subscription
    from .services import SubscriptionService

    sub_settings = _get_subscription_settings()
    if not sub_settings.get("AUTO_RETRY_FAILED_PAYMENTS", True):
        return {"skipped": True}

    max_retries = sub_settings.get("MAX_RETRY_ATTEMPTS", 3)

    past_due_subs = Subscription.objects.filter(
        status=Subscription.Status.PAST_DUE,
    ).select_related("plan", "user")

    service = SubscriptionService()
    retried = 0
    skipped = 0

    for subscription in past_due_subs:
        # Skip native Midtrans subscriptions (they handle retries internally)
        if subscription.midtrans_subscription_id:
            continue

        # Get latest payment retry count
        last_payment = subscription.payments.order_by("-created_at").first()
        if last_payment and last_payment.retry_count >= max_retries:
            skipped += 1
            continue

        retry_count = (last_payment.retry_count + 1) if last_payment else 1

        try:
            payment = service.create_charge_for_subscription(
                subscription=subscription,
                is_retry=True,
                retry_count=retry_count,
            )
            retried += 1
            logger.info(
                "Retry %d for subscription %s: order=%s",
                retry_count, subscription.id, payment.order_id,
            )
        except Exception as e:
            logger.exception(
                "Retry failed for subscription %s: %s", subscription.id, e
            )

    logger.info("retry_failed_payments: retried=%d, skipped=%d", retried, skipped)
    return {"retried": retried, "skipped": skipped}


# ─── Invoice Management ──────────────────────────────────────────────────────


@shared_task
def mark_overdue_invoices():
    """Mark invoices past due date as overdue."""
    from .models import Invoice, NotificationLog
    from .services import SubscriptionService

    service = SubscriptionService()
    overdue = service.get_overdue_invoices()

    marked = 0
    for invoice in overdue:
        invoice.status = Invoice.Status.OVERDUE
        invoice.save(update_fields=["status", "updated_at"])
        marked += 1

        # Create notification
        NotificationLog.objects.create(
            user=invoice.user,
            subscription=invoice.subscription,
            notification_type=NotificationLog.NotificationType.INVOICE_OVERDUE,
            channel=NotificationLog.Channel.IN_APP,
            status=NotificationLog.Status.QUEUED,
            recipient=invoice.user.email,
            subject=f"Invoice {invoice.invoice_number} is overdue",
            metadata={"invoice_number": invoice.invoice_number},
        )

    logger.info("mark_overdue_invoices: marked=%d", marked)
    return {"marked": marked}


# ─── Expiry Reminders ─────────────────────────────────────────────────────────


@shared_task
def send_expiry_reminders():
    """
    Send reminders for subscriptions expiring soon.
    Respects EXPIRY_REMINDER_DAYS setting (default: [7, 3, 1]).
    """
    from .models import NotificationLog
    from .services import SubscriptionService

    sub_settings = _get_subscription_settings()
    reminder_days = sub_settings.get("EXPIRY_REMINDER_DAYS", [7, 3, 1])

    service = SubscriptionService()
    sent = 0

    for days in reminder_days:
        expiring = service.get_expiring_subscriptions(days)
        for subscription in expiring:
            # Check if reminder already sent for this period
            already_sent = NotificationLog.objects.filter(
                subscription=subscription,
                notification_type=NotificationLog.NotificationType.EXPIRY_REMINDER,
                metadata__contains={"reminder_days": days},
                created_at__date=timezone.now().date(),
            ).exists()

            if already_sent:
                continue

            NotificationLog.objects.create(
                user=subscription.user,
                subscription=subscription,
                notification_type=NotificationLog.NotificationType.EXPIRY_REMINDER,
                channel=NotificationLog.Channel.IN_APP,
                status=NotificationLog.Status.QUEUED,
                recipient=subscription.customer_email,
                subject=f"Your subscription expires in {days} day(s)",
                metadata={
                    "reminder_days": days,
                    "plan_name": subscription.plan.name,
                    "expiry_date": subscription.current_period_end.isoformat() if subscription.current_period_end else None,
                },
            )
            sent += 1

    logger.info("send_expiry_reminders: sent=%d", sent)
    return {"sent": sent}


# ─── Midtrans Sync ────────────────────────────────────────────────────────────


@shared_task
def sync_midtrans_subscriptions():
    """
    Sync subscription status from Midtrans for all subscriptions
    with a Midtrans subscription ID.
    """
    from .models import Subscription
    from .services import SubscriptionService

    subscriptions = Subscription.objects.filter(
        midtrans_subscription_id__gt="",
        status__in=[
            Subscription.Status.ACTIVE,
            Subscription.Status.PAST_DUE,
            Subscription.Status.PAUSED,
        ],
    )

    service = SubscriptionService()
    synced = 0

    for subscription in subscriptions:
        service.sync_subscription_status(subscription)
        synced += 1

    logger.info("sync_midtrans_subscriptions: synced=%d", synced)
    return {"synced": synced}


# ─── Wallet Billing ───────────────────────────────────────────────────────────


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def process_wallet_billing(self):
    """
    Process billing for subscriptions that use wallet payment.
    Debits the user's wallet for due subscriptions.
    Run via Celery Beat (e.g., every hour).
    """
    from .models import Subscription
    from .services import WalletService

    wallet_subs = Subscription.objects.filter(
        status=Subscription.Status.ACTIVE,
        payment_type=Subscription.PaymentType.WALLET,
        next_billing_date__lte=timezone.now(),
    ).select_related("plan", "user")

    service = WalletService()
    processed = 0
    failed = 0
    insufficient = 0

    for subscription in wallet_subs:
        try:
            # Check max cycles
            if subscription.plan.max_cycles > 0 and subscription.billing_cycle_count >= subscription.plan.max_cycles:
                from .services import SubscriptionService
                SubscriptionService().expire_subscription(subscription)
                logger.info("Wallet subscription %s expired: max cycles reached", subscription.id)
                continue

            service.pay_subscription_from_wallet(subscription)
            processed += 1
            logger.info("Wallet billing success for subscription %s", subscription.id)
        except ValueError:
            # Insufficient balance
            insufficient += 1
            subscription.status = Subscription.Status.PAST_DUE
            subscription.save(update_fields=["status", "updated_at"])
            logger.warning("Insufficient wallet balance for subscription %s", subscription.id)
        except Exception as e:
            failed += 1
            logger.exception("Wallet billing failed for subscription %s: %s", subscription.id, e)

    logger.info(
        "process_wallet_billing: processed=%d, insufficient=%d, failed=%d",
        processed, insufficient, failed,
    )
    return {"processed": processed, "insufficient": insufficient, "failed": failed}

    logger.info("sync_midtrans_subscriptions: synced=%d", synced)
    return {"synced": synced}


@shared_task
def check_pending_payment_status(payment_id: str):
    """
    Check the status of a specific pending payment from Midtrans.
    Useful for payments where notification might be missed.
    """
    from .models import Payment
    from .services import SubscriptionService

    try:
        payment = Payment.objects.get(id=payment_id)
    except Payment.DoesNotExist:
        logger.warning("Payment %s not found for status check", payment_id)
        return

    if payment.status != Payment.Status.PENDING:
        return

    service = SubscriptionService()
    try:
        status_data = service.client.get_transaction_status(payment.order_id)
        # Process as if it were a notification
        service.process_notification(status_data)
    except Exception as e:
        logger.error("Failed checking payment %s status: %s", payment_id, e)


# ─── Email Notification Sender ────────────────────────────────────────────────


@shared_task
def send_pending_email_notifications():
    """
    Process queued email notifications and send them.
    Override this task to customize email sending logic.
    """
    from django.core.mail import send_mail

    from .models import NotificationLog

    sub_settings = _get_subscription_settings()
    if not sub_settings.get("SEND_EMAIL_NOTIFICATIONS", True):
        return {"skipped": True}

    pending = NotificationLog.objects.filter(
        status=NotificationLog.Status.QUEUED,
        channel=NotificationLog.Channel.EMAIL,
    )[:100]

    sent = 0
    failed = 0

    for notification in pending:
        try:
            send_mail(
                subject=notification.subject,
                message=notification.body,
                from_email=None,  # Uses DEFAULT_FROM_EMAIL
                recipient_list=[notification.recipient],
                fail_silently=False,
            )
            notification.status = NotificationLog.Status.SENT
            notification.sent_at = timezone.now()
            sent += 1
        except Exception as e:
            notification.status = NotificationLog.Status.FAILED
            notification.error_message = str(e)
            failed += 1
            logger.error("Failed sending email to %s: %s", notification.recipient, e)

        notification.save(update_fields=["status", "sent_at", "error_message", "updated_at"])

    logger.info("send_pending_email_notifications: sent=%d, failed=%d", sent, failed)
    return {"sent": sent, "failed": failed}
