"""ragtab - Table extraction for RAG systems."""

from .silence import silence_warnings
silence_warnings()

from .pipeline import extract_table
from .heuristic import bordered_table_extraction
from .utils import Cell

try:
    from importlib.metadata import version
    __version__ = version("ragtab")
except Exception:
    __version__ = "0.1.5"

__all__ = [
    "extract_table",
    "bordered_table_extraction", 
    "Cell",
    "__version__",
]