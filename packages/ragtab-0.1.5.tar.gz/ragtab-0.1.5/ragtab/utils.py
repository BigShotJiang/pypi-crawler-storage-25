from dataclasses import dataclass

from .silence import silence_warnings
silence_warnings()

from paddleocr import PaddleOCR

@dataclass
class Cell:
    row_idx: int
    col_idx: int
    x: int; y: int; w: int; h: int
    is_span: bool = False
    col_span: int = 1
    text: str = ""

ocr = PaddleOCR(
    use_doc_orientation_classify=False,
    use_doc_unwarping=False,
    use_textline_orientation=False,
    lang="en",
)