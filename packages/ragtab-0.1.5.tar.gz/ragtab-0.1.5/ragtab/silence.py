import os
import warnings
import logging

def silence_warnings():
    # ChromaDB telemetry
    os.environ["ANONYMIZED_TELEMETRY"] = "False"
    
    # Paddle ccache warning
    os.environ["FLAGS_call_stack_level"] = "0"
    
    # Python warnings
    warnings.filterwarnings("ignore", category=UserWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    
    # Logging levels
    for logger_name in [
        "paddle", "ppocr", "PaddleOCR", "paddlex",
        "chromadb", "chromadb.telemetry",
        "urllib3", "httpx",
    ]:
        logging.getLogger(logger_name).setLevel(logging.ERROR)