import os
def delete():
    command = 'cls' if os.name == 'nt' else 'clear'
    os.system(command)