"""Input widgets"""

from typing import Union, Callable, Optional, List, Any
import base64
import html as html_lib
import io
import json
from ..component import Component
from ..context import rendering_ctx, layout_ctx
from ..state import State
from ..style_utils import merge_cls, merge_style, wrap_html


class UploadedFile(io.BytesIO):
    def __init__(self, name, type, size, content_b64):
        self.name = name
        self.type = type
        self.size = size
        # content_b64 is like "data:text/csv;base64,AAAA..."
        if "," in content_b64:
             self.header, data = content_b64.split(",", 1)
        else:
             self.header = ""
             data = content_b64
        try:
            decoded = base64.b64decode(data)
        except:
            decoded = b""
        super().__init__(decoded)
    
    def __str__(self):
        return self.name

    def __repr__(self):
        return f"<UploadedFile name='{self.name}' type='{self.type}' size={self.size}>"


class InputWidgetsMixin:

    @staticmethod
    def _label_vis_attrs(label_visibility):
        """Return (label_style, wrapper_style) for Streamlit label_visibility compat."""
        if label_visibility == "hidden":
            return 'style="visibility:hidden;height:0;overflow:hidden;"', ''
        elif label_visibility == "collapsed":
            return 'style="display:none;"', ''
        return '', ''  # "visible"

    def text_input(self, label, value="", key=None, on_change=None,
                   type="default", max_chars=None, placeholder="",
                   autocomplete=None, disabled=False,
                   label_visibility="visible", help=None,
                   cls: str = "", style: str = "", **props):
        """Single-line text input

        Args:
            type: Input type - "default" or "password"
            max_chars: Maximum number of characters
            placeholder: Placeholder text when empty
            autocomplete: HTML autocomplete attribute
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text shown below the input
        """
        _type = "password" if type == "password" else "text"
        extra = {}
        if _type != "text": extra["type"] = _type
        if max_chars is not None: extra["maxlength"] = max_chars
        if placeholder: extra["placeholder"] = placeholder
        if autocomplete: extra["autocomplete"] = autocomplete
        if disabled: extra["disabled"] = True
        if help: extra["help-text"] = help
        return self._input_component("input", "sl-input", label, value, on_change, key,
                                     cls=cls, style=style, label_visibility=label_visibility,
                                     **extra, **props)

    def slider(self, label, min_value=0, max_value=100, value=None, step=1,
               key=None, on_change=None, live_update=False,
               disabled=False, label_visibility="visible", help=None,
               cls: str = "", style: str = "", **props):
        """Slider widget

        Args:
            live_update: If True, value updates in real-time while dragging.
                         If False (default), value updates only when released.
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text shown below the slider
        """
        if value is None: value = min_value
        extra = {}
        if disabled: extra["disabled"] = True
        if help: extra["help-text"] = help
        return self._input_component("slider", "sl-range", label, value, on_change, key,
                                     cls=cls, style=style, live_update=live_update,
                                     label_visibility=label_visibility,
                                     min=min_value, max=max_value, step=step,
                                     **extra, **props)

    def select_slider(self, label, options=None, value=None, key=None, on_change=None, cls: str = "", style: str = "", **props):
        """Slider widget with discrete values from a list
        
        Args:
            label: Display label
            options: List of option values (strings, numbers, etc.)
            value: Default value (must be in options list)
            key: Widget key for state management
            on_change: Callback when value changes
        """
        if options is None or len(options) == 0:
            return None

        cid = self._get_next_cid("select_slider")
        state_key = key or f"select_slider:{label}"
        default_val = value if value is not None else options[0]
        s = self.state(default_val, key=state_key)
        options_str = [str(o) for o in options]

        def action(v):
            idx = int(v)
            actual = options[idx] if 0 <= idx < len(options) else options[0]
            s.set(actual)
            if on_change:
                on_change(actual)

        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)

            try:
                current_idx = options.index(cv)
            except ValueError:
                current_idx = 0

            max_idx = len(options) - 1
            n = len(options)
            # The labels will be calculated in ticks_html instead
            current_label = html_lib.escape(str(cv))
            range_id = f"{cid}_range"

            if self.mode == 'lite':
                attrs_str = f'hx-post="/action/{cid}" hx-trigger="sl-change" hx-swap="none" hx-vals="js:{{value: event.target.value}}"'
                listener_script = ""
            else:
                attrs_str = ""
                listener_script = f'''
                <script>
                (function() {{
                    var el = document.getElementById('{range_id}');
                    var display = document.getElementById('{cid}_display');
                    var opts = {json.dumps(options_str)};
                    if (el && !el.hasAttribute('data-ws-listener')) {{
                        el.setAttribute('data-ws-listener', 'true');
                        el.addEventListener('sl-input', function() {{
                            if (display) display.textContent = opts[parseInt(el.value)];
                        }});
                        el.addEventListener('sl-change', function() {{
                            window.sendAction('{cid}', el.value);
                        }});
                    }}
                }})();
                </script>
                '''

            props_str = ' '.join(f'{k}="{v}"' for k, v in props.items() if v is not None and v is not False)

            # 5. Position labels precisely using relative/absolute positioning
            # A standard Shoelace slider thumb is typically 15px-16px.
            # It travels from ~8px from the left to ~8px from the right.
            ticks_html = []
            if max_idx > 0:
                for i, o in enumerate(options):
                    percent = (i / max_idx) * 100
                    # Position explicitly on the track taking thumb size into account
                    ticks_html.append(
                        f'<span style="position:absolute; left:calc({percent}% - {percent / 100 * 16}px + 8px); '
                        f'transform:translateX(-50%); font-size:0.75rem; opacity:0.7; pointer-events:none;">'
                        f'{html_lib.escape(str(o))}</span>'
                    )
            else:
                ticks_html.append(
                    f'<span style="position:absolute; left:50%; transform:translateX(-50%); '
                    f'font-size:0.75rem; opacity:0.7;">{html_lib.escape(str(options[0]))}</span>'
                )
            ticks = ''.join(ticks_html)

            # 6. HTML Construction
            html_content = f'''
                <label style="display:block; font-size:0.875rem; font-weight:500; margin-bottom:0.25rem;">{html_lib.escape(str(label))}</label>
                <sl-range id="{range_id}" min="0" max="{max_idx}" step="1" value="{current_idx}" tooltip="none" {attrs_str} {props_str}></sl-range>
                <div style="position:relative; width:100%; height:1rem; margin-top:0.15rem;">
                    {ticks}
                </div>
                <div id="{cid}_display" style="text-align:center; font-weight:600; margin-top:0.25rem; font-size:0.875rem;">{current_label}</div>
            {listener_script}
            '''
            _wd = self._get_widget_defaults("select_slider")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            # Add default margin bottom
            base_style = "margin-bottom:1rem;"
            _fs = merge_style(base_style, _wd.get("style", ""))
            _fs = merge_style(_fs, style)
            
            return Component("div", id=cid, class_=_fc or None, style=_fs or None, content=html_content)
        self._register_component(cid, builder, action=action)
        return s

    def checkbox(self, label, value=False, key=None, on_change=None,
                  disabled=False, label_visibility="visible", help=None,
                  cls: str = "", style: str = "", **props):
        """Checkbox widget

        Args:
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text
        """
        cid = self._get_next_cid("checkbox")
        
        state_key = key or f"checkbox:{label}"
        s = self.state(value, key=state_key)
        
        def action(v):
            real_val = str(v).lower() == 'true'
            s.set(real_val)
            if on_change: on_change(real_val)
        
        def builder():
            # Subscribe to own state - client-side will handle smart updates
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            checked_attr = 'checked' if cv else ''
            props_str = ' '.join(f'{k}="{v}"' for k, v in props.items() if v is not None and v is not False)
            
            if self.mode == 'lite':
                attrs_str = f'hx-post="/action/{cid}" hx-trigger="sl-change" hx-swap="none" hx-vals="js:{{value: event.target.checked}}"'
                listener_script = ""
            else:
                # WS mode: use addEventListener for Shoelace custom events
                attrs_str = ""
                listener_script = f'''
                <script>
                (function() {{
                    const el = document.getElementById('{cid}');
                    if (el && !el.hasAttribute('data-ws-listener')) {{
                        el.setAttribute('data-ws-listener', 'true');
                        el.addEventListener('sl-change', function(e) {{
                            window.sendAction('{cid}', el.checked);
                        }});
                    }}
                }})();
                </script>
                '''
            
            disabled_attr = 'disabled' if disabled else ''
            help_html = f'<br><span style="font-size:0.75rem;color:var(--sl-text-muted);">{html_lib.escape(str(help))}</span>' if help else ''
            html = f'<sl-checkbox id="{cid}" {checked_attr} {disabled_attr} {attrs_str} {props_str}>{html_lib.escape(str(label))}{help_html}</sl-checkbox>{listener_script}'
            _wd = self._get_widget_defaults("checkbox")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component(None, id=cid, content=wrap_html(html, _fc, _fs))
        self._register_component(cid, builder, action=action)
        return s

    def radio(self, label, options, index=0, key=None, on_change=None,
              horizontal=False, captions=None,
              disabled=False, label_visibility="visible", help=None,
              cls: str = "", style: str = "", **props):
        """Radio button group

        Args:
            horizontal: If True, display options in a row
            captions: List of caption strings shown below each option
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text
        """
        cid = self._get_next_cid("radio_group")
        
        state_key = key or f"radio:{label}"
        default_val = options[index] if options else None
        s = self.state(default_val, key=state_key)
        
        def action(v):
            s.set(v)
            if on_change: on_change(v)
            
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            opts_html = ""
            for i_opt, opt in enumerate(options):
                sel = 'checked' if opt == cv else ''
                escaped_opt = html_lib.escape(str(opt), quote=True)
                caption_html = ''
                if captions and i_opt < len(captions) and captions[i_opt]:
                    caption_html = f'<br><span style="font-size:0.75rem;color:var(--sl-text-muted);font-weight:normal;">{html_lib.escape(str(captions[i_opt]))}</span>'
                opts_html += f'<sl-radio value="{escaped_opt}" {sel}>{escaped_opt}{caption_html}</sl-radio>'
            
            if self.mode == 'lite':
                attrs_str = f'hx-post="/action/{cid}" hx-trigger="sl-change" hx-swap="none" name="value"'
                listener_script = ""
            else:
                # WS mode: use addEventListener for Shoelace custom events
                attrs_str = ""
                listener_script = f'''
                <script>
                (function() {{
                    const el = document.getElementById('{cid}');
                    if (el && !el.hasAttribute('data-ws-listener')) {{
                        el.setAttribute('data-ws-listener', 'true');
                        el.addEventListener('sl-change', function(e) {{
                            window.sendAction('{cid}', el.value);
                        }});
                    }}
                }})();
                </script>
                '''
            
            props_str = ' '.join(f'{k}="{v}"' for k, v in props.items() if v is not None and v is not False)
            escaped_cv = html_lib.escape(str(cv), quote=True)
            disabled_attr = 'disabled' if disabled else ''
            help_attr = f'help-text="{html_lib.escape(str(help), quote=True)}"' if help else ''
            # Horizontal layout via fieldset attribute (Shoelace) + CSS override
            horiz_style = ' style="display:flex;flex-direction:row;flex-wrap:wrap;gap:1rem;"' if horizontal else ''
            html = f'<sl-radio-group id="{cid}" label="{label}" value="{escaped_cv}" {disabled_attr} {help_attr} {attrs_str} {props_str}><div{horiz_style}>{opts_html}</div></sl-radio-group>{listener_script}'
            
            _wd = self._get_widget_defaults("radio")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component(None, id=cid, content=wrap_html(html, _fc, _fs))
            
        self._register_component(cid, builder, action=action)
        return s

    @staticmethod
    def _sl_encode(v):
        """Encode a string for safe use as Shoelace sl-option value attribute.
        
        Shoelace sl-select treats the value attribute as a space-separated
        token list (like HTML class). Spaces in values break selection/matching.
        We percent-encode spaces (and %) to produce a single safe token.
        """
        s = str(v)
        s = s.replace('%', '%25')  # encode % first
        s = s.replace(' ', '%20')  # encode space
        return s

    @staticmethod
    def _sl_decode(v):
        """Decode a Shoelace-safe value back to the original string."""
        s = str(v)
        s = s.replace('%20', ' ')
        s = s.replace('%25', '%')
        return s

    def selectbox(self, label, options, index=0, key=None, on_change=None,
                   placeholder=None, disabled=False,
                   label_visibility="visible", help=None,
                   cls: str = "", style: str = "", **props):
        """Single select dropdown

        Args:
            placeholder: Placeholder text when nothing is selected
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text
        """
        cid = self._get_next_cid("select")
        
        state_key = key or f"select:{label}"
        default_val = options[index] if options else None
        s = self.state(default_val, key=state_key)
        
        def action(v):
            decoded = InputWidgetsMixin._sl_decode(v)
            s.set(decoded)
            if on_change: on_change(decoded)
            
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            opts_html = ""
            for opt in options:
                encoded_opt = InputWidgetsMixin._sl_encode(opt)
                escaped_encoded = html_lib.escape(encoded_opt, quote=True)
                escaped_display = html_lib.escape(str(opt), quote=True)
                sel = 'selected' if opt == cv else ''
                opts_html += f'<sl-option value="{escaped_encoded}" {sel}>{escaped_display}</sl-option>'
            
            encoded_cv = InputWidgetsMixin._sl_encode(cv) if cv is not None else ''
            escaped_cv = html_lib.escape(encoded_cv, quote=True)
            escaped_label = html_lib.escape(str(label), quote=True)
            
            if self.mode == 'lite':
                attrs = {"hx-post": f"/action/{cid}", "hx-trigger": "sl-change", "hx-swap": "none", "name": "value"}
                listener_script = ""
            else:
                # WS mode: use addEventListener for Shoelace custom events
                attrs = {}
                desired_json = json.dumps(encoded_cv, ensure_ascii=False)
                listener_script = f'''
                <script>
                (function() {{
                    const el = document.getElementById('{cid}');
                    const desiredValue = {desired_json};
                    if (el) {{
                        function syncValue() {{
                            if (el.value !== desiredValue) el.value = desiredValue;
                        }}
                        
                        syncValue();
                        
                        if (el.updateComplete) {{
                            el.updateComplete.then(syncValue);
                        }}
                        
                        requestAnimationFrame(function() {{
                            syncValue();
                            setTimeout(syncValue, 150);
                        }});
                        
                        if (!el.hasAttribute('data-ws-listener')) {{
                            el.setAttribute('data-ws-listener', 'true');
                            el.addEventListener('sl-change', function(e) {{
                                window.sendAction('{cid}', el.value);
                            }});
                        }}
                    }}
                }})();
                </script>
                '''
            
            select_html = f'<sl-select id="{cid}" label="{escaped_label}" value="{escaped_cv}"'
            extra_attrs = {}
            if placeholder: extra_attrs['placeholder'] = placeholder
            if disabled: extra_attrs['disabled'] = True
            if help: extra_attrs['help-text'] = help
            for k, v in {**attrs, **extra_attrs, **props}.items():
                if v is True:
                    select_html += f' {k}'
                elif v is not False and v is not None:
                    select_html += f' {k}="{v}"'
            select_html += f'>{opts_html}</sl-select>{listener_script}'
            
            _wd = self._get_widget_defaults("selectbox")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component(None, id=cid, content=wrap_html(select_html, _fc, _fs))
            
        self._register_component(cid, builder, action=action)
        return s

    def multiselect(self, label, options, default=None, key=None, on_change=None,
                     max_selections=None, placeholder=None, disabled=False,
                     label_visibility="visible", help=None,
                     cls: str = "", style: str = "", **props):
        """Multi-select dropdown

        Args:
            max_selections: Maximum number of selections allowed
            placeholder: Placeholder text when nothing is selected
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text
        """
        cid = self._get_next_cid("multiselect")
        
        state_key = key or f"multiselect:{label}"
        default_val = default or []
        s = self.state(default_val, key=state_key)
        
        def action(v):
            if isinstance(v, str):
                selected = [InputWidgetsMixin._sl_decode(x.strip()) for x in v.split(',') if x.strip()]
            elif isinstance(v, list):
                selected = [InputWidgetsMixin._sl_decode(x) for x in v]
            else:
                selected = []
            s.set(selected)
            if on_change: on_change(selected)
        
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            opts_html = ""
            for opt in options:
                encoded_opt = InputWidgetsMixin._sl_encode(opt)
                escaped_encoded = html_lib.escape(encoded_opt, quote=True)
                escaped_display = html_lib.escape(str(opt), quote=True)
                sel = 'selected' if opt in cv else ''
                opts_html += f'<sl-option value="{escaped_encoded}" {sel}>{escaped_display}</sl-option>'
            
            listener_script = ""
            if self.mode == 'ws':
                encoded_cv = [InputWidgetsMixin._sl_encode(x) for x in cv] if cv else []
                desired_json = json.dumps(encoded_cv, ensure_ascii=False)
                listener_script = f'''
                <script>
                (function() {{
                    const el = document.getElementById('{cid}');
                    const desiredValue = {desired_json};
                    if (el) {{
                        function syncValue() {{
                            const current = Array.isArray(el.value) ? el.value.join(',') : '';
                            const desired = desiredValue.join(',');
                            if (current !== desired) el.value = desiredValue;
                        }}
                        
                        syncValue();
                        
                        if (el.updateComplete) {{
                            el.updateComplete.then(syncValue);
                        }}
                        
                        requestAnimationFrame(function() {{
                            syncValue();
                            setTimeout(syncValue, 150);
                        }});
                        
                        if (!el.hasAttribute('data-ws-listener')) {{
                            el.setAttribute('data-ws-listener', 'true');
                            el.addEventListener('sl-change', function(e) {{
                                const vals = Array.isArray(el.value) ? el.value : (el.value ? [el.value] : []);
                                window.sendAction('{cid}', vals.join(','));
                            }});
                        }}
                    }}
                }})();
                </script>
                '''

            _wd = self._get_widget_defaults("multiselect")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            # sl-select: cls/style applied via wrapper since this is a Shoelace component
            # label escaping handled by Component.render(); opts_html is raw so manually escaped above
            _ms_extra = {}
            if placeholder: _ms_extra['placeholder'] = placeholder
            if disabled: _ms_extra['disabled'] = True
            if help: _ms_extra['help-text'] = help
            if max_selections: _ms_extra['max-options-visible'] = max_selections
            inner = Component("sl-select", id=cid, label=label, content=opts_html, multiple=True, clearable=True, **_ms_extra)
            inner_html = inner.render() + listener_script
            if _fc or _fs:
                return Component(None, id=f"{cid}_wrap", content=wrap_html(inner_html, _fc, _fs))
            return Component(None, id=cid, content=inner_html)
        
        self._register_component(cid, builder, action=action)
        
        # Add initialization script for lite mode
        if self.mode == 'lite':
            init_script_cid = f"{cid}_init"
            def script_builder():
                script = f'''
                <script>
                (function() {{
                    function initSelect() {{
                        const el = document.getElementById('{cid}');
                        if (!el) {{
                            setTimeout(initSelect, 50);
                            return;
                        }}
                        if (!el.hasAttribute('data-listener-added')) {{
                            el.setAttribute('data-listener-added', 'true');
                            el.addEventListener('sl-change', function(e) {{
                                const values = Array.isArray(el.value) ? el.value : [];
                                const valueStr = values.join(',');
                                htmx.ajax('POST', '/action/{cid}', {{
                                    values: {{ value: valueStr }},
                                    swap: 'none'
                                }});
                            }});
                        }}
                    }}
                    initSelect();
                }})();
                </script>
                '''
                return Component("div", id=init_script_cid, style="display:none", content=script)
            
            self.static_builders[init_script_cid] = script_builder
            if layout_ctx.get() == "sidebar":
                if init_script_cid not in self.static_sidebar_order:
                    self.static_sidebar_order.append(init_script_cid)
            else:
                if init_script_cid not in self.static_order:
                    self.static_order.append(init_script_cid)
        
        return s

    def text_area(self, label, value="", height=None, key=None, on_change=None,
                   max_chars=None, placeholder="", disabled=False,
                   label_visibility="visible", help=None,
                   cls: str = "", style: str = "", **props):
        """Multi-line text input

        Args:
            height: Number of visible text rows (default: 3)
            max_chars: Maximum number of characters
            placeholder: Placeholder text when empty
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text
        """
        cid = self._get_next_cid("textarea")
        
        state_key = key or f"textarea:{label}"
        s = self.state(value, key=state_key)
        
        def action(v):
            s.set(v)
            if on_change: on_change(v)
        
        def builder():
            # Create local shallow copies of cls/style to avoid shadowing/unbound errors
            _cls = cls
            _style = style

            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            if self.mode == 'lite':
                attrs = {"hx-post": f"/action/{cid}", "hx-trigger": "sl-input delay:50ms", "hx-swap": "none", "name": "value"}
                listener_script = ""
            else:
                # WS mode: use addEventListener for Shoelace custom events
                attrs = {}
                listener_script = f'''
                <script>
                (function() {{
                    const el = document.getElementById('{cid}');
                    if (el && !el.hasAttribute('data-ws-listener')) {{
                        el.setAttribute('data-ws-listener', 'true');
                        el.addEventListener('sl-input', function(e) {{
                            window.sendAction('{cid}', el.value);
                        }});
                    }}
                }})();
                </script>
                '''
            
            textarea_props = {"resize": "auto"}
            if height:
                h_str = str(height)
                if h_str.endswith("rows"):
                    # Explicit rows: "10rows" -> 10
                    try:
                        textarea_props["rows"] = int(h_str.replace("rows", "").strip())
                    except ValueError:
                        textarea_props["rows"] = 3
                else:
                    # Everything else: Treat as pixels (Streamlit default)
                    # "200", 200, "200px" -> 200px
                    val = h_str.replace("px", "").strip()
                    _style = merge_style(f"height: {val}px;", _style)
            else:
                textarea_props["rows"] = 3

            if max_chars is not None: textarea_props["maxlength"] = max_chars
            if placeholder: textarea_props["placeholder"] = placeholder
            if disabled: textarea_props["disabled"] = True
            if help: textarea_props["help-text"] = help
            html = f'<sl-textarea id="{cid}" label="{label}" value="{cv}"'
            for k, v in {**attrs, **textarea_props, **props}.items():
                if v is True: html += f' {k}'
                elif v is not False and v is not None: html += f' {k}="{v}"'
            html += f'></sl-textarea>{listener_script}'
            
            _wd = self._get_widget_defaults("text_area")
            _fc = merge_cls(_wd.get("cls", ""), _cls)
            _fs = merge_style(_wd.get("style", ""), _style)
            return Component(None, id=cid, content=wrap_html(html, _fc, _fs))
        
        self._register_component(cid, builder, action=action)
        return s

    def number_input(self, label, value=0, min_value=None, max_value=None, step=1,
                      key=None, on_change=None,
                      placeholder="", disabled=False,
                      label_visibility="visible", help=None,
                      cls: str = "", style: str = "", **props):
        """Numeric input

        Args:
            placeholder: Placeholder text when empty
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text
        """
        cid = self._get_next_cid("number")
        
        state_key = key or f"number:{label}"
        s = self.state(value, key=state_key)
        
        def action(v):
            try:
                num_val = float(v) if '.' in str(v) else int(v)
                s.set(num_val)
                if on_change: on_change(num_val)
            except (ValueError, TypeError):
                pass
        
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            if self.mode == 'lite':
                attrs = {"hx-post": f"/action/{cid}", "hx-trigger": "sl-input delay:50ms", "hx-swap": "none", "name": "value"}
                listener_script = ""
            else:
                # WS mode: use addEventListener
                attrs = {}
                listener_script = f'''
                <script>
                (function() {{
                    const el = document.getElementById('{cid}');
                    if (el && !el.hasAttribute('data-ws-listener')) {{
                        el.setAttribute('data-ws-listener', 'true');
                        el.addEventListener('sl-input', function(e) {{
                            window.sendAction('{cid}', el.value);
                        }});
                    }}
                }})();
                </script>
                '''
            
            num_props = {"type": "number"}
            if min_value is not None: num_props["min"] = min_value
            if max_value is not None: num_props["max"] = max_value
            if step is not None: num_props["step"] = step
            if placeholder: num_props["placeholder"] = placeholder
            if disabled: num_props["disabled"] = True
            if help: num_props["help-text"] = help
            
            html = f'<sl-input id="{cid}" label="{label}" value="{cv}"'
            for k, v in {**attrs, **num_props, **props}.items():
                if v is True: html += f' {k}'
                elif v is not False and v is not None: html += f' {k}="{v}"'
            html += f'></sl-input>{listener_script}'
            
            _wd = self._get_widget_defaults("number_input")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component(None, id=cid, content=wrap_html(html, _fc, _fs))
        
        self._register_component(cid, builder, action=action)
        return s

    def file_uploader(self, label, type=None, accept=None, accept_multiple_files=False, multiple=False,
                       key=None, on_change=None, help=None, disabled=False,
                       label_visibility="visible",
                       cls: str = "", style: str = "", **props):
        """File upload widget

        Args:
            type: Accepted file types (Streamlit compat alias for accept)
            accept: Accepted file types (e.g. "image/*", ".csv,.xlsx")
            accept_multiple_files: If True, allow multiple files (Streamlit compat)
            multiple: If True, allow multiple files
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
        """
        # Streamlit compat: 'type' maps to 'accept'
        if type is not None and accept is None:
            if isinstance(type, list): accept = ','.join(type)
            else: accept = type
        # Streamlit compat: accept_multiple_files
        if accept_multiple_files: multiple = True
        cid = self._get_next_cid("file")
        
        state_key = key or f"file:{label}"
        s = self.state(None, key=state_key)
        
        def action(v):
            if v:
                try:
                    # v might be a JSON string if from Lite mode
                    if isinstance(v, str) and v.startswith('{'):
                         try:
                             data = json.loads(v)
                         except:
                             data = v
                    else:
                        data = v
                    
                    if isinstance(data, dict):
                        if "content" in data:
                            # Single file
                            uf = UploadedFile(data.get("name"), data.get("type"), data.get("size"), data.get("content"))
                            s.set(uf)
                            if on_change: on_change(uf)
                            return
                        elif "files" in data:
                             # Multiple files
                             files = []
                             for f_data in data["files"]:
                                 files.append(UploadedFile(f_data.get("name"), f_data.get("type"), f_data.get("size"), f_data.get("content")))
                             s.set(files)
                             if on_change: on_change(files)
                             return
                except Exception as e:
                    print(f"File upload error: {e}")
            
            s.set(None)
            if on_change: on_change(None)
        
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            # Build file info display
            if cv:
                if isinstance(cv, list):
                    file_info = f"✅ {len(cv)} file(s) uploaded"
                else:
                    size_kb = cv.size / 1024
                    size_str = f"{size_kb:.1f}KB" if size_kb < 1024 else f"{size_kb/1024:.1f}MB"
                    file_info = f"✅ {cv.name} ({size_str})"
            else:
                file_info = ""
            
            accept_str = accept if accept else "*"
            help_html = f'<div style="font-size:0.75rem;color:var(--sl-text-muted);margin-top:0.25rem;">{help}</div>' if help else ""
            
            html = f'''
            <div class="file-uploader" style="margin-bottom:1rem;">
                <label style="display:block;margin-bottom:0.5rem;font-weight:500;color:var(--sl-text);">{label}</label>
                <input type="file" id="{cid}_input" accept="{accept_str}" {'multiple' if multiple else ''} 
                       style="display:block;padding:0.5rem;border:1px solid var(--sl-border);border-radius:0.25rem;background:var(--sl-bg-card);color:var(--sl-text);width:100%;font-family:inherit;cursor:pointer;" />
                {help_html}
                <div id="{cid}_info" style="margin-top:0.5rem;font-size:0.875rem;color:var(--sl-text-muted);">{file_info}</div>
            </div>
            <script>
            (function() {{
                const input = document.getElementById('{cid}_input');
                const infoDiv = document.getElementById('{cid}_info');
                
                if (input && !input.hasAttribute('data-listener-added')) {{
                    input.setAttribute('data-listener-added', 'true');
                    
                    input.addEventListener('change', function(e) {{
                        const files = e.target.files;
                        if (files && files.length > 0) {{
                            infoDiv.textContent = '⏳ Uploading...';
                            
                            const fileArray = Array.from(files);
                            const promises = fileArray.map(file => {{
                                return new Promise((resolve, reject) => {{
                                    const reader = new FileReader();
                                    reader.onload = function(ev) {{
                                        resolve({{
                                            name: file.name,
                                            type: file.type,
                                            size: file.size,
                                            content: ev.target.result
                                        }});
                                    }};
                                    reader.onerror = function(err) {{
                                        reject(err);
                                    }};
                                    reader.readAsDataURL(file);
                                }});
                            }});
                            
                            Promise.all(promises).then(function(results) {{
                                let payload;
                                if ({'true' if multiple else 'false'}) {{
                                    payload = {{files: results}};
                                }} else {{
                                    payload = results[0];
                                }}
                                
                                // Update UI immediately
                                if ({'true' if multiple else 'false'}) {{
                                    infoDiv.textContent = '✅ ' + results.length + ' file(s) uploaded';
                                }} else {{
                                    const file = results[0];
                                    const sizeKB = (file.size / 1024).toFixed(1);
                                    infoDiv.textContent = '✅ ' + file.name + ' (' + sizeKB + ' KB)';
                                }}
                                
                                // Send to backend
                                if (window.sendAction) {{
                                    // WebSocket mode
                                    window.sendAction('{cid}', payload);
                                }} else if (window.htmx) {{
                                    // HTMX mode
                                    htmx.ajax('POST', '/action/{cid}', {{
                                        values: {{ value: JSON.stringify(payload) }},
                                        swap: 'none'
                                    }});
                                }}
                            }}).catch(function(err) {{
                                infoDiv.textContent = '❌ Upload failed';
                                console.error('File upload error:', err);
                            }});
                        }}
                    }});
                }}
            }})();
            </script>
            '''
            _wd = self._get_widget_defaults("file_uploader")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component("div", id=cid, content=html, class_=_fc or None, style=_fs or None)
        
        self._register_component(cid, builder, action=action)
        return s

    def toggle(self, label, value=False, key=None, on_change=None,
               disabled=False, label_visibility="visible", help=None,
               cls: str = "", style: str = "", **props):
        """Toggle switch widget

        Args:
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
            help: Tooltip / help text
        """
        cid = self._get_next_cid("toggle")
        
        state_key = key or f"toggle:{label}"
        s = self.state(value, key=state_key)
        
        def action(v):
            real_val = str(v).lower() == 'true'
            s.set(real_val)
            if on_change: on_change(real_val)
        
        def builder():
            # Subscribe to own state - client-side will handle smart updates
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            checked_attr = 'checked' if cv else ''
            props_str = ' '.join(f'{k}="{v}"' for k, v in props.items() if v is not None and v is not False)
            
            if self.mode == 'lite':
                attrs_str = f'hx-post="/action/{cid}" hx-trigger="sl-change" hx-swap="none" hx-vals="js:{{value: event.target.checked}}"'
                listener_script = ""
            else:
                # WS mode: use addEventListener for Shoelace custom events
                attrs_str = ""
                listener_script = f'''
                <script>
                (function() {{
                    const el = document.getElementById('{cid}');
                    if (el && !el.hasAttribute('data-ws-listener')) {{
                        el.setAttribute('data-ws-listener', 'true');
                        el.addEventListener('sl-change', function(e) {{
                            window.sendAction('{cid}', el.checked);
                        }});
                    }}
                }})();
                </script>
                '''
            
            disabled_attr = 'disabled' if disabled else ''
            help_html = f'<br><span style="font-size:0.75rem;color:var(--sl-text-muted);">{html_lib.escape(str(help))}</span>' if help else ''
            html = f'<sl-switch id="{cid}" {checked_attr} {disabled_attr} {attrs_str} {props_str}>{label}{help_html}</sl-switch>{listener_script}'
            _wd = self._get_widget_defaults("toggle")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component(None, id=cid, content=wrap_html(html, _fc, _fs))
        self._register_component(cid, builder, action=action)
        return s

    def color_picker(self, label="Pick a color", value="#000000", key=None, on_change=None,
                      disabled=False, label_visibility="visible",
                      cls: str = "", style: str = "", **props):
        """Color picker widget

        Args:
            disabled: If True, widget is grayed out
            label_visibility: "visible", "hidden", or "collapsed"
        """
        cid = self._get_next_cid("color")
        
        state_key = key or f"color:{label}"
        s = self.state(value, key=state_key)
        
        def action(v):
            s.set(v)
            if on_change: on_change(v)
        
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            if self.mode == 'lite':
                attrs = {"hx-post": f"/action/{cid}", "hx-trigger": "sl-change", "hx-swap": "none", "name": "value"}
            else:
                attrs = {"on_sl_change": f"window.sendAction('{cid}', this.value)"}
            
            inner = Component("sl-color-picker", id=cid, label=label, value=cv, **attrs, **props)
            _wd = self._get_widget_defaults("color_picker")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            if _fc or _fs:
                return Component("div", id=f"{cid}_wrap", content=inner.render(), class_=_fc or None, style=_fs or None)
            return inner
        
        self._register_component(cid, builder, action=action)
        return s

    def date_input(self, label="Select date", value=None, key=None, on_change=None, cls: str = "", style: str = "", **props):
        """Date picker widget"""
        import datetime
        cid = self._get_next_cid("date")
        
        state_key = key or f"date:{label}"
        default_val = value if value else datetime.date.today().isoformat()
        s = self.state(default_val, key=state_key)
        
        def action(v):
            s.set(v)
            if on_change: on_change(v)
        
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            if self.mode == 'lite':
                attrs = {"hx-post": f"/action/{cid}", "hx-trigger": "change", "hx-swap": "none", "name": "value"}
            else:
                attrs = {"onchange": f"window.sendAction('{cid}', this.value)"}
            
            html = f'''
            <div style="margin-bottom: 0.5rem;">
                <label style="display:block;margin-bottom:0.5rem;font-weight:500;color:var(--sl-text);">{label}</label>
                <input type="date" id="{cid}_input" value="{cv}" 
                       style="width:100%;padding:0.5rem;border:1px solid var(--sl-border);border-radius:0.5rem;background:var(--sl-bg-card);color:var(--sl-text);font-family:inherit;"
                       {' '.join(f'{k}="{v}"' for k,v in attrs.items())} />
            </div>
            '''
            _wd = self._get_widget_defaults("date_input")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component("div", id=cid, content=html, class_=_fc or None, style=_fs or None)
        
        self._register_component(cid, builder, action=action)
        return s

    def time_input(self, label="Select time", value=None, key=None, on_change=None, cls: str = "", style: str = "", **props):
        """Time picker widget"""
        import datetime
        cid = self._get_next_cid("time")
        
        state_key = key or f"time:{label}"
        default_val = value if value else datetime.datetime.now().strftime("%H:%M")
        s = self.state(default_val, key=state_key)
        
        def action(v):
            s.set(v)
            if on_change: on_change(v)
        
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            if self.mode == 'lite':
                attrs = {"hx-post": f"/action/{cid}", "hx-trigger": "change", "hx-swap": "none", "name": "value"}
            else:
                attrs = {"onchange": f"window.sendAction('{cid}', this.value)"}
            
            html = f'''
            <div style="margin-bottom: 0.5rem;">
                <label style="display:block;margin-bottom:0.5rem;font-weight:500;color:var(--sl-text);">{label}</label>
                <input type="time" id="{cid}_input" value="{cv}" 
                       style="width:100%;padding:0.5rem;border:1px solid var(--sl-border);border-radius:0.5rem;background:var(--sl-bg-card);color:var(--sl-text);font-family:inherit;"
                       {' '.join(f'{k}="{v}"' for k,v in attrs.items())} />
            </div>
            '''
            _wd = self._get_widget_defaults("time_input")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component("div", id=cid, content=html, class_=_fc or None, style=_fs or None)
        
        self._register_component(cid, builder, action=action)
        return s

    def datetime_input(self, label="Select date and time", value=None, key=None, on_change=None, cls: str = "", style: str = "", **props):
        """DateTime picker widget"""
        import datetime
        cid = self._get_next_cid("datetime")
        
        state_key = key or f"datetime:{label}"
        default_val = value if value else datetime.datetime.now().strftime("%Y-%m-%dT%H:%M")
        s = self.state(default_val, key=state_key)
        
        def action(v):
            s.set(v)
            if on_change: on_change(v)
        
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            if self.mode == 'lite':
                attrs = {"hx-post": f"/action/{cid}", "hx-trigger": "change", "hx-swap": "none", "name": "value"}
            else:
                attrs = {"onchange": f"window.sendAction('{cid}', this.value)"}
            
            html = f'''
            <div style="margin-bottom: 0.5rem;">
                <label style="display:block;margin-bottom:0.5rem;font-weight:500;color:var(--sl-text);">{label}</label>
                <input type="datetime-local" id="{cid}_input" value="{cv}" 
                       style="width:100%;padding:0.5rem;border:1px solid var(--sl-border);border-radius:0.5rem;background:var(--sl-bg-card);color:var(--sl-text);font-family:inherit;"
                       {' '.join(f'{k}="{v}"' for k,v in attrs.items())} />
            </div>
            '''
            _wd = self._get_widget_defaults("datetime_input")
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component("div", id=cid, content=html, class_=_fc or None, style=_fs or None)
        
        self._register_component(cid, builder, action=action)
        return s

    def _input_component(self, type_name, tag_name, label, value, on_change, key=None, cls: str = "", style: str = "", live_update=False, label_visibility="visible", **props):
        """Generic input component builder"""
        cid = self._get_next_cid(type_name)
        
        state_key = key or f"{type_name}:{label}"
        s = self.state(value, key=state_key)
        
        def action(v):
            if type_name == 'slider': 
                v = float(v) if '.' in str(v) else int(v)
            s.set(v)
            if on_change: on_change(v)
        
        # Choose event: sl-input fires during drag, sl-change fires on release
        sl_event = 'sl-input' if live_update else 'sl-change'
        
        def builder():
            token = rendering_ctx.set(cid)
            cv = s.value
            rendering_ctx.reset(token)
            
            if self.mode == 'lite':
                attrs_str = f'hx-post="/action/{cid}" hx-trigger="{sl_event}" hx-swap="none" name="value"'
                listener_script = ""
            else:
                # WS mode: use addEventListener for Shoelace custom events
                attrs_str = ""
                listener_script = f'''
                <script>
                (function() {{
                    const el = document.getElementById('{cid}');
                    if (el && !el.hasAttribute('data-ws-listener')) {{
                        el.setAttribute('data-ws-listener', 'true');
                        el.addEventListener('{sl_event}', function(e) {{
                            window.sendAction('{cid}', el.value);
                        }});
                    }}
                }})();
                </script>
                '''
            
            # Build props - handle boolean attrs & hyphenated names (e.g. help-text)
            parts = []
            for k, v in props.items():
                if v is None or v is False:
                    continue
                if v is True:
                    parts.append(k)
                else:
                    parts.append(f'{k}="{v}"')
            props_str = ' '.join(parts)
            escaped_cv = html_lib.escape(str(cv), quote=True)
            # label_visibility support
            _lbl = label
            if label_visibility == "hidden":
                _lbl = ""  # Shoelace still reserves space for empty label
            elif label_visibility == "collapsed":
                _lbl = ""
            html = f'<{tag_name} id="{cid}" label="{_lbl}" value="{escaped_cv}" {attrs_str} {props_str}></{tag_name}>{listener_script}'
            
            _wd = self._get_widget_defaults(type_name)
            _fc = merge_cls(_wd.get("cls", ""), cls)
            _fs = merge_style(_wd.get("style", ""), style)
            return Component(None, id=cid, content=wrap_html(html, _fc, _fs))
        self._register_component(cid, builder, action=action)
        return s
