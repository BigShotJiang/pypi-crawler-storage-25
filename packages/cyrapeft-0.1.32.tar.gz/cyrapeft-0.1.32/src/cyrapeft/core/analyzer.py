import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
from datasets import load_dataset
from tqdm import tqdm
import pandas as pd
import json
import os
import time

def evaluate_perplexity(model, tokenizer):
    print("Running Official Wikitext-2 Perplexity Benchmark...")
    test = load_dataset("wikitext", "wikitext-2-raw-v1", split="test")
    encodings = tokenizer("\n\n".join(test["text"]), return_tensors="pt")
    
    max_length = 2048
    stride = 512
    seq_len = encodings.input_ids.size(1)

    nlls = []
    prev_end_loc = 0
    for begin_loc in tqdm(range(0, seq_len, stride)):
        end_loc = min(begin_loc + max_length, seq_len)
        trg_len = end_loc - prev_end_loc
        input_ids = encodings.input_ids[:, begin_loc:end_loc].to("cuda")
        target_ids = input_ids.clone()
        target_ids[:, :-trg_len] = -100

        with torch.no_grad():
            outputs = model(input_ids, labels=target_ids)
            neg_log_likelihood = outputs.loss
        nlls.append(neg_log_likelihood * trg_len)
        prev_end_loc = end_loc
        if end_loc == seq_len: break

    ppl = torch.exp(torch.stack(nlls).sum() / end_loc)
    return ppl.item()

def evaluate_hellaswag(model, tokenizer, num_samples=50):
    print(f"Running Standardized HellaSwag Zero-Shot Benchmark ({num_samples} samples)...")
    dataset = load_dataset("hellaswag", split="validation", trust_remote_code=True)
    
    correct = 0
    total = min(num_samples, len(dataset))
    
    for i in tqdm(range(total)):
        example = dataset[i]
        context = example['ctx']
        endings = example['endings']
        label = int(example['label'])
        
        losses = []
        for ending in endings:
            full_text = f"{context} {ending}"
            inputs = tokenizer(full_text, return_tensors="pt").to("cuda")
            labels = inputs.input_ids.clone()
            ctx_len = len(tokenizer(context)["input_ids"])
            labels[:, :ctx_len] = -100 
            with torch.no_grad():
                outputs = model(**inputs, labels=labels)
                losses.append(outputs.loss.item())
        
        prediction = losses.index(min(losses))
        if prediction == label:
            correct += 1
            
    return (correct / total) * 100

def run_analysis(output_dir, model_name):
    metrics_path = os.path.join(output_dir, "metrics.json")
    if not os.path.exists(metrics_path):
        raise FileNotFoundError(f"metrics.json not found in {output_dir}")

    with open(metrics_path, "r") as f:
        metrics_history = json.load(f)
    
    # Use from_dict with orient='index' to allow lists of different lengths (pads with NaN)
    df_train = pd.DataFrame.from_dict(metrics_history, orient='index').transpose()
    df_train.to_csv(os.path.join(output_dir, "research_train_history.csv"), index=False)

    from transformers import BitsAndBytesConfig
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    quantization_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)
    
    base_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        quantization_config=quantization_config,
        device_map="auto",
        torch_dtype=torch.float16
    )
    model = PeftModel.from_pretrained(base_model, output_dir)
    
    ppl = evaluate_perplexity(model, tokenizer)
    hswag_acc = evaluate_hellaswag(model, tokenizer)
    
    master_log_path = "MASTER_RESEARCH_REPORT.csv"
    new_entry = {
        "Run_ID": os.path.basename(output_dir),
        "Model": model_name,
        "Final_Loss": df_train["train_loss"].iloc[-1] if "train_loss" in df_train else "N/A",
        "Wikitext_PPL": round(ppl, 4),
        "HellaSwag_Acc": f"{hswag_acc:.1f}%",
        "Timestamp": time.strftime("%Y-%m-%d %H:%M")
    }
    
    master_df = pd.DataFrame([new_entry])
    if not os.path.exists(master_log_path):
        master_df.to_csv(master_log_path, index=False)
    else:
        master_df.to_csv(master_log_path, mode='a', header=False, index=False)
    
    return {"perplexity": ppl, "hellaswag": hswag_acc}
