import argparse
import sys
import yaml
import torch
import os
import logging
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import LoraConfig
from torch.utils.data import DataLoader

try:
    import unsloth
except ImportError:
    pass

from cyrapeft import __version__
from cyrapeft.config.config import CyraConfig
from cyrapeft.core.model import AdaptiveLoRAModel
from cyrapeft.core.trainer import CyraTrainer
from cyrapeft.utils.logging import logger


def train_func_wrapper(config_dict):
    """
    The function that runs on each Ray worker (or locally).
    """
    args = config_dict["args"]
    config = config_dict["config"]
    
    # Setup Ray Torch environment if using Ray
    if args.use_ray:
        import ray.train.torch
        ray.train.torch.enable_reproducibility()
    
    logger.info(f"Loading Model: {config.model_name}")
    tokenizer = AutoTokenizer.from_pretrained(config.model_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        
    model_kwargs = {"device_map": "auto" if not args.use_ray and torch.cuda.is_available() else None}
    
    if args.use_unsloth:
        try:
            from unsloth import FastLanguageModel
            logger.info("Initializing Unsloth FastLanguageModel Turbo Mode...")
            base_model, tokenizer = FastLanguageModel.from_pretrained(
                model_name = config.model_name,
                max_seq_length = 512,
                load_in_4bit = True,
                device_map = model_kwargs["device_map"]
            )
            logger.info("Unsloth Model loaded successfully.")
        except ImportError:
            logger.error("Unsloth not installed. Please run: pip install unsloth")
            sys.exit(1)
    else:
        tokenizer = AutoTokenizer.from_pretrained(config.model_name)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
            
        if args.quantize_4bit:
            try:
                from transformers import BitsAndBytesConfig
                model_kwargs["quantization_config"] = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.float16,
                    bnb_4bit_use_double_quant=True,
                    bnb_4bit_quant_type="nf4"
                )
                logger.info("Enabled 4-bit quantization.")
            except ImportError:
                logger.warning("bitsandbytes not installed, skipping quantization.")
        
        base_model = AutoModelForCausalLM.from_pretrained(config.model_name, **model_kwargs)

    target_modules = ["c_attn"] if "gpt2" in config.model_name.lower() else ["q_proj", "v_proj"]
    if args.target_modules:
        target_modules = args.target_modules.split(",")
        
    lora_config = LoraConfig(
        r=config.lora_r,
        lora_alpha=config.lora_alpha_init,
        lora_dropout=config.lora_dropout,
        target_modules=target_modules
    )
    
    model = AdaptiveLoRAModel(base_model, lora_config, init_alpha=config.lora_alpha_init)
    
    if args.gradient_checkpointing:
        model.model.gradient_checkpointing_enable()
        logger.info("Enabled Gradient Checkpointing.")

    logger.info(f"Loading Dataset: {args.dataset}")
    try:
        from datasets import load_dataset
        if args.dataset_config:
            raw_dataset = load_dataset(args.dataset, args.dataset_config, split=args.dataset_split)
        else:
            raw_dataset = load_dataset(args.dataset, split=args.dataset_split)
            
        # Slice dataset if max_samples is set
        if config.max_samples and config.max_samples < len(raw_dataset):
            logger.info(f"Slicing dataset to {config.max_samples} samples.")
            raw_dataset = raw_dataset.select(range(config.max_samples))
        
        def tokenize_function(examples):
            col = 'text' if 'text' in examples else list(examples.keys())[0]
            tokens = tokenizer(examples[col], padding="max_length", truncation=True, max_length=512)
            labels = []
            for input_ids in tokens["input_ids"]:
                label = [token if token != tokenizer.pad_token_id else -100 for token in input_ids]
                labels.append(label)
            tokens["labels"] = labels
            return tokens
            
        tokenized_datasets = raw_dataset.map(tokenize_function, batched=True, remove_columns=raw_dataset.column_names)
        tokenized_datasets.set_format("torch")
    except ImportError:
        logger.error("The 'datasets' library is required to load remote datasets. Please run: pip install datasets")
        sys.exit(1)
        
    final_metrics = {}
    if not args.use_ray:
        train_loader = DataLoader(tokenized_datasets, batch_size=config.batch_size, shuffle=True)
        trainer = CyraTrainer(model=model, config=config, train_loader=train_loader, val_loader=None, use_ray=False)
        final_metrics = trainer.train()
    else:
        # Ray logic...
        import ray.train.torch
        train_loader = DataLoader(tokenized_datasets, batch_size=config.batch_size, shuffle=True)
        model.model = ray.train.torch.prepare_model(model.model)
        train_loader = ray.train.torch.prepare_data_loader(train_loader)
        trainer = CyraTrainer(model=model, config=config, train_loader=train_loader, val_loader=None, use_ray=True)
        final_metrics = trainer.train()
        
    return final_metrics

def train_command(args):
    logger.info("Starting CyraPEFT training setup...")
    
    # Global Seeding for Reproducibility
    if args.seed is not None:
        import numpy as np
        import random
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(args.seed)
        logger.info(f"Global seed set to: {args.seed}")
    if args.config:
        config = CyraConfig.from_yaml(args.config)
    else:
        config = CyraConfig()
        
    if args.model_name: config.model_name = args.model_name
    if args.batch_size: config.batch_size = args.batch_size
    if args.epochs: config.epochs = args.epochs
    if args.learning_rate: config.learning_rate = args.learning_rate
    if args.alpha: config.lora_alpha_init = args.alpha
    if args.use_swarm: config.swarm.enabled = True
    if args.gradient_checkpointing: config.gradient_checkpointing = True
    if args.max_samples: config.max_samples = args.max_samples
    if args.gradient_accumulation_steps: config.gradient_accumulation_steps = args.gradient_accumulation_steps
    
    if args.disable_difficulty: config.difficulty.enabled = False
    if args.disable_controller: config.controller.enabled = False
    
    config.output_dir = args.output_dir
    logger.info(f"Using Configuration: {config}")

    config_dict = {"args": args, "config": config}
    
    # Run training and capture metrics
    metrics = None
    if args.use_ray:
        logger.info(f"Initializing Ray Train with {args.num_workers} workers...")
        import ray
        from ray.train.torch import TorchTrainer
        from ray.train import ScalingConfig
        
        # Initialize Ray if not already running
        ray.init(ignore_reinit_error=True)
        
        trainer = TorchTrainer(
            train_loop_per_worker=train_func_wrapper,
            train_loop_config=config_dict,
            scaling_config=ScalingConfig(num_workers=args.num_workers, use_gpu=torch.cuda.is_available())
        )
        
        result = trainer.fit()
        logger.info(f"Ray Training completed. Results: {result.metrics}")
    else:
        metrics = train_func_wrapper(config_dict)
        
    if metrics:
        logger.info("="*50)
        logger.info("CYRAPEFT TRAINING COMPLETE - FINAL METRICS SUMMARY")
        logger.info("="*50)
        for k, v in metrics.items():
            if isinstance(v, list) and len(v) > 0:
                logger.info(f"{k:20}: {v[-1]:.4f} (Final)")
            elif isinstance(v, (float, int)):
                logger.info(f"{k:20}: {v:.4f}")
        logger.info("="*50)

def eval_command(args):
    logger.info(f"Evaluating CyraPEFT model from {args.model_path}")
    logger.info("Evaluation finished. (Mock)")

def info_command(args):
    print(f"CyraPEFT Version: {__version__}")
    try:
        import torch
        print(f"PyTorch Version: {torch.__version__}")
        print(f"CUDA Available: {torch.cuda.is_available()}")
    except ImportError:
        print("PyTorch not installed.")

def main():
    parser = argparse.ArgumentParser(
        description="CyraPEFT: Cybernetic Regulatory Adaptive PEFT Framework",
        prog="cyrapeft"
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Train command
    train_parser = subparsers.add_parser("train", help="Train a model using Adaptive LoRA")
    train_parser.add_argument("-c", "--config", type=str, help="Path to YAML config file (Optional)")
    
    # CLI Overrides
    train_parser.add_argument("-m", "--model_name", type=str, help="HuggingFace Model ID (e.g. gpt2)")
    train_parser.add_argument("-d", "--dataset", type=str, default="wikitext", help="HuggingFace Dataset name")
    train_parser.add_argument("--dataset_config", type=str, default=None, help="Dataset config name (if required)")
    train_parser.add_argument("--dataset_split", type=str, default="train", help="Dataset split to use (e.g. train, test)")
    train_parser.add_argument("-b", "--batch_size", type=int, help="Training batch size")
    train_parser.add_argument("-e", "--epochs", type=int, help="Number of training epochs")
    train_parser.add_argument("--alpha", type=float, help="Initial LoRA Alpha")
    train_parser.add_argument("--learning_rate", type=float, help="Learning rate")
    train_parser.add_argument("-t", "--target_modules", type=str, help="Comma separated list of target modules")
    train_parser.add_argument("--quantize_4bit", action="store_true", help="Enable 4-bit bitsandbytes quantization to save VRAM")
    
    # Ray integration
    train_parser.add_argument("--use_ray", action="store_true", help="Enable Ray for distributed adaptive fine-tuning")
    train_parser.add_argument("--num_workers", type=int, default=1, help="Number of Ray workers to use")
    
    # Swarm integration
    train_parser.add_argument("--use_swarm", action="store_true", help="Enable Particle Swarm Optimization for live hyperparameter tuning")
    train_parser.add_argument("--gradient_checkpointing", action="store_true", help="Enable gradient checkpointing to save VRAM")
    train_parser.add_argument("--use_unsloth", action="store_true", help="Use Unsloth for 2x-5x faster training")
    train_parser.add_argument("--max_samples", type=int, help="Limit the number of training samples")
    train_parser.add_argument("--gradient_accumulation_steps", type=int, default=1, help="Number of steps to accumulate gradients before updating weights")
    
    train_parser.add_argument("--disable_difficulty", action="store_true", help="Disable dynamic difficulty weighting (Baseline)")
    train_parser.add_argument("--disable_controller", action="store_true", help="Disable PID controller for adaptive LoRA (Baseline)")
    
    train_parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    train_parser.add_argument("-o", "--output_dir", type=str, default="./cyrapeft_output", help="Output directory")

    # Analyze command
    analyze_parser = subparsers.add_parser("analyze", help="Run research-grade benchmarks (Wikitext PPL, HellaSwag) on a trained model")
    analyze_parser.add_argument("-o", "--output_dir", type=str, required=True, help="Path to the training output directory containing metrics.json and adapters")
    analyze_parser.add_argument("-m", "--model_name", type=str, required=True, help="Original base model name (e.g. Qwen/Qwen2.5-1.5B)")
    
    # Info command
    info_parser = subparsers.add_parser("info", help="Show environment and framework info")

    args = parser.parse_args()

    if args.command == "train":
        train_command(args)
    elif args.command == "eval":
        eval_command(args)
    elif args.command == "analyze":
        from cyrapeft.core.analyzer import run_analysis
        print(f"Starting Research Analysis for {args.output_dir}...")
        results = run_analysis(args.output_dir, args.model_name)
        print("\n" + "="*40)
        print("ANALYSIS COMPLETE")
        print(f"Perplexity: {results['perplexity']:.4f}")
        print(f"HellaSwag Acc: {results['hellaswag']:.2f}%")
        print("="*40)
    elif args.command == "info":
        info_command()
    else:
        parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()
