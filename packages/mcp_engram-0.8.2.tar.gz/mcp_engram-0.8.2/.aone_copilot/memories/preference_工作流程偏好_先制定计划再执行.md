---
id: mem_20260507_173915
name: 工作流程偏好：先制定计划再执行
description: 用户在代码相关任务中倾向于先看到计划，然后再动手实施
type: preference
tags: [workflow, planning, code]
scope: project
createdAt: 2026-05-07T09:39:15.863Z
source: reflection
convertedTo: null
---

用户在代码任务中倾向于先制定计划再执行。
**Why:** 用户在对话中明确要求“看下代码，然后结合定位给我个plan”。
**How to apply:** 在涉及代码修改、重构或功能开发的任务中，先阅读代码并给出结构化的执行计划，等待用户确认后再开始编写代码。
