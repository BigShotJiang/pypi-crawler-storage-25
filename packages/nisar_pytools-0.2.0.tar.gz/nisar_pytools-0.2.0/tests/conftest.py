"""Shared test fixtures: synthetic NISAR HDF5 files."""

import h5py
import numpy as np
import pytest


# A minimal but well-formed WKT polygon used for the synthetic boundingPolygon
# attribute. The coordinates are nominal and don't need to match the gridded
# data extents; downstream code only reads .bounds() off the parsed polygon.
_TEST_BOUNDING_POLYGON_WKT = (
    "POLYGON ((-117.01 36.10, -116.99 36.10, "
    "-116.99 36.13, -117.01 36.13, -117.01 36.10))"
)


def _add_common_identification(ident: h5py.Group) -> None:
    """Identification fields shared by GSLC and GUNW synthetic fixtures.

    These mirror what real NISAR L2 products carry. Tests that exercise
    the `info` subcommand or anything else reading identification metadata
    expect these to be present.
    """
    ident.create_dataset("orbitPassDirection", data=b"Ascending")
    ident.create_dataset("lookDirection", data=b"Left")
    ident.create_dataset("radarBand", data=b"L")
    ident.create_dataset("productVersion", data=b"1.0.2")
    ident.create_dataset("productSpecificationVersion", data=b"1.4.0")
    ident.create_dataset("processingDateTime", data=b"2026-02-13T00:24:54")
    ident.create_dataset("boundingPolygon", data=_TEST_BOUNDING_POLYGON_WKT.encode())


def _create_frequency_group(parent, name, ny, nx, polarizations=("HH", "HV")):
    """Create a GSLC-style frequency group with coordinate scales and data."""
    grp = parent.create_group(name)

    x = np.arange(nx, dtype="f8") * 100.0 + 500000.0
    y = np.arange(ny, dtype="f8") * 100.0 + 4000000.0

    xds = grp.create_dataset("xCoordinates", data=x)
    yds = grp.create_dataset("yCoordinates", data=y)
    xds.make_scale("xCoordinates")
    yds.make_scale("yCoordinates")

    for pol in polarizations:
        ds = grp.create_dataset(pol, shape=(ny, nx), dtype="c8", chunks=(4, 4))
        ds.attrs["grid_mapping"] = "projection"
        ds.attrs["description"] = f"Focused SLC image ({pol})"
        ds.dims[0].attach_scale(yds)
        ds.dims[1].attach_scale(xds)

    grp.create_dataset("mask", shape=(ny, nx), dtype="u1", chunks=(4, 4))
    proj = grp.create_dataset("projection", data=np.uint32(32611))
    proj.attrs["epsg_code"] = 32611
    proj.attrs["grid_mapping_name"] = "transverse_mercator"
    grp.create_dataset("centerFrequency", data=1.257e9)
    grp.create_dataset("xCoordinateSpacing", data=100.0)
    grp.create_dataset("yCoordinateSpacing", data=100.0)
    pol_arr = np.array([p.encode() for p in polarizations], dtype="S2")
    grp.create_dataset("listOfPolarizations", data=pol_arr)

    return grp


def _create_gunw_subproduct(parent, name, ny, nx, data_vars, pol="HH"):
    """Create a GUNW sub-product group (e.g., unwrappedInterferogram)."""
    sub = parent.create_group(name)

    # Sub-product level coords and mask
    x_sub = np.arange(nx, dtype="f8") * 100.0 + 500000.0
    y_sub = np.arange(ny, dtype="f8") * 100.0 + 4000000.0
    sub.create_dataset("xCoordinates", data=x_sub)
    sub.create_dataset("yCoordinates", data=y_sub)
    sub.create_dataset("mask", shape=(ny, nx), dtype="u1", chunks=(4, 4))
    sub_proj = sub.create_dataset("projection", data=np.uint32(32611))
    sub_proj.attrs["epsg_code"] = 32611

    # Polarization group with its own coords and data
    pol_grp = sub.create_group(pol)
    x = np.arange(nx, dtype="f8") * 100.0 + 500000.0
    y = np.arange(ny, dtype="f8") * 100.0 + 4000000.0
    xds = pol_grp.create_dataset("xCoordinates", data=x)
    yds = pol_grp.create_dataset("yCoordinates", data=y)
    xds.make_scale("xCoordinates")
    yds.make_scale("yCoordinates")
    proj = pol_grp.create_dataset("projection", data=np.uint32(32611))
    proj.attrs["epsg_code"] = 32611

    for var_name in data_vars:
        dtype = "c8" if "Interferogram" in var_name else "f4"
        ds = pol_grp.create_dataset(var_name, shape=(ny, nx), dtype=dtype, chunks=(4, 4))
        ds.attrs["grid_mapping"] = "projection"
        ds.dims[0].attach_scale(yds)
        ds.dims[1].attach_scale(xds)

    return sub


@pytest.fixture
def gslc_h5(tmp_path):
    """Create a minimal synthetic GSLC HDF5 file."""
    path = tmp_path / "test_gslc.h5"
    ny, nx = 8, 10
    with h5py.File(path, "w") as f:
        f.attrs["Conventions"] = "CF-1.7"
        f.attrs["mission_name"] = "NISAR"

        # Identification
        ident = f.create_group("science/LSAR/identification")
        ident.create_dataset("productType", data=b"GSLC")
        ident.create_dataset("trackNumber", data=np.uint32(77))
        ident.create_dataset("frameNumber", data=np.uint16(24))
        ident.create_dataset("absoluteOrbitNumber", data=np.uint32(1387))
        # Single GSLC acquisition has start/end times.
        ident.create_dataset("zeroDopplerStartTime", data=b"2025-11-03T12:46:15.000000000")
        ident.create_dataset("zeroDopplerEndTime", data=b"2025-11-03T12:46:50.999342105")
        _add_common_identification(ident)

        # Grids
        grids = f.create_group("science/LSAR/GSLC/grids")
        _create_frequency_group(grids, "frequencyA", ny, nx, ("HH", "HV"))
        _create_frequency_group(grids, "frequencyB", ny, nx // 2, ("HH",))

    return path


@pytest.fixture
def gunw_h5(tmp_path):
    """Create a minimal synthetic GUNW HDF5 file."""
    path = tmp_path / "test_gunw.h5"
    with h5py.File(path, "w") as f:
        f.attrs["Conventions"] = "CF-1.7"

        # Identification
        ident = f.create_group("science/LSAR/identification")
        ident.create_dataset("productType", data=b"GUNW")
        ident.create_dataset("trackNumber", data=np.uint32(149))
        ident.create_dataset("frameNumber", data=np.uint16(24))
        # GUNW carries reference + secondary acquisition timestamps and orbits.
        ident.create_dataset(
            "referenceZeroDopplerStartTime", data=b"2025-11-03T12:46:15.000000000"
        )
        ident.create_dataset(
            "referenceZeroDopplerEndTime", data=b"2025-11-03T12:46:50.999342105"
        )
        ident.create_dataset(
            "secondaryZeroDopplerStartTime", data=b"2025-11-15T12:46:15.000000000"
        )
        ident.create_dataset(
            "secondaryZeroDopplerEndTime", data=b"2025-11-15T12:46:50.999342105"
        )
        ident.create_dataset("referenceAbsoluteOrbitNumber", data=np.uint32(1387))
        ident.create_dataset("secondaryAbsoluteOrbitNumber", data=np.uint32(1560))
        _add_common_identification(ident)

        # Pre-computed perpendicular + parallel baseline cubes on the
        # radarGrid, mirroring real NISAR L2 products. Real files store
        # these as (height_layers, az, rng) float32. The `info`
        # subcommand reads them directly rather than recomputing from
        # orbit state -- the JPL pipeline produces values that are
        # physically correct (per-pixel LOS-aware geometry).
        bperp = np.full((4, 6, 8), -98.0, dtype="f4")
        bpar = np.full((4, 6, 8), -40.0, dtype="f4")
        f.create_dataset(
            "science/LSAR/GUNW/metadata/radarGrid/perpendicularBaseline", data=bperp
        )
        f.create_dataset(
            "science/LSAR/GUNW/metadata/radarGrid/parallelBaseline", data=bpar
        )
        # Pre-computed temporal baseline scalar that real files include.
        f.create_dataset(
            "science/LSAR/GUNW/metadata/orbit/temporalBaseline", data=np.uint16(12)
        )

        # Grids / frequencyA
        base = f.create_group("science/LSAR/GUNW/grids/frequencyA")
        base.create_dataset("centerFrequency", data=1.257e9)

        # unwrappedInterferogram (6x8)
        _create_gunw_subproduct(
            base,
            "unwrappedInterferogram",
            ny=6,
            nx=8,
            data_vars=[
                "unwrappedPhase",
                "coherenceMagnitude",
                "connectedComponents",
                "ionospherePhaseScreen",
            ],
        )

        # wrappedInterferogram (12x16 — different resolution)
        _create_gunw_subproduct(
            base,
            "wrappedInterferogram",
            ny=12,
            nx=16,
            data_vars=["wrappedInterferogram", "coherenceMagnitude"],
        )

        # pixelOffsets (6x8 — same resolution as unwrapped)
        _create_gunw_subproduct(
            base,
            "pixelOffsets",
            ny=6,
            nx=8,
            data_vars=["alongTrackOffset", "slantRangeOffset"],
        )

    return path
