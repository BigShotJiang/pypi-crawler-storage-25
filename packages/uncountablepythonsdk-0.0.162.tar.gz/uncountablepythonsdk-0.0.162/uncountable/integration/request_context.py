from uncountable.types import client_config_t

MAX_HEADER_LENGTH = 100


def validated_header(*, headers: dict[str, str], key: str) -> str | None:
    value = headers.get(key)
    if value is not None and len(value) > MAX_HEADER_LENGTH:
        return None
    return value


def _parse_locale(*, raw_locale: str | None) -> client_config_t.SdkLocale | None:
    if raw_locale is None:
        return None
    try:
        return client_config_t.SdkLocale(raw_locale)
    except ValueError:
        return None


def extract_request_context(
    *, headers: dict[str, str]
) -> client_config_t.RequestContext | None:
    user_timezone = validated_header(headers=headers, key="X-User-Timezone")
    user_locale = _parse_locale(
        raw_locale=validated_header(headers=headers, key="X-User-Locale")
    )
    if user_timezone is None and user_locale is None:
        return None
    return client_config_t.RequestContext(
        user_timezone=user_timezone,
        user_locale=user_locale,
    )
