from __future__ import annotations

import json
import time
from copy import copy
from dataclasses import make_dataclass
from decimal import Decimal
from typing import Self

from pkgs.argument_parser import CachedParser
from pkgs.serialization.serial_class import serial_class
from uncountable.core.client import Client
from uncountable.core.query.column import (
    Column,
    ColumnFilter,
    EnumColumn,
    NullableColumn,
    PrimaryKeyColumn,
    get_column_base,
)
from uncountable.core.query.row import QueryRow
from uncountable.types import (
    async_jobs_t,
    base_t,
    entity_t,
    identifier_t,
    listing_t,
)
from uncountable.types.api.entity import list_entities as list_entities_t
from uncountable.types.api.files.download_file import FileDownloadQueryEntityField

_ASYNC_EXPORT_TIMEOUT_SECONDS = 60 * 10
_ASYNC_EXPORT_POLL_INTERVAL_SECONDS = 1


class _AsyncExportJob(QueryRow):
    id = PrimaryKeyColumn(base_type=entity_t.EntityType.ASYNC_JOB)
    status = EnumColumn(
        identifier=listing_t.ColumnIdentifierEntityRefName(
            entity_type=entity_t.EntityType.ASYNC_JOB, ref_name="core_async_job_status"
        ),
        nullable=NullableColumn,
        enum_type=async_jobs_t.AsyncJobStatus,
    )


class QueryBuilder[QueryRowT: QueryRow]:
    """
    Used in conjunction with the QueryRow and Column classes to fetch structured data from the Uncountable API.

    Create a QueryBuilder instance from a subclass of QueryRow. Use this to apply filters and fetch structured data.

    WARNING: This class is in beta and subject to breaking changes. Always check the SDK changelog for breaking changes before updating your SDK version.
    """

    def __init__(self, client: Client, model: type[QueryRowT]):
        self._filters: tuple[listing_t.FilterSpec, ...] = ()
        self._model: type[QueryRowT] = model
        self._client = client
        if base_type := model._validate_column_base_types():
            self._base_type = base_type
        else:
            raise ValueError(
                f"Failed to resolve base type of model {model.__name__}. Ensure at least one column property is defined"
            )

        column_definitions: dict[str, Column] = {
            key: value
            for cls in reversed(self._model.__mro__)
            for key, value in cls.__dict__.items()
            if isinstance(value, Column)
        }
        self._column_identifiers: tuple[listing_t.ColumnIdentifier, ...] = tuple(
            column.identifier for column in column_definitions.values()
        )
        self._property_names: tuple[str, ...] = tuple(column_definitions.keys())
        self._parser: CachedParser = CachedParser(
            serial_class(unconverted_keys={*self._property_names})(
                make_dataclass(
                    cls_name=self._model.__name__,
                    fields=[
                        (name, value._parse_type)
                        for name, value in column_definitions.items()
                    ],
                )
            )
        )

    def filter(self, *filters: ColumnFilter) -> Self:
        for filter in filters:
            if get_column_base(filter.identifier) != self._base_type:
                raise ValueError(
                    "Filter column base type does not match query base type"
                )
        branch = copy(self)
        branch._filters = (
            *self._filters,
            *(filter.filter(filter.identifier) for filter in filters),
        )
        return branch

    def _fetch(self, limit: int = 100, offset: int = 0) -> list[QueryRowT]:
        rows = self._client.fetch_listing(
            entity_type=self._base_type,
            columns=list(self._column_identifiers),
            filters=listing_t.FilterNodeColumnAnd(filters=tuple(self._filters)),
            limit=limit,
            offset=offset,
        ).results

        return [self._parse_row(row.column_values) for row in rows]

    def _hook_after_parse_row(self, row: QueryRowT) -> None:
        pass

    def _parse_row(self, row: list[base_t.JsonValue]) -> QueryRowT:
        parsed = self._parser.parse_api({
            key: value for key, value in zip(self._property_names, row, strict=True)
        })
        parsed_model = self._model()
        for key, value in parsed.__dict__.items():
            parsed_model.__dict__[key] = value
        self._hook_after_parse_row(parsed_model)
        return parsed_model

    def one(self) -> QueryRowT:
        results = self._fetch()
        if len(results) != 1:
            raise ValueError(f"Expected one result, received {len(results)}")
        return results[0]

    def one_or_none(self) -> QueryRowT | None:
        results = self._fetch()
        if len(results) > 1:
            raise ValueError(f"Expected one result, received {len(results)}")
        if len(results) == 0:
            return None
        return results[0]

    def first(self) -> QueryRowT | None:
        results = self._fetch(limit=1)
        return None if len(results) == 0 else results[0]

    def all(self) -> list[QueryRowT]:
        results = self._fetch()
        if len(results) < 100:
            return results
        return self._await_async_export()

    def _await_async_export(self) -> list[QueryRowT]:
        async_job_entity = self._client.export_listing(
            entity_type=self._base_type,
            columns=list(self._column_identifiers),
            filters=listing_t.FilterNodeColumnAnd(filters=tuple(self._filters)),
        ).entity
        if async_job_entity is None:
            raise ValueError("Listing export failed to create async job")

        status_query = QueryBuilder(client=self._client, model=_AsyncExportJob)

        start_time = time.time()
        while time.time() - start_time < _ASYNC_EXPORT_TIMEOUT_SECONDS:
            match (
                status_query
                .filter(_AsyncExportJob.id == async_job_entity.id)
                .one()
                .status
            ):
                case async_jobs_t.AsyncJobStatus.COMPLETED:
                    export_file = self._client.download_files(
                        file_query=FileDownloadQueryEntityField(
                            entity=entity_t.EntityIdentifier(
                                identifier_key=identifier_t.IdentifierKeyId(
                                    id=async_job_entity.id
                                ),
                                type=entity_t.EntityType.ASYNC_JOB,
                            ),
                            field_key=identifier_t.IdentifierKeyRefName(
                                ref_name="unc_async_listing_export_file"
                            ),
                        )
                    )[0].data.read()

                    return [
                        self._parse_row(row.column_values)
                        for row in CachedParser(list_entities_t.Data)
                        .parse_api(
                            json.loads(
                                export_file,
                                parse_float=Decimal,
                            )
                        )
                        .results
                    ]
                case async_jobs_t.AsyncJobStatus.ERROR:
                    raise ValueError("Listing export failed")
            time.sleep(_ASYNC_EXPORT_POLL_INTERVAL_SECONDS)
        raise TimeoutError(
            f"Async listing export timed out after {_ASYNC_EXPORT_TIMEOUT_SECONDS} seconds"
        )
