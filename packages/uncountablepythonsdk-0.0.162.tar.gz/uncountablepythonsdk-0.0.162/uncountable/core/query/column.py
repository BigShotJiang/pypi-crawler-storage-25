from __future__ import annotations

from collections.abc import Callable
from copy import copy
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from enum import StrEnum
from types import UnionType
from typing import (
    Never,
    Self,
    assert_never,
    overload,
)

from uncountable.core.query.types import TranslatedText
from uncountable.types import base_t, entity_t, listing_t
from uncountable.types.listing import ColumnIdentifier


@dataclass(kw_only=True)
class ColumnFilter:
    identifier: ColumnIdentifier
    filter: Callable[[ColumnIdentifier], listing_t.FilterSpec]


class NullableColumn:
    pass


class NonNullableColumn:
    pass


def get_column_base(
    column_identifier: listing_t.ColumnIdentifier,
) -> entity_t.EntityType:
    match column_identifier:
        case listing_t.ColumnIdentifierEntityRefName():
            return column_identifier.entity_type
        case listing_t.ColumnIdentifierTransitive():
            return get_column_base(column_identifier.via)
        case listing_t.ColumnIdentifierTransitiveAggregate():
            return get_column_base(column_identifier.via)
        case _:
            assert_never(column_identifier)


class Column[
    ValueT,
    NullableT: NullableColumn | NonNullableColumn,
]:
    """
    Used in conjunction with the QueryRow and QueryBuilder classes to fetch structured data from the Uncountable API.

    Add Column instances as properties to a subclass of QueryRow to define the data returned by the query.

    WARNING: This class is in beta and subject to breaking changes. Always check the SDK changelog for breaking changes before updating your SDK version.
    """

    @overload
    def __get__(self, obj: None, objtype: type) -> Self: ...

    @overload
    def __get__(
        self: Column[ValueT, NonNullableColumn],
        obj: object,
        objtype: type,
    ) -> ValueT: ...

    @overload
    def __get__(
        self: Column[ValueT, NullableColumn],
        obj: object,
        objtype: type,
    ) -> ValueT | None: ...

    def __get__(self, obj: object, objtype: type) -> Self | ValueT | None:
        """
        When accessed on instance: returns the column value
        When accessed on class: returns Column instance (for queries)
        """
        if obj is None:
            return self
        assert self.name is not None
        return obj.__dict__[self.name]  # type: ignore[no-any-return]

    def __set__(self, obj: Never, value: Never) -> None:
        raise AttributeError("Columns are read-only")

    def __init__(
        self,
        *,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
        # we can't use value_type: type[ValueT] because we need to support type unions, which can't be passed to TypeVars. We rely on the subclasses to ensure that the value passed to this parameter matches the value passed to the ValueT type arg.
        value_type: type[object] | UnionType,
    ) -> None:
        self._parse_type = (
            value_type | None if nullable is NullableColumn else value_type
        )
        self.nullable: type[NullableT] = nullable
        self.identifier: listing_t.ColumnIdentifier = identifier
        self.name: str | None = None
        self.owner: type[object] | None = None

    def __set_name__(self, owner: type, name: str) -> None:
        """Called when the column is assigned to a class attribute"""

        # Copy the object to avoid mutating the original when assigned to a subclass
        copy_to_assign = copy(self)
        copy_to_assign.name = name
        copy_to_assign.owner = owner
        setattr(owner, name, copy_to_assign)


class TextColumn[
    NullableT: NullableColumn | NonNullableColumn,
](Column[str, NullableT]):
    __hash__ = Column.__hash__

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
    ) -> None:
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=str,
        )

    def __ne__(self, other: None) -> ColumnFilter:  # type: ignore[override]
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    def __eq__(self, other: str) -> ColumnFilter:  # type: ignore[override]
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecEquals(column=x, value=other),
        )

    def contains(self, other: str) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecIStrContains(column=x, value=other),
        )

    def startswith(self, other: str) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecIStrStartsWith(column=x, value=other),
        )

    def includes(self, other: str | tuple[str, ...]) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecInclude(column=x, value=other),
        )

    # IMPROVE: Implement "Not Exists" and "Not Equals" filters (when supported in SDK)


class TranslatedTextColumn[
    NullableT: NullableColumn | NonNullableColumn,
](Column[TranslatedText, NullableT]):
    __hash__ = Column.__hash__

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
    ) -> None:
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=TranslatedText,
        )

    def __ne__(self, other: None) -> ColumnFilter:  # type: ignore[override]
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    def __eq__(self, other: str) -> ColumnFilter:  # type: ignore[override]
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecEquals(column=x, value=other),
        )

    def contains(self, other: str) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecIStrContains(column=x, value=other),
        )

    def startswith(self, other: str) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecIStrStartsWith(column=x, value=other),
        )

    def includes(self, other: str | tuple[str, ...]) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecInclude(column=x, value=other),
        )

    # IMPROVE: Implement "Not Exists" and "Not Equals" filters (when supported in SDK)


class EnumColumn[
    EnumT: StrEnum,
    NullableT: NullableColumn | NonNullableColumn,
](Column[EnumT | str, NullableT]):
    __hash__ = Column.__hash__

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        enum_type: type[EnumT],
        nullable: type[NullableT],
    ):
        self._enum_type = enum_type
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=enum_type | str,
        )

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    def __eq__(  # type: ignore[override]
        self, other: str
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecEquals(column=x, value=other),
        )

    def contains(self, other: str) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecIStrContains(column=x, value=other),
        )

    def startswith(self, other: str) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecIStrStartsWith(column=x, value=other),
        )

    def includes(self, other: EnumT | tuple[EnumT, ...]) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecInclude(column=x, value=other),
        )


class BooleanColumn[
    NullableT: NullableColumn | NonNullableColumn,
](Column[bool, NullableT]):
    __hash__ = Column.__hash__

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
    ) -> None:
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=bool,
        )

    def __ne__(self, other: None) -> ColumnFilter:  # type: ignore[override]
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    def __eq__(  # type: ignore[override]
        self: Column[bool, NullableT], other: bool
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecEquals(column=x, value=other),
        )


class DatetimeColumn[
    NullableT: NullableColumn | NonNullableColumn,
](Column[datetime, NullableT]):
    __hash__ = Column.__hash__

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
    ) -> None:
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=datetime,
        )

    # IMPROVE: Implement "Not Exists" and "Datetime Range" filters (when supported in SDK)

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )


class DateColumn[
    NullableT: NullableColumn | NonNullableColumn,
](Column[datetime, NullableT]):
    __hash__ = Column.__hash__

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
    ) -> None:
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=datetime,
        )

    # IMPROVE: Implement "Not Exists" and "Date Range" filters (when supported in SDK)

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )


class NumericColumn[
    NullableT: NullableColumn | NonNullableColumn,
](Column[Decimal, NullableT]):
    __hash__ = Column.__hash__

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
    ) -> None:
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=Decimal,
        )

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    def __eq__(  # type: ignore[override]
        self, other: Decimal | int
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecEquals(column=x, value=other),
        )

    def __gt__(self, other: Decimal) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecGreater(column=x, value=other),
        )

    def __ge__(self, other: Decimal) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecGeq(column=x, value=other),
        )

    def __le__(self, other: Decimal) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecLeq(column=x, value=other),
        )

    def includes(self, other: tuple[int, ...]) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecInclude(column=x, value=other),
        )

    # IMPROVE: Implement "Not Equals", "Not Exists", "Less Than", and "Range" filters (when supported in SDK)


class TextsColumn[
    NullableT: NullableColumn | NonNullableColumn,
](Column[tuple[str, ...], NullableT]):
    __hash__ = Column.__hash__

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
    ) -> None:
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=tuple[str, ...],
        )

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    # IMPROVE: Implement "Not Exists" filter (when supported in SDK)


class NullableTextsColumn[
    NullableT: NullableColumn | NonNullableColumn,
](Column[tuple[str | None, ...], NullableT]):
    __hash__ = Column.__hash__

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
    ) -> None:
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=tuple[str | None, ...],
        )

    # IMPROVE: Implement "Not Exists" filter (when supported in SDK)


class PrimaryKeyColumn(
    Column[base_t.ObjectId, NonNullableColumn],
):
    __hash__ = Column.__hash__

    def __init__(self, base_type: entity_t.EntityType) -> None:
        super().__init__(
            identifier=listing_t.ColumnIdentifierEntityRefName(
                entity_type=base_type, ref_name="id"
            ),
            nullable=NonNullableColumn,
            value_type=base_t.ObjectId,
        )

    def __eq__(  # type: ignore[override]
        self, other: int
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecEquals(column=x, value=other),
        )

    def includes(self, other: int | tuple[int, ...]) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecInclude(column=x, value=other),
        )

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    # IMPROVE: Implement "Not Exists" and "Exclude" filter (when supported in SDK)


class IdColumn[
    NullableT: NullableColumn | NonNullableColumn,
](
    Column[base_t.ObjectId, NullableT],
):
    __hash__ = Column.__hash__

    def __eq__(  # type: ignore[override]
        self, other: int
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecEquals(column=x, value=other),
        )

    def includes(self, other: int | tuple[int, ...]) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecInclude(column=x, value=other),
        )

    # IMPROVE: Implement "Not Exists" and "Exclude" filter (when supported in SDK)

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        id_type: entity_t.EntityType,
        nullable: type[NullableT],
    ) -> None:
        self.id_type = id_type
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=base_t.ObjectId,
        )

    # SUPPORTED TRANSITIVE LOAD TYPES

    # Column Filter
    @overload
    def __rshift__(self, column: ColumnFilter) -> ColumnFilter: ...

    # Text
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: TextColumn[BaseNullableT],
    ) -> TextColumn[NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: TextColumn[BaseNullableT],
    ) -> TextColumn[BaseNullableT]: ...

    # Translated Text
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: TranslatedTextColumn[BaseNullableT],
    ) -> TranslatedTextColumn[NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: TranslatedTextColumn[BaseNullableT],
    ) -> TranslatedTextColumn[BaseNullableT]: ...

    # Enum
    @overload
    def __rshift__[EnumT: StrEnum, BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: EnumColumn[EnumT, BaseNullableT],
    ) -> EnumColumn[EnumT, NullableColumn]: ...

    @overload
    def __rshift__[EnumT: StrEnum, BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: EnumColumn[EnumT, BaseNullableT],
    ) -> EnumColumn[EnumT, BaseNullableT]: ...

    # Enums
    @overload
    def __rshift__[EnumT: StrEnum, BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: EnumsColumn[EnumT, BaseNullableT],
    ) -> EnumsColumn[EnumT, NullableColumn]: ...

    @overload
    def __rshift__[EnumT: StrEnum, BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: EnumsColumn[EnumT, BaseNullableT],
    ) -> EnumsColumn[EnumT, BaseNullableT]: ...

    # Boolean
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: BooleanColumn[BaseNullableT],
    ) -> BooleanColumn[NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: BooleanColumn[BaseNullableT],
    ) -> BooleanColumn[BaseNullableT]: ...

    # Datetime
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: DatetimeColumn[BaseNullableT],
    ) -> DatetimeColumn[NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: DatetimeColumn[BaseNullableT],
    ) -> DatetimeColumn[BaseNullableT]: ...

    # Date
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: DateColumn[BaseNullableT],
    ) -> DateColumn[NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: DateColumn[BaseNullableT],
    ) -> DateColumn[BaseNullableT]: ...

    # Numeric
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: NumericColumn[BaseNullableT],
    ) -> NumericColumn[NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: NumericColumn[BaseNullableT],
    ) -> NumericColumn[BaseNullableT]: ...

    # Texts
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: TextsColumn[BaseNullableT],
    ) -> TextsColumn[NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: TextsColumn[BaseNullableT],
    ) -> TextsColumn[BaseNullableT]: ...

    # NullableTexts
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NullableColumn],
        column: NullableTextsColumn[BaseNullableT],
    ) -> NullableTextsColumn[NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdColumn[NonNullableColumn],
        column: NullableTextsColumn[BaseNullableT],
    ) -> NullableTextsColumn[BaseNullableT]: ...

    # Ids
    @overload
    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
    ](
        self: IdColumn[NullableColumn],
        column: IdsColumn[BaseNullableT],
    ) -> IdsColumn[NullableColumn]: ...

    @overload
    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
    ](
        self: IdColumn[NonNullableColumn],
        column: IdsColumn[BaseNullableT],
    ) -> IdsColumn[BaseNullableT]: ...

    # Id
    @overload
    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
    ](
        self: IdColumn[NullableColumn],
        column: IdColumn[BaseNullableT],
    ) -> IdColumn[NullableColumn]: ...

    @overload
    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
    ](
        self: IdColumn[NonNullableColumn],
        column: IdColumn[BaseNullableT],
    ) -> IdColumn[BaseNullableT]: ...

    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
        EnumT: StrEnum,
    ](
        self,
        column: ColumnFilter
        | TextColumn[BaseNullableT]
        | TranslatedTextColumn[BaseNullableT]
        | EnumColumn[EnumT, BaseNullableT]
        | EnumsColumn[EnumT, BaseNullableT]
        | BooleanColumn[BaseNullableT]
        | DatetimeColumn[BaseNullableT]
        | DateColumn[BaseNullableT]
        | NumericColumn[BaseNullableT]
        | TextsColumn[BaseNullableT]
        | NullableTextsColumn[BaseNullableT]
        | IdsColumn[BaseNullableT]
        | IdColumn[BaseNullableT],
    ) -> (
        ColumnFilter
        | TextColumn[BaseNullableT]
        | TextColumn[NonNullableColumn | NullableColumn]
        | TextColumn[NullableColumn]
        | TranslatedTextColumn[BaseNullableT]
        | TranslatedTextColumn[NonNullableColumn | NullableColumn]
        | TranslatedTextColumn[NullableColumn]
        | EnumColumn[EnumT, BaseNullableT]
        | EnumColumn[EnumT, NonNullableColumn | NullableColumn]
        | EnumColumn[EnumT, NullableColumn]
        | EnumsColumn[EnumT, BaseNullableT]
        | EnumsColumn[EnumT, NonNullableColumn | NullableColumn]
        | EnumsColumn[EnumT, NullableColumn]
        | BooleanColumn[BaseNullableT]
        | BooleanColumn[NonNullableColumn | NullableColumn]
        | BooleanColumn[NullableColumn]
        | DatetimeColumn[BaseNullableT]
        | DatetimeColumn[NonNullableColumn | NullableColumn]
        | DatetimeColumn[NullableColumn]
        | DateColumn[BaseNullableT]
        | DateColumn[NonNullableColumn | NullableColumn]
        | DateColumn[NullableColumn]
        | NumericColumn[BaseNullableT]
        | NumericColumn[NonNullableColumn | NullableColumn]
        | NumericColumn[NullableColumn]
        | TextsColumn[BaseNullableT]
        | TextsColumn[NonNullableColumn | NullableColumn]
        | TextsColumn[NullableColumn]
        | NullableTextsColumn[BaseNullableT]
        | NullableTextsColumn[NonNullableColumn | NullableColumn]
        | NullableTextsColumn[NullableColumn]
        | IdsColumn[BaseNullableT]
        | IdsColumn[NonNullableColumn | NullableColumn]
        | IdsColumn[NullableColumn]
        | IdColumn[BaseNullableT]
        | IdColumn[NonNullableColumn | NullableColumn]
        | IdColumn[NullableColumn]
    ):

        base_type = get_column_base(column.identifier)
        if base_type != self.id_type:
            raise ValueError(
                f"cannot load column with base type {base_type} from column with id type {self.id_type}"
            )

        transitive_identifier = listing_t.ColumnIdentifierTransitive(
            entity_type=self.id_type,
            via=self.identifier,
            target=column.identifier,
        )

        match column:
            case ColumnFilter():
                return ColumnFilter(
                    identifier=transitive_identifier,
                    filter=column.filter,
                )

            case TextColumn():
                return TextColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case TranslatedTextColumn():
                return TranslatedTextColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case EnumColumn():
                return EnumColumn(
                    identifier=transitive_identifier,
                    nullable=(
                        column.nullable
                        if self.nullable is NonNullableColumn
                        else NullableColumn
                    ),
                    enum_type=column._enum_type,
                )
            case EnumsColumn():
                return EnumsColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    enum_type=column._enum_type,
                )
            case BooleanColumn():
                return BooleanColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case DatetimeColumn():
                return DatetimeColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case DateColumn():
                return DateColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case NumericColumn():
                return NumericColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case TextsColumn():
                return TextsColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case NullableTextsColumn():
                return NullableTextsColumn(
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case IdsColumn():
                return IdsColumn(
                    id_type=column.id_type,
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case IdColumn():
                return IdColumn(
                    id_type=column.id_type,
                    identifier=transitive_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
        assert_never(column)


class AggregatedColumn[
    TupleValueT: tuple,
    NullableT: NullableColumn | NonNullableColumn,
](Column[TupleValueT, NullableT]):
    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        tuple_value_type: type[TupleValueT],
        nullable: type[NullableT],
    ):
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            value_type=tuple_value_type,
        )


class EnumsColumn[
    EnumT: StrEnum,
    NullableT: NullableColumn | NonNullableColumn,
](AggregatedColumn[tuple[EnumT | str, ...], NullableT]):
    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        nullable: type[NullableT],
        enum_type: type[EnumT],
    ) -> None:
        self._enum_type = enum_type
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            tuple_value_type=tuple[enum_type | str, ...],  # type: ignore[valid-type]
        )


class IdsColumn[
    NullableT: NullableColumn | NonNullableColumn,
](
    AggregatedColumn[tuple[base_t.ObjectId, ...], NullableT],
):
    __hash__ = Column.__hash__

    def __ne__(  # type: ignore[override]
        self, other: None
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda identifier: listing_t.FilterSpecExists(column=identifier),
        )

    def includes(
        self, other: base_t.ObjectId | tuple[base_t.ObjectId, ...]
    ) -> ColumnFilter:
        return ColumnFilter(
            identifier=self.identifier,
            filter=lambda x: listing_t.FilterSpecInclude(column=x, value=other),
        )

    def __init__(
        self,
        identifier: listing_t.ColumnIdentifier,
        id_type: entity_t.EntityType,
        nullable: type[NullableT],
        filters: list[ColumnFilter] | None = None,
    ) -> None:
        self.id_type = id_type
        self._filters: list[ColumnFilter] = filters if filters is not None else []
        super().__init__(
            identifier=identifier,
            nullable=nullable,
            tuple_value_type=tuple[base_t.ObjectId, ...],
        )

    # Text
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: TextColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[str, ...], NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: TextColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[str, ...], BaseNullableT]: ...

    # Translated Text
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: TranslatedTextColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[TranslatedText, ...], NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: TranslatedTextColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[TranslatedText, ...], BaseNullableT]: ...

    # Enum
    @overload
    def __rshift__[EnumT: StrEnum, BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: EnumColumn[EnumT, BaseNullableT],
    ) -> AggregatedColumn[tuple[EnumT | str, ...], NullableColumn]: ...

    @overload
    def __rshift__[EnumT: StrEnum, BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: EnumColumn[EnumT, BaseNullableT],
    ) -> AggregatedColumn[tuple[EnumT | str, ...], BaseNullableT]: ...

    # Enums
    # Seems to be broken in the platform - see what happens when you add the column Experiment -> Test Samples -> Link Types

    # Boolean
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: BooleanColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[bool, ...], NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: BooleanColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[bool, ...], BaseNullableT]: ...

    # Datetime
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: DatetimeColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[datetime, ...], NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: DatetimeColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[datetime, ...], BaseNullableT]: ...

    # Date
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: DateColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[datetime, ...], NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: DateColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[datetime, ...], BaseNullableT]: ...

    # Numeric
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: NumericColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[Decimal, ...], NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: NumericColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[Decimal, ...], BaseNullableT]: ...

    # Texts
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: TextsColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[str, ...], NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: TextsColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[str, ...], BaseNullableT]: ...

    # NullableTexts
    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NullableColumn],
        column: NullableTextsColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[str, ...], NullableColumn]: ...

    @overload
    def __rshift__[BaseNullableT: NullableColumn | NonNullableColumn](
        self: IdsColumn[NonNullableColumn],
        column: NullableTextsColumn[BaseNullableT],
    ) -> AggregatedColumn[tuple[str, ...], BaseNullableT]: ...

    # Id
    @overload
    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
    ](
        self: IdsColumn[NullableColumn],
        column: IdColumn[BaseNullableT],
    ) -> IdsColumn[NullableColumn]: ...

    @overload
    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
    ](
        self: IdsColumn[NonNullableColumn],
        column: IdColumn[BaseNullableT],
    ) -> IdsColumn[BaseNullableT]: ...

    # Ids
    @overload
    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
    ](
        self: IdsColumn[NullableColumn],
        column: IdsColumn[BaseNullableT],
    ) -> IdsColumn[NullableColumn]: ...

    @overload
    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
    ](
        self: IdsColumn[NonNullableColumn],
        column: IdsColumn[BaseNullableT],
    ) -> IdsColumn[BaseNullableT]: ...

    def __rshift__[
        BaseNullableT: NullableColumn | NonNullableColumn,
        EnumT: StrEnum,
    ](
        self,
        column: TextColumn[BaseNullableT]
        | TranslatedTextColumn[BaseNullableT]
        | EnumColumn[EnumT, BaseNullableT]
        | BooleanColumn[BaseNullableT]
        | DatetimeColumn[BaseNullableT]
        | DateColumn[BaseNullableT]
        | NumericColumn[BaseNullableT]
        | TextsColumn[BaseNullableT]
        | NullableTextsColumn[BaseNullableT]
        | IdColumn[BaseNullableT]
        | IdsColumn[BaseNullableT],
    ) -> (
        AggregatedColumn[tuple[str, ...], BaseNullableT]
        | AggregatedColumn[tuple[str, ...], NonNullableColumn | NullableColumn]
        | AggregatedColumn[tuple[str, ...], NullableColumn]
        | AggregatedColumn[tuple[TranslatedText, ...], BaseNullableT]
        | AggregatedColumn[
            tuple[TranslatedText, ...],
            NonNullableColumn | NullableColumn,
        ]
        | AggregatedColumn[tuple[TranslatedText, ...], NullableColumn]
        | AggregatedColumn[tuple[str | None, ...], BaseNullableT]
        | AggregatedColumn[
            tuple[str | None, ...],
            NonNullableColumn | NullableColumn,
        ]
        | AggregatedColumn[tuple[str | None, ...], NullableColumn]
        | AggregatedColumn[tuple[EnumT, ...], BaseNullableT]
        | AggregatedColumn[tuple[EnumT, ...], NonNullableColumn | NullableColumn]
        | AggregatedColumn[tuple[EnumT, ...], NullableColumn]
        | AggregatedColumn[tuple[bool, ...], BaseNullableT]
        | AggregatedColumn[tuple[bool, ...], NonNullableColumn | NullableColumn]
        | AggregatedColumn[tuple[bool, ...], NullableColumn]
        | AggregatedColumn[tuple[datetime, ...], BaseNullableT]
        | AggregatedColumn[tuple[datetime, ...], NonNullableColumn | NullableColumn]
        | AggregatedColumn[tuple[datetime, ...], NullableColumn]
        | AggregatedColumn[tuple[Decimal, ...], BaseNullableT]
        | AggregatedColumn[tuple[Decimal, ...], NonNullableColumn | NullableColumn]
        | AggregatedColumn[tuple[Decimal, ...], NullableColumn]
        | IdsColumn[BaseNullableT]
        | IdsColumn[NonNullableColumn | NullableColumn]
        | IdsColumn[NullableColumn]
    ):
        base_type = get_column_base(column.identifier)
        if base_type != self.id_type:
            raise ValueError(
                f"cannot load column with base type {base_type} from column with id type {self.id_type}"
            )

        transitive_aggregate_identifier = listing_t.ColumnIdentifierTransitiveAggregate(
            entity_type=self.id_type,
            via=self.identifier,
            target=column.identifier,
            aggregate=listing_t.LoadAggregateCollect(),
            filters=listing_t.FilterNodeColumnAnd(
                filters=tuple(x.filter(self.identifier) for x in self._filters)
            ),
        )

        match column:
            case TextColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[str, ...],
                )
            case TranslatedTextColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[TranslatedText, ...],
                )
            case EnumColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[EnumT | str, ...],
                )
            case BooleanColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[bool, ...],
                )
            case DatetimeColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[datetime, ...],
                )
            case DateColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[datetime, ...],
                )
            case NumericColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[Decimal, ...],
                )
            case TextsColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[str, ...],
                )
            case NullableTextsColumn():
                return AggregatedColumn(
                    identifier=transitive_aggregate_identifier,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                    tuple_value_type=tuple[str | None, ...],
                )
            case IdColumn():
                return IdsColumn(
                    identifier=transitive_aggregate_identifier,
                    id_type=column.id_type,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
            case IdsColumn():
                return IdsColumn(
                    identifier=transitive_aggregate_identifier,
                    id_type=column.id_type,
                    nullable=column.nullable
                    if self.nullable is NonNullableColumn
                    else NullableColumn,
                )
        assert_never(column)

    def filter(
        self,
        filter: ColumnFilter,
    ) -> IdsColumn[NullableT]:
        return IdsColumn(
            id_type=self.id_type,
            identifier=self.identifier,
            nullable=self.nullable,
            filters=[*self._filters, filter],
        )
