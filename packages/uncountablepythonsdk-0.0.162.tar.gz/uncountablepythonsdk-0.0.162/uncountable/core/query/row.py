from uncountable.core.query.column import Column, get_column_base
from uncountable.types import entity_t


class QueryRow:
    """
    Used in conjunction with the QueryBuilder and Column classes to fetch structured data from the Uncountable API

    Define a subclass of QueryRow with Column properties that define the data returned by the query.

    WARNING: This class is in beta and subject to breaking changes. Always check the SDK changelog for breaking changes before updating your SDK version.
    """

    def __repr__(self) -> str:
        column_property_names = [
            key
            for mro in self.__class__.mro()
            for key, value in mro.__dict__.items()
            if isinstance(value, Column)
        ]
        return f"{self.__class__.__name__}({', '.join(f'{key}={value!r}' for key, value in self.__dict__.items() if key in column_property_names)})"

    @classmethod
    def _validate_column_base_types(cls) -> entity_t.EntityType | None:
        base_type: entity_t.EntityType | None = None
        for c in cls.__mro__:
            for value in c.__dict__.values():
                if isinstance(value, Column):
                    if base_type is None:
                        base_type = get_column_base(value.identifier)
                    elif base_type != get_column_base(value.identifier):
                        raise ValueError(
                            "All columns in a query row must have the same base type"
                        )
        return base_type

    def __init_subclass__(cls) -> None:
        cls._validate_column_base_types()
