from dataclasses import dataclass

# This file contains types exclusively used to parse column values.
# Column types must be more permissive than generated SDK types to allow for disparity between the installed client and the platform.
# Eg. types containing an Enum must be typed as EnumType | str to handle future expansion of the Enum by the platform.


@dataclass(kw_only=True, frozen=True)
class TranslatedText:
    value: str
    display_value: str
    inferred_locale: str
