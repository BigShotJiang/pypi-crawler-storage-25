import os
from decimal import Decimal

from uncountable.core import AsyncBatchProcessor, AuthDetailsApiKey, Client
from uncountable.core.file_upload import UploaderFileUpload
from uncountable.types.generic_upload_t import UploadDestinationRecipe
from uncountable.types.identifier import IdentifierKeyId
from uncountable.types.uploader_t import (
    DataChannel,
    DecimalValue,
    NumericChannelData,
    ParsedFileData,
)

client = Client(
    base_url=os.environ["UNC_BASE_URL"],
    auth_details=AuthDetailsApiKey(
        api_id=os.environ["UNC_API_ID"], api_secret_key=os.environ["UNC_API_SECRET_KEY"]
    ),
)

ROWS = 1_000_000
CHANNELS = 2

parsed_file_data = [
    ParsedFileData(
        file_name="large_timeseries.csv",
        file_structures=[
            DataChannel(
                channel=NumericChannelData(
                    name=f"channel_{i}",
                    data=[DecimalValue(value=Decimal("1.0"))] * ROWS,
                ),
            )
            for i in range(CHANNELS)
        ],
    )
]

batch_loader = AsyncBatchProcessor(client=client)

uploaded = client.upload_files(
    file_uploads=[UploaderFileUpload(parsed_file_data=parsed_file_data)]
)

batch_loader.complete_async_parse(
    file_id=uploaded[0].file_id,
    async_job_key=IdentifierKeyId(id=1),
    upload_destination=UploadDestinationRecipe(
        recipe_key=IdentifierKeyId(id=1),
    ),
)
job_id = batch_loader.send()
