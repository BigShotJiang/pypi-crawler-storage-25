from io import BytesIO
from typing import Self

from azure.core.credentials import AzureSasCredential
from azure.storage.fileshare import ShareClient, ShareDirectoryClient

from pkgs.filesystem_utils.file_type_utils import (
    FileObjectData,
    FileSystemFileReference,
    FileSystemFileShareConfig,
    FileSystemObject,
    FileTransfer,
    IncompatibleFileReference,
)
from pkgs.filesystem_utils.filesystem_session import FileSystemSession


class FileShareSession(FileSystemSession):
    def __init__(self, config: FileSystemFileShareConfig) -> None:
        super().__init__()
        self.config = config
        self._share_client: ShareClient | None = None

    def start(self) -> None:
        self._share_client = ShareClient(
            account_url=self.config.account_url,
            share_name=self.config.share_name,
            credential=self.config.credential,
        )

    def __enter__(self) -> Self:
        self.start()
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        self._share_client = None

    def _list_dir(
        self,
        dir_client: ShareDirectoryClient,
        *,
        recursive: bool,
        valid_extensions: list[str] | None,
    ) -> list[FileSystemObject]:
        results: list[FileSystemObject] = []
        for item in dir_client.list_directories_and_files():
            item_path = f"{dir_client.directory_path}/{item['name']}".lstrip("/")
            if item["is_directory"]:
                if recursive:
                    assert self._share_client is not None
                    results.extend(
                        self._list_dir(
                            self._share_client.get_directory_client(item_path),
                            recursive=recursive,
                            valid_extensions=valid_extensions,
                        )
                    )
            elif valid_extensions is None or any(
                item_path.endswith(ext) for ext in valid_extensions
            ):
                results.append(FileSystemFileReference(filepath=item_path))
        return results

    def list_files(
        self,
        dir_path: FileSystemObject,
        *,
        recursive: bool = False,
        valid_extensions: list[str] | None = None,
    ) -> list[FileSystemObject]:
        if not isinstance(dir_path, FileSystemFileReference):
            raise IncompatibleFileReference()
        assert self._share_client is not None, (
            "call to list_files on uninitialized file share session"
        )
        dir_client = self._share_client.get_directory_client(dir_path.filepath)
        return self._list_dir(
            dir_client, recursive=recursive, valid_extensions=valid_extensions
        )

    def download_files(self, filepaths: list[FileSystemObject]) -> list[FileObjectData]:
        assert self._share_client is not None, (
            "call to download_files on uninitialized file share session"
        )
        downloaded: list[FileObjectData] = []
        for file_object in filepaths:
            if (
                not isinstance(file_object, FileSystemFileReference)
                or not file_object.filename
            ):
                raise IncompatibleFileReference()
            file_client = self._share_client.get_file_client(file_object.filepath)
            stream = file_client.download_file()
            file_data = stream.readall()
            downloaded.append(
                FileObjectData(
                    file_data=file_data,
                    file_IO=BytesIO(file_data),
                    filename=file_object.filename,
                    filepath=file_object.filepath,
                )
            )
        return downloaded

    def move_files(self, file_mappings: list[FileTransfer]) -> None:
        assert self._share_client is not None, (
            "call to move_files on uninitialized file share session"
        )
        for src, dest in file_mappings:
            if not isinstance(src, FileSystemFileReference) or not isinstance(
                dest, FileSystemFileReference
            ):
                raise IncompatibleFileReference()
            src_client = self._share_client.get_file_client(src.filepath)
            dest_client = self._share_client.get_file_client(dest.filepath)
            source_url = (
                f"{src_client.url}?{self.config.credential.signature}"
                if isinstance(self.config.credential, AzureSasCredential)
                else src_client.url
            )
            dest_client.start_copy_from_url(source_url)
            src_client.delete_file()

    def delete_files(self, filepaths: list[FileSystemObject]) -> None:
        assert self._share_client is not None, (
            "call to delete_files on uninitialized file share session"
        )
        for file_object in filepaths:
            if not isinstance(file_object, FileSystemFileReference):
                raise IncompatibleFileReference()
            self._share_client.get_file_client(file_object.filepath).delete_file()
