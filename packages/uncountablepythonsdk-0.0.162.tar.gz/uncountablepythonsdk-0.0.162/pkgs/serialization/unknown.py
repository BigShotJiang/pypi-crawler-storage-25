class UnknownBrand:
    """
    A branding to uniquely identify the Unknown type.
    """
