from __future__ import annotations as _annotations

from ._client import RemoteClientConnection, connect_remote_agent
from ._command import CommandOptions, run_remote_command_connection
from ._config import (
    DEFAULT_HEALTH_PATH,
    ServerOptions,
    ServerPaths,
    TransportOptions,
    build_server_paths,
    normalize_mount_path,
)
from ._metadata import ServerMetadata, TransportMetadata, build_server_metadata
from ._proxy_agent import RemoteProxyAgent, connect_acp
from ._server import (
    run_remote_agent_connection,
    serve_acp,
    serve_command,
    serve_remote_agent,
    serve_stdio_command,
)
from ._stream_adapter import WebSocketStreamBridge, open_websocket_stream_bridge
from ._version import __version__

__all__ = (
    "__version__",
    "CommandOptions",
    "DEFAULT_HEALTH_PATH",
    "RemoteClientConnection",
    "RemoteProxyAgent",
    "ServerMetadata",
    "ServerOptions",
    "ServerPaths",
    "TransportOptions",
    "TransportMetadata",
    "WebSocketStreamBridge",
    "build_server_metadata",
    "build_server_paths",
    "connect_remote_agent",
    "connect_acp",
    "normalize_mount_path",
    "open_websocket_stream_bridge",
    "run_remote_command_connection",
    "run_remote_agent_connection",
    "serve_acp",
    "serve_command",
    "serve_remote_agent",
    "serve_stdio_command",
)
