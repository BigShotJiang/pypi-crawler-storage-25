# src/apisniff/recon.py
from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from collections import Counter
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlparse

from rich.console import Console

from apisniff.bundle import (
    CAPTURES_DIR,
    detect_input_format,  # noqa: F401 — re-exported for backwards compat
    load_flows,
    read_capture_jsonl,
    safe_bundle_name,
    write_flow_jsonl,  # noqa: F401 — re-exported for backwards compat
)
from apisniff.models import CapturedFlow, SessionStats

stderr = Console(stderr=True)


@dataclass
class _BundleResult:
    report_md: str
    vendors: list
    auth_patterns: list
    cookies: list
    cookies_path: Path | None
    graphql_schema_path: Path | None


def _post_process_bundle(
    domain: str,
    flows: list[CapturedFlow],
    bundle_dir: Path,
    session_stats: SessionStats | None,
    *,
    fetch_graphql: bool = True,
) -> _BundleResult:
    """Auth, cookies, GraphQL, vendors, report. Returns structured result."""
    import asyncio

    from apisniff.auth import cookies_to_cookiejar, detect_auth, extract_cookies
    auth_patterns = detect_auth(flows)
    cookies = extract_cookies(flows)

    cookies_path: Path | None = None
    cookies_txt = cookies_to_cookiejar(cookies)
    if cookies_txt:
        cookies_path = bundle_dir / "cookies.txt"
        cookies_path.write_text(cookies_txt)

    graphql_schema_path: Path | None = None
    if fetch_graphql:
        from apisniff.probe import fetch_graphql_schema
        gql_flows = [f for f in flows if "graphql" in f.path.lower()]
        gql_paths = sorted({f.path for f in gql_flows})
        gql_headers: dict[str, str] = {}
        if gql_flows:
            sample = gql_flows[0].request_headers
            for hdr in ("authorization", "cookie", "x-api-key"):
                if hdr in sample:
                    gql_headers[hdr] = sample[hdr]
        for gql_path in gql_paths:
            schema_url = f"https://{domain}{gql_path}"
            schema = asyncio.run(
                fetch_graphql_schema(schema_url, headers=gql_headers or None)
            )
            if schema:
                graphql_schema_path = bundle_dir / "graphql-schema.json"
                graphql_schema_path.write_text(json.dumps(schema, indent=2))
                break

    from apisniff.vendors import flows_to_probe_results, load_signatures, match_vendors
    vendors = match_vendors(flows_to_probe_results(flows), load_signatures())

    from apisniff.report import generate_report
    report = generate_report(
        domain=domain, flows=flows, session_stats=session_stats,
        vendors=vendors, auth_patterns=auth_patterns, cookies=cookies,
    )
    report_path = bundle_dir / "report.md"
    report_path.write_text(report)

    return _BundleResult(
        report_md=report,
        vendors=vendors,
        auth_patterns=auth_patterns,
        cookies=cookies,
        cookies_path=cookies_path,
        graphql_schema_path=graphql_schema_path,
    )


def _normalize_target(raw: str) -> tuple[str, str]:
    """Return (bare_domain, launch_url) from user input that may include a scheme or path."""
    if raw.startswith(("http://", "https://")):
        parsed = urlparse(raw)
        domain = parsed.netloc or parsed.path.split("/")[0]
        return domain, raw
    return raw, f"https://{raw}"


def run_recon(
    domain: str,
    port: int = 8080,
    proxy: str | None = None,
    json_output: bool = False,
) -> None:
    domain, launch_url = _normalize_target(domain)
    CAPTURES_DIR.mkdir(parents=True, exist_ok=True)
    CAPTURES_DIR.chmod(0o700)
    ts = datetime.now(UTC).strftime("%Y-%m-%d_%H-%M")
    safe_domain = safe_bundle_name(domain)
    bundle_dir = CAPTURES_DIR / f"{safe_domain}_{ts}"
    bundle_dir.mkdir(parents=True, exist_ok=True)
    bundle_dir.chmod(0o700)
    output_path = bundle_dir / "flows.jsonl"

    addon_path = Path(__file__).parent / "proxy.py"

    env = {**os.environ, "APISNIFF_TARGET": domain, "APISNIFF_OUTPUT": str(output_path)}

    cmd = [
        sys.executable, "-c",
        "from mitmproxy.tools.main import mitmdump; mitmdump()",
        "--listen-port", str(port),
        "--set", "console_eventlog_verbosity=error",
        "-s", str(addon_path),
    ]
    if proxy:
        cmd.extend(["--mode", f"upstream:{proxy}"])

    chrome_profile = Path(f"/tmp/apisniff-chrome-{port}")
    chrome_cmd = [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        f"--proxy-server=http://127.0.0.1:{port}",
        f"--user-data-dir={chrome_profile}",
        "--no-first-run",
        "--no-default-browser-check",
        launch_url,
    ]

    stderr.print(f"\n[bold]apisniff recon[/bold] — {domain}")
    stderr.print(f"  Proxy: 127.0.0.1:{port}")
    stderr.print(f"  Bundle: {bundle_dir}")
    stderr.print("  Press Ctrl+C to stop capture.\n")

    proxy_proc = subprocess.Popen(cmd, env=env)
    time.sleep(1)

    if proxy_proc.poll() is not None:
        stderr.print(
            f"[red]mitmproxy exited with code {proxy_proc.returncode}[/red]"
        )
        return

    try:
        chrome_proc = subprocess.Popen(
            chrome_cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        stderr.print("[yellow]Chrome not found — open a browser manually[/yellow]")
        stderr.print(f"  Set proxy to http://127.0.0.1:{port}")
        chrome_proc = None

    try:
        proxy_proc.wait()
    except KeyboardInterrupt:
        stderr.print("\n[yellow]Stopping capture...[/yellow]")
        proxy_proc.send_signal(signal.SIGINT)
        if chrome_proc:
            chrome_proc.terminate()
        try:
            proxy_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proxy_proc.kill()
        if chrome_proc:
            try:
                chrome_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                chrome_proc.kill()

    flows = read_capture_jsonl(str(output_path)) if output_path.exists() else []

    session_stats = None
    session_path = bundle_dir / "session.json"
    try:
        session_stats = SessionStats.from_dict(json.loads(session_path.read_text()))
    except FileNotFoundError:
        pass
    except (json.JSONDecodeError, KeyError):
        stderr.print("[yellow]Warning: session.json corrupted, skipping drop stats[/yellow]")

    if not flows:
        stderr.print(f"\n  No flows captured → {bundle_dir}\n")
        return

    result = _post_process_bundle(domain, flows, bundle_dir, session_stats)
    from apisniff.output import render_recon
    render_recon(
        domain=domain,
        session_stats=session_stats,
        flows=flows,
        vendors=result.vendors,
        auth_patterns=result.auth_patterns,
        cookies=result.cookies,
        bundle_dir=bundle_dir,
        cookies_path=result.cookies_path,
        graphql_schema_path=result.graphql_schema_path,
        console=stderr,
    )


def run_analyze(
    input_file: str,
    domain: str | None = None,
    json_output: bool = False,
    output_dir: str | None = None,
    fetch_graphql: bool = False,
) -> None:
    """Offline analysis: load a traffic capture, classify, extract everything."""
    flows, fmt = load_flows(input_file)
    if not flows:
        stderr.print("[yellow]No flows found in input file.[/yellow]")
        return

    if domain is None:
        from apisniff.classify import extract_registered_domain
        host_counter: Counter[str] = Counter(
            extract_registered_domain(f.host) for f in flows if f.host
        )
        if not host_counter:
            stderr.print("[red]Cannot determine domain — use --domain.[/red]")
            return
        most_common = host_counter.most_common(2)
        top_domain, top_count = most_common[0]
        if len(most_common) > 1:
            _, second_count = most_common[1]
            if top_count < 2 * second_count:
                stderr.print(
                    f"[yellow]Warning: ambiguous domain — "
                    f"top '{top_domain}' ({top_count}) is not 2x second "
                    f"({second_count}). Use --domain to specify explicitly.[/yellow]"
                )
        domain = top_domain

    kept_flows: list[CapturedFlow]
    drop_counts: dict[str, int] = {}

    if fmt in ("har", "burp"):
        from apisniff.classify import Classifier
        classifier = Classifier(target_domain=domain)
        kept_flows = []
        for flow in flows:
            result = classifier.classify(flow)
            if result.action == "keep":
                if result.flow is not None:
                    kept_flows.append(result.flow)
            else:
                drop_counts[result.category] = drop_counts.get(result.category, 0) + 1
    elif fmt == "jsonl":
        kept_flows = flows
    else:
        stderr.print(f"[red]Unrecognised format for {input_file}[/red]")
        return

    if output_dir:
        bundle_dir = Path(output_dir)
    else:
        CAPTURES_DIR.mkdir(parents=True, exist_ok=True)
        CAPTURES_DIR.chmod(0o700)
        ts = datetime.now(UTC).strftime("%Y-%m-%d_%H-%M")
        safe_domain = safe_bundle_name(domain)
        bundle_dir = CAPTURES_DIR / f"{safe_domain}_{ts}_analyze"

    bundle_dir.mkdir(parents=True, exist_ok=True)
    bundle_dir.chmod(0o700)

    session_path = bundle_dir / "session.json"
    if session_path.exists():
        try:
            session_stats = SessionStats.from_dict(json.loads(session_path.read_text()))
        except (json.JSONDecodeError, KeyError):
            session_stats = None
    else:
        session_stats = None
    if session_stats is None:
        session_stats = SessionStats(
            domain=domain,
            started_at=datetime.now(tz=UTC).isoformat(),
            duration_seconds=0.0,
            total_flows=len(flows),
            kept_flows=len(kept_flows),
            dropped=drop_counts,
        )
        session_path.write_text(json.dumps(session_stats.to_dict(), indent=2))

    flows_path = bundle_dir / "flows.jsonl"
    if Path(input_file).resolve() != flows_path.resolve():
        with open(flows_path, "w") as fh:
            for flow in kept_flows:
                fh.write(flow.to_jsonl() + "\n")

    result = _post_process_bundle(
        domain, kept_flows, bundle_dir, session_stats,
        fetch_graphql=fetch_graphql,
    )

    if json_output:
        sys.stdout.write(json.dumps(session_stats.to_dict(), indent=2) + "\n")
        stderr.print(f"\n  Report: {bundle_dir / 'report.md'}")
        stderr.print(f"  Analyzed [bold]{len(kept_flows)}[/bold] flows → {bundle_dir}\n")
    else:
        from apisniff.output import render_recon
        render_recon(
            domain=domain,
            session_stats=session_stats,
            flows=kept_flows,
            vendors=result.vendors,
            auth_patterns=result.auth_patterns,
            cookies=result.cookies,
            bundle_dir=bundle_dir,
            cookies_path=result.cookies_path,
            graphql_schema_path=result.graphql_schema_path,
            command="analyze",
            console=stderr,
        )
