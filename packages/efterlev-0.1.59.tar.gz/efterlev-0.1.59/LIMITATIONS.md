# Limitations

Efterlev is useful. It is also bounded in specific ways. This document names those bounds honestly, because compliance tooling that overclaims is worse than compliance tooling that's modest about its scope.

**This is a first-class document, not a disclaimer.** It is updated alongside feature work, not at release time.

---

## What Efterlev does not do

### It does not produce an Authorization to Operate (ATO)

Efterlev produces drafts, findings, and evidence. The authorization decision is made by a human Authorizing Official after review by a 3PAO (for FedRAMP) or an authorized assessor (for DoD IL). No tool — AI-powered or otherwise — produces an ATO.

### It does not certify compliance

An Efterlev scan that finds no gaps does not mean the system is compliant with the target framework. It means the controls Efterlev can detect show no gaps. The controls Efterlev does not detect (policy, procedural, human-process) are unaddressed by the tool.

### It does not replace a 3PAO or an assessor

Efterlev accelerates the draft-and-review cycle. It does not substitute for independent assessment. LLM-generated narratives are drafts, marked as drafts, and require human review before submission to any authorizing body.

### It does not guarantee the accuracy of generated content

Generated content — FRMR attestations, KSI mappings, SSP narratives (v1), remediation proposals — is produced by large language models. Models hallucinate. Efterlev's provenance system mitigates hallucination by forcing every generated claim to cite its underlying evidence, but it does not eliminate it. Every Claim in the system carries a "DRAFT — requires human review" marker for this reason.

### It does not scan live cloud infrastructure (at v0.1.x)

Efterlev reads Terraform and OpenTofu source files (`.tf`), Terraform plan-JSON output (`terraform show -json`), GitHub workflow YAML (`.github/workflows/*.yml`), and customer-authored attestation manifests (`.efterlev/manifests/*.yml`). It does not call AWS, Azure, or GCP APIs to inspect running resources. CloudFormation, AWS CDK, Pulumi, Kubernetes manifests, and runtime cloud API scanning are deferred to v1.5+, gated on customer pull.

### It does not perform continuous monitoring (at v0.1.x)

Efterlev runs on demand (locally or in CI). It does not run as a daemon watching for drift. The provenance graph's append-only, versioned structure is designed to support continuous monitoring in a later release, but the monitoring daemon itself is not yet built. The "ConMon Lite" PR-delta check (compare the PR scan to the base-branch scan and post a regression comment) shipped at the v0 layer in v0.1.51 (Tier 4 #1) — scanner-only at v0; KSI-verdict diffs deferred to ConMon Lite v1 once a verdict-stability mechanism is in place.

### It does not cover the full FedRAMP 20x Moderate KSI set via detectors alone

At v0.1.17, **45 detectors ship** (38 KSI-mapped + 7 supplementary 800-53-only), covering **31 of the 60 thematic KSIs across 8 of 11 themes** (CNA, CMT, IAM, MLA, PIY, RPL, SCR, SVC). The 3 uncovered themes (AFR, CED, INR) are entirely procedural and cannot be evidenced from code alone. For those — and for the procedural aspects of KSIs in the 8 covered themes — Evidence Manifests are the complement: customers author signed attestations under `.efterlev/manifests/*.yml` and those records flow into the Gap Agent alongside detector Evidence. Scanner-only coverage of the baseline is meaningful but partial; scanner + manifests can approach 80%+ when customers author the procedural attestations their organization can genuinely sign for. The v0.1.18+ manifest starter-pack work will ship 30–40 templates for the commonly-procedural KSIs as a first-day asset for new users (see `CLAUDE.md` "Path forward").

### The FRMR KSI ↔ 800-53 mapping has known gaps

FRMR is at version 0.9.43-beta as of the vendored snapshot. Some 800-53 controls we can genuinely detect do not yet map to any KSI — most notably SC-28 (encryption at rest). Where this happens, Efterlev will evidence the underlying control honestly and flag the KSI mapping as `[TBD]` or use the closest thematic fit with an explicit caveat in the detector's README. We do not invent KSIs that do not exist in the vendored FRMR, and we do not claim clean KSI alignment where one does not exist.

### It does not automatically detect policy, procedural, or human-process controls

Controls like AT-* (Awareness and Training), PL-* (Planning), PS-* (Personnel Security), PM-* (Program Management), and large parts of AC-* (Access Control — the procedural aspects) cannot be detected from code and IaC alone. v1 Phase 1 Evidence Manifests are the path: customers declare what their organization does and who signed off (a VP, a security lead, a runbook owner) in a YAML the same way they commit code. The Gap Agent sees those attestations and classifies KSIs accordingly. What Efterlev does NOT do is evidence the underlying human process; it captures the attestation and its review cadence (`next_review` date), and the tool's output makes clear the record is human-signed, not machine-verified. A reviewer or 3PAO still evaluates the underlying process.

### It does not cover frameworks beyond FedRAMP and DoD IL (at v0.1.x)

CMMC 2.0 is the planned next framework (same 800-171 base, different overlay), held for a future release. SOC 2, ISO 27001, HIPAA, PCI-DSS, GDPR are explicitly out of scope — other tools (Comp AI, Vanta, Drata) serve those frameworks well, and Efterlev's focus on gov-grade frameworks is deliberate.

### It does not create real pull requests (at v0.1.x)

The Remediation Agent produces code diffs as local output (`efterlev agent remediate --ksi <id>` → unified diff on stdout + HTML/JSON sidecar in `.efterlev/reports/`). Opening PRs against remote repositories is a future capability; today the diff is for the user to review and apply manually.

---

## Known limitations in what Efterlev does do

### Detector coverage is partial by design

Each detector's `README.md` states what the detector proves and what it does not prove. For example: the SC-28 S3 encryption detector evidences the infrastructure layer of SC-28 (encryption is configured) but does not evidence the procedural layer (key management practices, rotation policies, BYOK). Never read an Efterlev finding as "SC-28 is implemented"; read it as "infrastructure-layer evidence for SC-28 is present."

### The HCL parser lags upstream Terraform syntax

Efterlev's `.tf` parser uses [`python-hcl2`](https://github.com/amplify-education/python-hcl2), a pure-Python re-implementation of HashiCorp's HCL2 grammar. python-hcl2 trails upstream Terraform — certain valid 1.x constructs (notably for-expressions inside list comprehensions emitting object literals, e.g. EFA network interface configuration in `terraform-aws-modules/terraform-aws-eks`) raise `Unexpected token` parse errors. Discovered 2026-04-25 dogfooding `terraform-aws-eks` and `cloudposse/terraform-aws-components` (13 of ~1800 files unparseable in the latter).

**Behavior on parse failure (post-2026-04-25):** the scan is partial-success. Each unparseable file is recorded as a `ParseFailure` and the walk continues. The CLI prints a warning block listing skipped files and exits 0 if any file parsed; non-zero only when every file failed. Detector coverage on a partially-failing codebase is reduced by exactly the resources in those files.

**Workaround for codebases with persistent failures:** use plan-JSON mode. `terraform plan -out plan.bin && terraform show -json plan.bin > plan.json && efterlev scan --plan plan.json` — plan JSON is HashiCorp-emitted and bypasses python-hcl2 entirely. Every detector runs against plan-derived resources without modification (Phase B equivalence test in `tests/detectors/test_plan_mode_equivalence.py`).

**Upgrade path:** when python-hcl2 catches up to the syntax (or we swap to a maintained alternative — `hcl-parser`-style native bindings, a Go-shellout to `hcl2json`, etc.). Tracked as a v0.2.0 follow-up; not blocking launch because plan-JSON mode is a clean workaround for the affected codebases.

### FRMR attestation output is Pydantic-validated, not FedRAMP-schema-validated

The FRMR attestation JSON artifact (`efterlev agent document` output) is validated against the Pydantic `AttestationArtifact` model at construction time — `extra="forbid"`, strict literal types, `requires_review=Literal[True]`. FedRAMP's vendored `FedRAMP.schema.json` describes the FRMR *catalog* (what KSIs exist), not attestation *output* (a CSP's statement of evidence). FedRAMP has not published an attestation-output schema as of April 2026; when they do, Efterlev will migrate. See `DECISIONS.md` 2026-04-22 "Phase 2: FRMR attestation generator" for the full schema-posture call. Regardless of schema validation, submission-time FedRAMP review may apply additional constraints the tool does not capture — the artifact is a draft, always.

### OSCAL output is deferred to v1.5+

The v1 scope lock (2026-04-22) moved OSCAL SSP / AR / POA&M generators from v1 to v1.5+, gated on customer pull. The internal data model already supports serialization into OSCAL shapes when needed; the generators are not built. Rev5-transition users and RegScale OSCAL-Hub-consuming prospects are the signal that pulls them forward.

### Generated narratives reflect the evidence we have, not the narrative the reviewer expects

LLM-drafted SSP narratives are grounded in the evidence records Efterlev has collected. If the evidence is thin, the narrative will be thin. The Documentation Agent does not invent implementation details to fill gaps; it describes what is evidenced and flags what is not.

### Cross-platform install validation is non-blocking

`release-smoke.yml` runs a 7-cell matrix that validates `pipx install efterlev` and `docker pull ghcr.io/efterlev/efterlev` actually works on Linux x86, Linux arm64, macOS Intel, macOS arm64, and Windows. The matrix is configured non-blocking (`continue-on-error: true` on the matrix job) because the v0.0.1-rc dry-runs (2026-04-26) showed it fighting GitHub-CI infrastructure quirks (uv cache propagation, TestPyPI CDN edge staleness, setup-uv's cache-restoration behavior) more than reporting product bugs — verified by identical local `uv tool install` succeeding first try. The build, sign, and publish paths are validated by `release-pypi.yml` + `release-container.yml`; the new `post-release-triage.yml` workflow (v0.1.16+) runs `pipx install efterlev==<version>` against the published wheel as **T1** of `scripts/triage.sh`, providing a single-cell post-publish install gate that DOES block release-quality regressions. Cross-platform matrix coverage is tracked as a v0.2 follow-up in `docs/followups.md`.

### Narrative templates are not enforced (SPEC-57.4 follow-up)

The Documentation Agent's per-KSI narratives vary in length and structure across status classes — some tight, some longer with multi-paragraph reviewer-action lists. The 3PAO review of 2026-04-25 noted this as an observation (not a blocker) for downstream review tooling that wants to do automated content checks. v0.2 work after launch will derive a consistent narrative template from real-customer artifacts; locking one now risks over-fitting to the dogfooded codebase shape. See `docs/specs/SPEC-57.md` §SPEC-57.4 for the deferral rationale.

### Cost estimates are best-effort

The end-of-run cost summary on `efterlev agent {gap, document, remediate}` (v0.1.19+) reads token usage from `.efterlev/receipts.log` and multiplies by Anthropic's published per-MTok pricing for the model used. Pricing snapshots live in `src/efterlev/llm/pricing.py` with `as_of` dates per entry. Anthropic occasionally adjusts prices and adds discounts; the `~` prefix on the dollar estimate signals approximation, not authority. Bedrock backend uses the Anthropic API rate as a proxy because AWS Bedrock pricing varies by region and discount tier — the summary surfaces the proxy nature with a `via bedrock; AWS region pricing may differ` suffix. Models not registered in the pricing table show tokens-only with a `pricing for <model> not registered` hint instead of crashing or guessing. For audit-precise cost accounting, walk `.efterlev/receipts.log` directly with the AWS or Anthropic billing console as truth source.

### Confidence levels are heuristic

Claims carry confidence levels (`low` / `medium` / `high`). These are heuristic, not statistically calibrated. They reflect model signal on narrative specificity and evidence density, not a measured probability of correctness.

### The tool itself is not FedRAMP-authorized

Efterlev is a developer tool that runs locally or in CI. It is not an authorized cloud service. Using Efterlev does not confer any authorization status on the user's system.

---

## How to read Efterlev output responsibly

1. **Findings are evidence, not conclusions.** An Efterlev finding that SC-28 has infrastructure-layer evidence is a starting point for a compliance review, not the review itself.
2. **Claims require human review.** Every LLM-generated artifact is marked "DRAFT." Do not submit Efterlev-generated SSP narratives to a 3PAO without human review.
3. **Walk the provenance chain.** Every generated sentence can be traced back to the evidence that produced it. If the chain doesn't resolve or the evidence is thin, the sentence is weak.
4. **Treat coverage gaps as coverage gaps.** Controls Efterlev did not detect are not controls that are absent; they are controls Efterlev did not look for. Separate tools or manual review cover the rest.

---

## Historical doc-vs-code drift (resolved)

Several pre-launch doc-vs-code drift items were tracked here through v0.1.0.
All have been resolved and are now part of shipped behavior:

- **Secret redaction before LLM transmission** — pattern-based scrubber in
  `src/efterlev/llm/scrubber.py` runs unconditionally; 7 secret families
  (AWS, GCP, GitHub, Slack, Stripe, PEM, JWT). See `THREAT_MODEL.md`
  "Secrets handling".
- **Store-write-time `validate_claim_provenance`** —
  `ProvenanceStore.write_record` validates every Claim's `derived_from` at
  write time; unresolvable IDs raise `ProvenanceError` before insertion.
  DECISIONS 2026-04-23.
- **Retry + Opus-to-Sonnet fallback on transient errors** —
  `AnthropicClient` retries 3× with exponential backoff + full jitter, then
  falls back once from primary to secondary model before surfacing.
- **Provenance-walk source-ref rendering** — walker loads the evidence blob
  at walk time and renders `source=<file>:<start>-<end>` at evidence leaves
  (commit 69873a0).
- **PyPI release + `pipx install efterlev`** — published; v0.1.59 is current.
  Trusted Publishing via PEP 740. 61 patch releases since v0.1.0 (2026-04-29).
- **Sigstore / cosign signing of release artifacts** — every release is
  cosign-keyless-OIDC-signed; v0.1.13+ adds cosign-verifiable SLSA v1 build
  provenance via `actions/attest-build-provenance`. `scripts/verify-release.sh`
  validates 4/4 against any tag (v0.1.13+); pre-v0.1.13 tags pass 3/4 by
  design (SLSA-attestation step landed v0.1.13).

The shape of doc-vs-code drift is now caught structurally rather than
reactively:

- **`scripts/check-docs.py`** runs on every PR, with rules for test/detector/
  indicator/source-file count drift (v0.1.0+), `.efterlev/reports/<subdir>/`
  path-shape drift (v0.1.12), and `vX.Y.Z is current` version-claim drift
  (v0.1.14). Each rule asserts its claim against the in-source truth.
- **`scripts/triage.sh`** + **`.github/workflows/post-release-triage.yml`**
  (v0.1.16) auto-run after every tag push, install the published wheel from
  PyPI in a fresh venv, and re-run check-docs against the *tagged source* —
  so any drift between what the tag says and what `__version__` claims is
  reported on the GitHub Release page within minutes of publish. The auto-
  triage's first run on v0.1.16 itself caught its own infrastructure bugs;
  v0.1.17 closed them. The methodology is the structural fix that makes
  this LIMITATIONS section less likely to drift again.

### Lessons learned: silent matrix failures v0.1.20–v0.1.21 (resolved at v0.1.22; full cascade through v0.1.27)

`release-smoke` had been silently failing across **every matrix cell**
(macOS-13, macOS-14, Windows-2022, Ubuntu-22.04, Ubuntu-24.04-arm; both
`pipx` and `docker-ghcr` install methods) for at least the v0.1.20 +
v0.1.21 release cycles. Two assertion bugs in `tests/smoke/assert.py`
made it impossible to pass against a real install — wrong SQLite table
name + a `reports/` directory check the workflow's command sequence
never produced. The failure was masked because `gh run list` collapses
workflow_run state to a single column; the column read "queued" while
every individual matrix cell failed. Manual `gh run view` was the only
way to see the matrix conclusion, and nobody was running it routinely
because the post-release-triage report on the GitHub Release page was
the trusted observable surface — and that report didn't include
release-smoke status.

**Resolved at v0.1.22; cascade closed through v0.1.27:**

The smoke-assertion fix in v0.1.22 made the matrix actually run, which
exposed a *cascade* of platform-specific bugs that had been silently
masked. Each release in the cascade closed one layer and surfaced the
next, until v0.1.27 landed the matrix fully green for the first time:

- **v0.1.22** — assertion script fixed (`provenance_records` table
  name + drop the spurious `reports/` dir check). T7 added to
  `scripts/triage.sh` to surface matrix conclusion on the GH Release
  page.
- **v0.1.23** — workflow `GITHUB_TOKEN` env + trigger gate
  (`{success, failure}` allowlist filters out stale-cancellation
  triggers); Windows top-level `import fcntl` replaced with
  platform-gated `_flock_exclusive` / `_flock_release` helpers
  (fcntl on POSIX, msvcrt on Windows); docker-ghcr SQLite open via
  URI `?mode=ro`.
- **v0.1.24** — WAL-mode SQLite needs `&immutable=1` (not just
  `?mode=ro`) when the DB is on read-only media; v0.1.23's test used
  a non-WAL fixture and missed the prod failure mode.
- **v0.1.25** — `Path.open()` defaults to OS-default encoding
  (cp1252 on Windows); FRMR catalog loader now passes
  `encoding="utf-8"` explicitly.
- **v0.1.26** — `msvcrt.locking()` is byte-range based; with
  `O_APPEND` the unlock targets a different byte range than the
  lock. Fix: `lseek(fd, 0)` before both lock and unlock.
- **v0.1.27** — Windows console default cp1252 can't encode `⚠`
  + other non-Latin-1 chars used in CLI output. Fix: reconfigure
  `sys.stdout` + `sys.stderr` to UTF-8 at CLI import time on Windows.

Source-level pin tests (read the source file, assert the fix shape is
present) lock every fix on every dev platform — no Windows runner
needed to catch a regression.

**Generalized lessons:**

1. **Single observable surface applies to CI.** If a release-quality
   signal isn't on the surface that's routinely checked, it might as
   well not exist. v0.1.22's T7 puts matrix conclusion on the GH Release
   page alongside T1-T6.
2. **Each cascade fix surfaces the next layer.** Bugs were stacked in
   import → runtime order; Windows fcntl crashed at import, so no
   later runtime bug could surface until v0.1.23 fixed it. Auto-triage
   doing what v0.1.16 designed it for.
3. **Test the prod failure mode, not an approximation.** v0.1.23's
   `test_assert_passes_against_readonly_db` used chmod-on-file and a
   non-WAL fixture; v0.1.24's `..._readonly_dir` reproduced the actual
   docker-ghcr scenario (chmod on directory + WAL fixture) and was
   A/B-verified to fail when the fix is reverted.

## Where we are honest and where we are aspirational

**Honest today:**
- The gaps listed above are named; they are not claimed as implemented.
- Detector output is real and grounded (see per-detector README for
  what each does and does not prove).
- The provenance chain is walkable for every generated claim; the
  walker's text rendering is minimal but the graph is complete.
- Per-agent citation validators DO reject fabricated evidence IDs.
- Per-run nonced XML fences (`<evidence_NONCE>…</evidence_NONCE>`) ARE
  in place and tested against adversarial content injection
  (post-review fixup F, 2026-04-22).

**Aspirational / roadmap (v0.1.18+ Tier 1, in priority order):**
- ~~`efterlev quickstart`~~ **shipped at v0.1.18.** One-command demo that runs init→scan→gap→document end-to-end against a bundled synthetic Terraform fixture under the platform-appropriate user cache dir. ~3 min wall, ~$0.30 on Sonnet; graceful no-key degradation runs init+scan only.
- ~~Cost + prompt visibility (2a — end-of-run summary)~~ **shipped at v0.1.19.** Each `efterlev agent {gap, document, remediate}` prints a one-line cost summary at end-of-run: tokens in/out + estimated USD against the model used. Bedrock backend qualifies the dollar estimate with a `via bedrock; AWS region pricing may differ` suffix; unregistered models surface tokens-only with a `pricing not registered` hint. Pricing snapshots in `src/efterlev/llm/pricing.py` carry `as_of` dates; estimates are best-effort approximations (see "Cost estimates are best-effort" below).
- ~~Cost + prompt visibility (2b — `--dry-run` / `--dump-prompt`)~~ **shipped at v0.1.20.** Each agent command gains `--dry-run` (prints the assembled prompts as JSON to stdout without invoking the LLM) and `--dump-prompt PATH` (writes to file; refuses to overwrite without `--force`). All prompts captured (not just the first), literal Anthropic API request envelope shape, per-prompt `_efterlev` metadata with token + dollar cost estimates. Audit-credibility primitive: a 3PAO can verify exactly what was sent to the LLM, see redactions in place, see fence nonces. No network call, no Claim writes to the store.
- ~~Manifest starter pack~~ **shipped at v0.1.21 (24 templates); expanded to 26 at v0.1.35** with KSI-MLA-RVL + KSI-SVC-EIS to close the Tier 1 #4 design entry's projected manifest follow-ups. Evidence Manifest templates covering the commonly-procedural KSIs (10 AFR + 4 CED + 3 INR + 4 PIY + 1 each CMT-RVP / RPL-RRO / SVC-PRR / MLA-RVL / SVC-EIS — selection criteria + per-KSI rationale at `src/efterlev/manifest_templates/SELECTION.md`). Copy into a workspace via `efterlev manifests init --starter-pack`. Templates land in `.efterlev/manifests/starter-pack/` (subdir, outside the loader's pickup glob — safe by default); each carries a `_template_help` block with hand-authored description + question prompts plus a structurally-valid attestation skeleton with explicit `DRAFT —` placeholders. Defense-in-depth: the manifest loader explicitly skips `*.template.yml` files even when placed directly in `.efterlev/manifests/`. `--force` required to overwrite the subdir.
- Detector gap analysis — DECISIONS entry classifying the 29 currently-
  uncovered KSIs by `evidenceable-via-iac` / `partial` / `procedural-only`,
  followed by per-KSI detector PRs for the first bucket.

**Tier 2 (after Tier 1 lands):**
- CloudFormation / AWS CDK source support (ICP doc names this v1 month 1–2).
- ConMon Lite v2 — configurable severity thresholds, gating policy (block-on-regress with skip label), drift detection over time (not just PR-delta but base-vs-prior-base; would need a stored baseline), suppression annotations (`# efterlev-ignore: KSI-CNA-RVP`). v0 (scanner-only) shipped in v0.1.51; v1 (Gap-Agent KSI-verdict diffs with 2-of-3 majority voting) shipped in v0.1.52.
**Out of scope this cycle:**
- Web UI, SaaS / multi-tenancy, runtime cloud API scanning, CMMC overlay,
  additional frameworks (SOC 2, ISO 27001, HIPAA, PCI-DSS, GDPR), Pulumi or
  Kubernetes support. Each of these is named in `docs/icp.md` as off-target
  for ICP A; promoting any requires a DECISIONS entry first.

The distinction is maintained in `README.md` (shipped) + `CLAUDE.md`
"Path forward" (Tier 0/1/2). `docs/followups.md` holds the longer-tail
backlog (provenance polish, FRMR upstream issues, infrastructure work).

---

## Reporting a limitation we haven't named

If you find a case where Efterlev overclaims, underdelivers, or produces misleading output, file an issue. Honest limitations are a product feature; undocumented ones are a bug.
