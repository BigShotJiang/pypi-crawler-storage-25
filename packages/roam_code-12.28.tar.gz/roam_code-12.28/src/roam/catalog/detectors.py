"""Algorithm detection: query DB signals to find suboptimal patterns.

Each detector has signature ``(conn) -> list[dict]`` and returns findings
with fields: task_id, detected_way, suggested_way, symbol_id, symbol_name,
kind, location, confidence, reason.

Design principles (informed by research):
- Structural AST patterns (loop depth, accumulator, subscript) are more
  reliable than function-name matching alone.
- Name matching is a confidence booster, not a gate.
- Idiom-only improvements (same Big-O) get ``low`` confidence.
- Genuine complexity-class improvements get ``medium`` or ``high``.
- Suppress known false-positive patterns (grid traversal, intentional polling).
"""

from __future__ import annotations

import json
import os
import re
import sqlite3

from roam.catalog.tasks import best_way


def _is_test_path(path: str) -> bool:
    p = path.replace("\\", "/").lower()
    base = os.path.basename(p)
    if base.startswith("test_") or base.endswith("_test.py"):
        return True
    if "tests/" in p or "test/" in p or "__tests__/" in p or "spec/" in p:
        return True
    return False


def _loc(path: str, line) -> str:
    if line is not None:
        return f"{path}:{line}"
    return path


def _finding(
    task_id,
    detected_way,
    sym,
    reason,
    confidence="medium",
    *,
    evidence=None,
    fix=None,
    match_line=None,
):
    """Build a finding dict.

    M1 (2026-05-06): when ``match_line`` is supplied, the finding's
    ``location`` field points at the exact AST node where the pattern
    matched (e.g. the line containing the .sort() call) — not the
    enclosing function declaration. The function-start line is
    preserved as ``symbol_line`` so callers needing both have access.
    """
    bw = best_way(task_id)
    sym_line = sym["line_start"]
    actual_line = match_line if match_line is not None else sym_line
    finding = {
        "task_id": task_id,
        "detected_way": detected_way,
        "suggested_way": bw["id"] if bw else "",
        "symbol_id": sym["id"],
        "symbol_name": sym["qualified_name"] or sym["name"],
        "kind": sym["kind"],
        "location": _loc(sym["file_path"], actual_line),
        "symbol_line": sym_line,
        "confidence": confidence,
        "reason": reason,
    }
    if evidence:
        finding["evidence"] = evidence
    if fix:
        finding["fix"] = fix
    return finding


def _find_match_line(snippet: str, pattern, sym_line_start: int | None) -> int | None:
    """Walk the snippet line by line to find the first line matching ``pattern``.

    Returns the absolute line number (sym_line_start + offset). When
    snippet doesn't contain the match, returns sym_line_start unchanged
    so callers can blindly substitute.

    Used by sort-to-select / IO-in-loop / regex-in-loop detectors to
    pin findings at the exact match site.
    """
    if not snippet or sym_line_start is None:
        return sym_line_start
    for offset, line in enumerate(snippet.splitlines()):
        if pattern.search(line):
            return sym_line_start + offset
    return sym_line_start


# M4 — recognise DEV-only / DEBUG-only gates so production-impact
# detectors don't fire on code that's stripped from production builds.
# Real-world examples (from the prior round of FPs):
#   - if (import.meta.env.DEV) { ... heavy diagnostics ... }
#   - if (process.env.NODE_ENV !== 'production') { ... }
#   - if (__DEV__) { ... }
#   - if (DEBUG) { ... }
#   - console.assert(...)  — short-circuits in production
_DEV_GATE_RE = re.compile(
    # No trailing \b — alternatives ending in `'production'` or `__DEV__` have
    # non-word chars after them, so the global `\b` would never fire there.
    r"\bif\s*\([^)]*?\b(?:"
    r"import\.meta\.env\.(?:DEV\b|MODE\s*[!=]==?\s*['\"]production['\"])|"
    r"process\.env\.NODE_ENV\s*[!=]==?\s*['\"]production['\"]|"
    r"__DEV__|"
    r"DEBUG\b"
    r")",
    re.IGNORECASE,
)
_CONSOLE_ASSERT_RE = re.compile(r"\bconsole\.assert\s*\(")


def _is_dev_only_block(snippet: str, match_line_offset: int | None = None) -> bool:
    """Heuristic: does the snippet (or the lines around the match) sit inside
    a DEV-only conditional?

    Conservative matcher: returns True only when an obvious DEV gate is
    visible *before* the match line in the snippet. Won't catch every
    case (e.g. a flag set in a parent function), but catches the common
    Vue 3 / React / Next.js / Vite patterns where heavy diagnostics live
    behind import.meta.env.DEV.
    """
    if not snippet:
        return False
    if _DEV_GATE_RE.search(snippet) or _CONSOLE_ASSERT_RE.search(snippet):
        return True
    return False


def _find_first_keyword_line(snippet: str, keywords: tuple[str, ...], sym_line_start: int | None) -> int | None:
    """First line containing any of the keywords (case-insensitive substring).

    Cheaper than regex; used for self-call detection in branching recursion.
    """
    if not snippet or sym_line_start is None:
        return sym_line_start
    lows = [k.lower() for k in keywords]
    for offset, line in enumerate(snippet.splitlines()):
        ll = line.lower()
        if any(k in ll for k in lows):
            return sym_line_start + offset
    return sym_line_start


def _row_value(row, key, default=None):
    """Safely read a sqlite row key with a fallback."""
    try:
        return row[key]
    except Exception:
        return default


def _json_list(value) -> list[str]:
    """Parse a JSON-encoded list of strings; return [] on malformed input."""
    if not value:
        return []
    try:
        data = json.loads(value)
    except Exception:
        return []
    if not isinstance(data, list):
        return []
    out: list[str] = []
    for item in data:
        if isinstance(item, str):
            out.append(item)
    return out


def _call_leaf(name: str) -> str:
    """Return the final method/function token from a qualified call name."""
    if not name:
        return ""
    return name.rsplit(".", 1)[-1]


def _dedupe(seq: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for s in seq:
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _read_symbol_source(path: str, line_start: int | None, line_end: int | None) -> str:
    """Best-effort source slice for a symbol location."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
    except OSError:
        return ""
    if line_start is None or line_end is None:
        return "\n".join(lines)
    ls = max(1, int(line_start))
    le = max(ls, int(line_end))
    return "\n".join(lines[ls - 1 : le])


def _iter_loop_calls(row) -> list[str]:
    """Return combined loop call names (leaf + qualified)."""
    calls = _json_list(_row_value(row, "calls_in_loops", ""))
    qcalls = _json_list(_row_value(row, "calls_in_loops_qualified", ""))
    return _dedupe(calls + qcalls)


def _call_in(calls: list[str], targets: set[str]) -> list[str]:
    """Match calls against targets by exact qualified name or leaf token."""
    hits: list[str] = []
    for c in calls:
        if c in targets or _call_leaf(c) in targets:
            hits.append(c)
    return _dedupe(hits)


_FRAMEWORK_IO_PACKS = {
    "python": [
        {
            "framework": "django-orm",
            "receiver_hints": {"objects", "queryset"},
            "leaves": {"get", "filter", "exclude", "all", "count", "exists"},
            "confidence": "high",
            "fix": ("Batch ORM fetches with `id__in` and add `select_related()/prefetch_related()`."),
        },
        {
            "framework": "sqlalchemy",
            "receiver_hints": {"session"},
            "leaves": {"execute", "query", "scalars", "get"},
            "confidence": "high",
            "fix": ("Use one `IN` query and eager loading (`selectinload`/`joinedload`) before the loop."),
        },
        {
            "framework": "python-http-client",
            "receiver_hints": {"requests", "httpx", "aiohttp", "client", "session"},
            "leaves": {"get", "post", "put", "delete", "patch", "request"},
            "confidence": "medium",
            "fix": "Use a bulk endpoint or bounded async batches (e.g., gather + semaphore).",
        },
    ],
    "ruby": [
        {
            "framework": "rails-active-record",
            "receiver_hints": {"activerecord", "relation", "model"},
            "leaves": {"find", "find_by", "where", "pluck"},
            "confidence": "high",
            "fix": "Preload associations with `.includes`/`.preload` and fetch in bulk.",
        },
    ],
    "php": [
        {
            "framework": "laravel-eloquent",
            "receiver_hints": {"db", "model", "eloquent", "query"},
            "leaves": {"find", "where", "first", "get", "value"},
            "confidence": "high",
            "fix": "Use `Model::whereIn(...)` or eager load with `with(...)`.",
        },
    ],
    "javascript": [
        {
            "framework": "node-orm",
            "receiver_hints": {"prisma", "sequelize", "knex", "db"},
            "leaves": {"findmany", "findunique", "findone", "query"},
            "confidence": "high",
            "fix": "Replace per-item ORM calls with one batched query.",
        },
        {
            "framework": "http-client",
            "receiver_hints": {"axios", "fetch", "http", "client"},
            "leaves": {"get", "post", "request"},
            "confidence": "medium",
            "fix": "Use a bulk endpoint or bounded parallel batch requests.",
        },
        {
            "framework": "graphql-client",
            "receiver_hints": {"graphql", "apollo", "urql", "client"},
            "leaves": {"query", "mutate", "request"},
            "confidence": "medium",
            "fix": "Batch GraphQL operations or use persisted/bulk queries.",
        },
    ],
    "typescript": [
        {
            "framework": "node-orm",
            "receiver_hints": {"prisma", "sequelize", "knex", "db"},
            "leaves": {"findmany", "findunique", "findone", "query"},
            "confidence": "high",
            "fix": "Replace per-item ORM calls with one batched query.",
        },
        {
            "framework": "http-client",
            "receiver_hints": {"axios", "fetch", "http", "client"},
            "leaves": {"get", "post", "request"},
            "confidence": "medium",
            "fix": "Use a bulk endpoint or bounded parallel batch requests.",
        },
        {
            "framework": "graphql-client",
            "receiver_hints": {"graphql", "apollo", "urql", "client"},
            "leaves": {"query", "mutate", "request"},
            "confidence": "medium",
            "fix": "Batch GraphQL operations or use persisted/bulk queries.",
        },
    ],
    "java": [
        {
            "framework": "jpa-hibernate",
            "receiver_hints": {"repository", "entitymanager", "jdbc", "template"},
            "leaves": {"findbyid", "findall", "query", "execute", "select"},
            "confidence": "high",
            "fix": ("Preload rows with one repository/JPA query (`IN (...)` + fetch join)."),
        },
    ],
}


def _framework_packs(language: str | None) -> list[dict]:
    if not language:
        return []
    return _FRAMEWORK_IO_PACKS.get(language.lower(), [])


_IO_GUARD_HINTS = {
    "python": {
        "select_related(",
        "prefetch_related(",
        "joinedload(",
        "selectinload(",
        "in_(",
        "__in",
        "executemany(",
    },
    "ruby": {
        ".includes(",
        ".preload(",
        ".eager_load(",
    },
    "php": {
        "->with(",
        "wherein(",
        "loadmissing(",
    },
    "javascript": {
        "findmany(",
        "include:",
        " in: ",
    },
    "typescript": {
        "findmany(",
        "include:",
        " in: ",
    },
    "java": {
        "join fetch",
        "findallbyid(",
        " in (",
    },
}


def _guard_hints_from_source(language: str | None, snippet: str) -> list[str]:
    if not language or not snippet:
        return []
    tokens = _IO_GUARD_HINTS.get((language or "").lower(), set())
    if not tokens:
        return []
    lower = snippet.lower()
    hits: list[str] = []
    for tok in tokens:
        if tok in lower:
            hits.append(tok)
    return _dedupe(hits)


# ---------------------------------------------------------------------------
# Individual detectors
# ---------------------------------------------------------------------------


def detect_manual_sort(conn: sqlite3.Connection) -> list[dict]:
    """Symbols named *sort* with nested loops, comparisons, and subscript
    access (swap pattern).  No call to built-in sort."""
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.has_nested_loops, ms.calls_in_loops, "
        "ms.loop_with_compare, ms.subscript_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%sort%' OR s.name LIKE '%Sort%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.has_nested_loops = 1 "
        "AND ms.loop_with_compare = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"sort", "sorted", "Arrays.sort", "Collections.sort", "qsort", "std::sort"}):
            continue
        # Subscript access in loops strengthens the signal (swap pattern)
        conf = "high" if r["subscript_in_loops"] else "medium"
        results.append(
            _finding(
                "sorting",
                "manual-sort",
                r,
                "Nested loops with comparisons in sort-named function",
                conf,
            )
        )
    return results


def detect_linear_search(conn: sqlite3.Connection) -> list[dict]:
    """Functions explicitly named *sorted*/*search_sorted* that loop with
    comparisons but don't call bisect/binarySearch.

    Downgraded to low confidence because we cannot verify from AST alone
    that the data being searched is actually sorted.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.loop_with_compare, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%search_sorted%' OR s.name LIKE '%searchSorted%' "
        "  OR s.name LIKE '%find_sorted%' OR s.name LIKE '%findSorted%' "
        "  OR s.name LIKE '%find_in_sorted%' OR s.name LIKE '%in_sorted%' "
        "  OR s.name LIKE '%linear_search%' OR s.name LIKE '%linearSearch%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND ms.loop_with_compare = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(
            calls,
            {
                "bisect",
                "bisect_left",
                "bisect_right",
                "binarySearch",
                "binary_search",
                "lower_bound",
                "upper_bound",
            },
        ):
            continue
        results.append(
            _finding(
                "search-sorted",
                "linear-scan",
                r,
                "Linear scan in function that implies sorted data",
                "low",
            )
        )
    return results


def detect_list_membership(conn: sqlite3.Connection) -> list[dict]:
    """Nested loops with equality comparisons β€” structural pattern for
    O(n^2) membership testing regardless of function name."""
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_with_compare, ms.subscript_in_loops, "
        "ms.has_nested_loops, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.has_nested_loops = 1 "
        "AND ms.loop_with_compare = 1 "
        "AND ms.subscript_in_loops = 1 "
        "AND (s.name LIKE '%contain%' OR s.name LIKE '%member%' "
        "  OR s.name LIKE '%exist%' OR s.name LIKE '%has_%' "
        "  OR s.name LIKE '%in_%' OR s.name LIKE '%check%' "
        "  OR s.name LIKE '%includes%' OR s.name LIKE '%Includes%')"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        results.append(
            _finding(
                "membership",
                "list-scan",
                r,
                "Nested loops with comparisons for membership check",
                "medium",
            )
        )
    return results


def detect_string_concat_loop(conn: sqlite3.Connection) -> list[dict]:
    """Loops with accumulation patterns and string-related call hints.

    Relies primarily on the structural pattern (loop + accumulator) combined
    with calls to string methods (append/concat) or string-building name hints.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.calls_in_loops, ms.loop_with_accumulator "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND ms.loop_with_accumulator = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        # Structural signal: calls to string concat/append methods
        has_concat_call = bool(_call_in(calls, {"concat", "strcat", "append", "push"}))
        # Name signal: function name suggests string building
        name_lower = (r["name"] or "").lower()
        has_name_hint = any(
            kw in name_lower
            for kw in (
                "concat",
                "build_str",
                "build_string",
                "format",
                "render",
                "serialize",
                "to_string",
                "tostring",
                "stringify",
                "to_csv",
                "to_html",
                "to_xml",
                "generate_report",
                "join",
            )
        )
        if has_concat_call or has_name_hint:
            results.append(
                _finding(
                    "string-concat",
                    "loop-concat",
                    r,
                    "Loop accumulation in string-building function",
                    "medium",
                )
            )
    return results


def detect_manual_dedup(conn: sqlite3.Connection) -> list[dict]:
    """Nested loops in dedup/unique-named functions without set usage."""
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.has_nested_loops, ms.loop_with_compare, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%dedup%' OR s.name LIKE '%unique%' "
        "  OR s.name LIKE '%Dedup%' OR s.name LIKE '%Unique%' "
        "  OR s.name LIKE '%distinct%' OR s.name LIKE '%Distinct%' "
        "  OR s.name LIKE '%remove_dup%' OR s.name LIKE '%removeDup%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.has_nested_loops = 1 "
        "AND ms.loop_with_compare = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Negative check: skip if they already use set/hash
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"set", "Set", "HashSet"}):
            continue
        results.append(
            _finding(
                "unique",
                "nested-dedup",
                r,
                "Nested loops with comparisons in dedup function",
                "high",
            )
        )
    return results


def detect_manual_maxmin(conn: sqlite3.Connection) -> list[dict]:
    """Loops with comparisons in max/min-named functions.

    Same Big-O (both O(n)) β€” this is an idiom improvement, flagged at low
    confidence.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.loop_with_compare, "
        "ms.loop_with_accumulator, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%find_max%' OR s.name LIKE '%find_min%' "
        "  OR s.name LIKE '%findMax%' OR s.name LIKE '%findMin%' "
        "  OR s.name LIKE '%get_max%' OR s.name LIKE '%get_min%' "
        "  OR s.name LIKE '%getMax%' OR s.name LIKE '%getMin%' "
        "  OR s.name LIKE '%find_largest%' OR s.name LIKE '%find_smallest%' "
        "  OR s.name LIKE '%findLargest%' OR s.name LIKE '%findSmallest%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND ms.loop_with_compare = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"max", "min", "Math.max", "Math.min", "Collections.max", "Collections.min"}):
            continue
        results.append(
            _finding(
                "max-min",
                "manual-loop",
                r,
                "Manual loop with comparisons in max/min function (idiomatic improvement)",
                "low",
            )
        )
    return results


def detect_manual_accumulation(conn: sqlite3.Connection) -> list[dict]:
    """Loops with accumulator in sum/total-named functions.

    Same Big-O (both O(n)) β€” idiom improvement, flagged at low confidence.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.loop_with_accumulator, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%_sum%' OR s.name LIKE '%_total%' "
        "  OR s.name LIKE '%Sum%' OR s.name LIKE '%Total%' "
        "  OR s.name LIKE '%accumulate%' OR s.name LIKE '%Accumulate%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND ms.loop_with_accumulator = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"sum", "reduce", "aggregate", "prod"}):
            continue
        results.append(
            _finding(
                "accumulation",
                "manual-sum",
                r,
                "Loop with accumulator in sum/total function (idiomatic improvement)",
                "low",
            )
        )
    return results


def detect_manual_power(conn: sqlite3.Connection) -> list[dict]:
    """Loop-based exponentiation in power/exponent-named functions."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.loop_with_multiplication, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%pow%' OR s.name LIKE '%Pow%' "
            "  OR s.name LIKE '%power%' OR s.name LIKE '%Power%' "
            "  OR s.name LIKE '%exp%' OR s.name LIKE '%Exponent%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1 "
            "AND ms.loop_with_multiplication = 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, 0 as loop_with_multiplication, "
            "ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%pow%' OR s.name LIKE '%Pow%' "
            "  OR s.name LIKE '%power%' OR s.name LIKE '%Power%' "
            "  OR s.name LIKE '%exp%' OR s.name LIKE '%Exponent%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1 "
            "AND ms.loop_with_accumulator = 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"pow", "Math.pow", "std::pow", "math.pow", "BigInteger.modPow"}):
            continue
        conf = "high" if _row_value(r, "loop_with_multiplication", 0) else "medium"
        results.append(
            _finding(
                "manual-power",
                "loop-multiply",
                r,
                "Loop multiplication used for exponentiation",
                conf,
            )
        )
    return results


def detect_manual_gcd(conn: sqlite3.Connection) -> list[dict]:
    """Manual GCD loops where built-in/standard helpers are available."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.loop_with_modulo, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%gcd%' OR s.name LIKE '%GCD%' "
            "  OR s.name LIKE '%hcf%' OR s.name LIKE '%gcf%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, 0 as loop_with_modulo, "
            "ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%gcd%' OR s.name LIKE '%GCD%' "
            "  OR s.name LIKE '%hcf%' OR s.name LIKE '%gcf%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"gcd", "math.gcd", "std::gcd", "BigInteger.gcd"}):
            continue
        conf = "medium"
        if _row_value(r, "loop_with_modulo", 0):
            conf = "high"
        results.append(
            _finding(
                "manual-gcd",
                "manual-gcd",
                r,
                "Manual GCD loop can be replaced with standard gcd helper",
                conf,
            )
        )
    return results


def detect_string_reverse(conn: sqlite3.Connection) -> list[dict]:
    """Manual reversal loops in reverse-named functions."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.loop_with_accumulator, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%reverse%' OR s.name LIKE '%Reverse%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.loop_with_accumulator, "
            "ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%reverse%' OR s.name LIKE '%Reverse%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"reverse", "reversed", "std::reverse", "StringBuilder.reverse", "strrev"}):
            continue
        results.append(
            _finding(
                "string-reverse",
                "manual-reverse",
                r,
                "Manual character-loop reversal in reverse-named function",
                "low",
            )
        )
    return results


def detect_matrix_mult(conn: sqlite3.Connection) -> list[dict]:
    """Naive triple-loop matrix multiplication patterns."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.subscript_in_loops, "
            "ms.loop_with_multiplication, ms.loop_with_accumulator, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%matrix%' OR s.name LIKE '%matmul%' "
            "  OR s.name LIKE '%multiply_matrix%' OR s.name LIKE '%dot%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 3 "
            "AND ms.subscript_in_loops = 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.subscript_in_loops, "
            "0 as loop_with_multiplication, ms.loop_with_accumulator, "
            "ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%matrix%' OR s.name LIKE '%matmul%' "
            "  OR s.name LIKE '%multiply_matrix%' OR s.name LIKE '%dot%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 3 "
            "AND ms.subscript_in_loops = 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"dot", "matmul", "gemm", "dgemm", "numpy.dot", "np.matmul"}):
            continue
        conf = (
            "high"
            if (_row_value(r, "loop_with_multiplication", 0) and _row_value(r, "loop_with_accumulator", 0))
            else "medium"
        )
        results.append(
            _finding(
                "matrix-mult",
                "naive-triple",
                r,
                "Naive matrix multiplication via nested loops",
                conf,
            )
        )
    return results


def detect_naive_fibonacci(conn: sqlite3.Connection) -> list[dict]:
    """Recursive functions named *fib* without memoization.

    O(2^n) -> O(n) β€” one of the strongest algorithmic improvements.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.has_self_call "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%fib%' OR s.name LIKE '%Fib%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.has_self_call >= 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Check if there's a memoization decorator (edge to lru_cache/cache)
        memo_edge = conn.execute(
            "SELECT 1 FROM edges e "
            "JOIN symbols t ON e.target_id = t.id "
            "WHERE e.source_id = ? "
            "AND t.name IN ('lru_cache', 'cache', 'memoize', 'memo', "
            "               'functools.lru_cache', 'functools.cache') "
            "LIMIT 1",
            (r["id"],),
        ).fetchone()
        if memo_edge:
            continue
        results.append(
            _finding(
                "fibonacci",
                "naive-recursive",
                r,
                "Recursive fibonacci without memoization (exponential blowup)",
                "high",
            )
        )
    return results


def detect_nested_lookup(conn: sqlite3.Connection) -> list[dict]:
    """Nested loops with subscript access and comparisons β€” O(n*m) lookup.

    Suppresses known false positives: grid/matrix traversal (name hints),
    and requires both nested loops AND comparisons (not just nested loops
    with subscript access, which could be matrix operations).
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.has_nested_loops, ms.subscript_in_loops, "
        "ms.loop_with_compare "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "JOIN symbol_metrics sm ON sm.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.has_nested_loops = 1 "
        "AND ms.subscript_in_loops = 1 "
        "AND ms.loop_with_compare = 1 "
        "AND sm.cognitive_complexity >= 8"
    ).fetchall()

    # Names that suggest grid/matrix traversal (suppress these)
    _GRID_NAMES = {
        "matrix",
        "grid",
        "board",
        "pixel",
        "cell",
        "permut",
        "combin",
        "cartesian",
        "product",
        "transpose",
        "rotate",
        "convolv",
    }

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Suppress grid/matrix traversal patterns
        name_lower = (r["name"] or "").lower()
        if any(kw in name_lower for kw in _GRID_NAMES):
            continue
        results.append(
            _finding(
                "nested-lookup",
                "nested-iteration",
                r,
                "Nested loops with subscript access and comparisons (potential O(n*m))",
                "medium",
            )
        )
    return results


def detect_manual_groupby(conn: sqlite3.Connection) -> list[dict]:
    """Loops in group/categorize-named functions without defaultdict/groupby.

    Same Big-O (both O(n)) β€” idiom improvement.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.loop_with_accumulator, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%group%' OR s.name LIKE '%Group%' "
        "  OR s.name LIKE '%bucket%' OR s.name LIKE '%Bucket%' "
        "  OR s.name LIKE '%partition%' OR s.name LIKE '%Partition%' "
        "  OR s.name LIKE '%categorize%' OR s.name LIKE '%Categorize%' "
        "  OR s.name LIKE '%classify%' OR s.name LIKE '%Classify%' "
        "  OR s.name LIKE '%bin_by%' OR s.name LIKE '%key_by%' "
        "  OR s.name LIKE '%index_by%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"groupby", "group_by", "defaultdict", "setdefault", "groupingBy", "Collectors"}):
            continue
        results.append(
            _finding(
                "groupby",
                "manual-check",
                r,
                "Manual loop in group-by function (idiomatic improvement)",
                "low",
            )
        )
    return results


def detect_busy_wait(conn: sqlite3.Connection) -> list[dict]:
    """Loops that call sleep β€” polling / busy-wait pattern.

    Suppresses intentional polling: functions named *poll*, *retry*,
    *health_check*, *monitor*, *wait_for* β€” these are legitimate patterns.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1"
    ).fetchall()

    # Intentional polling patterns β€” suppress these
    _POLL_NAMES = {
        "poll",
        "retry",
        "health_check",
        "healthcheck",
        "monitor",
        "wait_for",
        "wait_until",
        "watchdog",
        "ping",
        "heartbeat",
        "keepalive",
        "backoff",
    }

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if not _call_in(calls, {"sleep", "time.sleep", "Thread.sleep", "usleep", "nanosleep", "Sleep"}):
            continue
        # Suppress intentional polling
        name_lower = (r["name"] or "").lower()
        if any(kw in name_lower for kw in _POLL_NAMES):
            continue
        results.append(
            _finding(
                "busy-wait",
                "sleep-loop",
                r,
                "sleep() called inside a loop (busy-wait pattern)",
                "high",
            )
        )
    return results


# ---------------------------------------------------------------------------
# New detectors: patterns identified by research
# ---------------------------------------------------------------------------


def detect_regex_in_loop(conn: sqlite3.Connection) -> list[dict]:
    """Regex compilation inside a loop β€” recompiles on every iteration.

    O(n*p) wasted compilation when O(p + n*m) is achievable by compiling
    once outside the loop.  Applies to all languages with regex engines.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1"
    ).fetchall()

    # Note: call target names are extracted as the last identifier in
    # member expressions (e.g. re.compile -> "compile", re.match -> "match")
    _REGEX_COMPILE_CALLS = {"compile", "Compile", "MustCompile"}
    _REGEX_CONVENIENCE_CALLS = {
        "match",
        "search",
        "findall",
        "sub",
        "split",
        "fullmatch",
        "finditer",
        "matches",
        "Replace",
        "ReplaceAll",
        "Find",
        "FindAll",
        "MatchString",
    }

    # Module-level regex prefixes β€” calls like `re.match()` recompile each time,
    # but `compiled_pattern.match()` does not.  Only flag the former.
    _REGEX_MODULE_PREFIXES = {"re.", "regexp.", "regex.", "Pattern."}

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        # Direct compile in loop is always bad
        compile_calls = _call_in(calls, _REGEX_COMPILE_CALLS)
        # Convenience regex calls β€” only flag when called via the regex module
        # (e.g. `re.findall`), NOT when called on a pre-compiled pattern object
        # (e.g. `_MY_RE.findall`).  Check qualified names for module prefix.
        qcalls = _json_list(_row_value(r, "calls_in_loops_qualified", ""))
        module_convenience = [
            c
            for c in qcalls
            if any(c.startswith(prefix) for prefix in _REGEX_MODULE_PREFIXES)
            and _call_leaf(c) in _REGEX_CONVENIENCE_CALLS
        ]
        if compile_calls:
            results.append(
                _finding(
                    "regex-in-loop",
                    "compile-per-iter",
                    r,
                    f"Regex compile ({', '.join(compile_calls[:2])}) inside loop",
                    "high",
                )
            )
        elif module_convenience:
            results.append(
                _finding(
                    "regex-in-loop",
                    "compile-per-iter",
                    r,
                    f"Regex call ({', '.join(module_convenience[:2])}) inside loop (recompiles per iteration)",
                    "high",
                )
            )
    return results


_IO_HIGH_EXACT = {
    "requests.get",
    "requests.post",
    "requests.put",
    "requests.delete",
    "requests.patch",
    "urllib.request.urlopen",
    "session.execute",
    "session.query",
    "cursor.execute",
    "http.Get",
    "http.Post",
}
_IO_HIGH_EXACT_LOWER = {c.lower() for c in _IO_HIGH_EXACT}
_IO_HIGH_LEAF = {"execute", "executemany", "query", "urlopen"}
_IO_AMBIGUOUS_BARE = {"query", "find", "get"}
_IO_MEDIUM_LEAF = {"fetchone", "fetchall", "fetchmany", "fetch", "find", "get", "open"}
_IO_RECEIVER_HINTS = {
    "session",
    "cursor",
    "db",
    "conn",
    "connection",
    "repo",
    "repository",
    "queryset",
    "client",
    "api",
    "http",
    "requests",
    "urllib",
}
# M3 expansion: when a call is IN this set OR matches one of the IN_MEMORY_LEAVES
# attached to a recognised receiver, treat as an in-memory cache read NOT I/O.
# Real-world FP that drove the expansion: roam math flagged
# `queryClient.getQueryData` inside a TanStack Query factory as N+1
# round-trips when those are sync cache reads.
_IN_MEMORY_EXACT = {
    "queryclient.setquerydata",
    "queryclient.getquerydata",
    "queryclient.getqueriesdata",
    "queryclient.setqueriesdata",
    "queryclient.invalidatequeries",
    "queryclient.removequeries",
    "queryclient.cancelqueries",
    "queryclient.refetchqueries",
    "qc.setquerydata",
    "qc.getquerydata",
    "qc.getqueriesdata",
    "qc.setqueriesdata",
    "qc.invalidatequeries",
    "redux.dispatch",
    "store.dispatch",
    # SWR + RTK Query + Apollo cache equivalents
    "mutate",  # SWR's mutate() (cache-only)
    "cache.read",
    "cache.write",
    "cache.evict",
    "cache.modify",  # Apollo
    "client.readquery",  # Apollo
    "client.writequery",  # Apollo
    "client.cache.evict",  # Apollo
}
_IN_MEMORY_LEAVES = {
    "setquerydata",
    "getquerydata",
    "setqueriesdata",
    "getqueriesdata",
    "invalidatequeries",
    "removequeries",
    "cancelqueries",
    "refetchqueries",
    "dispatch",
    "setstate",
    # M3 — generic Map/Set/WeakMap operations are NOT I/O even in loops.
    # Without these, `mapInst.get(k)` inside a loop falsely fires as N+1.
    "has",
    "set",
    "delete",
    "clear",
    "peek",
    # SWR + Apollo
    "readquery",
    "writequery",
    "writefragment",
    "readfragment",
    "evict",
    "modify",
}
_IN_MEMORY_RECEIVER_HINTS = {
    "queryclient",
    "qc",
    "store",
    "redux",
    "cache",
    "state",
    "router",
    # M3 expansion: more cache-library + native-collection receivers
    "map",
    "set",
    "weakmap",
    "weakset",
    "dict",
    "lookup",
    "registry",
    "client",  # Apollo client.cache.evict
    "session",
    "pinia",  # Vue 3 store
}
_IO_WRAPPER_NAMES = {
    "batch",
    "bulk",
    "migrate",
    "seed",
    "import",
    "export",
    "sync_all",
    "backfill",
}


def _io_receiver_hint(call: str) -> str:
    if "." not in call:
        return ""
    return call.rsplit(".", 1)[0].lower()


def _io_receiver_is_ioish(call: str) -> bool:
    recv = _io_receiver_hint(call)
    if not recv:
        return False
    return any(h in recv for h in _IO_RECEIVER_HINTS)


def _io_is_known_in_memory_call(call: str) -> bool:
    lower_c = call.lower()
    leaf = _call_leaf(lower_c)
    recv = _io_receiver_hint(lower_c)
    if lower_c in _IN_MEMORY_EXACT:
        return True
    if leaf in _IN_MEMORY_LEAVES and any(h in recv for h in _IN_MEMORY_RECEIVER_HINTS):
        return True
    return False


def _io_match_framework_pack(call: str, language: str | None) -> dict | None:
    leaf = _call_leaf(call).lower()
    recv = _io_receiver_hint(call)
    lower_c = call.lower()
    for pack in _framework_packs(language):
        leaves = {str(v).lower() for v in pack.get("leaves", set())}
        recv_hints = {str(v).lower() for v in pack.get("receiver_hints", set())}
        if lower_c in {c.lower() for c in pack.get("exact", set())}:
            return pack
        if leaf not in leaves:
            continue
        if not recv_hints:
            return pack
        if any(h in recv for h in recv_hints):
            return pack
    return None


def _io_classify_call(c: str, language: str | None, conn, r) -> tuple[str | None, dict | None]:
    """Classify a single call inside a loop.

    Returns ``(level, framework_pack)`` where level is ``"high"``,
    ``"medium"``, ``"ambiguous"``, or None for in-memory / local-helper /
    non-I/O calls.
    """
    if _io_is_known_in_memory_call(c):
        return None, None
    pack = _io_match_framework_pack(c, language)
    if pack:
        if pack.get("confidence") == "high":
            return "high", pack
        return "medium", pack

    lower_c = c.lower()
    leaf = _call_leaf(c).lower()
    if lower_c in _IO_HIGH_EXACT_LOWER:
        return "high", None
    if leaf in _IO_HIGH_LEAF and _io_receiver_is_ioish(c):
        return "high", None
    if leaf in {"get", "post", "put", "delete", "patch", "request"}:
        recv = _io_receiver_hint(c)
        if "requests" in recv or recv.endswith("http"):
            return "high", None
    if leaf in _IO_MEDIUM_LEAF and _io_receiver_is_ioish(c):
        return "medium", None
    if "." not in c and leaf in _IO_AMBIGUOUS_BARE:
        local_helper = conn.execute(
            "SELECT 1 FROM edges e "
            "JOIN symbols t ON e.target_id = t.id "
            "WHERE e.source_id = ? "
            "AND lower(t.name) = ? "
            "AND t.file_id = ? "
            "LIMIT 1",
            (r["id"], leaf, r["file_id"]),
        ).fetchone()
        if local_helper:
            return None, None
        return "ambiguous", None
    if leaf == "open":
        return "medium", None
    return None, None


def _io_emit_finding(
    level: str,
    high_calls: list[str],
    medium_calls: list[str],
    ambiguous_calls: list[str],
    frameworks: set[str],
    fixes: set[str],
    guard_hints: list[str],
    guard_applies: bool,
    evidence_io_calls: list[str],
    r,
    *,
    dev_gated: bool = False,
    match_line: int | None = None,
    snippet: str | None = None,
) -> dict:
    """Build the finding dict for one of high/medium/ambiguous result branches.

    M1 (match_line): pin location at the first I/O call site in the snippet
    rather than the function declaration.
    M4 (dev_gated): note when the body sits inside a DEV gate.
    M6 (suppress hint): every emitted finding carries `to_suppress` evidence.
    """
    fix_text = "; ".join(sorted(fixes)) if fixes else None
    # M1: try to find the line of the first I/O call inside the snippet.
    derived_match_line = match_line
    if derived_match_line is None and snippet and (high_calls or medium_calls or ambiguous_calls):
        first_call = (high_calls + medium_calls + ambiguous_calls)[0]
        leaf = _call_leaf(first_call) or first_call
        # Use a loose substring match — call shapes vary across extractors.
        if leaf:
            for offset, line in enumerate(snippet.splitlines()):
                if leaf in line:
                    derived_match_line = (r["line_start"] or 0) + offset
                    break
    common_evidence_extras = {}
    if dev_gated:
        common_evidence_extras["dev_gated"] = True
        common_evidence_extras["dev_gated_note"] = (
            "loop body sits inside a DEV-only conditional (import.meta.env.DEV / __DEV__ / "
            "process.env.NODE_ENV); production-stripped, so the N+1 cost is not paid in prod"
        )
    suppress_hint = (
        "wrap the loop in a batch/eager guard (e.g. `with()` or `map()`+`Promise.all`), OR "
        "add `# roam: ignore-math[io-in-loop]` on the function line if the call is intentional"
    )
    if level == "high":
        reason_calls = _dedupe(high_calls)[:2]
        reason_suffix = f"; frameworks: {', '.join(sorted(frameworks))}" if frameworks else ""
        confidence = "high"
        if guard_applies:
            confidence = _lower_confidence(confidence)
            reason_suffix += f"; eager/batch guards: {', '.join(guard_hints[:2])}"
        return _finding(
            "io-in-loop",
            "loop-query",
            r,
            f"I/O call ({', '.join(reason_calls)}) inside loop (N+1 pattern){reason_suffix}",
            confidence,
            evidence={
                "io_calls": evidence_io_calls,
                "frameworks": sorted(frameworks),
                "guard_hints": guard_hints,
                "to_suppress": suppress_hint,
                **common_evidence_extras,
            },
            fix=fix_text,
            match_line=derived_match_line,
        )
    if level == "medium":
        reason_calls = _dedupe(medium_calls)[:2]
        reason_suffix = f"; frameworks: {', '.join(sorted(frameworks))}" if frameworks else ""
        confidence = "medium"
        if guard_applies:
            confidence = _lower_confidence(confidence)
            reason_suffix += f"; eager/batch guards: {', '.join(guard_hints[:2])}"
        return _finding(
            "io-in-loop",
            "loop-query",
            r,
            f"I/O-like call ({', '.join(reason_calls)}) inside loop (may be N+1){reason_suffix}",
            confidence,
            evidence={
                "io_calls": evidence_io_calls,
                "frameworks": sorted(frameworks),
                "guard_hints": guard_hints,
                "to_suppress": suppress_hint,
                **common_evidence_extras,
            },
            fix=fix_text,
            match_line=derived_match_line,
        )
    # Ambiguous bare calls (get/find/query) — weak evidence, low confidence.
    reason_calls = _dedupe(ambiguous_calls)[:2]
    finding = _finding(
        "io-in-loop",
        "loop-query",
        r,
        f"Ambiguous bare call ({', '.join(reason_calls)}) inside loop (possible I/O, review manually)",
        "low",
        evidence={
            "io_calls": evidence_io_calls,
            "ambiguous_io_calls": _dedupe(ambiguous_calls)[:4],
            "ambiguous_io_only": True,
            "frameworks": sorted(frameworks),
            "guard_hints": guard_hints,
            "to_suppress": suppress_hint,
            **common_evidence_extras,
        },
        fix=fix_text,
        match_line=derived_match_line,
    )
    finding["precision"] = "low"
    return finding


def detect_io_in_loop(conn: sqlite3.Connection) -> list[dict]:
    """Database query, HTTP request, or file I/O inside a loop β€” N+1 pattern.

    One of the most impactful performance anti-patterns in web applications.
    Each iteration incurs a full I/O round trip.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.file_id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "f.language as language, s.line_start, s.line_end, ms.loop_depth, ms.calls_in_loops, "
            "ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.file_id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "f.language as language, s.line_start, s.line_end, ms.loop_depth, ms.calls_in_loops, "
            "'' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        language = _row_value(r, "language", "")
        snippet = _read_symbol_source(
            r["file_path"],
            _row_value(r, "line_start", None),
            _row_value(r, "line_end", None),
        )
        guard_hints = _guard_hints_from_source(language, snippet)
        calls = _iter_loop_calls(r)
        if not calls:
            continue

        high_calls: list[str] = []
        medium_calls: list[str] = []
        ambiguous_calls: list[str] = []
        frameworks: set[str] = set()
        fixes: set[str] = set()
        for c in calls:
            level, pack = _io_classify_call(c, language, conn, r)
            if pack:
                frameworks.add(pack["framework"])
                if pack.get("fix"):
                    fixes.add(pack["fix"])
            if level == "high":
                high_calls.append(c)
            elif level == "medium":
                medium_calls.append(c)
            elif level == "ambiguous":
                ambiguous_calls.append(c)

        if not high_calls and not medium_calls and not ambiguous_calls:
            continue

        name_lower = (r["name"] or "").lower()
        if any(kw in name_lower for kw in _IO_WRAPPER_NAMES):
            continue

        # M4: skip DEV-gated bodies — production stripped, so loop overhead
        # is irrelevant. (Conservative: only skip when the gate is *literally*
        # in this function's body.)
        dev_gated = _is_dev_only_block(snippet)
        guard_applies = bool(frameworks and guard_hints)
        evidence_io_calls = _dedupe(high_calls + medium_calls + ambiguous_calls)[:6]
        if high_calls:
            level = "high"
        elif medium_calls:
            level = "medium"
        else:
            level = "ambiguous"
        if dev_gated:
            # Don't drop entirely — a real production-bound issue could still
            # exist outside the gate. But demote two tiers so it sinks to the
            # bottom of the verdict list.
            if level == "high":
                level = "medium"
            elif level == "medium":
                level = "ambiguous"
        results.append(
            _io_emit_finding(
                level,
                high_calls,
                medium_calls,
                ambiguous_calls,
                frameworks,
                fixes,
                guard_hints,
                guard_applies,
                evidence_io_calls,
                r,
                dev_gated=dev_gated,
                snippet=snippet,
            )
        )
    return results


def detect_list_prepend(conn: sqlite3.Connection) -> list[dict]:
    """insert(0, x), unshift(), or pop(0) inside a loop β€” O(n) per op
    due to array shifting, O(n^2) total."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.front_ops_in_loop, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.front_ops_in_loop = 1"
        ).fetchall()
    except Exception:
        # Fallback for older indexes without front_ops_in_loop.
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    # deque operations are O(1) β€” suppress when popleft/appendleft are the ops
    _DEQUE_OPS = {"popleft", "appendleft", "extendleft"}

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        # If the only front-ops are deque methods, this is already optimal
        front_calls = _call_in(calls, {"insert", "unshift", "shift", "popleft", "appendleft", "extendleft"})
        if front_calls and all(_call_leaf(c) in _DEQUE_OPS for c in front_calls):
            continue  # Already using deque β€” no issue
        # New indexes precompute the exact front-op signal.
        if _row_value(r, "front_ops_in_loop", None) == 1:
            results.append(
                _finding(
                    "list-prepend",
                    "insert-front",
                    r,
                    "Front insert/remove inside loop (O(n) shift per operation)",
                    "high",
                )
            )
            continue
        # Fallback heuristic (conservative): only list front APIs.
        # Note: appendleft/popleft are deque O(1) ops β€” do NOT flag those.
        if _call_in(calls, {"insert", "unshift", "shift"}):
            results.append(
                _finding(
                    "list-prepend",
                    "insert-front",
                    r,
                    "Potential front insert/remove inside loop",
                    "medium",
                )
            )
    return results


def detect_sort_to_select(conn: sqlite3.Connection) -> list[dict]:
    """Calling sort on a collection and then only using the first/last element.

    O(n log n) sort when min()/max() is O(n), or heapq.nsmallest is O(n log k).
    Detection: function calls sort AND has subscript access, but does NOT
    iterate the full sorted result.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, s.line_end "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "WHERE s.kind IN ('function', 'method')"
    ).fetchall()

    sorted_index_re = re.compile(r"\bsorted\s*\([^)]*\)\s*\[\s*(?:-?\d+|:\s*[^]\n]+)\s*\]")
    inplace_sort_index_re = re.compile(
        r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\.\s*sort\s*\([^)]*\).*?"
        r"\b\1\s*\[\s*(?:-?\d+|:\s*[^]\n]+)\s*\]",
        re.DOTALL,
    )
    generic_sort_index_re = re.compile(
        r"\bsort(?:ed)?\s*\([^)]*\).*?\[\s*(?:-?\d+|:\s*[^]\n]+)\s*\]",
        re.DOTALL,
    )
    # M1: per-line sort detector for pinpointing the match line
    sort_call_line_re = re.compile(r"\bsort(?:ed)?\s*\(")

    # M5 — fallback false-positive guard. Skip when the sort result is also
    # iterated/returned in full (sorted then map/forEach/return — display order,
    # not a min/max selection).
    # The check is conservative: if we see ANY iteration of the sort target
    # alongside the index access, demote the finding rather than skip outright.
    iteration_after_sort_re = re.compile(r"\bsort(?:ed)?\s*\(.*?\b(map|forEach|filter|reduce|return)\b", re.DOTALL)

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet:
            continue

        match_line = _find_match_line(snippet, sort_call_line_re, r["line_start"])
        sort_iterated = bool(iteration_after_sort_re.search(snippet))

        # Strong patterns: sorted(...)[0], sorted(... )[:k], arr.sort(); arr[0]
        if sorted_index_re.search(snippet) or inplace_sort_index_re.search(snippet):
            # M5: when the sort result is also iterated, downgrade — the
            # subscript may be incidental (e.g. logging the first item of a
            # display-ordered list).
            confidence = "medium" if sort_iterated else "high"
            reason = "Sort used only for first/last/top-k selection"
            if sort_iterated:
                reason += " (note: result is also iterated — may be incidental subscript)"
            results.append(
                _finding(
                    "sort-to-select",
                    "full-sort",
                    r,
                    reason,
                    confidence,
                    match_line=match_line,
                )
            )
            continue

        # Fallback pattern for other languages (sort(...) then index/slice).
        if generic_sort_index_re.search(snippet):
            confidence = "low" if sort_iterated else "medium"
            reason = "Potential full sort followed by index/slice selection"
            if sort_iterated:
                reason += " (note: result is also iterated — may be incidental subscript)"
            results.append(
                _finding(
                    "sort-to-select",
                    "full-sort",
                    r,
                    reason,
                    confidence,
                    match_line=match_line,
                )
            )
    return results


def detect_loop_lookup(conn: sqlite3.Connection) -> list[dict]:
    """.index(), .indexOf(), .contains(), .includes() called inside a loop.

    Each call is O(m) linear scan on the lookup collection, total O(n*m).
    Pre-building a set gives O(1) per lookup, O(n+m) total.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_lookup_calls, ms.calls_in_loops, "
            "ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, '' as loop_lookup_calls, ms.calls_in_loops, "
            "'' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    _LOOKUP_CALLS = {
        "index",
        "indexOf",
        "lastIndexOf",
        "contains",
        "includes",
        "Contains",
        "IndexOf",
    }

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        lookup_calls = _json_list(_row_value(r, "loop_lookup_calls", ""))
        if lookup_calls:
            results.append(
                _finding(
                    "loop-lookup",
                    "method-scan",
                    r,
                    f"Linear lookup ({', '.join(lookup_calls[:2])}) called on invariant collection",
                    "high",
                )
            )
            continue
        # Fallback for older indexes: conservative matching only.
        calls = _iter_loop_calls(r)
        fallback_hits = _call_in(calls, _LOOKUP_CALLS)
        if fallback_hits:
            results.append(
                _finding(
                    "loop-lookup",
                    "method-scan",
                    r,
                    f"Linear lookup ({', '.join(fallback_hits[:2])}) called inside loop",
                    "low",
                )
            )
    return results


# ---------------------------------------------------------------------------
# Tier 2 detectors: enhanced signals
# ---------------------------------------------------------------------------


def detect_branching_recursion(conn: sqlite3.Connection) -> list[dict]:
    """Functions with 2+ self-call sites and no memoization.

    Generalizes fibonacci to any branching recursion: tree traversals,
    divide-and-conquer, DP problems.  O(2^n) -> O(n) with memoization.
    """
    # self_call_count column may not exist in older DBs β€” fall back safely
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "f.language as language, s.line_start, s.line_end, ms.self_call_count "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.self_call_count >= 2"
        ).fetchall()
    except Exception:
        return []

    results = []

    # M2 fix: detect the SECOND form of depth guard — early-return when
    # depth EXCEEDS limit ("if depth > 10 return"). The original regex only
    # recognised "depth < limit ⇒ continue" patterns; the negation form was
    # silently mis-flagged as O(2^n). Real-world FP: deepEqual flagged
    # despite line+2 having `if (depth > 10) return false`.
    def _has_explicit_depth_guard(language: str | None, snippet: str) -> bool:
        """Return True for bounded-recursion guards that cap traversal depth."""
        if not snippet:
            return False
        # JS/TS: path.split('.').length < 5
        if re.search(r"\.split\s*\([^)]*\)\s*\.\s*length\s*(?:<|<=)\s*\d+", snippet):
            return True
        # Python: len(path.split(".")) < 5
        if re.search(r"len\s*\(\s*[^)]*\.split\s*\([^)]*\)\s*\)\s*(?:<|<=)\s*\d+", snippet):
            return True
        # Form 1: continue if depth/level/budget BELOW limit.
        # Common explicit counters: depth < maxDepth, level <= 4, etc.
        if re.search(
            r"\b(?:depth|level|budget|remaining|hops|currentDepth|current_depth|max_depth|maxDepth)\b"
            r"\s*(?:<|<=)\s*(?:\d+|maxDepth|max_depth|MAX_DEPTH|max_recursion|MAX_RECURSION)",
            snippet,
        ):
            return True
        # M2 — Form 2: early-return if depth/level/budget EXCEEDS limit.
        # Matches `if (depth > 10) return ...`, `if (level >= MAX_DEPTH) raise`,
        # `if (budget < 1) return`, `if (--budget <= 0) return`.
        # Generous on the "return / raise / throw / break" side since
        # short-circuit-and-bail is the universal early-exit shape.
        if re.search(
            r"\b(?:depth|level|budget|remaining|hops|recursion_count|recursionDepth)\b"
            r"\s*(?:>|>=|<|<=)\s*(?:\d+|maxDepth|max_depth|MAX_DEPTH|max_recursion|MAX_RECURSION|0)\s*\)?\s*"
            r"\s*[:{]?\s*(?:return|raise|throw|break)",
            snippet,
        ):
            return True
        # Decrement-then-check: `if (--budget <= 0) return`
        if re.search(
            r"--?\s*\b(?:depth|budget|remaining|hops)\b\s*[<>]=?\s*\d+\s*\)?\s*[:{]?\s*"
            r"(?:return|raise|throw|break)",
            snippet,
        ):
            return True
        if (
            language
            and language.lower() in {"javascript", "typescript"}
            and re.search(
                r"\b(?:maxDepth|max_depth)\b\s*(?:>|>=)\s*\b(?:depth|level|currentDepth|current_depth)\b",
                snippet,
            )
        ):
            return True
        return False

    # M2 — Set/Map/WeakSet/WeakMap parameter or local: signals the function
    # already implements its own memoization / cycle-tracking, so the
    # branching-recursion warning would be a FP.
    def _has_memo_collection(snippet: str) -> bool:
        if not snippet:
            return False
        if re.search(r"\b(?:Set|Map|WeakSet|WeakMap)\s*<", snippet):  # TS generic
            return True
        if re.search(r"\bnew\s+(?:Set|Map|WeakSet|WeakMap)\b", snippet):  # JS literal
            return True
        if re.search(r"\b(?:visited|seen|memo|cache|memoised|memoized)\b\s*[:=]", snippet):
            return True
        if re.search(r"@(?:lru_cache|cache|memoize|memoise|functools\.lru_cache)\b", snippet):
            return True
        return False

    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Skip fibonacci β€” already covered by detect_naive_fibonacci
        name_lower = (r["name"] or "").lower()
        if "fib" in name_lower:
            continue
        # Skip tree/AST walkers β€” recursive traversal of children is
        # intentional and doesn't have overlapping subproblems
        _WALKER_NAMES = {
            "walk",
            "visit",
            "traverse",
            "search",
            "scan",
            "crawl",
            "descend",
            "recurse",
            "dfs",
            "bfs",
        }
        if any(kw in name_lower for kw in _WALKER_NAMES):
            continue
        # Check for memoization edge
        memo_edge = conn.execute(
            "SELECT 1 FROM edges e "
            "JOIN symbols t ON e.target_id = t.id "
            "WHERE e.source_id = ? "
            "AND t.name IN ('lru_cache', 'cache', 'memoize', 'memo', "
            "               'functools.lru_cache', 'functools.cache') "
            "LIMIT 1",
            (r["id"],),
        ).fetchone()
        if memo_edge:
            continue
        snippet = _read_symbol_source(
            r["file_path"],
            _row_value(r, "line_start", None),
            _row_value(r, "line_end", None),
        )
        if _has_explicit_depth_guard(_row_value(r, "language", ""), snippet):
            continue
        if _has_memo_collection(snippet):
            # M2: function carries its own Set/Map/WeakSet — already memoised.
            continue
        # M1: pin the location at the first self-call line if we can find it,
        # not the function declaration. The detector flagged because
        # self_call_count >= 2; the first occurrence of `name(` (or shorthand
        # `name(`) inside the body is the most informative anchor.
        match_line = _find_first_keyword_line(snippet, (r["name"] + "(",), r["line_start"])
        results.append(
            _finding(
                "branching-recursion",
                "naive-branching",
                r,
                f"Branching recursion ({r['self_call_count']} self-calls) without memoization",
                "high",
                evidence={
                    "self_call_count": r["self_call_count"],
                    "guard_check": "no depth/budget guard found in body, no memo Set/Map detected",
                    "to_suppress": (
                        "add `if (depth > N) return` early-return guard, OR pass a "
                        "Set/Map/WeakSet for memoisation/cycle-tracking, OR add "
                        "`# roam: ignore-math[branching-recursion]` to the function line"
                    ),
                },
                match_line=match_line,
            )
        )
    return results


def detect_quadratic_string(conn: sqlite3.Connection) -> list[dict]:
    """String concatenation via += inside a loop β€” O(n^2) due to
    immutable string reallocation in Python/Java/Go.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.str_concat_in_loop "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.str_concat_in_loop = 1"
        ).fetchall()
    except Exception:
        return []

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        results.append(
            _finding(
                "quadratic-string",
                "augment-concat",
                r,
                "String += in loop (O(n^2) due to immutable reallocation)",
                "high",
            )
        )
    return results


def detect_loop_invariant_call(conn: sqlite3.Connection) -> list[dict]:
    """Calls inside loops whose arguments don't reference the loop variable.

    These can be hoisted before the loop to avoid repeated computation.
    Suppresses common intentional per-iteration calls (logging, metrics, etc.).
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_invariant_calls "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_invariant_calls IS NOT NULL "
            "AND ms.loop_invariant_calls != '[]'"
        ).fetchall()
    except Exception:
        return []

    # Calls that are intentionally per-iteration (suppress)
    _INTENTIONAL_CALLS = {
        # Logging / output
        "print",
        "log",
        "debug",
        "info",
        "warn",
        "warning",
        "error",
        # Collection mutation
        "append",
        "add",
        "push",
        "extend",
        "write",
        "send",
        "get",
        "values",
        "items",
        "keys",
        "update",
        "pop",
        "remove",
        "insert",
        "setdefault",
        "discard",
        # String methods (inherently per-item)
        "startswith",
        "endswith",
        "replace",
        "format",
        "strip",
        "split",
        "join",
        "lower",
        "upper",
        "lstrip",
        "rstrip",
        "encode",
        "decode",
        "ljust",
        "rjust",
        "center",
        "zfill",
        # Event / tracking
        "emit",
        "track",
        "record",
        "increment",
        "decrement",
        # Iteration helpers / builtins
        "enumerate",
        "zip",
        "range",
        "sorted",
        "reversed",
        "list",
        "dict",
        "set",
        "tuple",
        "len",
        "str",
        "int",
        "float",
        "bool",
        "bytes",
        "type",
        # Math / comparison builtins (per-item reductions)
        "max",
        "min",
        "sum",
        "abs",
        "round",
        "pow",
        "isinstance",
        "issubclass",
        "hasattr",
        "getattr",
        "setattr",
        # File / IO
        "resolve",
        "execute",
        "fetchone",
        "fetchall",
        "read_text",
        "read_bytes",
        "open",
        # Control flow
        "sleep",
        "yield",
    }

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        inv_calls = json.loads(r["loop_invariant_calls"]) if r["loop_invariant_calls"] else []
        # Filter out intentional per-iteration calls
        flagged = []
        for c in inv_calls:
            call_full = (c or "").lower()
            call_leaf = _call_leaf(c).lower()
            if call_full in _INTENTIONAL_CALLS or call_leaf in _INTENTIONAL_CALLS:
                continue
            flagged.append(c)
        flagged = _dedupe(flagged)
        if not flagged:
            continue
        results.append(
            _finding(
                "loop-invariant-call",
                "repeated-call",
                r,
                f"Loop-invariant call ({', '.join(flagged[:3])}) can be hoisted before loop",
                "medium",
            )
        )
    return results


# ---------------------------------------------------------------------------
# Confidence calibration
# ---------------------------------------------------------------------------

_CONFIDENCE_ORDER = ["low", "medium", "high"]

_DETECTOR_METADATA = {
    "sorting": {"precision": "high", "impact": "medium", "tags": ["ordering", "nested-loop"]},
    "search-sorted": {"precision": "low", "impact": "medium", "tags": ["search", "sorted-data"]},
    "membership": {"precision": "medium", "impact": "high", "tags": ["collections", "n2"]},
    "string-concat": {"precision": "medium", "impact": "medium", "tags": ["string", "quadratic"]},
    "unique": {"precision": "medium", "impact": "high", "tags": ["dedup", "n2"]},
    "max-min": {"precision": "medium", "impact": "low", "tags": ["idiom"]},
    "accumulation": {"precision": "medium", "impact": "low", "tags": ["idiom"]},
    "manual-power": {"precision": "high", "impact": "medium", "tags": ["math"]},
    "manual-gcd": {"precision": "high", "impact": "low", "tags": ["math"]},
    "fibonacci": {"precision": "high", "impact": "high", "tags": ["recursion", "exponential"]},
    "nested-lookup": {"precision": "medium", "impact": "high", "tags": ["join", "nxm"]},
    "groupby": {"precision": "medium", "impact": "low", "tags": ["idiom"]},
    "string-reverse": {"precision": "low", "impact": "low", "tags": ["idiom"]},
    "matrix-mult": {"precision": "high", "impact": "high", "tags": ["math", "triple-loop"]},
    "busy-wait": {"precision": "high", "impact": "high", "tags": ["concurrency"]},
    "regex-in-loop": {"precision": "high", "impact": "high", "tags": ["string", "regex"]},
    "io-in-loop": {"precision": "high", "impact": "high", "tags": ["io", "n+1"]},
    "list-prepend": {"precision": "high", "impact": "high", "tags": ["collections", "front-shift"]},
    "sort-to-select": {"precision": "high", "impact": "medium", "tags": ["ordering"]},
    "loop-lookup": {"precision": "high", "impact": "high", "tags": ["collections", "lookup"]},
    "branching-recursion": {"precision": "high", "impact": "high", "tags": ["recursion", "dp"]},
    "quadratic-string": {"precision": "high", "impact": "high", "tags": ["string", "quadratic"]},
    "loop-invariant-call": {"precision": "medium", "impact": "medium", "tags": ["hoisting"]},
}


def _detector_meta(task_id: str) -> dict:
    return _DETECTOR_METADATA.get(
        task_id,
        {"precision": "medium", "impact": "medium", "tags": []},
    )


def _boost_confidence(confidence: str) -> str:
    """Raise confidence by one level."""
    idx = _CONFIDENCE_ORDER.index(confidence) if confidence in _CONFIDENCE_ORDER else 1
    return _CONFIDENCE_ORDER[min(idx + 1, len(_CONFIDENCE_ORDER) - 1)]


def _lower_confidence(confidence: str) -> str:
    """Lower confidence by one level."""
    idx = _CONFIDENCE_ORDER.index(confidence) if confidence in _CONFIDENCE_ORDER else 1
    return _CONFIDENCE_ORDER[max(idx - 1, 0)]


_SIGNAL_COLUMNS = [
    ("has_nested_loops", "nested_loops"),
    ("subscript_in_loops", "subscript_in_loops"),
    ("loop_with_compare", "loop_compare"),
    ("loop_with_accumulator", "loop_accumulator"),
    ("loop_with_multiplication", "loop_multiplication"),
    ("loop_with_modulo", "loop_modulo"),
    ("str_concat_in_loop", "string_concat"),
    ("front_ops_in_loop", "front_ops"),
]

_PROFILE_BALANCED = "balanced"
_PROFILE_STRICT = "strict"
_PROFILE_AGGRESSIVE = "aggressive"
_VALID_PROFILES = {
    _PROFILE_BALANCED,
    _PROFILE_STRICT,
    _PROFILE_AGGRESSIVE,
}


def _chunked(values: list[int], size: int = 500):
    for i in range(0, len(values), size):
        yield values[i : i + size]


def _symbol_context(conn, symbol_ids: list[int]) -> dict[int, dict]:
    """Load calibration + evidence context for findings in bulk."""
    context: dict[int, dict] = {
        sid: {
            "signals": [],
            "loop_depth": 0,
            "loop_bound_small": 0,
            "caller_count": 0,
            "cognitive_complexity": 0.0,
            "cyclomatic_density": 0.0,
            "line_count": 0,
            "complexity_zscore": 0.0,
            "runtime_call_count": 0,
            "runtime_p99_latency_ms": None,
            "runtime_error_rate": 0.0,
            "runtime_otel_db_system": None,
            "runtime_otel_db_operation": None,
            "runtime_otel_db_statement_type": None,
        }
        for sid in symbol_ids
    }
    if not symbol_ids:
        return context

    # Repo-relative complexity baseline (differential scoring signal).
    complexity_mean = 0.0
    complexity_std = 0.0
    try:
        row = conn.execute(
            "SELECT AVG(COALESCE(cognitive_complexity, 0)) AS avg_cc, "
            "AVG(COALESCE(cognitive_complexity, 0) * COALESCE(cognitive_complexity, 0)) AS avg_sq_cc "
            "FROM symbol_metrics"
        ).fetchone()
        if row and row["avg_cc"] is not None:
            complexity_mean = float(row["avg_cc"] or 0.0)
            avg_sq = float(row["avg_sq_cc"] or 0.0)
            variance = max(0.0, avg_sq - (complexity_mean * complexity_mean))
            complexity_std = variance**0.5
    except Exception:
        complexity_mean = 0.0
        complexity_std = 0.0

    # Static AST signals
    for chunk in _chunked(symbol_ids):
        ph = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"SELECT symbol_id, loop_depth, loop_bound_small, "
            f"has_nested_loops, subscript_in_loops, loop_with_compare, "
            f"loop_with_accumulator, loop_with_multiplication, loop_with_modulo, "
            f"str_concat_in_loop, front_ops_in_loop "
            f"FROM math_signals WHERE symbol_id IN ({ph})",
            chunk,
        ).fetchall()
        for r in rows:
            sid = r["symbol_id"]
            if sid not in context:
                continue
            ctx = context[sid]
            ctx["loop_depth"] = int(r["loop_depth"] or 0)
            ctx["loop_bound_small"] = int(r["loop_bound_small"] or 0)
            signals: list[str] = []
            for col, label in _SIGNAL_COLUMNS:
                if r[col]:
                    signals.append(label)
            ctx["signals"] = signals

    # Complexity metrics
    for chunk in _chunked(symbol_ids):
        ph = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"SELECT symbol_id, cognitive_complexity, cyclomatic_density, line_count "
            f"FROM symbol_metrics WHERE symbol_id IN ({ph})",
            chunk,
        ).fetchall()
        for r in rows:
            sid = r["symbol_id"]
            if sid not in context:
                continue
            cc = float(r["cognitive_complexity"] or 0.0)
            density = float(r["cyclomatic_density"] or 0.0)
            line_count = int(r["line_count"] or 0)
            ctx = context[sid]
            ctx["cognitive_complexity"] = cc
            ctx["cyclomatic_density"] = density
            ctx["line_count"] = line_count
            if complexity_std > 0:
                ctx["complexity_zscore"] = (cc - complexity_mean) / complexity_std

    # Caller counts
    for chunk in _chunked(symbol_ids):
        ph = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"SELECT target_id, COUNT(*) AS cnt "
            f"FROM edges WHERE kind = 'call' AND target_id IN ({ph}) "
            f"GROUP BY target_id",
            chunk,
        ).fetchall()
        for r in rows:
            sid = r["target_id"]
            if sid in context:
                context[sid]["caller_count"] = int(r["cnt"] or 0)

    # Runtime traces (optional table for legacy DB compatibility)
    try:
        for chunk in _chunked(symbol_ids):
            ph = ",".join("?" for _ in chunk)
            rows = conn.execute(
                f"SELECT symbol_id, SUM(call_count) AS total_calls, "
                f"MAX(p99_latency_ms) AS p99_ms, MAX(error_rate) AS max_err, "
                f"MAX(otel_db_system) AS db_system, "
                f"MAX(otel_db_operation) AS db_operation, "
                f"MAX(otel_db_statement_type) AS db_statement_type "
                f"FROM runtime_stats "
                f"WHERE symbol_id IN ({ph}) "
                f"GROUP BY symbol_id",
                chunk,
            ).fetchall()
            for r in rows:
                sid = r["symbol_id"]
                if sid not in context:
                    continue
                context[sid]["runtime_call_count"] = int(r["total_calls"] or 0)
                context[sid]["runtime_p99_latency_ms"] = r["p99_ms"]
                context[sid]["runtime_error_rate"] = float(r["max_err"] or 0.0)
                context[sid]["runtime_otel_db_system"] = r["db_system"]
                context[sid]["runtime_otel_db_operation"] = r["db_operation"]
                context[sid]["runtime_otel_db_statement_type"] = r["db_statement_type"]
    except Exception:
        pass

    return context


def _merge_evidence(existing: dict | None, enriched: dict) -> dict:
    if not existing:
        return enriched
    merged = dict(existing)
    for k, v in enriched.items():
        if k not in merged:
            merged[k] = v
            continue
        current = merged[k]
        if isinstance(current, list) and isinstance(v, list):
            merged[k] = _dedupe([*current, *v])
        elif isinstance(current, dict) and isinstance(v, dict):
            tmp = dict(current)
            tmp.update(v)
            merged[k] = tmp
        else:
            merged[k] = v
    return merged


def _build_evidence(context: dict) -> dict:
    evidence = {
        "signal_count": len(context.get("signals", [])),
        "signals": context.get("signals", []),
        "loop_depth": int(context.get("loop_depth", 0) or 0),
        "loop_bound_small": bool(context.get("loop_bound_small", 0)),
        "caller_count": int(context.get("caller_count", 0) or 0),
    }
    cognitive = float(context.get("cognitive_complexity", 0.0) or 0.0)
    density = float(context.get("cyclomatic_density", 0.0) or 0.0)
    line_count = int(context.get("line_count", 0) or 0)
    zscore = float(context.get("complexity_zscore", 0.0) or 0.0)
    if cognitive > 0 or density > 0 or line_count > 0:
        evidence["complexity"] = {
            "cognitive": cognitive,
            "cyclomatic_density": density,
            "line_count": line_count,
            "zscore": round(zscore, 3),
        }
    runtime_calls = int(context.get("runtime_call_count", 0) or 0)
    runtime_p99 = context.get("runtime_p99_latency_ms")
    runtime_error = float(context.get("runtime_error_rate", 0.0) or 0.0)
    runtime_db_system = context.get("runtime_otel_db_system")
    runtime_db_operation = context.get("runtime_otel_db_operation")
    runtime_db_statement_type = context.get("runtime_otel_db_statement_type")
    if runtime_calls > 0 or runtime_p99 is not None:
        evidence["runtime"] = {
            "call_count": runtime_calls,
            "p99_latency_ms": runtime_p99,
            "error_rate": runtime_error,
            "db_system": runtime_db_system,
            "db_operation": runtime_db_operation,
            "db_statement_type": runtime_db_statement_type,
        }
    return evidence


def _build_evidence_path(finding: dict, context: dict) -> list[str]:
    path = [f"Observed pattern: {finding['reason']}"]
    signals = context.get("signals", [])
    if signals:
        path.append(f"Static evidence: {', '.join(signals[:4])}")
    cognitive = float(context.get("cognitive_complexity", 0.0) or 0.0)
    zscore = float(context.get("complexity_zscore", 0.0) or 0.0)
    if cognitive >= 12 or zscore >= 1.0:
        path.append(
            "Complexity pressure: cognitive={:.1f}, zscore={:.2f}".format(
                cognitive,
                zscore,
            )
        )
    runtime_calls = int(context.get("runtime_call_count", 0) or 0)
    runtime_p99 = context.get("runtime_p99_latency_ms")
    runtime_db_system = context.get("runtime_otel_db_system")
    runtime_db_operation = context.get("runtime_otel_db_operation") or context.get("runtime_otel_db_statement_type")
    if runtime_calls > 0:
        if runtime_p99 is not None:
            path.append(f"Runtime impact: {runtime_calls} calls, p99 {runtime_p99:.0f}ms")
        else:
            path.append(f"Runtime impact: {runtime_calls} calls")
        if runtime_db_system or runtime_db_operation:
            path.append(
                "Runtime semantics: db_system={} db_operation={}".format(
                    runtime_db_system or "n/a",
                    runtime_db_operation or "n/a",
                )
            )
    path.append(f"Recommendation: replace `{finding['detected_way']}` with `{finding['suggested_way']}`.")
    return path


def _impact_score(finding: dict, context: dict) -> float:
    """Rank finding urgency using static + runtime evidence."""
    confidence_base = {"high": 60.0, "medium": 35.0, "low": 15.0}
    impact_weight = {"high": 12.0, "medium": 6.0, "low": 2.0}

    score = confidence_base.get(finding.get("confidence", "medium"), 30.0)
    score += impact_weight.get(finding.get("impact", "medium"), 5.0)

    loop_depth = int(context.get("loop_depth", 0) or 0)
    score += min(12.0, loop_depth * 2.0)

    caller_count = int(context.get("caller_count", 0) or 0)
    score += min(10.0, caller_count * 1.5)

    # Differential complexity pressure (relative to repository baseline).
    cognitive = float(context.get("cognitive_complexity", 0.0) or 0.0)
    density = float(context.get("cyclomatic_density", 0.0) or 0.0)
    zscore = float(context.get("complexity_zscore", 0.0) or 0.0)
    if cognitive > 0:
        score += min(7.0, cognitive / 6.0)
    if density > 0:
        score += min(4.0, density * 8.0)
    if zscore > 0:
        score += min(8.0, zscore * 2.5)

    runtime_calls = int(context.get("runtime_call_count", 0) or 0)
    runtime_p99 = context.get("runtime_p99_latency_ms")
    runtime_error = float(context.get("runtime_error_rate", 0.0) or 0.0)
    runtime_db_system = context.get("runtime_otel_db_system")
    runtime_db_operation = (
        context.get("runtime_otel_db_operation") or context.get("runtime_otel_db_statement_type") or ""
    )
    runtime_db_operation = str(runtime_db_operation).upper()
    runtime_multiplier = 0.65
    if runtime_db_system:
        runtime_multiplier = 1.0
        if runtime_db_operation in {"INSERT", "UPDATE", "DELETE", "UPSERT", "MERGE", "REPLACE"}:
            runtime_multiplier = 1.25
        elif runtime_db_operation in {"SELECT", "READ", "QUERY", "GET"}:
            runtime_multiplier = 1.0
        else:
            runtime_multiplier = 0.9
    if runtime_calls:
        score += min(20.0, (len(str(max(1, runtime_calls))) - 1) * 5.0) * runtime_multiplier
    if runtime_p99 is not None:
        latency_mult = 1.1 if runtime_db_system else 0.9
        score += min(15.0, float(runtime_p99) / 40.0) * latency_mult
    if runtime_error > 0:
        score += min(8.0, runtime_error * 100.0)
    if runtime_db_system:
        score += 2.5
    if runtime_db_operation in {"INSERT", "UPDATE", "DELETE", "UPSERT", "MERGE", "REPLACE"}:
        score += 3.5

    if context.get("loop_bound_small", 0):
        score -= 8.0

    return round(max(0.0, score), 2)


def _impact_band(score: float) -> str:
    if score >= 80:
        return "high"
    if score >= 45:
        return "medium"
    return "low"


def _calibrate_finding(finding: dict, context: dict | None) -> dict:
    """Adjust confidence using static and runtime context."""
    ctx = context or {}
    caller_count = int(ctx.get("caller_count", 0) or 0)
    loop_bound_small = bool(ctx.get("loop_bound_small", 0))
    signal_count = len(ctx.get("signals", []))
    runtime_calls = int(ctx.get("runtime_call_count", 0) or 0)
    runtime_p99 = ctx.get("runtime_p99_latency_ms")
    runtime_error = float(ctx.get("runtime_error_rate", 0.0) or 0.0)
    runtime_db_system = ctx.get("runtime_otel_db_system")
    runtime_db_operation = ctx.get("runtime_otel_db_operation") or ctx.get("runtime_otel_db_statement_type") or ""
    runtime_db_operation = str(runtime_db_operation).upper()
    precision = (finding.get("precision") or "medium").lower()
    evidence = finding.get("evidence", {}) if isinstance(finding.get("evidence"), dict) else {}
    ambiguous_io_only = bool(finding.get("task_id") == "io-in-loop" and evidence.get("ambiguous_io_only"))
    caller_threshold = 5
    if precision == "medium":
        caller_threshold = 8
    elif precision == "low":
        caller_threshold = 12

    if (not ambiguous_io_only) and caller_count >= caller_threshold and (precision == "high" or signal_count >= 2):
        finding["confidence"] = _boost_confidence(finding["confidence"])
        finding["reason"] += f" (hot: {caller_count} callers)"
    elif caller_count == 0 and runtime_calls == 0:
        finding["confidence"] = _lower_confidence(finding["confidence"])

    runtime_call_threshold = 1500 if not runtime_db_system else 700
    runtime_hot = (
        runtime_calls >= runtime_call_threshold
        or (runtime_p99 is not None and runtime_p99 >= 300)
        or runtime_error >= 0.02
    )
    if runtime_hot:
        finding["confidence"] = _boost_confidence(finding["confidence"])
        runtime_very_hot = (
            runtime_calls >= 5000 or (runtime_p99 is not None and runtime_p99 >= 800) or runtime_error >= 0.05
        )
        if runtime_very_hot:
            finding["confidence"] = _boost_confidence(finding["confidence"])
        rt_bits = []
        if runtime_calls:
            rt_bits.append(f"{runtime_calls} calls")
        if runtime_p99 is not None:
            rt_bits.append(f"p99 {runtime_p99:.0f}ms")
        if runtime_error > 0:
            rt_bits.append(f"err {runtime_error * 100:.1f}%")
        if runtime_db_system:
            rt_bits.append(
                "db {}{}".format(
                    runtime_db_system,
                    f" {runtime_db_operation}" if runtime_db_operation else "",
                )
            )
        if rt_bits:
            finding["reason"] += f" (runtime: {', '.join(rt_bits)})"

    if loop_bound_small:
        finding["confidence"] = _lower_confidence(finding["confidence"])
        finding["reason"] += " (bounded loop)"

    # M8 — confidence calibration floor.
    # Categories where the FP-fix is heuristic-only (no AST-level proof)
    # cap at 'medium' regardless of caller-count or runtime boost. Real-world
    # calibration on union-web showed "high confidence" branching-recursion
    # was 0/1 true positive; same pattern likely on sort-then-subscript when
    # the result is also iterated.
    _MEDIUM_FLOOR_TASKS = {"branching-recursion", "sort-to-select"}
    if finding.get("task_id") in _MEDIUM_FLOOR_TASKS and finding.get("confidence") == "high":
        # Only floor when there's no strong runtime signal — runtime-hot code
        # earns the high-confidence boost.
        if not runtime_hot:
            finding["confidence"] = "medium"
            evidence_dict = finding.setdefault("evidence", {}) if isinstance(finding.get("evidence"), dict) else {}
            if isinstance(evidence_dict, dict):
                evidence_dict["calibration_floor"] = (
                    "category capped at 'medium' — heuristic-only detection has high FP rate; "
                    "use --confidence high to skip these"
                )

    return finding


def _has_strong_runtime(evidence: dict) -> bool:
    runtime = evidence.get("runtime") if isinstance(evidence, dict) else None
    if not isinstance(runtime, dict):
        return False
    calls = int(runtime.get("call_count", 0) or 0)
    p99 = runtime.get("p99_latency_ms")
    return calls >= 200 or (p99 is not None and p99 >= 200)


def _apply_profile(findings: list[dict], profile: str) -> list[dict]:
    if profile == _PROFILE_AGGRESSIVE:
        for f in findings:
            evidence = f.get("evidence", {})
            if f.get("confidence") == "low" and (
                int(evidence.get("signal_count", 0) or 0) >= 2 or _has_strong_runtime(evidence)
            ):
                f["confidence"] = "medium"
        return findings

    if profile == _PROFILE_STRICT:
        strict_findings: list[dict] = []
        for f in findings:
            if f.get("confidence") == "low":
                continue
            precision = (f.get("precision") or "medium").lower()
            evidence = f.get("evidence", {})
            runtime_strong = _has_strong_runtime(evidence)
            if precision == "low" and not runtime_strong and f.get("confidence") != "high":
                continue
            if f.get("confidence") == "high":
                strict_findings.append(f)
                continue
            if int(evidence.get("signal_count", 0) or 0) >= 2 or runtime_strong:
                strict_findings.append(f)
        return strict_findings

    return findings


# ---------------------------------------------------------------------------
# Detector registry
# ---------------------------------------------------------------------------

_MATH_DETECTORS = [
    ("sorting", "manual-sort", detect_manual_sort),
    ("search-sorted", "linear-scan", detect_linear_search),
    ("membership", "list-scan", detect_list_membership),
    ("string-concat", "loop-concat", detect_string_concat_loop),
    ("unique", "nested-dedup", detect_manual_dedup),
    ("max-min", "manual-loop", detect_manual_maxmin),
    ("accumulation", "manual-sum", detect_manual_accumulation),
    ("manual-power", "loop-multiply", detect_manual_power),
    ("manual-gcd", "manual-gcd", detect_manual_gcd),
    ("fibonacci", "naive-recursive", detect_naive_fibonacci),
    ("nested-lookup", "nested-iteration", detect_nested_lookup),
    ("groupby", "manual-check", detect_manual_groupby),
    ("string-reverse", "manual-reverse", detect_string_reverse),
    ("matrix-mult", "naive-triple", detect_matrix_mult),
    ("busy-wait", "sleep-loop", detect_busy_wait),
    ("regex-in-loop", "compile-per-iter", detect_regex_in_loop),
    ("io-in-loop", "loop-query", detect_io_in_loop),
    ("list-prepend", "insert-front", detect_list_prepend),
    ("sort-to-select", "full-sort", detect_sort_to_select),
    ("loop-lookup", "method-scan", detect_loop_lookup),
    ("branching-recursion", "naive-branching", detect_branching_recursion),
    ("quadratic-string", "augment-concat", detect_quadratic_string),
    ("loop-invariant-call", "repeated-call", detect_loop_invariant_call),
]


def _iter_registered_detectors():
    """Yield built-in detectors plus plugin-contributed detectors."""
    for det in _MATH_DETECTORS:
        yield det

    # Python pivot v12.4 β€” language-specific idiom detectors. Wrapped
    # in try/except so a regex bug in one detector can't block the
    # algorithm pass.
    try:
        from roam.catalog.python_idioms import PYTHON_IDIOM_DETECTORS

        for det in PYTHON_IDIOM_DETECTORS:
            yield det
    except Exception:
        pass

    try:
        from roam.plugins import get_plugin_detectors

        for task_id, way_id, detect_fn in get_plugin_detectors():
            if callable(detect_fn):
                yield (task_id, way_id, detect_fn)
    except Exception:
        # Plugin loading errors should not impact built-in detection.
        return


def run_detectors(
    conn,
    task_filter=None,
    confidence_filter=None,
    *,
    profile="balanced",
    return_meta=False,
):
    """Run all detectors and return combined findings.

    Parameters
    ----------
    conn : sqlite3.Connection
    task_filter : str or None
        If set, only run the detector for this task_id.
    confidence_filter : str or None
        If set, keep only findings with this confidence level.
    profile : str
        Precision profile: ``balanced`` (default), ``strict``, ``aggressive``.
    return_meta : bool
        When True, returns ``(findings, meta)`` where ``meta`` contains
        detector execution diagnostics (totals + failures).

    Returns list of finding dicts, or ``(findings, meta)`` when
    ``return_meta=True``.
    """
    findings = []
    failed_detectors = []
    executed = 0
    executed_tasks: list[str] = []
    for task_id, _way_id, detect_fn in _iter_registered_detectors():
        if task_filter and task_id != task_filter:
            continue
        executed += 1
        executed_tasks.append(task_id)
        try:
            hits = detect_fn(conn)
        except Exception as exc:
            failed_detectors.append(
                {
                    "task_id": task_id,
                    "detector": detect_fn.__name__,
                    "error": str(exc),
                }
            )
            continue
        dmeta = _detector_meta(task_id)
        for h in hits:
            h.setdefault("precision", dmeta["precision"])
            h.setdefault("impact", dmeta["impact"])
            h.setdefault("tags", list(dmeta["tags"]))
        findings.extend(hits)

    profile_key = (profile or _PROFILE_BALANCED).lower()
    if profile_key not in _VALID_PROFILES:
        profile_key = _PROFILE_BALANCED

    symbol_ids = _dedupe([f["symbol_id"] for f in findings if f.get("symbol_id")])
    context_map = _symbol_context(conn, symbol_ids)

    # Apply calibration and enrich findings with semantic evidence.
    for f in findings:
        ctx = context_map.get(f["symbol_id"], {})
        _calibrate_finding(f, ctx)
        enriched_evidence = _build_evidence(ctx)
        f["evidence"] = _merge_evidence(f.get("evidence"), enriched_evidence)
        f["evidence_path"] = _build_evidence_path(f, ctx)
        score = _impact_score(f, ctx)
        f["impact_score"] = score
        f["impact_band"] = _impact_band(score)

    pre_profile_count = len(findings)
    findings = _apply_profile(findings, profile_key)
    profile_filtered = pre_profile_count - len(findings)

    if confidence_filter:
        findings = [f for f in findings if f["confidence"] == confidence_filter]

    if return_meta:
        meta = {
            "detectors_executed": executed,
            "detectors_failed": len(failed_detectors),
            "failed_detectors": failed_detectors,
            "profile": profile_key,
            "profile_filtered": profile_filtered,
            "detector_metadata": {task_id: _detector_meta(task_id) for task_id in executed_tasks},
        }
        return findings, meta

    return findings
