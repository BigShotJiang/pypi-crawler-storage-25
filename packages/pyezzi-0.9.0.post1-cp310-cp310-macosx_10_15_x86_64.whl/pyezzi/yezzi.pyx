cimport numpy as cnp
cimport cython
from libc.math cimport fabs
from .common cimport OUTSIDE, has_converged

import numpy as np
from cython.parallel import prange


@cython.boundscheck(False)
@cython.wraparound(False)
@cython.cdivision(True)
def iterative_relaxation(unsigned int[:] neighbours,
                         double[:] vectors,
                         double tolerance,
                         int max_iterations,
                         double[:] spacing,
                         double[:] weights,
                         int n_threads):

    cdef Py_ssize_t dim = spacing.shape[0]
    cdef Py_ssize_t dim2 = 2 * dim
    cdef Py_ssize_t i

    cdef int n_points = neighbours.shape[0] // dim2
    cdef size_t n_points2 = n_points * 2

    cdef cnp.ndarray[double] abs_vectors = np.abs(vectors).astype(np.float64)
    cdef double[:] sum_abs_vectors = np.copy(abs_vectors[0::dim]) / spacing[0]
    for i in range(1, spacing.shape[0]):
        sum_abs_vectors += abs_vectors[i::dim] / spacing[i]

    cdef double neg_half_mean_spacing = -np.mean(spacing) * 0.5

    cdef int iteration = 0
    cdef bint convergence = False

    cdef cnp.ndarray[double] L0 = np.zeros(n_points, np.float64)
    cdef cnp.ndarray[double] L1 = np.zeros(n_points, np.float64)
    cdef double[:] errors = np.zeros(n_points2, np.float64)

    cdef size_t n, nn, n0, n1
    cdef double L0_acc, L1_acc, prev_L0, prev_L1
    cdef double L0_value, L1_value, sum_abs_vector

    while not convergence and iteration < max_iterations:
        iteration += 1
        for n in prange(n_points, nogil=True, num_threads=n_threads):
            L0_value = 0.
            L1_value = 0.
            for i in range(dim):
                n0 = neighbours[n * dim2 + i * 2]
                n1 = neighbours[n * dim2 + i * 2 + 1]
                if vectors[n * dim + i] > 0:
                    L0_acc = abs_vectors[n * dim + i] * (L0[n1] if n1 < OUTSIDE else neg_half_mean_spacing)
                    L1_acc = abs_vectors[n * dim + i] * (L1[n0] if n0 < OUTSIDE else neg_half_mean_spacing)
                else:
                    L0_acc = abs_vectors[n * dim + i] * (L0[n0] if n0 < OUTSIDE else neg_half_mean_spacing)
                    L1_acc = abs_vectors[n * dim + i] * (L1[n1] if n1 < OUTSIDE else neg_half_mean_spacing)

                L0_value += L0_acc / spacing[i]
                L1_value += L1_acc / spacing[i]

            sum_abs_vector = sum_abs_vectors[n]
            prev_L0 = L0[n]
            prev_L1 = L1[n]
            L0_value += weights[n]
            L1_value += weights[n]
            L0_value = L0_value / sum_abs_vector
            L1_value = L1_value / sum_abs_vector
            errors[n] = fabs((prev_L0 - L0_value) / (prev_L0 + 1e-300))
            nn = n + n_points
            errors[nn] = fabs((prev_L1 - L1_value) / (prev_L1 + 1e-300))
            L0[n] = L0_value
            L1[n] = L1_value
        convergence = has_converged(errors, n_points2, tolerance)

    return L0, L1, iteration, np.nanmax(errors)
