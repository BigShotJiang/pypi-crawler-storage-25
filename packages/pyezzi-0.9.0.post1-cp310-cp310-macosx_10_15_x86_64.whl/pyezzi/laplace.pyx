cimport numpy as np
cimport cython
from libc.math cimport fabs
from .common cimport OUTSIDE, INSIDE, has_converged

import numpy as np
from cython.parallel import prange


@cython.boundscheck(False)
@cython.wraparound(False)
@cython.cdivision(True)
def solve(
    unsigned int[:] neighbours,
    double tolerance,
    int max_iterations,
    double[:] spacing,
    int n_threads,
) -> tuple[np.typing.NDArray, int, double]:
    cdef int dim = spacing.shape[0]
    cdef Py_ssize_t dim2 = 2 * dim

    cdef int n_points = neighbours.shape[0] // dim2

    cdef double[:] errors = np.empty(n_points, np.float64)
    cdef np.ndarray[double, ndim=1] result_flat = np.full(n_points, 0.5, dtype=np.float64)

    cdef np.ndarray[double, ndim=1] spacing2 = np.power(spacing, 2)

    cdef double alpha = 2.0 * np.sum(1.0 / spacing2)

    cdef Py_ssize_t i, j, k, n
    cdef int iteration = 0
    cdef bint convergence = False
    cdef double prev_value, value, temp
    while not convergence and iteration < max_iterations:
        iteration += 1
        for i in prange(n_points, nogil=True, num_threads=n_threads):
            value = 0
            for j in range(dim):
                temp = 0
                for k in range(2):
                    n = neighbours[i * dim2 + j * 2 + k]
                    if n == OUTSIDE:
                        temp += 1.
                    elif n != INSIDE:
                        temp += result_flat[n]

                value += temp / spacing2[j]
            value = value / alpha
            prev_value = result_flat[i]
            errors[i] = fabs((prev_value - value) / (prev_value + 1e-300))
            result_flat[i] = value

        convergence = has_converged(errors, n_points, tolerance)

    return result_flat, iteration, np.nanmax(errors)
