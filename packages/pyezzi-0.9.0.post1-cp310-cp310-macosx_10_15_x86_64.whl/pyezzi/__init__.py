"""

Implementation of [weighted tissue thickness](https://nicoco.fr/weighted-thickness/).

Installation instructions on the [homepage](https://gitlab.inria.fr/ncedilni/pyezzi).

## Quickstart

The higher level interface is in `compute_thickness_cardiac`.

>>> from pathlib import Path
>>> import metaio
>>> import numpy as np

Load relevant data:

>>> data_dir = Path(__file__).parent.parent / "test" / "data"
>>> endo = metaio.read_mha(data_dir / "endo.mha")
>>> epi = metaio.read_mha(data_dir / "epi.mha")

We use numpy conventions for axis order, not ITK's, so spacing must be reversed.
NB: it is recommended to resample the masks to a homogeneous spacing anyway.

>>> result = compute_thickness_cardiac(
...     endo.data,
...     epi.data,
...     spacing=endo.spacing[::-1],
... )

Let's see what the average wall thickness is (voxels outside the wall are filled with
`NaN`):

>>> wall = endo.data.astype(bool) ^ epi.data.astype(bool)
>>> round(float(np.nanmean(result)), 1)
9.0

"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("pyezzi")
except PackageNotFoundError:
    __version__ = "DEV"

from .thickness import (
    Domain,
    ThicknessSolver,
    compute_thickness,
    compute_thickness_cardiac,
)

__all__ = (
    "Domain",
    "ThicknessSolver",
    "compute_thickness",
    "compute_thickness_cardiac",
    "__version__",
)
