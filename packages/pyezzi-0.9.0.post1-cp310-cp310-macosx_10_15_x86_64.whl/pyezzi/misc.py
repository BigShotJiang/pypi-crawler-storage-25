import logging
from collections.abc import Callable
from functools import wraps
from time import monotonic
from typing import Any, TypeVar, cast

import numpy as np

from . import _ni_label  # type:ignore[attr-defined]

T = TypeVar("T", bound=Callable[..., Any])


_STRUCTURING_ELEMENT = {
    2: np.array([[False, True, False], [True, True, True], [False, True, False]]),
    3: np.array(
        [
            [[False, False, False], [False, True, False], [False, False, False]],
            [[False, True, False], [True, True, True], [False, True, False]],
            [[False, False, False], [False, True, False], [False, False, False]],
        ]
    ),
}


def keep_biggest_cc(
    nda_image: np.typing.NDArray[np.bool],
) -> np.typing.NDArray[np.bool]:
    labeled_img, n = label(nda_image)
    sizes = [(labeled_img == i).sum() for i in range(1, labeled_img.max() + 1)]
    rankings = np.argsort(sizes)[::-1] + 1
    return cast(np.typing.NDArray[np.bool], labeled_img == rankings[0])


def label(
    input: np.typing.NDArray[np.bool],
) -> tuple[np.typing.NDArray[np.integer], int]:
    # This is vendored in from scipy with little modification to avoid
    # depending on scipy just for this single function.
    input = np.asarray(input)
    structure = _STRUCTURING_ELEMENT[input.ndim]
    need_64bits = input.size >= (2**31 - 2)
    output = np.empty(input.shape, np.intp if need_64bits else np.int32)
    max_label = _ni_label._label(input, structure, output)
    return output, max_label


def timeit(func: T) -> T:
    @wraps(func)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        tik = monotonic()
        result = func(*args, **kwargs)
        log.debug("%s took %s seconds", func.__name__, monotonic() - tik)
        return result

    return cast(T, wrapped)


def get_2d_domain(
    size: int = 7, offset: int = 1
) -> tuple[np.typing.NDArray[np.bool], np.typing.NDArray[np.bool]]:
    from skimage.draw import disk

    shape = size, size
    rr, cc = disk((size // 2, size // 2), size // 2 + 1, shape=shape)  # type:ignore[no-untyped-call]
    epi = np.zeros(shape, dtype=bool)
    epi[rr, cc] = 1

    rr, cc = disk(  # type:ignore[no-untyped-call]
        (size // 2 - offset, size // 2 - offset), size // 2 - offset, shape=shape
    )
    endo = np.zeros(shape, dtype=bool)
    endo[rr, cc] = 1

    return endo, epi


log = logging.getLogger(__name__)
