import logging
from argparse import ArgumentParser
from pathlib import Path

from metaio import MetaImage, read_mha

from . import __version__
from .thickness import compute_thickness_cardiac


def main() -> None:
    logging.basicConfig(level=logging.DEBUG)

    parser = ArgumentParser(
        description="A command-line interface to compute weighted tissue thickness on medical images."
    )

    parser.add_argument(
        "ENDO",
        help="Path to the segmentation of the outer layer. "
        "In a cardiac context, this would be the ventricle blood pool, a.k.a. 'endocardial mask'.",
    )
    parser.add_argument(
        "EPI",
        help="Path to the segmentation of the outer layer. "
        "In a cardiac context, this would be the whole ventricle myocardium + its blood pool, "
        "a.k.a. 'epicardial mask'.",
    )
    parser.add_argument("OUTPUT")
    parser.add_argument(
        "--weights",
        "-w",
        help="Path to a float image representing the thickness weights.",
        type=Path,
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s version {__version__}"
    )
    args = parser.parse_args()

    print("Reading images")
    endo = read_mha(args.ENDO)
    epi = read_mha(args.EPI)
    if args.weights:
        if args.weights.exists():
            weights = read_mha(args.weights).data
        else:
            print("Weights file not found")
            weights = None
    else:
        weights = None

    thickness = compute_thickness_cardiac(
        endo.data,
        epi.data,
        endo.spacing[::-1],  # type:ignore
        weights,
    )

    thickness_img = MetaImage(
        thickness, spacing=endo.spacing, direction=endo.direction, origin=endo.origin
    )

    print("Writing result")
    thickness_img.save(args.OUTPUT, True)


if __name__ == "__main__":
    main()
