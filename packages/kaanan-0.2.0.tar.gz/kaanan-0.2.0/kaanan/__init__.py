# kaanan — AI-driven SAST + VAPT CLI
__version__ = "0.1.0"
