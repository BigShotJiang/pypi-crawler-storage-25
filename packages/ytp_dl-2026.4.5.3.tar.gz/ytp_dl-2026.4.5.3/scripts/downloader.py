#!/usr/bin/env python3
# downloader.py (VPS) - playlist support, embedded cover art/metadata, hard kill timeout

from __future__ import annotations

import os
import re
import shlex
import shutil
import subprocess
import time
import signal
import threading
import zipfile
from collections import deque
from typing import Callable, Deque, List, Optional, Tuple

# =========================
# Config / constants
# =========================
VENV_PATH = os.environ.get("YTPDL_VENV", "/opt/yt-dlp-mullvad/venv")
YTDLP_BIN = os.path.join(VENV_PATH, "bin", "yt-dlp")
MULLVAD_LOCATION = os.environ.get("YTPDL_MULLVAD_LOCATION", "us")

MODERN_UA = os.environ.get(
    "YTPDL_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36",
)

FFMPEG_BIN = shutil.which("ffmpeg") or "ffmpeg"
DEFAULT_OUT_DIR = os.environ.get("YTPDL_DOWNLOAD_DIR", "/root")

# Hard timeout for a single job (kills stuck yt-dlp/ffmpeg). 0 = disable.
JOB_TIMEOUT_S = int(os.environ.get("YTPDL_JOB_TIMEOUT_S", "1800"))

# For playlists, allow more time (default 6 h).
PLAYLIST_JOB_TIMEOUT_S = int(os.environ.get("YTPDL_PLAYLIST_JOB_TIMEOUT_S", "21600"))

_MAX_ERR_LINES = 80
_MAX_ERR_CHARS = 4000


# =========================
# Shell helpers
# =========================
def _run_argv_capture(argv: List[str]) -> Tuple[int, str]:
    res = subprocess.run(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return res.returncode, (res.stdout or "")


def _run_argv(argv: List[str], check: bool = True) -> str:
    rc, out = _run_argv_capture(argv)
    if check and rc != 0:
        cmd = " ".join(shlex.quote(p) for p in argv)
        raise RuntimeError(f"Command failed: {cmd}\n{out}")
    return out


def _tail(out: str) -> str:
    lines = (out or "").splitlines()
    tail_lines = lines[-_MAX_ERR_LINES:]
    txt = "\n".join(tail_lines)
    if len(txt) > _MAX_ERR_CHARS:
        txt = txt[-_MAX_ERR_CHARS:]
    return txt.strip()


# =========================
# Playlist detection
# =========================
# Intentionally exclude YouTube auto-generated mixes (RD*, RDMM*) and
# personal-library lists (LL, WL, FL) which can be enormous.
_YT_PLAYLIST_RE = re.compile(r"[?&]list=(?!RD|RDMM|FL|LL|WL)", re.IGNORECASE)
_SC_SET_RE = re.compile(r"soundcloud\.com/[^/?#]+/sets/", re.IGNORECASE)


def is_playlist_url(url: str) -> bool:
    """Return True when url looks like a YouTube playlist or SoundCloud set/album."""
    url = (url or "").strip()
    return bool(_YT_PLAYLIST_RE.search(url) or _SC_SET_RE.search(url))


# =========================
# Environment / Mullvad
# =========================
def validate_environment() -> None:
    if not os.path.exists(YTDLP_BIN):
        raise RuntimeError(f"yt-dlp not found at {YTDLP_BIN}")
    if shutil.which(FFMPEG_BIN) is None:
        raise RuntimeError("ffmpeg not found on PATH")


def _mullvad_present() -> bool:
    return shutil.which("mullvad") is not None


def mullvad_logged_in() -> bool:
    if not _mullvad_present():
        return False
    res = subprocess.run(
        ["mullvad", "account", "get"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return "not logged in" not in (res.stdout or "").lower()


def require_mullvad_login() -> None:
    if _mullvad_present() and not mullvad_logged_in():
        raise RuntimeError("Mullvad not logged in. Run: mullvad account login <ACCOUNT>")


def mullvad_connect(location: Optional[str] = None) -> None:
    if not _mullvad_present():
        return
    loc = (location or MULLVAD_LOCATION).strip()
    _run_argv(["mullvad", "disconnect"], check=False)
    if loc:
        _run_argv(["mullvad", "relay", "set", "location", loc], check=False)
    _run_argv(["mullvad", "connect"], check=False)


def mullvad_wait_connected(timeout: int = 20) -> bool:
    if not _mullvad_present():
        return True
    for _ in range(timeout):
        res = subprocess.run(
            ["mullvad", "status"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        if "Connected" in (res.stdout or ""):
            return True
        time.sleep(1)
    return False


# =========================
# yt-dlp flag sets
# =========================
def _common_flags(*, playlist: bool = False) -> List[str]:
    """
    Base yt-dlp flags shared between single-file and playlist downloads.

    Changes vs original:
    - --embed-thumbnail  → embeds cover art into MP3 (ID3 APIC) and MP4
    - --convert-thumbnails jpg → normalises webp thumbnails so embedders accept them
    - --no-playlist / --yes-playlist controlled by `playlist` param
    """
    flags = [
        "--retries", "10",
        "--fragment-retries", "10",
        "--retry-sleep", "exp=1:30",
        "--user-agent", MODERN_UA,
        "--no-cache-dir",
        "--ignore-config",
        "--embed-metadata",        # title, artist, album, etc. in container
        "--embed-thumbnail",       # cover art embedded into the file
        "--convert-thumbnails", "jpg",  # webp → jpg so all embedders accept it
        "--sleep-interval", "1",
    ]
    if playlist:
        flags.append("--yes-playlist")
    else:
        flags.append("--no-playlist")
    return flags


# =========================
# Format selectors
# =========================
def _fmt_mp4_apple_safe(cap: int) -> str:
    return (
        f"bv*[height<={cap}][ext=mp4][vcodec~='^(avc1|h264)']"
        f"+ba[ext=m4a][acodec~='^mp4a']"
        f"/b[height<={cap}][ext=mp4][vcodec~='^(avc1|h264)'][acodec~='^mp4a']"
    )


def _fmt_best(cap: int) -> str:
    return f"bv*[height<={cap}]+ba/b[height<={cap}]"


# =========================
# Path extraction helpers
# =========================
def _extract_final_path_from_tail(stdout: str, out_dir: str) -> Optional[str]:
    candidates: List[str] = []
    out_dir = os.path.abspath(out_dir)

    for raw in (stdout or "").splitlines():
        line = (raw or "").strip()
        if not line:
            continue

        if os.path.isabs(line) and line.startswith(out_dir):
            candidates.append(line.strip("'\""))
            continue

        if "Merging formats into" in line and "\"" in line:
            try:
                merged = line.split("Merging formats into", 1)[1].strip()
                if merged.startswith("\"") and merged.endswith("\""):
                    merged = merged[1:-1]
                elif merged.startswith("\""):
                    merged = merged.split("\"", 2)[1]
                if merged:
                    if not os.path.isabs(merged):
                        merged = os.path.join(out_dir, merged)
                    candidates.append(merged.strip("'\""))
            except Exception:
                pass
            continue

        if "Destination:" in line:
            try:
                p = line.split("Destination:", 1)[1].strip().strip("'\"")
                if p and not os.path.isabs(p):
                    p = os.path.join(out_dir, p)
                if p:
                    candidates.append(p)
            except Exception:
                pass
            continue

        if "] " in line and " has already been downloaded" in line:
            try:
                p = (
                    line.split("] ", 1)[1]
                    .split(" has already been downloaded", 1)[0]
                    .strip()
                    .strip("'\"")
                )
                if p and not os.path.isabs(p):
                    p = os.path.join(out_dir, p)
                if p:
                    candidates.append(p)
            except Exception:
                pass

    for p in reversed(candidates):
        if p and os.path.exists(p):
            return os.path.abspath(p)

    # Directory scan fallback
    try:
        best_path = None
        best_mtime = -1.0
        for name in os.listdir(out_dir):
            if name.endswith((".part", ".ytdl", ".tmp", ".zip")):
                continue
            full = os.path.join(out_dir, name)
            if not os.path.isfile(full):
                continue
            mt = os.path.getmtime(full)
            if mt > best_mtime:
                best_mtime = mt
                best_path = full
        if best_path:
            return os.path.abspath(best_path)
    except Exception:
        pass

    return None


# =========================
# argv builder
# =========================
def _build_ytdlp_argv(
    *,
    url: str,
    out_dir: str,
    fmt: str,
    merge_output_format: Optional[str],
    extract_mp3: bool,
    playlist: bool = False,
) -> List[str]:
    out_dir = os.path.abspath(out_dir)

    # For playlists use an index prefix to avoid filename collisions and preserve order.
    if playlist:
        out_tpl = os.path.join(out_dir, "%(playlist_index)02d - %(title)s.%(ext)s")
    else:
        out_tpl = os.path.join(out_dir, "%(title)s.%(ext)s")

    argv = [
        YTDLP_BIN,
        "-f", fmt,
        *(_common_flags(playlist=playlist)),
        "--output", out_tpl,
        "--print", "after_move:filepath",   # prints final path once per track
        "--progress",
        "--newline",
        "--no-color",
    ]

    if extract_mp3:
        # --audio-quality 0 = best VBR for lame
        argv.extend(["--extract-audio", "--audio-format", "mp3", "--audio-quality", "0"])

    if merge_output_format:
        argv.extend(["--merge-output-format", merge_output_format])

    argv.append(url)
    return argv


# =========================
# Core streaming downloader
# =========================
def _download_with_format_stream(
    *,
    url: str,
    out_dir: str,
    fmt: str,
    merge_output_format: Optional[str],
    extract_mp3: bool,
    on_line: Callable[[str], None],
    playlist: bool = False,
) -> "str | List[str]":
    """
    Stream yt-dlp output line-by-line via on_line callback.

    Returns:
      - str  : path to the single downloaded file  (playlist=False)
      - list : sorted list of paths for all tracks  (playlist=True)
    """
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    argv = _build_ytdlp_argv(
        url=url,
        out_dir=out_dir,
        fmt=fmt,
        merge_output_format=merge_output_format,
        extract_mp3=extract_mp3,
        playlist=playlist,
    )

    tail_lines: Deque[str] = deque(maxlen=_MAX_ERR_LINES)
    # candidates preserves insertion order; for playlists each track adds one entry.
    candidates: List[str] = []

    def _maybe_add_candidate(p: str) -> None:
        p = (p or "").strip().strip("'\"")
        if not p:
            return
        if not os.path.isabs(p):
            p = os.path.join(out_dir, p)
        if p not in candidates:
            candidates.append(p)

    timeout_s = PLAYLIST_JOB_TIMEOUT_S if playlist else JOB_TIMEOUT_S

    proc = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        start_new_session=True,
    )

    assert proc.stdout is not None

    stop_killer = threading.Event()

    def _killer():
        if timeout_s <= 0:
            return
        if stop_killer.wait(timeout_s):
            return
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

    threading.Thread(target=_killer, daemon=True).start()

    try:
        for line in proc.stdout:
            s = (line or "").rstrip("\n")
            if not s:
                continue

            on_line(s)
            tail_lines.append(s)

            # --print after_move:filepath emits the absolute path of each finished track.
            if os.path.isabs(s) and s.startswith(out_dir):
                _maybe_add_candidate(s)
                continue

            if "Merging formats into" in s and "\"" in s:
                try:
                    merged = s.split("Merging formats into", 1)[1].strip()
                    if merged.startswith("\"") and merged.endswith("\""):
                        merged = merged[1:-1]
                    elif merged.startswith("\""):
                        merged = merged.split("\"", 2)[1]
                    _maybe_add_candidate(merged)
                except Exception:
                    pass

            if "Destination:" in s:
                try:
                    p = s.split("Destination:", 1)[1].strip()
                    _maybe_add_candidate(p)
                except Exception:
                    pass

        rc = proc.wait()
    finally:
        stop_killer.set()
        try:
            proc.stdout.close()
        except Exception:
            pass

    # ---- Playlist: return all collected paths ----
    if playlist:
        found = [p for p in candidates if p and os.path.exists(p)]
        if not found:
            # Fallback: scan directory for any media files (sorted = playlist order)
            try:
                found = sorted(
                    os.path.join(out_dir, n)
                    for n in os.listdir(out_dir)
                    if not n.endswith((".part", ".ytdl", ".tmp", ".zip", ".json"))
                    and os.path.isfile(os.path.join(out_dir, n))
                )
            except Exception:
                found = []

        if not found and rc != 0:
            tail_txt = "\n".join(tail_lines)
            raise RuntimeError(f"yt-dlp failed (playlist, format: {fmt})\n{_tail(tail_txt)}")

        return found  # may be empty if every track errored; caller decides

    # ---- Single file: existing logic ----
    for p in reversed(candidates):
        if p and os.path.exists(p):
            return os.path.abspath(p)

    tail_txt = "\n".join(tail_lines)
    final_path = _extract_final_path_from_tail(tail_txt, out_dir)
    if final_path and os.path.exists(final_path):
        return os.path.abspath(final_path)

    if rc != 0:
        raise RuntimeError(f"yt-dlp failed (format: {fmt})\n{_tail(tail_txt)}")
    raise RuntimeError(f"Download completed but output file not found (format: {fmt})\n{_tail(tail_txt)}")


# =========================
# ZIP helper
# =========================
def _create_zip(files: List[str], zip_path: str, on_line: Callable[[str], None]) -> str:
    """
    Bundle *files* into a ZIP archive at *zip_path*.
    Uses ZIP_STORED (no extra compression) because media files are already
    compressed; this keeps CPU usage low and avoids re-encoding artifacts.
    """
    on_line(f"[zip] Bundling {len(files)} file(s) into archive…")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_STORED) as zf:
        for path in files:
            if os.path.isfile(path):
                zf.write(path, os.path.basename(path))
    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    on_line(f"[zip] Archive ready ({size_mb:.1f} MB)")
    return zip_path


# =========================
# Playlist downloader
# =========================
def download_playlist(
    *,
    url: str,
    resolution: int | None = 1080,
    extension: Optional[str] = None,
    out_dir: str = DEFAULT_OUT_DIR,
    on_line: Callable[[str], None],
) -> str:
    """
    Download every track in a YouTube playlist or SoundCloud set.

    Returns the path of a ZIP archive containing all downloaded tracks,
    with embedded metadata and cover art.
    """
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    validate_environment()
    require_mullvad_login()
    mullvad_connect(MULLVAD_LOCATION)
    if not mullvad_wait_connected():
        raise RuntimeError("Mullvad connection failed")

    mode = (extension or "mp3").lower().strip()
    cap = int(resolution or 1080)

    on_line("[playlist] Fetching playlist metadata…")

    try:
        if mode == "mp3":
            files = _download_with_format_stream(
                url=url,
                out_dir=out_dir,
                fmt="bestaudio",
                merge_output_format=None,
                extract_mp3=True,
                on_line=on_line,
                playlist=True,
            )

        elif mode == "best":
            try:
                files = _download_with_format_stream(
                    url=url,
                    out_dir=out_dir,
                    fmt=_fmt_best(cap),
                    merge_output_format=None,
                    extract_mp3=False,
                    on_line=on_line,
                    playlist=True,
                )
            except Exception:
                files = _download_with_format_stream(
                    url=url,
                    out_dir=out_dir,
                    fmt=_fmt_mp4_apple_safe(cap),
                    merge_output_format="mp4",
                    extract_mp3=False,
                    on_line=on_line,
                    playlist=True,
                )

        else:  # mp4 (default video)
            files = _download_with_format_stream(
                url=url,
                out_dir=out_dir,
                fmt=_fmt_mp4_apple_safe(cap),
                merge_output_format="mp4",
                extract_mp3=False,
                on_line=on_line,
                playlist=True,
            )

        # files is always a list here (playlist=True path)
        if not files:
            raise RuntimeError("No tracks could be downloaded from this playlist.")

        n = len(files)
        on_line(f"[playlist] {n} track(s) downloaded. Building ZIP…")

        zip_path = os.path.join(out_dir, "playlist.zip")
        _create_zip(files, zip_path, on_line)
        return zip_path

    finally:
        if _mullvad_present():
            _run_argv(["mullvad", "disconnect"], check=False)


# =========================
# Public entry point
# =========================
def download_video(
    *,
    url: str,
    resolution: int | None = 1080,
    extension: Optional[str] = None,
    out_dir: str = DEFAULT_OUT_DIR,
    on_line: Callable[[str], None],
) -> str:
    """
    Download a single video/audio URL, or a full playlist.

    Always returns a single file path:
      - media file for single-URL downloads
      - playlist.zip for playlist URLs
    """
    if not url:
        raise RuntimeError("Missing URL")

    # Route playlists to the dedicated handler (returns ZIP path)
    if is_playlist_url(url):
        return download_playlist(
            url=url,
            resolution=resolution,
            extension=extension,
            out_dir=out_dir,
            on_line=on_line,
        )

    # ---- Single-file path (unchanged logic) ----
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    validate_environment()
    require_mullvad_login()
    mullvad_connect(MULLVAD_LOCATION)
    if not mullvad_wait_connected():
        raise RuntimeError("Mullvad connection failed")

    try:
        mode = (extension or "mp4").lower().strip()
        cap = int(resolution or 1080)

        if mode == "mp3":
            return _download_with_format_stream(
                url=url,
                out_dir=out_dir,
                fmt="bestaudio",
                merge_output_format=None,
                extract_mp3=True,
                on_line=on_line,
            )

        if mode == "best":
            try:
                return _download_with_format_stream(
                    url=url,
                    out_dir=out_dir,
                    fmt=_fmt_best(cap),
                    merge_output_format=None,
                    extract_mp3=False,
                    on_line=on_line,
                )
            except Exception:
                return _download_with_format_stream(
                    url=url,
                    out_dir=out_dir,
                    fmt=_fmt_mp4_apple_safe(cap),
                    merge_output_format="mp4",
                    extract_mp3=False,
                    on_line=on_line,
                )

        # mp4 (default)
        return _download_with_format_stream(
            url=url,
            out_dir=out_dir,
            fmt=_fmt_mp4_apple_safe(cap),
            merge_output_format="mp4",
            extract_mp3=False,
            on_line=on_line,
        )

    finally:
        if _mullvad_present():
            _run_argv(["mullvad", "disconnect"], check=False)
