# rye:signed:2026-04-01T06:49:05Z:a9fd434ceda3993cccc6a574eff17de08ba5b6761cb815485e47387386231414:s4a4dzdCdN8dYTEiUp1g50HQUETfECQOBA5SbxnIIGU582reOX6hGoHTcpNxWKJORU_YObP3tU3lGODnlAihCw:6ea18199041a1ea8
"""Core primitives package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/primitives"
__tool_description__ = "Core primitives package"
