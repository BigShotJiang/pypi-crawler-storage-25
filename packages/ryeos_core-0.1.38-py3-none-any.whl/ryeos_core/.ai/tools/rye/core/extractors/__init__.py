# rye:signed:2026-04-01T06:49:05Z:b9f2acbd0110656d9e859969b48adde6ca7a8ac254814ffa87e6a0ad68e77f9a:BgaS2j7BpdVwLpN9NmXADFVn9Xx49IIC4D_gkujSbJ5L3DtWbRrY4C8xpLD-e3rIswETj5I35NhKYoCYWGMuDA:6ea18199041a1ea8
"""Extractor tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/extractors"
__tool_description__ = "Extractor tools package"
