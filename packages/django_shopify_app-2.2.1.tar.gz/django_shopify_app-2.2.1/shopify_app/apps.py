from django.apps import AppConfig
from django.conf import settings


class ShopifyAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "shopify_app"

    SHOPIFY_API_KEY = settings.SHOPIFY_API_KEY
    SHOPIFY_API_SECRET = settings.SHOPIFY_API_SECRET
    APP_URL = settings.SHOPIFY_APP_HOST.replace("https://", "")

    APP_HOST = settings.SHOPIFY_APP_HOST

    WEBHOOK_HOST = getattr(settings, "SHOPIFY_WEBHOOK_HOST", APP_HOST)
    WEBHOOK_TOPICS = getattr(settings, "SHOPIFY_WEBHOOK_TOPICS", [])

    SHOPIFY_API_VERSION = getattr(settings, "SHOPIFY_API_VERSION", "2022-04")
    SHOPIFY_API_SCOPES = getattr(settings, "SHOPIFY_APP_SCOPES", [])
    SHOPIFY_STAFF_BYPASS = getattr(settings, "SHOPIFY_STAFF_BYPASS", False)
    SHOPIFY_STAFF_BYPASS_METHODS = getattr(settings, "SHOPIFY_STAFF_BYPASS_METHODS", None)
    SHOPIFY_STAFF_SHOP_ATTR = getattr(settings, "SHOPIFY_STAFF_SHOP_ATTR", "admin_shop")

    SHOPIFY_TOKEN_EXCHANGE = getattr(settings, "SHOPIFY_TOKEN_EXCHANGE", False)
    SHOPIFY_DASHBOARD_PATH = getattr(settings, "SHOPIFY_DASHBOARD_PATH", "/dashboard")

    def ready(self):
        return super().ready()
