"""Tests for SQLAlchemy sort specification visitor."""

import pytest

sa = pytest.importorskip("sqlalchemy")

from therismos.sorting import SortCriterion, SortOrder, SortSpec
from therismos.sorting.visitors.sqlalchemy import SQLAlchemySortSpec, SQLAlchemySortSpecVisitor


@pytest.fixture()
def visitor() -> SQLAlchemySortSpecVisitor:
    """Return a SQLAlchemySortSpecVisitor instance."""
    return SQLAlchemySortSpecVisitor()


class TestSQLAlchemySortSpecVisitorBasic:
    """Tests for basic SQLAlchemySortSpecVisitor functionality."""

    def test_result_is_sqlalchemy_sort_spec(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test that result is a SQLAlchemySortSpec."""
        spec = SortSpec([SortCriterion("age", SortOrder.ASCENDING)])
        result = spec.accept(visitor)
        assert isinstance(result, SQLAlchemySortSpec)

    def test_single_ascending_criterion(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test sort spec for single ascending criterion."""
        spec = SortSpec([SortCriterion("age", SortOrder.ASCENDING)])
        result = spec.accept(visitor)
        assert len(result.order_by) == 1
        sql = str(result.order_by[0])
        assert "age" in sql
        assert "ASC" in sql.upper()

    def test_single_descending_criterion(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test sort spec for single descending criterion."""
        spec = SortSpec([SortCriterion("name", SortOrder.DESCENDING)])
        result = spec.accept(visitor)
        assert len(result.order_by) == 1
        sql = str(result.order_by[0])
        assert "name" in sql
        assert "DESC" in sql.upper()

    def test_multiple_criteria_order_preserved(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test that multiple criteria preserve order."""
        spec = SortSpec(
            [
                SortCriterion("age", SortOrder.ASCENDING),
                SortCriterion("name", SortOrder.DESCENDING),
            ]
        )
        result = spec.accept(visitor)
        assert len(result.order_by) == 2
        assert "age" in str(result.order_by[0])
        assert "name" in str(result.order_by[1])

    def test_empty_spec_produces_empty_tuple(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test empty spec produces empty order_by tuple."""
        spec = SortSpec()
        result = spec.accept(visitor)
        assert result.order_by == ()


class TestSQLAlchemySortSpecVisitorNoneOrder:
    """Tests for handling SortOrder.NONE."""

    def test_single_none_criterion_skipped(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test that NONE order is skipped."""
        spec = SortSpec([SortCriterion("age", SortOrder.NONE)])
        result = spec.accept(visitor)
        assert result.order_by == ()

    def test_none_mixed_with_other_orders(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test that NONE orders are skipped while others are preserved."""
        spec = SortSpec(
            [
                SortCriterion("age", SortOrder.ASCENDING),
                SortCriterion("name", SortOrder.NONE),
                SortCriterion("score", SortOrder.DESCENDING),
            ]
        )
        result = spec.accept(visitor)
        assert len(result.order_by) == 2
        order_sql = [str(e) for e in result.order_by]
        assert any("age" in s for s in order_sql)
        assert not any("name" in s for s in order_sql)
        assert any("score" in s for s in order_sql)

    def test_all_none_orders_produce_empty_tuple(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test spec with all NONE orders produces empty order_by tuple."""
        spec = SortSpec(
            [
                SortCriterion("a", SortOrder.NONE),
                SortCriterion("b", SortOrder.NONE),
            ]
        )
        result = spec.accept(visitor)
        assert result.order_by == ()


@pytest.mark.parametrize(
    "criteria,expected_count,expected_fields",
    [
        ([SortCriterion("x", SortOrder.ASCENDING)], 1, ["x"]),
        ([SortCriterion("y", SortOrder.DESCENDING)], 1, ["y"]),
        (
            [SortCriterion("a", SortOrder.ASCENDING), SortCriterion("b", SortOrder.DESCENDING)],
            2,
            ["a", "b"],
        ),
        (
            [SortCriterion("a", SortOrder.ASCENDING), SortCriterion("b", SortOrder.NONE)],
            1,
            ["a"],
        ),
        ([], 0, []),
    ],
)
def test_sqlalchemy_sort_visitor_parametrized(
    criteria: list[SortCriterion],
    expected_count: int,
    expected_fields: list[str],
) -> None:
    """Parametrized test for SQLAlchemy sort visitor with various specs."""
    spec = SortSpec(criteria)
    visitor = SQLAlchemySortSpecVisitor()
    result = spec.accept(visitor)
    assert len(result.order_by) == expected_count
    order_sqls = [str(e) for e in result.order_by]
    for field in expected_fields:
        assert any(field in s for s in order_sqls)


class TestSQLAlchemySortSpecVisitorSQL:
    """Tests for generated SQL direction keywords."""

    def test_ascending_produces_asc_keyword(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test ascending criterion produces ASC in SQL."""
        spec = SortSpec([SortCriterion("price", SortOrder.ASCENDING)])
        result = spec.accept(visitor)
        sql = str(result.order_by[0])
        assert "ASC" in sql.upper()

    def test_descending_produces_desc_keyword(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test descending criterion produces DESC in SQL."""
        spec = SortSpec([SortCriterion("price", SortOrder.DESCENDING)])
        result = spec.accept(visitor)
        sql = str(result.order_by[0])
        assert "DESC" in sql.upper()

    def test_order_by_usable_in_select(self, visitor: SQLAlchemySortSpecVisitor) -> None:
        """Test that order_by elements can be passed to select().order_by()."""
        spec = SortSpec(
            [
                SortCriterion("age", SortOrder.DESCENDING),
                SortCriterion("name", SortOrder.ASCENDING),
            ]
        )
        result = spec.accept(visitor)
        t = sa.table("users", sa.column("age"), sa.column("name"))
        stmt = sa.select(t).order_by(*result.order_by)
        sql = str(stmt)
        assert "ORDER BY" in sql.upper()
        assert "age" in sql
        assert "name" in sql
