"""Tests for SQLAlchemy grouping specification visitor."""

import pytest

sa = pytest.importorskip("sqlalchemy")

from therismos.grouping import Aggregation, AggregationFunction, GroupSpec
from therismos.grouping.visitors.sqlalchemy import SQLAlchemyGroupSpec, SQLAlchemyGroupSpecVisitor


def _agg_sql(expr: object) -> str:
    """Compile an aggregation expression to SQL string with literal binds."""
    return str(expr.compile(compile_kwargs={"literal_binds": True}))  # type: ignore[union-attr]


@pytest.fixture()
def visitor() -> SQLAlchemyGroupSpecVisitor:
    """Return a SQLAlchemyGroupSpecVisitor instance."""
    return SQLAlchemyGroupSpecVisitor()


class TestSQLAlchemyGroupSpecVisitorBasic:
    """Tests for basic SQLAlchemyGroupSpecVisitor functionality."""

    def test_result_is_sqlalchemy_group_spec(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test that result is a SQLAlchemyGroupSpec."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[Aggregation("total", AggregationFunction.COUNT)],
        )
        result = spec.accept(visitor)
        assert isinstance(result, SQLAlchemyGroupSpec)

    def test_group_by_fields_preserved(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test that group_by field names are preserved in column expressions."""
        spec = GroupSpec(
            group_by=["category", "region"],
            aggregations=[Aggregation("total", AggregationFunction.COUNT)],
        )
        result = spec.accept(visitor)
        assert len(result.group_by) == 2
        group_by_sqls = [str(c) for c in result.group_by]
        assert any("category" in s for s in group_by_sqls)
        assert any("region" in s for s in group_by_sqls)

    def test_empty_group_by(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test with empty group_by produces empty tuple."""
        spec = GroupSpec(
            group_by=[],
            aggregations=[Aggregation("total", AggregationFunction.COUNT)],
        )
        result = spec.accept(visitor)
        assert result.group_by == ()

    def test_agg_count_uses_count_func(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test COUNT produces a count() SQL function."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[Aggregation("total", AggregationFunction.COUNT)],
        )
        result = spec.accept(visitor)
        assert len(result.agg) == 1
        sql = _agg_sql(result.agg[0])
        assert "count" in sql.lower()

    def test_agg_label_matches_id(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test that aggregation expression carries the aggregation id as its label name."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[Aggregation("my_total", AggregationFunction.COUNT)],
        )
        result = spec.accept(visitor)
        assert result.agg[0].name == "my_total"  # type: ignore[union-attr]

    def test_multiple_aggregations(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test multiple aggregations produce correct count of agg expressions."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[
                Aggregation("total", AggregationFunction.COUNT),
                Aggregation("avg_price", AggregationFunction.AVERAGE, "price"),
                Aggregation("max_revenue", AggregationFunction.MAX, "revenue"),
            ],
        )
        result = spec.accept(visitor)
        assert len(result.agg) == 3


class TestSQLAlchemyGroupSpecVisitorAggregations:
    """Tests for all aggregation functions."""

    @pytest.mark.parametrize(
        "func,expected_sql_fragment",
        [
            (AggregationFunction.SUM, "sum"),
            (AggregationFunction.MIN, "min"),
            (AggregationFunction.MAX, "max"),
            (AggregationFunction.AVERAGE, "avg"),
            (AggregationFunction.STDDEV, "stddev"),
        ],
    )
    def test_standard_field_aggregations(
        self,
        visitor: SQLAlchemyGroupSpecVisitor,
        func: AggregationFunction,
        expected_sql_fragment: str,
    ) -> None:
        """Test that standard field-based aggregations produce correct SQL functions."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[Aggregation("result", func, "price")],
        )
        result = spec.accept(visitor)
        assert len(result.agg) == 1
        sql = _agg_sql(result.agg[0]).lower()
        assert expected_sql_fragment in sql
        assert "price" in sql

    @pytest.mark.parametrize(
        "func,expected_quantile",
        [
            (AggregationFunction.MEDIAN, "0.5"),
            (AggregationFunction.Q1, "0.25"),
            (AggregationFunction.Q3, "0.75"),
            (AggregationFunction.P01, "0.01"),
            (AggregationFunction.P05, "0.05"),
            (AggregationFunction.P10, "0.1"),
            (AggregationFunction.P90, "0.9"),
            (AggregationFunction.P95, "0.95"),
            (AggregationFunction.P99, "0.99"),
        ],
    )
    def test_percentile_aggregations_use_percentile_cont(
        self,
        visitor: SQLAlchemyGroupSpecVisitor,
        func: AggregationFunction,
        expected_quantile: str,
    ) -> None:
        """Test percentile functions produce percentile_cont SQL with correct quantile."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[Aggregation("result", func, "price")],
        )
        result = spec.accept(visitor)
        assert len(result.agg) == 1
        sql = _agg_sql(result.agg[0]).lower()
        assert "percentile_cont" in sql
        assert expected_quantile in sql

    def test_percentile_aggregation_uses_within_group(
        self, visitor: SQLAlchemyGroupSpecVisitor
    ) -> None:
        """Test MEDIAN uses WITHIN GROUP clause for ordered-set aggregate."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[Aggregation("med", AggregationFunction.MEDIAN, "price")],
        )
        result = spec.accept(visitor)
        sql = _agg_sql(result.agg[0]).upper()
        assert "WITHIN GROUP" in sql

    def test_count_does_not_reference_field(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test COUNT produces count() without referencing a specific field."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[Aggregation("total", AggregationFunction.COUNT)],
        )
        result = spec.accept(visitor)
        sql = _agg_sql(result.agg[0])
        assert "price" not in sql
        assert "count" in sql.lower()


class TestSQLAlchemyGroupSpecVisitorSelectUsage:
    """Tests that group spec elements can be used in a SQLAlchemy select statement."""

    def test_group_by_usable_in_select(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test that group_by and agg can be passed to select().group_by()."""
        spec = GroupSpec(
            group_by=["category"],
            aggregations=[
                Aggregation("total", AggregationFunction.COUNT),
                Aggregation("avg_price", AggregationFunction.AVERAGE, "price"),
            ],
        )
        grp = spec.accept(visitor)
        stmt = sa.select(*grp.group_by, *grp.agg).group_by(*grp.group_by)
        sql = str(stmt)
        assert "category" in sql
        assert "GROUP BY" in sql.upper()
        assert "count" in sql.lower()
        assert "avg" in sql.lower()

    def test_multi_group_by_in_select(self, visitor: SQLAlchemyGroupSpecVisitor) -> None:
        """Test multiple group_by fields in select statement."""
        spec = GroupSpec(
            group_by=["category", "region"],
            aggregations=[Aggregation("total", AggregationFunction.COUNT)],
        )
        grp = spec.accept(visitor)
        stmt = sa.select(*grp.group_by, *grp.agg).group_by(*grp.group_by)
        sql = str(stmt)
        assert "category" in sql
        assert "region" in sql
        assert "GROUP BY" in sql.upper()
