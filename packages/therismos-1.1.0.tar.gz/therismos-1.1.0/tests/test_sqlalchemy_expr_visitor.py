"""Tests for SQLAlchemy expression visitor."""

import re

import pytest

sa = pytest.importorskip("sqlalchemy")

from therismos import F
from therismos.expr._expr import FALSE, TRUE, AllExpr, AnyExpr
from therismos.expr.visitors.sqlalchemy import SQLAlchemyExprVisitor


def _sql(expr: object) -> str:
    """Compile a SQLAlchemy expression to a SQL string with literal binds."""
    return str(expr.compile(compile_kwargs={"literal_binds": True}))  # type: ignore[union-attr]


@pytest.fixture()
def visitor() -> SQLAlchemyExprVisitor:
    """Return a SQLAlchemyExprVisitor instance."""
    return SQLAlchemyExprVisitor()


class TestSQLAlchemyExprVisitorComparisons:
    """Tests for comparison expression conversions."""

    def test_eq_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test that Eq produces a SQLAlchemy ColumnElement."""
        expr = F("age") == 20
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_ne_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test that Ne produces a SQLAlchemy ColumnElement."""
        expr = F("age") != 20
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_lt_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test that Lt produces a SQLAlchemy ColumnElement."""
        expr = F("age") < 20
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_le_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test that Le produces a SQLAlchemy ColumnElement."""
        expr = F("age") <= 20
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_gt_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test that Gt produces a SQLAlchemy ColumnElement."""
        expr = F("age") > 20
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_ge_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test that Ge produces a SQLAlchemy ColumnElement."""
        expr = F("age") >= 20
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    @pytest.mark.parametrize(
        "therismos_expr,expected_sql_fragment",
        [
            (F("age") == 20, "age = 20"),
            (F("age") != 20, "age != 20"),
            (F("age") < 20, "age < 20"),
            (F("age") <= 20, "age <= 20"),
            (F("age") > 20, "age > 20"),
            (F("age") >= 20, "age >= 20"),
        ],
    )
    def test_comparison_sql(
        self,
        visitor: SQLAlchemyExprVisitor,
        therismos_expr: object,
        expected_sql_fragment: str,
    ) -> None:
        """Test that comparison expressions produce the expected SQL fragments."""
        result = therismos_expr.accept(visitor)  # type: ignore[union-attr]
        assert expected_sql_fragment in _sql(result)


class TestSQLAlchemyExprVisitorBetween:
    """Tests for Between expression conversion."""

    def test_between_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test that Between produces a SQLAlchemy ColumnElement."""
        from therismos.expr._expr import Between

        expr = Between(F("age"), 18, 30)
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_between_half_open_semantics(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test Between uses half-open [lower, upper) semantics, not inclusive BETWEEN."""
        from therismos.expr._expr import Between

        expr = Between(F("age"), 18, 30)
        sql = _sql(expr.accept(visitor))
        assert "age >= 18" in sql
        assert "age < 30" in sql
        assert "BETWEEN" not in sql.upper()

    def test_between_string_sql(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test Between with string values."""
        from therismos.expr._expr import Between

        expr = Between(F("name"), "a", "m")
        sql = _sql(expr.accept(visitor))
        assert "name >= " in sql
        assert "name < " in sql


class TestSQLAlchemyExprVisitorRegex:
    """Tests for regex expression conversion."""

    def test_regex_without_flags_produces_column_element(
        self, visitor: SQLAlchemyExprVisitor
    ) -> None:
        """Test regex match without flags produces a ColumnElement."""
        expr = F("name").matches(r"^Alice$")
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_regex_case_insensitive_inline_modifier(
        self, visitor: SQLAlchemyExprVisitor
    ) -> None:
        """Test IGNORECASE flag converts to inline (?i) modifier."""
        expr = F("name").matches(r"alice", flags=re.IGNORECASE)
        result = expr.accept(visitor)
        sql = _sql(result)
        assert "(?i)" in sql

    def test_regex_multiline_inline_modifier(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test MULTILINE flag converts to inline (?m) modifier."""
        expr = F("text").matches(r"^line", flags=re.MULTILINE)
        result = expr.accept(visitor)
        sql = _sql(result)
        assert "(?m)" in sql

    def test_regex_dotall_inline_modifier(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test DOTALL flag converts to inline (?s) modifier."""
        expr = F("text").matches(r"a.b", flags=re.DOTALL)
        result = expr.accept(visitor)
        sql = _sql(result)
        assert "(?s)" in sql

    def test_regex_combined_flags(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test combined flags produce multiple inline modifiers."""
        expr = F("text").matches(r"hello", flags=re.IGNORECASE | re.MULTILINE)
        result = expr.accept(visitor)
        sql = _sql(result)
        assert "(?im)" in sql

    def test_regex_no_flags_no_modifier(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test regex without flags does not add any inline modifier."""
        expr = F("name").matches(r"Alice")
        result = expr.accept(visitor)
        sql = _sql(result)
        assert "(?i)" not in sql
        assert "(?m)" not in sql
        assert "(?s)" not in sql


class TestSQLAlchemyExprVisitorIn:
    """Tests for IN expression conversion."""

    def test_in_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test IN expression produces a ColumnElement."""
        expr = F("tag").is_in("python", "java")
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_in_sql_contains_values(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test IN expression SQL contains the correct values."""
        expr = F("tag").is_in("python", "java")
        sql = _sql(expr.accept(visitor))
        assert "python" in sql
        assert "java" in sql
        assert "IN" in sql.upper()

    def test_in_single_value(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test IN expression with single value."""
        expr = F("status").is_in("active")
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)


class TestSQLAlchemyExprVisitorIsNull:
    """Tests for IsNull expression conversion."""

    def test_is_null_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test IsNull produces a ColumnElement."""
        expr = F("nullable").is_null()
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_is_null_sql(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test IsNull produces IS NULL SQL."""
        expr = F("nullable").is_null()
        sql = _sql(expr.accept(visitor))
        assert "IS NULL" in sql.upper()

    def test_is_not_null_sql(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test IsNull(is_null=False) produces IS NOT NULL SQL."""
        expr = F("nullable").is_not_null()
        sql = _sql(expr.accept(visitor))
        assert "IS NOT NULL" in sql.upper()


class TestSQLAlchemyExprVisitorConstants:
    """Tests for TrueExpr and FalseExpr conversion."""

    def test_true_expr_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test TrueExpr produces a ColumnElement."""
        result = TRUE.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_false_expr_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test FalseExpr produces a ColumnElement."""
        result = FALSE.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_true_expr_sql(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test TrueExpr produces a truthy SQL literal."""
        sql = _sql(TRUE.accept(visitor))
        assert "true" in sql.lower() or sql.strip() == "1"

    def test_false_expr_sql(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test FalseExpr produces a falsy SQL literal."""
        sql = _sql(FALSE.accept(visitor))
        assert "false" in sql.lower() or sql.strip() == "0"


class TestSQLAlchemyExprVisitorLogical:
    """Tests for logical expression conversion (AND, OR, NOT)."""

    def test_all_expr_produces_column_element(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test AllExpr produces a ColumnElement."""
        expr = (F("age") > 18) & (F("status") == "active")
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_all_expr_sql_contains_and(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test AllExpr produces SQL with AND."""
        expr = (F("age") > 18) & (F("status") == "active")
        sql = _sql(expr.accept(visitor))
        assert "AND" in sql.upper()

    def test_any_expr_sql_contains_or(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test AnyExpr produces SQL with OR."""
        expr = (F("age") > 25) | (F("status") == "inactive")
        sql = _sql(expr.accept(visitor))
        assert "OR" in sql.upper()

    def test_not_expr_sql_contains_not(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test NotExpr on a compound expression produces SQL with NOT."""
        expr = ~((F("age") > 18) & (F("status") == "active"))
        sql = _sql(expr.accept(visitor))
        assert "NOT" in sql.upper()

    def test_empty_all_expr_returns_true(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test empty AllExpr returns sqlalchemy.true()."""
        result = AllExpr().accept(visitor)
        sql = _sql(result)
        assert "true" in sql.lower() or sql.strip() == "1"

    def test_empty_any_expr_returns_false(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test empty AnyExpr returns sqlalchemy.false()."""
        result = AnyExpr().accept(visitor)
        sql = _sql(result)
        assert "false" in sql.lower() or sql.strip() == "0"

    def test_nested_logical_produces_column_element(
        self, visitor: SQLAlchemyExprVisitor
    ) -> None:
        """Test nested logical expressions produce a ColumnElement."""
        expr = ((F("age") >= 20) & (F("age") <= 25)) | (F("name") == "Bob")
        result = expr.accept(visitor)
        assert isinstance(result, sa.sql.elements.ColumnElement)

    def test_complex_query_sql(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test a complex expression compiles to valid SQL."""
        expr = ((F("age") >= 18) & (F("status") == "active")) | ~((F("name") == "Admin") & (F("role") == "superuser"))
        sql = _sql(expr.accept(visitor))
        assert "AND" in sql.upper()
        assert "OR" in sql.upper()
        assert "NOT" in sql.upper()


class TestSQLAlchemyExprVisitorTemplate:
    """Tests that unbound template parameters raise errors."""

    def test_eq_unbound_param_raises(self, visitor: SQLAlchemyExprVisitor) -> None:
        """Test that an unbound template param in Eq raises UnboundTemplateParamError."""
        from therismos.expr._expr import TemplateParam, UnboundTemplateParamError

        expr = F("age") == TemplateParam("age_val")
        with pytest.raises(UnboundTemplateParamError):
            expr.accept(visitor)
