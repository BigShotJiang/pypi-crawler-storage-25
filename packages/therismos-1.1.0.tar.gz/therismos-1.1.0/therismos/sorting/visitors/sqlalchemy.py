"""SQLAlchemy sort specification visitor for therismos sorting.

This module provides a visitor that converts therismos sort specifications into
SQLAlchemy-compatible ORDER BY parameters via the SQLAlchemySortSpec dataclass.

Requires SQLAlchemy to be installed. Install with: pip install therismos[sqlalchemy]

Example
-------
>>> from therismos.sorting import SortSpec, SortCriterion, SortOrder
>>> from therismos.sorting.visitors.sqlalchemy import SQLAlchemySortSpecVisitor
>>>
>>> spec = SortSpec([
...     SortCriterion("age", SortOrder.ASCENDING),
...     SortCriterion("name", SortOrder.DESCENDING),
... ])
>>>
>>> visitor = SQLAlchemySortSpecVisitor()
>>> sort = spec.accept(visitor)
>>>
>>> # Use with Core select
>>> # stmt = select(t).order_by(*sort.order_by)
>>>
>>> # Use with ORM session
>>> # session.query(User).order_by(*sort.order_by)

Notes
-----
- ASCENDING maps to col.asc(), DESCENDING maps to col.desc().
- SortOrder.NONE criteria are skipped and not included in the result.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

try:
    import sqlalchemy as sa
    from sqlalchemy.sql.elements import UnaryExpression
except ImportError as exc:
    msg = "sqlalchemy is required. Install with: pip install therismos[sqlalchemy]"
    raise ImportError(msg) from exc

from therismos.sorting._sorting import SortOrder, SortSpec


@dataclass
class SQLAlchemySortSpec:
    """Dataclass holding SQLAlchemy ORDER BY parameters.

    Not frozen because UnaryExpression is not hashable.

    :ivar order_by: Tuple of SQLAlchemy unary expressions for ordering.
    :vartype order_by: tuple[UnaryExpression[Any], ...]

    Example
    -------
    >>> from sqlalchemy import select, table, column as col
    >>> sort = SQLAlchemySortSpec(
    ...     order_by=(col("age").asc(), col("name").desc()),
    ... )
    >>> t = table("users", col("age"), col("name"))
    >>> stmt = select(t).order_by(*sort.order_by)
    """

    order_by: tuple[UnaryExpression[Any], ...] = field(default_factory=tuple)


class SQLAlchemySortSpecVisitor:
    """Visitor that converts sort specifications to SQLAlchemy ORDER BY parameters.

    This visitor traverses sort specifications and generates a SQLAlchemySortSpec
    dataclass that can be passed to select().order_by() or query.order_by().

    Example
    -------
    >>> from sqlalchemy import select, table, column as col
    >>> from therismos.sorting import SortSpec, SortCriterion, SortOrder
    >>> from therismos.sorting.visitors.sqlalchemy import SQLAlchemySortSpecVisitor
    >>>
    >>> spec = SortSpec([
    ...     SortCriterion("age", SortOrder.DESCENDING),
    ...     SortCriterion("name", SortOrder.ASCENDING),
    ... ])
    >>>
    >>> visitor = SQLAlchemySortSpecVisitor()
    >>> sort = spec.accept(visitor)
    >>> t = table("users", col("age"), col("name"))
    >>> stmt = select(t).order_by(*sort.order_by)
    """

    def visit_sort_spec(self, spec: SortSpec) -> SQLAlchemySortSpec:
        """Convert a sort specification to SQLAlchemy ORDER BY parameters.

        Criteria with SortOrder.NONE are skipped.

        :param spec: The sort specification to visit.
        :type spec: SortSpec
        :returns: SQLAlchemySortSpec with a tuple of ordering expressions.
        :rtype: SQLAlchemySortSpec
        """
        order_by: list[UnaryExpression[Any]] = []

        for criterion in spec:
            if criterion.order == SortOrder.NONE:
                continue
            col = sa.column(criterion.field)
            if criterion.order == SortOrder.DESCENDING:
                order_by.append(col.desc())
            else:
                order_by.append(col.asc())

        return SQLAlchemySortSpec(order_by=tuple(order_by))


__all__ = [
    "SQLAlchemySortSpec",
    "SQLAlchemySortSpecVisitor",
]
