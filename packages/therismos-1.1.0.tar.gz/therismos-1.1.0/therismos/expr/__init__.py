"""Expression module for therismos query modeling library.

This module provides the core expression AST (Abstract Syntax Tree) implementation
for modeling generic queries and filters in a backend-agnostic way.

Submodules:
    - therismos.expr._expr: Core expression classes and types
    - therismos.expr.optimizer: Expression optimization and simplification
    - therismos.expr.pruning: Field pruning and projection utilities
    - therismos.expr.visitors: Built-in visitor implementations
    - therismos.expr.serializer: String serialization and deserialization

The expression module supports:
    - Atomic expressions: Eq, Ne, Lt, Le, Gt, Ge, Between, Regex, In, IsNull
    - Compound expressions: AllExpr (AND), AnyExpr (OR), NotExpr (NOT)
    - Logical constants: TRUE, FALSE
    - Type-safe fields with optional casting
    - Visitor pattern for extensible conversions
    - Grammar-based serialization to/from strings
    - Field pruning and projection with polarity-aware substitution
"""

from therismos.expr._expr import (
    FALSE,
    TRUE,
    AllExpr,
    AnyExpr,
    AtomicExpr,
    AtomicExprType,
    Between,
    BooleanLogicExpr,
    ComparisonExpr,
    ComparisonExprUnion,
    CompositeExpr,
    CompositeExprType,
    ConstantExpr,
    DecoratorExpr,
    DecoratorExprType,
    Eq,
    Expr,
    ExprVisitor,
    F,
    FalseExpr,
    Field,
    FieldBasedAtomicExprUnion,
    FieldBasedExpr,
    Ge,
    Gt,
    In,
    IsNull,
    Le,
    LogicalExpr,
    Lt,
    MultiValuedAtomicExprUnion,
    MultiValuedFieldExpr,
    Ne,
    NotExpr,
    Regex,
    SingleValuedAtomicExprUnion,
    SingleValuedFieldExpr,
    TemplateParam,
    TrueExpr,
    UnboundTemplateParamError,
    UnwoundValue,
    unwind_data,
)
from therismos.expr.pruning import FieldSelection, PruneMode, prune_fields
from therismos.expr.serializer import Serializer
from therismos.expr.template import (
    ExprTemplate,
    MissingParamError,
    ParamRule,
    TemplateParamSpec,
    TransformStep,
    bind,
    collect_params,
)
from therismos.expr.transforms import DEFAULT_TRANSFORM_REGISTRY, TransformRegistry

__all__ = [
    "Expr",
    "AtomicExpr",
    "FieldBasedExpr",
    "SingleValuedFieldExpr",
    "ComparisonExpr",
    "MultiValuedFieldExpr",
    "CompositeExpr",
    "DecoratorExpr",
    "Field",
    "F",
    "ExprVisitor",
    "UnwoundValue",
    "unwind_data",
    "Eq",
    "Ne",
    "Lt",
    "Le",
    "Gt",
    "Ge",
    "Between",
    "Regex",
    "In",
    "IsNull",
    "TrueExpr",
    "FalseExpr",
    "TRUE",
    "FALSE",
    "AllExpr",
    "AnyExpr",
    "NotExpr",
    "ComparisonExprUnion",
    "SingleValuedAtomicExprUnion",
    "MultiValuedAtomicExprUnion",
    "FieldBasedAtomicExprUnion",
    "ConstantExpr",
    "AtomicExprType",
    "CompositeExprType",
    "DecoratorExprType",
    "LogicalExpr",
    "BooleanLogicExpr",
    "Serializer",
    "TemplateParam",
    "UnboundTemplateParamError",
    "MissingParamError",
    "TemplateParamSpec",
    "TransformStep",
    "ParamRule",
    "ExprTemplate",
    "bind",
    "collect_params",
    "TransformRegistry",
    "DEFAULT_TRANSFORM_REGISTRY",
    "FieldSelection",
    "PruneMode",
    "prune_fields",
]
