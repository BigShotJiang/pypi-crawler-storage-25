"""SQLAlchemy expression visitor for therismos expressions.

This module provides a visitor that converts therismos expressions into SQLAlchemy
column elements compatible with Core queries, ORM queries, and SQLModel.

Requires SQLAlchemy to be installed. Install with: pip install therismos[sqlalchemy]

Example
-------
>>> from therismos import F
>>> from therismos.expr.visitors.sqlalchemy import SQLAlchemyExprVisitor
>>>
>>> age = F("age")
>>> status = F("status")
>>> expr = (age > 18) & (status == "active")
>>>
>>> visitor = SQLAlchemyExprVisitor()
>>> where_clause = expr.accept(visitor)
>>>
>>> # Use with Core select
>>> # from sqlalchemy import select, table
>>> # stmt = select(t).where(where_clause)
>>>
>>> # Use with ORM session
>>> # session.query(User).filter(where_clause)

Notes
-----
- Regex flags are converted to inline modifiers ((?i), (?m), (?s)); regexp_match
  support depends on the target database dialect.
- Between uses half-open semantics [lower, upper), matching therismos behaviour.
  SQLAlchemy's built-in between() is inclusive on both ends and is not used here.
- TrueExpr converts to sqlalchemy.true(), FalseExpr to sqlalchemy.false().
- Empty AllExpr returns sqlalchemy.true(), empty AnyExpr returns sqlalchemy.false().
"""

from __future__ import annotations

import re
from typing import Any

try:
    import sqlalchemy as sa
    from sqlalchemy.sql.elements import ColumnElement
except ImportError as exc:
    msg = "sqlalchemy is required. Install with: pip install therismos[sqlalchemy]"
    raise ImportError(msg) from exc

from therismos.expr._expr import (
    AllExpr,
    AnyExpr,
    Between,
    Eq,
    FalseExpr,
    Ge,
    Gt,
    In,
    IsNull,
    Le,
    Lt,
    Ne,
    NotExpr,
    Regex,
    TrueExpr,
)
from therismos.expr.visitors._visitors import _check_value


class SQLAlchemyExprVisitor:
    """Visitor that converts therismos expressions to SQLAlchemy column elements.

    This visitor traverses expression trees and generates SQLAlchemy
    ``ColumnElement[bool]`` objects that can be used as WHERE clause predicates
    in Core selects, ORM queries, and SQLModel statements.

    Example
    -------
    >>> from sqlalchemy import create_engine, select, table, column as col
    >>> from therismos import F
    >>> from therismos.expr.visitors.sqlalchemy import SQLAlchemyExprVisitor
    >>>
    >>> age = F("age")
    >>> name = F("name")
    >>> expr = (age >= 21) & (name == "Alice")
    >>>
    >>> visitor = SQLAlchemyExprVisitor()
    >>> where_clause = expr.accept(visitor)
    >>> t = table("users", col("age"), col("name"))
    >>> stmt = select(t).where(where_clause)
    """

    def visit_eq(self, expr: Eq) -> ColumnElement[bool]:
        """Convert equality expression to SQLAlchemy predicate.

        :param expr: Equality expression.
        :type expr: Eq
        :returns: SQLAlchemy predicate ``column(field) == value``.
        :rtype: ColumnElement[bool]
        """
        val = _check_value(expr.casted_value(), f"Eq({expr.field.name})")
        return sa.column(expr.field.name) == val  # type: ignore[no-any-return]

    def visit_ne(self, expr: Ne) -> ColumnElement[bool]:
        """Convert inequality expression to SQLAlchemy predicate.

        :param expr: Inequality expression.
        :type expr: Ne
        :returns: SQLAlchemy predicate ``column(field) != value``.
        :rtype: ColumnElement[bool]
        """
        val = _check_value(expr.casted_value(), f"Ne({expr.field.name})")
        return sa.column(expr.field.name) != val  # type: ignore[no-any-return]

    def visit_lt(self, expr: Lt) -> ColumnElement[bool]:
        """Convert less-than expression to SQLAlchemy predicate.

        :param expr: Less-than expression.
        :type expr: Lt
        :returns: SQLAlchemy predicate ``column(field) < value``.
        :rtype: ColumnElement[bool]
        """
        val = _check_value(expr.casted_value(), f"Lt({expr.field.name})")
        return sa.column(expr.field.name) < val  # type: ignore[no-any-return]

    def visit_le(self, expr: Le) -> ColumnElement[bool]:
        """Convert less-than-or-equal expression to SQLAlchemy predicate.

        :param expr: Less-than-or-equal expression.
        :type expr: Le
        :returns: SQLAlchemy predicate ``column(field) <= value``.
        :rtype: ColumnElement[bool]
        """
        val = _check_value(expr.casted_value(), f"Le({expr.field.name})")
        return sa.column(expr.field.name) <= val  # type: ignore[no-any-return]

    def visit_gt(self, expr: Gt) -> ColumnElement[bool]:
        """Convert greater-than expression to SQLAlchemy predicate.

        :param expr: Greater-than expression.
        :type expr: Gt
        :returns: SQLAlchemy predicate ``column(field) > value``.
        :rtype: ColumnElement[bool]
        """
        val = _check_value(expr.casted_value(), f"Gt({expr.field.name})")
        return sa.column(expr.field.name) > val  # type: ignore[no-any-return]

    def visit_ge(self, expr: Ge) -> ColumnElement[bool]:
        """Convert greater-than-or-equal expression to SQLAlchemy predicate.

        :param expr: Greater-than-or-equal expression.
        :type expr: Ge
        :returns: SQLAlchemy predicate ``column(field) >= value``.
        :rtype: ColumnElement[bool]
        """
        val = _check_value(expr.casted_value(), f"Ge({expr.field.name})")
        return sa.column(expr.field.name) >= val  # type: ignore[no-any-return]

    def visit_between(self, expr: Between) -> ColumnElement[bool]:
        """Convert between expression to a SQLAlchemy half-open range predicate.

        Uses ``(col >= lower) AND (col < upper)`` to match therismos half-open
        semantics [lower, upper). SQLAlchemy's built-in ``between()`` is inclusive
        on both ends and is intentionally not used here.

        :param expr: Between expression (lower <= field < upper).
        :type expr: Between
        :returns: SQLAlchemy predicate ``(col >= lower) AND (col < upper)``.
        :rtype: ColumnElement[bool]
        """
        col = sa.column(expr.field.name)
        lower = _check_value(expr.casted_lower(), f"Between({expr.field.name}).lower")
        upper = _check_value(expr.casted_upper(), f"Between({expr.field.name}).upper")
        return sa.and_(col >= lower, col < upper)  # type: ignore[no-any-return]

    def visit_regex(self, expr: Regex) -> ColumnElement[bool]:
        """Convert regex expression to SQLAlchemy regexp_match predicate.

        Regex flags are converted to inline modifiers prepended to the pattern:

        - re.IGNORECASE -> (?i)
        - re.MULTILINE -> (?m)
        - re.DOTALL -> (?s)

        .. note::
            ``regexp_match`` support and inline modifier syntax depend on the
            target database dialect (e.g. PostgreSQL, SQLite 3.8.3+, MySQL 8.0+).

        :param expr: Regex expression.
        :type expr: Regex
        :returns: SQLAlchemy regexp_match predicate.
        :rtype: ColumnElement[bool]
        """
        pattern = expr.value

        if expr.flags is not None:
            modifiers = ""
            if expr.flags & re.IGNORECASE:
                modifiers += "i"
            if expr.flags & re.MULTILINE:
                modifiers += "m"
            if expr.flags & re.DOTALL:
                modifiers += "s"
            if modifiers:
                pattern = f"(?{modifiers}){pattern}"

        return sa.column(expr.field.name).regexp_match(pattern)  # type: ignore[no-any-return]

    def visit_in(self, expr: In) -> ColumnElement[bool]:
        """Convert IN expression to SQLAlchemy in_ predicate.

        :param expr: IN expression.
        :type expr: In
        :returns: SQLAlchemy predicate using in_.
        :rtype: ColumnElement[bool]
        """
        casted_values = [
            _check_value(expr.field.cast(v), f"In({expr.field.name})") for v in expr.values
        ]
        return sa.column(expr.field.name).in_(casted_values)  # type: ignore[no-any-return]

    def visit_is_null(self, expr: IsNull) -> ColumnElement[bool]:
        """Convert null-check expression to SQLAlchemy IS NULL / IS NOT NULL predicate.

        :param expr: Null-check expression.
        :type expr: IsNull
        :returns: SQLAlchemy predicate using is_ or is_not.
        :rtype: ColumnElement[bool]
        """
        col = sa.column(expr.field.name)
        if expr.is_null:
            return col.is_(None)  # type: ignore[no-any-return]
        return col.is_not(None)  # type: ignore[no-any-return]

    def visit_true(self, expr: TrueExpr) -> ColumnElement[bool]:
        """Convert TRUE constant to SQLAlchemy true().

        :param expr: TRUE expression.
        :type expr: TrueExpr
        :returns: sqlalchemy.true().
        :rtype: ColumnElement[bool]
        """
        return sa.true()  # type: ignore[no-any-return]

    def visit_false(self, expr: FalseExpr) -> ColumnElement[bool]:
        """Convert FALSE constant to SQLAlchemy false().

        :param expr: FALSE expression.
        :type expr: FalseExpr
        :returns: sqlalchemy.false().
        :rtype: ColumnElement[bool]
        """
        return sa.false()  # type: ignore[no-any-return]

    def visit_all(self, expr: AllExpr) -> ColumnElement[bool]:
        """Convert AND expression to SQLAlchemy and_ predicate.

        An empty AllExpr returns sqlalchemy.true().

        :param expr: AND expression.
        :type expr: AllExpr
        :returns: SQLAlchemy predicate using and_.
        :rtype: ColumnElement[bool]
        """
        sub_exprs: list[Any] = [child.accept(self) for child in expr.exprs]
        if not sub_exprs:
            return sa.true()  # type: ignore[no-any-return]
        return sa.and_(*sub_exprs)  # type: ignore[no-any-return]

    def visit_any(self, expr: AnyExpr) -> ColumnElement[bool]:
        """Convert OR expression to SQLAlchemy or_ predicate.

        An empty AnyExpr returns sqlalchemy.false().

        :param expr: OR expression.
        :type expr: AnyExpr
        :returns: SQLAlchemy predicate using or_.
        :rtype: ColumnElement[bool]
        """
        sub_exprs: list[Any] = [child.accept(self) for child in expr.exprs]
        if not sub_exprs:
            return sa.false()  # type: ignore[no-any-return]
        return sa.or_(*sub_exprs)  # type: ignore[no-any-return]

    def visit_not(self, expr: NotExpr) -> ColumnElement[bool]:
        """Convert NOT expression to SQLAlchemy not_ predicate.

        :param expr: NOT expression.
        :type expr: NotExpr
        :returns: SQLAlchemy predicate using not_.
        :rtype: ColumnElement[bool]
        """
        return sa.not_(expr.expr.accept(self))  # type: ignore[no-any-return]


__all__ = [
    "SQLAlchemyExprVisitor",
]
