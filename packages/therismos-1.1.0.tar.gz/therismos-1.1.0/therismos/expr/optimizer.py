"""Optimizer module for simplifying and optimizing expression trees.

This module provides optimization capabilities for detecting contradictions,
tautologies, and simplification opportunities in expression trees.

.. note::
    - The optimizer assumes single-valued semantics for comparison expressions.
    - Optimization rules are conservative and remain correct for multi-valued fields,
      but may miss some optimization opportunities in those cases.
    - Contradiction detection for :class:`Eq`, :class:`Ne`, :class:`Lt`, :class:`Le`,
      :class:`Gt`, :class:`Ge`, :class:`Between`
      assumes single values.
"""

from __future__ import annotations

from typing import Any

from therismos._shared import OptimizationRecord
from therismos.expr import (
    FALSE,
    TRUE,
    AllExpr,
    AnyExpr,
    Between,
    Eq,
    Expr,
    FalseExpr,
    Field,
    Ge,
    Gt,
    In,
    IsNull,
    Le,
    Lt,
    Ne,
    NotExpr,
    TrueExpr,
)
from therismos.expr._expr import UnboundTemplateParamError


def optimize(
    expr: Expr, records: list[OptimizationRecord[Expr]] | None = None
) -> tuple[Expr, list[OptimizationRecord[Expr]]]:
    """Optimize an expression tree by applying simplification rules.

    :param expr: The expression to be optimized.
    :type expr: Expr
    :param records: An optional list to collect optimization records.
                    If ``None``, a new list is created.
    :type records: list[OptimizationRecord[Expr]] | None
    :return: A tuple containing the optimized expression and a list of optimization records.
    :rtype: tuple[Expr, list[OptimizationRecord[Expr]]]
    """
    if records is None:
        records = []

    from therismos.expr.template import collect_params

    unbound = collect_params(expr)
    if unbound:
        raise UnboundTemplateParamError(
            f"Cannot optimize a template expression with unbound parameters: "
            f"{sorted(unbound)}. Call bind() first."
        )

    def _record(
        records_list: list[OptimizationRecord[Expr]],
        before: Expr,
        after: Expr,
        reason: str,
    ) -> None:
        reason = reason.strip()
        records_list.append(OptimizationRecord(before, after, reason))

    def _optimize_expr(e: Expr, _records: list[OptimizationRecord[Expr]]) -> Expr:
        """Recursively optimize an expression."""
        if isinstance(e, NotExpr):
            optimized_child = _optimize_expr(e.expr, _records)
            if optimized_child is not e.expr:
                new_expr: Expr = NotExpr(optimized_child)
                if new_expr != e:
                    _record(_records, e, new_expr, "Optimize child in NOT")
                    e = new_expr
        elif isinstance(e, AllExpr):
            optimized_children = tuple(_optimize_expr(child, _records) for child in e.exprs)
            if optimized_children != e.exprs:
                new_expr = AllExpr(*optimized_children)
                if new_expr != e:
                    _record(_records, e, new_expr, "Optimize children in AND")
                    e = new_expr
        elif isinstance(e, AnyExpr):
            optimized_children = tuple(_optimize_expr(child, _records) for child in e.exprs)
            if optimized_children != e.exprs:
                new_expr = AnyExpr(*optimized_children)
                if new_expr != e:
                    _record(_records, e, new_expr, "Optimize children in OR")
                    e = new_expr

        while True:
            optimized = _apply_rules(e, _records)
            if optimized is e:
                break
            e = _optimize_expr(optimized, _records)

        return e

    def _apply_rules(e: Expr, _records: list[OptimizationRecord[Expr]]) -> Expr:
        """Apply a single optimization rule if applicable."""
        if isinstance(e, Between):
            return _optimize_between(e, _records)

        if isinstance(e, In):
            return _optimize_in(e, _records)

        if isinstance(e, NotExpr):
            return _optimize_not(e, _records)

        if isinstance(e, AllExpr):
            return _optimize_all(e, _records)

        if isinstance(e, AnyExpr):
            return _optimize_any(e, _records)

        return e

    def _optimize_between(e: Between, _records: list[OptimizationRecord[Expr]]) -> Expr:
        """Optimize Between expressions with empty ranges."""
        try:
            if e.casted_lower() >= e.casted_upper():
                _record(_records, e, FALSE, "Between with lower >= upper → FALSE")
                return FALSE
        except TypeError:
            pass
        return e

    def _optimize_in(e: In, _records: list[OptimizationRecord[Expr]]) -> Expr:
        """Optimize IN expressions."""
        if not e.values:
            _record(_records, e, FALSE, "IN with empty set → FALSE")
            return FALSE

        if len(e.values) == 1:
            result = Eq(e.field, e.values[0])
            _record(_records, e, result, "IN with single value → Eq")
            return result

        return e

    def _optimize_not(e: NotExpr, _records: list[OptimizationRecord[Expr]]) -> Expr:
        """Optimize NOT expressions."""
        if isinstance(e.expr, TrueExpr):
            _record(_records, e, FALSE, "NOT(TRUE) → FALSE")
            return FALSE

        if isinstance(e.expr, FalseExpr):
            _record(_records, e, TRUE, "NOT(FALSE) → TRUE")
            return TRUE

        if isinstance(e.expr, NotExpr):
            result = e.expr.expr
            _record(_records, e, result, "NOT(NOT(x)) → x")
            return result

        if isinstance(e.expr, Eq):
            result = Ne(e.expr.field, e.expr.value)
            _record(_records, e, result, "NOT(a == v) → a != v")
            return result

        if isinstance(e.expr, Ne):
            result = Eq(e.expr.field, e.expr.value)
            _record(_records, e, result, "NOT(a != v) → a == v")
            return result

        if isinstance(e.expr, Lt):
            result = Ge(e.expr.field, e.expr.value)
            _record(_records, e, result, "NOT(a < v) → a >= v")
            return result

        if isinstance(e.expr, Le):
            result = Gt(e.expr.field, e.expr.value)
            _record(_records, e, result, "NOT(a <= v) → a > v")
            return result

        if isinstance(e.expr, Gt):
            result = Le(e.expr.field, e.expr.value)
            _record(_records, e, result, "NOT(a > v) → a <= v")
            return result

        if isinstance(e.expr, Ge):
            result = Lt(e.expr.field, e.expr.value)
            _record(_records, e, result, "NOT(a >= v) → a < v")
            return result

        if isinstance(e.expr, IsNull):
            result = IsNull(e.expr.field, not e.expr.is_null)
            _record(
                _records,
                e,
                result,
                "NOT(IS NULL) → IS NOT NULL" if e.expr.is_null else "NOT(IS NOT NULL) → IS NULL",
            )
            return result

        if isinstance(e.expr, AllExpr):
            result = AnyExpr(*[NotExpr(child) for child in e.expr.exprs])
            _record(_records, e, result, "De Morgan's law: NOT(AND(...)) → OR(NOT(...))")
            return result

        if isinstance(e.expr, AnyExpr):
            result = AllExpr(*[NotExpr(child) for child in e.expr.exprs])
            _record(_records, e, result, "De Morgan's law: NOT(OR(...)) → AND(NOT(...))")
            return result

        return e

    def _optimize_all(e: AllExpr, _records: list[OptimizationRecord[Expr]]) -> Expr:
        """Optimize AllExpr (AND) expressions."""
        if not e.exprs:
            _record(_records, e, TRUE, "AllExpr([]) → TRUE")
            return TRUE

        if len(e.exprs) == 1:
            result = e.exprs[0]
            _record(_records, e, result, "AllExpr([x]) → x")
            return result

        if any(isinstance(child, FalseExpr) for child in e.exprs):
            _record(_records, e, FALSE, "AllExpr([..., FALSE, ...]) → FALSE")
            return FALSE

        filtered = tuple(child for child in e.exprs if not isinstance(child, TrueExpr))
        if len(filtered) != len(e.exprs):
            if not filtered:
                _record(_records, e, TRUE, "AllExpr([TRUE, ...]) → TRUE")
                return TRUE
            if len(filtered) == 1:
                result = filtered[0]
                _record(_records, e, result, "AllExpr([TRUE, ..., x]) → x")
                return result
            result = AllExpr(*filtered)
            _record(_records, e, result, "Identity elimination: remove TRUE from AND")
            return result

        intersected = _intersect_and_equalities(e.exprs, _records)
        if intersected is not None:
            if intersected is FALSE:
                _record(_records, e, FALSE, "Contradiction detected in AND")
            else:
                _record(_records, e, intersected, "AND equality/IN chain intersection")
            return intersected

        intersected_between = _intersect_between_ranges(e.exprs, _records)
        if intersected_between is not None:
            if intersected_between is FALSE:
                _record(_records, e, FALSE, "Between range intersection is empty → FALSE")
            else:
                _record(_records, e, intersected_between, "Between range intersection")
            return intersected_between

        if _has_contradiction(e.exprs, _records):
            _record(_records, e, FALSE, "Contradiction detected in AND")
            return FALSE

        return e

    def _optimize_any(e: AnyExpr, _records: list[OptimizationRecord[Expr]]) -> Expr:
        """Optimize AnyExpr (OR) expressions."""
        if not e.exprs:
            _record(_records, e, FALSE, "AnyExpr([]) → FALSE")
            return FALSE

        if len(e.exprs) == 1:
            result = e.exprs[0]
            _record(_records, e, result, "AnyExpr([x]) → x")
            return result

        if any(isinstance(child, TrueExpr) for child in e.exprs):
            _record(_records, e, TRUE, "AnyExpr([..., TRUE, ...]) → TRUE")
            return TRUE

        filtered = tuple(child for child in e.exprs if not isinstance(child, FalseExpr))
        if len(filtered) != len(e.exprs):
            if not filtered:
                _record(_records, e, FALSE, "AnyExpr([FALSE, ...]) → FALSE")
                return FALSE
            if len(filtered) == 1:
                result = filtered[0]
                _record(_records, e, result, "AnyExpr([FALSE, ..., x]) → x")
                return result
            result = AnyExpr(*filtered)
            _record(_records, e, result, "Identity elimination: remove FALSE from OR")
            return result

        if _has_tautology(e.exprs, _records):
            _record(_records, e, TRUE, "Tautology detected in OR")
            return TRUE

        aggregated = _aggregate_or_equalities(e.exprs, _records)
        if aggregated is not None:
            _record(_records, e, aggregated, "OR equality chain aggregation to IN")
            return aggregated

        unioned_between = _union_between_ranges(e.exprs, _records)
        if unioned_between is not None:
            _record(_records, e, unioned_between, "Between range union")
            return unioned_between

        return e

    def _intersect_between_ranges(
        exprs: tuple[Expr, ...], _records: list[OptimizationRecord[Expr]]
    ) -> Expr | None:
        """Intersect AND-connected Between expressions on the same field.

        For each field with multiple Between expressions, computes ``[max(lowers), min(uppers))``.
        Returns ``FALSE`` when the intersection is empty, the simplified expression when at least
        one intersection was computed, or ``None`` when no field has ≥2 Between expressions.
        """
        by_field: dict[str, list[Between]] = {}
        other_exprs: list[Expr] = []

        for expr in exprs:
            if isinstance(expr, Between) and isinstance(expr.field, Field):
                by_field.setdefault(expr.field.name, []).append(expr)
            else:
                other_exprs.append(expr)

        if not any(len(v) > 1 for v in by_field.values()):
            return None

        result_exprs: list[Expr] = list(other_exprs)
        for _, between_exprs in by_field.items():
            if len(between_exprs) == 1:
                result_exprs.append(between_exprs[0])
                continue
            field = between_exprs[0].field
            try:
                lower = max(e.casted_lower() for e in between_exprs)
                upper = min(e.casted_upper() for e in between_exprs)
            except TypeError:
                result_exprs.extend(between_exprs)
                continue
            if lower >= upper:
                return FALSE
            result_exprs.append(Between(field, lower, upper))

        return result_exprs[0] if len(result_exprs) == 1 else AllExpr(*result_exprs)

    def _union_between_ranges(
        exprs: tuple[Expr, ...], _records: list[OptimizationRecord[Expr]]
    ) -> Expr | None:
        """Union OR-connected Between expressions on the same field.

        For each field with multiple Between expressions, sorts by lower bound then sweeps:
        if the next range's lower is ``<=`` the current upper, the ranges are merged by
        extending the upper to ``max(uppers)``. Adjacency (``next.lower == prev.upper``)
        is treated as overlap so that ``[a, b) ∪ [b, d) → [a, d)``.

        Returns the simplified expression when at least one merge happens, ``None`` otherwise.
        """
        by_field: dict[str, list[Between]] = {}
        other_exprs: list[Expr] = []

        for expr in exprs:
            if isinstance(expr, Between) and isinstance(expr.field, Field):
                by_field.setdefault(expr.field.name, []).append(expr)
            else:
                other_exprs.append(expr)

        if not any(len(v) > 1 for v in by_field.values()):
            return None

        result_exprs: list[Expr] = list(other_exprs)
        made_change = False

        for _, between_exprs in by_field.items():
            if len(between_exprs) == 1:
                result_exprs.append(between_exprs[0])
                continue
            try:
                sorted_exprs = sorted(
                    between_exprs, key=lambda e: (e.casted_lower(), e.casted_upper())
                )
            except TypeError:
                result_exprs.extend(between_exprs)
                continue

            merged: list[Between] = [sorted_exprs[0]]
            for e in sorted_exprs[1:]:
                prev = merged[-1]
                if e.casted_lower() <= prev.casted_upper():
                    new_upper = max(prev.casted_upper(), e.casted_upper())
                    merged[-1] = Between(prev.field, prev.casted_lower(), new_upper)
                    made_change = True
                else:
                    merged.append(e)
            result_exprs.extend(merged)

        if not made_change:
            return None

        return result_exprs[0] if len(result_exprs) == 1 else AnyExpr(*result_exprs)

    def _has_contradiction(
        exprs: tuple[Expr, ...], _records: list[OptimizationRecord[Expr]]
    ) -> bool:
        """Check if a list of AND-connected expressions contains contradictions."""
        by_field: dict[str, list[Expr]] = {}
        for expr in exprs:
            if hasattr(expr, "field") and isinstance(expr.field, Field):
                field_name = expr.field.name
                if field_name not in by_field:
                    by_field[field_name] = []
                by_field[field_name].append(expr)

        return any(
            _field_has_contradiction(field_exprs, _records) for field_exprs in by_field.values()
        )

    def _field_has_contradiction(
        exprs: list[Expr], _records: list[OptimizationRecord[Expr]]
    ) -> bool:
        """Check if expressions on a single field contain contradictions."""
        eq_values, ne_values = set(), set()
        is_null_count, is_not_null_count = 0, 0
        lt_values, le_values, gt_values, ge_values = [], [], [], []

        for expr in exprs:
            if isinstance(expr, Eq):
                eq_values.add(expr.value)
            elif isinstance(expr, Ne):
                ne_values.add(expr.value)
            elif isinstance(expr, IsNull):
                if expr.is_null:
                    is_null_count += 1
                else:
                    is_not_null_count += 1
            elif isinstance(expr, Lt):
                lt_values.append(expr.value)
            elif isinstance(expr, Le):
                le_values.append(expr.value)
            elif isinstance(expr, Gt):
                gt_values.append(expr.value)
            elif isinstance(expr, Ge):
                ge_values.append(expr.value)
            elif isinstance(expr, Between):
                ge_values.append(expr.lower)
                lt_values.append(expr.upper)

        if eq_values & ne_values:
            return True

        if is_null_count > 0 and is_not_null_count > 0:
            return True

        for lt_val in lt_values:
            for gt_val in gt_values:
                try:
                    if gt_val >= lt_val:
                        return True
                except TypeError:
                    pass

        for le_val in le_values:
            for gt_val in gt_values:
                try:
                    if gt_val >= le_val:
                        return True
                except TypeError:
                    pass

        for ge_val in ge_values:
            for lt_val in lt_values:
                try:
                    if ge_val >= lt_val:
                        return True
                except TypeError:
                    pass

        return False

    def _has_tautology(exprs: tuple[Expr, ...], _records: list[OptimizationRecord[Expr]]) -> bool:
        """Check if a list of OR-connected expressions contains tautologies."""
        by_field: dict[str, list[Expr]] = {}
        for expr in exprs:
            if hasattr(expr, "field") and isinstance(expr.field, Field):
                field_name = expr.field.name
                if field_name not in by_field:
                    by_field[field_name] = []
                by_field[field_name].append(expr)

        return any(_field_has_tautology(field_exprs, _records) for field_exprs in by_field.values())

    def _field_has_tautology(exprs: list[Expr], _records: list[OptimizationRecord[Expr]]) -> bool:
        """Check if expressions on a single field contain tautologies."""
        eq_values, ne_values = set(), set()
        is_null_count, is_not_null_count = 0, 0
        has_lt, has_ge, has_le, has_gt = False, False, False, False
        lt_ge_pairs, le_gt_pairs = [], []

        for expr in exprs:
            if isinstance(expr, Eq):
                eq_values.add(expr.value)
            elif isinstance(expr, Ne):
                ne_values.add(expr.value)
            elif isinstance(expr, IsNull):
                if expr.is_null:
                    is_null_count += 1
                else:
                    is_not_null_count += 1
            elif isinstance(expr, Lt):
                has_lt = True
                lt_ge_pairs.append(("lt", expr.value))
            elif isinstance(expr, Le):
                has_le = True
                le_gt_pairs.append(("le", expr.value))
            elif isinstance(expr, Gt):
                has_gt = True
                le_gt_pairs.append(("gt", expr.value))
            elif isinstance(expr, Ge):
                has_ge = True
                lt_ge_pairs.append(("ge", expr.value))

        if eq_values & ne_values:
            return True

        if is_null_count > 0 and is_not_null_count > 0:
            return True

        if has_lt and has_ge:
            lt_vals = {val for op, val in lt_ge_pairs if op == "lt"}
            ge_vals = {val for op, val in lt_ge_pairs if op == "ge"}
            if lt_vals & ge_vals:
                return True

        if has_le and has_gt:
            le_vals = {val for op, val in le_gt_pairs if op == "le"}
            gt_vals = {val for op, val in le_gt_pairs if op == "gt"}
            if le_vals & gt_vals:
                return True

        return False

    def _aggregate_or_equalities(
        exprs: tuple[Expr, ...], _records: list[OptimizationRecord[Expr]]
    ) -> Expr | None:
        """Aggregate OR equality and IN chains to IN expressions.

        Patterns:
        - (f == v1) OR (f == v2) OR ... OR (f == vk) → f IN (v1, v2, ..., vk)
        - (f == v1) OR (f IN (v2, v3)) → f IN (v1, v2, v3)
        - (f IN (v1, v2)) OR (f IN (v3, v4)) → f IN (v1, v2, v3, v4)

        Only applies if ALL expressions on a field are Eq or In.
        """
        by_field: dict[str, list[Expr]] = {}
        non_field_exprs: list[Expr] = []

        for expr in exprs:
            if hasattr(expr, "field") and isinstance(expr.field, Field):
                field_name = expr.field.name
                if field_name not in by_field:
                    by_field[field_name] = []
                by_field[field_name].append(expr)
            else:
                non_field_exprs.append(expr)

        aggregated_exprs: list[Expr] = list(non_field_exprs)
        made_change = False

        for _, field_exprs in by_field.items():
            if all(isinstance(e, (Eq, In)) for e in field_exprs) and len(field_exprs) > 1:
                all_values: list[Any] = []
                field = None
                for e in field_exprs:
                    if isinstance(e, Eq):
                        if field is None:
                            field = e.field
                        all_values.append(e.value)
                    elif isinstance(e, In):
                        if field is None:
                            field = e.field
                        all_values.extend(e.values)

                if field is not None:
                    aggregated_exprs.append(In(field, tuple(all_values)))
                    made_change = True
            else:
                aggregated_exprs.extend(field_exprs)

        if not made_change:
            return None

        return aggregated_exprs[0] if len(aggregated_exprs) == 1 else AnyExpr(*aggregated_exprs)

    def _intersect_and_equalities(
        exprs: tuple[Expr, ...], _records: list[OptimizationRecord[Expr]]
    ) -> Expr | None:
        """Intersect AND equality and IN chains.

        Patterns:
        - (f == v1) AND (f == v2) → FALSE if v1 != v2, or f == v1 if v1 == v2
        - (f == v) AND (f IN (v, ...)) → f == v
        - (f == v) AND (f IN (...)) → FALSE if v not in set
        - (f IN (v1, v2)) AND (f IN (v3, v4)) → FALSE if no intersection
        - (f IN (v1, v2)) AND (f IN (v2, v3)) → f == v2 if intersection is single
        - (f IN (v1, v2, v3)) AND (f IN (v2, v3, v4)) → f IN (v2, v3)

        Only applies if ALL expressions on a field are Eq or In.
        """
        by_field: dict[str, list[Expr]] = {}
        non_field_exprs: list[Expr] = []

        for expr in exprs:
            if hasattr(expr, "field") and isinstance(expr.field, Field):
                field_name = expr.field.name
                if field_name not in by_field:
                    by_field[field_name] = []
                by_field[field_name].append(expr)
            else:
                non_field_exprs.append(expr)

        intersected_exprs: list[Expr] = list(non_field_exprs)
        made_change = False

        for _, field_exprs in by_field.items():
            if all(isinstance(e, (Eq, In)) for e in field_exprs) and len(field_exprs) > 1:
                field = None
                intersection_set: set[Any] | None = None

                for e in field_exprs:
                    if isinstance(e, Eq):
                        if field is None:
                            field = e.field
                        if intersection_set is None:
                            intersection_set = {e.value}
                        else:
                            intersection_set &= {e.value}
                    elif isinstance(e, In):
                        if field is None:
                            field = e.field
                        if intersection_set is None:
                            intersection_set = set(e.values)
                        else:
                            intersection_set &= set(e.values)

                if field is not None and intersection_set is not None:
                    if not intersection_set:
                        return FALSE
                    if len(intersection_set) == 1:
                        intersected_exprs.append(Eq(field, next(iter(intersection_set))))
                    else:
                        intersected_exprs.append(In(field, tuple(intersection_set)))
                    made_change = True
            else:
                intersected_exprs.extend(field_exprs)

        if not made_change:
            return None

        return intersected_exprs[0] if len(intersected_exprs) == 1 else AllExpr(*intersected_exprs)

    result = _optimize_expr(expr, records)
    return result, records


__all__ = ["OptimizationRecord", "optimize"]
