"""SQLAlchemy grouping specification visitor for therismos grouping.

This module provides a visitor that converts therismos grouping specifications into
SQLAlchemy-compatible GROUP BY and aggregation parameters via the SQLAlchemyGroupSpec
dataclass.

Requires SQLAlchemy to be installed. Install with: pip install therismos[sqlalchemy]

Example
-------
>>> from therismos.grouping import GroupSpec, Aggregation, AggregationFunction
>>> from therismos.grouping.visitors.sqlalchemy import SQLAlchemyGroupSpecVisitor
>>>
>>> spec = GroupSpec(
...     group_by=["category", "region"],
...     aggregations=[
...         Aggregation("total", AggregationFunction.COUNT),
...         Aggregation("avg_price", AggregationFunction.AVERAGE, "price"),
...     ],
... )
>>>
>>> visitor = SQLAlchemyGroupSpecVisitor()
>>> grp = spec.accept(visitor)
>>>
>>> # Use with Core select
>>> # from sqlalchemy import select
>>> # stmt = select(*grp.group_by, *grp.agg).group_by(*grp.group_by)

Notes
-----
- COUNT uses func.count() to count all rows in the group.
- MEDIAN, Q1, Q3, and percentile functions use PostgreSQL ordered-set aggregate
  syntax: ``percentile_cont(q) WITHIN GROUP (ORDER BY col ASC)``. These generate
  valid SQL but will fail at execution time on databases that do not support this
  syntax (e.g. SQLite, older MySQL versions).
- SQLAlchemyGroupSpec is not frozen because ColumnElement is not hashable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

try:
    import sqlalchemy as sa
    from sqlalchemy.sql.elements import ColumnElement
except ImportError as exc:
    msg = "sqlalchemy is required. Install with: pip install therismos[sqlalchemy]"
    raise ImportError(msg) from exc

from therismos.grouping._grouping import Aggregation, AggregationFunction, GroupSpec


@dataclass
class SQLAlchemyGroupSpec:
    """Dataclass holding SQLAlchemy GROUP BY and aggregation parameters.

    Not frozen because ColumnElement is not hashable.

    :ivar group_by: Tuple of column clause expressions to group by.
    :vartype group_by: tuple[ColumnElement[Any], ...]
    :ivar agg: Tuple of labelled aggregation column expressions.
    :vartype agg: tuple[ColumnElement[Any], ...]

    Example
    -------
    >>> from sqlalchemy import select
    >>> grp = SQLAlchemyGroupSpec(
    ...     group_by=(sa.column("category"),),
    ...     agg=(sa.func.count().label("total"), sa.func.avg(sa.column("price")).label("avg_price")),
    ... )
    >>> stmt = select(*grp.group_by, *grp.agg).group_by(*grp.group_by)
    """

    group_by: tuple[ColumnElement[Any], ...] = field(default_factory=tuple)
    agg: tuple[ColumnElement[Any], ...] = field(default_factory=tuple)


class SQLAlchemyGroupSpecVisitor:
    """Visitor that converts grouping specifications to SQLAlchemy GROUP BY parameters.

    This visitor traverses grouping specifications and generates a SQLAlchemyGroupSpec
    dataclass whose ``group_by`` and ``agg`` tuples can be passed directly to a
    SQLAlchemy select statement.

    Example
    -------
    >>> from sqlalchemy import select
    >>> from therismos.grouping import GroupSpec, Aggregation, AggregationFunction
    >>> from therismos.grouping.visitors.sqlalchemy import SQLAlchemyGroupSpecVisitor
    >>>
    >>> spec = GroupSpec(
    ...     group_by=["status"],
    ...     aggregations=[
    ...         Aggregation("count", AggregationFunction.COUNT),
    ...         Aggregation("avg_age", AggregationFunction.AVERAGE, "age"),
    ...     ],
    ... )
    >>>
    >>> visitor = SQLAlchemyGroupSpecVisitor()
    >>> grp = spec.accept(visitor)
    >>> stmt = select(*grp.group_by, *grp.agg).group_by(*grp.group_by)
    """

    def _convert_aggregation(self, agg: Aggregation) -> ColumnElement[Any]:
        """Convert a single aggregation to a labelled SQLAlchemy column expression.

        :param agg: The aggregation to convert.
        :type agg: Aggregation
        :returns: Labelled SQLAlchemy aggregation expression.
        :rtype: ColumnElement[Any]
        :raises ValueError: If the aggregation function is not supported.
        """
        func = agg.function
        agg_id = agg.id

        match func:
            case AggregationFunction.COUNT:
                return sa.func.count().label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.SUM:
                return sa.func.sum(sa.column(agg.field)).label(agg_id)  # type: ignore[no-any-return,arg-type]
            case AggregationFunction.MIN:
                return sa.func.min(sa.column(agg.field)).label(agg_id)  # type: ignore[no-any-return,arg-type]
            case AggregationFunction.MAX:
                return sa.func.max(sa.column(agg.field)).label(agg_id)  # type: ignore[no-any-return,arg-type]
            case AggregationFunction.AVERAGE:
                return sa.func.avg(sa.column(agg.field)).label(agg_id)  # type: ignore[no-any-return,arg-type]
            case AggregationFunction.STDDEV:
                return sa.func.stddev(sa.column(agg.field)).label(agg_id)  # type: ignore[no-any-return,arg-type]
            case AggregationFunction.MEDIAN:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.5).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.Q1:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.25).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.Q3:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.75).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.P01:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.01).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.P05:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.05).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.P10:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.10).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.P90:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.90).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.P95:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.95).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case AggregationFunction.P99:
                col = sa.column(agg.field)  # type: ignore[arg-type]
                return sa.func.percentile_cont(0.99).within_group(col.asc()).label(agg_id)  # type: ignore[no-any-return]
            case _:
                msg = f"Unsupported aggregation function: {func}"
                raise ValueError(msg)

    def visit_group_spec(self, spec: GroupSpec) -> SQLAlchemyGroupSpec:
        """Convert a grouping specification to SQLAlchemy GROUP BY parameters.

        :param spec: The grouping specification to visit.
        :type spec: GroupSpec
        :returns: SQLAlchemyGroupSpec with group_by column expressions and
            labelled aggregation expressions.
        :rtype: SQLAlchemyGroupSpec
        """
        group_by = tuple(sa.column(f) for f in spec.group_by)  # type: ignore[misc]
        agg = tuple(self._convert_aggregation(a) for a in spec.aggregations.values())
        return SQLAlchemyGroupSpec(group_by=group_by, agg=agg)


__all__ = [
    "SQLAlchemyGroupSpec",
    "SQLAlchemyGroupSpecVisitor",
]
