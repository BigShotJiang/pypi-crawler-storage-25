"""
Visitor implementations for grouping specifications.

Backend-specific converters are available as separate modules:

- :mod:`mongo`: MongoDB $group stage converter (requires pymongo or motor)
- :mod:`polars`: Polars PolarsGroupSpec converter (requires polars)
- :mod:`pandas`: Pandas PandasGroupSpec converter (requires pandas)
"""

from __future__ import annotations

from therismos.grouping.visitors._visitors import (
    DictVisitor,
    FieldGathererVisitor,
    StringVisitor,
)

__all__ = [
    "DictVisitor",
    "FieldGathererVisitor",
    "StringVisitor",
]
