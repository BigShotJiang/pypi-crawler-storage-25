# Therismos

> **θερισμός** — _Greek; noun_ — Harvest.

A Python library for modeling queries, filters, expressions, grouping, and aggregations as object structures.

## Features

- **Backend-agnostic modeling**: Build expressions, filters, sorting, and aggregations independent of any specific backend
- **Declarative DSL**: Natural Python syntax for building complex queries
- **Type safety**: Optional field type declarations with automatic casting
- **Immutable structures**: All nodes are immutable and thread-safe
- **Powerful optimizer**: Detects contradictions, tautologies, and simplification opportunities
- **Grammar-based serialization**: Convert expressions to/from compact strings for URLs and APIs
- **Visitor pattern**: Extensible architecture for converting to any backend format
- **Multiple backends**: MongoDB, Polars, pandas, SQLAlchemy, SQLModel, and custom backends
- **Expression templates**: Parameterized, persistable filter expressions with a transform pipeline DSL
- **Grouping and aggregation**: Model grouping and aggregation criteria as objects
- **Sorting specifications**: Model sort criteria as objects with optimization and visitor support
- **Field pruning**: Remove or project field-based constraints with polarity-aware semantics

## Installation

```bash
pip install therismos
```

Optional extras:

```bash
pip install therismos[mongodb]        # PyMongo / Motor
pip install therismos[polars]         # Polars DataFrames
pip install therismos[pandas]         # pandas DataFrames
pip install therismos[sqlalchemy]     # SQLAlchemy / SQLModel
```

## Documentation

Full documentation is available at <https://therismos.readthedocs.io>.

## License

MIT
