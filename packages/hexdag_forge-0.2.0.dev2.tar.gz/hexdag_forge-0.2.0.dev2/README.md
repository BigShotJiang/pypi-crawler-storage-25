# hexDAG Forge

**Generate operational systems from prompts.** Describe your business → get a complete, runnable system with YAML pipelines, Python services, Django models, and a `kind: System` manifest.

```bash
pip install hexdag-forge

hexdag-forge generate "I run a freight brokerage that matches shippers with carriers"
```

Output:
```
./generated/
├── system.yaml              # kind: System manifest (LifecycleRunner)
├── pipelines/
│   ├── load_lifecycle.yaml   # Pipeline per entity lifecycle
│   └── escalation.yaml
├── services/
│   └── freight_service.py    # @tool/@step CRUD + domain stubs
├── models/
│   └── models.py             # Django models
├── state_machines.py         # StateMachineConfig definitions
├── manage.py                 # Django manage.py
├── settings.py               # Django settings
├── urls.py                   # URL config
├── admin.py                  # Admin registration
└── profile.json              # BusinessProfile (for refinement)
```

## What it generates

- **YAML Pipelines** — entity lifecycle workflows using hexDAG nodes
- **Python Services** — `@tool`/`@step` CRUD methods (implemented) + domain-specific stubs (`NotImplementedError`) for the builder agent to fill
- **Django Models** — proper ORM models with fields, relationships, state choices
- **System Manifest** — `kind: System` with state machines, `on_enter` process mappings, terminal states
- **State Machines** — `StateMachineConfig` definitions with validated transitions

## CLI

```bash
# Generate from prompt
hexdag-forge generate "I run a freight brokerage" --output ./my-erp/

# Refine existing system
hexdag-forge refine ./my-erp/ "Add an Escalation entity with severity field"

# Validate generated files
hexdag-forge validate ./my-erp/

# MCP server for Claude Code
hexdag-forge mcp serve
```

## MCP + Claude Code

```bash
hexdag-forge mcp serve
```

Skills:
- `/forge "I run a freight brokerage"` — generate system
- `/forge:entity "add Carrier with mc_number, score"` — add entity
- `/forge:implement "fill in negotiate_rate"` — implement stub

## License

Apache 2.0
