"""MCP server for hexdag-forge.

Exposes forge tools via FastMCP so Claude Code can generate
and manage operational systems.

Usage:
    hexdag-forge mcp serve              # stdio (for Claude Code)
    hexdag-forge mcp serve --transport sse --port 3001
"""

from __future__ import annotations

import json
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from hexdag_forge.domain.business_profile import BusinessProfile
from hexdag_forge.generator.assembler import assemble, validate_system
from hexdag_forge.generator.business_analyzer import create_default_profile

mcp = FastMCP(
    "hexdag-forge",
    instructions="Generate operational systems (ERP/TMS/CRM) from business descriptions. "
    "Use forge_generate to create a system, forge_get_schema to inspect it, "
    "forge_list_stubs to find methods that need implementation.",
)


@mcp.tool()
async def forge_generate(description: str, output_dir: str = "./generated") -> str:
    """Generate a complete operational system from a business description.

    Creates YAML pipelines, Python services, Django models, state machines,
    and a kind: System manifest in the output directory.
    """
    profile = create_default_profile(description)
    result = assemble(profile, Path(output_dir))

    summary = {
        "output_dir": str(output_dir),
        "business_name": result.profile.business_name,
        "entities": [
            {
                "name": e.name,
                "display_name": e.display_name,
                "fields": len(e.fields),
                "states": e.states,
            }
            for e in result.profile.entities
        ],
        "pipelines": list(result.pipelines.keys()),
        "services": list(result.services.keys()),
    }
    return json.dumps(summary, indent=2)


@mcp.tool()
async def forge_generate_from_profile(profile_json: str, output_dir: str = "./generated") -> str:
    """Generate a system from a pre-built BusinessProfile JSON.

    Use this when you've already extracted the entities, fields, states,
    and relationships — pass the full BusinessProfile as JSON.
    """
    profile = BusinessProfile.model_validate_json(profile_json)
    result = assemble(profile, Path(output_dir))

    return json.dumps(
        {
            "output_dir": str(output_dir),
            "entities": [e.name for e in result.profile.entities],
            "pipelines": list(result.pipelines.keys()),
            "services": list(result.services.keys()),
        },
        indent=2,
    )


@mcp.tool()
async def forge_validate(output_dir: str) -> str:
    """Validate all generated files in a directory.

    Checks: required files exist, Python syntax valid, profile.json valid.
    """
    errors = validate_system(Path(output_dir))
    return json.dumps({"valid": len(errors) == 0, "errors": errors}, indent=2)


@mcp.tool()
async def forge_get_schema(output_dir: str) -> str:
    """Read the BusinessProfile from a generated system.

    Returns the full schema: entities with fields, states, transitions, relationships.
    """
    profile_path = Path(output_dir) / "profile.json"
    if not profile_path.exists():
        return json.dumps({"error": f"No profile.json found in {output_dir}"})

    profile = BusinessProfile.model_validate_json(profile_path.read_text())
    return json.dumps(profile.model_dump(), indent=2, default=str)


@mcp.tool()
async def forge_list_stubs(output_dir: str) -> str:
    """List all NotImplementedError stubs in generated services.

    Shows methods that need actual business logic implementation.
    """
    import ast

    stubs: list[dict[str, str]] = []
    services_dir = Path(output_dir) / "services"
    if not services_dir.exists():
        return json.dumps([])

    for py_file in services_dir.glob("*.py"):
        tree = ast.parse(py_file.read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.AsyncFunctionDef):
                for stmt in ast.walk(node):
                    if isinstance(stmt, ast.Raise) and isinstance(stmt.exc, ast.Call):
                        func = stmt.exc.func
                        if isinstance(func, ast.Name) and func.id == "NotImplementedError":
                            stubs.append({
                                "service": py_file.stem,
                                "method": node.name,
                                "file": str(py_file.relative_to(output_dir)),
                                "docstring": ast.get_docstring(node) or "",
                            })

    return json.dumps(stubs, indent=2)


@mcp.tool()
async def forge_implement_stub(
    output_dir: str,
    service_name: str,
    method_name: str,
    implementation: str,
) -> str:
    """Replace a NotImplementedError stub with actual implementation code.

    The implementation should be the method body lines (properly indented with 8 spaces).
    """
    import ast
    import re

    service_path = Path(output_dir) / "services" / f"{service_name}.py"
    if not service_path.exists():
        return json.dumps({"error": f"Service file not found: {service_name}.py"})

    source = service_path.read_text()

    pattern = rf"(        raise NotImplementedError\([^)]*{re.escape(method_name)}[^)]*\))"
    match = re.search(pattern, source)
    if not match:
        return json.dumps({"error": f"Stub for {method_name} not found"})

    new_source = source[: match.start()] + implementation + source[match.end() :]

    try:
        ast.parse(new_source)
    except SyntaxError as e:
        return json.dumps({"error": f"Syntax error in implementation: {e}"})

    service_path.write_text(new_source)
    return json.dumps({"success": True, "file": str(service_path)})


def run_server(transport: str = "stdio", port: int = 3001) -> None:
    """Start the MCP server."""
    if transport == "stdio":
        mcp.run(transport="stdio")
    elif transport == "sse":
        mcp.run(
            transport="sse",
            sse_params={"host": "0.0.0.0", "port": port},  # nosec B104
        )
    else:
        mcp.run(transport=transport)
