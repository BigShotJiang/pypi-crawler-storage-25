"""CLI entry point for hexdag-forge — a code generator for operational systems."""

from __future__ import annotations

from pathlib import Path  # noqa: TC003 — needed at runtime by typer
from typing import Annotated

import typer

app = typer.Typer(
    name="hexdag-forge",
    help="Generate operational systems from prompts — powered by hexDAG",
    no_args_is_help=True,
)

mcp_app = typer.Typer(help="MCP server commands")
app.add_typer(mcp_app, name="mcp")


@app.command()
def generate(
    description: Annotated[str, typer.Argument(help="Business description")],
    output: Annotated[
        Path, typer.Option(help="Output directory for generated files")
    ] = "./generated",
) -> None:
    """Generate an operational system from a business description."""
    from hexdag_forge.generator.assembler import assemble
    from hexdag_forge.generator.business_analyzer import create_default_profile

    profile = create_default_profile(description)
    result = assemble(profile, output)
    typer.echo(f"Generated system in {output}/")
    typer.echo(f"  Entities: {', '.join(e.name for e in result.profile.entities)}")
    typer.echo(f"  Pipelines: {len(result.pipelines)} files")
    typer.echo(f"  Services: {len(result.services)} files")


@app.command()
def validate(
    output: Annotated[Path, typer.Argument(help="Path to generated system")],
) -> None:
    """Validate generated files (YAML pipelines, Python syntax, system manifest)."""
    from hexdag_forge.generator.assembler import validate_system

    errors = validate_system(output_dir=output)
    if errors:
        for err in errors:
            typer.echo(f"  ERROR: {err}", err=True)
        raise typer.Exit(1)
    typer.echo("All generated files are valid.")


@mcp_app.command("serve")
def mcp_serve(
    transport: Annotated[str, typer.Option(help="Transport: stdio or sse")] = "stdio",
    port: Annotated[int, typer.Option(help="Port for SSE transport")] = 3001,
) -> None:
    """Start the forge MCP server for Claude Code integration."""
    from hexdag_forge.mcp.server import run_server

    run_server(transport=transport, port=port)


def main() -> None:
    """Entry point."""
    app()


if __name__ == "__main__":
    main()
