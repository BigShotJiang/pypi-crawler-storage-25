---
name: forge
description: Generate an operational system from a business description
---

Use the forge MCP server to generate a complete operational system.

## Steps

1. Call `forge_generate` with the user's business description and an output directory.
   - If the user provides a detailed BusinessProfile JSON, use `forge_generate_from_profile` instead.

2. Show the user a summary of what was generated:
   - Entity names, their fields and states
   - Generated pipeline files
   - Generated service files (with CRUD + domain stubs)

3. Ask if the user wants to refine the generated system:
   - If yes, call `forge_refine` with their instructions
   - Show what changed

4. List any stubs that need implementation:
   - Call `forge_list_stubs` to show NotImplementedError methods
   - Ask if the user wants to implement any of them

5. Validate the output:
   - Call `forge_validate` to check all files are valid

## Notes

- The generated system includes: system.yaml, YAML pipelines, Python services, Django models, state machines
- Services have `@tool`/`@step` decorated CRUD methods (fully implemented) and domain-specific stubs (NotImplementedError)
- The system.yaml uses hexDAG's `kind: System` with LifecycleRunner (state machine driven)
- profile.json is saved for future refinement
