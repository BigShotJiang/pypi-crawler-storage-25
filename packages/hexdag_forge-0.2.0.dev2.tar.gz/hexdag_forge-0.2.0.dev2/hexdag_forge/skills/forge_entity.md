---
name: forge:entity
description: Add or modify an entity type in a generated forge system
---

Use the forge MCP server to add or modify entities in a generated system.

## Adding an entity

1. Call `forge_get_schema` to see the current entities in the system
2. Build the entity spec from the user's description (name, fields, states, transitions, relationships)
3. Load the current profile, add the new entity, and call `forge_generate_from_profile` to regenerate

## Modifying an entity

1. Call `forge_get_schema` to see current entity definition
2. Modify the profile JSON with the user's requested changes
3. Call `forge_generate_from_profile` with the updated profile to regenerate all files

## Notes

- Entity names must be valid Python identifiers (snake_case)
- Every entity needs at least 2 states and a valid initial_state
- Transitions must only reference declared states
- Relationships use: belongs_to, has_many, has_one
