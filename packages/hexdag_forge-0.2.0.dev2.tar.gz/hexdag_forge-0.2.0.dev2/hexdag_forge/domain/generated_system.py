"""Domain model for a fully generated operational system."""

from __future__ import annotations

from pydantic import BaseModel

from hexdag_forge.domain.business_profile import BusinessProfile  # noqa: TC001


class GeneratedSystem(BaseModel):
    """The complete output artifact of the forge generation process.

    Contains the business profile that was analyzed, plus all generated
    artifacts: YAML pipelines, Python service source code, Django model
    source (for export), state machine configs, and the system manifest.
    """

    profile: BusinessProfile
    pipelines: dict[str, str] = {}
    services: dict[str, str] = {}
    models_source: dict[str, str] = {}
    state_machines: dict[str, dict] = {}
    system_yaml: str = ""
