"""Generate Python service files from a BusinessProfile."""

from __future__ import annotations

from typing import TYPE_CHECKING

from hexdag_forge.generator.template_engine import render_template

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile


def generate_services(profile: BusinessProfile) -> dict[str, str]:
    """Generate a hexDAG Service class per entity.

    Each service has:
    - Fully implemented CRUD methods (@tool/@step)
    - Domain-specific stub methods (NotImplementedError) from workflow descriptions

    Returns:
        Dict of filename -> Python source code.
    """
    services: dict[str, str] = {}

    # Associate workflows with entities by keyword matching
    entity_workflows = _match_workflows_to_entities(profile)

    for entity in profile.entities:
        filename = f"{entity.name}_service.py"
        workflows = entity_workflows.get(entity.name, [])
        content = render_template("service.py.j2", entity=entity, workflows=workflows)
        services[filename] = content

    return services


def _match_workflows_to_entities(profile: BusinessProfile) -> dict[str, list[str]]:
    """Simple keyword matching: assign workflows to entities they mention."""
    result: dict[str, list[str]] = {e.name: [] for e in profile.entities}

    for workflow in profile.workflows:
        workflow_lower = workflow.lower()
        matched = False
        for entity in profile.entities:
            if (
                entity.name.lower() in workflow_lower
                or entity.display_name.lower() in workflow_lower
            ):
                result[entity.name].append(workflow)
                matched = True
        # If no entity matched, assign to first entity as a catch-all
        if not matched and profile.entities:
            result[profile.entities[0].name].append(workflow)

    return result
