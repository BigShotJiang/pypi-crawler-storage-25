"""Generate Django project files from a BusinessProfile."""

from __future__ import annotations

from typing import TYPE_CHECKING

from hexdag_forge.generator.template_engine import render_template

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile


def generate_django(profile: BusinessProfile) -> dict[str, str]:
    """Generate Django models, settings, urls, admin, and manage.py.

    Returns:
        Dict of relative path -> file content.
    """
    files: dict[str, str] = {
        "models/models.py": render_template("django_model.py.j2", profile=profile),
        "settings.py": render_template("django_settings.py.j2", profile=profile),
        "urls.py": render_template("django_urls.py.j2", profile=profile),
        "admin.py": render_template("django_admin.py.j2", profile=profile),
        "manage.py": render_template("django_manage.py.j2", profile=profile),
        "state_machines.py": render_template("state_machines.py.j2", profile=profile),
    }
    return files
