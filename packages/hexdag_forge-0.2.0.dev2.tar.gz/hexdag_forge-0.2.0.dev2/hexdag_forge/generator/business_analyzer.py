"""LLM-powered business analysis — prompt → BusinessProfile.

Uses hexDAG's LLM port to extract entities, fields, states,
transitions, and relationships from a natural language description.
"""

from __future__ import annotations

import json
from typing import Any

from hexdag_forge.domain.business_profile import BusinessProfile, EntitySpec, FieldSpec

# System prompt for the LLM
_SYSTEM_PROMPT = """You are a business systems architect. Given a business description,
extract the operational entities, their fields, state machines, and relationships.

Return a JSON object with this exact structure:
{
    "business_name": "short name",
    "business_type": "freight_brokerage|retail|saas|pharma_sales"
                     "|manufacturing|services|logistics|general",
    "entities": [
        {
            "name": "snake_case_name",
            "display_name": "Human Name",
            "description": "what this entity represents",
            "fields": [
                {"name": "field_name",
                 "type": "str|int|float|Decimal|bool|datetime|date|text|email|url",
                 "required": true, "description": "..."}
            ],
            "relationships": [
                {"target": "other_entity_name",
                 "kind": "belongs_to|has_many|has_one",
                 "field_name": "fk_field_name"}
            ],
            "states": ["STATE_A", "STATE_B", "STATE_C"],
            "initial_state": "STATE_A",
            "transitions": {
                "STATE_A": ["STATE_B", "STATE_C"],
                "STATE_B": ["STATE_C"]
            }
        }
    ],
    "workflows": ["short description of a business process that needs custom logic"],
    "modules": ["what modules this system covers"]
}

Rules:
- Entity names must be valid Python identifiers (snake_case)
- Every entity must have at least 2 states and a valid initial_state
- Transitions must only reference declared states
- Include at least id-like fields and status-relevant fields
- workflows should describe domain-specific logic that needs custom code (not CRUD)
- Be thorough but practical — extract the entities that actually matter for operations"""

_REFINE_PROMPT = """You are refining an existing business profile. The current profile is:

{current_profile}

The user wants to make this change:
{refinement}

Return the COMPLETE updated profile JSON (same structure as before), incorporating the change.
Only modify what the user asked for. Keep everything else the same."""


async def analyze_business(description: str, llm_adapter: Any) -> BusinessProfile:
    """Analyze a business description and extract a BusinessProfile.

    Args:
        description: Natural language business description.
        llm_adapter: Any hexDAG LLM adapter (OpenAI, Anthropic, mock, etc.)

    Returns:
        Validated BusinessProfile.
    """
    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": description},
    ]
    response = await llm_adapter.aresponse(messages)
    profile_data = _parse_json_response(response)
    profile_data["description"] = description
    return BusinessProfile.model_validate(profile_data)


async def refine_profile(
    profile: BusinessProfile,
    refinement: str,
    llm_adapter: Any,
) -> BusinessProfile:
    """Refine an existing BusinessProfile with additional instructions.

    Args:
        profile: Current BusinessProfile.
        refinement: What to change.
        llm_adapter: Any hexDAG LLM adapter.

    Returns:
        Updated BusinessProfile.
    """
    current_json = profile.model_dump_json(indent=2)
    prompt = _REFINE_PROMPT.format(current_profile=current_json, refinement=refinement)

    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]
    response = await llm_adapter.aresponse(messages)
    profile_data = _parse_json_response(response)
    profile_data.setdefault("description", profile.description)
    return BusinessProfile.model_validate(profile_data)


def create_default_profile(description: str) -> BusinessProfile:
    """Create a minimal default profile when no LLM is available.

    Useful for testing or offline mode.
    """
    return BusinessProfile(
        business_name="My Business",
        business_type="general",
        description=description,
        entities=[
            EntitySpec(
                name="item",
                display_name="Item",
                fields=[
                    FieldSpec(name="name", type="str", required=True),
                    FieldSpec(name="description", type="text", required=False),
                ],
                states=["DRAFT", "ACTIVE", "COMPLETED", "ARCHIVED"],
                initial_state="DRAFT",
                transitions={
                    "DRAFT": ["ACTIVE", "ARCHIVED"],
                    "ACTIVE": ["COMPLETED", "ARCHIVED"],
                    "COMPLETED": ["ARCHIVED"],
                },
            )
        ],
        workflows=[],
        modules=["general"],
    )


def _parse_json_response(response: str) -> dict:
    """Extract JSON from LLM response, handling markdown code blocks."""
    text = response.strip()
    # Handle ```json ... ``` blocks
    if "```" in text:
        start = text.find("```")
        end = text.rfind("```")
        if start != end:
            block = text[start:end]
            # Remove ```json or ``` prefix
            first_newline = block.find("\n")
            if first_newline != -1:
                text = block[first_newline + 1 :]
    return json.loads(text)
