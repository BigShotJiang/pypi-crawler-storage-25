"""Generate kind: System YAML manifest from a BusinessProfile."""

from __future__ import annotations

from typing import TYPE_CHECKING

from hexdag_forge.generator.entity_generator import generate_terminal_states_map
from hexdag_forge.generator.template_engine import render_template

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile


def generate_system(profile: BusinessProfile) -> str:
    """Generate the kind: System YAML manifest.

    Uses LifecycleRunner (because state_machines is declared).
    Each entity state maps to a process pipeline via on_enter.
    """
    terminal_states = generate_terminal_states_map(profile)
    return render_template("system.yaml.j2", profile=profile, terminal_states=terminal_states)
