"""Generate YAML pipeline files from a BusinessProfile."""

from __future__ import annotations

from typing import TYPE_CHECKING

from hexdag_forge.generator.template_engine import render_template

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile


def generate_pipelines(profile: BusinessProfile) -> dict[str, str]:
    """Generate a lifecycle pipeline YAML file per entity.

    Returns:
        Dict of filename -> YAML content.
    """
    pipelines: dict[str, str] = {}
    for entity in profile.entities:
        filename = f"{entity.name}_lifecycle.yaml"
        content = render_template("pipeline.yaml.j2", entity=entity)
        pipelines[filename] = content
    return pipelines
