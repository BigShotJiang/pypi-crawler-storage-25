"""Assembler — orchestrates all generators and writes output files.

This is the main entry point for code generation. It takes a BusinessProfile
(from LLM analysis or manual construction) and produces a complete runnable
system in the output directory.
"""

from __future__ import annotations

import json
from pathlib import Path

from hexdag_forge.domain.business_profile import BusinessProfile
from hexdag_forge.domain.generated_system import GeneratedSystem
from hexdag_forge.generator.django_generator import generate_django
from hexdag_forge.generator.pipeline_generator import generate_pipelines
from hexdag_forge.generator.service_generator import generate_services
from hexdag_forge.generator.system_generator import generate_system


def assemble(profile: BusinessProfile, output_dir: Path) -> GeneratedSystem:
    """Generate all files from a BusinessProfile and write to output_dir.

    Args:
        profile: The business profile to generate from.
        output_dir: Directory to write generated files to.

    Returns:
        GeneratedSystem with metadata about what was generated.
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # Generate all artifacts
    pipelines = generate_pipelines(profile)
    services = generate_services(profile)
    system_yaml = generate_system(profile)
    django_files = generate_django(profile)

    # Write pipelines
    pipelines_dir = output_dir / "pipelines"
    pipelines_dir.mkdir(exist_ok=True)
    for filename, content in pipelines.items():
        (pipelines_dir / filename).write_text(content)

    # Write services
    services_dir = output_dir / "services"
    services_dir.mkdir(exist_ok=True)
    for filename, content in services.items():
        (services_dir / filename).write_text(content)

    # Write system manifest
    (output_dir / "system.yaml").write_text(system_yaml)

    # Write Django files
    for rel_path, content in django_files.items():
        file_path = output_dir / rel_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)

    # Write models/__init__.py
    (output_dir / "models" / "__init__.py").write_text("")

    # Write profile.json for refinement
    (output_dir / "profile.json").write_text(profile.model_dump_json(indent=2))

    return GeneratedSystem(
        profile=profile,
        pipelines=pipelines,
        services=services,
        models_source={"models/models.py": django_files["models/models.py"]},
        state_machines={e.name: e.transitions for e in profile.entities},
        system_yaml=system_yaml,
    )


def validate_system(output_dir: Path) -> list[str]:
    """Validate all generated files in an output directory.

    Returns:
        List of error messages. Empty list means valid.
    """
    errors: list[str] = []
    output_dir = Path(output_dir)

    # Check required files exist
    required = ["system.yaml", "profile.json", "settings.py", "manage.py"]
    errors.extend(f"Missing required file: {f}" for f in required if not (output_dir / f).exists())

    # Check pipelines directory
    pipelines_dir = output_dir / "pipelines"
    if not pipelines_dir.exists():
        errors.append("Missing pipelines/ directory")
    elif not list(pipelines_dir.glob("*.yaml")):
        errors.append("No YAML files in pipelines/")

    # Check services directory
    services_dir = output_dir / "services"
    if not services_dir.exists():
        errors.append("Missing services/ directory")
    elif not list(services_dir.glob("*.py")):
        errors.append("No Python files in services/")

    # Validate Python syntax
    for py_file in output_dir.rglob("*.py"):
        try:
            import ast

            ast.parse(py_file.read_text())
        except SyntaxError as e:
            errors.append(f"Syntax error in {py_file.relative_to(output_dir)}: {e}")

    # Validate profile.json
    profile_path = output_dir / "profile.json"
    if profile_path.exists():
        try:
            profile_data = json.loads(profile_path.read_text())
            BusinessProfile.model_validate(profile_data)
        except Exception as e:
            errors.append(f"Invalid profile.json: {e}")

    return errors
