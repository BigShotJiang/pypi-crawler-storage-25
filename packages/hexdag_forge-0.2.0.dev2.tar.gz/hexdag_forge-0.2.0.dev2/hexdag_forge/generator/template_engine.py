"""Jinja2 template rendering engine for code generation."""

from __future__ import annotations

from pathlib import Path

from jinja2 import Environment, FileSystemLoader

_TEMPLATE_DIR = Path(__file__).parent.parent / "templates"


def create_env() -> Environment:
    """Create a Jinja2 environment configured for code generation."""
    return Environment(  # nosec B701 — code generation templates, not HTML
        loader=FileSystemLoader(str(_TEMPLATE_DIR)),
        keep_trailing_newline=True,
        trim_blocks=True,
        lstrip_blocks=True,
        autoescape=False,
    )


def render_template(template_name: str, **context: object) -> str:
    """Render a Jinja2 template with the given context."""
    env = create_env()
    template = env.get_template(template_name)
    return template.render(**context)
