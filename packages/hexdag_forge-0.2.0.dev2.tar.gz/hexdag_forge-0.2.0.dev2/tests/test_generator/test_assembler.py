"""Tests for the assembler — end-to-end generation."""

import ast
import json
from pathlib import Path

from hexdag_forge.domain.business_profile import (
    BusinessProfile,
    EntitySpec,
    FieldSpec,
    RelationshipSpec,
)
from hexdag_forge.generator.assembler import assemble, validate_system


def _freight_profile() -> BusinessProfile:
    return BusinessProfile(
        business_name="Test Freight",
        business_type="freight_brokerage",
        description="A freight brokerage",
        entities=[
            EntitySpec(
                name="load",
                display_name="Load",
                description="Freight load",
                fields=[
                    FieldSpec(name="origin", type="str", required=True),
                    FieldSpec(name="destination", type="str", required=True),
                    FieldSpec(name="weight", type="float", required=True),
                    FieldSpec(name="rate", type="Decimal", required=False),
                ],
                relationships=[
                    RelationshipSpec(target="carrier", kind="belongs_to", field_name="carrier_id"),
                ],
                states=["POSTED", "COVERED", "IN_TRANSIT", "DELIVERED", "CLOSED"],
                initial_state="POSTED",
                transitions={
                    "POSTED": ["COVERED"],
                    "COVERED": ["IN_TRANSIT"],
                    "IN_TRANSIT": ["DELIVERED"],
                    "DELIVERED": ["CLOSED"],
                },
            ),
            EntitySpec(
                name="carrier",
                display_name="Carrier",
                fields=[
                    FieldSpec(name="name", type="str", required=True),
                    FieldSpec(name="mc_number", type="str", required=True),
                    FieldSpec(name="score", type="float", required=False),
                ],
                states=["PENDING", "ACTIVE", "SUSPENDED"],
                initial_state="PENDING",
                transitions={
                    "PENDING": ["ACTIVE"],
                    "ACTIVE": ["SUSPENDED"],
                    "SUSPENDED": ["ACTIVE"],
                },
            ),
        ],
        workflows=["negotiate rate with carrier"],
        modules=["logistics"],
    )


class TestAssemble:
    def test_creates_output_directory(self, tmp_path: Path):
        output = tmp_path / "output"
        assemble(_freight_profile(), output)
        assert output.exists()

    def test_generates_system_yaml(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        system_yaml = tmp_path / "system.yaml"
        assert system_yaml.exists()
        content = system_yaml.read_text()
        assert "kind: System" in content
        assert "state_machines:" in content
        assert "load:" in content
        assert "carrier:" in content

    def test_generates_pipelines(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        pipelines = list((tmp_path / "pipelines").glob("*.yaml"))
        assert len(pipelines) == 2
        names = {p.name for p in pipelines}
        assert "load_lifecycle.yaml" in names
        assert "carrier_lifecycle.yaml" in names

    def test_generates_services(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        services = list((tmp_path / "services").glob("*.py"))
        assert len(services) == 2
        names = {s.name for s in services}
        assert "load_service.py" in names
        assert "carrier_service.py" in names

    def test_services_have_valid_python(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        for py_file in (tmp_path / "services").glob("*.py"):
            ast.parse(py_file.read_text())  # Should not raise

    def test_generates_django_models(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        models = tmp_path / "models" / "models.py"
        assert models.exists()
        content = models.read_text()
        assert "class Load(models.Model):" in content
        assert "class Carrier(models.Model):" in content
        assert "origin = models.CharField" in content
        assert "carrier_id = models.ForeignKey" in content

    def test_generates_manage_py(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        manage = tmp_path / "manage.py"
        assert manage.exists()
        ast.parse(manage.read_text())

    def test_generates_profile_json(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        profile = tmp_path / "profile.json"
        assert profile.exists()
        data = json.loads(profile.read_text())
        assert data["business_name"] == "Test Freight"
        assert len(data["entities"]) == 2

    def test_generates_state_machines(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        sm = tmp_path / "state_machines.py"
        assert sm.exists()
        content = sm.read_text()
        assert "LOAD_STATE_MACHINE" in content
        assert "CARRIER_STATE_MACHINE" in content

    def test_services_contain_stubs(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        # "negotiate rate with carrier" matches "carrier" entity
        carrier_service = (tmp_path / "services" / "carrier_service.py").read_text()
        assert "NotImplementedError" in carrier_service
        assert "negotiate_rate_with_carrier" in carrier_service

    def test_returns_generated_system(self, tmp_path: Path):
        result = assemble(_freight_profile(), tmp_path)
        assert result.profile.business_name == "Test Freight"
        assert len(result.pipelines) == 2
        assert len(result.services) == 2
        assert result.system_yaml != ""


class TestValidateSystem:
    def test_valid_system(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        errors = validate_system(tmp_path)
        assert errors == []

    def test_missing_files(self, tmp_path: Path):
        errors = validate_system(tmp_path)
        assert len(errors) > 0
        assert any("Missing" in e for e in errors)

    def test_invalid_python_detected(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        # Corrupt a Python file
        (tmp_path / "services" / "load_service.py").write_text("def broken(:\n")
        errors = validate_system(tmp_path)
        assert any("Syntax error" in e for e in errors)
