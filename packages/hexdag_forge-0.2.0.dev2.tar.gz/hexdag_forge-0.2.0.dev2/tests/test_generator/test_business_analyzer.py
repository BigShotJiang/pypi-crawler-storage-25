"""Tests for the business analyzer."""

from hexdag_forge.generator.business_analyzer import (
    _parse_json_response,
    create_default_profile,
)


class TestCreateDefaultProfile:
    def test_creates_valid_profile(self):
        profile = create_default_profile("A test business")
        assert profile.business_name == "My Business"
        assert len(profile.entities) == 1
        assert profile.entities[0].name == "item"
        assert profile.entities[0].initial_state == "DRAFT"

    def test_preserves_description(self):
        profile = create_default_profile("I run a bakery")
        assert profile.description == "I run a bakery"


class TestParseJsonResponse:
    def test_plain_json(self):
        result = _parse_json_response('{"key": "value"}')
        assert result == {"key": "value"}

    def test_json_in_code_block(self):
        response = '```json\n{"key": "value"}\n```'
        result = _parse_json_response(response)
        assert result == {"key": "value"}

    def test_json_in_plain_code_block(self):
        response = '```\n{"key": "value"}\n```'
        result = _parse_json_response(response)
        assert result == {"key": "value"}
