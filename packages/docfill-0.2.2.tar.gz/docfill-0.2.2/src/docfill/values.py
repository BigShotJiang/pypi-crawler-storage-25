from __future__ import annotations

import re
from typing import Any


_INT_RE = re.compile(r"^-?\d+$")
_FLOAT_DOT_RE = re.compile(r"^-?\d+\.\d+$")
_FLOAT_COMMA_RE = re.compile(r"^-?\d+,\d+$")


def excel_value_from_rendered_string(s: str) -> Any:
    t = s.strip()
    if not t:
        return s
    if _INT_RE.match(t):
        return int(t)
    if _FLOAT_DOT_RE.match(t):
        return float(t)
    if _FLOAT_COMMA_RE.match(t):
        return float(t.replace(",", "."))
    return s
