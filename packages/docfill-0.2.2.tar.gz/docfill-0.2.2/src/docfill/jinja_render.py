from __future__ import annotations

from typing import Any, Mapping

from jinja2 import Environment, StrictUndefined, TemplateSyntaxError, UndefinedError


def build_environment() -> Environment:
    return Environment(
        autoescape=False,
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
    )


def template_markers_in_text(s: str) -> bool:
    return "{{" in s or "{%" in s


def render_cell_text(
    env: Environment,
    template_str: str,
    context: Mapping[str, Any],
    cell_coord: str,
) -> str:
    if not template_markers_in_text(template_str):
        return template_str
    try:
        return env.from_string(template_str).render(**context)
    except UndefinedError as e:
        raise ValueError(f"{cell_coord}: undefined template variable: {e}") from e
    except TemplateSyntaxError as e:
        raise ValueError(f"{cell_coord}: Jinja syntax error: {e}") from e
