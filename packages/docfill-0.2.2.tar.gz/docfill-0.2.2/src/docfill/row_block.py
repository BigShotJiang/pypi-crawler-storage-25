from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Mapping

from jinja2 import Environment
from openpyxl.cell import Cell
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from . import formulas, jinja_render, styles, values
from .constants import ITEMS_LIST_KEY

_FOR_RE = re.compile(r"{%\s*for\s+([A-Za-z_]\w*)\s+in\s+([A-Za-z_]\w*)\s*%}")
_ENDFOR_RE = re.compile(r"{%\s*endfor\s*%}")
_LOOP_PLACEHOLDER_RE = re.compile(r"\{\{\s*loop\s*\.\s*\w+\s*\}\}")


def render_worksheet_global(
    ws: Worksheet,
    context: Mapping[str, Any],
    env: Environment,
) -> None:
    if ws.max_row is None:
        return
    min_r, max_r = ws.min_row or 1, ws.max_row
    min_c, max_c = ws.min_column or 1, ws.max_column or 1

    for r in range(min_r, max_r + 1):
        for c in range(min_c, max_c + 1):
            cell = ws.cell(row=r, column=c)
            coord = cell.coordinate
            if formulas.is_formula_cell(cell):
                continue
            text = cell.value
            if not isinstance(text, str) or not jinja_render.template_markers_in_text(text):
                continue
            if _FOR_RE.search(text) or _ENDFOR_RE.search(text):
                text = _FOR_RE.sub("", text)
                text = _ENDFOR_RE.sub("", text).strip()
                cell.value = text
            if not text or not jinja_render.template_markers_in_text(text):
                continue
            if "{{ loop." in text or "{{loop." in text:
                if "loop" not in context:
                    text = _LOOP_PLACEHOLDER_RE.sub("", text).strip()
                    cell.value = text
                    if not text or not jinja_render.template_markers_in_text(text):
                        continue
            rendered = jinja_render.render_cell_text(env, text, context, coord)
            cell.value = values.excel_value_from_rendered_string(rendered)


@dataclass
class _CellSnapshot:
    col: int
    is_formula: bool
    formula_text: str | None
    text_for_jinja: str | None
    static_value: Any


@dataclass
class _LoopMarkers:
    loop_var: str
    list_key: str
    endfor_row: int


@dataclass(frozen=True)
class RepeatBlock:
    template_row: int
    loop_var: str
    list_key: str
    endfor_row: int


def _classify_cell(cell: Cell) -> _CellSnapshot | None:
    col = cell.column
    if formulas.is_formula_cell(cell):
        return _CellSnapshot(col, True, str(cell.value), None, None)
    val = cell.value
    if val is None and not cell.has_style:
        return None
    if isinstance(val, str) and jinja_render.template_markers_in_text(val):
        return _CellSnapshot(col, False, None, val, None)
    return _CellSnapshot(col, False, None, None, val)


def _row_context(global_ctx: Mapping[str, Any], items_key: str, row_item: Mapping[str, Any]) -> dict[str, Any]:
    base = {k: v for k, v in global_ctx.items() if k != items_key}
    return {**base, **row_item, "item": row_item}


class _RowLoop:
    __slots__ = ("_env", "_index0", "_items")

    def __init__(self, env: Environment, index0: int, items: list[Any]) -> None:
        self._env = env
        self._index0 = index0
        self._items = items

    @property
    def length(self) -> int:
        return len(self._items)

    @property
    def index(self) -> int:
        return self._index0 + 1

    @property
    def index0(self) -> int:
        return self._index0

    @property
    def first(self) -> bool:
        return self._index0 == 0

    @property
    def last(self) -> bool:
        return self._index0 == len(self._items) - 1

    @property
    def revindex(self) -> int:
        return len(self._items) - self._index0

    @property
    def revindex0(self) -> int:
        return len(self._items) - self._index0 - 1

    @property
    def depth(self) -> int:
        return 1

    @property
    def depth0(self) -> int:
        return 0

    @property
    def previtem(self) -> Any:
        if self._index0 == 0:
            return self._env.undefined(name="loop.previtem")
        return self._items[self._index0 - 1]

    @property
    def nextitem(self) -> Any:
        if self._index0 >= len(self._items) - 1:
            return self._env.undefined(name="loop.nextitem")
        return self._items[self._index0 + 1]


def _detect_loop_markers(ws: Worksheet, template_row: int) -> _LoopMarkers | None:
    open_match: re.Match[str] | None = None
    max_col = ws.max_column or 1

    for col in range(1, max_col + 1):
        cell = ws.cell(row=template_row, column=col)
        val = cell.value
        if isinstance(val, str):
            m = _FOR_RE.search(val)
            if m:
                open_match = m
                break

    if open_match is None:
        return None

    max_row = ws.max_row or template_row
    end_row: int | None = None
    for row in range(template_row + 1, max_row + 1):
        for col in range(1, max_col + 1):
            val = ws.cell(row=row, column=col).value
            if isinstance(val, str) and _ENDFOR_RE.search(val):
                end_row = row
                break
        if end_row is not None:
            break

    if end_row is None:
        raise ValueError(
            f"A{template_row}: found '{{% for ... %}}' but matching '{{% endfor %}}' was not found"
        )

    return _LoopMarkers(
        loop_var=open_match.group(1),
        list_key=open_match.group(2),
        endfor_row=end_row,
    )


def parse_repeat_block_at_row(ws: Worksheet, template_row: int) -> RepeatBlock | None:
    markers = _detect_loop_markers(ws, template_row)
    if markers is None:
        return None
    return RepeatBlock(
        template_row=template_row,
        loop_var=markers.loop_var,
        list_key=markers.list_key,
        endfor_row=markers.endfor_row,
    )


def find_repeat_blocks(ws: Worksheet) -> list[RepeatBlock]:
    max_row = ws.max_row or 1
    max_col = ws.max_column or 1
    out: list[RepeatBlock] = []
    for row in range(1, max_row + 1):
        has_for = False
        for col in range(1, max_col + 1):
            val = ws.cell(row=row, column=col).value
            if isinstance(val, str) and _FOR_RE.search(val):
                has_for = True
                break
        if not has_for:
            continue
        blk = parse_repeat_block_at_row(ws, row)
        if blk is None:
            continue
        out.append(blk)
    return out


def find_template_row(ws: Worksheet) -> int:
    max_row = ws.max_row or 1
    max_col = ws.max_column or 1

    for row in range(1, max_row + 1):
        for col in range(1, max_col + 1):
            val = ws.cell(row=row, column=col).value
            if isinstance(val, str):
                m = _FOR_RE.search(val)
                if m and m.group(2) == ITEMS_LIST_KEY:
                    return row

    for row in range(1, max_row + 1):
        for col in range(1, max_col + 1):
            val = ws.cell(row=row, column=col).value
            if isinstance(val, str) and "{{ item." in val:
                return row

    per_row_counts: list[tuple[int, int]] = []
    for row in range(1, max_row + 1):
        cnt = 0
        for col in range(1, max_col + 1):
            cell = ws.cell(row=row, column=col)
            v = cell.value
            if isinstance(v, str) and jinja_render.template_markers_in_text(v) and not formulas.is_formula_cell(cell):
                cnt += 1
        per_row_counts.append((row, cnt))

    best_count = max((c for _, c in per_row_counts), default=0)
    candidates = [r for r, c in per_row_counts if c == best_count and c > 0]

    if not candidates:
        raise ValueError(
            f"Could not detect template row for list key {ITEMS_LIST_KEY!r}. "
            f"Add a row with a for-tag referencing {ITEMS_LIST_KEY!r}, or {{ item.field }} cells, "
            "or put several {{ ... }} placeholders on the same data row."
        )

    if best_count == 1 and len(candidates) > 1:
        raise ValueError(
            f"Could not detect template row for list key {ITEMS_LIST_KEY!r}: several rows "
            f"each have a single '{{' placeholder cell (rows {candidates}), which is ambiguous. "
            "Mark the data row with `{% for ... in ... %}` or `{{ item.field }}`, "
            "or use only one Jinja row for list expansion."
        )

    return max(candidates)


def _strip_loop_markers_from_template_row(ws: Worksheet, template_row: int) -> None:
    max_col = ws.max_column or 1
    for col in range(1, max_col + 1):
        cell = ws.cell(row=template_row, column=col)
        val = cell.value
        if not isinstance(val, str):
            continue
        new_val = _FOR_RE.sub("", val)
        new_val = _ENDFOR_RE.sub("", new_val)
        if new_val != val:
            cell.value = new_val.strip()


def _shift_formulas_below(
    ws: Worksheet,
    start_row: int,
    delta_rows: int,
    stop_row_exclusive: int | None = None,
) -> None:
    if delta_rows <= 0:
        return
    max_row = ws.max_row or start_row
    max_col = ws.max_column or 1
    end_row = max_row if stop_row_exclusive is None else min(max_row, stop_row_exclusive - 1)
    for row in range(start_row, end_row + 1):
        for col in range(1, max_col + 1):
            cell = ws.cell(row=row, column=col)
            if not formulas.is_formula_cell(cell):
                continue
            origin = f"{get_column_letter(col)}{row}"
            shifted_dest = f"{get_column_letter(col)}{row + delta_rows}"
            try:
                cell.value = formulas.translate_formula(str(cell.value), origin, shifted_dest)
            except Exception as e:
                raise ValueError(f"{origin}: formula translate failed: {e}") from e


def _shift_references_in_formulas_above(
    ws: Worksheet,
    formulas_end_row_inclusive: int,
    refs_min_row_inclusive: int,
    delta_rows: int,
) -> None:
    if delta_rows == 0 or formulas_end_row_inclusive < 1:
        return
    max_col = ws.max_column or 1
    for row in range(1, formulas_end_row_inclusive + 1):
        for col in range(1, max_col + 1):
            cell = ws.cell(row=row, column=col)
            if not formulas.is_formula_cell(cell):
                continue
            try:
                cell.value = formulas.shift_formula_row_refs(
                    str(cell.value),
                    refs_min_row_inclusive,
                    delta_rows,
                )
            except Exception as e:
                origin = f"{get_column_letter(col)}{row}"
                raise ValueError(f"{origin}: formula reference shift failed: {e}") from e


def expand_template_rows(
    ws: Worksheet,
    template_row: int,
    items: list[dict[str, Any]],
    global_ctx: Mapping[str, Any],
    items_key: str,
    env: Environment,
    formula_shift_stop_row_exclusive: int | None = None,
) -> None:
    markers = _detect_loop_markers(ws, template_row)

    if markers is not None:
        if markers.list_key != items_key:
            raise ValueError(
                f"A{template_row}: template uses 'for {markers.loop_var} in {markers.list_key}', "
                f"but this expansion uses list key {items_key!r}"
            )
        _strip_loop_markers_from_template_row(ws, template_row)

    if not items:
        if markers is not None:
            ws.delete_rows(markers.endfor_row, amount=1)
            max_col_empty = ws.max_column or 1
            for col in range(1, max_col_empty + 1):
                cell = ws.cell(row=template_row, column=col)
                if formulas.is_formula_cell(cell):
                    continue
                v = cell.value
                if isinstance(v, str) and jinja_render.template_markers_in_text(v):
                    cell.value = ""
        return
    for it in items:
        if not isinstance(it, Mapping):
            raise TypeError(f"Each {items_key!r} entry must be a JSON object, got {type(it).__name__}")

    max_col = ws.max_column or 1
    snapshots: list[_CellSnapshot] = []
    for col in range(1, max_col + 1):
        cell = ws.cell(row=template_row, column=col)
        snap = _classify_cell(cell)
        if snap is not None:
            snapshots.append(snap)

    n = len(items)
    if n > 1:
        ws.insert_rows(template_row + 1, amount=n - 1)

    template_h = ws.row_dimensions[template_row].height
    if template_h is not None:
        for r in range(n):
            ws.row_dimensions[template_row + r].height = template_h

    for r, item in enumerate(items):
        row_idx = template_row + r
        row_ctx = _row_context(global_ctx, items_key, item)
        if markers is not None:
            row_ctx[markers.loop_var] = item
        row_ctx["loop"] = _RowLoop(env, r, items)
        for snap in snapshots:
            col = snap.col
            coord = f"{get_column_letter(col)}{row_idx}"
            origin_coord = f"{get_column_letter(col)}{template_row}"
            src_cell = ws.cell(row=template_row, column=col)
            dst_cell = ws.cell(row=row_idx, column=col)
            styles.copy_cell_style(src_cell, dst_cell)

            if snap.is_formula:
                ft = snap.formula_text or "="
                try:
                    translated = formulas.translate_formula(ft, origin_coord, coord)
                except Exception as e:
                    raise ValueError(f"{coord}: formula translate failed: {e}") from e
                dst_cell.value = translated
            elif snap.text_for_jinja is not None:
                rendered = jinja_render.render_cell_text(env, snap.text_for_jinja, row_ctx, coord)
                dst_cell.value = values.excel_value_from_rendered_string(rendered)
            else:
                dst_cell.value = snap.static_value

    if markers is not None:
        shifted_endfor_row = markers.endfor_row + (n - 1)
        ws.delete_rows(shifted_endfor_row, amount=1)
        _shift_formulas_below(
            ws,
            template_row + n,
            n - 1,
            stop_row_exclusive=formula_shift_stop_row_exclusive,
        )
        _shift_references_in_formulas_above(
            ws,
            formulas_end_row_inclusive=template_row - 1,
            refs_min_row_inclusive=markers.endfor_row + 1,
            delta_rows=n - 2,
        )
