from __future__ import annotations

import re

from openpyxl.cell import Cell
from openpyxl.formula.translate import Translator


def is_formula_cell(cell: Cell) -> bool:
    return cell.data_type == "f" and isinstance(cell.value, str)


def translate_formula(formula: str, origin_coord: str, dest_coord: str) -> str:
    if not formula.startswith("="):
        formula = "=" + formula
    return Translator(formula, origin_coord).translate_formula(dest_coord)


_A1_REF_RE = re.compile(r"(\$?[A-Za-z]{1,3}\$?)(\d+)")


def shift_formula_row_refs(formula: str, min_row_inclusive: int, delta_rows: int) -> str:
    if delta_rows == 0:
        return formula
    if not formula.startswith("="):
        formula = "=" + formula

    def _replace(m: re.Match[str]) -> str:
        col_part = m.group(1)
        row_part = int(m.group(2))
        if row_part < min_row_inclusive:
            return m.group(0)
        return f"{col_part}{row_part + delta_rows}"

    return _A1_REF_RE.sub(_replace, formula)
