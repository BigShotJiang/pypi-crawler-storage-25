from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from jinja2 import Environment
from openpyxl import load_workbook
from openpyxl.worksheet.worksheet import Worksheet

from . import jinja_render, row_block
from .constants import ITEMS_LIST_KEY
from .row_block import RepeatBlock


def _formula_shift_stop_row(
    blocks_sorted_asc: list[RepeatBlock],
    block: RepeatBlock,
) -> int | None:
    for b in blocks_sorted_asc:
        if b.template_row > block.template_row:
            return b.template_row
    return None


def _expand_repeat_blocks(
    ws: Worksheet,
    context: Mapping[str, Any],
    env: Environment,
    sheet_title: str,
    blocks: list[RepeatBlock],
) -> None:
    blocks_asc = sorted(blocks, key=lambda b: b.template_row)
    for block in reversed(blocks_asc):
        raw = context.get(block.list_key)
        if raw is None:
            raise ValueError(
                f"Sheet {sheet_title!r}, row {block.template_row}: template uses list "
                f"{block.list_key!r}, but context has no such key."
            )
        if not isinstance(raw, list):
            raise TypeError(
                f"Sheet {sheet_title!r}, context key {block.list_key!r} must be a list, "
                f"got {type(raw).__name__}"
            )
        row_block.expand_template_rows(
            ws,
            block.template_row,
            list(raw),
            context,
            block.list_key,
            env,
            formula_shift_stop_row_exclusive=_formula_shift_stop_row(blocks_asc, block),
        )


def _expand_auto_items_template(
    ws: Worksheet,
    context: Mapping[str, Any],
    env: Environment,
    items: list[Any],
) -> None:
    try:
        template_row = row_block.find_template_row(ws)
    except ValueError:
        return
    row_block.expand_template_rows(
        ws,
        template_row,
        list(items),
        context,
        ITEMS_LIST_KEY,
        env,
    )


def _fill_worksheet(ws: Worksheet, context: Mapping[str, Any], env: Environment) -> None:
    blocks = row_block.find_repeat_blocks(ws)
    items = context.get(ITEMS_LIST_KEY)

    if blocks:
        _expand_repeat_blocks(ws, context, env, ws.title, blocks)
    elif isinstance(items, list) and len(items) > 0:
        _expand_auto_items_template(ws, context, env, items)

    row_block.render_worksheet_global(ws, context, env)


def fill_workbook(
    template_path: str | Path,
    output_path: str | Path,
    context: Mapping[str, Any],
) -> None:
    wb = load_workbook(filename=template_path, data_only=False)
    env = jinja_render.build_environment()
    for ws in wb.worksheets:
        _fill_worksheet(ws, context, env)
    wb.save(output_path)
