from __future__ import annotations

from copy import copy

from openpyxl.cell import Cell


def copy_cell_style(src: Cell, dst: Cell) -> None:
    if not src.has_style:
        return
    dst.font = copy(src.font)
    dst.border = copy(src.border)
    dst.fill = copy(src.fill)
    dst.number_format = copy(src.number_format)
    dst.protection = copy(src.protection)
    dst.alignment = copy(src.alignment)
