from importlib.metadata import PackageNotFoundError, version

from .pipeline import fill_workbook

try:
    __version__ = version("docfill")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = ["fill_workbook", "__version__"]
