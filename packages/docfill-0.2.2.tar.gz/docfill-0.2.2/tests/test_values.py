import unittest

from docfill.values import excel_value_from_rendered_string


class TestValues(unittest.TestCase):
    def test_int(self) -> None:
        self.assertEqual(excel_value_from_rendered_string("  42 "), 42)
        self.assertEqual(excel_value_from_rendered_string("-7"), -7)

    def test_float(self) -> None:
        self.assertEqual(excel_value_from_rendered_string("3.5"), 3.5)
        self.assertEqual(excel_value_from_rendered_string("3,5"), 3.5)

    def test_text_unchanged(self) -> None:
        self.assertEqual(excel_value_from_rendered_string("Item A"), "Item A")
        self.assertEqual(excel_value_from_rendered_string("2x"), "2x")


if __name__ == "__main__":
    unittest.main()
