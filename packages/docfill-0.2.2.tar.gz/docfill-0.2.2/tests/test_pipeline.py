import unittest
from pathlib import Path

from openpyxl import Workbook, load_workbook

from docfill.pipeline import fill_workbook


class TestPipeline(unittest.TestCase):
    def test_fill_workbook_global(self) -> None:
        tmp = Path(__file__).resolve().parent / "_tmp_pipeline"
        tmp.mkdir(exist_ok=True)
        t = tmp / "t.xlsx"
        o = tmp / "o.xlsx"

        wb = Workbook()
        ws = wb.active
        ws["A1"] = "{{ title }}"
        wb.save(t)

        fill_workbook(t, o, {"title": "Hi"})

        out = load_workbook(o, data_only=False)
        self.assertEqual(out.active["A1"].value, "Hi")

    def test_fill_workbook_items(self) -> None:
        tmp = Path(__file__).resolve().parent / "_tmp_pipeline"
        tmp.mkdir(exist_ok=True)
        t = tmp / "t2.xlsx"
        o = tmp / "o2.xlsx"

        wb = Workbook()
        ws = wb.active
        ws["A1"] = "{{ title }}"
        ws["A2"] = "{{ item.name }}"
        wb.save(t)

        fill_workbook(
            t,
            o,
            {
                "title": "Report",
                "items": [{"name": "n1"}, {"name": "n2"}],
            },
        )

        out = load_workbook(o, data_only=False)
        self.assertEqual(out.active["A1"].value, "Report")
        self.assertEqual(out.active["A2"].value, "n1")
        self.assertEqual(out.active["A3"].value, "n2")

    def test_fill_all_sheets_same_context(self) -> None:
        tmp = Path(__file__).resolve().parent / "_tmp_pipeline"
        tmp.mkdir(exist_ok=True)
        t = tmp / "multi.xlsx"
        o = tmp / "multi_out.xlsx"

        wb = Workbook()
        ws1 = wb.active
        ws1.title = "First"
        ws1["A1"] = "{{ title }}"
        ws2 = wb.create_sheet("Second")
        ws2["B2"] = "{{ title }}"
        wb.save(t)

        fill_workbook(t, o, {"title": "Same"})

        out = load_workbook(o, data_only=False)
        self.assertEqual(out["First"]["A1"].value, "Same")
        self.assertEqual(out["Second"]["B2"].value, "Same")

    def test_sheet_without_items_template_skips_expand(self) -> None:
        """Context has items but only one sheet is an item template; other sheet must not raise."""
        tmp = Path(__file__).resolve().parent / "_tmp_pipeline"
        tmp.mkdir(exist_ok=True)
        t = tmp / "skip.xlsx"
        o = tmp / "skip_out.xlsx"

        wb = Workbook()
        ws1 = wb.active
        ws1.title = "Data"
        ws1["A1"] = "{{ name }}"
        ws2 = wb.create_sheet("Empty")
        wb.save(t)

        fill_workbook(
            t,
            o,
            {"items": [{"name": "x"}, {"name": "y"}]},
        )

        out = load_workbook(o, data_only=False)
        self.assertEqual(out["Data"]["A1"].value, "x")
        self.assertEqual(out["Data"]["A2"].value, "y")


if __name__ == "__main__":
    unittest.main()
