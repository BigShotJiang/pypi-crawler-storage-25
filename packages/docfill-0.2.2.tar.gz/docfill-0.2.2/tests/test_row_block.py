import unittest
from openpyxl import Workbook

from docfill.jinja_render import build_environment
from docfill.row_block import expand_template_rows, render_worksheet_global


class TestRowBlock(unittest.TestCase):
    def test_expand_two_rows_jinja_and_formula(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A2"] = "{{ name }}"
        ws["B2"] = 10
        ws["C2"] = "=B2*2"

        env = build_environment()
        items = [{"name": "a"}, {"name": "b"}]
        ctx = {"items": items, "meta": 1}
        expand_template_rows(ws, 2, items, ctx, "items", env)

        self.assertEqual(ws["A2"].value, "a")
        self.assertEqual(ws["A3"].value, "b")
        self.assertEqual(ws["C2"].value, "=B2*2")
        self.assertEqual(ws["C3"].value, "=B3*2")

    def test_expand_preserves_static(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A1"] = "hdr"
        ws["A2"] = 99
        env = build_environment()
        items = [{"x": 1}, {"x": 2}]
        expand_template_rows(ws, 2, items, {"items": items}, "items", env)
        self.assertEqual(ws["A2"].value, 99)
        self.assertEqual(ws["A3"].value, 99)

    def test_supports_item_dot_notation(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A2"] = "{{ item.name }}"
        ws["B2"] = "{{ item.qty }}"
        env = build_environment()
        items = [{"name": "n1", "qty": 3}, {"name": "n2", "qty": 4}]
        expand_template_rows(ws, 2, items, {"items": items}, "items", env)
        self.assertEqual(ws["A2"].value, "n1")
        self.assertEqual(ws["A3"].value, "n2")
        self.assertEqual(ws["B2"].value, 3)
        self.assertEqual(ws["B3"].value, 4)

    def test_supports_for_endfor_markers_across_rows(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A5"] = "{% for item in items %}{{ item.name }}"
        ws["B5"] = "{{ item.qty }}"
        ws["C5"] = "=B5*2"
        ws["A6"] = "{% endfor %}"
        ws["C7"] = "=SUM($C$5:C5)"

        env = build_environment()
        items = [{"name": "n1", "qty": 2}, {"name": "n2", "qty": 4}]
        expand_template_rows(ws, 5, items, {"items": items}, "items", env)

        self.assertEqual(ws["A5"].value, "n1")
        self.assertEqual(ws["A6"].value, "n2")
        self.assertEqual(ws["B5"].value, 2)
        self.assertEqual(ws["B6"].value, 4)
        self.assertEqual(ws["C5"].value, "=B5*2")
        self.assertEqual(ws["C6"].value, "=B6*2")
        self.assertEqual(ws["C7"].value, "=SUM($C$5:C6)")

    def test_loop_index_after_for_stripped(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A5"] = "{% for item in items %}{{ loop.index }}"
        ws["B5"] = "{{ item.name }}"
        ws["A6"] = "{% endfor %}"

        env = build_environment()
        items = [{"name": "a"}, {"name": "b"}, {"name": "c"}]
        expand_template_rows(ws, 5, items, {"items": items}, "items", env)

        self.assertEqual(ws["A5"].value, 1)
        self.assertEqual(ws["A6"].value, 2)
        self.assertEqual(ws["A7"].value, 3)

    def test_formula_above_block_updates_reference_to_rows_below(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A2"] = "=3000*C24"
        ws["A17"] = "{% for product in products %}{{ loop.index }}"
        ws["B17"] = "{{ product.name }}"
        ws["A18"] = "{% endfor %}"
        ws["C24"] = 7

        env = build_environment()
        products = [{"name": "p1"}, {"name": "p2"}, {"name": "p3"}, {"name": "p4"}]
        expand_template_rows(ws, 17, products, {"products": products}, "products", env)

        self.assertEqual(ws["A2"].value, "=3000*C26")

    def test_global_pass_strips_for_and_orphan_loop(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A1"] = "{% for product in products %}{{ loop.index }}"
        env = build_environment()
        render_worksheet_global(ws, {"products": [{"x": 1}]}, env)
        self.assertEqual(ws["A1"].value, "")

    def test_global_pass_clears_standalone_loop_placeholder(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A1"] = "{{ loop.index }}"
        env = build_environment()
        render_worksheet_global(ws, {}, env)
        self.assertEqual(ws["A1"].value, "")

    def test_empty_items_clears_loop_and_product_cells(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A5"] = "{% for item in items %}{{ loop.index }}"
        ws["B5"] = "{{ item.name }}"
        ws["A6"] = "{% endfor %}"

        env = build_environment()
        ctx: dict = {"items": []}
        expand_template_rows(ws, 5, [], ctx, "items", env)
        render_worksheet_global(ws, ctx, env)

        self.assertEqual(ws["A5"].value, "")
        self.assertEqual(ws["B5"].value, "")


if __name__ == "__main__":
    unittest.main()
