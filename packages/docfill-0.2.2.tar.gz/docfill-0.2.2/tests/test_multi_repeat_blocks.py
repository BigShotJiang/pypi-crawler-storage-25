import unittest
from pathlib import Path

from openpyxl import Workbook, load_workbook

from docfill.pipeline import fill_workbook
from docfill.row_block import find_repeat_blocks


class TestMultiRepeatBlocks(unittest.TestCase):
    def test_find_two_blocks(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A5"] = "{% for item in items %}{{ item.name }}"
        ws["A6"] = "{% endfor %}"
        ws["A11"] = "{% for x in items2 %}{{ x.name }}"
        ws["A12"] = "{% endfor %}"
        blocks = find_repeat_blocks(ws)
        self.assertEqual(len(blocks), 2)
        keys = {b.list_key for b in blocks}
        self.assertEqual(keys, {"items", "items2"})

    def test_fill_two_tables_bottom_first(self) -> None:
        tmp = Path(__file__).resolve().parent / "_tmp_multi"
        tmp.mkdir(exist_ok=True)
        t = tmp / "two_tables.xlsx"
        o = tmp / "two_tables_out.xlsx"

        wb = Workbook()
        ws = wb.active
        ws["A5"] = "{% for item in items %}{{ item.name }}"
        ws["B5"] = "{{ item.qty }}"
        ws["A6"] = "{% endfor %}"
        ws["A11"] = "{% for z in items2 %}{{ z.name }}"
        ws["B11"] = "{{ z.qty }}"
        ws["A12"] = "{% endfor %}"
        wb.save(t)

        fill_workbook(
            t,
            o,
            {
                "items": [{"name": "Top1", "qty": 1}, {"name": "Top2", "qty": 2}],
                "items2": [{"name": "Bot1", "qty": 9}],
            },
        )

        out = load_workbook(o, data_only=False)
        wso = out.active
        self.assertEqual(wso["A5"].value, "Top1")
        self.assertEqual(wso["A6"].value, "Top2")
        self.assertEqual(wso["B5"].value, 1)
        self.assertEqual(wso["B6"].value, 2)
        self.assertEqual(wso["A11"].value, "Bot1")
        self.assertEqual(wso["B11"].value, 9)

    def test_upper_block_shift_does_not_corrupt_lower_table_formulas(self) -> None:
        tmp = Path(__file__).resolve().parent / "_tmp_multi"
        tmp.mkdir(exist_ok=True)
        t = tmp / "two_tables_f.xlsx"
        o = tmp / "two_tables_f_out.xlsx"

        wb = Workbook()
        ws = wb.active
        ws["A5"] = "{% for item in items %}{{ item.name }}"
        ws["B5"] = "{{ item.qty }}"
        ws["C5"] = "{{ item.price }}"
        ws["D5"] = "=B5*C5"
        ws["A6"] = "{% endfor %}"
        ws["A11"] = "{% for z in items2 %}{{ z.name }}"
        ws["B11"] = "{{ z.qty }}"
        ws["C11"] = "{{ z.price }}"
        ws["D11"] = "=B11*C11"
        ws["A12"] = "{% endfor %}"
        wb.save(t)

        fill_workbook(
            t,
            o,
            {
                "items": [
                    {"name": "T1", "qty": 2, "price": 3},
                    {"name": "T2", "qty": 1, "price": 5},
                ],
                "items2": [
                    {"name": "B1", "qty": 1, "price": 15},
                    {"name": "B2", "qty": 4, "price": 2},
                ],
            },
        )

        out = load_workbook(o, data_only=False)
        wso = out.active
        d11 = str(wso["D11"].value or "").upper().replace("$", "")
        d12 = str(wso["D12"].value or "").upper().replace("$", "")
        self.assertIn("B11", d11)
        self.assertIn("C11", d11)
        self.assertIn("B12", d12)
        self.assertIn("C12", d12)


if __name__ == "__main__":
    unittest.main()
