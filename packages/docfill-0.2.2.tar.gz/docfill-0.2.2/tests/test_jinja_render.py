import unittest

from docfill.jinja_render import build_environment, render_cell_text


class TestJinjaRender(unittest.TestCase):
    def test_render_simple(self) -> None:
        env = build_environment()
        self.assertEqual(render_cell_text(env, "{{ name }}", {"name": "X"}, "A1"), "X")

    def test_render_undefined_includes_coord(self) -> None:
        env = build_environment()
        with self.assertRaises(ValueError) as ctx:
            render_cell_text(env, "{{ missing }}", {}, "B2")
        self.assertIn("B2", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
