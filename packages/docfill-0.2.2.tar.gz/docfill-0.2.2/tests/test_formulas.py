import unittest
from openpyxl import Workbook

from docfill.formulas import is_formula_cell, translate_formula


class TestFormulas(unittest.TestCase):
    def test_translate_sum_range(self) -> None:
        out = translate_formula("=SUM($B$4:B5)", "B5", "B6")
        self.assertEqual(out, "=SUM($B$4:B6)")

    def test_running_total_anchor_row_must_be_absolute(self) -> None:
        """SUM($E$2:E2) grows the range; SUM($E2:E2) collapses to one row after copy-down."""
        ok = translate_formula("=SUM($E$2:E2)", "F2", "F3")
        self.assertEqual(ok, "=SUM($E$2:E3)")
        bad = translate_formula("=SUM($E2:E2)", "F2", "F3")
        self.assertEqual(bad, "=SUM($E3:E3)")

    def test_translate_relative(self) -> None:
        out = translate_formula("=A1+B1", "A1", "A2")
        self.assertIn("A2", out)
        self.assertIn("B2", out)

    def test_is_formula_cell(self) -> None:
        ws = Workbook().active
        ws["A1"] = "=1+1"
        self.assertTrue(is_formula_cell(ws["A1"]))
        ws["A2"] = "plain"
        self.assertFalse(is_formula_cell(ws["A2"]))


if __name__ == "__main__":
    unittest.main()
