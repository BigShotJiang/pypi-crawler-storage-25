import unittest
from openpyxl import Workbook

from docfill.row_block import find_template_row


class TestFindTemplateRow(unittest.TestCase):
    def test_detects_for_row(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["A2"] = "{{ x }}"
        ws["A5"] = "{% for item in items %}{{ item.name }}"
        ws["A6"] = "{% endfor %}"
        self.assertEqual(find_template_row(ws), 5)

    def test_detects_item_dot_row(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["B2"] = "{{ customer_name }}"
        ws["A5"] = "{{ item.name }}"
        ws["B5"] = "{{ item.qty }}"
        self.assertEqual(find_template_row(ws), 5)

    def test_prefers_row_with_most_jinja_cells_on_tie_bottom(self) -> None:
        wb = Workbook()
        ws = wb.active
        ws["B2"] = "{{ a }}"
        ws["C3"] = "{{ b }}"
        ws["A5"] = "{{ x }}"
        ws["B5"] = "{{ y }}"
        ws["C5"] = "{{ z }}"
        self.assertEqual(find_template_row(ws), 5)

    def test_rejects_multiple_rows_with_single_placeholder(self) -> None:
        """Stacked header lines must not pick a bogus template when items is used."""
        wb = Workbook()
        ws = wb.active
        ws["A11"] = "{{ customer_name }}"
        ws["A12"] = "{{ report_date }}"
        with self.assertRaises(ValueError) as ctx:
            find_template_row(ws)
        self.assertIn("ambiguous", str(ctx.exception).lower())


if __name__ == "__main__":
    unittest.main()
