"""Setup configuration for lab-downloader package"""

from setuptools import setup, find_packages
import os

# Read README
try:
    with open(os.path.join(os.path.dirname(__file__), "README.md"), "r", encoding="utf-8") as f:
        long_description = f.read()
except Exception:
    long_description = ""

setup(
    name="lab-downloader",
    version="1.0.0",
    author="Lab Downloader Team",
    description="A pip CLI tool to download programs for ML, SDP, and MAD labs",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/user/lab-downloader",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[],  # No external dependencies required
    entry_points={
        "console_scripts": [
            "lab-downloader=lab_downloader.cli:cli",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "Topic :: Education",
    ],
    keywords="lab downloader ml sdp mad education",
)
