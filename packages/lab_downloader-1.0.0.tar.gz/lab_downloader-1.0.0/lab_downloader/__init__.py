"""Lab Downloader - Download ML, SDP, and MAD lab programs easily"""

__version__ = "1.0.0"
__author__ = "Lab Downloader Team"
__description__ = "A pip CLI tool to download programs for ML, SDP, and MAD labs"
