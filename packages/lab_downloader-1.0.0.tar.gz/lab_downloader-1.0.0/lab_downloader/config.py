"""Configuration and lab definitions"""

LAB_CONFIGS = {
    "ml": {
        "name": "Machine Learning Lab",
        "description": "ML lab with datasets and jupyter notebooks",
        "url": "https://github.com/user/ML_Lab/archive/refs/heads/main.zip",
        "folder_name": "ML_Lab-main",
        "files": [
            "lab6_PCA.ipynb",
            "ML_lab_1.ipynb",
            "ml_lab_2.ipynb",
            "mllab3.ipynb",
            "mllab5.ipynb",
            "mllab8.ipynb",
            "mllab9.ipynb",
            "mllab10.ipynb",
            "pgm7.ipynb",
            "program4.ipynb",
            "breast-cancer.csv"
        ]
    },
    "sdp": {
        "name": "Software Development Project",
        "description": "SDP lab programs",
        "url": "https://github.com/user/sdp-program/archive/refs/heads/main.zip",
        "folder_name": "sdp-program-main",
        "files": []
    },
    "mad": {
        "name": "Mobile Application Development",
        "description": "MAD lab programs and resources",
        "url": "https://github.com/user/MAD-program/archive/refs/heads/main.zip",
        "folder_name": "MAD-program-main",
        "files": ["MAD (1).txt"]
    }
}

DEFAULT_DOWNLOAD_DIR = "./lab_programs"
