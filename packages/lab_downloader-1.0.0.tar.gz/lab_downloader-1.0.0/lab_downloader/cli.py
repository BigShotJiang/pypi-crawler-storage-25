"""Command-line interface for lab downloader"""

import argparse
import sys
from pathlib import Path

from .downloader import LabDownloader


def create_parser() -> argparse.ArgumentParser:
    """Create and return the argument parser"""
    parser = argparse.ArgumentParser(
        prog='lab-downloader',
        description='Download programs for ML, SDP, and MAD labs',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  lab-downloader download ml              Download ML lab
  lab-downloader download sdp --verbose   Download SDP lab with details
  lab-downloader download all             Download all labs
  lab-downloader list                     List all available labs
  lab-downloader status                   Show download status
  lab-downloader download mad --dir ./my_labs    Download to custom directory
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Download command
    download_parser = subparsers.add_parser('download', help='Download lab programs')
    download_parser.add_argument(
        'lab',
        choices=['ml', 'sdp', 'mad', 'all'],
        help='Lab to download (ml, sdp, mad, or all)'
    )
    download_parser.add_argument(
        '--dir',
        type=str,
        default=None,
        help='Download directory (default: ./lab_programs)'
    )
    download_parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Verbose output'
    )
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all available labs')
    list_parser.add_argument(
        '--dir',
        type=str,
        default=None,
        help='Lab directory (default: ./lab_programs)'
    )
    
    # Status command
    status_parser = subparsers.add_parser('status', help='Show download status')
    status_parser.add_argument(
        '--dir',
        type=str,
        default=None,
        help='Lab directory (default: ./lab_programs)'
    )
    
    # Version command
    subparsers.add_parser('version', help='Show version')
    
    return parser


def main(args=None) -> int:
    """Main entry point for CLI"""
    parser = create_parser()
    
    if args is None:
        args = sys.argv[1:]
    
    # If no arguments provided, show help
    if not args:
        parser.print_help()
        return 0
    
    parsed_args = parser.parse_args(args)
    
    try:
        if parsed_args.command == 'download':
            downloader = LabDownloader(parsed_args.dir)
            
            if parsed_args.lab == 'all':
                success_count = downloader.download_all(parsed_args.verbose)
                from .config import LAB_CONFIGS
                total_labs = len(LAB_CONFIGS)
                print(f"\n✨ Downloaded {success_count}/{total_labs} labs")
                return 0 if success_count > 0 else 1
            else:
                success = downloader.download_lab(parsed_args.lab, parsed_args.verbose)
                return 0 if success else 1
        
        elif parsed_args.command == 'list':
            downloader = LabDownloader(parsed_args.dir if hasattr(parsed_args, 'dir') else None)
            downloader.list_labs()
            return 0
        
        elif parsed_args.command == 'status':
            downloader = LabDownloader(parsed_args.dir)
            downloader.get_lab_status()
            return 0
        
        elif parsed_args.command == 'version':
            from . import __version__
            print(f"lab-downloader version {__version__}")
            return 0
        
        else:
            parser.print_help()
            return 0
    
    except KeyboardInterrupt:
        print("\n\n❌ Download cancelled by user")
        return 130
    except Exception as e:
        print(f"❌ Error: {str(e)}", file=sys.stderr)
        return 1


def cli():
    """Entry point for installed script"""
    sys.exit(main())


if __name__ == '__main__':
    sys.exit(main())
