# Lab Downloader 📚

A pip CLI tool to easily download programs for ML (Machine Learning), SDP (Software Development Project), and MAD (Mobile Application Development) labs.

## Features ✨

- ⚡ **Quick Setup**: Install via pip and start downloading labs instantly
- 🎯 **Multi-Lab Support**: Download ML, SDP, or MAD labs individually or all at once
- 📋 **Status Tracking**: Check which labs are downloaded and where
- 🔧 **Flexible**: Customize download directory
- 📖 **Easy to Use**: Simple CLI commands with helpful documentation

## Installation 🚀

### From source (local development):
```bash
cd lab-downloader
pip install -e .
```

### From PyPI (once published):
```bash
pip install lab-downloader
```

## Quick Start 🏃

### Download a specific lab:
```bash
# Download ML lab
lab-downloader download ml

# Download SDP lab
lab-downloader download sdp

# Download MAD lab
lab-downloader download mad
```

### Download all labs:
```bash
lab-downloader download all
```

### List available labs:
```bash
lab-downloader list
```

### Check download status:
```bash
lab-downloader status
```

### Use custom download directory:
```bash
lab-downloader download ml --dir ./my_labs
lab-downloader download all --dir /path/to/labs
```

### Verbose output:
```bash
lab-downloader download ml --verbose
# or
lab-downloader download ml -v
```

## Available Labs 📚

### 🤖 ML (Machine Learning)
- **Description**: Machine Learning lab with datasets and jupyter notebooks
- **Files**: PCA analysis, multiple lab notebooks, breast cancer dataset
- **Command**: `lab-downloader download ml`

### 💼 SDP (Software Development Project)
- **Description**: Software Development Project lab programs
- **Command**: `lab-downloader download sdp`

### 📱 MAD (Mobile Application Development)
- **Description**: Mobile Application Development lab programs and resources
- **Command**: `lab-downloader download mad`

## Usage Examples 💡

```bash
# Download ML lab with detailed output
lab-downloader download ml -v

# Download all labs to a custom location
lab-downloader download all --dir ~/my_projects/labs

# Check what labs are available
lab-downloader list

# See current download status
lab-downloader status

# Get version info
lab-downloader version
```

## File Locations 📁

By default, labs are downloaded to: `./lab_programs/`

Structure:
```
lab_programs/
├── ML_Lab-main/
│   ├── lab6_PCA.ipynb
│   ├── ML_lab_1.ipynb
│   ├── breast-cancer.csv
│   └── ... (more notebooks)
├── sdp-program-main/
│   └── ... (SDP files)
└── MAD-program-main/
    └── MAD (1).txt
```

## Requirements 📋

- Python 3.7+
- No external dependencies (uses only Python standard library)

## Development 🛠️

### Clone the repository:
```bash
git clone https://github.com/user/lab-downloader.git
cd lab-downloader
```

### Install in development mode:
```bash
pip install -e .
```

### Run tests:
```bash
python -m pytest
```

### Build the package:
```bash
python -m build
```

## Troubleshooting 🔧

### Command not found after installation:
```bash
# Try reinstalling
pip install --force-reinstall -e .
```

### Permission denied:
```bash
# On Unix/Linux/Mac
chmod +x $(which lab-downloader)

# Or use sudo
sudo pip install lab-downloader
```

### Download fails:
- Check your internet connection
- Verify the lab name is correct: `lab-downloader list`
- Try verbose mode: `lab-downloader download ml -v`

## Contributing 🤝

Contributions are welcome! Please feel free to submit a Pull Request.

## License 📄

This project is licensed under the MIT License - see the LICENSE file for details.

## Support 💬

For issues, questions, or suggestions, please open an issue on GitHub.

---

**Made with ❤️ for students learning ML, SDP, and MAD**
