"""Testing utilities for SDK examples and tests."""

from __future__ import annotations

import re

import httpx

FALLBACK_WALLETS = [
    "0xc2e7800b5af46e6093872b177b7a5e7f0563be51",
    "0x02227b8f5a9636e895607edd3185ed6ee5598ff7",
    "0xefbc5fec8d7b0acdc8911bdd9a98d6964308f9a2",
    "0x2a2c53bd278c04da9962fcf96490e17f3dfb9bc1",
    "0x37c1874a60d348903594a96703e0507c518fc53a",
]


async def get_active_test_wallet(*, fresh: bool = False) -> str:
    if not fresh:
        return FALLBACK_WALLETS[0]
    try:
        traders = await _fetch_top_traders(1)
        return traders[0]["wallet"] if traders else FALLBACK_WALLETS[0]
    except Exception:
        return FALLBACK_WALLETS[0]


async def get_active_test_wallets(count: int = 5, *, fresh: bool = False) -> list[str]:
    if not fresh:
        return FALLBACK_WALLETS[:count]
    try:
        traders = await _fetch_top_traders(count)
        if traders:
            return [t["wallet"] for t in traders]
        return FALLBACK_WALLETS[:count]
    except Exception:
        return FALLBACK_WALLETS[:count]


async def _fetch_top_traders(count: int) -> list[dict]:
    build_id = await _discover_build_id()
    if not build_id:
        return []

    url = f"https://polymarket.com/_next/data/{build_id}/en/leaderboard/overall/monthly/profit.json?segment=overall&period=monthly&sort=profit"

    async with httpx.AsyncClient(timeout=10.0) as http:
        resp = await http.get(url, headers={"User-Agent": "polynode-sdk/testing"})
        if not resp.is_success:
            return []
        data = resp.json()

    queries = data.get("pageProps", {}).get("dehydratedState", {}).get("queries", [])
    for q in queries:
        key = q.get("queryKey", [])
        if isinstance(key, list) and "profit" in key and "/leaderboard" in str(key):
            records = q.get("state", {}).get("data", [])
            if isinstance(records, list):
                return [
                    {
                        "wallet": r.get("proxyWallet", ""),
                        "name": r.get("pseudonym") or r.get("name", ""),
                        "pnl": r.get("pnl") or r.get("amount", 0),
                        "volume": r.get("volume", 0),
                    }
                    for r in records[:count]
                ]
    return []


async def _discover_build_id() -> str | None:
    try:
        async with httpx.AsyncClient(timeout=10.0) as http:
            resp = await http.get(
                "https://polymarket.com/",
                headers={"User-Agent": "polynode-sdk/testing"},
            )
            if not resp.is_success:
                return None
            match = re.search(r"/_next/data/([^/]+)/", resp.text)
            return match.group(1) if match else None
    except Exception:
        return None
