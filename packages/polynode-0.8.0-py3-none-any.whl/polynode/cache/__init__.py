"""Cache module placeholder — local SQLite-backed trade/position history.

This module will be implemented in a future release.
The cache/ directory structure matches the TypeScript SDK:
- sqlite_backend.py — SQLite storage (settlements, trades, positions)
- watchlist.py — JSON watchlist file management
- backfill.py — Rate-limited REST backfill orchestrator
- query_builder.py — Fluent query builder
- views.py — Analytical views (wallet_dashboard, leaderboard, etc.)
- export.py — CSV/JSON export
"""
