"""Redemption watcher — tracks wallet positions and alerts on market resolution."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Callable

from .client import PolyNode
from .ws import PolyNodeWS


@dataclass
class RedeemableAlert:
    wallet: str
    condition_id: str
    token_id: str
    outcome: str
    winning_outcome: str
    is_winner: bool
    size: float
    estimated_payout_usd: float
    market_title: str
    market_slug: str
    market_image: str | None
    resolved_price: float
    payouts: list[float]
    block_number: int
    timestamp: float


@dataclass
class TrackedPosition:
    wallet: str
    token_id: str
    condition_id: str
    outcome: str
    size: float
    market_title: str
    market_slug: str
    market_image: str | None = None
    outcomes: list[str] = field(default_factory=list)
    token_ids: list[str] = field(default_factory=list)
    neg_risk: bool | None = None


class RedemptionWatcher:
    """Tracks wallet positions and emits alerts when markets resolve."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str | None = None,
        ws_url: str | None = None,
        compress: bool = True,
        auto_reconnect: bool = True,
        track_position_changes: bool = True,
        refresh_interval: float = 300.0,
    ) -> None:
        self._client = PolyNode(api_key, base_url=base_url or "https://api.polynode.dev")
        from .types.ws import WsOptions
        self._ws = PolyNodeWS(
            api_key,
            ws_url or "wss://ws.polynode.dev/ws",
            WsOptions(compress=compress, auto_reconnect=auto_reconnect),
        )
        self._track_position_changes = track_position_changes
        self._refresh_interval = refresh_interval

        self._by_condition: dict[str, list[TrackedPosition]] = {}
        self._by_wallet: dict[str, set[str]] = {}

        self._oracle_sub = None
        self._wallet_sub = None
        self._refresh_task: asyncio.Task | None = None
        self._closed = False

        self._handlers: dict[str, list[Callable]] = {"alert": [], "ready": [], "error": []}
        self._alert_queue: asyncio.Queue[RedeemableAlert | None] = asyncio.Queue()

    async def start(self, wallets: list[str]) -> None:
        if self._closed:
            raise RuntimeError("RedemptionWatcher is closed")

        await self._fetch_and_load(wallets)

        self._oracle_sub = await self._ws.subscribe("oracle").send()
        self._oracle_sub.on("oracle", self._handle_oracle_event)

        if self._track_position_changes and wallets:
            self._wallet_sub = await self._ws.subscribe("wallets").wallets(wallets).send()
            self._wallet_sub.on("position_change", self._handle_position_change)

        if self._refresh_interval > 0:
            self._refresh_task = asyncio.ensure_future(self._refresh_loop())

        for h in self._handlers["ready"]:
            h()

    async def add_wallets(self, wallets: list[str]) -> None:
        if self._closed:
            raise RuntimeError("RedemptionWatcher is closed")
        await self._fetch_and_load(wallets)
        if self._track_position_changes:
            await self._resubscribe_wallets()

    def remove_wallets(self, wallets: list[str]) -> None:
        for wallet in wallets:
            conditions = self._by_wallet.pop(wallet, set())
            for cond_id in conditions:
                positions = self._by_condition.get(cond_id, [])
                filtered = [p for p in positions if p.wallet.lower() != wallet.lower()]
                if filtered:
                    self._by_condition[cond_id] = filtered
                else:
                    self._by_condition.pop(cond_id, None)
        if self._track_position_changes and not self._closed:
            asyncio.ensure_future(self._resubscribe_wallets())

    def on(self, event: str, handler: Callable) -> RedemptionWatcher:
        if event in self._handlers:
            self._handlers[event].append(handler)
        return self

    def off(self, event: str, handler: Callable) -> RedemptionWatcher:
        if event in self._handlers:
            try:
                self._handlers[event].remove(handler)
            except ValueError:
                pass
        return self

    @property
    def wallets(self) -> list[str]:
        return list(self._by_wallet.keys())

    @property
    def conditions(self) -> list[str]:
        return list(self._by_condition.keys())

    def positions_for(self, wallet: str) -> list[TrackedPosition]:
        conditions = self._by_wallet.get(wallet, set())
        result = []
        for cond_id in conditions:
            for p in self._by_condition.get(cond_id, []):
                if p.wallet.lower() == wallet.lower():
                    result.append(p)
        return result

    @property
    def size(self) -> int:
        return sum(len(ps) for ps in self._by_condition.values())

    def close(self) -> None:
        self._closed = True
        if self._refresh_task and not self._refresh_task.done():
            self._refresh_task.cancel()
        if self._oracle_sub:
            self._oracle_sub.unsubscribe()
        if self._wallet_sub:
            self._wallet_sub.unsubscribe()
        self._ws.disconnect()
        self._client.close()
        self._alert_queue.put_nowait(None)

    def __aiter__(self):
        return self

    async def __anext__(self) -> RedeemableAlert:
        if self._closed:
            raise StopAsyncIteration
        alert = await self._alert_queue.get()
        if alert is None:
            raise StopAsyncIteration
        return alert

    # ── Private ──

    async def _fetch_and_load(self, wallets: list[str]) -> None:
        for wallet in wallets:
            try:
                data = self._client.wallet_positions(wallet)
                self._load_positions(wallet, data.get("positions", []))
            except Exception as e:
                for h in self._handlers["error"]:
                    h(e)

    def _load_positions(self, wallet: str, positions: list[dict]) -> None:
        wallet_conditions = self._by_wallet.get(wallet, set())

        for pos in positions:
            condition_id = pos.get("conditionId") or pos.get("condition_id")
            token_id = pos.get("asset") or pos.get("token_id")
            size = pos.get("size", 0)
            if not condition_id or not token_id or size <= 0:
                continue

            tracked = TrackedPosition(
                wallet=wallet,
                token_id=token_id,
                condition_id=condition_id,
                outcome=pos.get("outcome", ""),
                size=size,
                market_title=pos.get("market_title") or pos.get("title", ""),
                market_slug=pos.get("market_slug") or pos.get("slug", ""),
                market_image=pos.get("market_image") or pos.get("icon") or pos.get("image"),
                outcomes=pos.get("outcomes", []),
                token_ids=pos.get("token_ids", []),
                neg_risk=pos.get("neg_risk") or pos.get("negativeRisk"),
            )

            existing = self._by_condition.get(condition_id, [])
            dup_idx = next(
                (i for i, p in enumerate(existing) if p.wallet.lower() == wallet.lower() and p.token_id == token_id),
                None,
            )
            if dup_idx is not None:
                existing[dup_idx] = tracked
            else:
                existing.append(tracked)
            self._by_condition[condition_id] = existing
            wallet_conditions.add(condition_id)

        self._by_wallet[wallet] = wallet_conditions

    def _handle_oracle_event(self, event: Any) -> None:
        if event.oracle_type != "condition_resolution":
            return
        condition_id = event.condition_id
        if not condition_id:
            return

        positions = self._by_condition.get(condition_id, [])
        if not positions:
            return

        for pos in positions:
            token_ids = event.token_ids or []
            token_index = token_ids.index(pos.token_id) if pos.token_id in token_ids else -1
            is_winner = token_index >= 0 and (event.payouts or [])[token_index] > 0 if event.payouts and token_index >= 0 else False

            alert = RedeemableAlert(
                wallet=pos.wallet,
                condition_id=pos.condition_id,
                token_id=pos.token_id,
                outcome=pos.outcome,
                winning_outcome=event.resolved_outcome or "Unknown",
                is_winner=is_winner,
                size=pos.size,
                estimated_payout_usd=pos.size if is_winner else 0,
                market_title=pos.market_title,
                market_slug=pos.market_slug,
                market_image=pos.market_image,
                resolved_price=event.resolved_price or 0,
                payouts=event.payouts or [],
                block_number=event.block_number,
                timestamp=event.timestamp,
            )

            for h in self._handlers["alert"]:
                h(alert)
            self._alert_queue.put_nowait(alert)

        # Evict resolved condition
        self._by_condition.pop(condition_id, None)
        for wc in self._by_wallet.values():
            wc.discard(condition_id)

    def _handle_position_change(self, event: Any) -> None:
        matched = False
        affected_condition_id = None

        for cond_id, positions in self._by_condition.items():
            for pos in positions:
                if pos.token_id != event.token_id:
                    continue
                matched = True
                affected_condition_id = cond_id
                if event.to.lower() == pos.wallet.lower():
                    pos.size += event.amount
                if event.from_address.lower() == pos.wallet.lower():
                    pos.size -= event.amount
                    if pos.size < 0:
                        pos.size = 0

        if affected_condition_id:
            positions = self._by_condition.get(affected_condition_id, [])
            remaining = [p for p in positions if p.size > 0]
            if not remaining:
                self._by_condition.pop(affected_condition_id, None)
                for wc in self._by_wallet.values():
                    wc.discard(affected_condition_id)
            elif len(remaining) < len(positions):
                self._by_condition[affected_condition_id] = remaining

        if not matched and hasattr(event, "condition_id") and event.condition_id:
            to_wallet = event.to.lower()
            if to_wallet in self._by_wallet:
                tracked = TrackedPosition(
                    wallet=to_wallet,
                    token_id=event.token_id,
                    condition_id=event.condition_id,
                    outcome=getattr(event, "outcome", "") or "",
                    size=event.amount,
                    market_title=getattr(event, "market_title", "") or "",
                    market_slug=getattr(event, "market_slug", "") or "",
                    market_image=getattr(event, "market_image", None),
                    outcomes=getattr(event, "outcomes", []) or [],
                    token_ids=getattr(event, "token_ids", []) or [],
                    neg_risk=getattr(event, "neg_risk", None),
                )
                existing = self._by_condition.get(event.condition_id, [])
                existing.append(tracked)
                self._by_condition[event.condition_id] = existing
                self._by_wallet[to_wallet].add(event.condition_id)

    async def _resubscribe_wallets(self) -> None:
        if self._wallet_sub:
            self._wallet_sub.unsubscribe()
            self._wallet_sub = None
        all_wallets = list(self._by_wallet.keys())
        if not all_wallets:
            return
        self._wallet_sub = await self._ws.subscribe("wallets").wallets(all_wallets).send()
        self._wallet_sub.on("position_change", self._handle_position_change)

    async def _refresh_loop(self) -> None:
        while not self._closed:
            await asyncio.sleep(self._refresh_interval)
            if self._closed:
                break
            all_wallets = list(self._by_wallet.keys())
            if all_wallets:
                try:
                    await self._fetch_and_load(all_wallets)
                except Exception as e:
                    for h in self._handlers["error"]:
                        h(e)
