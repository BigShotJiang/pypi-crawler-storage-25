"""Async WebSocket client for real-time orderbook updates."""

from __future__ import annotations

import asyncio
import json
import math
import random
import zlib
from typing import Any, Callable

import websockets
import websockets.asyncio.client

from .errors import WsError
from .types.orderbook import (
    BookSnapshot,
    BookUpdate,
    ObErrorMessage,
    PriceChange,
    SnapshotsDoneMessage,
    SubscribedMessage,
)


class OrderbookWS:
    """Async WebSocket client for orderbook streaming from ob.polynode.dev."""

    def __init__(self, api_key: str, ob_url: str, *, compress: bool = True, auto_reconnect: bool = True,
                 max_reconnect_attempts: int = 0, reconnect_base_delay: float = 1.0,
                 reconnect_max_delay: float = 30.0) -> None:
        self._api_key = api_key
        self._ob_url = ob_url
        self._compress = compress
        self._auto_reconnect = auto_reconnect
        self._max_reconnect = max_reconnect_attempts
        self._base_delay = reconnect_base_delay
        self._max_delay = reconnect_max_delay

        self._socket: Any = None
        self._connected = False
        self._intentional_close = False
        self._reconnect_attempts = 0
        self._token_ids: list[str] = []
        self._recv_task: asyncio.Task | None = None

        self._handlers: dict[str, list[Callable]] = {
            "snapshot": [],
            "update": [],
            "price": [],
            "snapshots_done": [],
            "subscribed": [],
            "error": [],
            "*": [],
        }
        self._on_connect: list[Callable] = []
        self._on_disconnect: list[Callable] = []
        self._on_reconnect: list[Callable] = []
        self._on_error: list[Callable] = []

    @property
    def is_connected(self) -> bool:
        return self._connected

    def on_connect(self, handler: Callable) -> OrderbookWS:
        self._on_connect.append(handler)
        return self

    def on_disconnect(self, handler: Callable) -> OrderbookWS:
        self._on_disconnect.append(handler)
        return self

    def on_reconnect(self, handler: Callable) -> OrderbookWS:
        self._on_reconnect.append(handler)
        return self

    def on_error(self, handler: Callable) -> OrderbookWS:
        self._on_error.append(handler)
        return self

    def on(self, event: str, handler: Callable) -> OrderbookWS:
        if event in self._handlers:
            self._handlers[event].append(handler)
        return self

    def off(self, event: str, handler: Callable) -> OrderbookWS:
        if event in self._handlers:
            try:
                self._handlers[event].remove(handler)
            except ValueError:
                pass
        return self

    async def subscribe(self, token_ids: list[str]) -> None:
        self._token_ids = token_ids
        await self._ensure_connected()
        await self._send(json.dumps({"action": "subscribe", "markets": token_ids}))

    def unsubscribe(self) -> None:
        self._token_ids = []
        if self._connected and self._socket:
            asyncio.ensure_future(self._send(json.dumps({"action": "unsubscribe"})))

    async def connect(self) -> None:
        if self._connected and self._socket:
            return
        await self._connect()

    def disconnect(self) -> None:
        self._intentional_close = True
        if self._recv_task and not self._recv_task.done():
            self._recv_task.cancel()
        if self._socket:
            asyncio.ensure_future(self._socket.close())
            self._socket = None
        self._connected = False

    # ── Private ──

    async def _ensure_connected(self) -> None:
        if not self._connected or not self._socket:
            await self._connect()

    async def _connect(self) -> None:
        url = f"{self._ob_url}?key={self._api_key}"
        if self._compress:
            url += "&compress=zlib"

        self._socket = await websockets.asyncio.client.connect(url, max_size=10 * 1024 * 1024)
        self._connected = True
        self._reconnect_attempts = 0
        self._intentional_close = False

        for h in self._on_connect:
            h()

        self._recv_task = asyncio.ensure_future(self._recv_loop())

    async def _recv_loop(self) -> None:
        try:
            async for raw in self._socket:
                try:
                    if isinstance(raw, bytes) and self._compress:
                        text = zlib.decompress(raw, -zlib.MAX_WBITS).decode("utf-8")
                    elif isinstance(raw, bytes):
                        text = raw.decode("utf-8")
                    else:
                        text = raw
                    self._handle_message(text)
                except Exception as e:
                    err = WsError(f"Failed to process message: {e}")
                    for h in self._on_error:
                        h(err)
        except websockets.exceptions.ConnectionClosed:
            pass
        except asyncio.CancelledError:
            return
        finally:
            self._connected = False
            reason = "closed" if self._intentional_close else "lost"
            for h in self._on_disconnect:
                h(reason)
            if not self._intentional_close and self._auto_reconnect:
                asyncio.ensure_future(self._schedule_reconnect())

    async def _send(self, data: str) -> None:
        if self._socket and self._connected:
            await self._socket.send(data)

    def _handle_message(self, text: str) -> None:
        msg = json.loads(text)

        if msg.get("error"):
            err_msg = ObErrorMessage.model_validate(msg)
            for h in self._handlers["error"]:
                h(err_msg)
            return

        msg_type = msg.get("type")

        if msg_type == "subscribed":
            sub_msg = SubscribedMessage(markets=msg.get("markets", 0))
            for h in self._handlers["subscribed"]:
                h(sub_msg)

        elif msg_type == "snapshot_batch":
            snapshots = msg.get("snapshots", [])
            for snap_data in snapshots:
                snap = BookSnapshot.model_validate(snap_data)
                for h in self._handlers["snapshot"]:
                    h(snap)
                for h in self._handlers["*"]:
                    h(snap)

        elif msg_type == "snapshots_done":
            done = SnapshotsDoneMessage(total=msg.get("total", 0))
            for h in self._handlers["snapshots_done"]:
                h(done)

        elif msg_type == "batch":
            updates = msg.get("updates", [])
            for update_data in updates:
                self._dispatch_update(update_data)

    def _dispatch_update(self, data: dict) -> None:
        update_type = data.get("type")
        if update_type == "book_snapshot":
            snap = BookSnapshot.model_validate(data)
            for h in self._handlers["snapshot"]:
                h(snap)
            for h in self._handlers["*"]:
                h(snap)
        elif update_type == "book_update":
            update = BookUpdate.model_validate(data)
            for h in self._handlers["update"]:
                h(update)
            for h in self._handlers["*"]:
                h(update)
        elif update_type == "price_change":
            change = PriceChange.model_validate(data)
            for h in self._handlers["price"]:
                h(change)
            for h in self._handlers["*"]:
                h(change)

    async def _schedule_reconnect(self) -> None:
        if self._max_reconnect and self._reconnect_attempts >= self._max_reconnect:
            return

        self._reconnect_attempts += 1
        delay = min(self._base_delay * math.pow(2, self._reconnect_attempts - 1), self._max_delay)
        jitter = delay * (0.5 + random.random() * 0.5)

        await asyncio.sleep(jitter)

        try:
            await self._connect()
            for h in self._on_reconnect:
                h(self._reconnect_attempts)
            if self._token_ids:
                await self._send(json.dumps({"action": "subscribe", "markets": self._token_ids}))
        except Exception:
            pass
