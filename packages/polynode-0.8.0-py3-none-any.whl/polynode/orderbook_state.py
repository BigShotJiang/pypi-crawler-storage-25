"""Local orderbook state manager."""

from __future__ import annotations

from .types.orderbook import BookSnapshot, BookUpdate, OrderbookLevel, PriceChange


class LocalOrderbook:
    """Maintains sorted local copies of orderbooks for any number of assets."""

    def __init__(self) -> None:
        self._books: dict[str, tuple[list[OrderbookLevel], list[OrderbookLevel]]] = {}

    def apply_snapshot(self, snap: BookSnapshot) -> None:
        bids = sorted(list(snap.bids), key=lambda l: float(l.price), reverse=True)
        asks = sorted(list(snap.asks), key=lambda l: float(l.price))
        self._books[snap.asset_id] = (bids, asks)

    def apply_update(self, update: BookUpdate) -> None:
        if update.asset_id not in self._books:
            self._books[update.asset_id] = ([], [])
        bids, asks = self._books[update.asset_id]
        new_bids = _apply_deltas(bids, update.bids, reverse=True)
        new_asks = _apply_deltas(asks, update.asks, reverse=False)
        self._books[update.asset_id] = (new_bids, new_asks)

    def apply_price_change(self, change: PriceChange) -> None:
        pass

    def get_book(self, asset_id: str) -> tuple[list[OrderbookLevel], list[OrderbookLevel]] | None:
        return self._books.get(asset_id)

    def get_best_bid(self, asset_id: str) -> OrderbookLevel | None:
        book = self._books.get(asset_id)
        if book and book[0]:
            return book[0][0]
        return None

    def get_best_ask(self, asset_id: str) -> OrderbookLevel | None:
        book = self._books.get(asset_id)
        if book and book[1]:
            return book[1][0]
        return None

    def get_spread(self, asset_id: str) -> float | None:
        bid = self.get_best_bid(asset_id)
        ask = self.get_best_ask(asset_id)
        if not bid or not ask:
            return None
        return float(ask.price) - float(bid.price)

    @property
    def size(self) -> int:
        return len(self._books)

    def clear(self) -> None:
        self._books.clear()


def _apply_deltas(
    levels: list[OrderbookLevel],
    deltas: list[OrderbookLevel],
    *,
    reverse: bool,
) -> list[OrderbookLevel]:
    price_map: dict[str, str] = {}
    for level in levels:
        price_map[level.price] = level.size
    for delta in deltas:
        if delta.size == "0" or delta.size == "0.00":
            price_map.pop(delta.price, None)
        else:
            price_map[delta.price] = delta.size

    result = [OrderbookLevel(price=p, size=s) for p, s in price_map.items()]
    result.sort(key=lambda l: float(l.price), reverse=reverse)
    return result
