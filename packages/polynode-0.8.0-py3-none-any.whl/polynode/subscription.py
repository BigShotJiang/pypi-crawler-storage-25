"""Subscription builder and async iterator for PolyNode WebSocket events."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any, Callable

from .types.enums import EventType, SubscriptionType
from .types.events import PolyNodeEvent
from .types.ws import SubscriptionFilters

if TYPE_CHECKING:
    from .ws import PolyNodeWS


class SubscriptionBuilder:
    """Fluent builder for WebSocket subscriptions."""

    def __init__(self, ws: PolyNodeWS, type: SubscriptionType) -> None:
        self._ws = ws
        self._type = type
        self._filters = SubscriptionFilters()

    def wallets(self, addresses: list[str]) -> SubscriptionBuilder:
        self._filters.wallets = addresses
        return self

    def tokens(self, token_ids: list[str]) -> SubscriptionBuilder:
        self._filters.tokens = token_ids
        return self

    def slugs(self, slugs: list[str]) -> SubscriptionBuilder:
        self._filters.slugs = slugs
        return self

    def condition_ids(self, ids: list[str]) -> SubscriptionBuilder:
        self._filters.condition_ids = ids
        return self

    def side(self, side: str) -> SubscriptionBuilder:
        self._filters.side = side
        return self

    def status(self, status: str) -> SubscriptionBuilder:
        self._filters.status = status
        return self

    def min_size(self, usd: float) -> SubscriptionBuilder:
        self._filters.min_size = usd
        return self

    def max_size(self, usd: float) -> SubscriptionBuilder:
        self._filters.max_size = usd
        return self

    def event_types(self, types: list[EventType]) -> SubscriptionBuilder:
        self._filters.event_types = types
        return self

    def snapshot_count(self, count: int) -> SubscriptionBuilder:
        self._filters.snapshot_count = count
        return self

    def feeds(self, feed_names: list[str]) -> SubscriptionBuilder:
        self._filters.feeds = feed_names
        return self

    async def send(self) -> Subscription:
        return await self._ws._subscribe(self._type, self._filters)


class Subscription:
    """An active WebSocket subscription with event handling and async iteration."""

    def __init__(self, ws: PolyNodeWS, type: SubscriptionType, filters: SubscriptionFilters) -> None:
        self._ws = ws
        self.type = type
        self.filters = filters
        self._id: str | None = None
        self._handlers: dict[str, set[Callable]] = {}
        self._queue: asyncio.Queue[PolyNodeEvent | None] = asyncio.Queue()
        self._closed = False

    @property
    def id(self) -> str | None:
        return self._id

    def _set_id(self, id: str) -> None:
        self._id = id

    def on(self, type: str, handler: Callable) -> Subscription:
        if type not in self._handlers:
            self._handlers[type] = set()
        self._handlers[type].add(handler)
        return self

    def off(self, type: str, handler: Callable) -> Subscription:
        if type in self._handlers:
            self._handlers[type].discard(handler)
        return self

    def _emit(self, event: PolyNodeEvent) -> None:
        # Typed handlers
        event_type = event.event_type  # type: ignore[union-attr]
        handlers = self._handlers.get(event_type)
        if handlers:
            for h in handlers:
                h(event)
        # Catch-all
        star = self._handlers.get("*")
        if star:
            for h in star:
                h(event)
        # Async iterator queue
        self._queue.put_nowait(event)

    def unsubscribe(self) -> None:
        self._closed = True
        self._queue.put_nowait(None)
        self._ws._unsubscribe(self._id)

    def __aiter__(self):
        return self

    async def __anext__(self) -> PolyNodeEvent:
        if self._closed:
            raise StopAsyncIteration
        event = await self._queue.get()
        if event is None:
            raise StopAsyncIteration
        return event

    async def __aenter__(self) -> Subscription:
        return self

    async def __aexit__(self, *args: Any) -> None:
        self.unsubscribe()
