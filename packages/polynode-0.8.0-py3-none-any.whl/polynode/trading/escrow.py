"""Fee Escrow — EIP-712 signing, fee calculation, and nonce fetching
for the on-chain FeeEscrow contract.

The escrow is completely optional. When fee_bps=0, none of this code runs.
"""

from __future__ import annotations

import math
import os
import secrets
from dataclasses import dataclass
from typing import Any

import httpx

from .constants import CHAIN_ID, FEE_ESCROW_ADDRESS
from .types import Eip712Payload

# ── EIP-712 Types ──

FEE_AUTH_DOMAIN = {
    "name": "PolyNodeFeeEscrow",
    "version": "1",
    "chainId": CHAIN_ID,
    "verifyingContract": FEE_ESCROW_ADDRESS,
}

FEE_AUTH_TYPES = {
    "FeeAuth": [
        {"name": "orderId", "type": "bytes32"},
        {"name": "payer", "type": "address"},
        {"name": "signer", "type": "address"},
        {"name": "feeAmount", "type": "uint256"},
        {"name": "deadline", "type": "uint256"},
        {"name": "nonce", "type": "uint256"},
    ],
}

ZERO_ADDRESS = "0x0000000000000000000000000000000000000000"


# ── Fee Calculation ──

def calculate_fee(price: float, size: float, fee_bps: int) -> int:
    """Calculate fee amount in raw USDC (6 decimals).

    Args:
        price: Order price (e.g. 0.55)
        size: Order size in tokens (e.g. 100)
        fee_bps: Fee in basis points (e.g. 50 = 0.5%)

    Returns:
        Fee amount as int in raw USDC units
    """
    notional_raw = math.floor(price * size * 1e6)
    fee = math.floor(notional_raw * fee_bps / 10000)
    return max(fee, 0)


# ── Order ID Generation ──

def generate_escrow_order_id() -> str:
    """Generate a random bytes32 escrow order ID (0x-prefixed hex)."""
    return "0x" + secrets.token_hex(32)


# ── Nonce Fetching ──

async def fetch_escrow_nonce(rpc_url: str, signer_address: str) -> int:
    """Fetch the current nonce for a signer from the FeeEscrow contract via eth_call."""
    # getNonce(address) selector = 0x2d0335ab
    addr = signer_address.lower().replace("0x", "").zfill(64)
    data = "0x2d0335ab" + addr

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "eth_call",
                "params": [{"to": FEE_ESCROW_ADDRESS, "data": data}, "latest"],
            },
        )
        result = resp.json()

    if "error" in result:
        raise RuntimeError(f"Failed to fetch escrow nonce: {result['error']}")
    return int(result.get("result", "0x0"), 16)


# ── EIP-712 Signing ──

@dataclass
class FeeAuthRequest:
    escrow_order_id: str
    payer: str
    signer: str
    fee_amount: str
    deadline: int
    nonce: int
    signature: str
    affiliate: str
    affiliate_share_bps: int


async def sign_fee_auth(
    sign_typed_data: Any,
    *,
    escrow_order_id: str,
    payer: str,
    signer_address: str,
    fee_amount: int,
    deadline: int,
    nonce: int,
    affiliate: str | None = None,
    affiliate_share_bps: int | None = None,
) -> FeeAuthRequest:
    """Sign a FeeAuth EIP-712 message.

    Args:
        sign_typed_data: Callable that signs an Eip712Payload and returns a hex signature.
        escrow_order_id: Random bytes32 hex string.
        payer: Safe wallet address (where USDC is pulled from).
        signer_address: EOA address (signs the message).
        fee_amount: Fee in raw USDC (6 decimals).
        deadline: Unix timestamp — authorization expires after this.
        nonce: Signer's current nonce from the escrow contract.
        affiliate: Partner wallet address.
        affiliate_share_bps: Partner's share of fee in bps.

    Returns:
        FeeAuthRequest ready for the cosigner.
    """
    message = {
        "orderId": escrow_order_id,
        "payer": payer,
        "signer": signer_address,
        "feeAmount": str(fee_amount),
        "deadline": str(deadline),
        "nonce": str(nonce),
    }

    payload = Eip712Payload(
        domain=FEE_AUTH_DOMAIN,
        types=FEE_AUTH_TYPES,
        primary_type="FeeAuth",
        message=message,
    )

    signature = await sign_typed_data(payload)
    if not signature.startswith("0x"):
        signature = f"0x{signature}"

    return FeeAuthRequest(
        escrow_order_id=escrow_order_id,
        payer=payer,
        signer=signer_address,
        fee_amount=str(fee_amount),
        deadline=deadline,
        nonce=nonce,
        signature=signature,
        affiliate=affiliate or ZERO_ADDRESS,
        affiliate_share_bps=affiliate_share_bps if affiliate_share_bps is not None else 10000,
    )
