"""Wallet signer abstraction — normalizes private keys and RouterSigners."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .types import RouterSigner, SignatureType


@dataclass
class NormalizedSigner:
    address: str
    sign_typed_data: Any  # callable
    sign_message: Any  # callable or None
    signature_type: SignatureType
    funder_address: str | None = None
    _private_key: str | None = None  # stored for on-chain txn signing (wrap/unwrap)


async def normalize_signer(
    signer: str | RouterSigner,
    default_signature_type: SignatureType = SignatureType.POLY_GNOSIS_SAFE,
) -> NormalizedSigner:
    """Normalize a private key string or RouterSigner into a consistent interface."""

    if isinstance(signer, str):
        # Hex private key
        try:
            from eth_account import Account
        except ImportError:
            raise ImportError(
                "eth-account is required for trading. Install with: pip install polynode[trading]"
            )

        key = signer if signer.startswith("0x") else f"0x{signer}"
        account = Account.from_key(key)

        async def _sign_typed_data(payload: Any) -> str:
            from eth_account.messages import encode_typed_data
            # Build full EIP-712 message dict for encode_typed_data
            eip712_domain_type = [
                {"name": k, "type": "string" if isinstance(v, str) else ("uint256" if isinstance(v, int) else "address")}
                for k, v in payload.domain.items()
            ]
            full_message = {
                "primaryType": payload.primary_type,
                "domain": payload.domain,
                "types": {**payload.types, "EIP712Domain": eip712_domain_type},
                "message": payload.message,
            }
            msg = encode_typed_data(full_message=full_message)
            signed = account.sign_message(msg)
            return signed.signature.hex()

        async def _sign_message(message: str | bytes) -> str:
            from eth_account.messages import encode_defunct
            if isinstance(message, bytes):
                msg = encode_defunct(primitive=message)
            else:
                msg = encode_defunct(text=message)
            signed = account.sign_message(msg)
            return signed.signature.hex()

        return NormalizedSigner(
            address=account.address,
            sign_typed_data=_sign_typed_data,
            sign_message=_sign_message,
            signature_type=default_signature_type,
            _private_key=key,
        )

    if isinstance(signer, RouterSigner):
        address = await signer.get_address()

        async def _rs_sign_typed_data(payload: Any) -> str:
            return await signer.sign_typed_data(payload)

        _rs_sign_message = None
        if hasattr(signer, "sign_message") and callable(getattr(signer, "sign_message", None)):
            async def _rs_sign_message(message: str | bytes) -> str:
                return await signer.sign_message(message)  # type: ignore

        return NormalizedSigner(
            address=address,
            sign_typed_data=_rs_sign_typed_data,
            sign_message=_rs_sign_message,
            signature_type=default_signature_type,
        )

    raise TypeError(
        "Unsupported signer type. Provide a hex private key string or RouterSigner."
    )
