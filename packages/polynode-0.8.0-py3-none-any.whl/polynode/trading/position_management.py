"""
Position management — build transactions for split, merge, and convert on Polymarket.

These functions return TransactionRequest objects containing the contract address
and ABI-encoded calldata. Submit them via the Polymarket relayer (gasless for
Safe wallets) or directly on-chain.

    from polynode.trading.position_management import build_split_txn, build_convert_txn

    # Split $100 into YES + NO tokens
    tx = build_split_txn("0xabc...conditionId", 100.0, neg_risk=True)

    # Convert NO positions on outcomes 0 and 1
    tx = build_convert_txn("0xdef...marketId", [0, 1], 50.0)
"""

from .constants import CTF, NEG_RISK_ADAPTER, USDC
from .types import TransactionRequest


def build_split_txn(condition_id: str, amount: float, neg_risk: bool = True) -> TransactionRequest:
    """Build a split transaction: USDC -> YES + NO outcome tokens.

    Routes to NegRiskAdapter for neg-risk markets, CTF for standard markets.
    Amount is in USDC (e.g. 100.0 = $100).
    """
    amount_raw = int(amount * 1_000_000)

    if neg_risk:
        # NegRiskAdapter.splitPosition(bytes32 conditionId, uint256 amount)
        data = "0xa3d7da1d" + _encode_bytes32(condition_id) + _encode_uint256(amount_raw)
        return TransactionRequest(to=NEG_RISK_ADAPTER, data=data)
    else:
        # CTF.splitPosition(address, bytes32, bytes32, uint256[], uint256)
        data = (
            "0x72108503"
            + _encode_address(USDC)
            + "00" * 32  # parentCollectionId = bytes32(0)
            + _encode_bytes32(condition_id)
            + _encode_uint256(160)  # offset to partition array
            + _encode_uint256(amount_raw)
            + _encode_uint256(2)  # partition length
            + _encode_uint256(1)
            + _encode_uint256(2)
        )
        return TransactionRequest(to=CTF, data=data)


def build_merge_txn(condition_id: str, amount: float, neg_risk: bool = True) -> TransactionRequest:
    """Build a merge transaction: YES + NO outcome tokens -> USDC."""
    amount_raw = int(amount * 1_000_000)

    if neg_risk:
        # NegRiskAdapter.mergePositions(bytes32 conditionId, uint256 amount)
        data = "0x5d03f453" + _encode_bytes32(condition_id) + _encode_uint256(amount_raw)
        return TransactionRequest(to=NEG_RISK_ADAPTER, data=data)
    else:
        # CTF.mergePositions(address, bytes32, bytes32, uint256[], uint256)
        data = (
            "0xcad9440e"
            + _encode_address(USDC)
            + "00" * 32
            + _encode_bytes32(condition_id)
            + _encode_uint256(160)
            + _encode_uint256(amount_raw)
            + _encode_uint256(2)
            + _encode_uint256(1)
            + _encode_uint256(2)
        )
        return TransactionRequest(to=CTF, data=data)


def build_convert_txn(market_id: str, outcome_indices: list[int], amount: float) -> TransactionRequest:
    """Build a convert transaction: NO positions -> USDC + YES on complementary outcomes.

    Only works on neg-risk multi-outcome markets.
    outcome_indices: which outcomes' NOs to convert (e.g. [0, 1]).
    """
    amount_raw = int(amount * 1_000_000)

    # Compute indexSet bitmask
    index_set = 0
    for idx in outcome_indices:
        index_set |= 1 << idx

    # NegRiskAdapter.convertPositions(bytes32 marketId, uint256 indexSet, uint256 amount)
    data = "0xc64748c4" + _encode_bytes32(market_id) + _encode_uint256(index_set) + _encode_uint256(amount_raw)
    return TransactionRequest(to=NEG_RISK_ADAPTER, data=data)


# ── Encoding helpers ──

def _encode_bytes32(hex_str: str) -> str:
    s = hex_str.removeprefix("0x")
    return s.zfill(64)[:64]


def _encode_address(addr: str) -> str:
    s = addr.removeprefix("0x")
    return s.lower().zfill(64)


def _encode_uint256(val: int) -> str:
    return hex(val)[2:].zfill(64)
