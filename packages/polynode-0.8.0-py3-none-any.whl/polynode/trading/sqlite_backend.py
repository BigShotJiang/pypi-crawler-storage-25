"""SQLite storage backend for trading credentials, market metadata, and order history."""

from __future__ import annotations

import sqlite3
import time
from typing import Any

from .constants import META_TTL_SECONDS
from .types import HistoryParams, MarketMeta, OrderHistoryRow, SignatureType, StoredCredentials


class TradingSqliteBackend:
    """Local SQLite storage for trading module."""

    SCHEMA_VERSION = 2

    def __init__(self, db_path: str) -> None:
        self._db = sqlite3.connect(db_path)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._init_schema()
        self._migrate()

    def _init_schema(self) -> None:
        self._db.executescript("""
            CREATE TABLE IF NOT EXISTS clob_credentials (
                wallet_address TEXT PRIMARY KEY,
                funder_address TEXT,
                api_key TEXT NOT NULL,
                api_secret TEXT NOT NULL,
                api_passphrase TEXT NOT NULL,
                signature_type INTEGER NOT NULL DEFAULT 2,
                safe_deployed INTEGER NOT NULL DEFAULT 0,
                approvals_set INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS market_meta (
                token_id TEXT PRIMARY KEY,
                tick_size TEXT NOT NULL,
                fee_rate_bps INTEGER NOT NULL DEFAULT 0,
                neg_risk INTEGER NOT NULL DEFAULT 0,
                fetched_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS order_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                wallet_address TEXT NOT NULL,
                order_id TEXT,
                token_id TEXT NOT NULL,
                side TEXT NOT NULL,
                price REAL NOT NULL,
                size REAL NOT NULL,
                order_type TEXT NOT NULL DEFAULT 'GTC',
                status TEXT NOT NULL DEFAULT 'submitting',
                error_msg TEXT,
                response_json TEXT,
                created_at REAL NOT NULL,
                fee_amount_raw TEXT,
                escrow_order_id TEXT,
                fee_escrow_tx_hash TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_order_history_wallet ON order_history(wallet_address);
            CREATE INDEX IF NOT EXISTS idx_order_history_token ON order_history(token_id);
        """)

    def _migrate(self) -> None:
        """Run schema migrations for existing databases."""
        # Check if fee escrow columns exist (v2 migration)
        cols = {row[1] for row in self._db.execute("PRAGMA table_info(order_history)").fetchall()}
        if "fee_amount_raw" not in cols:
            self._db.executescript("""
                ALTER TABLE order_history ADD COLUMN fee_amount_raw TEXT;
                ALTER TABLE order_history ADD COLUMN escrow_order_id TEXT;
                ALTER TABLE order_history ADD COLUMN fee_escrow_tx_hash TEXT;
            """)

    def get_credentials(self, wallet_address: str) -> StoredCredentials | None:
        row = self._db.execute(
            "SELECT * FROM clob_credentials WHERE wallet_address = ? COLLATE NOCASE",
            (wallet_address,),
        ).fetchone()
        if not row:
            return None
        return StoredCredentials(
            wallet_address=row[0],
            funder_address=row[1],
            api_key=row[2],
            api_secret=row[3],
            api_passphrase=row[4],
            signature_type=SignatureType(row[5]),
            safe_deployed=bool(row[6]),
            approvals_set=bool(row[7]),
            created_at=row[8],
            updated_at=row[9],
        )

    def upsert_credentials(self, creds: StoredCredentials) -> None:
        self._db.execute(
            """INSERT OR REPLACE INTO clob_credentials
               (wallet_address, funder_address, api_key, api_secret, api_passphrase,
                signature_type, safe_deployed, approvals_set, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                creds.wallet_address,
                creds.funder_address,
                creds.api_key,
                creds.api_secret,
                creds.api_passphrase,
                int(creds.signature_type),
                int(creds.safe_deployed),
                int(creds.approvals_set),
                creds.created_at,
                creds.updated_at,
            ),
        )
        self._db.commit()

    def delete_credentials(self, wallet_address: str) -> None:
        self._db.execute(
            "DELETE FROM clob_credentials WHERE wallet_address = ? COLLATE NOCASE",
            (wallet_address,),
        )
        self._db.commit()

    def get_all_credentials(self) -> list[StoredCredentials]:
        rows = self._db.execute("SELECT * FROM clob_credentials").fetchall()
        return [
            StoredCredentials(
                wallet_address=r[0], funder_address=r[1], api_key=r[2],
                api_secret=r[3], api_passphrase=r[4], signature_type=SignatureType(r[5]),
                safe_deployed=bool(r[6]), approvals_set=bool(r[7]),
                created_at=r[8], updated_at=r[9],
            )
            for r in rows
        ]

    def get_market_meta(self, token_id: str) -> MarketMeta | None:
        row = self._db.execute(
            "SELECT * FROM market_meta WHERE token_id = ?", (token_id,)
        ).fetchone()
        if not row:
            return None
        meta = MarketMeta(
            token_id=row[0], tick_size=row[1], fee_rate_bps=row[2],
            neg_risk=bool(row[3]), fetched_at=row[4],
        )
        if time.time() - meta.fetched_at > META_TTL_SECONDS:
            return None
        return meta

    def upsert_market_meta(self, meta: MarketMeta) -> None:
        self._db.execute(
            """INSERT OR REPLACE INTO market_meta
               (token_id, tick_size, fee_rate_bps, neg_risk, fetched_at)
               VALUES (?, ?, ?, ?, ?)""",
            (meta.token_id, meta.tick_size, meta.fee_rate_bps, int(meta.neg_risk), meta.fetched_at),
        )
        self._db.commit()

    def insert_order(self, order: dict[str, Any]) -> int:
        cur = self._db.execute(
            """INSERT INTO order_history
               (wallet_address, order_id, token_id, side, price, size, order_type,
                status, error_msg, response_json, created_at,
                fee_amount_raw, escrow_order_id, fee_escrow_tx_hash)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                order["wallet_address"], order.get("order_id"), order["token_id"],
                order["side"], order["price"], order["size"], order.get("order_type", "GTC"),
                order.get("status", "submitting"), order.get("error_msg"),
                order.get("response_json"), order.get("created_at", time.time()),
                order.get("fee_amount_raw"), order.get("escrow_order_id"),
                order.get("fee_escrow_tx_hash"),
            ),
        )
        self._db.commit()
        return cur.lastrowid  # type: ignore

    def update_order_status(
        self, row_id: int, status: str, order_id: str | None = None,
        error_msg: str | None = None, response_json: str | None = None,
        fee_amount_raw: str | None = None, escrow_order_id: str | None = None,
        fee_escrow_tx_hash: str | None = None,
    ) -> None:
        self._db.execute(
            """UPDATE order_history
               SET status = ?, order_id = COALESCE(?, order_id),
                   error_msg = COALESCE(?, error_msg), response_json = COALESCE(?, response_json),
                   fee_amount_raw = COALESCE(?, fee_amount_raw), escrow_order_id = COALESCE(?, escrow_order_id),
                   fee_escrow_tx_hash = COALESCE(?, fee_escrow_tx_hash)
               WHERE id = ?""",
            (status, order_id, error_msg, response_json, fee_amount_raw, escrow_order_id, fee_escrow_tx_hash, row_id),
        )
        self._db.commit()

    def get_order_history(self, wallet_address: str, params: HistoryParams | None = None) -> list[OrderHistoryRow]:
        sql = "SELECT * FROM order_history WHERE wallet_address = ? COLLATE NOCASE"
        args: list[Any] = [wallet_address]

        if params:
            if params.token_id:
                sql += " AND token_id = ?"
                args.append(params.token_id)
            if params.side:
                sql += " AND side = ?"
                args.append(params.side)

        sql += " ORDER BY created_at DESC"

        if params and params.limit:
            sql += " LIMIT ?"
            args.append(params.limit)
        if params and params.offset:
            sql += " OFFSET ?"
            args.append(params.offset)

        rows = self._db.execute(sql, args).fetchall()
        return [
            OrderHistoryRow(
                id=r[0], wallet_address=r[1], order_id=r[2], token_id=r[3],
                side=r[4], price=r[5], size=r[6], order_type=r[7],
                status=r[8], error_msg=r[9], response_json=r[10], created_at=r[11],
                fee_amount_raw=r[12] if len(r) > 12 else None,
                escrow_order_id=r[13] if len(r) > 13 else None,
                fee_escrow_tx_hash=r[14] if len(r) > 14 else None,
            )
            for r in rows
        ]

    def close(self) -> None:
        self._db.close()
