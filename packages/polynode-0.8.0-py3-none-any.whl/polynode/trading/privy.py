"""Privy server-side wallet integration for headless order signing.

Creates RouterSigner instances that call Privy's wallet API for EIP-712
signing — no browser, no user interaction. This is the Python equivalent
of the TypeScript SDK's createPrivySigner.

Requires: pip install httpx (already a polynode dependency)
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Any

import httpx

PRIVY_API_BASE = "https://auth.privy.io/api/v1"


def _compute_eip712_hash(payload: Any) -> bytes:
    """Compute the EIP-712 hash locally using eth_account's encode_typed_data.

    This matches what on-chain contracts expect and avoids any encoding
    differences from Privy's signTypedData implementation.
    """
    from eth_account.messages import encode_typed_data
    from eth_utils import keccak

    # Build EIP712Domain type from domain fields
    domain_type = []
    if "name" in payload.domain:
        domain_type.append({"name": "name", "type": "string"})
    if "version" in payload.domain:
        domain_type.append({"name": "version", "type": "string"})
    if "chainId" in payload.domain:
        domain_type.append({"name": "chainId", "type": "uint256"})
    if "verifyingContract" in payload.domain:
        domain_type.append({"name": "verifyingContract", "type": "address"})

    full_message = {
        "primaryType": payload.primary_type,
        "domain": payload.domain,
        "types": {**payload.types, "EIP712Domain": domain_type},
        "message": payload.message,
    }

    signable = encode_typed_data(full_message=full_message)
    # EIP-712 hash = keccak(0x19 0x01 + domainSeparator + structHash)
    # signable.header = domainSeparator, signable.body = structHash
    return keccak(b"\x19\x01" + signable.header + signable.body)


@dataclass
class PrivyConfig:
    app_id: str
    app_secret: str
    authorization_key: str


class PrivySigner:
    """A RouterSigner backed by Privy's server-auth wallet API."""

    def __init__(self, config: PrivyConfig, wallet_id: str, wallet_address: str):
        self.config = config
        self.wallet_id = wallet_id
        self.wallet_address = wallet_address
        self._headers = {
            "privy-app-id": config.app_id,
            "Authorization": f"Basic {base64.b64encode(f'{config.app_id}:{config.app_secret}'.encode()).decode()}",
            "privy-authorization-key": config.authorization_key,
            "Content-Type": "application/json",
        }

    async def get_address(self) -> str:
        return self.wallet_address

    async def sign_typed_data(self, payload: Any) -> str:
        """Sign EIP-712 typed data via Privy wallet API.

        Uses secp256k1_sign with a locally-computed EIP-712 hash to ensure
        the hash matches exactly what on-chain contracts expect. Privy's
        eth_signTypedData_v4 can produce different hashes due to encoding
        differences (integer serialization, field ordering).
        """
        msg_hash = _compute_eip712_hash(payload)

        async with httpx.AsyncClient(timeout=15.0) as http:
            resp = await http.post(
                f"{PRIVY_API_BASE}/wallets/{self.wallet_id}/rpc",
                headers=self._headers,
                json={
                    "method": "secp256k1_sign",
                    "params": {"hash": "0x" + msg_hash.hex()},
                },
            )
            if not resp.is_success:
                raise RuntimeError(f"Privy secp256k1_sign failed: {resp.status_code} {resp.text}")
            data = resp.json()
            return data["data"]["signature"]

    async def sign_message(self, message: str | bytes) -> str:
        """Sign a personal message via Privy wallet API."""
        if isinstance(message, bytes):
            msg_value = "0x" + message.hex()
            encoding = "hex"
        else:
            msg_value = message
            encoding = "utf-8"

        async with httpx.AsyncClient(timeout=15.0) as http:
            resp = await http.post(
                f"{PRIVY_API_BASE}/wallets/{self.wallet_id}/rpc",
                headers=self._headers,
                json={
                    "method": "personal_sign",
                    "params": {"message": msg_value, "encoding": encoding},
                },
            )
            if not resp.is_success:
                raise RuntimeError(f"Privy signMessage failed: {resp.status_code} {resp.text}")
            data = resp.json()
            return data["data"]["signature"]
