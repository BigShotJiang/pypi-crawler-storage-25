"""Pure Python EIP-712 order signing for Polymarket exchange contracts."""

from __future__ import annotations

import math
from typing import Any

from .constants import (
    CTF_EXCHANGE,
    CTF_EXCHANGE_V2,
    NEG_RISK_CTF_EXCHANGE,
    NEG_RISK_CTF_EXCHANGE_V2_A,
)
from .types import Eip712Payload, ExchangeVersion, SignatureType


# ── V1 EIP-712 domains ──

EXCHANGE_DOMAIN = {
    "name": "Polymarket CTF Exchange",
    "version": "1",
    "chainId": 137,
    "verifyingContract": CTF_EXCHANGE,
}

NEG_RISK_DOMAIN = {
    "name": "Polymarket CTF Exchange",
    "version": "1",
    "chainId": 137,
    "verifyingContract": NEG_RISK_CTF_EXCHANGE,
}

ORDER_TYPES = {
    "Order": [
        {"name": "salt", "type": "uint256"},
        {"name": "maker", "type": "address"},
        {"name": "signer", "type": "address"},
        {"name": "taker", "type": "address"},
        {"name": "tokenId", "type": "uint256"},
        {"name": "makerAmount", "type": "uint256"},
        {"name": "takerAmount", "type": "uint256"},
        {"name": "expiration", "type": "uint256"},
        {"name": "nonce", "type": "uint256"},
        {"name": "feeRateBps", "type": "uint256"},
        {"name": "side", "type": "uint8"},
        {"name": "signatureType", "type": "uint8"},
    ],
}

# ── V2 EIP-712 domains ──

EXCHANGE_DOMAIN_V2 = {
    "name": "Polymarket CTF Exchange",
    "version": "2",
    "chainId": 137,
    "verifyingContract": CTF_EXCHANGE_V2,
}

NEG_RISK_DOMAIN_V2 = {
    "name": "Polymarket CTF Exchange",
    "version": "2",
    "chainId": 137,
    "verifyingContract": NEG_RISK_CTF_EXCHANGE_V2_A,
}

ORDER_TYPES_V2 = {
    "Order": [
        {"name": "salt", "type": "uint256"},
        {"name": "maker", "type": "address"},
        {"name": "signer", "type": "address"},
        {"name": "tokenId", "type": "uint256"},
        {"name": "makerAmount", "type": "uint256"},
        {"name": "takerAmount", "type": "uint256"},
        {"name": "side", "type": "uint8"},
        {"name": "signatureType", "type": "uint8"},
        {"name": "timestamp", "type": "uint256"},
        {"name": "metadata", "type": "bytes32"},
        {"name": "builder", "type": "bytes32"},
    ],
}


def compute_amounts(
    price: float,
    size: float,
    side: str,
    tick_size: str,
) -> tuple[int, int]:
    """Compute maker_amount and taker_amount from price/size/tick_size."""
    decimals = len(tick_size.rstrip("0").split(".")[-1]) if "." in tick_size else 0
    raw_price = round(price * (10 ** decimals))
    raw_size = round(size * 1_000_000)  # USDC has 6 decimals
    price_denom = 10 ** decimals

    if side == "BUY":
        maker_amount = raw_size * raw_price // price_denom
        taker_amount = raw_size
    else:
        maker_amount = raw_size
        taker_amount = raw_size * raw_price // price_denom

    return maker_amount, taker_amount


def build_order_payload(
    *,
    maker: str,
    signer: str,
    token_id: str,
    maker_amount: int,
    taker_amount: int,
    side: str,
    signature_type: SignatureType,
    fee_rate_bps: int = 0,
    nonce: int = 0,
    expiration: int = 0,
    neg_risk: bool = False,
) -> Eip712Payload:
    """Build an EIP-712 typed data payload for a Polymarket order."""
    import secrets

    salt = secrets.randbelow(2**32)
    side_int = 0 if side == "BUY" else 1

    domain = NEG_RISK_DOMAIN if neg_risk else EXCHANGE_DOMAIN

    message = {
        "salt": salt,
        "maker": maker,
        "signer": signer,
        "taker": "0x0000000000000000000000000000000000000000",
        "tokenId": int(token_id),
        "makerAmount": maker_amount,
        "takerAmount": taker_amount,
        "expiration": expiration,
        "nonce": nonce,
        "feeRateBps": fee_rate_bps,
        "side": side_int,
        "signatureType": int(signature_type),
    }

    return Eip712Payload(
        domain=domain,
        types=ORDER_TYPES,
        primary_type="Order",
        message=message,
    )


async def create_signed_order(
    sign_typed_data: Any,
    *,
    signer_address: str,
    funder_address: str,
    token_id: str,
    price: float,
    size: float,
    side: str,
    signature_type: SignatureType,
    tick_size: str = "0.01",
    neg_risk: bool = False,
    fee_rate_bps: int = 0,
    expiration: int = 0,
    nonce: int = 0,
) -> dict[str, Any]:
    """Create and sign a V1 Polymarket order. Returns the order dict ready for CLOB submission."""
    maker_amount, taker_amount = compute_amounts(price, size, side, tick_size)

    payload = build_order_payload(
        maker=funder_address,
        signer=signer_address,
        token_id=token_id,
        maker_amount=maker_amount,
        taker_amount=taker_amount,
        side=side,
        signature_type=signature_type,
        fee_rate_bps=fee_rate_bps,
        nonce=nonce,
        expiration=expiration,
        neg_risk=neg_risk,
    )

    signature = await sign_typed_data(payload)
    if not signature.startswith("0x"):
        signature = f"0x{signature}"

    # Normalize v to raw recovery id (0/1): CLOB expects v=0/1 for order signatures
    sig_bytes = bytearray(bytes.fromhex(signature[2:]))
    if len(sig_bytes) == 65 and sig_bytes[-1] >= 27:
        sig_bytes[-1] -= 27
    signature = "0x" + sig_bytes.hex()

    return {
        "salt": payload.message["salt"],
        "maker": funder_address,
        "signer": signer_address,
        "taker": "0x0000000000000000000000000000000000000000",
        "tokenId": token_id,
        "makerAmount": str(maker_amount),
        "takerAmount": str(taker_amount),
        "expiration": str(expiration),
        "nonce": str(nonce),
        "feeRateBps": str(fee_rate_bps),
        "side": side,
        "signatureType": int(signature_type),
        "signature": signature,
    }


# ── V2 order building ──


def build_order_payload_v2(
    *,
    maker: str,
    signer: str,
    token_id: str,
    maker_amount: int,
    taker_amount: int,
    side: str,
    signature_type: SignatureType,
    neg_risk: bool = False,
    timestamp_ms: int | None = None,
    metadata: str = "0x" + "00" * 32,
    builder: str = "0x" + "00" * 32,
) -> Eip712Payload:
    """Build a V2 EIP-712 typed data payload for a Polymarket order."""
    import time

    if timestamp_ms is None:
        timestamp_ms = int(time.time() * 1000)

    salt = timestamp_ms
    side_int = 0 if side == "BUY" else 1
    domain = NEG_RISK_DOMAIN_V2 if neg_risk else EXCHANGE_DOMAIN_V2

    # Pad metadata/builder to bytes32
    meta_hex = metadata if metadata.startswith("0x") else f"0x{metadata}"
    meta_hex = meta_hex[:2] + meta_hex[2:].ljust(64, "0")
    builder_hex = builder if builder.startswith("0x") else f"0x{builder}"
    builder_hex = builder_hex[:2] + builder_hex[2:].ljust(64, "0")

    message = {
        "salt": salt,
        "maker": maker,
        "signer": signer,
        "tokenId": int(token_id),
        "makerAmount": maker_amount,
        "takerAmount": taker_amount,
        "side": side_int,
        "signatureType": int(signature_type),
        "timestamp": timestamp_ms,
        "metadata": meta_hex,
        "builder": builder_hex,
    }

    return Eip712Payload(
        domain=domain,
        types=ORDER_TYPES_V2,
        primary_type="Order",
        message=message,
    )


async def create_signed_order_v2(
    sign_typed_data: Any,
    *,
    signer_address: str,
    funder_address: str,
    token_id: str,
    price: float,
    size: float,
    side: str,
    signature_type: SignatureType,
    tick_size: str = "0.01",
    neg_risk: bool = False,
    timestamp_ms: int | None = None,
    metadata: str = "0x" + "00" * 32,
    builder: str = "0x" + "00" * 32,
) -> dict[str, Any]:
    """Create and sign a V2 Polymarket order. Returns the order dict ready for V2 CLOB submission.

    V2 differences from V1:
    - No taker, expiration, nonce, or feeRateBps fields
    - Adds timestamp (ms), metadata (bytes32), builder (bytes32)
    - Domain version "2" with V2 exchange addresses
    - salt is a number (not string) in the payload
    - side is a string ("BUY"/"SELL") in the payload
    - timestamp is a string in the payload
    """
    maker_amount, taker_amount = compute_amounts(price, size, side, tick_size)

    payload = build_order_payload_v2(
        maker=funder_address,
        signer=signer_address,
        token_id=token_id,
        maker_amount=maker_amount,
        taker_amount=taker_amount,
        side=side,
        signature_type=signature_type,
        neg_risk=neg_risk,
        timestamp_ms=timestamp_ms,
        metadata=metadata,
        builder=builder,
    )

    signature = await sign_typed_data(payload)
    if not signature.startswith("0x"):
        signature = f"0x{signature}"

    # Normalize v to raw recovery id (0/1): CLOB expects v=0/1 for order signatures
    sig_bytes = bytearray(bytes.fromhex(signature[2:]))
    if len(sig_bytes) == 65 and sig_bytes[-1] >= 27:
        sig_bytes[-1] -= 27
    signature = "0x" + sig_bytes.hex()

    return {
        "salt": payload.message["salt"],  # number
        "maker": funder_address,
        "signer": signer_address,
        "tokenId": token_id,
        "makerAmount": str(maker_amount),
        "takerAmount": str(taker_amount),
        "side": side,  # string "BUY"/"SELL"
        "signatureType": int(signature_type),  # number
        "timestamp": str(payload.message["timestamp"]),  # string
        "expiration": "0",  # "0" = no expiration (matches @polymarket/clob-client-v2)
        "metadata": payload.message["metadata"],
        "builder": payload.message["builder"],
        "signature": signature,
    }
