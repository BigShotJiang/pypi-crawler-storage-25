"""High-level orderbook engine with local state and filtered views."""

from __future__ import annotations

from typing import Any, Callable

from .orderbook import OrderbookWS
from .orderbook_state import LocalOrderbook
from .types.orderbook import (
    BookSnapshot,
    BookUpdate,
    OrderbookLevel,
    PriceChange,
)


class EngineView:
    """A filtered view over the shared orderbook state for specific tokens."""

    def __init__(
        self,
        token_ids: list[str],
        state: LocalOrderbook,
        remove_from_engine: Callable,
    ) -> None:
        self._tokens: set[str] = set(token_ids)
        self._state = state
        self._remove_from_engine = remove_from_engine
        self._destroyed = False
        self._handlers: dict[str, list[Callable]] = {"update": [], "price": []}

    def on(self, event: str, handler: Callable) -> EngineView:
        if not self._destroyed and event in self._handlers:
            self._handlers[event].append(handler)
        return self

    def off(self, event: str, handler: Callable) -> EngineView:
        if event in self._handlers:
            try:
                self._handlers[event].remove(handler)
            except ValueError:
                pass
        return self

    def set_tokens(self, token_ids: list[str]) -> None:
        self._tokens = set(token_ids)

    def book(self, token_id: str) -> tuple[list[OrderbookLevel], list[OrderbookLevel]] | None:
        return self._state.get_book(token_id)

    def midpoint(self, token_id: str) -> float | None:
        return _compute_midpoint(self._state, token_id)

    def spread(self, token_id: str) -> float | None:
        return self._state.get_spread(token_id)

    def best_bid(self, token_id: str) -> OrderbookLevel | None:
        return self._state.get_best_bid(token_id)

    def best_ask(self, token_id: str) -> OrderbookLevel | None:
        return self._state.get_best_ask(token_id)

    def destroy(self) -> None:
        self._destroyed = True
        self._handlers = {"update": [], "price": []}
        self._tokens.clear()
        self._remove_from_engine()

    def _emit_update(self, data: BookSnapshot | BookUpdate) -> None:
        if self._destroyed:
            return
        for h in self._handlers["update"]:
            h(data)

    def _emit_price(self, data: PriceChange) -> None:
        if self._destroyed:
            return
        for h in self._handlers["price"]:
            h(data)


class OrderbookEngine:
    """Manages one WebSocket connection, local state, and multiple filtered views."""

    def __init__(
        self,
        api_key: str,
        *,
        ob_url: str = "wss://ob.polynode.dev/ws",
        compress: bool = True,
        auto_reconnect: bool = True,
        max_reconnect_attempts: int = 0,
        reconnect_base_delay: float = 1.0,
        reconnect_max_delay: float = 30.0,
    ) -> None:
        self._ws = OrderbookWS(
            api_key,
            ob_url,
            compress=compress,
            auto_reconnect=auto_reconnect,
            max_reconnect_attempts=max_reconnect_attempts,
            reconnect_base_delay=reconnect_base_delay,
            reconnect_max_delay=reconnect_max_delay,
        )
        self._state = LocalOrderbook()
        self._views: set[EngineView] = set()
        self._handlers: dict[str, list[Callable]] = {"update": [], "price": [], "ready": []}

        self._ws.on("snapshot", self._on_snapshot)
        self._ws.on("update", self._on_update)
        self._ws.on("price", self._on_price)
        self._ws.on("snapshots_done", self._on_ready)

    def _on_snapshot(self, snap: BookSnapshot) -> None:
        self._state.apply_snapshot(snap)
        self._route_update(snap)

    def _on_update(self, update: BookUpdate) -> None:
        self._state.apply_update(update)
        self._route_update(update)

    def _on_price(self, change: PriceChange) -> None:
        for h in self._handlers["price"]:
            h(change)
        for view in self._views:
            if view._destroyed:
                continue
            if any(a.asset_id in view._tokens for a in change.assets):
                view._emit_price(change)

    def _on_ready(self, msg: Any) -> None:
        for h in self._handlers["ready"]:
            h()

    async def subscribe(self, identifiers: list[str]) -> None:
        await self._ws.subscribe(identifiers)

    def on(self, event: str, handler: Callable) -> OrderbookEngine:
        if event in self._handlers:
            self._handlers[event].append(handler)
        return self

    def off(self, event: str, handler: Callable) -> OrderbookEngine:
        if event in self._handlers:
            try:
                self._handlers[event].remove(handler)
            except ValueError:
                pass
        return self

    def view(self, token_ids: list[str]) -> EngineView:
        v = EngineView(token_ids, self._state, lambda: self._views.discard(v))
        self._views.add(v)
        return v

    def book(self, token_id: str) -> tuple[list[OrderbookLevel], list[OrderbookLevel]] | None:
        return self._state.get_book(token_id)

    def midpoint(self, token_id: str) -> float | None:
        return _compute_midpoint(self._state, token_id)

    def spread(self, token_id: str) -> float | None:
        return self._state.get_spread(token_id)

    def best_bid(self, token_id: str) -> OrderbookLevel | None:
        return self._state.get_best_bid(token_id)

    def best_ask(self, token_id: str) -> OrderbookLevel | None:
        return self._state.get_best_ask(token_id)

    @property
    def connection(self) -> OrderbookWS:
        return self._ws

    @property
    def size(self) -> int:
        return self._state.size

    def close(self) -> None:
        for view in list(self._views):
            view.destroy()
        self._views.clear()
        self._state.clear()
        self._ws.disconnect()

    def _route_update(self, update: BookSnapshot | BookUpdate) -> None:
        for h in self._handlers["update"]:
            h(update)
        for view in self._views:
            if view._destroyed:
                continue
            if update.asset_id in view._tokens:
                view._emit_update(update)


def _compute_midpoint(state: LocalOrderbook, token_id: str) -> float | None:
    bid = state.get_best_bid(token_id)
    ask = state.get_best_ask(token_id)
    if not bid or not ask:
        return None
    return (float(bid.price) + float(ask.price)) / 2
