"""Async WebSocket client for PolyNode settlement and market event streaming."""

from __future__ import annotations

import asyncio
import json
import math
import random
import zlib
from typing import Any, Callable

import websockets
import websockets.asyncio.client

from .errors import WsError
from .subscription import Subscription, SubscriptionBuilder
from .types.enums import SubscriptionType
from .types.events import PolyNodeEvent
from .types.ws import SubscriptionFilters, WsOptions


def _parse_event(data: dict) -> PolyNodeEvent | None:
    """Parse a raw dict into a typed PolyNodeEvent using Pydantic."""
    from pydantic import TypeAdapter
    _adapter = TypeAdapter(PolyNodeEvent)
    try:
        return _adapter.validate_python(data)
    except Exception:
        return None


class PolyNodeWS:
    """Async WebSocket client with auto-reconnect and subscription management."""

    def __init__(self, api_key: str, ws_url: str, options: WsOptions | None = None) -> None:
        self._api_key = api_key
        self._ws_url = ws_url
        opts = options or WsOptions()
        self._compress = opts.compress
        self._auto_reconnect = opts.auto_reconnect
        self._max_reconnect = opts.max_reconnect_attempts
        self._base_delay = opts.reconnect_base_delay
        self._max_delay = opts.reconnect_max_delay

        self._socket: Any = None
        self._connected = False
        self._intentional_close = False
        self._reconnect_attempts = 0
        self._sub_counter = 0
        self._subscriber_id: str | None = None

        self._subscriptions: dict[str, Subscription] = {}
        self._pending: list[tuple[Subscription, asyncio.Future]] = []

        self._recv_task: asyncio.Task | None = None

        # System handlers
        self._on_connect: list[Callable] = []
        self._on_disconnect: list[Callable] = []
        self._on_reconnect: list[Callable] = []
        self._on_error: list[Callable] = []
        self._on_heartbeat: list[Callable] = []

    @property
    def is_connected(self) -> bool:
        return self._connected

    def on_connect(self, handler: Callable) -> PolyNodeWS:
        self._on_connect.append(handler)
        return self

    def on_disconnect(self, handler: Callable) -> PolyNodeWS:
        self._on_disconnect.append(handler)
        return self

    def on_reconnect(self, handler: Callable) -> PolyNodeWS:
        self._on_reconnect.append(handler)
        return self

    def on_error(self, handler: Callable) -> PolyNodeWS:
        self._on_error.append(handler)
        return self

    def on_heartbeat(self, handler: Callable) -> PolyNodeWS:
        self._on_heartbeat.append(handler)
        return self

    def subscribe(self, type: SubscriptionType) -> SubscriptionBuilder:
        return SubscriptionBuilder(self, type)

    async def _subscribe(self, type: SubscriptionType, filters: SubscriptionFilters) -> Subscription:
        await self._ensure_connected()

        sub = Subscription(self, type, filters)
        fut: asyncio.Future[Subscription] = asyncio.get_event_loop().create_future()
        self._pending.append((sub, fut))

        msg: dict[str, Any] = {"action": "subscribe"}
        if type:
            msg["type"] = type
        clean_filters = filters.to_dict()
        if clean_filters:
            msg["filters"] = clean_filters

        await self._send(json.dumps(msg))

        try:
            return await asyncio.wait_for(fut, timeout=10.0)
        except asyncio.TimeoutError:
            # Remove from pending
            self._pending = [(s, f) for s, f in self._pending if f is not fut]
            raise WsError("Subscribe timed out after 10 seconds")

    def _unsubscribe(self, subscription_id: str | None = None) -> None:
        if subscription_id:
            self._subscriptions.pop(subscription_id, None)
            if self._connected and self._socket:
                asyncio.ensure_future(
                    self._send(json.dumps({"action": "unsubscribe", "subscription_id": subscription_id}))
                )
        else:
            self._subscriptions.clear()
            if self._connected and self._socket:
                asyncio.ensure_future(self._send(json.dumps({"action": "unsubscribe"})))

    def unsubscribe_all(self) -> None:
        self._unsubscribe()

    async def connect(self) -> None:
        if self._connected and self._socket:
            return
        await self._connect()

    def disconnect(self) -> None:
        self._intentional_close = True
        if self._recv_task and not self._recv_task.done():
            self._recv_task.cancel()
        if self._socket:
            asyncio.ensure_future(self._socket.close())
            self._socket = None
        self._connected = False

    # ── Private ──

    async def _ensure_connected(self) -> None:
        if not self._connected or not self._socket:
            await self._connect()

    async def _connect(self) -> None:
        url = f"{self._ws_url}?key={self._api_key}"
        if self._compress:
            url += "&compress=zlib"

        self._socket = await websockets.asyncio.client.connect(url, max_size=10 * 1024 * 1024)
        self._connected = True
        self._reconnect_attempts = 0
        self._intentional_close = False

        for h in self._on_connect:
            h()

        self._recv_task = asyncio.ensure_future(self._recv_loop())

    async def _recv_loop(self) -> None:
        try:
            async for raw in self._socket:
                try:
                    if isinstance(raw, bytes) and self._compress:
                        text = zlib.decompress(raw, -zlib.MAX_WBITS).decode("utf-8")
                    elif isinstance(raw, bytes):
                        text = raw.decode("utf-8")
                    else:
                        text = raw
                    self._handle_message(text)
                except Exception as e:
                    err = WsError(f"Failed to process message: {e}")
                    for h in self._on_error:
                        h(err)
        except websockets.exceptions.ConnectionClosed:
            pass
        except asyncio.CancelledError:
            return
        finally:
            self._connected = False
            reason = "closed" if self._intentional_close else "lost"
            for h in self._on_disconnect:
                h(reason)
            if not self._intentional_close and self._auto_reconnect:
                asyncio.ensure_future(self._schedule_reconnect())

    async def _send(self, data: str) -> None:
        if self._socket and self._connected:
            await self._socket.send(data)

    def _handle_message(self, text: str) -> None:
        msg = json.loads(text)
        msg_type = msg.get("type")

        if msg_type == "subscribed":
            sub_id = msg.get("subscription_id", "")
            self._subscriber_id = msg.get("subscriber_id") or self._subscriber_id
            if self._pending:
                sub, fut = self._pending.pop(0)
                sub._set_id(sub_id)
                self._subscriptions[sub_id] = sub
                if not fut.done():
                    fut.set_result(sub)

        elif msg_type == "heartbeat":
            ts = msg.get("ts", 0)
            for h in self._on_heartbeat:
                h(ts)

        elif msg_type == "pong":
            pass

        elif msg_type == "error":
            err = WsError(msg.get("message", "Unknown error"), msg.get("code"))
            for h in self._on_error:
                h(err)
            if self._pending:
                sub, fut = self._pending.pop(0)
                if not fut.done():
                    fut.set_exception(err)

        elif msg_type == "snapshot":
            events = msg.get("events", [])
            for wrapper in events:
                data = wrapper.get("data")
                if data:
                    event = _parse_event(data)
                    if event:
                        self._route_event(event)

        elif msg_type == "unsubscribed":
            pass

        elif msg_type == "price_feed":
            event = _parse_event({"event_type": "price_feed", **msg.get("data", {})})
            if event:
                self._route_event(event)

        else:
            data = msg.get("data")
            if data and data.get("event_type"):
                event = _parse_event(data)
                if event:
                    self._route_event(event)

    def _route_event(self, event: PolyNodeEvent) -> None:
        for sub in self._subscriptions.values():
            sub._emit(event)

    async def _schedule_reconnect(self) -> None:
        if self._max_reconnect and self._reconnect_attempts >= self._max_reconnect:
            return

        self._reconnect_attempts += 1
        delay = min(self._base_delay * math.pow(2, self._reconnect_attempts - 1), self._max_delay)
        jitter = delay * (0.5 + random.random() * 0.5)

        await asyncio.sleep(jitter)

        try:
            await self._connect()
            for h in self._on_reconnect:
                h(self._reconnect_attempts)
            await self._resubscribe_all()
        except Exception:
            pass

    async def _resubscribe_all(self) -> None:
        existing = list(self._subscriptions.items())
        self._subscriptions.clear()

        for _, sub in existing:
            try:
                new_sub = await self._subscribe(sub.type, sub.filters)
                if new_sub.id:
                    self._subscriptions[new_sub.id] = sub
                    sub._set_id(new_sub.id)
            except Exception:
                pass
