"""WebSocket protocol types for the PolyNode SDK."""

from __future__ import annotations

from dataclasses import dataclass, field

from .enums import EventType, SubscriptionType


@dataclass
class SubscriptionFilters:
    wallets: list[str] | None = None
    tokens: list[str] | None = None
    slugs: list[str] | None = None
    condition_ids: list[str] | None = None
    side: str | None = None
    status: str | None = None
    min_size: float | None = None
    max_size: float | None = None
    event_types: list[EventType] | None = None
    snapshot_count: int | None = None
    feeds: list[str] | None = None

    def to_dict(self) -> dict:
        d = {}
        for k, v in self.__dict__.items():
            if v is not None:
                d[k] = v
        return d


@dataclass
class WsOptions:
    compress: bool = True
    auto_reconnect: bool = True
    max_reconnect_attempts: int = 0  # 0 = infinite
    reconnect_base_delay: float = 1.0
    reconnect_max_delay: float = 30.0
