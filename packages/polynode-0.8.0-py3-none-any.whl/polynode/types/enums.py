"""Enum types for the PolyNode SDK."""

from __future__ import annotations

from typing import Literal

EventStatus = Literal["pending", "confirmed"]
TradeSide = Literal["BUY", "SELL"]
Exchange = Literal["ctf_exchange", "neg_risk_ctf_exchange"]
TransferType = Literal["single", "batch"]
DepositDirection = Literal["deposit", "withdrawal"]
OracleEventType = Literal[
    "initialization",
    "proposal",
    "dispute",
    "resolution",
    "settled",
    "flag",
    "unflag",
    "pause",
    "unpause",
    "manual_resolution",
    "reset",
    "condition_resolution",
]
CandleResolution = Literal["1m", "5m", "15m", "1h", "4h", "1d"]
EventType = Literal[
    "settlement",
    "trade",
    "status_update",
    "block",
    "position_change",
    "deposit",
    "position_split",
    "position_merge",
    "oracle",
    "price_feed",
]
SubscriptionType = Literal[
    "settlements",
    "trades",
    "prices",
    "blocks",
    "wallets",
    "markets",
    "large_trades",
    "global",
    "oracle",
    "chainlink",
]
MarketSortField = Literal["volume", "price", "updated"]
