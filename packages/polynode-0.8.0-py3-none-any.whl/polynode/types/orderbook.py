"""Orderbook types for the PolyNode SDK."""

from __future__ import annotations

from pydantic import BaseModel


class OrderbookLevel(BaseModel):
    price: str
    size: str


class BookSnapshot(BaseModel):
    type: str = "book_snapshot"
    asset_id: str
    market: str
    event_title: str | None = None
    question: str | None = None
    outcome: str | None = None
    slug: str | None = None
    bids: list[OrderbookLevel]
    asks: list[OrderbookLevel]


class BookUpdate(BaseModel):
    type: str = "book_update"
    asset_id: str
    market: str
    event_title: str | None = None
    question: str | None = None
    outcome: str | None = None
    slug: str | None = None
    bids: list[OrderbookLevel]
    asks: list[OrderbookLevel]


class PriceChangeAsset(BaseModel):
    asset_id: str
    price: str
    outcome: str


class PriceChange(BaseModel):
    type: str = "price_change"
    market: str
    event_title: str | None = None
    question: str | None = None
    slug: str | None = None
    assets: list[PriceChangeAsset]


class SubscribedMessage(BaseModel):
    type: str = "subscribed"
    markets: int


class SnapshotsDoneMessage(BaseModel):
    type: str = "snapshots_done"
    total: int


class ObErrorMessage(BaseModel):
    error: str
    message: str
    max: int | None = None
    requested: int | None = None
