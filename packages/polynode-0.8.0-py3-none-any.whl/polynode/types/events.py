"""Event type models for the PolyNode SDK."""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field

from .enums import (
    DepositDirection,
    EventStatus,
    Exchange,
    OracleEventType,
    TradeSide,
    TransferType,
)


class DecodedTrade(BaseModel):
    maker: str
    signer: str
    taker: str
    token_id: str
    side: TradeSide
    price: float
    size: float
    maker_amount: str
    taker_amount: str
    outcome: str | None = None


class SettlementEvent(BaseModel):
    event_type: Literal["settlement"]
    tx_hash: str
    status: EventStatus
    detected_at: float
    block_number: int | None = None
    taker_wallet: str
    taker_token: str
    taker_side: str
    taker_price: float
    taker_size: float
    trades: list[DecodedTrade]
    # Enrichment fields
    market_title: str | None = None
    outcome: str | None = None
    market_slug: str | None = None
    event_title: str | None = None
    market_image: str | None = None
    condition_id: str | None = None
    tokens: dict[str, str] | None = None
    token_ids: list[str] | None = None
    outcomes: list[str] | None = None
    tick_size: float | None = None
    neg_risk: bool | None = None
    event_slug: str | None = None
    taker_base_fee: float | None = None


class TradeEvent(BaseModel):
    event_type: Literal["trade"]
    tx_hash: str
    block_number: int
    log_index: int
    timestamp: float
    exchange: Exchange
    maker: str
    taker: str
    token_id: str
    side: TradeSide
    price: float
    size: float
    maker_amount: str
    taker_amount: str
    fee: float | None = None
    # Enrichment fields
    market_title: str | None = None
    outcome: str | None = None
    market_slug: str | None = None
    event_title: str | None = None
    market_image: str | None = None
    condition_id: str | None = None
    tokens: dict[str, str] | None = None
    token_ids: list[str] | None = None
    outcomes: list[str] | None = None
    tick_size: float | None = None
    neg_risk: bool | None = None
    event_slug: str | None = None
    taker_base_fee: float | None = None


class StatusUpdateEvent(BaseModel):
    event_type: Literal["status_update"]
    tx_hash: str
    token_id: str
    block_number: int
    confirmed_at: float
    pending_detected_at: float
    latency_ms: float
    taker_wallet: str | None = None
    maker_wallets: list[str] | None = None
    # Enrichment fields
    market_title: str | None = None
    outcome: str | None = None
    market_slug: str | None = None
    event_title: str | None = None
    market_image: str | None = None
    condition_id: str | None = None
    tokens: dict[str, str] | None = None
    token_ids: list[str] | None = None
    outcomes: list[str] | None = None
    tick_size: float | None = None
    neg_risk: bool | None = None
    event_slug: str | None = None
    taker_base_fee: float | None = None


class BlockEvent(BaseModel):
    event_type: Literal["block"]
    block_number: int
    block_hash: str
    timestamp: float
    parent_hash: str
    tx_count: int
    polymarket_tx_count: int
    settlement_count: int
    trade_volume_usd: float


class PositionChangeEvent(BaseModel):
    event_type: Literal["position_change"]
    tx_hash: str
    block_number: int
    log_index: int
    timestamp: float
    from_address: str = Field(alias="from")
    to: str
    token_id: str
    amount: float
    transfer_type: TransferType
    # Enrichment fields
    market_title: str | None = None
    outcome: str | None = None
    market_slug: str | None = None
    event_title: str | None = None
    market_image: str | None = None
    condition_id: str | None = None
    tokens: dict[str, str] | None = None
    token_ids: list[str] | None = None
    outcomes: list[str] | None = None
    tick_size: float | None = None
    neg_risk: bool | None = None
    event_slug: str | None = None
    taker_base_fee: float | None = None

    model_config = {"populate_by_name": True}


class DepositEvent(BaseModel):
    event_type: Literal["deposit"]
    tx_hash: str
    block_number: int
    log_index: int
    timestamp: float
    from_address: str = Field(alias="from")
    to: str
    amount: float
    direction: DepositDirection

    model_config = {"populate_by_name": True}


class PositionSplitEvent(BaseModel):
    event_type: Literal["position_split"]
    tx_hash: str
    block_number: int
    log_index: int
    timestamp: float
    stakeholder: str
    collateral_token: str
    condition_id: str
    amount: float
    market_title: str | None = None
    market_slug: str | None = None
    event_title: str | None = None
    market_image: str | None = None
    tokens: dict[str, str] | None = None
    tick_size: float | None = None
    neg_risk: bool | None = None
    taker_base_fee: float | None = None


class PositionMergeEvent(BaseModel):
    event_type: Literal["position_merge"]
    tx_hash: str
    block_number: int
    log_index: int
    timestamp: float
    stakeholder: str
    collateral_token: str
    condition_id: str
    amount: float
    market_title: str | None = None
    market_slug: str | None = None
    event_title: str | None = None
    market_image: str | None = None
    tokens: dict[str, str] | None = None
    tick_size: float | None = None
    neg_risk: bool | None = None
    taker_base_fee: float | None = None


class OracleEvent(BaseModel):
    event_type: Literal["oracle"]
    tx_hash: str
    block_number: int
    log_index: int
    timestamp: float
    question_id: str
    oracle_type: OracleEventType
    adapter_address: str
    # Resolution fields
    resolved_price: float | None = None
    resolved_outcome: str | None = None
    payouts: list[float] | None = None
    # Proposal fields
    proposer: str | None = None
    bond_amount: float | None = None
    proposed_price: float | None = None
    expiration_timestamp: float | None = None
    # Dispute fields
    disputer: str | None = None
    # Enrichment
    market_title: str | None = None
    market_slug: str | None = None
    condition_id: str | None = None
    event_title: str | None = None
    market_image: str | None = None
    tokens: dict[str, str] | None = None
    token_ids: list[str] | None = None
    outcomes: list[str] | None = None
    neg_risk: bool | None = None


class PriceFeedEvent(BaseModel):
    event_type: Literal["price_feed"]
    feed: str
    feed_id: str = ""
    price: float
    bid: float
    ask: float
    timestamp: float
    source: str = "chainlink"


PolyNodeEvent = Annotated[
    Union[
        SettlementEvent,
        TradeEvent,
        StatusUpdateEvent,
        BlockEvent,
        PositionChangeEvent,
        DepositEvent,
        PositionSplitEvent,
        PositionMergeEvent,
        OracleEvent,
        PriceFeedEvent,
    ],
    Field(discriminator="event_type"),
]
