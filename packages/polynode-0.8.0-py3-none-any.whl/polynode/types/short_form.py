"""Short-form market types for the PolyNode SDK."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

ShortFormInterval = Literal["5m", "15m", "1h"]
ShortFormCoin = Literal["btc", "eth", "sol", "xrp", "doge", "hype", "bnb"]


class ShortFormMarket(BaseModel):
    coin: ShortFormCoin
    slug: str
    title: str
    condition_id: str
    window_start: int
    window_end: int
    outcomes: list[str]
    outcome_prices: list[float]
    clob_token_ids: list[str]
    up_odds: float
    down_odds: float
    liquidity: float
    volume_24h: float
    price_to_beat: float | None = None


class RotationEvent(BaseModel):
    interval: ShortFormInterval
    markets: list[ShortFormMarket]
    window_start: int
    window_end: int
    time_remaining: int
