"""REST API response models for the PolyNode SDK."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from .enums import EventStatus


# ── System ──


class StateSummary(BaseModel):
    market_count: int
    wallet_count: int
    metadata_count: int
    events_buffered: int
    events_processed: int
    latest_block: int


class StatusResponse(BaseModel):
    node_connected: bool
    uptime_seconds: float
    stream_length: int
    events_stream_length: int
    pending_txs: int
    ws_subscribers: int
    firehose_connections: int
    redis_memory: str
    state: StateSummary


class ApiKeyResponse(BaseModel):
    api_key: str
    name: str
    rate_limit_per_minute: int
    message: str


# ── Markets ──


class MarketSummary(BaseModel):
    token_id: str | None = None
    last_price: float | None = None
    volume_24h: float = 0
    trade_count_24h: int = 0
    last_trade_at: float | None = None
    question: str | None = None
    slug: str | None = None
    outcomes: list[str] | None = None
    condition_id: str | None = None
    end_date: str | None = None
    category: str | None = None
    market_type: str | None = None
    image: str | None = None
    icon: str | None = None
    neg_risk: bool | None = None
    created_at: str | None = None
    active: bool | None = None
    closed: bool | None = None
    last_status: EventStatus | None = None


class MarketsResponse(BaseModel):
    count: int
    total: int
    markets: list[MarketSummary]


class MarketsListResponse(BaseModel):
    count: int
    total: int
    cursor: int | None = None
    markets: list[MarketSummary]


class SearchResponse(BaseModel):
    query: str
    count: int
    results: list[MarketSummary]


# ── Pricing ──


class Candle(BaseModel):
    timestamp: float
    open: float
    high: float
    low: float
    close: float
    volume: float


class CandlesResponse(BaseModel):
    candles: list[Candle]
    count: int
    token_id: str
    question: str | None = None
    slug: str | None = None
    resolution: str | None = None


# ── Settlements ──


class Settlement(BaseModel):
    tx_hash: str
    taker_side: str
    taker_size: str
    taker_price: str
    taker_wallet: str
    taker_token: str
    timestamp: str
    detected_at: str
    status: str
    outcome: str
    market_title: str
    market_slug: str
    market_image: str
    event_title: str
    block_number: str
    id: str
    trades_json: str


class SettlementsResponse(BaseModel):
    count: int
    settlements: list[Settlement]
    wallet: str | None = None
    token_id: str | None = None


# ── Wallets ──


class WalletActivity(BaseModel):
    last_active: float
    trade_count: int
    trade_volume_usd: float
    transfer_count: int
    deposit_count: int
    deposit_volume_usd: float


class WalletResponse(BaseModel):
    wallet: str
    activity: WalletActivity

    model_config = {"extra": "allow"}


# ── Orderbook (REST) ──


class OrderbookLevel(BaseModel):
    price: str
    size: str


class OrderbookResponse(BaseModel):
    bids: list[OrderbookLevel]
    asks: list[OrderbookLevel]
    asset_id: str
    market: str
    hash: str
    last_trade_price: str
    min_order_size: str
    tick_size: str
    neg_risk: bool
    timestamp: str


class MidpointResponse(BaseModel):
    mid: str


class SpreadResponse(BaseModel):
    spread: str


# ── Enriched Data ──


class LeaderboardTrader(BaseModel):
    rank: int
    wallet: str
    name: str
    pnl: float
    volume: float
    profileImage: str | None = None


class LeaderboardResponse(BaseModel):
    traders: list[LeaderboardTrader]
    period: str
    sort: str
    count: int


class TrendingCarouselItem(BaseModel):
    id: str
    slug: str
    title: str
    image: str | None = None
    volume: float
    volume24hr: float | None = None
    liquidity: float | None = None
    startDate: str
    active: bool
    closed: bool


class TrendingBreakingItem(BaseModel):
    id: str
    slug: str
    question: str
    image: str | None = None
    outcomePrices: list[str]
    oneDayPriceChange: float


class TrendingHotTopic(BaseModel):
    title: str
    volume: float
    url: str


class TrendingResponse(BaseModel):
    carousel: list[TrendingCarouselItem]
    breaking: list[TrendingBreakingItem]
    hotTopics: list[TrendingHotTopic]
    featured: list[TrendingCarouselItem]
    movers: list[TrendingBreakingItem]


class ActivityTrade(BaseModel):
    wallet: str
    side: str
    tokenId: str
    conditionId: str
    size: float
    price: float
    timestamp: float
    title: str
    slug: str
    eventSlug: str
    outcome: str
    name: str
    txHash: str


class ActivityResponse(BaseModel):
    trades: list[ActivityTrade]
    count: int


class MoverMarket(BaseModel):
    id: str
    slug: str
    question: str
    image: str | None = None
    outcomePrices: list[str]
    oneDayPriceChange: float


class MoversResponse(BaseModel):
    markets: list[MoverMarket]
    count: int


class TraderProfile(BaseModel):
    wallet: str
    name: str
    pseudonym: str
    profileSlug: str
    joinDate: str
    trades: int
    marketsTraded: int
    largestWin: float
    views: int
    totalVolume: float
    totalPnl: float
    realizedPnl: float
    unrealizedPnl: float
    positionValue: float
    profileImage: str | None = None


class PnlPoint(BaseModel):
    timestamp: float
    pnl: float


class TraderPnlResponse(BaseModel):
    wallet: str
    period: str
    series: list[PnlPoint]
    count: int


class EventMarket(BaseModel):
    question: str
    conditionId: str
    outcomes: list[str]
    outcomePrices: list[str]
    volume: float
    liquidity: float
    active: bool
    closed: bool
    groupItemTitle: str | None = None
    tokenId: str | None = None


class EventSearchMarket(BaseModel):
    question: str
    groupItemTitle: str
    conditionId: str
    tokenId: str | None = None
    price: float | None = None
    active: bool


class EventSearchResult(BaseModel):
    id: str
    slug: str
    title: str
    image: str | None = None
    active: bool
    markets: list[EventSearchMarket]


class EventSearchResponse(BaseModel):
    query: str
    events: list[EventSearchResult]
    count: int


class EventDetailResponse(BaseModel):
    id: int
    slug: str
    title: str
    description: str
    image: str | None = None
    active: bool
    closed: bool
    volume: float
    volume24hr: float
    liquidity: float
    startDate: str
    endDate: str
    markets: list[EventMarket]
    series: dict[str, Any] | None = None
    similarMarkets: int
    annotations: int


class MarketsByCategoryResponse(BaseModel):
    category: str
    counts: dict[str, int]
    events: list[dict[str, Any]]
    totalResults: int


# ── RPC ──


class JsonRpcResponse(BaseModel):
    jsonrpc: str
    id: int | str | None = None
    result: Any | None = None
    error: dict[str, Any] | None = None
