"""PolyNode SDK error hierarchy."""

from __future__ import annotations


class PolyNodeError(Exception):
    """Base error for all PolyNode SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class ApiError(PolyNodeError):
    """HTTP API error with status code."""

    def __init__(self, message: str, status: int) -> None:
        self.status = status
        super().__init__(message)

    def __str__(self) -> str:
        return f"ApiError({self.status}): {self.message}"


class WsError(PolyNodeError):
    """WebSocket error with optional error code."""

    def __init__(self, message: str, code: str | None = None) -> None:
        self.code = code
        super().__init__(message)

    def __str__(self) -> str:
        if self.code:
            return f"WsError({self.code}): {self.message}"
        return f"WsError: {self.message}"
