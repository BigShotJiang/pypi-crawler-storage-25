"""Orchestration settings.

Kept separate from `IngestionSettings` so generation knobs (model, prompt
caps) rotate independently from data-pipeline credentials.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)

# Default value of `GECKO_LLM_ENDPOINT` baked into `OrchestrationSettings`.
# Used to detect whether the operator has *explicitly* overridden the legacy
# endpoint (vs. pydantic just hydrating the default into the model). When the
# value matches this default, treat it as "not set" for precedence purposes.
_DEFAULT_LLM_ENDPOINT = "http://localhost:8402/v1"


class OrchestrationSettings(BaseSettings):
    """LLM-side knobs for the basic + (later) pro orchestration paths."""

    # ClawRouter is the v3 default. Pin a JSON-mode-safe model for orchestration
    # steps that depend on response_format=json_object — `blockrun/auto` may
    # route to a model that breaks JSON mode. Override per-deploy via env.
    chat_model: str = Field("openai/gpt-4o", alias="CHAT_MODEL")

    # OpenAI-compatible base_url. Default points at the local ClawRouter proxy
    # (`npx @blockrun/clawrouter`) on port 8402. Set to OpenAI's URL for the v2
    # fallback path, or to any OpenAI-compatible gateway.
    llm_endpoint: str = Field("http://localhost:8402/v1", alias="GECKO_LLM_ENDPOINT")

    # Auth header value sent to the LLM endpoint. ClawRouter accepts the literal
    # "x402" because payments are wallet-signed. For OpenAI fallback, set to
    # the real API key.
    llm_api_key: str = Field("x402", alias="GECKO_LLM_API_KEY")

    # Defensive cap on prompt input tokens. Truncation happens in
    # orchestration.basic before the OpenAI call. 60k leaves comfortable
    # headroom under the 128k context window for response + system prompt.
    max_input_tokens: int = Field(60_000, alias="ORCH_MAX_INPUT_TOKENS")

    # Sampling. Low for grounded, deterministic-ish output.
    temperature: float = Field(0.3, alias="ORCH_TEMPERATURE")

    # LLM-hygiene Commit C — per-role output cap (max_tokens). Each role is
    # tunable independently because the cost / risk tradeoff differs:
    # research_basic emits a large structured envelope; ask is a short
    # prose answer; advisor voices need headroom to avoid mid-sentence
    # truncation. Override per-deploy via env (e.g. ``ORCH_MAX_TOKENS_AG2``).
    max_tokens_research_basic: int = Field(6000, alias="ORCH_MAX_TOKENS_RESEARCH_BASIC")
    max_tokens_post_processor: int = Field(2000, alias="ORCH_MAX_TOKENS_POST_PROCESSOR")
    # S20-FIX-05 — `market_landscape` is structurally larger than the
    # other post-processors (3-5 competitors x 4 fields each + axis-key
    # echo) and saturated the shared 2000-token cap on deepseek-v4-flash
    # in production (session c05ab663 returned `market_landscape: null`).
    # Default 4000 leaves comfortable headroom; override per-deploy via
    # ``GECKO_MARKET_LANDSCAPE_MAX_TOKENS``.
    max_tokens_market_landscape: int = Field(4000, alias="GECKO_MARKET_LANDSCAPE_MAX_TOKENS")
    max_tokens_refiner: int = Field(4000, alias="ORCH_MAX_TOKENS_REFINER")
    max_tokens_judge_synth: int = Field(4000, alias="ORCH_MAX_TOKENS_JUDGE_SYNTH")
    max_tokens_ask: int = Field(1500, alias="ORCH_MAX_TOKENS_ASK")
    max_tokens_ag2: int = Field(3000, alias="ORCH_MAX_TOKENS_AG2")
    max_tokens_advisor: int = Field(4000, alias="ORCH_MAX_TOKENS_ADVISOR")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )


@lru_cache(maxsize=1)
def get_orchestration_settings() -> OrchestrationSettings:
    return OrchestrationSettings()  # type: ignore[call-arg]


@dataclass(frozen=True)
class LLMClientConfig:
    """Resolved LLM client surface used by single-call orchestration paths
    (advisor panel, basic-tier research, scaffold, flywheel).

    Unifies the two historical config planes:
      - ``LLM_ROUTER`` (Pro debate, S4) — selects router by name and pulls
        base_url/api_key from per-router settings.
      - ``GECKO_LLM_ENDPOINT`` / ``GECKO_LLM_API_KEY`` (advisor, S3) — direct
        OpenAI-compatible base_url + auth header.

    Resolution order (S8-CONFIG-01):
      1. If ``LLM_ROUTER`` is set in env, route via ``resolve_router`` (the
         same path Pro debate uses). Default model comes from the router's
         per-tier preset; callers that need a specific model override
         ``OrchestrationSettings.chat_model``.
      2. Otherwise fall back to ``OrchestrationSettings`` (legacy
         ``GECKO_LLM_ENDPOINT``/``GECKO_LLM_API_KEY``).

    S9-CONFIG-03 — corrected precedence (fixes F15):
      1. ``LLM_ROUTER`` set → router wins (always). OpenRouter prefixed slugs
         like ``kimi-k2.6`` would 400 against ``api.openai.com``; the previous
         rule "legacy wins when both are set" treated even the default
         ``GECKO_LLM_ENDPOINT`` as an override and broke OpenRouter dogfood.
      2. ``LLM_ROUTER`` unset AND ``GECKO_LLM_ENDPOINT`` explicitly set to a
         non-default value → legacy plane, with an INFO deprecation log.
      3. Otherwise → default (OpenAI-compatible legacy plane with whatever
         OrchestrationSettings resolved to).
    """

    base_url: str
    api_key: str
    extra_headers: dict[str, str]
    chat_model: str
    temperature: float
    max_input_tokens: int
    source: str  # "router:<name>" or "legacy"


def resolve_llm_config(
    environ: dict[str, str] | None = None,
    *,
    settings: OrchestrationSettings | None = None,
) -> LLMClientConfig:
    """Single LLM-resolution path used by every non-Pro-debate orchestrator.

    See ``LLMClientConfig`` for the precedence rules. Pure: never reads the
    environment again past the optional ``environ`` parameter, and never
    raises on missing legacy env (legacy defaults remain "x402" / clawrouter
    so unit tests that don't set anything still construct a client).
    """
    env = environ if environ is not None else dict(os.environ)
    s = settings or get_orchestration_settings()

    # Did the operator opt into the unified router plane?
    router_env = (env.get("LLM_ROUTER") or "").strip().lower()

    # Legacy endpoint is only "explicitly set" when:
    #   (a) the env var is present + non-empty, AND
    #   (b) the resolved endpoint differs from the baked-in default.
    # This guards against pydantic-settings hydrating the default value into
    # the model and tripping the override path (the F15 bug).
    raw_endpoint = (env.get("GECKO_LLM_ENDPOINT") or "").strip()
    legacy_endpoint_set = bool(raw_endpoint) and raw_endpoint != _DEFAULT_LLM_ENDPOINT

    if router_env:
        # Lazy import — `pro.router` pulls in routing.catalog which is a
        # heavier graph than orchestration.settings should require at import
        # time.
        from gecko_core.orchestration.pro.router import resolve_router

        rc = resolve_router(env)

        # S9-CONFIG-03: router ALWAYS wins when LLM_ROUTER is set. We still
        # log INFO if a legacy override is also set so operators notice
        # GECKO_LLM_ENDPOINT is now a no-op alongside LLM_ROUTER.
        if legacy_endpoint_set:
            logger.info(
                "GECKO_LLM_ENDPOINT=%s is set alongside LLM_ROUTER=%s; "
                "router takes precedence (S9-CONFIG-03). Drop "
                "GECKO_LLM_ENDPOINT/GECKO_LLM_API_KEY to silence this notice.",
                raw_endpoint,
                router_env,
            )

        return LLMClientConfig(
            base_url=rc.base_url,
            api_key=rc.api_key,
            extra_headers=dict(rc.extra_headers),
            chat_model=s.chat_model,
            temperature=s.temperature,
            max_input_tokens=s.max_input_tokens,
            source=f"router:{rc.router}",
        )

    if legacy_endpoint_set:
        logger.info(
            "GECKO_LLM_ENDPOINT=%s in use (legacy plane). LLM_ROUTER is the "
            "preferred config surface; this path will be removed in a future "
            "release.",
            raw_endpoint,
        )

    # No LLM_ROUTER → legacy plane. Unchanged from pre-S8 behavior.
    return LLMClientConfig(
        base_url=s.llm_endpoint,
        api_key=s.llm_api_key,
        extra_headers={},
        chat_model=s.chat_model,
        temperature=s.temperature,
        max_input_tokens=s.max_input_tokens,
        source="legacy",
    )


__all__ = [
    "LLMClientConfig",
    "OrchestrationSettings",
    "get_orchestration_settings",
    "resolve_llm_config",
]
