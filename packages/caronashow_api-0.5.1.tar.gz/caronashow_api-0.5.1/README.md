# caronashow-api

Python client for CaronaShow APIs.

## Installation

```bash
pip install caronashow-api
```

## Usage

The code below is a minimal version and not comprehensive of all APIs.

To view the API definitions and types, consult the
`.protobuf` files or generated code.

### Pooler API client

```python
import asyncio

from caronashow.pooler.v1.pooler_connect import PoolerServiceClient
from caronashow.pooler.v1.pooler_pb2 import (
    MATCHING_ALGORITHM_RANDOM,
    ExecuteMatchingAlgorithmOnDatasetRequest,
)


async def main():
    # Create a client
    client = PoolerServiceClient("http://localhost:8080")

    # Make a request
    request = ExecuteMatchingAlgorithmOnDatasetRequest(
        dataset_id="dataset-123",
        algorithm=MATCHING_ALGORITHM_RANDOM,
    )

    # Call the service
    response = await client.execute_matching_algorithm_on_dataset(request)
    print(response.operation)


if __name__ == "__main__":
    asyncio.run(main())
```

### Pooler API server

```python
from caronashow.pooler.v1.pooler_connect import (
    PoolerService,
    PoolerServiceASGIApplication,
)
from caronashow.pooler.v1.pooler_pb2 import (
    ExecuteMatchingAlgorithmOnDatasetResponse,
    Operation,
    OperationState,
)


class Pooler(PoolerService):
    async def execute_matching_algorithm_on_dataset(self, request, ctx):
        print("Request headers:", ctx.request_headers())
        response = ExecuteMatchingAlgorithmOnDatasetResponse(
            operation=Operation(
                operation_id="op-123",
                dataset_id=request.dataset_id,
                state=OperationState.OPERATION_STATE_SUCCEEDED,
            )
        )
        return response


app = PoolerServiceASGIApplication(Pooler())
```

### Types

```python
from caronashow.types.v1 import user_pb2

# Create user objects
user = user_pb2.User(...)
```

## License

MIT License - see LICENSE file for details.

