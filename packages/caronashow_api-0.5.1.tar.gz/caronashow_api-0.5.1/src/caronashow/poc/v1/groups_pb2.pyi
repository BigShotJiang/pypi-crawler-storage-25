from caronashow.poc.v1 import points_pb2 as _points_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MatchGroup(_message.Message):
    __slots__ = ("id", "driver", "passengers")
    ID_FIELD_NUMBER: _ClassVar[int]
    DRIVER_FIELD_NUMBER: _ClassVar[int]
    PASSENGERS_FIELD_NUMBER: _ClassVar[int]
    id: str
    driver: _containers.RepeatedCompositeFieldContainer[_points_pb2.DriverPoint]
    passengers: _containers.RepeatedCompositeFieldContainer[_points_pb2.PassengerPoint]
    def __init__(self, id: _Optional[str] = ..., driver: _Optional[_Iterable[_Union[_points_pb2.DriverPoint, _Mapping]]] = ..., passengers: _Optional[_Iterable[_Union[_points_pb2.PassengerPoint, _Mapping]]] = ...) -> None: ...
