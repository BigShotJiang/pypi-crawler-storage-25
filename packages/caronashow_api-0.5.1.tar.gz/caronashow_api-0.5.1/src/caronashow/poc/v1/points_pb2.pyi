import datetime

from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.type import latlng_pb2 as _latlng_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PersonRank(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PERSON_RANK_UNSPECIFIED: _ClassVar[PersonRank]
    PERSON_RANK_BRONZE: _ClassVar[PersonRank]
    PERSON_RANK_SILVER: _ClassVar[PersonRank]
    PERSON_RANK_GOLD: _ClassVar[PersonRank]
    PERSON_RANK_PLATINUM: _ClassVar[PersonRank]
    PERSON_RANK_DIAMOND: _ClassVar[PersonRank]

class PersonIcon(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PERSON_ICON_UNSPECIFIED: _ClassVar[PersonIcon]
    PERSON_ICON_MALE_1: _ClassVar[PersonIcon]
    PERSON_ICON_MALE_2: _ClassVar[PersonIcon]
    PERSON_ICON_FEMALE_1: _ClassVar[PersonIcon]
    PERSON_ICON_FEMALE_2: _ClassVar[PersonIcon]
    PERSON_ICON_FEMALE_3: _ClassVar[PersonIcon]
PERSON_RANK_UNSPECIFIED: PersonRank
PERSON_RANK_BRONZE: PersonRank
PERSON_RANK_SILVER: PersonRank
PERSON_RANK_GOLD: PersonRank
PERSON_RANK_PLATINUM: PersonRank
PERSON_RANK_DIAMOND: PersonRank
PERSON_ICON_UNSPECIFIED: PersonIcon
PERSON_ICON_MALE_1: PersonIcon
PERSON_ICON_MALE_2: PersonIcon
PERSON_ICON_FEMALE_1: PersonIcon
PERSON_ICON_FEMALE_2: PersonIcon
PERSON_ICON_FEMALE_3: PersonIcon

class Address(_message.Message):
    __slots__ = ("position", "full_address")
    POSITION_FIELD_NUMBER: _ClassVar[int]
    FULL_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    position: _latlng_pb2.LatLng
    full_address: str
    def __init__(self, position: _Optional[_Union[_latlng_pb2.LatLng, _Mapping]] = ..., full_address: _Optional[str] = ...) -> None: ...

class Vehicle(_message.Message):
    __slots__ = ("license_plate", "model", "color")
    LICENSE_PLATE_FIELD_NUMBER: _ClassVar[int]
    MODEL_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    license_plate: str
    model: str
    color: str
    def __init__(self, license_plate: _Optional[str] = ..., model: _Optional[str] = ..., color: _Optional[str] = ...) -> None: ...

class Person(_message.Message):
    __slots__ = ("id", "name", "rating", "rank", "icon", "departure_from_org", "departure_window_from_org")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    RATING_FIELD_NUMBER: _ClassVar[int]
    RANK_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DEPARTURE_FROM_ORG_FIELD_NUMBER: _ClassVar[int]
    DEPARTURE_WINDOW_FROM_ORG_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    rating: float
    rank: PersonRank
    icon: PersonIcon
    departure_from_org: _timestamp_pb2.Timestamp
    departure_window_from_org: _duration_pb2.Duration
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., rating: _Optional[float] = ..., rank: _Optional[_Union[PersonRank, str]] = ..., icon: _Optional[_Union[PersonIcon, str]] = ..., departure_from_org: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., departure_window_from_org: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class PassengerPoint(_message.Message):
    __slots__ = ("id", "address", "person", "comment")
    ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    PERSON_FIELD_NUMBER: _ClassVar[int]
    COMMENT_FIELD_NUMBER: _ClassVar[int]
    id: str
    address: Address
    person: Person
    comment: str
    def __init__(self, id: _Optional[str] = ..., address: _Optional[_Union[Address, _Mapping]] = ..., person: _Optional[_Union[Person, _Mapping]] = ..., comment: _Optional[str] = ...) -> None: ...

class DriverPoint(_message.Message):
    __slots__ = ("id", "address", "person", "vehicle", "comment", "seats_offered", "seats_available")
    ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    PERSON_FIELD_NUMBER: _ClassVar[int]
    VEHICLE_FIELD_NUMBER: _ClassVar[int]
    COMMENT_FIELD_NUMBER: _ClassVar[int]
    SEATS_OFFERED_FIELD_NUMBER: _ClassVar[int]
    SEATS_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    id: str
    address: Address
    person: Person
    vehicle: Vehicle
    comment: str
    seats_offered: int
    seats_available: int
    def __init__(self, id: _Optional[str] = ..., address: _Optional[_Union[Address, _Mapping]] = ..., person: _Optional[_Union[Person, _Mapping]] = ..., vehicle: _Optional[_Union[Vehicle, _Mapping]] = ..., comment: _Optional[str] = ..., seats_offered: _Optional[int] = ..., seats_available: _Optional[int] = ...) -> None: ...

class OrganizationPoint(_message.Message):
    __slots__ = ("id", "address", "name")
    ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    address: Address
    name: str
    def __init__(self, id: _Optional[str] = ..., address: _Optional[_Union[Address, _Mapping]] = ..., name: _Optional[str] = ...) -> None: ...
