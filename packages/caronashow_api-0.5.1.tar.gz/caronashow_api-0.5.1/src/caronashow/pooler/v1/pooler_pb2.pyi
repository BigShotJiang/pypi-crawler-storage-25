import datetime

from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MatchingAlgorithm(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MATCHING_ALGORITHM_UNSPECIFIED: _ClassVar[MatchingAlgorithm]
    MATCHING_ALGORITHM_RANDOM: _ClassVar[MatchingAlgorithm]
    MATCHING_ALGORITHM_ROUTE_SIMILARITY: _ClassVar[MatchingAlgorithm]
    MATCHING_ALGORITHM_POINT_DISTANCE: _ClassVar[MatchingAlgorithm]
    MATCHING_ALGORITHM_FULL: _ClassVar[MatchingAlgorithm]

class OperationState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OPERATION_STATE_UNSPECIFIED: _ClassVar[OperationState]
    OPERATION_STATE_PENDING: _ClassVar[OperationState]
    OPERATION_STATE_RUNNING: _ClassVar[OperationState]
    OPERATION_STATE_SUCCEEDED: _ClassVar[OperationState]
    OPERATION_STATE_FAILED: _ClassVar[OperationState]
MATCHING_ALGORITHM_UNSPECIFIED: MatchingAlgorithm
MATCHING_ALGORITHM_RANDOM: MatchingAlgorithm
MATCHING_ALGORITHM_ROUTE_SIMILARITY: MatchingAlgorithm
MATCHING_ALGORITHM_POINT_DISTANCE: MatchingAlgorithm
MATCHING_ALGORITHM_FULL: MatchingAlgorithm
OPERATION_STATE_UNSPECIFIED: OperationState
OPERATION_STATE_PENDING: OperationState
OPERATION_STATE_RUNNING: OperationState
OPERATION_STATE_SUCCEEDED: OperationState
OPERATION_STATE_FAILED: OperationState

class Operation(_message.Message):
    __slots__ = ("operation_id", "dataset_id", "started_at", "time_elapsed", "state")
    OPERATION_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    TIME_ELAPSED_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    operation_id: str
    dataset_id: str
    started_at: _timestamp_pb2.Timestamp
    time_elapsed: _duration_pb2.Duration
    state: OperationState
    def __init__(self, operation_id: _Optional[str] = ..., dataset_id: _Optional[str] = ..., started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., time_elapsed: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., state: _Optional[_Union[OperationState, str]] = ...) -> None: ...

class ExecuteMatchingAlgorithmOnDatasetRequest(_message.Message):
    __slots__ = ("dataset_id", "algorithm")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    ALGORITHM_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    algorithm: MatchingAlgorithm
    def __init__(self, dataset_id: _Optional[str] = ..., algorithm: _Optional[_Union[MatchingAlgorithm, str]] = ...) -> None: ...

class ExecuteMatchingAlgorithmOnDatasetResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: Operation
    def __init__(self, operation: _Optional[_Union[Operation, _Mapping]] = ...) -> None: ...

class ListOperationsRequest(_message.Message):
    __slots__ = ("limit", "state")
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    limit: int
    state: OperationState
    def __init__(self, limit: _Optional[int] = ..., state: _Optional[_Union[OperationState, str]] = ...) -> None: ...

class ListOperationsResponse(_message.Message):
    __slots__ = ("operations",)
    OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    operations: _containers.RepeatedCompositeFieldContainer[Operation]
    def __init__(self, operations: _Optional[_Iterable[_Union[Operation, _Mapping]]] = ...) -> None: ...

class GetStateOfOperationRequest(_message.Message):
    __slots__ = ("operation_id",)
    OPERATION_ID_FIELD_NUMBER: _ClassVar[int]
    operation_id: str
    def __init__(self, operation_id: _Optional[str] = ...) -> None: ...

class GetStateOfOperationResponse(_message.Message):
    __slots__ = ("operation",)
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    operation: Operation
    def __init__(self, operation: _Optional[_Union[Operation, _Mapping]] = ...) -> None: ...
