import unittest

from django.conf import settings


if not settings.configured:
    settings.configure(
        SECRET_KEY="test-secret",
        INSTALLED_APPS=[
            "django.contrib.auth",
            "django.contrib.contenttypes",
        ],
        DATABASES={"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}},
        USE_TZ=True,
    )

import django

django.setup()


class PackageSmokeTests(unittest.TestCase):
    def test_package_exports(self):
        from djangotoolspack import (
            AdminMixin,
            AuditLogMixin,
            SerializerMixin,
            StandardPaginationResult,
            TimestampedMixin,
            UserTrackedMixin,
        )

        self.assertTrue(TimestampedMixin)
        self.assertTrue(UserTrackedMixin)
        self.assertTrue(AuditLogMixin)
        self.assertTrue(AdminMixin)
        self.assertTrue(SerializerMixin)
        self.assertTrue(StandardPaginationResult)

    def test_serializer_mixin_file_and_ordering(self):
        from djangotoolspack import SerializerMixin

        class _BaseSerializer:
            def to_representation(self, instance):
                return {
                    "id": 1,
                    "name": "sample",
                    "avatar": "raw",
                    "priority": 10,
                }

        class _Serializer(SerializerMixin, _BaseSerializer):
            class Meta:
                file_fields = ["avatar"]
                fields_ordering = ["priority", "id"]

        class _File:
            url = "https://example.com/avatar.png"

        class _Obj:
            avatar = _File()

        output = _Serializer().to_representation(_Obj())
        self.assertEqual(output["avatar"], "https://example.com/avatar.png")
        self.assertEqual(list(output.keys())[-2:], ["priority", "id"])


if __name__ == "__main__":
    unittest.main()
