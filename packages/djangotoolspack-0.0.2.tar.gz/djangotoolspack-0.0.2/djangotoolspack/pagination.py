from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from rest_framework.request import Request
from rest_framework import status
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

class StandardPaginationResult(PageNumberPagination):
    page_size_query_param = "page_size"
    page_query_param = "page"
    page_size = 50
    max_page_size = 5000
    
    def set_page_size(self, request: "Request"):
        page_size = request.query_params.get(self.page_size_query_param, self.page_size)
        try:
            parsed_page_size = int(page_size)
        except (TypeError, ValueError):
            parsed_page_size = self.page_size

        if parsed_page_size < 1:
            parsed_page_size = self.page_size

        self.page_size = min(parsed_page_size, self.max_page_size)

    def paginate_queryset(self, queryset, request, view=None):
        self.set_page_size(request)

        if isinstance(queryset, list):
            paginator = Paginator(queryset, self.page_size)
            page_number = request.query_params.get(self.page_query_param, 1)
            try:
                self.page = paginator.page(page_number)
            except PageNotAnInteger:
                self.page = paginator.page(1)
            except EmptyPage:
                self.page = paginator.page(paginator.num_pages)

            self.request = request
            return list(self.page)

        return super().paginate_queryset(queryset, request, view)

    def get_paginated_response(self, data, message=None, status_code=None):
        if status_code is None:
            status_code = status.HTTP_200_OK

        if not hasattr(self, "page") or self.page is None:
            return Response({
                "status": "fail",
                "code": 500,
                "message": "Pagination not initialized. Please use paginate_queryset first.",
                "error": {
                    "type": "PaginationError",
                    "details": "Missing self.page object."
                },
                "data": [],
                "pagination": None,
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        
        if 200 <= status_code < 300:
            response_status = "success"
        elif 400 <= status_code < 500:
            response_status = "fail"
        else:
            response_status = "error"
        
        return Response({   
                "status": response_status,
                "code": status_code,
                "message": message,
                "data": {
                    "result": data,
                    "pagination": {
                        "page_size": self.page_size,
                        "total_objects": self.page.paginator.count,
                        "total_pages": self.page.paginator.num_pages,
                        "current_page": self.page.number,
                        "next": self.get_next_link(),
                        "previous": self.get_previous_link(),
                    },
                },
                
            }, status=status_code)
