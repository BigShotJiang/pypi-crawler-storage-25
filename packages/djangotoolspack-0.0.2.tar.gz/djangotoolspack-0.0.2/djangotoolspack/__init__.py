from importlib import import_module

__all__ = [
    "TimestampedMixin",
    "UserTrackedMixin",
    "AuditLogMixin",
    "AdminMixin",
    "SerializerMixin",
    "StandardPaginationResult",
]

_EXPORTS = {
    "TimestampedMixin": (".mixins", "TimestampedMixin"),
    "UserTrackedMixin": (".mixins", "UserTrackedMixin"),
    "AuditLogMixin": (".mixins", "AuditLogMixin"),
    "AdminMixin": (".mixins", "AdminMixin"),
    "SerializerMixin": (".mixins", "SerializerMixin"),
    "StandardPaginationResult": (".pagination", "StandardPaginationResult"),
}


def __getattr__(name):
    if name in _EXPORTS:
        module_name, attr_name = _EXPORTS[name]
        module = import_module(module_name, package=__name__)
        value = getattr(module, attr_name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | set(__all__))
