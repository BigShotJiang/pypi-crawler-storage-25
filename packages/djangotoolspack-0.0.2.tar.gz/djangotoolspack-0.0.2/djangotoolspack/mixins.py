from django.conf import settings
from django.contrib import admin
from django.db import models


class TimestampedMixin(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, editable=False)
    updated_at = models.DateTimeField(auto_now=True, editable=False)

    class Meta:
        abstract = True


class UserTrackedMixin(models.Model):
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, editable=False, related_name="%(app_label)s_%(class)s_created_by_related",)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, editable=False, related_name="%(app_label)s_%(class)s_updated_by_related",)

    class Meta:
        abstract = True


class AuditLogMixin(TimestampedMixin, UserTrackedMixin):
    class Meta:
        abstract = True


class AdminMixin(admin.ModelAdmin):
    def save_model(self, request, obj, form, change):
        user = request.user if request.user.is_authenticated else None

        if not change:
            obj.created_by = user
        obj.updated_by = user
        super().save_model(request, obj, form, change)


class SerializerMixin:
    def to_representation(self, instance):
        data = super().to_representation(instance)

        meta = getattr(self, "Meta", None)
        file_fields = getattr(meta, "file_fields", [])
        for field in file_fields:
            file_obj = getattr(instance, field, None)
            if file_obj and hasattr(file_obj, "url"):
                data[field] = file_obj.url
            else:
                data[field] = None

        fields_ordering = getattr(meta, "fields_ordering", [])
        for field in fields_ordering:
            if field in data:
                data[field] = data.pop(field)

        return data
