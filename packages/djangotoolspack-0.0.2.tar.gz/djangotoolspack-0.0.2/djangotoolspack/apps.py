from django.apps import AppConfig


class DjangoToolsPackConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "djangotoolspack"
    verbose_name = "Django Tools Pack"
