# Django Tools Pack Usage Guide

This guide is for application developers who want to install the package and use it directly in their Django project.

## 1) Install

```bash
pip install djangotoolspack
```

## 2) Add to INSTALLED_APPS

In your Django settings:

```python
INSTALLED_APPS = [
    # your apps...
    "djangotoolspack",
]
```

## 3) Import what you need

```python
from djangotoolspack import (
    TimestampedMixin,
    UserTrackedMixin,
    AuditLogMixin,
    AdminMixin,
    SerializerMixin,
    StandardPaginationResult,
)
```

## 4) Use mixins in models

```python
from django.db import models
from djangotoolspack import AuditLogMixin


class Product(AuditLogMixin, models.Model):
    name = models.CharField(max_length=120)
    price = models.DecimalField(max_digits=10, decimal_places=2)
```

What you get automatically:
- `created_at`
- `updated_at`
- `created_by`
- `updated_by`

## 5) Use AdminMixin in Django admin

```python
from django.contrib import admin
from djangotoolspack import AdminMixin
from .models import Product


@admin.register(Product)
class ProductAdmin(AdminMixin):
    list_display = ("id", "name", "created_at", "updated_at")
```

`AdminMixin` sets:
- `created_by` when object is first created in admin
- `updated_by` on every admin save

## 6) Use SerializerMixin for file URLs and field ordering

```python
from rest_framework import serializers
from djangotoolspack import SerializerMixin
from .models import Product


class ProductSerializer(SerializerMixin, serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ["id", "name", "image", "price"]

        # Converts file fields to URL (or None)
        file_fields = ["image"]

        # Moves listed fields to the end in this exact order
        fields_ordering = ["price", "id"]
```

## 7) Use StandardPaginationResult in API views

```python
from rest_framework.views import APIView
from djangotoolspack import StandardPaginationResult
from .models import Product
from .serializers import ProductSerializer


class ProductListApi(APIView):
    def get(self, request):
        queryset = Product.objects.all().order_by("-id")

        paginator = StandardPaginationResult()
        page_items = paginator.paginate_queryset(queryset, request, view=self)
        serializer = ProductSerializer(page_items, many=True)

        return paginator.get_paginated_response(
            serializer.data,
            message="Products fetched successfully",
            status_code=200,
        )
```

Supported query params:
- `page`
- `page_size`

## Typical import pattern

Import directly from the package root:

```python
from djangotoolspack import AuditLogMixin, StandardPaginationResult
```

If you need any help then please contact with use.