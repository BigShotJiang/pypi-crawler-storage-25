# Django Tools Pack

Development documentation for maintaining and releasing the djangotoolspack package.

For application usage (install, import, and integration examples), see [docs/USAGE.md](docs/USAGE.md).

## Quick links

- Development docs: [README.md](README.md)
- End-user docs: [docs/USAGE.md](docs/USAGE.md)

## Package scope

Reusable Django and DRF helpers for:
- pagination
- model auditing fields
- admin user tracking
- serializer output customization

## Project layout

- [djangotoolspack/__init__.py](djangotoolspack/__init__.py): export surface.
- [djangotoolspack/apps.py](djangotoolspack/apps.py): Django app config.
- [djangotoolspack/mixins.py](djangotoolspack/mixins.py): model/admin/serializer mixins.
- [djangotoolspack/pagination.py](djangotoolspack/pagination.py): paginator class.

## Local development

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .[dev]
python -m unittest discover -s tests -p "test_*.py"
python -m build
python -m twine check dist/*
```

## End-user docs

- [docs/USAGE.md](docs/USAGE.md): install and use in your Django project.

## Publishing

Publishing to PyPI is automated via GitHub Actions on release.published using trusted publishing.
