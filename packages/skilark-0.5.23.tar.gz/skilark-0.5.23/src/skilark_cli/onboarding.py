"""
Choices and utilities used by the profile command and TUI for editing profile fields.

The onboarding flow (run_onboarding, run_profile_migration) has been removed.
Identity is now established via `skilark login` (OAuth).
"""

ROLE_CHOICES = [
    {"name": "Software Engineer", "value": "swe"},
    {"name": "ML / AI Engineer", "value": "ai_ml"},
    {"name": "Data Engineer", "value": "data_eng"},
    {"name": "Platform / DevOps", "value": "platform"},
    {"name": "Security Engineer", "value": "security"},
    {"name": "Product Manager", "value": "product"},
    {"name": "Research", "value": "research"},
    {"name": "Other", "value": "other"},
]

LANGUAGE_CHOICES = [
    {"name": "Python", "value": "Python"},
    {"name": "Go", "value": "Go"},
    {"name": "Java", "value": "Java"},
    {"name": "TypeScript", "value": "TypeScript"},
    {"name": "Rust", "value": "Rust"},
    {"name": "C++", "value": "C++"},
    {"name": "Other", "value": "Other"},
]

DIRECTION_CHOICES = [
    {"name": "Stay sharp in my current role", "value": "stay_sharp"},
    {"name": "Level up (promotion track)", "value": "level_up"},
    {"name": "Transition to a new role", "value": "transition"},
]

# Mapping from profile fields to auto-derived topics for backward compat.
_LANGUAGE_TO_TOPICS: dict[str, list[str]] = {
    "Python": ["python"],
    "Go": ["go"],
    "Java": ["java"],
    "TypeScript": ["typescript"],
    "Rust": ["rust"],
    "C++": ["c"],
    "Other": [],
}

_ROLE_TO_TOPICS: dict[str, list[str]] = {
    "swe": ["dsa", "system-design"],
    "ai_ml": ["pytorch", "llms", "python"],
    "data_eng": ["sql", "spark", "python"],
    "platform": ["kubernetes", "docker", "terraform"],
    "security": ["linux"],
    "product": [],
    "research": ["python"],
    "other": [],
}

# Keep old TOPIC_CHOICES available for backward-compat (imported by tests etc.)
TOPIC_CHOICES = [
    {"name": "Python", "value": "python"},
    {"name": "Java", "value": "java"},
    {"name": "JavaScript", "value": "javascript"},
    {"name": "Go", "value": "go"},
    {"name": "Rust", "value": "rust"},
    {"name": "C / C++", "value": "c"},
    {"name": "TypeScript", "value": "typescript"},
    {"name": "SQL", "value": "sql"},
    {"name": "Kubernetes", "value": "kubernetes"},
    {"name": "Docker", "value": "docker"},
    {"name": "Terraform", "value": "terraform"},
    {"name": "AWS", "value": "aws"},
    {"name": "CI/CD", "value": "cicd"},
    {"name": "Linux", "value": "linux"},
    {"name": "Spark", "value": "spark"},
    {"name": "Kafka", "value": "kafka"},
    {"name": "Airflow", "value": "airflow"},
    {"name": "Data Modeling", "value": "data-modeling"},
    {"name": "PyTorch", "value": "pytorch"},
    {"name": "LLMs", "value": "llms"},
    {"name": "Deep Learning", "value": "deep-learning"},
    {"name": "Machine Learning", "value": "machine-learning"},
    {"name": "REST APIs", "value": "rest-api"},
    {"name": "Redis", "value": "redis"},
    {"name": "Spring Boot", "value": "spring-boot"},
    {"name": "Distributed Systems", "value": "distributed-systems"},
    {"name": "DSA", "value": "dsa"},
    {"name": "Design Patterns", "value": "patterns"},
    {"name": "System Design", "value": "system-design"},
    {"name": "Git", "value": "git"},
    {"name": "Maven", "value": "maven"},
    {"name": "Bazel", "value": "bazel"},
]


def derive_topics(role: str, language: str) -> list[str]:
    """Derive backward-compatible topics from profile fields."""
    topics = list(_LANGUAGE_TO_TOPICS.get(language, []))
    for t in _ROLE_TO_TOPICS.get(role, []):
        if t not in topics:
            topics.append(t)
    return topics if topics else ["python"]  # fallback
