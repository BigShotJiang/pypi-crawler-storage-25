"""
Tests for onboarding choices and derive_topics utility.

run_onboarding and run_profile_migration have been removed — identity is
now established via `skilark login` (OAuth).
"""

from skilark_cli.config_store import ConfigStore
from skilark_cli.onboarding import (
    TOPIC_CHOICES,
    ROLE_CHOICES,
    LANGUAGE_CHOICES,
    DIRECTION_CHOICES,
    derive_topics,
)


def test_topic_choices_cover_key_sources():
    values = {t["value"] for t in TOPIC_CHOICES}
    assert "python" in values
    assert "java" in values
    assert "go" in values
    assert "docker" in values
    assert "kubernetes" in values
    assert "dsa" in values
    assert "sql" in values


def test_role_choices_not_empty():
    assert len(ROLE_CHOICES) >= 5
    values = {c["value"] for c in ROLE_CHOICES}
    assert "swe" in values
    assert "ai_ml" in values
    assert "data_eng" in values


def testderive_topics_python_swe():
    topics = derive_topics("swe", "Python")
    assert "python" in topics
    assert "dsa" in topics
    assert "system-design" in topics


def testderive_topics_go_data_eng():
    topics = derive_topics("data_eng", "Go")
    assert "go" in topics
    assert "sql" in topics
    assert "spark" in topics


def testderive_topics_fallback():
    topics = derive_topics("other", "Other")
    assert topics == ["python"]  # fallback when no topics derived


def test_config_store_has_profile(tmp_path):
    store = ConfigStore(config_dir=tmp_path)
    assert not store.has_profile()

    store.save(user_id="test-id", topics=["python"], api_url="http://localhost:8000")
    assert not store.has_profile()

    store.update_profile(current_role="swe")
    assert store.has_profile()
