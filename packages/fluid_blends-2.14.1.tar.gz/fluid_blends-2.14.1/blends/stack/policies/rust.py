from __future__ import annotations

from typing import TYPE_CHECKING

from blends.stack.policies.base import ExportPolicy
from blends.stack.scope_types import ScopeType

if TYPE_CHECKING:
    from blends.models import NId, StackGraph, SyntaxGraph


class RustExportPolicy(ExportPolicy):
    def get_visibility_modifier(
        self,
        graph: SyntaxGraph,
        node_id: NId,
    ) -> str | None:
        modifiers = graph.nodes[node_id].get(
            "access_modifiers",
            graph.nodes[node_id].get("access_modifier", ""),
        )
        if "pub" in modifiers:
            return "public"
        return None

    def is_scope_exported(
        self,
        graph: SyntaxGraph,
        node_id: NId,
        scope_type: str | None,
    ) -> bool:
        if scope_type == ScopeType.FILE.value:
            return True
        if scope_type == ScopeType.CLASS.value:
            return True
        if scope_type == ScopeType.DECLARATION.value:
            return self.get_visibility_modifier(graph, node_id) == "public"
        return False

    def is_definition_exported(
        self,
        graph: SyntaxGraph,
        stack_graph: StackGraph | None,
        node_id: NId,
        parent_scope_id: NId | None,
    ) -> bool:
        # Trait impl methods carry no pub — bypass pub gate when parent is a trait impl
        if parent_scope_id is not None and graph.nodes.get(parent_scope_id, {}).get(
            "inherited_class"
        ):
            sg_nodes = stack_graph.nodes if stack_graph is not None else graph.nodes
            return bool(sg_nodes.get(parent_scope_id, {}).get("stack_graph_is_exported", False))

        if self.get_visibility_modifier(graph, node_id) != "public":
            return False
        if parent_scope_id is None:
            return True
        sg_nodes = stack_graph.nodes if stack_graph is not None else graph.nodes
        return bool(sg_nodes.get(parent_scope_id, {}).get("stack_graph_is_exported", False))
