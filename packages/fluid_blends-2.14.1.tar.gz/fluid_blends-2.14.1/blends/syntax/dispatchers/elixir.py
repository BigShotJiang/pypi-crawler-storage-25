from blends.syntax.models import (
    Dispatcher,
)
from blends.syntax.readers.elixir import (
    access_call as elixir_access_call,
)
from blends.syntax.readers.elixir import (
    anonymous_function as elixir_anonymous_function,
)
from blends.syntax.readers.elixir import (
    arguments as elixir_arguments,
)
from blends.syntax.readers.elixir import (
    atom as elixir_atom,
)
from blends.syntax.readers.elixir import (
    binary_operator as elixir_binary_operator,
)
from blends.syntax.readers.elixir import (
    bitstring as elixir_bitstring,
)
from blends.syntax.readers.elixir import (
    block as elixir_block,
)
from blends.syntax.readers.elixir import (
    boolean_literal as elixir_boolean_literal,
)
from blends.syntax.readers.elixir import (
    call as elixir_call,
)
from blends.syntax.readers.elixir import (
    comment as elixir_comment,
)
from blends.syntax.readers.elixir import (
    complex_identifier as elixir_complex_identifier,
)
from blends.syntax.readers.elixir import (
    dot as elixir_dot,
)
from blends.syntax.readers.elixir import (
    identifier as elixir_identifier,
)
from blends.syntax.readers.elixir import (
    integer_literal as elixir_integer_literal,
)
from blends.syntax.readers.elixir import (
    interpolation as elixir_interpolation,
)
from blends.syntax.readers.elixir import (
    keywords as elixir_keywords,
)
from blends.syntax.readers.elixir import (
    list as elixir_list,
)
from blends.syntax.readers.elixir import (
    map as elixir_map,
)
from blends.syntax.readers.elixir import (
    nil as elixir_nil,
)
from blends.syntax.readers.elixir import (
    pair as elixir_pair,
)
from blends.syntax.readers.elixir import (
    source_file as elixir_source_file,
)
from blends.syntax.readers.elixir import (
    stab_clause as elixir_stab_clause,
)
from blends.syntax.readers.elixir import (
    string_literal as elixir_string_literal,
)
from blends.syntax.readers.elixir import (
    tuple as elixir_tuple,
)
from blends.syntax.readers.elixir import (
    unary_operator as elixir_unary_operator,
)

ELIXIR_DISPATCHERS: Dispatcher = {
    # source
    "source": elixir_source_file.reader,
    # identifiers and names
    "identifier": elixir_identifier.reader,
    "alias": elixir_identifier.reader,
    "struct": elixir_complex_identifier.reader,
    "operator_identifier": elixir_complex_identifier.reader,
    "sigil_name": elixir_identifier.reader,
    # literals
    "integer": elixir_integer_literal.reader,
    "float": elixir_integer_literal.reader,
    "char": elixir_string_literal.reader,
    "atom": elixir_atom.reader,
    "keyword": elixir_atom.reader,
    "quoted_atom": elixir_atom.reader,
    "quoted_keyword": elixir_atom.reader,
    "boolean": elixir_boolean_literal.reader,
    "true": elixir_boolean_literal.reader,
    "false": elixir_boolean_literal.reader,
    "nil": elixir_nil.reader,
    # strings
    "string": elixir_string_literal.reader,
    "charlist": elixir_string_literal.reader,
    "quoted_content": elixir_string_literal.reader,
    "sigil": elixir_string_literal.reader,
    "escape_sequence": elixir_string_literal.reader,
    "sigil_modifiers": elixir_string_literal.reader,
    # comments
    "comment": elixir_comment.reader,
    # operators
    "binary_operator": elixir_binary_operator.reader,
    "unary_operator": elixir_unary_operator.reader,
    # collections
    "list": elixir_list.reader,
    "tuple": elixir_tuple.reader,
    "map": elixir_map.reader,
    "map_content": elixir_keywords.reader,
    "keywords": elixir_keywords.reader,
    "pair": elixir_pair.reader,
    "bitstring": elixir_bitstring.reader,
    # interpolation
    "interpolation": elixir_interpolation.reader,
    # access
    "dot": elixir_dot.reader,
    "access_call": elixir_access_call.reader,
    # arguments
    "arguments": elixir_arguments.reader,
    # blocks
    "block": elixir_block.reader,
    "do_block": elixir_block.reader,
    "body": elixir_block.reader,
    "else_block": elixir_block.reader,
    "rescue_block": elixir_block.reader,
    "catch_block": elixir_block.reader,
    "after_block": elixir_block.reader,
    # functions
    "call": elixir_call.reader,
    "anonymous_function": elixir_anonymous_function.reader,
    "stab_clause": elixir_stab_clause.reader,
}
