from blends.models import (
    NId,
)
from blends.syntax.builders.class_decl import (
    build_class_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.java.class_declaration import (
    extract_modifiers,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    name_id = graph.nodes[args.n_id]["label_field_name"]
    name = node_to_str(graph, name_id)
    body_id = graph.nodes[args.n_id]["label_field_body"]
    modifiers_id, access_modifiers = extract_modifiers(graph, args.n_id)
    is_public = access_modifiers is not None and "public" in access_modifiers
    return build_class_node(
        args,
        name,
        body_id,
        None,
        modifiers_id=modifiers_id,
        access_modifiers=access_modifiers,
        export_definition=is_public,
    )
