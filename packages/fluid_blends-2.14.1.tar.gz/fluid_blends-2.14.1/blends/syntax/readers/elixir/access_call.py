from blends.models import (
    NId,
)
from blends.syntax.builders.element_access import (
    build_element_access_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    n_attrs = args.ast_graph.nodes[args.n_id]
    return build_element_access_node(
        args,
        n_attrs["label_field_target"],
        n_attrs["label_field_key"],
    )
