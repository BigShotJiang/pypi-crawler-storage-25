from blends.models import (
    NId,
)
from blends.syntax.builders.method_declaration import (
    DirectChildren,
    build_method_declaration_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    n_attrs = args.ast_graph.nodes[args.n_id]
    direct: DirectChildren = {}
    if left_id := n_attrs.get("label_field_left"):
        direct["parameters_id"] = left_id
    if right_id := n_attrs.get("label_field_right"):
        direct["block_id"] = right_id
    return build_method_declaration_node(args, None, direct, {})
