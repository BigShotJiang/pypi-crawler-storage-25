from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.object import (
    build_object_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    ignored_outer = {"%", "{", "}", ",", "\n", "\r\n"}
    graph = args.ast_graph
    c_ids: list[NId] = []
    for child in adj_ast(graph, args.n_id):
        label = graph.nodes[child]["label_type"]
        if label in ignored_outer:
            continue
        if label in {"map_content", "keywords"}:
            for gc in adj_ast(graph, child):
                gc_label = graph.nodes[gc]["label_type"]
                if gc_label in {"pair", "comment"}:
                    c_ids.append(gc)
                elif gc_label == "keywords":
                    c_ids.extend(
                        ggc
                        for ggc in adj_ast(graph, gc)
                        if graph.nodes[ggc]["label_type"] in {"pair", "comment"}
                    )
    return build_object_node(args, c_ids=iter(c_ids))
