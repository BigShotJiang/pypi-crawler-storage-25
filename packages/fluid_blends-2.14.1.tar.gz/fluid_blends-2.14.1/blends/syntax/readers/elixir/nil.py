from blends.models import NId
from blends.syntax.builders.literal import build_literal_node
from blends.syntax.models import SyntaxGraphArgs


def reader(args: SyntaxGraphArgs) -> NId:
    return build_literal_node(args, "nil", "null")
