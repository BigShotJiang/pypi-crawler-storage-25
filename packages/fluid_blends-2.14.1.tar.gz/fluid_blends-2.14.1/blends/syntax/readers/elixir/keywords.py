from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.object import (
    build_object_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    c_ids = [
        child
        for child in adj_ast(graph, args.n_id)
        if graph.nodes[child]["label_type"] in {"pair", "comment"}
    ]
    return build_object_node(args, c_ids=iter(c_ids))
