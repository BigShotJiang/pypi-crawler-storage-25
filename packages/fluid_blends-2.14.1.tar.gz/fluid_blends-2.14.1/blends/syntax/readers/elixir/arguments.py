from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.argument_list import (
    build_argument_list_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    ignored_labels = {"(", ",", ")", "\n", "\r\n", "comment"}
    graph = args.ast_graph
    c_ids = [
        child
        for child in adj_ast(graph, args.n_id)
        if graph.nodes[child]["label_type"] not in ignored_labels
    ]
    return build_argument_list_node(args, iter(c_ids))
