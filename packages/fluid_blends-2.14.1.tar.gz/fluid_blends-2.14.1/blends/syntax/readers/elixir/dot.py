from blends.models import (
    NId,
)
from blends.syntax.builders.member_access import (
    build_member_access_node,
)
from blends.syntax.builders.symbol_lookup import (
    build_symbol_lookup_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    n_attrs = graph.nodes[args.n_id]
    left_id = n_attrs.get("label_field_left")
    right_id = n_attrs.get("label_field_right")
    if left_id is None:
        name = node_to_str(graph, right_id) if right_id else ""
        return build_symbol_lookup_node(args, name)
    if right_id is None:
        return build_symbol_lookup_node(args, node_to_str(graph, left_id))
    member = node_to_str(graph, right_id)
    expression = node_to_str(graph, left_id)
    return build_member_access_node(args, member, expression, left_id)
