from blends.models import (
    Graph,
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.import_statement import (
    ImportElement,
    build_import_statement_node,
)
from blends.syntax.builders.method_declaration import (
    DirectChildren as DeclChildren,
)
from blends.syntax.builders.method_declaration import (
    build_method_declaration_node,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren as InvocChildren,
)
from blends.syntax.builders.method_invocation import (
    build_method_invocation_node,
)
from blends.syntax.builders.namespace import (
    build_namespace_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)

_IMPORT_KEYWORDS = {"alias", "import", "use", "require"}


def _find_child_by_type(
    graph: Graph,
    n_id: NId,
    label_type: str,
) -> NId | None:
    return next(
        (nid for nid in adj_ast(graph, n_id) if graph.nodes[nid]["label_type"] == label_type),
        None,
    )


def _build_defmodule(
    args: SyntaxGraphArgs,
    arguments_id: NId | None,
    do_block_id: NId | None,
) -> NId:
    graph = args.ast_graph
    name = "anonymous"
    if arguments_id:
        name_id = next(
            (
                nid
                for nid in adj_ast(graph, arguments_id)
                if graph.nodes[nid]["label_type"] not in {"(", ")", ",", "comment", "keywords"}
            ),
            None,
        )
        if name_id:
            name = node_to_str(graph, name_id)
    block_id = _resolve_block_id(graph, arguments_id, do_block_id) if arguments_id else do_block_id
    return build_namespace_node(args, name, block_id)


def _find_do_keyword_body(graph: Graph, arguments_id: NId) -> NId | None:
    keywords_id = _find_child_by_type(graph, arguments_id, "keywords")
    if not keywords_id:
        return None
    for pair_id in adj_ast(graph, keywords_id):
        if graph.nodes[pair_id]["label_type"] != "pair":
            continue
        key_id = graph.nodes[pair_id].get("label_field_key")
        if key_id and node_to_str(graph, key_id).strip().rstrip(":") == "do":
            return graph.nodes[pair_id].get("label_field_value")
    return None


def _resolve_block_id(
    graph: Graph,
    arguments_id: NId,
    do_block_id: NId | None,
) -> NId | None:
    if do_block_id:
        return do_block_id
    return _find_do_keyword_body(graph, arguments_id)


def _find_signature_node(graph: Graph, arguments_id: NId) -> NId | None:
    sig_id = _find_child_by_type(graph, arguments_id, "call")
    if sig_id:
        return sig_id
    bin_op_id = _find_child_by_type(graph, arguments_id, "binary_operator")
    if bin_op_id:
        return graph.nodes[bin_op_id].get("label_field_left")
    return None


def _build_def(
    args: SyntaxGraphArgs,
    arguments_id: NId | None,
    do_block_id: NId | None,
) -> NId:
    graph = args.ast_graph
    direct: DeclChildren = {}

    if not arguments_id:
        if do_block_id:
            direct["block_id"] = do_block_id
        return build_method_declaration_node(args, "anonymous", direct, {})

    block_id = _resolve_block_id(graph, arguments_id, do_block_id)
    if block_id:
        direct["block_id"] = block_id

    sig_id = _find_signature_node(graph, arguments_id)
    if sig_id:
        sig_attrs = graph.nodes[sig_id]
        if sig_attrs["label_type"] == "call":
            func_name = node_to_str(graph, sig_attrs["label_field_target"])
            params_id = _find_child_by_type(graph, sig_id, "arguments")
            if params_id:
                direct["parameters_id"] = params_id
        else:
            func_name = node_to_str(graph, sig_id)
        return build_method_declaration_node(args, func_name, direct, {})

    name_id = next(
        (
            nid
            for nid in adj_ast(graph, arguments_id)
            if graph.nodes[nid]["label_type"] not in {"(", ")", ",", "comment", "keywords"}
        ),
        None,
    )
    name = node_to_str(graph, name_id) if name_id else "anonymous"
    return build_method_declaration_node(args, name, direct, {})


def _build_import(
    args: SyntaxGraphArgs,
    target_name: str,
    arguments_id: NId | None,
    do_block_id: NId | None,
) -> NId:
    graph = args.ast_graph
    block_id = _resolve_block_id(graph, arguments_id, do_block_id) if arguments_id else do_block_id
    if not arguments_id:
        result = build_import_statement_node(args)
    else:
        module_ids = [
            nid
            for nid in adj_ast(graph, arguments_id)
            if graph.nodes[nid]["label_type"] not in {"(", ")", ",", "comment", "keywords"}
        ]
        if not module_ids:
            result = build_import_statement_node(args)
        else:
            import_elements: list[ImportElement] = [
                {
                    "corrected_n_id": module_id,
                    "method_name": target_name,
                    "expression": node_to_str(graph, module_id),
                }
                for module_id in module_ids
            ]
            result = build_import_statement_node(args, *import_elements)
    if block_id:
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(block_id)),
            label_ast="AST",
        )
    return result


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    n_attrs = graph.nodes[args.n_id]
    target_id = n_attrs["label_field_target"]
    target_name = node_to_str(graph, target_id)

    arguments_id = _find_child_by_type(graph, args.n_id, "arguments")
    do_block_id = _find_child_by_type(graph, args.n_id, "do_block")

    if target_name == "defmodule":
        return _build_defmodule(args, arguments_id, do_block_id)

    if target_name in {"def", "defp"}:
        return _build_def(args, arguments_id, do_block_id)

    if target_name in _IMPORT_KEYWORDS:
        return _build_import(args, target_name, arguments_id, do_block_id)

    children: InvocChildren = {"expression_id": target_id}
    if arguments_id:
        children["arguments_id"] = arguments_id
    block_id = _resolve_block_id(graph, arguments_id, do_block_id) if arguments_id else do_block_id
    if block_id:
        children["block_id"] = block_id
    return build_method_invocation_node(args, target_name, children)
