from blends.models import NId
from blends.query import adj_ast
from blends.syntax.builders.file import build_file_node
from blends.syntax.models import SyntaxGraphArgs


def reader(args: SyntaxGraphArgs) -> NId:
    ignored_labels = {
        "\n",
        "\r\n",
    }
    graph = args.ast_graph
    c_ids = adj_ast(graph, args.n_id)
    filtered_ids = [_id for _id in c_ids if graph.nodes[_id]["label_type"] not in ignored_labels]
    return build_file_node(args, filtered_ids)
