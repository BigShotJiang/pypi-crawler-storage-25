from collections.abc import (
    Iterator,
)

from blends.ctx import ctx
from blends.models import (
    Language,
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.stack.edges import (
    Edge,
    add_edge,
)
from blends.stack.node_helpers import scope_node_attributes
from blends.stack.policies.registry import get_export_policy
from blends.stack.scope_types import ScopeType
from blends.syntax.models import (
    SyntaxGraphArgs,
)

_BLOCK_SCOPED_LANGUAGES: frozenset[Language] = frozenset({Language.JAVASCRIPT, Language.TYPESCRIPT})


def _enter_block_scope(args: SyntaxGraphArgs) -> None:
    scope_stack = args.metadata.setdefault("scope_stack", [])
    if scope_stack:
        args.syntax_graph.scope_parent[args.n_id] = scope_stack[-1]
    if ctx.has_feature_flag("StackGraph"):
        policy = get_export_policy(args.language)
        stack_attrs = scope_node_attributes(
            is_exported=policy.is_scope_exported(
                args.syntax_graph, args.n_id, ScopeType.BLOCK.value
            ),
            scope_type=ScopeType.BLOCK,
        )
        if args.stack_graph is not None:
            args.stack_graph.add_node(args.n_id, **stack_attrs)
        if scope_stack and args.stack_graph is not None:
            add_edge(args.stack_graph, Edge(source=args.n_id, sink=scope_stack[-1], precedence=0))
    scope_stack.append(args.n_id)


def _exit_block_scope(args: SyntaxGraphArgs) -> None:
    scope_stack = args.metadata.setdefault("scope_stack", [])
    if scope_stack and scope_stack[-1] == args.n_id:
        scope_stack.pop()


def build_execution_block_node(args: SyntaxGraphArgs, c_ids: Iterator[NId]) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        label_type="ExecutionBlock",
    )
    use_block_scope = args.language in _BLOCK_SCOPED_LANGUAGES
    if use_block_scope:
        _enter_block_scope(args)
    for c_id in c_ids:
        if (
            args.language != Language.DART
            and args.ast_graph.nodes[c_id]["label_type"] == "expression_statement"
        ):
            child_id = adj_ast(args.ast_graph, c_id)[0]
            args.syntax_graph.add_edge(
                args.n_id,
                args.generic(args.fork_n_id(child_id)),
                label_ast="AST",
            )
        else:
            args.syntax_graph.add_edge(
                args.n_id,
                args.generic(args.fork_n_id(c_id)),
                label_ast="AST",
            )

    if use_block_scope:
        _exit_block_scope(args)
    return args.n_id
