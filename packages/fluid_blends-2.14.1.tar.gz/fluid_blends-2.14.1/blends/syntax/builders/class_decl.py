from collections.abc import (
    Iterable,
)

from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.stack.scope_types import ScopeType
from blends.syntax.builders.utils import (
    enter_scope_stack,
    exit_scope_stack_if_current,
    setup_stack_graph_definition,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_class_node(  # noqa: PLR0913
    args: SyntaxGraphArgs,
    name: str,
    block_id: NId | None,
    attrl_ids: Iterable[NId] | None,
    inherited_class: str | None = None,
    modifiers_id: NId | None = None,
    access_modifiers: str | None = None,
    *,
    export_definition: bool = True,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        name=name,
        block_id=block_id,
        label_type="Class",
        **({"access_modifiers": access_modifiers} if access_modifiers else {}),
        **({"inherited_class": inherited_class} if inherited_class else {}),
    )

    if ctx.has_feature_flag("StackGraph"):
        setup_stack_graph_definition(args, name, is_exported=export_definition)

    enter_scope_stack(args, name, ScopeType.CLASS)

    if block_id:
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(block_id)),
            label_ast="AST",
        )

    if attrl_ids:
        for n_id in attrl_ids:
            args.syntax_graph.add_edge(
                args.n_id,
                args.generic(args.fork_n_id(n_id)),
                label_ast="AST",
            )

    if modifiers_id:
        args.syntax_graph.update_node_attribute(args.n_id, "modifiers_id", modifiers_id)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(modifiers_id)),
            label_ast="AST",
        )

    if args.metadata["class_path"]:
        args.metadata["class_path"].pop()

    exit_scope_stack_if_current(args)

    return args.n_id
