"""SDK primitives — narrow injection points that vary between hosted and
local execution. The SDK has ONE code path; each high-level method calls
the relevant primitive directly. There is no per-method adapter layer.

  Signer       — sign + broadcast txs and EVM messages.
  LogSink      — write-only log timeline destination.
  MemoryStore  — bidirectional key-value storage.
  RpcProvider  — chain reads (receipts).
  HostedApi    — hosted-only operations (swap, platforms, indexed reads,
                 job tracking). The local impl raises LocalModeUnsupported
                 on every call; the hosted impl HTTP-calls agent-api.

Hosted Lambda runtimes stay lightweight HTTP clients: every primitive's
hosted impl is a thin wrapper around a POST/GET/DELETE to agent-api. No
new IAM credentials, no direct KMS or DB access on the Lambda. The
Lambda's SDK code path is identical to the local CLI's; only the
primitives' implementations differ.
"""

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass
class SignedTxResult:
    """Returned by the signer's transaction-signing methods. The on-chain
    tx hash is the only field both modes agree on; everything else (URLs,
    suggestion ids) is computed by the SDK around this primitive return.
    """

    tx_hash: str


class Signer(Protocol):
    """The signing primitive. Hosted impl posts to agent-api `/v1/sign`
    (which does policy + OFAC + KMS + broadcast); local impl signs with a
    keystore-backed account and broadcasts via direct RPC.
    """

    def sign_evm_transaction(self, request: dict[str, Any]) -> SignedTxResult: ...
    def sign_solana_transaction(self, request: dict[str, Any]) -> SignedTxResult: ...
    def sign_evm_message(self, request: dict[str, Any]) -> dict[str, Any]: ...


class LogSink(Protocol):
    """Append timeline log entries. Hosted: POST `/v1/logs`. Local: append to file."""

    def append(self, logs: list[Any]) -> None: ...


class MemoryStore(Protocol):
    def set(self, key: str, value: str, options: Any = None) -> dict[str, Any]: ...
    def get(self, key: str, options: Any = None) -> dict[str, Any]: ...
    def delete(self, key: str, options: Any = None) -> dict[str, Any]: ...
    def list(self, options: Any = None) -> dict[str, Any]: ...


class RpcProvider(Protocol):
    """Chain reads (receipts). Hosted: HTTP to agent-api's RPC proxy.
    Local: direct RPC via web3.py.
    """

    def wait_for_receipt(
        self, chain_id: int, tx_hash: str, timeout_ms: int = 30000
    ) -> str: ...


class HostedApi(Protocol):
    """Hosted-only operations. These rely on Circuit's indexer, session
    tracking, or platform-specific server-side logic that has no local
    equivalent today. Local-mode runtimes provide an implementation that
    raises LocalModeUnsupported on every method.

    Inputs and outputs are typed as `dict[str, Any]` (or `list` for
    array-shaped responses) — the wire format is JSON, validated into
    Pydantic models by the SDK consumer methods (swap.py, hyperliquid.py,
    etc.). Both impls construct/return the same JSON shape; the SDK
    enforces it at the next layer up.
    """

    # swap
    def swap_quote(self, request: dict[str, Any]) -> dict[str, Any]: ...
    def swap_execute(
        self, request: dict[str, Any] | list[dict[str, Any]]
    ) -> dict[str, Any] | list[Any]: ...

    # polymarket
    def polymarket_market_order(self, request: dict[str, Any]) -> dict[str, Any]: ...
    def polymarket_redeem_positions(
        self, request: dict[str, Any]
    ) -> dict[str, Any]: ...

    # hyperliquid
    def hyperliquid_place_order(self, request: dict[str, Any]) -> dict[str, Any]: ...
    def hyperliquid_order(self, order_id: str) -> dict[str, Any]: ...
    def hyperliquid_delete_order(self, order_id: str, coin: str) -> dict[str, Any]: ...
    def hyperliquid_balances(self) -> dict[str, Any]: ...
    def hyperliquid_positions(self, dex: str | None = None) -> dict[str, Any]: ...
    def hyperliquid_open_orders(self) -> dict[str, Any]: ...
    def hyperliquid_order_fills(self) -> dict[str, Any]: ...
    def hyperliquid_historical_orders(self) -> dict[str, Any]: ...
    def hyperliquid_transfer(self, request: dict[str, Any]) -> dict[str, Any]: ...
    def hyperliquid_liquidations(
        self, start_time: int | None = None
    ) -> dict[str, Any]: ...

    # session-bound reads/writes
    def transactions_ledger(self) -> dict[str, Any] | list[Any]: ...
    def current_positions(self) -> dict[str, Any]: ...
    def clear_suggested_transactions(self) -> dict[str, Any]: ...
    def update_job_status(self, request: dict[str, Any]) -> dict[str, Any]: ...


@dataclass
class SdkPrimitives:
    """The bag of primitives an AgentSdk is built with. The SDK takes one
    of these and routes every method through the relevant primitive —
    there is no SDK-level distinction between hosted and local.
    """

    signer: Signer
    logs: LogSink
    memory: MemoryStore
    rpc: RpcProvider
    hosted_api: HostedApi


class LocalModeUnsupported(RuntimeError):
    """Raised by local-mode HostedApi (and any other primitive method that
    has no local fulfillment) when an agent calls a hosted-only method.
    Surfaced verbatim to agent code.
    """

    def __init__(self, operation: str) -> None:
        super().__init__(
            f"{operation} is not supported in local mode (requires Circuit's "
            "hosted indexer/session state). Run this agent via 'circuit "
            "publish' + hosted execution, or query the data directly via RPC."
        )
        self.code = "LOCAL_MODE_UNSUPPORTED"
        self.operation = operation
