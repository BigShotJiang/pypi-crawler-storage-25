"""Local-mode primitives — thin clients over the parent CLI's UDS RPC.

All execution-layer logic (signing, broadcast, swap routing, platform
orchestration) lives in TS. Python primitives forward each call to the
parent ``circuit dev run`` process over a Unix domain socket and wait
for the JSON response on the same connection.

The architectural rule: ``execution-layer`` (TS) is the single canonical
implementation. Hosted Python reaches it via HTTPS to ``agent-api``;
local Python reaches it via UDS to the parent CLI process. Either way,
no DeFi runtime code lives in Python.

Configuration: the parent CLI listens on
``<CIRCUIT_CONFIG_PATH>/.run-<parent_pid>.sock`` and the SDK derives
that path from ``os.getppid()``. Running ``python main.py`` standalone
errors at connect time with a clear hint to use ``circuit dev run``.

The HostedApi protocol's auto-stub via ``__getattr__`` still applies:
methods not explicitly named here forward to ``client.call(method,
params)`` and translate ``LOCAL_MODE_UNSUPPORTED`` errors into
``LocalModeUnsupported`` exceptions.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .local_call import LocalCallClient, build_call_client_from_env
from .primitives import (
    HostedApi,
    LogSink,
    MemoryStore,
    RpcProvider,
    SdkPrimitives,
    SignedTxResult,
    Signer,
)


def _camel_case(snake: str) -> str:
    parts = snake.split("_")
    return parts[0] + "".join(p.title() for p in parts[1:])


def _build_signer(client: LocalCallClient) -> Signer:
    class _CallSigner:
        def sign_evm_transaction(self, request: dict[str, Any]) -> SignedTxResult:
            result = client.call("signer.signEvmTransaction", request)
            return SignedTxResult(tx_hash=result["txHash"])

        def sign_solana_transaction(self, request: dict[str, Any]) -> SignedTxResult:
            result = client.call("signer.signSolanaTransaction", request)
            return SignedTxResult(tx_hash=result["txHash"])

        def sign_evm_message(self, request: dict[str, Any]) -> dict[str, Any]:
            result: dict[str, Any] = client.call("signer.signEvmMessage", request)
            return result

    return _CallSigner()


def _build_log_sink(client: LocalCallClient) -> LogSink:
    class _CallLogSink:
        def append(self, logs: list[Any]) -> None:
            client.call("logs.append", {"logs": logs})

    return _CallLogSink()


def _build_memory_store(client: LocalCallClient) -> MemoryStore:
    class _CallMemoryStore:
        def set(self, key: str, value: str, options: Any = None) -> dict[str, Any]:
            result: dict[str, Any] = client.call(
                "memory.set",
                {"key": key, "value": value, "options": options},
            )
            return result

        def get(self, key: str, options: Any = None) -> dict[str, Any]:
            result: dict[str, Any] = client.call(
                "memory.get", {"key": key, "options": options}
            )
            return result

        def delete(self, key: str, options: Any = None) -> dict[str, Any]:
            result: dict[str, Any] = client.call(
                "memory.delete", {"key": key, "options": options}
            )
            return result

        def list(self, options: Any = None) -> dict[str, Any]:
            result: dict[str, Any] = client.call("memory.list", {"options": options})
            return result

    return _CallMemoryStore()


def _build_rpc_provider(client: LocalCallClient) -> RpcProvider:
    class _CallRpcProvider:
        def wait_for_receipt(
            self, chain_id: int, tx_hash: str, timeout_ms: int = 30000
        ) -> str:
            result: str = client.call(
                "rpc.waitForReceipt",
                {"chainId": chain_id, "txHash": tx_hash, "timeoutMs": timeout_ms},
            )
            return result

    return _CallRpcProvider()


def _build_hosted_api(client: LocalCallClient) -> HostedApi:
    """HostedApi where every method round-trips to the CLI over the
    Unix-socket RPC channel.

    ``__getattr__`` covers methods not added to HostedApi at the time
    this code was written, plus all the platform methods that don't need
    explicit shaping. The CLI's dispatcher exposes the same names.
    """

    class _CallHostedApi:
        def __getattr__(self, name: str) -> Callable[..., Any]:
            if name.startswith("_"):
                raise AttributeError(name)

            method = f"hostedApi.{_camel_case(name)}"

            def _impl(*args: Any, **kwargs: Any) -> Any:
                # Most HostedApi methods take a single positional argument
                # (a request object/dict). When called with multiple args,
                # bundle them as ordered positional params. Keyword args
                # become the params object directly.
                if kwargs:
                    return client.call(method, kwargs)
                if len(args) == 1:
                    return client.call(method, args[0])
                if len(args) == 0:
                    return client.call(method, None)
                return client.call(method, list(args))

            return _impl

    return _CallHostedApi()


def build_local_primitives() -> SdkPrimitives:
    """Build the RPC-backed primitives bag.

    Connects to the parent CLI's UDS at
    ``<config-path>/.run-<getppid()>.sock``. Errors with an actionable
    hint if the socket isn't there — indicates the agent is being run
    outside ``circuit dev run``.
    """

    client = build_call_client_from_env()
    return SdkPrimitives(
        signer=_build_signer(client),
        logs=_build_log_sink(client),
        memory=_build_memory_store(client),
        rpc=_build_rpc_provider(client),
        hosted_api=_build_hosted_api(client),
    )
