"""
Circuit Agent Python SDK v1.2 — clean, unified, agent automation.

**Major Simplification:**
- Agent functions receive a single `AgentContext` object with everything they need
- Functions return `None` - all error handling is automatic
- Unified `agent.log()` for both console and backend logging
- No more boilerplate code

Install: `pip install circuit-agent-sdk`

Minimal example (v1.2):
```python
from agent_sdk import Agent, AgentContext

def run_function(agent: AgentContext) -> None:
    agent.log(f"Starting execution for session {agent.sessionId}")
    agent.memory.set("last_run", str(time.time()))
    positions = agent.platforms.polymarket.positions()
    if positions.success:
        agent.log(f"Found {len(positions.data.positions)} positions")

agent = Agent(run_function=run_function)

# For local development
if __name__ == "__main__":
    agent.run()

# For Circuit deployment
handler = agent.get_handler()
```

Features:
- Unified Interface: Single `AgentContext` object with request data + SDK methods
- Simple Logging: `agent.log()` handles console + backend with debug/error flags
- Type Safety: Full type hints and Pydantic models
- Cross-Chain: Unified interface for EVM and Solana networks
- Swap: Cross-chain swaps via `agent.swap.quote()` and `agent.swap.execute()`
- Polymarket: Prediction markets via `agent.platforms.polymarket.*`
- Memory: Key-value storage (session-scoped or shared) via `agent.memory.*`
- Error Handling: Automatic catching and reporting of uncaught exceptions
- Deployment: Simple local dev with `agent.run()`, production with `agent.get_handler()`

For more information, see the README.md file or visit:
https://github.com/circuitorg/agent-sdk-python
"""

# Per-primitive injection — runtime seam for hosted vs. local execution
from .agent import (
    Agent,
    AgentConfig,
    AgentRequest,
    AgentResponse,
    ExecutionFunctionContract,
    HealthCheckFunctionContract,
    HealthResponse,
    UnwindFunctionContract,
    create_agent_handler,
)
from .agent_context import AgentContext
from .agent_sdk import AgentSdk
from .hosted_primitives import build_hosted_primitives
from .local_primitives import build_local_primitives
from .primitives import (
    HostedApi,
    LocalModeUnsupported,
    LogSink,
    MemoryStore,
    RpcProvider,
    SdkPrimitives,
    SignedTxResult,
    Signer,
)

# Core types
from .types import (
    CurrentPosition,
    Network,
    SDKConfig,
    get_chain_id_from_network,
    is_ethereum_network,
    is_solana_network,
)

# Utility functions
from .utils import get_agent_config_from_pyproject, setup_logging

__all__ = [
    # Main SDK
    "AgentSdk",
    "AgentContext",
    # Agent wrapper for HTTP server deployment
    "Agent",
    "AgentConfig",
    "AgentRequest",
    "AgentResponse",
    "HealthResponse",
    "create_agent_handler",
    "ExecutionFunctionContract",
    "UnwindFunctionContract",
    "HealthCheckFunctionContract",
    # Per-primitive injection
    "SdkPrimitives",
    "Signer",
    "LogSink",
    "MemoryStore",
    "RpcProvider",
    "HostedApi",
    "SignedTxResult",
    "LocalModeUnsupported",
    "build_hosted_primitives",
    "build_local_primitives",
    # Core types
    "CurrentPosition",
    "Network",
    "SDKConfig",
    "is_ethereum_network",
    "is_solana_network",
    "get_chain_id_from_network",
    # Utility functions
    "get_agent_config_from_pyproject",
    "setup_logging",
]
