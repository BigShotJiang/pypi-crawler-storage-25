"""
Memory operations for agent session storage.

This module provides the MemoryApi class for storing and retrieving key-value
pairs scoped to the current agent session or shared across all sessions.
"""

import json
from typing import TYPE_CHECKING, Any

from .types.memory import (
    MemoryDeleteData,
    MemoryDeleteResponse,
    MemoryGetData,
    MemoryGetResponse,
    MemoryListData,
    MemoryListResponse,
    MemorySetData,
    MemorySetResponse,
)

if TYPE_CHECKING:
    from .agent_sdk import AgentSdk


def _ensure_string_error(error: Any) -> str:
    """
    Ensure error is always a string, converting dicts/objects to JSON if needed.

    Args:
        error: Error value that might be a string, dict, or other type

    Returns:
        String representation of the error
    """
    if error is None:
        return "Unknown error"
    elif isinstance(error, dict):
        return json.dumps(error)
    else:
        return str(error)


class MemoryApi:
    """
    Key-value storage operations (session-scoped or shared).

    By default, keys are namespaced by agentId and sessionId (session scope).
    Pass ``shared=True`` to use agent-wide shared storage that is accessible
    across all sessions. Shared memory uses last-write-wins concurrency.

    """

    def __init__(self, sdk: "AgentSdk"):
        self._sdk = sdk

    @staticmethod
    def _scope_options(shared: bool) -> dict[str, bool] | None:
        return {"shared": True} if shared else None

    def set(self, key: str, value: str, shared: bool = False) -> MemorySetResponse:
        """Set a key-value pair in memory.

        Store a string value with a unique key. The key is automatically scoped to your
        agent and session (or shared if ``shared=True``).

        **Input**: ``key: str, value: str, shared: bool = False``
            - ``key`` (str): Unique identifier for the value (1-255 characters)
            - ``value`` (str): String value to store
            - ``shared`` (bool): If True, store in shared (cross-session) memory

        **Output**: ``MemorySetResponse``
            - ``success`` (bool): Whether the operation succeeded
            - ``data`` (MemorySetData | None): Present on success
              - ``key`` (str): The key that was set
            - ``error`` (str | None): Error message on failure

        Args:
            key: Unique identifier for the value
            value: String value to store
            shared: If True, store in shared memory accessible across sessions

        Returns:
            MemorySetResponse: Wrapped response with success status and key

        Example:
            ```python
            # Session memory (default)
            sdk.memory.set("lastSwapNetwork", "ethereum:42161")

            # Shared memory (accessible across sessions)
            sdk.memory.set("preferredSlippage", "0.5", shared=True)
            ```
        """
        return self._handle_memory_set(key, value, shared)

    def get(self, key: str, shared: bool = False) -> MemoryGetResponse:
        """Get a value by key from memory.

        Retrieve a previously stored value. Returns an error if the key doesn't exist.

        **Input**: ``key: str, shared: bool = False``
            - ``key`` (str): The key to retrieve
            - ``shared`` (bool): If True, read from shared memory

        **Output**: ``MemoryGetResponse``
            - ``success`` (bool): Whether the operation succeeded
            - ``data`` (MemoryGetData | None): Present on success
              - ``key`` (str): The requested key
              - ``value`` (str): The stored value
            - ``error`` (str | None): Error message (e.g., "Key not found")

        Args:
            key: The key to retrieve
            shared: If True, read from shared memory accessible across sessions

        Returns:
            MemoryGetResponse: Wrapped response with key and value, or error details

        Example:
            ```python
            # Session memory (default)
            result = sdk.memory.get("lastSwapNetwork")

            # Shared memory
            result = sdk.memory.get("preferredSlippage", shared=True)
            ```
        """
        return self._handle_memory_get(key, shared)

    def list(
        self,
        prefix: str | None = None,
        shared: bool = False,
    ) -> MemoryListResponse:
        """List keys in memory.

        Enumerate keys in the current scope, optionally filtered by a prefix.
        Results are returned in lexicographic ascending order, capped at 1000
        items (R2's hard ceiling). Pagination is intentionally not exposed —
        organize keys to stay under that limit.

        **Input**: ``prefix: str | None = None, shared: bool = False``
            - ``prefix`` (str, optional): Filter keys by prefix
            - ``shared`` (bool): If True, list shared-scope keys

        **Output**: ``MemoryListResponse``
            - ``success`` (bool): Whether the operation succeeded
            - ``data`` (MemoryListData | None): Present on success
              - ``items`` (list[MemoryListItem]): Matching keys with metadata (max 1000)
            - ``error`` (str | None): Error message on failure

        Args:
            prefix: Optional prefix filter on user-facing key names
            shared: If True, list shared memory (across sessions)

        Returns:
            MemoryListResponse: Wrapped response with up to 1000 items

        Example:
            ```python
            # Session keys (default)
            result = sdk.memory.list()
            if result.success and result.data:
                for item in result.data.items:
                    print(item.key, item.updated_at)

            # Prefix filter
            result = sdk.memory.list(prefix="lastSwap")

            # Shared scope
            result = sdk.memory.list(shared=True)
            ```
        """
        return self._handle_memory_list(prefix, shared)

    def delete(self, key: str, shared: bool = False) -> MemoryDeleteResponse:
        """Delete a key from memory.

        Remove a key-value pair. Succeeds even if the key doesn't exist.

        **Input**: ``key: str, shared: bool = False``
            - ``key`` (str): The key to delete
            - ``shared`` (bool): If True, delete from shared memory

        **Output**: ``MemoryDeleteResponse``
            - ``success`` (bool): Whether the operation succeeded
            - ``data`` (MemoryDeleteData | None): Present on success
              - ``key`` (str): The key that was deleted
            - ``error`` (str | None): Error message on failure

        Args:
            key: The key to delete
            shared: If True, delete from shared memory accessible across sessions

        Returns:
            MemoryDeleteResponse: Wrapped response with success status and deleted key

        Example:
            ```python
            # Session memory (default)
            sdk.memory.delete("tempSwapQuote")

            # Shared memory
            sdk.memory.delete("preferredSlippage", shared=True)
            ```
        """
        return self._handle_memory_delete(key, shared)

    def _handle_memory_set(
        self, key: str, value: str, shared: bool = False
    ) -> MemorySetResponse:
        try:
            response = self._sdk.primitives.memory.set(
                key, value, self._scope_options(shared)
            )
            return MemorySetResponse(
                success=True, data=MemorySetData(**response["data"]), error=None
            )
        except Exception as error:
            return MemorySetResponse(
                success=False,
                data=None,
                error=_ensure_string_error(str(error)) or "Failed to set memory",
            )

    def _handle_memory_get(self, key: str, shared: bool = False) -> MemoryGetResponse:
        try:
            response = self._sdk.primitives.memory.get(key, self._scope_options(shared))
            if not response.get("success", True):
                return MemoryGetResponse(
                    success=False, data=None, error=response.get("error")
                )
            return MemoryGetResponse(
                success=True, data=MemoryGetData(**response["data"]), error=None
            )
        except Exception as error:
            return MemoryGetResponse(
                success=False,
                data=None,
                error=_ensure_string_error(str(error)) or "Failed to get memory",
            )

    def _handle_memory_delete(
        self, key: str, shared: bool = False
    ) -> MemoryDeleteResponse:
        try:
            response = self._sdk.primitives.memory.delete(
                key, self._scope_options(shared)
            )
            return MemoryDeleteResponse(
                success=True, data=MemoryDeleteData(**response["data"]), error=None
            )
        except Exception as error:
            return MemoryDeleteResponse(
                success=False,
                data=None,
                error=_ensure_string_error(str(error)) or "Failed to delete memory",
            )

    def _handle_memory_list(
        self, prefix: str | None, shared: bool
    ) -> MemoryListResponse:
        options: dict[str, Any] = {}
        if shared:
            options["shared"] = True
        if prefix is not None:
            options["prefix"] = prefix
        try:
            response = self._sdk.primitives.memory.list(options or None)
            return MemoryListResponse(
                success=True, data=MemoryListData(**response["data"]), error=None
            )
        except Exception as error:
            return MemoryListResponse(
                success=False,
                data=None,
                error=_ensure_string_error(str(error)) or "Failed to list memory",
            )
