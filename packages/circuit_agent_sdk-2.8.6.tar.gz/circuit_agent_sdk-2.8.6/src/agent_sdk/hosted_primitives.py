"""Hosted primitives — every Signer/LogSink/MemoryStore/RpcProvider/HostedApi
method is a thin HTTP call to agent-api via the supplied APIClient. Used
by the Agent HTTP wrapper when serving /run requests in the Lambda
sandbox.

Lambda stays a pure HTTP client: no KMS access, no DB credentials, no
indexer reads. agent-api remains the trust-critical edge that owns
policy + OFAC + KMS.
"""

import time
from typing import Any
from urllib.parse import quote, urlencode

from .client import APIClient
from .primitives import (
    HostedApi,
    LogSink,
    MemoryStore,
    RpcProvider,
    SdkPrimitives,
    SignedTxResult,
    Signer,
)


def _memory_scope_query(options: Any) -> str:
    if options is None:
        return ""
    shared = (
        options.get("shared")
        if isinstance(options, dict)
        else getattr(options, "shared", None)
    )
    return "?scope=shared" if shared else ""


def _memory_list_query(options: Any) -> str:
    if options is None:
        return ""
    if isinstance(options, dict):
        shared = options.get("shared")
        prefix = options.get("prefix")
    else:
        shared = getattr(options, "shared", None)
        prefix = getattr(options, "prefix", None)
    params: list[tuple[str, str]] = []
    if shared:
        params.append(("scope", "shared"))
    if prefix is not None:
        params.append(("prefix", prefix))
    return f"?{urlencode(params)}" if params else ""


def _build_signer(client: APIClient) -> Signer:
    class _HostedSigner:
        def sign_evm_transaction(self, request: dict[str, Any]) -> SignedTxResult:
            wrapper = client.post("/v1/sign", {"kind": "evm", **request})
            assert isinstance(wrapper, dict)
            return SignedTxResult(tx_hash=wrapper["data"]["txHash"])

        def sign_solana_transaction(self, request: dict[str, Any]) -> SignedTxResult:
            wrapper = client.post("/v1/sign", {"kind": "solana", **request})
            assert isinstance(wrapper, dict)
            return SignedTxResult(tx_hash=wrapper["data"]["txHash"])

        def sign_evm_message(self, request: dict[str, Any]) -> dict[str, Any]:
            return client.post("/v1/messages/evm", request)  # type: ignore[return-value]

    return _HostedSigner()


def _build_log_sink(client: APIClient) -> LogSink:
    class _HostedLogSink:
        def append(self, logs: list[Any]) -> None:
            client.post("/v1/logs", logs)

    return _HostedLogSink()


def _build_memory_store(client: APIClient) -> MemoryStore:
    class _HostedMemoryStore:
        def set(self, key: str, value: str, options: Any = None) -> dict[str, Any]:
            return client.post(  # type: ignore[return-value]
                f"/v1/memory/{key}{_memory_scope_query(options)}",
                {"value": value},
            )

        def get(self, key: str, options: Any = None) -> dict[str, Any]:
            return client.get(  # type: ignore[return-value]
                f"/v1/memory/{key}{_memory_scope_query(options)}"
            )

        def delete(self, key: str, options: Any = None) -> dict[str, Any]:
            return client.delete(  # type: ignore[return-value]
                f"/v1/memory/{key}{_memory_scope_query(options)}"
            )

        def list(self, options: Any = None) -> dict[str, Any]:
            return client.get(  # type: ignore[return-value]
                f"/v1/memory{_memory_list_query(options)}"
            )

    return _HostedMemoryStore()


def _build_rpc_provider(client: APIClient) -> RpcProvider:
    class _HostedRpcProvider:
        def wait_for_receipt(
            self, chain_id: int, tx_hash: str, timeout_ms: int = 30000
        ) -> str:
            deadline = time.time() + (timeout_ms / 1000)
            while time.time() < deadline:
                try:
                    res = client.get(f"/v1/rpc/{chain_id}/receipt/{tx_hash}", timeout=5)
                    status = res.get("status") if isinstance(res, dict) else None
                    if status == "success":
                        return "success"
                    if status == "reverted":
                        return "reverted"
                    if status != "pending":
                        return "unknown"
                except Exception:
                    pass
                time.sleep(1)
            return "unknown"

    return _HostedRpcProvider()


def _build_hosted_api(client: APIClient) -> HostedApi:
    class _HostedApi:
        # swap
        def swap_quote(self, request: dict[str, Any]) -> dict[str, Any]:
            return client.post("/v1/swap/quote", request)  # type: ignore[return-value]

        def swap_execute(
            self, request: dict[str, Any] | list[dict[str, Any]]
        ) -> dict[str, Any] | list[Any]:
            return client.post("/v1/swap/execute", request)

        # polymarket
        def polymarket_market_order(self, request: dict[str, Any]) -> dict[str, Any]:
            return client.post(  # type: ignore[return-value]
                "/v1/platforms/polymarket/market-order", request
            )

        def polymarket_redeem_positions(
            self, request: dict[str, Any]
        ) -> dict[str, Any]:
            return client.post(  # type: ignore[return-value]
                "/v1/platforms/polymarket/redeem-positions", request
            )

        # hyperliquid
        def hyperliquid_place_order(self, request: dict[str, Any]) -> dict[str, Any]:
            return client.post(  # type: ignore[return-value]
                "/v1/platforms/hyperliquid/order", request
            )

        def hyperliquid_order(self, order_id: str) -> dict[str, Any]:
            return client.get(  # type: ignore[return-value]
                f"/v1/platforms/hyperliquid/order/{order_id}"
            )

        def hyperliquid_delete_order(self, order_id: str, coin: str) -> dict[str, Any]:
            return client.delete(  # type: ignore[return-value]
                f"/v1/platforms/hyperliquid/order/{order_id}/{coin}"
            )

        def hyperliquid_balances(self) -> dict[str, Any]:
            return client.get("/v1/platforms/hyperliquid/balances")  # type: ignore[return-value]

        def hyperliquid_positions(self, dex: str | None = None) -> dict[str, Any]:
            path = "/v1/platforms/hyperliquid/positions"
            if dex:
                path = f"{path}?dex={quote(dex)}"
            return client.get(path)  # type: ignore[return-value]

        def hyperliquid_open_orders(self) -> dict[str, Any]:
            return client.get("/v1/platforms/hyperliquid/orders")  # type: ignore[return-value]

        def hyperliquid_order_fills(self) -> dict[str, Any]:
            return client.get(  # type: ignore[return-value]
                "/v1/platforms/hyperliquid/orders/fill-history"
            )

        def hyperliquid_historical_orders(self) -> dict[str, Any]:
            return client.get(  # type: ignore[return-value]
                "/v1/platforms/hyperliquid/orders/historical"
            )

        def hyperliquid_transfer(self, request: dict[str, Any]) -> dict[str, Any]:
            return client.post(  # type: ignore[return-value]
                "/v1/platforms/hyperliquid/transfer", request
            )

        def hyperliquid_liquidations(
            self, start_time: int | None = None
        ) -> dict[str, Any]:
            path = "/v1/platforms/hyperliquid/liquidations"
            if start_time is not None:
                path = f"{path}?startTime={start_time}"
            return client.get(path)  # type: ignore[return-value]

        # session-bound reads/writes
        def transactions_ledger(self) -> dict[str, Any] | list[Any]:
            return client.get("/v1/transactions/ledger")

        def current_positions(self) -> dict[str, Any]:
            return client.get("/v1/positions/current")  # type: ignore[return-value]

        def clear_suggested_transactions(self) -> dict[str, Any]:
            return client.delete("/v1/sessions/suggestions")  # type: ignore[return-value]

        def update_job_status(self, request: dict[str, Any]) -> dict[str, Any]:
            return client.post(  # type: ignore[return-value]
                f"/v1/jobs/{request['jobId']}/status", request
            )

    return _HostedApi()


def build_hosted_primitives(client: APIClient) -> SdkPrimitives:
    """Construct a full hosted primitive bag from an APIClient. The SDK
    takes the result and routes every method through it; no further
    hosted/local branching exists at any layer above this.
    """

    return SdkPrimitives(
        signer=_build_signer(client),
        logs=_build_log_sink(client),
        memory=_build_memory_store(client),
        rpc=_build_rpc_provider(client),
        hosted_api=_build_hosted_api(client),
    )
