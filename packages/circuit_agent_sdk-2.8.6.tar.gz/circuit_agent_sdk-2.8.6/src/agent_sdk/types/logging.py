"""
Logging type definitions for agent operations.

This module provides types for logging operations that send timeline logs
to session traces and UIs for observability and debugging.
"""

from typing import Literal

from pydantic import Field

from .base import BaseRequest, BaseResponse


class AddLogRequest(BaseRequest):
    """
    Message request for send_log function.

    Used to send timeline logs that show up in session traces and UIs for
    observability, human-in-the-loop reviews, and debugging.

    Attributes:
        type: Log type — `"info"` for normal logs or `"error"` for failures.
        message: Log message content (max 250 characters).

    Examples:
        ```python
        # Status observation
        sdk.send_log({
            "type": "info",
            "message": "Starting swap operation"
        })

        # Error reporting
        sdk.send_log({
            "type": "error",
            "message": "Transaction failed: insufficient gas"
        })
        ```
    """

    type: Literal["info", "error"] = Field(..., description="Type of log")
    message: str = Field(..., description="Log message content", max_length=250)


class LogResponse(BaseResponse[None]):
    """
    Response from agent.log() operations.

    This response is returned after attempting to log a message to the console
    and optionally to the backend.

    Attributes:
        success: Whether the operation was successful
        error: Error message (only present on failure)

    Example:
        ```python
        response = agent.log("Processing transaction")
        if not response.success:
            print(f"Failed to log: {response.error}")
        ```
    """

    data: None = Field(None, description="No data returned for log operations")
