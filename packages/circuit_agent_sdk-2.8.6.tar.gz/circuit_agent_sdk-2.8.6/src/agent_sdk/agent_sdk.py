"""Main AgentSdk class with a single SDK code path. Every method routes
through one of the small primitive interfaces (`Signer`, `LogSink`,
`MemoryStore`, `RpcProvider`, `HostedApi`); the hosted/local variation
lives entirely below the surface.
"""

from typing import Any, cast

from .memory import MemoryApi
from .platforms import PlatformsApi
from .primitives import SdkPrimitives
from .swap import SwapApi
from .types import (
    AddLogRequest,
    AssetChange,
    ClearSuggestionsResponse,
    EthereumSignRequest,
    EvmMessageSignData,
    EvmMessageSignRequest,
    EvmMessageSignResponse,
    GetCurrentPositionsData,
    GetCurrentPositionsResponse,
    SignAndSendData,
    SignAndSendRequest,
    SignAndSendResponse,
    SolanaSignRequest,
    TransactionsResponse,
    UpdateJobStatusRequest,
    UpdateJobStatusResponse,
    get_chain_id_from_network,
    is_ethereum_network,
    is_solana_network,
)


class AgentSdk:
    """Main SDK entrypoint. Provides:

    - `send_log()` — emit timeline logs
    - `sign_message()` — sign EIP-712 / EIP-191 messages on EVM
    - `sign_and_send()` — sign and broadcast transactions across networks
    - `swap` — cross-chain swap operations
    - `platforms` — platform integrations (polymarket, hyperliquid)
    - `memory` — key-value storage
    """

    swap: "SwapApi"
    platforms: "PlatformsApi"
    memory: "MemoryApi"

    def __init__(self, primitives: SdkPrimitives) -> None:
        """Create an AgentSdk routed through the supplied primitives bag."""

        self.primitives = primitives
        self.swap = SwapApi(self)
        self.platforms = PlatformsApi(self)
        self.memory = MemoryApi(self)

    # ---------------------------------------------------------------------
    # Logs
    # ---------------------------------------------------------------------

    def send_log(self, log: AddLogRequest | dict) -> None:
        """Add a log to the agent timeline."""
        try:
            if isinstance(log, dict):
                msg = log.get("message", "")
                if isinstance(msg, str) and len(msg) > 250:
                    log = {**log, "message": f"{msg[:247]}..."}
                message_obj = AddLogRequest(**log)
            else:
                message_dict = log.model_dump()
                if len(message_dict.get("message", "")) > 250:
                    message_dict["message"] = f"{message_dict['message'][:247]}..."
                    message_obj = AddLogRequest(**message_dict)
                else:
                    message_obj = log
        except Exception:
            return

        try:
            self.primitives.logs.append(
                [{"type": message_obj.type, "message": message_obj.message}]
            )
        except Exception:
            # Logging errors must never crash the agent.
            pass

    def _send_logs(self, logs: list) -> dict[str, Any]:
        """Internal: send raw log payload via adapter. Used by AgentContext.log()."""
        self.primitives.logs.append(logs)
        return {}

    # ---------------------------------------------------------------------
    # Signing
    # ---------------------------------------------------------------------

    def sign_and_send(self, request: SignAndSendRequest | dict) -> SignAndSendResponse:
        """Sign and broadcast a transaction. Single round trip via /v1/sign
        (delegated to adapter) — no separate sign+broadcast steps.
        """
        try:
            request_obj = (
                SignAndSendRequest(**request) if isinstance(request, dict) else request
            )
            if is_ethereum_network(request_obj.network):
                if not isinstance(request_obj.request, EthereumSignRequest):
                    return SignAndSendResponse(
                        success=False,
                        data=None,
                        error="Ethereum network requires EthereumSignRequest",
                    )
                chain_id = get_chain_id_from_network(request_obj.network)
                payload: dict[str, Any] = {
                    "chainId": chain_id,
                    "toAddress": request_obj.request.to_address,
                    "data": request_obj.request.data,
                    "valueWei": request_obj.request.value,
                }
                # Forward optional fields when present so the adapter (and
                # eventually agent-api) sees the full request shape.
                for src, dst in (
                    ("gas", "gas"),
                    ("max_fee_per_gas", "maxFeePerGas"),
                    ("max_priority_fee_per_gas", "maxPriorityFeePerGas"),
                    ("nonce", "nonce"),
                    ("enforce_transaction_success", "enforceTransactionSuccess"),
                ):
                    val = getattr(request_obj.request, src, None)
                    if val is not None:
                        payload[dst] = val
                if request_obj.message is not None:
                    payload["message"] = request_obj.message
                if request_obj.expires_at is not None:
                    payload["expiresAt"] = request_obj.expires_at

                response = self.primitives.signer.sign_evm_transaction(payload)
                tx_hash = response.tx_hash
                return SignAndSendResponse(
                    success=True,
                    data=SignAndSendData(
                        internal_transaction_id=0,
                        tx_hash=tx_hash,
                        transaction_url=None,
                        suggestionId=None,
                    ),
                    error=None,
                )

            if is_solana_network(request_obj.network):
                if not isinstance(request_obj.request, SolanaSignRequest):
                    return SignAndSendResponse(
                        success=False,
                        data=None,
                        error="Solana network requires SolanaSignRequest",
                    )
                payload = {"hexTransaction": request_obj.request.hex_transaction}
                if request_obj.message is not None:
                    payload["message"] = request_obj.message
                if request_obj.expires_at is not None:
                    payload["expiresAt"] = request_obj.expires_at
                response = self.primitives.signer.sign_solana_transaction(payload)
                tx_hash = response.tx_hash
                return SignAndSendResponse(
                    success=True,
                    data=SignAndSendData(
                        internal_transaction_id=0,
                        tx_hash=tx_hash,
                        transaction_url=None,
                        suggestionId=None,
                    ),
                    error=None,
                )

            return SignAndSendResponse(
                success=False,
                data=None,
                error=f"Unsupported network: {request_obj.network}",
            )
        except Exception as e:
            return SignAndSendResponse(success=False, data=None, error=str(e))

    def sign_message(
        self, request: EvmMessageSignRequest | dict
    ) -> EvmMessageSignResponse:
        """Sign an EIP-712 or EIP-191 message on an EVM network."""
        try:
            request_obj = (
                EvmMessageSignRequest(**request)
                if isinstance(request, dict)
                else request
            )
            payload = {
                "messageType": request_obj.messageType,
                "data": request_obj.data,
                "chainId": request_obj.chainId,
            }
            response = self.primitives.signer.sign_evm_message(payload)
            return EvmMessageSignResponse(
                success=True,
                data=EvmMessageSignData(**response["data"]),
                error=None,
            )
        except Exception as e:
            return EvmMessageSignResponse(success=False, data=None, error=str(e))

    # ---------------------------------------------------------------------
    # Job tracking (used by Agent HTTP wrapper)
    # ---------------------------------------------------------------------

    def _update_job_status(
        self, request: UpdateJobStatusRequest | dict
    ) -> UpdateJobStatusResponse:
        request_obj = (
            UpdateJobStatusRequest(**request) if isinstance(request, dict) else request
        )
        payload: dict[str, Any] = {
            "jobId": request_obj.jobId,
            "status": request_obj.status,
        }
        if request_obj.errorMessage:
            payload["errorMessage"] = request_obj.errorMessage
        try:
            response = self.primitives.hosted_api.update_job_status(payload)
            # Hosted adapter returns the upstream response; local adapter
            # returns its own no-op shape. Normalize.
            status = response.get("status", 200) if isinstance(response, dict) else 200
            message = (
                response.get("message", "Job status updated")
                if isinstance(response, dict)
                else "Job status updated"
            )
            return UpdateJobStatusResponse(status=status, message=message)
        except Exception as e:
            return UpdateJobStatusResponse(
                status=400, message=f"Failed to update job status: {e}"
            )

    # ---------------------------------------------------------------------
    # Chain reads
    # ---------------------------------------------------------------------

    def _wait_for_receipt(
        self,
        chain_id: int,
        tx_hash: str,
        timeout_ms: int = 30000,
        interval_ms: int = 1000,  # noqa: ARG002 — kept for API compat
    ) -> str:
        """Poll a tx receipt until status is final. Returns 'success',
        'reverted', or 'unknown' (timeout/error)."""
        return self.primitives.rpc.wait_for_receipt(chain_id, tx_hash, timeout_ms)

    # ---------------------------------------------------------------------
    # Hosted-only reads (LocalAdapter raises LocalModeUnsupported)
    # ---------------------------------------------------------------------

    def transactions(self) -> TransactionsResponse:
        """Get transaction ledger with asset changes for the current session."""
        try:
            response = self.primitives.hosted_api.transactions_ledger()
            data = response["data"] if isinstance(response, dict) else response
            asset_changes = [AssetChange(**item) for item in cast(list[Any], data)]
            return TransactionsResponse(success=True, data=asset_changes, error=None)
        except Exception as e:
            return TransactionsResponse(success=False, data=None, error=str(e))

    def get_current_positions(self) -> GetCurrentPositionsResponse:
        """Get current live positions for the session (with Polymarket enrichment)."""
        try:
            response = self.primitives.hosted_api.current_positions()
            return GetCurrentPositionsResponse(
                success=True,
                data=GetCurrentPositionsData(**response["data"]),
                error=None,
            )
        except Exception as e:
            return GetCurrentPositionsResponse(success=False, data=None, error=str(e))

    def clear_suggested_transactions(self) -> ClearSuggestionsResponse:
        """Clear all pending suggested transactions for this session."""
        try:
            self.primitives.hosted_api.clear_suggested_transactions()
            return ClearSuggestionsResponse(success=True, data=None, error=None)
        except Exception as e:
            return ClearSuggestionsResponse(success=False, data=None, error=str(e))
