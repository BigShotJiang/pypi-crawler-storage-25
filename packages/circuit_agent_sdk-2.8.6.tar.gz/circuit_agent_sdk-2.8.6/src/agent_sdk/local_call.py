"""Local-mode primitive-call client.

The parent ``circuit dev run`` (or ``circuit dev unwind``) listens on
a Unix domain socket at ``<config-path>/.run-<parent_pid>.sock``. The
Python agent SDK opens that socket once at startup and writes one
NDJSON request per primitive call, blocking on the matching response.

  parent: ``circuit dev run`` (Bun, holds primitives + credential)
    └── opens UDS at ``<config-path>/.run-<pid>.sock``, listens
    └── spawns ``python main.py``
          └── PrimitiveRpcClient connects to the socket
                └── ``agent.swap.quote(...)`` →
                       write {"id": N, "method": "...", "params": ...}\\n
                       read  {"id": N, "result": ...}\\n
                       ~0.1ms vs the previous ~50ms-per-call subprocess

The credential never enters this process's environment — it lives only
in the parent's in-memory ``primitives`` and is reached over RPC.

Wire format (NDJSON, one object per line):

    request:  {"id": <number>, "method": "namespace.op", "params": <any>}
    response: {"id": <number>, "result": <any>}
            | {"id": <number>, "error": {"message": "...", "code"?: "..."}}

The path is derivable: ``CIRCUIT_CONFIG_PATH`` (already a documented
env var, defaults to ``~/.config/circuit``) plus the parent's pid via
``os.getppid()``. No extra env-var coordination needed.
"""

from __future__ import annotations

import json
import os
import socket
import threading
from pathlib import Path
from typing import Any

from .primitives import LocalModeUnsupported


class LocalCallError(RuntimeError):
    def __init__(self, message: str, code: str | None = None) -> None:
        super().__init__(message)
        self.code = code


class LocalCallClient:
    """Talks to the parent CLI's primitive RPC server over a Unix socket.

    Calls are serialized via an internal lock — the protocol carries
    request ids that would let the server interleave responses, but the
    Python agent SDK invokes primitives sequentially, so a simple write
    + read-line loop is enough for v1.
    """

    def __init__(self, socket_path: str) -> None:
        self._socket_path = socket_path
        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            self._sock.connect(socket_path)
        except (FileNotFoundError, ConnectionRefusedError) as e:
            raise LocalCallError(
                f"could not connect to circuit RPC socket at {socket_path}: {e}. "
                "This is normally set up by `circuit dev run`; running "
                "`python main.py` directly is not supported in local mode.",
                code="RPC_CONNECT_FAILED",
            ) from e
        # Buffered text-mode reader for line-delimited JSON.
        self._reader = self._sock.makefile("r", encoding="utf-8", newline="\n")
        self._lock = threading.Lock()
        self._next_id = 0

    def call(self, method: str, params: Any = None) -> Any:
        with self._lock:
            self._next_id += 1
            req_id = self._next_id
            payload = json.dumps({"id": req_id, "method": method, "params": params})
            try:
                self._sock.sendall((payload + "\n").encode("utf-8"))
                line = self._reader.readline()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError) as e:
                # Linux surfaces an abrupt peer close as ECONNRESET / EPIPE
                # mid-read or mid-write; macOS more often returns an empty
                # readline. Normalize both to RPC_DISCONNECT.
                raise LocalCallError(
                    "circuit RPC socket closed mid-call (parent died?)",
                    code="RPC_DISCONNECT",
                ) from e
            if not line:
                raise LocalCallError(
                    "circuit RPC socket closed mid-call (parent died?)",
                    code="RPC_DISCONNECT",
                )
            try:
                response = json.loads(line)
            except json.JSONDecodeError as e:
                raise LocalCallError(
                    f"circuit RPC returned non-JSON line: {line[:200]!r}",
                    code="RPC_BAD_RESPONSE",
                ) from e

        if "error" in response:
            err = response["error"] or {}
            code = err.get("code") if isinstance(err, dict) else None
            message = err.get("message") if isinstance(err, dict) else str(err)
            if code == "LOCAL_MODE_UNSUPPORTED":
                raise LocalModeUnsupported(message or method)
            raise LocalCallError(message or "unknown call error", code=code)

        return response.get("result")

    def close(self) -> None:
        try:
            self._reader.close()
        except Exception:
            pass
        try:
            self._sock.close()
        except Exception:
            pass


def _config_dir() -> Path:
    """Mirror the CLI's config-dir resolution."""
    override = os.environ.get("CIRCUIT_CONFIG_PATH")
    if override:
        return Path(override)
    return Path.home() / ".config" / "circuit"


def build_call_client_from_env() -> LocalCallClient:
    """Connect to the parent CLI's RPC socket.

    Path = ``<CIRCUIT_CONFIG_PATH or ~/.config/circuit>/.run-<getppid()>.sock``.
    The parent CLI sets up this socket before spawning Python; if Python
    is run standalone (``python main.py`` outside ``circuit dev run``)
    the connect fails with a clear error.
    """
    parent_pid = os.getppid()
    socket_path = str(_config_dir() / f".run-{parent_pid}.sock")
    return LocalCallClient(socket_path)
