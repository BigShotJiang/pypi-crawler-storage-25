"""Tests for memory type schemas."""

import pytest

from agent_sdk.types.memory import (
    MemoryGetData,
    MemoryListData,
    MemoryListItem,
    MemoryListResponse,
)


class TestMemoryGetData:
    def test_parses_response_with_camel_case_alias(self):
        """API returns updatedAt (camelCase), SDK exposes as updated_at."""
        data = MemoryGetData(key="lastPrice", value="45000.50", updatedAt=1744545600)
        assert data.key == "lastPrice"
        assert data.value == "45000.50"
        assert data.updated_at == 1744545600

    def test_parses_response_with_snake_case(self):
        data = MemoryGetData(key="lastPrice", value="45000.50", updated_at=1744545600)
        assert data.updated_at == 1744545600

    def test_rejects_response_without_updated_at(self):
        with pytest.raises(ValueError):
            MemoryGetData(key="lastPrice", value="45000.50")  # type: ignore[call-arg]


class TestMemoryListItem:
    def test_parses_with_camel_case_alias(self):
        """API returns updatedAt (camelCase), SDK exposes as updated_at."""
        item = MemoryListItem(key="alpha", updatedAt=1744545600)
        assert item.key == "alpha"
        assert item.updated_at == 1744545600

    def test_parses_with_snake_case(self):
        item = MemoryListItem(key="alpha", updated_at=1744545600)
        assert item.updated_at == 1744545600

    def test_rejects_item_without_updated_at(self):
        with pytest.raises(ValueError):
            MemoryListItem(key="alpha")  # type: ignore[call-arg]


class TestMemoryListData:
    def test_parses_with_items(self):
        data = MemoryListData(
            items=[
                MemoryListItem(key="a", updated_at=1744545600),
                MemoryListItem(key="ab", updated_at=1744545700),
            ],
        )
        assert len(data.items) == 2
        assert data.items[0].key == "a"

    def test_parses_with_empty_items(self):
        data = MemoryListData(items=[])
        assert data.items == []

    def test_parses_nested_dicts_via_alias(self):
        """End-to-end shape as the SDK would receive it from the API."""
        data = MemoryListData(**{"items": [{"key": "x", "updatedAt": 1}]})
        assert data.items[0].key == "x"
        assert data.items[0].updated_at == 1


class TestMemoryListResponse:
    def test_wraps_successful_list_data(self):
        response = MemoryListResponse(
            success=True,
            data=MemoryListData(items=[MemoryListItem(key="k", updated_at=1)]),
            error=None,
        )
        assert response.success is True
        assert response.data is not None
        assert response.data.items[0].key == "k"

    def test_wraps_error_response(self):
        response = MemoryListResponse(
            success=False,
            data=None,
            error="something broke",
        )
        assert response.success is False
        assert response.data is None
        assert response.error == "something broke"
