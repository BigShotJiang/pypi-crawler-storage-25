"""Smoke tests for the LocalCallClient UDS RPC client.

A fake server bound to a tempdir Unix socket validates the wire
protocol (NDJSON request → NDJSON response, id correlation, error
mapping, lock serialization).
"""

from __future__ import annotations

import json
import shutil
import socket
import tempfile
import threading
from collections.abc import Iterator
from pathlib import Path

import pytest

from agent_sdk.local_call import LocalCallClient, LocalCallError
from agent_sdk.primitives import LocalModeUnsupported


class _FakeRpcServer:
    """Minimal NDJSON UDS server. Reads one request line, writes one
    response line per `responses` entry. Closes when exhausted."""

    def __init__(self, socket_path: Path, responses: list[dict]) -> None:
        self.socket_path = socket_path
        self.responses = responses
        self.received: list[dict] = []
        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._sock.bind(str(socket_path))
        self._sock.listen(1)
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        conn, _ = self._sock.accept()
        try:
            with conn.makefile("rwb", buffering=0) as f:
                for response in self.responses:
                    line = f.readline()
                    if not line:
                        return
                    self.received.append(json.loads(line))
                    f.write((json.dumps(response) + "\n").encode("utf-8"))
        finally:
            conn.close()

    def stop(self) -> None:
        self._sock.close()
        self._thread.join(timeout=1)


@pytest.fixture
def socket_path() -> Iterator[Path]:
    """Sockets need short paths (macOS AF_UNIX caps at ~104 chars), so we
    bypass pytest's deeply-nested tmp_path and use /tmp directly."""
    tmpdir = tempfile.mkdtemp(prefix="circ-rpc-", dir="/tmp")
    try:
        yield Path(tmpdir) / "t.sock"
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def test_call_round_trips_ndjson(socket_path: Path) -> None:
    server = _FakeRpcServer(socket_path, [{"id": 1, "result": {"ok": True}}])
    try:
        client = LocalCallClient(str(socket_path))
        result = client.call("memory.get", {"key": "alpha"})
        assert result == {"ok": True}
        assert server.received[0] == {
            "id": 1,
            "method": "memory.get",
            "params": {"key": "alpha"},
        }
        client.close()
    finally:
        server.stop()


def test_call_maps_local_mode_unsupported(socket_path: Path) -> None:
    server = _FakeRpcServer(
        socket_path,
        [
            {
                "id": 1,
                "error": {
                    "message": "not supported in local",
                    "code": "LOCAL_MODE_UNSUPPORTED",
                },
            }
        ],
    )
    try:
        client = LocalCallClient(str(socket_path))
        with pytest.raises(LocalModeUnsupported):
            client.call("hostedApi.something", {})
        client.close()
    finally:
        server.stop()


def test_call_maps_generic_error(socket_path: Path) -> None:
    server = _FakeRpcServer(
        socket_path,
        [{"id": 1, "error": {"message": "boom", "code": "RUNTIME_ERROR"}}],
    )
    try:
        client = LocalCallClient(str(socket_path))
        with pytest.raises(LocalCallError) as exc_info:
            client.call("memory.get", {"key": "alpha"})
        assert exc_info.value.code == "RUNTIME_ERROR"
        assert "boom" in str(exc_info.value)
        client.close()
    finally:
        server.stop()


def test_connect_failure_raises_actionable_error() -> None:
    tmpdir = tempfile.mkdtemp(prefix="circ-rpc-", dir="/tmp")
    try:
        missing = str(Path(tmpdir) / "missing.sock")
        with pytest.raises(LocalCallError) as exc_info:
            LocalCallClient(missing)
        assert exc_info.value.code == "RPC_CONNECT_FAILED"
        assert "circuit dev run" in str(exc_info.value)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def test_disconnect_mid_call_raises(socket_path: Path) -> None:
    """Server closes without responding — client should surface RPC_DISCONNECT."""
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind(str(socket_path))
    sock.listen(1)

    def accept_then_close() -> None:
        conn, _ = sock.accept()
        conn.close()

    thread = threading.Thread(target=accept_then_close, daemon=True)
    thread.start()
    try:
        client = LocalCallClient(str(socket_path))
        with pytest.raises(LocalCallError) as exc_info:
            client.call("memory.get", None)
        assert exc_info.value.code == "RPC_DISCONNECT"
        client.close()
    finally:
        sock.close()
        thread.join(timeout=1)


def test_request_ids_increment(socket_path: Path) -> None:
    server = _FakeRpcServer(
        socket_path,
        [
            {"id": 1, "result": "first"},
            {"id": 2, "result": "second"},
        ],
    )
    try:
        client = LocalCallClient(str(socket_path))
        assert client.call("a.b", None) == "first"
        assert client.call("c.d", None) == "second"
        assert [msg["id"] for msg in server.received] == [1, 2]
        client.close()
    finally:
        server.stop()
