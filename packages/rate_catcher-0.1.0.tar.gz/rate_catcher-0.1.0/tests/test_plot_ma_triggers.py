from rate_catcher import (
    generate_dummy_data,
    metric_func,
    get_ma_triggers,
    plot_ma_triggers
)


if __name__ == '__main__':
    print("Generating dummy data...")
    df = generate_dummy_data(n_minutes=500)
    print(f"Data shape: {df.shape}")
    print()
    print("Running get_ma_triggers...")
    output = get_ma_triggers(
        main_signal_name='sig_1',
        data=df,
        ma_value=20,
        metric_function=metric_func,
        ma_buckets_number=10,
        slope_buckets_number=20
    )
    ma_df, slope_labels, ma_labels, triggers, ma_buckets, slope_buckets = output
    print(f"MA DataFrame shape: {ma_df.shape}")
    print(f"Number of slope buckets: {len(slope_labels)}")
    print(f"Number of MA buckets: {len(ma_labels)}")
    print(f"Number of populated triggers: {len(triggers)}")
    print()
    print("Creating plot...")
    plot_ma_triggers('sig_1', df, ma_df, slope_labels, ma_labels, triggers)
