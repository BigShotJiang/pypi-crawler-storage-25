import pandas as pd
from rate_catcher import (
    generate_dummy_data,
    metric_func,
    plot_signals_and_metric
)


if __name__ == '__main__':
    df = generate_dummy_data()
    timestamps = df['timestamp'].unique()
    memory = {}
    metric_values = []
    for ts in timestamps:
        metric_val = metric_func(ts, df, memory)
        metric_values.append({'timestamp': ts, 'metric': metric_val})
    metric_df = pd.DataFrame(metric_values)
    plot_signals_and_metric(df, metric_df)
