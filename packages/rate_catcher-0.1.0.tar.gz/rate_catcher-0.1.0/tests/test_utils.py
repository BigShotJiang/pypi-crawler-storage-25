import pandas as pd
import numpy as np
from rate_catcher import (
    apply_moving_average,
    calculate_slope_degrees,
    find_bucket_index,
    create_bucket_labels
)


if __name__ == '__main__':
    print("Testing apply_moving_average...")
    series = pd.Series([10, 20, 30, 40, 50])
    ma_result = apply_moving_average(series, 3)
    print(f"Input: {series.values}")
    print(f"MA(3): {ma_result.values}")
    print()
    print("Testing calculate_slope_degrees...")
    angle1 = calculate_slope_degrees(100, 110)
    angle2 = calculate_slope_degrees(100, 90)
    angle3 = calculate_slope_degrees(100, 100)
    print(f"MA 100->110: {angle1:.2f} degrees")
    print(f"MA 100->90: {angle2:.2f} degrees")
    print(f"MA 100->100: {angle3:.2f} degrees")
    print()
    print("Testing find_bucket_index...")
    buckets = [(0, 10), (10, 20), (20, 30), (30, 40)]
    print(f"Buckets: {buckets}")
    print(f"Value 5 -> bucket {find_bucket_index(5, buckets)}")
    print(f"Value 15 -> bucket {find_bucket_index(15, buckets)}")
    print(f"Value 40 -> bucket {find_bucket_index(40, buckets)}")
    print()
    print("Testing create_bucket_labels...")
    labels = create_bucket_labels(buckets)
    print(f"Labels: {labels}")
    print()
    print("Testing with slope buckets (-90 to 90)...")
    slope_edges = np.linspace(-90, 90, 21)
    slope_buckets = [
        (slope_edges[i], slope_edges[i+1])
        for i in range(20)
    ]
    slope_labels = create_bucket_labels(slope_buckets)
    print(f"20 slope buckets from -90 to 90:")
    for i, label in enumerate(slope_labels):
        print(f"  Bucket {i}: {label}")
