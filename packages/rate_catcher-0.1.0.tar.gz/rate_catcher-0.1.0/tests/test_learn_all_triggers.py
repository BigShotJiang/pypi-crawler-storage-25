from rate_catcher import generate_dummy_data, metric_func, learn_all_triggers


if __name__ == '__main__':
    print("Generating dummy data...")
    df = generate_dummy_data(n_minutes=500)
    print(f"Data shape: {df.shape}")
    print()
    print("Testing learn_all_triggers with small MA list...")
    ma_list = [5, 10, 15, 20, 25, 30]
    result = learn_all_triggers(
        main_signal_name='sig_1',
        data=df,
        metric_function=metric_func,
        ma_values=ma_list,
        ma_buckets_number=10,
        slope_buckets_number=20
    )
    print()
    print(f"Results collected for {len(result)} MA values")
    print()
    for ma_value in sorted(result.keys()):
        ma_df, slope_labels, ma_labels, triggers, ma_buckets, slope_buckets = result[ma_value]
        print(f"MA={ma_value}:")
        print(f"  - MA DataFrame rows: {len(ma_df)}")
        print(f"  - Slope buckets: {len(slope_labels)}")
        print(f"  - MA buckets: {len(ma_labels)}")
        print(f"  - Populated trigger combinations: {len(triggers)}")
        total_occurrences = sum(len(v) for v in triggers.values())
        print(f"  - Total trigger occurrences: {total_occurrences}")
        print()
    print("\nTesting with default MA range (1-100) on smaller dataset...")
    df_small = generate_dummy_data(n_minutes=200)
    result_full = learn_all_triggers(
        main_signal_name='sig_1',
        data=df_small,
        metric_function=metric_func,
        ma_buckets_number=5,
        slope_buckets_number=10
    )
    print()
    print(f"Results for {len(result_full)} MA values collected")
    print(f"MA values with results: {sorted(result_full.keys())[:20]}...")
