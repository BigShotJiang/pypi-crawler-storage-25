import pandas as pd
from rate_catcher import generate_dummy_data, metric_func, get_ma_triggers


if __name__ == '__main__':
    print("Generating dummy data...")
    df = generate_dummy_data(n_minutes=500)
    print(f"Data shape: {df.shape}")
    print()
    print("Testing get_ma_triggers with sig_1...")
    output = get_ma_triggers(
        main_signal_name='sig_1',
        data=df,
        ma_value=10,
        metric_function=metric_func,
        ma_buckets_number=5,
        slope_buckets_number=10
    )
    ma_df, slope_labels, ma_labels, triggers, ma_buckets, slope_buckets = output
    print(f"MA DataFrame shape: {ma_df.shape}")
    print(f"First 5 rows of MA DataFrame:")
    print(ma_df.head())
    print()
    print(f"Number of slope buckets: {len(slope_labels)}")
    print(f"Slope labels: {slope_labels}")
    print()
    print(f"Number of MA buckets: {len(ma_labels)}")
    print(f"MA labels: {ma_labels}")
    print()
    print(f"Number of populated trigger combinations: {len(triggers)}")
    print()
    print("Sample triggers (first 5 combinations):")
    for idx, (key, values) in enumerate(list(triggers.items())[:5]):
        slope_label, ma_label = key
        print(f"  {idx+1}. Slope: {slope_label}, MA: {ma_label}")
        print(f"     Count: {len(values)} occurrences")
        print(f"     First occurrence: {values[0]}")
        print()
    print("Testing with different parameters...")
    output2 = get_ma_triggers(
        main_signal_name='sig_1',
        data=df,
        ma_value=30,
        metric_function=metric_func,
        ma_buckets_number=10,
        slope_buckets_number=20
    )
    ma_df2, slope_labels2, ma_labels2, triggers2, _, _ = output2
    print(f"MA=30: DataFrame shape: {ma_df2.shape}")
    print(f"MA=30: Populated triggers: {len(triggers2)}")
    print(f"MA=30: Slope buckets: {len(slope_labels2)}")
    print(f"MA=30: MA buckets: {len(ma_labels2)}")
