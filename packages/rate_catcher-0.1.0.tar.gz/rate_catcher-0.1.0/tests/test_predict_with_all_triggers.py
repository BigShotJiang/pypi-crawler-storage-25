from rate_catcher import (
    generate_dummy_data,
    metric_func,
    learn_all_triggers,
    predict_with_all_triggers,
    plot_predictions
)


if __name__ == '__main__':
    print("Generating dummy data...")
    df = generate_dummy_data(n_minutes=1000)
    print(f"Total data shape: {df.shape}")
    print()
    timestamps = sorted(df['timestamp'].unique())
    split_idx = len(timestamps) // 2
    split_timestamp = timestamps[split_idx]
    learning_data = df[df['timestamp'] < split_timestamp].copy()
    prediction_data = df[df['timestamp'] >= split_timestamp].copy()
    print(f"Learning data: {len(learning_data)} rows")
    print(f"Prediction data: {len(prediction_data)} rows")
    print(f"Split at timestamp: {split_timestamp}")
    print()
    print("Learning triggers from first half...")
    ma_list = list(range(5, 51, 5))
    all_triggers = learn_all_triggers(
        main_signal_name='sig_1',
        data=learning_data,
        metric_function=metric_func,
        ma_values=ma_list,
        ma_buckets_number=10,
        slope_buckets_number=20
    )
    print()
    print(f"Learned triggers for {len(all_triggers)} MA values")
    print()
    print("Predicting on second half...")
    predictions_df = predict_with_all_triggers(
        main_signal_name='sig_1',
        data=prediction_data,
        all_triggers=all_triggers,
        minimum_count=3,
        minimum_rate=0.5
    )
    print()
    print(f"Predictions shape: {predictions_df.shape}")
    print(f"First 10 predictions:")
    print(predictions_df.head(10))
    print()
    print(f"Max activated triggers: {predictions_df['num_activated'].max()}")
    print(f"Mean activated triggers: {predictions_df['num_activated'].mean():.2f}")
    print(f"Timestamps with >0 activations: {(predictions_df['num_activated'] > 0).sum()}")
    print()
    print("Creating plot...")
    plot_predictions('sig_1', prediction_data, predictions_df)
