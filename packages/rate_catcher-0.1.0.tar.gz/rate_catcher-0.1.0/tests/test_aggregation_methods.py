import numpy as np
from rate_catcher import (
    generate_dummy_data,
    metric_func,
    aggregation_func,
    learn_all_triggers,
    predict_with_all_triggers
)


def custom_median_aggregation(values):
    return np.median(values)


def custom_percentile_75(values):
    return np.percentile(values, 75)


if __name__ == '__main__':
    print("Generating dummy data...")
    df = generate_dummy_data(n_minutes=1000)
    timestamps = sorted(df['timestamp'].unique())
    split_idx = len(timestamps) // 2
    split_timestamp = timestamps[split_idx]
    learning_data = df[df['timestamp'] < split_timestamp].copy()
    prediction_data = df[df['timestamp'] >= split_timestamp].copy()
    print(f"Learning data: {len(learning_data)} rows")
    print(f"Prediction data: {len(prediction_data)} rows")
    print()
    print("Learning triggers once...")
    ma_list = list(range(5, 51, 5))
    all_triggers = learn_all_triggers(
        main_signal_name='sig_1',
        data=learning_data,
        metric_function=metric_func,
        ma_values=ma_list,
        ma_buckets_number=10,
        slope_buckets_number=20
    )
    print()
    print("=" * 60)
    print("Testing different aggregation methods")
    print("=" * 60)
    print()
    print("1. Testing 'mean' (default)...")
    pred_mean = predict_with_all_triggers(
        main_signal_name='sig_1',
        data=prediction_data,
        all_triggers=all_triggers,
        minimum_count=3,
        minimum_rate=0.5,
        aggregation_method="mean"
    )
    print(f"   Activated timestamps: {(pred_mean['num_activated'] > 0).sum()}")
    print(f"   Max activations: {pred_mean['num_activated'].max()}")
    print(f"   Mean activations: {pred_mean['num_activated'].mean():.2f}")
    print()
    print("2. Testing 'max'...")
    pred_max = predict_with_all_triggers(
        main_signal_name='sig_1',
        data=prediction_data,
        all_triggers=all_triggers,
        minimum_count=3,
        minimum_rate=0.5,
        aggregation_method="max"
    )
    print(f"   Activated timestamps: {(pred_max['num_activated'] > 0).sum()}")
    print(f"   Max activations: {pred_max['num_activated'].max()}")
    print(f"   Mean activations: {pred_max['num_activated'].mean():.2f}")
    print()
    print("3. Testing 'min'...")
    pred_min = predict_with_all_triggers(
        main_signal_name='sig_1',
        data=prediction_data,
        all_triggers=all_triggers,
        minimum_count=3,
        minimum_rate=0.5,
        aggregation_method="min"
    )
    print(f"   Activated timestamps: {(pred_min['num_activated'] > 0).sum()}")
    print(f"   Max activations: {pred_min['num_activated'].max()}")
    print(f"   Mean activations: {pred_min['num_activated'].mean():.2f}")
    print()
    print("4. Testing custom function (median)...")
    pred_median = predict_with_all_triggers(
        main_signal_name='sig_1',
        data=prediction_data,
        all_triggers=all_triggers,
        minimum_count=3,
        minimum_rate=0.5,
        aggregation_method=custom_median_aggregation
    )
    print(f"   Activated timestamps: {(pred_median['num_activated'] > 0).sum()}")
    print(f"   Max activations: {pred_median['num_activated'].max()}")
    print(f"   Mean activations: {pred_median['num_activated'].mean():.2f}")
    print()
    print("5. Testing custom function (75th percentile)...")
    pred_p75 = predict_with_all_triggers(
        main_signal_name='sig_1',
        data=prediction_data,
        all_triggers=all_triggers,
        minimum_count=3,
        minimum_rate=0.5,
        aggregation_method=custom_percentile_75
    )
    print(f"   Activated timestamps: {(pred_p75['num_activated'] > 0).sum()}")
    print(f"   Max activations: {pred_p75['num_activated'].max()}")
    print(f"   Mean activations: {pred_p75['num_activated'].mean():.2f}")
    print()
    print("6. Testing default aggregation_func...")
    pred_func = predict_with_all_triggers(
        main_signal_name='sig_1',
        data=prediction_data,
        all_triggers=all_triggers,
        minimum_count=3,
        minimum_rate=0.5,
        aggregation_method=aggregation_func
    )
    print(f"   Activated timestamps: {(pred_func['num_activated'] > 0).sum()}")
    print(f"   Max activations: {pred_func['num_activated'].max()}")
    print(f"   Mean activations: {pred_func['num_activated'].mean():.2f}")
    print()
    print("7. Testing invalid string (should raise error)...")
    try:
        pred_invalid = predict_with_all_triggers(
            main_signal_name='sig_1',
            data=prediction_data,
            all_triggers=all_triggers,
            minimum_count=3,
            minimum_rate=0.5,
            aggregation_method="invalid_method"
        )
        print("   ERROR: Should have raised ValueError!")
    except ValueError as e:
        print(f"   ✓ Correctly raised ValueError: {e}")
    print()
    print("=" * 60)
    print("Summary Comparison:")
    print("=" * 60)
    print(f"{'Method':<20} {'Activated':<12} {'Max':<8} {'Mean':<8}")
    print("-" * 60)
    print(f"{'mean':<20} {(pred_mean['num_activated'] > 0).sum():<12} "
          f"{pred_mean['num_activated'].max():<8} "
          f"{pred_mean['num_activated'].mean():<8.2f}")
    print(f"{'max':<20} {(pred_max['num_activated'] > 0).sum():<12} "
          f"{pred_max['num_activated'].max():<8} "
          f"{pred_max['num_activated'].mean():<8.2f}")
    print(f"{'min':<20} {(pred_min['num_activated'] > 0).sum():<12} "
          f"{pred_min['num_activated'].max():<8} "
          f"{pred_min['num_activated'].mean():<8.2f}")
    print(f"{'median':<20} {(pred_median['num_activated'] > 0).sum():<12} "
          f"{pred_median['num_activated'].max():<8} "
          f"{pred_median['num_activated'].mean():<8.2f}")
    print(f"{'75th percentile':<20} {(pred_p75['num_activated'] > 0).sum():<12} "
          f"{pred_p75['num_activated'].max():<8} "
          f"{pred_p75['num_activated'].mean():<8.2f}")
    print(f"{'aggregation_func':<20} {(pred_func['num_activated'] > 0).sum():<12} "
          f"{pred_func['num_activated'].max():<8} "
          f"{pred_func['num_activated'].mean():<8.2f}")
