import pandas as pd
import numpy as np
from tqdm import tqdm
from .utils import (
    apply_moving_average,
    calculate_slope_degrees,
    find_bucket_index,
    create_bucket_labels
)


def metric_func(timestamp, data, memory):
    if 'max' not in memory:
        sig_2_data = data[data['signal_name'] == 'sig_2']
        memory['max'] = sig_2_data['count'].max()
    max_val = memory['max']
    sig_2_data = data[data['signal_name'] == 'sig_2']
    sig_2_data = sig_2_data.sort_values('timestamp')
    next_5_minutes = sig_2_data[
        (sig_2_data['timestamp'] > timestamp) &
        (sig_2_data['timestamp'] <= timestamp + pd.Timedelta(minutes=5))
    ]
    if len(next_5_minutes) == 0:
        return 0.0
    max_next_5 = next_5_minutes['count'].max()
    return float(max_next_5 / max_val)


def aggregation_func(values):
    return np.mean(values)


def get_ma_triggers(
    main_signal_name,
    data,
    ma_value,
    metric_function,
    ma_buckets_number=10,
    slope_buckets_number=20
):
    signal_data = data[data['signal_name'] == main_signal_name].copy()
    signal_data = signal_data.groupby('timestamp')['count'].sum().reset_index()
    signal_data = signal_data.sort_values('timestamp').reset_index(drop=True)
    signal_data['ma'] = apply_moving_average(signal_data['count'], ma_value)
    ma_df = signal_data[['timestamp', 'ma']].iloc[ma_value:].reset_index(
        drop=True
    )
    if len(ma_df) == 0:
        return ma_df, [], [], {}
    ma_values = ma_df['ma'].values
    min_ma = np.min(ma_values)
    max_ma = np.max(ma_values)
    if max_ma == min_ma:
        return ma_df, [], [], {}
    ma_edges = np.linspace(min_ma, max_ma, ma_buckets_number + 1)
    ma_buckets = [(ma_edges[i], ma_edges[i+1]) for i in range(ma_buckets_number)]
    ma_labels = create_bucket_labels(ma_buckets)
    slope_edges = np.linspace(-90, 90, slope_buckets_number + 1)
    slope_buckets = [
        (slope_edges[i], slope_edges[i+1])
        for i in range(slope_buckets_number)
    ]
    slope_labels = create_bucket_labels(slope_buckets)
    triggers = {}
    memory = {}
    for i in range(len(ma_df) - 1):
        current_row = ma_df.iloc[i]
        next_row = ma_df.iloc[i + 1]
        timestamp = current_row['timestamp']
        ma_current = current_row['ma']
        ma_next = next_row['ma']
        angle_deg = calculate_slope_degrees(ma_current, ma_next)
        if angle_deg is None or angle_deg < -90 or angle_deg > 90:
            continue
        ma_bucket_idx = find_bucket_index(ma_current, ma_buckets)
        slope_bucket_idx = find_bucket_index(angle_deg, slope_buckets)
        if ma_bucket_idx is None or slope_bucket_idx is None:
            continue
        ma_label = ma_labels[ma_bucket_idx]
        slope_label = slope_labels[slope_bucket_idx]
        metric_value = metric_function(timestamp, data, memory)
        key = (slope_label, ma_label)
        if key not in triggers:
            triggers[key] = []
        triggers[key].append((timestamp, metric_value))
    return ma_df, slope_labels, ma_labels, triggers, ma_buckets, slope_buckets


def learn_all_triggers(
    main_signal_name,
    data,
    metric_function,
    ma_values=None,
    ma_buckets_number=10,
    slope_buckets_number=20
):
    if ma_values is None:
        ma_values = list(range(1, 101))
    result = {}
    for ma_value in tqdm(ma_values, desc="Learning triggers"):
        output = get_ma_triggers(
            main_signal_name,
            data,
            ma_value,
            metric_function,
            ma_buckets_number,
            slope_buckets_number
        )
        ma_df, slope_labels, ma_labels, triggers, ma_buckets, slope_buckets = output
        if len(ma_df) == 0 or len(triggers) == 0:
            continue
        result[ma_value] = output
    print(f"Completed! Collected results for {len(result)} MA values.")
    return result


def predict_with_all_triggers(
    main_signal_name,
    data,
    all_triggers,
    minimum_count=0,
    minimum_rate=0.5,
    aggregation_method="mean"
):
    if isinstance(aggregation_method, str):
        valid_methods = ["mean", "max", "min"]
        if aggregation_method not in valid_methods:
            raise ValueError(
                f"Invalid aggregation_method: {aggregation_method}. "
                f"Must be one of {valid_methods} or a callable function."
            )
    signal_data = data[data['signal_name'] == main_signal_name].copy()
    signal_data = signal_data.groupby('timestamp')['count'].sum().reset_index()
    signal_data = signal_data.sort_values('timestamp').reset_index(drop=True)
    all_timestamps = signal_data['timestamp'].unique()
    timestamp_activated = {ts: 0 for ts in all_timestamps}
    for ma_value in tqdm(all_triggers.keys(), desc="Predicting"):
        result_tuple = all_triggers[ma_value]
        _, slope_labels, ma_labels, triggers, ma_buckets, slope_buckets = result_tuple
        signal_data['ma'] = apply_moving_average(signal_data['count'], ma_value)
        ma_df = signal_data[['timestamp', 'ma']].iloc[ma_value:].reset_index(
            drop=True
        )
        if len(ma_df) < 2:
            continue
        for i in range(len(ma_df) - 1):
            current_row = ma_df.iloc[i]
            next_row = ma_df.iloc[i + 1]
            timestamp = current_row['timestamp']
            ma_current = current_row['ma']
            ma_next = next_row['ma']
            angle_deg = calculate_slope_degrees(ma_current, ma_next)
            if angle_deg is None or angle_deg < -90 or angle_deg > 90:
                continue
            ma_bucket_idx = find_bucket_index(ma_current, ma_buckets)
            slope_bucket_idx = find_bucket_index(angle_deg, slope_buckets)
            if ma_bucket_idx is None or slope_bucket_idx is None:
                continue
            ma_label = ma_labels[ma_bucket_idx]
            slope_label = slope_labels[slope_bucket_idx]
            key = (slope_label, ma_label)
            if key not in triggers:
                continue
            trigger_values = triggers[key]
            count = len(trigger_values)
            if count < minimum_count:
                continue
            metric_values = [v[1] for v in trigger_values]
            if len(metric_values) == 0:
                continue
            if isinstance(aggregation_method, str):
                if aggregation_method == "mean":
                    agg_value = np.mean(metric_values)
                elif aggregation_method == "max":
                    agg_value = np.max(metric_values)
                elif aggregation_method == "min":
                    agg_value = np.min(metric_values)
            else:
                agg_value = aggregation_method(metric_values)
            if agg_value < minimum_rate:
                continue
            timestamp_activated[timestamp] += 1
    result_df = pd.DataFrame([
        {'timestamp': ts, 'num_activated': count}
        for ts, count in timestamp_activated.items()
    ])
    result_df = result_df.sort_values('timestamp').reset_index(drop=True)
    return result_df


def predict(
    main_signal_name,
    learning_data,
    prediction_data,
    metric_function,
    ma_values=None,
    ma_buckets_number=10,
    slope_buckets_number=20,
    minimum_count=0,
    minimum_rate=0.5,
    aggregation_method="mean"
):
    all_triggers = learn_all_triggers(
        main_signal_name,
        learning_data,
        metric_function,
        ma_values,
        ma_buckets_number,
        slope_buckets_number
    )
    predictions_df = predict_with_all_triggers(
        main_signal_name,
        prediction_data,
        all_triggers,
        minimum_count,
        minimum_rate,
        aggregation_method
    )
    return predictions_df

