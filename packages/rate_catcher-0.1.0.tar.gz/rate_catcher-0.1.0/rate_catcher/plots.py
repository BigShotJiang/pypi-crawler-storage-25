import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np


def plot_signals_and_metric(df, metric_df):
    sig_1_data = df[df['signal_name'] == 'sig_1']
    sig_2_data = df[df['signal_name'] == 'sig_2']
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=('Signals', 'Metric Values'),
        vertical_spacing=0.15
    )
    fig.add_trace(
        go.Scatter(
            x=sig_1_data['timestamp'],
            y=sig_1_data['count'],
            mode='lines',
            name='sig_1',
            line=dict(color='blue')
        ),
        row=1, col=1
    )
    fig.add_trace(
        go.Scatter(
            x=sig_2_data['timestamp'],
            y=sig_2_data['count'],
            mode='lines',
            name='sig_2',
            line=dict(color='red')
        ),
        row=1, col=1
    )
    fig.add_trace(
        go.Scatter(
            x=metric_df['timestamp'],
            y=metric_df['metric'],
            mode='lines',
            name='metric',
            line=dict(color='green')
        ),
        row=2, col=1
    )
    fig.update_xaxes(title_text='Timestamp', row=1, col=1)
    fig.update_xaxes(title_text='Timestamp', row=2, col=1)
    fig.update_yaxes(title_text='Count', row=1, col=1)
    fig.update_yaxes(title_text='Metric Value', row=2, col=1)
    fig.update_layout(height=800, hovermode='x unified')
    fig.show()


def plot_ma_triggers(
    signal_name, data, ma_df, slope_labels, ma_labels, triggers
):
    signal_data = data[data['signal_name'] == signal_name].copy()
    signal_data = signal_data.groupby('timestamp')['count'].sum().reset_index()
    signal_data = signal_data.sort_values('timestamp')
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=(
            f'{signal_name} with Moving Average',
            'Heatmap: Slope vs MA Buckets (Avg Metric Values)'
        ),
        vertical_spacing=0.15,
        specs=[[{"type": "scatter"}], [{"type": "heatmap"}]]
    )
    fig.add_trace(
        go.Scatter(
            x=signal_data['timestamp'],
            y=signal_data['count'],
            mode='lines',
            name=signal_name,
            line=dict(color='blue')
        ),
        row=1, col=1
    )
    fig.add_trace(
        go.Scatter(
            x=ma_df['timestamp'],
            y=ma_df['ma'],
            mode='lines',
            name='MA',
            line=dict(color='red', dash='dash')
        ),
        row=1, col=1
    )
    n_slope = len(slope_labels)
    n_ma = len(ma_labels)
    heatmap_matrix = np.full((n_slope, n_ma), np.nan)
    for (slope_label, ma_label), values in triggers.items():
        if slope_label not in slope_labels or ma_label not in ma_labels:
            continue
        slope_idx = slope_labels.index(slope_label)
        ma_idx = ma_labels.index(ma_label)
        metric_values = [v[1] for v in values]
        avg_metric = np.mean(metric_values)
        heatmap_matrix[slope_idx, ma_idx] = avg_metric
    fig.add_trace(
        go.Heatmap(
            z=heatmap_matrix,
            x=ma_labels,
            y=slope_labels,
            colorscale='Reds',
            showscale=True,
            hovertemplate='MA: %{x}<br>Slope: %{y}<br>Avg Metric: %{z:.3f}<extra></extra>'
        ),
        row=2, col=1
    )
    fig.update_xaxes(title_text='Timestamp', row=1, col=1)
    fig.update_xaxes(title_text='MA Bucket', row=2, col=1)
    fig.update_yaxes(title_text='Count', row=1, col=1)
    fig.update_yaxes(title_text='Slope Bucket (degrees)', row=2, col=1)
    fig.update_layout(height=900, hovermode='x unified')
    fig.show()


def plot_predictions(signal_name, data, predictions_df):
    signal_data = data[data['signal_name'] == signal_name].copy()
    signal_data = signal_data.groupby('timestamp')['count'].sum().reset_index()
    signal_data = signal_data.sort_values('timestamp')
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=predictions_df['timestamp'],
        y=predictions_df['num_activated'],
        name='Activated Triggers',
        marker=dict(color='orange'),
        yaxis='y2'
    ))
    fig.add_trace(go.Scatter(
        x=signal_data['timestamp'],
        y=signal_data['count'],
        mode='lines',
        name=signal_name,
        line=dict(color='blue'),
        yaxis='y'
    ))
    fig.update_layout(
        title=f'{signal_name} with Prediction Triggers',
        xaxis=dict(title='Timestamp'),
        yaxis=dict(
            title='Count',
            side='left'
        ),
        yaxis2=dict(
            title='Activated Triggers',
            overlaying='y',
            side='right'
        ),
        hovermode='x unified',
        height=600
    )
    fig.show()
