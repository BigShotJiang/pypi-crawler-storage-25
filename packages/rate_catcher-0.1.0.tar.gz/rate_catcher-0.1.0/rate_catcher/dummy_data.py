import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go


def generate_dummy_data(n_minutes=1440, start_time=None):
    if start_time is None:
        start_time = datetime(2024, 1, 1, 0, 0, 0)
    timestamps = [start_time + timedelta(minutes=i) for i in range(n_minutes)]
    period = n_minutes / 6
    t = np.arange(n_minutes)
    sig_1_base = 275 + 75 * np.sin(2 * np.pi * t / period)
    sig_1_noise = np.random.uniform(-20, 20, n_minutes)
    sig_1_values = sig_1_base + sig_1_noise
    sig_2_values = []
    for sig_1_val in sig_1_values:
        baseline = np.random.uniform(10, 20)
        if sig_1_val > 350:
            sig_2_values.append(baseline + 150)
        else:
            sig_2_values.append(baseline)
    data = []
    for i in range(n_minutes):
        data.append({
            'timestamp': timestamps[i],
            'signal_name': 'sig_1',
            'count': int(sig_1_values[i])
        })
        data.append({
            'timestamp': timestamps[i],
            'signal_name': 'sig_2',
            'count': int(sig_2_values[i])
        })
    df = pd.DataFrame(data)
    df = df.sort_values(['timestamp', 'signal_name']).reset_index(drop=True)
    return df


if __name__ == '__main__':
    df = generate_dummy_data()
    print("First 20 rows of generated data:")
    print(df.head(20))
    print()
    sig_1_data = df[df['signal_name'] == 'sig_1']
    sig_2_data = df[df['signal_name'] == 'sig_2']
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=sig_1_data['timestamp'],
        y=sig_1_data['count'],
        mode='lines',
        name='sig_1',
        line=dict(color='blue')
    ))
    fig.add_trace(go.Scatter(
        x=sig_2_data['timestamp'],
        y=sig_2_data['count'],
        mode='lines',
        name='sig_2',
        line=dict(color='red')
    ))
    fig.update_layout(
        title='Dummy Signals',
        xaxis_title='Timestamp',
        yaxis_title='Count',
        hovermode='x unified'
    )
    fig.show()
