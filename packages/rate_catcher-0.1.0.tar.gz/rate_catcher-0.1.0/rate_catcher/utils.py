import pandas as pd
import numpy as np


def apply_moving_average(series, window):
    if window <= 1:
        return series
    return series.rolling(window=window, min_periods=1).mean()


def calculate_slope_degrees(ma_current, ma_next):
    if ma_next is None or np.isnan(ma_next):
        return None
    slope = ma_next - ma_current
    angle_rad = np.arctan(slope)
    angle_deg = np.degrees(angle_rad)
    return angle_deg


def find_bucket_index(value, buckets):
    for idx, (bucket_min, bucket_max) in enumerate(buckets):
        if idx == len(buckets) - 1:
            if bucket_min <= value <= bucket_max:
                return idx
        else:
            if bucket_min <= value < bucket_max:
                return idx
    return None


def create_bucket_labels(buckets):
    for precision in range(0, 5):
        labels = [
            f"{bmin:.{precision}f}-{bmax:.{precision}f}"
            for bmin, bmax in buckets
        ]
        if len(labels) == len(set(labels)):
            return labels
    return [f"{bmin:.4f}-{bmax:.4f}" for bmin, bmax in buckets]
