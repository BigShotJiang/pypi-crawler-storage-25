from .core import (
    metric_func,
    aggregation_func,
    get_ma_triggers,
    learn_all_triggers,
    predict_with_all_triggers,
    predict
)
from .utils import (
    apply_moving_average,
    calculate_slope_degrees,
    find_bucket_index,
    create_bucket_labels
)
from .plots import (
    plot_signals_and_metric,
    plot_ma_triggers,
    plot_predictions
)
from .dummy_data import generate_dummy_data


__all__ = [
    'metric_func',
    'aggregation_func',
    'get_ma_triggers',
    'learn_all_triggers',
    'predict_with_all_triggers',
    'predict',
    'apply_moving_average',
    'calculate_slope_degrees',
    'find_bucket_index',
    'create_bucket_labels',
    'plot_signals_and_metric',
    'plot_ma_triggers',
    'plot_predictions',
    'generate_dummy_data'
]
