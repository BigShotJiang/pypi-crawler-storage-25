# RateCatcher Library

A Python library for pattern-based prediction using moving averages and slope analysis.

## Code Conventions

### ⚠️ CRITICAL: Code Formatting Rules (MUST FOLLOW)

**These conventions are MANDATORY for ALL Python files in this project:**

1. **Max 100 characters per line** - Hard limit, no exceptions
2. **NO comments in code** - Code must be self-explanatory
3. **Exactly 2 empty lines between functions/methods** - Always
4. **NO empty lines inside functions/methods** - Keep function bodies compact
5. **Very short, focused functions** - Single responsibility, minimal complexity
6. **All imports at the top** - Never inside functions

**Violation of these conventions is NOT acceptable. Always refactor to comply.**

### Style Guidelines
- **Minimal code** - no unnecessary abstractions
- **Precise and short** - direct implementations
- **Self-explanatory code** - comments only when absolutely necessary
- **No premature optimization** - simple solutions first

## Project Structure

```
rate_catcher/
├── rate_catcher.py    # Core analysis and prediction functions
├── utils.py           # Helper functions (MA, slope, buckets)
├── plots.py           # Visualization functions
├── dummy_data.py      # Example data generator
└── tests/             # Test files
```

## Core Concepts

The library analyzes time-series data by:
1. Computing moving averages (MA) at different window sizes
2. Calculating slopes between consecutive MA values
3. Bucketing MA values and slopes into discrete ranges
4. Identifying patterns (triggers) where certain outcomes occur
5. Using learned triggers to predict future occurrences
