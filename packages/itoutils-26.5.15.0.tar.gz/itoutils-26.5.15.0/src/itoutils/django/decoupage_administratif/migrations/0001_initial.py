import django.contrib.gis.db.models.fields
import django.contrib.postgres.fields
import django.contrib.postgres.indexes
import django.contrib.postgres.operations
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        django.contrib.postgres.operations.TrigramExtension(),
        migrations.CreateModel(
            name="City",
            fields=[
                ("name", models.CharField(max_length=255)),
                (
                    "normalized_name",
                    models.CharField(blank=True, default="", max_length=255),
                ),
                (
                    "code",
                    models.CharField(max_length=5, primary_key=True, serialize=False),
                ),
                ("department", models.CharField(db_index=True, max_length=3)),
                ("epci", models.CharField(db_index=True, max_length=9)),
                ("region", models.CharField(db_index=True, max_length=3)),
                (
                    "postal_codes",
                    django.contrib.postgres.fields.ArrayField(
                        base_field=models.CharField(max_length=5),
                        blank=True,
                        default=list,
                    ),
                ),
                ("population", models.IntegerField(default=0)),
                (
                    "center",
                    django.contrib.gis.db.models.fields.PointField(geography=True, srid=4326),
                ),
            ],
            options={
                "verbose_name": "commune",
                "verbose_name_plural": "communes",
                "indexes": [
                    django.contrib.postgres.indexes.GinIndex(
                        fields=["normalized_name"],
                        name="da_city_name_trgm_idx",
                        opclasses=("gin_trgm_ops",),
                    )
                ],
            },
        ),
        migrations.CreateModel(
            name="Department",
            fields=[
                ("name", models.CharField(max_length=255)),
                (
                    "normalized_name",
                    models.CharField(blank=True, default="", max_length=255),
                ),
                (
                    "code",
                    models.CharField(max_length=3, primary_key=True, serialize=False),
                ),
                ("region", models.CharField(db_index=True, max_length=3)),
            ],
            options={
                "verbose_name": "département",
                "verbose_name_plural": "départements",
                "indexes": [
                    django.contrib.postgres.indexes.GinIndex(
                        fields=["normalized_name"],
                        name="da_dept_name_trgm_idx",
                        opclasses=("gin_trgm_ops",),
                    )
                ],
            },
        ),
        migrations.CreateModel(
            name="EPCI",
            fields=[
                ("name", models.CharField(max_length=255)),
                (
                    "normalized_name",
                    models.CharField(blank=True, default="", max_length=255),
                ),
                (
                    "code",
                    models.CharField(max_length=9, primary_key=True, serialize=False),
                ),
                (
                    "departments",
                    django.contrib.postgres.fields.ArrayField(
                        base_field=models.CharField(max_length=3),
                        blank=True,
                        default=list,
                    ),
                ),
                (
                    "regions",
                    django.contrib.postgres.fields.ArrayField(
                        base_field=models.CharField(max_length=3),
                        blank=True,
                        default=list,
                    ),
                ),
            ],
            options={
                "verbose_name": "EPCI",
                "verbose_name_plural": "EPCI",
                "indexes": [
                    django.contrib.postgres.indexes.GinIndex(
                        fields=["normalized_name"],
                        name="da_epci_name_trgm_idx",
                        opclasses=("gin_trgm_ops",),
                    )
                ],
            },
        ),
        migrations.CreateModel(
            name="Region",
            fields=[
                ("name", models.CharField(max_length=255)),
                (
                    "normalized_name",
                    models.CharField(blank=True, default="", max_length=255),
                ),
                (
                    "code",
                    models.CharField(max_length=3, primary_key=True, serialize=False),
                ),
            ],
            options={
                "verbose_name": "région",
                "verbose_name_plural": "régions",
                "indexes": [
                    django.contrib.postgres.indexes.GinIndex(
                        fields=["normalized_name"],
                        name="da_region_name_trgm_idx",
                        opclasses=("gin_trgm_ops",),
                    )
                ],
            },
        ),
    ]
