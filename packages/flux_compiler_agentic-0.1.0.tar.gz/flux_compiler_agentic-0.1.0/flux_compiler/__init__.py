"""
Flux Compiler — 6-plane abstraction stack with dual-interpreter gradient gates

Each plane compiles to the next, gated by a gradient check.
Only pairs where gradient > 0.35 advance to the next plane.

Plane 5 (Intent):  natural language goal
Plane 4 (Domain):   domain vocabulary
Plane 3 (IR):       structured JSON AST
Plane 2 (Bytecode): FLUX opcodes
Plane 1 (Native):   C / Rust / Zig
Plane 0 (Metal):    assembly
"""

import os
import time
import requests
import json
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

# DeepInfra config
DEEPINFRA_BASE = "https://api.deepinfra.com/v1/openai"
DEEPINFRA_KEY = os.environ.get("DEEPINFRA_API_KEY", "RhZPtvuy4cXzu02LbBSffbXeqs5Yf2IZ")
SILICONFLOW_KEY = os.environ.get("SILICONFLOW_KEY", "")


class AbstractionPlane(Enum):
    """6-plane abstraction stack. Higher number = higher abstraction."""
    METAL = 0       # Assembly / machine code
    NATIVE = 1      # C / Rust / Zig
    BYTECODE = 2     # FLUX opcodes
    IR = 3          # Structured JSON AST
    DOMAIN = 4      # Domain vocabulary
    INTENT = 5      # Natural language goal

    def next_plane(self) -> Optional["AbstractionPlane"]:
        """Get the next higher plane, or None if at top."""
        mappings = {
            AbstractionPlane.METAL: AbstractionPlane.NATIVE,
            AbstractionPlane.NATIVE: AbstractionPlane.BYTECODE,
            AbstractionPlane.BYTECODE: AbstractionPlane.IR,
            AbstractionPlane.IR: AbstractionPlane.DOMAIN,
            AbstractionPlane.DOMAIN: AbstractionPlane.INTENT,
            AbstractionPlane.INTENT: None,
        }
        return mappings[self]

    def plane_name(self) -> str:
        return self.name

    @staticmethod
    def from_number(n: int) -> "AbstractionPlane":
        return AbstractionPlane(n)


@dataclass
class PlanePair:
    """
    Dual-interpreter output pair for a single plane.
    The gradient gate decides whether this pair advances.
    """
    plane: AbstractionPlane
    creative_output: str = ""
    logical_output: str = ""
    gradient: float = 0.0
    advanced: bool = False
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "plane": self.plane.plane_name(),
            "plane_number": self.plane.value,
            "creative_output": self.creative_output,
            "logical_output": self.logical_output,
            "gradient": self.gradient,
            "advanced": self.advanced,
            "error": self.error,
        }


class FluxCompiler:
    """
    6-plane compiler with dual-interpreter gradient gates.

    Compiles from Intent (Plane 5) to Metal (Plane 0).
    Each plane transition requires gradient > 0.35.

    Usage:
        compiler = FluxCompiler()
        result = compiler.compile("implement a thread-safe LRU cache")
        print(result["plane_pairs"])  # one per plane
        print(result["final_output"]) # Metal output if all planes advanced
    """

    PLANE_NAMES = {
        AbstractionPlane.INTENT: "Intent (natural language)",
        AbstractionPlane.DOMAIN: "Domain (vocabulary)",
        AbstractionPlane.IR: "IR (structured JSON)",
        AbstractionPlane.BYTECODE: "Bytecode (FLUX ops)",
        AbstractionPlane.NATIVE: "Native (C/Rust/Zig)",
        AbstractionPlane.METAL: "Metal (assembly)",
    }

    def __init__(self, deepinfra_key: str = DEEPINFRA_KEY, siliconflow_key: str = SILICONFLOW_KEY):
        self.deepinfra_key = deepinfra_key
        self.siliconflow_key = siliconflow_key
        self.headers = {
            "Authorization": f"Bearer {deepinfra_key}",
            "Content-Type": "application/json"
        }

    # -------------------------------------------------------------------------
    # API Calls
    # -------------------------------------------------------------------------

    def _call_deepinfra_seed_mini(self, prompt: str, temperature: float = 0.85) -> str:
        """Call Seed-2.0-mini for creative generation at a plane."""
        payload = {
            "model": "ByteDance/Seed-2.0-mini",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "max_tokens": 600
        }
        response = requests.post(
            f"{DEEPINFRA_BASE}/chat/completions",
            headers=self.headers,
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]

    def _call_deepseek(self, prompt: str) -> str:
        """Call DeepSeek-v4-flash for logical evaluation at a plane."""
        payload = {
            "model": "deepseek-ai/DeepSeek-V3",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.3,
            "max_tokens": 600
        }
        response = requests.post(
            "https://api.siliconflow.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.siliconflow_key}"},
            json=payload,
            timeout=30
        )
        return response.json()["choices"][0]["message"]["content"]

    def _compute_gradient(self, creative_output: str, logical_output: str) -> float:
        """Compute gradient = novelty - constraint for a plane pair."""
        creative_words = set(creative_output.lower().split())
        logical_words = set(logical_output.lower().split())

        novelty = len(creative_words) / 50.0
        constraint = len(logical_words & creative_words) / max(len(creative_words), 1)

        gradient = novelty - (constraint * 0.5)
        return min(max(gradient, 0.0), 1.0)

    # -------------------------------------------------------------------------
    # Plane Prompts
    # -------------------------------------------------------------------------

    def _plane_creative_prompt(self, plane: AbstractionPlane, input: str, prev_output: Optional[str] = None) -> str:
        """Generate the creative prompt for a specific plane."""
        if plane == AbstractionPlane.INTENT:
            return f"Interpret this goal into a clear intent statement: {input}"
        elif plane == AbstractionPlane.DOMAIN:
            ctx = f"Intent: {prev_output}\n\n" if prev_output else ""
            return f"{ctx}Translate the intent into domain-specific vocabulary and concepts: {input}"
        elif plane == AbstractionPlane.IR:
            ctx = f"Domain model: {prev_output}\n\n" if prev_output else ""
            return f"{ctx}Generate a structured JSON AST (IR) for: {input}"
        elif plane == AbstractionPlane.BYTECODE:
            ctx = f"IR: {prev_output}\n\n" if prev_output else ""
            return f"{ctx}Compile the IR to FLUX bytecode opcodes: {input}"
        elif plane == AbstractionPlane.NATIVE:
            ctx = f"Bytecode: {prev_output}\n\n" if prev_output else ""
            return f"{ctx}Translate FLUX bytecode to idiomatic C or Rust: {input}"
        elif plane == AbstractionPlane.METAL:
            ctx = f"Native code: {prev_output}\n\n" if prev_output else ""
            return f"{ctx}Lower the native code to optimized assembly: {input}"
        return input

    def _plane_logical_prompt(self, plane: AbstractionPlane, creative_output: str, original_input: str) -> str:
        """Generate the logical critique prompt for a specific plane."""
        plane_desc = self.PLANE_NAMES.get(plane, plane.plane_name())
        return (
            f"Critically evaluate this {plane_desc} output for correctness, completeness, "
            f"and feasibility. Find the strongest flaws:\n\n{creative_output}\n\n"
            f"Original goal: {original_input}"
        )

    # -------------------------------------------------------------------------
    # Core Compilation
    # -------------------------------------------------------------------------

    def advance_plane(
        self,
        plane: AbstractionPlane,
        input: str,
        prev_output: Optional[str] = None,
        threshold: float = 0.35
    ) -> PlanePair:
        """
        Run dual-interpreter on a single plane. Returns PlanePair with gradient gate.
        """
        pair = PlanePair(plane=plane)

        try:
            creative_prompt = self._plane_creative_prompt(plane, input, prev_output)
            logical_prompt = self._plane_logical_prompt(plane, creative_prompt, input)

            creative_output = self._call_deepinfra_seed_mini(creative_prompt)
            time.sleep(0.5)

            logical_output = self._call_deepseek(logical_prompt)

            gradient = self._compute_gradient(creative_output, logical_output)

            pair.creative_output = creative_output
            pair.logical_output = logical_output
            pair.gradient = gradient
            pair.advanced = gradient > threshold

        except Exception as e:
            pair.error = str(e)

        return pair

    def compile(self, intent: str, threshold: float = 0.35) -> Dict[str, Any]:
        """
        Compile from Intent (Plane 5) to Metal (Plane 0).
        Each plane transition is gated by gradient > threshold.
        """
        plane_pairs: List[PlanePair] = []
        current_input = intent
        prev_output: Optional[str] = None

        # Start at INTENT (5) and compile down to METAL (0)
        plane_order = [
            AbstractionPlane.INTENT,
            AbstractionPlane.DOMAIN,
            AbstractionPlane.IR,
            AbstractionPlane.BYTECODE,
            AbstractionPlane.NATIVE,
            AbstractionPlane.METAL,
        ]

        for plane in plane_order:
            pair = self.advance_plane(plane, current_input, prev_output, threshold)
            plane_pairs.append(pair)

            if not pair.advanced and pair.gradient < threshold:
                # Don't advance if gradient gate failed
                if plane != AbstractionPlane.METAL:
                    # Keep going but note the failure
                    pass

            if pair.creative_output:
                prev_output = pair.creative_output
                current_input = intent  # original intent flows through

            if pair.error:
                break

        final_pair = plane_pairs[-1]
        final_output = final_pair.creative_output if final_pair.advanced else ""

        return {
            "intent": intent,
            "threshold": threshold,
            "plane_pairs": [p.to_dict() for p in plane_pairs],
            "planes_advanced": sum(1 for p in plane_pairs if p.advanced),
            "total_planes": len(plane_pairs),
            "final_output": final_output,
            "compilation_successful": final_pair.advanced and final_pair.error is None,
        }

    def compile_report(self, intent: str, threshold: float = 0.35) -> str:
        """Generate a human-readable compilation report."""
        result = self.compile(intent, threshold)

        lines = [
            f"# Flux Compiler Report",
            f"",
            f"Intent: {result['intent']}",
            f"Threshold: {result['threshold']}",
            f"Planes Advanced: {result['planes_advanced']}/{result['total_planes']}",
            f"",
            f"## Plane-by-Plane Results",
            "",
        ]

        for p in result["plane_pairs"]:
            status = "✅ ADVANCED" if p["advanced"] else "❌ BLOCKED"
            lines.append(f"### Plane {p['plane_number']}: {p['plane']} [{status}]")
            lines.append(f"- Gradient: {p['gradient']:.3f}")
            if p["error"]:
                lines.append(f"- Error: {p['error']}")
            lines.append(f"- Creative: {p['creative_output'][:200]}...")
            lines.append(f"- Logical: {p['logical_output'][:200]}...")
            lines.append("")

        lines.append(f"## Final Output")
        lines.append(result["final_output"][:500] if result["final_output"] else "(no output)")
        lines.append("")
        lines.append(f"Compilation: {'SUCCESS' if result['compilation_successful'] else 'FAILED'}")

        return "\n".join(lines)
