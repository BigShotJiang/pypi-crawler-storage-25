"""Tests for FluxCompiler plane gates and gradient logic."""

import pytest
from unittest.mock import patch, MagicMock
from flux_compiler import FluxCompiler, AbstractionPlane, PlanePair


class TestAbstractionPlane:
    """Test AbstractionPlane enum and methods."""

    def test_plane_order(self):
        """Test planes are ordered correctly."""
        assert AbstractionPlane.INTENT.value == 5
        assert AbstractionPlane.DOMAIN.value == 4
        assert AbstractionPlane.IR.value == 3
        assert AbstractionPlane.BYTECODE.value == 2
        assert AbstractionPlane.NATIVE.value == 1
        assert AbstractionPlane.METAL.value == 0

    def test_next_plane(self):
        """Test next_plane mappings."""
        assert AbstractionPlane.METAL.next_plane() == AbstractionPlane.NATIVE
        assert AbstractionPlane.NATIVE.next_plane() == AbstractionPlane.BYTECODE
        assert AbstractionPlane.BYTECODE.next_plane() == AbstractionPlane.IR
        assert AbstractionPlane.IR.next_plane() == AbstractionPlane.DOMAIN
        assert AbstractionPlane.DOMAIN.next_plane() == AbstractionPlane.INTENT
        assert AbstractionPlane.INTENT.next_plane() is None

    def test_plane_name(self):
        """Test plane_name returns string name."""
        assert AbstractionPlane.INTENT.plane_name() == "INTENT"
        assert AbstractionPlane.METAL.plane_name() == "METAL"

    def test_from_number(self):
        """Test from_number returns correct plane."""
        assert AbstractionPlane.from_number(0) == AbstractionPlane.METAL
        assert AbstractionPlane.from_number(5) == AbstractionPlane.INTENT


class TestPlanePair:
    """Test PlanePair dataclass."""

    def test_to_dict(self):
        """Test PlanePair serialization."""
        pair = PlanePair(
            plane=AbstractionPlane.IR,
            creative_output="creative result",
            logical_output="logical critique",
            gradient=0.42,
            advanced=True
        )
        d = pair.to_dict()
        assert d["plane"] == "IR"
        assert d["plane_number"] == 3
        assert d["creative_output"] == "creative result"
        assert d["gradient"] == 0.42
        assert d["advanced"] is True

    def test_default_values(self):
        """Test default values for PlanePair."""
        pair = PlanePair(plane=AbstractionPlane.INTENT)
        assert pair.creative_output == ""
        assert pair.logical_output == ""
        assert pair.gradient == 0.0
        assert pair.advanced is False
        assert pair.error is None


class TestFluxCompiler:
    """Test FluxCompiler methods."""

    def test_init(self):
        """Test initialization."""
        compiler = FluxCompiler(deepinfra_key='di-key', siliconflow_key='sf-key')
        assert compiler.deepinfra_key == 'di-key'
        assert compiler.siliconflow_key == 'sf-key'

    def test_compute_gradient(self):
        """Test gradient computation."""
        compiler = FluxCompiler()
        creative = "foo bar baz qux quux corge grault garply waldo fred"
        logical = "some constraints limiting options"
        gradient = compiler._compute_gradient(creative, logical)
        assert 0.0 <= gradient <= 1.0
        assert gradient > 0.0

    def test_compute_gradient_high_constraint(self):
        """Test gradient with high constraint."""
        compiler = FluxCompiler()
        creative = "the the the the the the the the the the"
        logical = "the the the the the the the the the the the the the the the"
        gradient = compiler._compute_gradient(creative, logical)
        assert gradient < 0.2

    @patch.object(FluxCompiler, '_call_deepinfra_seed_mini')
    @patch.object(FluxCompiler, '_call_deepseek')
    def test_advance_plane_adaptive(self, mock_deepseek, mock_deepinfra):
        """Test plane advancement with passing gradient."""
        mock_deepinfra.return_value = "creative output with many unique words here and there"
        mock_deepseek.return_value = "logical evaluation of the output"

        compiler = FluxCompiler()
        pair = compiler.advance_plane(
            plane=AbstractionPlane.DOMAIN,
            input="test input",
            prev_output=None,
            threshold=0.35
        )

        assert pair.plane == AbstractionPlane.DOMAIN
        assert pair.gradient > 0.0
        # gradient > 0.35 should advance
        assert pair.advanced == (pair.gradient > 0.35)

    @patch.object(FluxCompiler, '_call_deepinfra_seed_mini')
    @patch.object(FluxCompiler, '_call_deepseek')
    def test_advance_plane_blocked(self, mock_deepseek, mock_deepinfra):
        """Test plane blocked when gradient too low."""
        mock_deepinfra.return_value = "the the the the the the the the the the"
        mock_deepseek.return_value = "the the the the the the the the the the the the the the the"

        compiler = FluxCompiler()
        pair = compiler.advance_plane(
            plane=AbstractionPlane.IR,
            input="test input",
            prev_output=None,
            threshold=0.35
        )

        assert pair.gradient < 0.35
        assert pair.advanced is False

    def test_plane_creative_prompt_intent(self):
        """Test creative prompt for Intent plane."""
        compiler = FluxCompiler()
        prompt = compiler._plane_creative_prompt(
            AbstractionPlane.INTENT,
            "implement a cache",
            None
        )
        assert "implement a cache" in prompt
        assert "Interpret this goal" in prompt or "intent" in prompt.lower()

    def test_plane_creative_prompt_domain(self):
        """Test creative prompt for Domain plane."""
        compiler = FluxCompiler()
        prompt = compiler._plane_creative_prompt(
            AbstractionPlane.DOMAIN,
            "implement a cache",
            "Intent: build a caching system"
        )
        assert "implement a cache" in prompt
        assert "Intent: build a caching system" in prompt
        assert "Domain" in prompt or "vocabulary" in prompt.lower()

    def test_plane_creative_prompt_ir(self):
        """Test creative prompt for IR plane."""
        compiler = FluxCompiler()
        prompt = compiler._plane_creative_prompt(
            AbstractionPlane.IR,
            "implement a cache",
            "Domain model: Cache, Key, Value"
        )
        assert "Cache, Key, Value" in prompt
        assert "IR" in prompt or "JSON" in prompt

    @patch.object(FluxCompiler, '_call_deepinfra_seed_mini')
    @patch.object(FluxCompiler, '_call_deepseek')
    def test_compile_full_pipeline(self, mock_deepseek, mock_deepinfra):
        """Test full compilation pipeline."""
        def creative_side_effect(prompt):
            return f"creative output for {prompt[:30]}"

        def logical_side_effect(prompt):
            return f"logical evaluation of {prompt[:30]}"

        mock_deepinfra.side_effect = creative_side_effect
        mock_deepseek.side_effect = logical_side_effect

        compiler = FluxCompiler()
        result = compiler.compile("implement a simple counter", threshold=0.35)

        assert "plane_pairs" in result
        assert len(result["plane_pairs"]) == 6
        assert "planes_advanced" in result
        assert "final_output" in result
        assert "compilation_successful" in result

    @patch.object(FluxCompiler, '_call_deepinfra_seed_mini')
    @patch.object(FluxCompiler, '_call_deepseek')
    def test_compile_report_format(self, mock_deepseek, mock_deepinfra):
        """Test compilation report is valid markdown."""
        mock_deepinfra.return_value = "output with unique creative words here and there"
        mock_deepseek.return_value = "logical evaluation"

        compiler = FluxCompiler()
        report = compiler.compile_report("test intent", threshold=0.35)

        assert "# Flux Compiler Report" in report
        assert "## Plane-by-Plane Results" in report
        assert "## Final Output" in report


class TestGradientGate:
    """Test gradient gate threshold logic."""

    def test_gate_above_threshold_advances(self):
        """Test gradient above threshold marks plane as advanced."""
        pair = PlanePair(
            plane=AbstractionPlane.IR,
            gradient=0.5,
            advanced=False
        )
        threshold = 0.35
        pair.advanced = pair.gradient > threshold
        assert pair.advanced is True

    def test_gate_below_threshold_blocks(self):
        """Test gradient below threshold blocks plane."""
        pair = PlanePair(
            plane=AbstractionPlane.IR,
            gradient=0.2,
            advanced=False
        )
        threshold = 0.35
        pair.advanced = pair.gradient > threshold
        assert pair.advanced is False

    def test_gradient_clamping(self):
        """Test gradient is clamped to [0.0, 1.0]."""
        compiler = FluxCompiler()
        # Very short creative, high overlap → should clamp to 0
        g1 = compiler._compute_gradient("word", "word word word word word")
        assert g1 == 0.0

        # Many unique words, no overlap → should be high but clamped to 1
        many_words = " ".join([f"unique{i}" for i in range(100)])
        g2 = compiler._compute_gradient(many_words, "")
        assert g2 == 1.0
