# Flux Compiler

6-plane abstraction stack with dual-interpreter gradient gates. Each plane compiles to the next; only pairs where gradient > 0.35 advance.

## Abstraction Planes

```
Plane 5 (Intent):   natural language goal        ← input
Plane 4 (Domain):   domain vocabulary
Plane 3 (IR):       structured JSON AST
Plane 2 (Bytecode): FLUX opcodes
Plane 1 (Native):   C / Rust / Zig
Plane 0 (Metal):    assembly                     ← output
```

## Architecture

Each plane has a **dual-interpreter gate**:

```
Plane Input
    ↓
[Creative Interpreter (Seed-2.0-mini)] → creative output
[Logical Interpreter (DeepSeek-v4-flash)] → logical evaluation
    ↓
[Gradient Gate: novelty - constraint]
    ↓
gradient > 0.35? → ADVANCE to next plane
gradient ≤ 0.35? → BLOCK, compilation fails or halts
```

The **gradient** is `novelty - constraint`:
- **novelty**: how many unique words did the creative interpreter produce?
- **constraint**: how much did the logical evaluation overlap with/limit the creative output?

## Installation

```bash
pip install flux-compiler-agentic
```

## Usage

### Basic Compilation

```python
from flux_compiler import FluxCompiler, AbstractionPlane

compiler = FluxCompiler()
result = compiler.compile("implement a thread-safe LRU cache")
print(result["compilation_successful"])
print(result["planes_advanced"])  # how many planes passed the gradient gate
```

### Compilation Report

```python
report = compiler.compile_report("build a rate limiter with token bucket algorithm")
print(report)
```

### Manual Plane Advancement

```python
from flux_compiler import FluxCompiler, AbstractionPlane, PlanePair

compiler = FluxCompiler()

# Advance one plane manually
pair = compiler.advance_plane(
    plane=AbstractionPlane.DOMAIN,
    input="implement a connection pool",
    prev_output=None,
    threshold=0.35
)
print(pair.gradient)
print(pair.advanced)  # True if gradient > 0.35
```

## API Reference

### AbstractionPlane

Enum representing the 6 planes:

```python
class AbstractionPlane(Enum):
    METAL = 0       # Assembly / machine code
    NATIVE = 1      # C / Rust / Zig
    BYTECODE = 2    # FLUX opcodes
    IR = 3          # Structured JSON AST
    DOMAIN = 4      # Domain vocabulary
    INTENT = 5      # Natural language goal
```

Methods:
- `next_plane() -> AbstractionPlane | None` — get the next higher plane
- `plane_name() -> str` — human-readable name

### PlanePair

Dataclass holding dual-interpreter results for one plane:

```python
@dataclass
class PlanePair:
    plane: AbstractionPlane
    creative_output: str = ""
    logical_output: str = ""
    gradient: float = 0.0
    advanced: bool = False
    error: Optional[str] = None
```

### FluxCompiler

Main compiler class.

#### `__init__(deepinfra_key: str = None, siliconflow_key: str = None)`
Initialize. Reads keys from environment if not provided.

#### `advance_plane(plane, input, prev_output=None, threshold=0.35) -> PlanePair`
Run dual-interpreter on a single plane. Returns `PlanePair` with gradient result.

#### `compile(intent: str, threshold: float = 0.35) -> Dict`
Compile from Intent to Metal. Returns:

```python
{
    "intent": str,                    # Original intent
    "threshold": float,              # Threshold used
    "plane_pairs": List[Dict],        # One dict per plane
    "planes_advanced": int,           # How many planes passed
    "total_planes": int,             # Total planes (6)
    "final_output": str,             # Metal output if successful
    "compilation_successful": bool,   # True if all planes advanced
}
```

#### `compile_report(intent: str, threshold: float = 0.35) -> str`
Human-readable markdown report of the compilation process.

## Plane-by-Plane Description

### Plane 5: Intent
**Input**: Natural language goal (e.g., "implement a thread-safe LRU cache")

The creative interpreter extracts and formalizes the intent. The logical interpreter critiques it for clarity and completeness.

### Plane 4: Domain
**Input**: Intent output from Plane 5

Translates the intent into domain-specific vocabulary, entities, and concepts. Establishes the semantic model.

### Plane 3: IR
**Input**: Domain model from Plane 4

Generates a structured JSON AST representing the program structure. This is the canonical intermediate representation.

### Plane 2: Bytecode
**Input**: IR from Plane 3

Compiles the JSON AST to FLUX opcodes — a custom bytecode instruction set for the Flux VM.

### Plane 1: Native
**Input**: Bytecode from Plane 2

Translates FLUX opcodes to idiomatic C, Rust, or Zig. Target language is chosen based on constraints in the domain model.

### Plane 0: Metal
**Input**: Native code from Plane 1

Lowers the native code to optimized assembly (x86-64, ARM64, or RISC-V depending on target).

## FLUX Opcodes

The Flux Bytecode instruction set:

| Opcode | Name | Description |
|--------|------|-------------|
| `NOP` | No-op | No operation |
| `LOAD` | Load | Load from memory |
| `STORE` | Store | Store to memory |
| `ADD` | Add | Pop two, push sum |
| `SUB` | Subtract | Pop two, push difference |
| `JMP` | Jump | Unconditional jump |
| `JIZ` | Jump if zero | Conditional jump |
| `CALL` | Call | Call function |
| `RET` | Return | Return from function |
| `HALT` | Halt | Stop execution |

## Environment Variables

- `DEEPINFRA_API_KEY`: DeepInfra API key (Seed-2.0-mini)
- `SILICONFLOW_KEY`: SiliconFlow API key (DeepSeek-v4-flash)

## License

MIT
