"""Collmex CLI - LLM-friendly wrapper for Collmex accounting API."""

__version__ = "2026.05.6"
