use {
    crate::url_builder::{build_project_url, build_project_url_with_id},
    reqwest::Client,
    smbcloud_model::{error_codes::ErrorResponse, project::Project},
    smbcloud_network::{environment::Environment, network::request},
    smbcloud_networking::{constants::SMB_USER_AGENT, smb_client::SmbClient},
};

pub async fn get_project(
    env: Environment,
    client: (&SmbClient, &str),
    access_token: String,
    id: String,
) -> Result<Project, ErrorResponse> {
    let builder: reqwest::RequestBuilder = Client::new()
        .get(build_project_url_with_id(env, client, id))
        .header("Authorization", access_token)
        .header("User-agent", SMB_USER_AGENT);
    request(builder).await
}

pub async fn get_projects(
    env: Environment,
    client: (&SmbClient, &str),
    access_token: String,
) -> Result<Vec<Project>, ErrorResponse> {
    let builder = Client::new()
        .get(build_project_url(env, client))
        .header("Authorization", access_token)
        .header("User-agent", SMB_USER_AGENT);
    request(builder).await
}
