from __future__ import annotations
import gzip
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from multiprocessing.pool import ThreadPool
from collections import defaultdict

import typer
from pyrodigal import GeneFinder   # pyrodigal>=3
from pyrodigal_gv import ViralGeneFinder  # New import for viral gene prediction

import pyhmmer
import pyhmmer.plan7
import pyhmmer.easel

from ._exec import run, _executable, CmdNotFound
from ._click import run_click_task
from .gene_prediction_core import (
    PredictionInputs,
    get_or_predict_proteins,
    write_prediction_metadata,
)
from .kofam_db import (
    KOFamMetadata,
    ensure_kofam_database,
    extract_kofam_models,
    get_kofam_metadata_map,
    is_kofam_id,
    normalize_kofam_id,
)
from .pfam_db import ensure_pfam_database, extract_pfam_models, is_pfam_id, normalize_pfam_id

app = typer.Typer(help="Screen contigs for a protein family using pyHMMER on predicted CDS.")


# ---------- Utilities ----------

def _cmd_exists(exe: str) -> bool:
    return shutil.which(exe) is not None


def _resolve_hmm_inputs(
    hmm_inputs: List[Path],
    outdir: Path,
) -> Tuple[List[Path], Dict[str, KOFamMetadata]]:
    """
    Resolve positional inputs into concrete HMM file paths.

    Input tokens may be local HMM file paths, PFAM accessions, and KO identifiers.
    PFAM and KO IDs are resolved from their local databases, downloading on demand.
    """
    local_hmms: List[Path] = []
    pfam_ids: List[str] = []
    ko_ids: List[str] = []

    for token_path in hmm_inputs:
        token = str(token_path)

        if token_path.exists():
            local_hmms.append(token_path)
            continue

        if is_pfam_id(token):
            pfam_ids.append(normalize_pfam_id(token))
            continue

        if is_kofam_id(token):
            ko_ids.append(normalize_kofam_id(token))
            continue

        raise FileNotFoundError(f"HMM file not found: {token_path}")

    dedup_pfam_ids = list(dict.fromkeys(pfam_ids))
    dedup_ko_ids = list(dict.fromkeys(ko_ids))

    resolved: List[Path] = list(local_hmms)

    if dedup_pfam_ids:
        pfam_meta = run_click_task("Preparing PFAM database", ensure_pfam_database)
        pfam_hmm_db_path = Path(pfam_meta["hmm_path"])

        pfam_dir = outdir / "resolved_pfam_hmms"
        pfam_hmms, missing = run_click_task(
            "Resolving PFAM accessions",
            extract_pfam_models,
            hmm_db_path=pfam_hmm_db_path,
            requested_ids=dedup_pfam_ids,
            output_dir=pfam_dir,
        )

        if missing:
            missing_msg = ", ".join(missing)
            raise FileNotFoundError(
                f"PFAM accession(s) not found in local database: {missing_msg}. "
                "Run again later to refresh the DB source if needed."
            )

        print(
            f"Resolved {len(pfam_hmms)} PFAM model(s) from local database: "
            f"{', '.join(dedup_pfam_ids)}"
        )
        resolved.extend(pfam_hmms)

    ko_metadata: Dict[str, KOFamMetadata] = {}
    if dedup_ko_ids:
        run_click_task("Preparing KOFam database", ensure_kofam_database)

        kofam_dir = outdir / "resolved_kofam_hmms"
        kofam_hmms, missing = run_click_task(
            "Resolving KO identifiers",
            extract_kofam_models,
            requested_ids=dedup_ko_ids,
            output_dir=kofam_dir,
        )

        if missing:
            missing_msg = ", ".join(missing)
            raise FileNotFoundError(
                f"KO identifier(s) not found in local KOFam database: {missing_msg}. "
                "Run `phu dbs refresh kofam` and try again."
            )

        ko_metadata = get_kofam_metadata_map(dedup_ko_ids)
        print(
            f"Resolved {len(kofam_hmms)} KOFam model(s) from local database: "
            f"{', '.join(dedup_ko_ids)}"
        )
        resolved.extend(kofam_hmms)

    return resolved, ko_metadata

@dataclass
class ScreenConfig:
    """Configuration for screening contigs for protein families."""
    input_contigs: Path
    hmms: List[Path]  # Changed from hmm: Path to support multiple HMMs
    outdir: Path = Path("phu-screen")
    mode: str = "meta"  # pyrodigal mode: meta|single
    threads: int = 1
    min_bitscore: Optional[float] = None
    max_evalue: Optional[float] = 1e-5
    cut_ga: bool = True
    use_kofam_thresholds: bool = True
    top_per_contig: int = 1
    min_protein_len_aa: int = 30
    translation_table: int = 11
    keep_proteins: bool = False
    keep_domtbl: bool = True
    combine_mode: str = "any"  # New: how to combine hits from multiple HMMs
    min_hmm_hits: int = 1  # New: minimum number of HMMs that must hit a contig
    save_target_proteins: bool = False  # New: save matched proteins per HMM
    save_target_hmms: bool = False  # New: build and save HMMs from target proteins
    hmm_mode: str = "pure"  # New: "pure" for single models, "mixed" for pressed/concatenated HMMs
    
    def __post_init__(self):
        """Validate configuration parameters."""
        if self.threads < 0:
            raise ValueError("threads must be >= 0")
        if self.threads == 0:
            # HMMER interprets --cpu 0 as "turn off multithreading"
            # This is valid, so we allow it
            pass
        if not self.hmms:
            raise ValueError("At least one HMM file must be provided")
        if self.combine_mode not in {"any", "all", "threshold"}:
            raise ValueError("combine_mode must be 'any', 'all', or 'threshold'")
        if self.hmm_mode not in {"pure", "mixed"}:
            raise ValueError("hmm_mode must be 'pure' or 'mixed'")
        if self.save_target_hmms and not self.save_target_proteins:
            raise ValueError("save_target_hmms requires save_target_proteins to be True")
        if self.min_protein_len_aa < 1:
            raise ValueError("min_protein_len_aa must be >= 1")

    def plan(self) -> "ScreenPlan":
        """Create execution plan from configuration."""
        if self.mode not in {"meta", "single"}:
            raise ValueError("mode must be 'meta' or 'single'")
        
        effective_threads = self.threads
        
        # Create domtbl paths for each HMM
        domtbl_paths = {}
        for hmm in self.hmms:
            hmm_name = hmm.stem  # filename without extension
            domtbl_paths[hmm_name] = self.outdir / f"hits_{hmm_name}.domtblout"
        
        return ScreenPlan(
            hmmer_bin="",
            seqkit_bin="",
            input_contigs=self.input_contigs,
            hmms=self.hmms,
            outdir=self.outdir,
            mode=self.mode,
            threads=effective_threads,
            min_bitscore=self.min_bitscore,
            max_evalue=self.max_evalue,
            cut_ga=self.cut_ga,
            use_kofam_thresholds=self.use_kofam_thresholds,
            top_per_contig=self.top_per_contig,
            min_protein_len_aa=self.min_protein_len_aa,
            translation_table=self.translation_table,
            keep_proteins=self.keep_proteins,
            keep_domtbl=self.keep_domtbl,
            combine_mode=self.combine_mode,
            min_hmm_hits=self.min_hmm_hits,
            save_target_proteins=self.save_target_proteins,
            save_target_hmms=self.save_target_hmms,
            hmm_mode=self.hmm_mode,
            proteins_fa=self.outdir / "proteins.faa",
            domtbl_paths=domtbl_paths,
            kept_ids=self.outdir / "kept_contigs.txt",
            out_contigs=self.outdir / "screened_contigs.fasta",
        )


@dataclass
class ScreenPlan:
    """Execution plan for screening operation."""
    hmmer_bin: str
    seqkit_bin: str
    input_contigs: Path
    hmms: List[Path]  # Changed from hmm: Path
    outdir: Path
    mode: str
    threads: int
    min_bitscore: Optional[float]
    max_evalue: Optional[float]
    cut_ga: bool
    use_kofam_thresholds: bool
    top_per_contig: int
    min_protein_len_aa: int
    translation_table: int
    keep_proteins: bool
    keep_domtbl: bool
    combine_mode: str
    min_hmm_hits: int
    save_target_proteins: bool  # New
    save_target_hmms: bool  # New
    hmm_mode: str  # New
    proteins_fa: Path
    domtbl_paths: Dict[str, Path]  # Changed from domtbl: Path
    kept_ids: Path
    out_contigs: Path

def _binaries() -> str:
    """
    Discover required binaries for screening.
    Only seqkit is needed since we use pyHMMER instead of HMMER binary.
    """
    seqkit = _executable(["seqkit"])
    return seqkit

def _read_fasta(fp: Path) -> Iterable[Tuple[str, str]]:
    """
    Read FASTA sequences with two strategies:
    1) Python parser (stdlib; robust for compressed/edge-case inputs)
    2) pyhmmer/easel fallback (fast native parser when available)

    This keeps a dependency-light default while preserving a pyhmmer-backed
    alternative in environments where easel parsing is preferred.
    """
    try:
        yield from _read_fasta_python(fp)
        return
    except Exception:
        # Fallback to easel parser when Python parsing fails unexpectedly.
        yield from _read_fasta_easel(fp)


def _read_fasta_easel(fp: Path) -> Iterable[Tuple[str, str]]:
    """Read FASTA records using pyhmmer.easel.SequenceFile."""
    with pyhmmer.easel.SequenceFile(str(fp)) as seq_file:
        for seq in seq_file:
            seq_id = seq.name.decode() if isinstance(seq.name, bytes) else seq.name
            seq_seq = seq.sequence
            if isinstance(seq_seq, (bytes, bytearray, memoryview)):
                seq_seq = bytes(seq_seq).decode()
            elif not isinstance(seq_seq, str):
                seq_seq = str(seq_seq)
            yield seq_id, seq_seq


def _read_fasta_python(fp: Path) -> Iterable[Tuple[str, str]]:
    """Read FASTA records using Python text IO (supports .gz)."""
    opener = gzip.open if fp.suffix == ".gz" else open
    with opener(fp, "rt") as handle:
        seq_id: Optional[str] = None
        seq_chunks: List[str] = []

        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue

            if line.startswith(">"):
                if seq_id is not None:
                    yield seq_id, "".join(seq_chunks)
                # FASTA header id is first token after '>'
                seq_id = line[1:].split(None, 1)[0]
                seq_chunks = []
                continue

            if seq_id is None:
                raise ValueError(f"Invalid FASTA format in {fp}: sequence before header")

            seq_chunks.append(line)

        if seq_id is not None:
            yield seq_id, "".join(seq_chunks)

@dataclass
class Hit:
    contig: str
    prot_id: str
    model: str
    bitscore: float
    evalue: float
    domain_bitscore: Optional[float] = None


# ---------- Core pipeline ----------

def _predict_proteins_pyrodigal(
    contigs_fa: Path,
    output_prot_fa: Path,
    mode: str = "meta",
    min_len: int = 90,
    min_protein_len_aa: int = 30,
    translation_table: int = 11,
    threads: int = 1,
) -> int:
    """
    Use pyrodigal to predict CDS and write protein FASTA.
    Headers encode contig and CDS index as: contig|gene<idx>
    Returns number of proteins written.
    
    Uses ThreadPool for parallel processing of contigs when threads > 1.
    """
    # Initialize GeneFinder according to the API
    gf = ViralGeneFinder(meta=(mode == "meta"), min_gene=min_len)
    
    # Read all contigs first
    contigs = list(_read_fasta(contigs_fa))
    
    if not contigs:
        return 0
    
    # Process contigs in parallel if threads > 1
    if threads > 1:
        # Extract sequences for parallel processing
        sequences = [seq for _, seq in contigs]
        
        # Use ThreadPool to process sequences in parallel
        with ThreadPool(processes=threads) as pool:
            genes_results = pool.map(gf.find_genes, sequences)
        
        # Write results
        n_prot = 0
        with output_prot_fa.open("w") as out:
            for (contig_id, _), genes in zip(contigs, genes_results):
                for i, gene in enumerate(genes, start=1):
                    aa = gene.translate()
                    if not aa:
                        continue
                    if len(aa) < min_protein_len_aa:
                        continue
                    prot_id = f"{contig_id}|gene{i}"
                    out.write(f">{prot_id}\n{aa}\n")
                    n_prot += 1
    else:
        # Single-threaded processing (original logic)
        n_prot = 0
        with output_prot_fa.open("w") as out:
            for contig_id, seq in contigs:
                genes = gf.find_genes(seq)
                for i, gene in enumerate(genes, start=1):
                    aa = gene.translate()
                    if not aa:
                        continue
                    if len(aa) < min_protein_len_aa:
                        continue
                    prot_id = f"{contig_id}|gene{i}"
                    out.write(f">{prot_id}\n{aa}\n")
                    n_prot += 1
    
    return n_prot

def _hmmsearch(
    hmm_paths: List[Path],
    proteins_fa: Path,
    domtbl_paths: Dict[str, Path],
    threads: int = 1,
    hmm_mode: str = "pure",
    keep_domtbl: bool = True,
    cut_ga: bool = True,
) -> Iterable[Hit]:
    """
    Run pyhmmer.hmmsearch on loaded HMMs and proteins.
    Returns hits directly as Hit objects and optionally writes domtbl files.
    """
    # Load all HMMs into memory
    hmms = []
    hmm_names = []
    for hmm_path in hmm_paths:
        with pyhmmer.plan7.HMMFile(hmm_path) as hmm_file:
            for hmm in hmm_file:
                hmms.append(hmm)
                hmm_names.append(hmm_path.stem)  # Use filename for pure mode
    
    # Load proteins into memory
    with pyhmmer.easel.SequenceFile(proteins_fa, digital=True) as seq_file:
        proteins = seq_file.read_block()
    
    # Run hmmsearch with pyHMMER
    bit_cutoffs = "gathering" if cut_ga else None
    try:
        hits_list = list(pyhmmer.hmmsearch(hmms, proteins, cpus=threads, bit_cutoffs=bit_cutoffs))
    except Exception as exc:
        missing_cutoffs_exc = getattr(pyhmmer.plan7, "MissingCutoffs", None)
        if (
            cut_ga
            and missing_cutoffs_exc is not None
            and isinstance(exc, missing_cutoffs_exc)
        ):
            print(
                " Warning: One or more models are missing gathering cutoffs; "
                "retrying without --cut-ga."
            )
            hits_list = list(pyhmmer.hmmsearch(hmms, proteins, cpus=threads, bit_cutoffs=None))
        else:
            raise
    
    # Write domtbl files if requested
    if keep_domtbl:
        for i, top_hits in enumerate(hits_list):
            # Map back to original HMM file for domtbl naming
            hmm_name = hmm_names[i] if i < len(hmm_names) else f"hmm_{i}"
            if hmm_name in domtbl_paths:
                domtbl_path = domtbl_paths[hmm_name]
                with domtbl_path.open("wb") as f:
                    top_hits.write(f, format="domains")
    
    # Process hits and yield Hit objects
    for i, top_hits in enumerate(hits_list):
        query_name = top_hits.query.name
        model_name = query_name.decode() if isinstance(query_name, bytes) else query_name
        
        # Determine model identifier based on hmm_mode
        if hmm_mode == "pure":
            # Use filename as model ID for pure mode
            model_id = hmm_names[i] if i < len(hmm_names) else model_name
        else:
            # Use actual HMM name for mixed mode
            model_id = model_name
        
        for hit in top_hits:
            if hit.included:  # pyHMMER's inclusion check
                prot_id = hit.name if isinstance(hit.name, str) else hit.name.decode()
                
                # Extract contig from prot_id with robust handling of multiple "|" characters
                # Expected format: "contig_name|gene<idx>" where contig_name may contain "|"
                # Use regex to find the last "|gene" pattern
                import re
                gene_pattern = r'\|gene\d+$'
                match = re.search(gene_pattern, prot_id)
                if match:
                    # Split at the position where "|gene" starts
                    contig = prot_id[:match.start()]
                else:
                    # Fallback: if no "|gene" pattern found, try simple split
                    if "|" in prot_id:
                        # Take everything before the last "|" as contig ID
                        contig = prot_id.rsplit("|", 1)[0]
                    else:
                        # No "|" found, use entire protein ID as contig ID
                        contig = prot_id
                
                domain_bitscore: Optional[float] = None
                hit_domains = getattr(hit, "domains", None)
                if hit_domains is not None:
                    included_scores = [
                        domain.score
                        for domain in hit_domains
                        if getattr(domain, "included", True)
                    ]
                    if included_scores:
                        domain_bitscore = max(included_scores)

                yield Hit(
                    contig=contig,
                    prot_id=prot_id,
                    model=model_id,
                    bitscore=hit.score,
                    domain_bitscore=domain_bitscore,
                    evalue=hit.evalue,
                )

def _effective_hit_score(hit: Hit, score_type: str) -> float:
    if score_type == "domain" and hit.domain_bitscore is not None:
        return hit.domain_bitscore
    return hit.bitscore


def _hit_sort_key(hit: Hit, score_type: str) -> Tuple[float, float]:
    return (-_effective_hit_score(hit, score_type), hit.evalue)


def _choose_best_contigs(
    hits: Iterable[Hit],
    min_bitscore: Optional[float],
    max_evalue: Optional[float],
    top_per_contig: int = 1,
    combine_mode: str = "any",
    min_hmm_hits: int = 1,
    total_hmm_models: int = 1,
    kofam_metadata_by_model: Optional[Dict[str, KOFamMetadata]] = None,
    use_kofam_thresholds: bool = True,
) -> Tuple[List[Hit], List[str]]:
    """
    Filter by thresholds, then pick top N hits per contig by bitscore.
    For KO models, ko_list thresholds are used by their score_type (full/domain).

    Returns (kept_hits, list_of_contig_ids).
    """
    per_contig: Dict[str, List[Hit]] = defaultdict(list)
    kofam_metadata_by_model = kofam_metadata_by_model or {}

    for h in hits:
        score_type = "full"
        ko_threshold: Optional[float] = None
        ko_meta = kofam_metadata_by_model.get(h.model)
        if ko_meta is not None:
            score_type = ko_meta.score_type
            ko_threshold = ko_meta.threshold

        effective_score = _effective_hit_score(h, score_type)

        effective_min_bitscore = min_bitscore
        if use_kofam_thresholds and ko_threshold is not None:
            if effective_min_bitscore is None:
                effective_min_bitscore = ko_threshold
            else:
                effective_min_bitscore = max(effective_min_bitscore, ko_threshold)

        if effective_min_bitscore is not None and effective_score < effective_min_bitscore:
            continue
        if max_evalue is not None and h.evalue > max_evalue:
            continue
        per_contig[h.contig].append(h)

    kept: List[Hit] = []
    kept_contigs: List[str] = []

    for contig, contig_hits in per_contig.items():
        if combine_mode == "any":
            if contig_hits:
                hits_per_model = defaultdict(list)
                for hit in contig_hits:
                    hits_per_model[hit.model].append(hit)

                for model_hits in hits_per_model.values():
                    score_type = "full"
                    if model_hits[0].model in kofam_metadata_by_model:
                        score_type = kofam_metadata_by_model[model_hits[0].model].score_type
                    model_hits.sort(key=lambda hit: _hit_sort_key(hit, score_type))
                    kept.extend(model_hits[:max(1, top_per_contig)])
                kept_contigs.append(contig)

        elif combine_mode == "all":
            model_names = set(hit.model for hit in contig_hits)
            if len(model_names) == total_hmm_models:
                hits_per_model = defaultdict(list)
                for hit in contig_hits:
                    hits_per_model[hit.model].append(hit)

                for model_hits in hits_per_model.values():
                    score_type = "full"
                    if model_hits[0].model in kofam_metadata_by_model:
                        score_type = kofam_metadata_by_model[model_hits[0].model].score_type
                    model_hits.sort(key=lambda hit: _hit_sort_key(hit, score_type))
                    kept.extend(model_hits[:1])

                kept_contigs.append(contig)

        elif combine_mode == "threshold":
            model_names = set(hit.model for hit in contig_hits)
            if len(model_names) >= min_hmm_hits:
                contig_hits.sort(
                    key=lambda hit: _hit_sort_key(
                        hit,
                        kofam_metadata_by_model[hit.model].score_type
                        if hit.model in kofam_metadata_by_model
                        else "full",
                    )
                )
                kept.extend(contig_hits[:max(1, top_per_contig)])
                kept_contigs.append(contig)

    return kept, kept_contigs

def _seqkit_extract(
    input_fa: Path,
    ids: List[str],
    output_fa: Path,
    seqkit_bin: str = "seqkit",
) -> None:
    if not ids:
        # write empty file but succeed, useful for pipelines
        output_fa.write_text("")
        return
    tmp = output_fa.parent / (output_fa.name + ".ids.txt")
    tmp.write_text("\n".join(ids) + "\n")
    cmd = [seqkit_bin, "grep", "-f", str(tmp), str(input_fa)]
    with output_fa.open("w") as out:
        p = subprocess.run(cmd, stdout=out, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"seqkit grep failed with code {p.returncode}")
    tmp.unlink()  # cleanup


def _extract_target_proteins(
    kept_hits: List[Hit],
    kept_contig_ids: List[str],
    proteins_fa: Path,
    outdir: Path,
    hmm_mode: str,
    seqkit_bin: str = "seqkit",
    kofam_metadata_by_model: Optional[Dict[str, KOFamMetadata]] = None,
) -> None:
    """
    Extract matched proteins per HMM model from the final kept contigs only.
    For KOFam models, headers are enriched as KO|definition.
    """
    # Create a set of kept contig IDs for fast lookup
    kept_contig_set = set(kept_contig_ids)
    kofam_metadata_by_model = kofam_metadata_by_model or {}

    # Group protein IDs by model - only from kept hits AND kept contigs
    proteins_per_model: Dict[str, List[str]] = defaultdict(list)

    for hit in kept_hits:
        if hit.contig in kept_contig_set:
            proteins_per_model[hit.model].append(hit.prot_id)
    
    # Create target_proteins directory
    target_proteins_dir = outdir / "target_proteins"
    target_proteins_dir.mkdir(parents=True, exist_ok=True)
    
    # Extract proteins for each model
    for model_id, protein_ids in proteins_per_model.items():
        # Create a safe filename from the model identifier
        safe_model_name = re.sub(r'[^\w\-_.]', '_', model_id)
        output_path = target_proteins_dir / f"{safe_model_name}_proteins.mfa"
        
        if not protein_ids:
            output_path.write_text("")
            continue
        
        # Remove duplicates while preserving order
        unique_protein_ids = []
        seen = set()
        for pid in protein_ids:
            if pid not in seen:
                unique_protein_ids.append(pid)
                seen.add(pid)
        
        # Use seqkit to extract the proteins
        tmp_ids_file = output_path.parent / f"{output_path.name}.ids.tmp"
        tmp_ids_file.write_text("\n".join(unique_protein_ids) + "\n")
        
        cmd = [seqkit_bin, "grep", "-f", str(tmp_ids_file), str(proteins_fa)]
        
        with output_path.open("w") as out:
            result = subprocess.run(cmd, stdout=out, text=True)
            
        if result.returncode != 0:
            print(f"Warning: seqkit failed to extract proteins for {model_id}")
        else:
            ko_meta = kofam_metadata_by_model.get(model_id)
            if ko_meta is not None and ko_meta.definition:
                label = f"{ko_meta.ko_id}|{ko_meta.definition}"
                rewritten_path = output_path.parent / f"{output_path.name}.tmp"
                with output_path.open("r") as src, rewritten_path.open("w") as dst:
                    for line in src:
                        if line.startswith(">"):
                            dst.write(f"{line.rstrip()}|{label}\n")
                        else:
                            dst.write(line)
                rewritten_path.replace(output_path)

            print(f"    Extracted {len(unique_protein_ids)} proteins for {model_id} (from screened contigs)")

        # Cleanup temporary file
        tmp_ids_file.unlink()

def _build_target_hmms(
    target_proteins_dir: Path,
    outdir: Path,
    threads: int = 1,
) -> None:
    """
    Build HMM models from target protein sequences using pyHMMER.
    Creates one HMM file per model from the corresponding protein FASTA files.

    For single sequences, builds HMM directly using builder.build().
    For multiple sequences, aligns them by padding to the same length before MSA creation.
    """
    target_hmms_dir = outdir / "target_hmms"
    target_hmms_dir.mkdir(parents=True, exist_ok=True)

    protein_files = list(target_proteins_dir.glob("*_proteins.mfa"))

    if not protein_files:
        print("    No target protein files found for HMM building")
        return

    print(f"    Building HMMs for {len(protein_files)} protein sets...")

    def _build_single_hmm(protein_file: Path) -> None:
        model_name = protein_file.stem.replace("_proteins", "")
        hmm_output_path = target_hmms_dir / f"{model_name}.hmm"

        try:
            alphabet = pyhmmer.easel.Alphabet.amino()
            builder = pyhmmer.plan7.Builder(alphabet)
            background = pyhmmer.plan7.Background(alphabet)

            sequences = [
                pyhmmer.easel.TextSequence(name=seq_id.encode(), sequence=seq_str)
                for seq_id, seq_str in _read_fasta(protein_file)
                if seq_str
            ]

            if len(sequences) == 0:
                print(f"      Skipping {model_name}: no valid sequences found")
                return
            elif len(sequences) == 1:
                # For single sequence, use builder.build() method
                digital_seq = sequences[0].digitize(alphabet)
                hmm, _, _ = builder.build(digital_seq, background)
                hmm.name = model_name.encode()
                print(f"      Built HMM from 1 sequence: {model_name}")
            else:
                # For multiple sequences, align by padding to same length
                max_len = max(len(seq.sequence) for seq in sequences)

                # Pad sequences to same length with gaps
                aligned_sequences = [
                    pyhmmer.easel.TextSequence(
                        name=seq.name,
                        sequence=seq.sequence + "-" * (max_len - len(seq.sequence)),
                    )
                    for seq in sequences
                ]
                text_msa = pyhmmer.easel.TextMSA(
                    name=model_name.encode(),
                    sequences=aligned_sequences,
                )
                digital_msa = text_msa.digitize(alphabet)
                hmm, _, _ = builder.build_msa(digital_msa, background)
                print(f"      Built HMM from {len(sequences)} aligned sequences: {model_name}")

            if not hmm.name:
                hmm.name = model_name.encode()

            with hmm_output_path.open("wb") as f:
                hmm.write(f)

        except Exception as e:
            print(f"      Warning: Failed to build HMM for {model_name}: {e}")
            import traceback
            traceback.print_exc()

    # Use threads if requested; otherwise fall back to sequential processing
    if threads and threads > 1:
        print(f"    Using {threads} threads for HMM building")
        with ThreadPool(processes=threads) as pool:
            pool.map(_build_single_hmm, protein_files)
    else:
        for protein_file in protein_files:
            _build_single_hmm(protein_file)

def _screen(cfg: ScreenConfig) -> ScreenPlan:
    """
    Screen contigs for protein families using pyHMMER.
    
    Main workflow:
    1. Predict proteins with pyrodigal
    2. Search proteins against HMMs with pyhmmer.hmmsearch
    3. Parse results, combine, and select best hits per contig
    4. Extract screened contigs
    5. Optionally extract matched proteins per HMM model from screened contigs only
    """
    if not cfg.input_contigs.exists():
        raise FileNotFoundError(f"Input file not found: {cfg.input_contigs}")

    # Resolve positional inputs: local HMM paths, PFAM accessions, and KO IDs.
    cfg.hmms, kofam_metadata_by_model = _resolve_hmm_inputs(cfg.hmms, cfg.outdir)

    # Check all resolved HMM files exist.
    for hmm in cfg.hmms:
        if not hmm.exists():
            raise FileNotFoundError(f"HMM file not found: {hmm}")
    
    # Discover binaries (only seqkit needed)
    seqkit_bin = _binaries()
    plan = cfg.plan()
    plan.hmmer_bin = ""  # Not used with pyHMMER
    plan.seqkit_bin = seqkit_bin
    
    # Create output directory
    plan.outdir.mkdir(parents=True, exist_ok=True)
    
    # Use cache-aware protein prediction
    pred_inputs = PredictionInputs(
        input_contigs=plan.input_contigs,
        mode=plan.mode,
        min_protein_len_aa=plan.min_protein_len_aa,
        translation_table=plan.translation_table,
    )
    cache_enabled = os.environ.get("PHU_CACHE", "on") != "off"
    cache_artifact = run_click_task(
        "Predicting proteins",
        get_or_predict_proteins,
        pred_inputs,
        use_cache=cache_enabled,
        threads=plan.threads,
    )
    
    print(
        f"Predicting proteins with pyrodigal…"
        + (" [cache hit]" if cache_artifact.cache_hit else "")
    )
    print(f"  Proteins predicted: {cache_artifact.protein_count}")
    
    n_prot = cache_artifact.protein_count
    proteins_fa = cache_artifact.proteins_path
    
    if n_prot == 0:
        print("No proteins predicted. Exiting with empty outputs.")
        plan.out_contigs.write_text("")
        plan.kept_ids.write_text("")
        if cache_artifact.temp_dir is not None:
            shutil.rmtree(cache_artifact.temp_dir, ignore_errors=True)
        return plan
    
    print(f"Running pyhmmer.hmmsearch for {len(plan.hmms)} HMM file(s) (mode: {plan.hmm_mode})…")
    
    # Use pyHMMER for all searches
    all_hits = run_click_task(
        "Running HMM searches",
        lambda: list(
            _hmmsearch(
                hmm_paths=plan.hmms,
                proteins_fa=proteins_fa,
                domtbl_paths=plan.domtbl_paths,
                threads=plan.threads,
                hmm_mode=plan.hmm_mode,
                keep_domtbl=plan.keep_domtbl,
                cut_ga=plan.cut_ga,
            )
        ),
    )
    
    unique_model_ids = set(hit.model for hit in all_hits)
    if plan.hmm_mode == "pure":
        total_models = len(plan.hmms)  # Each file is one model
        print(f"  Pure HMM mode: {total_models} models from {len(plan.hmms)} files")
    else:
        total_models = len(unique_model_ids)  # Count actual models found
        print(f"  Mixed HMM mode: {total_models} unique models found from {len(plan.hmms)} files")
    
    print(f"    Found {len(all_hits)} hits")
    
    print(f"Parsing results and selecting best hits per contig (combine_mode: {plan.combine_mode})…")
    kept_hits, contig_ids = _choose_best_contigs(
        all_hits,
        min_bitscore=plan.min_bitscore,
        max_evalue=plan.max_evalue,
        top_per_contig=plan.top_per_contig,
        combine_mode=plan.combine_mode,
        min_hmm_hits=plan.min_hmm_hits,
        total_hmm_models=total_models,
        kofam_metadata_by_model=kofam_metadata_by_model,
        use_kofam_thresholds=plan.use_kofam_thresholds,
    )
    
    plan.kept_ids.write_text("\n".join(contig_ids) + ("\n" if contig_ids else ""))
    
    # Extract target proteins per HMM if requested
    if plan.save_target_proteins:
        print("Extracting matched proteins per HMM model from screened contigs…")
        _extract_target_proteins(
            kept_hits,
            contig_ids,
            proteins_fa,
            plan.outdir,
            plan.hmm_mode,
            plan.seqkit_bin,
            kofam_metadata_by_model=kofam_metadata_by_model,
        )
        
        # Build HMMs from target proteins if requested
        if plan.save_target_hmms:
            print("Building HMMs from target protein sequences…")
            target_proteins_dir = plan.outdir / "target_proteins"
            _build_target_hmms(
                target_proteins_dir,
                plan.outdir,
                threads=plan.threads,
            )
    
    print(f"Extracting {len(contig_ids)} contig(s) with seqkit…")
    run_click_task(
        "Extracting contigs",
        _seqkit_extract,
        input_fa=plan.input_contigs,
        ids=contig_ids,
        output_fa=plan.out_contigs,
        seqkit_bin=plan.seqkit_bin,
    )
    
    # Output handling: copy proteins to output folder if requested
    if plan.keep_proteins:
        shutil.copy(proteins_fa, plan.outdir / "proteins.faa")
        write_prediction_metadata(
            plan.outdir / ".phu_prediction_metadata.json",
            cache_hit=cache_artifact.cache_hit,
            cache_key=cache_artifact.cache_key,
            cache_dir=cache_artifact.cache_dir,
        )

    # Clean up temp prediction directory (only set when caching is disabled)
    if cache_artifact.temp_dir is not None:
        shutil.rmtree(cache_artifact.temp_dir, ignore_errors=True)
    
    # Clean up domtblout if not requested
    if not plan.keep_domtbl:
        for domtbl_path in plan.domtbl_paths.values():
            if domtbl_path.exists():
                domtbl_path.unlink()
    
    print(f"Done. Output FASTA: {plan.out_contigs}")
    files_msg = f"Also wrote: {plan.kept_ids.name} (contig IDs)"
    if plan.keep_domtbl:
        files_msg += f" and {len(plan.domtbl_paths)} domtblout files"
    if plan.keep_proteins:
        proteins_msg = "proteins.faa (cached)" if cache_artifact.cache_hit else "proteins.faa"
        files_msg += f" and {proteins_msg}"
    if plan.save_target_proteins:
        files_msg += f" and target proteins in target_proteins/ folder"
    if plan.save_target_hmms:
        files_msg += f" and target HMMs in target_hmms/ folder"
    print(f"{files_msg}.")
    
    return plan