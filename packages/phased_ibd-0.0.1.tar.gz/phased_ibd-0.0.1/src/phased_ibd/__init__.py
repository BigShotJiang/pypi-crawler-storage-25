"""
phased-ibd - Security research namespace placeholder.

This package is empty. It exists only to claim the PyPI name as part of
authorized security research under 23andMe's HackerOne bug bounty program.

Bug bounty program: https://hackerone.com/23andme_bbp
Researcher contact: idkruan@wearehackerone.com

The real phasedibd tool lives at: https://github.com/23andMe/phasedibd
"""

__version__ = "0.0.1"
