# phased-ibd — Security Research Namespace Placeholder

**This package contains no functionality.** It is an empty placeholder published as part of authorized security research under 23andMe's HackerOne bug bounty program.

## Why this exists

The package name `phasedibd` is declared in 23andMe's public GitHub repository ([23andMe/phasedibd](https://github.com/23andMe/phasedibd)) but was unregistered on PyPI. Per [PEP 503 name normalization](https://peps.python.org/pep-0503/#normalized-names), the names `phasedibd`, `phased-ibd`, and `phased_ibd` are equivalent on PyPI. This created a dependency confusion risk: an attacker could register the name and ship malicious code that would execute when anyone ran `pip install phasedibd`.

To responsibly demonstrate the risk to 23andMe's security team, this name has been claimed as a safe, empty placeholder. **There is no executable code, no install hooks, no network calls, no telemetry — nothing.**

## Authorization

This research is conducted under 23andMe's public bug bounty program: https://hackerone.com/23andme_bbp

## Ownership Transfer

I will gladly transfer ownership of this package name to 23andMe upon request. Please contact me via the HackerOne report or at idkruan@wearehackerone.com.

## What this package is NOT

- Not affiliated with or endorsed by 23andMe
- Not a working implementation of phased IBD inference
- Not malicious in any way
- Not intended for installation by end users

If you are looking for the real phasedibd tool, install it directly from source:
`pip install git+https://github.com/23andMe/phasedibd.git`
