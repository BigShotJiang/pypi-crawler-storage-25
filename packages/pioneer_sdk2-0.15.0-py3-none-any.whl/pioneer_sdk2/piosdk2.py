import time
import math
import threading as th
import sys
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)
import proto
from enum import Enum
from .config import CONFIG

class Event(Enum):
    """
    Класс, предоставляющий константы для различных событий дрона.
    """
    ALL                = 0   # Все события.
    NULL               = 255 # Пустое событие.
    COPTER_LANDED      = 26  # Событие посадки дрона на землю.
    LOW_VOLTAGE1       = 31  # Низкий заряд АКБ, но заряда хватит, чтобы вернуться домой.
    LOW_VOLTAGE2       = 32  # Низкий заряд АКБ, начата экстренная посадка
    POINT_REACHED      = 42  # Событие достижения целевой точки.
    POINT_DECELERATION = 43  # Событие замедления дрона перед целевой точкой.
    TAKEOFF_COMPLETE   = 51  # Событие завершения взлета.
    ENGINES_STARTED    = 56  # Событие запуска моторов.
    SHOCK              = 65  # Сильный удар, возможна потеря управления.
    LOW_CHARGE         = 115 # Критически низкий заряд АКБ

class NavSystem(Enum):
    """
    Класс, предоставляющий константы видов навигации дрона.
    """
    GPS                = 0  # Глобальная система навигации ГНСС.
    LPS                = 1  # Локальная система навигации Локус (УЗ), ИК.
    OPT                = 2  # Оптическая система навигации.

class NavStatus(Enum):
    """
    Класс, предоставляющий константы состояния системы навигации дрона.
    """
    NO_DATA            = 0  # Нет данных с модуля
    CANNOT             = 1  # Невозможно оценить позицию
    LOW                = 2  # Малое доверие к оценке
    OK                 = 3  # Успешная оценка

class _ManualSpeedMode(Enum):
    """
    Класс, определяющий режимы управления дроном по скоростям.
    """
    GLOBAL             = 6  # Глобальная ось координат
    BODY_FIXED         = 8  # Относительно тела дрона

class FlyState(Enum):
    """
    Класс, представляющий состояния полета дрона в цикле: ON_LAND -> ARMED -> IN_SKY -> ON_LAND.
    Используется для контроля последовательности выполнения команд.
    """
    ON_LAND            = 0  # Коптер на земле, моторы выключены
    ARMED              = 1  # Коптер заармлен, моторы запущены
    IN_SKY             = 2  # Коптер в воздухе, выполняет полет

# Разрешенные команды в зависимости от текущего состояния полета дрона
_FLY_STATE_ALLOWED_COMMAND = {
    FlyState.ON_LAND   : "arm",
    FlyState.ARMED     : "takeoff",
    FlyState.IN_SKY    : "flight",
}

_FLY_STATE_TRANSITION_TABLE = [FlyState.ON_LAND, FlyState.ARMED, FlyState.IN_SKY]

class Pioneer():
    """
    Основной класс для управления беспилотником Pioneer Mini 2.
    """
    def __init__(self, 
                 serial             : str | None     = None,
                 tcp                : str | None     = "127.0.0.1:20556",
                 baudrate           : int            = 57600, 
                 wait_callback      : bool           = True,
                 safety_command     : bool           = True,
                 logger             : bool           = True, 
                ) -> None:
        """
        Инициализирует объект Pioneer для управления беспилотником. 
        Если указан serial, то используется последовательный порт, если tcp, то используется TCP-соединение.

        Args:
            serial (str): Подключаемый последовательный порт.
            tcp (str): TCP адрес и порт (по умолчанию "127.0.0.1:20556").
            baudrate (int): Скорость передачи данных.
            wait_callback (bool): Флаг, указывающий, следует ли ожидать выполнения callback-функции.
            safety_command (bool): Флаг, включающий проверку разрешенных команд в зависимости от состояния полета.
            logger (bool): Флаг, указывающий, включено ли логирование.
        """

        self.messenger = None
        self._logger = logger
        self.wait_callback = wait_callback
        self.safety_command = safety_command

        self.__global_point_seq = 0
        self.__local_point_seq = 0
        self.__current_fly_state = FlyState.ON_LAND

        if serial is not None:
            stream = proto.SerialStream(serial, baudrate)
        elif tcp is not None:
            try:
                parts = tcp.split(':')
                if len(parts) == 1:
                    address, port = parts[0], 5500
                else:
                    address, port = parts[0], int(parts[1])

                stream = proto.NetworkStream(address, port, 1, 2)
            except:
                self.__print_log('Не получилось подключиться по TCP')
                exit()
        else:
            self.__print_log('Не указан тип подключения')
            raise Exception()
        
        if stream is None:
            self.__print_log('Соединение не удалось')
            exit()
        
        events_ids = [event.value for event in Event]
        self.callback_events = {event_id: th.Event() for event_id in events_ids}
        self._nav_system = None
        
        self.messenger = proto.Messenger(stream)
        self.messenger.hub.onFieldsChanged = self.__on_fields_changed
        self.watchers = []
        self.field_watcher = []
        self._field_watcher_thread = None
        self._stop_field_watcher_thread = th.Event()

        self.connect()

        self.__print_log("Соединение установлено")

        self._field_watcher_thread = th.Thread(target=self._field_watcher_loop, daemon=True)
        self._field_watcher_thread.start()

        self.__board_params = CONFIG
        if self.__board_params is None:
            self.__print_log('Загрузка конфигурационного файла не удалась\n  возможно стоит переустановить pioneer_sdk2')
            exit()

        self._current_gnss = self.__get_current_navigation_module('gnss')
        self._current_lps = self.__get_current_navigation_module('lps')

        self.__autopilot_params_id = None

        self.__print_log("Класс Пионер инициализирован")

    def __check_allowed(self, command_name: str) -> bool:
        """
        Проверяет, разрешена ли команда в текущем состоянии полета.
        
        Цикл состояний: ON_LAND -> ARMED -> IN_SKY -> ON_LAND
        
        Проверка выполняется только если включены флаги wait_callback и safety_command.
        Если хотя бы один из них отключен, команда всегда разрешается.
        
        Логика работы (при включенных проверках):
        - Команда для текущего состояния: разрешена (возвращает True)
        - Команда для предыдущего состояния: игнорируется (возвращает False)
        - Команда для следующего состояния: запрещена (выбрасывает RuntimeError, пропуск этапа)
        - Любая другая команда: запрещена (выбрасывает RuntimeError)
        
        Args:
            command_name (str): Название команды для проверки ("arm", "takeoff", "flight").
            
        Returns:
            bool: True если команда разрешена, False если команда игнорируется.
            
        Raises:
            RuntimeError: Если выполнение команды приведет к некорректному поведению.
        """

        if not self.wait_callback:
            return True

        if not self.safety_command:
            return True

        if command_name == _FLY_STATE_ALLOWED_COMMAND[self.__current_fly_state]:
            return True
        
        current_state_index = _FLY_STATE_TRANSITION_TABLE.index(self.__current_fly_state)
        next_state_index = 0 if current_state_index == len(_FLY_STATE_TRANSITION_TABLE) - 1 else current_state_index + 1
        prev_state_index = current_state_index - 1

        next_state = _FLY_STATE_TRANSITION_TABLE[next_state_index]
        prev_state = _FLY_STATE_TRANSITION_TABLE[prev_state_index]


        if command_name == _FLY_STATE_ALLOWED_COMMAND[next_state]:
            raise RuntimeError("Команда запрещена: её вызов приведет к некорректному поведению в полете")

        if command_name == _FLY_STATE_ALLOWED_COMMAND[prev_state]:
            return False

        raise RuntimeError("Команда запрещена: её вызов приведет к некорректному поведению в полете")

    def __get_current_navigation_module(self, navigation_type: str) -> str | None:
        """
        Возвращает установленный поддерживаемый модуль навигации.

        Args:
            navigation_type (str): Тип навигации из конфигурации (например, 'gnss' или 'lps').

        Returns:
            str | None: Имя модуля навигации или None, если не установлен.
        """
        comp_name = [self.messenger.hub.components[i].name for i in self.messenger.hub.components]
        for com_in_config in self.__board_params.get(navigation_type, []):
            if com_in_config in comp_name:
                return com_in_config
        return None

    def __del__(self) -> None:
        """ 
        Очищает ресурсы при удалении объекта.
        """
        self.close_connection()

    def set_logger(self, value=True) -> None:
        """
        Устанавливает флаг логирования.
        """
        self._logger = value

    def __print_log(self, message: str) -> None:
        """
        Выводит сообщение в консоль.
        """
        if self._logger: print(message)

    def connect(self) -> None:
        """
        Устанавливает соединение с устройством.
        """
        self.messenger.connect()

    def close_connection(self) -> None:
        """
        Закрывает соединение с устройством.
        """
        if self.messenger is not None:
            self.messenger.stop()
            self._stop_field_watcher_thread.set()
            if self._field_watcher_thread and self._field_watcher_thread.is_alive():
                self._field_watcher_thread.join(timeout=1.0)
            self.messenger.handler.stream.socket.close()
            self.messenger = None # обнуляем messenger

    def time(self) -> float | None:
        """
        Возвращает время работы беспилотника в секундах с момента начала GPS-эпохи.

        Returns:
            float | None: Время в секундах с начала эпохи GPS или None, если ошибка.
        """
        try:
            UNIX_TO_GPS = 315964800.0 # Смещение в секундах между началом UNIX-эпохи и началом GPS-эпохи
            gps_time = self.messenger.hub['UavMonitor']['time'].read()[0]
            return float(gps_time) / 1000000.0 + UNIX_TO_GPS # Конвертация в GPS-время
        except:
            return None

    def uptime(self) -> int | None:
        """
        Возвращает время в секундах, прошедшее с момента идентификации в системе навигации.

        Returns:
            int | None: Время в секундах или None, если ошибка.
        """
        try:
            return self.messenger.hub['UavMonitor']['uptime'].read()[0]
        except:
            return None

    def flight_time(self) -> float | None:
        """
        Возвращает время с начала полёта дрона в секундах.

        Returns:
            int | None: Время полёта в секундах или None, если ошибка.
        """
        try:
            return self.messenger.hub['FlightManager']['missionTime'].read()[0]
        except:
            return None

    def get_battery_status(self) -> tuple[float, float] | None:
        """
        Возвращает текущий статус заряда батареи.

        Returns:
            tuple[float, float] | None: Кортеж с напряжением и температурой батареи или None, если ошибка.
        """
        try:
            battery_config = self.__board_params.get('battery')
            voltage_data = None
            temperature_data = None

            voltage_cfg = battery_config.get('voltage')
            if voltage_cfg is not None:
                comp_v = voltage_cfg.get('comp')
                field_v = voltage_cfg.get('field')
                voltage_data = self.messenger.hub[comp_v][field_v].read()[0]

            temperature_cfg = battery_config.get('temperature')
            if temperature_cfg is not None:
                comp_t = temperature_cfg.get('comp')
                field_t = temperature_cfg.get('field')
                temperature_data = self.messenger.hub[comp_t][field_t].read()[0]

            return (voltage_data / 1000.0 if voltage_data is not None else None), temperature_data
        except:
            return None

    def reboot_board(self) -> bool:
        """
        Перезагружает основную плату дрона.
        """
        try:
            if self.__board_params.get('board_reboot') is True:
                self.__print_log("-> Перезагрузка платы автопилота")
                self.messenger.hub.sendCommand(18)
                self.close_connection()
                time.sleep(5)
                self.__print_log("Перезагрузка завершена")
                return True
            else:
                self.__print_log(f"Перезагрузка платы {self.__board_params.get('board_name')} запрещена")
                return False
        except Exception as e:
            self.__print_log(f"Ошибка при перезагрузке: {e}")
            return False

    def arm(self, timeout: int = 5, retries: int = 0) -> bool:
        """
        Отдает команду на запуск моторов дрона.

        Args:
            timeout (int): Время ожидания (в секундах) для запуска моторов.
            retries (int): Количество повторных попыток ARM при неудаче (0 = без повторов).

        Returns:
            bool: True, если команда успешно выполнена, иначе False.
        """
        if not self.__check_allowed("arm"):
            self.__print_log("Команда запуска моторов проигнорирована: коптер уже в воздухе")
            return False

        try:
            attempt = 0
            while attempt < (retries + 1):
                if attempt == 0: self.__print_log("-> ARM")
                else: self.__print_log(f"Повторная попытка ARM ({attempt + 1})")

                self.messenger.hub['UavMonitor']['mode'].write(10)

                if self.wait_callback:
                    event_triggered = self.callback_events[Event.ENGINES_STARTED.value].wait(timeout=timeout)
                    if event_triggered:
                        self.__print_log("Моторы запущены")
                        self.callback_events[Event.ENGINES_STARTED.value].clear()
                        return True
                    else:
                        self.__print_log("Таймаут ожидания запуска моторов.")
                        self.disarm()
                        attempt += 1

            self.__print_log("ARM не удался. Проверьте систему навигации. Попробуйте задать большее время таймаута или количество попыток")
            return False

        except Exception:
            return False

    def disarm(self) -> bool:
        """
        Отдает команду на отключение моторов дрона.

        Returns:
            bool: True, если успешно, иначе False.
        """
        try:
            self.__print_log("-> DISARM")

            self.messenger.hub['UavMonitor']['mode'].write(2)
            self.__print_log("Двигатели остановлены")
            return True
        except:
            return False

    def land(self) -> bool:
        """
        Отдает команду на посадку дрона.

        Returns:
            bool: True, если команда успешно выполнена, иначе False.
        """
        try:
            self.__print_log("-> Посадка")

            self.messenger.hub['UavMonitor']['mode'].write(23)

            if self.wait_callback:
                self.callback_events[Event.COPTER_LANDED.value].wait()
                self.__print_log("Посадка завершена")
                self.callback_events[Event.COPTER_LANDED.value].clear()
            return True
        except:
            return False

    def takeoff(self) -> bool:
        """
        Запускает процесс взлёта и ждёт его завершения.

        Returns:
            bool: True, если успешно, иначе False.
        """
        if not self.__check_allowed("takeoff"):
            self.__print_log("Команда взлета проигнорирована: коптер уже в воздухе")
            return False

        try:
            self.__print_log("-> Взлет")

            self.messenger.hub['UavMonitor']['mode'].write(12)

            if self.wait_callback:
                self.callback_events[Event.TAKEOFF_COMPLETE.value].wait()
                self.__print_log("Взлёт завершен")
                self.callback_events[Event.TAKEOFF_COMPLETE.value].clear()

            return True
        except:
            return False

    def point_deceleration(self) -> bool:
        """
        Проверяет, замедляется ли дрон перед целевой точкой.

        Returns:
            bool: True, если замедление осуществлено, иначе False.
        """
        if self.callback_events[Event.POINT_DECELERATION.value].is_set():
            self.callback_events[Event.POINT_DECELERATION.value].clear()
            return True
        else:
            return False
        
    def point_reached(self) -> bool:
        """
        Проверяет, достиг ли дрон целевой точки.

        Returns:
            bool: True, если точка достигнута, иначе False.
        """
        if self.callback_events[Event.POINT_REACHED.value].is_set():
            self.callback_events[Event.POINT_REACHED.value].clear()
            return True
        else:
            return False

    def __invoke_go_to_global_point(self,
                                    latitude     : float,
                                    longitude    : float,
                                    altitude     : float,
                                    yaw          : int = 0,
                                    relative     : bool = False
                                   ) -> bool:
        """
        Вызывает команду перемещения к глобальной точке по координатам GPS.
        """
        callback = lambda packet: proto.listen(proto.Message.GO_TO_POINT_RESPONSE, packet)
        
        fields = {}
        if relative:
            fields['id'] = proto.Message.GO_TO_RELATIVE_POINT_V2
            fields['latitudeOffset'] = int(latitude * 1e3)
            fields['longitudeOffset'] = int(longitude * 1e3)
            fields['altitudeOffset'] = int(altitude * 1e3)
        else:
            fields['id'] = proto.Message.GO_TO_POINT_V2
            fields['latitude'] = int(latitude * 1e7)
            fields['longitude'] = int(longitude * 1e7)
            fields['altitude'] = int(altitude * 1e3)
        
        fields['sequence'] = self.__global_point_seq
        fields['yaw'] = yaw
        fields['flags'] = 32 if yaw != 0 else 0
        fields['type'] = 3
        fields['duration'] = 0
        fields['radius'] = 0
        fields['onStartedCommand'] = 0xFFFF
        fields['onReachedCommand'] = 0xFFFF

        self.__global_point_seq += 1
        if self.__global_point_seq >= 256:
            self.__global_point_seq = 0
        
        response = self.messenger.invoke(packet = fields, callback = callback)
        
        return response is None

    # CHECK
    def go_to_global_point_relative(self,
                                    latitude_offset     : float,
                                    longitude_offset    : float,
                                    altitude_offset     : float,
                                    yaw                 : int = 0
                                   ) -> bool:
        """
        Перемещает дрон к глобальной точке, заданной смещениями относительно текущего положения.
        Только для системы навигации GPS.

        Аргументы:
            latitude_offset (float): Смещение по широте в градусах относительно текущей позиции.
            longitude_offset (float): Смещение по долготе в градусах относительно текущей позиции.
            altitude_offset (float): Смещение по высоте в градусах относительно текущей позиции.
            yaw (int, по умолчанию 0): Угол рысканья (азимут) в градусах.

        Возвращает:
            bool: True, если команда успешно отправлена, иначе False.
        """
        if not self.__check_allowed("flight"):
            self.__print_log("Команда полета в точку проигнорирована: коптер еще не в воздухе")
            return False

        if self.get_nav_system() != NavSystem.GPS:
            self.__print_log("Команда может быть выполнена только когда установлена система навигации GPS")
            return False
        
        return self.__invoke_go_to_global_point(latitude_offset, longitude_offset, altitude_offset, yaw, relative=True)

    # CHECK
    def go_to_global_point(self,
                           latitude     : float,
                           longitude    : float,
                           altitude     : float,
                           yaw          : int = 0
                          ) -> bool:
        """
        Перемещает дрон к заданной глобальной точке по координатам GPS.
        Только для системы навигации GPS.

        Аргументы:
            latitude (float): Широта целевой точки в градусах.
            longitude (float): Долгота целевой точки в градусах.
            altitude (float): Высота над уровнем моря в метрах.
            yaw (int, по умолчанию 0): Угол рысканья (азимут) в градусах.

        Возвращает:
            bool: True, если команда успешно отправлена, иначе False.
        """
        if not self.__check_allowed("flight"):
            self.__print_log("Команда полета в точку проигнорирована: коптер еще не в воздухе")
            return False

        if self.get_nav_system() != NavSystem.GPS:
            self.__print_log("Команда может быть выполнена только когда установлена система навигации GPS")
            return False
        
        return self.__invoke_go_to_global_point(latitude, longitude, altitude, yaw)            

    def __invoke_go_to_local_point(self, x : float, y : float, z : float, yaw : float = None, time : int = 0, body_fixed : bool = False) -> None:
        """
        Вызывает команду перемещения к локальной точке.
        """
        fields = {}
        if self.__board_params.get('gtlp_version') == 1:
            if yaw is not None: self.set_yaw(yaw)
            if body_fixed:
                current_pos = self.get_local_position_lps()
                if current_pos is not None:
                    x = float(current_pos[0]) + x
                    y = float(current_pos[1]) + y
                    z = float(current_pos[2]) + z
                else:
                    raise ValueError("Нет информации с LPS")
            fields['id'] = proto.Message.GOTO_LOCAL_POINT
            fields['x'] = int(x * 1e3)
            fields['y'] = int(y * 1e3)
            fields['z'] = int(z * 1e3)
            fields['time'] = int(time)

        elif self.__board_params.get('gtlp_version') == 2:
            fields['id'] = proto.Message.GO_TO_LOCAL_POINT_V2
            fields['sequence'] = self.__local_point_seq
            fields['x'] = int(x * 1e3)
            fields['y'] = int(y * 1e3)
            fields['z'] = int(z * 1e3)
            fields['yaw'] = int(yaw) if yaw is not None else 0
            fields['flags'] = 0x11 if body_fixed else 0x01
            fields['type'] = 3
            fields['duration'] = 0
            fields['time'] = int(time)
            fields['radius'] = 0
            fields['onStartedCommand'] = 0xFFFF
            fields['onReachedCommand'] = 0xFFFF

            self.__local_point_seq += 1
            if self.__local_point_seq >= 256:
                self.__local_point_seq = 0
        else:
            raise ValueError("Неверная версия команды перемещения к локальной точке")

        self.messenger.invoke(packet=fields)

    def go_to_local_point_body_fixed(self, 
                                     x    : float, 
                                     y    : float, 
                                     z    : float, 
                                     yaw  : float = None, 
                                     time : int   = 0
                                    ) -> None:
        """
        Перемещает дрон к локальной точке относительно его текущей позиции.

        Args:
            x (float): Смещение по оси X в метрах.
            y (float): Смещение по оси Y в метрах.
            z (float): Смещение по оси Z в метрах.
            yaw (float): Угол рысканья в градусах.
            time (int): Желательное время достижения целевой точки. 
                Если равен 0, дрон перемещается с текущей скоростью.
        """
        if not self.__check_allowed("flight"):
            self.__print_log("Команда полета в точку проигнорирована: коптер еще не в воздухе")
            return False

        self.__invoke_go_to_local_point(x, y, z, yaw, time, body_fixed=True)
        

    def go_to_local_point(self,
                          x    : float,
                          y    : float,
                          z    : float,
                          yaw  : float = None,
                          time : int   = 0
                         ) -> None:
        """
        Перемещает дрон к локальной точке.

        Args:
            x (int): Координата X в метрах.
            y (int): Координата Y в метрах.
            z (int): Координата Z в метрах.
            yaw (float): Угол рысканья в градусах.
            time (int): Желательное время достижения целевой точки. 
                Если равен 0, дрон перемещается с текущей скоростью.
        """
        if not self.__check_allowed("flight"):
            self.__print_log("Команда полета в точку проигнорирована: коптер еще не в воздухе")
            return False
        
        self.__invoke_go_to_local_point(x, y, z, yaw, time)

    def __set_speed_fields(self,
                    vx          : float,
                    vy          : float,
                    vz          : float,
                    yaw_rate    : float,
                    interval    : float = 1.
                    ) -> None:
        """
        Устанавливает значения скоростей и интервала для ручного управления дроном.

        Args:
            vx (float): Скорость по оси X в м/с.
            vy (float): Скорость по оси Y в м/с.
            vz (float): Скорость по оси Z в м/с.
            yaw_rate (float): Скорость рысканья в град/с.
            interval (float, по умолчанию 1 секунда): Время действия команды в секундах.
        """
        try:
            self.messenger.hub['ManualControl']['interval'].write(int(interval * 1e3), blocking=False)
            self.messenger.hub['ManualControl']['northSpeed'].write(int(vy * 1e2), blocking=False)
            self.messenger.hub['ManualControl']['eastSpeed'].write(int(vx * 1e2), blocking=False)
            self.messenger.hub['ManualControl']['downSpeed'].write(-int(vz * 1e2), blocking=False)
            self.messenger.hub['ManualControl']['yawSpeed'].write(int(yaw_rate * 1e2), blocking=False)
        except:
            pass
    
    def set_manual_speed(self,
                         vx          : float,
                         vy          : float,
                         vz          : float,
                         yaw_rate    : float,
                         interval    : float = 1.
                        ) -> None:
        """
        Полёт с заданной скоростью относительно системы координат.

        Args:
            vx (float): Скорость по оси X в м/с.
            vy (float): Скорость по оси Y в м/с.
            vz (float): Скорость по оси Z в м/с.
            yaw_rate (float): Скорость рысканья в рад/с.
            interval (float, по умолчанию 1 секунда): Время в секундах, в течение которого команда управления скоростью считается активной.
        """
        if not self.__check_allowed("flight"):
            self.__print_log("Команда установки скорости проигнорирована: коптер еще не в воздухе")

        try:
            if abs(yaw_rate) > 1.82:
                raise ValueError("-> Скорость рысканья не должна превышать 1.82 рад/с")
            yaw_rate = math.degrees(yaw_rate)
            self.messenger.hub['ManualControl']['mode'].write(_ManualSpeedMode.GLOBAL.value, blocking=False)
            self.__set_speed_fields(vx, vy, vz, yaw_rate, interval)
        except:
            pass

    def set_manual_speed_body_fixed(self,
                                    vx          : float,
                                    vy          : float,
                                    vz          : float,
                                    yaw_rate    : float,
                                    interval    : float = 1.
                                    ) -> None:
        """
        Полёт с заданной скоростью относительно текущей позиции дрона.

        Args:
            vx (float): Скорость по оси X в м/с.
            vy (float): Скорость по оси Y в м/с.
            vz (float): Скорость по оси Z в м/с.
            yaw_rate (float): Скорость рысканья в рад/с.
            interval (float, по умолчанию 1 секунда): Время в секундах, в течение которого команда управления скоростью считается активной.
        """
        if not self.__check_allowed("flight"):
            self.__print_log("Команда установки скорости проигнорирована: коптер еще не в воздухе")

        try:
            if abs(yaw_rate) > 1.82:
                raise ValueError("-> Скорость рысканья не должна превышать 1.82 рад/с")
            yaw_rate = math.degrees(yaw_rate)
            self.messenger.hub['ManualControl']['mode'].write(_ManualSpeedMode.BODY_FIXED.value, blocking=False)
            self.__set_speed_fields(vx, vy, vz, yaw_rate, interval)
        except:
            pass

    def set_yaw(self, yaw: float) -> bool:
        """
        Устанавливает угол рыскания (yaw).

        Args:
            yaw (float): Угол рыскания в градусах.

        Returns:
            bool: True, если успешно, иначе False.
        """
        if not self.__check_allowed("flight"):
            self.__print_log("Команда установки угла проигнорирована: коптер еще не в воздухе")
            return False

        try:
            yaw = math.radians(yaw)
            self.messenger.hub['ManualControl']['yawManual'].write(int(yaw * 100.0))
            return True
        except:
            return False

    def rtl(self) -> bool:
        """
        Возвращение домой (Return To Launch).

        Returns:
            bool: True, если успешно, иначе False.
        """
        try:
            self.messenger.hub['UavMonitor']['mode'].write(18)
            return True
        except:
            return False
    
    
    def rc_sdk1_to_sdk2(self, channel_1 = 0, channel_2 = 0, channel_3 = 0, channel_4 = 0, channel_5 = 2000):
        """
        Конвертация RC каналов из SDK1 в SDK2.

        Args:
            channel_1-4 (float): Значения каналов SDK1
            channel_5 (float): Значение канала режима SDK1

        Returns:
            tuple[float, float, float, float, float]: Значения каналов SDK2
        """
        channel_1 = channel_4 - 1500 / 500
        channel_2 = channel_3 - 1500 / 500
        channel_3 = channel_1 - 1500 / 500
        channel_4 = channel_2 - 1500 / 500
        if channel_5 == 2000:
            channel_5 = 1
        else:
            channel_5 = 0
        return channel_1, channel_2, channel_3, channel_4, channel_5


    def send_rc_channels(self, channel_1 : float = 0, 
                               channel_2 : float = 0, 
                               channel_3 : float = 0, 
                               channel_4 : float = 0,
                               channel_5 : float = 1, 
                               channel_6 : float = 0, 
                               channel_7 : float = 1, 
                               channel_8 : float = 0):
        """
        Отправка RC каналов.
        Требуется постоянная отправка RC каналов для поддержания связи.

        Args:
            channel_1 (float): RC канал 1. Правый джойстик -1 влево   0 вправо  1        f
            channel_2 (float): RC канал 2. Правый джойстик -1 вперед  0 назад   1        f
            channel_3 (float): RC канал 3. Левый  джойстик -1 вниз    0 вверх   1        f
            channel_4 (float): RC канал 4. Левый  джойстик  1 влево   0 вправо -1        f
            channel_5 (float): RC канал 5. Режим управления
            channel_6 (float): RC канал 6.
            channel_7 (float): RC канал 7.
            channel_8 (float): RC канал 8.
        """
        ch = [
            channel_1 * 32760,
            channel_2 * 32760,
            channel_3 * 32760,
            channel_4 * 32760,
            channel_5 * 32767,
            channel_6 * 32767,
            channel_7 * 32767,
            channel_8 * 32767,
        ]
        ch = [int(x) for x in ch]
        fields = {}
        fields['id'] = proto.Message.MANUAL_CONTROL
        fields['channel'] = ch
        try:
            self.messenger.invoke(packet=fields)
            return True
        except:
            return False
        
    def get_rc_channel(self) -> int | None:
        """
        Возвращает значение RC-канала.

        Returns:
            int | None: Значение RC-канала или None, если произошла ошибка.
        """
        try:
            rc_config = self.__board_params.get('rc')
            comp = rc_config.get('comp')
            rc_field = rc_config.get('field')
            return self.messenger.hub[comp][rc_field].read()[0]
        except:
            return None
        
    def set_rc_trigger(self, callback : callable) -> None:
        """
        Устанавливает функцию обратного вызова для триггера RC-канала.

        Args:
            callback (callable): Функция обратного вызова, которая будет вызвана при срабатывании триггера.
        """
        try:
            rc_config = self.__board_params.get('rc')
            watcher = {}
            watcher['comp'] = rc_config.get('comp')
            watcher['field'] = rc_config.get('field')
            watcher['callback'] = callback
            watcher['last_value'] = None # Добавляем последнее известное значение
            self.field_watcher.append(watcher)
        except:
            pass
        
    def get_accel(self) -> tuple[float, float, float] | None:
        """
        Возвращает ускорение дрона по осям X, Y и Z.

        Returns:
            tuple[float, float, float] | None: Ускорение по осям или None, если ошибка.
        """       
        try:
            ax = self.messenger.hub['SensorMonitor']['accelX'].read()[0]
            ay = self.messenger.hub['SensorMonitor']['accelY'].read()[0]
            az = self.messenger.hub['SensorMonitor']['accelZ'].read()[0]
            return (ax / 1e3, ay / 1e3, az / 1e3)
        except:
            return None

    def get_gyro(self) -> tuple[float, float, float] | None:
        """
        Возвращает угловую скорость дрона.

        Returns:
            tuple[float, float, float] | None: Угловая скорость по осям X, Y, Z в рад/с 
                или None, если ошибка.
        """
        try:
            gx = self.messenger.hub['SensorMonitor']['gyroX'].read()[0]
            gy = self.messenger.hub['SensorMonitor']['gyroY'].read()[0]
            gz = self.messenger.hub['SensorMonitor']['gyroZ'].read()[0]
            return (gx / 1e3, gy / 1e3, gz / 1e3)
        except:
            return None

    def get_mag(self) -> tuple[float, float, float] | None:
        """
        Возвращает показания магнитометра по осям X, Y и Z.

        Returns:
            tuple[float, float, float] | None: Кортеж с угловой скоростью по осям X, Y и Z 
                или None, если ошибка.
        """
        try:
            mx = self.messenger.hub['SensorMonitor']['magX'].read()[0]
            my = self.messenger.hub['SensorMonitor']['magY'].read()[0]
            mz = self.messenger.hub['SensorMonitor']['magZ'].read()[0]
            return (mx / 1e3, my / 1e3, mz / 1e3)
        except:
            return None

    def get_altitude(self) -> float | None:
        """
        Возвращает высоту дрона.

        Returns:
            float | None: Высота в метрах или None, если ошибка.
        """
        try:
            altitude = self.messenger.hub['UavMonitor']['altitude'].read()[0]
            return altitude / 1e3
        except:
            return None

    def get_orientation(self) -> tuple[float, float, float] | None:
        """
        Возвращает ориентацию дрона по углу крена(roll), тангажа(pitch), рыскания(yaw).

        Returns:
            tuple[float, float, float] | None: Кортеж с ориентацией дрона по углу крена (roll), 
                тангажа (pitch) и рыскания (yaw) или None, если ошибка.
        """
        try:
            roll = self.messenger.hub['UavMonitor']['roll'].read()[0]
            pitch = self.messenger.hub['UavMonitor']['pitch'].read()[0]
            yaw = self.messenger.hub['UavMonitor']['yaw'].read()[0]
            return (roll / 1e2, pitch / 1e2, yaw / 1e2)
        except:
            return None

    def get_dist_sensor_data(self) -> float | None:
        """
        Возвращает дальность оптического сенсора.

        Returns:
            float | None: Дальность в метрах или None, если ошибка.
        """
        try:
            alt = self.messenger.hub['SensorMonitor']['range'].read()[0]
            return alt / 1e3
        except:
            return None
        
    def get_local_position_lps(self) -> tuple[float, float, float] | None:
        """
        Возвращает позицию дрона в локальной системе координат.

        Returns:
            tuple[int, int, int] | None: Позиция по осям X, Y, Z в метрах или None, если ошибка.
        """ 
        if self._current_lps is not None:
            try:
                x = self.messenger.hub[self._current_lps]['x'].read()[0]
                y = self.messenger.hub[self._current_lps]['y'].read()[0]
                z = self.messenger.hub[self._current_lps]['z'].read()[0]
                return (x / 1e3, y / 1e3, z / 1e3)
            except:
                pass
        self.__print_log("Модуль локальной навигации не установлен")
        return None

    def get_local_velocity_lps(self) -> tuple[float, float, float] | None:
        """
        Возвращает скорость дрона в локальной системе координат.

        Returns:
            tuple[float, float, float] | None: Скорость по осям X, Y, Z в м/с или None, если ошибка.
        """
        if self._current_lps is not None:
            try:
                x = self.messenger.hub[self._current_lps]['velX'].read()[0]
                y = self.messenger.hub[self._current_lps]['velY'].read()[0]
                z = self.messenger.hub[self._current_lps]['velZ'].read()[0]
                return (x / 1e3, y / 1e3, z / 1e3)
            except:
                pass
        self.__print_log("Модуль локальной навигации не установлен")   
        return None
        
    def get_local_yaw_lps(self) -> float | None:
        """
        Возвращает текущий угол рыскания (yaw).

        Returns:
            float | None: Угол рыскания в градусах (-180.0; +180.0) или None, если ошибка.
        """
        if self._current_lps is not None:
            try:
                yaw = self.messenger.hub[self._current_lps]['yaw'].read()[0]
                return yaw / 1e2
            except:
                pass
        self.__print_log("Модуль локальной навигации не установлен")   
        return None

    def get_nav_status_lps(self) -> NavStatus | None:
        """
        Возвращает статус системы локальной навигации.

        Returns:
            NavStatusLPS | None: Статус системы навигации дрона или None, если ошибка.
        """
        if self._current_lps is not None:
            try:
                return NavStatus(self.messenger.hub[self._current_lps]['status'].read()[0])
            except:
                pass
        self.__print_log("Модуль локальной навигации не установлен")
        return None

    def get_optical_data(self) -> tuple[int, int, float] | None:
        """
        Возвращает данные оптического потока.

        Returns:
            tuple[int, int, float] | None: данные оптического потока или None, если ошибка.
        """
        try:
            opt_flow_x = self.messenger.hub['SensorMonitor']['optFlowX'].read()[0]
            opt_flow_y = self.messenger.hub['SensorMonitor']['optFlowY'].read()[0]
            range = self.messenger.hub['SensorMonitor']['range'].read()[0]
            return (opt_flow_x, opt_flow_y, range / 1e3)
        except:
            return None

    def get_global_position_gps(self) -> tuple[float, float, float] | None:
        """
        Возвращает текущие глобальные координаты дрона по данным GPS.
        Только для системы навигации GPS.

        Returns:
            tuple[float, float, float] | None: Кортеж (широта, долгота, высота) в градусах и метрах,
            либо None, если модуль навигации не установлен.
        """
        try:
            if self._current_gnss is not None:
                lat = self.messenger.hub[self._current_gnss]['latitude'].read()[0]
                lon = self.messenger.hub[self._current_gnss]['longitude'].read()[0]
                alt = self.messenger.hub[self._current_gnss]['altitude'].read()[0]
                return (lat / 1e7, lon / 1e7, alt / 1e3)
        except:
            pass
        self.__print_log("Модуль навигации не установлен")
        return None

    def get_global_velocity_gps(self) -> tuple[float, float, float] | None:
        """
        Возвращает скорость дрона в системе координат GPS. Только для системы навигации GPS.

        Returns:
            tuple[float, float, float] | None: Северная скорость, восточная скорость, вертикальная скорость в м/с или None, если ошибка.
        """
        if self._current_gnss is not None:
            try:
                    vel_north = self.messenger.hub[self._current_gnss]['velNorth'].read()[0]
                    vel_east = self.messenger.hub[self._current_gnss]['velEast'].read()[0]
                    vel_down = self.messenger.hub[self._current_gnss]['velDown'].read()[0]
                    return (vel_north / 1e2, vel_east / 1e2, vel_down / 1e2)
            except:
                pass
        self.__print_log("Модуль навигации не установлен")
        return None

    def get_satellites_count(self) -> tuple[int, int] | None:
        """
        Возвращает количество спутников GPS и ГЛОНАСС, видимых дрону.
        Только для системы навигации GPS.

        Returns:
            tuple[int, int] | None: Кортеж (число GPS-спутников, число ГЛОНАСС-спутников),
            либо None, если модуль навигации не установлен.
        """
        if self._current_gnss is not None:
            try:
                sat_gps = self.messenger.hub[self._current_gnss]['satGps'].read()[0]
                sat_glonass = self.messenger.hub[self._current_gnss]['satGlonass'].read()[0]
                return (sat_gps, sat_glonass)
            except:
                pass
        self.__print_log("Модуль навигации не установлен")
        return None

    def get_nav_status_gps(self) -> NavStatus | None:
        """
        Возвращает статус системы навигации GPS. Только для системы навигации GPS.

        Returns:
            NavStatusLPS | None: Статус системы навигации дрона или None, если ошибка.
        """
        if self._current_gnss is not None:
            try:
                return NavStatus(self.messenger.hub[self._current_gnss]['status'].read()[0])
            except:
                pass
        self.__print_log("Модуль навигации не установлен")
        return None

    def get_ranger_data(self) -> tuple[float, float, float, float, float] | tuple[None, None, None, None, None]:
        """
        Возвращает данные с дальномеров модуля Ranger.

        Returns:
            tuple[float, float, float, float, float] | tuple[None, None, None, None, None]:
                Кортеж из пяти значений (в метрах): 
                (право, лево, вперед, назад, сверху/снизу).
                Если модуль не поддерживается или не установлен — кортеж из None.
        """
        if self.__board_params.get('ranger'):
            try:
                ranger_right = self.messenger.hub['RangerModule']['RanegeRight'].read()[0]
                ranger_left = self.messenger.hub['RangerModule']['RanegeLeft'].read()[0]
                ranger_front = self.messenger.hub['RangerModule']['RanegeFront'].read()[0]
                ranger_back = self.messenger.hub['RangerModule']['RanegeBack'].read()[0]
                ranger_above_below = self.messenger.hub['RangerModule']['RanegeAbove/Below'].read()[0]
                return (
                    ranger_right / 1e3,
                    ranger_left / 1e3,
                    ranger_front / 1e3,
                    ranger_back / 1e3,
                    ranger_above_below / 1e3
                )
            except:
                self.__print_log("Модуль Ranger не установлен")
        else:
            self.__print_log("Модуль Ranger не поддерживается")
        return (None, None, None, None, None)
    
    def __on_fields_changed(self, device: str, fields: list[str]) -> None:
        """        
        Метод вызывается автоматически при изменении определенных внутренний состояний дрона и выполняет:
        1. Обработку событий автопилота (взлет, посадка, запуск моторов и т.д.)
        2. Обновление внутреннего состояния полета для контроля допустимых команд
        3. Уведомление подписчиков о произошедших событиях
        4. Отслеживание состояния дрона по режиму работы

        Args:
            device (str): Название устройства.
            fields (list[str]): Список измененных полей.
        """
        device_object = self.messenger.hub[device]
        if device_object.name == 'FlightManager':
            if len(fields) > 0 and device_object[fields[0]].name == 'event':
                ev = Event(device_object['event'].value)

                if ev != Event.NULL:
                    device_object['event'].write(value=ev.value, callback=None, blocking=False)

                    self.callback_events[ev.value].set()

                    if ev == Event.ENGINES_STARTED:
                        self.__current_fly_state = FlyState.ARMED
                    elif ev == Event.TAKEOFF_COMPLETE:
                        self.__current_fly_state = FlyState.IN_SKY
                    elif ev == Event.COPTER_LANDED or ev == Event.SHOCK:
                        self.__current_fly_state = FlyState.ON_LAND

                    for watcher in self.watchers:
                        if watcher[0] == Event.ALL or watcher[0] == ev:
                            watcher[1](ev)
        
        elif device_object.name == 'UavMonitor':
            if len(fields) > 0 and device_object[fields[0]].name == 'mode':
                if device_object[fields[0]].value == 2:
                    self.__current_fly_state = FlyState.ON_LAND

    def get_fly_state(self) -> FlyState:
        """
        Возвращает текущее состояние полета дрона.
        
        Returns:
            FlyState: Текущее состояние полета (ON_LAND, ARMED или IN_SKY).
        """
        return self.__current_fly_state

    def subscribe(self, callback: callable, event: Event = Event.ALL) -> None:
        """
        Подписывается на событие.

        Args:
            callback (callable): Функция обратного вызова.
            event (Event): Номер события для подписки.
        """
        self.watchers.append((event, callback))

    def unsubscribe(self, callback: callable, event: Event = Event.ALL) -> None:
        """
        Отписывается от события. Команда позволяет подписаться на определенные события дрона. 
            Если событие происходит, вызывается указанный обратный вызов (callback). 

        Args:
            callback (callable): Функция обратного вызова.
            event (Event): Номер события для отписки. По умолчанию Event.ALL (255).
        """
        for i, watcher in enumerate(self.watchers):
            if watcher[0] == event and watcher[1] == callback:
                del self.watchers[i]
                break
    
    def _field_watcher_loop(self) -> None:
        """
        Отдельный поток для периодического чтения значений полей и вызова колбэков.
        """
        while not self._stop_field_watcher_thread.is_set():
            try:
                for watcher in list(self.field_watcher):
                    try:
                        comp = watcher['comp']
                        field = watcher['field']
                        callback = watcher['callback']
                        current_value = self.messenger.hub[comp][field].read()[0]

                        if current_value != watcher['last_value']:
                            callback(current_value)
                            watcher['last_value'] = current_value
                    except Exception as e:
                        self.__print_log(f"-> Ошибка при чтении поля или вызове колбэка: {e}")
            except Exception as e:
                self.__print_log(f"-> Общая ошибка в цикле чтения полей: {e}")
            self._stop_field_watcher_thread.wait(0.1)

    def led_control(self, led_id : int = 255, r : float = 0., g : float = 0., b : float = 0.) -> bool:
        """
        Устанавливает цвет для указанного светодиода или всех светодиодов.

        Args:
            led_id (int): Номер светодиода. Если 255, устанавливается для всех всех светодиодов.
            r (float): Значение красного цвета от 0 до 1.
            g (float): Значение зеленого цвета от 0 до 1.
            b (float): Значение синего цвета от 0 до 1.

        Returns:
            bool: True, если успешно, иначе False.
        """
        
        if led_id > 255 or led_id < 0:
            raise ValueError("led_id должен быть в диапазоне от 0 до 255 включительно.")

        clamp = lambda v: min(max(int(v), 0), 255)
        r = clamp(r * 255.0)
        g = clamp(g * 255.0)
        b = clamp(b * 255.0)

        try:
            # Необходимо проверять имя платы, а не тип,
            # потому что параметр Board*_type для mini2 уникален не во всех версиях автопилота.
            if self.__board_params['board_name'] == 'Pioneer Mini 2':
                self.messenger.hub['LedModule']['RedBrightness'].write(r)
                self.messenger.hub['LedModule']['GreenBrightness'].write(g)
                self.messenger.hub['LedModule']['BlueBrightness'].write(b)
            else:
                value = r | (g << 8) | (b << 16)
                value = value | clamp(led_id) << 24
                self.messenger.hub['LedBar']['color'].write(value)
            return True
        except:
            return False

    def __get_autopilot_params_id(self):
        """
        Возвращает словарь с параметрами автопилота типа {name: id}.

        Returns:
            dict: Словарь с параметрами автопилота.
        """
        self.__print_log('-> Загрузка словаря автопилота ...')
        autopilot_params_id = {}
        try:
            for i in range(self.messenger.hub.getParamCount()):
                name, _ = self.messenger.hub.getParam(i)
                autopilot_params_id[name] = i
            return autopilot_params_id
        except:
            return autopilot_params_id
        
    def get_param(self, name: str, update = False) -> float | None:
        """
        Возвращает значение параметра автопилота.

        Args:
            name (str): Имя параметра.
            update (bool): Если True, принудительно обновит значение параметра из автопилота, иначе вернет кэшированное значение.

        Returns:
            float | None: Значение параметра или None, если ошибка.
        """
        # Если словарь [id : название параметра автопилота] не загружен, 
        # то загружаем его
        if (self.__autopilot_params_id is None) or update:
            self.__autopilot_params_id = self.__get_autopilot_params_id()

        try:
            if name in self.__autopilot_params_id:
                _, value = self.messenger.hub.getParam(self.__autopilot_params_id[name])
                return value
        except:
            pass
        self.__print_log(f"-> Параметр {name} не найден")
        return None

    def set_param(self, name : str, value : float | int) -> bool:
        """
        Устанавливает значение параметра автопилота.

        Args:
            name (str): Имя параметра.
            value (float | int): Значение параметра.

        Returns:
            bool: True, если успешно, иначе False.
        """
        try:
            if self.__autopilot_params_id is None:
                self.__autopilot_params_id = self.__get_autopilot_params_id()

            if name in self.__autopilot_params_id:
                self.__print_log(f"-> Установка параметра: {name} {value}")
                self.messenger.hub.setParam(name = name, value = float(value))
                return True
        except:
            pass
        self.__print_log(f"-> Установка параметра {name} не удалась")
        return False

    def get_nav_system(self, update = False) -> NavSystem:
        """
        Возвращает текущую систему навигации дрона.
        
        Args:
            update (bool): Если True, принудительно обновит значение параметра из автопилота, иначе вернет кэшированное значение.
            
        Returns:
            NavSystem: Текущая система навигации (GPS, LPS или OPT).
        """
        if (self._nav_system is None) or update:
            self._nav_system = NavSystem(self.get_param('Flight_com_navSystem', update))
        return self._nav_system
    
    def get_motors_rpm(self) -> list[float | None]:
        """
        Возвращает текущие обороты каждого из 4 двигателей дрона.

        Returns:
            list[float | None]: Список из 4 значений оборотов (RPM) для каждого двигателя, 
                или None для каждого двигателя, если произошла ошибка.
        """
        try:
            return [
                self.messenger.hub['Actuators'][f'rpmMotor{i}'].read()[0]
                for i in range(4)
            ]
        except:
            return [None for _ in range(4)]

    def _grab_move(self, state: int, movement_time: float = 0, velocity: int = 100) -> bool:
        """Общая логика открытия (state=1) или закрытия (state=2) захвата."""
        try:
            if not self.__board_params.get('grab'):
                self.__print_log("-> Модуль захвата не поддерживается")
                return False
            if velocity > 100 or velocity < 0:
                self.__print_log("-> Скорость должна быть в диапазоне от 0 до 100 включительно")
                raise ValueError("-> Скорость должна быть в диапазоне от 0 до 100 включительно")
            self.messenger.hub['GrabModule']['VelocityValue, %'].write(velocity, blocking=False)
            self.messenger.hub['GrabModule']['MovementTime, ms'].write(int(movement_time * 1e3), blocking=False)
            self.messenger.hub['GrabModule']['MovementState'].write(state, blocking=False)
            if movement_time > 0:
                time.sleep(movement_time)
            return True
        except:
            self.__print_log("-> Ошибка при работе захвата. Или модуль не установлен.")
            return False

    def grab_close(self, movement_time: float = 0, velocity: int = 100) -> bool:
        """
        Закрывает захват.

        Args:
            movement_time (float, по умолчанию 0): Время движения в секундах. Если 0, закрытие до упора.
            velocity (int, по умолчанию 100): Скорость движения в процентах.

        Returns:
            bool: True, если успешно, иначе False.
        """
        return self._grab_move(2, movement_time, velocity)

    def grab_open(self, movement_time: float = 0, velocity: int = 100) -> bool:
        """
        Открывает захват.

        Args:
            movement_time (float, по умолчанию 0): Время движения в секундах. Если 0, открытие до упора.
            velocity (int, по умолчанию 100): Скорость движения в процентах.

        Returns:
            bool: True, если успешно, иначе False.
        """
        return self._grab_move(1, movement_time, velocity)

    def grab_stop(self) -> bool:
        """Останавливает движение захвата."""
        try:
            if not self.__board_params.get('grab'):
                self.__print_log("-> Модуль захвата не поддерживается")
                return False
            self.messenger.hub['GrabModule']['MovementState'].write(0, blocking=False)
            return True
        except Exception:
            self.__print_log("-> Ошибка при остановке захвата. Или модуль не установлен.")
            return False

    def cargo_set(self, grab: bool) -> bool:
        """
        Устанавливает состояние магнитного захвата груза (вкл/выкл).

        Args:
            grab (bool): True — включить, False — выключить.

        Returns:
            bool: True, если успешно, иначе False.
        """
        try:
            if not self.__board_params.get('cargo'):
                self.__print_log("-> Модуль магнитного захвата груза не поддерживается")
                return False
            self.messenger.hub['LedBar']['cargo'].write(int(grab))
            return True
        except Exception:
            self.__print_log("-> Ошибка при установке состояния магнитного захвата груза. Или модуль не установлен.")
            return False

    def cargo_grab(self) -> bool:
        """Включает магнитный захват груза."""
        return self.cargo_set(True)

    def cargo_release(self) -> bool:
        """Выключает магнитный захват груза."""
        return self.cargo_set(False)