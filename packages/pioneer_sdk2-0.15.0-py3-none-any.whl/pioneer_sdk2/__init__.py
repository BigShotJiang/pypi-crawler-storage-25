from .config import CONFIG, ConfigException
from .piosdk2 import Pioneer, Event

if CONFIG is not None:
    from .camera_driver.base import CameraType
    if CONFIG['cameras']['driver'] == 'gstreamer':
        from .camera_driver.gstreamer import GstreamerCamera as Camera, ImageViewer

        if CONFIG['cameras']['recorder']:
            from .camera_driver.gstreamer import RecorderControl, RecordingConfig
    elif CONFIG['cameras']['driver'] == 'rtsp':
        from .camera_driver.rtsp import RtspCamera as Camera

    if CONFIG['servo'] is not None:
        try:
            from .modules.servo import ServoPriority, ServoCamera
        except Exception:
            raise ConfigException("Для вашей версии SDK данный модуль не поддерживается")
    if CONFIG['flashlight']:
        try:
            from .modules.flashlight import Flashlight
        except Exception:
            raise ConfigException("Для вашей версии SDK данный модуль не поддерживается")
else:
    raise ConfigException("Не удалось загрузить конфигурацию SDK. Проверьте, что файл board_config.json находится в директории pioneer_sdk2")