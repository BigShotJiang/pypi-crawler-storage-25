import gi
gi.require_version('Gst', '1.0')
from gi.repository import Gst, GLib
import cv2
import numpy as np
import threading
import time
import random
import string
from collections import deque
from ..config import CONFIG
from .base import AbstractDriver, CameraType
import subprocess
from pathlib import Path
from dataclasses import dataclass
from time import sleep
import os

@dataclass
class RecordingConfig:
    """
    Параметры кадра (ширина, высота, fps) для программного потока, записи и фото.
    """
    width: int
    height: int
    fps: int

class GstreamerCamera(AbstractDriver):
    """Класс для захвата видеокадров из GStreamer и предоставления их через очередь."""
    def __init__(self, camera_type = CameraType.MAIN) -> None:
        """Инициализирует объект Camera.

        Args:
            camera_type (CameraType): Тип камеры для захвата (MAIN или OPT).
        """
        Gst.init(None)
        self.camera_type = camera_type
        self.name  = CONFIG["cameras"][camera_type.value]["name"]
        self.recording_config = self._get_config_for_program(camera_type)
        self.pipeline = None
        self.appsink = None
        self.running = False

        self.__frame_buffer = deque(maxlen=1)
        self.__frame_condition = threading.Condition()

        self._setup_pipeline()
        self._start()

    def _setup_pipeline(self):
        """Настраивает GStreamer-пайплайн для захвата кадров."""
        random_prefix = ''.join(random.choice(string.ascii_lowercase) for _ in range(6))

        # f"queue max-size-buffers=1 leaky=downstream ! " всегда держим только последний кадр.
        # Если камер несколько, то буфер первой инициализированной заполняется быстрее,
        # поэтому без этого шага пайплайна появляется задержка на одной из них.

        pipeline_str = (
            f"shmsrc socket-path=/tmp/{self.name} do-timestamp=true ! "
            f"queue max-size-buffers=1 leaky=downstream ! "
            f"video/x-raw,format=NV12,width={self.recording_config.width},height={self.recording_config.height},framerate={self.recording_config.fps}/1 ! "
            f"videoconvert ! video/x-raw,format=BGR ! appsink name={self.camera_type.value}_{random_prefix} emit-signals=true sync=false"
        )
        self.pipeline = Gst.parse_launch(pipeline_str)
        self.appsink = self.pipeline.get_by_name(f"{self.camera_type.value}_{random_prefix}")
        self.appsink.set_property("max-buffers", 5)
        self.appsink.set_property("drop", True)
        self.appsink.connect("new-sample", self._on_sample)

    def _on_sample(self, sink):
        """Обрабатывает новые образцы от appsink.

        Args:
            sink (Gst.AppSink): appsink элемент, вызывающий new-sample.

        Returns:
            Gst.FlowReturn: OK при успешном захвате кадра, ERROR в случае ошибки.
        """
        sample = sink.emit("pull-sample")
        buffer = sample.get_buffer()
        
        success, map_info = buffer.map(Gst.MapFlags.READ)
        if not success:
            return Gst.FlowReturn.ERROR
        
        try:
            frame = np.frombuffer(map_info.data, dtype=np.uint8)
            frame = frame.reshape(self.recording_config.height, self.recording_config.width, 3)
            with self.__frame_condition:
                self.__frame_buffer.append(frame.copy())
                self.__frame_condition.notify_all()
        finally:
            buffer.unmap(map_info)
            
        return Gst.FlowReturn.OK

    def _start(self):
        """Запускает GStreamer-пайплайн и поток для GLib MainLoop."""
        self.pipeline.set_state(Gst.State.PLAYING)
        self.running = True
        self.thread = threading.Thread(target=self._gst_loop)
        self.thread.start()

    def _gst_loop(self):
        """Запускает цикл обработки сообщений GStreamer."""
        self.loop = GLib.MainLoop()
        self.loop.run()

    def _get_config_for_program(self, camera_type: CameraType) -> RecordingConfig:
        """Возвращает конфигурацию для программного видеопотока выбранной камеры.

        Args:
            camera_type (CameraType): Тип камеры.

        Returns:
            RecordingConfig: Параметры кадра для программного потока.

        Raises:
            ValueError: Если не найден режим с `program=true` для камеры.
        """
        resolutions = CONFIG["cameras"][camera_type.value]["resolutions"]
        program_resolutions = [
            RecordingConfig(width=mode["width"], height=mode["height"], fps=mode["fps"])
            for mode in resolutions
            if mode["program"]
        ]
        if not program_resolutions:
            raise ValueError(f"Не найдена конфигурация для программного потока для камеры {camera_type.value}")
        return program_resolutions[0]

    def get_cv_frame(self, timeout: float = 5.0) -> np.ndarray:
        """Возвращает следующий доступный кадр из очереди.

        Args:
            timeout (float): Время ожидания в секундах.

        Returns:
            np.ndarray: кадр в формате BGR.

        Raises:
            TimeoutError: Если кадр не был получен в течение указанного таймаута.
        """
        with self.__frame_condition:
            if not self.__frame_condition.wait_for(lambda: len(self.__frame_buffer) > 0, timeout=timeout):
                raise TimeoutError(f"Не удалось получить кадр в течение {timeout} секунд. Проверьте исправность камеры/media-server.")
            return self.__frame_buffer.pop()

    def stop(self):
        """Останавливает GStreamer-пайплайн и завершает поток захвата."""
        self.running = False
        self.pipeline.set_state(Gst.State.NULL)
        self.loop.quit()
        self.thread.join()

    def __del__(self) -> None:
        """ 
        Очищает ресурсы при удалении объекта.
        """
        self.stop()

class ImageViewer:
    """Класс для трансляции numpy-кадров по RTSP через GStreamer."""
    def __init__(self):
        """Инициализирует GStreamer и подготовку для хранения потоков."""
        Gst.init(None)
        self.streams = {}
        self.start_time = time.time()
        self.frame_count = {}
        
    def _create_stream(self, name: str, width: int, height: int, fps: int = 30):
        """Создаёт и запускает новый RTSP-поток.

        Args:
            name (str): идентификатор потока.
            width (int): ширина кадра.
            height (int): высота кадра.
            fps (int): частота кадров.
        """
        pipeline_str = (
            f"appsrc name=source_{name} is-live=true block=true format=TIME"
            ' ! videoconvert ! video/x-raw,format=I420' + \
            ' ! mpph264enc profile=100 bps=4000000 bps-max=5000000 bps-min=3000000 rc-mode=0 header-mode=1 ' + \
            f"! rtspclientsink location=rtsp://localhost:8554/{name}"
        )
        pipeline = Gst.parse_launch(pipeline_str)
        appsrc = pipeline.get_by_name(f"source_{name}")
        appsrc.set_property("caps", Gst.Caps.from_string(
            f"video/x-raw,format=BGR,width={width},height={height},framerate={fps}/1"
        ))
        pipeline.set_state(Gst.State.PLAYING)
        self.streams[name] = (pipeline, appsrc)
        self.frame_count[name] = 0
        
    def imshow(self, name: str, frame: np.ndarray, fps: int = 30):
        """Отправляет кадр в соответствующий RTSP-поток.

        Args:
            name (str): идентификатор потока.
            frame (np.ndarray): изображение в формате BGR для трансляции.
            fps (int): кадров в секунду при передаче видео (по умолчанию 30)
        """
        if name not in self.streams:
            self._create_stream(name, frame.shape[1], frame.shape[0], fps)
            
        _, appsrc = self.streams[name]
        data = frame.tobytes()
        buffer = Gst.Buffer.new_allocate(None, len(data), None)
        buffer.fill(0, data)

        duration = Gst.util_uint64_scale_int(1, Gst.SECOND, fps)
        timestamp = self.frame_count[name] * duration

        buffer.pts = timestamp
        buffer.dts = timestamp
        buffer.duration = duration

        self.frame_count[name] += 1
        appsrc.emit("push-buffer", buffer)
        
    def close(self):
        """
        Уничтожает все gstreamer пайплайны.
        """
        for name, (pipeline, _) in self.streams.items():
            pipeline.set_state(Gst.State.NULL)
        self.streams.clear()

    def __del__(self) -> None:
        """ 
        Очищает ресурсы при удалении объекта.
        """
        self.close()

class RecorderControl:
    """
    Управляет записью видео и съемкой фото через `pm2-jmp-camera-control`.
    """
    ALLOWED_PHOTO_EXT = {".jpg", ".jpeg", ".png"}

    def __init__(self) -> None:
        """
        Инициализирует объект RecorderControl.
        
        Raises:
            ValueError: Если запись фото и видео не поддерживается на этом устройстве. Установите пакет pm2-jmp-camera-control.
        """

        if not self.__check_pm2_jmp_camera_control():
            raise ValueError("Запись фото и видео не поддерживается на этом устройстве. Установите пакет pm2-jmp-camera-control.")

        self.__recording_configs : dict[CameraType, list[RecordingConfig]] = {}
        for camera_type in CameraType:
            self.__recording_configs[camera_type] = self.__read_camera_recording_configs(camera_type)

    def __run_command_raw(self, command: list[str]) -> subprocess.CompletedProcess[str]:
        """
        Выполняет сырую CLI-команду `pm2-jmp-camera-control`.

        Args:
            command (list[str]): Аргументы команды без имени бинарника.

        Returns:
            subprocess.CompletedProcess[str]: Результат выполнения процесса.
        """
        cmd = ["pm2-jmp-camera-control"] + command
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result

    def _run_camera_cmd(self, *args: str) -> str | None:
        """Выполняет команду управления камерой и валидирует код возврата.

        Args:
            *args (str): Аргументы команды.

        Returns:
            str | None: `stdout` без пробелов по краям или `None`, если вывод пустой.

        Raises:
            RuntimeError: Если команда завершилась с ошибкой.
        """
        result = self.__run_command_raw(list(args))
        if result.returncode != 0:
            stderr = result.stderr.strip()
            stdout = result.stdout.strip()
            details = stderr or stdout or f"exit_code={result.returncode}"
            raise RuntimeError(f"Ошибка команды {' '.join(args)}: {details}")

        output = result.stdout.strip()
        return output or None

    def __record_path_exists(self, camera_type: CameraType) -> bool:
        """
        Проверяет, существует ли подготовленный record-path для выбранной камеры.

        Args:
            camera_type (CameraType): Тип камеры.

        Returns:
            bool: `True`, если path уже существует, иначе `False`.
        """
        result = self.__run_command_raw(["record", "--path", camera_type.value, "exists"])
        return result.returncode == 0

    def __prepare_recording(
        self,
        camera_type: CameraType,
        recording_config: RecordingConfig,
    ) -> bool:
        """
        Подготавливает выбранную камеру к записи с нужными параметрами.

        Args:
            camera_type (CameraType): Тип камеры.
            recording_config (RecordingConfig): Конфигурация записи.

        Returns:
            bool: `True`, если подготовка прошла успешно, иначе `False`.
        """
        path_name = camera_type.value

        device = CONFIG["cameras"][path_name]["record_device"]
        args = [
            "record", "--path", path_name, "prepare",
            "--source", f"/dev/video{device}",
            "--photo-socket", f"/tmp/take_photo_ctrl_{path_name}.sock",
            "--width", str(recording_config.width),
            "--height", str(recording_config.height),
            "--framerate", f"{recording_config.fps}/1",
        ]

        try:
            self._run_camera_cmd(*args)
            return True
        except RuntimeError:
            print(f"Не удалось подготовить запись для камеры {camera_type.value} с разрешением {recording_config.width}x{recording_config.height} и fps {recording_config.fps}")
            return False
    

    def __check_pm2_jmp_camera_control(self) -> bool:
        """
        Проверяет наличие пакета `pm2-jmp-camera-control` в системе.

        Returns:
            bool: `True`, если пакет установлен, иначе `False`.
        """

        result = subprocess.run(["dpkg-query", "-W",  "-f='${Status}\n'", "pm2-jmp-camera-control"], capture_output=True, text=True)
        return "install ok installed" in result.stdout

    def __wait_for_file_exists(self, target_path: str | Path, attempts: int = 10, delay: float = 0.05) -> bool:
        """
        Ожидает появления файла ограниченное число попыток.

        Args:
            target_path (str | Path): Путь к ожидаемому файлу.
            attempts (int): Максимальное количество попыток.
            delay (float): Пауза между попытками в секундах.

        Returns:
            bool: `True`, если файл появился, иначе `False`.
        """
        path = Path(target_path)
        for _ in range(attempts):
            if path.exists():
                return True
            sleep(delay)
        return False

    def start_recording(
        self,
        camera_type: CameraType,
        recording_config: RecordingConfig | None = None,
        output_dir: str | Path = "/mnt/media/videos/",
    ) -> bool:
        """
        Подготавливает и запускает запись видео с указанными параметрами для выбранной камеры.

        Args:
            camera_type (CameraType): Тип камеры.
            recording_config (RecordingConfig | None): Конфигурация записи. По умолчанию `None` - используется первая доступная конфигурация.
            output_dir (str | Path, optional): Директория для сохранения видео.
                По умолчанию `"/mnt/media/videos/"`.

        Returns:
            bool: `True`, если запись успешно запущена, иначе `False`.
        """
        if recording_config is None:
            if len(self.__recording_configs[camera_type]) == 0:
                raise ValueError(f"Нет доступных конфигураций для записи видео для камеры {camera_type.value}")
            recording_config = self.__recording_configs[camera_type][0]
            print(f"Используется первая доступная конфигурация для камеры {camera_type.value}: {recording_config}")

        if not self.__prepare_recording(camera_type=camera_type, recording_config=recording_config):
            return False

        self._run_camera_cmd("record", "--path", camera_type.value, "start", str(output_dir))
        return True

    def stop_recording(self, camera_type: CameraType = CameraType.MAIN) -> bool:
        """
        Останавливает запись и очищает `record-path` выбранной камеры.

        Args:
            camera_type (CameraType, optional): Тип камеры. По умолчанию `CameraType.MAIN`.

        Returns:
            bool: `True` при успешной остановке.

        Raises:
            RuntimeError: Если остановка или уничтожение path завершились ошибкой.
        """
        self._run_camera_cmd("record", "--path", camera_type.value, "stop")
        self._run_camera_cmd("record", "--path", camera_type.value, "destroy")
        return True

    def take_photo(
        self,
        file_name: str,
        camera_type: CameraType,
        recording_config: RecordingConfig | None = None,
        output_dir: str | Path = "/mnt/media/photos/",
    ) -> bool:
        """
        Делает фотографию с указанными параметрами и сохраняет ее в указанную директорию.

        Args:
            file_name (str): Имя файла фотографии с расширением.
            camera_type (CameraType): Тип камеры.
            recording_config (RecordingConfig | None): Конфигурация записи. По умолчанию `None` - используется первая доступная конфигурация.
            output_dir (str | Path): Директория сохранения фотографий.

        Returns:
            bool: `True`, если фото успешно сохранено.
        """

        if recording_config is None:
            if len(self.__recording_configs[camera_type]) == 0:
                raise ValueError(f"Нет доступных конфигураций для записи видео для камеры {camera_type.value}")
            recording_config = self.__recording_configs[camera_type][0]
            print(f"Используется первая доступная конфигурация для камеры {camera_type.value}: {recording_config}")

        raw_name = file_name.strip()
        if not raw_name:
            raise ValueError("Имя фотографии не может быть пустым.")

        stem, ext = Path(raw_name).stem, Path(raw_name).suffix.lower()
        if ext not in self.ALLOWED_PHOTO_EXT or not stem:
            raise ValueError(
                f"Должно быть имя файла и расширение {', '.join(sorted(self.ALLOWED_PHOTO_EXT))}"
            )

        target_path = Path(output_dir) / raw_name
        if target_path.exists():
            os.remove(str(target_path))

        path_existed_before_photo = self.__record_path_exists(camera_type=camera_type)
        recording = False
        if not path_existed_before_photo:
            status = self.__prepare_recording(camera_type=camera_type, recording_config=recording_config)
            if not status:
                return False
            sleep(0.5)
            is_started = self.__record_path_exists(camera_type=camera_type)
            recording = is_started and self.__wait_for_file_exists(
                f"/tmp/take_photo_ctrl_{camera_type.value}.sock"
            )

        sleep(5)
        if recording:
            self._run_camera_cmd("photo", "--socket", f"/tmp/take_photo_ctrl_{camera_type.value}.sock", "--name", str(target_path))
            recording = self.__wait_for_file_exists(target_path)

        if not path_existed_before_photo:
            self.stop_recording(camera_type=camera_type)

        return True and recording

    def __read_camera_recording_configs(self, camera_type: CameraType = CameraType.MAIN) -> list[RecordingConfig]:
        """
        Читает конфигурации для записи видео для выбранной камеры.

        Args:
            camera_type (CameraType): Тип камеры.

        Returns:
            list[RecordingConfig]: Список конфигураций для записи видео.
        """
        resolutions = CONFIG["cameras"][camera_type.value]["resolutions"]
        recordable_resolutions = [
            RecordingConfig(width=mode["width"], height=mode["height"], fps=mode["fps"])
            for mode in resolutions
            if mode["recordable"]
        ]
        return recordable_resolutions

    def get_camera_recording_configs(self, camera_type: CameraType = CameraType.MAIN) -> list[RecordingConfig]:
        """
        Возвращает конфигурации для записи видео для выбранной камеры.

        Args:
            camera_type (CameraType, optional): Тип камеры. По умолчанию `CameraType.MAIN`.

        Returns:
            list[RecordingConfig]: Список конфигураций для записи видео.
        """
        return self.__recording_configs[camera_type]
