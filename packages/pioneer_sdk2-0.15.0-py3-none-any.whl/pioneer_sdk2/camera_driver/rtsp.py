from os import name
import numpy as np
import cv2
from ..config import CONFIG
import re
import threading
from collections import deque
from .base import AbstractDriver, CameraType

class RtspCamera(AbstractDriver):
    """Класс для захвата видеокадров RTSP и предоставления их через очередь."""
    def __init__(self, camera_type = CameraType.MAIN, camera_ip = "10.42.0.1:8554") -> None:
        ip_port_pattern = re.compile(r'^((\d{1,3}\.){3}\d{1,3}):(\d{1,5})$')
        if not isinstance(camera_ip, str) or not ip_port_pattern.match(camera_ip):
            raise ValueError(f"Некорректный IP-адрес камеры (обязательно с портом): {camera_ip}")

        self.name  = CONFIG["cameras"][camera_type.value]["name"]

        self.__capture = cv2.VideoCapture(f"rtsp://{camera_ip}/{self.name}")
        self.running = False
        self.__frame_buffer = deque(maxlen=1)
        self.__frame_condition = threading.Condition()
        self.thread = None

        self._start()

    def _start(self):
        """Запускает поток захвата видео."""
        self.running = True
        self.thread = threading.Thread(target=self._capture_loop)
        self.thread.start()

    def _capture_loop(self):
        """Непрерывно считывает кадры из видеопотока и помещает их в буфер."""
        while self.running:
            ret, frame = self.__capture.read()
            if ret:
                with self.__frame_condition:
                    self.__frame_buffer.append(frame)
                    self.__frame_condition.notify_all()

    def get_cv_frame(self, timeout: float = 5.0) -> np.ndarray:
        """Возвращает следующий доступный кадр из очереди.

        Args:
            timeout (float): Время ожидания в секундах.

        Returns:
            np.ndarray: кадр в формате BGR.

        Raises:
            TimeoutError: Если кадр не был получен в течение указанного таймаута.
        """
        with self.__frame_condition:
            if not self.__frame_condition.wait_for(lambda: len(self.__frame_buffer) > 0, timeout=timeout):
                raise TimeoutError(f"Не удалось получить кадр в течение {timeout} секунд. Проверьте исправность камеры/RTSP-сервера.")
            return self.__frame_buffer.pop()

    def stop(self):
        """Останавливает поток захвата видео и освобождает ресурсы."""
        self.running = False
        if self.thread:
            self.thread.join()
        self.__capture.release()

    def __del__(self) -> None:
        """ 
        Очищает ресурсы при удалении объекта.
        """
        self.stop()