import os, sys, json

class ConfigException(Exception):
    pass

class _ConfigSingleton:
    _instance = None
    _config = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(_ConfigSingleton, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._config is None:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            sys.path.append(script_dir)
            config_path = os.path.join(script_dir, 'board_config.json')
            if os.path.exists(config_path):
                with open(config_path, "r") as f:
                    self._config = json.load(f)
    
    def get_config(self):
        return self._config

_config_instance = _ConfigSingleton()

CONFIG = _config_instance.get_config()