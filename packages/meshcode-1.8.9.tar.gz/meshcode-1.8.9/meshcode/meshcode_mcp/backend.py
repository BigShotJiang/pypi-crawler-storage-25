"""Thin Supabase REST backend used by both the MCP server and tests.

Reuses the helpers from comms_v4.py without going through subprocess.
Zero deps beyond stdlib (urllib).
"""
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

# Bake in production defaults — RLS-protected publishable key, safe to ship.
_DEFAULT_SUPABASE_URL = "https://gjinagyyjttyxnaoavnz.supabase.co"
_DEFAULT_SUPABASE_KEY = "sb_publishable_qwN9PO1L7jUXhhbhhVk2CQ_z1FXG2Qf"

def _load_env_file() -> Dict[str, str]:
    env_path = Path.home() / ".meshcode" / "env"
    if not env_path.exists():
        return {}
    out: Dict[str, str] = {}
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("export "):
                line = line[7:]
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"').strip("'")
    except Exception:
        pass
    return out

_env_file = _load_env_file()
SUPABASE_URL = os.environ.get("SUPABASE_URL") or _env_file.get("SUPABASE_URL") or _DEFAULT_SUPABASE_URL
SUPABASE_KEY = os.environ.get("SUPABASE_KEY") or _env_file.get("SUPABASE_KEY") or _DEFAULT_SUPABASE_KEY
SCHEMA = "meshcode"


def _now_iso() -> str:
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S+00:00")


def _headers(*, prefer: Optional[str] = None, content_profile: bool = True) -> Dict[str, str]:
    h = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
    }
    if content_profile:
        h["Accept-Profile"] = SCHEMA
        h["Content-Profile"] = SCHEMA
    if prefer:
        h["Prefer"] = prefer
    return h


def _request(method: str, path: str, *, data: Any = None, prefer: Optional[str] = None) -> Any:
    url = f"{SUPABASE_URL}/rest/v1/{path}"
    body = json.dumps(data).encode("utf-8") if data else None
    req = Request(url, data=body, method=method, headers=_headers(prefer=prefer))
    try:
        with urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw.strip() else None
    except HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        try:
            err_obj = json.loads(err)
            return {"_error": err_obj.get("message", err[:200]), "_code": e.code}
        except Exception:
            return {"_error": err[:200], "_code": e.code}
    except URLError as e:
        return {"_error": str(e.reason), "_code": 0}


def sb_select(table: str, filters: str = "", order: Optional[str] = None, limit: Optional[int] = None) -> List[Dict]:
    params = []
    if filters:
        params.append(filters)
    if order:
        params.append(f"order={order}")
    if limit:
        params.append(f"limit={limit}")
    path = f"{table}?{'&'.join(params)}" if params else table
    result = _request("GET", path)
    if isinstance(result, dict) and result.get("_error"):
        return []
    return result or []


def sb_insert(table: str, row: Dict, *, upsert: bool = False, on_conflict: Optional[str] = None) -> Any:
    prefer = "return=representation"
    if upsert:
        prefer += ",resolution=merge-duplicates"
    path = table
    if on_conflict:
        path += f"?on_conflict={on_conflict}"
    return _request("POST", path, data=row, prefer=prefer)


def sb_update(table: str, filters: str, updates: Dict) -> Any:
    return _request("PATCH", f"{table}?{filters}", data=updates, prefer="return=representation")


def sb_rpc(fn_name: str, params: Dict) -> Any:
    url = f"{SUPABASE_URL}/rest/v1/rpc/{fn_name}"
    body = json.dumps(params).encode("utf-8")
    req = Request(url, data=body, method="POST", headers=_headers(content_profile=False))
    try:
        with urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw.strip() else None
    except HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        try:
            return {"_error": json.loads(err).get("message", err[:200])}
        except Exception:
            return {"_error": err[:200]}
    except URLError as e:
        return {"_error": str(e.reason)}


# ============================================================
# Project + agent helpers
# ============================================================

def get_project_id(project_name: str) -> Optional[str]:
    rows = sb_select("mc_projects", f"name=eq.{quote(project_name)}")
    if rows:
        return rows[0]["id"]
    result = sb_insert("mc_projects", {"name": project_name})
    if isinstance(result, list) and result:
        return result[0]["id"]
    return None


def register_agent(project: str, name: str, role: str = "") -> Dict:
    project_id = get_project_id(project)
    if not project_id:
        # Fallback: many spawn paths (setup_clients.py) bake the project
        # uuid into the env so we can register even when the name lookup
        # fails (RLS, schema cache, network blip, anon-key visibility).
        env_pid = os.environ.get("MESHCODE_PROJECT_ID", "").strip()
        if env_pid:
            project_id = env_pid
    if not project_id:
        return {"error": f"Project '{project}' not found"}

    result = sb_rpc("mc_register_agent", {
        "p_project_id": project_id,
        "p_name": name,
        "p_role": role,
        "p_status": "online",
    })

    if not result or (isinstance(result, dict) and result.get("error")):
        return result or {"error": "Failed to register agent"}

    sb_update("mc_agents",
              f"project_id=eq.{project_id}&name=eq.{quote(name)}",
              {"task": role, "last_heartbeat": _now_iso()})

    return {
        "registered": True,
        "project_id": project_id,
        "agent_name": name,
        "agent_id": result.get("agent_id") if isinstance(result, dict) else None,
    }


def send_message(project_id: str, from_agent: str, to_agent: str, payload: Any, msg_type: str = "msg", parent_msg_id: Optional[str] = None, sensitive: bool = False) -> Dict:
    if not isinstance(payload, dict):
        payload = {"text": str(payload)}
    msg = {
        "project_id": project_id,
        "from_agent": from_agent,
        "to_agent": to_agent,
        "type": msg_type,
        "payload": payload,
        "read": False,
    }
    if parent_msg_id:
        msg["parent_msg_id"] = parent_msg_id
    if sensitive:
        msg["is_sensitive"] = True
    result = sb_insert("mc_messages", msg)
    if isinstance(result, dict) and result.get("_error"):
        return {"error": result["_error"]}
    if isinstance(result, list) and result:
        return {"sent": True, "msg_id": result[0].get("id")}
    return {"sent": True}


def read_inbox(project_id: str, agent: str, mark_read: bool = True) -> List[Dict]:
    messages = sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&to_agent=eq.{quote(agent)}&read=eq.false",
        order="created_at.asc",
    )
    if mark_read and messages:
        for m in messages:
            sb_update("mc_messages", f"id=eq.{m['id']}", {"read": True})

        # Auto-ACK senders — but ONLY for messages older than 60s. If the
        # message was sent recently, the sender is very likely still inside
        # a meshcode_wait call that already returned the message via the
        # realtime path; an extra "you got it" ack row is pure noise that
        # spams the dashboard and the sender's inbox.
        import datetime as _dt
        now = _dt.datetime.now(_dt.timezone.utc)
        def _is_stale(m):
            ts = m.get("created_at")
            if not ts:
                return True
            try:
                # Supabase returns ISO8601 with timezone
                dt = _dt.datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                return (now - dt).total_seconds() > 60
            except Exception:
                return True
        ack_targets = {
            m["from_agent"]
            for m in messages
            if m.get("type") not in ("ack", "broadcast") and _is_stale(m)
        }
        for sender in ack_targets:
            sb_insert("mc_messages", {
                "project_id": project_id,
                "from_agent": agent,
                "to_agent": sender,
                "type": "ack",
                "payload": {"text": f"{agent} read your message"},
                "read": False,
            })
    return messages


def count_pending(project_id: str, agent: str) -> int:
    pending = sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&to_agent=eq.{quote(agent)}&read=eq.false&type=neq.ack",
        limit=1000,
    )
    return len(pending)


def get_board(project_id: str) -> List[Dict]:
    return sb_select("mc_agents", f"project_id=eq.{project_id}", order="registered_at.asc")


def heartbeat(project_id: str, agent: str) -> Dict:
    result = sb_rpc("mc_heartbeat", {"p_project_id": project_id, "p_agent_name": agent})
    return result or {}


def set_status(project_id: str, agent: str, status: str, task: str = "") -> Dict:
    updates = {"status": status, "last_heartbeat": _now_iso()}
    if task:
        updates["task"] = task
    result = sb_update("mc_agents", f"project_id=eq.{project_id}&name=eq.{quote(agent)}", updates)
    if isinstance(result, dict) and result.get("_error"):
        return {"error": result["_error"]}
    return {"ok": True, "status": status}


def task_create(api_key, project_id, creator_agent, title, description="", assignee="*", priority="normal", parent_task_id=None):
    return sb_rpc("mc_task_create", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_creator_agent": creator_agent,
        "p_title": title,
        "p_description": description,
        "p_assignee": assignee,
        "p_priority": priority,
        "p_parent_task_id": parent_task_id,
    })


def task_list(api_key, project_id, agent, status_filter=None):
    return sb_rpc("mc_task_list", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_agent": agent,
        "p_status_filter": status_filter,
    })


def task_claim(api_key, project_id, task_id, claiming_agent):
    return sb_rpc("mc_task_claim", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_task_id": task_id,
        "p_claiming_agent": claiming_agent,
    })


def task_complete(api_key, project_id, task_id, completing_agent, summary=""):
    return sb_rpc("mc_task_complete", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_task_id": task_id,
        "p_completing_agent": completing_agent,
        "p_summary": summary,
    })


def get_history(project_id: str, limit: int = 20) -> List[Dict]:
    return sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&type=neq.ack",
        order="created_at.desc",
        limit=limit,
    )
