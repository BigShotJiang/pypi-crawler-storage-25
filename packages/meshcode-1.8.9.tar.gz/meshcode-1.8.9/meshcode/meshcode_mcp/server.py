"""MeshCode MCP server — exposes meshcode tools to MCP clients (Claude Code, etc).

Tools:    meshcode_send, meshcode_broadcast, meshcode_read, meshcode_check,
          meshcode_status, meshcode_register, meshcode_set_status
Resources: meshcode://inbox, meshcode://board, meshcode://history

Run with:
    MESHCODE_PROJECT=my-app MESHCODE_AGENT=backend python -m meshcode_mcp serve
"""
import asyncio
import json
import logging
import os
import sys
from collections import deque
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional, Union


# ============================================================
# Dedupe: track IDs of messages we've already returned from
# meshcode_wait / meshcode_check so the same row doesn't show
# up twice when realtime + polled paths race.
# ============================================================
_SEEN_MSG_IDS: set = set()
_SEEN_MSG_ORDER: deque = deque()
_SEEN_MSG_CAP = 1000


def _seen_key(msg: Dict[str, Any]) -> str:
    """Build a dedupe key. Prefer the real row id; fall back to a synthetic."""
    mid = msg.get("id")
    if mid:
        return str(mid)
    payload = msg.get("payload") or {}
    try:
        payload_str = json.dumps(payload, sort_keys=True, default=str)[:50]
    except Exception:
        payload_str = str(payload)[:50]
    return f"{msg.get('from') or msg.get('from_agent')}|{msg.get('ts') or msg.get('created_at')}|{payload_str}"


def _mark_seen(key: str) -> None:
    if key in _SEEN_MSG_IDS:
        return
    _SEEN_MSG_IDS.add(key)
    _SEEN_MSG_ORDER.append(key)
    while len(_SEEN_MSG_ORDER) > _SEEN_MSG_CAP:
        old = _SEEN_MSG_ORDER.popleft()
        _SEEN_MSG_IDS.discard(old)


def _filter_and_mark(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Drop already-seen messages; mark the rest as seen."""
    out = []
    for m in messages:
        k = _seen_key(m)
        if k in _SEEN_MSG_IDS:
            continue
        _mark_seen(k)
        out.append(m)
    return out


def _split_messages(messages: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Split a list of normalized message dicts into messages / acks / done_signals."""
    real: List[Dict[str, Any]] = []
    acks: List[Dict[str, Any]] = []
    dones: List[Dict[str, Any]] = []
    for m in messages:
        t = m.get("type", "msg")
        if t == "ack":
            acks.append(m)
        elif t == "done":
            dones.append(m)
        else:
            real.append(m)
    return {
        "messages": real,
        "acks": acks,
        "done_signals": dones,
        "count": len(real),
    }

from . import backend as be
from .realtime import RealtimeListener

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print(
        "[meshcode-mcp] ERROR: mcp package not installed. Run: pip install 'mcp[cli]>=1.0'",
        file=sys.stderr,
    )
    sys.exit(2)

logging.basicConfig(level=logging.INFO, stream=sys.stderr,
                    format="[meshcode-mcp] %(message)s")
log = logging.getLogger("meshcode-mcp")


# ============================================================
# Server context — agent identity from env vars
# ============================================================

PROJECT_NAME = os.environ.get("MESHCODE_PROJECT", "")
AGENT_NAME = os.environ.get("MESHCODE_AGENT", "")
AGENT_ROLE = os.environ.get("MESHCODE_ROLE", "")

if not PROJECT_NAME or not AGENT_NAME:
    print(
        "[meshcode-mcp] ERROR: MESHCODE_PROJECT and MESHCODE_AGENT env vars required",
        file=sys.stderr,
    )
    sys.exit(2)


# ============================================================
# API key resolution — keychain first, env var fallback
# ============================================================
#
# 1.4.1+ stores api keys in the OS keychain. The setup_clients writer
# bakes only MESHCODE_KEYCHAIN_PROFILE into the .mcp.json env block, NOT
# the api key itself. The MCP server resolves the key at boot via the
# secrets module. The env-var path is preserved as a fallback for users
# whose OS doesn't have a keychain backend.

_API_KEY_CACHE: Optional[str] = None

def _get_api_key() -> str:
    """Resolve the api_key for this MCP server process. Cached after first call."""
    global _API_KEY_CACHE
    if _API_KEY_CACHE is not None:
        return _API_KEY_CACHE
    # 1. Direct env var (legacy / fallback path)
    val = os.environ.get("MESHCODE_API_KEY", "").strip()
    if val:
        _API_KEY_CACHE = val
        return val
    # 2. Keychain via profile name in env
    profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE", "").strip()
    if profile:
        try:
            import importlib
            secrets_mod = importlib.import_module("meshcode.secrets")
            kc_val = secrets_mod.get_api_key(profile=profile)
            if kc_val:
                _API_KEY_CACHE = kc_val
                return kc_val
        except Exception as e:
            print(f"[meshcode-mcp] WARNING: keychain lookup failed for profile '{profile}': {e}", file=sys.stderr)
    _API_KEY_CACHE = ""
    return ""


# Resolve project_id at startup. Try in order:
#   1. MESHCODE_PROJECT_ID env var (baked by `meshcode setup`, fastest)
#   2. mc_resolve_project RPC with the user's api_key (security definer, bypasses RLS)
#   3. Direct SELECT via get_project_id (only works if RLS is open / user is admin)
_PROJECT_ID: Optional[str] = os.environ.get("MESHCODE_PROJECT_ID") or None
if not _PROJECT_ID:
    _api_key = _get_api_key()
    if _api_key:
        try:
            _r = be.sb_rpc("mc_resolve_project", {
                "p_api_key": _api_key,
                "p_project_name": PROJECT_NAME,
            })
            if isinstance(_r, dict) and _r.get("project_id"):
                _PROJECT_ID = _r["project_id"]
            elif isinstance(_r, dict) and _r.get("error"):
                print(f"[meshcode-mcp] WARNING: mc_resolve_project: {_r['error']}", file=sys.stderr)
        except Exception as _e:
            print(f"[meshcode-mcp] WARNING: mc_resolve_project failed: {_e}", file=sys.stderr)
if not _PROJECT_ID:
    _PROJECT_ID = be.get_project_id(PROJECT_NAME)
if not _PROJECT_ID:
    print(f"[meshcode-mcp] ERROR: project '{PROJECT_NAME}' not found (check MESHCODE_KEYCHAIN_PROFILE / MESHCODE_API_KEY)", file=sys.stderr)
    sys.exit(2)

_register_result = be.register_agent(PROJECT_NAME, AGENT_NAME, AGENT_ROLE or "MCP-connected agent")
if isinstance(_register_result, dict) and _register_result.get("error"):
    print(f"[meshcode-mcp] WARNING: register failed: {_register_result['error']}", file=sys.stderr)

# Flip to online so the dashboard reflects the live MCP session.
# Use the SECURITY DEFINER RPC (mc_agent_set_status_by_api_key) so we
# bypass RLS — the publishable key has no JWT context and cannot UPDATE
# mc_agents directly. The RPC validates ownership via api_key.
def _flip_status(status: str, task: str = "") -> bool:
    api_key = _get_api_key()
    if not api_key:
        # Last-resort fallback: try the direct PATCH (may be denied by RLS)
        try:
            be.set_status(_PROJECT_ID, AGENT_NAME, status, task)
            return True
        except Exception:
            return False
    try:
        r = be.sb_rpc("mc_agent_set_status_by_api_key", {
            "p_api_key": api_key,
            "p_project_id": _PROJECT_ID,
            "p_agent_name": AGENT_NAME,
            "p_status": status,
            "p_task": task,
        })
        if isinstance(r, dict) and r.get("ok"):
            return True
        if isinstance(r, dict) and r.get("error"):
            log.warning(f"set_status RPC: {r['error']}")
        return False
    except Exception as e:
        log.warning(f"set_status RPC threw: {e}")
        return False

if not _flip_status("idle", ""):
    print(f"[meshcode-mcp] WARNING: could not flip status to idle", file=sys.stderr)


# ============================================================
# Working/idle status decorator for @mcp.tool() functions.
# Fire-and-forget flips so tool execution is never blocked.
# ============================================================
import functools as _functools
import threading as _threading

_flip_lock = _threading.Lock()


async def _async_flip_status(status: str, task: str = "") -> None:
    try:
        await asyncio.to_thread(_flip_status_locked, status, task)
    except Exception as e:
        log.debug(f"flip_status({status}) failed: {e}")


def _flip_status_locked(status: str, task: str = "") -> bool:
    """Thread-safe wrapper around _flip_status to prevent concurrent RPCs."""
    with _flip_lock:
        return _flip_status(status, task)


def _schedule_flip(status: str, task: str = "") -> None:
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_async_flip_status(status, task))
    except RuntimeError:
        # No running loop (sync context) — run in a throwaway thread
        _threading.Thread(
            target=_flip_status_locked, args=(status, task), daemon=True
        ).start()


def with_working_status(func):
    name = func.__name__
    skip = (name == "meshcode_wait")
    if asyncio.iscoroutinefunction(func):
        @_functools.wraps(func)
        async def awrapper(*args, **kwargs):
            if not skip:
                _schedule_flip("working", name)
            try:
                return await func(*args, **kwargs)
            finally:
                if not skip:
                    _schedule_flip("idle", "")
        return awrapper
    else:
        @_functools.wraps(func)
        def swrapper(*args, **kwargs):
            if not skip:
                _schedule_flip("working", name)
            try:
                return func(*args, **kwargs)
            finally:
                if not skip:
                    _schedule_flip("idle", "")
        return swrapper


# ============================================================
# Single-instance lease — prevent split-brain when two windows
# run `meshcode run <same-agent>` simultaneously.
# ============================================================
import uuid as _uuid
_INSTANCE_ID = f"mcp-{_uuid.uuid4().hex[:12]}"

def _acquire_lease() -> bool:
    api_key = _get_api_key()
    if not api_key:
        return True  # legacy clients without api_key skip lease check
    try:
        r = be.sb_rpc("mc_acquire_agent_lease", {
            "p_api_key": api_key,
            "p_project_id": _PROJECT_ID,
            "p_agent_name": AGENT_NAME,
            "p_instance_id": _INSTANCE_ID,
        })
        if isinstance(r, dict) and r.get("ok"):
            return True
        if isinstance(r, dict) and r.get("error"):
            print(f"[meshcode-mcp] LEASE DENIED: {r['error']}", file=sys.stderr)
            print(f"[meshcode-mcp] Another window is already running this agent.", file=sys.stderr)
            print(f"[meshcode-mcp] Close the other window first, or use a different agent name.", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[meshcode-mcp] WARNING: lease RPC failed: {e}", file=sys.stderr)
        return True  # don't hard-fail on transient network issues

if not _acquire_lease():
    sys.exit(2)


def _release_lease() -> None:
    api_key = _get_api_key()
    if not api_key:
        return
    try:
        be.sb_rpc("mc_release_agent_lease", {
            "p_api_key": api_key,
            "p_project_id": _PROJECT_ID,
            "p_agent_name": AGENT_NAME,
            "p_instance_id": _INSTANCE_ID,
        })
    except Exception:
        pass


# ============================================================
# Agent identity from Supabase profile (for system instructions)
# ============================================================

_LAUNCH_PROMPT = ""
_ROLE_DESCRIPTION = AGENT_ROLE or ""
try:
    _profile = be.sb_rpc("mc_agent_get_profile", {
        "p_project_id": _PROJECT_ID,
        "p_agent_name": AGENT_NAME,
    })
    if isinstance(_profile, list) and _profile:
        _profile = _profile[0]
    if isinstance(_profile, dict):
        _inner = _profile.get("profile") if isinstance(_profile.get("profile"), dict) else _profile
        _LAUNCH_PROMPT = (_inner.get("launch_prompt") or _profile.get("launch_prompt") or "") if isinstance(_inner, dict) else ""
        _ROLE_DESCRIPTION = (
            (_inner.get("role_description") if isinstance(_inner, dict) else None)
            or _profile.get("role_description")
            or _profile.get("role")
            or AGENT_ROLE
            or "(unspecified)"
        )
except Exception as _e:
    log.warning(f"could not fetch agent profile: {_e}")


def _build_instructions() -> str:
    """Build the system-instructions block injected via the MCP InitializeResult.

    Per the MCP spec, servers may return an `instructions` field that compatible
    clients (Claude Code, Cursor, Cline, etc.) merge into the model's system
    context at session start. This is how we make the mesh "be" the agent — no
    user setup, no launch_prompt fiddling, no per-session prompt engineering.
    """
    role_block = f"\nROLE: {_ROLE_DESCRIPTION}\n" if _ROLE_DESCRIPTION else ""
    launch_block = (
        f"\nUSER-PROVIDED ROLE PROMPT (from the dashboard):\n---\n{_LAUNCH_PROMPT}\n---\n"
        if _LAUNCH_PROMPT else ""
    )
    return f"""You are an autonomous AI agent inside a MeshCode meshwork.

IDENTITY (this is who you are — you cannot leave or change this):
- Meshwork (project): {PROJECT_NAME}
- Your agent name:    {AGENT_NAME}{role_block}{launch_block}

THE MESH PROTOCOL — READ CAREFULLY, THIS IS YOUR PRIMARY BEHAVIOR LOOP:

You are connected in real time to other AI agents in this meshwork. You can
send them messages and they can send you messages at any moment, including
while you are idle. You don't need to "join" the mesh — the MCP connection
already made you a member. The mesh tools are part of your body now.

YOUR DEFAULT BEHAVIOR LOOP (do this without being asked):

1. When the user gives you an initial task or you receive a mesh message,
   read it, decide what to do, and act.
2. Whenever your work depends on another agent's expertise, output, or
   review, send them a message via the meshcode_send tool. Do not wait
   for the user to tell you to coordinate — collaborating with the other
   mesh agents is your job.
3. When you would normally finish a turn and return to the user, INSTEAD
   call the meshcode_wait tool. It blocks for up to 4 minutes inside the
   MCP server, listening for incoming mesh messages. While inside this
   call you ARE listening — your turn never actually ends.
4. When meshcode_wait returns with a message, treat it exactly like a new
   user prompt. Read it, decide if it requires action or a reply, take
   action, send a reply via meshcode_send if appropriate, then call
   meshcode_wait AGAIN to keep listening.
5. When meshcode_wait returns timed_out, call it AGAIN — but apply
   TOKEN-EFFICIENT WAIT BACKOFF: double the previous timeout each
   consecutive timeout (60 → 120 → 240 → 480 → 960 → 1800s, cap at
   1800). Reset to 60s as soon as you receive ANY mesh message. Do
   not return to the user. The loop is your default state — you are
   a long-running mesh agent, not a one-shot chatbot.

6. GLOBAL DONE: when ANY agent (typically commander) calls
   meshcode_done(reason), every other agent's meshcode_wait returns
   with {{got_done: true, reason}}. Treat this as "task complete, exit
   the loop". Do NOT call meshcode_wait again. Return cleanly to the
   user with a summary of what the mesh accomplished. Stay quiet
   until the user gives a new task.

YOU SHOULD ONLY BREAK OUT OF THE meshcode_wait LOOP IF:
- The human user explicitly says "stop" or pressed Ctrl+C.
- A mesh message explicitly says "tell the human X" — in that case,
  return to the user with that message AND then re-enter the loop.
- A fatal error happens that requires user intervention.

THREADING: when you reply to a specific message (not just sending a fresh
task), pass the original message's `id` as `in_reply_to` in your
meshcode_send call. The dashboard renders threaded replies as a tree under
their parent — much easier for humans to follow than a flat chat. Use
threading especially when you sent a broadcast and one agent's reply is to
a different message than another's. Every message you receive via
meshcode_wait / meshcode_check / meshcode_read now includes an `id` field
(use it for in_reply_to) and a `parent_id` field (so you can see whether
the message you received is itself a reply to something).

SENSITIVE DATA: when sharing API keys, credentials, customer data, personal
information, secrets, or anything that should not be in a public log, set
sensitive=True in your meshcode_send call. Sensitive messages are NEVER
included in public meshwork exports, even if the meshwork owner publishes
the meshwork. The flag is enforced at the database level — there is no way
for a public viewer to read sensitive messages. Use this liberally — false
positives are harmless, false negatives are a privacy leak.

LOOP-SAFETY RULES (IMPORTANT — prevent token-burning ping-pong):
- Do NOT reply "Done" / "OK" / "Got it" to every message. If a message
  is a status update or pure ack, just process it and call meshcode_wait
  again WITHOUT sending a reply.
- Do NOT bounce the same message back to the sender.
- Only send a message if you have substantive new information, a real
  question, or a real action result to share.
- If you find yourself sending more than ~10 messages on the same topic
  in a row, stop and reassess — you may be in a feedback loop.

COMMUNICATION EFFICIENCY PROTOCOL (MANDATORY):

1. TASKS OVER MESSAGES: use meshcode_task_create/claim/complete for all
   trackable work assignments, NOT messages. Messages are only for short
   signals: "review needed", "blocked on X", "approved", "question: ...".
   The Tasks panel in the dashboard is where the human sees progress — if
   there are no tasks, the human has no visibility into what you're doing.

2. COMPRESSED REPORTS: when reporting findings, use structured JSON in the
   payload, not prose:
     {{"findings": [{{"severity":"high","file":"X","issue":"Y","fix":"Z"}}],
      "commits":["abc1234"], "next":"awaiting_review"}}

3. NO PROSE PADDING: never write "As you asked, I reviewed the schema and
   found that..." — go straight to the data. Max 2 sentences of context,
   then structured output. Every token costs money.

4. SIGNAL-ONLY MESSAGES: meshcode_send messages must be <100 tokens. If you
   need to communicate more, create a task with the full description and
   send a signal: "task created: <title>".

5. TASK STATUS AS SOURCE OF TRUTH: always create tasks for trackable work.
   Claim them when you start. Complete them when done. The human watches the
   task board, not the chat. No task = invisible work = wasted effort.

6. POLL TASKS, DON'T WAIT FOR MESSAGES: when coordinating, use
   meshcode_tasks() to check task status instead of waiting for a message.
   If you assigned a task, poll the board to see if it's done — don't
   assume the agent will message you. Messages can be missed; task status
   is persistent and reliable. Check meshcode_tasks() before each
   meshcode_wait() call to avoid stale waits.

YOUR FIRST ACTIONS WHEN THIS SESSION STARTS:
1. Call meshcode_status() once to see who else is in the meshwork.
2. Call meshcode_set_status(status="online", task="ready") to announce
   your presence on the dashboard.
3. If the human user has given you an initial task, do it now.
4. When you have nothing else to do (or right after sending a mesh
   message that expects a reply), call meshcode_wait() to enter your
   idle/listening state. Stay there forever unless one of the
   break-out conditions above fires.

TASK BOARD: the meshwork has a shared task list. Use it instead of just messages
when work needs tracking. Tools:
  meshcode_tasks(status_filter='open')   — list tasks you could pick up
  meshcode_task_claim(task_id)            — atomically claim one (CAS — fails if
                                            another agent already claimed)
  meshcode_task_complete(task_id, summary)— mark done with a 1-line summary
  meshcode_task_create(title, description, assignee='*')  — create one (commanders
                                                            usually do this)
The dashboard renders the board live. Prefer claiming open tasks over starting
fresh work — it makes coordination visible to humans.

AVAILABLE MESH TOOLS (all from this MCP server):
  meshcode_wait        — block until a mesh message arrives (your idle state)
  meshcode_done        — broadcast a GLOBAL DONE to break every agent out of wait
  meshcode_send        — send a message to another mesh agent
  meshcode_check       — non-blocking peek at the inbox count
  meshcode_read        — drain inbox, mark messages read
  meshcode_status      — list all agents in the meshwork
  meshcode_set_status  — update your own dashboard status
  meshcode_broadcast   — send to ALL agents in the meshwork
  meshcode_register    — re-register if disconnected
  meshcode_init        — re-initialize agent context (rarely needed)
  meshcode_tasks             — list tasks on the shared board
  meshcode_task_create       — create a new task
  meshcode_task_claim        — atomically claim an open task
  meshcode_task_complete     — mark a claimed task done

You are not a single-turn chatbot. You are a persistent mesh agent. Act
accordingly.
"""


_INSTRUCTIONS = _build_instructions()


# ============================================================
# Realtime listener (created in lifespan)
# ============================================================

_REALTIME: Optional[RealtimeListener] = None


async def _on_new_message(msg: Dict[str, Any]) -> None:
    """Best-effort: try to push an MCP resource-updated notification.

    If the underlying session supports send_resource_updated_notification,
    use it. If not (older MCP versions or unsupported), the message is
    still queued and meshcode_check / next-tool-call will surface it.
    """
    try:
        srv = mcp._mcp_server  # FastMCP exposes the lowlevel server here
        ctx = getattr(srv, "request_context", None)
        if ctx and getattr(ctx, "session", None):
            from pydantic import AnyUrl
            await ctx.session.send_resource_updated(AnyUrl("meshcode://inbox"))
            log.info(f"sent MCP resource_updated notification for msg from {msg.get('from')}")
    except Exception as e:
        log.debug(f"send_resource_updated unavailable: {e}")


async def _heartbeat_loop():
    """Send heartbeat every 30s via HTTP. Also renews the agent lease and
    logs when the WebSocket is disconnected (heartbeat still works via HTTP
    so the agent stays 'online' in the DB even during WS reconnects)."""
    _lease_counter = 0
    while True:
        try:
            be.sb_rpc("mc_heartbeat", {"p_project_id": _PROJECT_ID, "p_agent_name": AGENT_NAME})
            # Log WS health for diagnostics
            if _REALTIME and not _REALTIME.is_connected:
                log.warning("heartbeat ok (HTTP) but WebSocket is disconnected — realtime messages may be delayed")
            else:
                log.debug(f"heartbeat ok for {AGENT_NAME}")
        except Exception as e:
            log.warning(f"heartbeat failed: {e}")

        # Renew lease every ~2 minutes (every 4th heartbeat) to prevent
        # another instance from stealing it during long sessions.
        _lease_counter += 1
        if _lease_counter % 4 == 0:
            try:
                api_key = _get_api_key()
                if api_key:
                    be.sb_rpc("mc_acquire_agent_lease", {
                        "p_api_key": api_key,
                        "p_project_id": _PROJECT_ID,
                        "p_agent_name": AGENT_NAME,
                        "p_instance_id": _INSTANCE_ID,
                    })
            except Exception as e:
                log.warning(f"lease renewal failed: {e}")

        await asyncio.sleep(30)


@asynccontextmanager
async def lifespan(_app):
    """Start the Realtime listener when the MCP server boots; stop on shutdown."""
    global _REALTIME
    _REALTIME = RealtimeListener(
        supabase_url=be.SUPABASE_URL,
        supabase_key=be.SUPABASE_KEY,
        project_id=_PROJECT_ID,
        agent_name=AGENT_NAME,
        notify_callback=_on_new_message,
    )
    await _REALTIME.start()
    hb_task = asyncio.create_task(_heartbeat_loop())
    log.info(f"lifespan started — Realtime + heartbeat (30s) active for {AGENT_NAME}")
    try:
        yield {"realtime": _REALTIME}
    finally:
        log.info("lifespan shutdown — stopping heartbeat + realtime + releasing lease")
        hb_task.cancel()
        try:
            await hb_task
        except asyncio.CancelledError:
            pass
        await _REALTIME.stop()
        # Flip to offline + release lease so the dashboard reflects reality
        # within seconds (not waiting for the 30s cron to notice).
        try:
            _release_lease()
        except Exception as _e:
            log.warning(f"could not release lease: {_e}")


# ============================================================
# FastMCP server
# ============================================================

mcp = FastMCP(
    name=f"meshcode-{PROJECT_NAME}-{AGENT_NAME}",
    instructions=_INSTRUCTIONS,
    lifespan=lifespan,
)
# Belt-and-suspenders: some FastMCP versions don't forward `instructions=` to
# the underlying lowlevel server's InitializeResult. Set it directly too.
try:
    mcp._mcp_server.instructions = _INSTRUCTIONS  # type: ignore[attr-defined]
except Exception:
    pass


# ----------------- TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_send(to: str, message: Any, in_reply_to: Optional[str] = None,
                  sensitive: bool = False) -> Dict[str, Any]:
    """Send a message to another agent in the meshwork.

    If you only have plain text, just pass it as a string and it will be
    wrapped as {text: ...} automatically. For protocol payloads (need / done
    / fyi / blocked), pass a dict.

    Args:
        to: Name of the recipient agent.
        message: Either a plain string (auto-wrapped as {"text": message}) or
            a structured dict payload (use protocol keys: need/done/fyi/blocked).
        in_reply_to: Optional message id you are replying to. If set, this
            message is a threaded reply — the dashboard renders it under the
            original. Use this especially when replying to one of several
            outstanding broadcasts so humans can tell which is which.
        sensitive: If True, this message will NEVER appear in a public meshwork
            export, regardless of whether the meshwork is published. ALWAYS
            set this to True when sharing API keys, credentials, customer
            data, secrets, personal information, or anything that should not
            be visible to anyone outside the meshwork. The owner can publish
            the meshwork without leaking sensitive messages, because the
            sensitive flag is enforced at the database level.
    """
    if isinstance(message, str):
        payload: Dict[str, Any] = {"text": message}
    elif isinstance(message, dict):
        payload = message
    else:
        payload = {"text": str(message)}
    return be.send_message(_PROJECT_ID, AGENT_NAME, to, payload, msg_type="msg",
                           parent_msg_id=in_reply_to, sensitive=sensitive)


@mcp.tool()
@with_working_status
def meshcode_broadcast(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Send a message to ALL agents in the meshwork (except yourself).

    Args:
        payload: Structured message payload.
    """
    agents = be.get_board(_PROJECT_ID)
    sent = 0
    for a in agents:
        if a["name"] != AGENT_NAME:
            be.send_message(_PROJECT_ID, AGENT_NAME, a["name"], payload, msg_type="broadcast")
            sent += 1
    return {"broadcast": True, "agents_notified": sent}


@mcp.tool()
@with_working_status
def meshcode_read(include_acks: bool = False) -> Dict[str, Any]:
    """Read all pending (unread) messages for this agent. Marks them as read and ACKs senders.

    Returns a split shape: `messages` (real msgs), `acks`, and `done_signals`
    — so you don't have to filter by type yourself.

    Args:
        include_acks: If False (default), type='ack' rows are dropped entirely
            from the response. Acks are bookkeeping noise and most callers
            don't want them in their LLM context.
    """
    raw = be.read_inbox(_PROJECT_ID, AGENT_NAME)
    normalized = [
        {
            "from": m["from_agent"],
            "type": m.get("type", "msg"),
            "ts": m.get("created_at"),
            "payload": m.get("payload", {}),
            "id": m.get("id"),
            "parent_id": m.get("parent_msg_id"),
        }
        for m in raw
    ]
    deduped = _filter_and_mark(normalized)
    split = _split_messages(deduped)
    if not include_acks:
        split["acks"] = []
    return split


def _detect_global_done(messages: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return {reason, from} if the list contains a global_done signal, else None."""
    for m in messages:
        if m.get("type") == "done":
            p = m.get("payload") or {}
            if p.get("type") == "global_done" or p.get("reason"):
                return {
                    "reason": p.get("reason"),
                    "from": p.get("from") or m.get("from"),
                }
    return None


@mcp.tool()
@with_working_status
async def meshcode_wait(timeout_seconds: int = 120, include_acks: bool = False) -> Dict[str, Any]:
    """LONG-POLL: Block until a new message arrives for this agent (or timeout).

    This is a TRUE async long-poll. While idle, the MCP server blocks on a
    single asyncio Event — zero CPU, zero Supabase calls, zero token cost on
    the Claude side (the tool call literally has not returned yet). It wakes
    INSTANTLY the moment a mesh message lands via the Realtime websocket.

    TOKEN-EFFICIENT WAIT BACKOFF: when this returns timed_out, call it again
    with double the previous timeout (60 → 120 → 240 → 480 → 960 → 1800s,
    cap at 1800). Reset to 60s as soon as you receive ANY mesh message. This
    minimizes the cost of being idle.

    GLOBAL DONE: if any agent calls meshcode_done(reason), this tool returns
    with {got_done: true, reason, from}. Treat that as "task complete, exit
    the loop". Do NOT call meshcode_wait again after a got_done. Return
    cleanly to the user with a summary and stay quiet until a new task.

    Args:
        timeout_seconds: How long to block before returning empty (default 120s).
                         Pick something < your client's tool-call timeout.
    """
    actual_timeout = max(1, int(timeout_seconds))

    def _return_from_buffered(buffered: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        deduped = _filter_and_mark(buffered)
        if not deduped:
            return None
        split = _split_messages(deduped)
        if not include_acks:
            split["acks"] = []
        # If the ONLY thing buffered was acks (now suppressed) AND there
        # are no real messages or done signals, treat as nothing useful.
        if not split["messages"] and not split["done_signals"] and not split["acks"]:
            return None
        out: Dict[str, Any] = {
            "got_message": True,
            "source": "realtime",
            **split,
        }
        done = _detect_global_done(deduped)
        if done:
            out["got_done"] = True
            out["reason"] = done["reason"]
            out["from"] = done["from"]
        return out

    # 1) Drain anything already buffered from before this call.
    if _REALTIME:
        pre = _REALTIME.drain()
        if pre:
            shaped = _return_from_buffered(pre)
            if shaped:
                return shaped

        # 2) Real async wait — zero CPU, zero Supabase calls.
        woke = await _REALTIME.wait_for_message(timeout=float(actual_timeout))
        if woke:
            buffered = _REALTIME.drain()
            if buffered:
                shaped = _return_from_buffered(buffered)
                if shaped:
                    return shaped
    else:
        # Realtime unavailable — plain sleep fallback so we still honor timeout.
        await asyncio.sleep(actual_timeout)

    return {
        "got_message": False,
        "timed_out": True,
        "agent": AGENT_NAME,
        "hint": (
            "No messages arrived. Per TOKEN-EFFICIENT WAIT BACKOFF: call "
            "meshcode_wait again with DOUBLE the previous timeout "
            "(60→120→240→480→960→1800, cap 1800). Reset to 60s on any "
            "received mesh message."
        ),
    }


@mcp.tool()
@with_working_status
def meshcode_done(reason: str) -> Dict[str, Any]:
    """Broadcast a GLOBAL DONE signal to every other agent in the meshwork.

    Typically called by the commander when the overall task is complete.
    Every other agent's meshcode_wait() will return immediately with
    {got_done: true, reason, from}, breaking them cleanly out of their idle
    loop so they can report to the human and stop burning tokens.

    Args:
        reason: Short human-readable reason, e.g. "tests green, PR merged".
    """
    agents = be.get_board(_PROJECT_ID)
    payload = {"reason": reason, "from": AGENT_NAME, "type": "global_done"}
    sent = 0
    for a in agents:
        name = a.get("name")
        if name and name != AGENT_NAME:
            try:
                be.send_message(_PROJECT_ID, AGENT_NAME, name, payload, msg_type="done")
                sent += 1
            except Exception as e:
                log.warning(f"meshcode_done: failed to notify {name}: {e}")
    log.info(f"global done broadcast from {AGENT_NAME}: reason={reason!r} notified={sent}")
    return {"ok": True, "global_done": True, "agents_notified": sent, "reason": reason}


@mcp.tool()
@with_working_status
def meshcode_check(include_acks: bool = False) -> Dict[str, Any]:
    """Quick poll: returns pending message count + any messages buffered by the
    Realtime listener since the last check.

    Use this to check if there's anything new without marking messages as read.
    Useful as the first call in a tool loop or after a long thinking phase.
    """
    pending = be.count_pending(_PROJECT_ID, AGENT_NAME)
    realtime_buffered = _REALTIME.drain() if _REALTIME else []
    deduped = _filter_and_mark(realtime_buffered)
    split = _split_messages(deduped)
    if not include_acks:
        split["acks"] = []
    return {
        "pending": pending,
        "agent": AGENT_NAME,
        "project": PROJECT_NAME,
        "realtime_connected": _REALTIME.is_connected if _REALTIME else False,
        **split,
    }


@mcp.tool()
@with_working_status
def meshcode_status() -> Dict[str, Any]:
    """Get the meshwork status board: all agents with their status, role, and current task."""
    agents = be.get_board(_PROJECT_ID)
    return {
        "project": PROJECT_NAME,
        "agents": [
            {
                "name": a["name"],
                "role": a.get("role", ""),
                "status": a.get("status", "?"),
                "task": a.get("task", ""),
                "last_heartbeat": a.get("last_heartbeat"),
            }
            for a in agents
        ],
    }


@mcp.tool()
@with_working_status
def meshcode_register(role: str = "") -> Dict[str, Any]:
    """Re-register this agent in the meshwork. Use if you got disconnected or
    want to update your role description.
    """
    return be.register_agent(PROJECT_NAME, AGENT_NAME, role or AGENT_ROLE)


@mcp.tool()
def meshcode_set_status(status: str, task: str = "") -> Dict[str, Any]:
    """Update your status in the board.

    Args:
        status: One of: working, idle, standby, blocked, done, online.
        task: Optional human-readable task description.
    """
    return be.set_status(_PROJECT_ID, AGENT_NAME, status, task)


@mcp.tool()
@with_working_status
def meshcode_init(project: str, agent: str, role: str = "") -> Dict[str, Any]:
    """Re-initialize this MCP session for a different (project, agent). Use ONLY
    if you need to dynamically switch context — normally the env vars set at
    server start are correct.
    """
    global PROJECT_NAME, AGENT_NAME, AGENT_ROLE, _PROJECT_ID
    PROJECT_NAME = project
    AGENT_NAME = agent
    AGENT_ROLE = role
    pid = be.get_project_id(project)
    if not pid:
        return {"error": f"project '{project}' not found"}
    _PROJECT_ID = pid
    result = be.register_agent(project, agent, role or "MCP-connected agent")
    return {"ok": True, "project": project, "agent": agent, "register": result}


@mcp.tool()
@with_working_status
def meshcode_task_create(title: str, description: str = "", assignee: str = "*",
                          priority: str = "normal", parent_task_id: Optional[str] = None) -> Dict[str, Any]:
    """Create a task in the meshwork's shared backlog. Use this when you (typically
    the commander) want to assign work that needs tracking.

    Args:
        title: Short title of the task.
        description: Longer description / acceptance criteria.
        assignee: Agent name to assign to, or "*" for any agent (anyone can claim).
        priority: 'low' / 'normal' / 'high' / 'urgent'.
        parent_task_id: Optional parent task id for nesting subtasks.

    Returns: {"ok": true, "task_id": "...", "title": "..."}
    """
    api_key = _get_api_key()
    return be.task_create(api_key, _PROJECT_ID, AGENT_NAME, title,
                           description=description, assignee=assignee,
                           priority=priority, parent_task_id=parent_task_id)


@mcp.tool()
@with_working_status
def meshcode_tasks(status_filter: Optional[str] = None) -> Dict[str, Any]:
    """List tasks in the meshwork. Use this to discover work you can pick up.

    Args:
        status_filter: 'open' / 'in_progress' / 'done' / etc. None = all.

    Returns: {"ok": true, "tasks": [...]}
    """
    api_key = _get_api_key()
    return be.task_list(api_key, _PROJECT_ID, AGENT_NAME, status_filter=status_filter)


@mcp.tool()
@with_working_status
def meshcode_task_claim(task_id: str) -> Dict[str, Any]:
    """Atomically claim an open task. If the task is already claimed by someone
    else (or assigned to a different agent), this returns an error and another
    task should be picked.

    Args:
        task_id: The uuid of the task you want to claim.
    """
    api_key = _get_api_key()
    return be.task_claim(api_key, _PROJECT_ID, task_id, AGENT_NAME)


@mcp.tool()
@with_working_status
def meshcode_task_complete(task_id: str, summary: str = "") -> Dict[str, Any]:
    """Mark a task as done. Only the claimer can complete it.

    Args:
        task_id: The uuid of the task you previously claimed.
        summary: Short description of what was accomplished + any artifacts.
    """
    api_key = _get_api_key()
    return be.task_complete(api_key, _PROJECT_ID, task_id, AGENT_NAME, summary=summary)


# ----------------- RESOURCES -----------------

@mcp.resource("meshcode://inbox")
def inbox_resource() -> str:
    """Current pending messages for this agent. Read-only — does NOT mark as read."""
    pending = be.sb_select(
        "mc_messages",
        f"project_id=eq.{_PROJECT_ID}&to_agent=eq.{AGENT_NAME}&read=eq.false",
        order="created_at.asc",
    )
    return json.dumps({
        "count": len(pending),
        "messages": [
            {
                "from": m["from_agent"],
                "type": m.get("type", "msg"),
                "ts": m.get("created_at"),
                "payload": m.get("payload", {}),
                "id": m.get("id"),
                "parent_id": m.get("parent_msg_id"),
            }
            for m in pending
        ],
    }, indent=2)


@mcp.resource("meshcode://board")
def board_resource() -> str:
    """Snapshot of the meshwork board (all agents and their status)."""
    agents = be.get_board(_PROJECT_ID)
    return json.dumps({
        "project": PROJECT_NAME,
        "agents": agents,
    }, indent=2, default=str)


@mcp.resource("meshcode://history")
def history_resource() -> str:
    """Recent message history for this meshwork (last 20 non-ack messages)."""
    history = be.get_history(_PROJECT_ID, limit=20)
    return json.dumps({
        "project": PROJECT_NAME,
        "history": history,
    }, indent=2, default=str)


# ============================================================
# Entry point
# ============================================================

def run_server():
    """Start the MCP server on stdio (default for Claude Code)."""
    print(
        f"[meshcode-mcp] Starting server for {AGENT_NAME}@{PROJECT_NAME}",
        file=sys.stderr,
    )
    mcp.run()
