"""`meshcode run <agent>` — universal agent launcher.

Looks up the agent's workspace dir (created by `meshcode setup`) in the
registry at ~/meshcode/.registry.json, auto-detects the user's MCP-aware
editor, and launches it pointing at that workspace's isolated .mcp.json
so ONLY this one agent loads in the new window.

Editor detection order (first match wins):
    1. $MESHCODE_EDITOR env var (explicit override: claude / cursor / code)
    2. claude (Claude Code) — uses --mcp-config flag for per-instance config
    3. cursor — opens Cursor in the workspace dir (reads .cursor/mcp.json)
    4. code (VS Code, used by Cline) — opens VS Code in the workspace dir
       (Cline reads .vscode/mcp.json)

The workspace dir contains all three config files (.mcp.json,
.cursor/mcp.json, .vscode/mcp.json) so any of these editors works
identically. Closing the editor window kills the MCP subprocess and
the agent flips to offline.
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

from .preferences import resolve_permission_mode
from . import self_update

WORKSPACES_ROOT = Path.home() / "meshcode"
REGISTRY_PATH = WORKSPACES_ROOT / ".registry.json"


def _load_registry() -> dict:
    if not REGISTRY_PATH.exists():
        return {}
    try:
        return json.loads(REGISTRY_PATH.read_text())
    except Exception:
        return {}


def _find_agent_workspace(agent: str, project: Optional[str] = None) -> Optional[Tuple[Path, str]]:
    """Look up the agent in the registry. Returns (workspace_path, project_name) or None.

    If multiple agents share the same name across projects, requires the
    user to disambiguate by passing project explicitly.
    """
    reg = _load_registry()
    agents = reg.get("agents", {})

    # Direct hit by agent name (current model: agent names unique within registry)
    info = agents.get(agent)
    if info:
        ws = Path(info["workspace"])
        if not ws.exists():
            print(f"[meshcode] ERROR: workspace dir for '{agent}' is missing: {ws}", file=sys.stderr)
            print(f"[meshcode]        Re-run: meshcode setup {info.get('project','<project>')} {agent}", file=sys.stderr)
            return None
        if project and info.get("project") != project:
            print(f"[meshcode] ERROR: agent '{agent}' belongs to project '{info.get('project')}', not '{project}'", file=sys.stderr)
            return None
        return ws, info.get("project", "")

    # Fallback: scan ~/meshcode for any dir matching <project>-<agent>
    if project:
        ws = WORKSPACES_ROOT / f"{project}-{agent}"
        if ws.exists():
            return ws, project
    else:
        # Scan all workspaces for any matching <*>-<agent>
        if WORKSPACES_ROOT.exists():
            matches = [p for p in WORKSPACES_ROOT.iterdir() if p.is_dir() and p.name.endswith(f"-{agent}")]
            if len(matches) == 1:
                return matches[0], matches[0].name.rsplit(f"-{agent}", 1)[0]
            if len(matches) > 1:
                print(f"[meshcode] ERROR: agent '{agent}' exists in multiple projects:", file=sys.stderr)
                for m in matches:
                    print(f"[meshcode]   {m.name}", file=sys.stderr)
                print(f"[meshcode] Disambiguate: meshcode run {agent} --project <name>", file=sys.stderr)
                return None

    print(f"[meshcode] ERROR: no workspace found for agent '{agent}'", file=sys.stderr)
    print(f"[meshcode]        Run `meshcode setup <project> {agent}` first.", file=sys.stderr)
    return None


def _detect_editor() -> Optional[str]:
    """Pick the user's preferred MCP-aware editor."""
    override = os.environ.get("MESHCODE_EDITOR", "").strip().lower()
    if override:
        if shutil.which(override):
            return override
        print(f"[meshcode] WARNING: MESHCODE_EDITOR='{override}' not found in PATH", file=sys.stderr)

    # Detection order: most likely to be installed + best per-workspace MCP
    # support first. codex is last because its MCP config is GLOBAL only —
    # launching it doesn't take a workspace-scoped .mcp.json, so it should
    # only be picked if nothing else is available.
    for cmd in ("claude", "cursor", "code", "windsurf", "codex"):
        if shutil.which(cmd):
            return cmd
    return None


def run(agent: str, project: Optional[str] = None, editor_override: Optional[str] = None, permission_override: Optional[str] = None) -> int:
    """Launch the user's editor with ONLY the named agent's MCP server loaded."""
    # Non-blocking self-update check (consumes prior result, may spawn bg pip)
    try:
        self_update.check_and_maybe_update()
    except Exception:
        pass

    # Detect: are we already inside a Claude Code session? os.execvp(claude)
    # from inside an existing claude won't work — claude needs a fresh
    # interactive terminal it owns. Refuse with a clear message.
    if os.environ.get("CLAUDECODE") == "1" or os.environ.get("CLAUDE_CODE_SESSION"):
        print("[meshcode] ERROR: meshcode run cannot bootstrap a new agent from inside an", file=sys.stderr)
        print("[meshcode]        existing Claude Code session.", file=sys.stderr)
        print("[meshcode]        Open a fresh Terminal / iTerm window and run the command there.", file=sys.stderr)
        print(f"[meshcode]        (or copy this exact line into a new terminal: meshcode run {agent})", file=sys.stderr)
        return 2

    found = _find_agent_workspace(agent, project)
    if not found:
        return 2
    ws, resolved_project = found
    server_id = f"meshcode-{resolved_project}-{agent}"

    editor = editor_override or _detect_editor()
    if not editor:
        print("[meshcode] ERROR: no MCP-aware editor found in PATH (claude / cursor / code).", file=sys.stderr)
        print(f"[meshcode]        Workspace is ready at: {ws}", file=sys.stderr)
        print("[meshcode]        Open it manually with the editor of your choice.", file=sys.stderr)
        return 2

    print(f"[meshcode] Launching {editor} for agent '{agent}' (project: {resolved_project})")
    print(f"[meshcode]   Workspace: {ws}")
    print(f"[meshcode]   MCP server: {server_id}")
    print(f"[meshcode]   Closing the editor will flip this agent offline.")
    print()

    if editor == "claude":
        # Claude Code: pass --mcp-config to point at the workspace's .mcp.json
        # and --strict-mcp-config so it ignores ~/.claude.json's mcpServers.
        mode = resolve_permission_mode(permission_override)
        cmd = [
            editor,
            "--mcp-config", str(ws / ".mcp.json"),
        ]
        if mode == "bypass":
            cmd.append("--dangerously-skip-permissions")
            print(f"[meshcode]   Permission mode: bypass (autonomous loop, no prompts)")
        else:
            print(f"[meshcode]   Permission mode: safe (Claude will prompt for every tool call)")
            print(f"[meshcode]   Tip: change with `meshcode prefs permission-mode bypass`")
        try:
            os.chdir(ws)
        except Exception:
            pass
    elif editor == "cursor":
        # Cursor reads .cursor/mcp.json from the workspace cwd.
        cmd = [editor, str(ws)]
    elif editor == "code":
        # VS Code (Cline reads .vscode/mcp.json from workspace cwd).
        cmd = [editor, str(ws)]
    elif editor == "windsurf":
        # Windsurf (Codeium fork of VS Code) — reads workspace cwd the same
        # way VS Code does; global MCP config at ~/.codeium/windsurf/mcp_config.json.
        cmd = [editor, str(ws)]
    elif editor == "codex":
        # Codex CLI reads ~/.codex/config.toml globally. There's no per-
        # workspace flag, so launching is just `codex` with cwd set to the
        # workspace dir so any file ops the agent does land there.
        try:
            os.chdir(ws)
        except Exception:
            pass
        cmd = [editor]
    else:
        cmd = [editor, str(ws)]

    try:
        # Replace this process with the editor so the user gets a clean tab.
        os.execvp(cmd[0], cmd)
    except FileNotFoundError:
        print(f"[meshcode] ERROR: '{editor}' not found in PATH", file=sys.stderr)
        return 127
    except Exception as e:
        print(f"[meshcode] ERROR launching {editor}: {e}", file=sys.stderr)
        return 1
