# QA STLC Agents — Claude Code Guide

> **Before working on any task in this repo, read `AGENT-BEHAVIOR.md` first.**
> It defines the zero-inference contract that governs all agent decisions.
> The key rules below are a summary — `AGENT-BEHAVIOR.md` is the authoritative source.

## What this repo is

Five MCP servers for the QA Software Test Life Cycle. Each server is a Python package
in `src/stlc_agents/` sharing auth modules. Browser interaction at
generation time is handled by the external **Playwright MCP** server — not this package.

Both ADO and Jira pipelines run the full STLC flow:
**fetch → analyse AC → create test cases → generate Gherkin → generate Playwright → write Helix-QA files.**
`qa-test-case-manager` is the ADO entry point; `qa-jira-manager` is the Jira entry point.
Agents 2–4 (`qa-gherkin-generator`, `qa-playwright-generator`, `qa-helix-writer`) are shared.

## Architecture

```
src/stlc_agents/
├── shared/auth.py                              ← MSAL token cache (never modify)
├── shared_jira/auth.py                         ← Jira OAuth 2.0 token cache (never modify)
├── agent_test_case_manager/server.py           ← qa-test-case-manager  (ADO: fetch + create test cases)
├── agent_gherkin_generator/server.py           ← qa-gherkin-generator  (ADO + Jira: Gherkin generation)
├── agent_playwright_generator/server.py        ← qa-playwright-generator (Gherkin → Playwright TS + healer scaffolds)
├── agent_helix_writer/server.py                ← qa-helix-writer       (write files to Helix-QA on disk)
├── agent_jira_manager/server.py                ← qa-jira-manager       (Jira: fetch + create test cases)
└── agent_migration/                            ← qa-migration / stlc-migrate CLI
    ├── _migrate.py                             ← orchestrator: file pipeline + scaffold + skill install
    ├── mapper.py                               ← source-path → helix-target mapping
    ├── detector.py                             ← framework detection (playwright-{js,ts,bdd-js,bdd-ts})
    ├── cli.py                                  ← `stlc-migrate --source X --helix Y [--integration both]`
    └── transformer/
        ├── js_to_ts.py                         ← require → import, etc.
        ├── locator_moderniser.py               ← [data-testid] → getByTestId, etc.
        ├── locator_registrar.py                ← string → {selector, intent, stability}
        ├── healer_injector.py                  ← page.click → _healer.clickWithHealing
        ├── import_fixer.py                     ← consults mapper for authoritative target paths
        ├── spec_to_bdd.py                      ← lossless one-scenario-per-test conversion
        ├── config_merger.py                    ← package.json / tsconfig / cucumber.js / .env.example
        └── local_var_hoister.py                ← inline locators → centralised locator object
```

## Development commands

```bash
make install-ado      # create .venv + pip install -e . (prints ADO next steps)
make install-jira     # create .venv + pip install -e . (prints Jira next steps)
make install-both     # create .venv + pip install -e . (prints Both next steps)
make test             # run pytest tests/ -v
make skills-ado       # install ADO skill files to .claude/skills/ + copilot-instructions/
make skills-jira      # install Jira skill files
make skills-both      # install all skill files
make verify-ado       # check ADO agents + MSAL auth
make verify-jira      # check Jira agents + OAuth token cache
make mcp-config-ado   # write .mcp.json for ADO pipeline
make mcp-config-jira  # write .mcp.json for Jira pipeline
make mcp-config-both  # write .mcp.json for both pipelines
make clean            # remove .venv, __pycache__, dist
```

### Migration (existing Playwright project → Helix-QA layout)

```bash
# stlc-migrate ships as a console script after `pip install -e .`
stlc-migrate --source <existing-project> --helix <target> --dry-run
stlc-migrate --source <existing-project> --helix <target> --integration both
stlc-migrate --source <existing-project> --helix <target> --conflict overwrite
```

Outputs:
- All source files transformed into Helix-QA layout (page objects with healer
  wiring, locator files in `{selector, intent, stability}` form, `.feature` files
  for non-BDD `.spec.*` sources via lossless one-scenario-per-test conversion).
- Self-healing infra in `src/utils/locators/`: `LocatorHealer.ts` (8-strategy
  chain), `LocatorRepository.ts` (heal-only persist with schema v1 envelope,
  per-env file suffix, debounced writes), `HealingDashboard.ts` (Confirm/Revert
  UI that writes back to locator files), `TimingHealer.ts`, `VisualIntentChecker.ts`,
  `dashboard-server.ts` (launcher for `npm run healix:dashboard|review`).
- Agent assets: `.mcp.json`, `.claude/skills/<name>/SKILL.md`,
  `.github/copilot-instructions/<name>.md`, `AGENT-BEHAVIOR.md`,
  `ORCHESTRATION_RULES.md` — `--integration ado|jira|both` controls which.
- Boilerplate fill: 11 files from `agent_helix_writer.tools.boilerplate.BOILERPLATE`
  (allow-listed in `_BOILERPLATE_FILL_ALLOWLIST` — strategy / rules / apply /
  helpers / config). Never overwrites an existing file.

The migrate-framework skill (`skills/migrate-framework/SKILL.md`) is the
authoritative reference for the pipeline + every runtime env var.

Start Playwright MCP before running any generation workflow:
```bash
npx @playwright/mcp@latest --port 8931
# headless: npx @playwright/mcp@latest --headless --port 8931
```

## Key rules

### Coding rules (repo structure)

1. `shared/auth.py` — **do not change** the `_ADO_SCOPE`, `_DEFAULT_CLIENT_ID`, or
   `_CACHE_FILE` constants. They must match `microsoft/azure-devops-mcp` exactly.

2. Agent servers expose tools via `@app.list_tools()` and `@app.call_tool()`.
   No LLM calls inside the servers — reasoning lives in the skill files.

3. `agent_playwright_generator/server.py` contains all TypeScript code-generation
   logic as Python strings. When updating generated code patterns, update the
   corresponding `_generate_*` or `_gen_*` function. Note: the f-strings are
   sensitive — single `{` / `}` in doc comments and embedded regex patterns
   must be doubled (`{{` / `}}`) to escape Python interpolation. The dashboard
   write-back helper (`LocatorHealer_rewriteEntrySelector`) lives at module
   scope to keep the regex backslashes manageable; class-scope nesting is
   harder to reason about under the f-string template.

4. `inspect_live_page` has been removed from agent 3. Browser interaction is now
   handled by the external Playwright MCP server (`playwright:browser_navigate`,
   `playwright:browser_snapshot`, etc.). The coding agent builds a `context_map`
   from Playwright MCP snapshots and passes it to `generate_playwright_code`.

5. `DevToolsHealer.ts` uses Playwright's built-in `CDPSession` at **test runtime** —
   this is separate from the Playwright MCP server used at generation time.

6. **Migration scaffolds vs BOILERPLATE.** `_scaffold_locator_repository` emits
   the enhanced `LocatorHealer` / `LocatorRepository` / `TimingHealer` /
   `VisualIntentChecker` / `HealingDashboard` / `dashboard-server`. The
   `agent_helix_writer.tools.boilerplate.BOILERPLATE` map contains an older
   parallel set of the same files plus other infra. The migration tool ALWAYS
   prefers the enhanced scaffold for the 5 files they overlap on (because the
   enhanced ones have `HEAL_STORE_PATH`, schema v1, debounced persist, write-
   back, etc.). Only files in `_BOILERPLATE_FILL_ALLOWLIST` (in `_migrate.py`)
   are filled from BOILERPLATE — the held-back ones reference symbols
   (`HealerLogger`, `HealEvent`) the enhanced scaffold doesn't export.

7. **Healer chain order is data-driven.** `LocatorHealer.STRATEGY_ORDER` is
   parsed once from `HEAL_STRATEGY_ORDER` (CSV) at class-load time. Strategies
   named `attribute` / `type-hint` / `role` / `label` / `text` dispatch through
   `_runStrategy(name, ...)`. After any strategy attaches a locator,
   `_resolveSpecificSelector(loc, fallback)` introspects the matched element
   and returns the most stable single-attribute selector — that's what gets
   persisted, NOT the search union the strategy used to find the element.

6. Tests in `tests/test_imports.py` must pass without live ADO connectivity or a
   browser. All tests that touch auth or ADO must be skipped or mocked.

### Agent behavior rules (read `AGENT-BEHAVIOR.md` for full detail)

7. **Work item type routing for Gherkin generation (strict — no inference):**
   - Epic ID   → ⛔ Not supported — warn user; ask for a Feature or PBI/Bug ID
   - Feature ID → `fetch_feature_hierarchy`
   - PBI/Bug ID → `fetch_work_item_for_gherkin`
   - Unknown type → call fetch tool; read `work_item_type` from response; never guess

8. **Manual test cases must NEVER be created for an Epic.**
   Both `fetch_work_item` and `create_and_link_test_cases` return `epic_not_supported`.

9. **Feature-scoped test case creation requires explicit user confirmation.**
   Server returns `confirmation_required: true`. Surface to user; wait for "yes"; abort on "no".

10. **Each artifact delivery decision is independent — no carry-over.**
    - Gherkin ADO/Jira attachment: ask the user after generating
    - Playwright ADO/Jira attachment: ask the user separately — never inferred from Gherkin decision
    - Test case creation (ADO or Jira): ask the user separately — never inferred from any prior answer
    - Local file creation: only when user explicitly requests it
    - Helix disk write: only when user explicitly requests it

11. **Never invent test data, screen names, or acceptance criteria.**
    Stop and ask the user. Write `<!-- TODO: confirm screen name -->` placeholders for
    unknown navigation paths — do not guess.

12. **Never proceed past a gap.** Deduplication protocol Phase 1 is mandatory before
    creating any artifact. Gap check is mandatory before writing any Gherkin or navigating
    any live screen. Stop and wait for user answers when gaps are found.

13. **When updating instructions:** update `AGENT-BEHAVIOR.md` first, then the relevant
    `skills/*.md` file, then run `make skills-ado`, `make skills-jira`, or `make skills-both`
    to sync `.claude/skills/` and `.github/copilot-instructions/`. Update the change log in `AGENT-BEHAVIOR.md`.

## Module paths (import these, not agent1/agent2/agent3)

```python
# Agent 1 — ADO test case manager
from stlc_agents.agent_test_case_manager.server import main, app
from stlc_agents.agent_test_case_manager.tools.ado_workitem import fetch_work_item

# Agent 2 — Gherkin generator (ADO + Jira)
from stlc_agents.agent_gherkin_generator.server import main, app
from stlc_agents.agent_gherkin_generator.tools.ado_gherkin import fetch_feature_hierarchy

# Agent 3 — Playwright generator (ADO + Jira)
from stlc_agents.agent_playwright_generator.server import (
    main, app, _generate_playwright_code, _scaffold_locator_repository, _parse_gherkin_steps
)
from stlc_agents.agent_playwright_generator.tools.ado_attach import attach_file_to_work_item

# Agent 4 — Helix writer (ADO + Jira)
from stlc_agents.agent_helix_writer.server import main, app
from stlc_agents.agent_helix_writer.tools.helix_write import (
    write_files_to_helix,
    read_helix_file,
    list_helix_tree,
)

# Agent 5 — Jira manager
from stlc_agents.agent_jira_manager.server import main, app
from stlc_agents.agent_jira_manager.tools.jira_workitem import (
    fetch_work_item,
    create_test_case,
    link_test_cases_to_issue,
    get_linked_test_cases,
)

# Shared — ADO auth
from stlc_agents.shared.auth import get_auth_headers, get_signed_in_user

# Shared — Jira auth
from stlc_agents.shared_jira.auth import get_auth_headers, get_cloud_id, get_signed_in_user
```

## Adding a new tool

1. Add the tool definition to `@app.list_tools()` in the relevant `server.py`
2. Add the handler in `@app.call_tool()`
3. If it needs ADO REST calls, add the function to `tools/ado_*.py`
   If it needs Jira REST calls, add the function to `tools/jira_*.py`
4. Update the corresponding skill file in `skills/`
5. Add a test to `tests/test_imports.py`

# Agent 4 — Helix Writer

`agent_helix_writer` has no ADO dependency and no LLM calls.
It only writes already-generated files to disk at the correct Helix-QA paths.

Tool routing:
  1. `list_helix_tree`  — always call first to see what already exists
  2. `read_helix_file`  — read a specific file for deduplication
  3. `write_helix_files` — pass the `files` dict from `generate_playwright_code`
                           or `scaffold_locator_repository` directly

Directory mapping (Helix-QA layout):
  locators.ts          → src/locators/<kebab>.locators.ts
  <Page>.page.ts       → src/pages/<Page>.page.ts
  <feature>.steps.ts   → src/test/steps/<feature>.steps.ts
  <feature>.feature    → src/test/features/<feature>.feature
  cucumber profile key → src/config/cucumber.config.ts  (appended, not replaced)
  utils/locators/*.ts  → src/utils/locators/<file>

## Skill files

Skills live in `skills/`. They are Markdown files that teach a coding agent the
step-by-step workflow for each STLC phase. They reference tool names directly.
Keep them accurate — they are the primary documentation for the agents.