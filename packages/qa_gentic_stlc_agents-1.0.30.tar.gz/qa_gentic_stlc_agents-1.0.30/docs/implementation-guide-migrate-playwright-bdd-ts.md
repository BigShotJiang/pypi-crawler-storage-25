# Implementation Guide — Migrate Playwright + BDD + TypeScript

**Scenario:** Project already has Playwright + Cucumber + TypeScript — `.feature` files,
step definitions, page objects, maybe some locator helpers. Goal is to migrate into the
Helix-QA self-healing structure and put test generation under the STLC pipeline.

---

## Phase 0 — Audit Existing BDD Project

Map the existing project to the Helix-QA layout before running any agent.

```
Existing layout → Helix-QA target
─────────────────────────────────────────────────────────
features/**/*.feature        → src/test/features/
step_definitions/**/*.ts     → src/test/steps/
pages/**/*.ts                → src/pages/
locators/**/*.ts (if any)    → src/locators/   ← key migration target
cucumber.config.ts           → src/config/cucumber.config.ts
```

Audit checklist:
1. **Feature files** — are scenarios tagged `@smoke` / `@regression`? If not, tag them now
2. **Step definitions** — are locators inline (`page.locator(...)`) or in a shared object?
3. **Page objects** — do they extend a base class? Note the pattern for Agent 3 to follow
4. **Duplicate steps** — run `validate_gherkin_steps` on each `.feature` to surface conflicts
5. **Work item linkage** — note which feature file maps to which ADO Feature / PBI or Jira Story

---

## Phase 1 — Bootstrap the STLC Pipeline

```bash
npm install -g @qa-gentic/stlc-agents
qa-stlc init --integration ado          # or --integration jira / both
npx @playwright/mcp@latest --port 8931
```

**Do not run `qa-stlc scaffold`** — the project already has a Cucumber skeleton.
Instead, let Agent 4 write into the existing directory via `mode: tests_only`.

Set `.env` — same keys as a greenfield install.

---

## Phase 2 — Register Existing Feature Files with Agents (No Re-generation)

For feature files that are already good quality and linked to a work item:

| Step | Action |
|---|---|
| 1 | `fetch_work_item_for_gherkin` → confirm the AC matches what the `.feature` covers |
| 2 | `validate_gherkin_content` on the existing `.feature` — fix any structural issues flagged |
| 3 | `attach_gherkin_to_work_item` → link the existing file to the ADO / Jira work item |
| 4 | Skip Agent 3 re-generation for this work item — flag it as migrated in a tracking sheet |

This preserves your existing test logic while bringing it under the pipeline.

---

## Phase 3 — Migrate Locators into LocatorRepository

This is the highest-value step. It replaces fragile inline selectors with the
self-healing `LocatorRepository` pattern.

1. **Run `scaffold_locator_repository` once** — generates `LocatorHealer.ts`,
   `TimingHealer.ts`, `VisualIntentChecker.ts`, `LocatorRepository.ts`,
   `HealingDashboard.ts` into `src/utils/locators/`
2. **For each page object**, extract all `page.locator(...)` calls:
   - Move `data-testid` selectors → `locators.ts` (stability = 1)
   - Move ARIA role selectors → `locators.ts` (stability = 1)
   - CSS class / XPath selectors → move to `locators.ts` with a healing fallback chain
3. **Update page objects** to import from `LocatorRepository` instead of calling
   `page.locator()` directly
4. **Verify step definitions** still compile — no interface changes, only import source changes

---

## Phase 4 — Identify Gaps and Re-generate

For features or work items where step definitions have stubs, TODOs, or are missing:

| Step | Agent / Tool | Action |
|---|---|
| 1 | Playwright MCP | `browser_navigate` → `browser_snapshot` on each feature's screens |
| 2 | `qa-playwright-generator` | `generate_playwright_code` with `context_map` + existing `gherkin_content` |
| 3 | Review diff | Compare generated output against existing steps — merge non-conflicting new steps |
| 4 | `qa-helix-writer` | `inspect_helix_project` → `write_helix_files` (`mode: tests_only`) |

Agent 4 `tests_only` mode never overwrites existing files — it conflict-renames
any collision as `*_generated_<timestamp>.ts` for manual review.

---

## Phase 5 — Validate and Cut Over CI

1. Replace the Playwright runner (`playwright test`) with the Cucumber runner if not already done:
   ```bash
   cucumber-js --config=config/cucumber.js -p <profile> --tags "@smoke"
   ```
2. Run full regression once, review the healing dashboard at `http://localhost:7890`
3. Approve any AI-suggested locator fallbacks; reject and fix at source if a `data-testid`
   can be added to the app instead
4. Once all suites are green, set up the webhook bridge for headless triggering

---

## Phase 6 — Headless Triggers for Net-New Work Items

All new work items from this point forward flow through the full headless pipeline.
The migrated tests are maintained by re-running Agent 3 on AC changes — Agent 4
`tests_only` mode ensures existing passing tests are never overwritten.

---

## Key Success Criteria

- All `.feature` files are attached to their ADO / Jira work items via Agent 2
- All locators live in `src/locators/*.locators.ts` — zero inline `page.locator()` in step files
- `scaffold_locator_repository` has been run once; healing infrastructure is in `src/utils/locators/`
- CI runs the Cucumber runner; tags `@smoke` and `@regression` are working filters
- No conflict-renamed `_generated_*` files remain unreviewed in the Helix-QA tree
