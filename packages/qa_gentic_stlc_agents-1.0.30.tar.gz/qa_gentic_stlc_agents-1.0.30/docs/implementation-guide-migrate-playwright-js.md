# Implementation Guide — Migrate Conventional Playwright + JavaScript

**Scenario:** Project has Playwright + JavaScript tests (no BDD, no TypeScript) using
`page.locator()` calls scattered across test files. Goal is to migrate to the
self-healing Helix-QA stack and bring the tests under the STLC pipeline.

---

## Phase 0 — Audit Existing Tests

Before touching any agent, take stock of what exists:

1. **Inventory test files** — list all `*.spec.js` / `*.test.js` files and map each to
   a feature area or ADO/Jira work item
2. **Identify selector patterns** — run:
   ```bash
   grep -rn "locator\|getBy\|fill\|click" tests/ | grep -v node_modules > locator-audit.txt
   ```
3. **Flag fragile selectors** — CSS class chains, XPath, positional selectors
   (`nth-child`, `first()`) are migration candidates; `data-testid` and ARIA role
   selectors are keep-as-is
4. **Map coverage gaps** — work items with no existing test file are net-new candidates
   for the full pipeline; work items with tests are refactor candidates

---

## Phase 1 — Bootstrap the STLC Pipeline

```bash
npm install -g @qa-gentic/stlc-agents
qa-stlc init --integration ado          # or --integration jira
qa-stlc scaffold --name <project>-qa    # creates TypeScript Helix-QA skeleton
npx @playwright/mcp@latest --port 8931
```

Set `.env` — same as a greenfield install (ADO PAT, APP_BASE_URL, AI provider key).

---

## Phase 2 — Convert Existing Tests (Feature-by-Feature)

For each existing `*.spec.js` file:

| Step | Action |
|---|---|
| 1 | Link the spec file to its ADO / Jira work item (use the title to find the WI) |
| 2 | Run `fetch_work_item_for_gherkin` on that WI — extract its acceptance criteria |
| 3 | Generate Gherkin from the AC (Agent 2). Map existing test assertions to `Then` steps |
| 4 | Navigate the live app with Playwright MCP; `browser_snapshot` on each relevant screen |
| 5 | Run `generate_playwright_code` with `context_map` from the snapshot |
| 6 | **Reconcile locators:** compare generated `locators.ts` against the existing `*.spec.js`; promote any `data-testid` locators from the old file; discard class-chain selectors |
| 7 | Write to Helix-QA via Agent 4 (`mode: scaffold_and_tests`) |
| 8 | Delete or archive the original `*.spec.js` after validating the new step definitions run green |

**Do not batch-convert.** Convert one feature area per sprint to keep CI green.

---

## Phase 3 — Locator Repository Scaffold (Run Once)

```
qa-playwright-generator → scaffold_locator_repository
```

This generates `LocatorHealer.ts`, `TimingHealer.ts`, `VisualIntentChecker.ts`,
`LocatorRepository.ts`, and `HealingDashboard.ts` into `src/utils/locators/`.
All migrated step definitions reference `LocatorRepository` instead of raw `page.locator()`.

---

## Phase 4 — Selector Remediation Strategy

| Old selector pattern | Migration action |
|---|---|
| `data-testid="…"` | Copy directly into `locators.ts` — stability = 1 |
| ARIA role (`getByRole`) | Copy directly — stability = 1 |
| CSS class (`.btn-primary`) | Request `data-testid` from dev; use healing fallback until added |
| XPath (`//div[2]/span`) | Replace via live snapshot — never carry forward |
| Text match (`getByText`) | Keep only if text is static; flag dynamic text for `data-testid` |

---

## Phase 5 — Automate Triggers

Same as greenfield Phase 4. New work items from this point forward go through the
full headless pipeline; old migrated tests live in Helix-QA and are maintained by
re-running Agent 3 whenever AC changes.

---

## Key Success Criteria

- Zero `*.spec.js` files remain in the old test directory
- All active locators in `locators.ts` have stability ≥ 0.8 (CSS fallback accepted short-term)
- `LocatorRepository.ts` is the single source of truth — no raw `page.locator()` in step files
- CI pipeline runs `cucumber-js` not `playwright test` (Cucumber runner replaces Playwright runner)
- Healing dashboard shows locator fallback rate per sprint; target: 0% XPath by end of migration
