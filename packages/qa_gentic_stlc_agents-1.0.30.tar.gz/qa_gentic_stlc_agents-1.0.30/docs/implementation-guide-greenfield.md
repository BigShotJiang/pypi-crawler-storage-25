# Implementation Guide — Greenfield Project (No Existing Automation)

**Scenario:** Application has no test automation. Dev team needs to add `data-testid` attributes
as a foundation, then build out the full STLC pipeline with these agents.

---

## Phase 0 — Developer Instrumentation (Before Agents)

**Goal:** Establish stable, agent-readable locators in the application source.

1. Agree on a naming convention with developers:
   `data-testid="<component>-<element>-<action>"` — e.g. `data-testid="login-email-input"`
2. Prioritise instrumentation in order: **forms → buttons → navigation → headings → tables**
3. Create a shared locator registry (a spreadsheet or ADO wiki page) mapping
   `data-testid` values to feature areas — this feeds Agent 3's `context_map`
4. Gate: no test generation begins until the target screen has `data-testid` attributes
   for every acceptance-criteria-relevant element

---

## Phase 1 — Bootstrap the STLC Pipeline

```bash
npm install -g @qa-gentic/stlc-agents
qa-stlc init --integration ado          # or --integration jira
qa-stlc scaffold --name <project>-qa    # creates Helix-QA skeleton
npx @playwright/mcp@latest --port 8931  # keep running in a separate terminal
```

Set `.env`:
```
ADO_ORGANIZATION_URL / JIRA_CLIENT_ID …
APP_BASE_URL=https://your-app.example.com
AI_HEALING_PROVIDER=anthropic
AI_HEALING_API_KEY=sk-ant-…
```

---

## Phase 2 — First Work Item (Manual + Interactive)

Run through this sequence once manually to validate the pipeline end-to-end.

| Step | Agent / Tool | Action |
|---|---|---|
| 1 | `qa-test-case-manager` | `fetch_work_item` → review AC |
| 2 | Agent 1 | `create_and_link_test_cases` → confirm in ADO / Jira |
| 3 | `qa-gherkin-generator` | `fetch_work_item_for_gherkin` → generate → `validate_gherkin_content` |
| 4 | Agent 2 | `attach_gherkin_to_work_item` → confirm attachment in ADO |
| 5 | Playwright MCP | `browser_navigate` → `browser_snapshot` → build `context_map` |
| 6 | `qa-playwright-generator` | `generate_playwright_code` with `context_map` |
| 7 | `qa-helix-writer` | `inspect_helix_project` → `write_helix_files` (mode: scaffold_and_tests) |
| 8 | `qa-playwright-generator` | `scaffold_locator_repository` (run **once** per project) |

---

## Phase 3 — Validate & Iterate

- Run `cucumber-js --config=config/cucumber.js -p <profile> --tags "@smoke"`
- Review healing dashboard at `http://localhost:7890`; approve any AI-suggested locator fixes
- Feed failures back: if a locator resolves to the wrong element, update the `data-testid`
  in the app source and re-run Agent 3 for that work item only

---

## Key Success Criteria

- Every generated locator traces back to a `data-testid` attribute (stability = 1)
- `scaffold_locator_repository` has been run once; `LocatorHealer.ts` is in `src/utils/locators/`
- No work item triggers the pipeline twice without deduplication passing silently
- Healing dashboard shows zero pending AI approvals before a sprint release
