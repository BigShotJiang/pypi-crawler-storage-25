# Skill: migrate-framework

Migrate an existing Playwright test framework to the Helix-QA agent-compatible
structure with full self-healing support.

## When to use this skill

Trigger on any of:
- "migrate my Playwright tests"
- "convert existing tests to Helix"
- "migrate playwright+cucumber project"
- "bring old tests into the agent framework"
- "stlc-migrate", "qa-migration", "migrate_framework" tool names

## Supported source frameworks

| Framework | Detection |
|-----------|-----------|
| Plain Playwright JS | `playwright.config.js`, no `.feature` files |
| Plain Playwright TS | `playwright.config.ts`, no `.feature` files |
| Playwright + Cucumber JS | `playwright.config.js` + `.feature` files or `@cucumber/cucumber` in package.json |
| Playwright + Cucumber TS | `playwright.config.ts` + `.feature` files or `@cucumber/cucumber` in package.json |

## Step-by-step workflow

### Step 1 — Confirm source and target directories

Ask the user for:
- **Source directory** — root of the existing Playwright project (must exist)
- **Helix root** — root of the Helix-QA project to migrate into (must exist unless dry-run)

### Step 2 — Detect the framework

```
detect_framework(source_dir=<source>)
```

Report back:
- `framework` — one of: `playwright-bdd-ts`, `playwright-bdd-js`, `playwright-ts`, `playwright-js`
- `language` — `typescript` or `javascript`
- `bdd` — whether BDD/Cucumber files were found
- `file_counts` — number of `.ts`, `.js`, `.feature` files found

### Step 3 — Preview the migration plan

```
preview_migration(source_dir=<source>, helix_root=<helix>)
```

Show the user:
- Total mappable files and their roles
- Any conflicts (files already existing in Helix)
- Files with unknown/unrecognised roles that will be skipped

Ask the user to confirm before proceeding if there are conflicts.

### Step 4 — Run the migration

```
migrate_framework(
  source_dir=<source>,
  helix_root=<helix>,
  conflict_strategy="interactive",   # or "overwrite" / "skip"
  dry_run=false
)
```

The tool applies this pipeline to each file:

| Step | What happens |
|------|-------------|
| JS → TS | `require(...)` → `import`, `module.exports` → `export default`, async return types added |
| Locator modernisation | `[data-testid]` → `getByTestId`, `text=` → `getByText`, `[aria-label]` → `getByLabel`, `[placeholder]` → `getByPlaceholder`, `role=X[name=Y]` → `getByRole`. Complex XPath/CSS flagged with `// TODO` |
| Healer injection | ALL `page.click` → `_healer.clickWithHealing`, `page.fill` → `_healer.fillWithHealing`, `page.goto` → wrapped with `TimingHealer`, `expect.toBeVisible` → preceded by `VisualIntentChecker.check`. Applied to page objects, step definitions, AND helper files |
| Import fixing | Relative imports remapped to Helix structure; infra imports replaced with `@utils/locators/*` aliases |
| Config merge | `playwright.config` settings merged into Helix `playwright.config.ts`; cucumber profiles merged into `src/config/cucumber.config.ts` |

### Step 5 — Review the migration report

The tool writes `MIGRATION-REPORT.md` to the Helix root. Report back to the user:
- Number of files written / skipped / conflicted
- TODO count (locators needing manual review)
- Path to `MIGRATION-REPORT.md`

### Step 6 — Post-migration steps (tell the user)

After migration, the user should:
1. Run `make install` to reinstall with the new file layout
2. Review all `// TODO: convert to getByRole` comments in locator files
3. Review all `// TODO: initialize healers` comments in generic helper files
4. Run `npx tsc --noEmit` to check for TypeScript errors
5. Run `make test` to verify existing tests still pass
6. Optionally scaffold the locator repository infra:
   ```
   scaffold_locator_repository(output_dir="src/utils/locators", ...)
   ```

## Helix-QA file layout

| Source role | Helix target |
|-------------|-------------|
| Locators (`*Locators.ts`, `*selectors.ts`) | `src/locators/<kebab>.locators.ts` |
| Page objects (`*Page.ts`, `*.page.ts`) | `src/pages/<kebab>.page.ts` |
| Step definitions (`*.steps.ts`, `step_definitions/**`) | `src/test/steps/<kebab>.steps.ts` |
| Feature files (`*.feature`) | `src/test/features/<kebab>.feature` |
| Playwright config | `playwright.config.ts` (merged) |
| Cucumber config | `src/config/cucumber.config.ts` (merged) |

## CLI usage (terminal)

```bash
# Preview migration without writing
stlc-migrate --source ./my-old-tests --helix ./helix-qa --dry-run

# Full migration (interactive conflict handling)
stlc-migrate --source ./my-old-tests --helix ./helix-qa

# Overwrite all existing files
stlc-migrate --source ./my-old-tests --helix ./helix-qa --conflict overwrite

# JSON output for scripting
stlc-migrate --source ./my-old-tests --helix ./helix-qa --json

# Makefile shortcut
make migrate-preview SOURCE=./my-old-tests HELIX=./helix-qa
```

## Key rules

1. **Always run `preview_migration` first** — review the plan and conflicts before writing.
2. **Never infer conflict decisions** — ask the user whether to overwrite, skip, or abort.
3. **TODO comments are not errors** — complex locators flagged with `// TODO` are valid output; inform the user they need manual review.
4. **Feature files are copied as-is** — no Gherkin transformation is applied to `.feature` files during migration.
5. **The healer init is injected** — but healer instance variables (`_healer`, `_timing`, `_visual`) are local to each function/constructor. If the migrated page object extends `BasePage`, the existing `this.healer` from `BasePage` will be used instead.
6. **Config merge is non-destructive** — existing settings in Helix configs are never overwritten; only missing settings are added.
