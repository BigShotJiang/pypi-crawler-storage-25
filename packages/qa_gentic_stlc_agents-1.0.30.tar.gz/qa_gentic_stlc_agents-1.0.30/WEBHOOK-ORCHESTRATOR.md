# Webhook Orchestrator

Receives state-change webhooks from **Azure DevOps** or **Jira Cloud** and
automatically drives the correct agent pipeline — without deviating from
each agent's own behaviour, validation gates, or skill constraints.

## State → Pipeline mapping

| State (ADO) | State (Jira) | Pipeline triggered |
|---|---|---|
| Active, In Progress, Committed, In Review | In Progress, Active, In Development, In Review | **Agent 1** (ADO) or **Agent 5** (Jira) — generate & link manual test cases |
| Resolved, Done, Closed, Completed | Done, Resolved, Closed, Completed, Released | **Agent 2 → 3 → 4** — Gherkin → Playwright TS → Helix-QA write |

## Install

```bash
pip install 'qa-stlc-agents[webhook]'
```

## Configure

Copy `.env.example` to `.env` and fill in:

```dotenv
# ADO
ADO_ORGANIZATION_URL=https://dev.azure.com/yourorg
ADO_PROJECT_NAME=YourProject

# Jira
JIRA_CLOUD_ID=your-cloud-id

# LLM (generates test case payloads and Gherkin)
LLM_PROVIDER=anthropic          # anthropic | openai | copilot | ollama | grok | deepseek
ANTHROPIC_API_KEY=sk-ant-...    # or OPENAI_API_KEY / GITHUB_TOKEN / XAI_API_KEY / DEEPSEEK_API_KEY

# Helix-QA (leave blank to skip Agent 4)
HELIX_PROJECT_ROOT=/path/to/helix-qa-project
```

## Run

```bash
qa-stlc-webhook --port 8080

# or via uvicorn directly:
uvicorn stlc_agents.webhook_orchestrator.webhook_bridge:app --port 8080 --reload
```

## Register webhooks

### Azure DevOps
1. Project Settings → Service Hooks → New subscription → Web Hooks
2. Event: **Work item updated**
3. Filters: State changes to any (or specific states)
4. URL: `http://your-server:8080/webhook/ado`
5. Optional: set a shared secret and add to `ADO_WEBHOOK_SECRET`

### Jira Cloud
1. Settings → System → WebHooks → Create a WebHook
2. Events: **Issue updated**, **Issue created**
3. URL: `http://your-server:8080/webhook/jira`
4. Optional: configure shared secret and add to `JIRA_WEBHOOK_SECRET`

## LLM providers

| `LLM_PROVIDER` | Auth env var | Notes |
|---|---|---|
| `anthropic` (default) | `ANTHROPIC_API_KEY` | Direct Anthropic API |
| `openai` | `OPENAI_API_KEY` | GPT-4o default |
| `copilot` | `GITHUB_TOKEN` | GitHub Copilot chat completions |
| `ollama` | none | Set `LLM_BASE_URL=http://localhost:11434/v1` |
| `grok` | `XAI_API_KEY` | xAI Grok |
| `deepseek` | `DEEPSEEK_API_KEY` | DeepSeek Chat |

## Architecture

```
Webhook (ADO/Jira)
       │
       ▼
webhook_bridge.py   ← parses payload, verifies HMAC signature
       │
       ▼
orchestrator.py     ← classify_state() → PipelineStage
       │
  ┌────┴─────────────────────────────┐
  │ Active state                     │ Resolved state
  ▼                                  ▼
Agent 1 (ADO)                    Agent 2 (Gherkin)
  fetch_work_item                  fetch_feature_hierarchy /
  get_linked_test_cases            fetch_work_item_for_gherkin
  [LLM: generate payloads]         [LLM: generate Gherkin]
  create_and_link_test_cases       attach_gherkin_to_feature /
                                   attach_gherkin_to_work_item
Agent 5 (Jira)                       │
  fetch_jira_issue                 Agent 3 (Playwright)
  get_linked_test_cases              generate_playwright_code
  [LLM: generate payloads]           attach_code_to_work_item
  create_and_link_test_cases           │
                                   Agent 4 (Helix writer)
                                     inspect_helix_project
                                     write_helix_files
```

All agent calls go through the MCP stdio protocol — the orchestrator does not
bypass agent validation gates, confirmation prompts (auto-confirmed in webhook
context), or skill constraints.
