"""
models.py — Shared data models for the webhook orchestrator.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any


class Platform(str, enum.Enum):
    ADO  = "ado"
    JIRA = "jira"


class PipelineStage(str, enum.Enum):
    TEST_CASES         = "test_cases"
    GHERKIN_PLAYWRIGHT = "gherkin_playwright"
    FULL               = "full"
    SKIP               = "skip"


@dataclass
class WebhookEvent:
    platform: Platform
    work_item_id: str
    state: str
    work_item_type: str
    title: str = ""
    previous_state: str = ""

    # ADO-specific
    organization_url: str = ""
    project_name: str = ""

    # Jira-specific
    cloud_id: str = ""
    project_key: str = ""

    # Common optional
    helix_project_root: str = ""
    app_base_url: str = ""
    app_username: str = ""
    app_password: str = ""

    # LLM
    llm_provider: str = "anthropic"
    llm_model: str = ""
    llm_api_key: str = ""
    llm_base_url: str = ""

    # Agent extra kwargs
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineResult:
    success: bool
    steps: list[str] = field(default_factory=list)
    error: str = ""

    def to_dict(self) -> dict:
        return {"success": self.success, "steps": self.steps, "error": self.error}
