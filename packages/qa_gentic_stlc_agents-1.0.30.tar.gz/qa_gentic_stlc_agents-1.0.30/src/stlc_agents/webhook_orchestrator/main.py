"""
Entry point for the qa-stlc-webhook CLI command.

Usage:
  qa-stlc-webhook [--port PORT] [--host HOST]

  Or via uvicorn directly:
  uvicorn stlc_agents.webhook_orchestrator.webhook_bridge:app --port 8080
"""
from __future__ import annotations

import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description="STLC Agents Webhook Bridge")
    parser.add_argument("--port", type=int, default=8080, help="Port to listen on (default: 8080)")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind (default: 0.0.0.0)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (dev mode)")
    args = parser.parse_args()

    try:
        import uvicorn
    except ImportError:
        print(
            "ERROR: uvicorn is not installed. "
            "Install the webhook extra: pip install 'qa-stlc-agents[webhook]'",
            file=sys.stderr,
        )
        sys.exit(1)

    uvicorn.run(
        "stlc_agents.webhook_orchestrator.webhook_bridge:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="info",
    )


if __name__ == "__main__":
    main()
