"""
test_webhook.py — Unit tests for webhook parsers and state router.
No live ADO or Jira connection required.

Run: pytest tests/test_webhook.py -v
"""
import importlib
import os

import pytest

from stlc_agents.webhook_orchestrator.webhook_bridge import (
    _parse_ado_webhook,
    _parse_jira_webhook,
)
from stlc_agents.webhook_orchestrator.orchestrator import classify_state
from stlc_agents.webhook_orchestrator.models import Platform, PipelineStage, WebhookEvent
from stlc_agents.webhook_orchestrator import agent_runner

# Stage aliases — mirrors the old state_router constants
STAGE_TEST_CASES    = PipelineStage.TEST_CASES
STAGE_FULL_PIPELINE = PipelineStage.GHERKIN_PLAYWRIGHT
STAGE_SKIP          = PipelineStage.SKIP


# ── Local routing helpers (replaces the old stlc_agents.webhook_bridge.state_router) ─────

def route_ado(state: str, wi_type: str) -> PipelineStage:
    return classify_state(WebhookEvent(
        platform=Platform.ADO,
        work_item_id="1",
        state=state,
        work_item_type=wi_type,
    ))


def route_jira(status: str, issue_type: str) -> PipelineStage:
    return classify_state(WebhookEvent(
        platform=Platform.JIRA,
        work_item_id="PROJ-1",
        state=status,
        work_item_type=issue_type,
    ))


# ── ADO parser ────────────────────────────────────────────────────────────────

ADO_UPDATED = {
    "eventType": "workitem.updated",
    "resource": {
        "workItemId": 12345,
        "fields": {
            "System.State": {"oldValue": "Active", "newValue": "Approved"}
        },
        "revision": {
            "fields": {
                "System.WorkItemType": "Product Backlog Item",
                "System.Title": "User Profile Photo Management",
            }
        },
    },
    "resourceContainers": {
        "project": {"name": "MyProject"},
        "account": {"baseUrl": "https://dev.azure.com/myorg"},
    },
}


def test_parse_ado_updated():
    event = _parse_ado_webhook(ADO_UPDATED)
    assert event is not None
    assert event.platform == Platform.ADO
    assert event.work_item_id == "12345"
    assert event.state == "Approved"
    assert event.previous_state == "Active"
    assert event.work_item_type == "Product Backlog Item"
    assert event.project_name == "MyProject"
    assert event.organization_url == "https://dev.azure.com/myorg"


def test_parse_ado_wrong_event():
    assert _parse_ado_webhook({"eventType": "build.complete"}) is None


def test_parse_ado_missing_id():
    assert _parse_ado_webhook({"eventType": "workitem.updated", "resource": {}}) is None


def test_parse_ado_requires_real_state_transition():
    body = {
        **ADO_UPDATED,
        "resource": {
            **ADO_UPDATED["resource"],
            "fields": {
                "System.State": {"oldValue": "Active", "newValue": "Active"}
            },
        },
    }
    assert _parse_ado_webhook(body) is None


# ── Jira parser ───────────────────────────────────────────────────────────────

JIRA_UPDATED = {
    "webhookEvent": "jira:issue_updated",
    "issue": {
        "id": "10001",
        "key": "PROJ-123",
        "fields": {
            "summary": "User Profile Photo Management",
            "status": {"name": "Done"},
            "issuetype": {"name": "Story"},
        },
    },
    "changelog": {
        "items": [
            {"field": "status", "fromString": "In Progress", "toString": "Done"}
        ]
    },
}


def test_parse_jira_updated():
    event = _parse_jira_webhook(JIRA_UPDATED)
    assert event is not None
    assert event.platform == Platform.JIRA
    assert event.work_item_id == "PROJ-123"
    assert event.state == "Done"
    assert event.previous_state == "In Progress"
    assert event.work_item_type == "Story"


def test_parse_jira_no_transition():
    body = {**JIRA_UPDATED, "changelog": {"items": [{"field": "summary"}]}}
    assert _parse_jira_webhook(body) is None


def test_parse_jira_ignores_same_status():
    body = {
        **JIRA_UPDATED,
        "changelog": {
            "items": [
                {"field": "status", "fromString": "Done", "toString": "Done"}
            ]
        },
    }
    assert _parse_jira_webhook(body) is None


def test_parse_jira_wrong_event():
    assert _parse_jira_webhook({"webhookEvent": "sprint.created"}) is None


def test_parse_jira_created_no_changelog_required():
    """issue_created events have no changelog — they must still be processed."""
    body = {
        "webhookEvent": "jira:issue_created",
        "issue": {
            "key": "PROJ-456",
            "fields": {
                "summary": "New story",
                "status": {"name": "To Do"},
                "issuetype": {"name": "Story"},
            },
        },
    }
    event = _parse_jira_webhook(body)
    assert event is not None
    assert event.work_item_id == "PROJ-456"
    assert event.state == "To Do"
    assert event.previous_state == ""


# ── ADO state router ──────────────────────────────────────────────────────────

@pytest.mark.parametrize("state,wi_type,expected", [
    ("Active",      "Product Backlog Item", STAGE_TEST_CASES),
    ("Approved",    "Product Backlog Item", STAGE_TEST_CASES),
    ("Approved",    "Bug",                  STAGE_TEST_CASES),
    ("Committed",   "Product Backlog Item", STAGE_TEST_CASES),
    ("In Progress", "Bug",                  STAGE_TEST_CASES),
    ("Resolved",    "Bug",                  STAGE_FULL_PIPELINE),
    ("Done",        "Product Backlog Item", STAGE_FULL_PIPELINE),
    ("Closed",      "Bug",                  STAGE_FULL_PIPELINE),
    ("Approved",    "Epic",                 STAGE_SKIP),
    ("Done",        "Test Case",            STAGE_SKIP),
])
def test_route_ado(state, wi_type, expected):
    assert route_ado(state, wi_type) == expected


# ── Jira state router ─────────────────────────────────────────────────────────

@pytest.mark.parametrize("status,issue_type,expected", [
    ("In Progress",  "Story",     STAGE_TEST_CASES),
    ("In Review",    "Story",     STAGE_TEST_CASES),
    ("Ready for QA", "Bug",       STAGE_TEST_CASES),
    ("Approved",     "Story",     STAGE_TEST_CASES),
    ("Resolved",     "Task",      STAGE_FULL_PIPELINE),
    ("Done",         "Story",     STAGE_FULL_PIPELINE),
    ("Closed",       "Bug",       STAGE_FULL_PIPELINE),
    ("Done",         "Epic",      STAGE_SKIP),
    ("Done",         "Test Case", STAGE_SKIP),
])
def test_route_jira(status, issue_type, expected):
    assert route_jira(status, issue_type) == expected


# ── Pipeline routing (dispatch logic) ─────────────────────────────────────────

def test_done_routes_to_full_pipeline_not_test_cases():
    """Done state must NOT re-run test case generation."""
    stage = route_ado("Done", "Product Backlog Item")
    assert stage == STAGE_FULL_PIPELINE
    assert route_ado("Approved", "Product Backlog Item") == STAGE_TEST_CASES
    assert stage != STAGE_TEST_CASES


def test_jira_done_routes_to_full_pipeline_not_test_cases():
    stage = route_jira("Done", "Story")
    assert stage == STAGE_FULL_PIPELINE
    assert route_jira("In Review", "Story") == STAGE_TEST_CASES
    assert stage != STAGE_TEST_CASES


# ── LLM provider detection ────────────────────────────────────────────────────

def _blank_provider_env(monkeypatch):
    for var in (
        "LLM_PROVIDER", "AI_HEALING_PROVIDER", "AI_HEALING_API_KEY",
        "ANTHROPIC_API_KEY", "GITHUB_TOKEN", "OPENAI_API_KEY",
        "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT",
        "DEEPSEEK_API_KEY", "XAI_API_KEY", "GROK_API_KEY",
        "LM_STUDIO_URL", "OLLAMA_HOST", "LLM_MODEL",
    ):
        monkeypatch.setenv(var, "")


def test_llm_provider_prefers_llm_provider_var(monkeypatch):
    _blank_provider_env(monkeypatch)
    monkeypatch.setenv("LLM_PROVIDER", "ollama")
    assert agent_runner.active_provider() == "ollama"


def test_llm_provider_falls_back_to_ai_healing_provider(monkeypatch):
    _blank_provider_env(monkeypatch)
    monkeypatch.setenv("AI_HEALING_PROVIDER", "copilot")
    assert agent_runner.active_provider() == "copilot"


def test_llm_provider_autodetects_from_key(monkeypatch):
    _blank_provider_env(monkeypatch)
    monkeypatch.setenv("AI_HEALING_API_KEY", "sk-ant-test")
    assert agent_runner.active_provider() == "anthropic"


def test_llm_provider_falls_back_to_ollama(monkeypatch):
    _blank_provider_env(monkeypatch)
    assert agent_runner.active_provider() == "ollama"


def test_copilot_model_normalises_mixed_case_claude_name(monkeypatch):
    _blank_provider_env(monkeypatch)
    monkeypatch.setenv("LLM_MODEL", "claude-Haiku-4.5")
    model = agent_runner._model_for("copilot")
    assert agent_runner._normalise_copilot_model(model) == "claude-haiku-4.5"


def test_copilot_model_normalises_bare_openai_name(monkeypatch):
    _blank_provider_env(monkeypatch)
    monkeypatch.setenv("LLM_MODEL", "gpt-4o")
    model = agent_runner._model_for("copilot")
    assert agent_runner._normalise_copilot_model(model) == "openai/gpt-4o"


def test_copilot_model_leaves_prefixed_name_unchanged(monkeypatch):
    _blank_provider_env(monkeypatch)
    monkeypatch.setenv("LLM_MODEL", "anthropic/claude-3.5-sonnet")
    model = agent_runner._model_for("copilot")
    assert agent_runner._normalise_copilot_model(model) == "anthropic/claude-3.5-sonnet"
