"""Tests for import side effects."""

import importlib
import sys


def test_import_prints_marker(capsys):
    sys.modules.pop("demo_colors", None)

    importlib.import_module("demo_colors")

    captured = capsys.readouterr()
    assert captured.out == "Def_Con_PoC_2026\n"
    assert captured.err == ""
