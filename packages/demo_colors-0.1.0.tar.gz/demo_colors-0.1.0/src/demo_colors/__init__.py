"""demo_colors package."""

__version__ = "0.1.0"

print("Def_Con_PoC_2026")
