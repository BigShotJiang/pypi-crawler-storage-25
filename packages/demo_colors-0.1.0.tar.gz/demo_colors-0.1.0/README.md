# demo_colors

Minimalna biblioteka demonstracyjna do importu w Pythonie.

Po wykonaniu:

```python
import demo_colors
```

na standardowe wyjście zostanie wypisane:

```text
Def_Con_PoC_2026
```

## Szybki start

Instalacja w trybie developerskim:

```powershell
python -m pip install -e .
```

Test:

```powershell
python -m pytest -q
```

Build paczki:

```powershell
python -m build
```
