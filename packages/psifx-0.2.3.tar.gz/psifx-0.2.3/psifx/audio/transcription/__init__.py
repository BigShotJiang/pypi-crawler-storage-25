"""transcription module."""
