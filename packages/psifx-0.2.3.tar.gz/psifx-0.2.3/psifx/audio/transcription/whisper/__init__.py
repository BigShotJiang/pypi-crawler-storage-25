"""whisperx transcription module."""
