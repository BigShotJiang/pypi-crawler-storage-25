"""audio processing module."""
