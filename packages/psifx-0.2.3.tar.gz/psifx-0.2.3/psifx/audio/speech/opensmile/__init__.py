"""openSMILE speech processing module."""
