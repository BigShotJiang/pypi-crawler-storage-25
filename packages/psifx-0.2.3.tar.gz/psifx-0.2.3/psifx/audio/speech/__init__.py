"""speech processing module."""
