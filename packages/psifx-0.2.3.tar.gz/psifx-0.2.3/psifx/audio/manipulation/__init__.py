"""audio manipulation module."""
