"""speaker identification module."""
