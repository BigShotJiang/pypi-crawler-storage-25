"""pyannote speaker identification module."""
