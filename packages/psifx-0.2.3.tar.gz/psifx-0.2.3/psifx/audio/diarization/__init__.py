"""speaker diarization module."""
