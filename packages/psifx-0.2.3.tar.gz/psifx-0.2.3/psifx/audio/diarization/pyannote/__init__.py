"""pyannote speaker diarization module."""
