"""video manipulation module."""
