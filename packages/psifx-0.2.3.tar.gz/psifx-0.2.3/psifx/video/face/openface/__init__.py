"""OpenFace face analysis module."""
