"""MediaPipe pose estimation module."""
