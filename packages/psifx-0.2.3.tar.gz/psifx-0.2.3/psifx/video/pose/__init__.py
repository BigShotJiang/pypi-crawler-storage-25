"""pose estimation module."""
