"""utility module."""
