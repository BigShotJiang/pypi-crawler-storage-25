"""Built-in model pricing table.

Costs are in USD per token (not per 1K tokens). We maintain this table so the
SDK can estimate `cost_usd` without any user configuration.  Prices should be
updated periodically as providers change their rates.
"""

from __future__ import annotations

from typing import Optional

# fmt: off
MODEL_COSTS: dict[str, dict[str, float]] = {
    # OpenAI
    "gpt-4o":                {"input": 2.50  / 1_000_000, "output": 10.00 / 1_000_000},
    "gpt-4o-2024-11-20":     {"input": 2.50  / 1_000_000, "output": 10.00 / 1_000_000},
    "gpt-4o-2024-08-06":     {"input": 2.50  / 1_000_000, "output": 10.00 / 1_000_000},
    "gpt-4o-2024-05-13":     {"input": 5.00  / 1_000_000, "output": 15.00 / 1_000_000},
    "gpt-4o-mini":           {"input": 0.15  / 1_000_000, "output": 0.60  / 1_000_000},
    "gpt-4o-mini-2024-07-18":{"input": 0.15  / 1_000_000, "output": 0.60  / 1_000_000},
    "gpt-4-turbo":           {"input": 10.00 / 1_000_000, "output": 30.00 / 1_000_000},
    "gpt-4":                 {"input": 30.00 / 1_000_000, "output": 60.00 / 1_000_000},
    "gpt-3.5-turbo":         {"input": 0.50  / 1_000_000, "output": 1.50  / 1_000_000},
    "o1":                    {"input": 15.00 / 1_000_000, "output": 60.00 / 1_000_000},
    "o1-mini":               {"input": 3.00  / 1_000_000, "output": 12.00 / 1_000_000},
    "o1-preview":            {"input": 15.00 / 1_000_000, "output": 60.00 / 1_000_000},
    "o3-mini":               {"input": 1.10  / 1_000_000, "output": 4.40  / 1_000_000},

    # Anthropic
    "claude-3-5-sonnet-20241022": {"input": 3.00 / 1_000_000, "output": 15.00 / 1_000_000},
    "claude-3-5-sonnet-20240620": {"input": 3.00 / 1_000_000, "output": 15.00 / 1_000_000},
    "claude-3-5-haiku-20241022":  {"input": 0.80 / 1_000_000, "output": 4.00  / 1_000_000},
    "claude-3-opus-20240229":     {"input": 15.00/ 1_000_000, "output": 75.00 / 1_000_000},
    "claude-3-sonnet-20240229":   {"input": 3.00 / 1_000_000, "output": 15.00 / 1_000_000},
    "claude-3-haiku-20240307":    {"input": 0.25 / 1_000_000, "output": 1.25  / 1_000_000},
    "claude-sonnet-4-20250514":   {"input": 3.00 / 1_000_000, "output": 15.00 / 1_000_000},
    "claude-haiku-4-20250514":    {"input": 0.80 / 1_000_000, "output": 4.00  / 1_000_000},
}
# fmt: on

# Prefix aliases so "gpt-4o-2024-*" matches even if the exact snapshot isn't listed.
_PREFIX_MAP: dict[str, str] = {
    "gpt-4o-mini": "gpt-4o-mini",
    "gpt-4o": "gpt-4o",
    "gpt-4-turbo": "gpt-4-turbo",
    "gpt-4": "gpt-4",
    "gpt-3.5-turbo": "gpt-3.5-turbo",
    "o3-mini": "o3-mini",
    "o1-mini": "o1-mini",
    "o1-preview": "o1-preview",
    "o1": "o1",
    "claude-3-5-sonnet": "claude-3-5-sonnet-20241022",
    "claude-3-5-haiku": "claude-3-5-haiku-20241022",
    "claude-3-opus": "claude-3-opus-20240229",
    "claude-3-sonnet": "claude-3-sonnet-20240229",
    "claude-3-haiku": "claude-3-haiku-20240307",
    "claude-sonnet-4": "claude-sonnet-4-20250514",
    "claude-haiku-4": "claude-haiku-4-20250514",
}


def _resolve_model(model: str) -> Optional[str]:
    if model in MODEL_COSTS:
        return model
    for prefix, canonical in _PREFIX_MAP.items():
        if model.startswith(prefix):
            return canonical
    return None


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
) -> Optional[float]:
    """Return estimated USD cost, or None if the model is unknown."""
    resolved = _resolve_model(model)
    if resolved is None:
        return None
    costs = MODEL_COSTS[resolved]
    return input_tokens * costs["input"] + output_tokens * costs["output"]
