"""SpyLLM Python SDK — two-line automatic LLM tracing.

Usage::

    import spyllm
    spyllm.init(api_key="sk-...")

    # Every OpenAI / Anthropic call is now auto-traced.
"""

from __future__ import annotations

from typing import Optional

from .client import SpyLLMClient, agent_trace

__all__ = [
    "init",
    "shutdown",
    "SpyLLMClient",
    "agent_trace",
]

_client: Optional[SpyLLMClient] = None


def init(
    api_key: str,
    *,
    base_url: str = "https://api.spyllm.dev",
    instrument: bool = True,
) -> SpyLLMClient:
    """Initialise the SpyLLM SDK.

    This creates a background batcher, monkey-patches supported LLM providers,
    and returns a client instance for manual tracing if needed.

    Args:
        api_key: Your SpyLLM API key.
        base_url: Override the API endpoint (useful for self-hosted).
        instrument: If True (default), auto-patch OpenAI and Anthropic.
    """
    global _client

    from .batcher import TraceBatcher
    from . import instrumentor

    batcher = TraceBatcher(api_key=api_key, base_url=base_url)
    instrumentor._batcher = batcher

    _client = SpyLLMClient(api_key=api_key, base_url=base_url)

    if instrument:
        instrumentor.patch_all()

    return _client


def shutdown() -> None:
    """Flush pending traces and shut down the background thread."""
    from . import instrumentor

    if instrumentor._batcher is not None:
        instrumentor._batcher.shutdown()
