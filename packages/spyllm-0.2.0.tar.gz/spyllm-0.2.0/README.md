# SpyLLM Python SDK

Automatic LLM tracing in two lines. Works with OpenAI, Anthropic, and more.

## Quick Start

```python
import spyllm

spyllm.init(api_key="sk-...")

# That's it. Every OpenAI and Anthropic call is now automatically traced.
from openai import OpenAI

client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
)
# Prompt, response, tokens, cost, and latency are captured automatically.
```

## Install

```bash
pip install spyllm
```

## What Gets Captured

Every LLM call automatically records:

- **Prompt** — full message history sent to the model
- **Response** — the model's output
- **Token count** — input + output tokens
- **Cost** — estimated USD cost based on model pricing
- **Latency** — wall-clock time for the API call
- **Tool calls** — if the model invoked tools/functions
- **Errors** — failed calls with the exception message

## Supported Providers

| Provider   | Auto-instrumented |
|------------|-------------------|
| OpenAI     | Yes               |
| Anthropic  | Yes               |

## Advanced Usage

### Manual Tracing

```python
from spyllm import SpyLLMClient

client = SpyLLMClient(api_key="sk-...", base_url="https://api.spyllm.com")
client.trace(
    agent_name="my-agent",
    prompt="What is 2+2?",
    response="4",
    token_count=15,
    cost_usd=0.001,
)
```

### Decorator

```python
from spyllm import agent_trace, init

init(api_key="sk-...")

@agent_trace("my-pipeline")
def run_pipeline(query: str) -> str:
    # your code here
    return result
```

### Disable Auto-instrumentation

```python
spyllm.init(api_key="sk-...", instrument=False)
```
