from beet import *
from .core import *
from .cli import main as main
from .plugins.initialize.source_lore_font import find_pack_png as find_pack_png
from .plugins.resource_pack.item_models.object import AutoModel as AutoModel
from .plugins.resource_pack.sounds import add_sound as add_sound
from typing import Any

def beet_default(ctx: Context) -> Any:
    """ Initializes the StewBeet package. """
