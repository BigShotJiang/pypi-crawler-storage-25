class InvalidException(Exception):
    "Exception raised for invalid URL"
    def __init__(self, message="The provided URL is invalid"):
        self.message = message
        super().__init__(self.message)
        