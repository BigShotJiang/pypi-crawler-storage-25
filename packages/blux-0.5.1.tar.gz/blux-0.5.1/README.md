# blux
面向 Bilibili 场景的无状态工具库，提供 BV/AV 互转、文档打分、文本整理、WBI 签名、搜索和公开资源下载等能力。

![](https://img.shields.io/pypi/v/blux?label=blux&color=blue&cacheSeconds=60)


## 模块

- `blux.bvs`: AV/BV 互转工具
- `blux.doc_score`: 文档互动分值计算
- `blux.text_doc`: 标题、标签、简介拼接与 MD5 标识生成
- `blux.wbi`: WBI 签名和 `dm_img` 参数生成
- `blux.search`: Bilibili 搜索客户端与数据模型
- `blux.download`: 面向公开资源的下载工具


## 文档索引

- [BV/AV 互转](docs/bvs/README.md)
- [文档打分](docs/doc_score/README.md)
- [文本工具](docs/text_doc/README.md)
- [WBI 签名](docs/wbi/README.md)
- [搜索使用指南](docs/search/USAGE.md)
- [搜索 API 记录](docs/search/API.md)
- [下载模块](docs/download/README.md)
- [顶层 CLI](docs/package/CLI.md)


## 命令行

```sh
blux bv av-to-bv 100
blux search all 猫和老鼠
blux dl snapshot BV1YXZPB1Erc
blux dl all BV1YXZPB1Erc
```


## 安装

```sh
pip install blux --upgrade
```

`blux` 只保留无状态能力。持久化存储、缓存策略和服务编排应放在仓库外部的独立层中。


## 开发

```sh
pip install -e .[dev]
git config core.hooksPath .githooks
pytest
```