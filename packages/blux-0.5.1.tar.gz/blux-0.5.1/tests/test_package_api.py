import blux


def test_root_package_exports_backward_compatible_helpers() -> None:
    assert blux.av_to_bv(100) == "BV1xx411c7mW"
    assert blux.bv_to_av("BV1xx411c7mW") == 100
    assert hasattr(blux, "BiliSearcher")
    assert hasattr(blux, "BiliDownloader")


def test_subpackages_are_importable() -> None:
    import blux.bvs
    import blux.doc_score
    import blux.download
    import blux.search
    import blux.text_doc
    import blux.wbi

    assert blux.bvs.av_to_bv(100) == "BV1xx411c7mW"
