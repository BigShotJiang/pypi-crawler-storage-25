import json

from pathlib import Path

from blux.download import (
    BiliDownloader,
    DEFAULT_VIDEO_QN,
    DEFAULT_WORKERS,
    DownloadSettings,
    PlayInfo,
    SnapshotInfo,
    VideoPage,
    VideoView,
)
from blux.download.models import MediaStream


class StubDownloadClient:
    def __init__(self):
        self.calls: list[str] = []

    def fetch_video_view(self, bvid: str) -> VideoView:
        self.calls.append("view")
        return VideoView(
            aid=123,
            bvid=bvid,
            cid=456,
            title="测试视频",
            desc="desc",
            pic="https://i0.hdslb.com/bfs/cover/test.jpg",
            owner_name="作者",
            owner_mid=789,
            pages=[VideoPage(page=1, cid=456, part="P1", duration=10)],
        )

    def fetch_playinfo(
        self,
        video_view: VideoView,
        page_index: int = 1,
        video_qn: int = DEFAULT_VIDEO_QN,
    ) -> PlayInfo:
        self.calls.append("playinfo")
        return PlayInfo(
            video_streams=[
                MediaStream(
                    kind="video",
                    id=video_qn,
                    quality_label="360P",
                    codecs="avc1",
                    mime_type="video/mp4",
                    url="https://example.com/video.mp4",
                    bandwidth=100,
                )
            ],
            audio_streams=[
                MediaStream(
                    kind="audio",
                    id=30216,
                    quality_label="64K",
                    codecs="mp4a.40.2",
                    mime_type="audio/mp4",
                    url="https://example.com/audio.m4a",
                    bandwidth=10,
                )
            ],
            accepted_quality={video_qn: "360P"},
            timelength_ms=10000,
        )

    def fetch_snapshot_info(
        self,
        video_view: VideoView,
        page_index: int = 1,
        include_index: bool = True,
    ) -> SnapshotInfo:
        self.calls.append("snapshot")
        return SnapshotInfo(
            pvdata_url="https://example.com/snapshot.bin",
            image_urls=[
                "https://example.com/snapshot-1.jpg",
                "https://example.com/snapshot-2.jpg",
            ],
            index_points=[0, 10, 20],
            img_x_len=10,
            img_y_len=10,
            img_x_size=160,
            img_y_size=90,
        )

    def fetch_danmaku_xml(self, cid: int) -> bytes:
        self.calls.append("danmaku")
        return b"<i></i>"

    def download_bytes(self, url: str) -> bytes:
        self.calls.append(f"bytes:{url}")
        return url.encode("utf-8")

    def stream_to_path(
        self, urls: list[str], output_path: Path, referer: str, resume: bool = True
    ) -> tuple[str, int]:
        self.calls.append(f"stream:{urls[0]}")
        payload = f"downloaded:{urls[0]}".encode("utf-8")
        output_path.write_bytes(payload)
        return urls[0], len(payload)


def test_snapshot_download_avoids_playinfo_for_snapshot_only(tmp_path) -> None:
    client = StubDownloadClient()
    downloader = BiliDownloader(
        client=client, settings=DownloadSettings(output_root=tmp_path)
    )

    result = downloader.download("BV1test", {"snapshot"})

    assert "playinfo" not in client.calls
    assert any(artifact.kind == "snapshot_image" for artifact in result.artifacts)
    manifest = json.loads(
        (result.output_dir / "manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["snapshot"]["image_urls"] == [
        "https://example.com/snapshot-1.jpg",
        "https://example.com/snapshot-2.jpg",
    ]


def test_all_download_writes_expected_artifacts(tmp_path) -> None:
    client = StubDownloadClient()
    downloader = BiliDownloader(
        client=client, settings=DownloadSettings(output_root=tmp_path)
    )

    result = downloader.download(
        "BV1test", {"audio", "video", "snapshot", "danmaku", "cover"}
    )

    kinds = {artifact.kind for artifact in result.artifacts}
    assert {
        "audio",
        "video",
        "snapshot_pvdata",
        "snapshot_index",
        "snapshot_image",
        "danmaku",
        "cover",
    } <= kinds
    assert "playinfo" in client.calls


def test_download_many_preserves_input_order(tmp_path) -> None:
    client = StubDownloadClient()
    downloader = BiliDownloader(
        client=client, settings=DownloadSettings(output_root=tmp_path, workers=2)
    )

    results = downloader.download_many(["BV1b", "BV1a"], {"snapshot"}, workers=2)

    assert [result.bvid for result in results] == ["BV1b", "BV1a"]


def test_default_download_settings_prioritize_small_outputs() -> None:
    settings = DownloadSettings()

    assert DEFAULT_VIDEO_QN == 16
    assert DEFAULT_WORKERS == 2
    assert settings.video_qn == 16
    assert settings.audio_strategy == "lowest"
    assert settings.workers == 2


def test_inspect_returns_view_playinfo_and_snapshot(tmp_path) -> None:
    client = StubDownloadClient()
    downloader = BiliDownloader(
        client=client, settings=DownloadSettings(output_root=tmp_path)
    )

    video_view, playinfo, snapshot_info = downloader.inspect("BV1test")

    assert client.calls == ["view", "playinfo", "snapshot"]
    assert video_view.bvid == "BV1test"
    assert playinfo.video_streams[0].id == DEFAULT_VIDEO_QN
    assert snapshot_info.image_urls
