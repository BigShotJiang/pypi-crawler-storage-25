from dataclasses import dataclass
from pathlib import Path

DEFAULT_VIDEO_QN = 16
DEFAULT_WORKERS = 2


@dataclass
class DownloadSettings:
    output_root: Path = Path("downloads")
    video_qn: int = DEFAULT_VIDEO_QN
    audio_strategy: str = "lowest"
    workers: int = DEFAULT_WORKERS
    resume: bool = True
    timeout: int = 30
    page_index: int = 1
