import argparse
import json

from pathlib import Path

from .client import BiliVideoClient
from .config import DownloadSettings, DEFAULT_VIDEO_QN, DEFAULT_WORKERS
from .downloader import BiliDownloader


TARGETS_BY_COMMAND = {
    "audio": {"audio"},
    "video": {"video"},
    "snapshot": {"snapshot"},
    "cover": {"cover"},
    "danmaku": {"danmaku"},
    "all": {"audio", "video", "snapshot", "danmaku"},
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="blux dl", description="Download public Bilibili assets by bvid"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    info_parser = subparsers.add_parser(
        "info", help="Inspect available streams and metadata"
    )
    info_parser.add_argument("bvid")
    info_parser.add_argument("--page", type=int, default=1)
    info_parser.add_argument("--video-qn", type=int, default=DEFAULT_VIDEO_QN)

    for command in TARGETS_BY_COMMAND:
        cmd_parser = subparsers.add_parser(command, help=f"Download {command} assets")
        cmd_parser.add_argument("bvids", nargs="+")
        cmd_parser.add_argument("--page", type=int, default=1)
        cmd_parser.add_argument("--video-qn", type=int, default=DEFAULT_VIDEO_QN)
        cmd_parser.add_argument("--workers", type=int, default=DEFAULT_WORKERS)
        cmd_parser.add_argument("--output-root", type=Path)
        cmd_parser.add_argument(
            "--audio-strategy", choices=["lowest", "highest"], default="lowest"
        )
        cmd_parser.add_argument("--no-resume", action="store_true")
    return parser


def build_downloader(args: argparse.Namespace) -> BiliDownloader:
    settings = DownloadSettings(
        output_root=args.output_root or Path("downloads"),
        video_qn=getattr(args, "video_qn", DEFAULT_VIDEO_QN),
        audio_strategy=getattr(args, "audio_strategy", "lowest"),
        workers=getattr(args, "workers", DEFAULT_WORKERS),
        resume=not getattr(args, "no_resume", False),
        page_index=getattr(args, "page", 1),
    )
    return BiliDownloader(settings=settings)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "info":
        downloader = build_downloader(args)
        video_view, playinfo, snapshot_info = downloader.inspect(
            args.bvid,
            page_index=args.page,
            video_qn=args.video_qn,
        )
        payload = {
            "bvid": video_view.bvid,
            "aid": video_view.aid,
            "title": video_view.title,
            "pages": [page.__dict__ for page in video_view.pages],
            "video_streams": [stream.__dict__ for stream in playinfo.video_streams],
            "audio_streams": [stream.__dict__ for stream in playinfo.audio_streams],
            "accepted_quality": playinfo.accepted_quality,
            "snapshot": {
                "pvdata_url": snapshot_info.pvdata_url,
                "image_urls": snapshot_info.image_urls,
                "index_points": snapshot_info.index_points,
                "img_x_len": snapshot_info.img_x_len,
                "img_y_len": snapshot_info.img_y_len,
                "img_x_size": snapshot_info.img_x_size,
                "img_y_size": snapshot_info.img_y_size,
            },
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    downloader = build_downloader(args)
    results = downloader.download_many(
        args.bvids,
        TARGETS_BY_COMMAND[args.command],
        workers=args.workers,
        page_index=args.page,
        output_root=args.output_root,
        video_qn=args.video_qn,
        resume=not args.no_resume,
    )
    payload = [
        {
            "bvid": result.bvid,
            "title": result.title,
            "page_index": result.page_index,
            "output_dir": str(result.output_dir),
            "manifest_path": (
                str(result.manifest_path) if result.manifest_path else None
            ),
            "artifacts": [
                {
                    "kind": artifact.kind,
                    "path": str(artifact.path),
                    "source_url": artifact.source_url,
                    "bytes_written": artifact.bytes_written,
                }
                for artifact in result.artifacts
            ],
        }
        for result in results
    ]
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0
