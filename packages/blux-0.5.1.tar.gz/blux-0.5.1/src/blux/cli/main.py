import sys

from blux.bvs.cli import main as bvs_main
from blux.doc_score.cli import main as doc_score_main
from blux.download.cli import main as download_main
from blux.search.cli import main as search_main
from blux.text_doc.cli import main as text_main
from blux.wbi.cli import main as wbi_main

COMMANDS = {
    "bv": bvs_main,
    "score": doc_score_main,
    "text": text_main,
    "wbi": wbi_main,
    "search": search_main,
    "dl": download_main,
}


def _print_help() -> None:
    print(
        "Usage: blux <command> [args]\n\n"
        "Commands:\n"
        "  bv      AV/BV conversion helpers\n"
        "  score   Document scoring helpers\n"
        "  text    Text document helpers\n"
        "  wbi     WBI signing helpers\n"
        "  search  Bilibili search helpers\n"
        "  dl      Bilibili asset download helpers"
    )


def main(argv: list[str] | None = None) -> int:
    resolved_argv = list(sys.argv[1:] if argv is None else argv)
    if not resolved_argv or resolved_argv[0] in {"-h", "--help"}:
        _print_help()
        return 0
    command = resolved_argv[0]
    command_main = COMMANDS.get(command)
    if command_main is None:
        _print_help()
        raise SystemExit(2)
    return command_main(resolved_argv[1:])
