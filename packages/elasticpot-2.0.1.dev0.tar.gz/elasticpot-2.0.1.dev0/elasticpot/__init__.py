# elasticpot: the installable Python package for the elasticpot honeypot.
#
# After `pip install elasticpot`, use the `elasticpot` command:
#
#   elasticpot init    -- scaffold a working directory
#   elasticpot run     -- start the honeypot in the foreground
#   elasticpot start   -- start the honeypot in the background
#   elasticpot stop    -- stop the background honeypot
#   elasticpot restart -- restart the honeypot (stop and start the honeypot in
#                         the background)
#   elasticpot status  -- show running status
#
# NOTE: elasticpot/honeypot.py is generated at build time by the build_py
# hook in setup.py - it is a copy of the top-level honeypot.py bundled so
# that the `elasticpot run/start` entry point can locate and run it.
# It is listed in .gitignore and should not be committed.
#
# Contents:
#   cli.py        the `elasticpot` console entry point (init/run/start/stop/status)
#   honeypot.py   the main honeypot script (copied from repo root at build time)
#   data/         bundled read-only assets copied to the working directory
#                 by `elasticpot init`:
#     docs/       documentation and SQL schema files
#     etc/        default configuration templates
#     responses/  MongoDB wire-protocol response stubs
#     test/       test.py for verifying a running honeypot
