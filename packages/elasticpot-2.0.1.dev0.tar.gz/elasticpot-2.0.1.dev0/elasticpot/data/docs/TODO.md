# Planned Future Improvements

* Implement additional output plugins
