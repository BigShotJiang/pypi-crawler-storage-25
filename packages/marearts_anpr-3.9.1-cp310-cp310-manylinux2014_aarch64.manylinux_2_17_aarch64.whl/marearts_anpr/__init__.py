"""MareArts ANPR - License Plate Detection and Recognition"""

import os as _os

_saved_fd = _os.dup(2)
_devnull = _os.open(_os.devnull, _os.O_WRONLY)
_os.dup2(_devnull, 2)
_os.close(_devnull)
try:
    from ._version import __version__
    from .region_aliases import (
        normalize_region_alias,
        to_api_region,
        to_internal_region,
    )

    from .marearts_anpr import (
        marearts_anpr_from_pil,
        marearts_anpr_from_image_file,
        marearts_anpr_from_cv2
    )

    from .marearts_anpr_d import ma_anpr_detector
    from .marearts_anpr_d_v14 import ma_anpr_detector_v14
    from .marearts_anpr_d_v16 import ma_anpr_detector_v16
    from .marearts_anpr_r_v14 import ma_anpr_ocr_v14 as _ma_anpr_ocr_v14
    from .marearts_anpr_r_v15 import ma_anpr_ocr_v15 as _ma_anpr_ocr_v15
    from .marearts_anpr_r_v16 import ma_anpr_ocr_v16 as _ma_anpr_ocr_v16
    from .marearts_anpr_r_wrapper import ma_anpr_ocr as _ma_anpr_ocr
    from .marearts_anpr_p import (
        validate_user_key, validate_user_key_with_signature, validate_user_key_with_dates,
        download_anpr_ocr_v14_model, download_anpr_ocr_v15_model,
        download_anpr_detector_v16_model, download_anpr_ocr_v16_model,
    )
    from .marearts_anpr_mmc import ma_anpr_mmc
finally:
    _os.dup2(_saved_fd, 2)
    _os.close(_saved_fd)
    del _saved_fd, _devnull, _os


def ma_anpr_ocr_v14(model_name, region, *args, **kwargs):
    return _ma_anpr_ocr_v14(model_name, to_internal_region(region), *args, **kwargs)


def ma_anpr_ocr_v15(model_name, region, *args, **kwargs):
    return _ma_anpr_ocr_v15(model_name, to_internal_region(region), *args, **kwargs)


def ma_anpr_ocr_v16(model_name, region, *args, **kwargs):
    return _ma_anpr_ocr_v16(model_name, to_internal_region(region), *args, **kwargs)


def ma_anpr_ocr(model_name, region, *args, **kwargs):
    return _ma_anpr_ocr(model_name, to_internal_region(region), *args, **kwargs)

__all__ = [
    "__version__",
    "marearts_anpr_from_pil",
    "marearts_anpr_from_image_file",
    "marearts_anpr_from_cv2",
    "ma_anpr_detector",
    "ma_anpr_detector_v14",
    "ma_anpr_detector_v16",
    "ma_anpr_ocr",
    "ma_anpr_ocr_v14",
    "ma_anpr_ocr_v15",
    "ma_anpr_ocr_v16",
    "ma_anpr_mmc",
    "normalize_region_alias",
    "to_internal_region",
    "to_api_region",
    "validate_user_key",
    "validate_user_key_with_signature",
    "validate_user_key_with_dates",
    "download_anpr_ocr_v14_model",
    "download_anpr_ocr_v15_model",
    "download_anpr_detector_v16_model",
    "download_anpr_ocr_v16_model",
]
