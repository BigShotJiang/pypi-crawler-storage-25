from marearts_anpr.marearts_anpr_cli import *
