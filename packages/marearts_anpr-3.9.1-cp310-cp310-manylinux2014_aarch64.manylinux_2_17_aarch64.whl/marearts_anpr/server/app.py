from marearts_anpr.marearts_anpr_server_app import *
from marearts_anpr.marearts_anpr_server_app import state, health_monitor
