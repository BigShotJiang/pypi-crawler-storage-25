"""Entry point for: python -m marearts_anpr.server"""
import argparse
import sys


def main():
    parser = argparse.ArgumentParser(description="MareArts ANPR Server")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to listen on")
    parser.add_argument("--config", default=None, help="Path to server_config.yaml")
    args = parser.parse_args()

    try:
        import uvicorn
    except ImportError:
        print("Error: uvicorn not installed. Run: pip install uvicorn")
        sys.exit(1)

    from .config import load_config
    from pathlib import Path

    config = load_config(Path(args.config) if args.config else None)
    config["server"]["host"] = args.host
    config["server"]["port"] = args.port

    from .app import create_app
    app = create_app(config)

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level="warning",
        access_log=False,
    )


if __name__ == "__main__":
    main()
