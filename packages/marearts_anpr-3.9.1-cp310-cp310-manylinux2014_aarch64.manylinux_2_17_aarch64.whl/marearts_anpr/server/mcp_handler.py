from marearts_anpr.marearts_anpr_server_mcp import *
