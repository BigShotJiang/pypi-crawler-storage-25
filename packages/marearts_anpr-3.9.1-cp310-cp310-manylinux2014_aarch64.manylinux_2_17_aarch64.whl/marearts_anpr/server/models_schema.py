from typing import List, Optional
from pydantic import BaseModel


class DetectionResult(BaseModel):
    plate_text: str
    confidence: float
    bbox: List[float]
    detection_confidence: float
    mmc_make: Optional[str] = None
    mmc_make_conf: Optional[float] = None
    mmc_model: Optional[str] = None
    mmc_model_conf: Optional[float] = None
    mmc_color: Optional[str] = None
    mmc_color_conf: Optional[float] = None
    mmc_type: Optional[str] = None
    mmc_type_conf: Optional[float] = None
    mmc_plate: Optional[str] = None
    mmc_plate_conf: Optional[float] = None
    mmc_plate_nation: Optional[str] = None
    mmc_plate_nation_conf: Optional[float] = None
    mmc_vehicle_side: Optional[str] = None
    mmc_vehicle_side_conf: Optional[float] = None


class ANPRResponse(BaseModel):
    success: bool
    detection_id: Optional[int] = None
    timestamp: str = ""
    results: List[DetectionResult] = []
    processing_sec: float = 0.0
    detector_sec: float = 0.0
    ocr_sec: float = 0.0
    mmc_model_sec: Optional[float] = None
    mmc_request_sec: Optional[float] = None
    mmc_daily_limit: Optional[int] = None
    mmc_calls_today: Optional[int] = None
    mmc_request_id: Optional[str] = None
    mmc_error: Optional[str] = None
    error: Optional[str] = None


class BatchANPRResponse(BaseModel):
    total_images: int
    total_plates: int
    results: List[dict]


class Base64ImageRequest(BaseModel):
    image: str
    region: Optional[str] = None


class URLImageRequest(BaseModel):
    url: str
    region: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    version: str
    sdk_version: str
    models_loaded: bool
    credentials_configured: bool
    uptime: float
    detector_version: str
    ocr_version: str
    region: str


class ServerStats(BaseModel):
    total_detections: int = 0
    successful_detections: int = 0
    failed_detections: int = 0
    total_plates_found: int = 0
    avg_processing_sec: float = 0.0
    uptime: float = 0.0


class RegionsResponse(BaseModel):
    regions: List[str]
    aliases: dict


class WatchlistItem(BaseModel):
    plate: str
    label: str = ""


class WatchlistResponse(BaseModel):
    id: int
    plate: str
    label: str
    created_at: str


class AlertResponse(BaseModel):
    id: int
    timestamp: str
    plate: str
    watchlist_label: str
    detection_id: Optional[int]
    confidence: Optional[float]


class SearchRequest(BaseModel):
    query: str = ""
    date_from: Optional[str] = None
    date_to: Optional[str] = None
    min_confidence: float = 0
    limit: int = 100
    offset: int = 0
