"""MareArts ANPR Server - REST API, MCP, and Web Dashboard"""

__all__ = ["create_app", "start_server", "stop_server", "get_status"]
