from marearts_anpr.marearts_anpr_server_daemon import *
