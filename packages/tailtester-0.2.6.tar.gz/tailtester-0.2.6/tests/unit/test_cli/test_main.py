"""Tests for the tailtest CLI entry point."""

import pytest
from click.testing import CliRunner

from tailtest.cli.main import cli


@pytest.fixture
def runner():
    return CliRunner()


def test_version_shows_version(runner):
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "tailtest" in result.output
    assert "0.2.6" in result.output


def test_help_shows_commands(runner):
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "tailtest" in result.output.lower() or "pytest for AI agents" in result.output
    # Should list available subcommands
    assert "init" in result.output
    assert "scan" in result.output
    assert "run" in result.output


def test_unknown_command_shows_error(runner):
    result = runner.invoke(cli, ["nonexistent-command"])
    assert result.exit_code != 0


def test_help_shows_generate_command(runner):
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "generate" in result.output
