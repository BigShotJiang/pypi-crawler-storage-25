"""Tests for Phase 9 - Interactive Mode (Conversational UX).

Covers:
  - interactive detection (TTY, env var, flag)
  - ask / choose helpers
  - ConsentManager persistence and prompts
  - --no-interactive flag on all updated commands
  - interactive prompts in scan, run, redteam, report, generate
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import click
import pytest
from click.testing import CliRunner

from tailtest.cli.consent import ConsentManager
from tailtest.cli.interactive import ask, choose, is_interactive, no_interactive_option


# ======================================================================
# is_interactive
# ======================================================================


class TestIsInteractive:
    """Tests for the is_interactive() helper."""

    def test_is_interactive_detects_tty(self):
        """Returns True when both stdin and stdout are TTYs."""
        with (
            patch("tailtest.cli.interactive.sys.stdin") as mock_in,
            patch("tailtest.cli.interactive.sys.stdout") as mock_out,
            patch.dict(os.environ, {}, clear=False),
        ):
            # Remove env var if present
            os.environ.pop("TAILTEST_INTERACTIVE", None)
            mock_in.isatty.return_value = True
            mock_out.isatty.return_value = True
            assert is_interactive() is True

    def test_is_interactive_false_in_ci(self):
        """Returns False when stdin is not a TTY (e.g. CI pipe)."""
        with (
            patch("tailtest.cli.interactive.sys.stdin") as mock_in,
            patch("tailtest.cli.interactive.sys.stdout") as mock_out,
            patch.dict(os.environ, {}, clear=False),
        ):
            os.environ.pop("TAILTEST_INTERACTIVE", None)
            mock_in.isatty.return_value = False
            mock_out.isatty.return_value = True
            assert is_interactive() is False

    def test_is_interactive_false_when_stdout_not_tty(self):
        """Returns False when stdout is piped (not a TTY)."""
        with (
            patch("tailtest.cli.interactive.sys.stdin") as mock_in,
            patch("tailtest.cli.interactive.sys.stdout") as mock_out,
            patch.dict(os.environ, {}, clear=False),
        ):
            os.environ.pop("TAILTEST_INTERACTIVE", None)
            mock_in.isatty.return_value = True
            mock_out.isatty.return_value = False
            assert is_interactive() is False

    def test_env_var_enables_interactive(self):
        """TAILTEST_INTERACTIVE=1 forces interactive mode on."""
        with patch.dict(os.environ, {"TAILTEST_INTERACTIVE": "1"}):
            assert is_interactive() is True

    def test_env_var_disables_interactive(self):
        """TAILTEST_INTERACTIVE=0 forces interactive mode off."""
        with patch.dict(os.environ, {"TAILTEST_INTERACTIVE": "0"}):
            assert is_interactive() is False

    def test_env_var_false_string(self):
        """TAILTEST_INTERACTIVE=false forces interactive mode off."""
        with patch.dict(os.environ, {"TAILTEST_INTERACTIVE": "false"}):
            assert is_interactive() is False

    def test_env_var_no_string(self):
        """TAILTEST_INTERACTIVE=no forces interactive mode off."""
        with patch.dict(os.environ, {"TAILTEST_INTERACTIVE": "no"}):
            assert is_interactive() is False


# ======================================================================
# ask / choose
# ======================================================================


class TestAsk:
    """Tests for the ask() helper."""

    def test_ask_returns_default_when_not_interactive(self):
        """In non-interactive mode, ask() returns the default."""
        with patch("tailtest.cli.interactive.is_interactive", return_value=False):
            assert ask("Continue?", default=False) is False
            assert ask("Continue?", default=True) is True

    def test_ask_calls_confirm_when_interactive(self):
        """In interactive mode, ask() delegates to click.confirm."""
        with (
            patch("tailtest.cli.interactive.is_interactive", return_value=True),
            patch("tailtest.cli.interactive.click.confirm", return_value=True) as mock_confirm,
        ):
            result = ask("Continue?", default=False)
            assert result is True
            mock_confirm.assert_called_once_with("Continue?", default=False)

    def test_ask_passes_default_to_confirm(self):
        """The default value is forwarded to click.confirm."""
        with (
            patch("tailtest.cli.interactive.is_interactive", return_value=True),
            patch("tailtest.cli.interactive.click.confirm", return_value=True) as mock_confirm,
        ):
            ask("Sure?", default=True)
            mock_confirm.assert_called_once_with("Sure?", default=True)


class TestChoose:
    """Tests for the choose() helper."""

    def test_choose_returns_default_when_not_interactive(self):
        """In non-interactive mode, choose() returns the default."""
        with patch("tailtest.cli.interactive.is_interactive", return_value=False):
            assert choose("Pick", ["a", "b"], "b") == "b"

    def test_choose_calls_prompt_when_interactive(self):
        """In interactive mode, choose() delegates to click.prompt."""
        with (
            patch("tailtest.cli.interactive.is_interactive", return_value=True),
            patch("tailtest.cli.interactive.click.prompt", return_value="a") as mock_prompt,
        ):
            result = choose("Pick", ["a", "b"], "b")
            assert result == "a"
            mock_prompt.assert_called_once()


# ======================================================================
# ConsentManager
# ======================================================================


class TestConsentManager:
    """Tests for the ConsentManager class."""

    def test_consent_manager_save_load(self, tmp_path: Path):
        """Consent is persisted to disk and reloaded correctly."""
        cm = ConsentManager(project_dir=tmp_path)
        assert cm.has_consent("http://example.com") is False
        cm.record_consent("http://example.com")
        assert cm.has_consent("http://example.com") is True

        # Create a new instance to verify persistence
        cm2 = ConsentManager(project_dir=tmp_path)
        assert cm2.has_consent("http://example.com") is True

    def test_consent_manager_has_consent(self, tmp_path: Path):
        """has_consent returns False for unknown targets."""
        cm = ConsentManager(project_dir=tmp_path)
        assert cm.has_consent("http://unknown.example.com") is False

    def test_consent_manager_revoke(self, tmp_path: Path):
        """revoke_consent removes a previously consented target."""
        cm = ConsentManager(project_dir=tmp_path)
        cm.record_consent("http://revoke-me.com")
        assert cm.has_consent("http://revoke-me.com") is True

        cm.revoke_consent("http://revoke-me.com")
        assert cm.has_consent("http://revoke-me.com") is False

    def test_consent_not_asked_twice(self, tmp_path: Path):
        """request_consent returns True immediately for already-consented targets."""
        cm = ConsentManager(project_dir=tmp_path)
        cm.record_consent("http://already-consented.com")

        with patch("tailtest.cli.consent.is_interactive", return_value=True):
            # Should return True without asking
            result = cm.request_consent("http://already-consented.com")
            assert result is True

    def test_consent_skipped_in_ci(self, tmp_path: Path):
        """request_consent returns True without asking in non-interactive mode."""
        cm = ConsentManager(project_dir=tmp_path)
        with patch("tailtest.cli.consent.is_interactive", return_value=False):
            result = cm.request_consent("http://ci-target.com")
            assert result is True

    def test_consent_declined(self, tmp_path: Path):
        """request_consent returns False when user declines."""
        cm = ConsentManager(project_dir=tmp_path)
        with (
            patch("tailtest.cli.consent.is_interactive", return_value=True),
            patch("tailtest.cli.consent.ask", return_value=False),
        ):
            result = cm.request_consent("http://decline.com")
            assert result is False
            # Should not be persisted
            assert cm.has_consent("http://decline.com") is False

    def test_consent_accepted_and_persisted(self, tmp_path: Path):
        """request_consent persists consent when user accepts."""
        cm = ConsentManager(project_dir=tmp_path)
        with (
            patch("tailtest.cli.consent.is_interactive", return_value=True),
            patch("tailtest.cli.consent.ask", return_value=True),
        ):
            result = cm.request_consent("http://accept.com")
            assert result is True
            assert cm.has_consent("http://accept.com") is True

    def test_consent_file_created_in_tailtest_dir(self, tmp_path: Path):
        """Consent file is created under .tailtest/consent.json."""
        cm = ConsentManager(project_dir=tmp_path)
        cm.record_consent("http://file-check.com")
        consent_file = tmp_path / ".tailtest" / "consent.json"
        assert consent_file.exists()
        data = json.loads(consent_file.read_text())
        assert "http://file-check.com" in data["consented_targets"]

    def test_consent_redteam_warning(self, tmp_path: Path):
        """request_consent with warn_redteam=True shows adversarial warning."""
        cm = ConsentManager(project_dir=tmp_path)
        with (
            patch("tailtest.cli.consent.is_interactive", return_value=True),
            patch("tailtest.cli.consent.ask", return_value=True),
            patch("tailtest.cli.consent.click.echo") as mock_echo,
        ):
            cm.request_consent("http://redteam.com", warn_redteam=True)
            # Verify the adversarial warning was echoed
            calls = [str(c) for c in mock_echo.call_args_list]
            warning_shown = any("adversarial" in c for c in calls)
            assert warning_shown

    def test_consent_revoke_nonexistent(self, tmp_path: Path):
        """Revoking consent for a target that was never consented is a no-op."""
        cm = ConsentManager(project_dir=tmp_path)
        cm.revoke_consent("http://never-consented.com")  # should not raise

    def test_consent_corrupted_file(self, tmp_path: Path):
        """ConsentManager handles corrupted consent.json gracefully."""
        consent_dir = tmp_path / ".tailtest"
        consent_dir.mkdir(parents=True)
        (consent_dir / "consent.json").write_text("not valid json!!!")

        cm = ConsentManager(project_dir=tmp_path)
        # Should not raise, treats as empty
        assert cm.has_consent("http://anything.com") is False

    def test_consent_multiple_targets(self, tmp_path: Path):
        """Multiple targets can be consented independently."""
        cm = ConsentManager(project_dir=tmp_path)
        cm.record_consent("http://target-a.com")
        cm.record_consent("http://target-b.com")
        assert cm.has_consent("http://target-a.com") is True
        assert cm.has_consent("http://target-b.com") is True
        cm.revoke_consent("http://target-a.com")
        assert cm.has_consent("http://target-a.com") is False
        assert cm.has_consent("http://target-b.com") is True


# ======================================================================
# --no-interactive flag
# ======================================================================


class TestNoInteractiveFlag:
    """Verify --no-interactive flag is wired to all updated commands."""

    def _runner(self):
        return CliRunner()

    def test_no_interactive_flag_on_scan(self):
        """scan command accepts --no-interactive."""
        from tailtest.cli.scan import scan_cmd

        runner = self._runner()
        result = runner.invoke(scan_cmd, ["--help"])
        assert result.exit_code == 0
        assert "--no-interactive" in result.output

    def test_no_interactive_flag_on_run(self):
        """run command accepts --no-interactive."""
        from tailtest.cli.run import run_cmd

        runner = self._runner()
        result = runner.invoke(run_cmd, ["--help"])
        assert result.exit_code == 0
        assert "--no-interactive" in result.output

    def test_no_interactive_flag_on_redteam(self):
        """redteam command accepts --no-interactive."""
        from tailtest.cli.redteam import redteam_cmd

        runner = self._runner()
        result = runner.invoke(redteam_cmd, ["--help"])
        assert result.exit_code == 0
        assert "--no-interactive" in result.output

    def test_no_interactive_flag_on_report(self):
        """report command accepts --no-interactive."""
        from tailtest.cli.report import report_cmd

        runner = self._runner()
        result = runner.invoke(report_cmd, ["--help"])
        assert result.exit_code == 0
        assert "--no-interactive" in result.output

    def test_no_interactive_flag_on_generate(self):
        """generate command accepts --no-interactive."""
        from tailtest.cli.generate import generate_cmd

        runner = self._runner()
        result = runner.invoke(generate_cmd, ["--help"])
        assert result.exit_code == 0
        assert "--no-interactive" in result.output

    def test_no_interactive_flag_skips_prompts(self):
        """When --no-interactive is set, is_interactive returns False."""
        # Simulate the Click context with no_interactive=True
        with patch.dict(os.environ, {"TAILTEST_INTERACTIVE": "0"}):
            assert is_interactive() is False


# ======================================================================
# Interactive prompts in scan
# ======================================================================


class TestScanInteractive:
    """Tests for interactive prompts in the scan command."""

    def test_scan_asks_about_understand(self, tmp_path: Path):
        """When tools/prompts found, scan asks about deeper analysis."""
        (tmp_path / "agent.py").write_text("import openai\n")

        mock_result = MagicMock()
        mock_result.framework = "openai"
        mock_result.framework_version = None
        mock_result.tools = [MagicMock()]
        mock_result.prompts = [MagicMock()]
        mock_result.agents = []
        mock_result.models = ["gpt-4"]
        mock_result.dependencies = []
        mock_result.env_vars = []
        mock_result.model_dump.return_value = {}

        mock_engine = MagicMock()
        mock_engine.scan = MagicMock(return_value=mock_result)

        runner = CliRunner()
        with (
            patch("tailtest.cli.scan.ask", return_value=False) as mock_ask,
            patch("tailtest.cli.scan.asyncio") as mock_asyncio,
            patch("tailtest.context.engine.ContextEngine", return_value=mock_engine),
        ):
            mock_asyncio.run.return_value = mock_result

            from tailtest.cli.scan import scan_cmd

            result = runner.invoke(scan_cmd, [str(tmp_path)])
            assert result.exit_code == 0, result.output
            # ask should have been called because tools/prompts are non-empty
            mock_ask.assert_called()

    def test_scan_no_interactive_skips_understand_prompt(self, tmp_path: Path):
        """With --no-interactive, scan does not ask about understand."""
        (tmp_path / "agent.py").write_text("import openai\n")

        mock_result = MagicMock()
        mock_result.framework = "openai"
        mock_result.framework_version = None
        mock_result.tools = [MagicMock()]
        mock_result.prompts = [MagicMock()]
        mock_result.agents = []
        mock_result.models = ["gpt-4"]
        mock_result.dependencies = []
        mock_result.env_vars = []
        mock_result.model_dump.return_value = {}

        mock_engine = MagicMock()
        mock_engine.scan = MagicMock(return_value=mock_result)

        runner = CliRunner()
        with (
            patch("tailtest.cli.scan.ask") as mock_ask,
            patch("tailtest.cli.scan.asyncio") as mock_asyncio,
            patch("tailtest.context.engine.ContextEngine", return_value=mock_engine),
        ):
            mock_asyncio.run.return_value = mock_result

            from tailtest.cli.scan import scan_cmd

            # --no-interactive should make ask() return default (False)
            result = runner.invoke(scan_cmd, [str(tmp_path), "--no-interactive"])
            assert result.exit_code == 0, result.output
            # ask is called but is_interactive inside it returns False,
            # so the user is never actually prompted


# ======================================================================
# Interactive prompts in run
# ======================================================================


class TestRunInteractive:
    """Tests for interactive prompts in the run command."""

    def test_run_asks_consent_for_remote(self, tmp_path: Path):
        """run command checks consent for remote targets."""
        runner = CliRunner()
        with (
            patch("tailtest.config.loader.load_config") as mock_config,
            patch("tailtest.cli.run.ConsentManager") as mock_consent_cls,
        ):
            config_obj = MagicMock()
            config_obj.targets = {"staging": {}}
            config_obj.get_agent.return_value = MagicMock()
            mock_config.return_value = config_obj

            consent_instance = MagicMock()
            consent_instance.request_consent.return_value = False
            mock_consent_cls.return_value = consent_instance

            from tailtest.cli.run import run_cmd

            result = runner.invoke(run_cmd, ["--target", "staging"])
            consent_instance.request_consent.assert_called_once_with("staging")


# ======================================================================
# Interactive prompts in redteam
# ======================================================================


class TestRedteamInteractive:
    """Tests for interactive prompts in the redteam command."""

    def test_redteam_warns_about_adversarial(self):
        """redteam warns about adversarial prompts when agent-url is set."""
        runner = CliRunner()
        with (
            patch("tailtest.cli.redteam.ConsentManager") as mock_consent_cls,
            patch("tailtest.cli.redteam.is_interactive", return_value=False),
        ):
            consent_instance = MagicMock()
            consent_instance.request_consent.return_value = False
            mock_consent_cls.return_value = consent_instance

            from tailtest.cli.redteam import redteam_cmd

            result = runner.invoke(
                redteam_cmd,
                ["--agent-url", "http://example.com/chat", "--no-interactive"],
            )
            consent_instance.request_consent.assert_called_once_with(
                "http://example.com/chat",
                warn_redteam=True,
            )

    def test_redteam_no_interactive_skips_intensity_prompt(self):
        """With --no-interactive, redteam does not ask about intensity."""
        runner = CliRunner()
        with (
            patch("tailtest.cli.redteam.is_interactive", return_value=False),
            patch("tailtest.cli.redteam.choose") as mock_choose,
        ):
            from tailtest.cli.redteam import redteam_cmd

            # Use --quick to avoid the interactive prompt path entirely
            result = runner.invoke(redteam_cmd, ["--quick", "--no-interactive"])
            mock_choose.assert_not_called()


# ======================================================================
# Interactive prompts in report
# ======================================================================


class TestReportInteractive:
    """Tests for interactive prompts in the report command."""

    def test_report_asks_format(self):
        """report command asks about format when not specified."""
        runner = CliRunner()
        with (
            patch("tailtest.cli.report.choose", return_value="terminal") as mock_choose,
            patch("tailtest.cli.report.ReportAggregator") as mock_agg_cls,
        ):
            mock_agg = MagicMock()
            mock_trend = MagicMock()
            mock_trend.points = []
            mock_trend.period = "latest"
            mock_trend.total_runs = 0
            mock_trend.avg_pass_rate = 0
            mock_trend.avg_cost = 0
            mock_trend.flaky_tests = []
            mock_trend.new_failures = []
            mock_trend.fixed_tests = []
            mock_agg.trend.return_value = mock_trend
            mock_agg_cls.return_value = mock_agg

            from tailtest.cli.report import report_cmd

            result = runner.invoke(report_cmd, [])
            mock_choose.assert_called_once()

    def test_report_no_interactive_uses_default_format(self):
        """With --no-interactive, report uses default text format."""
        runner = CliRunner()
        with (
            patch("tailtest.cli.report.choose", return_value="terminal") as mock_choose,
            patch("tailtest.cli.report.ReportAggregator") as mock_agg_cls,
        ):
            mock_agg = MagicMock()
            mock_trend = MagicMock()
            mock_trend.points = []
            mock_trend.period = "latest"
            mock_trend.total_runs = 0
            mock_trend.avg_pass_rate = 0
            mock_trend.avg_cost = 0
            mock_trend.flaky_tests = []
            mock_trend.new_failures = []
            mock_trend.fixed_tests = []
            mock_agg.trend.return_value = mock_trend
            mock_agg_cls.return_value = mock_agg

            from tailtest.cli.report import report_cmd

            result = runner.invoke(report_cmd, ["--no-interactive"])
            # choose is called but is_interactive inside returns False,
            # so the default is returned without prompting

    def test_report_format_flag_bypasses_prompt(self):
        """Explicit --format flag skips the interactive prompt."""
        runner = CliRunner()
        with (
            patch("tailtest.cli.report.choose") as mock_choose,
            patch("tailtest.cli.report.ReportAggregator") as mock_agg_cls,
        ):
            mock_agg = MagicMock()
            mock_trend = MagicMock()
            mock_trend.points = []
            mock_trend.period = "latest"
            mock_trend.total_runs = 0
            mock_trend.avg_pass_rate = 0
            mock_trend.avg_cost = 0
            mock_trend.flaky_tests = []
            mock_trend.new_failures = []
            mock_trend.fixed_tests = []
            mock_agg.trend.return_value = mock_trend
            mock_agg_cls.return_value = mock_agg

            from tailtest.cli.report import report_cmd

            result = runner.invoke(report_cmd, ["--format", "text"])
            # choose should NOT be called because format was provided
            mock_choose.assert_not_called()


# ======================================================================
# Interactive prompts in generate
# ======================================================================


class TestGenerateInteractive:
    """Tests for interactive prompts in the generate command."""

    def test_generate_asks_about_llm_tests(self, tmp_path: Path):
        """generate command asks about LLM-inferred tests."""
        runner = CliRunner()
        with (
            patch("tailtest.cli.generate.is_interactive", return_value=True),
            patch("tailtest.cli.generate.ask", side_effect=[True, False]) as mock_ask,
            patch("tailtest.context.store.load_scan") as mock_load,
            patch("tailtest.generator.engine.TestGenerator") as mock_gen_cls,
        ):
            mock_context = MagicMock()
            mock_context.framework = "openai"
            mock_context.tools = []
            mock_context.prompts = []
            mock_load.return_value = mock_context

            mock_gen = MagicMock()
            mock_gen.generate = MagicMock(return_value=[])
            mock_gen_cls.return_value = mock_gen

            from tailtest.cli.generate import generate_cmd

            result = runner.invoke(generate_cmd, ["--project-dir", str(tmp_path)])
            # Should have asked about LLM tests and business rules
            assert mock_ask.call_count >= 1

    def test_generate_business_rules_creates_guidance(self, tmp_path: Path):
        """When user says yes to business rules but no rules.yaml, shows guidance."""
        runner = CliRunner()
        with (
            patch("tailtest.cli.generate.is_interactive", return_value=True),
            # First ask: LLM tests = False; Second ask: business rules = True
            patch("tailtest.cli.generate.ask", side_effect=[False, True]),
            patch("tailtest.context.store.load_scan") as mock_load,
        ):
            mock_context = MagicMock()
            mock_context.framework = "openai"
            mock_context.tools = []
            mock_context.prompts = []
            mock_load.return_value = mock_context

            from tailtest.cli.generate import generate_cmd

            result = runner.invoke(generate_cmd, ["--project-dir", str(tmp_path)])
            assert "rules.yaml" in result.output

    def test_generate_no_interactive_skips_prompts(self, tmp_path: Path):
        """With --no-interactive, generate does not ask interactive questions."""
        runner = CliRunner()
        with (
            patch("tailtest.cli.generate.is_interactive", return_value=False),
            patch("tailtest.cli.generate.ask") as mock_ask,
            patch("tailtest.context.store.load_scan") as mock_load,
            patch("tailtest.generator.engine.TestGenerator") as mock_gen_cls,
        ):
            mock_context = MagicMock()
            mock_context.framework = "openai"
            mock_context.tools = []
            mock_context.prompts = []
            mock_load.return_value = mock_context

            mock_gen = MagicMock()
            mock_gen.generate = MagicMock(return_value=[])
            mock_gen_cls.return_value = mock_gen

            from tailtest.cli.generate import generate_cmd

            result = runner.invoke(generate_cmd, ["--project-dir", str(tmp_path), "--no-interactive"])
            mock_ask.assert_not_called()


# ======================================================================
# no_interactive_option decorator
# ======================================================================


class TestNoInteractiveDecorator:
    """Tests for the no_interactive_option decorator."""

    def test_decorator_adds_flag(self):
        """no_interactive_option adds --no-interactive to a Click command."""

        @click.command()
        @no_interactive_option
        def dummy(no_interactive: bool):
            click.echo(f"no_interactive={no_interactive}")

        runner = CliRunner()
        result = runner.invoke(dummy, ["--no-interactive"])
        assert result.exit_code == 0
        assert "no_interactive=True" in result.output

    def test_decorator_default_is_false(self):
        """Default value for --no-interactive is False."""

        @click.command()
        @no_interactive_option
        def dummy(no_interactive: bool):
            click.echo(f"no_interactive={no_interactive}")

        runner = CliRunner()
        result = runner.invoke(dummy, [])
        assert result.exit_code == 0
        assert "no_interactive=False" in result.output
