"""Tests for the CLI agent interface  -  input substitution and shell quoting."""

from __future__ import annotations

import shlex

import pytest

from tailtest.runner.interfaces.cli_proc import CLIInterface, _prepare_template


# --------------------------------------------------------------------------- #
# _prepare_template  -  stripping quotes around {{input}}
# --------------------------------------------------------------------------- #


class TestPrepareTemplate:
    """Verify that _prepare_template strips surrounding quotes."""

    def test_bare_placeholder(self):
        assert _prepare_template("echo {{input}}") == "echo {{input}}"

    def test_double_quoted_placeholder(self):
        assert _prepare_template('echo "{{input}}"') == "echo {{input}}"

    def test_single_quoted_placeholder(self):
        assert _prepare_template("echo '{{input}}'") == "echo {{input}}"

    def test_escaped_double_quoted_placeholder(self):
        assert _prepare_template('echo \\"{{input}}\\"') == "echo {{input}}"

    def test_multiple_placeholders(self):
        result = _prepare_template('cmd "{{input}}" --flag "{{input}}"')
        assert result == "cmd {{input}} --flag {{input}}"

    def test_preserves_other_quotes(self):
        result = _prepare_template("""ssh host 'echo "{{input}}"'""")
        # The inner "{{input}}" quotes are stripped, outer ssh quotes preserved
        assert "{{input}}" in result


# --------------------------------------------------------------------------- #
# Input substitution via chat()
# --------------------------------------------------------------------------- #


class TestInputSubstitution:
    """Verify that {{input}} substitution produces safe shell commands."""

    @pytest.mark.asyncio
    async def test_input_substitution_simple_message(self):
        """Simple single-word input is substituted correctly."""
        iface = CLIInterface(command="echo {{input}}")
        result = await iface.chat("hello")
        assert result.content == "hello"
        await iface.close()

    @pytest.mark.asyncio
    async def test_input_substitution_with_quotes_in_message(self):
        """Quotes inside the message don't break the shell command."""
        iface = CLIInterface(command="echo {{input}}")
        result = await iface.chat("it's a \"test\"")
        assert "it's a \"test\"" in result.content
        await iface.close()

    @pytest.mark.asyncio
    async def test_input_substitution_with_special_chars(self):
        """Special shell characters ($, `, ;, etc.) are escaped safely."""
        iface = CLIInterface(command="echo {{input}}")
        result = await iface.chat("price is $100; rm -rf /")
        assert "$100" in result.content
        assert "rm -rf" in result.content
        await iface.close()

    @pytest.mark.asyncio
    async def test_input_substitution_ssh_nested_quotes(self):
        """Multi-word input works in SSH-style nested quote commands.

        The original bug: a command like
          ssh host 'cmd -m "{{input}}"'
        would split multi-word inputs into separate arguments.
        """
        # Use a local echo to simulate the SSH pattern  -  the key is that
        # the entire multi-word message must arrive as one argument
        iface = CLIInterface(
            command='echo "{{input}}"',
        )
        result = await iface.chat("I want to connect my Stripe account")
        assert "I want to connect my Stripe account" in result.content
        await iface.close()

    @pytest.mark.asyncio
    async def test_input_substitution_preserves_non_template_commands(self):
        """Commands without {{input}} still use stdin piping."""
        iface = CLIInterface(command="cat")
        result = await iface.chat("hello via stdin")
        assert result.content == "hello via stdin"
        await iface.close()

    @pytest.mark.asyncio
    async def test_input_substitution_multi_word_no_split(self):
        """Multi-word inputs must stay as one shell argument."""
        # printf %s prints without newline; we use it to verify the full
        # message arrives intact.
        iface = CLIInterface(command="printf '%s' {{input}}")
        result = await iface.chat("one two three")
        assert result.content == "one two three"
        await iface.close()
