"""Tests for the record/replay system."""

import json

import pytest

from tailtest.models import AgentResponse
from tailtest.runner.recorder import Recorder, Replayer


# --------------------------------------------------------------------------- #
# Recording
# --------------------------------------------------------------------------- #


def test_records_request_response_pairs(tmp_path):
    """Recorder.record() writes a JSON file for each interaction."""
    recorder = Recorder(base_dir=tmp_path, session_name="test-session")
    response = AgentResponse(content="Hello!", latency_ms=100.0, cost_usd=0.001)
    recorder.record("What is 2+2?", response)
    recorder.finalize()

    session_dir = tmp_path / "test-session"
    assert session_dir.is_dir()
    # Should have at least one JSON file besides manifest.json
    json_files = [f for f in session_dir.glob("*.json") if f.name != "manifest.json"]
    assert len(json_files) >= 1

    data = json.loads(json_files[0].read_text())
    assert data["input"] == "What is 2+2?"
    assert data["response"]["content"] == "Hello!"


def test_creates_timestamped_directories(tmp_path):
    """Recorder creates a session directory named by timestamp."""
    recorder = Recorder(base_dir=tmp_path)
    response = AgentResponse(content="ok")
    recorder.record("hi", response)
    recorder.finalize()

    # The session dir should be created under base_dir
    dirs = [d for d in tmp_path.iterdir() if d.is_dir()]
    assert len(dirs) == 1
    # Name is a timestamp string like 2026-03-31T12-00-00
    assert "-" in dirs[0].name and "T" in dirs[0].name


def test_manifest_json_is_valid(tmp_path):
    """Recorder.finalize() writes a valid manifest.json."""
    recorder = Recorder(base_dir=tmp_path, session_name="s1")
    response = AgentResponse(content="Hi")
    recorder.record("hello", response)
    recorder.record("goodbye", response)
    session_path = recorder.finalize()

    manifest = json.loads((session_path / "manifest.json").read_text())
    assert manifest["session"] == "s1"
    assert manifest["interaction_count"] == 2
    assert "finalized_at" in manifest


# --------------------------------------------------------------------------- #
# Replay
# --------------------------------------------------------------------------- #


def test_replays_recorded_responses(tmp_path):
    """Replayer.replay() returns the previously recorded response."""
    # Record first
    recorder = Recorder(base_dir=tmp_path, session_name="replay-test")
    original = AgentResponse(content="The answer is 4.", latency_ms=50.0)
    recorder.record("What is 2+2?", original)
    recorder.finalize()

    # Replay
    replayer = Replayer(session_dir=tmp_path / "replay-test")
    replayed = replayer.replay("What is 2+2?")
    assert replayed is not None
    assert replayed.content == "The answer is 4."


def test_handles_missing_recordings(tmp_path):
    """Replayer.replay() returns None when no recording matches the input."""
    # Create session with one recording
    recorder = Recorder(base_dir=tmp_path, session_name="partial")
    recorder.record("known input", AgentResponse(content="response"))
    recorder.finalize()

    replayer = Replayer(session_dir=tmp_path / "partial")
    result = replayer.replay("completely different input")
    assert result is None


def test_replayer_has_method(tmp_path):
    """Replayer.has() returns True/False for existing/missing recordings."""
    recorder = Recorder(base_dir=tmp_path, session_name="has-test")
    recorder.record("exists", AgentResponse(content="yes"))
    recorder.finalize()

    replayer = Replayer(session_dir=tmp_path / "has-test")
    assert replayer.has("exists") is True
    assert replayer.has("does not exist") is False


def test_handles_duplicate_inputs(tmp_path):
    """Recorder handles the same input recorded multiple times."""
    recorder = Recorder(base_dir=tmp_path, session_name="dupes")
    recorder.record("same input", AgentResponse(content="first"))
    recorder.record("same input", AgentResponse(content="second"))
    recorder.finalize()

    replayer = Replayer(session_dir=tmp_path / "dupes")
    first = replayer.replay("same input")
    assert first is not None
    second = replayer.replay("same input")
    assert second is not None
    # They should be returned in order
    assert first.content == "first"
    assert second.content == "second"


# --------------------------------------------------------------------------- #
# CLI record/replay wiring
# --------------------------------------------------------------------------- #


def test_record_cmd_creates_recordings(tmp_path):
    """The record CLI command should create recording files on disk."""
    from click.testing import CliRunner
    from tailtest.cli.record import record_cmd

    # Write a minimal test file that the runner can discover
    test_file = tmp_path / "test_basic.py"
    test_file.write_text(
        "def test_hello():\n    assert True\n"
    )

    runner = CliRunner()
    result = runner.invoke(record_cmd, [str(tmp_path), "--no-interactive"])

    # The command should succeed (exit code 0)
    assert result.exit_code == 0
    assert "Recording mode" in result.output


def test_record_cmd_with_session_name(tmp_path):
    """The record CLI command respects the --session flag."""
    from click.testing import CliRunner
    from tailtest.cli.record import record_cmd

    test_file = tmp_path / "test_pass.py"
    test_file.write_text(
        "def test_pass():\n    assert 1 + 1 == 2\n"
    )

    runner = CliRunner()
    result = runner.invoke(
        record_cmd,
        [str(tmp_path), "--session", "my-baseline", "--no-interactive"],
    )

    assert result.exit_code == 0
    assert "my-baseline" in result.output


def test_replay_cmd_shows_replay_mode(tmp_path):
    """The replay CLI command prints replay mode information."""
    from click.testing import CliRunner
    from tailtest.cli.replay import replay_cmd

    # Create a test file so the runner has something to discover
    test_file = tmp_path / "test_basic.py"
    test_file.write_text(
        "def test_simple():\n    assert True\n"
    )

    # Create a dummy recording session so the replayer can be set up
    recordings_dir = tmp_path / ".tailtest" / "recordings" / "test-session"
    recordings_dir.mkdir(parents=True)
    manifest = recordings_dir / "manifest.json"
    manifest.write_text('{"session": "test-session", "interaction_count": 0}')

    runner = CliRunner()
    result = runner.invoke(
        replay_cmd,
        [str(tmp_path), "--no-interactive"],
    )

    assert "Replay mode" in result.output


def test_replayer_exhausted_duplicates_returns_last(tmp_path):
    """When replaying more times than recorded, the last recording is reused."""
    recorder = Recorder(base_dir=tmp_path, session_name="exhaust")
    recorder.record("input", AgentResponse(content="only-response"))
    recorder.finalize()

    replayer = Replayer(session_dir=tmp_path / "exhaust")
    # Replay more times than recorded
    r1 = replayer.replay("input")
    r2 = replayer.replay("input")
    r3 = replayer.replay("input")

    assert r1 is not None
    assert r2 is not None
    assert r3 is not None
    # All should return the same (last/only) response
    assert r1.content == "only-response"
    assert r2.content == "only-response"
    assert r3.content == "only-response"


def test_replayer_latest_session_picks_most_recent(tmp_path):
    """Replayer auto-selects the most recent session when none is specified."""
    # Create two sessions with alphabetically ordered names
    for name, content in [("2026-01-01T00-00-00", "old"), ("2026-12-31T00-00-00", "new")]:
        recorder = Recorder(base_dir=tmp_path, session_name=name)
        recorder.record("query", AgentResponse(content=content))
        recorder.finalize()

    # Replayer should pick the latest (2026-12-31)
    replayer = Replayer(base_dir=tmp_path)
    result = replayer.replay("query")
    assert result is not None
    assert result.content == "new"
