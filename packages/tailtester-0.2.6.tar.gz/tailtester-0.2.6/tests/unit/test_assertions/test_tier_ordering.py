"""Tests for tier-based assertion ordering with short-circuiting.

Verifies that the ``Expectation`` class correctly:
- Sorts assertions by tier (deterministic=1, llm_judge=2, reliability=3)
- Short-circuits higher tiers when a lower tier fails
- Tracks skipped assertions and cost savings
- Preserves backward-compatible chain-order execution
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.deterministic.contains import ContainsAssertion
from tailtest.assertions.deterministic.cost import CostAssertion
from tailtest.assertions.expect import Expectation, TierExecutionStats, expect
from tailtest.assertions.llm_judge.faithfulness import FaithfulnessAssertion
from tailtest.assertions.llm_judge.safety import SafetyAssertion
from tailtest.assertions.reliability.compound import CompoundReliabilityAssertion
from tailtest.assertions.reliability.consistency import ConsistencyAssertion
from tailtest.models import AgentResponse, AssertionResult


# ---------------------------------------------------------------------------
# Helpers: stub assertions with configurable tier and pass/fail
# ---------------------------------------------------------------------------


class StubAssertion(BaseAssertion):
    """A test-only assertion with configurable tier and outcome."""

    def __init__(self, *, tier: int = 1, passes: bool = True, name: str = "stub") -> None:
        self.tier = tier  # type: ignore[assignment]
        self._passes = passes
        self.name = name
        self.was_executed = False

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        self.was_executed = True
        return AssertionResult(
            passed=self._passes,
            assertion_type=self.name,
            expected="pass" if self._passes else "fail",
            actual="pass" if self._passes else "fail",
            message=f"{self.name} {'passed' if self._passes else 'FAILED'}",
        )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def response():
    return AgentResponse(
        content="Hello! How can I help you today?",
        latency_ms=150.0,
        cost_usd=0.003,
        model="test-model",
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_evaluate_sorts_by_tier(response):
    """Assertions are sorted by tier before execution."""
    tier3 = StubAssertion(tier=3, name="tier3")
    tier1 = StubAssertion(tier=1, name="tier1")
    tier2 = StubAssertion(tier=2, name="tier2")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [tier3, tier1, tier2]
    e.evaluate()

    # All should have been executed
    assert tier1.was_executed
    assert tier2.was_executed
    assert tier3.was_executed

    # Results should be in tier order: tier1, tier2, tier3
    assert e.results[0].assertion_type == "tier1"
    assert e.results[1].assertion_type == "tier2"
    assert e.results[2].assertion_type == "tier3"


def test_tier1_runs_before_tier2(response):
    """Tier 1 assertions execute before Tier 2, regardless of insertion order."""
    tier2 = StubAssertion(tier=2, name="llm_judge")
    tier1 = StubAssertion(tier=1, name="deterministic")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [tier2, tier1]
    e.evaluate()

    # Tier 1 result should be first
    assert e.results[0].assertion_type == "deterministic"
    assert e.results[1].assertion_type == "llm_judge"


def test_short_circuit_skips_tier2_on_tier1_fail(response):
    """When a Tier 1 assertion fails, all Tier 2 assertions are skipped."""
    tier1_pass = StubAssertion(tier=1, passes=True, name="t1_pass")
    tier1_fail = StubAssertion(tier=1, passes=False, name="t1_fail")
    tier2_a = StubAssertion(tier=2, name="t2_a")
    tier2_b = StubAssertion(tier=2, name="t2_b")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [tier2_a, tier1_pass, tier2_b, tier1_fail]

    with pytest.raises(AssertionError, match="t1_fail FAILED"):
        e.evaluate()

    # Tier 1 assertions both ran
    assert tier1_pass.was_executed
    assert tier1_fail.was_executed
    # Tier 2 assertions were skipped
    assert not tier2_a.was_executed
    assert not tier2_b.was_executed


def test_short_circuit_skips_tier3_on_tier2_fail(response):
    """When a Tier 2 assertion fails, Tier 3 is skipped but Tier 1 ran."""
    tier1 = StubAssertion(tier=1, passes=True, name="t1")
    tier2_fail = StubAssertion(tier=2, passes=False, name="t2_fail")
    tier3 = StubAssertion(tier=3, name="t3")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [tier3, tier2_fail, tier1]

    with pytest.raises(AssertionError, match="t2_fail FAILED"):
        e.evaluate()

    assert tier1.was_executed
    assert tier2_fail.was_executed
    assert not tier3.was_executed


def test_all_tiers_run_when_all_pass(response):
    """When all assertions pass, all tiers execute in order."""
    tier1 = StubAssertion(tier=1, passes=True, name="t1")
    tier2 = StubAssertion(tier=2, passes=True, name="t2")
    tier3 = StubAssertion(tier=3, passes=True, name="t3")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [tier3, tier1, tier2]
    e.evaluate()

    assert tier1.was_executed
    assert tier2.was_executed
    assert tier3.was_executed
    assert len(e.results) == 3
    assert all(r.passed for r in e.results)


def test_backward_compat_chain_order_preserved(response):
    """Default mode (no tier_ordered) runs assertions in chain order, not tier order."""
    e = expect(response)
    # These are all tier 1, so run immediately in chain order
    result = e.to_contain("Hello").cost_under(0.01)

    assert len(result.results) == 2
    assert result.results[0].assertion_type == "contains"
    assert result.results[1].assertion_type == "cost_under"
    assert all(r.passed for r in result.results)


def test_backward_compat_immediate_failure():
    """In default mode, failure raises immediately without running later assertions."""
    response = AgentResponse(content="Goodbye", cost_usd=0.003)

    with pytest.raises(AssertionError, match="Hello"):
        # "Hello" is not in "Goodbye", so this should fail immediately
        expect(response).to_contain("Hello").cost_under(0.01)


def test_tier_ordered_activates_mode(response):
    """Calling .tier_ordered() sets _tier_mode to True."""
    e = expect(response).tier_ordered()
    assert e._tier_mode is True

    # Chaining assertions should NOT run them immediately
    e.to_contain("Hello").cost_under(0.01)
    assert len(e._pending) == 2
    assert len(e.results) == 0  # Nothing executed yet


def test_context_manager_auto_evaluates(response):
    """Context manager activates tier mode and auto-evaluates on exit."""
    with expect(response) as e:
        e.to_contain("Hello")
        e.cost_under(0.01)

    # After exit, assertions should have been evaluated
    assert len(e.results) == 2
    assert all(r.passed for r in e.results)


def test_context_manager_with_failure():
    """Context manager raises AssertionError on assertion failure."""
    response = AgentResponse(content="Goodbye", cost_usd=0.003)

    with pytest.raises(AssertionError, match="Hello"):
        with expect(response) as e:
            e.to_contain("Hello")
            e.cost_under(0.01)


def test_cost_savings_tracked(response):
    """Tier stats track estimated cost savings from short-circuiting."""
    tier1_fail = StubAssertion(tier=1, passes=False, name="t1_fail")
    tier2_a = StubAssertion(tier=2, name="t2_a")
    tier2_b = StubAssertion(tier=2, name="t2_b")
    tier3 = StubAssertion(tier=3, name="t3")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [tier1_fail, tier2_a, tier2_b, tier3]

    with pytest.raises(AssertionError):
        e.evaluate()

    stats = e.tier_stats
    assert stats is not None
    assert stats.total_assertions == 4
    assert stats.executed_assertions == 1  # only tier1_fail
    assert stats.skipped_assertions == 3  # tier2_a, tier2_b, tier3
    assert stats.estimated_cost_saved > 0
    # 2 tier-2 ($0.01 each) + 1 tier-3 ($0.05) = $0.07
    assert stats.estimated_cost_saved == pytest.approx(0.07, abs=0.001)


def test_skipped_assertions_recorded(response):
    """Skipped assertions are recorded and accessible via .skipped property."""
    tier1_fail = StubAssertion(tier=1, passes=False, name="t1_fail")
    tier2 = StubAssertion(tier=2, name="t2")
    tier3 = StubAssertion(tier=3, name="t3")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [tier1_fail, tier2, tier3]

    with pytest.raises(AssertionError):
        e.evaluate()

    assert len(e.skipped) == 2
    skipped_names = [a.name for a in e.skipped]
    assert "t2" in skipped_names
    assert "t3" in skipped_names


def test_mixed_tiers_correct_order(response):
    """Assertions from mixed tiers are reordered: T1, T1, T2, T2, T3."""
    t1a = StubAssertion(tier=1, passes=True, name="t1a")
    t2a = StubAssertion(tier=2, passes=True, name="t2a")
    t3a = StubAssertion(tier=3, passes=True, name="t3a")
    t1b = StubAssertion(tier=1, passes=True, name="t1b")
    t2b = StubAssertion(tier=2, passes=True, name="t2b")

    e = Expectation(response)
    e._tier_mode = True
    # Insert in scrambled order
    e._pending = [t2a, t3a, t1b, t2b, t1a]
    e.evaluate()

    types = [r.assertion_type for r in e.results]
    # Tier 1s first, then tier 2s, then tier 3
    assert types[0] in ("t1a", "t1b")
    assert types[1] in ("t1a", "t1b")
    assert types[2] in ("t2a", "t2b")
    assert types[3] in ("t2a", "t2b")
    assert types[4] == "t3a"


def test_multiple_tier1_all_run_before_tier2(response):
    """All Tier 1 assertions run (even if one fails) before Tier 2 is considered."""
    t1a = StubAssertion(tier=1, passes=True, name="t1a")
    t1b = StubAssertion(tier=1, passes=False, name="t1b")
    t1c = StubAssertion(tier=1, passes=True, name="t1c")
    t2 = StubAssertion(tier=2, name="t2")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [t2, t1a, t1b, t1c]

    with pytest.raises(AssertionError, match="t1b FAILED"):
        e.evaluate()

    # All tier 1 assertions ran
    assert t1a.was_executed
    assert t1b.was_executed
    assert t1c.was_executed
    # Tier 2 was skipped
    assert not t2.was_executed


def test_real_assertions_have_correct_tiers():
    """Verify that actual assertion classes have the correct tier assigned."""
    # Tier 1: deterministic
    assert ContainsAssertion(text="x").tier == 1
    assert CostAssertion(max_cost=1.0).tier == 1

    # Tier 2: LLM judge
    assert FaithfulnessAssertion(context="ctx").tier == 2
    assert SafetyAssertion().tier == 2

    # Tier 3: reliability
    assert CompoundReliabilityAssertion(step_scores=[0.9], min_compound=0.5).tier == 3


def test_evaluate_with_no_pending_returns_self(response):
    """Calling evaluate() with no pending assertions is a no-op."""
    e = Expectation(response)
    e._tier_mode = True
    result = e.evaluate()
    assert result is e
    assert len(e.results) == 0
    assert e.tier_stats is None


def test_tier_stats_populated_after_evaluate(response):
    """TierExecutionStats is populated after a successful evaluate()."""
    t1 = StubAssertion(tier=1, passes=True, name="t1")
    t2 = StubAssertion(tier=2, passes=True, name="t2")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [t1, t2]
    e.evaluate()

    stats = e.tier_stats
    assert stats is not None
    assert stats.total_assertions == 2
    assert stats.executed_assertions == 2
    assert stats.skipped_assertions == 0
    assert stats.estimated_cost_saved == 0.0


def test_tier_ordered_with_evaluate_chain(response):
    """Full chain: tier_ordered() -> assertions -> evaluate()."""
    e = (
        expect(response)
        .tier_ordered()
        .to_contain("Hello")
        .cost_under(0.01)
    )
    # Nothing executed yet
    assert len(e.results) == 0
    assert len(e._pending) == 2

    # Now evaluate
    e.evaluate()
    assert len(e.results) == 2
    assert all(r.passed for r in e.results)


def test_short_circuit_only_at_tier_boundary(response):
    """Failures within a tier do NOT short-circuit other assertions in the same tier."""
    t1a = StubAssertion(tier=1, passes=False, name="t1a_fail")
    t1b = StubAssertion(tier=1, passes=True, name="t1b_pass")

    e = Expectation(response)
    e._tier_mode = True
    e._pending = [t1a, t1b]

    with pytest.raises(AssertionError):
        e.evaluate()

    # Both tier 1 assertions ran, even though t1a failed
    assert t1a.was_executed
    assert t1b.was_executed
