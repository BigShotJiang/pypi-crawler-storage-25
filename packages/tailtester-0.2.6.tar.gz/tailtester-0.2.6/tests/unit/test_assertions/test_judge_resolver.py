"""Tests for LLM judge model resolver and auto-detection wiring."""

from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tailtest.assertions.llm_judge.judge import JudgeResult, LLMJudge
from tailtest.assertions.llm_judge.resolver import resolve_judge_model
from tailtest.config.schema import JudgeConfig


# ── Helpers ───────────────────────────────────────────────────────────────────


def _mock_completion(score: float, passed: bool, reason: str, cost: float = 0.001):
    """Build a mock litellm completion response object."""
    content = json.dumps({"score": score, "passed": passed, "reason": reason})
    message = SimpleNamespace(content=content)
    choice = SimpleNamespace(message=message)
    usage = SimpleNamespace(prompt_tokens=100, completion_tokens=50, total_tokens=150)
    return SimpleNamespace(choices=[choice], usage=usage)


# ── Resolver tests ────────────────────────────────────────────────────────────


class TestResolverDetection:
    """Test that resolve_judge_model detects providers correctly."""

    def test_resolver_detects_anthropic_key(self):
        """When ANTHROPIC_API_KEY is set, resolver returns claude-haiku."""
        env = {"ANTHROPIC_API_KEY": "sk-ant-test-key"}
        with patch.dict("os.environ", env, clear=True):
            result = resolve_judge_model()
        assert result == "claude-haiku-4-5-20251001"

    def test_resolver_detects_openai_key(self):
        """When OPENAI_API_KEY is set (no Anthropic), resolver returns gpt-4o-mini."""
        env = {"OPENAI_API_KEY": "sk-test-key"}
        with patch.dict("os.environ", env, clear=True):
            result = resolve_judge_model()
        assert result == "gpt-4o-mini"

    def test_resolver_detects_gemini_key(self):
        """When GEMINI_API_KEY is set, resolver returns gemini model."""
        env = {"GEMINI_API_KEY": "AIza-test-key"}
        with patch.dict("os.environ", env, clear=True):
            result = resolve_judge_model()
        assert result == "gemini/gemini-2.0-flash"

    def test_resolver_detects_google_api_key(self):
        """When GOOGLE_API_KEY is set, resolver returns gemini model."""
        env = {"GOOGLE_API_KEY": "AIza-test-key"}
        with patch.dict("os.environ", env, clear=True):
            result = resolve_judge_model()
        assert result == "gemini/gemini-2.0-flash"

    def test_resolver_detects_ollama_running(self):
        """When Ollama is running on localhost, resolver returns ollama/llama3.2."""
        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch.dict("os.environ", {}, clear=True):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.get.return_value = mock_response
                mock_client_cls.return_value = mock_client
                result = resolve_judge_model()

        assert result == "ollama/llama3.2"

    def test_resolver_returns_none_when_nothing_available(self):
        """When no LLM provider is available, resolver returns None."""
        with patch.dict("os.environ", {}, clear=True):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.get.side_effect = ConnectionError("refused")
                mock_client_cls.return_value = mock_client
                result = resolve_judge_model()

        assert result is None

    def test_resolver_priority_order(self):
        """Anthropic beats OpenAI beats Gemini beats Ollama."""
        # All keys set -- Anthropic should win
        env = {
            "ANTHROPIC_API_KEY": "sk-ant-test",
            "OPENAI_API_KEY": "sk-test",
            "GEMINI_API_KEY": "AIza-test",
        }
        with patch.dict("os.environ", env, clear=True):
            result = resolve_judge_model()
        assert result == "claude-haiku-4-5-20251001"

        # Only OpenAI and Gemini -- OpenAI should win
        env = {
            "OPENAI_API_KEY": "sk-test",
            "GEMINI_API_KEY": "AIza-test",
        }
        with patch.dict("os.environ", env, clear=True):
            result = resolve_judge_model()
        assert result == "gpt-4o-mini"

        # Only Gemini -- should win over Ollama
        env = {"GEMINI_API_KEY": "AIza-test"}
        with patch.dict("os.environ", env, clear=True):
            result = resolve_judge_model()
        assert result == "gemini/gemini-2.0-flash"

    def test_resolver_empty_key_is_not_detected(self):
        """An empty string API key should not be treated as available."""
        env = {"ANTHROPIC_API_KEY": ""}
        with patch.dict("os.environ", env, clear=True):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.get.side_effect = ConnectionError("refused")
                mock_client_cls.return_value = mock_client
                result = resolve_judge_model()
        # Empty string is falsy, so it should not match
        assert result is None

    def test_resolver_ollama_timeout_returns_none(self):
        """When Ollama check times out, resolver skips it gracefully."""
        import httpx

        with patch.dict("os.environ", {}, clear=True):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.get.side_effect = httpx.TimeoutException("timeout")
                mock_client_cls.return_value = mock_client
                result = resolve_judge_model()

        assert result is None


# ── LLMJudge auto mode ──────────────────────────────────────────────────────


class TestJudgeAutoMode:
    """Test that LLMJudge handles auto mode correctly."""

    async def test_judge_auto_mode_uses_resolver(self):
        """When model is 'auto', judge should resolve and use the detected model."""
        config = JudgeConfig(model="auto")
        judge = LLMJudge(config)

        mock_resp = _mock_completion(0.85, True, "Good answer")

        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "sk-test"}, clear=True):
            with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
                with patch("litellm.completion_cost", return_value=0.001):
                    result = await judge.evaluate(
                        prompt="What is 2+2?",
                        response_text="4",
                        rubric="Check math",
                    )

        assert result.passed is True
        assert result.model == "claude-haiku-4-5-20251001"

    async def test_judge_auto_mode_returns_failure_when_no_llm(self):
        """When auto-detect finds nothing, judge should return a failing result."""
        config = JudgeConfig(model="auto")
        judge = LLMJudge(config)

        with patch.dict("os.environ", {}, clear=True):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.get.side_effect = ConnectionError("refused")
                mock_client_cls.return_value = mock_client
                result = await judge.evaluate(
                    prompt="test",
                    response_text="test",
                    rubric="test",
                )

        assert result.passed is False
        assert result.score == 0.0
        assert "No LLM available" in result.reason

    async def test_judge_explicit_model_skips_resolver(self):
        """When model is explicitly set (not 'auto'), resolver should not be called."""
        config = JudgeConfig(model="ollama/llama3.2")
        judge = LLMJudge(config)

        mock_resp = _mock_completion(0.9, True, "Correct")

        with patch(
            "tailtest.assertions.llm_judge.resolver.resolve_judge_model"
        ) as mock_resolve:
            with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
                with patch("litellm.completion_cost", return_value=0.001):
                    result = await judge.evaluate(
                        prompt="test",
                        response_text="test",
                        rubric="test",
                    )

        mock_resolve.assert_not_called()
        assert result.model == "ollama/llama3.2"

    async def test_judge_default_config_is_auto(self):
        """Default JudgeConfig should use 'auto' model."""
        config = JudgeConfig()
        assert config.model == "auto"

        judge = LLMJudge()
        assert judge.config.model == "auto"

    async def test_judge_caches_resolved_model(self):
        """The resolved model should be cached across evaluate() calls."""
        config = JudgeConfig(model="auto")
        judge = LLMJudge(config)

        mock_resp = _mock_completion(0.85, True, "Good")

        with patch.dict("os.environ", {"OPENAI_API_KEY": "sk-test"}, clear=True):
            with patch(
                "tailtest.assertions.llm_judge.judge.resolve_judge_model",
                return_value="gpt-4o-mini",
            ) as mock_resolve:
                with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
                    with patch("litellm.completion_cost", return_value=0.001):
                        await judge.evaluate("p", "r", "rubric")
                        await judge.evaluate("p2", "r2", "rubric2")

        # Should only resolve once (cached)
        mock_resolve.assert_called_once()


# ── CLI --judge flag ─────────────────────────────────────────────────────────


class TestCLIJudgeOverride:
    """Test that --judge CLI flag flows through to config."""

    def test_cli_judge_flag_overrides_config(self, tmp_path):
        """The --judge flag should override the judge model in loaded config."""
        from tailtest.config.loader import load_config

        yaml_content = """\
version: "1"
judge:
  model: auto
  temperature: 0.0
"""
        yaml_file = tmp_path / "tailtest.yaml"
        yaml_file.write_text(yaml_content)

        # Without override -- should be "auto"
        config = load_config(path=yaml_file)
        assert config.judge.model == "auto"

        # With override -- should be the explicit model
        config = load_config(
            path=yaml_file,
            overrides={"judge": {"model": "gpt-4o-mini"}},
        )
        assert config.judge.model == "gpt-4o-mini"

    def test_cli_judge_flag_overrides_explicit_model(self, tmp_path):
        """--judge should override even an explicit model in tailtest.yaml."""
        from tailtest.config.loader import load_config

        yaml_content = """\
version: "1"
judge:
  model: ollama/llama3.2
"""
        yaml_file = tmp_path / "tailtest.yaml"
        yaml_file.write_text(yaml_content)

        config = load_config(
            path=yaml_file,
            overrides={"judge": {"model": "claude-haiku-4-5-20251001"}},
        )
        assert config.judge.model == "claude-haiku-4-5-20251001"


# ── MCP sampling capability ──────────────────────────────────────────────────


class TestMCPSamplingCapability:
    """Test MCP sampling capability detection."""

    @pytest.fixture
    def server(self):
        from tailtest.mcp.server import TailtestMCPServer

        return TailtestMCPServer()

    async def test_mcp_sampling_capability_detection(self, server):
        """Server should detect sampling capability from client init."""
        init_msg = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"sampling": {}},
                "clientInfo": {"name": "test", "version": "1.0"},
            },
        })

        response = await server.handle_message(init_msg)
        data = json.loads(response)

        assert data["result"]["serverInfo"]["name"] == "tailtest"
        assert server._client_supports_sampling is True

    async def test_mcp_no_sampling_capability(self, server):
        """Server should handle missing sampling capability gracefully."""
        init_msg = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"},
            },
        })

        response = await server.handle_message(init_msg)
        data = json.loads(response)

        assert data["result"]["serverInfo"]["name"] == "tailtest"
        assert server._client_supports_sampling is False

    def test_mcp_sampling_request_format(self, server):
        """The sampling request builder should produce valid JSON-RPC."""
        request = server._request_sampling(
            "Explain this failure",
            system_prompt="You are a test analyst.",
            max_tokens=300,
        )

        assert request["jsonrpc"] == "2.0"
        assert request["method"] == "sampling/createMessage"
        assert request["id"] >= 1
        params = request["params"]
        assert params["messages"][0]["role"] == "user"
        assert params["messages"][0]["content"]["text"] == "Explain this failure"
        assert params["systemPrompt"] == "You are a test analyst."
        assert params["maxTokens"] == 300
        assert params["modelPreferences"]["costPriority"] == 0.9

    def test_mcp_sampling_request_increments_id(self, server):
        """Each sampling request should get a unique incrementing ID."""
        r1 = server._request_sampling("prompt 1")
        r2 = server._request_sampling("prompt 2")
        assert r2["id"] > r1["id"]


# ── MCP explain/suggest use config ───────────────────────────────────────────


class TestMCPJudgeConfig:
    """MCP tools should use resolved judge config, not bare defaults."""

    @pytest.fixture
    def server(self):
        from tailtest.mcp.server import TailtestMCPServer

        return TailtestMCPServer()

    async def test_explain_failure_uses_resolved_config(self, server):
        """explain_failure should pass config to LLMJudge."""
        from dataclasses import dataclass

        @dataclass
        class _FakeResult:
            passed: bool
            score: float
            reason: str
            cost_usd: float = 0.0
            model: str = "test"
            latency_ms: float = 0.0
            raw_response: str = ""

        fake_result = _FakeResult(
            passed=True,
            score=0.9,
            reason="The test failed because of a timeout.",
        )
        mock_judge_instance = AsyncMock()
        mock_judge_instance.evaluate = AsyncMock(return_value=fake_result)

        judge_cls_path = "tailtest.assertions.llm_judge.judge.LLMJudge"
        with patch(judge_cls_path, return_value=mock_judge_instance) as mock_cls:
            result = await server._explain_failure({
                "test_name": "test_foo",
                "error_message": "timeout",
            })

        # Verify LLMJudge was instantiated with config= keyword
        call_kwargs = mock_cls.call_args
        assert "config" in call_kwargs.kwargs


# ── Backward compatibility ────────────────────────────────────────────────────


class TestBackwardCompatibility:
    """Explicit model strings in tailtest.yaml should still work."""

    def test_explicit_ollama_model_preserved(self):
        """Someone with 'ollama/llama3.2' in their config should still work."""
        config = JudgeConfig(model="ollama/llama3.2")
        judge = LLMJudge(config)
        assert judge._get_model() == "ollama/llama3.2"

    def test_explicit_openai_model_preserved(self):
        config = JudgeConfig(model="gpt-4o")
        judge = LLMJudge(config)
        assert judge._get_model() == "gpt-4o"

    def test_explicit_anthropic_model_preserved(self):
        config = JudgeConfig(model="claude-sonnet-4-20250514")
        judge = LLMJudge(config)
        assert judge._get_model() == "claude-sonnet-4-20250514"

    def test_config_from_yaml_dict_explicit_model(self):
        """Config loaded from YAML dict with explicit model should work."""
        from tailtest.config.schema import TailtestConfig

        data = {
            "version": "1",
            "judge": {"model": "ollama/llama3.2", "temperature": 0.0},
        }
        config = TailtestConfig.model_validate(data)
        assert config.judge.model == "ollama/llama3.2"

    def test_config_from_yaml_dict_auto_model(self):
        """Config loaded from YAML dict without model should default to auto."""
        from tailtest.config.schema import TailtestConfig

        data = {"version": "1"}
        config = TailtestConfig.model_validate(data)
        assert config.judge.model == "auto"
