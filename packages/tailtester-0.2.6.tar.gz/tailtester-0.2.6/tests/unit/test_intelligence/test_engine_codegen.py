"""Tests for Intelligence Engine generated code (P1-B).

Verifies that the engine produces real, executable Python code for each
GeneratedTest instead of empty strings.
"""

from __future__ import annotations

import ast
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from tailtest.intelligence.cache import UnderstandingCache
from tailtest.intelligence.engine import IntelligenceEngine, _slugify
from tailtest.intelligence.rules_to_tests import GeneratedTest
from tailtest.intelligence.understanding import CodeUnderstanding, UnderstandingResult
from tailtest.models import PromptDefinition, ScanResult, ToolDefinition


# -- helpers ---------------------------------------------------------------


def _make_scan(
    tools: list[ToolDefinition] | None = None,
    prompts: list[PromptDefinition] | None = None,
) -> ScanResult:
    return ScanResult(
        framework="openai",
        tools=tools or [],
        prompts=prompts or [],
        agents=[],
        models=["gpt-4"],
        env_vars=[],
        dependencies=[],
        config_files=[],
    )


def _mock_completion(analysis: dict):
    content = json.dumps(analysis)
    message = SimpleNamespace(content=content)
    choice = SimpleNamespace(message=message)
    usage = SimpleNamespace(prompt_tokens=200, completion_tokens=100, total_tokens=300)
    return SimpleNamespace(choices=[choice], usage=usage)


SAMPLE_ANALYSIS = {
    "domain": "accounting",
    "invariants": ["debits must equal credits"],
    "failure_modes": ["rounding errors in currency conversion"],
    "edge_cases": ["zero-amount invoice"],
    "data_validation": ["amount must be positive"],
}

SAMPLE_CODE = "def process(amount): return amount * 1.1\n"


# -- Structural code gen ---------------------------------------------------


class TestStructuralCodeGen:
    """Structural tests should generate real executable code."""

    @pytest.fixture
    def engine(self, tmp_path):
        return IntelligenceEngine(
            project_dir=tmp_path,
            cache=UnderstandingCache(cache_dir=tmp_path / "cache"),
        )

    async def test_tool_test_code_not_empty(self, engine):
        scan = _make_scan(tools=[ToolDefinition(name="lookup_order", parameters={})])
        result = await engine.analyse(scan_result=scan)
        assert len(result.structural_tests) == 1
        assert result.structural_tests[0].code != ""

    async def test_tool_test_code_is_valid_python(self, engine):
        scan = _make_scan(tools=[ToolDefinition(name="search", parameters={})])
        result = await engine.analyse(scan_result=scan)
        code = result.structural_tests[0].code
        # Should parse as valid Python
        ast.parse(code)

    async def test_tool_test_has_agent_test_decorator(self, engine):
        scan = _make_scan(tools=[ToolDefinition(name="get_weather", parameters={})])
        result = await engine.analyse(scan_result=scan)
        code = result.structural_tests[0].code
        assert "@agent_test" in code

    async def test_tool_test_has_async_def(self, engine):
        scan = _make_scan(tools=[ToolDefinition(name="send_email", parameters={})])
        result = await engine.analyse(scan_result=scan)
        code = result.structural_tests[0].code
        assert "async def" in code

    async def test_tool_test_uses_expect_api(self, engine):
        scan = _make_scan(tools=[ToolDefinition(name="create_ticket", parameters={})])
        result = await engine.analyse(scan_result=scan)
        code = result.structural_tests[0].code
        assert "expect(" in code
        assert "to_call_tool" in code

    async def test_tool_test_references_tool_name(self, engine):
        scan = _make_scan(tools=[ToolDefinition(name="delete_record", parameters={})])
        result = await engine.analyse(scan_result=scan)
        code = result.structural_tests[0].code
        assert "delete_record" in code

    async def test_tool_test_uses_example_input_when_available(self, engine):
        scan = _make_scan(
            tools=[
                ToolDefinition(
                    name="calc",
                    parameters={},
                    example_input="Calculate 2+2",
                )
            ]
        )
        result = await engine.analyse(scan_result=scan)
        code = result.structural_tests[0].code
        assert "Calculate 2+2" in code

    async def test_prompt_test_code_not_empty(self, engine):
        scan = _make_scan(
            prompts=[
                PromptDefinition(
                    content="You are a helpful assistant",
                    file_path="main.py",
                )
            ]
        )
        result = await engine.analyse(scan_result=scan)
        assert len(result.structural_tests) == 1
        assert result.structural_tests[0].code != ""

    async def test_prompt_test_code_is_valid_python(self, engine):
        scan = _make_scan(
            prompts=[PromptDefinition(content="You are a helpful bot", file_path="app.py")]
        )
        result = await engine.analyse(scan_result=scan)
        code = result.structural_tests[0].code
        ast.parse(code)

    async def test_prompt_test_uses_matches_rubric(self, engine):
        scan = _make_scan(
            prompts=[PromptDefinition(content="Be concise", file_path="prompts.py")]
        )
        result = await engine.analyse(scan_result=scan)
        code = result.structural_tests[0].code
        assert "matches_rubric" in code

    async def test_multiple_tools_all_have_code(self, engine):
        tools = [
            ToolDefinition(name=f"tool_{i}", parameters={})
            for i in range(5)
        ]
        scan = _make_scan(tools=tools)
        result = await engine.analyse(scan_result=scan)
        assert len(result.structural_tests) == 5
        for test in result.structural_tests:
            assert test.code != "", f"{test.name} has empty code"
            ast.parse(test.code)


# -- LLM-inferred code gen ------------------------------------------------


class TestLLMInferredCodeGen:
    """LLM-inferred tests should generate real executable code."""

    @pytest.fixture
    def engine(self, tmp_path):
        return IntelligenceEngine(
            project_dir=tmp_path,
            understanding=CodeUnderstanding(
                cache=UnderstandingCache(cache_dir=tmp_path / "cache")
            ),
        )

    async def test_invariant_test_code_not_empty(self, engine):
        mock_resp = _mock_completion(SAMPLE_ANALYSIS)
        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/inv.py", SAMPLE_CODE)],
                )
        for test in result.llm_inferred_tests:
            assert test.code != "", f"{test.name} has empty code"

    async def test_llm_test_code_is_valid_python(self, engine):
        mock_resp = _mock_completion(SAMPLE_ANALYSIS)
        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/inv.py", SAMPLE_CODE)],
                )
        for test in result.llm_inferred_tests:
            ast.parse(test.code)

    async def test_llm_test_has_agent_test_decorator(self, engine):
        mock_resp = _mock_completion(SAMPLE_ANALYSIS)
        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/inv.py", SAMPLE_CODE)],
                )
        for test in result.llm_inferred_tests:
            assert "@agent_test" in test.code, f"{test.name} missing @agent_test"

    async def test_llm_test_uses_matches_rubric(self, engine):
        mock_resp = _mock_completion(SAMPLE_ANALYSIS)
        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/inv.py", SAMPLE_CODE)],
                )
        for test in result.llm_inferred_tests:
            assert "matches_rubric" in test.code, f"{test.name} missing matches_rubric"

    async def test_llm_test_includes_description_in_code(self, engine):
        analysis = {
            "domain": "finance",
            "invariants": ["transactions must be atomic"],
            "failure_modes": [],
            "edge_cases": [],
            "data_validation": [],
        }
        mock_resp = _mock_completion(analysis)
        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/tx.py", SAMPLE_CODE)],
                )
        assert len(result.llm_inferred_tests) == 1
        code = result.llm_inferred_tests[0].code
        assert "atomic" in code

    async def test_failure_mode_test_has_code(self, engine):
        analysis = {
            "domain": "ecommerce",
            "invariants": [],
            "failure_modes": ["double charging"],
            "edge_cases": [],
            "data_validation": [],
        }
        mock_resp = _mock_completion(analysis)
        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/charge.py", SAMPLE_CODE)],
                )
        assert len(result.llm_inferred_tests) == 1
        code = result.llm_inferred_tests[0].code
        assert "async def" in code
        assert "double charging" in code

    async def test_edge_case_test_has_code(self, engine):
        analysis = {
            "domain": "general",
            "invariants": [],
            "failure_modes": [],
            "edge_cases": ["empty input"],
            "data_validation": [],
        }
        mock_resp = _mock_completion(analysis)
        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/edge.py", SAMPLE_CODE)],
                )
        assert len(result.llm_inferred_tests) == 1
        assert "empty input" in result.llm_inferred_tests[0].code

    async def test_data_validation_test_has_code(self, engine):
        analysis = {
            "domain": "general",
            "invariants": [],
            "failure_modes": [],
            "edge_cases": [],
            "data_validation": ["email must be valid"],
        }
        mock_resp = _mock_completion(analysis)
        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.001):
                result = await engine.analyse(
                    understand=True,
                    files=[("src/val.py", SAMPLE_CODE)],
                )
        assert len(result.llm_inferred_tests) == 1
        assert "email must be valid" in result.llm_inferred_tests[0].code


# -- User-rule code gen (rules_to_tests.py already working) ---------------


class TestUserRuleCodeGenWiredThrough:
    """Verify user-rule tests flow through the engine with real code."""

    async def test_user_rules_wired_through_engine(self, tmp_path):
        rules_dir = tmp_path / ".tailtest"
        rules_dir.mkdir(parents=True)
        (rules_dir / "rules.yaml").write_text(
            'rules:\n  - "Refunds over $100 need approval"\n'
            'never:\n  - "Reveal API keys"\n'
        )
        engine = IntelligenceEngine(
            project_dir=tmp_path,
            cache=UnderstandingCache(cache_dir=tmp_path / "cache"),
        )
        result = await engine.analyse()
        assert len(result.user_rule_tests) == 2
        for test in result.user_rule_tests:
            assert test.code != "", f"{test.name} has empty code"
            assert "async def" in test.code
            assert "matches_rubric" in test.code
            ast.parse(test.code)
