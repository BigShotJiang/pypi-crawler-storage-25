"""Tests for LLM-powered MCP tools (P2-A).

Verifies that explain_failure and suggest_test use LLM when available
and fall back to keyword matching when not.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from unittest.mock import AsyncMock, patch

import pytest

from tailtest.mcp.server import TailtestMCPServer


# -- helpers ---------------------------------------------------------------

JUDGE_IMPORT = "tailtest.assertions.llm_judge.judge.LLMJudge"


@dataclass
class _FakeJudgeResult:
    passed: bool
    score: float
    reason: str
    cost_usd: float = 0.0
    model: str = "test"
    latency_ms: float = 0.0
    raw_response: str = ""


def _make_call_msg(tool_name: str, arguments: dict, msg_id: int = 1) -> str:
    return json.dumps({
        "jsonrpc": "2.0",
        "id": msg_id,
        "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments},
    })


# -- explain_failure tests ------------------------------------------------


class TestExplainFailureLLM:
    """explain_failure should try LLM first, then fall back."""

    @pytest.fixture
    def server(self):
        return TailtestMCPServer()

    async def test_llm_import_fails_falls_back_to_keyword(self, server):
        """When the LLM judge import raises, keyword fallback should work."""
        with patch(JUDGE_IMPORT, side_effect=ImportError("no LLM")):
            result = await server._explain_failure({
                "test_name": "test_timeout",
                "error_message": "Timeout after 30s",
            })
        assert "timeout" in result.lower()

    async def test_llm_explain_returns_llm_analysis(self, server):
        fake_result = _FakeJudgeResult(
            passed=True,
            score=0.9,
            reason="The PII detector found an email address in the response.",
        )
        mock_judge_instance = AsyncMock()
        mock_judge_instance.evaluate = AsyncMock(return_value=fake_result)

        with patch(JUDGE_IMPORT, return_value=mock_judge_instance):
            result = await server._explain_failure({
                "test_name": "test_pii",
                "error_message": "PII detected: email",
            })
        assert "LLM Analysis" in result
        assert "PII detector" in result

    async def test_keyword_fallback_on_evaluate_exception(self, server):
        mock_judge_instance = AsyncMock()
        mock_judge_instance.evaluate = AsyncMock(side_effect=RuntimeError("LLM down"))

        with patch(JUDGE_IMPORT, return_value=mock_judge_instance):
            result = await server._explain_failure({
                "test_name": "test_safety",
                "error_message": "Safety check: harmful content",
            })
        # Should get keyword-based analysis
        assert "safety" in result.lower() or "harmful" in result.lower()

    async def test_keyword_explain_timeout(self, server):
        result = server._keyword_explain("test_t", "Request timeout after 30s")
        assert "time limit" in result

    async def test_keyword_explain_pii(self, server):
        result = server._keyword_explain("test_p", "PII found in response")
        assert "personally identifiable" in result

    async def test_keyword_explain_tool_call(self, server):
        result = server._keyword_explain("test_tool", "Tool call to search failed")
        assert "tool" in result.lower()

    async def test_keyword_explain_cost(self, server):
        result = server._keyword_explain("test_c", "Cost exceeded $1.00")
        assert "cost" in result.lower()

    async def test_keyword_explain_safety(self, server):
        result = server._keyword_explain("test_s", "Safety violation: harmful content")
        assert "unsafe" in result.lower() or "safety" in result.lower()

    async def test_keyword_explain_unknown(self, server):
        result = server._keyword_explain("test_x", "Something weird happened")
        assert "unexpected error" in result.lower()

    async def test_keyword_explain_expected(self, server):
        result = server._keyword_explain("test_e", "Expected 'hello' but got 'goodbye'")
        assert "expected" in result.lower() or "contain" in result.lower()


# -- suggest_test tests ----------------------------------------------------


class TestSuggestTestLLM:
    """suggest_test should try LLM first, then fall back."""

    @pytest.fixture
    def server(self):
        return TailtestMCPServer()

    async def test_llm_suggest_used_when_available(self, server):
        fake_result = _FakeJudgeResult(
            passed=True,
            score=0.9,
            reason='@agent_test("test weather")\nasync def test_weather(): ...',
        )
        mock_judge_instance = AsyncMock()
        mock_judge_instance.evaluate = AsyncMock(return_value=fake_result)

        with patch(JUDGE_IMPORT, return_value=mock_judge_instance):
            result = await server._suggest_test({
                "code_or_description": "A weather lookup agent",
            })
        assert "LLM-generated" in result

    async def test_keyword_fallback_for_suggest(self, server):
        with patch(JUDGE_IMPORT, side_effect=ImportError("no LLM")):
            result = await server._suggest_test({
                "code_or_description": "An agent that uses tools to search",
            })
        assert "Suggested tailtest tests" in result
        assert "test_tool_call" in result

    async def test_keyword_suggest_pii(self, server):
        result = server._keyword_suggest("Agent handles personal email addresses")
        assert "no_pii" in result

    async def test_keyword_suggest_prompt_injection(self, server):
        result = server._keyword_suggest("System prompt with injection risk")
        assert "prompt_injection" in result or "system prompt" in result

    async def test_keyword_suggest_cost(self, server):
        result = server._keyword_suggest("Budget-constrained token usage")
        assert "cost_under" in result

    async def test_keyword_suggest_reliability(self, server):
        result = server._keyword_suggest("Agent must be reliable and consistent")
        assert "retries" in result

    async def test_keyword_suggest_structured(self, server):
        result = server._keyword_suggest("Returns JSON formatted output")
        assert "structured_output" in result or "JSON" in result

    async def test_keyword_suggest_default_tests(self, server):
        result = server._keyword_suggest("A basic chatbot")
        # Should include edge case and PII defaults
        assert "edge_case" in result or "no_pii" in result

    async def test_keyword_suggest_always_has_basic_test(self, server):
        result = server._keyword_suggest("anything")
        assert "test_basic_response" in result
        assert "from tailtest import" in result


# -- MCP protocol integration tests ----------------------------------------


class TestMCPProtocolIntegration:
    """Verify the MCP protocol routes to the updated tool implementations."""

    @pytest.fixture
    def server(self):
        return TailtestMCPServer()

    async def test_explain_via_protocol(self, server):
        msg = _make_call_msg("explain_failure", {
            "test_name": "test_foo",
            "error_message": "Request timeout after 30s",
        })
        # Mock out LLM so it falls back to keyword
        with patch(JUDGE_IMPORT, side_effect=ImportError("no LLM")):
            response = await server.handle_message(msg)
        data = json.loads(response)
        assert data["result"]["content"][0]["text"]
        assert "time limit" in data["result"]["content"][0]["text"].lower()

    async def test_suggest_via_protocol(self, server):
        msg = _make_call_msg("suggest_test", {
            "code_or_description": "A tool-using agent",
        })
        with patch(JUDGE_IMPORT, side_effect=ImportError("no LLM")):
            response = await server.handle_message(msg)
        data = json.loads(response)
        text = data["result"]["content"][0]["text"]
        assert "agent_test" in text
