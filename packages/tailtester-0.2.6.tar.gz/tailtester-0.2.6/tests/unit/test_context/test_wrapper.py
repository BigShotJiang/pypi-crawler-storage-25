"""Tests for the ProcessWrapper context source."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tailtest.context.sources.session import (
    SessionReport,
    SessionTracker,
    FailureDetail,
)
from tailtest.context.sources.wrapper import ProcessWrapper, WrapResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_process(exit_code: int = 0) -> AsyncMock:
    """Create a mock asyncio subprocess that exits with the given code."""
    proc = AsyncMock()
    proc.returncode = None

    async def _wait():
        proc.returncode = exit_code
        return exit_code

    proc.wait = _wait
    proc.send_signal = MagicMock()
    proc.kill = MagicMock()
    return proc


def _make_scan_result():
    """Create a minimal ScanResult for test purposes."""
    from tailtest.models import ScanResult

    return ScanResult(
        framework="unknown",
        tools=[],
        prompts=[],
        agents=[],
        models=[],
        env_vars=[],
        dependencies=[],
        config_files=[],
    )


def _patch_session_tracker():
    """Patch SessionTracker to avoid real filesystem snapshots during tests."""
    mock_tracker = MagicMock(spec=SessionTracker)
    now = datetime.now(tz=timezone.utc)
    mock_tracker.finish.return_value = SessionReport(
        start_time=now,
        end_time=now,
        duration_seconds=0.0,
    )
    mock_tracker.save_report.return_value = None
    return mock_tracker


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestWrapperStartsSubprocess:
    """Verify the wrapper starts the command as a subprocess."""

    async def test_wrapper_starts_subprocess(self, tmp_path):
        """ProcessWrapper should invoke asyncio.create_subprocess_shell
        with the given command."""
        mock_proc = _make_mock_process(exit_code=0)
        scan_result = _make_scan_result()

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ) as mock_create,
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=scan_result,
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=0,
            ),
        ):
            wrapper = ProcessWrapper("echo hello", tmp_path)
            result = await wrapper.run()

            mock_create.assert_called_once()
            call_args = mock_create.call_args
            assert call_args[0][0] == "echo hello"
            assert result.command == "echo hello"


class TestWrapperWatchesFiles:
    """Verify the wrapper launches a file watcher during subprocess execution."""

    async def test_wrapper_watches_files(self, tmp_path):
        """The watcher task should be started while the subprocess runs."""
        mock_proc = _make_mock_process(exit_code=0)
        watcher_started = asyncio.Event()

        original_wait = mock_proc.wait

        async def slow_wait():
            """Wait for the watcher to start before letting the process exit."""
            await watcher_started.wait()
            return await original_wait()

        mock_proc.wait = slow_wait

        async def fake_watch_files(self_ref, tracker=None):
            watcher_started.set()
            try:
                await asyncio.sleep(100)
            except asyncio.CancelledError:
                raise

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                fake_watch_files,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=0,
            ),
        ):
            wrapper = ProcessWrapper("echo hi", tmp_path)
            result = await wrapper.run()

            assert watcher_started.is_set()


class TestWrapperScansAfterExit:
    """Verify the wrapper runs a final scan after the subprocess exits."""

    async def test_wrapper_scans_after_exit(self, tmp_path):
        """_final_scan should be called after the subprocess exits."""
        mock_proc = _make_mock_process(exit_code=0)
        scan_called = False

        async def track_scan(self_ref):
            nonlocal scan_called
            scan_called = True
            return _make_scan_result()

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                track_scan,
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=0,
            ),
        ):
            wrapper = ProcessWrapper("echo done", tmp_path)
            await wrapper.run()

            assert scan_called


class TestWrapperHandlesCrash:
    """Verify the wrapper handles a subprocess crash gracefully."""

    async def test_wrapper_handles_crash(self, tmp_path):
        """Non-zero exit code should be captured in WrapResult."""
        mock_proc = _make_mock_process(exit_code=1)

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=0,
            ),
        ):
            wrapper = ProcessWrapper("false", tmp_path)
            result = await wrapper.run()

            assert result.exit_code == 1


class TestWrapperCtrlC:
    """Verify Ctrl+C handling terminates both subprocess and watcher."""

    async def test_wrapper_ctrl_c(self, tmp_path):
        """When the process wait is cancelled, _kill_process should be invoked."""
        mock_proc = _make_mock_process(exit_code=0)
        kill_called = False

        async def _wait_forever():
            """Simulate a long-running process that gets cancelled."""
            raise asyncio.CancelledError

        mock_proc.wait = _wait_forever

        original_kill = ProcessWrapper._kill_process

        async def track_kill(self_ref):
            nonlocal kill_called
            kill_called = True

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_kill_process",
                track_kill,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=0,
            ),
        ):
            wrapper = ProcessWrapper("sleep 999", tmp_path)
            result = await wrapper.run()

            assert kill_called
            assert result.exit_code == -2


class TestWrapperNoRunFlag:
    """Verify the --no-run flag skips test execution."""

    async def test_wrapper_no_run_flag(self, tmp_path):
        """With no_run=True, _run_tests_detailed should not be called."""
        mock_proc = _make_mock_process(exit_code=0)
        run_tests_called = False

        async def track_run(self_ref):
            nonlocal run_tests_called
            run_tests_called = True
            return (0, 0, 0, [])

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=3,
            ),
            patch.object(
                ProcessWrapper,
                "_run_tests_detailed",
                track_run,
            ),
        ):
            wrapper = ProcessWrapper("echo hi", tmp_path, no_run=True)
            result = await wrapper.run()

            assert not run_tests_called
            assert result.tests_passed == 0
            assert result.tests_failed == 0


class TestWrapperUnderstandFlag:
    """Verify the --understand flag is stored and accessible."""

    async def test_wrapper_understand_flag(self, tmp_path):
        """The understand flag should be stored on the wrapper."""
        wrapper = ProcessWrapper("echo test", tmp_path, understand=True)
        assert wrapper.understand is True

        wrapper2 = ProcessWrapper("echo test", tmp_path, understand=False)
        assert wrapper2.understand is False


class TestWrapperGeneratesReport:
    """Verify the wrapper produces a complete WrapResult."""

    async def test_wrapper_generates_report(self, tmp_path):
        """WrapResult should contain all session metrics."""
        mock_proc = _make_mock_process(exit_code=0)

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=2,
            ),
            patch.object(
                ProcessWrapper,
                "_run_tests_detailed",
                return_value=(1, 1, 0, [("test_fail", "assertion error")]),
            ),
        ):
            wrapper = ProcessWrapper("echo report", tmp_path)
            result = await wrapper.run()

            assert isinstance(result, WrapResult)
            assert result.command == "echo report"
            assert result.exit_code == 0
            assert result.duration_seconds > 0
            assert result.tests_generated == 2
            assert result.tests_passed == 1
            assert result.tests_failed == 1


# ---------------------------------------------------------------------------
# New feature tests: bookend mode, live mode, exit report, fix mode
# ---------------------------------------------------------------------------


class TestWrapBookendModeNoOutputDuringSession:
    """Verify bookend mode suppresses file-change output during the session."""

    async def test_wrap_bookend_mode_no_output_during_session(self, tmp_path):
        """In bookend mode (default), file change events should not print."""
        from rich.console import Console

        output = StringIO()
        test_console = Console(file=output, force_terminal=True)

        mock_proc = _make_mock_process(exit_code=0)

        # Simulate a file watcher that fires a change event
        async def fake_watch(self_ref, tracker=None):
            # In bookend mode the watcher should NOT print change lines
            # (the wrapper code has a `if not self.live: pass` branch)
            pass

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                fake_watch,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=0,
            ),
        ):
            wrapper = ProcessWrapper(
                "echo bookend", tmp_path, live=False, console=test_console
            )
            result = await wrapper.run()

            captured = output.getvalue()
            # Should NOT contain file change markers like + ~ -
            # The output should have the session report but no per-file lines
            assert result.exit_code == 0
            # Bookend mode doesn't show individual file changes
            assert "added" not in captured or "modified" not in captured

    async def test_bookend_mode_is_default(self, tmp_path):
        """ProcessWrapper should default to bookend mode (live=False)."""
        wrapper = ProcessWrapper("echo test", tmp_path)
        assert wrapper.live is False


class TestWrapLiveModeDebounced:
    """Verify live mode stores pending changes for debounced processing."""

    async def test_wrap_live_mode_debounced(self, tmp_path):
        """In live mode, changes should be queued for debounced processing."""
        mock_proc = _make_mock_process(exit_code=0)

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=0,
            ),
        ):
            wrapper = ProcessWrapper("echo live", tmp_path, live=True)
            assert wrapper.live is True

            result = await wrapper.run()
            assert result.exit_code == 0

    async def test_live_mode_flag_stored(self, tmp_path):
        """The live flag should be stored on the wrapper."""
        wrapper = ProcessWrapper("echo test", tmp_path, live=True)
        assert wrapper.live is True

        wrapper2 = ProcessWrapper("echo test", tmp_path, live=False)
        assert wrapper2.live is False


class TestWrapExitReportFormat:
    """Verify the rich exit report contains expected sections."""

    async def test_wrap_exit_report_format(self, tmp_path):
        """The exit report should contain session duration, file counts,
        test results, and failure details."""
        from rich.console import Console

        output = StringIO()
        test_console = Console(file=output, force_terminal=True)

        mock_proc = _make_mock_process(exit_code=0)

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=3,
            ),
            patch.object(
                ProcessWrapper,
                "_run_tests_detailed",
                return_value=(2, 1, 0, [("test_pii_leak", "email in response")]),
            ),
        ):
            wrapper = ProcessWrapper("echo report", tmp_path, console=test_console)
            result = await wrapper.run()

            captured = output.getvalue()

            # Should contain key sections
            assert "Session Report" in captured
            assert "Session:" in captured
            assert "Files created:" in captured
            assert "Files modified:" in captured
            assert "Files deleted:" in captured
            assert "Auto-generated:" in captured
            assert "passed" in captured
            assert "failed" in captured
            assert "Failures:" in captured
            assert "test_pii_leak" in captured
            assert "email in response" in captured

    async def test_exit_report_no_tests(self, tmp_path):
        """When no tests are generated, report should say so."""
        from rich.console import Console

        output = StringIO()
        test_console = Console(file=output, force_terminal=True)

        mock_proc = _make_mock_process(exit_code=0)

        with (
            patch(
                "asyncio.create_subprocess_shell",
                return_value=mock_proc,
            ),
            patch.object(
                ProcessWrapper,
                "_watch_files",
                new_callable=AsyncMock,
            ),
            patch.object(
                ProcessWrapper,
                "_final_scan",
                return_value=_make_scan_result(),
            ),
            patch.object(
                ProcessWrapper,
                "_generate_tests",
                return_value=0,
            ),
        ):
            wrapper = ProcessWrapper("echo nada", tmp_path, console=test_console)
            await wrapper.run()

            captured = output.getvalue()
            assert "No tests generated" in captured


class TestWrapFixReadsPreviousSession:
    """Verify --fix mode loads and uses a previous session report."""

    def test_wrap_fix_reads_previous_session(self, tmp_path):
        """_write_fix_context should produce a fix-context.md from a report."""
        from tailtest.cli.wrap import _write_fix_context

        reports_dir = tmp_path / ".tailtest" / "reports"
        reports_dir.mkdir(parents=True)

        now = datetime.now(tz=timezone.utc)
        prev_report = SessionReport(
            start_time=now,
            end_time=now,
            duration_seconds=120.0,
            command="claude code",
            exit_code=0,
            files_created=["new.py"],
            files_modified=["old.py"],
            tests_generated=5,
            tests_passed=3,
            tests_failed=2,
            test_failures=[
                FailureDetail(name="test_no_pii", message="leaked email"),
                FailureDetail(name="test_cost", message="cost too high"),
            ],
        )

        fix_path = _write_fix_context(reports_dir, prev_report)

        assert fix_path.exists()
        content = fix_path.read_text()
        assert "Fix Context" in content
        assert "test_no_pii" in content
        assert "leaked email" in content
        assert "test_cost" in content
        assert "cost too high" in content
        assert "new.py" in content
        assert "old.py" in content


class TestWrapFixComparesResults:
    """Verify --fix mode comparison output."""

    def test_wrap_fix_compares_results(self, tmp_path):
        """_print_fix_comparison should show improvement."""
        import re
        from rich.console import Console
        from tailtest.cli.wrap import _print_fix_comparison

        output = StringIO()
        test_console = Console(file=output, force_terminal=True)

        # Monkey-patch the module-level console for the comparison function
        import tailtest.cli.wrap as wrap_mod

        original_console = wrap_mod.console
        wrap_mod.console = test_console

        try:
            now = datetime.now(tz=timezone.utc)
            previous = SessionReport(
                start_time=now,
                end_time=now,
                duration_seconds=60.0,
                tests_failed=4,
                tests_passed=10,
            )

            current = WrapResult(
                command="echo fix",
                exit_code=0,
                duration_seconds=30.0,
                tests_failed=1,
                tests_passed=13,
            )

            _print_fix_comparison(previous, current)

            captured = output.getvalue()
            # Strip ANSI escape codes for content assertions
            plain = re.sub(r"\x1b\[[0-9;]*m", "", captured)
            assert "Fix Comparison" in plain
            assert "Previous:" in plain
            assert "4 failures" in plain
            assert "1 failures" in plain
            assert "Fixed:" in plain
            assert "3" in plain  # 4 - 1 = 3 fixed
        finally:
            wrap_mod.console = original_console

    def test_fix_comparison_no_improvement(self, tmp_path):
        """When failures increase, comparison should show new failures."""
        import re
        from rich.console import Console
        from tailtest.cli.wrap import _print_fix_comparison

        output = StringIO()
        test_console = Console(file=output, force_terminal=True)

        import tailtest.cli.wrap as wrap_mod

        original_console = wrap_mod.console
        wrap_mod.console = test_console

        try:
            now = datetime.now(tz=timezone.utc)
            previous = SessionReport(
                start_time=now,
                end_time=now,
                duration_seconds=60.0,
                tests_failed=2,
                tests_passed=10,
            )

            current = WrapResult(
                command="echo fix",
                exit_code=0,
                duration_seconds=30.0,
                tests_failed=5,
                tests_passed=7,
            )

            _print_fix_comparison(previous, current)

            captured = output.getvalue()
            plain = re.sub(r"\x1b\[[0-9;]*m", "", captured)
            assert "New failures:" in plain
        finally:
            wrap_mod.console = original_console
