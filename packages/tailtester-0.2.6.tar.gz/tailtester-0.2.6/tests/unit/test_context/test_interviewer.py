"""Tests for the AgentInterviewer context source."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from tailtest.context.sources.interviewer import (
    AgentInterviewer,
    InterviewResult,
    _normalise_interface,
    _parse_comma_list,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_result(**kwargs) -> InterviewResult:
    """Create an InterviewResult with sensible defaults for testing."""
    defaults = {
        "domain": "customer support bot",
        "tools": ["lookup_order", "search_faq", "create_ticket"],
        "never_rules": ["give medical advice", "reveal other customers data"],
        "always_rules": ["ask for confirmation", "cite knowledge base"],
        "interface_type": "http",
        "interface_details": "http://localhost:8000/chat",
        "priority": "safety",
    }
    defaults.update(kwargs)
    return InterviewResult(**defaults)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestInterviewAsksQuestions:
    """Verify the interview prompts for all six questions."""

    async def test_interview_asks_questions(self):
        """Each question should be presented via click.prompt and the
        answers parsed into an InterviewResult."""
        answers = [
            "email assistant",        # domain
            "send_email, read_inbox", # tools
            "delete emails",          # never
            "confirm before sending", # always
            "http",                   # interface_type
            "http://localhost:5000",   # interface_details
        ]

        interviewer = AgentInterviewer()

        with (
            patch.object(interviewer, "is_interactive", return_value=True),
            patch("click.prompt", side_effect=answers),
            patch("click.echo"),
        ):
            result = await interviewer.interview()

        assert result.domain == "email assistant"
        assert result.tools == ["send_email", "read_inbox"]
        assert result.never_rules == ["delete emails"]
        assert result.always_rules == ["confirm before sending"]
        assert result.interface_type == "http"
        assert result.interface_details == "http://localhost:5000"


class TestInterviewGeneratesRulesYaml:
    """Verify rules.yaml generation from interview results."""

    def test_interview_generates_rules_yaml(self, tmp_path):
        """Generated rules.yaml should contain never, always, and scenario entries."""
        result = _make_result()
        interviewer = AgentInterviewer()
        path = interviewer.generate_rules_yaml(result, tmp_path)

        assert path.exists()
        assert path.name == "rules.yaml"
        assert path.parent.name == ".tailtest"

        content = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert "never" in content
        assert "always" in content
        assert "give medical advice" in content["never"]
        assert "ask for confirmation" in content["always"]
        assert "scenarios" in content
        assert len(content["scenarios"]) == 3  # one per tool


class TestInterviewGeneratesConfig:
    """Verify tailtest.yaml generation from interview results."""

    def test_interview_generates_config(self, tmp_path):
        """Generated tailtest.yaml should have the agent connection config."""
        result = _make_result()
        interviewer = AgentInterviewer()
        path = interviewer.generate_config(result, tmp_path)

        assert path.exists()
        assert path.name == "tailtest.yaml"

        content = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert content["version"] == "1"
        assert content["agent"]["type"] == "http"
        assert content["agent"]["url"] == "http://localhost:8000/chat"
        assert content["domain"] == "customer support bot"


class TestInterviewParsesCommaLists:
    """Verify comma-separated answer parsing."""

    def test_interview_parses_comma_lists(self):
        """_parse_comma_list should split on commas and strip whitespace."""
        assert _parse_comma_list("a, b, c") == ["a", "b", "c"]
        assert _parse_comma_list("one") == ["one"]
        assert _parse_comma_list("  foo ,  bar  ") == ["foo", "bar"]
        assert _parse_comma_list("") == []
        assert _parse_comma_list("a,,b,") == ["a", "b"]


class TestInterviewHandlesEmptyAnswers:
    """Verify graceful handling of empty answers."""

    async def test_interview_handles_empty_answers(self):
        """Empty strings for all answers should produce an InterviewResult
        with empty lists and defaults."""
        answers = ["", "", "", "", "", ""]

        interviewer = AgentInterviewer()

        with (
            patch.object(interviewer, "is_interactive", return_value=True),
            patch("click.prompt", side_effect=answers),
            patch("click.echo"),
        ):
            result = await interviewer.interview()

        assert result.domain == ""
        assert result.tools == []
        assert result.never_rules == []
        assert result.always_rules == []
        # Default interface type should be "http" for empty input
        assert result.interface_type == "http"
        assert result.interface_details == ""

    def test_empty_result_generates_minimal_rules(self, tmp_path):
        """An empty InterviewResult should produce a rules.yaml that is
        a valid YAML mapping (even if sparse)."""
        result = InterviewResult()
        interviewer = AgentInterviewer()
        path = interviewer.generate_rules_yaml(result, tmp_path)

        assert path.exists()
        content = yaml.safe_load(path.read_text(encoding="utf-8"))
        # Should be a dict (possibly empty or None for empty mapping)
        assert content is None or isinstance(content, dict)


class TestInterviewSkipsInCI:
    """Verify the interview is skipped in non-interactive environments."""

    async def test_interview_skips_in_ci(self):
        """When CI env var is set, interview should return empty result
        without prompting."""
        interviewer = AgentInterviewer()

        with patch.dict(os.environ, {"CI": "true"}, clear=False):
            result = await interviewer.interview()

        assert result.domain == ""
        assert result.tools == []
        assert result.never_rules == []

    async def test_interview_skips_with_env_override(self):
        """TAILTEST_INTERACTIVE=0 should skip the interview."""
        interviewer = AgentInterviewer()

        with patch.dict(
            os.environ, {"TAILTEST_INTERACTIVE": "0"}, clear=False
        ):
            result = await interviewer.interview()

        assert result.domain == ""


class TestInterviewHttpConfig:
    """Verify HTTP-specific config generation."""

    def test_interview_http_config(self, tmp_path):
        """HTTP interface type should produce a config with url field."""
        result = _make_result(
            interface_type="http",
            interface_details="http://api.example.com/v1/chat",
        )
        interviewer = AgentInterviewer()
        path = interviewer.generate_config(result, tmp_path)

        content = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert content["agent"]["type"] == "http"
        assert content["agent"]["url"] == "http://api.example.com/v1/chat"

    def test_interview_cli_config(self, tmp_path):
        """CLI interface type should produce a config with command field."""
        result = _make_result(
            interface_type="cli",
            interface_details="python agent.py",
        )
        interviewer = AgentInterviewer()
        path = interviewer.generate_config(result, tmp_path)

        content = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert content["agent"]["type"] == "cli"
        assert content["agent"]["command"] == "python agent.py"

    def test_interview_python_config(self, tmp_path):
        """Python interface type should produce a config with function field."""
        result = _make_result(
            interface_type="python",
            interface_details="myagent:run",
        )
        interviewer = AgentInterviewer()
        path = interviewer.generate_config(result, tmp_path)

        content = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert content["agent"]["type"] == "python"
        assert content["agent"]["function"] == "myagent:run"


class TestNormaliseInterface:
    """Verify interface type normalisation."""

    def test_normalise_known_types(self):
        assert _normalise_interface("http") == "http"
        assert _normalise_interface("HTTP") == "http"
        assert _normalise_interface("api") == "http"
        assert _normalise_interface("rest") == "http"
        assert _normalise_interface("cli") == "cli"
        assert _normalise_interface("command") == "cli"
        assert _normalise_interface("python") == "python"
        assert _normalise_interface("py") == "python"

    def test_normalise_unknown_defaults_to_http(self):
        assert _normalise_interface("") == "http"
        assert _normalise_interface("something") == "http"
