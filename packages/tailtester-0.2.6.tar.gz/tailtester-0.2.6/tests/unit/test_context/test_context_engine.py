"""Tests for ContextEngine.save_context  -  verify correct output path."""

from __future__ import annotations

import pytest

from tailtest.context.engine import ContextEngine
from tailtest.models import ScanResult


@pytest.fixture
def sample_scan():
    return ScanResult(
        framework="openai",
        framework_version=None,
        tools=[],
        prompts=[],
        agents=[],
        models=["gpt-4o"],
        env_vars=[],
        dependencies=[],
        config_files=[],
    )


class TestSaveContext:
    def test_saves_to_correct_path(self, tmp_path, sample_scan):
        """save_context should write to <project_root>/.tailtest/context/scan.json,
        NOT to <project_root>/.tailtest/context/.tailtest/context/scan.json.

        This was Bug 3: scan.py passed .tailtest/context as the output_dir
        which caused save_scan to nest another .tailtest/context/ inside it.
        """
        engine = ContextEngine()
        scan_path = engine.save_context(sample_scan, tmp_path)

        # Must be at the correct path
        expected = tmp_path / ".tailtest" / "context" / "scan.json"
        assert scan_path == expected
        assert expected.is_file()

        # Must NOT have the nested duplicate path
        bad_path = tmp_path / ".tailtest" / "context" / ".tailtest" / "context" / "scan.json"
        assert not bad_path.exists()

    def test_roundtrip_via_engine(self, tmp_path, sample_scan):
        """save_context then load_context should round-trip."""
        engine = ContextEngine()
        engine.save_context(sample_scan, tmp_path)

        loaded = engine.load_context(tmp_path)
        assert loaded is not None
        assert loaded.framework == "openai"
