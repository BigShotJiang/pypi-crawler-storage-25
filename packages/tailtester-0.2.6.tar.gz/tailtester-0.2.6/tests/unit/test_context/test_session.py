"""Tests for SessionTracker and SessionReport."""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from tailtest.context.sources.session import (
    FileChange,
    SessionReport,
    SessionTracker,
    FailureDetail,
)


# ---------------------------------------------------------------------------
# SessionReport dataclass
# ---------------------------------------------------------------------------


class TestSessionReportDataclass:
    """Verify SessionReport model serialization and fields."""

    def test_session_report_dataclass(self):
        """SessionReport should round-trip through JSON."""
        from datetime import datetime, timezone

        now = datetime.now(tz=timezone.utc)
        report = SessionReport(
            start_time=now,
            end_time=now,
            duration_seconds=42.0,
            command="echo test",
            exit_code=0,
            files_created=["a.py"],
            files_modified=["b.py"],
            files_deleted=["c.py"],
            tests_generated=5,
            tests_by_source={"structural": 3, "llm-inferred": 2},
            tests_passed=4,
            tests_failed=1,
            test_failures=[
                FailureDetail(name="test_foo", message="assertion failed")
            ],
        )

        data = json.loads(report.model_dump_json())
        restored = SessionReport.model_validate(data)

        assert restored.duration_seconds == 42.0
        assert restored.command == "echo test"
        assert restored.files_created == ["a.py"]
        assert restored.files_modified == ["b.py"]
        assert restored.files_deleted == ["c.py"]
        assert restored.tests_generated == 5
        assert restored.tests_passed == 4
        assert restored.tests_failed == 1
        assert len(restored.test_failures) == 1
        assert restored.test_failures[0].name == "test_foo"

    def test_session_report_defaults(self):
        """SessionReport should have sensible defaults for optional fields."""
        from datetime import datetime, timezone

        now = datetime.now(tz=timezone.utc)
        report = SessionReport(
            start_time=now,
            end_time=now,
            duration_seconds=0.0,
        )
        assert report.files_created == []
        assert report.files_modified == []
        assert report.files_deleted == []
        assert report.tests_generated == 0
        assert report.tests_passed == 0
        assert report.tests_failed == 0
        assert report.test_failures == []
        assert report.tests_by_source == {}
        assert report.report_path is None


# ---------------------------------------------------------------------------
# SessionTracker snapshots
# ---------------------------------------------------------------------------


class TestSessionTrackerSnapshots:
    """Verify initial project snapshots."""

    def test_session_tracker_snapshots_files(self, tmp_path: Path):
        """Tracker should capture file hashes at start."""
        # Create some files
        (tmp_path / "hello.py").write_text("print('hello')")
        (tmp_path / "data.json").write_text('{"key": "value"}')

        tracker = SessionTracker(tmp_path)
        tracker.start()

        # The snapshot should contain both files
        assert "hello.py" in tracker._start_snapshot
        assert "data.json" in tracker._start_snapshot
        assert len(tracker._start_snapshot) == 2

    def test_snapshot_skips_ignored_dirs(self, tmp_path: Path):
        """Files in .git, __pycache__ etc. should be excluded."""
        pycache = tmp_path / "__pycache__"
        pycache.mkdir()
        (pycache / "cached.py").write_text("cached")
        (tmp_path / "real.py").write_text("real")

        tracker = SessionTracker(tmp_path)
        tracker.start()

        assert "real.py" in tracker._start_snapshot
        assert "__pycache__/cached.py" not in tracker._start_snapshot

    def test_snapshot_only_watched_suffixes(self, tmp_path: Path):
        """Only files with watched suffixes should appear in snapshot."""
        (tmp_path / "code.py").write_text("pass")
        (tmp_path / "image.png").write_bytes(b"\x89PNG")

        tracker = SessionTracker(tmp_path)
        tracker.start()

        assert "code.py" in tracker._start_snapshot
        assert "image.png" not in tracker._start_snapshot


# ---------------------------------------------------------------------------
# Change detection
# ---------------------------------------------------------------------------


class TestSessionTrackerDetectsCreates:
    """Verify creation detection via snapshot diff."""

    def test_session_tracker_detects_creates(self, tmp_path: Path):
        """Files added after start should appear in files_created."""
        tracker = SessionTracker(tmp_path)
        tracker.start()

        # Create a file after the snapshot
        (tmp_path / "new_file.py").write_text("new")

        report = tracker.finish()

        assert "new_file.py" in report.files_created
        assert report.files_modified == []
        assert report.files_deleted == []


class TestSessionTrackerDetectsModifies:
    """Verify modification detection via snapshot diff."""

    def test_session_tracker_detects_modifies(self, tmp_path: Path):
        """Files changed after start should appear in files_modified."""
        (tmp_path / "existing.py").write_text("original content")

        tracker = SessionTracker(tmp_path)
        tracker.start()

        # Modify the file
        (tmp_path / "existing.py").write_text("modified content")

        report = tracker.finish()

        assert "existing.py" in report.files_modified
        assert report.files_created == []
        assert report.files_deleted == []


class TestSessionTrackerDetectsDeletes:
    """Verify deletion detection via snapshot diff."""

    def test_session_tracker_detects_deletes(self, tmp_path: Path):
        """Files removed after start should appear in files_deleted."""
        (tmp_path / "doomed.py").write_text("goodbye")

        tracker = SessionTracker(tmp_path)
        tracker.start()

        # Delete the file
        (tmp_path / "doomed.py").unlink()

        report = tracker.finish()

        assert "doomed.py" in report.files_deleted
        assert report.files_created == []
        assert report.files_modified == []


class TestSessionTrackerMixedChanges:
    """Verify all change types detected simultaneously."""

    def test_mixed_changes(self, tmp_path: Path):
        """Creates, modifies, and deletes should all be detected."""
        (tmp_path / "keep.py").write_text("keep")
        (tmp_path / "remove.py").write_text("remove")

        tracker = SessionTracker(tmp_path)
        tracker.start()

        (tmp_path / "keep.py").write_text("modified keep")
        (tmp_path / "remove.py").unlink()
        (tmp_path / "brand_new.py").write_text("new")

        report = tracker.finish()

        assert "brand_new.py" in report.files_created
        assert "keep.py" in report.files_modified
        assert "remove.py" in report.files_deleted


# ---------------------------------------------------------------------------
# record_change
# ---------------------------------------------------------------------------


class TestSessionTrackerRecordChange:
    """Verify the record_change method stores events."""

    def test_record_change(self, tmp_path: Path):
        """record_change should append to the internal changes list."""
        tracker = SessionTracker(tmp_path)
        tracker.start()

        tracker.record_change("foo.py", "modified")
        tracker.record_change("bar.py", "created")

        assert len(tracker._changes) == 2
        assert tracker._changes[0].path == "foo.py"
        assert tracker._changes[0].action == "modified"
        assert tracker._changes[1].path == "bar.py"
        assert tracker._changes[1].action == "created"


# ---------------------------------------------------------------------------
# Report persistence
# ---------------------------------------------------------------------------


class TestSessionTrackerPersistence:
    """Verify save/load of session reports."""

    def test_save_and_load_report(self, tmp_path: Path):
        """A saved report should be loadable."""
        (tmp_path / "src.py").write_text("pass")

        tracker = SessionTracker(tmp_path)
        tracker.start()

        (tmp_path / "src.py").write_text("updated")

        report = tracker.finish(
            command="test cmd",
            exit_code=0,
            tests_generated=3,
            tests_passed=2,
            tests_failed=1,
            test_failures=[
                FailureDetail(name="test_x", message="boom")
            ],
        )

        reports_dir = tmp_path / ".tailtest" / "reports"
        saved_path = tracker.save_report(report, reports_dir)

        assert saved_path.exists()

        loaded = SessionTracker.load_latest_report(reports_dir)
        assert loaded is not None
        assert loaded.command == "test cmd"
        assert loaded.tests_generated == 3
        assert loaded.tests_passed == 2
        assert loaded.tests_failed == 1
        assert len(loaded.test_failures) == 1

    def test_load_latest_report_empty_dir(self, tmp_path: Path):
        """load_latest_report should return None when no reports exist."""
        reports_dir = tmp_path / "empty_reports"
        reports_dir.mkdir()

        result = SessionTracker.load_latest_report(reports_dir)
        assert result is None

    def test_load_latest_report_missing_dir(self, tmp_path: Path):
        """load_latest_report should return None when dir doesn't exist."""
        result = SessionTracker.load_latest_report(tmp_path / "nonexistent")
        assert result is None
