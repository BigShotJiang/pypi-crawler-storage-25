"""Tests for load_config  -  search_from parameter and walk-up resolution."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from tailtest.config.loader import load_config


@pytest.fixture
def project_tree(tmp_path):
    """Build a project tree with two tailtest.yaml files:

    tmp_path/
      tailtest.yaml          (root config, agent type: http)
      testing/
        tailtest/
          tailtest.yaml      (sub-dir config, agent type: cli)
          tests/
            test_example.py
    """
    root_cfg = {"version": "1", "agent": {"type": "http", "url": "http://root:8000"}}
    sub_cfg = {"version": "1", "agent": {"type": "cli", "command": "python agent.py"}}

    (tmp_path / "tailtest.yaml").write_text(yaml.dump(root_cfg))

    sub_dir = tmp_path / "testing" / "tailtest"
    sub_dir.mkdir(parents=True)
    (sub_dir / "tailtest.yaml").write_text(yaml.dump(sub_cfg))

    tests_dir = sub_dir / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_example.py").write_text("# test stub")

    return tmp_path


class TestSearchFrom:
    """Verify that search_from controls where config discovery starts."""

    def test_search_from_subdir_finds_subdir_config(self, project_tree):
        """When search_from points to the test subdir, the subdir config wins."""
        sub_dir = project_tree / "testing" / "tailtest"
        config = load_config(search_from=sub_dir)
        assert config.agent.type == "cli"
        assert config.agent.command == "python agent.py"

    def test_search_from_none_uses_cwd(self, project_tree, monkeypatch):
        """When search_from is None, load_config falls back to CWD."""
        monkeypatch.chdir(project_tree)
        config = load_config()
        assert config.agent.type == "http"
        assert config.agent.url == "http://root:8000"

    def test_search_from_walks_up(self, project_tree):
        """search_from walks up from a deep directory to find the nearest config."""
        deep = project_tree / "testing" / "tailtest" / "tests"
        config = load_config(search_from=deep)
        # Should find testing/tailtest/tailtest.yaml, not the root one
        assert config.agent.type == "cli"

    def test_search_from_with_file_path(self, project_tree):
        """search_from handles a file path by starting from its parent dir."""
        file_path = project_tree / "testing" / "tailtest" / "tests" / "test_example.py"
        config = load_config(search_from=file_path)
        assert config.agent.type == "cli"

    def test_search_from_root_finds_root_config(self, project_tree):
        """search_from at the project root finds the root config."""
        config = load_config(search_from=project_tree)
        assert config.agent.type == "http"

    def test_explicit_path_ignores_search_from(self, project_tree):
        """When an explicit path is given, search_from is ignored."""
        root_yaml = project_tree / "tailtest.yaml"
        sub_dir = project_tree / "testing" / "tailtest"
        config = load_config(path=root_yaml, search_from=sub_dir)
        assert config.agent.type == "http"

    def test_search_from_no_config_returns_defaults(self, tmp_path):
        """When no config is found, defaults are returned."""
        empty = tmp_path / "empty"
        empty.mkdir()
        config = load_config(search_from=empty)
        # Should get Pydantic defaults
        assert config.agent.type == "http"
        assert config.version == "1"
