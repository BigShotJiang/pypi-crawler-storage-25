"""Tests for the test generator engine  -  agent type from config."""

from __future__ import annotations

import pytest

from tailtest.config.schema import AgentConfig
from tailtest.generator.engine import TestGenerator, _agent_template_vars
from tailtest.models import ScanResult, ToolDefinition, PromptDefinition


@pytest.fixture
def minimal_scan():
    return ScanResult(
        framework="generic",
        framework_version=None,
        tools=[],
        prompts=[],
        agents=[],
        models=[],
        env_vars=[],
        dependencies=[],
        config_files=[],
    )


@pytest.fixture
def scan_with_tools():
    return ScanResult(
        framework="openai",
        framework_version=None,
        tools=[
            ToolDefinition(
                name="search",
                description="Search the web",
                parameters={"query": {"type": "string"}},
                required_params=["query"],
            ),
        ],
        prompts=[],
        agents=[],
        models=["gpt-4o"],
        env_vars=[],
        dependencies=[],
        config_files=[],
    )


@pytest.fixture
def scan_with_prompts():
    return ScanResult(
        framework="openai",
        framework_version=None,
        tools=[],
        prompts=[
            PromptDefinition(
                role="system",
                content="You are a helpful support assistant.",
                file_path="agent.py",
                line_number=10,
            ),
        ],
        agents=[],
        models=["gpt-4o"],
        env_vars=[],
        dependencies=[],
        config_files=[],
    )


# --------------------------------------------------------------------------- #
# _agent_template_vars
# --------------------------------------------------------------------------- #


class TestAgentTemplateVars:
    def test_http_type(self):
        cfg = AgentConfig(type="http", url="http://myhost:9000/api")
        agent_type, agent_config = _agent_template_vars(cfg)
        assert agent_type == "http"
        assert "http://myhost:9000/api" in agent_config

    def test_cli_type(self):
        cfg = AgentConfig(type="cli", command="python agent.py")
        agent_type, agent_config = _agent_template_vars(cfg)
        assert agent_type == "cli"
        assert "python agent.py" in agent_config

    def test_python_type(self):
        cfg = AgentConfig(type="python", function="mymodule:chat")
        agent_type, agent_config = _agent_template_vars(cfg)
        assert agent_type == "function"
        assert "mymodule:chat" in agent_config

    def test_none_config_defaults_to_http(self):
        agent_type, agent_config = _agent_template_vars(None)
        assert agent_type == "http"
        assert "localhost:8000" in agent_config

    def test_http_type_no_url_defaults(self):
        cfg = AgentConfig(type="http")
        agent_type, agent_config = _agent_template_vars(cfg)
        assert agent_type == "http"
        assert "localhost:8000" in agent_config


# --------------------------------------------------------------------------- #
# Generated test files use correct agent constructor
# --------------------------------------------------------------------------- #


class TestGeneratorUsesConfig:
    @pytest.mark.asyncio
    async def test_safety_tests_use_cli_config(self, tmp_path, minimal_scan):
        """Generated safety tests use Agent.from_cli() when config says type: cli."""
        cfg = AgentConfig(type="cli", command="python agent.py")
        gen = TestGenerator()
        paths = await gen.generate(
            minimal_scan, tmp_path, regenerate=True, only="safety", agent_cfg=cfg
        )
        assert len(paths) == 1
        content = paths[0].read_text()
        assert "Agent.from_cli(" in content
        assert "python agent.py" in content
        # The active agent line (not comments) should use from_cli
        active_lines = [
            ln for ln in content.splitlines()
            if ln.startswith("agent = Agent.from_")
        ]
        assert len(active_lines) == 1
        assert "from_cli(" in active_lines[0]

    @pytest.mark.asyncio
    async def test_safety_tests_use_http_config(self, tmp_path, minimal_scan):
        """Generated safety tests use Agent.from_http() when config says type: http."""
        cfg = AgentConfig(type="http", url="http://staging:9000/chat")
        gen = TestGenerator()
        paths = await gen.generate(
            minimal_scan, tmp_path, regenerate=True, only="safety", agent_cfg=cfg
        )
        assert len(paths) == 1
        content = paths[0].read_text()
        assert "Agent.from_http(" in content
        assert "http://staging:9000/chat" in content

    @pytest.mark.asyncio
    async def test_safety_tests_use_python_config(self, tmp_path, minimal_scan):
        """Generated safety tests use Agent.from_function() when config says type: python."""
        cfg = AgentConfig(type="python", function="myapp:chat")
        gen = TestGenerator()
        paths = await gen.generate(
            minimal_scan, tmp_path, regenerate=True, only="safety", agent_cfg=cfg
        )
        assert len(paths) == 1
        content = paths[0].read_text()
        assert "Agent.from_function(" in content
        assert "myapp:chat" in content

    @pytest.mark.asyncio
    async def test_tool_tests_use_cli_config(self, tmp_path, scan_with_tools):
        """Generated tool tests use Agent.from_cli() when config says type: cli."""
        cfg = AgentConfig(type="cli", command="./run_agent.sh")
        gen = TestGenerator()
        paths = await gen.generate(
            scan_with_tools, tmp_path, regenerate=True, only="tools", agent_cfg=cfg
        )
        assert len(paths) == 1
        content = paths[0].read_text()
        assert "Agent.from_cli(" in content
        assert "./run_agent.sh" in content

    @pytest.mark.asyncio
    async def test_prompt_tests_use_python_config(self, tmp_path, scan_with_prompts):
        """Generated prompt tests use Agent.from_function() when config says type: python."""
        cfg = AgentConfig(type="python", function="bot:respond")
        gen = TestGenerator()
        paths = await gen.generate(
            scan_with_prompts, tmp_path, regenerate=True, only="prompts", agent_cfg=cfg
        )
        assert len(paths) == 1
        content = paths[0].read_text()
        assert "Agent.from_function(" in content
        assert "bot:respond" in content

    @pytest.mark.asyncio
    async def test_no_agent_cfg_defaults_to_http_localhost(self, tmp_path, minimal_scan):
        """Without agent_cfg, generated tests default to Agent.from_http(localhost)."""
        gen = TestGenerator()
        paths = await gen.generate(
            minimal_scan, tmp_path, regenerate=True, only="safety"
        )
        assert len(paths) == 1
        content = paths[0].read_text()
        assert "Agent.from_http(" in content
        assert "localhost:8000" in content
