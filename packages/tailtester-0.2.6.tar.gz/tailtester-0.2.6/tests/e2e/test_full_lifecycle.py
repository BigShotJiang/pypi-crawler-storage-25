"""End-to-end lifecycle test - tailtest tests itself as a real user would (P2-B).

Runs the actual CLI binary against real directories to verify the full
user journey: install -> init -> scan -> generate -> run -> report -> doctor -> status.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

# Resolve the project root (two levels up from tests/e2e/)
PROJECT_ROOT = Path(__file__).resolve().parents[2]
EXAMPLES_DIR = PROJECT_ROOT / "examples"

# Use sys.executable to ensure we invoke the installed tailtest via the
# same Python that is running pytest, avoiding PATH issues.
TAILTEST = [sys.executable, "-m", "tailtest"]


def _run(args: list[str], **kwargs) -> subprocess.CompletedProcess:
    """Run a tailtest CLI command and return the result."""
    return subprocess.run(
        TAILTEST + args,
        capture_output=True,
        text=True,
        timeout=60,
        **kwargs,
    )


# -- Basic CLI tests -------------------------------------------------------


class TestCLIBasics:
    """Verify core CLI plumbing works."""

    def test_version_output(self):
        result = _run(["--version"])
        assert result.returncode == 0
        assert "tailtest" in result.stdout.lower()

    def test_help_output(self):
        result = _run(["--help"])
        assert result.returncode == 0
        assert "Usage" in result.stdout

    def test_all_commands_have_help(self):
        """Every registered CLI command responds to --help."""
        commands = [
            "init", "scan", "run", "generate", "redteam", "watch",
            "guard", "ingest", "drift", "record", "replay", "report",
            "doctor", "status", "suggest", "predict", "optimize",
            "mcp-serve", "wrap", "interview",
        ]
        for cmd in commands:
            result = _run([cmd, "--help"])
            assert result.returncode == 0, (
                f"{cmd} --help failed with rc={result.returncode}: {result.stderr}"
            )


# -- Init tests ------------------------------------------------------------


class TestInit:
    """Verify tailtest init creates the expected directory structure."""

    def test_init_creates_tailtest_dir(self, tmp_path):
        result = _run(["init", "--no-wizard"], cwd=tmp_path)
        assert result.returncode == 0
        assert (tmp_path / ".tailtest").is_dir()

    def test_init_creates_config(self, tmp_path):
        _run(["init", "--no-wizard"], cwd=tmp_path)
        config_dir = tmp_path / ".tailtest"
        # Should have at least one config file
        files = list(config_dir.iterdir())
        assert len(files) > 0

    def test_init_idempotent(self, tmp_path):
        _run(["init", "--no-wizard"], cwd=tmp_path)
        result = _run(["init", "--no-wizard"], cwd=tmp_path)
        # Should succeed even when already initialized
        assert result.returncode == 0


# -- Doctor tests ----------------------------------------------------------


class TestDoctor:
    """Verify tailtest doctor shows health check information."""

    def test_doctor_runs_successfully(self):
        result = _run(["doctor"])
        assert result.returncode == 0

    def test_doctor_shows_python(self):
        result = _run(["doctor"])
        assert "Python" in result.stdout

    def test_doctor_shows_dependencies(self):
        result = _run(["doctor"])
        output = result.stdout
        assert "pydantic" in output or "click" in output


# -- Status tests ----------------------------------------------------------


class TestStatus:
    """Verify tailtest status shows maturity tracking."""

    def test_status_shows_maturity(self):
        result = _run(["status"])
        assert result.returncode == 0
        assert "Maturity" in result.stdout or "Seedling" in result.stdout

    def test_status_shows_run_count(self):
        result = _run(["status"])
        assert "Runs" in result.stdout or "run" in result.stdout.lower()


# -- Scan tests ------------------------------------------------------------


class TestScan:
    """Verify tailtest scan works on example projects."""

    @pytest.mark.skipif(
        not (EXAMPLES_DIR / "hello-world").exists(),
        reason="hello-world example not present",
    )
    def test_scan_hello_world(self):
        example_dir = EXAMPLES_DIR / "hello-world"
        result = _run(["scan", str(example_dir)])
        assert result.returncode == 0

    def test_scan_nonexistent_dir(self):
        result = _run(["scan", "/tmp/nonexistent_tailtest_dir_xyz"])
        # Should fail gracefully
        assert result.returncode != 0 or "error" in result.stderr.lower() or "not" in result.stdout.lower()

    def test_scan_empty_dir(self, tmp_path):
        result = _run(["scan", str(tmp_path)])
        # Should succeed but find nothing
        assert result.returncode == 0


# -- Suggest tests ---------------------------------------------------------


class TestSuggest:
    """Verify tailtest suggest works."""

    def test_suggest_help(self):
        result = _run(["suggest", "--help"])
        assert result.returncode == 0


# -- Report tests ----------------------------------------------------------


class TestReport:
    """Verify tailtest report generates output."""

    def test_report_help(self):
        result = _run(["report", "--help"])
        assert result.returncode == 0
        assert "format" in result.stdout.lower() or "help" in result.stdout.lower()
