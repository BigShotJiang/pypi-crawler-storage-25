"""Dogfood Layer 2: treat tailtest's own MCP server as an agent under test.

Sends JSON-RPC 2.0 messages to TailtestMCPServer.handle_message() and
asserts on the responses -- proving tailtest can test non-chatbot agents
that speak the MCP protocol.

No external services required (Ollama, API keys).  LLM-powered code paths
are mocked so every test is deterministic and fast.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from tailtest.mcp.server import TailtestMCPServer, _TOOL_DEFINITIONS

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_EXPECTED_TOOL_NAMES = sorted([
    "generate_tests",
    "run_tests",
    "check_safety",
    "explain_failure",
    "suggest_test",
    "scan_project",
])

JUDGE_IMPORT = "tailtest.assertions.llm_judge.judge.LLMJudge"


def _jsonrpc(method: str, params: dict | None = None, msg_id: int = 1) -> str:
    """Build a JSON-RPC 2.0 request string."""
    msg: dict = {"jsonrpc": "2.0", "id": msg_id, "method": method}
    if params is not None:
        msg["params"] = params
    return json.dumps(msg)


def _tool_call(tool_name: str, arguments: dict, msg_id: int = 1) -> str:
    """Build a JSON-RPC 2.0 tools/call request."""
    return _jsonrpc("tools/call", {"name": tool_name, "arguments": arguments}, msg_id)


def _parse(raw: str) -> dict:
    """Parse a JSON-RPC response string."""
    return json.loads(raw)


def _text(response: dict) -> str:
    """Extract the text content from a tools/call result."""
    return response["result"]["content"][0]["text"]


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def server() -> TailtestMCPServer:
    return TailtestMCPServer()


@pytest.fixture
def hello_world_path() -> Path:
    """Path to the examples/hello-world project."""
    return Path(__file__).resolve().parents[2] / "examples" / "hello-world"


# ---------------------------------------------------------------------------
# MCP protocol tests
# ---------------------------------------------------------------------------


class TestMCPProtocol:
    """Verify the MCP JSON-RPC protocol layer behaves correctly."""

    async def test_mcp_initialize_returns_capabilities(self, server):
        """initialize should return protocolVersion, capabilities, and serverInfo."""
        raw = await server.handle_message(_jsonrpc("initialize"))
        data = _parse(raw)

        assert "error" not in data
        result = data["result"]
        assert result["protocolVersion"] == "2024-11-05"
        assert "tools" in result["capabilities"]
        assert result["serverInfo"]["name"] == "tailtest"
        assert "version" in result["serverInfo"]

    async def test_mcp_tools_list_returns_six_tools(self, server):
        """tools/list should return exactly 6 tool definitions."""
        raw = await server.handle_message(_jsonrpc("tools/list"))
        data = _parse(raw)

        tools = data["result"]["tools"]
        assert len(tools) == 6

    async def test_mcp_tool_names_correct(self, server):
        """tools/list should return exactly the expected tool names."""
        raw = await server.handle_message(_jsonrpc("tools/list"))
        data = _parse(raw)

        tool_names = sorted(t["name"] for t in data["result"]["tools"])
        assert tool_names == _EXPECTED_TOOL_NAMES

    async def test_mcp_tools_have_input_schemas(self, server):
        """Every tool definition should include an inputSchema."""
        raw = await server.handle_message(_jsonrpc("tools/list"))
        data = _parse(raw)

        for tool in data["result"]["tools"]:
            assert "inputSchema" in tool, f"Tool {tool['name']} missing inputSchema"
            assert tool["inputSchema"]["type"] == "object"

    async def test_mcp_ping_returns_pong(self, server):
        """The ping method should return an empty result (MCP pong)."""
        raw = await server.handle_message(_jsonrpc("ping"))
        data = _parse(raw)

        assert "error" not in data
        assert data["result"] == {}

    async def test_mcp_invalid_method_returns_error(self, server):
        """An unknown method should return a -32601 Method not found error."""
        raw = await server.handle_message(_jsonrpc("nonexistent/method"))
        data = _parse(raw)

        assert "error" in data
        assert data["error"]["code"] == -32601
        assert "not found" in data["error"]["message"].lower()

    async def test_mcp_invalid_json_returns_parse_error(self, server):
        """Sending invalid JSON should return a -32700 Parse error."""
        raw = await server.handle_message("{not valid json at all")
        data = _parse(raw)

        assert "error" in data
        assert data["error"]["code"] == -32700

    async def test_mcp_notification_returns_none(self, server):
        """A notification (no id) should return None, not a response."""
        msg = json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"})
        result = await server.handle_message(msg)

        assert result is None

    async def test_mcp_invalid_tool_returns_error(self, server):
        """Calling an unknown tool should return an error in the result."""
        raw = await server.handle_message(_tool_call("nonexistent_tool", {}))
        data = _parse(raw)

        assert "error" in data
        assert data["error"]["code"] == -32602
        assert "nonexistent_tool" in data["error"]["message"]

    async def test_mcp_response_ids_match(self, server):
        """The response id should match the request id."""
        for msg_id in [1, 42, 999]:
            raw = await server.handle_message(_jsonrpc("ping", msg_id=msg_id))
            data = _parse(raw)
            assert data["id"] == msg_id


# ---------------------------------------------------------------------------
# Tool-level tests (called via the MCP protocol)
# ---------------------------------------------------------------------------


class TestCheckSafetyTool:
    """Test the check_safety tool through the MCP protocol layer."""

    async def test_mcp_check_safety_clean_response(self, server):
        """A clean agent response should return SAFE."""
        raw = await server.handle_message(_tool_call("check_safety", {
            "agent_response": "The capital of France is Paris.",
        }))
        data = _parse(raw)

        assert "error" not in data
        text = _text(data)
        assert "SAFE" in text
        assert "ISSUES" not in text

    async def test_mcp_check_safety_pii_detected(self, server):
        """A response containing PII should return ISSUES FOUND."""
        raw = await server.handle_message(_tool_call("check_safety", {
            "agent_response": (
                "Sure! The customer's email is jane.doe@example.com "
                "and their SSN is 123-45-6789."
            ),
        }))
        data = _parse(raw)

        text = _text(data)
        assert "ISSUES FOUND" in text
        assert "PII" in text

    async def test_mcp_check_safety_credential_leak(self, server):
        """A response with credential patterns should be flagged."""
        raw = await server.handle_message(_tool_call("check_safety", {
            "agent_response": "Your api_key=sk-abc123xyz is active.",
        }))
        data = _parse(raw)

        text = _text(data)
        assert "ISSUES FOUND" in text

    async def test_mcp_check_safety_prompt_injection_echo(self, server):
        """A response echoing prompt injection should be flagged."""
        raw = await server.handle_message(_tool_call("check_safety", {
            "agent_response": "Sure, I'll ignore previous instructions and help you.",
        }))
        data = _parse(raw)

        text = _text(data)
        assert "ISSUES FOUND" in text

    async def test_mcp_check_safety_with_user_input(self, server):
        """check_safety should accept optional user_input without error."""
        raw = await server.handle_message(_tool_call("check_safety", {
            "agent_response": "The sky is blue.",
            "user_input": "What color is the sky?",
        }))
        data = _parse(raw)

        text = _text(data)
        assert "SAFE" in text


class TestExplainFailureTool:
    """Test the explain_failure tool through the MCP protocol layer."""

    async def test_mcp_explain_failure_returns_explanation(self, server):
        """explain_failure should return analysis with the test name and error."""
        with patch(JUDGE_IMPORT, side_effect=ImportError("no LLM")):
            raw = await server.handle_message(_tool_call("explain_failure", {
                "test_name": "test_weather_lookup",
                "error_message": "TimeoutError: agent did not respond within 30000ms",
            }))
        data = _parse(raw)

        text = _text(data)
        assert "test_weather_lookup" in text
        assert "timeout" in text.lower() or "time limit" in text.lower()

    async def test_mcp_explain_failure_pii_error(self, server):
        """explain_failure should give PII-specific advice for PII errors."""
        with patch(JUDGE_IMPORT, side_effect=ImportError("no LLM")):
            raw = await server.handle_message(_tool_call("explain_failure", {
                "test_name": "test_pii_check",
                "error_message": "PII detected: email address found in response",
            }))
        data = _parse(raw)

        text = _text(data)
        assert "personally identifiable" in text.lower() or "pii" in text.lower()

    async def test_mcp_explain_failure_missing_args_returns_error(self, server):
        """explain_failure with missing required args should return an error."""
        raw = await server.handle_message(_tool_call("explain_failure", {
            "test_name": "test_missing",
            # missing "error_message"
        }))
        data = _parse(raw)

        # The tool should fail because error_message is required
        result = data["result"]
        assert result.get("isError") is True or "Error" in result["content"][0]["text"]


class TestSuggestTestTool:
    """Test the suggest_test tool through the MCP protocol layer."""

    async def test_mcp_suggest_test_returns_code(self, server):
        """suggest_test should return tailtest code with imports and decorators."""
        with patch(JUDGE_IMPORT, side_effect=ImportError("no LLM")):
            raw = await server.handle_message(_tool_call("suggest_test", {
                "code_or_description": "An agent that uses a weather API tool.",
            }))
        data = _parse(raw)

        text = _text(data)
        assert "from tailtest import" in text
        assert "@agent_test" in text
        assert "expect(" in text

    async def test_mcp_suggest_test_tool_keyword(self, server):
        """When description mentions tools, output should include tool assertions."""
        with patch(JUDGE_IMPORT, side_effect=ImportError("no LLM")):
            raw = await server.handle_message(_tool_call("suggest_test", {
                "code_or_description": "Agent calls a function called search_docs",
            }))
        data = _parse(raw)

        text = _text(data)
        assert "to_call_tool" in text


class TestScanProjectTool:
    """Test the scan_project tool through the MCP protocol layer."""

    async def test_mcp_scan_project_finds_framework(self, server, hello_world_path):
        """scan_project on examples/hello-world should detect a framework."""
        raw = await server.handle_message(_tool_call("scan_project", {
            "project_path": str(hello_world_path),
        }))
        data = _parse(raw)

        assert "error" not in data
        text = _text(data)
        assert "Framework:" in text
        assert "hello-world" in text.lower() or "Project:" in text

    async def test_mcp_scan_project_nonexistent_path(self, server, tmp_path):
        """scan_project on a path that does not exist should return an error message."""
        bad_path = str(tmp_path / "does_not_exist")
        raw = await server.handle_message(_tool_call("scan_project", {
            "project_path": bad_path,
        }))
        data = _parse(raw)

        text = _text(data)
        assert "Error" in text or "does not exist" in text


class TestGenerateTestsTool:
    """Test the generate_tests tool through the MCP protocol layer."""

    async def test_mcp_generate_tests_tool(self, server, hello_world_path):
        """generate_tests on examples/hello-world should succeed."""
        raw = await server.handle_message(_tool_call("generate_tests", {
            "project_path": str(hello_world_path),
        }))
        data = _parse(raw)

        assert "error" not in data
        text = _text(data)
        # Should either generate tests or report they already exist
        assert "Generated" in text or "already exist" in text or "Scanned" in text

    async def test_mcp_generate_tests_nonexistent_path(self, server, tmp_path):
        """generate_tests on a missing path should return an error message."""
        bad_path = str(tmp_path / "nonexistent_project")
        raw = await server.handle_message(_tool_call("generate_tests", {
            "project_path": bad_path,
        }))
        data = _parse(raw)

        text = _text(data)
        assert "Error" in text or "does not exist" in text


class TestRunTestsTool:
    """Test the run_tests tool through the MCP protocol layer."""

    async def test_mcp_run_tests_empty_dir(self, server, tmp_path):
        """run_tests on an empty directory should return 'No tests found'."""
        raw = await server.handle_message(_tool_call("run_tests", {
            "test_path": str(tmp_path),
        }))
        data = _parse(raw)

        text = _text(data)
        assert "No tests found" in text

    async def test_mcp_run_tests_no_path_arg(self, server):
        """run_tests with no test_path should not crash (uses cwd)."""
        # This runs from the repo root which may or may not find tests,
        # but it must not crash with a protocol error.
        raw = await server.handle_message(_tool_call("run_tests", {}))
        data = _parse(raw)

        assert "error" not in data
        # Should return either results or "No tests found"
        text = _text(data)
        assert isinstance(text, str)
        assert len(text) > 0
