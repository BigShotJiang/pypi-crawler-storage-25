"""Dogfooding: tailtest tests its own LLM judge components.

These tests use tailtest's assertion system to verify that tailtest's
own LLM-powered features produce correct, safe, and consistent output.

Note: These tests require litellm (always present as a dependency).
When Ollama is not running, we fall back to mocked LLM responses so that
tests always pass in CI.  When an LLM *is* available, the tests perform
real evaluation for genuine dogfooding.
"""

from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from tailtest import expect
from tailtest.models import AgentResponse
from tailtest.mcp.server import TailtestMCPServer
from tailtest.production.failure_classifier import FailureClassifier, FailureType


# ---------------------------------------------------------------------------
# Helpers  -  mock LLM responses for CI (deterministic mode)
# ---------------------------------------------------------------------------

def _mock_completion(score: float, passed: bool, reason: str):
    """Build a mock litellm completion response."""
    content = json.dumps({"score": score, "passed": passed, "reason": reason})
    message = SimpleNamespace(content=content)
    choice = SimpleNamespace(message=message)
    usage = SimpleNamespace(prompt_tokens=80, completion_tokens=40, total_tokens=120)
    return SimpleNamespace(choices=[choice], usage=usage)


def _mock_classification(failure_type: str, confidence: float, evidence: str, suggestion: str):
    """Build a mock judge result for the failure classifier."""
    content = json.dumps({
        "failure_type": failure_type,
        "confidence": confidence,
        "evidence": evidence,
        "suggestion": suggestion,
    })
    # Also wrap as score/passed/reason so the judge parser doesn't choke
    message = SimpleNamespace(content=content)
    choice = SimpleNamespace(message=message)
    usage = SimpleNamespace(prompt_tokens=80, completion_tokens=60, total_tokens=140)
    return SimpleNamespace(choices=[choice], usage=usage)


# ---------------------------------------------------------------------------
# Test 1: MCP "suggest_test" tool produces valid Python code
# ---------------------------------------------------------------------------

class TestSuggestTestOutput:
    async def test_suggest_test_produces_valid_python(self, mcp_server, code_suggestion_input):
        """suggest_test should return syntactically valid Python with expect() calls."""
        result = await mcp_server._suggest_test({"code_or_description": code_suggestion_input})

        # Wrap the output as an AgentResponse so we can use tailtest's own expect()
        response = AgentResponse(
            content=result,
            metadata={"prompt": code_suggestion_input},
        )

        # The output must contain tailtest imports and expect() usage
        expect(response).to_contain("from tailtest import")
        expect(response).to_contain("expect(")
        expect(response).to_contain("@agent_test")

    async def test_suggest_test_includes_tool_test(self, mcp_server):
        """When input mentions tools, suggest_test should include tool assertions."""
        result = await mcp_server._suggest_test({
            "code_or_description": "Agent calls a function named search_docs to find documents."
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("to_call_tool")

    async def test_suggest_test_includes_pii_test(self, mcp_server):
        """When input mentions PII/privacy, suggest_test should include no_pii."""
        result = await mcp_server._suggest_test({
            "code_or_description": "Agent handles personal data and email addresses."
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("no_pii")

    async def test_suggest_test_no_pii_in_output(self, mcp_server, code_suggestion_input):
        """suggest_test output should not contain real PII."""
        result = await mcp_server._suggest_test({"code_or_description": code_suggestion_input})

        response = AgentResponse(content=result, metadata={})
        expect(response).no_pii()


# ---------------------------------------------------------------------------
# Test 2: MCP "explain_failure" tool produces helpful explanations
# ---------------------------------------------------------------------------

class TestExplainFailureOutput:
    async def test_explain_timeout_failure(self, mcp_server, failure_error_timeout):
        """explain_failure should give relevant advice for timeout errors."""
        result = await mcp_server._explain_failure(failure_error_timeout)

        response = AgentResponse(
            content=result,
            metadata={"prompt": "Explain this test failure"},
        )

        # Should mention the test name and contain timeout-related guidance
        expect(response).to_contain("test_weather_lookup")
        expect(response).to_contain("timeout", case_insensitive=True)
        expect(response).to_contain("Suggested fix", case_insensitive=True)

    async def test_explain_pii_failure(self, mcp_server, failure_error_pii):
        """explain_failure should give relevant advice for PII failures."""
        result = await mcp_server._explain_failure(failure_error_pii)

        response = AgentResponse(
            content=result,
            metadata={"prompt": "Explain this test failure"},
        )

        expect(response).to_contain("PII", case_insensitive=True)
        expect(response).to_contain("no_pii")

    async def test_explain_failure_is_relevant_to_error(self, mcp_server):
        """explain_failure output should reference the actual error message."""
        args = {
            "test_name": "test_order_lookup",
            "error_message": "Expected response to contain 'shipped' but got 'pending'",
        }
        result = await mcp_server._explain_failure(args)

        response = AgentResponse(content=result, metadata={})

        # Must reference the test and the content mismatch
        expect(response).to_contain("test_order_lookup")
        expect(response).to_match(r"(?i)(contain|expected)")

    async def test_explain_failure_no_pii(self, mcp_server, failure_error_timeout):
        """explain_failure output should not contain real PII."""
        result = await mcp_server._explain_failure(failure_error_timeout)

        response = AgentResponse(content=result, metadata={})
        expect(response).no_pii()


# ---------------------------------------------------------------------------
# Test 3: MCP "check_safety" tool correctly identifies PII
# ---------------------------------------------------------------------------

class TestCheckSafetyTool:
    async def test_check_safety_detects_pii(self, mcp_server):
        """check_safety should flag a response containing an email address."""
        result = await mcp_server._check_safety({
            "agent_response": "Your email is test@example.com and phone is 555-123-4567.",
            "user_input": "What is my contact info?",
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("ISSUES FOUND")
        expect(response).to_contain("PII")

    async def test_check_safety_passes_clean(self, mcp_server):
        """check_safety should return SAFE for a clean response."""
        result = await mcp_server._check_safety({
            "agent_response": "The weather today is sunny with a high of 72F.",
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("SAFE")

    async def test_check_safety_detects_credential_leak(self, mcp_server):
        """check_safety should flag credential patterns."""
        result = await mcp_server._check_safety({
            "agent_response": "Your password is: hunter2 and api_key=sk-abc123xyz",
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("ISSUES FOUND")

    async def test_check_safety_no_hallucinated_issues(self, mcp_server):
        """check_safety should not flag issues in a perfectly clean response."""
        result = await mcp_server._check_safety({
            "agent_response": (
                "Python is a high-level programming language created by "
                "Guido van Rossum and first released in 1991."
            ),
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("SAFE")
        expect(response).not_to_contain("ISSUES FOUND")


# ---------------------------------------------------------------------------
# Test 4: Failure classifier correctly classifies a hallucination (mocked)
# ---------------------------------------------------------------------------

class TestFailureClassifierHallucination:
    async def test_classifier_detects_hallucination(self, hallucination_response):
        """FailureClassifier should classify fabricated facts as hallucination.

        Uses a mocked LLM judge since we cannot guarantee Ollama is running.
        """
        from tailtest.config.schema import JudgeConfig

        classifier = FailureClassifier(judge_config=JudgeConfig(model="test-model"))

        # The hallucination response has no PII, loops, or cost/latency issues,
        # so it will fall through to the LLM judge.  Mock it.
        mock_resp = _mock_classification(
            failure_type="hallucination",
            confidence=0.92,
            evidence="Response claims Python was invented in 1642 by Newton, which is fabricated.",
            suggestion="Add a faithful_to() assertion with grounding context.",
        )

        with patch("litellm.acompletion", new_callable=AsyncMock, return_value=mock_resp):
            with patch("litellm.completion_cost", return_value=0.0):
                result = await classifier.classify(
                    hallucination_response,
                    user_input="Who created Python?",
                )

        assert result.failure_type == FailureType.HALLUCINATION
        assert result.confidence > 0.8

        # Use tailtest's own expect() to verify the evidence is relevant
        evidence_response = AgentResponse(content=result.evidence, metadata={})
        expect(evidence_response).to_match(r"(?i)(fabricat|invent|newton|1642)")


# ---------------------------------------------------------------------------
# Test 5: Failure classifier correctly classifies a PII leak
# ---------------------------------------------------------------------------

class TestFailureClassifierPII:
    async def test_classifier_detects_pii_deterministically(self, unsafe_pii_response):
        """FailureClassifier should catch PII via deterministic checks (no LLM needed)."""
        classifier = FailureClassifier()
        result = await classifier.classify(unsafe_pii_response)

        assert result.failure_type == FailureType.PII_LEAK
        assert result.confidence == 1.0

        # The suggestion should reference the no_pii() assertion
        suggestion_response = AgentResponse(content=result.suggestion, metadata={})
        expect(suggestion_response).to_contain("no_pii")


# ---------------------------------------------------------------------------
# Test 6: suggest_test output does not contain PII
# ---------------------------------------------------------------------------

class TestSuggestTestNoPII:
    async def test_suggest_test_various_inputs_no_pii(self, mcp_server):
        """suggest_test should never include real PII, regardless of input."""
        inputs = [
            "Agent processes customer orders and returns shipping info",
            "Agent handles API calls to a payment system",
            "Agent answers questions about company policies",
        ]

        for desc in inputs:
            result = await mcp_server._suggest_test({"code_or_description": desc})
            response = AgentResponse(content=result, metadata={})
            expect(response).no_pii()


# ---------------------------------------------------------------------------
# Test 7: explain_failure output is relevant to the error
# ---------------------------------------------------------------------------

class TestExplainFailureRelevance:
    async def test_explain_safety_failure(self, mcp_server):
        """explain_failure should give safety-specific advice for safety errors."""
        result = await mcp_server._explain_failure({
            "test_name": "test_refuse_harmful",
            "error_message": "Safety check FAILED: response contains harmful content",
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("safety", case_insensitive=True)
        expect(response).to_match(r"(?i)(safe|harm|guardrail|filter)")

    async def test_explain_tool_failure(self, mcp_server):
        """explain_failure should give tool-specific advice for tool call errors."""
        result = await mcp_server._explain_failure({
            "test_name": "test_search_tool",
            "error_message": "Expected tool call 'search' but agent did not invoke any tool",
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("tool", case_insensitive=True)

    async def test_explain_cost_failure(self, mcp_server):
        """explain_failure should give cost-specific advice for cost errors."""
        result = await mcp_server._explain_failure({
            "test_name": "test_budget",
            "error_message": "Cost $2.50 exceeds limit. cost_under assertion failed.",
        })

        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("cost", case_insensitive=True)


# ---------------------------------------------------------------------------
# Test 8: check_safety does not hallucinate issues that don't exist
# ---------------------------------------------------------------------------

class TestCheckSafetyNoFalsePositives:
    async def test_normal_text_is_safe(self, mcp_server):
        """Ordinary factual text should not trigger any safety flags."""
        clean_texts = [
            "The capital of France is Paris.",
            "To install Python, run: pip install python3",
            "The meeting has been scheduled for 3pm tomorrow.",
            "Here are the quarterly revenue figures for 2025.",
        ]

        for text in clean_texts:
            result = await mcp_server._check_safety({"agent_response": text})
            response = AgentResponse(content=result, metadata={})
            expect(response).to_contain("SAFE")
            expect(response).not_to_contain("ISSUES FOUND")

    async def test_code_snippets_are_safe(self, mcp_server):
        """Code examples should not be falsely flagged."""
        code_text = (
            "Here is how to read a file in Python:\n"
            "```python\n"
            "with open('data.txt', 'r') as f:\n"
            "    content = f.read()\n"
            "```"
        )
        result = await mcp_server._check_safety({"agent_response": code_text})
        response = AgentResponse(content=result, metadata={})
        expect(response).to_contain("SAFE")
