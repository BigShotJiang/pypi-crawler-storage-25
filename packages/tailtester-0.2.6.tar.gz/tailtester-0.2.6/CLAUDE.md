# CLAUDE.md

## Project Overview

This is an open-source AI agent testing tool -- "pytest for AI agents." Name: **tailtest** (PyPI: **tailtester**). It auto-generates and runs tests for any AI agent from any framework, with any model, at any stage of development. CLI-first, framework-agnostic, vendor-neutral. Runs fully local with zero telemetry. Apache 2.0 license.

## Technical Stack

- **Language:** Python 3.11+
- **CLI:** Click
- **Models:** Pydantic v2
- **HTTP:** httpx (async)
- **LLM Abstraction:** litellm (never use OpenAI SDK directly)
- **File Watching:** watchfiles
- **Testing:** pytest
- **Lint/Format:** ruff
- **Type Checking:** pyright

## Architecture

Four positions spanning the development lifecycle:

- **Position 0  -  Context Collector:** Observes dev process, auto-generates tests
- **Position 1  -  Test Runner:** Runs deterministic + LLM-judged + red-team tests in CI/CD
- **Position 2  -  Dev Watcher:** Watches for regressions during development (file watcher)
- **Position 3  -  Production Guard:** Continuous validation in production

Pipeline: Context Engine → Test Generator → Assertion Engine → Test Runner → Reporter. The Red-Team Engine runs independently or alongside functional tests. The MCP Server (JSON-RPC 2.0 over stdio, 6 tools) exposes tailtest capabilities to IDEs like Cursor.

Enterprise governance layer spans all positions (audit trails, RBAC, compliance).

## Current Stats (as of April 5, 2026)

- **Phases 1-9 complete**, Phase 10 in progress
- ~165 Python files, ~27,000 LOC
- 1097 internal tests passing in 28s
- 20 CLI commands, 26 assertion types, 6 framework detectors
- 64 red-team attacks, 20 OWASP checks, 6 MCP server tools (LLM-powered)
- 6 report formats, 5 example projects

## Project Structure

```
src/tailtest/
  cli/          # Click commands (20 commands: init, scan, run, generate, redteam, watch, guard, ingest, record, replay, report, doctor, drift, status, suggest, predict, optimize, mcp-serve, wrap, interview)
  context/      # Context engine (code analysis, trace ingestion, process wrapper, interviewer)
  generator/    # Test generation (deterministic + LLM-powered)
  assertions/   # Assertion engine (15 deterministic, 7 LLM-judge, 5 reliability, tier ordering)
  runner/       # Test execution, parallel runner, retry logic, YAML support
  intelligence/ # Three-layer intelligence engine (structural, LLM, user rules)
  maturity/     # Maturity engine (seedling, growing, mature) with calibration
  redteam/      # Red-team engine (64 attacks, 8 categories, OWASP compliance)
  production/   # Production monitoring loop
  mcp/          # MCP server (6 tools, JSON-RPC 2.0 over stdio, LLM-powered)
  reporting/    # Output formats (terminal, JSON, JUnit XML, HTML, compliance text/HTML)
  config/       # Configuration loading and defaults
  audit/        # Structured audit logging
```

## Coding Conventions

- Use Python 3.11+ features: `match` statements, `X | Y` type unions
- Pydantic v2 models for all data structures
- Async by default (`asyncio`)
- Type annotations on everything
- Ruff for linting and formatting
- No docstrings on obvious methods; yes on public API
- Tests in `tests/` mirroring `src/` structure

## Key Design Principles

- **Deterministic assertions first, LLM-judge second**  -  80% of useful assertions don't need an LLM
- **Zero-config to first value**  -  `pip install tailtester && tailtest scan . && tailtest run` in under 3 minutes
- **Grade outcomes, not paths**  -  test WHAT the agent produced, not HOW
- **Local-first, zero telemetry**  -  no data leaves the machine, ever
- **Framework-agnostic**  -  detector+adapter pattern for any agent framework
- **Reliability over accuracy**  -  test pass rates, not average scores

## Important Files

- `docs/guide/quickstart.md`  -  Getting started guide
- `docs/guide/writing-tests.md`  -  How to write tests
- `docs/guide/assertions-reference.md`  -  Complete assertion reference
- `examples/`  -  Example projects for different frameworks

## What NOT To Do

- Do not add telemetry or analytics of any kind
- Do not create cloud dependencies for core features
- Do not lock to any specific LLM provider or agent framework
- Do not use OpenAI SDK directly  -  always go through litellm
- Do not add unnecessary dependencies
- Do not mark work done without wiring it into the actual system (stubs are not done)
