# MCP Server

The tailtest MCP server exposes all core capabilities to MCP-compatible IDEs over the Model Context Protocol. This lets tools like Cursor and Claude Code generate tests, run them, check safety, and scan projects without leaving the editor.

The server communicates over stdio using JSON-RPC 2.0. It reads requests from stdin and writes responses to stdout. All logging goes to stderr so the protocol channel stays clean.

## Starting the server

```bash
tailtest mcp-serve
```

This starts the server in stdio mode. You do not call this directly - your IDE launches it as a subprocess using the configuration below.

## Configuring in Cursor

Create or edit `.cursor/mcp.json` in your project root (or `~/.cursor/mcp.json` for global config):

```json
{
  "mcpServers": {
    "tailtest": {
      "command": "tailtest",
      "args": ["mcp-serve"]
    }
  }
}
```

An example config file is also available at `examples/mcp-config.json` in the tailtest repository.

After saving, restart Cursor. The tailtest tools will appear in the MCP tools panel.

## Configuring in Claude Code

Add tailtest to your Claude Code MCP configuration. Run:

```bash
claude mcp add tailtest tailtest mcp-serve
```

Or manually edit your `.claude/settings.json`:

```json
{
  "mcpServers": {
    "tailtest": {
      "command": "tailtest",
      "args": ["mcp-serve"]
    }
  }
}
```

After adding, Claude Code will have access to all six tailtest tools.

## Tools

The MCP server exposes six tools. Each tool accepts a JSON object as input and returns a text result.

---

### `generate_tests`

Scan an AI agent project and auto-generate a test suite.

**Input schema:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `project_path` | `string` | yes | Absolute or relative path to the project directory |

**Example request:**

```json
{
  "name": "generate_tests",
  "arguments": {
    "project_path": "/home/user/my-agent"
  }
}
```

**Example output:**

```
Generated 3 test(s) in .tailtest/tests/auto/
Framework: langchain
Files:
  - test_tools.py
  - test_safety.py
  - test_prompts.py
```

---

### `run_tests`

Discover and run tailtest tests, returning pass/fail results with details.

**Input schema:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `test_path` | `string` | no | Path to a test file or directory. Defaults to the current working directory |

**Example request:**

```json
{
  "name": "run_tests",
  "arguments": {
    "test_path": ".tailtest/tests/"
  }
}
```

**Example output:**

```
Results: 8/10 passed, 2 failed, 0 skipped
Duration: 4523ms
Cost: $0.0312
Reliability: 80%

  [PASS] test_greeting (120ms)
  [PASS] test_tool_call (340ms)
  [FAIL] test_pii_check (89ms)
         Response contained PII: email address detected
  [FAIL] test_cost_budget (210ms)
         Cost $0.15 exceeded limit $0.10
```

---

### `check_safety`

Quick safety check on an agent response. Runs PII detection and basic safety assertions.

**Input schema:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `agent_response` | `string` | yes | The agent's response text to check |
| `user_input` | `string` | no | Original user input for context |

**Example request:**

```json
{
  "name": "check_safety",
  "arguments": {
    "agent_response": "Your account email is john@example.com and your balance is $500.",
    "user_input": "What is my account balance?"
  }
}
```

**Example output:**

```
ISSUES FOUND:
  - PII: email address detected in response
```

When no issues are found, returns: `SAFE -- No issues detected.`

---

### `explain_failure`

Explain why a tailtest test failed and suggest how to fix it.

**Input schema:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `test_name` | `string` | yes | Name of the failing test |
| `error_message` | `string` | yes | The error or assertion message from the failure |

**Example request:**

```json
{
  "name": "explain_failure",
  "arguments": {
    "test_name": "test_order_lookup",
    "error_message": "Expected tool call 'lookup_order' but no tools were called"
  }
}
```

**Example output:**

```
Test: test_order_lookup
Error: Expected tool call 'lookup_order' but no tools were called

Analysis:
  The agent did not call the expected tool (or called the wrong one).

Possible causes:
  1. The agent's tool-calling logic has changed.
  2. The input did not trigger the expected tool path.
  3. The tool definition was renamed or removed.

Suggested fixes:
  - Verify the tool name matches exactly.
  - Check the agent's system prompt for tool-routing instructions.
  - Use tool_called_with() to also verify arguments.
```

If an LLM judge is available, the explanation will include deeper LLM-powered analysis.

---

### `suggest_test`

Given a code diff or natural-language description, suggest tailtest tests using the expect() API.

**Input schema:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `code_or_description` | `string` | yes | A code diff, code snippet, or natural-language description of agent behaviour to write tests for |

**Example request:**

```json
{
  "name": "suggest_test",
  "arguments": {
    "code_or_description": "The agent has a tool called get_weather that takes a city name and returns the current temperature."
  }
}
```

**Example output:**

```python
# Suggested tailtest tests

from tailtest import agent_test, expect, Agent

@agent_test("should respond appropriately")
async def test_basic_response():
    agent = Agent(url="http://localhost:8000/chat")
    response = await agent.chat("Hello")
    expect(response).to_contain("hello").safe().no_pii()

@agent_test("should call the correct tool")
async def test_tool_call():
    agent = Agent(url="http://localhost:8000/chat")
    response = await agent.chat("Look up the weather")
    expect(response).to_call_tool("get_weather")
    expect(response).steps_under(5)
```

If an LLM judge is available, the suggestions will be tailored to the specific code or description.

---

### `scan_project`

Scan a project directory and return a context summary: detected framework, tools, prompts, models, and agents.

**Input schema:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `project_path` | `string` | yes | Absolute or relative path to the project directory |

**Example request:**

```json
{
  "name": "scan_project",
  "arguments": {
    "project_path": "."
  }
}
```

**Example output:**

```
Project: my-agent
Framework: langchain
Models: gpt-4o, gpt-3.5-turbo
Tools: 3
  - search_web - Search the web for information
  - lookup_order - Look up an order by ID
  - send_email - Send an email to a customer
Prompts: 2
  - [system] You are a helpful customer support agent...
  - [user] The customer asked: {{question}}...
Agents: 1
  - support-bot (langchain)
Environment variables: OPENAI_API_KEY, DATABASE_URL
Key dependencies: langchain, openai, httpx

Context saved to .tailtest/context/scan.json
```

## Protocol details

The MCP server implements JSON-RPC 2.0 over stdio. The supported methods are:

| Method | Description |
|--------|-------------|
| `initialize` | Handshake - returns server info and capabilities |
| `tools/list` | Returns the list of available tools and their input schemas |
| `tools/call` | Invokes a tool by name with the given arguments |
| `ping` | Health check - returns an empty result |

Notifications (messages without an `id` field) are acknowledged silently. The `notifications/initialized` notification from the client is logged but produces no response.

## Troubleshooting

**Server does not start**

Make sure tailtest is installed and on your PATH:

```bash
which tailtest
tailtest --version
```

If you installed with `pip install --user`, ensure `~/.local/bin` is in your PATH.

**IDE does not show tailtest tools**

1. Verify the MCP config JSON is valid (no trailing commas, correct structure).
2. Restart the IDE after adding the configuration.
3. Check the IDE's MCP logs for connection errors.
4. Test the server manually: `echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | tailtest mcp-serve`

**Tools return errors**

- `generate_tests` and `scan_project` require the `project_path` to exist on disk.
- `run_tests` requires tests to be generated first. Run `tailtest scan . && tailtest generate` before using `run_tests`.
- `check_safety` needs at least the `agent_response` parameter.
- `explain_failure` and `suggest_test` work with or without an LLM. If no LLM is configured, they fall back to keyword-based analysis.

**Logs and debugging**

All server logs go to stderr. To see them while testing:

```bash
tailtest mcp-serve 2>mcp-debug.log
```

Then inspect `mcp-debug.log` for errors and request/response traces.
