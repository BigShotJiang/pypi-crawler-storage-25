# CLI Reference

Complete reference for every `tailtest` command. Run `tailtest --help` or `tailtest <command> --help` for built-in help.

---

## Setup

### `tailtest init`

Initialize a new tailtest project in the current directory. Creates the `.tailtest/` directory structure with configuration files.

By default runs an interactive wizard that asks where your agent runs and configures accordingly. Use quick-mode flags to skip the wizard.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--framework` | choice | auto | AI framework: langchain, crewai, openai, anthropic, pydantic-ai |
| `--no-wizard` | flag | false | Skip the interactive wizard and use legacy init |
| `--ssh` | string | - | Quick mode: SSH target (user@host) |
| `--key` | string | - | Quick mode: SSH key path (used with --ssh) |
| `--http` | string | - | Quick mode: HTTP agent URL |
| `--python` | string | - | Quick mode: Python function path (module:function) |
| `--cli` | string | - | Quick mode: CLI command |

```bash
tailtest init
tailtest init --framework langchain
tailtest init --http http://localhost:8000/chat
tailtest init --python myagent:run
tailtest init --ssh user@host --key ~/.ssh/id_rsa
tailtest init --no-wizard --framework openai
```

### `tailtest doctor`

Check system health, dependencies, and configuration. Verifies Python version, Ollama availability, project initialization, and all required Python packages.

No options.

```bash
tailtest doctor
```

### `tailtest interview`

Ask questions about your agent to generate tests. Use this when `tailtest scan` cannot detect your agent's architecture from code. Six questions about what your agent does, what tools it has, what it should never do, and how users interact with it.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--path` | path | . | Project directory |
| `--generate / --no-generate` | flag | true | Run test generation after the interview |

```bash
tailtest interview
tailtest interview --path /path/to/project
tailtest interview --no-generate
```

---

## Context and scanning

### `tailtest scan [PATH]`

Scan an agent project to build context for test generation. Discovers framework, tools, prompts, agents, models, and dependencies.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--deep` | flag | false | Include git history analysis |
| `--understand` | flag | false | Run LLM understanding on scanned files (Layer 2 intelligence) |
| `--output` | choice | text | Output format: json, text |
| `--ssh` | string | - | Remote scan via SSH (user@host:/path/to/project) |
| `--no-interactive` | flag | false | Disable interactive prompts |

```bash
tailtest scan .
tailtest scan /path/to/project
tailtest scan . --deep
tailtest scan . --understand
tailtest scan . --output json
tailtest scan --ssh user@host:/path/to/project
```

### `tailtest watch [PATH]`

Watch a project directory for file changes and update context continuously. Triggers incremental re-scans when agent code, prompts, or tool definitions change. Runs until Ctrl+C.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--no-generate` | flag | false | Disable automatic test generation on file changes |

```bash
tailtest watch .
tailtest watch /path/to/project
tailtest watch . --no-generate
```

### `tailtest ingest`

Ingest agent traces from observability platforms. Connects to OpenTelemetry, Langfuse, LangSmith, or reads from JSON.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--otlp` | flag | false | Start an OpenTelemetry OTLP/HTTP receiver |
| `--otlp-port` | int | 4318 | Port for the OTLP receiver |
| `--langfuse-url` | string | - | Langfuse instance URL to pull traces from |
| `--langsmith` | flag | false | Pull traces from LangSmith |
| `--json` | path | - | Ingest traces from a JSON file |
| `--save / --no-save` | flag | true | Persist ingested traces to .tailtest/traces/ |
| `--storage-dir` | path | - | Directory to store traces |

```bash
tailtest ingest --otlp
tailtest ingest --otlp --otlp-port 9411
tailtest ingest --langfuse-url https://cloud.langfuse.com
tailtest ingest --langsmith
tailtest ingest --json traces.json
```

### `tailtest wrap COMMAND`

Wrap a development tool and auto-test what it builds. Launches COMMAND as a child process while watching the project for file changes. When the command exits, tailtest scans, generates tests, runs them, and prints a summary.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--live` | flag | false | Continuous companion mode: run tests incrementally during the session (debounced 5s) instead of only on exit |
| `--fix` | flag | false | Load failures from the previous session, write fix context, and compare results on exit |
| `--understand` | flag | false | Use LLM to understand code changes after the session |
| `--no-run` | flag | false | Generate tests but do not run them |
| `--path` | path | . | Project directory to watch |

```bash
tailtest wrap "claude code"                # bookend mode (default) - tests on exit only
tailtest wrap "cursor" --live              # continuous - tests incrementally during session
tailtest wrap "claude code" --fix          # load previous failures, compare on exit
tailtest wrap "aider" --understand
```

---

## Test generation

### `tailtest generate`

Generate tests from scanned project context. Uses context gathered by `tailtest scan` to create test cases for tools, safety boundaries, and prompt handling.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--only` | choice | all | Generate only a specific category: safety, tools, prompts, all |
| `--regenerate` | flag | false | Overwrite existing auto-generated tests |
| `--project-dir` | path | . | Project root directory |
| `--no-interactive` | flag | false | Disable interactive prompts |

```bash
tailtest generate
tailtest generate --only safety
tailtest generate --only tools
tailtest generate --regenerate
tailtest generate --project-dir /path/to/project
```

---

## Testing

### `tailtest run [PATH]`

Run agent tests. PATH is an optional test file or directory. If omitted, runs all tests found under .tailtest/tests/ and any test files in the project.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--ci` | flag | false | CI mode: strict assertions, JUnit XML output |
| `--parallel, -p` | int | 1 | Number of concurrent test workers |
| `--replay` | flag | false | Use recorded LLM responses instead of live calls |
| `--reliability, -r` | int | 1 | Run each test N times for reliability scoring |
| `--cost-limit` | float | - | Abort if total LLM cost exceeds this amount (USD) |
| `--tag, -t` | string | - | Run only tests matching this tag (repeatable) |
| `--model` | string | - | Override the agent model for this run |
| `--judge` | string | - | Override the LLM judge model |
| `--target` | string | - | Named target from tailtest.yaml targets |
| `--no-interactive` | flag | false | Disable interactive prompts |

```bash
tailtest run
tailtest run tests/test_agent.py
tailtest run --ci
tailtest run --parallel 4
tailtest run --tag smoke
tailtest run --tag safety --tag tools
tailtest run --reliability 5
tailtest run --cost-limit 1.00
tailtest run --model gpt-4o
tailtest run --replay
```

### `tailtest record [PATH]`

Run tests while recording all agent responses for later replay. Recordings are saved to `.tailtest/recordings/<session>/`.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--session` | string | timestamp | Custom name for this recording session |
| `--tag, -t` | string | - | Run only tests matching this tag (repeatable) |
| `--parallel, -p` | int | 1 | Number of concurrent test workers |
| `--no-interactive` | flag | false | Disable interactive prompts |

```bash
tailtest record
tailtest record tests/test_agent.py
tailtest record --session baseline-v1
tailtest record --tag smoke
```

### `tailtest replay [PATH]`

Replay recorded LLM responses for deterministic test runs. Uses previously recorded responses from `tailtest record` to run tests without live API calls. Useful for offline testing, CI without agent access, and deterministic runs.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--session` | string | most recent | Specific recording session to replay |
| `--tag, -t` | string | - | Run only tests matching this tag (repeatable) |
| `--parallel, -p` | int | 1 | Number of concurrent test workers |
| `--ci` | flag | false | CI mode: strict assertions, JUnit XML output |
| `--no-interactive` | flag | false | Disable interactive prompts |

```bash
tailtest replay
tailtest replay tests/test_agent.py
tailtest replay --session 2026-03-31T12-00-00
tailtest replay --ci
```

### `tailtest redteam`

Run adversarial red-team tests against your agent. Tests for prompt injection, jailbreaks, data exfiltration, tool misuse, and other attack vectors.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--quick` | flag | false | Quick scan (around 5 minutes) with core attack vectors |
| `--thorough` | flag | false | Thorough scan (30+ minutes) with exhaustive coverage |
| `--owasp` | flag | false | Run OWASP LLM Top 10 and Agentic Top 10 compliance checks |
| `--custom` | path | - | Path to a custom attack definitions YAML file |
| `--report` | choice | text | Report format: html, json, text |
| `--category` | string | - | Only run attacks from specific categories (repeatable) |
| `--agent-url` | string | - | HTTP endpoint of the agent to test |
| `--no-interactive` | flag | false | Disable interactive prompts |

```bash
tailtest redteam --quick
tailtest redteam
tailtest redteam --thorough --owasp
tailtest redteam --agent-url http://localhost:8000/chat
tailtest redteam --category prompt_injection --category jailbreak
tailtest redteam --report html
```

---

## Analysis

### `tailtest status`

Show maturity engine status. Displays the current maturity level, calibrated thresholds, identified failure patterns, and flaky tests.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--project-dir` | path | . | Project directory |

```bash
tailtest status
tailtest status --project-dir /path/to/project
```

### `tailtest suggest`

Suggest new tests based on observed failure patterns. Analyses accumulated data from the maturity engine and suggests targeted tests. Requires Growing maturity level (10+ runs).

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--project-dir` | path | . | Project directory |
| `--apply` | flag | false | Generate a test file from suggestions |
| `--output` | path | - | Output file path for generated tests |
| `--max` | int | 10 | Maximum number of suggestions to show |

```bash
tailtest suggest
tailtest suggest --apply
tailtest suggest --apply --output tests/test_regressions.py
```

### `tailtest predict`

Predict which tests will break from uncommitted changes. Analyses a git diff against historical test failure data. Requires Mature maturity level (50+ runs).

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--diff-file` | path | - | Path to a diff file (instead of git diff) |
| `--project-dir` | path | . | Project root directory |

```bash
tailtest predict
tailtest predict --diff-file changes.patch
```

### `tailtest optimize`

Show test suite optimization suggestions. Analyses historical test profiles to find redundant tests, coverage gaps, efficiency opportunities, and flaky tests. Requires Mature maturity level (50+ runs).

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--project-dir` | path | . | Project root directory |
| `--json` | flag | false | Output suggestions as JSON |

```bash
tailtest optimize
tailtest optimize --json
```

### `tailtest drift`

Detect quality drift in agent responses. Set a baseline from a previous run, then compare current traces against it to detect regressions.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--baseline` | string | - | Set baseline from a run ID |
| `--check` | flag | false | Compare current traces against the stored baseline |
| `--alert` | choice | - | Alert channel: slack, json, terminal |
| `--webhook` | string | - | Webhook URL for alert delivery (used with --alert slack) |
| `--traces-dir` | path | - | Directory containing trace files to check |
| `--baseline-path` | path | - | Path to baseline JSON file |

```bash
tailtest drift --baseline run-123
tailtest drift --check
tailtest drift --check --alert slack --webhook https://hooks.slack.com/...
tailtest drift --check --alert json
```

---

## Reporting

### `tailtest report`

Generate a report from test results. Summarizes pass/fail rates, reliability scores, cost breakdown, and optionally maps results to compliance frameworks.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--format` | choice | terminal | Report format: html, json, text |
| `--trend` | flag | false | Show trend from last 30 runs |
| `--daily` | flag | false | Summary of last 24 hours |
| `--weekly` | flag | false | Summary of last 7 days |
| `--open` | flag | false | Open HTML report in browser |
| `--compliance` | choice | - | Include compliance data: eu-ai-act, nist, soc2 |
| `--output, -o` | path | - | Output file path |
| `--no-interactive` | flag | false | Disable interactive prompts |

```bash
tailtest report
tailtest report --trend
tailtest report --daily
tailtest report --weekly
tailtest report --format html --open
tailtest report --format json -o report.json
tailtest report --compliance eu-ai-act
```

---

## Production monitoring

### `tailtest guard`

Start a production validation proxy. Intercepts agent requests and responses in real-time, running validation checks (no PII, no loops, cost/latency limits) before forwarding.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--port` | int | 8080 | Port to run the guard proxy on |
| `--upstream` | string | required | Upstream URL to proxy requests to |
| `--block / --no-block` | flag | false | Block responses that fail validation (return 422) |
| `--max-cost` | float | 1.0 | Maximum cost per request (USD) |
| `--max-latency` | int | 30000 | Maximum latency per request (ms) |
| `--audit-dir` | path | - | Directory for audit logs |

```bash
tailtest guard --upstream http://localhost:3000
tailtest guard --port 9090 --upstream http://agent:8000 --block
tailtest guard --upstream http://localhost:3000 --max-cost 0.50
```

---

## IDE integration

### `tailtest mcp-serve`

Start the MCP server on stdio for IDE integration. Exposes tailtest capabilities to MCP-compatible IDEs like Cursor and Claude Code. See [MCP Server](mcp-server.md) for full documentation.

No options.

```bash
tailtest mcp-serve
```

Configure in your IDE:

```json
{
  "mcpServers": {
    "tailtest": {
      "command": "tailtest",
      "args": ["mcp-serve"]
    }
  }
}
```
