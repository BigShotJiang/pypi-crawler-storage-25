"""tailtest wrap -- wrap a development tool and auto-test what it builds."""

from __future__ import annotations

import asyncio
import signal
from pathlib import Path

import click
from rich.console import Console

console = Console()


def _write_fix_context(
    reports_dir: Path,
    previous_report,
) -> Path:
    """Write a fix-context.md file from the previous session report.

    Returns the path to the fix-context file.
    """
    tailtest_dir = reports_dir.parent
    fix_path = tailtest_dir / "fix-context.md"

    lines = [
        "# Fix Context",
        "",
        f"Previous session: {previous_report.command}",
        f"Exit code: {previous_report.exit_code}",
        f"Duration: {previous_report.duration_seconds:.0f}s",
        "",
        "## Failures",
        "",
    ]

    if previous_report.test_failures:
        for failure in previous_report.test_failures:
            lines.append(f"### {failure.name}")
            lines.append("")
            lines.append(f"**Error:** {failure.message}")
            lines.append("")
            lines.append("**Suggested fix:** Review the agent behavior that causes this failure.")
            lines.append("")
    else:
        lines.append("No test failures recorded in previous session.")
        lines.append("")

    lines.append("## Files Changed")
    lines.append("")
    if previous_report.files_created:
        lines.append("**Created:**")
        for f in previous_report.files_created:
            lines.append(f"- {f}")
        lines.append("")
    if previous_report.files_modified:
        lines.append("**Modified:**")
        for f in previous_report.files_modified:
            lines.append(f"- {f}")
        lines.append("")

    fix_path.write_text("\n".join(lines), encoding="utf-8")
    return fix_path


@click.command("wrap")
@click.argument("command")
@click.option(
    "--understand",
    is_flag=True,
    default=False,
    help="Use LLM to understand code changes after the session.",
)
@click.option(
    "--no-run",
    is_flag=True,
    default=False,
    help="Generate tests but do not run them after the subprocess exits.",
)
@click.option(
    "--live",
    is_flag=True,
    default=False,
    help="Continuous companion mode: debounced incremental test runs during session.",
)
@click.option(
    "--fix",
    is_flag=True,
    default=False,
    help="Load previous session failures, write fix context, and compare results.",
)
@click.option(
    "--path",
    "project_path",
    default=".",
    type=click.Path(exists=True),
    help="Project directory to watch (defaults to current directory).",
)
def wrap_cmd(
    command: str,
    understand: bool,
    no_run: bool,
    live: bool,
    fix: bool,
    project_path: str,
) -> None:
    """Wrap a development tool and auto-test what it builds.

    Launches COMMAND as a child process while watching the project directory
    for file changes.  When the command exits, tailtest scans the project,
    generates tests, runs them, and prints a session summary.

    The wrapped command has full control of stdin/stdout -- tailtest only
    observes the filesystem.

    \b
    Modes:
      (default)  Bookend mode -- no output during session, full report on exit.
      --live     Continuous companion -- debounced incremental runs during session.
      --fix      Load previous failures, write fix context, compare on exit.

    \b
    Examples:
        tailtest wrap "claude code"
        tailtest wrap "cursor" --live
        tailtest wrap "aider" --understand
        tailtest wrap "make build" --no-run
        tailtest wrap "claude code" --fix
    """
    resolved = Path(project_path).resolve()

    from tailtest.context.sources.session import SessionTracker

    previous_report = None
    if fix:
        reports_dir = resolved / ".tailtest" / "reports"
        previous_report = SessionTracker.load_latest_report(reports_dir)
        if previous_report is None:
            console.print(
                "[yellow]No previous session report found in "
                f"{reports_dir}. Running without --fix.[/yellow]"
            )
        else:
            console.print(
                f"[dim]Loaded previous session: {previous_report.command}[/dim]"
            )
            prev_failed = previous_report.tests_failed
            console.print(
                f"[dim]Previous failures: {prev_failed}[/dim]"
            )
            # Write fix context
            fix_path = _write_fix_context(reports_dir, previous_report)
            console.print(
                f"[dim]Fix context written: {fix_path}[/dim]"
            )
            console.print()

    from tailtest.context.sources.wrapper import ProcessWrapper

    wrapper = ProcessWrapper(
        command=command,
        project_dir=resolved,
        understand=understand,
        no_run=no_run,
        live=live,
        console=console,
    )

    loop = asyncio.new_event_loop()

    # Handle Ctrl+C: cancel the main task so the wrapper can clean up
    # the child process and watcher gracefully.
    main_task = None

    def _handle_sigint() -> None:
        if main_task is not None and not main_task.done():
            main_task.cancel()

    try:
        loop.add_signal_handler(signal.SIGINT, _handle_sigint)
    except NotImplementedError:
        # signal handlers are not available on all platforms (e.g. Windows)
        pass

    try:
        main_task = loop.create_task(wrapper.run())
        result = loop.run_until_complete(main_task)

        # --fix comparison
        if fix and previous_report is not None and result is not None:
            _print_fix_comparison(previous_report, result)

    except asyncio.CancelledError:
        console.print("\n[bold]Session interrupted.[/bold]")
    except KeyboardInterrupt:
        console.print("\n[bold]Session interrupted.[/bold]")
    finally:
        loop.close()


def _print_fix_comparison(previous_report, current_result) -> None:
    """Print a before/after comparison when using --fix mode."""
    prev_failed = previous_report.tests_failed
    curr_failed = current_result.tests_failed

    console.print()
    console.print("[bold cyan]Fix Comparison[/bold cyan]")
    console.print("=" * 40)
    console.print(f"Previous: [red]{prev_failed} failures[/red]")
    console.print(f"Now:      [{'green' if curr_failed < prev_failed else 'red'}]{curr_failed} failures[/{'green' if curr_failed < prev_failed else 'red'}]")

    fixed = prev_failed - curr_failed
    if fixed > 0:
        console.print(f"Fixed:    [green]{fixed}[/green]")
    elif fixed < 0:
        console.print(f"New failures: [red]{abs(fixed)}[/red]")
    else:
        console.print("[dim]No change in failure count.[/dim]")
    console.print()
