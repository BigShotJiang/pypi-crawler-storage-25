"""tailtest record  -  run tests while recording LLM calls for deterministic replay."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import click
from rich.console import Console

from tailtest.cli.interactive import no_interactive_option

console = Console()


@click.command("record")
@click.argument("path", default=None, required=False, type=click.Path())
@click.option(
    "--session",
    type=str,
    default=None,
    help="Custom name for this recording session (default: timestamp).",
)
@click.option(
    "--tag",
    "-t",
    multiple=True,
    help="Run only tests matching this tag (repeatable).",
)
@click.option(
    "--parallel",
    "-p",
    type=int,
    default=1,
    show_default=True,
    help="Number of concurrent test workers.",
)
@no_interactive_option
def record_cmd(
    path: str | None,
    session: str | None,
    tag: tuple[str, ...],
    parallel: int,
    no_interactive: bool,
) -> None:
    """Record LLM calls during a test run for deterministic replay.

    Runs all tests at PATH (or the default test location) while capturing
    every agent request and response.  Recordings are saved to
    .tailtest/recordings/<session>/ and can be replayed later with
    'tailtest replay'.

    \b
    Examples:
      tailtest record                       Record all tests
      tailtest record tests/test_agent.py   Record specific tests
      tailtest record --session baseline    Name the session
    """
    from tailtest.config.loader import load_config
    from tailtest.runner.engine import RunConfig, TestRunner
    from tailtest.reporting.terminal import TerminalReporter

    # Resolve test path
    test_path = Path(path) if path else _find_default_test_path()
    if test_path is None:
        console.print(
            "[red]No test files found.[/red] Specify a path or run "
            "'tailtest generate' first."
        )
        sys.exit(1)

    console.print()
    console.print("[bold]Recording mode[/bold]")
    console.print(f"[dim]  Test path: {test_path}[/dim]")
    if session:
        console.print(f"[dim]  Session:   {session}[/dim]")
    console.print("[dim]  Recordings will be saved to .tailtest/recordings/[/dim]")
    console.print()

    # Build run config with recording enabled
    config = RunConfig(
        record=True,
        tags=list(tag),
        parallel=parallel,
    )

    # Run tests with recording
    runner = TestRunner()

    # Override the recorder session name if provided
    if session:
        from tailtest.runner.recorder import Recorder

        runner._recorder = Recorder(session_name=session)

    suite_result = asyncio.run(runner.run(test_path, config))

    # Report results
    reporter = TerminalReporter(console=console)
    reporter.report(suite_result, agent_info=str(test_path))

    # Print recording summary
    total_responses = sum(
        1 for r in suite_result.results
        if r.agent_response and r.agent_response.content
    )
    console.print()
    console.print(
        f"[bold green]Recorded {total_responses} response(s) "
        f"from {suite_result.total} test(s).[/bold green]"
    )
    console.print("[dim]Replay with: tailtest replay[/dim]")
    console.print()

    if suite_result.failed > 0:
        sys.exit(1)


def _find_default_test_path() -> Path | None:
    """Find the default test path by checking common locations."""
    candidates = [
        Path(".tailtest/tests"),
        Path("tests"),
        Path("."),
    ]
    for candidate in candidates:
        if candidate.exists():
            test_files = list(candidate.rglob("test_*.py")) + list(
                candidate.rglob("*_test.py")
            )
            if test_files:
                return candidate
    return None
