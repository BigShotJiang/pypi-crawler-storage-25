"""tailtest interview -- ask questions about your agent to generate tests."""

from __future__ import annotations

import asyncio
from pathlib import Path

import click
from rich.console import Console

console = Console()


@click.command("interview")
@click.option(
    "--path",
    "project_path",
    default=".",
    type=click.Path(exists=True),
    help="Project directory to generate config in (defaults to current directory).",
)
@click.option(
    "--generate/--no-generate",
    default=True,
    help="Run tailtest generate after the interview.",
)
def interview_cmd(project_path: str, generate: bool) -> None:
    """Ask questions about your agent to generate tests.

    Use this when ``tailtest scan`` finds nothing useful -- describe your
    agent in plain English and tailtest will generate rules, configuration,
    and tests from your answers.

    \b
    The interview produces:
      - .tailtest/rules.yaml   (never/always rules, tool scenarios)
      - tailtest.yaml          (agent connection config)
    """
    resolved = Path(project_path).resolve()

    from tailtest.context.sources.interviewer import AgentInterviewer

    interviewer = AgentInterviewer()

    if not interviewer.is_interactive():
        console.print(
            "[yellow]Non-interactive environment detected. "
            "Skipping interview.[/yellow]"
        )
        return

    result = asyncio.run(interviewer.interview())

    # Check if we got anything useful
    if not result.domain and not result.never_rules and not result.always_rules:
        console.print()
        console.print("[yellow]No answers provided. Nothing to generate.[/yellow]")
        return

    # Generate rules.yaml
    rules_path = interviewer.generate_rules_yaml(result, resolved)
    console.print()
    console.print(f"  [green]Created:[/green] {rules_path.relative_to(resolved)}")

    # Generate tailtest.yaml
    config_path = interviewer.generate_config(result, resolved)
    console.print(f"  [green]Created:[/green] {config_path.relative_to(resolved)}")

    # Optionally run test generation
    if generate:
        console.print()
        console.print("[bold]Generating tests from your answers...[/bold]")

        from tailtest.context.engine import ContextEngine
        from tailtest.generator.engine import TestGenerator

        engine = ContextEngine()
        scan_result = asyncio.run(engine.scan(resolved))

        generator = TestGenerator()
        output_dir = resolved / ".tailtest" / "tests" / "auto"
        generated = asyncio.run(generator.generate(scan_result, output_dir))

        if generated:
            for gf in generated:
                try:
                    rel = gf.relative_to(resolved)
                except ValueError:
                    rel = gf
                console.print(f"  [green]Generated:[/green] {rel}")
            console.print()
            console.print(
                f"[bold green]Created {len(generated)} test file(s).[/bold green]"
            )
        else:
            console.print("  [dim]No test files generated.[/dim]")

    console.print()
    console.print("[bold green]Interview complete.[/bold green]")
    console.print()
