"""tailtest run  -  execute agent tests."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import click
from rich.console import Console

from tailtest.cli.consent import ConsentManager
from tailtest.cli.interactive import ask, is_interactive, no_interactive_option

console = Console()


@click.command("run")
@click.argument("path", default=None, required=False, type=click.Path())
@click.option(
    "--ci",
    is_flag=True,
    default=False,
    help="CI mode: strict assertions, JUnit XML output.",
)
@click.option(
    "--parallel",
    "-p",
    type=int,
    default=1,
    show_default=True,
    help="Number of concurrent test workers.",
)
@click.option(
    "--replay",
    is_flag=True,
    default=False,
    help="Use recorded LLM responses instead of live calls.",
)
@click.option(
    "--reliability",
    "-r",
    type=int,
    default=1,
    show_default=True,
    help="Run each test N times for pass^k reliability scoring.",
)
@click.option(
    "--cost-limit",
    type=float,
    default=None,
    help="Abort the run if total LLM cost exceeds this amount (USD).",
)
@click.option(
    "--tag",
    "-t",
    multiple=True,
    help="Run only tests matching this tag (repeatable). Prefix with 'not ' to exclude.",
)
@click.option(
    "--model",
    type=str,
    default=None,
    help="Override the agent model for this run (e.g. gpt-4o, claude-sonnet-4-20250514).",
)
@click.option(
    "--judge",
    type=str,
    default=None,
    help="Override the LLM judge model (e.g. ollama/llama3.2).",
)
@click.option(
    "--target",
    type=str,
    default=None,
    help="Named target from tailtest.yaml targets (e.g. staging, production).",
)
@no_interactive_option
def run_cmd(
    path: str | None,
    ci: bool,
    parallel: int,
    replay: bool,
    reliability: int,
    cost_limit: float | None,
    tag: tuple[str, ...],
    model: str | None,
    judge: str | None,
    target: str | None,
    no_interactive: bool,
) -> None:
    """Run agent tests.

    PATH is an optional test file or directory. If omitted, runs all tests
    found under .tailtest/tests/ and any test files in the project.
    """
    from tailtest.config.loader import load_config
    from tailtest.runner.engine import RunConfig, TestRunner
    from tailtest.reporting.terminal import TerminalReporter

    # Build config overrides from CLI flags
    config_overrides: dict = {}
    if judge is not None:
        config_overrides["judge"] = {"model": judge}

    # Load config — if the user specified a test path, search for config
    # starting from that path so we find the closest tailtest.yaml
    config_obj = load_config(
        search_from=Path(path) if path else None,
        overrides=config_overrides or None,
    )
    if target:
        agent_cfg = config_obj.get_agent(target)
        if target not in config_obj.targets:
            console.print(f"[yellow]Target '{target}' not found in config, using default agent.[/yellow]")
        else:
            console.print(f"[dim]Using target: {target}[/dim]")

            # Consent check for remote targets
            consent = ConsentManager()
            if not consent.request_consent(target):
                console.print("[yellow]Aborted - consent not given.[/yellow]")
                return

    # Determine test path
    test_path = Path(path) if path else _find_default_test_path()
    if test_path is None:
        console.print("[red]No test files found.[/red] Specify a path or run 'tailtest generate' first.")
        sys.exit(1)

    # Build run config
    config = RunConfig(
        tags=list(tag),
        parallel=parallel,
        reliability=reliability,
        cost_limit=cost_limit,
        replay=replay,
        ci=ci,
        model_override=model,
        judge_override=judge,
    )

    # Run tests
    runner = TestRunner()
    suite_result = asyncio.run(runner.run(test_path, config))

    # Report results
    reporter = TerminalReporter(console=console)
    reporter.report(suite_result, agent_info=str(test_path))

    # JUnit XML in CI mode
    if ci:
        from tailtest.reporting.junit_xml import JUnitReporter

        junit = JUnitReporter()
        output_path = Path(".tailtest/reports/junit.xml")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        junit.write(suite_result, output_path)
        console.print(f"[dim]JUnit XML written to {output_path}[/dim]")

    # JSON report always
    from tailtest.reporting.json_report import JSONReporter

    json_reporter = JSONReporter()
    json_reporter.write(suite_result)

    # Interactive: offer suggestions after failures
    if suite_result.failed > 0 and is_interactive():
        if ask("  Want to see suggestions?", default=True):
            console.print()
            console.print("[bold]Suggestions:[/bold]")
            console.print("  - Review failing tests for flaky assertions")
            console.print("  - Run with [cyan]--reliability 3[/cyan] to check consistency")
            console.print("  - Run [cyan]tailtest suggest[/cyan] for detailed guidance")
            console.print()

    # Exit with failure code if any tests failed
    if suite_result.failed > 0:
        sys.exit(1)


def _find_default_test_path() -> Path | None:
    """Find the default test path by checking common locations."""
    candidates = [
        Path(".tailtest/tests"),
        Path("tests"),
        Path("."),
    ]
    for candidate in candidates:
        if candidate.exists():
            # Check if there are any test files
            test_files = list(candidate.rglob("test_*.py")) + list(candidate.rglob("*_test.py"))
            if test_files:
                return candidate
    return None
