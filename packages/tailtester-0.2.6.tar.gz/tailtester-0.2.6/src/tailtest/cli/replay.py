"""tailtest replay  -  replay recorded LLM calls for deterministic testing."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import click
from rich.console import Console

from tailtest.cli.interactive import no_interactive_option

console = Console()


@click.command("replay")
@click.argument("path", default=None, required=False, type=click.Path())
@click.option(
    "--session",
    type=str,
    default=None,
    help="Specific recording session to replay (default: most recent).",
)
@click.option(
    "--tag",
    "-t",
    multiple=True,
    help="Run only tests matching this tag (repeatable).",
)
@click.option(
    "--parallel",
    "-p",
    type=int,
    default=1,
    show_default=True,
    help="Number of concurrent test workers.",
)
@click.option(
    "--ci",
    is_flag=True,
    default=False,
    help="CI mode: strict assertions, JUnit XML output.",
)
@no_interactive_option
def replay_cmd(
    path: str | None,
    session: str | None,
    tag: tuple[str, ...],
    parallel: int,
    ci: bool,
    no_interactive: bool,
) -> None:
    """Replay recorded LLM responses for deterministic test runs.

    Uses previously recorded responses (from 'tailtest record') to run
    tests without making live API calls.  This is useful for offline
    testing, CI without agent access, and deterministic test runs.

    \b
    Examples:
      tailtest replay                             Replay with latest session
      tailtest replay tests/test_agent.py         Replay specific tests
      tailtest replay --session 2026-03-31T12-00-00  Use a specific session
      tailtest replay --ci                        Replay in CI mode
    """
    from tailtest.runner.engine import RunConfig, TestRunner
    from tailtest.reporting.terminal import TerminalReporter

    # Resolve test path
    test_path = Path(path) if path else _find_default_test_path()
    if test_path is None:
        console.print(
            "[red]No test files found.[/red] Specify a path or run "
            "'tailtest generate' first."
        )
        sys.exit(1)

    # Resolve session directory
    session_dir: str | None = None
    if session:
        candidate = Path(".tailtest/recordings") / session
        if candidate.is_dir():
            session_dir = str(candidate)
        else:
            console.print(
                f"[red]Session '{session}' not found in "
                f".tailtest/recordings/[/red]"
            )
            sys.exit(1)

    console.print()
    console.print("[bold]Replay mode[/bold]")
    console.print(f"[dim]  Test path: {test_path}[/dim]")
    if session:
        console.print(f"[dim]  Session:   {session}[/dim]")
    else:
        console.print("[dim]  Session:   most recent[/dim]")
    console.print(
        "[dim]  Using recorded responses from .tailtest/recordings/[/dim]"
    )
    console.print()

    # Build run config with replay enabled
    config = RunConfig(
        replay=True,
        replay_session=session_dir,
        tags=list(tag),
        parallel=parallel,
        ci=ci,
    )

    # Run tests with replay
    runner = TestRunner()
    suite_result = asyncio.run(runner.run(test_path, config))

    # Report results
    reporter = TerminalReporter(console=console)
    reporter.report(suite_result, agent_info=str(test_path))

    # JUnit XML in CI mode
    if ci:
        from tailtest.reporting.junit_xml import JUnitReporter

        junit = JUnitReporter()
        output_path = Path(".tailtest/reports/junit.xml")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        junit.write(suite_result, output_path)
        console.print(f"[dim]JUnit XML written to {output_path}[/dim]")

    # Print replay summary
    passed = suite_result.passed
    total = suite_result.total
    console.print()
    console.print(
        f"[bold green]Replayed {total} test(s), "
        f"{passed} passed.[/bold green]"
    )
    console.print()

    if suite_result.failed > 0:
        sys.exit(1)


def _find_default_test_path() -> Path | None:
    """Find the default test path by checking common locations."""
    candidates = [
        Path(".tailtest/tests"),
        Path("tests"),
        Path("."),
    ]
    for candidate in candidates:
        if candidate.exists():
            test_files = list(candidate.rglob("test_*.py")) + list(
                candidate.rglob("*_test.py")
            )
            if test_files:
                return candidate
    return None
