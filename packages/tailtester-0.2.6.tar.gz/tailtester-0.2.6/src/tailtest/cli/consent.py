"""Remote-access consent manager for tailtest.

Before tailtest sends test prompts to a remote endpoint it asks the user
for explicit consent.  Consent decisions are persisted in
``.tailtest/consent.json`` so the user is only asked once per target.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import click

from tailtest.cli.interactive import ask, is_interactive


class ConsentManager:
    """Manages user consent for remote agent access."""

    def __init__(self, project_dir: Path | None = None):
        self.consent_file = (project_dir or Path(".")) / ".tailtest" / "consent.json"

    # ------------------------------------------------------------------
    # persistence
    # ------------------------------------------------------------------

    def _load(self) -> dict:
        if self.consent_file.exists():
            try:
                return json.loads(self.consent_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                return {}
        return {}

    def _save(self, data: dict) -> None:
        self.consent_file.parent.mkdir(parents=True, exist_ok=True)
        self.consent_file.write_text(
            json.dumps(data, indent=2, default=str),
            encoding="utf-8",
        )

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------

    def has_consent(self, target: str) -> bool:
        """Check if user has previously consented to this target."""
        data = self._load()
        return target in data.get("consented_targets", {})

    def record_consent(self, target: str) -> None:
        """Record that user consented to this target."""
        data = self._load()
        targets = data.setdefault("consented_targets", {})
        targets[target] = {
            "consented_at": datetime.now(timezone.utc).isoformat(),
        }
        self._save(data)

    def revoke_consent(self, target: str) -> None:
        """Revoke consent for a target."""
        data = self._load()
        targets = data.get("consented_targets", {})
        targets.pop(target, None)
        self._save(data)

    def request_consent(self, target: str, warn_redteam: bool = False) -> bool:
        """Ask user for consent to access this target.

        Shows the target, warns about test prompts, asks y/N.
        Returns True if consented, False if declined.
        Stores consent so it is not asked again for the same target.
        """
        if not is_interactive():
            return True  # CI/CD mode - assume consent

        if self.has_consent(target):
            return True

        click.echo(f"\n  Agent target: {target}")
        if warn_redteam:
            click.echo("  WARNING: This will send adversarial prompts including")
            click.echo("  prompt injection, jailbreak, and PII extraction attacks.")
        else:
            click.echo("  This will send test prompts to this endpoint.")

        if ask("  Continue?", default=False):
            self.record_consent(target)
            return True
        return False
