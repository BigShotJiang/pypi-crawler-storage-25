"""tailtest generate  -  auto-generate tests from scanned context."""

from __future__ import annotations

import asyncio
from pathlib import Path

import click
from rich.console import Console

from tailtest.cli.interactive import ask, is_interactive, no_interactive_option

console = Console()

GENERATE_CHOICES = ["safety", "tools", "prompts", "all"]


@click.command("generate")
@click.option(
    "--only",
    type=click.Choice(GENERATE_CHOICES, case_sensitive=False),
    default="all",
    show_default=True,
    help="Generate only a specific category of tests.",
)
@click.option(
    "--regenerate",
    is_flag=True,
    default=False,
    help="Regenerate all auto-generated tests, overwriting existing ones.",
)
@click.option(
    "--project-dir",
    type=click.Path(exists=True),
    default=".",
    help="Project root directory (defaults to current directory).",
)
@no_interactive_option
def generate_cmd(only: str, regenerate: bool, project_dir: str, no_interactive: bool) -> None:
    """Generate tests from scanned project context.

    Uses the context gathered by 'tailtest scan' to automatically create
    test cases for your agent's tools, safety boundaries, and prompt handling.

    Requires a prior scan -- run 'tailtest scan .' first.
    """
    project_root = Path(project_dir).resolve()
    console.print()

    # Load scan context
    from tailtest.context.store import load_scan

    context = load_scan(project_root)

    if context is None:
        console.print(
            "[bold red]No scan context found.[/bold red]\n"
            "\n"
            "Run [cyan]tailtest scan .[/cyan] first to scan your project,\n"
            "then re-run [cyan]tailtest generate[/cyan].\n"
        )
        raise SystemExit(1)

    # Interactive prompts for enhanced generation
    include_llm_tests = False
    if is_interactive():
        include_llm_tests = ask(
            "  Include LLM-inferred tests? (requires AI analysis)",
            default=False,
        )
        if ask("  Do you have business rules to add?", default=False):
            rules_path = project_root / ".tailtest" / "rules.yaml"
            if not rules_path.exists():
                console.print()
                console.print(
                    f"  Create [cyan]{rules_path.relative_to(project_root)}[/cyan] "
                    "and add your rules, then re-run generate."
                )
                console.print()
                return

    if regenerate:
        console.print("[yellow]Regenerating all auto-generated tests...[/yellow]")
    else:
        console.print("[bold]Generating tests from context...[/bold]")

    if only != "all":
        console.print(f"[dim]  Category: {only}[/dim]")

    console.print(
        f"[dim]  Framework: {context.framework}  |  "
        f"Tools: {len(context.tools)}  |  "
        f"Prompts: {len(context.prompts)}[/dim]"
    )
    console.print()

    # Load config so the generator knows the agent type (http/cli/python)
    from tailtest.config.loader import load_config

    try:
        config_obj = load_config(search_from=project_root)
        agent_cfg = config_obj.agent
    except Exception:
        agent_cfg = None

    # Run the generator
    from tailtest.generator.engine import TestGenerator

    output_dir = project_root / ".tailtest" / "tests" / "auto"
    generator = TestGenerator()

    generated = asyncio.run(
        generator.generate(
            context=context,
            output_dir=output_dir,
            regenerate=regenerate,
            only=only,
            agent_cfg=agent_cfg,
        )
    )

    # Report results
    if generated:
        console.print(
            f"[bold green]Generated {len(generated)} test file(s):[/bold green]"
        )
        for path in generated:
            # Show path relative to project root for readability
            try:
                rel = path.relative_to(project_root)
            except ValueError:
                rel = path
            console.print(f"  [cyan]{rel}[/cyan]")

        console.print()
        console.print(
            "[dim]Next steps:[/dim]\n"
            "[dim]  1. Update the agent configuration in each test file[/dim]\n"
            "[dim]  2. Run tests with: [cyan]tailtest run[/cyan][/dim]\n"
            "[dim]  3. Add custom tests in: .tailtest/tests/custom/[/dim]"
        )
    else:
        console.print(
            "[yellow]No new test files generated.[/yellow]\n"
            "[dim]Use [cyan]--regenerate[/cyan] to overwrite existing tests.[/dim]"
        )

    console.print()
