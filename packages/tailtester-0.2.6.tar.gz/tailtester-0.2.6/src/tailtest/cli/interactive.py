"""Shared interactive utilities for the tailtest CLI.

Detects whether tailtest is running in a human terminal (TTY) or in
CI/CD (no TTY) and provides helpers that adapt accordingly.
"""

from __future__ import annotations

import os
import sys

import click


def is_interactive() -> bool:
    """True when running in a human terminal, False in CI/CD.

    Respects the ``--no-interactive`` flag (stored in Click context) and
    the ``TAILTEST_INTERACTIVE`` environment variable.
    """
    # Environment variable override
    env_val = os.environ.get("TAILTEST_INTERACTIVE")
    if env_val is not None:
        return env_val not in ("0", "false", "no")

    # Click context override (set by --no-interactive flag)
    try:
        ctx = click.get_current_context(silent=True)
        if ctx is not None:
            no_interactive = ctx.params.get("no_interactive") or (
                ctx.parent and ctx.parent.params.get("no_interactive")
            )
            if no_interactive:
                return False
    except RuntimeError:
        pass

    return sys.stdin.isatty() and sys.stdout.isatty()


def ask(prompt: str, default: bool = False) -> bool:
    """Ask a yes/no question if interactive, return *default* if not."""
    if not is_interactive():
        return default
    return click.confirm(prompt, default=default)


def choose(prompt: str, choices: list[str], default: str) -> str:
    """Present choices if interactive, return *default* if not."""
    if not is_interactive():
        return default
    return click.prompt(prompt, type=click.Choice(choices), default=default)


def no_interactive_option(fn: object | None = None):
    """Decorator that adds ``--no-interactive`` to a Click command."""
    decorator = click.option(
        "--no-interactive",
        is_flag=True,
        default=False,
        help="Disable interactive prompts (use defaults).",
    )
    if fn is not None:
        return decorator(fn)
    return decorator
