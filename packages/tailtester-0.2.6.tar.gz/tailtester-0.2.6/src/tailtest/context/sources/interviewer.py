"""Interactive interview -- asks the developer questions about their agent
to generate rules and configuration when no other context sources are available.

Implements the interactive interview module described in Filing 001 Claim 8:
presenting questions about the agent's intended behavior, scope, and
constraints.
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

import click
import yaml

logger = logging.getLogger(__name__)


@dataclass
class InterviewResult:
    """Structured answers from the interactive interview."""

    domain: str = ""
    tools: list[str] = field(default_factory=list)
    never_rules: list[str] = field(default_factory=list)
    always_rules: list[str] = field(default_factory=list)
    interface_type: str = "http"  # http, cli, python
    interface_details: str = ""  # URL, command, module:fn
    priority: str = ""


class AgentInterviewer:
    """Asks the developer about their agent and produces structured output.

    Usage::

        interviewer = AgentInterviewer()
        result = await interviewer.interview()
        interviewer.generate_rules_yaml(result, Path("."))
        interviewer.generate_config(result, Path("."))
    """

    QUESTIONS: list[tuple[str, str]] = [
        ("What does your agent do?", "domain"),
        (
            "What tools/actions can it perform? (comma-separated)",
            "tools",
        ),
        (
            "What should it NEVER do? (comma-separated)",
            "never_rules",
        ),
        (
            "What should it ALWAYS do? (comma-separated)",
            "always_rules",
        ),
        (
            "How do users interact with it? (http/cli/python)",
            "interface_type",
        ),
        (
            "Connection details? (URL, command, or module:fn)",
            "interface_details",
        ),
    ]

    def is_interactive(self) -> bool:
        """Check whether we are running in an interactive terminal."""
        env_val = os.environ.get("TAILTEST_INTERACTIVE")
        if env_val is not None:
            return env_val not in ("0", "false", "no")

        # CI environment variables that indicate non-interactive mode
        ci_vars = ("CI", "GITHUB_ACTIONS", "GITLAB_CI", "JENKINS_URL")
        if any(os.environ.get(v) for v in ci_vars):
            return False

        return sys.stdin.isatty() and sys.stdout.isatty()

    async def interview(self) -> InterviewResult:
        """Ask all questions and return structured answers.

        In non-interactive mode (CI), returns an empty
        :class:`InterviewResult` without prompting.
        """
        if not self.is_interactive():
            logger.info("Non-interactive mode detected, skipping interview")
            return InterviewResult()

        click.echo()
        click.echo("  I'll ask you about your agent to generate tests.")
        click.echo()

        answers: dict[str, str] = {}
        for idx, (question, key) in enumerate(self.QUESTIONS, start=1):
            prompt_text = f"  {idx}. {question}"
            raw = click.prompt(prompt_text, default="", show_default=False)
            answers[key] = raw.strip()

        return self._parse_answers(answers)

    def _parse_answers(self, answers: dict[str, str]) -> InterviewResult:
        """Parse raw string answers into a structured result."""
        return InterviewResult(
            domain=answers.get("domain", ""),
            tools=_parse_comma_list(answers.get("tools", "")),
            never_rules=_parse_comma_list(answers.get("never_rules", "")),
            always_rules=_parse_comma_list(answers.get("always_rules", "")),
            interface_type=_normalise_interface(
                answers.get("interface_type", "")
            ),
            interface_details=answers.get("interface_details", ""),
            priority=answers.get("priority", ""),
        )

    def generate_rules_yaml(
        self, result: InterviewResult, output_dir: Path
    ) -> Path:
        """Generate ``.tailtest/rules.yaml`` from interview answers.

        Returns the path to the generated file.
        """
        tailtest_dir = output_dir / ".tailtest"
        tailtest_dir.mkdir(parents=True, exist_ok=True)

        rules_path = tailtest_dir / "rules.yaml"

        data: dict[str, object] = {}

        if result.domain:
            data["rules"] = [f"Agent domain: {result.domain}"]

        if result.never_rules:
            data["never"] = result.never_rules

        if result.always_rules:
            data["always"] = result.always_rules

        if result.tools:
            data["scenarios"] = [
                {"input": f"Use the {tool} tool", "expect": f"{tool} is called correctly"}
                for tool in result.tools
            ]

        content = yaml.dump(data, default_flow_style=False, sort_keys=False)
        rules_path.write_text(content, encoding="utf-8")
        logger.info("Generated rules at %s", rules_path)

        return rules_path

    def generate_config(
        self, result: InterviewResult, output_dir: Path
    ) -> Path:
        """Generate ``tailtest.yaml`` from the interface answers.

        Returns the path to the generated file.
        """
        config_path = output_dir / "tailtest.yaml"

        agent_config: dict[str, str] = {"type": result.interface_type}

        if result.interface_type == "http":
            url = result.interface_details or "http://localhost:8000/chat"
            agent_config["url"] = url
        elif result.interface_type == "cli":
            command = result.interface_details or "python agent.py"
            agent_config["command"] = command
        elif result.interface_type == "python":
            function = result.interface_details or "agent:run"
            agent_config["function"] = function

        data: dict[str, object] = {
            "version": "1",
            "agent": agent_config,
        }

        if result.domain:
            data["domain"] = result.domain

        content = yaml.dump(data, default_flow_style=False, sort_keys=False)
        config_path.write_text(content, encoding="utf-8")
        logger.info("Generated config at %s", config_path)

        return config_path


def _parse_comma_list(raw: str) -> list[str]:
    """Split a comma-separated string into a list of trimmed, non-empty items."""
    if not raw:
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]


def _normalise_interface(raw: str) -> str:
    """Normalise the interface type to one of http, cli, python."""
    raw_lower = raw.strip().lower()
    if raw_lower in ("http", "api", "rest", "web"):
        return "http"
    if raw_lower in ("cli", "command", "cmd", "terminal"):
        return "cli"
    if raw_lower in ("python", "py", "module", "function"):
        return "python"
    # Default to http if unrecognised
    return "http"
