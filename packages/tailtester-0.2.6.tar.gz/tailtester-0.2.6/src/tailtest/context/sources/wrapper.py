"""Process wrapper -- launches a development tool as a child process while
watching the project directory for file changes.

This implements the ``tailtest wrap`` context source described in Filing 001
Claim 4: monitoring an AI-assisted development session by launching the
developer's development tool as a child process and observing files created,
modified, and deleted during the session.
"""

from __future__ import annotations

import asyncio
import logging
import signal
import time
from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console

logger = logging.getLogger(__name__)


@dataclass
class WrapResult:
    """Summary of a wrapped development session."""

    command: str
    exit_code: int
    duration_seconds: float
    files_created: int = 0
    files_modified: int = 0
    files_deleted: int = 0
    tests_generated: int = 0
    tests_passed: int = 0
    tests_failed: int = 0
    tests_skipped: int = 0
    changed_paths: list[str] = field(default_factory=list)


class ProcessWrapper:
    """Wraps a development tool as child process while watching for file changes.

    Usage::

        wrapper = ProcessWrapper("claude code", Path("./my-project"))
        result = await wrapper.run()
    """

    def __init__(
        self,
        command: str,
        project_dir: Path,
        understand: bool = False,
        no_run: bool = False,
        live: bool = False,
        console: Console | None = None,
    ):
        self.command = command
        self.project_dir = project_dir.resolve()
        self.understand = understand
        self.no_run = no_run
        self.live = live
        self.console = console or Console()

        self._process: asyncio.subprocess.Process | None = None
        self._watcher_task: asyncio.Task | None = None
        self._live_task: asyncio.Task | None = None
        self._changed_paths: list[str] = []
        self._files_created: int = 0
        self._files_modified: int = 0
        self._files_deleted: int = 0

        # Live mode debounce state
        self._last_change_time: float = 0.0
        self._pending_live_paths: list[str] = []
        self._live_incremental_passed: int = 0
        self._live_incremental_failed: int = 0
        self._live_incremental_generated: int = 0

    async def run(self) -> WrapResult:
        """Start the subprocess, watch files, generate tests, run on exit.

        Returns a :class:`WrapResult` summarising the session.
        """
        from tailtest.context.sources.session import SessionTracker

        start_time = time.monotonic()

        # Initialise session tracker
        tracker = SessionTracker(self.project_dir)
        tracker.start()

        self.console.print()
        self.console.print(
            f"[bold]Wrapping[/bold] [cyan]{self.command}[/cyan]"
        )
        mode_label = "live companion" if self.live else "bookend"
        self.console.print(
            f"[dim]Watching {self.project_dir} for changes... ({mode_label} mode)[/dim]"
        )
        self.console.print()

        # 1. Start the subprocess -- do NOT capture stdin/stdout so the
        #    developer retains full interactive control of the child.
        try:
            self._process = await asyncio.create_subprocess_shell(
                self.command,
                stdin=None,   # inherit from parent
                stdout=None,  # inherit from parent
                stderr=None,  # inherit from parent
                cwd=str(self.project_dir),
            )
        except OSError as exc:
            self.console.print(f"[red]Failed to start process: {exc}[/red]")
            elapsed = time.monotonic() - start_time
            return WrapResult(
                command=self.command,
                exit_code=-1,
                duration_seconds=elapsed,
            )

        # 2. Start file watcher in background (reuse ProjectWatcher)
        self._watcher_task = asyncio.create_task(
            self._watch_files(tracker)
        )

        # 3. Start live debounce loop if in live mode
        if self.live:
            self._live_task = asyncio.create_task(self._live_loop())

        # 4. Wait for the subprocess to exit
        exit_code = await self._wait_for_process()

        # 5. Cancel the watcher and live loop
        for task in (self._watcher_task, self._live_task):
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        elapsed = time.monotonic() - start_time

        self.console.print()
        self.console.print(
            f"[bold]Process exited[/bold] with code [cyan]{exit_code}[/cyan]"
        )

        # 6. Final scan (with --understand if enabled)
        scan_result = await self._final_scan()

        # 7. Generate tests
        tests_generated = 0
        if scan_result is not None:
            tests_generated = await self._generate_tests(scan_result)

        # 8. Run tests (unless --no-run)
        tests_passed = 0
        tests_failed = 0
        tests_skipped = 0
        test_failures: list[tuple[str, str]] = []
        if not self.no_run and tests_generated > 0:
            tests_passed, tests_failed, tests_skipped, test_failures = (
                await self._run_tests_detailed()
            )

        # 9. Build result
        total_generated = tests_generated + self._live_incremental_generated
        total_passed = tests_passed + self._live_incremental_passed
        total_failed = tests_failed + self._live_incremental_failed

        result = WrapResult(
            command=self.command,
            exit_code=exit_code,
            duration_seconds=elapsed,
            files_created=self._files_created,
            files_modified=self._files_modified,
            files_deleted=self._files_deleted,
            tests_generated=total_generated,
            tests_passed=total_passed,
            tests_failed=total_failed,
            tests_skipped=tests_skipped,
            changed_paths=list(self._changed_paths),
        )

        # 10. Build and save session report
        from tailtest.context.sources.session import FailureDetail

        session_report = tracker.finish(
            command=self.command,
            exit_code=exit_code,
            tests_generated=total_generated,
            tests_passed=total_passed,
            tests_failed=total_failed,
            test_failures=[
                FailureDetail(name=n, message=m) for n, m in test_failures
            ],
        )

        report_path = self._save_session_report(tracker, session_report)
        if report_path:
            session_report.report_path = str(report_path)

        # 11. Print rich session report
        self._print_rich_report(result, test_failures, report_path)

        return result

    # ------------------------------------------------------------------ #
    # File watching
    # ------------------------------------------------------------------ #

    async def _watch_files(self, tracker=None) -> None:
        """Run the file watcher until cancelled."""
        try:
            from watchfiles import Change, awatch

            from tailtest.context.sources.watcher import (
                _SKIP_DIRS,
                _WATCH_SUFFIXES,
            )

            def _should_watch(_change: Change, path: str) -> bool:
                p = Path(path)
                if any(part in _SKIP_DIRS for part in p.parts):
                    return False
                return p.suffix in _WATCH_SUFFIXES

            async for changes in awatch(
                self.project_dir,
                watch_filter=_should_watch,
                debounce=300,
            ):
                for change_type, path in changes:
                    rel = Path(path)
                    try:
                        rel = rel.relative_to(self.project_dir)
                    except ValueError:
                        pass
                    str_path = str(rel)
                    if str_path not in self._changed_paths:
                        self._changed_paths.append(str_path)

                    if change_type == Change.added:
                        self._files_created += 1
                        action = "created"
                    elif change_type == Change.modified:
                        self._files_modified += 1
                        action = "modified"
                    elif change_type == Change.deleted:
                        self._files_deleted += 1
                        action = "deleted"
                    else:
                        action = "changed"

                    # Record in session tracker
                    if tracker is not None:
                        tracker.record_change(str_path, action)

                    # Track for live mode
                    if self.live:
                        self._last_change_time = time.monotonic()
                        if str_path not in self._pending_live_paths:
                            self._pending_live_paths.append(str_path)

                    label = {
                        Change.added: "added",
                        Change.modified: "modified",
                        Change.deleted: "deleted",
                    }.get(change_type, "changed")

                    icon = {
                        Change.added: "[green]+[/green]",
                        Change.modified: "[yellow]~[/yellow]",
                        Change.deleted: "[red]-[/red]",
                    }.get(change_type, "[yellow]~[/yellow]")

                    if not self.live:
                        # Bookend mode: no output during session
                        pass
                    else:
                        self.console.print(f"  {icon} {rel} {label}")

        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("File watcher error: %s", exc)

    # ------------------------------------------------------------------ #
    # Live mode debounced loop
    # ------------------------------------------------------------------ #

    async def _live_loop(self) -> None:
        """Debounced incremental scan/generate/run loop for live mode.

        Waits 5 seconds after the last file change before running an
        incremental pipeline on the changed files.
        """
        debounce_seconds = 5.0
        try:
            while True:
                await asyncio.sleep(1.0)

                if not self._pending_live_paths:
                    continue

                elapsed = time.monotonic() - self._last_change_time
                if elapsed < debounce_seconds:
                    continue

                # Grab and clear pending paths
                paths = list(self._pending_live_paths)
                self._pending_live_paths.clear()

                self.console.print(
                    f"[dim]  > incremental: {len(paths)} changed file(s)...[/dim]"
                )

                # Run incremental pipeline
                scan_result = await self._final_scan()
                if scan_result is not None:
                    gen_count = await self._generate_tests(scan_result)
                    self._live_incremental_generated += gen_count

                    if not self.no_run and gen_count > 0:
                        p, f, _s, _failures = await self._run_tests_detailed()
                        self._live_incremental_passed += p
                        self._live_incremental_failed += f
                        self.console.print(
                            f"[dim]  > incremental: {p} passed, {f} failed[/dim]"
                        )

        except asyncio.CancelledError:
            raise

    # ------------------------------------------------------------------ #
    # Process management
    # ------------------------------------------------------------------ #

    async def _wait_for_process(self) -> int:
        """Wait for the subprocess, handling Ctrl+C gracefully."""
        assert self._process is not None

        try:
            exit_code = await self._process.wait()
        except asyncio.CancelledError:
            # Ctrl+C propagated -- terminate the child
            await self._kill_process()
            exit_code = -2

        return exit_code

    async def _kill_process(self) -> None:
        """Terminate the child process if it is still running."""
        if self._process is None:
            return
        if self._process.returncode is not None:
            return  # already exited

        try:
            self._process.send_signal(signal.SIGTERM)
            try:
                await asyncio.wait_for(self._process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                self._process.kill()
                await self._process.wait()
        except ProcessLookupError:
            pass

    # ------------------------------------------------------------------ #
    # Post-exit pipeline: scan -> generate -> run
    # ------------------------------------------------------------------ #

    async def _final_scan(self):
        """Run a final context scan after the subprocess exits."""
        self.console.print()
        self.console.print("[bold]Running final scan...[/bold]")

        from tailtest.context.engine import ContextEngine

        engine = ContextEngine()
        try:
            result = await engine.scan(self.project_dir)
        except Exception as exc:
            logger.warning("Final scan failed: %s", exc)
            self.console.print(f"[yellow]Scan warning: {exc}[/yellow]")
            return None

        # Save context if project is initialised
        tailtest_dir = self.project_dir / ".tailtest"
        if tailtest_dir.exists():
            engine.save_context(result, self.project_dir)

        self.console.print(
            f"  Framework: [cyan]{result.framework}[/cyan], "
            f"Tools: [cyan]{len(result.tools)}[/cyan], "
            f"Prompts: [cyan]{len(result.prompts)}[/cyan]"
        )

        return result

    async def _generate_tests(self, scan_result) -> int:
        """Generate tests from scan results. Returns count of generated files."""
        self.console.print()
        self.console.print("[bold]Generating tests...[/bold]")

        from tailtest.generator.engine import TestGenerator

        generator = TestGenerator()
        output_dir = self.project_dir / ".tailtest" / "tests" / "auto"

        try:
            generated = await generator.generate(
                scan_result, output_dir, regenerate=True
            )
        except Exception as exc:
            logger.warning("Test generation failed: %s", exc)
            self.console.print(f"[yellow]Generation warning: {exc}[/yellow]")
            return 0

        for gf in generated:
            try:
                rel = gf.relative_to(self.project_dir)
            except ValueError:
                rel = gf
            self.console.print(f"  [green]Generated:[/green] {rel}")

        return len(generated)

    async def _run_tests(self) -> tuple[int, int, int]:
        """Run the generated test suite. Returns (passed, failed, skipped)."""
        p, f, s, _failures = await self._run_tests_detailed()
        return (p, f, s)

    async def _run_tests_detailed(
        self,
    ) -> tuple[int, int, int, list[tuple[str, str]]]:
        """Run the generated test suite.

        Returns (passed, failed, skipped, failures) where failures is a list
        of (test_name, failure_message) tuples.
        """
        self.console.print()
        self.console.print("[bold]Running tests...[/bold]")

        from tailtest.runner.engine import RunConfig, TestRunner

        runner = TestRunner()
        test_dir = self.project_dir / ".tailtest" / "tests"

        try:
            suite_result = await runner.run(
                str(test_dir), config=RunConfig()
            )
        except Exception as exc:
            logger.warning("Test run failed: %s", exc)
            self.console.print(f"[yellow]Test run warning: {exc}[/yellow]")
            return (0, 0, 0, [])

        failures: list[tuple[str, str]] = []
        for tr in suite_result.results:
            if not tr.passed:
                msg_parts = [
                    ar.message
                    for ar in tr.assertion_results
                    if not ar.passed
                ]
                msg = "; ".join(msg_parts) if msg_parts else "test failed"
                failures.append((tr.test_case.name, msg))

        return (
            suite_result.passed,
            suite_result.failed,
            suite_result.skipped,
            failures,
        )

    # ------------------------------------------------------------------ #
    # Session report persistence
    # ------------------------------------------------------------------ #

    def _save_session_report(self, tracker, session_report) -> Path | None:
        """Save session report and return the path, or None on error."""
        try:
            reports_dir = self.project_dir / ".tailtest" / "reports"
            return tracker.save_report(session_report, reports_dir)
        except Exception as exc:
            logger.warning("Failed to save session report: %s", exc)
            return None

    # ------------------------------------------------------------------ #
    # Rich exit report
    # ------------------------------------------------------------------ #

    def _print_rich_report(
        self,
        result: WrapResult,
        test_failures: list[tuple[str, str]],
        report_path: Path | None,
    ) -> None:
        """Print the rich session report to the console."""
        self.console.print()
        self.console.print("[bold cyan]tailtest Session Report[/bold cyan]")
        self.console.print("=" * 40)

        # Duration
        minutes = int(result.duration_seconds // 60)
        seconds = int(result.duration_seconds % 60)
        if minutes > 0:
            self.console.print(f"Session: {minutes} minutes, {seconds} seconds")
        else:
            self.console.print(f"Session: {seconds} seconds")

        # Files
        self.console.print(
            f"Files created:  [green]{result.files_created}[/green]"
        )
        self.console.print(
            f"Files modified: [yellow]{result.files_modified}[/yellow]"
        )
        self.console.print(
            f"Files deleted:  [red]{result.files_deleted}[/red]"
        )
        self.console.print()

        # Tests
        if result.tests_generated > 0:
            self.console.print(
                f"Auto-generated: [cyan]{result.tests_generated}[/cyan] tests"
            )
            self.console.print()
            self.console.print(
                f"Results: [green]{result.tests_passed} passed[/green], "
                f"[red]{result.tests_failed} failed[/red]"
            )
        else:
            self.console.print("[dim]No tests generated.[/dim]")

        # Failures
        if test_failures:
            self.console.print()
            self.console.print("[bold red]Failures:[/bold red]")
            for name, msg in test_failures:
                self.console.print(f"  [red]{name}[/red] - {msg}")

        # Live mode incremental summary
        if self.live and (
            self._live_incremental_generated > 0
            or self._live_incremental_passed > 0
            or self._live_incremental_failed > 0
        ):
            self.console.print()
            self.console.print("[dim]Incremental (live mode):[/dim]")
            self.console.print(
                f"  [dim]Generated: {self._live_incremental_generated}, "
                f"Passed: {self._live_incremental_passed}, "
                f"Failed: {self._live_incremental_failed}[/dim]"
            )

        # Report path
        if report_path:
            self.console.print()
            self.console.print(f"Report saved: [dim]{report_path}[/dim]")

        self.console.print()

    # ------------------------------------------------------------------ #
    # Session summary (legacy, kept for backward compatibility)
    # ------------------------------------------------------------------ #

    def _print_summary(self, result: WrapResult) -> None:
        """Print a session summary to the console."""
        self.console.print()
        self.console.print("[bold]Session Summary[/bold]")
        self.console.print("=" * 40)

        minutes = int(result.duration_seconds // 60)
        seconds = int(result.duration_seconds % 60)
        self.console.print(f"  Duration:       {minutes}m {seconds}s")
        self.console.print(f"  Command:        {result.command}")
        self.console.print(f"  Exit code:      {result.exit_code}")
        self.console.print()
        self.console.print(
            f"  Files created:  [green]{result.files_created}[/green]"
        )
        self.console.print(
            f"  Files modified: [yellow]{result.files_modified}[/yellow]"
        )
        self.console.print(
            f"  Files deleted:  [red]{result.files_deleted}[/red]"
        )
        self.console.print()

        if result.tests_generated > 0:
            self.console.print(
                f"  Tests generated: [cyan]{result.tests_generated}[/cyan]"
            )
            self.console.print(
                f"  Passed:          [green]{result.tests_passed}[/green]"
            )
            self.console.print(
                f"  Failed:          [red]{result.tests_failed}[/red]"
            )
            if result.tests_skipped:
                self.console.print(
                    f"  Skipped:         [yellow]{result.tests_skipped}[/yellow]"
                )
        else:
            self.console.print("  [dim]No tests generated.[/dim]")

        self.console.print()
