"""Session tracking for wrapped development sessions.

Records file-level changes (creates, modifies, deletes) with timestamps
and produces a structured SessionReport at the end of the session.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, Field

from tailtest.context.sources.watcher import _SKIP_DIRS, _WATCH_SUFFIXES

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class FileChange(BaseModel):
    """A single recorded file-system change."""

    path: str
    action: str  # "created" | "modified" | "deleted"
    timestamp: float


class FailureDetail(BaseModel):
    """Details about a single test failure for the session report."""

    name: str
    message: str


class SessionReport(BaseModel):
    """Complete report for a wrapped development session."""

    start_time: datetime
    end_time: datetime
    duration_seconds: float
    command: str = ""
    exit_code: int = 0

    files_created: list[str] = Field(default_factory=list)
    files_modified: list[str] = Field(default_factory=list)
    files_deleted: list[str] = Field(default_factory=list)

    tests_generated: int = 0
    tests_by_source: dict[str, int] = Field(default_factory=dict)
    tests_passed: int = 0
    tests_failed: int = 0
    test_failures: list[FailureDetail] = Field(default_factory=list)

    report_path: str | None = None


# ---------------------------------------------------------------------------
# Tracker
# ---------------------------------------------------------------------------


class SessionTracker:
    """Snapshots project state and tracks file-level changes over a session.

    Usage::

        tracker = SessionTracker(project_dir)
        tracker.start()
        # ... development session ...
        tracker.record_change("src/foo.py", "modified")
        report = tracker.finish(command="claude code", exit_code=0)
    """

    def __init__(self, project_dir: Path) -> None:
        self.project_dir = project_dir.resolve()
        self._start_time: float = 0.0
        self._start_snapshot: dict[str, str] = {}  # relative path -> sha256
        self._changes: list[FileChange] = []

    # ------------------------------------------------------------------ #
    # Snapshot helpers
    # ------------------------------------------------------------------ #

    def _hash_file(self, path: Path) -> str:
        """Return the SHA-256 hex digest of a file, or empty string on error."""
        try:
            return hashlib.sha256(path.read_bytes()).hexdigest()
        except (OSError, PermissionError):
            return ""

    def _snapshot(self) -> dict[str, str]:
        """Walk the project directory and build a path -> hash map."""
        result: dict[str, str] = {}
        try:
            for p in self.project_dir.rglob("*"):
                if not p.is_file():
                    continue
                # Skip ignored directories
                if any(part in _SKIP_DIRS for part in p.parts):
                    continue
                # Only track watched suffixes
                if p.suffix not in _WATCH_SUFFIXES:
                    continue
                try:
                    rel = str(p.relative_to(self.project_dir))
                except ValueError:
                    continue
                result[rel] = self._hash_file(p)
        except OSError:
            logger.warning("Failed to snapshot project directory")
        return result

    # ------------------------------------------------------------------ #
    # Session lifecycle
    # ------------------------------------------------------------------ #

    def start(self) -> None:
        """Take the initial snapshot and record the start time."""
        self._start_time = time.time()
        self._start_snapshot = self._snapshot()
        self._changes = []

    def record_change(self, path: str, action: str) -> None:
        """Record a file change event observed by the watcher."""
        self._changes.append(
            FileChange(path=path, action=action, timestamp=time.time())
        )

    def finish(
        self,
        command: str = "",
        exit_code: int = 0,
        tests_generated: int = 0,
        tests_by_source: dict[str, int] | None = None,
        tests_passed: int = 0,
        tests_failed: int = 0,
        test_failures: list[FailureDetail] | None = None,
    ) -> SessionReport:
        """Build the final SessionReport by diffing start vs current state."""
        end_time = time.time()
        end_snapshot = self._snapshot()

        # Compute file-level diffs
        created: list[str] = []
        modified: list[str] = []
        deleted: list[str] = []

        all_paths = set(self._start_snapshot) | set(end_snapshot)
        for p in sorted(all_paths):
            in_start = p in self._start_snapshot
            in_end = p in end_snapshot
            if not in_start and in_end:
                created.append(p)
            elif in_start and not in_end:
                deleted.append(p)
            elif in_start and in_end:
                if self._start_snapshot[p] != end_snapshot[p]:
                    modified.append(p)

        start_dt = datetime.fromtimestamp(self._start_time, tz=timezone.utc)
        end_dt = datetime.fromtimestamp(end_time, tz=timezone.utc)

        return SessionReport(
            start_time=start_dt,
            end_time=end_dt,
            duration_seconds=end_time - self._start_time,
            command=command,
            exit_code=exit_code,
            files_created=created,
            files_modified=modified,
            files_deleted=deleted,
            tests_generated=tests_generated,
            tests_by_source=tests_by_source or {},
            tests_passed=tests_passed,
            tests_failed=tests_failed,
            test_failures=test_failures or [],
        )

    # ------------------------------------------------------------------ #
    # Persistence
    # ------------------------------------------------------------------ #

    def save_report(
        self, report: SessionReport, reports_dir: Path | None = None
    ) -> Path:
        """Serialize the session report to JSON on disk.

        Returns the path the report was saved to.
        """
        if reports_dir is None:
            reports_dir = self.project_dir / ".tailtest" / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)

        ts = report.end_time.strftime("%Y-%m-%d_%H%M%S")
        path = reports_dir / f"session-{ts}.json"
        path.write_text(
            report.model_dump_json(indent=2), encoding="utf-8"
        )
        return path

    @staticmethod
    def load_latest_report(reports_dir: Path) -> SessionReport | None:
        """Load the most recent session report from disk."""
        if not reports_dir.exists():
            return None
        files = sorted(reports_dir.glob("session-*.json"), reverse=True)
        if not files:
            return None
        try:
            data = json.loads(files[0].read_text(encoding="utf-8"))
            return SessionReport.model_validate(data)
        except Exception as exc:
            logger.warning("Failed to load session report: %s", exc)
            return None
