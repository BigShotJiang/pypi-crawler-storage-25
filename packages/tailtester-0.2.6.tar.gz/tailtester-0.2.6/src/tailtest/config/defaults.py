"""Default configuration values and template for tailtest.yaml."""

from __future__ import annotations

# Default tailtest.yaml template  -  written by `tailtest init`.
DEFAULT_TAILTEST_YAML = """\
# tailtest.yaml  -  configuration for tailtest (the pytest for AI agents)
version: "1"

# Agent under test
agent:
  type: http                          # http | python | cli
  url: http://localhost:8000/chat     # for http type
  # function: my_module:my_agent_fn   # for python type
  # command: python agent.py --chat   # for cli type

  # Request format
  request_method: POST
  request_headers:
    Authorization: "Bearer ${AGENT_API_KEY}"
  body_template: '{"message": "{{input}}", "session_id": "{{session_id}}"}'

  # Response parsing
  response_content_path: "$.response.text"     # JSONPath to extract content
  # response_tool_calls_path: "$.response.tools"  # JSONPath for tool calls

# Test configuration
testing:
  timeout_ms: 30000                    # Default timeout per test
  parallel: 4                          # Concurrent test workers
  # cost_limit: 10.00                  # Abort suite if cost exceeds

# LLM Judge configuration
judge:
  model: auto                         # Auto-detect best available LLM
  # model: ollama/llama3.2            # Explicit: local model (free)
  # model: anthropic/claude-sonnet    # Explicit: cloud model (paid)
  temperature: 0.0                     # Deterministic judging

# Red-team configuration
redteam:
  intensity: standard                  # quick | standard | thorough
  categories:                          # Which attack categories
    - prompt_injection
    - jailbreak
    - pii_extraction
    - tool_misuse
    - hallucination

# Production monitoring
production:
  # otlp_endpoint: http://localhost:4318  # OTel collector endpoint
  sampling_rate: 0.01                     # Sample 1% of traces
  quality_threshold: 0.8                  # Alert below this

# Reporting
reporting:
  formats:
    - terminal
    # - junit_xml
  output_dir: .tailtest/reports/
"""
