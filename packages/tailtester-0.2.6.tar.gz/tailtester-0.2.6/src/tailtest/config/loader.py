"""Configuration loading for tailtest.

Resolution order:
  1. tailtest.yaml in current directory (or explicit path)
  2. [tool.tailtest] section in pyproject.toml
  3. Built-in defaults

Environment variables in values are interpolated: ${VAR_NAME} is replaced
with the value of os.environ["VAR_NAME"]. Missing variables are left as-is.
"""

from __future__ import annotations

import os
import re
import tomllib
from pathlib import Path
from typing import Any

import yaml

from tailtest.config.schema import TailtestConfig

_ENV_VAR_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def _interpolate_env(value: Any) -> Any:
    """Recursively replace ${VAR} references in string values."""
    if isinstance(value, str):
        return _ENV_VAR_RE.sub(lambda m: os.environ.get(m.group(1), m.group(0)), value)
    if isinstance(value, dict):
        return {k: _interpolate_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_interpolate_env(v) for v in value]
    return value


def _flatten_agent_request(data: dict[str, Any]) -> dict[str, Any]:
    """Normalize the YAML-style nested agent.request/response into flat schema fields.

    In tailtest.yaml the user writes:
        agent:
          request:
            method: POST
            headers: { ... }
            body_template: "..."
          response:
            content_path: "$.x"

    The Pydantic schema uses flat fields on AgentConfig:
        request_method, request_headers, body_template,
        response_content_path, response_tool_calls_path
    """
    agent = data.get("agent")
    if not isinstance(agent, dict):
        return data

    # Flatten request block
    request = agent.pop("request", None)
    if isinstance(request, dict):
        if "method" in request:
            agent.setdefault("request_method", request["method"])
        if "headers" in request:
            agent.setdefault("request_headers", request["headers"])
        if "body_template" in request:
            agent.setdefault("body_template", request["body_template"])

    # Flatten response block
    response = agent.pop("response", None)
    if isinstance(response, dict):
        if "content_path" in response:
            agent.setdefault("response_content_path", response["content_path"])
        if "tool_calls_path" in response:
            agent.setdefault("response_tool_calls_path", response["tool_calls_path"])

    return data


def _load_yaml(path: Path) -> dict[str, Any]:
    """Load and parse a YAML file, returning a raw dict."""
    with path.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    return raw if isinstance(raw, dict) else {}


def _load_pyproject(path: Path) -> dict[str, Any]:
    """Extract [tool.tailtest] from a pyproject.toml file."""
    with path.open("rb") as f:
        data = tomllib.load(f)
    return data.get("tool", {}).get("tailtest", {})


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge *override* into *base*, returning a new dict."""
    merged = dict(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_config(
    path: Path | None = None,
    *,
    search_from: Path | None = None,
    overrides: dict[str, Any] | None = None,
) -> TailtestConfig:
    """Load tailtest configuration.

    Args:
        path: Explicit path to a tailtest.yaml file.  When *None*, the loader
              searches for ``tailtest.yaml`` starting from *search_from* (or
              CWD when *search_from* is also *None*), walking up the directory
              tree, and then falls back to ``[tool.tailtest]`` in
              ``pyproject.toml``.
        search_from: Directory to start the walk-up search from.  When a user
                     runs ``tailtest run testing/tailtest/``, pass that test
                     directory here so the config closest to the tests is
                     found first.  Defaults to ``Path.cwd()``.
        overrides: Dict of values to merge on top of file-based config
                   (typically from CLI flags).

    Returns:
        A validated ``TailtestConfig`` instance.
    """
    raw: dict[str, Any] = {}

    if path is not None:
        # Explicit path  -  must exist.
        raw = _load_yaml(path)
    else:
        # Auto-discovery: walk up from search_from (or cwd) to find tailtest.yaml
        found = False
        start = search_from.resolve() if search_from is not None else Path.cwd()
        # If the starting point is a file, begin from its parent directory
        search_dir = start if start.is_dir() else start.parent
        for _ in range(20):  # safety limit
            yaml_path = search_dir / "tailtest.yaml"
            if yaml_path.is_file():
                raw = _load_yaml(yaml_path)
                found = True
                break
            parent = search_dir.parent
            if parent == search_dir:
                break  # reached filesystem root
            search_dir = parent

        if not found:
            # Fall back to pyproject.toml in cwd
            pyproject_path = Path.cwd() / "pyproject.toml"
            if pyproject_path.is_file():
                raw = _load_pyproject(pyproject_path)
        # else: use defaults (empty dict -> Pydantic defaults kick in)

    # Merge CLI overrides.
    if overrides:
        raw = _deep_merge(raw, overrides)

    # Environment variable interpolation.
    raw = _interpolate_env(raw)

    # Normalize nested agent request/response blocks.
    raw = _flatten_agent_request(raw)

    return TailtestConfig.model_validate(raw)
