"""Intelligence Engine  -  fuses three layers of test intelligence.

Layer 1: Structural (existing scanner  -  AST/pattern based)
Layer 2: LLM Understanding (deep code analysis)
Layer 3: User Rules (rules.yaml)

The engine combines all three sources, deduplicates overlapping tests,
and tags each test with its origin for filtering and reporting.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from tailtest.intelligence.cache import UnderstandingCache
from tailtest.intelligence.rules_loader import RulesLoader, UserRules
from tailtest.intelligence.rules_to_tests import GeneratedTest, RulesToTests
from tailtest.intelligence.understanding import CodeUnderstanding, UnderstandingResult
from tailtest.models import ScanResult

logger = logging.getLogger(__name__)


@dataclass
class IntelligenceResult:
    """Combined intelligence from all three layers."""

    # Layer 1: structural scan result (from existing context engine)
    scan_result: ScanResult | None = None

    # Layer 2: LLM understanding results per file
    understanding: list[UnderstandingResult] = field(default_factory=list)

    # Layer 3: user rules
    user_rules: UserRules | None = None

    # Combined generated tests (deduplicated, tagged)
    generated_tests: list[GeneratedTest] = field(default_factory=list)

    # Cost tracking
    total_cost_usd: float = 0.0

    @property
    def structural_tests(self) -> list[GeneratedTest]:
        return [t for t in self.generated_tests if "structural" in t.tags]

    @property
    def llm_inferred_tests(self) -> list[GeneratedTest]:
        return [t for t in self.generated_tests if "llm-inferred" in t.tags]

    @property
    def user_rule_tests(self) -> list[GeneratedTest]:
        return [t for t in self.generated_tests if "user-rule" in t.tags]


class IntelligenceEngine:
    """Orchestrates the three-layer intelligence pipeline.

    Parameters
    ----------
    project_dir:
        Root of the project being analysed.
    understanding:
        Optional pre-configured :class:`CodeUnderstanding` instance.
    rules_loader:
        Optional pre-configured :class:`RulesLoader` instance.
    cache:
        Optional pre-configured :class:`UnderstandingCache` instance.
    """

    def __init__(
        self,
        project_dir: Path | None = None,
        understanding: CodeUnderstanding | None = None,
        rules_loader: RulesLoader | None = None,
        cache: UnderstandingCache | None = None,
    ) -> None:
        self.project_dir = project_dir or Path(".")
        self._cache = cache
        self._understanding = understanding or CodeUnderstanding(cache=self._cache or UnderstandingCache())
        self._rules_loader = rules_loader or RulesLoader()
        self._rules_to_tests = RulesToTests()

    async def analyse(
        self,
        scan_result: ScanResult | None = None,
        *,
        understand: bool = False,
        files: list[tuple[str, str]] | None = None,
        on_progress: object | None = None,
    ) -> IntelligenceResult:
        """Run the full intelligence pipeline.

        Parameters
        ----------
        scan_result:
            Layer 1 structural scan result (from the existing scanner).
        understand:
            When ``True``, run LLM understanding (Layer 2) on the provided
            *files*.
        files:
            List of ``(file_path, content)`` tuples for Layer 2 analysis.
        on_progress:
            Optional callback ``(current, total, path)`` for Layer 2 progress.
        """
        result = IntelligenceResult(scan_result=scan_result)
        all_tests: list[GeneratedTest] = []

        # --- Layer 1: Structural tests ---
        if scan_result is not None:
            structural_tests = self._generate_structural_tests(scan_result)
            all_tests.extend(structural_tests)

        # --- Layer 2: LLM Understanding ---
        if understand and files:
            understanding_results = await self._understanding.analyse_files(
                files, on_progress=on_progress
            )
            result.understanding = understanding_results
            result.total_cost_usd = sum(u.cost_usd for u in understanding_results)
            llm_tests = self._generate_llm_tests(understanding_results)
            all_tests.extend(llm_tests)

        # --- Layer 3: User Rules ---
        user_rules = self._rules_loader.load(self.project_dir)
        result.user_rules = user_rules
        if not user_rules.is_empty:
            rule_tests = self._rules_to_tests.generate(user_rules)
            all_tests.extend(rule_tests)

        # --- Deduplicate ---
        result.generated_tests = self._deduplicate(all_tests)

        logger.info(
            "Intelligence complete: %d structural, %d llm-inferred, %d user-rule tests",
            len(result.structural_tests),
            len(result.llm_inferred_tests),
            len(result.user_rule_tests),
        )
        return result

    # ------------------------------------------------------------------ #
    # Layer 1: Structural test generation
    # ------------------------------------------------------------------ #

    def _generate_structural_tests(self, scan: ScanResult) -> list[GeneratedTest]:
        """Generate executable test code from structural scan findings."""
        tests: list[GeneratedTest] = []

        # Tool invocation tests
        for tool in scan.tools:
            name = f"test_tool_{tool.name}_invoked"
            desc = f"Tool {tool.name} should be invoked for relevant input"
            trigger = tool.example_input or f"Use the {tool.name} tool"
            code = (
                f'@agent_test(tags=["structural"])\n'
                f"async def {name}():\n"
                f'    """Verify agent calls {tool.name} when expected."""\n'
                f"    response = await agent.chat({trigger!r})\n"
                f'    expect(response).to_call_tool({tool.name!r})\n'
            )
            tests.append(GeneratedTest(
                name=name,
                code=code,
                tags=["structural"],
                source="structural",
                description=desc,
            ))

        # Prompt presence tests
        for idx, prompt in enumerate(scan.prompts):
            name = f"test_prompt_{idx}_present"
            source_file = prompt.file_path or "unknown"
            desc = f"System prompt from {source_file} should be active"
            preview = prompt.content[:60].replace('"', '\\"').replace("\n", " ")
            code = (
                f'@agent_test(tags=["structural"])\n'
                f"async def {name}():\n"
                f'    """System prompt from {source_file} should be active."""\n'
                f'    response = await agent.chat("Describe your role")\n'
                f'    expect(response).matches_rubric(\n'
                f'        "The response should reflect the system prompt: {preview}"\n'
                f"    )\n"
            )
            tests.append(GeneratedTest(
                name=name,
                code=code,
                tags=["structural"],
                source="structural",
                description=desc,
            ))

        return tests

    # ------------------------------------------------------------------ #
    # Layer 2: LLM-inferred test generation
    # ------------------------------------------------------------------ #

    def _generate_llm_tests(
        self, understanding: list[UnderstandingResult]
    ) -> list[GeneratedTest]:
        """Generate executable test code from LLM understanding results."""
        tests: list[GeneratedTest] = []

        for ur in understanding:
            domain = ur.domain or "general"

            # Invariant tests
            for invariant in ur.invariants:
                slug = _slugify(invariant)
                name = f"test_invariant_{slug}"
                code = (
                    f'@agent_test(tags=["llm-inferred"])\n'
                    f"async def {name}():\n"
                    f'    """{invariant}"""\n'
                    f'    response = await agent.chat("Test the invariant: {invariant}")\n'
                    f"    expect(response).matches_rubric(\n"
                    f'        "Invariant for {domain}: {invariant}"\n'
                    f"    )\n"
                )
                tests.append(GeneratedTest(
                    name=name,
                    code=code,
                    tags=["llm-inferred"],
                    source="llm-inferred",
                    description=f"Invariant: {invariant}",
                ))

            # Failure mode tests
            for fm in ur.failure_modes:
                slug = _slugify(fm)
                name = f"test_failure_mode_{slug}"
                code = (
                    f'@agent_test(tags=["llm-inferred"])\n'
                    f"async def {name}():\n"
                    f'    """Failure mode: {fm}"""\n'
                    f'    response = await agent.chat("Trigger scenario: {fm}")\n'
                    f"    expect(response).matches_rubric(\n"
                    f'        "The agent should handle this failure mode correctly: {fm}"\n'
                    f"    )\n"
                )
                tests.append(GeneratedTest(
                    name=name,
                    code=code,
                    tags=["llm-inferred"],
                    source="llm-inferred",
                    description=f"Failure mode: {fm}",
                ))

            # Edge case tests
            for ec in ur.edge_cases:
                slug = _slugify(ec)
                name = f"test_edge_case_{slug}"
                code = (
                    f'@agent_test(tags=["llm-inferred"])\n'
                    f"async def {name}():\n"
                    f'    """Edge case: {ec}"""\n'
                    f'    response = await agent.chat("Edge case: {ec}")\n'
                    f"    expect(response).matches_rubric(\n"
                    f'        "The agent should handle this edge case gracefully: {ec}"\n'
                    f"    )\n"
                )
                tests.append(GeneratedTest(
                    name=name,
                    code=code,
                    tags=["llm-inferred"],
                    source="llm-inferred",
                    description=f"Edge case: {ec}",
                ))

            # Data validation tests
            for dv in ur.data_validation:
                slug = _slugify(dv)
                name = f"test_data_validation_{slug}"
                code = (
                    f'@agent_test(tags=["llm-inferred"])\n'
                    f"async def {name}():\n"
                    f'    """Data validation: {dv}"""\n'
                    f'    response = await agent.chat("Validate: {dv}")\n'
                    f"    expect(response).matches_rubric(\n"
                    f'        "The agent should enforce data validation: {dv}"\n'
                    f"    )\n"
                )
                tests.append(GeneratedTest(
                    name=name,
                    code=code,
                    tags=["llm-inferred"],
                    source="llm-inferred",
                    description=f"Data validation: {dv}",
                ))

        return tests

    # ------------------------------------------------------------------ #
    # Deduplication
    # ------------------------------------------------------------------ #

    def _deduplicate(self, tests: list[GeneratedTest]) -> list[GeneratedTest]:
        """Remove duplicate tests, keeping the first occurrence.

        Deduplication is by test name.  If two sources produce a test with
        the same name, the first one (higher-priority source) wins.
        """
        seen: set[str] = set()
        unique: list[GeneratedTest] = []
        for test in tests:
            if test.name not in seen:
                seen.add(test.name)
                unique.append(test)
        return unique


def _slugify(text: str, max_len: int = 50) -> str:
    """Convert *text* into a valid Python identifier suffix."""
    import re

    slug = re.sub(r"[^a-zA-Z0-9]+", "_", text.lower()).strip("_")
    return slug[:max_len]
