"""Base assertion interface  -  all assertions inherit from this."""

from __future__ import annotations

from abc import ABC, abstractmethod

from tailtest.models import AgentResponse, AssertionResult


class BaseAssertion(ABC):
    """Abstract base class for all tailtest assertions.

    Subclasses implement ``evaluate`` to inspect an ``AgentResponse`` and
    return a deterministic ``AssertionResult`` (pass/fail with message).

    The ``tier`` attribute controls execution ordering when using
    tier-based evaluation (see ``Expectation.evaluate()``):

    - Tier 1 (default): Deterministic assertions -- free, instant.
    - Tier 2: LLM-judge assertions -- expensive, requires LLM call.
    - Tier 3: Reliability assertions -- most expensive, multiple runs.
    """

    tier: int = 1  # 1=deterministic, 2=llm_judge, 3=reliability

    @abstractmethod
    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        """Evaluate this assertion against the agent response."""
        ...
