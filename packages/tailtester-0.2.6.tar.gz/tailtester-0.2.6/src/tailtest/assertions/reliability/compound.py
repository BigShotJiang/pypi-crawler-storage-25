"""Compound reliability assertion -- product of per-step reliability scores.

For multi-step agents, the overall reliability is the product of individual
step reliabilities.  Example: [0.90, 0.85, 0.97] -> 0.90 * 0.85 * 0.97 = 0.742.

This is critical because humans underestimate how fast compound probabilities
drop: five steps at 90% each yield only 59% end-to-end reliability.
"""

from __future__ import annotations

import math

from tailtest.assertions.base import BaseAssertion
from tailtest.models import AgentResponse, AssertionResult


class CompoundReliabilityAssertion(BaseAssertion):
    """Assert that the compound reliability across steps meets a minimum threshold.

    Takes a list of per-step reliability scores (each 0.0-1.0) and computes
    the product.  Passes if the compound score meets or exceeds *min_compound*.

    Example::

        assertion = CompoundReliabilityAssertion(
            step_scores=[0.90, 0.85, 0.97],
            min_compound=0.80,
        )
        # compound = 0.90 * 0.85 * 0.97 = 0.742 < 0.80 -> FAIL
        result = await assertion.evaluate(response)

    Args:
        step_scores: List of per-step reliability scores (each 0.0-1.0).
        min_compound: Minimum compound reliability to pass (default 0.80).
    """

    tier: int = 3

    def __init__(
        self,
        step_scores: list[float],
        min_compound: float = 0.80,
    ) -> None:
        if not step_scores:
            raise ValueError("step_scores must not be empty")
        for i, score in enumerate(step_scores):
            if not 0.0 <= score <= 1.0:
                raise ValueError(
                    f"step_scores[{i}] = {score} is not in [0.0, 1.0]"
                )
        if not 0.0 <= min_compound <= 1.0:
            raise ValueError("min_compound must be between 0.0 and 1.0")
        self.step_scores = step_scores
        self.min_compound = min_compound

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        """Compute compound reliability as the product of step scores.

        The *response* argument is not used -- compound reliability is
        computed purely from the pre-supplied step scores.
        """
        compound = math.prod(self.step_scores)
        passed = compound >= self.min_compound

        steps_str = " * ".join(f"{s:.2f}" for s in self.step_scores)

        return AssertionResult(
            passed=passed,
            assertion_type="compound_reliability",
            expected=f"Compound reliability >= {self.min_compound:.2f}",
            actual=f"Compound reliability = {compound:.4f}",
            message=(
                f"Compound reliability: {steps_str} = {compound:.4f} "
                f">= {self.min_compound:.2f}"
                if passed
                else (
                    f"Compound reliability FAILED: {steps_str} = {compound:.4f} "
                    f"< {self.min_compound:.2f}"
                )
            ),
            score=compound,
        )
