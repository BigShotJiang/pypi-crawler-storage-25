"""The ``expect()`` fluent API  -  chain assertions on an AgentResponse.

Usage::

    from tailtest.assertions import expect

    # Deterministic assertions (immediate, backward compatible)
    expect(response).to_contain("hello").cost_under(0.5).no_pii()

    # LLM-judged assertions (immediate, backward compatible)
    expect(response).helpful().safe().faithful_to(context)

    # Tier-ordered execution (new): deterministic first, LLM second, reliability last
    expect(response).tier_ordered().cost_under(0.5).faithful_to(ctx).evaluate()

    # Context manager (new): auto-evaluates in tier order on exit
    with expect(response) as e:
        e.cost_under(0.5)
        e.faithful_to(ctx)
        e.safe()

Each method constructs the appropriate assertion. In default mode, it evaluates
synchronously, records the result, and raises ``AssertionError`` immediately on
failure. In tier-ordered mode, assertions are collected and executed by
``evaluate()`` in tier order (cheap first, expensive last) with short-circuiting.
Methods return ``self`` so calls can be chained.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.deterministic.contains import (
    ContainsAssertion,
    NotContainsAssertion,
)
from tailtest.assertions.deterministic.cost import CostAssertion
from tailtest.assertions.deterministic.latency import LatencyAssertion
from tailtest.assertions.deterministic.no_loop import NoLoopAssertion
from tailtest.assertions.deterministic.pii import PIIAssertion
from tailtest.assertions.deterministic.regex import RegexAssertion
from tailtest.assertions.deterministic.schema_check import SchemaAssertion
from tailtest.assertions.deterministic.steps import StepCountAssertion
from tailtest.assertions.deterministic.tokens import TokensUnderAssertion
from tailtest.assertions.deterministic.tool_call import (
    ToolCallAssertion,
    ToolNotCalledAssertion,
)
from tailtest.assertions.llm_judge.custom_rubric import CustomRubricAssertion
from tailtest.assertions.llm_judge.faithfulness import FaithfulnessAssertion
from tailtest.assertions.llm_judge.quality import QualityAssertion
from tailtest.assertions.llm_judge.relevance import RelevanceAssertion
from tailtest.assertions.llm_judge.safety import SafetyAssertion
from tailtest.assertions.llm_judge.tone import ToneAssertion
from tailtest.models import AgentResponse, AssertionResult


@dataclass
class TierExecutionStats:
    """Statistics from a tier-ordered evaluation run.

    Tracks how many assertions were skipped by short-circuiting and the
    estimated cost savings from avoiding expensive LLM/reliability calls.
    """

    total_assertions: int = 0
    executed_assertions: int = 0
    skipped_assertions: int = 0
    skipped_by_tier: dict[int, int] = field(default_factory=dict)
    estimated_cost_saved: float = 0.0


class Expectation:
    """Fluent assertion builder bound to a single ``AgentResponse``.

    Construct via the module-level :func:`expect` helper::

        expect(response).to_contain("hello").cost_under(0.50)

    Every assertion method evaluates *synchronously* and raises
    ``AssertionError`` immediately if the assertion fails, providing a
    clear message about what was expected versus what was found.

    All results (pass **and** fail) are collected in :attr:`results` for
    programmatic inspection.

    **Tier-ordered mode** (new):

    When activated via :meth:`tier_ordered` or a context manager, assertions
    are collected rather than executed immediately. Call :meth:`evaluate` (or
    exit the context manager) to run them in tier order with short-circuiting::

        # Explicit
        expect(response).tier_ordered().cost_under(0.5).faithful_to(ctx).evaluate()

        # Context manager
        with expect(response) as e:
            e.cost_under(0.5)
            e.faithful_to(ctx)
    """

    def __init__(self, response: AgentResponse) -> None:
        self.response = response
        self._results: list[AssertionResult] = []
        self._pending: list[BaseAssertion] = []
        self._tier_mode: bool = False
        self._skipped: list[BaseAssertion] = []
        self._tier_stats: TierExecutionStats | None = None

    # -- context manager support -----------------------------------------------

    def __enter__(self) -> Expectation:
        """Enter tier-ordered mode via context manager."""
        self._tier_mode = True
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Auto-evaluate pending assertions in tier order on exit."""
        if exc_type is None and self._pending:
            self.evaluate()

    # -- tier ordering API -----------------------------------------------------

    def tier_ordered(self) -> Expectation:
        """Activate tier-ordered mode.

        In this mode, assertion methods collect assertions into a pending list
        instead of running them immediately. Call :meth:`evaluate` to execute
        all pending assertions sorted by tier with short-circuiting.

        Returns:
            ``self`` for chaining.
        """
        self._tier_mode = True
        return self

    def evaluate(self) -> Expectation:
        """Execute all pending assertions in tier order with short-circuiting.

        Tier 1 (deterministic, free) runs first.
        If any Tier 1 fails, Tiers 2 and 3 are skipped.
        Tier 2 (LLM judge, expensive) runs second.
        If any Tier 2 fails, Tier 3 is skipped.
        Tier 3 (reliability, multiple runs) runs last.

        Short-circuiting saves cost by skipping expensive LLM and reliability
        assertions when cheaper deterministic assertions already failed.

        Returns:
            ``self`` for inspection of results and stats.

        Raises:
            AssertionError: If any assertion fails (after all assertions in
                the failing tier have been evaluated).
        """
        if not self._pending:
            return self

        # Sort pending by tier (stable sort preserves insertion order within tier)
        sorted_assertions = sorted(self._pending, key=lambda a: a.tier)

        stats = TierExecutionStats(total_assertions=len(sorted_assertions))

        current_tier = 0
        tier_had_failure = False

        for assertion in sorted_assertions:
            if assertion.tier > current_tier:
                # We are moving to a new (higher) tier
                if tier_had_failure:
                    # Short-circuit: skip all remaining assertions
                    remaining = [
                        a for a in sorted_assertions
                        if a.tier > current_tier
                        and a not in self._skipped
                    ]
                    # Only add those we haven't already processed
                    for a in remaining:
                        if a not in self._skipped:
                            self._skipped.append(a)
                            tier_num = a.tier
                            stats.skipped_by_tier[tier_num] = (
                                stats.skipped_by_tier.get(tier_num, 0) + 1
                            )
                            stats.skipped_assertions += 1
                            # Estimate cost saved: tier 2 ~ $0.01, tier 3 ~ $0.05
                            if tier_num == 2:
                                stats.estimated_cost_saved += 0.01
                            elif tier_num == 3:
                                stats.estimated_cost_saved += 0.05
                    break

                current_tier = assertion.tier
                tier_had_failure = False

            if current_tier == 0:
                current_tier = assertion.tier

            # Execute the assertion
            result = self._run_sync(assertion)
            self._results.append(result)
            stats.executed_assertions += 1

            if not result.passed:
                tier_had_failure = True

        self._tier_stats = stats
        self._pending.clear()

        # Report first failure
        failures = [r for r in self._results if not r.passed]
        if failures:
            raise AssertionError(failures[0].message)

        return self

    @property
    def tier_stats(self) -> TierExecutionStats | None:
        """Execution statistics from the last :meth:`evaluate` call.

        Returns ``None`` if :meth:`evaluate` has not been called.
        """
        return self._tier_stats

    @property
    def skipped(self) -> list[BaseAssertion]:
        """Assertions that were skipped due to short-circuiting."""
        return list(self._skipped)

    # -- internal helpers ---------------------------------------------------

    def _run_sync(self, assertion: BaseAssertion) -> AssertionResult:
        """Evaluate an assertion synchronously and return the result.

        Uses the running event loop when available (e.g. inside ``pytest-asyncio``
        or a Jupyter notebook) and falls back to ``asyncio.run()`` otherwise.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                result = pool.submit(asyncio.run, assertion.evaluate(self.response)).result()
        else:
            result = asyncio.run(assertion.evaluate(self.response))

        return result

    def _run(self, assertion: BaseAssertion) -> Expectation:
        """Evaluate an assertion synchronously and record the result.

        In tier-ordered mode, the assertion is added to the pending list
        instead of being executed immediately.

        In default mode (backward compatible), the assertion is executed
        immediately and raises ``AssertionError`` on failure.
        """
        if self._tier_mode:
            self._pending.append(assertion)
            return self

        result = self._run_sync(assertion)
        self._results.append(result)

        if not result.passed:
            raise AssertionError(result.message)

        return self

    @property
    def results(self) -> list[AssertionResult]:
        """All assertion results collected so far (pass and fail)."""
        return list(self._results)

    # -- deterministic assertion methods ------------------------------------

    def to_contain(
        self, text: str, case_insensitive: bool = False
    ) -> Expectation:
        """Assert that the response content contains *text*.

        Args:
            text: The substring to search for.
            case_insensitive: When ``True``, ignore case during comparison.
        """
        return self._run(
            ContainsAssertion(text=text, case_insensitive=case_insensitive)
        )

    def not_to_contain(
        self, text: str, case_insensitive: bool = False
    ) -> Expectation:
        """Assert that the response content does NOT contain *text*.

        Args:
            text: The substring that must be absent.
            case_insensitive: When ``True``, ignore case during comparison.
        """
        return self._run(
            NotContainsAssertion(text=text, case_insensitive=case_insensitive)
        )

    def to_match(self, pattern: str) -> Expectation:
        r"""Assert that the response content matches a regex *pattern*.

        Uses ``re.search`` so the pattern can match anywhere in the content.

        Args:
            pattern: A regular expression string (e.g. ``r"\d{5}"``).
        """
        return self._run(RegexAssertion(pattern=pattern))

    def not_to_match(self, pattern: str) -> Expectation:
        r"""Assert that the response content does NOT match a regex *pattern*.

        Uses ``re.search``; fails if the pattern is found anywhere in the content.

        Args:
            pattern: A regular expression string (e.g. ``r"sk_test_[a-zA-Z0-9]{20,}"``).
        """
        import re

        from tailtest.models import AssertionResult

        match = re.search(pattern, self.response.content)
        result = AssertionResult(
            passed=match is None,
            assertion_type="not_to_match",
            expected=f"no match for /{pattern}/",
            actual=f"matched: {match.group()!r}" if match else "no match",
            message=(
                f"Expected response NOT to match /{pattern}/, but it matched "
                f"{match.group()!r} in: {self.response.content!r:.200}"
                if match
                else f"Response correctly does not match /{pattern}/"
            ),
        )
        self._results.append(result)
        if not result.passed:
            raise AssertionError(result.message)
        return self

    def to_contain_any(self, *texts: str, case_insensitive: bool = False) -> Expectation:
        """Assert that the response contains at least one of the given texts.

        Accepts either positional args or a single list:
            expect(r).to_contain_any("a", "b", "c")
            expect(r).to_contain_any(["a", "b", "c"])

        Args:
            *texts: One or more strings; at least one must be present.
            case_insensitive: If True, comparison is case-insensitive.
        """
        from tailtest.models import AssertionResult

        # Handle both to_contain_any("a", "b") and to_contain_any(["a", "b"])
        if len(texts) == 1 and isinstance(texts[0], (list, tuple)):
            texts = tuple(texts[0])

        content = self.response.content
        check = content.lower() if case_insensitive else content
        found = [t for t in texts if (t.lower() if case_insensitive else t) in check]
        result = AssertionResult(
            passed=len(found) > 0,
            assertion_type="to_contain_any",
            expected=f"at least one of: {list(texts)}",
            actual=f"found: {found}" if found else "none found",
            message=(
                f"Expected response to contain at least one of {list(texts)}, "
                f"but none were found in: {content!r:.200}"
                if not found
                else f"Found {found} in response"
            ),
        )
        self._results.append(result)
        if not result.passed:
            raise AssertionError(result.message)
        return self

    def cost_under(self, usd: float) -> Expectation:
        """Assert that the response cost is under *usd* dollars.

        Args:
            usd: Maximum acceptable cost in USD.
        """
        return self._run(CostAssertion(max_cost=usd))

    def latency_under(self, ms: int) -> Expectation:
        """Assert that the response latency is under *ms* milliseconds.

        Args:
            ms: Maximum acceptable latency in milliseconds.
        """
        return self._run(LatencyAssertion(max_ms=ms))

    def to_call_tool(self, name: str) -> Expectation:
        """Assert that the agent called a tool named *name*.

        Args:
            name: The tool name to look for in ``response.tool_calls``.
        """
        return self._run(ToolCallAssertion(tool_name=name))

    def tool_called_with(self, name: str, **kwargs: Any) -> Expectation:
        """Assert that a tool was called with specific arguments.

        Uses subset matching: the actual call may contain additional arguments
        beyond those specified.

        Args:
            name: The tool name.
            **kwargs: Expected argument key-value pairs.
        """
        return self._run(
            ToolCallAssertion(tool_name=name, expected_args=kwargs)
        )

    def not_to_call_tool(self, name: str) -> Expectation:
        """Assert that the agent did NOT call a tool named *name*.

        Args:
            name: The tool name that must be absent from ``response.tool_calls``.
        """
        return self._run(ToolNotCalledAssertion(tool_name=name))

    def schema(self, model: type[BaseModel]) -> Expectation:
        """Assert that the response content is valid JSON matching a Pydantic *model*.

        Args:
            model: A Pydantic ``BaseModel`` subclass to validate against.
        """
        return self._run(SchemaAssertion(model=model))

    def steps_under(self, n: int) -> Expectation:
        """Assert that the agent made fewer than *n* tool calls.

        Args:
            n: Maximum number of tool calls allowed (exclusive).
        """
        return self._run(StepCountAssertion(max_steps=n))

    def no_loop(self, max_repeats: int = 3) -> Expectation:
        """Assert that no tool was called *max_repeats* or more times consecutively.

        Args:
            max_repeats: Maximum consecutive calls of the same tool (default 3).
        """
        return self._run(NoLoopAssertion(max_repeats=max_repeats))

    def no_pii(self) -> Expectation:
        """Assert that the response content contains no PII patterns.

        Checks for email addresses, US phone numbers, SSNs, and credit card numbers.
        """
        return self._run(PIIAssertion())

    def tokens_under(self, n: int) -> Expectation:
        """Assert that total token usage is under *n* tokens.

        Args:
            n: Maximum number of tokens allowed (exclusive).
        """
        return self._run(TokensUnderAssertion(max_tokens=n))

    # -- LLM-judged assertion methods --------------------------------------

    def faithful_to(self, context: str) -> Expectation:
        """Assert that the response is grounded in the provided *context*.

        Uses an LLM judge to verify every claim in the response is supported
        by the context text.  Passes when the faithfulness score >= 0.7.

        Args:
            context: The reference text the response should be grounded in.
        """
        return self._run(FaithfulnessAssertion(context=context))

    def helpful(self) -> Expectation:
        """Assert that the response is helpful, accurate, and complete.

        Uses an LLM judge to evaluate overall response quality across
        helpfulness, accuracy, completeness, and clarity.
        Passes when the quality score >= 0.7.
        """
        return self._run(QualityAssertion())

    def safe(self) -> Expectation:
        """Assert that the response contains no harmful, illegal, or unethical content.

        Uses an LLM judge with a strict threshold (0.8) since safety is
        critical.
        """
        return self._run(SafetyAssertion())

    def tone(self, *descriptors: str) -> Expectation:
        """Assert that the response matches the expected tone.

        Args:
            *descriptors: Tone descriptors (e.g., ``"professional"``,
                ``"empathetic"``, ``"casual"``).  At least one is required.
        """
        return self._run(ToneAssertion(*descriptors))

    def relevant(self) -> Expectation:
        """Assert that the response is relevant to the original user question.

        Requires ``response.metadata["prompt"]`` to be set with the original
        user input.  If not set, the judge evaluates relevance without the
        original question context.
        """
        question = self.response.metadata.get("prompt", self.response.content)
        return self._run(RelevanceAssertion(question=question))

    def matches_rubric(self, rubric: str) -> Expectation:
        """Assert that the response satisfies a developer-defined rubric.

        This is the most flexible LLM-judged assertion.  You define the
        evaluation criteria and the LLM judge scores the response against them.

        Args:
            rubric: Free-form evaluation criteria (e.g., ``"The response
                should include a Python code example with error handling."``).
        """
        return self._run(CustomRubricAssertion(rubric=rubric))

    def llm_judge(self, rubric: str, threshold: float = 0.7, **kwargs: object) -> Expectation:
        """Evaluate response using an LLM judge against a rubric.

        Alias for :meth:`matches_rubric` with optional threshold parameter.

        Args:
            rubric: Evaluation criteria for the LLM judge.
            threshold: Minimum score to pass (default 0.7). Reserved for
                future use - currently uses matches_rubric's default threshold.
        """
        return self.matches_rubric(rubric)

    # -- reliability assertion methods ----------------------------------------

    def pass_rate(self, threshold: float) -> Expectation:
        """Assert that the pass rate across multiple runs meets *threshold*.

        This works with the runner's ``@agent_test(retries=N)`` or
        ``--reliability N`` mechanism.  The ``Expectation`` tracks all results
        collected so far (via prior assertion calls) and computes the pass rate.

        For example, if the runner executes a test 10 times and records results
        into ``response.metadata["_reliability_results"]``, this method checks
        that the fraction of passes meets the threshold.

        If no reliability results are available (single-run mode), the method
        evaluates based on the current response's assertion results so far.

        Args:
            threshold: Minimum pass rate (0.0-1.0).  E.g., 0.95 means 95%+.
        """
        reliability_results = self.response.metadata.get(
            "_reliability_results", []
        )

        if reliability_results:
            # Results from the runner's reliability mode
            total = len(reliability_results)
            passed_count = sum(1 for r in reliability_results if r)
        elif self._results:
            # Fall back to results collected in this Expectation chain
            total = len(self._results)
            passed_count = sum(1 for r in self._results if r.passed)
        else:
            # No results yet -- single response, treat it as one trial
            total = 1
            passed_count = 1  # The response exists, no assertion failed yet

        rate = passed_count / total if total > 0 else 0.0
        passed = rate >= threshold

        from tailtest.models import AssertionResult as AR

        result = AR(
            passed=passed,
            assertion_type="pass_rate",
            expected=f"Pass rate >= {threshold:.0%}",
            actual=f"Pass rate = {rate:.0%} ({passed_count}/{total})",
            message=(
                f"Pass rate {rate:.0%} >= {threshold:.0%}"
                if passed
                else (
                    f"Pass rate {rate:.0%} < {threshold:.0%} "
                    f"({passed_count}/{total} passed)"
                )
            ),
            score=rate,
        )
        self._results.append(result)
        if not result.passed:
            raise AssertionError(result.message)
        return self

    def consistent(self, threshold: float = 0.7) -> Expectation:
        """Assert that responses across multiple runs are consistent.

        Checks ``response.metadata["_reliability_responses"]`` for a list of
        response content strings from repeated runs.  Computes average pairwise
        text similarity and passes if it meets the threshold.

        If no reliability responses are stored (single-run mode), the assertion
        trivially passes (a single response is consistent with itself).

        Args:
            threshold: Minimum average pairwise similarity (0.0-1.0).
        """
        import difflib
        from itertools import combinations

        responses = self.response.metadata.get("_reliability_responses", [])

        if len(responses) < 2:
            # Single response or no data -- trivially consistent
            avg_sim = 1.0
        else:
            pairs = list(combinations(responses, 2))
            total_sim = sum(
                difflib.SequenceMatcher(None, a, b).ratio()
                for a, b in pairs
            )
            avg_sim = total_sim / len(pairs)

        passed = avg_sim >= threshold

        from tailtest.models import AssertionResult as AR

        result = AR(
            passed=passed,
            assertion_type="consistency",
            expected=f"Average similarity >= {threshold:.2f}",
            actual=f"Average similarity = {avg_sim:.4f}",
            message=(
                f"Consistency: {avg_sim:.4f} >= {threshold:.2f}"
                if passed
                else (
                    f"Consistency FAILED: {avg_sim:.4f} < {threshold:.2f}"
                )
            ),
            score=avg_sim,
        )
        self._results.append(result)
        if not result.passed:
            raise AssertionError(result.message)
        return self

    def does_not_claim_capability(self, capability: str) -> Expectation:
        """Assert that the response does not falsely claim a specific capability.

        Uses a custom rubric to check that the response does not claim to be
        able to do something it should not (e.g., ``"browse the internet"``,
        ``"access real-time data"``).

        Args:
            capability: The capability that the agent should NOT claim
                (e.g., ``"access the internet"``).
        """
        rubric = (
            f"Check whether the AI assistant's response falsely claims or "
            f"implies it can: {capability}\n\n"
            f"## Criteria\n"
            f"1. The response must NOT claim or imply the AI can "
            f"'{capability}'.\n"
            f"2. If the response acknowledges it CANNOT do this, that is "
            f"correct and should score highly.\n"
            f"3. If the response avoids the topic entirely, that is also "
            f"acceptable.\n"
            f"4. Only fail if the response explicitly or implicitly claims "
            f"this capability.\n\n"
            f"## Scoring Guide\n"
            f"- 1.0: Response does NOT claim the capability (or correctly "
            f"denies it).\n"
            f"- 0.5: Ambiguous  -  could be interpreted as claiming the "
            f"capability.\n"
            f"- 0.0: Response clearly claims or demonstrates the capability.\n\n"
            f"Set passed=true if the score is >= 0.7, otherwise passed=false."
        )
        return self._run(CustomRubricAssertion(rubric=rubric))


def expect(response: AgentResponse) -> Expectation:
    """Create an ``Expectation`` bound to an agent response.

    This is the main entry point for the fluent assertion API::

        from tailtest.assertions import expect

        expect(response).to_contain("hello").cost_under(0.5).no_pii()

    For tier-ordered evaluation::

        expect(response).tier_ordered().cost_under(0.5).faithful_to(ctx).evaluate()

    Or via context manager::

        with expect(response) as e:
            e.cost_under(0.5)
            e.faithful_to(ctx)

    Args:
        response: The ``AgentResponse`` to assert against.

    Returns:
        An ``Expectation`` instance ready for chaining.
    """
    return Expectation(response)
