"""Quality assertion  -  checks that a response is helpful, accurate, and complete."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.llm_judge.judge import LLMJudge
from tailtest.config.schema import JudgeConfig
from tailtest.models import AgentResponse, AssertionResult


QUALITY_RUBRIC = """\
Evaluate the overall **quality** of the AI assistant's response.

## Criteria
1. **Helpfulness**: Does the response provide useful, actionable information
   that addresses the user's needs?
2. **Accuracy**: Are the facts, explanations, and recommendations correct?
   Are there any factual errors or misleading statements?
3. **Completeness**: Does the response cover the key aspects of the question
   without omitting important information?
4. **Clarity**: Is the response well-organized, easy to understand, and free
   of unnecessary jargon?

## Scoring Guide
- 1.0: Excellent  -  helpful, accurate, complete, and clearly written.
- 0.7-0.9: Good  -  mostly helpful and accurate with minor gaps.
- 0.4-0.6: Mediocre  -  partially helpful but has notable inaccuracies or
  missing information.
- 0.1-0.3: Poor  -  unhelpful, inaccurate, or severely incomplete.
- 0.0: Useless or actively harmful.

Set passed=true if the score is >= 0.7, otherwise passed=false.
"""


class QualityAssertion(BaseAssertion):
    """Assert that the agent response meets a baseline quality standard.

    Evaluates helpfulness, accuracy, completeness, and clarity.

    Example::

        assertion = QualityAssertion()
        result = await assertion.evaluate(response)
    """

    tier: int = 2

    def __init__(self, config: JudgeConfig | None = None) -> None:
        self._judge = LLMJudge(config)

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        prompt = response.metadata.get("prompt", "")

        judge_result = await self._judge.evaluate(
            prompt=prompt,
            response_text=response.content,
            rubric=QUALITY_RUBRIC,
            threshold=0.7,
        )

        return AssertionResult(
            passed=judge_result.passed,
            assertion_type="quality",
            expected="Helpful, accurate, and complete response",
            actual=judge_result.reason,
            message=(
                f"Quality check {'passed' if judge_result.passed else 'FAILED'} "
                f"(score: {judge_result.score:.2f}): {judge_result.reason}"
            ),
            score=judge_result.score,
            cost_usd=judge_result.cost_usd,
        )
