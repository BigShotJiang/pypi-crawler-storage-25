"""Custom rubric assertion  -  evaluate a response against developer-defined criteria."""

from __future__ import annotations

from tailtest.assertions.base import BaseAssertion
from tailtest.assertions.llm_judge.judge import LLMJudge
from tailtest.config.schema import JudgeConfig
from tailtest.models import AgentResponse, AssertionResult


CUSTOM_RUBRIC_WRAPPER = """\
Evaluate the AI assistant's response against the following **custom rubric**
provided by the developer.

## Developer-Defined Rubric
{rubric}

## Scoring Guide
- 1.0: Fully meets all criteria in the rubric.
- 0.7-0.9: Mostly meets the criteria with minor shortcomings.
- 0.4-0.6: Partially meets the criteria  -  some requirements are met, others
  are not.
- 0.1-0.3: Barely meets any criteria in the rubric.
- 0.0: Completely fails to meet the rubric criteria.

Set passed=true if the score is >= 0.7, otherwise passed=false.
"""


class CustomRubricAssertion(BaseAssertion):
    """Assert that the agent response satisfies a developer-defined rubric.

    This is the most flexible LLM-judged assertion: the developer supplies
    free-form evaluation criteria and the judge scores the response against
    them.

    Example::

        rubric = "The response should include a code example in Python."
        assertion = CustomRubricAssertion(rubric=rubric)
        result = await assertion.evaluate(response)
    """

    tier: int = 2

    def __init__(
        self,
        rubric: str,
        *,
        threshold: float = 0.7,
        config: JudgeConfig | None = None,
    ) -> None:
        self.rubric = rubric
        self.threshold = threshold
        self._judge = LLMJudge(config)

    async def evaluate(self, response: AgentResponse) -> AssertionResult:
        full_rubric = CUSTOM_RUBRIC_WRAPPER.format(rubric=self.rubric)

        prompt = response.metadata.get("prompt", "")

        judge_result = await self._judge.evaluate(
            prompt=prompt,
            response_text=response.content,
            rubric=full_rubric,
            threshold=self.threshold,
        )

        return AssertionResult(
            passed=judge_result.passed,
            assertion_type="custom_rubric",
            expected=f"Matches rubric: {self.rubric[:100]}{'...' if len(self.rubric) > 100 else ''}",
            actual=judge_result.reason,
            message=(
                f"Custom rubric check {'passed' if judge_result.passed else 'FAILED'} "
                f"(score: {judge_result.score:.2f}): {judge_result.reason}"
            ),
            score=judge_result.score,
            cost_usd=judge_result.cost_usd,
        )
