"""Test generator orchestrator.

Coordinates the individual test generators (tool, prompt, safety) to
produce a complete set of auto-generated test files from scan context.
Also integrates intelligence results (LLM understanding + user rules)
when available.
"""

from __future__ import annotations

import logging
from pathlib import Path

from tailtest.config.schema import AgentConfig
from tailtest.generator.prompt_tests import PromptTestGenerator
from tailtest.generator.safety_tests import SafetyTestGenerator
from tailtest.generator.tool_tests import ToolTestGenerator
from tailtest.models import ScanResult

logger = logging.getLogger(__name__)

# Categories that can be selected via --only
CATEGORIES = ("safety", "tools", "prompts", "intelligence", "all")


def _agent_template_vars(agent_cfg: AgentConfig | None) -> tuple[str, str]:
    """Return ``(agent_type, agent_config)`` template variables from config.

    Maps the ``AgentConfig.type`` field to the right ``Agent.from_*()``
    constructor and its argument in generated test code.
    """
    if agent_cfg is None:
        return "http", '"http://localhost:8000/chat"'

    match agent_cfg.type:
        case "cli":
            arg = repr(agent_cfg.command or "echo hello")
            return "cli", arg
        case "python":
            arg = repr(agent_cfg.function or "agent:run")
            return "function", arg
        case _:
            # Default: http
            arg = repr(agent_cfg.url or "http://localhost:8000/chat")
            return "http", arg


class TestGenerator:
    """Orchestrates test generation from scan context.

    Delegates to specialised generators for each test category:

    - :class:`ToolTestGenerator`  -  tests for discovered tools
    - :class:`PromptTestGenerator`  -  tests for discovered prompts
    - :class:`SafetyTestGenerator`  -  baseline safety tests (always generated)

    When intelligence results are provided, also generates tests from
    LLM understanding (Layer 2) and user rules (Layer 3).

    Usage::

        generator = TestGenerator()
        paths = await generator.generate(scan_result, output_dir)
    """

    async def generate(
        self,
        context: ScanResult,
        output_dir: Path,
        regenerate: bool = False,
        only: str = "all",
        intelligence: object | None = None,
        agent_cfg: AgentConfig | None = None,
    ) -> list[Path]:
        """Generate test files from scan context.

        Parameters
        ----------
        context:
            A :class:`ScanResult` containing discovered tools, prompts, and agents.
        output_dir:
            Directory where generated test files will be written
            (typically ``.tailtest/tests/auto/``).
        regenerate:
            If ``True``, overwrite any existing generated test files.
        only:
            Category filter  -  one of ``"all"``, ``"safety"``, ``"tools"``,
            ``"prompts"``, or ``"intelligence"``.
        intelligence:
            Optional :class:`IntelligenceResult` from the intelligence engine,
            providing LLM understanding and user-rule tests.
        agent_cfg:
            Optional :class:`AgentConfig` from tailtest.yaml.  When provided,
            the generated test code uses the correct ``Agent.from_*()``
            constructor instead of always defaulting to ``Agent.from_http()``.

        Returns
        -------
        list[Path]
            Paths to all generated test files.
        """
        output_dir.mkdir(parents=True, exist_ok=True)

        scan_source = ".tailtest/context/scan.json"
        framework = context.framework
        agent_type, agent_config = _agent_template_vars(agent_cfg)

        generated: list[Path] = []

        # Safety tests are always generated (unless filtered out)
        if only in ("all", "safety"):
            safety_gen = SafetyTestGenerator(
                framework=framework,
                scan_source=scan_source,
                agent_type=agent_type,
                agent_config=agent_config,
            )
            generated.extend(
                safety_gen.generate(context, output_dir, regenerate=regenerate)
            )

        # Tool tests  -  only if tools were discovered
        if only in ("all", "tools"):
            tool_gen = ToolTestGenerator(
                framework=framework,
                scan_source=scan_source,
                agent_type=agent_type,
                agent_config=agent_config,
            )
            generated.extend(
                tool_gen.generate(context, output_dir, regenerate=regenerate)
            )

        # Prompt tests  -  only if prompts were discovered
        if only in ("all", "prompts"):
            prompt_gen = PromptTestGenerator(
                framework=framework,
                scan_source=scan_source,
                agent_type=agent_type,
                agent_config=agent_config,
            )
            generated.extend(
                prompt_gen.generate(context, output_dir, regenerate=regenerate)
            )

        # Intelligence tests  -  from LLM understanding and user rules
        if only in ("all", "intelligence") and intelligence is not None:
            intel_paths = self._generate_intelligence_tests(
                intelligence, output_dir, regenerate=regenerate
            )
            generated.extend(intel_paths)

        if generated:
            logger.info(
                "Generated %d test file(s) in %s", len(generated), output_dir
            )
        else:
            logger.info("No test files generated (nothing new to create).")

        return generated

    def _generate_intelligence_tests(
        self,
        intelligence: object,
        output_dir: Path,
        regenerate: bool = False,
    ) -> list[Path]:
        """Write intelligence-derived tests to files.

        Generates separate files for LLM-inferred and user-rule tests,
        each tagged with their source.
        """
        from tailtest.intelligence.engine import IntelligenceResult

        if not isinstance(intelligence, IntelligenceResult):
            return []

        paths: list[Path] = []

        # User-rule tests file
        if intelligence.user_rules and not intelligence.user_rules.is_empty:
            from tailtest.intelligence.rules_to_tests import RulesToTests

            converter = RulesToTests()
            content = converter.generate_file(intelligence.user_rules)
            if content:
                rule_path = output_dir / "test_user_rules.py"
                if not rule_path.exists() or regenerate:
                    rule_path.write_text(content, encoding="utf-8")
                    logger.info("Generated user-rule tests: %s", rule_path)
                    paths.append(rule_path)

        # LLM-inferred tests file
        llm_tests = intelligence.llm_inferred_tests
        if llm_tests:
            lines = [
                '"""Auto-generated tests from LLM code understanding (Layer 2)."""',
                "",
                "import pytest",
                "",
                "from tailtest.assertions.expect import expect",
                "from tailtest.models import AgentResponse",
                "",
                "",
            ]
            for test in llm_tests:
                tag_str = ", ".join(f'"{t}"' for t in test.tags)
                lines.append(
                    f'@pytest.mark.parametrize("tags", [[{tag_str}]])'
                )
                lines.append(f"async def {test.name}(agent):")
                lines.append(f'    """{test.description}"""')
                lines.append(f"    response = await agent.chat({test.description!r})")
                lines.append(f"    expect(response).matches_rubric(")
                lines.append(f"        {test.description!r}")
                lines.append(f"    )")
                lines.append("")
                lines.append("")

            content = "\n".join(lines).rstrip() + "\n"
            llm_path = output_dir / "test_llm_inferred.py"
            if not llm_path.exists() or regenerate:
                llm_path.write_text(content, encoding="utf-8")
                logger.info("Generated LLM-inferred tests: %s", llm_path)
                paths.append(llm_path)

        return paths
