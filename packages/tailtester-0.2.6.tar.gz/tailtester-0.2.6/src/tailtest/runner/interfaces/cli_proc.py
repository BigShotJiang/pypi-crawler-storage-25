"""Agent interface that communicates via a CLI subprocess."""

from __future__ import annotations

import asyncio
import re
import shlex
import time

from tailtest.models import AgentResponse, Message
from tailtest.runner.interfaces.base import BaseAgentInterface

# Regex to strip quotes immediately surrounding {{input}} in a template.
# Handles: "{{input}}", '{{input}}', \"{{input}}\"
_TEMPLATE_QUOTE_RE = re.compile(
    r"""\\?"{{input}}\\?"|"""    # \"{{input}}\" or "{{input}}"
    r"""\\?'{{input}}\\?'|"""    # \'{{input}}\' or '{{input}}'
    r"""{{input}}""",            # bare {{input}}
)


def _prepare_template(raw_command: str) -> str:
    """Strip any quotes immediately surrounding ``{{input}}`` in *raw_command*.

    This lets us unconditionally replace ``{{input}}`` with a
    :func:`shlex.quote`-d value so escaping is always correct regardless
    of what the user wrote in their YAML template.
    """

    def _strip_surrounding_quotes(m: re.Match[str]) -> str:
        return "{{input}}"

    return _TEMPLATE_QUOTE_RE.sub(_strip_surrounding_quotes, raw_command)


class CLIInterface(BaseAgentInterface):
    """Run an agent as a subprocess, piping input through stdin.

    Parameters
    ----------
    command:
        Shell command (string) or argument list to spawn.  When given as
        a string it is parsed with :func:`shlex.split`.
    timeout:
        Maximum seconds to wait for the process to produce output and
        exit.  Defaults to 30.
    """

    def __init__(
        self,
        command: str | list[str],
        timeout: float = 30.0,
    ) -> None:
        # Keep the raw command string for template substitution ({{input}})
        # shlex.split mangles nested quotes in SSH commands
        if isinstance(command, str):
            self._raw_command: str = command
            self._args: list[str] = shlex.split(command)
        else:
            self._raw_command = " ".join(command)
            self._args = list(command)
        self.timeout = timeout
        self._process: asyncio.subprocess.Process | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def chat(self, message: str) -> AgentResponse:
        """Spawn the command, write *message* to stdin, collect stdout.

        If the command contains ``{{input}}``, the placeholder is replaced
        with the message and stdin is closed immediately (useful for SSH
        commands where the message must be part of the command string).
        Otherwise the message is piped through stdin.
        """
        start = time.perf_counter()

        # Check if command uses template substitution
        uses_template = "{{input}}" in self._raw_command

        try:
            if uses_template:
                # Substitute {{input}} in the ORIGINAL command string and run via shell.
                # 1. Strip any user-supplied quotes around {{input}} so we don't
                #    double-quote.
                # 2. Use shlex.quote() which handles all edge cases (spaces,
                #    special chars, nested SSH quoting).
                prepared = _prepare_template(self._raw_command)
                escaped = shlex.quote(message)
                cmd = prepared.replace("{{input}}", escaped)
                process = await asyncio.create_subprocess_shell(
                    cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                self._process = process
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.timeout,
                )
            else:
                # Pipe message through stdin
                process = await asyncio.create_subprocess_exec(
                    *self._args,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                self._process = process
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(input=message.encode()),
                    timeout=self.timeout,
                )
            elapsed_ms = (time.perf_counter() - start) * 1000

            stdout_text = stdout_bytes.decode(errors="replace").strip()
            stderr_text = stderr_bytes.decode(errors="replace").strip()

            # Use stderr as fallback when stdout is empty (some agents
            # print responses to stderr instead of stdout)
            content = stdout_text or stderr_text

            metadata: dict[str, object] = {
                "exit_code": process.returncode,
                "stdout_length": len(stdout_text),
                "stderr_length": len(stderr_text),
            }
            if stderr_text and stdout_text:
                metadata["stderr"] = stderr_text
            if not stdout_text and stderr_text:
                metadata["source"] = "stderr"

            if process.returncode != 0:
                metadata["error"] = f"process exited with code {process.returncode}"

            return AgentResponse(
                content=content,
                latency_ms=elapsed_ms,
                metadata=metadata,
            )

        except asyncio.TimeoutError:
            elapsed_ms = (time.perf_counter() - start) * 1000
            await self._kill_process()
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={
                    "error": "timeout",
                    "outcome": "TIMEOUT",
                    "timeout_seconds": self.timeout,
                    "detail": (
                        f"Agent did not respond within {self.timeout}s. "
                        "This may indicate an infinite tool-call loop or "
                        "LLM processing delay."
                    ),
                },
            )
        except FileNotFoundError:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={
                    "error": "command_not_found",
                    "command": self._args,
                },
            )
        except OSError as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return AgentResponse(
                content="",
                latency_ms=elapsed_ms,
                metadata={
                    "error": "os_error",
                    "detail": str(exc),
                },
            )

    async def conversation(self, messages: list[Message]) -> AgentResponse:
        """Replay a multi-turn conversation.

        Since a subprocess is spawned fresh for each invocation, only the
        last user message is sent.
        """
        last_user_msg = ""
        for msg in reversed(messages):
            if msg.role == "user":
                last_user_msg = msg.content
                break

        if not last_user_msg:
            return AgentResponse(content="", metadata={"error": "no user message found"})

        return await self.chat(last_user_msg)

    async def close(self) -> None:
        """Terminate any lingering subprocess."""
        await self._kill_process()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _kill_process(self) -> None:
        """Best-effort termination of the current subprocess."""
        if self._process is None:
            return
        try:
            self._process.kill()
            await self._process.wait()
        except ProcessLookupError:
            pass
        finally:
            self._process = None

    def __repr__(self) -> str:
        cmd_display = " ".join(self._args)
        return f"CLIInterface(command={cmd_display!r})"
