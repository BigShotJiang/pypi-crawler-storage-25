"""CloudAnalyzer CLI package."""
