"""Tests for config-driven QA check suites."""

import json
from pathlib import Path
from textwrap import dedent

import numpy as np
import open3d as o3d
import pytest

from ca.core import load_check_suite, run_check_suite
from ca.core.check_triage import build_check_triage_request


def _write_csv_trajectory(path: Path, rows: list[tuple[float, float, float, float]]) -> str:
    lines = ["timestamp,x,y,z"]
    lines.extend(f"{timestamp},{x},{y},{z}" for timestamp, x, y, z in rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(path)


def _write_tum_trajectory(path: Path, rows: list[tuple[float, float, float, float]]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "\n".join(f"{timestamp} {x} {y} {z} 0 0 0 1" for timestamp, x, y, z in rows) + "\n",
        encoding="utf-8",
    )
    return str(path)


def _write_config(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(dedent(text).strip() + "\n", encoding="utf-8")
    return path


def _write_pcd(path: Path, points: list[list[float]]) -> str:
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(np.array(points, dtype=np.float64))
    path.parent.mkdir(parents=True, exist_ok=True)
    o3d.io.write_point_cloud(str(path), pcd)
    return str(path)


def _write_json(path: Path, data: dict) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(path)


def _write_valid_g2o(path: Path) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "\n".join(
            [
                "VERTEX_SE3:QUAT 0 0 0 0 0 0 0 1",
                "VERTEX_SE3:QUAT 1 1 0 0 0 0 0 1",
                "VERTEX_SE3:QUAT 2 2 0 0 0 0 0 1",
                "EDGE_SE3:QUAT 0 1 1 0 0 0 0 0 1 " + " ".join(["1"] * 21),
                "EDGE_SE3:QUAT 1 2 1 0 0 0 0 0 1 " + " ".join(["1"] * 21),
                "",
            ]
        ),
        encoding="utf-8",
    )
    return str(path)


def _write_bad_g2o(path: Path) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "\n".join(
            [
                "VERTEX_SE3:QUAT 0 0 0 0 0 0 0 1",
                "EDGE_SE3:QUAT 0 99 1 0 0 0 0 0 1 " + " ".join(["1"] * 21),
                "",
            ]
        ),
        encoding="utf-8",
    )
    return str(path)


class TestLoadCheckSuite:
    def test_merges_defaults_and_resolves_relative_paths(self, tmp_path: Path):
        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            """
            version: 1
            project: demo-stack
            summary_output_json: qa/summary.json
            defaults:
              thresholds: [0.2, 0.05, 0.1]
              max_time_delta: 0.1
              alignment: rigid
              report_dir: qa/reports
              json_dir: qa/results
              gate:
                min_auc: 0.95
                max_ate: 0.5
            checks:
              - id: perception-output
                kind: map
                source: outputs/map.pcd
                reference: refs/map_ref.pcd
              - kind: trajectory
                estimated: outputs/traj.csv
                reference: refs/traj_ref.csv
                gate:
                  max_rpe: 0.2
                  min_coverage: 0.9
            """,
        )

        suite = load_check_suite(str(config))

        assert suite.project == "demo-stack"
        assert suite.summary_output_json == str((tmp_path / "qa" / "summary.json").resolve())
        assert len(suite.checks) == 2

        artifact_check = suite.checks[0]
        assert artifact_check.kind == "artifact"
        assert artifact_check.thresholds == (0.05, 0.1, 0.2)
        assert artifact_check.alignment == "rigid"
        assert artifact_check.gate == {"min_auc": 0.95}
        assert artifact_check.inputs["source"] == str((tmp_path / "outputs" / "map.pcd").resolve())
        assert artifact_check.outputs.report_path == str(
            (tmp_path / "qa" / "reports" / "perception-output.html").resolve()
        )
        assert artifact_check.outputs.json_path == str(
            (tmp_path / "qa" / "results" / "perception-output.json").resolve()
        )

        trajectory_check = suite.checks[1]
        assert trajectory_check.kind == "trajectory"
        assert trajectory_check.alignment == "rigid"
        assert trajectory_check.max_time_delta == pytest.approx(0.1)
        assert trajectory_check.gate == {
            "max_ate": 0.5,
            "max_rpe": 0.2,
            "min_coverage": 0.9,
        }

    def test_rejects_unknown_kind(self, tmp_path: Path):
        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            """
            checks:
              - kind: mystery
                source: a.pcd
                reference: b.pcd
            """,
        )

        with pytest.raises(ValueError, match="Unsupported check.kind"):
            load_check_suite(str(config))

    def test_requires_non_empty_checks(self, tmp_path: Path):
        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            """
            checks: []
            """,
        )

        with pytest.raises(ValueError, match="checks must contain at least one item"):
            load_check_suite(str(config))


class TestRunCheckSuite:
    def test_runs_single_checks_and_writes_outputs(
        self,
        tmp_path: Path,
        identical_pcd,
    ):
        map_path = tmp_path / "artifacts" / "map.pcd"
        map_reference = tmp_path / "refs" / "map_ref.pcd"
        map_path.parent.mkdir(parents=True, exist_ok=True)
        map_reference.parent.mkdir(parents=True, exist_ok=True)
        o3d.io.write_point_cloud(str(map_path), identical_pcd)
        o3d.io.write_point_cloud(str(map_reference), identical_pcd)

        trajectory_path = _write_csv_trajectory(
            tmp_path / "trajectories" / "estimated.csv",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )
        trajectory_reference = _write_csv_trajectory(
            tmp_path / "trajectories" / "reference.csv",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )

        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            version: 1
            project: qa-platform
            summary_output_json: qa/summary.json
            defaults:
              report_dir: qa/reports
              json_dir: qa/results
            checks:
              - id: perception-output
                kind: artifact
                source: {map_path.relative_to(tmp_path)}
                reference: {map_reference.relative_to(tmp_path)}
                gate:
                  min_auc: 0.95
                  max_chamfer: 0.01
              - id: localization-run
                kind: trajectory
                estimated: {Path(trajectory_path).relative_to(tmp_path)}
                reference: {Path(trajectory_reference).relative_to(tmp_path)}
                gate:
                  max_ate: 0.1
                  max_rpe: 0.1
                  max_drift: 0.1
                  min_coverage: 1.0
              - id: integrated-run
                kind: run
                map: {map_path.relative_to(tmp_path)}
                map_reference: {map_reference.relative_to(tmp_path)}
                trajectory: {Path(trajectory_path).relative_to(tmp_path)}
                trajectory_reference: {Path(trajectory_reference).relative_to(tmp_path)}
                gate:
                  min_auc: 0.95
                  max_chamfer: 0.01
                  max_ate: 0.1
                  max_rpe: 0.1
                  max_drift: 0.1
                  min_coverage: 1.0
            """,
        )

        result = run_check_suite(load_check_suite(str(config)))

        assert result["summary"]["passed"] is True
        assert result["summary"]["passed_checks"] == 3
        assert result["summary"]["failed_checks"] == 0
        assert [item["kind"] for item in result["checks"]] == [
            "artifact",
            "trajectory",
            "run",
        ]
        assert (tmp_path / "qa" / "summary.json").exists()
        assert (tmp_path / "qa" / "reports" / "perception-output.html").exists()
        assert (tmp_path / "qa" / "results" / "perception-output.json").exists()
        assert (tmp_path / "qa" / "reports" / "localization-run.html").exists()
        assert (tmp_path / "qa" / "reports" / "integrated-run.html").exists()
        assert result["checks"][0]["result"]["inspect"]["web_heatmap"].startswith("ca web ")

    def test_runs_batch_checks(self, tmp_path: Path, identical_pcd):
        artifact_dir = tmp_path / "artifacts"
        map_dir = tmp_path / "maps"
        map_reference_dir = tmp_path / "map_refs"
        trajectory_dir = tmp_path / "trajectories"
        trajectory_reference_dir = tmp_path / "trajectory_refs"
        trajectory_batch_dir = tmp_path / "trajectory_batch"
        trajectory_batch_reference_dir = tmp_path / "trajectory_batch_refs"
        for directory in [
            artifact_dir,
            map_dir,
            map_reference_dir,
            trajectory_dir,
            trajectory_reference_dir,
            trajectory_batch_dir,
            trajectory_batch_reference_dir,
        ]:
            directory.mkdir(parents=True, exist_ok=True)

        reference_map = tmp_path / "reference_map.pcd"
        artifact_path = artifact_dir / "candidate.pcd"
        run_map_path = map_dir / "run1.pcd"
        run_map_reference_path = map_reference_dir / "run1.pcd"
        for path in [reference_map, artifact_path, run_map_path, run_map_reference_path]:
            o3d.io.write_point_cloud(str(path), identical_pcd)

        _write_csv_trajectory(
            trajectory_batch_dir / "run1.csv",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )
        _write_csv_trajectory(
            trajectory_batch_reference_dir / "run1.csv",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )
        _write_csv_trajectory(
            trajectory_dir / "run1.csv",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )
        _write_csv_trajectory(
            trajectory_reference_dir / "run1.csv",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )

        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            defaults:
              report_dir: qa/reports
              json_dir: qa/results
            checks:
              - id: artifact-batch
                kind: artifact_batch
                directory: {artifact_dir.relative_to(tmp_path)}
                reference: {reference_map.relative_to(tmp_path)}
                gate:
                  min_auc: 0.95
              - id: trajectory-batch
                kind: trajectory_batch
                directory: {trajectory_batch_dir.relative_to(tmp_path)}
                reference_dir: {trajectory_batch_reference_dir.relative_to(tmp_path)}
                gate:
                  max_ate: 0.1
                  max_rpe: 0.1
                  max_drift: 0.1
                  min_coverage: 1.0
              - id: run-batch
                kind: run_batch
                map_dir: {map_dir.relative_to(tmp_path)}
                map_reference_dir: {map_reference_dir.relative_to(tmp_path)}
                trajectory_dir: {trajectory_dir.relative_to(tmp_path)}
                trajectory_reference_dir: {trajectory_reference_dir.relative_to(tmp_path)}
                gate:
                  min_auc: 0.95
                  max_ate: 0.1
                  max_rpe: 0.1
                  max_drift: 0.1
                  min_coverage: 1.0
            """,
        )

        result = run_check_suite(load_check_suite(str(config)))

        assert result["summary"]["passed"] is True
        assert result["summary"]["passed_checks"] == 3
        assert result["checks"][0]["summary"]["total_files"] == 1
        assert result["checks"][1]["summary"]["total_files"] == 1
        assert result["checks"][2]["summary"]["total_runs"] == 1
        assert (tmp_path / "qa" / "reports" / "artifact-batch.html").exists()
        assert (tmp_path / "qa" / "reports" / "trajectory-batch.html").exists()
        assert (tmp_path / "qa" / "reports" / "run-batch.html").exists()

    def test_marks_failed_checks(self, tmp_path: Path, identical_pcd, shifted_pcd):
        map_path = tmp_path / "map.pcd"
        map_reference = tmp_path / "map_ref.pcd"
        o3d.io.write_point_cloud(str(map_path), shifted_pcd)
        o3d.io.write_point_cloud(str(map_reference), identical_pcd)

        trajectory_path = _write_csv_trajectory(
            tmp_path / "traj.csv",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.4, 0.0, 0.0)],
        )
        trajectory_reference = _write_csv_trajectory(
            tmp_path / "traj_ref.csv",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )

        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            checks:
              - id: bad-artifact
                kind: artifact
                source: {map_path.relative_to(tmp_path)}
                reference: {map_reference.relative_to(tmp_path)}
                gate:
                  min_auc: 0.99
                  max_chamfer: 0.01
              - id: bad-trajectory
                kind: trajectory
                estimated: {Path(trajectory_path).relative_to(tmp_path)}
                reference: {Path(trajectory_reference).relative_to(tmp_path)}
                gate:
                  max_ate: 0.05
                  max_rpe: 0.05
                  max_drift: 0.05
                  min_coverage: 1.0
            """,
        )

        result = run_check_suite(load_check_suite(str(config)))

        assert result["summary"]["passed"] is False
        assert result["summary"]["failed_checks"] == 2
        assert result["summary"]["failed_check_ids"] == ["bad-artifact", "bad-trajectory"]
        assert result["summary"]["triage"]["strategy"] == "severity_weighted"
        assert result["summary"]["triage"]["failed_count"] == 2
        assert set(result["summary"]["triage"]["ranked_ids"]) == {
            "bad-artifact",
            "bad-trajectory",
        }

    def test_runs_ground_check(self, tmp_path: Path):
        ground = [[0, 0, 0], [1, 0, 0], [2, 0, 0]]
        nonground = [[0, 0, 2], [1, 0, 2], [2, 0, 2]]
        est_ground = _write_pcd(tmp_path / "est_g.pcd", ground)
        est_nonground = _write_pcd(tmp_path / "est_ng.pcd", nonground)
        ref_ground = _write_pcd(tmp_path / "ref_g.pcd", ground)
        ref_nonground = _write_pcd(tmp_path / "ref_ng.pcd", nonground)

        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            checks:
              - id: ground-seg
                kind: ground
                estimated_ground: {Path(est_ground).relative_to(tmp_path)}
                estimated_nonground: {Path(est_nonground).relative_to(tmp_path)}
                reference_ground: {Path(ref_ground).relative_to(tmp_path)}
                reference_nonground: {Path(ref_nonground).relative_to(tmp_path)}
                gate:
                  min_f1: 0.9
                  min_iou: 0.8
            """,
        )

        result = run_check_suite(load_check_suite(str(config)))

        assert result["summary"]["passed"] is True
        assert result["summary"]["gated_checks"] == 1
        ground_check = result["checks"][0]
        assert ground_check["id"] == "ground-seg"
        assert ground_check["kind"] == "ground"
        assert ground_check["passed"] is True
        assert ground_check["summary"]["f1"] == pytest.approx(1.0)
        assert ground_check["summary"]["iou"] == pytest.approx(1.0)

    def test_runs_ground_check_with_report_output_and_voxel_size(self, tmp_path: Path):
        ground = [[0, 0, 0], [1, 0, 0], [2, 0, 0]]
        nonground = [[0, 0, 2], [1, 0, 2], [2, 0, 2]]
        est_ground = _write_pcd(tmp_path / "est_g.pcd", ground)
        est_nonground = _write_pcd(tmp_path / "est_ng.pcd", nonground)
        ref_ground = _write_pcd(tmp_path / "ref_g.pcd", ground)
        ref_nonground = _write_pcd(tmp_path / "ref_ng.pcd", nonground)

        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            defaults:
              report_dir: qa/reports
            checks:
              - id: ground-seg
                kind: ground
                estimated_ground: {Path(est_ground).relative_to(tmp_path)}
                estimated_nonground: {Path(est_nonground).relative_to(tmp_path)}
                reference_ground: {Path(ref_ground).relative_to(tmp_path)}
                reference_nonground: {Path(ref_nonground).relative_to(tmp_path)}
                gate:
                  voxel_size: 0.5
                  min_f1: 0.9
            """,
        )

        result = run_check_suite(load_check_suite(str(config)))

        ground_check = result["checks"][0]
        assert ground_check["passed"] is True
        assert ground_check["report_path"] == str(
            (tmp_path / "qa" / "reports" / "ground-seg.html").resolve()
        )
        assert (tmp_path / "qa" / "reports" / "ground-seg.html").exists()

    def test_runs_loop_closure_check_with_posegraph_gate(self, tmp_path: Path):
        before_dir = tmp_path / "before"
        after_dir = tmp_path / "after"
        ref_dir = tmp_path / "reference"
        ref_points = [[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0]]
        before_points = [[x + 0.25, y, z] for x, y, z in ref_points]
        _write_pcd(before_dir / "map.pcd", before_points)
        _write_pcd(after_dir / "map.pcd", ref_points)
        _write_pcd(ref_dir / "map.pcd", ref_points)
        _write_valid_g2o(before_dir / "pose_graph.g2o")
        _write_valid_g2o(after_dir / "pose_graph.g2o")
        (before_dir / "key_point_frame").mkdir()
        (after_dir / "key_point_frame").mkdir()
        _write_pcd(before_dir / "key_point_frame" / "000000.pcd", [[0.2, 0, 0]])
        _write_pcd(after_dir / "key_point_frame" / "000000.pcd", [[0, 0, 0]])
        before_traj = _write_tum_trajectory(
            before_dir / "optimized_poses_tum.txt",
            [(0.0, 0.2, 0.0, 0.0), (1.0, 1.2, 0.0, 0.0), (2.0, 2.2, 0.0, 0.0)],
        )
        after_traj = _write_tum_trajectory(
            after_dir / "optimized_poses_tum.txt",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )
        ref_traj = _write_tum_trajectory(
            ref_dir / "trajectory.tum",
            [(0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0), (2.0, 2.0, 0.0, 0.0)],
        )

        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            defaults:
              report_dir: qa/reports
              json_dir: qa/results
            checks:
              - id: manual-loop
                kind: loop_closure
                before_session_root: {before_dir.relative_to(tmp_path)}
                after_session_root: {after_dir.relative_to(tmp_path)}
                reference_map: {Path(ref_dir / "map.pcd").relative_to(tmp_path)}
                before_traj: {Path(before_traj).relative_to(tmp_path)}
                after_traj: {Path(after_traj).relative_to(tmp_path)}
                ref_traj: {Path(ref_traj).relative_to(tmp_path)}
                thresholds: [0.05, 0.1, 0.2, 0.5]
                gate:
                  min_auc_gain: 0.01
                  min_ate_gain: 0.05
                  require_posegraph_ok: true
            """,
        )

        suite = load_check_suite(str(config))
        assert suite.checks[0].kind == "loop_closure"
        assert suite.checks[0].gate["require_posegraph_ok"] is True
        result = run_check_suite(suite)

        assert result["summary"]["passed"] is True
        assert result["summary"]["passed_checks"] == 1
        check = result["checks"][0]
        assert check["passed"] is True
        assert check["summary"]["map_auc_gain"] > 0
        assert check["summary"]["trajectory_ate_gain"] > 0
        assert check["summary"]["posegraph_before_ok"] is True
        assert check["summary"]["posegraph_after_ok"] is True
        assert (tmp_path / "qa" / "reports" / "manual-loop.html").exists()
        assert (tmp_path / "qa" / "results" / "manual-loop.json").exists()

    def test_loop_closure_check_can_fail_on_posegraph_gate(self, tmp_path: Path):
        ref_points = [[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0]]
        before_map = _write_pcd(tmp_path / "before.pcd", ref_points)
        after_map = _write_pcd(tmp_path / "after.pcd", ref_points)
        ref_map = _write_pcd(tmp_path / "ref.pcd", ref_points)
        bad_g2o = _write_bad_g2o(tmp_path / "bad.g2o")

        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            checks:
              - id: bad-loop
                kind: loop_closure
                before_map: {Path(before_map).relative_to(tmp_path)}
                after_map: {Path(after_map).relative_to(tmp_path)}
                reference_map: {Path(ref_map).relative_to(tmp_path)}
                after_g2o: {Path(bad_g2o).relative_to(tmp_path)}
                gate:
                  require_posegraph_ok: true
            """,
        )

        result = run_check_suite(load_check_suite(str(config)))

        assert result["summary"]["passed"] is False
        assert result["summary"]["failed_check_ids"] == ["bad-loop"]
        check = result["checks"][0]
        assert check["passed"] is False
        assert check["summary"]["posegraph_after_ok"] is False
        assert "bad-loop" in result["summary"]["triage"]["ranked_ids"]

    def test_runs_detection_and_tracking_checks(self, tmp_path: Path):
        detection_reference = _write_json(
            tmp_path / "refs" / "detection_ref.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "center": [0.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                    {
                        "frame_id": "0002",
                        "boxes": [
                            {"label": "car", "center": [1.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                ]
            },
        )
        detection_estimated = _write_json(
            tmp_path / "outputs" / "detection_est.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "center": [0.0, 0.1, 0.0], "size": [2.0, 2.0, 2.0], "score": 0.9},
                        ],
                    },
                    {
                        "frame_id": "0002",
                        "boxes": [
                            {"label": "car", "center": [1.0, 0.0, 0.1], "size": [2.0, 2.0, 2.0], "score": 0.8},
                        ],
                    },
                ]
            },
        )
        tracking_reference = _write_json(
            tmp_path / "refs" / "tracking_ref.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "track_id": "gt-car", "center": [0.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                    {
                        "frame_id": "0002",
                        "boxes": [
                            {"label": "car", "track_id": "gt-car", "center": [1.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                ]
            },
        )
        tracking_estimated = _write_json(
            tmp_path / "outputs" / "tracking_est.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "track_id": "pred-a", "center": [0.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                    {
                        "frame_id": "0002",
                        "boxes": [
                            {"label": "car", "track_id": "pred-a", "center": [1.0, 0.0, 0.1], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                ]
            },
        )

        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            defaults:
              report_dir: qa/reports
              json_dir: qa/results
            checks:
              - id: detection-out
                kind: detection
                estimated: {Path(detection_estimated).relative_to(tmp_path)}
                reference: {Path(detection_reference).relative_to(tmp_path)}
                thresholds: [0.25, 0.5]
                gate:
                  min_map: 0.9
                  min_recall: 0.9
              - id: tracking-out
                kind: tracking
                estimated: {Path(tracking_estimated).relative_to(tmp_path)}
                reference: {Path(tracking_reference).relative_to(tmp_path)}
                thresholds: [0.5]
                gate:
                  min_mota: 0.9
                  min_recall: 0.9
                  max_id_switches: 0
            """,
        )

        result = run_check_suite(load_check_suite(str(config)))

        assert result["summary"]["passed"] is True
        assert result["summary"]["passed_checks"] == 2
        assert result["checks"][0]["kind"] == "detection"
        assert result["checks"][0]["summary"]["map"] == pytest.approx(1.0)
        assert result["checks"][1]["kind"] == "tracking"
        assert result["checks"][1]["summary"]["mota"] == pytest.approx(1.0)
        assert (tmp_path / "qa" / "reports" / "detection-out.html").exists()
        assert (tmp_path / "qa" / "reports" / "tracking-out.html").exists()

    def test_detection_triage_propagates_gate(self, tmp_path: Path):
        """Failed detection check should propagate gate data to triage."""
        detection_reference = _write_json(
            tmp_path / "refs" / "det_ref.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "center": [0.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                ]
            },
        )
        detection_estimated = _write_json(
            tmp_path / "outputs" / "det_est.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "center": [5.0, 5.0, 5.0], "size": [2.0, 2.0, 2.0], "score": 0.9},
                        ],
                    },
                ]
            },
        )
        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            defaults:
              report_dir: qa/reports
              json_dir: qa/results
            checks:
              - id: det-fail
                kind: detection
                estimated: {Path(detection_estimated).relative_to(tmp_path)}
                reference: {Path(detection_reference).relative_to(tmp_path)}
                thresholds: [0.5]
                gate:
                  min_map: 0.9
                  min_recall: 0.9
            """,
        )
        result = run_check_suite(load_check_suite(str(config)))
        assert result["summary"]["passed"] is False
        triage_req = build_check_triage_request(result["checks"])
        assert len(triage_req.failed_items) == 1
        item = triage_req.failed_items[0]
        assert item.gate  # gate dict should not be empty
        assert item.reasons  # reasons should be populated

    def test_tracking_rejects_multiple_thresholds(self, tmp_path: Path):
        """Tracking check should reject configs with multiple thresholds."""
        tracking_reference = _write_json(
            tmp_path / "refs" / "trk_ref.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "track_id": "gt-1", "center": [0.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                ]
            },
        )
        tracking_estimated = _write_json(
            tmp_path / "outputs" / "trk_est.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "track_id": "p-1", "center": [0.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                ]
            },
        )
        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            defaults:
              report_dir: qa/reports
              json_dir: qa/results
            checks:
              - id: trk-multi
                kind: tracking
                estimated: {Path(tracking_estimated).relative_to(tmp_path)}
                reference: {Path(tracking_reference).relative_to(tmp_path)}
                thresholds: [0.25, 0.5]
                gate:
                  min_mota: 0.5
            """,
        )
        with pytest.raises(ValueError, match="exactly one threshold"):
            run_check_suite(load_check_suite(str(config)))

    def test_detection_ignores_defaults_thresholds(self, tmp_path: Path):
        """Detection should not inherit artifact distance thresholds from defaults."""
        detection_reference = _write_json(
            tmp_path / "refs" / "det_ref.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "center": [0.0, 0.0, 0.0], "size": [2.0, 2.0, 2.0]},
                        ],
                    },
                ]
            },
        )
        detection_estimated = _write_json(
            tmp_path / "outputs" / "det_est.json",
            {
                "frames": [
                    {
                        "frame_id": "0001",
                        "boxes": [
                            {"label": "car", "center": [0.0, 0.1, 0.0], "size": [2.0, 2.0, 2.0], "score": 0.9},
                        ],
                    },
                ]
            },
        )
        config = _write_config(
            tmp_path / "cloudanalyzer.yaml",
            f"""
            defaults:
              thresholds: [0.02, 0.05, 0.1]
              report_dir: qa/reports
              json_dir: qa/results
            checks:
              - id: det-defaults
                kind: detection
                estimated: {Path(detection_estimated).relative_to(tmp_path)}
                reference: {Path(detection_reference).relative_to(tmp_path)}
                gate:
                  min_map: 0.9
            """,
        )
        result = run_check_suite(load_check_suite(str(config)))
        det = result["checks"][0]
        assert det["kind"] == "detection"
        # Should use detection defaults (0.5), not artifact thresholds (0.02, 0.05, 0.1)
        assert det["summary"]["passed"] is True
