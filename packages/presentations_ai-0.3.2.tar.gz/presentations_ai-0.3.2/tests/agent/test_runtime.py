"""Tests for the Agent runtime."""

from __future__ import annotations

import pytest

from presentations_ai import AgentError, AuthenticationError
from presentations_ai.agent._system_prompt import AGENT_SYSTEM_PROMPT
from presentations_ai.agent.runtime import _extract_presentation_details
from presentations_ai.agent.types import AgentToolCall


class TestAgentRuntimeConstructor:
    def test_requires_anthropic_api_key(self) -> None:
        with pytest.raises(AuthenticationError, match="anthropic_api_key is required"):
            from presentations_ai.agent import AgentRuntime

            AgentRuntime(anthropic_api_key="")

    def test_requires_anthropic_package(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Should raise ImportError if anthropic is not installed."""
        import builtins

        original_import = builtins.__import__

        def mock_import(name: str, *args: object, **kwargs: object) -> object:
            if name == "anthropic":
                raise ImportError("No module named 'anthropic'")
            return original_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", mock_import)

        with pytest.raises(ImportError, match="pip install presentations-ai\\[agent\\]"):
            from presentations_ai.agent.runtime import AgentRuntime

            AgentRuntime(anthropic_api_key="sk-ant-test")


class TestExtractPresentationDetails:
    def test_extracts_url_from_access_pattern(self) -> None:
        calls = [
            AgentToolCall(
                tool_name="create_presentation_from_topic",
                server_name="presentations-ai",
                input={},
                result=(
                    "**Access:** https://console.presentations.ai/view/abc123"
                    "\n**Document ID:** 42"
                ),
            )
        ]
        result = _extract_presentation_details(calls)
        assert result["presentation_url"] == "https://console.presentations.ai/view/abc123"
        assert result["document_id"] == 42

    def test_extracts_url_from_document_url_pattern(self) -> None:
        calls = [
            AgentToolCall(
                tool_name="check_job_status",
                server_name="presentations-ai",
                input={},
                result=(
                    "**Document URL:** https://console.presentations.ai/view/def456"
                    "\n**Document ID:** 99"
                ),
            )
        ]
        result = _extract_presentation_details(calls)
        assert result["presentation_url"] == "https://console.presentations.ai/view/def456"
        assert result["document_id"] == 99

    def test_extracts_animated_url(self) -> None:
        calls = [
            AgentToolCall(
                tool_name="test",
                server_name="presentations-ai",
                input={},
                result="**Access:** https://x.com/view\n**Animated:** https://x.com/animated",
            )
        ]
        result = _extract_presentation_details(calls)
        assert result["animated_url"] == "https://x.com/animated"

    def test_extracts_animated_url_alternate_pattern(self) -> None:
        calls = [
            AgentToolCall(
                tool_name="test",
                server_name="presentations-ai",
                input={},
                result="**Access:** https://x.com/view\n**Animated URL:** https://x.com/anim2",
            )
        ]
        result = _extract_presentation_details(calls)
        assert result["animated_url"] == "https://x.com/anim2"

    def test_extracts_job_id(self) -> None:
        calls = [
            AgentToolCall(
                tool_name="test",
                server_name="presentations-ai",
                input={},
                result="**Job ID:** job_xyz789",
            )
        ]
        result = _extract_presentation_details(calls)
        assert result["job_id"] == "job_xyz789"

    def test_skips_error_calls(self) -> None:
        calls = [
            AgentToolCall(
                tool_name="test",
                server_name="presentations-ai",
                input={},
                result="**Access:** https://bad.com\n**Document ID:** 1",
                is_error=True,
            ),
            AgentToolCall(
                tool_name="test",
                server_name="presentations-ai",
                input={},
                result="**Access:** https://good.com\n**Document ID:** 2",
                is_error=False,
            ),
        ]
        result = _extract_presentation_details(calls)
        assert result["presentation_url"] == "https://good.com"
        assert result["document_id"] == 2

    def test_returns_empty_when_no_matches(self) -> None:
        calls = [
            AgentToolCall(
                tool_name="test",
                server_name="presentations-ai",
                input={},
                result="Some random text without patterns",
            )
        ]
        result = _extract_presentation_details(calls)
        assert result == {}

    def test_returns_empty_for_empty_calls(self) -> None:
        assert _extract_presentation_details([]) == {}


class TestSystemPrompt:
    def test_system_prompt_is_non_empty(self) -> None:
        assert len(AGENT_SYSTEM_PROMPT) > 100

    def test_system_prompt_mentions_five_active_tools(self) -> None:
        """The system prompt must describe each active MCP tool.

        Four tools (update_document_content, refresh_presentation,
        create_presentation_from_slides, create_document_from_content) are
        temporarily disabled server-side and their entries live inside HTML
        comment blocks in the prompt. Those are not asserted here so the test
        reflects the live tool surface.
        """
        for tool in (
            "create_presentation_from_topic",
            "create_single_slide",
            "create_presentation_from_content",
            "create_presentation_from_file",
            "check_job_status",
        ):
            assert tool in AGENT_SYSTEM_PROMPT, f"missing tool: {tool}"

    def test_system_prompt_mentions_preservation_modes(self) -> None:
        assert "enhance" in AGENT_SYSTEM_PROMPT
        assert "preserve" in AGENT_SYSTEM_PROMPT
        assert "summarize" in AGENT_SYSTEM_PROMPT
        assert "instruction" in AGENT_SYSTEM_PROMPT

    def test_system_prompt_mentions_error_handling(self) -> None:
        assert "out of credits" in AGENT_SYSTEM_PROMPT
        assert "Rate limited" in AGENT_SYSTEM_PROMPT


class TestAgentRuntimeChatValidation:
    """Test chat() input validation without requiring anthropic SDK."""

    def _make_runtime_with_mock(self) -> object:
        """Create a runtime with a mocked anthropic client."""
        try:
            from presentations_ai.agent import AgentRuntime

            runtime = AgentRuntime(anthropic_api_key="sk-ant-test-key")
            return runtime
        except ImportError:
            pytest.skip("anthropic package not installed")

    def test_chat_rejects_empty_message(self) -> None:
        runtime = self._make_runtime_with_mock()
        if runtime is None:
            return
        with pytest.raises(AgentError, match="user_message must be a non-empty string"):
            runtime.chat("", "pai_key")  # type: ignore[union-attr]

    def test_chat_rejects_empty_api_key(self) -> None:
        runtime = self._make_runtime_with_mock()
        if runtime is None:
            return
        with pytest.raises(
            AuthenticationError,
            match="presentationsApiKey is required|presentations_api_key",
        ):
            runtime.chat("Create a deck", "")  # type: ignore[union-attr]


class _StubBlock:
    """Mimics the attribute-access shape of Anthropic SDK content blocks."""

    def __init__(self, **kwargs: object) -> None:
        for k, v in kwargs.items():
            setattr(self, k, v)


class _StubResponse:
    def __init__(
        self,
        content: list[object],
        stop_reason: str | None = "end_turn",
        input_tokens: int = 100,
        output_tokens: int = 50,
    ) -> None:
        self.content = content
        self.stop_reason = stop_reason
        self.usage = _StubBlock(
            input_tokens=input_tokens, output_tokens=output_tokens
        )


def _make_runtime_with_mock(responses: list[_StubResponse]) -> object:
    """Create a Agent runtime whose Anthropic client returns the given stubs."""
    try:
        from presentations_ai.agent import AgentRuntime
    except ImportError:
        pytest.skip("anthropic package not installed")

    runtime = AgentRuntime(anthropic_api_key="sk-ant-test")
    iter_responses = iter(responses)

    class _StubMessages:
        def create(self, **_kwargs: object) -> object:
            return next(iter_responses)

    class _StubBeta:
        messages = _StubMessages()

    class _StubClient:
        beta = _StubBeta()

    runtime._client = _StubClient()  # type: ignore[attr-defined]
    return runtime


class TestAgentChatFlow:
    """Functional coverage of AgentRuntime.chat() against mocked Anthropic responses."""

    def test_passes_correct_args_to_anthropic(self) -> None:
        runtime = _make_runtime_with_mock(
            [
                _StubResponse(
                    content=[_StubBlock(type="text", text="Hello")],
                    stop_reason="end_turn",
                ),
            ]
        )
        captured: dict[str, object] = {}

        # Re-wire the mock to capture kwargs
        class _Capturing:
            def create(self, **kwargs: object) -> object:
                captured.update(kwargs)
                return _StubResponse(
                    content=[_StubBlock(type="text", text="Hello")],
                    stop_reason="end_turn",
                )

        runtime._client.beta.messages = _Capturing()  # type: ignore[attr-defined]
        runtime.chat("Make a deck", "pai_test_key")  # type: ignore[union-attr]

        assert captured["model"] == "claude-sonnet-4-5-20250929"
        assert captured["system"] == AGENT_SYSTEM_PROMPT
        assert captured["messages"] == [{"role": "user", "content": "Make a deck"}]
        mcp_servers = captured["mcp_servers"]
        assert isinstance(mcp_servers, list)
        assert mcp_servers[0]["url"] == "https://api.presentations.ai/mcp"
        assert mcp_servers[0]["authorization_token"] == "pai_test_key"
        assert captured["betas"] == ["mcp-client-2025-11-20"]

    def test_extracts_text_content(self) -> None:
        runtime = _make_runtime_with_mock(
            [
                _StubResponse(
                    content=[_StubBlock(type="text", text="Your deck is ready!")],
                    stop_reason="end_turn",
                ),
            ]
        )
        result = runtime.chat("hi", "pai_x")  # type: ignore[union-attr]
        assert result.text == "Your deck is ready!"
        assert result.stop_reason == "end_turn"

    def test_parses_tool_use_and_result_with_url_extraction(self) -> None:
        runtime = _make_runtime_with_mock(
            [
                _StubResponse(
                    content=[
                        _StubBlock(
                            type="mcp_tool_use",
                            name="create_presentation_from_topic",
                            server_name="presentations-ai",
                            input={"topic": "AI", "slideCount": 5},
                        ),
                        _StubBlock(
                            type="mcp_tool_result",
                            is_error=False,
                            content=[
                                _StubBlock(
                                    type="text",
                                    text="✅ Presentation created!\n\n"
                                    "**Document ID:** 45678\n"
                                    "**Access:** https://console.presentations.ai/view/abc123\n"
                                    "**Animated:** https://cdn.presentations.ai/exports/12345/presentation_animated.pptx",
                                )
                            ],
                        ),
                        _StubBlock(type="text", text="Done!"),
                    ],
                    stop_reason="end_turn",
                ),
            ]
        )
        result = runtime.chat("Make a deck", "pai_x")  # type: ignore[union-attr]
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].tool_name == "create_presentation_from_topic"
        assert result.tool_calls[0].input == {"topic": "AI", "slideCount": 5}
        assert result.tool_calls[0].is_error is False
        assert result.presentation_url == "https://console.presentations.ai/view/abc123"
        assert result.document_id == 45678
        assert result.animated_url == "https://cdn.presentations.ai/exports/12345/presentation_animated.pptx"

    def test_extracts_job_id_from_async_result(self) -> None:
        runtime = _make_runtime_with_mock(
            [
                _StubResponse(
                    content=[
                        _StubBlock(
                            type="mcp_tool_use",
                            name="create_presentation_from_topic",
                            server_name="presentations-ai",
                            input={"immediatePollUrl": True},
                        ),
                        _StubBlock(
                            type="mcp_tool_result",
                            is_error=False,
                            content=[
                                _StubBlock(
                                    type="text",
                                    text="Background processing.\n\n**Job ID:** mcp_b1ed-49d1\n",
                                )
                            ],
                        ),
                    ],
                    stop_reason="end_turn",
                ),
            ]
        )
        result = runtime.chat("Make async", "pai_x")  # type: ignore[union-attr]
        assert result.job_id == "mcp_b1ed-49d1"

    def test_marks_tool_call_as_error(self) -> None:
        runtime = _make_runtime_with_mock(
            [
                _StubResponse(
                    content=[
                        _StubBlock(
                            type="mcp_tool_use",
                            name="create_presentation_from_topic",
                            server_name="presentations-ai",
                            input={},
                        ),
                        _StubBlock(
                            type="mcp_tool_result",
                            is_error=True,
                            content=[
                                _StubBlock(type="text", text="Error: out of credits")
                            ],
                        ),
                    ],
                    stop_reason="end_turn",
                ),
            ]
        )
        result = runtime.chat("Make a deck", "pai_x")  # type: ignore[union-attr]
        assert result.tool_calls[0].is_error is True
        assert result.tool_calls[0].result == "Error: out of credits"
        # No URL extracted from error result
        assert result.presentation_url is None

    def test_pause_turn_continuation(self) -> None:
        runtime = _make_runtime_with_mock(
            [
                _StubResponse(
                    content=[
                        _StubBlock(
                            type="mcp_tool_use",
                            name="create_presentation_from_topic",
                            server_name="presentations-ai",
                            input={"topic": "A"},
                        ),
                    ],
                    stop_reason="pause_turn",
                    input_tokens=100,
                    output_tokens=50,
                ),
                _StubResponse(
                    content=[
                        _StubBlock(
                            type="mcp_tool_result",
                            is_error=False,
                            content=[
                                _StubBlock(
                                    type="text",
                                    text="**Document ID:** 99\n**Access:** https://x/y",
                                )
                            ],
                        ),
                        _StubBlock(type="text", text="Done!"),
                    ],
                    stop_reason="end_turn",
                    input_tokens=80,
                    output_tokens=30,
                ),
            ]
        )
        result = runtime.chat("Make a deck", "pai_x")  # type: ignore[union-attr]
        assert result.text == "Done!"
        assert result.document_id == 99
        assert result.presentation_url == "https://x/y"
        # Token usage is accumulated across continuations.
        assert result.usage.input_tokens == 180
        assert result.usage.output_tokens == 80

    def test_wraps_anthropic_failure_as_agent_error(self) -> None:
        try:
            from presentations_ai.agent import AgentRuntime
        except ImportError:
            pytest.skip("anthropic package not installed")

        runtime = AgentRuntime(anthropic_api_key="sk-ant-test")

        class _FailingMessages:
            def create(self, **_kwargs: object) -> object:
                raise RuntimeError("Anthropic 401")

        runtime._client.beta.messages = _FailingMessages()  # type: ignore[attr-defined]
        with pytest.raises(AgentError, match="Anthropic API call failed"):
            runtime.chat("Hi", "pai_x")

    def test_passes_conversation_history(self) -> None:
        captured: dict[str, object] = {}

        try:
            from presentations_ai.agent import AgentRuntime
            from presentations_ai.agent.types import AgentMessage
        except ImportError:
            pytest.skip("anthropic package not installed")

        runtime = AgentRuntime(anthropic_api_key="sk-ant-test")

        class _Capturing:
            def create(self, **kwargs: object) -> object:
                captured.update(kwargs)
                return _StubResponse(
                    content=[_StubBlock(type="text", text="OK")],
                    stop_reason="end_turn",
                )

        runtime._client.beta.messages = _Capturing()  # type: ignore[attr-defined]
        runtime.chat(
            "Follow-up",
            "pai_x",
            conversation_history=[
                AgentMessage(role="user", content="first"),
                AgentMessage(role="assistant", content="reply"),
            ],
        )
        assert captured["messages"] == [
            {"role": "user", "content": "first"},
            {"role": "assistant", "content": "reply"},
            {"role": "user", "content": "Follow-up"},
        ]
