"""Tests for Pydantic response models and type definitions."""

from __future__ import annotations

from presentations_ai.types import (
    ApiErrorResponse,
    AsyncJobResponse,
    ContentDocumentResponse,
    JobStatusResponse,
    PresentationResponse,
    SlideUpdateResponse,
)


class TestPresentationResponse:
    def test_parses_complete_response(self) -> None:
        data = {
            "status": 0,
            "docid": 12345,
            "docurl": "https://example.com/view/abc",
            "animated_url": "https://cdn.example.com/anim.pptx",
        }
        resp = PresentationResponse.model_validate(data)
        assert resp.status == 0
        assert resp.docid == 12345
        assert resp.docurl == "https://example.com/view/abc"
        assert resp.animated_url == "https://cdn.example.com/anim.pptx"

    def test_animated_url_optional(self) -> None:
        data = {"status": 0, "docid": 1, "docurl": "https://example.com"}
        resp = PresentationResponse.model_validate(data)
        assert resp.animated_url is None

    def test_ignores_extra_fields(self) -> None:
        data = {
            "status": 0,
            "docid": 1,
            "docurl": "https://example.com",
            "some_future_field": "ignored",
        }
        resp = PresentationResponse.model_validate(data)
        assert resp.docid == 1
        assert not hasattr(resp, "some_future_field")


class TestContentDocumentResponse:
    def test_parses_response(self) -> None:
        data = {
            "status": 0,
            "message": "Created",
            "docurl": "https://example.com",
            "insertid": 42,
        }
        resp = ContentDocumentResponse.model_validate(data)
        assert resp.insertid == 42
        assert resp.message == "Created"


class TestSlideUpdateResponse:
    def test_parses_response(self) -> None:
        data = {"status": 0, "message": "Updated"}
        resp = SlideUpdateResponse.model_validate(data)
        assert resp.status == 0


class TestAsyncJobResponse:
    def test_parses_response(self) -> None:
        data = {"job_id": "job_abc", "status": "queued"}
        resp = AsyncJobResponse.model_validate(data)
        assert resp.job_id == "job_abc"
        assert resp.status == "queued"


class TestJobStatusResponse:
    def test_parses_complete_job(self) -> None:
        data = {
            "status": 0,
            "message": "Ready",
            "docid": 123,
            "docurl": "https://example.com",
            "animated_url": "https://example.com/animated",
        }
        resp = JobStatusResponse.model_validate(data)
        assert resp.status == 0
        assert resp.docid == 123

    def test_parses_processing_job(self) -> None:
        data = {"status": 1, "message": "Document is being processed"}
        resp = JobStatusResponse.model_validate(data)
        assert resp.status == 1
        assert resp.docid is None

    def test_optional_fields_default_none(self) -> None:
        data = {"status": 1}
        resp = JobStatusResponse.model_validate(data)
        assert resp.message is None
        assert resp.poll_url is None
        assert resp.docid is None
        assert resp.docurl is None
        assert resp.animated_url is None


class TestApiErrorResponse:
    def test_parses_error(self) -> None:
        data = {"status": 1, "error": "Invalid API key"}
        resp = ApiErrorResponse.model_validate(data)
        assert resp.status == 1
        assert resp.error == "Invalid API key"
