"""Tests for the asynchronous AsyncPresentationsAI client."""

from __future__ import annotations

from typing import Any

import httpx
import pytest
import respx

from presentations_ai import (
    AsyncPresentationsAI,
    AuthenticationError,
    BadRequestError,
)
from presentations_ai.types import (
    AsyncJobResponse,
    ContentDocumentResponse,
    JobStatusResponse,
    PresentationResponse,
    SlideUpdateResponse,
)

TEST_API_KEY = "pai_test_key"
BASE = "https://api.presentations.ai"


class TestAsyncClientConstructor:
    def test_requires_api_key(self) -> None:
        with pytest.raises(AuthenticationError):
            AsyncPresentationsAI(api_key="")

    @pytest.mark.asyncio
    async def test_context_manager(self) -> None:
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            assert client._api_key == TEST_API_KEY


class TestAsyncCreateFromTopic:
    @pytest.mark.asyncio
    @respx.mock
    async def test_success(
        self,
        respx_mock: respx.MockRouter,
        presentation_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(200, json=presentation_response_data)
        )

        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_from_topic(
                topic="AI Strategy", export_type="pptx"
            )

        assert isinstance(result, PresentationResponse)
        assert result.docid == 12345

    @pytest.mark.asyncio
    @respx.mock
    async def test_returns_async_job(
        self,
        respx_mock: respx.MockRouter,
        async_job_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(200, json=async_job_response_data)
        )

        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_from_topic(
                topic="AI Strategy", export_type="pptx"
            )

        assert isinstance(result, AsyncJobResponse)
        assert result.job_id == "job_abc123"

    @pytest.mark.asyncio
    async def test_validates_empty_topic(self) -> None:
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            with pytest.raises(BadRequestError):
                await client.create_from_topic(
                    topic="", export_type="pptx"
                )


class TestAsyncCreateFromFile:
    @pytest.mark.asyncio
    @respx.mock
    async def test_success(
        self,
        respx_mock: respx.MockRouter,
        presentation_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/document/file").mock(
            return_value=httpx.Response(200, json=presentation_response_data)
        )

        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_from_file(
                file=b"PDF content",
                file_name="report.pdf",
                export_type="pptx",
            )

        assert isinstance(result, PresentationResponse)


class TestAsyncCreateSingleSlide:
    @pytest.mark.asyncio
    @respx.mock
    async def test_success(
        self,
        respx_mock: respx.MockRouter,
        presentation_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/singleslide").mock(
            return_value=httpx.Response(200, json=presentation_response_data)
        )

        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            # /api/v1/topic/singleslide does not accept export_type.
            result = await client.create_single_slide(topic="Title")

        assert isinstance(result, PresentationResponse)


@pytest.mark.skip(
    reason="create_from_content is currently disabled (MCP tool create_document_from_content overlaps with create_from_raw_content)."
)
class TestAsyncCreateFromContent:
    @pytest.mark.asyncio
    @respx.mock
    async def test_success(
        self,
        respx_mock: respx.MockRouter,
        content_document_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/content/document").mock(
            return_value=httpx.Response(
                200, json=content_document_response_data
            )
        )

        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_from_content(
                name="Report",
                slides=[{"title": "S1", "section": "C1"}],
            )

        assert isinstance(result, ContentDocumentResponse)


class TestAsyncCreateFromRawContent:
    @pytest.mark.asyncio
    async def test_validates_empty_content(self) -> None:
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            with pytest.raises(BadRequestError):
                await client.create_from_raw_content(
                    content="   ", export_type="pptx"
                )

    @pytest.mark.asyncio
    @respx.mock
    async def test_success(
        self,
        respx_mock: respx.MockRouter,
        presentation_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/document/content").mock(
            return_value=httpx.Response(200, json=presentation_response_data)
        )

        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_from_raw_content(
                content="Meeting notes...", export_type="pptx"
            )

        assert isinstance(result, PresentationResponse)


@pytest.mark.skip(
    reason="Method disabled in client.py until update/refresh flows are validated end-to-end."
)
class TestAsyncUpdateSlides:
    @pytest.mark.asyncio
    @respx.mock
    async def test_success(self, respx_mock: respx.MockRouter) -> None:
        respx_mock.post(f"{BASE}/api/v1/document/slide").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "message": "Updated"}
            )
        )

        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.update_slides(
                doc_id=1,
                slides=[
                    {
                        "action": "update",
                        "slide_content": "New",
                        "index": 0,
                    }
                ],
            )

        assert isinstance(result, SlideUpdateResponse)


class TestAsyncCheckJobStatus:
    @pytest.mark.asyncio
    @respx.mock
    async def test_success(
        self,
        respx_mock: respx.MockRouter,
        job_status_complete_data: dict[str, Any],
    ) -> None:
        respx_mock.get(f"{BASE}/api/v1/polljob/job_123").mock(
            return_value=httpx.Response(200, json=job_status_complete_data)
        )

        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.check_job_status("job_123")

        assert isinstance(result, JobStatusResponse)
        assert result.status == 0


class TestAsyncHttpErrorMapping:
    @pytest.mark.asyncio
    @respx.mock
    async def test_401_raises_authentication_error(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                401, json={"error": "Invalid key"}
            )
        )

        async with AsyncPresentationsAI(
            api_key=TEST_API_KEY, max_retries=0
        ) as client:
            with pytest.raises(AuthenticationError):
                await client.create_from_topic(
                    topic="test", export_type="pptx"
                )


import json  # noqa: E402


class TestAsyncResponseShapeVariants:
    @pytest.mark.asyncio
    @respx.mock
    async def test_create_from_topic_export_shape(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "url": "https://cdn.x/p.pptx",
                    "animated_url": "https://cdn.x/p_animated.pptx",
                },
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_from_topic(topic="t", export_type="pptx")
        assert getattr(result, "url", None) == "https://cdn.x/p.pptx"

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_from_topic_render_shape(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "docid": 199944,
                    "docurl": "https://app.x/#/docs/edit/199944",
                },
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_from_topic(topic="t", export_type="render")
        assert getattr(result, "docid", None) == 199944
        assert getattr(result, "docurl", None) == "https://app.x/#/docs/edit/199944"

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_from_topic_async_job_response_202(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                202, json={"job_id": "b1ed-49d1", "status": "queued"}
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_from_topic(
                topic="t",
                export_type="pptx",
                callback_url="https://cb.x/wh",
            )
        assert isinstance(result, AsyncJobResponse)
        assert result.job_id == "b1ed-49d1"

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_single_slide_image_shape(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/singleslide").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "url": "https://cdn.x/single-slide.png",
                    "animated_url": None,
                },
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.create_single_slide(topic="My slide")
        assert getattr(result, "url", None) == "https://cdn.x/single-slide.png"


class TestAsyncCreateFromFileMultipart:
    @pytest.mark.asyncio
    @respx.mock
    async def test_sends_instruction_in_form_data(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/file").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "url": "https://x", "animated_url": None}
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            await client.create_from_file(
                file=b"hello",
                file_name="doc.pdf",
                export_type="pptx",
                instruction="enhance",
                instructions="Lead with metrics",
                immediate_poll_url=True,
            )
        body = route.calls[0].request.content.decode("utf-8", errors="ignore")
        assert 'name="instruction"\r\n\r\nenhance' in body
        assert 'name="instructions"\r\n\r\nLead with metrics' in body
        assert 'name="immediatePollUrl"\r\n\r\ntrue' in body
        assert "preservationMode" not in body


@pytest.mark.skip(
    reason="Method disabled in client.py until update/refresh flows are validated end-to-end."
)
class TestAsyncRefreshPresentation:
    @pytest.mark.asyncio
    @respx.mock
    async def test_validates_empty_docid(self) -> None:
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            with pytest.raises(BadRequestError):
                await client.refresh_presentation(docid="")

    @pytest.mark.asyncio
    @respx.mock
    async def test_sends_lowercase_docid(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/refresh").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "message": "refresh_initiated",
                    "docId": 12345,
                },
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.refresh_presentation(docid="doc-99")
        body = json.loads(route.calls[0].request.content)
        assert body == {"docid": "doc-99"}
        assert result.status == 0
        assert result.docId == 12345

    @pytest.mark.asyncio
    @respx.mock
    async def test_sends_multipart_with_file(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/refresh").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "message": "refresh_initiated"}
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            await client.refresh_presentation(
                docid="doc-99",
                file=b"new content",
                file_name="new.pdf",
            )
        body = route.calls[0].request.content.decode("utf-8", errors="ignore")
        assert 'name="docid"\r\n\r\ndoc-99' in body
        assert 'name="file"; filename="new.pdf"' in body


class TestAsyncAuthenticate:
    @pytest.mark.asyncio
    @respx.mock
    async def test_success(self, respx_mock: respx.MockRouter) -> None:
        respx_mock.get(f"{BASE}/api/v1/authenticate").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "message": "API key is valid"}
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            result = await client.authenticate()
        assert result.status == 0
        assert result.message == "API key is valid"


class TestAsyncEndToEndAsyncFlow:
    @pytest.mark.asyncio
    @respx.mock
    async def test_create_immediate_poll_then_polljob(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 1,
                    "pollUrl": "https://api.x/api/v1/polljob/job-1",
                },
            )
        )
        respx_mock.get(f"{BASE}/api/v1/polljob/job-1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "url": "https://cdn.x/p.pptx",
                    "animated_url": None,
                },
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            await client.create_from_topic(
                topic="t",
                export_type="pptx",
                immediate_poll_url=True,
            )
            polled = await client.check_job_status("job-1")
        assert polled.status == 0
        assert polled.url == "https://cdn.x/p.pptx"


class TestAsyncWireFormatContracts:
    """Sanity checks that wire field names match the server contract."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_from_raw_content_sends_instruction_not_preservation_mode(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/content").mock(
            return_value=httpx.Response(
                200,
                json={"status": 0, "url": "https://x", "animated_url": None},
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            await client.create_from_raw_content(
                content="some text",
                export_type="pptx",
                instruction="enhance",
                instructions="Make it punchy",
            )
        body = json.loads(route.calls[0].request.content)
        assert body["instruction"] == "enhance"
        assert body["instructions"] == "Make it punchy"
        assert "preservationMode" not in body

    @pytest.mark.skip(
        reason="create_from_content is currently disabled (MCP tool create_document_from_content overlaps with create_from_raw_content)."
    )
    @pytest.mark.asyncio
    @respx.mock
    async def test_create_from_content_sends_section_field(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/content/document").mock(
            return_value=httpx.Response(
                200,
                json={"status": 0, "docid": 1, "docurl": "https://x"},
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            await client.create_from_content(
                name="Test Deck",
                slides=[{"title": "S1", "section": "Body"}],
            )
        body = json.loads(route.calls[0].request.content)
        slides = json.loads(body["slides"])
        assert slides[0] == {"title": "S1", "section": "Body"}

    @pytest.mark.asyncio
    @respx.mock
    async def test_create_single_slide_does_not_send_export_type(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/topic/singleslide").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "url": "https://x", "animated_url": None}
            )
        )
        async with AsyncPresentationsAI(api_key=TEST_API_KEY) as client:
            await client.create_single_slide(topic="Some topic")
        body = json.loads(route.calls[0].request.content)
        assert "exportType" not in body
        assert "slideCount" not in body
