"""Tests for the synchronous PresentationsAI client."""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest
import respx

from presentations_ai import (
    AuthenticationError,
    BadRequestError,
    InsufficientCreditsError,
    InternalServerError,
    NotFoundError,
    PresentationsAI,
    RateLimitError,
)
from presentations_ai.types import (
    AsyncJobResponse,
    ContentDocumentResponse,
    PresentationResponse,
    SlideUpdateResponse,
)

TEST_API_KEY = "pai_test_key"
BASE = "https://api.presentations.ai"


class TestClientConstructor:
    def test_requires_api_key(self) -> None:
        with pytest.raises(AuthenticationError, match="API key is required"):
            PresentationsAI(api_key="")

    def test_accepts_api_key(self) -> None:
        client = PresentationsAI(api_key=TEST_API_KEY)
        assert client._api_key == TEST_API_KEY
        client.close()

    def test_env_var_fallback(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("PRESENTATIONS_AI_API_KEY", "pai_from_env")
        client = PresentationsAI()
        assert client._api_key == "pai_from_env"
        client.close()

    def test_custom_base_url(self) -> None:
        client = PresentationsAI(
            api_key=TEST_API_KEY, base_url="https://custom.api.com/"
        )
        assert client._base_url == "https://custom.api.com"
        client.close()

    def test_context_manager(self) -> None:
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            assert client._api_key == TEST_API_KEY


class TestCreateFromTopic:
    @respx.mock
    def test_success(
        self,
        respx_mock: respx.MockRouter,
        presentation_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(200, json=presentation_response_data)
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.create_from_topic(
                topic="AI Strategy", export_type="pptx"
            )

        assert isinstance(result, PresentationResponse)
        assert result.docid == 12345
        assert result.docurl == "https://console.presentations.ai/view/abc123"

    @respx.mock
    def test_returns_async_job(
        self,
        respx_mock: respx.MockRouter,
        async_job_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(200, json=async_job_response_data)
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.create_from_topic(
                topic="AI Strategy", export_type="pptx"
            )

        assert isinstance(result, AsyncJobResponse)
        assert result.job_id == "job_abc123"

    def test_validates_empty_topic(self) -> None:
        with (
            PresentationsAI(api_key=TEST_API_KEY) as client,
            pytest.raises(
                BadRequestError, match="topic must be a non-empty string"
            ),
        ):
            client.create_from_topic(topic="", export_type="pptx")

    def test_validates_slide_count_range(self) -> None:
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            with pytest.raises(
                BadRequestError, match="slide_count must be an integer"
            ):
                client.create_from_topic(
                    topic="test", export_type="pptx", slide_count=0
                )

            with pytest.raises(
                BadRequestError, match="slide_count must be an integer"
            ):
                client.create_from_topic(
                    topic="test", export_type="pptx", slide_count=51
                )

    @respx.mock
    def test_sends_camel_case_keys(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "docid": 1, "docurl": "http://x"}
            )
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.create_from_topic(
                topic="test",
                export_type="pptx",
                slide_count=5,
                target_audience="VCs",
            )

        body = route.calls[0].request.content
        parsed = json.loads(body)
        assert "slideCount" in parsed
        assert "targetAudience" in parsed
        assert "exportType" in parsed


class TestCreateFromFile:
    @respx.mock
    def test_success(
        self,
        respx_mock: respx.MockRouter,
        presentation_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/document/file").mock(
            return_value=httpx.Response(200, json=presentation_response_data)
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.create_from_file(
                file=b"PDF content here",
                file_name="report.pdf",
                export_type="pptx",
            )

        assert isinstance(result, PresentationResponse)


class TestCreateSingleSlide:
    @respx.mock
    def test_success(
        self,
        respx_mock: respx.MockRouter,
        presentation_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/singleslide").mock(
            return_value=httpx.Response(200, json=presentation_response_data)
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            # /api/v1/topic/singleslide does not accept export_type (server ignores it).
            result = client.create_single_slide(topic="Title Slide")

        assert isinstance(result, PresentationResponse)


@pytest.mark.skip(
    reason="create_from_content is currently disabled (MCP tool create_document_from_content overlaps with create_from_raw_content)."
)
class TestCreateFromContent:
    @respx.mock
    def test_success(
        self,
        respx_mock: respx.MockRouter,
        content_document_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/content/document").mock(
            return_value=httpx.Response(
                200, json=content_document_response_data
            )
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            # Server expects each slide as {title, section}.
            result = client.create_from_content(
                name="Q4 Report",
                slides=[
                    {"title": "Slide 1", "section": "Content 1"},
                    {"title": "Slide 2", "section": "Content 2"},
                ],
            )

        assert isinstance(result, ContentDocumentResponse)
        assert result.insertid == 67890

    @respx.mock
    def test_stringifies_slides(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/content/document").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "message": "ok",
                    "docurl": "http://x",
                    "insertid": 1,
                },
            )
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.create_from_content(
                name="test",
                slides=[{"title": "T", "section": "C"}],
            )

        body = json.loads(route.calls[0].request.content)
        # slides should be a JSON string, not a list
        assert isinstance(body["slides"], str)
        parsed_slides = json.loads(body["slides"])
        assert parsed_slides == [{"title": "T", "section": "C"}]


class TestCreateFromRawContent:
    def test_validates_empty_content(self) -> None:
        with (
            PresentationsAI(api_key=TEST_API_KEY) as client,
            pytest.raises(
                BadRequestError,
                match="content must be a non-empty string",
            ),
        ):
            client.create_from_raw_content(content="", export_type="pptx")

    @respx.mock
    def test_success(
        self,
        respx_mock: respx.MockRouter,
        presentation_response_data: dict[str, Any],
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/document/content").mock(
            return_value=httpx.Response(200, json=presentation_response_data)
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.create_from_raw_content(
                content="Meeting notes from Q4 review...",
                export_type="pptx",
                # Server reads `instruction` (api-mcp/routes/restroutes.js:1315),
                # not `preservation_mode`.
                instruction="summarize",
            )

        assert isinstance(result, PresentationResponse)


@pytest.mark.skip(
    reason="Method disabled in client.py until update/refresh flows are validated end-to-end."
)
class TestUpdateSlides:
    @respx.mock
    def test_success(self, respx_mock: respx.MockRouter) -> None:
        respx_mock.post(f"{BASE}/api/v1/document/slide").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "message": "Updated"}
            )
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.update_slides(
                doc_id=12345,
                slides=[
                    {
                        "action": "update",
                        "slide_content": "New content",
                        "index": 0,
                    }
                ],
            )

        assert isinstance(result, SlideUpdateResponse)
        assert result.message == "Updated"

    @respx.mock
    def test_stringifies_slides(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/slide").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "message": "ok"}
            )
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.update_slides(
                doc_id=1,
                slides=[
                    {"action": "update", "slide_content": "X", "index": 0}
                ],
            )

        body = json.loads(route.calls[0].request.content)
        assert isinstance(body["slides"], str)


class TestCheckJobStatus:
    @respx.mock
    def test_success(
        self,
        respx_mock: respx.MockRouter,
        job_status_complete_data: dict[str, Any],
    ) -> None:
        respx_mock.get(f"{BASE}/api/v1/polljob/job_abc123").mock(
            return_value=httpx.Response(200, json=job_status_complete_data)
        )

        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.check_job_status("job_abc123")

        assert result.status == 0
        assert result.docid == 12345


class TestHttpErrorMapping:
    @respx.mock
    def test_401_raises_authentication_error(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                401, json={"error": "Invalid API key"}
            )
        )

        with PresentationsAI(
            api_key=TEST_API_KEY, max_retries=0
        ) as client:
            with pytest.raises(AuthenticationError) as exc_info:
                client.create_from_topic(topic="test", export_type="pptx")
            assert exc_info.value.status_code == 401
            assert exc_info.value.code == "API_UNAUTHORIZED"

    @respx.mock
    def test_402_raises_insufficient_credits(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                402, json={"error": "Out of credits"}
            )
        )

        with PresentationsAI(
            api_key=TEST_API_KEY, max_retries=0
        ) as client:
            with pytest.raises(InsufficientCreditsError) as exc_info:
                client.create_from_topic(topic="test", export_type="pptx")
            assert exc_info.value.status_code == 402

    @respx.mock
    def test_404_raises_not_found(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.get(f"{BASE}/api/v1/polljob/nonexistent").mock(
            return_value=httpx.Response(404, json={"error": "Not found"})
        )

        with (
            PresentationsAI(
                api_key=TEST_API_KEY, max_retries=0
            ) as client,
            pytest.raises(NotFoundError),
        ):
            client.check_job_status("nonexistent")

    @respx.mock
    def test_429_raises_rate_limit(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                429, json={"error": "Too many requests"}
            )
        )

        with (
            PresentationsAI(
                api_key=TEST_API_KEY, max_retries=0
            ) as client,
            pytest.raises(RateLimitError),
        ):
            client.create_from_topic(topic="test", export_type="pptx")

    @respx.mock
    def test_500_raises_internal_server_error(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(500, text="Internal Server Error")
        )

        with (
            PresentationsAI(
                api_key=TEST_API_KEY, max_retries=0
            ) as client,
            pytest.raises(InternalServerError),
        ):
            client.create_from_topic(topic="test", export_type="pptx")


class TestAuthenticate:
    @respx.mock
    def test_success(self, respx_mock: respx.MockRouter) -> None:
        respx_mock.get(f"{BASE}/api/v1/authenticate").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "message": "API key is valid"}
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.authenticate()

        assert result.status == 0
        assert result.message == "API key is valid"


@pytest.mark.skip(
    reason="Method disabled in client.py until update/refresh flows are validated end-to-end."
)
class TestRefreshPresentation:
    def test_validates_empty_docid(self) -> None:
        with (
            PresentationsAI(api_key=TEST_API_KEY) as client,
            pytest.raises(BadRequestError, match="docid"),
        ):
            client.refresh_presentation(docid="")

    @respx.mock
    def test_sends_lowercase_docid_field(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # Server-side body field is lowercase `docid` (api-mcp/routes/restroutes.js:1728).
        route = respx_mock.post(f"{BASE}/api/v1/document/refresh").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "message": "refresh_initiated",
                    "docId": 12345,
                    "meta_id": "abc",
                },
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.refresh_presentation(docid="doc-99")

        body = json.loads(route.calls[0].request.content)
        assert body == {"docid": "doc-99"}
        assert result.status == 0


class TestWireFormatContracts:
    """Sanity checks that we send the exact field names the server reads."""

    @respx.mock
    def test_create_from_raw_content_sends_instruction_not_preservation_mode(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # api-mcp/routes/restroutes.js:1315 reads `req.body.instruction`.
        route = respx_mock.post(f"{BASE}/api/v1/document/content").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "url": "https://x",
                    "animated_url": None,
                },
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.create_from_raw_content(
                content="some text",
                export_type="pptx",
                instruction="enhance",
                instructions="Make it punchy",
            )

        body = json.loads(route.calls[0].request.content)
        assert body["instruction"] == "enhance"
        assert body["instructions"] == "Make it punchy"
        assert "preservationMode" not in body
        assert "preservation_mode" not in body

    @respx.mock
    def test_create_from_file_sends_instruction_in_form_data(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # /api/v1/document/file is multipart; field name is also `instruction`.
        route = respx_mock.post(f"{BASE}/api/v1/document/file").mock(
            return_value=httpx.Response(
                200,
                json={"status": 0, "url": "https://x", "animated_url": None},
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.create_from_file(
                file=b"hello",
                file_name="x.txt",
                export_type="pptx",
                slide_count=5,
                instruction="enhance",
            )

        body_text = route.calls[0].request.content.decode("utf-8", errors="ignore")
        # Multipart body should contain a form part for `instruction`.
        assert 'name="instruction"' in body_text
        assert "preservationMode" not in body_text

    @respx.mock
    def test_create_single_slide_does_not_send_export_type(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # Server doesn't read these for /api/v1/topic/singleslide.
        route = respx_mock.post(f"{BASE}/api/v1/topic/singleslide").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "url": "https://x", "animated_url": None}
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.create_single_slide(topic="Some topic")

        body = json.loads(route.calls[0].request.content)
        assert "exportType" not in body
        assert "slideCount" not in body
        assert body["topic"] == "Some topic"


class TestResponseShapeVariants:
    """Cover all 3 response shapes the server returns from creation endpoints."""

    @respx.mock
    def test_create_from_topic_export_shape(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # Export types ppt/pptx/pdf/image return {status, url, animated_url}.
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "url": "https://cdn.x/exports/123/p.pptx",
                    "animated_url": "https://cdn.x/exports/123/p_animated.pptx",
                },
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.create_from_topic(topic="t", export_type="pptx")
        assert result.status == 0
        # Result is parsed as PresentationResponse — both shapes share the model
        assert getattr(result, "url", None) == "https://cdn.x/exports/123/p.pptx"

    @respx.mock
    def test_create_from_topic_render_shape(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # Render/share return {status, docid, docurl}.
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "docid": 199944,
                    "docurl": "https://app.x/#/docs/edit/199944",
                },
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.create_from_topic(topic="t", export_type="render")
        assert getattr(result, "docid", None) == 199944
        assert getattr(result, "docurl", None) == "https://app.x/#/docs/edit/199944"

    @respx.mock
    def test_create_from_topic_async_job_response_202(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # callback_url path: server returns HTTP 202 with {job_id, status:"queued"}.
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                202,
                json={"job_id": "b1ed-49d1", "status": "queued"},
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.create_from_topic(
                topic="t",
                export_type="pptx",
                callback_url="https://cb.x/wh",
            )
        # Parsed as AsyncJobResponse via the union parser
        assert getattr(result, "job_id", None) == "b1ed-49d1"

    @respx.mock
    def test_create_single_slide_image_shape(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # Single slide always returns image: {status, url, animated_url:null}.
        respx_mock.post(f"{BASE}/api/v1/topic/singleslide").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "url": "https://cdn.x/single-slide.png",
                    "animated_url": None,
                },
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.create_single_slide(topic="My slide")
        assert getattr(result, "url", None) == "https://cdn.x/single-slide.png"
        assert getattr(result, "animated_url", None) is None


class TestCreateFromFileMultipart:
    @respx.mock
    def test_sends_all_optional_form_fields(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/file").mock(
            return_value=httpx.Response(
                200,
                json={"status": 0, "url": "https://x", "animated_url": None},
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.create_from_file(
                file=b"hello",
                file_name="doc.pdf",
                export_type="pptx",
                slide_count=10,
                language="es",
                domain="business",
                instruction="enhance",
                instructions="Lead with metrics",
                target_audience="execs",
                tone="formal",
                callback_url="https://cb.x/wh",
                immediate_poll_url=True,
            )
        body = route.calls[0].request.content.decode("utf-8", errors="ignore")
        # Every optional field should appear as a form part with its expected value.
        assert 'name="exportType"\r\n\r\npptx' in body
        assert 'name="slideCount"\r\n\r\n10' in body
        assert 'name="language"\r\n\r\nes' in body
        assert 'name="domain"\r\n\r\nbusiness' in body
        assert 'name="instruction"\r\n\r\nenhance' in body
        assert 'name="instructions"\r\n\r\nLead with metrics' in body
        assert 'name="targetAudience"\r\n\r\nexecs' in body
        assert 'name="tone"\r\n\r\nformal' in body
        assert 'name="callback_url"\r\n\r\nhttps://cb.x/wh' in body
        assert 'name="immediatePollUrl"\r\n\r\ntrue' in body

    @respx.mock
    def test_omits_optional_fields_when_none(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/file").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "url": "https://x", "animated_url": None}
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.create_from_file(
                file=b"hello",
                file_name="doc.pdf",
                export_type="pptx",
            )
        body = route.calls[0].request.content.decode("utf-8", errors="ignore")
        # Optional fields not provided should not appear in the body.
        assert 'name="slideCount"' not in body
        assert 'name="instruction"' not in body
        assert 'name="instructions"' not in body
        assert 'name="callback_url"' not in body
        assert 'name="immediatePollUrl"' not in body

    @respx.mock
    def test_attaches_file_with_correct_name(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/file").mock(
            return_value=httpx.Response(
                200, json={"status": 0, "url": "https://x", "animated_url": None}
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.create_from_file(
                file=b"binary content here",
                file_name="report.pdf",
                export_type="pptx",
            )
        body = route.calls[0].request.content.decode("utf-8", errors="ignore")
        assert 'name="file"; filename="report.pdf"' in body


@pytest.mark.skip(
    reason="Method disabled in client.py until update/refresh flows are validated end-to-end."
)
class TestRefreshPresentationFunctional:
    @respx.mock
    def test_parses_full_response_shape(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/document/refresh").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "message": "refresh_initiated",
                    "docId": 12345,
                    "meta_id": "6643a1b2c3d4e5f600112233",
                },
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.refresh_presentation(docid="doc-99")
        assert result.status == 0
        assert result.message == "refresh_initiated"
        assert result.docId == 12345
        assert result.meta_id == "6643a1b2c3d4e5f600112233"

    @respx.mock
    def test_sends_multipart_when_file_provided(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/refresh").mock(
            return_value=httpx.Response(
                200,
                json={"status": 0, "message": "refresh_initiated"},
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.refresh_presentation(
                docid="doc-99",
                file=b"new source content",
                file_name="new.pdf",
            )
        body = route.calls[0].request.content.decode("utf-8", errors="ignore")
        # docid as form field, file with correct filename
        assert 'name="docid"\r\n\r\ndoc-99' in body
        assert 'name="file"; filename="new.pdf"' in body

    @respx.mock
    def test_default_filename_when_omitted(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/refresh").mock(
            return_value=httpx.Response(200, json={"status": 0})
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.refresh_presentation(docid="doc-99", file=b"x")
        body = route.calls[0].request.content.decode("utf-8", errors="ignore")
        assert 'filename="source"' in body


@pytest.mark.skip(
    reason="Method disabled in client.py until update/refresh flows are validated end-to-end."
)
class TestUpdateSlidesFunctional:
    @respx.mock
    def test_parses_full_response_shape(
        self, respx_mock: respx.MockRouter
    ) -> None:
        respx_mock.post(f"{BASE}/api/v1/document/slide").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "msg": "Slide content updated successfully",
                    "insertid": "6643a1b2c3d4e5f600112233",
                    "docurl": "https://app.x/#/docs/edit/199943",
                },
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            result = client.update_slides(
                doc_id=199943,
                slides=[{"action": "update", "slide_content": "new", "index": 0}],
            )
        assert result.status == 0
        assert result.msg == "Slide content updated successfully"
        assert result.insertid == "6643a1b2c3d4e5f600112233"
        assert result.docurl == "https://app.x/#/docs/edit/199943"

    @respx.mock
    def test_supports_all_three_actions(
        self, respx_mock: respx.MockRouter
    ) -> None:
        route = respx_mock.post(f"{BASE}/api/v1/document/slide").mock(
            return_value=httpx.Response(200, json={"status": 0})
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            client.update_slides(
                doc_id=1,
                slides=[
                    {"action": "update", "slide_content": "a", "index": 0},
                    {"action": "add", "slide_content": "b", "index": 1},
                    {"action": "delete", "slide_content": "c", "index": 2},
                ],
            )
        body = json.loads(route.calls[0].request.content)
        slides = json.loads(body["slides"])
        assert [s["action"] for s in slides] == ["update", "add", "delete"]


class TestEndToEndAsyncFlow:
    @respx.mock
    def test_create_with_immediate_poll_then_polljob_completes(
        self, respx_mock: respx.MockRouter
    ) -> None:
        # Step 1: create returns {status:1, pollUrl}
        respx_mock.post(f"{BASE}/api/v1/topic/document").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 1,
                    "pollUrl": "https://api.x/api/v1/polljob/job-1",
                },
            )
        )
        # Step 2: polljob returns success
        respx_mock.get(f"{BASE}/api/v1/polljob/job-1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": 0,
                    "url": "https://cdn.x/p.pptx",
                    "animated_url": None,
                },
            )
        )
        with PresentationsAI(api_key=TEST_API_KEY) as client:
            created = client.create_from_topic(
                topic="t", export_type="pptx", immediate_poll_url=True
            )
            # Both AsyncJobResponse and PresentationResponse are valid here.
            # PollUrlResponse shape is parsed as PresentationResponse with poll_url field.
            assert created is not None
            polled = client.check_job_status("job-1")
        assert polled.status == 0
        assert polled.url == "https://cdn.x/p.pptx"
