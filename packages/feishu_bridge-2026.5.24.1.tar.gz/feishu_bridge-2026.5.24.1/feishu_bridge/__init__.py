"""Feishu Bridge — Feishu <-> Claude Code CLI bridge."""

__version__ = "2026.05.24.1"
