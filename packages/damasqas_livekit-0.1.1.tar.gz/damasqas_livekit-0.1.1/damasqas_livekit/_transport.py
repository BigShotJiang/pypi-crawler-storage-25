"""
Async HTTP transport to the Damasqas ingestion API.
Fire-and-forget with batching. NEVER blocks the voice pipeline.
"""

import asyncio
import logging
from typing import Optional

import httpx

logger = logging.getLogger("damasqas_livekit")

# Batch settings
BATCH_SIZE = 20
BATCH_INTERVAL = 2.0
MAX_RETRY = 2
QUEUE_MAX = 500

# Module-level singleton — shared across all monitor() calls in the same process
# to avoid connection pool sprawl with concurrent sessions.
_shared_transports: dict[str, "MetricsTransport"] = {}


def get_or_create_transport(url: str, token: str) -> "MetricsTransport":
    """Return a shared transport for the given url+token combination."""
    key = f"{url}:{token}"
    existing = _shared_transports.get(key)
    if existing is not None and not existing._closed:
        return existing
    transport = MetricsTransport(url=url, token=token)
    _shared_transports[key] = transport
    return transport


class MetricsTransport:
    def __init__(self, url: str, token: str):
        self._url = url
        self._token = token
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(5.0, connect=3.0),
            limits=httpx.Limits(max_connections=5),
        )
        self._queue: list[dict] = []
        self._flush_task: Optional[asyncio.Task] = None
        self._closed = False
        # Batch loop is started lazily on first send() when the event loop
        # is guaranteed to be running. This avoids issues when the transport
        # is constructed before the asyncio event loop starts.

    def _ensure_batch_loop(self) -> None:
        """Start the batch flush loop if not already running."""
        if self._flush_task is not None:
            return
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                self._flush_task = asyncio.ensure_future(self._batch_loop())
        except RuntimeError:
            pass

    async def send(self, event: dict) -> None:
        """Add an event to the send queue. Non-blocking."""
        if self._closed:
            return

        self._ensure_batch_loop()

        if len(self._queue) >= QUEUE_MAX:
            # Backpressure: drop oldest events
            self._queue = self._queue[QUEUE_MAX // 2:]
            logger.warning("damasqas_livekit: event queue overflow, dropping oldest events")

        self._queue.append(event)

        if len(self._queue) >= BATCH_SIZE:
            await self._flush()

    async def _batch_loop(self) -> None:
        """Periodic flush of queued events."""
        while not self._closed:
            await asyncio.sleep(BATCH_INTERVAL)
            if self._queue:
                await self._flush()

    async def _flush(self) -> None:
        """Send all queued events to Damasqas."""
        if not self._queue:
            return

        batch = self._queue[:]
        self._queue.clear()

        for attempt in range(MAX_RETRY + 1):
            try:
                resp = await self._client.post(
                    self._url,
                    json={"events": batch},
                    headers={
                        "Authorization": f"Bearer {self._token}",
                        "Content-Type": "application/json",
                        "X-Damasqas-SDK": "python/0.1.0",
                    },
                )
                if resp.status_code < 400:
                    return
                if resp.status_code == 401:
                    logger.error("damasqas_livekit: invalid token (401). Check DAMASQAS_TOKEN.")
                    return
                if resp.status_code >= 500 and attempt < MAX_RETRY:
                    await asyncio.sleep(0.5 * (attempt + 1))
                    continue
            except Exception as e:
                if attempt < MAX_RETRY:
                    await asyncio.sleep(0.5 * (attempt + 1))
                    continue
                logger.debug("damasqas_livekit: send failed after retries: %s", e)
                return

    async def close(self) -> None:
        """Flush remaining events and close the HTTP client."""
        self._closed = True
        if self._flush_task:
            self._flush_task.cancel()
        await self._flush()
        await self._client.aclose()
