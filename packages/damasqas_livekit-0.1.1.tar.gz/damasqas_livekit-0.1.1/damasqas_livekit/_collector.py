"""
Collects all events from a LiveKit AgentSession and batches them
for transport to the Damasqas ingestion API.
"""

import asyncio
import inspect
import time
import logging
from typing import Optional, Any
from dataclasses import dataclass, field

from damasqas_livekit._transport import MetricsTransport

logger = logging.getLogger("damasqas_livekit")


@dataclass
class TurnMetrics:
    """Accumulates all metrics for a single speech turn (grouped by speech_id)."""

    speech_id: str
    started_at: float = 0.0

    # STT
    stt_provider: Optional[str] = None
    stt_duration_ms: Optional[int] = None
    stt_audio_duration_ms: Optional[int] = None
    stt_error: Optional[str] = None

    # LLM
    llm_provider: Optional[str] = None
    llm_model: Optional[str] = None
    llm_ttft_ms: Optional[int] = None
    llm_total_duration_ms: Optional[int] = None
    llm_input_tokens: Optional[int] = None
    llm_output_tokens: Optional[int] = None
    llm_cached_tokens: Optional[int] = None
    llm_tokens_per_second: Optional[float] = None
    llm_cancelled: bool = False
    llm_error: Optional[str] = None

    # TTS
    tts_provider: Optional[str] = None
    tts_ttfb_ms: Optional[int] = None
    tts_duration_ms: Optional[int] = None
    tts_audio_duration_ms: Optional[int] = None
    tts_characters: Optional[int] = None
    tts_cancelled: bool = False
    tts_error: Optional[str] = None

    # VAD
    vad_speech_duration_ms: Optional[int] = None
    vad_silence_duration_ms: Optional[int] = None

    # EOU
    eou_latency_ms: Optional[int] = None

    # Interruption
    interruption_occurred: bool = False
    interruption_overlap_ms: Optional[int] = None

    # Tool calls (accumulated from turn_metrics, not function_tools_executed)
    tool_calls: list = field(default_factory=list)

    # Computed
    e2e_latency_ms: Optional[int] = None

    def compute_e2e(self) -> None:
        """Compute end-to-end latency: STT + LLM(TTFT) + TTS(TTFB)."""
        parts = [self.stt_duration_ms, self.llm_ttft_ms, self.tts_ttfb_ms]
        if all(p is not None for p in parts):
            self.e2e_latency_ms = sum(parts)  # type: ignore[arg-type]


def _s_to_ms(val: Any) -> Optional[int]:
    """Convert seconds (float) to milliseconds (int)."""
    if val is None:
        return None
    return int(val * 1000)


class EventCollector:
    """
    Attaches to all AgentSession events and collects telemetry.

    Batching strategy:
    - Metrics are grouped by speech_id into TurnMetrics objects.
    - When a TurnMetrics has all three pipeline stages (STT + LLM + TTS),
      it's considered complete and flushed.
    - A background timer flushes incomplete turns after 10 seconds.
    - Tool calls, transcripts, state changes, and session close are
      sent immediately as separate event types.
    """

    def __init__(
        self,
        session: Any,
        transport: MetricsTransport,
        workspace_id: Optional[str],
    ):
        self._session = session
        self._transport = transport
        self._workspace_id = workspace_id
        self._room_sid: Optional[str] = None
        self._room_name: Optional[str] = None
        self._room_resolved = False
        self._turns: dict[str, TurnMetrics] = {}
        self._turn_index = 0
        self._session_start = time.time()
        self._flush_task: Optional[asyncio.Task] = None
        # Hold references to spawned tasks so they aren't GC'd mid-flight.
        self._pending_tasks: set[asyncio.Task] = set()

    def _spawn(self, coro) -> None:
        """Schedule a coroutine as a task, preventing GC until it completes."""
        task = asyncio.create_task(coro)
        self._pending_tasks.add(task)
        task.add_done_callback(self._pending_tasks.discard)

    def attach(self) -> None:
        """Register event handlers on the session."""
        s = self._session

        # LiveKit >=1.5.0 requires sync callbacks on .on(). Wrap async
        # handlers so they schedule a task instead of being passed directly.
        def _sync(async_fn):
            def wrapper(ev):
                self._spawn(async_fn(ev))
            return wrapper

        # TODO: metrics_collected is deprecated in livekit-agents>=1.5.0.
        # Migrate to session_usage_updated + ChatMessage.metrics.
        s.on("metrics_collected", _sync(self._on_metrics))
        s.on("function_tools_executed", _sync(self._on_tools_executed))
        s.on("user_input_transcribed", _sync(self._on_user_transcript))
        s.on("conversation_item_added", _sync(self._on_conversation_item))
        s.on("agent_state_changed", _sync(self._on_state_changed))
        s.on("speech_created", _sync(self._on_speech_created))
        s.on("close", _sync(self._on_close))

        # Defer flush loop start — it will be created on first event when
        # the event loop is guaranteed to be running
        self._flush_task = None

    async def _resolve_room(self) -> None:
        """Resolve room SID and name from the session (async-safe)."""
        if self._room_resolved:
            return
        self._room_resolved = True
        try:
            room = None
            if hasattr(self._session, "room") and self._session.room:
                room = self._session.room
            elif hasattr(self._session, "_room_io") and self._session._room_io:
                room = self._session._room_io._room

            if room is None:
                return

            sid = room.sid
            if inspect.isawaitable(sid):
                sid = await sid
            self._room_sid = sid

            name = room.name
            if inspect.isawaitable(name):
                name = await name
            self._room_name = name
        except Exception:
            pass

    async def _flush_loop(self) -> None:
        """Flush stale turns every 5 seconds."""
        while True:
            await asyncio.sleep(5)
            now = time.time()
            stale_ids = [
                sid
                for sid, turn in self._turns.items()
                if (now - turn.started_at) > 10
            ]
            for sid in stale_ids:
                await self._flush_turn(sid)

    def _ensure_flush_loop(self) -> None:
        """Lazily start the background flush loop when the event loop is running."""
        if self._flush_task is not None:
            return
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                self._flush_task = asyncio.ensure_future(self._flush_loop())
        except RuntimeError:
            pass

    # ── metrics_collected handler ────────────────────────────────

    async def _on_metrics(self, ev: Any) -> None:
        """
        Called for every STT/LLM/TTS/VAD/EOU/Interruption metric.
        Groups by speech_id into TurnMetrics.
        """
        try:
            await self._resolve_room()
            self._ensure_flush_loop()

            m = ev.metrics
            speech_id = getattr(m, "speech_id", None) or f"unknown_{time.time()}"
            type_name = type(m).__name__.lower()

            if speech_id not in self._turns:
                self._turns[speech_id] = TurnMetrics(
                    speech_id=speech_id,
                    started_at=time.time(),
                )
            turn = self._turns[speech_id]

            if "stt" in type_name:
                turn.stt_provider = getattr(m, "label", None)
                turn.stt_duration_ms = _s_to_ms(getattr(m, "duration", None))
                turn.stt_audio_duration_ms = _s_to_ms(
                    getattr(m, "audio_duration", None)
                )
                turn.stt_error = (
                    str(m.error) if getattr(m, "error", None) else None
                )

            elif "llm" in type_name and "realtime" not in type_name:
                # LLM fires multiple times per turn if tool calls happen.
                # Keep the first TTFT (most meaningful for user-perceived latency)
                # but accumulate tokens from all completions.
                new_ttft = _s_to_ms(getattr(m, "ttft", None))
                new_duration = _s_to_ms(getattr(m, "duration", None))
                new_input = getattr(m, "prompt_tokens", None)
                new_output = getattr(m, "completion_tokens", None)

                turn.llm_provider = getattr(m, "label", None)
                turn.llm_model = getattr(m, "model", None)

                # Preserve first TTFT — it's the user-perceived latency
                if turn.llm_ttft_ms is None:
                    turn.llm_ttft_ms = new_ttft

                # Accumulate duration across all LLM completions
                if new_duration is not None:
                    turn.llm_total_duration_ms = (
                        (turn.llm_total_duration_ms or 0) + new_duration
                    )

                # Accumulate tokens across all LLM completions
                if new_input is not None:
                    turn.llm_input_tokens = (
                        (turn.llm_input_tokens or 0) + new_input
                    )
                if new_output is not None:
                    turn.llm_output_tokens = (
                        (turn.llm_output_tokens or 0) + new_output
                    )

                turn.llm_cached_tokens = getattr(
                    m, "prompt_cached_tokens", None
                )
                turn.llm_tokens_per_second = getattr(
                    m, "tokens_per_second", None
                )
                turn.llm_cancelled = getattr(m, "cancelled", False)
                turn.llm_error = (
                    str(m.error) if getattr(m, "error", None) else None
                )

            elif "tts" in type_name:
                turn.tts_provider = getattr(m, "label", None)
                turn.tts_ttfb_ms = _s_to_ms(getattr(m, "ttfb", None))
                turn.tts_duration_ms = _s_to_ms(getattr(m, "duration", None))
                turn.tts_audio_duration_ms = _s_to_ms(
                    getattr(m, "audio_duration", None)
                )
                turn.tts_characters = getattr(m, "characters_count", None)
                turn.tts_cancelled = getattr(m, "cancelled", False)
                turn.tts_error = (
                    str(m.error) if getattr(m, "error", None) else None
                )

            elif "vad" in type_name:
                turn.vad_speech_duration_ms = _s_to_ms(
                    getattr(m, "speech_duration", None)
                )
                turn.vad_silence_duration_ms = _s_to_ms(
                    getattr(m, "silence_duration", None)
                )

            elif "eou" in type_name:
                turn.eou_latency_ms = _s_to_ms(getattr(m, "duration", None))

            elif "interruption" in type_name:
                turn.interruption_occurred = True
                turn.interruption_overlap_ms = _s_to_ms(
                    getattr(m, "duration", None)
                )

            # Flush if turn is complete (all three pipeline stages present)
            if (
                turn.stt_duration_ms is not None
                and turn.llm_ttft_ms is not None
                and turn.tts_ttfb_ms is not None
            ):
                turn.compute_e2e()
                await self._flush_turn(speech_id)
        except Exception:
            pass  # Never crash the voice pipeline

    # ── function_tools_executed handler ──────────────────────────

    async def _on_tools_executed(self, ev: Any) -> None:
        """Captures tool call names, durations, success/failure."""
        try:
            tools_data = []
            for tool_result in ev.tools:
                record: dict[str, Any] = {
                    "name": getattr(tool_result, "name", "unknown"),
                    "success": getattr(tool_result, "error", None) is None,
                    "error": (
                        str(tool_result.error)
                        if getattr(tool_result, "error", None)
                        else None
                    ),
                }
                if (
                    hasattr(tool_result, "duration")
                    and tool_result.duration is not None
                ):
                    record["duration_ms"] = _s_to_ms(tool_result.duration)

                tools_data.append(record)

            await self._transport.send(
                {
                    "type": "tool_calls",
                    "workspace_id": self._workspace_id,
                    "room_sid": self._room_sid,
                    "room_name": self._room_name,
                    "timestamp": time.time(),
                    "tools": tools_data,
                }
            )
        except Exception:
            pass

    # ── user_input_transcribed handler ───────────────────────────

    async def _on_user_transcript(self, ev: Any) -> None:
        """Captures user speech transcriptions (final only)."""
        try:
            if not getattr(ev, "is_final", True):
                return

            await self._transport.send(
                {
                    "type": "transcript",
                    "workspace_id": self._workspace_id,
                    "room_sid": self._room_sid,
                    "room_name": self._room_name,
                    "timestamp": time.time(),
                    "role": "user",
                    "text": getattr(ev, "transcript", ""),
                    "language": getattr(ev, "language", None),
                }
            )
        except Exception:
            pass

    # ── conversation_item_added handler ──────────────────────────

    async def _on_conversation_item(self, ev: Any) -> None:
        """Captures agent responses for intent/topic tracking."""
        try:
            item = ev.item
            role = getattr(item, "role", "unknown")

            if role != "assistant":
                return

            await self._transport.send(
                {
                    "type": "transcript",
                    "workspace_id": self._workspace_id,
                    "room_sid": self._room_sid,
                    "room_name": self._room_name,
                    "timestamp": time.time(),
                    "role": "agent",
                    "text": getattr(item, "text_content", ""),
                    "interrupted": getattr(item, "interrupted", False),
                }
            )
        except Exception:
            pass

    # ── agent_state_changed handler ──────────────────────────────

    async def _on_state_changed(self, ev: Any) -> None:
        """Captures agent state transitions."""
        try:
            await self._transport.send(
                {
                    "type": "state_change",
                    "workspace_id": self._workspace_id,
                    "room_sid": self._room_sid,
                    "room_name": self._room_name,
                    "timestamp": time.time(),
                    "state": getattr(ev, "state", "unknown"),
                }
            )
        except Exception:
            pass

    # ── speech_created handler ───────────────────────────────────

    async def _on_speech_created(self, ev: Any) -> None:
        """Captures when agent starts generating speech."""
        try:
            await self._transport.send(
                {
                    "type": "speech_created",
                    "workspace_id": self._workspace_id,
                    "room_sid": self._room_sid,
                    "room_name": self._room_name,
                    "timestamp": time.time(),
                    "source": getattr(ev, "source", "unknown"),
                }
            )
        except Exception:
            pass

    # ── close handler ────────────────────────────────────────────

    async def _on_close(self, ev: Any) -> None:
        """Captures session end reason and any errors. Awaits all flushes in order."""
        try:
            # Cancel flush loop first to avoid concurrent flushes
            if self._flush_task:
                self._flush_task.cancel()

            # Wait for any in-flight event handler tasks to finish so their
            # metrics are captured before we do the final flush.
            in_flight = [t for t in self._pending_tasks if t is not asyncio.current_task()]
            if in_flight:
                await asyncio.gather(*in_flight, return_exceptions=True)

            # Flush all remaining turns (awaited sequentially to guarantee ordering)
            for speech_id in list(self._turns.keys()):
                await self._flush_turn(speech_id)

            error_info = None
            if hasattr(ev, "error") and ev.error:
                error_info = {
                    "type": type(ev.error).__name__,
                    "message": str(ev.error),
                }

            # Send session_close after all turns are flushed
            await self._transport.send(
                {
                    "type": "session_close",
                    "workspace_id": self._workspace_id,
                    "room_sid": self._room_sid,
                    "room_name": self._room_name,
                    "timestamp": time.time(),
                    "reason": getattr(ev, "reason", "unknown"),
                    "error": error_info,
                    "session_duration_s": round(
                        time.time() - self._session_start, 2
                    ),
                    "total_turns": self._turn_index,
                }
            )

            # Close transport after everything is queued
            await self._transport.close()
        except Exception:
            pass

    # ── Flush logic ──────────────────────────────────────────────

    async def _flush_turn(self, speech_id: str) -> None:
        """Send a completed turn to Damasqas and remove from buffer."""
        if speech_id not in self._turns:
            return

        turn = self._turns.pop(speech_id)
        self._turn_index += 1

        turn.compute_e2e()

        await self._transport.send(
            {
                "type": "turn_metrics",
                "workspace_id": self._workspace_id,
                "room_sid": self._room_sid,
                "room_name": self._room_name,
                "turn_index": self._turn_index,
                "speech_id": turn.speech_id,
                "timestamp": turn.started_at,
                # STT
                "stt_provider": turn.stt_provider,
                "stt_duration_ms": turn.stt_duration_ms,
                "stt_audio_duration_ms": turn.stt_audio_duration_ms,
                "stt_error": turn.stt_error,
                # LLM
                "llm_provider": turn.llm_provider,
                "llm_model": turn.llm_model,
                "llm_ttft_ms": turn.llm_ttft_ms,
                "llm_total_duration_ms": turn.llm_total_duration_ms,
                "llm_input_tokens": turn.llm_input_tokens,
                "llm_output_tokens": turn.llm_output_tokens,
                "llm_cached_tokens": turn.llm_cached_tokens,
                "llm_tokens_per_second": turn.llm_tokens_per_second,
                "llm_cancelled": turn.llm_cancelled,
                "llm_error": turn.llm_error,
                # TTS
                "tts_provider": turn.tts_provider,
                "tts_ttfb_ms": turn.tts_ttfb_ms,
                "tts_duration_ms": turn.tts_duration_ms,
                "tts_audio_duration_ms": turn.tts_audio_duration_ms,
                "tts_characters": turn.tts_characters,
                "tts_cancelled": turn.tts_cancelled,
                "tts_error": turn.tts_error,
                # VAD / EOU / Interruption
                "vad_speech_duration_ms": turn.vad_speech_duration_ms,
                "vad_silence_duration_ms": turn.vad_silence_duration_ms,
                "eou_latency_ms": turn.eou_latency_ms,
                "interruption_occurred": turn.interruption_occurred,
                "interruption_overlap_ms": turn.interruption_overlap_ms,
                # Computed
                "e2e_latency_ms": turn.e2e_latency_ms,
                # Tool calls from this turn
                "tool_calls": turn.tool_calls,
            }
        )
