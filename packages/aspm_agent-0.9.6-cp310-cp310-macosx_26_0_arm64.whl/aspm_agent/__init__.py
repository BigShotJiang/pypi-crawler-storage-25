__version__ = "0.9.6"
__author__ = "ARX Security"
__email__ = "support@arx-security.ru"
__license__ = "MIT"
