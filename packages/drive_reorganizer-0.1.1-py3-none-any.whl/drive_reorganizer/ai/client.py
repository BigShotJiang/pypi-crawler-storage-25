import anthropic

from ..config import get_api_key
from ..drive.models import DriveTree
from .prompts import SYSTEM_PROMPT, build_prompt

MODEL = "claude-sonnet-4-6"


class ClaudeClient:
    def __init__(self) -> None:
        api_key = get_api_key()
        if not api_key:
            raise EnvironmentError(
                "Anthropic API key not configured.\n"
                "Run 'drive-reorganizer setup' to add your key."
            )
        self._client = anthropic.Anthropic(api_key=api_key)

    def suggest_reorganization(self, tree: DriveTree) -> str:
        prompt = build_prompt(tree)
        message = self._client.messages.create(
            model=MODEL,
            max_tokens=2048,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        return message.content[0].text
