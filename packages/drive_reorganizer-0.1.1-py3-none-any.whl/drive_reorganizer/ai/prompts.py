from datetime import datetime, timezone

from ..drive.models import DriveItem, DriveTree, TREE_DEPTH

# Max children to list per folder before summarizing
MAX_CHILDREN = 30


SYSTEM_PROMPT = """You are an expert in digital file organization and information architecture.

You will be given a Google Drive folder structure (names, types, and modification dates only — no file contents).

Your task is to analyze the structure and suggest a reorganization that improves clarity, reduces clutter, and makes files easier to find.

Output your response in three sections:

## Issues Found
A bulleted list of specific problems (e.g., overstuffed folders, stale content mixed with active content, vague names, redundant nesting, etc.).

## Recommended Changes
Concrete, actionable suggestions. Be specific — name the actual folders and files. Do not give generic advice.

## Proposed Structure
Show the suggested folder hierarchy as an indented tree. Only show folders (not individual files). Annotate each folder with a brief note on what belongs there.

Rules:
- Suggestions must be read-only recommendations. Do not imply any commands or scripts.
- If a section of the drive looks well-organized, say so — do not invent problems.
- Flag anything you are uncertain about rather than guessing.
- Prioritize the user's apparent existing organizational intent over imposing a rigid system."""


def build_prompt(tree: DriveTree) -> str:
    serialized = _serialize_tree(tree.root, depth=0)
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return (
        f"Today's date: {now}\n"
        f"Total items in Drive: {tree.total_items}\n\n"
        f"Current Google Drive structure:\n\n"
        f"{serialized}"
    )


def _serialize_tree(item: DriveItem, depth: int) -> str:
    indent = "  " * depth
    icon = "📁" if item.is_folder else "📄"
    date_hint = f"  [{item.modified_date_str}]" if item.modified_time else ""
    child_count = len(item.children)

    if item.is_folder and child_count > 0:
        count_hint = f" ({child_count} items)"
    else:
        count_hint = ""

    line = f"{indent}{icon} {item.name}{count_hint}{date_hint}\n"

    if not item.is_folder or depth >= TREE_DEPTH:
        return line

    children_output = ""
    shown = 0
    for child in item.children:
        if shown >= MAX_CHILDREN:
            remaining = child_count - shown
            children_output += f"{'  ' * (depth + 1)}... and {remaining} more items\n"
            break
        children_output += _serialize_tree(child, depth + 1)
        shown += 1

    return line + children_output
