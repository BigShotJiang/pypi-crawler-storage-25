from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

from ..config import TOKEN_PATH, get_client_secret_path, get_config_dir

SCOPES = ["https://www.googleapis.com/auth/drive.metadata.readonly"]


def get_credentials(no_browser: bool = False) -> Credentials:
    """
    Load cached credentials or run OAuth flow.
    Saves token.json after first successful auth so subsequent runs skip the browser.
    """
    creds = None

    if TOKEN_PATH.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_PATH), SCOPES)

    if creds and creds.valid:
        return creds

    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
        _save_token(creds)
        return creds

    client_secret_path = get_client_secret_path()
    if not client_secret_path.exists():
        raise FileNotFoundError(
            f"Google OAuth credentials not found at {client_secret_path}.\n"
            f"Set GOOGLE_CLIENT_SECRET_PATH to point to your client_secret.json."
        )

    flow = InstalledAppFlow.from_client_secrets_file(str(client_secret_path), SCOPES)

    if no_browser:
        creds = flow.run_console()
    else:
        creds = flow.run_local_server(port=0)

    _save_token(creds)
    return creds


def revoke_token() -> None:
    """Delete the saved token, forcing re-authentication on next run."""
    if TOKEN_PATH.exists():
        TOKEN_PATH.unlink()


def _save_token(creds: Credentials) -> None:
    get_config_dir()
    with open(TOKEN_PATH, "w") as f:
        f.write(creds.to_json())
    TOKEN_PATH.chmod(0o600)
