"""
Manages user configuration stored in ~/.config/drive-reorganizer/.
All credentials and settings live here — nothing is stored in the project directory.
"""
import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "drive-reorganizer"
CONFIG_FILE = CONFIG_DIR / "config.json"
TOKEN_PATH = CONFIG_DIR / "token.json"

# Bundled OAuth client credentials (injected at build time, never committed to the repo).
# Override with GOOGLE_CLIENT_SECRET_PATH for local development or testing.
_BUNDLED_CLIENT_SECRET = Path(__file__).parent / "client_secret.json"


def get_client_secret_path() -> Path:
    if override := os.environ.get("GOOGLE_CLIENT_SECRET_PATH"):
        return Path(override)
    return _BUNDLED_CLIENT_SECRET


def get_config_dir() -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def _read_config() -> dict:
    try:
        return json.loads(CONFIG_FILE.read_text())
    except json.JSONDecodeError as e:
        raise ValueError(
            f"config.json is invalid and could not be read: {e}\n"
            f"Fix or delete {CONFIG_FILE} and run 'drive-reorganizer setup' again."
        ) from e


def get_api_key() -> str | None:
    """Return Anthropic API key — env var takes precedence over config file.

    Returns the stripped key, or None if absent or whitespace-only.
    """
    if raw := os.environ.get("ANTHROPIC_API_KEY"):
        if key := raw.strip():
            return key
    if CONFIG_FILE.exists():
        raw = _read_config().get("anthropic_api_key")
        if raw and (key := raw.strip()):
            return key
    return None


def save_api_key(api_key: str) -> None:
    get_config_dir()
    if CONFIG_FILE.exists():
        try:
            data = _read_config()
        except ValueError:
            data = {}
    else:
        data = {}
    data["anthropic_api_key"] = api_key
    CONFIG_FILE.write_text(json.dumps(data, indent=2))
    CONFIG_FILE.chmod(0o600)


def is_configured() -> dict[str, bool]:
    """Return a dict describing which components are configured."""
    return {
        "api_key": bool(get_api_key()),
        "authenticated": TOKEN_PATH.exists(),
    }
