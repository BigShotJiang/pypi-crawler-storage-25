from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.tree import Tree

from ..drive.models import DriveItem, DriveTree, TREE_DEPTH

# Icon map for known types
_ICONS = {
    "folder": "[bold blue]📁[/]",
    "doc": "[cyan]📝[/]",
    "sheet": "[green]📊[/]",
    "slides": "[yellow]📋[/]",
    "pdf": "[red]📄[/]",
    "image": "[magenta]🖼[/]",
    "video": "[magenta]🎬[/]",
    "audio": "[magenta]🎵[/]",
    "file": "[white]📄[/]",
    "form": "[cyan]📋[/]",
}

class Renderer:
    def __init__(self, no_color: bool = False) -> None:
        self._console = Console(no_color=no_color)

    def render_tree(self, drive_tree: DriveTree) -> None:
        self._console.print()
        rich_tree = Tree(
            f"[bold blue]📁 My Drive[/] [dim]({drive_tree.total_items} items total)[/]"
        )
        for child in drive_tree.root.children:
            _add_node(rich_tree, child, depth=1)
        self._console.print(
            Panel(rich_tree, title="[bold]Current Drive Structure[/]", border_style="blue")
        )

    def render_thinking(self) -> None:
        self._console.print("\n[dim]Analyzing with Claude...[/]\n")

    def render_suggestions(self, suggestions: str) -> None:
        self._console.print(
            Panel(
                Markdown(suggestions),
                title="[bold green]Reorganization Suggestions[/]",
                border_style="green",
            )
        )
        self._console.print()

    def render_error(self, message: str) -> None:
        self._console.print(f"\n[bold red]Error:[/] {message}\n")

    def render_info(self, message: str) -> None:
        self._console.print(f"[dim]{message}[/]")


def _add_node(parent_node: Tree, item: DriveItem, depth: int) -> None:
    icon = _ICONS.get(item.type_label, _ICONS["file"])
    date = f" [dim]{item.modified_date_str}[/]" if item.modified_time else ""
    label = f"{icon} {item.name}{date}"

    if item.is_folder and item.children:
        label += f" [dim]({len(item.children)})[/]"

    node = parent_node.add(label)

    if item.is_folder and depth < TREE_DEPTH:
        for child in item.children:
            _add_node(node, child, depth + 1)
    elif item.is_folder and item.children:
        node.add("[dim]...[/]")
