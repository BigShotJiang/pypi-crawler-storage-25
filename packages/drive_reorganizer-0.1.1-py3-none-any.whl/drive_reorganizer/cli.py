import os
import sys

import click
from rich.console import Console
from rich.table import Table

from .auth.google_auth import get_credentials
from .config import (
    TOKEN_PATH,
    get_api_key,
    is_configured,
    save_api_key,
)
from .drive.client import DriveClient
from .ai.client import ClaudeClient
from .output.renderer import Renderer

VERSION = "0.1.0"


@click.group()
@click.version_option(version=VERSION, prog_name="drive-reorganizer")
def cli():
    """Drive Reorganizer — AI-powered Google Drive structure analyzer."""
    pass


@cli.command()
@click.option("--no-browser", is_flag=True, help="Use console-based OAuth (for headless environments).")
@click.option("--no-color", is_flag=True, help="Disable colored output (useful for piping).")
def analyze(no_browser: bool, no_color: bool):
    """Fetch your Drive structure and get AI reorganization suggestions."""
    renderer = Renderer(no_color=no_color)

    status = is_configured()
    if not all(status.values()):
        renderer.render_error(
            "Setup is incomplete. Run 'drive-reorganizer doctor' to see what's missing."
        )
        sys.exit(1)

    renderer.render_info("Authenticating with Google Drive...")
    try:
        credentials = get_credentials(no_browser=no_browser)
    except FileNotFoundError as e:
        renderer.render_error(str(e))
        sys.exit(1)
    except Exception as e:
        renderer.render_error(f"Authentication failed: {e}")
        sys.exit(1)

    renderer.render_info("Fetching Drive structure...")
    try:
        client = DriveClient(credentials)
        tree = client.get_folder_tree()
    except RuntimeError as e:
        renderer.render_error(str(e))
        sys.exit(1)

    renderer.render_info(f"Fetched {tree.total_items} items.")
    renderer.render_tree(tree)

    renderer.render_thinking()
    try:
        claude = ClaudeClient()
        suggestions = claude.suggest_reorganization(tree)
    except EnvironmentError as e:
        renderer.render_error(str(e))
        sys.exit(1)
    except Exception as e:
        renderer.render_error(f"Claude API error: {e}")
        sys.exit(1)

    renderer.render_suggestions(suggestions)


@cli.command()
@click.option("--no-browser", is_flag=True, help="Use console-based OAuth (for headless environments).")
def setup(no_browser: bool):
    """Interactive setup wizard — configure your Anthropic API key and connect Google Drive."""
    console = Console()
    console.print("\n[bold]Drive Reorganizer Setup[/bold]\n")

    # Step 1: Anthropic API key
    console.print("[bold]Step 1 of 2:[/bold] Anthropic API key")
    _setup_api_key_step(console)

    # Step 2: Google OAuth
    console.print("[bold]Step 2 of 2:[/bold] Connect Google Drive")
    if no_browser:
        console.print("  A console-based OAuth flow will be used. You will be asked to visit a URL and paste the authorization code.\n")
    else:
        console.print("  A browser window will open. Sign in and grant read-only access.\n")
    try:
        get_credentials(no_browser=no_browser)
        console.print("  [green]Authenticated successfully.[/green]\n")
    except Exception as e:
        console.print(f"\n  [red]Authentication failed:[/red] {e}\n")
        sys.exit(1)

    console.print("[bold green]Setup complete![/bold green] Run [cyan]drive-reorganizer analyze[/cyan] to get started.\n")


@cli.command()
def doctor():
    """Check that all required configuration is in place."""
    console = Console()
    status = is_configured()

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(style="dim")
    table.add_column()
    table.add_column()

    checks = [
        ("api_key", "Anthropic API key", "Run 'drive-reorganizer setup'"),
        ("authenticated", "Google Drive authentication", "Run 'drive-reorganizer setup' or 'drive-reorganizer reauth'"),
    ]

    all_ok = True
    for key, label, fix in checks:
        ok = status[key]
        if not ok:
            all_ok = False
        icon = "[green]✓[/green]" if ok else "[red]✗[/red]"
        note = "" if ok else f"[dim]{fix}[/dim]"
        table.add_row(icon, label, note)

    console.print()
    console.print(table)
    console.print()

    if all_ok:
        console.print("[green]Everything looks good.[/green] Run [cyan]drive-reorganizer analyze[/cyan].\n")
    else:
        console.print("[yellow]Some checks failed.[/yellow] Run [cyan]drive-reorganizer setup[/cyan] to fix them.\n")
        sys.exit(1)


@cli.command()
@click.option("--no-browser", is_flag=True, help="Use console-based OAuth (for headless environments).")
def reauth(no_browser: bool):
    """Re-authenticate with Google Drive (replaces saved token)."""
    staged_path = TOKEN_PATH.with_name(TOKEN_PATH.name + ".staged") if TOKEN_PATH.exists() else None
    if staged_path is not None:
        TOKEN_PATH.rename(staged_path)
    click.echo("Re-authenticating...")
    try:
        get_credentials(no_browser=no_browser)
    except Exception as e:
        if staged_path is not None and staged_path.exists():
            try:
                staged_path.rename(TOKEN_PATH)
            except OSError as rollback_err:
                click.echo(f"Warning: failed to restore previous token: {rollback_err}", err=True)
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    click.echo("Authentication successful.")
    if staged_path is not None and staged_path.exists():
        try:
            staged_path.unlink()
        except OSError as e:
            click.echo(f"Warning: could not remove stale token backup {staged_path}: {e}", err=True)


def _setup_api_key_step(console: Console) -> None:
    existing_key = get_api_key()
    env_key = os.environ.get("ANTHROPIC_API_KEY")
    if existing_key and env_key:
        console.print(
            f"  [yellow]Warning:[/yellow] An [bold]ANTHROPIC_API_KEY[/bold] environment variable is active "
            f"(ends in ...{env_key[-4:]}) and will take precedence over any saved config."
        )
        console.print(
            "  Choose an option:\n"
            "    [bold](a)[/bold] Save a new key to config anyway "
            "(the env var will continue to override until removed)\n"
            "    [bold](b)[/bold] Abort — unset the env var manually first "
            "([cyan]unset ANTHROPIC_API_KEY[/cyan]), then re-run setup\n"
            "    [bold](c)[/bold] Abort and do nothing"
        )
        choice = click.prompt(
            "  Your choice",
            type=click.Choice(["a", "b", "c"], case_sensitive=False),
            default="c",
        )
        if choice.lower() == "a":
            console.print(
                "  [yellow]Note:[/yellow] The env var will override the saved key until you remove it."
            )
            _prompt_and_save_api_key(console)
        elif choice.lower() == "b":
            console.print(
                "  Run [cyan]unset ANTHROPIC_API_KEY[/cyan] (or remove it from your shell profile), "
                "then re-run [cyan]drive-reorganizer setup[/cyan].\n"
            )
            sys.exit(0)
        else:
            console.print()
            sys.exit(0)
    elif existing_key:
        console.print(f"  [green]Already configured.[/green] (ends in ...{existing_key[-4:]})")
        if click.confirm("  Replace it?", default=False):
            _prompt_and_save_api_key(console)
        else:
            console.print()
    else:
        _prompt_and_save_api_key(console)


def _prompt_and_save_api_key(console: Console) -> None:
    while True:
        key = click.prompt("  Enter your Anthropic API key", hide_input=True).strip()
        if not key:
            console.print("  [yellow]Warning:[/yellow] API key cannot be empty.")
            continue
        if key.startswith("sk-"):
            break
        console.print("  [yellow]Warning:[/yellow] Key doesn't look like an Anthropic key (expected 'sk-...')")
        if click.confirm("  Save anyway?", default=False):
            break
    save_api_key(key)
    console.print("  [green]Saved.[/green]\n")


if __name__ == "__main__":
    cli()
