from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


FOLDER_MIME = "application/vnd.google-apps.folder"
TREE_DEPTH = 4

MIME_LABELS = {
    "application/vnd.google-apps.folder": "folder",
    "application/vnd.google-apps.document": "doc",
    "application/vnd.google-apps.spreadsheet": "sheet",
    "application/vnd.google-apps.presentation": "slides",
    "application/vnd.google-apps.form": "form",
    "application/pdf": "pdf",
    "image/jpeg": "image",
    "image/png": "image",
    "video/mp4": "video",
    "audio/mpeg": "audio",
}


@dataclass
class DriveItem:
    id: str
    name: str
    mime_type: str
    modified_time: Optional[datetime]
    parent_id: Optional[str]
    children: list["DriveItem"] = field(default_factory=list)

    @property
    def is_folder(self) -> bool:
        return self.mime_type == FOLDER_MIME

    @property
    def type_label(self) -> str:
        return MIME_LABELS.get(self.mime_type, "file")

    @property
    def modified_date_str(self) -> str:
        if self.modified_time is None:
            return "unknown"
        return self.modified_time.strftime("%Y-%m-%d")


@dataclass
class DriveTree:
    root: DriveItem
    total_items: int
