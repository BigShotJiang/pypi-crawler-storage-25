# standard
import base64
import json
from unittest.mock import AsyncMock, MagicMock, patch

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.providers.completions import CompletionsEngine
from sunwaee.modules.gen.engine.types import (
    FileAttachment,
    Message,
    Role,
    StopReason,
    Tool,
    ToolCall,
)

# Minimal 1x1 transparent PNG
_PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==")

ENGINE = CompletionsEngine(model="gpt-4.1-nano", api_key="test-key")
DEEPSEEK = CompletionsEngine(
    model="deepseek-reasoner",
    api_key="test-key",
    provider="deepseek",
    base_url="https://api.deepseek.com/v1",
)

DUMMY_TOOL = Tool(
    name="tasks",
    description="Manage tasks.",
    parameters={"type": "object", "properties": {}, "required": []},
)


### MESSAGES


def test_build_messages_user():
    result = ENGINE._build_messages([Message(role=Role.USER, content="Hi")])
    assert result == [{"role": "user", "content": "Hi"}]


def test_build_messages_system():
    result = ENGINE._build_messages([Message(role=Role.SYSTEM, content="You are Sun.")])
    assert result == [{"role": "system", "content": "You are Sun."}]


def test_build_messages_context_role():
    result = ENGINE._build_messages([Message(role=Role.CONTEXT, content="dynamic header")])
    assert result == [{"role": "system", "content": "<context>\ndynamic header\n</context>"}]


def test_build_messages_assistant_text():
    result = ENGINE._build_messages([Message(role=Role.ASSISTANT, content="Hello")])
    assert result == [{"role": "assistant", "content": "Hello"}]


def test_build_messages_assistant_with_tool_calls():
    tc = ToolCall(id="call-1", name="tasks", arguments={"action": "list"})
    result = ENGINE._build_messages([Message(role=Role.ASSISTANT, content=None, tool_calls=[tc])])
    msg = result[0]
    assert msg["role"] == "assistant"
    assert msg["tool_calls"][0]["id"] == "call-1"
    assert msg["tool_calls"][0]["type"] == "function"
    assert msg["tool_calls"][0]["function"]["name"] == "tasks"
    assert json.loads(msg["tool_calls"][0]["function"]["arguments"]) == {"action": "list"}


def test_build_messages_tool_result():
    result = ENGINE._build_messages([Message(role=Role.TOOL, content='{"ok": true}', tool_call_id="call-1")])
    assert result == [{"role": "tool", "tool_call_id": "call-1", "content": '{"ok": true}'}]


def test_build_messages_reasoning_content_echoed_on_last_turn():
    result = ENGINE._build_messages([Message(role=Role.ASSISTANT, content="Hi", reasoning_content="internal thought")])
    assert result[0]["reasoning_content"] == "internal thought"


def test_build_messages_reasoning_content_not_echoed_on_intermediate_turns():
    msgs = [
        Message(role=Role.USER, content="Q1"),
        Message(role=Role.ASSISTANT, content="A1", reasoning_content="thought1"),
        Message(role=Role.USER, content="Q2"),
        Message(role=Role.ASSISTANT, content="A2", reasoning_content="thought2"),
    ]
    result = ENGINE._build_messages(msgs)
    assistant_msgs = [m for m in result if m.get("role") == "assistant"]
    assert "reasoning_content" not in assistant_msgs[0]
    assert assistant_msgs[1]["reasoning_content"] == "thought2"


def test_build_messages_reasoning_content_echoed_with_tool_calls_on_last_turn():
    tc = ToolCall(id="call-1", name="tasks", arguments={"action": "list"})
    result = ENGINE._build_messages(
        [
            Message(
                role=Role.ASSISTANT,
                content=None,
                reasoning_content="thinking...",
                tool_calls=[tc],
            )
        ]
    )
    assert result[0]["reasoning_content"] == "thinking..."
    assert result[0]["tool_calls"][0]["id"] == "call-1"


def test_build_messages_no_reasoning_content_key_when_none():
    result = ENGINE._build_messages([Message(role=Role.ASSISTANT, content="Hi")])
    assert "reasoning_content" not in result[0]


### ATTACHMENTS


def test_build_messages_user_text_attachment():
    att = FileAttachment(data=b"file contents", filename="notes.txt")
    msgs = [Message(role=Role.USER, content="Here is a file", attachments=[att])]
    result = ENGINE._build_messages(msgs)
    content = result[0]["content"]
    assert isinstance(content, list)
    file_part = content[0]
    assert file_part["type"] == "text"
    assert '<file name="notes.txt">' in file_part["text"]
    assert "file contents" in file_part["text"]
    assert content[1] == {"type": "text", "text": "Here is a file"}


def test_build_messages_user_image_attachment():
    att = FileAttachment(data=_PNG, filename="photo.png")
    msgs = [Message(role=Role.USER, content="Look at this", attachments=[att])]
    result = ENGINE._build_messages(msgs)
    content = result[0]["content"]
    assert isinstance(content, list)
    img_part = content[0]
    assert img_part["type"] == "image_url"
    expected_url = f"data:image/png;base64,{base64.b64encode(_PNG).decode()}"
    assert img_part["image_url"]["url"] == expected_url
    assert content[1] == {"type": "text", "text": "Look at this"}


def test_build_messages_image_on_non_vision_model_raises():
    engine = CompletionsEngine(model="deepseek-chat", api_key="k", provider="deepseek")
    att = FileAttachment(data=_PNG, filename="photo.png")
    msgs = [Message(role=Role.USER, content="Hi", attachments=[att])]
    with pytest.raises(ValueError, match="does not support vision"):
        engine._build_messages(msgs)


def test_build_messages_multiple_attachments_ordered_before_text():
    att1 = FileAttachment(data=b"first", filename="a.txt")
    att2 = FileAttachment(data=b"second", filename="b.txt")
    msgs = [Message(role=Role.USER, content="see both", attachments=[att1, att2])]
    result = ENGINE._build_messages(msgs)
    content = result[0]["content"]
    assert len(content) == 3
    assert "a.txt" in content[0]["text"]
    assert "b.txt" in content[1]["text"]
    assert content[2] == {"type": "text", "text": "see both"}


### TOOLS


def test_build_tools():
    tools = ENGINE._build_tools([DUMMY_TOOL])
    assert tools == [
        {
            "type": "function",
            "function": {
                "name": "tasks",
                "description": "Manage tasks.",
                "parameters": {"type": "object", "properties": {}, "required": []},
            },
        }
    ]


def test_build_payload_with_tools():
    msgs = [Message(role=Role.USER, content="Hi")]
    payload = ENGINE._build_payload(msgs, tools=[DUMMY_TOOL])
    assert "tools" in payload
    assert payload["tools"][0]["function"]["name"] == "tasks"


def test_build_payload_no_reasoning_effort_by_default():
    msgs = [Message(role=Role.USER, content="Hi")]
    payload = ENGINE._build_payload(msgs, tools=None)
    assert "reasoning_effort" not in payload
    assert "thinking" not in payload


def test_build_payload_reasoning_effort_included_when_set():
    engine = CompletionsEngine(model="gpt-5-mini", api_key="k", reasoning_effort="high")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload["reasoning_effort"] == "high"


def test_build_payload_reasoning_effort_auto_not_sent():
    """'auto' means model reasons at its default — don't send the param."""
    engine = CompletionsEngine(model="kimi-k2.5", api_key="k", provider="moonshot", reasoning_effort="auto")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert "reasoning_effort" not in payload
    assert "thinking" not in payload


def test_build_payload_reasoning_effort_off_merges_disabled_payload():
    """kimi-k2.5 reasons by default — effort='off' merges reasoning_disabled_payload."""
    engine = CompletionsEngine(model="kimi-k2.5", api_key="k", provider="moonshot", reasoning_effort="off")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload.get("thinking") == {"type": "disabled"}
    assert "reasoning_effort" not in payload


def test_build_payload_reasoning_effort_off_no_disabled_payload_when_model_has_none():
    """Models without reasoning_disabled_payload and effort='off' → no reasoning keys set."""
    engine = CompletionsEngine(model="gpt-5-mini", api_key="k", reasoning_effort="off")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert "thinking" not in payload
    assert "reasoning_effort" not in payload


### RESPONSE PARSING


def _raw(
    content=None,
    tool_calls=None,
    finish_reason="stop",
    reasoning_content=None,
    prompt_tokens=10,
    completion_tokens=20,
):
    msg = {"content": content}
    if reasoning_content is not None:
        msg["reasoning_content"] = reasoning_content
    if tool_calls:
        msg["tool_calls"] = tool_calls
    return {
        "choices": [{"message": msg, "finish_reason": finish_reason}],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
        },
    }


def test_parse_response_text():
    r = ENGINE._parse_response(_raw(content="Hello!"))
    assert r.content == "Hello!"
    assert r.tool_calls is None
    assert r.stop_reason == StopReason.END_TURN
    assert r.usage
    assert r.usage.input_tokens == 10
    assert r.usage.output_tokens == 20
    assert r.reasoning_content is None
    assert r.provider == ENGINE.provider
    assert r.model == ENGINE.model


def test_parse_response_tool_calls():
    raw_tool_calls = [
        {
            "id": "call-1",
            "function": {"name": "tasks", "arguments": '{"action": "list"}'},
        }
    ]
    r = ENGINE._parse_response(_raw(tool_calls=raw_tool_calls, finish_reason="tool_calls"))
    assert r.stop_reason == StopReason.TOOL_USE
    assert r.tool_calls
    assert len(r.tool_calls) == 1
    assert r.tool_calls[0].id == "call-1"
    assert r.tool_calls[0].name == "tasks"
    assert r.tool_calls[0].arguments == {"action": "list"}


def test_parse_response_deepseek_reasoning():
    r = DEEPSEEK._parse_response(
        _raw(
            content="The answer is 42.",
            reasoning_content="Let me think step by step...",
        )
    )
    assert r.content == "The answer is 42."
    assert r.reasoning_content == "Let me think step by step..."
    assert r.reasoning_signature is None


def test_parse_response_stop_reason_mapping():
    assert ENGINE._parse_response(_raw(finish_reason="stop")).stop_reason == StopReason.END_TURN
    assert ENGINE._parse_response(_raw(finish_reason="tool_calls")).stop_reason == StopReason.TOOL_USE
    assert ENGINE._parse_response(_raw(finish_reason="length")).stop_reason == StopReason.MAX_TOKENS


def test_parse_response_multiple_tool_calls():
    raw_calls = [
        {"id": "c1", "function": {"name": "tasks", "arguments": '{"action": "list"}'}},
        {"id": "c2", "function": {"name": "notes", "arguments": '{"action": "list"}'}},
    ]
    r = ENGINE._parse_response(_raw(tool_calls=raw_calls, finish_reason="tool_calls"))
    assert r.tool_calls
    assert len(r.tool_calls) == 2


### CHAT - chat()


@pytest.mark.asyncio
async def test_chat_returns_response():
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = _raw(content="Hello from OpenAI")

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        response = await ENGINE.chat([Message(role=Role.USER, content="Hi")])

    assert response.content == "Hello from OpenAI"


@pytest.mark.asyncio
async def test_chat_raises_on_error():
    mock_resp = MagicMock()
    mock_resp.is_success = False
    mock_resp.status_code = 429
    mock_resp.text = "Rate limit"

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        with pytest.raises(RuntimeError, match="429"):
            await ENGINE.chat([Message(role=Role.USER, content="Hi")])


@pytest.mark.asyncio
async def test_chat_computes_cost_for_known_model():
    engine = CompletionsEngine(model="gpt-4.1-nano", api_key="test-key")
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = _raw(content="Hello from OpenAI")

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        response = await engine.chat([Message(role=Role.USER, content="Hi")])

    assert response.cost is not None
    assert response.cost.total > 0


@pytest.mark.asyncio
async def test_chat_with_text_attachment():
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = _raw(content="Got your file")

    att = FileAttachment(data=b"Hello from file", filename="notes.txt")
    msg = Message(role=Role.USER, content="Here is a file", attachments=[att])

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp) as mock_post:
        await ENGINE.chat([msg])

    payload = mock_post.call_args.kwargs["json"]
    content = payload["messages"][0]["content"]
    assert isinstance(content, list)
    assert content[0]["type"] == "text"
    assert '<file name="notes.txt">' in content[0]["text"]
    assert "Hello from file" in content[0]["text"]
    assert content[-1] == {"type": "text", "text": "Here is a file"}


@pytest.mark.asyncio
async def test_chat_with_image_attachment():
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = _raw(content="Got your image")

    att = FileAttachment(data=_PNG, filename="photo.png")
    msg = Message(role=Role.USER, content="Look at this", attachments=[att])

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp) as mock_post:
        await ENGINE.chat([msg])

    payload = mock_post.call_args.kwargs["json"]
    content = payload["messages"][0]["content"]
    assert isinstance(content, list)
    img = content[0]
    assert img["type"] == "image_url"
    expected_url = f"data:image/png;base64,{base64.b64encode(_PNG).decode()}"
    assert img["image_url"]["url"] == expected_url
    assert content[-1] == {"type": "text", "text": "Look at this"}


### STREAM - stream()


@pytest.mark.asyncio
async def test_stream_yields_text_chunks():
    lines = [
        'data: {"choices": [{"delta": {"content": "Hello"}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {"content": " world"}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {}, "finish_reason": "stop"}]}',
        'data: {"choices": [], "usage": {"prompt_tokens": 8, "completion_tokens": 2}}',
        "data: [DONE]",
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    chunks = [c async for c in ENGINE.stream([Message(role=Role.USER, content="Hi")])]

    text_chunks = [c for c in chunks if c.content]
    assert [c.content for c in text_chunks] == ["Hello", " world"]
    summary = chunks[-1]
    assert summary.content is None
    assert summary.stop_reason == StopReason.END_TURN
    assert summary.usage
    assert summary.usage.input_tokens == 8
    assert summary.usage.output_tokens == 2


@pytest.mark.asyncio
async def test_stream_yields_reasoning_content():
    lines = [
        'data: {"choices": [{"delta": {"reasoning_content": "thinking..."}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {"content": "Answer"}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {}, "finish_reason": "stop"}]}',
        "data: [DONE]",
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    chunks = [c async for c in ENGINE.stream([Message(role=Role.USER, content="Hi")])]

    assert chunks[0].reasoning_content == "thinking..."
    assert chunks[0].stop_reason is None
    assert chunks[1].content == "Answer"
    assert chunks[1].stop_reason is None


@pytest.mark.asyncio
async def test_stream_yields_tool_call():
    lines = [
        'data: {"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "tc_1", "function": {"name": "update_chat", "arguments": ""}}]}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": "{\\"title\\": \\"Test\\"}"}}]}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {}, "finish_reason": "tool_calls"}]}',
        "data: [DONE]",
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    chunks = [c async for c in ENGINE.stream([Message(role=Role.USER, content="Hi")])]

    tc_chunk = next(c for c in chunks if c.tool_calls)
    assert tc_chunk.tool_calls
    assert tc_chunk.tool_calls[0].id == "tc_1"
    assert tc_chunk.tool_calls[0].name == "update_chat"
    assert tc_chunk.tool_calls[0].arguments == {"title": "Test"}
    assert chunks[-1].stop_reason == StopReason.TOOL_USE


@pytest.mark.asyncio
async def test_stream_tool_call_trailing_args_with_finish_reason_same_chunk():
    lines = [
        'data: {"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "tc_1", "function": {"name": "f", "arguments": "{\\"a\\""}}]}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": ": 1}"}}]}, "finish_reason": "tool_calls"}]}',
        "data: [DONE]",
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    chunks = [c async for c in ENGINE.stream([Message(role=Role.USER, content="Hi")])]

    tc_chunk = next(c for c in chunks if c.tool_calls)
    assert tc_chunk.tool_calls[0].arguments == {"a": 1}
    assert chunks[-1].stop_reason == StopReason.TOOL_USE


@pytest.mark.asyncio
async def test_stream_only_done_yields_summary_chunk():
    lines = ["data: [DONE]"]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    chunks = [c async for c in ENGINE.stream([Message(role=Role.USER, content="Hi")])]

    assert len(chunks) == 1
    assert chunks[0].content is None


@pytest.mark.asyncio
async def test_stream_synthetic_stub_emitted_for_silent_reasoning_model():
    """When reasoning_effort is set on a model with reasoning_tokens_type=None, a
    sentinel fires so the consumer isn't left in the dark during silent thinking."""
    engine = CompletionsEngine(model="gpt-5", api_key="k", reasoning_effort="medium")
    lines = [
        'data: {"choices": [{"delta": {"content": "Hello"}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {}, "finish_reason": "stop"}]}',
        "data: [DONE]",
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    engine._client = mock_client
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    assert chunks[0].synthetic is True
    assert chunks[0].reasoning_content == "Reasoning in progress - tokens not available for this model"
    assert chunks[0].content is None
    assert chunks[1].content == "Hello"
    summary = chunks[-1]
    assert summary.performance is not None
    assert summary.performance.latency < 0.1


@pytest.mark.asyncio
async def test_stream_no_synthetic_stub_when_model_exposes_reasoning_tokens():
    """kimi-k2.5 has reasoning_tokens_type='raw' — no sentinel should be emitted,
    because real reasoning deltas will stream in."""
    engine = CompletionsEngine(
        model="kimi-k2.5",
        api_key="k",
        provider="moonshot",
        reasoning_effort="auto",
    )
    lines = [
        'data: {"choices": [{"delta": {"reasoning_content": "thinking"}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {"content": "Hi"}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {}, "finish_reason": "stop"}]}',
        "data: [DONE]",
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    engine._client = mock_client
    chunks = [c async for c in engine.stream([Message(role=Role.USER, content="Hi")])]

    assert all(not c.synthetic for c in chunks)


@pytest.mark.asyncio
async def test_stream_no_synthetic_stub_without_reasoning_effort():
    lines = [
        'data: {"choices": [{"delta": {"content": "Hi"}, "finish_reason": null}]}',
        'data: {"choices": [{"delta": {}, "finish_reason": "stop"}]}',
        "data: [DONE]",
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    chunks = [c async for c in ENGINE.stream([Message(role=Role.USER, content="Hi")])]

    assert all(c.reasoning_content is None for c in chunks)
    assert chunks[0].content == "Hi"


@pytest.mark.asyncio
async def test_stream_reads_body_before_raising_on_error():
    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = False
    mock_resp.status_code = 429
    mock_resp.aread = AsyncMock(return_value=b"Too Many Requests")

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    with pytest.raises(RuntimeError, match="429"):
        async for _ in ENGINE.stream([Message(role=Role.USER, content="Hi")]):
            pass


@pytest.mark.asyncio
async def test_chat_raises_auth_error_for_401():
    from sunwaee.modules.gen.engine.errors import AuthError

    mock_resp = MagicMock()
    mock_resp.is_success = False
    mock_resp.status_code = 401
    mock_resp.text = "Unauthorized"

    engine = CompletionsEngine(model="gpt-4.1-nano", api_key="test-key")
    engine._client = AsyncMock()
    engine._client.post = AsyncMock(return_value=mock_resp)

    with pytest.raises(AuthError):
        await engine.chat([Message(role=Role.USER, content="Hello")])


@pytest.mark.asyncio
async def test_chat_raises_rate_limit_error_for_429():
    from sunwaee.modules.gen.engine.errors import RateLimitError

    mock_resp = MagicMock()
    mock_resp.is_success = False
    mock_resp.status_code = 429
    mock_resp.text = "Too Many Requests"

    engine = CompletionsEngine(model="gpt-4.1-nano", api_key="test-key")
    engine._client = AsyncMock()
    engine._client.post = AsyncMock(return_value=mock_resp)

    with pytest.raises(RateLimitError):
        await engine.chat([Message(role=Role.USER, content="Hello")])


### HELPERS


async def aiter(items):
    for item in items:
        yield item
