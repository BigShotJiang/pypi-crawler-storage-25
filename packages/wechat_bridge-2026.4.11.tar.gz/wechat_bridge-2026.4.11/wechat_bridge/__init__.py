"""WeChat <-> Claude Code bridge via iLink Bot API."""

__version__ = "2026.4.11"
