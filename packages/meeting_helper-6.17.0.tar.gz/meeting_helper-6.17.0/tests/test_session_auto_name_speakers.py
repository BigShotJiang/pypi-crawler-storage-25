"""End-to-end: session._maybe_auto_name_speakers writes the sidecar."""
import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from meeting_helper import speakers


@pytest.fixture
def session_skeleton():
    cfg = MagicMock()
    cfg.auto_name_speakers_on_end = True
    cfg.user_display_name = ""
    cfg.preferred_provider = ""
    cfg.anthropic_api_key = "sk-test"
    cfg.claude_model = "claude-sonnet-4-6"
    cfg.max_tokens = 1024
    return cfg


def test_writes_sidecar_with_ai_names(tmp_path, session_skeleton):
    mp3 = tmp_path / "2026-05-14_0900_meeting.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text(
        "[00:01] OTHER#0: Hey Victor, hello.\n"
        "[00:02] SELF: hi back, this is Victor.\n"
        "[00:03] OTHER#1: Maria here.\n"
    )
    fake_map = speakers.SpeakerMap(
        names={"SELF": "Victor", "OTHER#0": None, "OTHER#1": "Maria"},
        evidence={"SELF": "this is Victor.", "OTHER#1": "Maria here."},
        source={"SELF": "ai", "OTHER#0": "ai", "OTHER#1": "ai"},
    )

    with patch(
        "meeting_helper.ai.client.name_speakers_from_transcript",
        new=AsyncMock(return_value=fake_map),
    ):
        from meeting_helper.session import _maybe_auto_name_speakers
        asyncio.run(_maybe_auto_name_speakers(mp3, live, session_skeleton))

    sidecar = speakers.speakers_path_for(mp3)
    assert sidecar.is_file()
    on_disk = speakers.read_speaker_map(sidecar)
    assert on_disk.names == {"SELF": "Victor", "OTHER#0": None, "OTHER#1": "Maria"}


def test_user_display_name_overrides_self(tmp_path, session_skeleton):
    session_skeleton.user_display_name = "VictorOverride"
    mp3 = tmp_path / "x.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text("[00:01] SELF: hi\n[00:02] OTHER#0: hello\n")
    fake_map = speakers.SpeakerMap(
        names={"SELF": "WrongAIGuess", "OTHER#0": "Maria"},
        source={"SELF": "ai", "OTHER#0": "ai"},
    )
    with patch(
        "meeting_helper.ai.client.name_speakers_from_transcript",
        new=AsyncMock(return_value=fake_map),
    ):
        from meeting_helper.session import _maybe_auto_name_speakers
        asyncio.run(_maybe_auto_name_speakers(mp3, live, session_skeleton))

    on_disk = speakers.read_speaker_map(speakers.speakers_path_for(mp3))
    assert on_disk.names["SELF"] == "VictorOverride"
    assert on_disk.source["SELF"] == "manual"


def test_disabled_writes_nothing(tmp_path, session_skeleton):
    session_skeleton.auto_name_speakers_on_end = False
    mp3 = tmp_path / "y.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text("[00:01] SELF: hi\n")
    from meeting_helper.session import _maybe_auto_name_speakers
    asyncio.run(_maybe_auto_name_speakers(mp3, live, session_skeleton))
    assert not speakers.speakers_path_for(mp3).exists()


def test_manual_entries_preserved_against_ai(tmp_path, session_skeleton):
    """If a sidecar already has manual entries, auto-naming must not overwrite them."""
    mp3 = tmp_path / "z.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text("[00:01] OTHER#0: hi\n[00:02] OTHER#1: hello\n")
    # Pre-existing manual entry.
    speakers.write_speaker_map(
        speakers.speakers_path_for(mp3),
        names={"OTHER#0": "Maria"},
        source={"OTHER#0": "manual"},
    )
    fake_map = speakers.SpeakerMap(
        names={"OTHER#0": "WrongAI", "OTHER#1": "Alex"},
        evidence={"OTHER#0": "x", "OTHER#1": "y"},
        source={"OTHER#0": "ai", "OTHER#1": "ai"},
    )
    with patch(
        "meeting_helper.ai.client.name_speakers_from_transcript",
        new=AsyncMock(return_value=fake_map),
    ):
        from meeting_helper.session import _maybe_auto_name_speakers
        asyncio.run(_maybe_auto_name_speakers(mp3, live, session_skeleton))

    on_disk = speakers.read_speaker_map(speakers.speakers_path_for(mp3))
    assert on_disk.names["OTHER#0"] == "Maria"
    assert on_disk.names["OTHER#1"] == "Alex"
    assert on_disk.source["OTHER#0"] == "manual"


def test_no_labels_returned_writes_nothing(tmp_path, session_skeleton):
    mp3 = tmp_path / "w.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text("[00:01] SELF: hi\n")
    empty = speakers.SpeakerMap()  # AI returned nothing parseable
    with patch(
        "meeting_helper.ai.client.name_speakers_from_transcript",
        new=AsyncMock(return_value=empty),
    ):
        from meeting_helper.session import _maybe_auto_name_speakers
        asyncio.run(_maybe_auto_name_speakers(mp3, live, session_skeleton))
    assert not speakers.speakers_path_for(mp3).exists()
