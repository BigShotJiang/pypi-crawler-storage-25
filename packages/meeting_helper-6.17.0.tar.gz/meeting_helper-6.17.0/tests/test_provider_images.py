from meeting_helper.ai.client import (
    _messages_to_gemini_contents,
    _openai_messages_from,
)


def _img_turn():
    return {
        "role": "user",
        "content": [
            {"type": "text", "text": "look"},
            {
                "type": "image",
                "source": {"type": "base64", "media_type": "image/jpeg", "data": "QUFB"},
            },
        ],
    }


def test_gemini_contents_include_inline_image():
    contents = _messages_to_gemini_contents([_img_turn()])
    parts = contents[-1].parts
    assert any(getattr(p, "inline_data", None) is not None for p in parts)
    assert any(getattr(p, "text", None) for p in parts)


def test_openai_messages_include_image_url():
    msgs = _openai_messages_from([_img_turn()], system="s")
    user = [m for m in msgs if m["role"] == "user"][0]
    assert isinstance(user["content"], list)
    assert any(b.get("type") == "image_url" for b in user["content"])
    assert any(b.get("type") == "text" for b in user["content"])


def test_openai_plain_string_passthrough():
    msgs = _openai_messages_from([{"role": "user", "content": "hi"}], system="s")
    assert msgs[0] == {"role": "system", "content": "s"}
    assert msgs[1] == {"role": "user", "content": "hi"}
