import subprocess

import pytest

from meeting_helper.git_context import (
    DiffSnapshot,
    GitContextError,
    current_branch,
    load_diff,
)


def _git(path, *args):
    subprocess.run(
        ["git", "-C", str(path), *args],
        check=True, capture_output=True, text=True,
    )


@pytest.fixture
def repo(tmp_path):
    p = tmp_path / "r"
    p.mkdir()
    _git(p, "init", "-q", "-b", "main")
    _git(p, "config", "user.email", "t@t")
    _git(p, "config", "user.name", "t")
    (p / "a.txt").write_text("base\n")
    _git(p, "add", "-A")
    _git(p, "commit", "-qm", "base")
    _git(p, "checkout", "-q", "-b", "feat")
    (p / "a.txt").write_text("base\nchange\n")
    _git(p, "commit", "-qam", "feat change")
    return p


def test_load_diff_returns_pr_view(repo):
    snap = load_diff(str(repo), "main")
    assert isinstance(snap, DiffSnapshot)
    assert snap.branch == "feat"
    assert len(snap.head_sha) >= 7
    assert "a.txt" in snap.stat
    assert "+change" in snap.body
    assert snap.truncated is False


def test_missing_base_raises(repo):
    with pytest.raises(GitContextError):
        load_diff(str(repo), "nonexistent-branch")


def test_not_a_repo_raises(tmp_path):
    with pytest.raises(GitContextError):
        current_branch(str(tmp_path))


def test_huge_diff_truncates(repo):
    big = "x\n" * 20000  # well over the cap
    (repo / "big.txt").write_text(big)
    _git(repo, "add", "-A")
    _git(repo, "commit", "-qm", "big")
    snap = load_diff(str(repo), "main", cap=2000)
    assert snap.truncated is True
    assert len(snap.body) <= 2000 + 200  # body + marker headroom
    assert "diff truncated" in snap.body
