"""Unit tests for the per-workspace skills store (ticket #269)."""
from __future__ import annotations

import pytest

from meeting_helper import skills as skills_store
from meeting_helper.chat import paths as chat_paths
from meeting_helper.chat.tools.skills import build_skills_create


@pytest.fixture(autouse=True)
def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


def test_read_all_empty_when_no_file():
    assert skills_store.list_skills() == []


def test_create_and_list():
    e = skills_store.create_skill(
        name="Start Ticket", description="kick it off", body="Please do X.",
    )
    assert e["id"].startswith("skl_")
    assert e["name"] == "start-ticket"  # slugified
    assert e["description"] == "kick it off"
    assert e["body"] == "Please do X."
    assert e["created_at"]
    assert e["updated_at"]
    listed = skills_store.list_skills()
    assert len(listed) == 1
    assert listed[0]["id"] == e["id"]


def test_create_missing_name_raises():
    with pytest.raises(skills_store.SkillError):
        skills_store.create_skill(name="   ", description="", body="body")


def test_create_slug_strips_to_empty_raises():
    """A name made entirely of disallowed chars must reject — not silently
    store a skill no slash trigger can reach."""
    with pytest.raises(skills_store.SkillError):
        skills_store.create_skill(name="@@@", description="", body="body")


def test_create_missing_body_raises():
    with pytest.raises(skills_store.SkillError):
        skills_store.create_skill(name="x", description="", body="   ")


def test_create_duplicate_slug_raises():
    skills_store.create_skill(name="start-ticket", description="", body="A")
    with pytest.raises(skills_store.SkillError):
        skills_store.create_skill(name="Start Ticket", description="", body="B")


def test_slugify_examples():
    assert skills_store._slugify("Start Ticket") == "start-ticket"
    assert skills_store._slugify("PR  review") == "pr-review"
    assert skills_store._slugify("foo_bar baz") == "foo-bar-baz"
    assert skills_store._slugify("//weird!!--name") == "weird-name"
    assert skills_store._slugify("") == ""
    assert skills_store._slugify("   ") == ""


def test_get_skill_returns_entry():
    e = skills_store.create_skill(name="abc", description="", body="hi")
    found = skills_store.get_skill(e["id"])
    assert found is not None
    assert found["id"] == e["id"]


def test_get_skill_missing_returns_none():
    assert skills_store.get_skill("skl_missing") is None


def test_update_renames_with_slugify():
    e = skills_store.create_skill(name="abc", description="", body="body")
    upd = skills_store.update_skill(e["id"], name="New Name")
    assert upd is not None
    assert upd["name"] == "new-name"


def test_update_body_and_description():
    e = skills_store.create_skill(name="abc", description="old", body="old body")
    upd = skills_store.update_skill(
        e["id"], description="new", body="new body",
    )
    assert upd is not None
    assert upd["description"] == "new"
    assert upd["body"] == "new body"


def test_update_to_existing_slug_raises():
    a = skills_store.create_skill(name="a", description="", body="x")
    skills_store.create_skill(name="b", description="", body="y")
    with pytest.raises(skills_store.SkillError):
        skills_store.update_skill(a["id"], name="b")


def test_update_missing_returns_none():
    assert skills_store.update_skill("skl_nope", name="x") is None


def test_update_empty_body_raises():
    e = skills_store.create_skill(name="abc", description="", body="body")
    with pytest.raises(skills_store.SkillError):
        skills_store.update_skill(e["id"], body="   ")


def test_delete_skill():
    e = skills_store.create_skill(name="abc", description="", body="body")
    assert skills_store.delete_skill(e["id"]) is True
    assert skills_store.list_skills() == []


def test_delete_missing_returns_false():
    assert skills_store.delete_skill("skl_nope") is False


# ---------------------------------------------------------------------------
# Chat-tool wrapper
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_tool_create_returns_ok_with_skill():
    out = await build_skills_create().run(
        {"name": "Start Ticket", "description": "d", "body": "do it"}, {},
    )
    assert out["status"] == "ok"
    assert out["result"]["skill"]["name"] == "start-ticket"


@pytest.mark.asyncio
async def test_tool_create_missing_name_returns_error():
    out = await build_skills_create().run({"body": "x"}, {})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_tool_create_missing_body_returns_error():
    out = await build_skills_create().run({"name": "x"}, {})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_tool_create_duplicate_returns_error():
    await build_skills_create().run(
        {"name": "dup", "body": "a"}, {},
    )
    out = await build_skills_create().run(
        {"name": "dup", "body": "b"}, {},
    )
    assert out["status"] == "error"
