"""POST /brief uses agent-fetched sprint_tickets → Haiku → returns {script, cards}."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def _make_task_dict(id, title, status="in_progress", workspace_id="2", workspace_name="Board"):
    """Build a dict in the shape agent_fetch returns."""
    return {
        "id": id, "title": title, "status": status, "status_kind": "in_progress",
        "priority": None, "body_md": "", "workspace_id": workspace_id,
        "workspace_name": workspace_name, "board_id": workspace_id,
        "board_name": workspace_name, "sprint_name": "Sprint 1", "url": None,
        "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
        "recent_history": [], "linked_docs": [],
    }


def _make_task_full(id, title, status="in_progress", workspace_id="2", workspace_name="Board"):
    from meeting_helper.trackers.profile import TaskFull
    return TaskFull(
        id=id, title=title, status=status, status_kind="in_progress",
        priority=None, body_md="", workspace_id=workspace_id,
        workspace_name=workspace_name, sprint_name="Sprint 1", url=None,
        subtasks=[], subtasks_summary={}, recent_comments=[], recent_history=[], linked_docs=[],
    )


@pytest.mark.asyncio
async def test_brief_handler_assembles_script_and_cards(aiohttp_client, monkeypatch):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    t_123 = _make_task_dict("PROJ-123", "Refresh tokens")
    t_119 = _make_task_dict("PROJ-119", "OAuth refactor", status="done")

    fake_tracker = MagicMock()

    fake_message = MagicMock()
    fake_message.content = [MagicMock(text=json.dumps({
        "script": "Yesterday I finished OAuth.\nToday I'm on refresh tokens.",
        "card_ids": ["PROJ-119", "PROJ-123"],
    }))]

    class FakeMessages:
        async def create(self, **kwargs):
            return fake_message

    class FakeAnthropic:
        def __init__(self, *args, **kwargs):
            self.messages = FakeMessages()

    global_state.tracker = fake_tracker
    # Pre-populate sprint_tickets so refresh_sprint_tickets uses cached data.
    global_state.sprint_tickets = [t_123, t_119]
    import time
    global_state.sprint_tickets_loaded_at = time.time()

    class FakeConfig:
        anthropic_api_key = "test-key"
        max_tokens = 800
        # Brief reads config.claude_model directly — never hardcoded.
        claude_model = "claude-haiku-4-5-20251001"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    with patch("meeting_helper.server.routes.AsyncAnthropic", new=FakeAnthropic, create=True):
        client = await aiohttp_client(app)
        resp = await client.post("/brief")
        assert resp.status == 200
        body = await resp.json()
        assert "Yesterday I finished OAuth" in body["script"]
        assert len(body["cards"]) == 2
        ids = [c["id"] for c in body["cards"]]
        assert "PROJ-119" in ids
        assert "PROJ-123" in ids

    global_state.tracker = None
    global_state.sprint_tickets = []
    global_state.sprint_tickets_loaded_at = 0


@pytest.mark.asyncio
async def test_brief_handler_returns_503_when_local_todo_unconfigured(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.tracker = None
    class FakeConfig: anthropic_api_key = "test-key"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.post("/brief")
    assert resp.status == 503


@pytest.mark.asyncio
async def test_last_cards_handler_returns_state_cards(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.last_cards = [
        {"kind": "task", "id": "PROJ-9", "title": "Test", "status": "open"}
    ]

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.get("/last_cards")
    assert resp.status == 200
    body = await resp.json()
    assert body["items"][0]["id"] == "PROJ-9"

    # Reset for other tests
    global_state.last_cards = []


@pytest.mark.asyncio
async def test_last_cards_handler_returns_empty_when_unset(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.last_cards = []

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.get("/last_cards")
    body = await resp.json()
    assert body["items"] == []


@pytest.mark.asyncio
async def test_brief_seeds_warm_cache(aiohttp_client):
    """After /brief succeeds, state.current_topic + state.current_topic_cards
    + state.self_buffer are populated so subsequent queries are grounded."""
    import json
    import time
    from unittest.mock import AsyncMock, MagicMock, patch
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state
    from meeting_helper.buffer import SentenceBuffer

    t_4212 = _make_task_dict("ENGT-4212", "Frontend contract layer", workspace_id="2", workspace_name="Board")
    t_4147 = _make_task_dict("ENGT-4147", "Status remapper", status="done", workspace_id="2", workspace_name="Board")

    fake_tracker = MagicMock()

    fake_message = MagicMock()
    fake_message.content = [MagicMock(text=json.dumps({
        "script": (
            "**Today**\n"
            "- I'm working on ENGT-4212 Phase 2 — Frontend contract layer + feature flag (PR #3635, draft).\n"
            "**Yesterday**\n"
            "- I finished ENGT-4147 — Status remapper: accept numeric severity values."
        ),
        "card_ids": ["ENGT-4212", "ENGT-4147"],
    }))]

    class FakeMessages:
        async def create(self, **kwargs):
            return fake_message

    class FakeAnthropic:
        def __init__(self, *a, **k):
            self.messages = FakeMessages()

    global_state.tracker = fake_tracker
    # Pre-populate sprint_tickets so refresh_sprint_tickets uses cached data.
    global_state.sprint_tickets = [t_4212, t_4147]
    global_state.sprint_tickets_loaded_at = time.time()
    global_state.self_buffer = SentenceBuffer(role="self")
    global_state.other_buffer = SentenceBuffer(role="other")
    global_state.current_topic = {"topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": ""}
    global_state.current_topic_cards = []

    class FakeConfig:
        anthropic_api_key = "test"
        max_tokens = 800
        claude_model = "claude-haiku-4-5-20251001"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    with patch("meeting_helper.server.routes.AsyncAnthropic", new=FakeAnthropic, create=True):
        client = await aiohttp_client(app)
        resp = await client.post("/brief")
        assert resp.status == 200

    # current_topic seeded
    assert "ENGT-4212" in global_state.current_topic["ticket_ids"]
    assert "ENGT-4147" in global_state.current_topic["ticket_ids"]
    assert "frontend contract layer" in global_state.current_topic["topic"].lower() or \
           "ENGT-4212" in global_state.current_topic["last_user_statement"]
    assert global_state.current_topic["last_user_statement"].startswith("I'm working on ENGT-4212")

    # current_topic_cards seeded from brief cards
    assert len(global_state.current_topic_cards) == 2
    assert any(c["id"] == "ENGT-4212" for c in global_state.current_topic_cards)

    # self_buffer received both bullet sentences
    self_sentences = global_state.self_buffer.get_last_n()
    assert any("ENGT-4212" in s for s in self_sentences)
    assert any("ENGT-4147" in s for s in self_sentences)

    # Reset
    global_state.tracker = None
    global_state.sprint_tickets = []
    global_state.sprint_tickets_loaded_at = 0
    global_state.current_topic = {"topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": ""}
    global_state.current_topic_cards = []
    global_state.self_buffer = None
    global_state.other_buffer = None


@pytest.mark.asyncio
async def test_debug_say_injects_into_self_buffer(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state
    from meeting_helper.buffer import SentenceBuffer

    global_state.self_buffer = SentenceBuffer(role="self")
    global_state.other_buffer = SentenceBuffer(role="other")

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)

    client = await aiohttp_client(app)
    resp = await client.post("/debug/say", json={"text": "I finished the auth refactor.", "role": "self"})
    assert resp.status == 200
    assert "I finished the auth refactor." in global_state.self_buffer.get_last_n()

    resp = await client.post("/debug/say", json={"text": "what about edge cases?", "role": "other"})
    assert resp.status == 200
    assert "what about edge cases?" in global_state.other_buffer.get_last_n()

    # Bad role
    resp = await client.post("/debug/say", json={"text": "test", "role": "bystander"})
    assert resp.status == 400

    # Empty text
    resp = await client.post("/debug/say", json={"text": "  ", "role": "self"})
    assert resp.status == 400

    # Reset
    global_state.self_buffer = None
    global_state.other_buffer = None
