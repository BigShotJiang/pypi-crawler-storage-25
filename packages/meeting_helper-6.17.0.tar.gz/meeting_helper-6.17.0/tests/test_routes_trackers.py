"""HTTP integration tests for /trackers CRUD, activate, and test endpoints."""
from __future__ import annotations

import pytest
from unittest.mock import patch, AsyncMock

from aiohttp.test_utils import TestClient, TestServer

from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.mark.asyncio
async def test_create_tracker_writes_secrets(monkeypatch):
    written: dict = {}
    monkeypatch.setattr(
        "meeting_helper.trackers.secrets.write_secrets",
        lambda ws, tid, values: written.update(values),
    )
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        resp = await client.post("/trackers", json={
            "vendor": "local_todo",
            "label": "Local",
            "auth_values": {"command": "npx"},
            "secrets": {},
        })
        assert resp.status == 201
        body = await resp.json()
        assert body["vendor"] == "local_todo"
        assert "id" in body
        assert "secrets" not in body  # never echoed


@pytest.mark.asyncio
async def test_activate_tracker_swaps(monkeypatch):
    monkeypatch.setattr(
        "meeting_helper.trackers.secrets.write_secrets",
        lambda ws, tid, values: None,
    )
    monkeypatch.setattr(
        "meeting_helper.trackers.secrets.read_secrets",
        lambda ws, tid, keys: {},
    )
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        await client.post("/trackers", json={
            "vendor": "local_todo", "label": "A",
            "auth_values": {"command": "npx"}, "secrets": {},
        })
        resp = await client.get("/trackers")
        trackers = (await resp.json())["trackers"]
        target = trackers[0]["id"]
        with patch("meeting_helper.trackers.registry.TrackerRegistry.activate",
                   new=AsyncMock()) as mock_act:
            resp = await client.post(f"/trackers/{target}/activate")
            assert resp.status == 200
            mock_act.assert_awaited_once()


@pytest.mark.asyncio
async def test_delete_active_tracker_succeeds_and_clears_active(monkeypatch):
    """Deleting the active tracker is allowed — the registry is shut down,
    active_tracker_id is cleared, and the entry is removed. A workspace
    can have zero connected trackers."""
    monkeypatch.setattr(
        "meeting_helper.trackers.secrets.write_secrets",
        lambda ws, tid, values: None,
    )
    monkeypatch.setattr(
        "meeting_helper.trackers.secrets.read_secrets",
        lambda ws, tid, keys: {},
    )
    monkeypatch.setattr(
        "meeting_helper.trackers.secrets.purge_tracker",
        lambda ws, tid, keys: None,
    )
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        resp = await client.post("/trackers", json={
            "vendor": "local_todo", "label": "A",
            "auth_values": {"command": "npx"}, "secrets": {},
        })
        tid = (await resp.json())["id"]
        with patch("meeting_helper.trackers.registry.TrackerRegistry.activate",
                   new=AsyncMock()):
            await client.post(f"/trackers/{tid}/activate")
        resp = await client.delete(f"/trackers/{tid}")
        assert resp.status == 200, await resp.text()
        # And listing shows no trackers + no active.
        listing = await (await client.get("/trackers")).json()
        assert listing["trackers"] == []
        assert listing["active_tracker_id"] is None


@pytest.mark.asyncio
async def test_vendors_endpoint_marks_unvalidated_vendors_disabled():
    """The /vendors response must include `enabled` per vendor — local_todo,
    jira, notion are enabled; linear / trello / github_projects ship but are
    surfaced as disabled until validated end-to-end against their MCP servers.
    """
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        resp = await client.get("/vendors")
        assert resp.status == 200
        data = await resp.json()
        by_id = {v["id"]: v for v in data["vendors"]}
        for ready in ("local_todo", "jira", "notion"):
            assert ready in by_id, f"missing vendor {ready}"
            assert by_id[ready]["enabled"] is True, f"{ready} should be enabled"
        for unready in ("linear", "trello", "github_projects"):
            if unready in by_id:
                assert by_id[unready]["enabled"] is False, f"{unready} should be disabled"


@pytest.mark.asyncio
async def test_create_rejects_disabled_vendor(monkeypatch):
    """POST /trackers for a known-but-disabled vendor must 400 — the UI
    disables those rows in the picker, but the API is the source of truth.
    """
    monkeypatch.setattr(
        "meeting_helper.trackers.secrets.write_secrets",
        lambda ws, tid, values: None,
    )
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        resp = await client.post("/trackers", json={
            "vendor": "linear", "label": "L",
            "auth_values": {"url": "https://mcp.linear.app/sse"}, "secrets": {},
        })
        assert resp.status == 400
        body = await resp.json()
        assert "coming soon" in body["error"].lower() or "not yet enabled" in body["error"].lower()


@pytest.mark.asyncio
async def test_delete_copilot_promotes_next_chat_enabled(monkeypatch):
    """Removing the Copilot tracker promotes the next chat-enabled tracker
    (by insertion order). Only when none qualify does copilot_tracker_id
    become null."""
    monkeypatch.setattr("meeting_helper.trackers.secrets.write_secrets",
                        lambda ws, tid, values: None)
    monkeypatch.setattr("meeting_helper.trackers.secrets.read_secrets",
                        lambda ws, tid, keys: {})
    monkeypatch.setattr("meeting_helper.trackers.secrets.purge_tracker",
                        lambda ws, tid, keys: None)

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        # tracker A (copilot, by auto-promote on first create)
        a = (await (await client.post("/trackers", json={
            "vendor": "local_todo", "label": "A",
            "auth_values": {"url": "http://a/mcp"}, "secrets": {}})).json())["id"]
        # tracker B (chat-enabled by default)
        b = (await (await client.post("/trackers", json={
            "vendor": "local_todo", "label": "B",
            "auth_values": {"url": "http://b/mcp"}, "secrets": {}})).json())["id"]

        r = await client.delete(f"/trackers/{a}")
        assert r.status == 200, await r.text()

        listing = await (await client.get("/trackers")).json()
        assert listing["active_tracker_id"] == b  # alias still served
        assert {t["id"] for t in listing["trackers"]} == {b}


@pytest.mark.asyncio
async def test_create_preserves_user_chosen_label(monkeypatch):
    """Frontend computes auto-suffixed labels (Notion / Notion (2)); the
    backend must accept and persist whatever label the client sends."""
    monkeypatch.setattr("meeting_helper.trackers.secrets.write_secrets",
                        lambda ws, tid, values: None)
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        r = await client.post("/trackers", json={
            "vendor": "local_todo", "label": "Local Todo (2)",
            "auth_values": {"url": "http://x/mcp"}, "secrets": {},
        })
        assert r.status == 201
        body = await r.json()
        assert body["label"] == "Local Todo (2)"

        listing = await (await client.get("/trackers")).json()
        labels = [t["label"] for t in listing["trackers"]]
        assert "Local Todo (2)" in labels


@pytest.mark.asyncio
async def test_delete_last_chat_enabled_clears_copilot_and_state(monkeypatch):
    """Removing the only Copilot-eligible tracker clears copilot_tracker_id
    AND state.tracker — Brief/Copilot must see no tracker, not a dangling one."""
    monkeypatch.setattr("meeting_helper.trackers.secrets.write_secrets",
                        lambda ws, tid, values: None)
    monkeypatch.setattr("meeting_helper.trackers.secrets.read_secrets",
                        lambda ws, tid, keys: {})
    monkeypatch.setattr("meeting_helper.trackers.secrets.purge_tracker",
                        lambda ws, tid, keys: None)

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        a = (await (await client.post("/trackers", json={
            "vendor": "local_todo", "label": "A",
            "auth_values": {"url": "http://a/mcp"}, "secrets": {}})).json())["id"]

        resp = await client.delete(f"/trackers/{a}")
        assert resp.status == 200, await resp.text()

        listing = await (await client.get("/trackers")).json()
        assert listing["trackers"] == []
        assert listing["active_tracker_id"] is None

        # state.tracker (module-level) should be cleared too.
        from meeting_helper.server.routes import state
        assert getattr(state, "tracker", None) is None


@pytest.mark.asyncio
async def test_delete_copilot_skips_chat_disabled_survivor(monkeypatch):
    """When the copilot is removed and the next-by-insertion-order survivor
    has chat_enabled=False, promotion must skip it and pick the next
    chat_enabled survivor."""
    monkeypatch.setattr("meeting_helper.trackers.secrets.write_secrets",
                        lambda ws, tid, values: None)
    monkeypatch.setattr("meeting_helper.trackers.secrets.read_secrets",
                        lambda ws, tid, keys: {})
    monkeypatch.setattr("meeting_helper.trackers.secrets.purge_tracker",
                        lambda ws, tid, keys: None)

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        # A → copilot
        a = (await (await client.post("/trackers", json={
            "vendor": "local_todo", "label": "A",
            "auth_values": {"url": "http://a/mcp"}, "secrets": {}})).json())["id"]
        # B → chat_enabled defaults true; we disable it right away
        b = (await (await client.post("/trackers", json={
            "vendor": "local_todo", "label": "B",
            "auth_values": {"url": "http://b/mcp"}, "secrets": {}})).json())["id"]
        # B cannot be disabled while it's not Copilot... it IS not Copilot, A is.
        r = await client.put(f"/trackers/{b}/chat-enabled", json={"enabled": False})
        assert r.status == 200
        # C → chat_enabled stays true
        c = (await (await client.post("/trackers", json={
            "vendor": "local_todo", "label": "C",
            "auth_values": {"url": "http://c/mcp"}, "secrets": {}})).json())["id"]

        # Delete A. Promotion must skip B (chat_enabled=false) and pick C.
        resp = await client.delete(f"/trackers/{a}")
        assert resp.status == 200, await resp.text()

        listing = await (await client.get("/trackers")).json()
        assert listing["active_tracker_id"] == c


@pytest.mark.asyncio
async def test_activate_syncs_both_copilot_and_active_in_appconfig(monkeypatch):
    """AppConfig is a plain dataclass — copilot_tracker_id and active_tracker_id
    don't auto-sync. The activate handler must write BOTH so the
    chat-enabled guard (which reads copilot_tracker_id) and legacy callers
    (which read active_tracker_id) agree on which tracker is the Copilot.
    Previously the activate handler only wrote active_tracker_id, leaving
    copilot_tracker_id stale and rejecting `PUT /chat-enabled` on the actual
    non-copilot row."""
    monkeypatch.setattr("meeting_helper.trackers.secrets.write_secrets",
                        lambda ws, tid, values: None)
    monkeypatch.setattr("meeting_helper.trackers.secrets.read_secrets",
                        lambda ws, tid, keys: {})
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        a = (await (await client.post("/trackers", json={
            "vendor": "local_todo", "label": "A",
            "auth_values": {"url": "http://a/mcp"}, "secrets": {}})).json())["id"]
        b = (await (await client.post("/trackers", json={
            "vendor": "local_todo", "label": "B",
            "auth_values": {"url": "http://b/mcp"}, "secrets": {}})).json())["id"]

        with patch("meeting_helper.trackers.registry.TrackerRegistry.activate",
                   new=AsyncMock()):
            await client.post(f"/trackers/{b}/activate")

        # PUT chat-enabled on the OLD copilot (a) must now succeed —
        # the activate handler should have moved copilot to b.
        r = await client.put(f"/trackers/{a}/chat-enabled", json={"enabled": False})
        assert r.status == 200, await r.text()
        # And b's chat is locked (rejected with 409).
        r = await client.put(f"/trackers/{b}/chat-enabled", json={"enabled": False})
        assert r.status == 409, await r.text()
