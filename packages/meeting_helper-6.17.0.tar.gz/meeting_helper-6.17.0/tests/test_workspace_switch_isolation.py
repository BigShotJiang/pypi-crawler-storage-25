"""Workspace switch must completely isolate tracker sessions and pre-warm
tasks across workspaces — otherwise a chat-only Jira session from workspace
A stays hot when the user switches to workspace B, leaking cross-workspace
MCP access and giving the agent_fetch loop a path to write workspace A's
tickets into workspace B's copilot_learned_memory.

See the parallel investigator report for the full data-leak path.
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from meeting_helper.trackers.registry import TrackerRegistry


@pytest.mark.asyncio
async def test_registry_shutdown_all_closes_every_session_across_workspaces():
    """The shutdown(None) path (workspace boundary) must close EVERY session
    in the registry, not only the Copilot one. This is what
    workspace_activate_handler relies on to prevent the cross-workspace leak."""
    reg = TrackerRegistry()
    notion = MagicMock(); notion.close = AsyncMock()
    jira = MagicMock(); jira.close = AsyncMock()
    local = MagicMock(); local.close = AsyncMock()

    with patch.object(reg, "_build", side_effect=[notion, jira, local]):
        await reg.ensure_session({"id": "n", "vendor": "notion", "secret_keys": []}, workspace_name="W")
        await reg.ensure_session({"id": "j", "vendor": "jira", "secret_keys": []}, workspace_name="W")
        await reg.ensure_session({"id": "l", "vendor": "local_todo", "secret_keys": []}, workspace_name="W")

    # Mark Notion as Copilot (mirrors a chat-only Jira + chat-only Local scenario).
    await reg.set_copilot("n")

    # Workspace switch — close ALL sessions, not just the copilot.
    await reg.shutdown()

    notion.close.assert_awaited_once()
    jira.close.assert_awaited_once()
    local.close.assert_awaited_once()
    assert reg.get("n") is None
    assert reg.get("j") is None
    assert reg.get("l") is None
    assert reg.copilot_id is None


@pytest.mark.asyncio
async def test_refresh_sprint_tickets_discards_when_workspace_switches_midfetch(monkeypatch, tmp_path):
    """If the workspace switches WHILE refresh_sprint_tickets is mid-fetch,
    the returned items must NOT be written to state.sprint_tickets. Without
    this guard, the prior workspace's tickets get committed under the new
    workspace's banner."""
    from meeting_helper.ai import client as c
    from meeting_helper.state import AppState

    state = AppState()
    state.tracker = MagicMock(name="tracker_A")
    state.sprint_tickets = []
    state.sprint_tickets_loaded_at = 0.0

    # Fake disk: looks like the OLD workspace at start, like NEW after switch.
    old_disk = MagicMock()
    old_disk.workspace_name = "Personal"
    old_disk.to_app_config = MagicMock(return_value=MagicMock(
        workspace_name="Personal", anthropic_api_key="k",
    ))
    new_disk = MagicMock()
    new_disk.workspace_name = "Work"

    # get_config gets called twice: once at the start (snapshot) and once
    # at the end (current). Return old first, then new.
    disk_iter = iter([old_disk, new_disk])
    monkeypatch.setattr("meeting_helper.config.get_config", lambda: next(disk_iter))

    async def _fetch_then_simulate_switch(**kwargs):
        # Simulate workspace switch BEFORE this returns.
        state.tracker = MagicMock(name="tracker_B")
        return [{"id": "should_be_dropped", "title": "Personal ticket"}]

    monkeypatch.setattr("meeting_helper.ai.agent_fetch.fetch_active_topics", _fetch_then_simulate_switch)

    # Silence broadcasts.
    import meeting_helper.server.websocket as ws
    monkeypatch.setattr(ws, "broadcast", AsyncMock())

    await c.refresh_sprint_tickets(state, force=True)

    # Workspace switched between snapshot and write → result is dropped.
    assert state.sprint_tickets == [], (
        "Expected refresh to discard the fetched items when the workspace "
        "switched mid-fetch; instead they were written and would leak across."
    )


@pytest.mark.asyncio
async def test_refresh_sprint_tickets_writes_normally_when_no_switch(monkeypatch):
    """When the workspace does NOT switch mid-fetch, results are written
    as usual. (Regression guard so the previous test's discard logic doesn't
    over-trigger.)"""
    from meeting_helper.ai import client as c
    from meeting_helper.state import AppState

    state = AppState()
    tracker = MagicMock(name="stable_tracker")
    state.tracker = tracker
    state.sprint_tickets = []
    state.sprint_tickets_loaded_at = 0.0

    disk = MagicMock()
    disk.workspace_name = "Personal"
    disk.to_app_config = MagicMock(return_value=MagicMock(
        workspace_name="Personal", anthropic_api_key="k",
    ))
    monkeypatch.setattr("meeting_helper.config.get_config", lambda: disk)

    async def _fetch(**kwargs):
        return [{"id": "SCRUM-1", "title": "Real ticket"}]
    monkeypatch.setattr("meeting_helper.ai.agent_fetch.fetch_active_topics", _fetch)

    import meeting_helper.server.websocket as ws
    monkeypatch.setattr(ws, "broadcast", AsyncMock())

    await c.refresh_sprint_tickets(state, force=True)

    assert state.sprint_tickets == [{"id": "SCRUM-1", "title": "Real ticket"}]
