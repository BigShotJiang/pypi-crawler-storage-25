import json
import pytest
from tests.helpers.fake_mcp import FakeMCPSession, FakeToolResult


@pytest.mark.asyncio
async def test_call_tool_returns_canned_result():
    s = FakeMCPSession({
        ("list_boards", ()): {"boards": [{"board_id": 10, "name": "Demo"}]}
    })
    result = await s.call_tool("list_boards", {})
    assert isinstance(result, FakeToolResult)
    assert json.loads(result.content[0].text) == {
        "boards": [{"board_id": 10, "name": "Demo"}],
    }


@pytest.mark.asyncio
async def test_call_tool_records_invocation():
    s = FakeMCPSession({("ping", ()): {"ok": True}})
    await s.call_tool("ping", {"a": 1, "b": 2})
    assert s.calls == [("ping", {"a": 1, "b": 2})]


@pytest.mark.asyncio
async def test_call_tool_unknown_raises():
    s = FakeMCPSession({})
    with pytest.raises(KeyError):
        await s.call_tool("nope", {})


@pytest.mark.asyncio
async def test_list_tools():
    s = FakeMCPSession({}, tool_schemas=[
        {"name": "list_boards", "description": "list", "inputSchema": {"type": "object"}}
    ])
    resp = await s.list_tools()
    assert len(resp.tools) == 1
    assert resp.tools[0].name == "list_boards"
