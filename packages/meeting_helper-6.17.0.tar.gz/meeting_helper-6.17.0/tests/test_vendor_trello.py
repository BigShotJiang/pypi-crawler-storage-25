# tests/test_vendor_trello.py
import pytest
from meeting_helper.trackers.vendors.trello import TrelloProfile


def test_profile_class_attributes():
    p = TrelloProfile
    assert p.id == "trello"
    assert p.label == "Trello"
    assert p.transport.type == "http"
    assert p.auth_mode == "mcp_oauth"
    assert p.supports == frozenset()
    assert p.agent_terminology
    assert p.agent_hints
