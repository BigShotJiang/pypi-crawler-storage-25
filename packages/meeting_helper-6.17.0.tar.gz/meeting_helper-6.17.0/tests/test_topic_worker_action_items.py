"""TopicWorker — action item candidate beats the ticket pick when confident."""
from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock

import pytest

from meeting_helper.action_items.models import new_item
from meeting_helper.buffer import SentenceBuffer
from meeting_helper.state import AppState
from meeting_helper.topic_worker import TopicWorker


class FakeConfig:
    preferred_provider = "claude"
    anthropic_api_key = "test-key"
    google_api_key = ""
    deepgram_api_key = ""
    claude_model = "claude-test"
    gemini_model = "gemini-test"
    local_model = "x"
    ollama_host = "http://localhost:11434"
    max_tokens = 512
    action_items_inject_into_copilot = True
    workspace_name = "TestWS"
    recordings_dir = ""  # set per-test via tmp_path


async def test_action_item_wins_when_score_higher(monkeypatch, tmp_path):
    """An action item with confidence > ticket-pick (which is treated as 1.0
    only when the ticket pick succeeds) should override the broadcast to
    carry ``source: "action_item"``.

    Here we drive ``_run`` after monkeypatching the ticket-picker to return
    None (no ticket match) and the action-item matcher to return a strong
    hit. The broadcast must carry ``source="action_item"`` and the item id.
    """
    import time

    buf = SentenceBuffer(role="self")
    buf.append_final("We still need to follow up on the SLA stuff.")

    state = AppState()
    state.self_buffer = buf
    state.tracker = AsyncMock()
    state.asyncio_loop = asyncio.get_event_loop()
    # No sprint tickets cached -> pick_topic_ticket returns None.
    state.sprint_tickets = []
    state.sprint_tickets_loaded_at = time.time()
    state.arm_hot_moment(window_sec=60)

    cfg = FakeConfig()
    cfg.recordings_dir = str(tmp_path / "recordings")

    item = new_item(title="Investigate SLA")

    async def fake_pick(_state, _cfg, question=""):
        return None  # no sprint ticket match

    async def fake_refresh(*_a, **_kw):
        return None

    async def fake_match(buffer_text, open_items, *, ai_client):
        return {"item": item, "confidence": 0.9}

    payloads: list[dict] = []

    async def fake_broadcast(payload):
        payloads.append(payload)

    monkeypatch.setattr("meeting_helper.ai.client.pick_topic_ticket", fake_pick)
    monkeypatch.setattr(
        "meeting_helper.ai.client.refresh_sprint_tickets", fake_refresh
    )
    monkeypatch.setattr(
        "meeting_helper.action_items.topic_candidate.match", fake_match
    )
    monkeypatch.setattr(
        "meeting_helper.action_items.store.list_all", lambda *_: [item]
    )
    monkeypatch.setattr(
        "meeting_helper.server.websocket.broadcast", fake_broadcast
    )
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(cfg, buf)
    await worker._run()

    assert payloads, "expected a topic broadcast"
    topic_payload = next(p for p in payloads if p.get("type") == "topic")
    assert topic_payload["source"] == "action_item"
    assert topic_payload["action_item_id"] == item["id"]
    assert topic_payload["topic"] == "Investigate SLA"


async def test_ticket_wins_when_no_action_item_match(monkeypatch, tmp_path):
    """When the action-item matcher returns no hit, the existing ticket pick
    flows through unchanged with ``source: "ticket"``."""
    import time

    buf = SentenceBuffer(role="self")
    buf.append_final("Talking about ticket ENGT-4147.")

    state = AppState()
    state.self_buffer = buf
    state.tracker = AsyncMock()
    state.asyncio_loop = asyncio.get_event_loop()
    state.sprint_tickets = [
        {"id": "110", "title": "ENGT-4147 remapper", "status": "in_progress",
         "status_kind": "in_progress", "priority": None, "body_md": "",
         "workspace_id": "ws1", "workspace_name": "WS1",
         "board_id": "ws1", "board_name": "WS1", "sprint_name": "Sp1",
         "url": None, "subtasks": [], "subtasks_summary": {},
         "recent_comments": [], "recent_history": [], "linked_docs": []},
    ]
    state.sprint_tickets_loaded_at = time.time()
    state.arm_hot_moment(window_sec=60)

    cfg = FakeConfig()
    cfg.recordings_dir = str(tmp_path / "recordings")

    async def fake_pick(_state, _cfg, question=""):
        return {"id": "110", "title": "ENGT-4147 remapper"}

    async def fake_refresh(*_a, **_kw):
        return None

    async def fake_match(*_a, **_kw):
        return None  # no action-item match

    payloads: list[dict] = []

    async def fake_broadcast(payload):
        payloads.append(payload)

    monkeypatch.setattr("meeting_helper.ai.client.pick_topic_ticket", fake_pick)
    monkeypatch.setattr(
        "meeting_helper.ai.client.refresh_sprint_tickets", fake_refresh
    )
    monkeypatch.setattr(
        "meeting_helper.action_items.topic_candidate.match", fake_match
    )
    monkeypatch.setattr(
        "meeting_helper.action_items.store.list_all", lambda *_: []
    )
    monkeypatch.setattr(
        "meeting_helper.server.websocket.broadcast", fake_broadcast
    )
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(cfg, buf)
    await worker._run()

    assert payloads
    topic_payload = next(p for p in payloads if p.get("type") == "topic")
    assert topic_payload["source"] == "ticket"
    assert topic_payload["ticket_ids"] == ["110"]


async def test_ticket_beats_high_confidence_action_item(monkeypatch, tmp_path):
    """Invariant: a successful ticket pick is treated as confidence=1.0, so
    even an action item reporting confidence=0.99 must lose. The broadcast
    must carry ``source="ticket"`` (not action_item).

    This pins the load-bearing default in `_run`:
        ticket_confidence = 1.0 if picked is not None else 0.0
        if action_item_winner and ai_confidence > ticket_confidence: ...

    Regressing it (e.g. flipping `>` to `>=`, or lowering the ticket default)
    would let near-miss action items steal topics from real tickets.
    """
    import time

    buf = SentenceBuffer(role="self")
    buf.append_final("Talking about ENGT-4147 and also some SLA follow-up.")

    state = AppState()
    state.self_buffer = buf
    state.tracker = AsyncMock()
    state.asyncio_loop = asyncio.get_event_loop()
    state.sprint_tickets = [
        {"id": "110", "title": "ENGT-4147 remapper", "status": "in_progress",
         "status_kind": "in_progress", "priority": None, "body_md": "",
         "workspace_id": "ws1", "workspace_name": "WS1",
         "board_id": "ws1", "board_name": "WS1", "sprint_name": "Sp1",
         "url": None, "subtasks": [], "subtasks_summary": {},
         "recent_comments": [], "recent_history": [], "linked_docs": []},
    ]
    state.sprint_tickets_loaded_at = time.time()
    state.arm_hot_moment(window_sec=60)

    cfg = FakeConfig()
    cfg.recordings_dir = str(tmp_path / "recordings")

    item = new_item(title="Investigate SLA")

    async def fake_pick(_state, _cfg, question=""):
        return {"id": "110", "title": "ENGT-4147 remapper"}

    async def fake_refresh(*_a, **_kw):
        return None

    async def fake_match(buffer_text, open_items, *, ai_client):
        # Just below the ticket's implicit 1.0 — the ticket must still win.
        return {"item": item, "confidence": 0.99}

    payloads: list[dict] = []

    async def fake_broadcast(payload):
        payloads.append(payload)

    monkeypatch.setattr("meeting_helper.ai.client.pick_topic_ticket", fake_pick)
    monkeypatch.setattr(
        "meeting_helper.ai.client.refresh_sprint_tickets", fake_refresh
    )
    monkeypatch.setattr(
        "meeting_helper.action_items.topic_candidate.match", fake_match
    )
    monkeypatch.setattr(
        "meeting_helper.action_items.store.list_all", lambda *_: [item]
    )
    monkeypatch.setattr(
        "meeting_helper.server.websocket.broadcast", fake_broadcast
    )
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(cfg, buf)
    await worker._run()

    assert payloads, "expected a topic broadcast"
    topic_payload = next(p for p in payloads if p.get("type") == "topic")
    assert topic_payload["source"] == "ticket", (
        f"ticket=1.0 default must beat action item with confidence=0.99; "
        f"got source={topic_payload.get('source')!r}"
    )
    assert topic_payload["ticket_ids"] == ["110"]


async def test_action_items_skipped_when_toggle_off(monkeypatch, tmp_path):
    """If ``action_items_inject_into_copilot`` is False, the matcher is never
    called and the ticket branch flows through unchanged."""
    import time

    buf = SentenceBuffer(role="self")
    buf.append_final("Talking about ENGT-4147 remapper.")

    state = AppState()
    state.self_buffer = buf
    state.tracker = AsyncMock()
    state.asyncio_loop = asyncio.get_event_loop()
    state.sprint_tickets = [
        {"id": "110", "title": "ENGT-4147 remapper", "status": "in_progress",
         "status_kind": "in_progress", "priority": None, "body_md": "",
         "workspace_id": "ws1", "workspace_name": "WS1",
         "board_id": "ws1", "board_name": "WS1", "sprint_name": "Sp1",
         "url": None, "subtasks": [], "subtasks_summary": {},
         "recent_comments": [], "recent_history": [], "linked_docs": []},
    ]
    state.sprint_tickets_loaded_at = time.time()

    state.arm_hot_moment(window_sec=60)

    cfg = FakeConfig()
    cfg.recordings_dir = str(tmp_path / "recordings")
    cfg.action_items_inject_into_copilot = False  # toggle off

    async def fake_pick(_state, _cfg, question=""):
        return {"id": "110", "title": "ENGT-4147 remapper"}

    async def fake_refresh(*_a, **_kw):
        return None

    match_calls: list = []

    async def fake_match(*a, **kw):
        match_calls.append((a, kw))
        return {"item": new_item(title="should not be picked"), "confidence": 0.99}

    payloads: list[dict] = []

    async def fake_broadcast(payload):
        payloads.append(payload)

    monkeypatch.setattr("meeting_helper.ai.client.pick_topic_ticket", fake_pick)
    monkeypatch.setattr(
        "meeting_helper.ai.client.refresh_sprint_tickets", fake_refresh
    )
    monkeypatch.setattr(
        "meeting_helper.action_items.topic_candidate.match", fake_match
    )
    monkeypatch.setattr(
        "meeting_helper.server.websocket.broadcast", fake_broadcast
    )
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(cfg, buf)
    await worker._run()

    assert not match_calls, "matcher must not run when toggle is off"
    topic_payload = next(p for p in payloads if p.get("type") == "topic")
    assert topic_payload["source"] == "ticket"


async def test_low_confidence_action_item_does_not_override(monkeypatch, tmp_path):
    """A matcher hit below the confidence floor (0.7) must not change the
    topic banner. Otherwise the auto-selector flickers on weak signal whenever
    no ticket matches the current speech.
    """
    import time

    buf = SentenceBuffer(role="self")
    buf.append_final("Random unrelated chatter.")

    state = AppState()
    state.self_buffer = buf
    state.tracker = AsyncMock()
    state.asyncio_loop = asyncio.get_event_loop()
    state.sprint_tickets = []
    state.sprint_tickets_loaded_at = time.time()
    # Pre-existing topic so we can confirm it's left alone.
    state.current_topic = {"topic": "PrevTopic", "ticket_ids": []}
    state.arm_hot_moment(window_sec=60)

    cfg = FakeConfig()
    cfg.recordings_dir = str(tmp_path / "recordings")

    item = new_item(title="Investigate SLA")

    async def fake_pick(_state, _cfg, question=""):
        return None

    async def fake_refresh(*_a, **_kw):
        return None

    async def fake_match(buffer_text, open_items, *, ai_client):
        return {"item": item, "confidence": 0.4}

    payloads: list[dict] = []

    async def fake_broadcast(payload):
        payloads.append(payload)

    monkeypatch.setattr("meeting_helper.ai.client.pick_topic_ticket", fake_pick)
    monkeypatch.setattr("meeting_helper.ai.client.refresh_sprint_tickets", fake_refresh)
    monkeypatch.setattr("meeting_helper.action_items.topic_candidate.match", fake_match)
    monkeypatch.setattr("meeting_helper.action_items.store.list_all", lambda *_: [item])
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", fake_broadcast)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(cfg, buf)
    await worker._run()

    # Topic must be unchanged; nothing broadcast.
    assert state.current_topic["topic"] == "PrevTopic"
    assert not any(p.get("type") == "topic" for p in payloads)


async def test_matcher_skipped_when_ticket_matched(monkeypatch, tmp_path):
    """When a sprint ticket already matched, the action-item matcher must not
    fire — it would waste an LLM call (action items can't beat ticket=1.0).
    """
    import time

    buf = SentenceBuffer(role="self")
    buf.append_final("Talking about ticket ENGT-4147.")

    state = AppState()
    state.self_buffer = buf
    state.tracker = AsyncMock()
    state.asyncio_loop = asyncio.get_event_loop()
    state.sprint_tickets = [
        {"id": "110", "title": "ENGT-4147 remapper", "status": "in_progress",
         "status_kind": "in_progress", "priority": None, "body_md": "",
         "workspace_id": "ws1", "workspace_name": "WS1",
         "board_id": "ws1", "board_name": "WS1", "sprint_name": "Sp1",
         "url": None, "subtasks": [], "subtasks_summary": {},
         "recent_comments": [], "recent_history": [], "linked_docs": []},
    ]
    state.sprint_tickets_loaded_at = time.time()
    state.arm_hot_moment(window_sec=60)

    cfg = FakeConfig()
    cfg.recordings_dir = str(tmp_path / "recordings")

    async def fake_pick(_state, _cfg, question=""):
        return {"id": "110", "title": "ENGT-4147 remapper"}

    async def fake_refresh(*_a, **_kw):
        return None

    match_calls: list[tuple] = []

    async def fake_match(buffer_text, open_items, *, ai_client):
        match_calls.append((buffer_text, open_items))
        return {"item": new_item(title="X"), "confidence": 0.99}

    async def fake_broadcast(_payload):
        return None

    monkeypatch.setattr("meeting_helper.ai.client.pick_topic_ticket", fake_pick)
    monkeypatch.setattr("meeting_helper.ai.client.refresh_sprint_tickets", fake_refresh)
    monkeypatch.setattr("meeting_helper.action_items.topic_candidate.match", fake_match)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", fake_broadcast)
    monkeypatch.setattr("meeting_helper.state.state", state)

    worker = TopicWorker(cfg, buf)
    await worker._run()

    assert not match_calls, "matcher must not run when ticket pick succeeded"
