"""Verify workspace switch updates the disk factory so trackers don't leak."""
from unittest.mock import MagicMock
import pytest
from aiohttp.test_utils import TestServer, TestClient
from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig


@pytest.mark.asyncio
async def test_disk_factory_resolves_per_request(monkeypatch):
    """Each handler call resolves the current Config via the factory; we
    can flip the factory mid-test to simulate a workspace switch."""
    cfg1 = MagicMock()
    cfg1.trackers = [{
        "id": "lt-w1", "vendor": "local_todo", "label": "WS1",
        "transport": {"type": "http", "url": "u1", "headers": {}},
        "auth_values": {"url": "u1"}, "secret_keys": [],
    }]
    cfg1.active_tracker_id = "lt-w1"
    cfg1.workspace_name = "ws1"

    cfg2 = MagicMock()
    cfg2.trackers = [{
        "id": "lt-w2", "vendor": "local_todo", "label": "WS2",
        "transport": {"type": "http", "url": "u2", "headers": {}},
        "auth_values": {"url": "u2"}, "secret_keys": [],
    }]
    cfg2.active_tracker_id = "lt-w2"
    cfg2.workspace_name = "ws2"

    current = {"cfg": cfg1}
    app = create_app(AppConfig(), disk_factory=lambda: current["cfg"])

    async with TestClient(TestServer(app)) as client:
        # Before switch: factory resolves cfg1.
        assert app["disk_factory"]() is cfg1

        # Simulate workspace switch by flipping the factory target.
        current["cfg"] = cfg2
        assert app["disk_factory"]() is cfg2  # post-switch

        # And back again — factory always reflects the current value.
        current["cfg"] = cfg1
        assert app["disk_factory"]() is cfg1  # post-switch back
