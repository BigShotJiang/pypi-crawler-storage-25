"""SentenceBuffer.role attribute + broadcast plumbing."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from meeting_helper.buffer import SentenceBuffer


def test_default_role_is_self():
    assert SentenceBuffer().role == "self"


def test_explicit_role_other():
    assert SentenceBuffer(role="other").role == "other"


def test_invalid_role_raises():
    with pytest.raises(ValueError):
        SentenceBuffer(role="bystander")


def test_fire_listeners_false_skips_listener_fanout_but_keeps_sentence():
    buf = SentenceBuffer(role="self")
    seen: list[tuple[str, int | None]] = []
    buf.add_sentence_listener(lambda t, s: seen.append((t, s)))
    buf.append_final("synthesized brief line", fire_listeners=False)
    # Sentence is in the buffer for AI context...
    assert buf.get_last_n() == ["synthesized brief line"]
    # ...but the live-transcript listener (and others) never fired.
    assert seen == []


def test_fire_listeners_true_still_fans_out_by_default():
    buf = SentenceBuffer(role="self")
    seen: list[tuple[str, int | None]] = []
    buf.add_sentence_listener(lambda t, s: seen.append((t, s)))
    buf.append_final("real transcription line")
    assert seen == [("real transcription line", None)]


@pytest.mark.asyncio
async def test_broadcast_transcript_includes_role():
    from meeting_helper.audio.transcriber import DeepgramTranscriber
    payloads: list[dict] = []

    async def fake_broadcast(payload: dict) -> None:
        payloads.append(payload)

    with patch("meeting_helper.server.websocket.broadcast", new=fake_broadcast):
        await DeepgramTranscriber._broadcast_transcript("hello", interim=False, role="other")

    assert payloads == [{"type": "transcript", "text": "hello", "interim": False, "role": "other", "speaker": None}]


def test_append_final_stores_speaker():
    from meeting_helper.buffer import SentenceBuffer
    buf = SentenceBuffer(max_sentences=5, role="other")
    buf.append_final("hello", speaker=0)
    buf.append_final("world", speaker=1)
    buf.append_final("no speaker", speaker=None)
    entries = list(buf._sentences)
    assert entries[0].speaker == 0
    assert entries[1].speaker == 1
    assert entries[2].speaker is None


def test_listener_receives_text_and_speaker():
    from meeting_helper.buffer import SentenceBuffer
    received: list[tuple[str, int | None]] = []
    buf = SentenceBuffer(max_sentences=5, role="other")
    buf.add_sentence_listener(lambda t, s: received.append((t, s)))
    buf.append_final("hi", speaker=2)
    buf.append_final("bye", speaker=None)
    assert received == [("hi", 2), ("bye", None)]


def test_append_final_default_speaker_is_none():
    from meeting_helper.buffer import SentenceBuffer
    buf = SentenceBuffer(role="self")
    buf.append_final("plain text")
    assert list(buf._sentences)[0].speaker is None
