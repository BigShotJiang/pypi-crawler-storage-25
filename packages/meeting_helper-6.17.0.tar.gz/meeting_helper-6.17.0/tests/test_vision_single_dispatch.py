"""Image-turn dispatch contract for _stream_ai.

On an image turn the cascade must collapse to a single vision-capable provider
so the one shown answer always comes from a model that can read the image, and
a blind (non-vision) model must never answer. Text turns keep the multi-provider
cascade unchanged.
"""
import asyncio

import meeting_helper.ai.client as client
import meeting_helper.server.websocket as ws


class _State:
    def record_ai_call(self, kind="ai"):
        pass


class _Cfg:
    anthropic_api_key = "x"
    google_api_key = "y"
    openai_api_key = "z"
    claude_model = "claude-haiku-4-5-20251001"  # vision
    gemini_model = "gemini-2.5-flash"           # vision
    openai_model = "gpt-5.4-nano"               # text-only (blind)
    preferred_provider = "openai"
    ai_provider_order = ["openai", "google", "anthropic"]
    ai_failover_delay_ms = 0  # launch siblings immediately so text-cascade fans out


def _image_messages():
    return [{
        "role": "user",
        "content": [
            {"type": "text", "text": "what is in this screenshot"},
            {"type": "image",
             "source": {"type": "base64", "media_type": "image/png", "data": "QUFB"}},
        ],
    }]


def _text_messages():
    return [{"role": "user", "content": "plain text question"}]


def _patch_generators(monkeypatch, *, used: list):
    """Replace every provider factory with a fake that records which providers
    actually ran and yields one deterministic chunk per provider."""

    def make(key):
        async def gen(state, config, messages, system_prompt):
            used.append(key)
            yield f"answer-from-{key}"
        return gen

    label_by_key = {k: v[0] for k, v in client._PROVIDER_GENERATORS.items()}
    fake = {k: (label_by_key[k], make(k)) for k in client._PROVIDER_GENERATORS}
    monkeypatch.setattr(client, "_PROVIDER_GENERATORS", fake)


def _patch_broadcast(monkeypatch, events: list):
    async def fake_broadcast(message):
        events.append(message)
    monkeypatch.setattr(ws, "broadcast", fake_broadcast)


def test_image_turn_dispatches_single_vision_provider(monkeypatch):
    used: list = []
    events: list = []
    _patch_generators(monkeypatch, used=used)
    _patch_broadcast(monkeypatch, events)

    text = asyncio.run(client._stream_ai(
        _State(), _Cfg(), _image_messages(), "sys"))

    # Exactly one provider ran, and it was vision-capable (not openai/nano).
    assert used == ["google"], used
    assert "openai" not in used
    assert text == "answer-from-google"

    # vision_note still emitted with the dropped (blind) providers listed.
    notes = [e for e in events if e.get("type") == "vision_note"]
    assert len(notes) == 1
    dropped_keys = {d["provider"] for d in notes[0]["dropped"]}
    assert "ChatGPT" in dropped_keys  # openai/nano was dropped


def test_image_turn_with_no_vision_provider_errors_and_returns_empty(monkeypatch):
    used: list = []
    events: list = []
    _patch_generators(monkeypatch, used=used)
    _patch_broadcast(monkeypatch, events)

    class NoVision(_Cfg):
        claude_model = "gpt-5.4-nano"   # pretend all configured models are blind
        gemini_model = "gpt-5.4-nano"
        openai_model = "gpt-5.4-nano"

    text = asyncio.run(client._stream_ai(
        _State(), NoVision(), _image_messages(), "sys"))

    # No provider ran and no fabricated answer was returned.
    assert used == []
    assert text == ""

    # A clear error was broadcast guiding the user to a vision-capable model.
    errors = [e for e in events if e.get("type") == "error"]
    assert len(errors) == 1
    assert "vision-capable" in errors[0]["message"]
    assert not any(e.get("type") == "vision_note" for e in events)


def test_text_turn_keeps_multi_provider_cascade(monkeypatch):
    used: list = []
    events: list = []
    _patch_generators(monkeypatch, used=used)
    _patch_broadcast(monkeypatch, events)

    text = asyncio.run(client._stream_ai(
        _State(), _Cfg(), _text_messages(), "sys"))

    # delay_ms == 0 fans out to every keyed provider in order; unchanged.
    assert used == ["openai", "google", "anthropic"], used
    # Canonical answer is the primary (first in order).
    assert text == "answer-from-openai"
    # No vision_note on a text turn.
    assert not any(e.get("type") == "vision_note" for e in events)
