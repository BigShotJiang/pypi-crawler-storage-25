import pytest

from meeting_helper.chat.tools.web_search import build_web_search


@pytest.mark.asyncio
async def test_returns_not_configured_when_no_key():
    ctx = {
        "config": type(
            "C", (), {"web_search_provider": None, "web_search_api_key": None}
        )()
    }
    out = await build_web_search().run({"q": "rust async"}, ctx)
    assert out == {"status": "not_configured"}


@pytest.mark.asyncio
async def test_brave_provider_dispatches_brave(monkeypatch):
    ctx = {
        "config": type(
            "C", (), {"web_search_provider": "brave", "web_search_api_key": "k"}
        )()
    }

    async def _fake_brave(q, key, limit):
        assert q == "claude tool use"
        return [{"title": "T", "url": "u", "snippet": "s"}]

    monkeypatch.setattr(
        "meeting_helper.chat.tools.web_search._brave_search", _fake_brave
    )
    out = await build_web_search().run({"q": "claude tool use"}, ctx)
    assert out["status"] == "ok"
    assert out["result"]["results"][0]["url"] == "u"


@pytest.mark.asyncio
async def test_error_returns_status_error(monkeypatch):
    ctx = {
        "config": type(
            "C", (), {"web_search_provider": "brave", "web_search_api_key": "k"}
        )()
    }

    async def _boom(*a, **k):
        raise RuntimeError("offline")

    monkeypatch.setattr(
        "meeting_helper.chat.tools.web_search._brave_search", _boom
    )
    out = await build_web_search().run({"q": "x"}, ctx)
    assert out["status"] == "error"
    assert "offline" in out["error"]
