"""Tests for ai/client.py using state.tracker instead of state.local_todo."""
import pytest
from unittest.mock import AsyncMock, MagicMock
from meeting_helper.ai.client import refresh_sprint_tickets


@pytest.mark.asyncio
async def test_refresh_sprint_tickets_calls_agent_fetch(monkeypatch):
    fake_state = MagicMock()
    fake_state.tracker = MagicMock()
    fake_state.sprint_tickets = []
    fake_state.sprint_tickets_loaded_at = 0

    async def stub_fetch(**kw):
        return [{"id": "X", "title": "Y", "status_kind": "todo", "workspace_id": "p"}]
    monkeypatch.setattr("meeting_helper.ai.agent_fetch.fetch_active_topics", stub_fetch)

    # Stub broadcast to avoid real WS
    monkeypatch.setattr(
        "meeting_helper.server.websocket.broadcast",
        AsyncMock(),
    )

    # Stub get_config to return a fake disk config
    fake_disk = MagicMock()
    fake_disk.to_app_config.return_value = MagicMock(
        preferred_provider="claude",
        anthropic_api_key="k",
        claude_model="haiku",
        copilot_instructions="",
        copilot_learned_memory=[],
        workspace_name="test",
    )
    monkeypatch.setattr("meeting_helper.config.get_config", lambda **kw: fake_disk)

    await refresh_sprint_tickets(fake_state, force=True)
    assert len(fake_state.sprint_tickets) == 1
