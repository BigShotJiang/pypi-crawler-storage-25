import pytest

from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig
from meeting_helper.state import state as global_state, PinnedItem


@pytest.fixture(autouse=True)
def _clean_pins():
    global_state.clear_pins()
    global_state.current_topic = {
        "topic": "",
        "ticket_ids": [],
        "search_query": "",
        "last_user_statement": "",
    }
    global_state.current_topic_cards = []
    yield
    global_state.clear_pins()


@pytest.fixture
async def client(aiohttp_client):
    app = create_app(AppConfig())
    return await aiohttp_client(app)


async def test_current_topic_includes_pinned(client):
    global_state.pin_topic(PinnedItem(kind="ticket", id="MH-1", title="A", board_id="bd"))
    global_state.pin_topic(PinnedItem(kind="note", id="foo.note.md", title="Foo"))
    resp = await client.get("/current_topic")
    assert resp.status == 200
    body = await resp.json()
    assert "pinned" in body
    assert body["pinned"] == [
        {"kind": "ticket", "id": "MH-1", "title": "A", "board_id": "bd"},
        {"kind": "note", "id": "foo.note.md", "title": "Foo", "board_id": ""},
    ]


async def test_current_topic_pinned_empty_when_basket_empty(client):
    resp = await client.get("/current_topic")
    body = await resp.json()
    assert body["pinned"] == []
