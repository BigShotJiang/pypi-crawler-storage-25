# tests/test_vendor_jira.py
import json
from pathlib import Path
import pytest
from tests.helpers.fake_mcp import FakeMCPSession
from meeting_helper.trackers.vendors.jira import JiraProfile


def _fix(name: str) -> dict | list:
    p = Path(__file__).parent / "fixtures" / "trackers" / "jira" / f"{name}.json"
    return json.loads(p.read_text())


def test_profile_class_attributes():
    p = JiraProfile
    assert p.id == "jira"
    assert p.label == "Jira"
    assert p.transport.type == "http"
    assert p.auth_mode == "mcp_oauth"
    assert p.supports == frozenset()
    assert p.agent_terminology
    assert p.agent_hints
