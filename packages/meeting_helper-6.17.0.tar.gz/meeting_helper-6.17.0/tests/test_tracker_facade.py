import asyncio
import pytest
from tests.helpers.fake_mcp import FakeMCPSession
from meeting_helper.trackers.profile import CapabilityNotSupported, Workspace
from meeting_helper.trackers.tracker import Tracker
from meeting_helper.trackers.vendors.local_todo import LocalTodoProfile


def _tracker_with_session(session):
    t = Tracker(profile=LocalTodoProfile(), transport={"type": "stdio", "command": "x", "args": [], "env": {}})
    t._session = session  # inject; tests bypass _ensure_started
    return t


@pytest.mark.asyncio
async def test_list_workspaces_caches():
    session = FakeMCPSession()
    session.set_response("list_boards", {}, [
        {"board_id": 10, "name": "Demo", "effective_permission": "write"},
    ])
    t = _tracker_with_session(session)
    a = await t.list_workspaces()
    b = await t.list_workspaces()
    assert a == b == [Workspace(id="10", name="Demo", permission="write")]
    # call_tool should have been hit exactly once thanks to the cache
    assert sum(1 for c in session.calls if c[0] == "list_boards") == 1


@pytest.mark.asyncio
async def test_call_tool_passthrough():
    session = FakeMCPSession()
    session.set_response("custom", {"x": 1}, {"ok": True})
    t = _tracker_with_session(session)
    result = await t.call_tool("custom", {"x": 1})
    assert result == {"ok": True}


@pytest.mark.asyncio
async def test_close_waits_for_in_flight():
    session = FakeMCPSession()
    hold = asyncio.Event()

    async def slow(*_a, **_kw):
        await hold.wait()
        from tests.helpers.fake_mcp import FakeToolResult, FakeTextContent
        import json as _json
        return FakeToolResult(content=[FakeTextContent(text=_json.dumps([]))])

    session.call_tool = slow  # type: ignore[assignment]
    t = _tracker_with_session(session)

    task = asyncio.create_task(t.call_tool("anything", {}))
    await asyncio.sleep(0.05)
    closer = asyncio.create_task(t.close(timeout=1.0))
    await asyncio.sleep(0.05)
    assert not closer.done(), "close() should be waiting on in-flight call"
    hold.set()
    await task
    await closer  # finishes once in_flight reaches 0
    assert t._session is None


@pytest.mark.asyncio
async def test_unsupported_capability_raises():
    class StubProfile(LocalTodoProfile):
        supports = frozenset()  # nothing supported

    t = Tracker(profile=StubProfile(), transport={"type": "stdio", "command": "x", "args": [], "env": {}})
    t._session = FakeMCPSession()
    with pytest.raises(CapabilityNotSupported):
        await t.list_workspaces()


@pytest.mark.asyncio
async def test_close_rejects_new_borrows_after_drain():
    """After close() is initiated, new borrows must not succeed."""
    session = FakeMCPSession()
    session.set_response("list_boards", {}, [])
    t = _tracker_with_session(session)
    await t.close(timeout=1.0)
    with pytest.raises((RuntimeError, Exception)):
        await t.list_workspaces()
