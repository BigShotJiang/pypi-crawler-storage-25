"""PUT /trackers/{id}/chat-enabled toggles the chat_enabled flag and
broadcasts tracker_changed. Cannot disable chat on the Copilot tracker."""

import pytest
from aiohttp.test_utils import TestClient, TestServer
from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig


@pytest.mark.asyncio
async def test_put_chat_enabled_flips_flag(monkeypatch):
    monkeypatch.setattr("meeting_helper.trackers.secrets.write_secrets",
                        lambda ws, tid, values: None)
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        # First tracker becomes copilot — disabling on it would 409. Create a
        # second tracker (non-copilot) to test the happy-path flip.
        await client.post("/trackers", json={
            "vendor": "local_todo", "label": "Copilot",
            "auth_values": {"url": "http://a/mcp"}, "secrets": {},
        })
        r = await client.post("/trackers", json={
            "vendor": "local_todo", "label": "L",
            "auth_values": {"url": "http://x/mcp"}, "secrets": {},
        })
        tid = (await r.json())["id"]

        r = await client.put(f"/trackers/{tid}/chat-enabled", json={"enabled": False})
        assert r.status == 200, await r.text()

        # Confirm via listing.
        listing = await (await client.get("/trackers")).json()
        entry = next(t for t in listing["trackers"] if t["id"] == tid)
        assert entry["chat_enabled"] is False


@pytest.mark.asyncio
async def test_put_chat_enabled_rejects_disabling_copilot(monkeypatch):
    monkeypatch.setattr("meeting_helper.trackers.secrets.write_secrets",
                        lambda ws, tid, values: None)
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        r = await client.post("/trackers", json={
            "vendor": "local_todo", "label": "L",
            "auth_values": {"url": "http://x/mcp"}, "secrets": {},
        })
        tid = (await r.json())["id"]
        # First tracker is auto-promoted to copilot. Attempt to disable chat:
        r = await client.put(f"/trackers/{tid}/chat-enabled", json={"enabled": False})
        assert r.status == 409, await r.text()
        body = await r.json()
        assert "copilot" in body["error"].lower()


@pytest.mark.asyncio
async def test_put_chat_enabled_404_for_unknown(monkeypatch):
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        r = await client.put("/trackers/does-not-exist/chat-enabled", json={"enabled": True})
        assert r.status == 404
