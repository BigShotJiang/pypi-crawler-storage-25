"""Verify agent_fetch.fetch_active_topics:
- Returns [] when tracker is None
- Returns [] when no provider configured
- Parses agent JSON output into normalized items
- Persists learned memory to disk
"""
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
import pytest

from meeting_helper.ai.agent_fetch import fetch_active_topics, _parse_items, _normalize_item


def test_system_prompt_mentions_done_and_subtasks():
    """Spec test — the agent should know it can include done items + subtasks."""
    from meeting_helper.ai.agent_fetch import _SYSTEM_PROMPT
    text = _SYSTEM_PROMPT.lower()
    assert "done" in text or "completed" in text
    assert "subtask" in text
    assert "child" in text or "children" in text


def test_normalize_item_fills_defaults():
    item = _normalize_item({"id": "MH-1", "title": "X"})
    assert item["id"] == "MH-1"
    assert item["status_kind"] == "todo"
    assert item["board_id"] == ""  # legacy alias mirrors workspace_id

def test_normalize_item_coerces_unknown_status_kind():
    item = _normalize_item({"id": "MH-1", "title": "X", "status_kind": "weird"})
    assert item["status_kind"] == "todo"

def test_parse_items_direct_json():
    items = _parse_items('{"items": [{"id": "MH-1", "title": "Hi"}]}')
    assert len(items) == 1
    assert items[0]["id"] == "MH-1"

def test_parse_items_returns_empty_on_garbage():
    assert _parse_items("the agent forgot to emit JSON") == []

@pytest.mark.asyncio
async def test_returns_empty_when_tracker_none():
    cfg = MagicMock()
    out = await fetch_active_topics(tracker=None, config=cfg)
    assert out == []

@pytest.mark.asyncio
async def test_returns_empty_when_no_provider(monkeypatch):
    tracker = MagicMock()
    cfg = MagicMock()
    cfg.preferred_provider = "claude"
    cfg.anthropic_api_key = ""
    cfg.google_api_key = ""
    cfg.copilot_instructions = ""
    cfg.copilot_learned_memory = []
    # Stub the MCP passthrough so we don't touch a real tracker.
    async def _stub_mcp_tools(_tracker):
        return []
    monkeypatch.setattr(
        "meeting_helper.chat.tools.mcp_passthrough.build_mcp_passthrough_tools",
        _stub_mcp_tools,
    )
    out = await fetch_active_topics(tracker=tracker, config=cfg)
    assert out == []

@pytest.mark.asyncio
async def test_agent_loop_invocation_and_memory_persist(monkeypatch):
    tracker = MagicMock()
    cfg = MagicMock()
    cfg.preferred_provider = "claude"
    cfg.anthropic_api_key = "k"
    cfg.claude_model = "haiku"
    cfg.copilot_instructions = "project=MH"
    cfg.copilot_learned_memory = []

    async def _stub_registry(_state, _cfg=None):
        from meeting_helper.chat.registry import Registry
        return Registry()
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry_async", _stub_registry)

    # Stub run_agent to return a JSON reply.
    async def _stub_run_agent(*, system, messages, registry, provider, **_):
        # Pretend agent already called the `remember` tool via the registry.
        for tool in registry.tools():
            if tool.name == "remember":
                await tool.run({"text": "cloudId=acme-cloud-abc"}, {})
        return {"text": '{"items":[{"id":"MH-1","title":"Test","workspace_id":"P"}]}'}
    monkeypatch.setattr("meeting_helper.chat.agent_loop.run_agent", _stub_run_agent)

    disk = MagicMock()
    disk.copilot_learned_memory = []
    out = await fetch_active_topics(tracker=tracker, config=cfg, disk=disk)
    assert len(out) == 1
    assert out[0]["id"] == "MH-1"
    # learned memory was persisted
    assert disk.save.called
    assert any("cloudId" in m.get("text", "") for m in (disk.copilot_learned_memory or []))
