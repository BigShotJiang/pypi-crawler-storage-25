"""The ticket picker prompt must surface the previous topic so the LLM can
keep it on follow-up questions ('what are the consequences?' / 'why?' /
'tell me more') instead of re-anchoring onto a different recent transcript
line."""

from unittest.mock import AsyncMock, patch

import pytest

from meeting_helper.ai.prompts import (
    TICKET_PICKER_SYSTEM_PROMPT,
    build_ticket_picker_user_message,
)


def test_system_prompt_documents_followup_rule():
    """The system prompt must teach the LLM the follow-up rule explicitly,
    otherwise it has no way to know to keep the prior ticket."""
    text = TICKET_PICKER_SYSTEM_PROMPT.lower()
    assert "previous topic" in text
    assert "follow-up" in text
    # The follow-up step must come BEFORE the transcript-pick step — otherwise
    # the LLM will weight recency over the follow-up rule.
    step1 = text.find("step 1")
    step3 = text.find("step 3")
    assert step1 != -1 and step3 != -1 and step1 < step3
    # Spot-check the user-facing example phrasings.
    assert "consequences" in text or "tell me more" in text


def test_user_message_includes_previous_topic_and_user_question_blocks():
    msg = build_ticket_picker_user_message(
        sprint_tickets=[
            {"id": "SCRUM-7", "title": "Integer overflow in sample manager"},
            {"id": "SCRUM-8", "title": "Review skip backlog on restart"},
        ],
        labeled_sentences=[
            ("other", "let's talk about the overflow bug"),
        ],
        previous_ticket_id="SCRUM-7",
        previous_topic_title="Integer overflow in sample manager",
        user_question="what is the consequences of having it not fixed",
    )
    # All four required sections present.
    assert "## Available tickets" in msg
    assert "## Previous topic" in msg
    assert "## User question" in msg
    assert "## Recent transcript" in msg
    # Previous topic block names the prior ticket id + title.
    assert "SCRUM-7: Integer overflow in sample manager" in msg
    # User question lives in its OWN block, not merged into the transcript.
    q_block = msg.split("## User question", 1)[1].split("##", 1)[0]
    assert "what is the consequences of having it not fixed" in q_block
    transcript_block = msg.split("## Recent transcript", 1)[1]
    assert "what is the consequences of having it not fixed" not in transcript_block


def test_user_message_marks_first_pick_when_no_previous():
    msg = build_ticket_picker_user_message(
        sprint_tickets=[{"id": "X-1", "title": "Thing"}],
        labeled_sentences=[("self", "let's discuss the thing")],
    )
    assert "## Previous topic" in msg
    assert "(none — first pick)" in msg


def test_user_message_marks_auto_pick_when_no_user_question():
    """TopicWorker calls pick_topic_ticket with question='' — the User
    question block must show the auto-pick sentinel so the LLM knows
    to fall back to Step 3 (transcript pick) instead of treating an empty
    question as a follow-up."""
    msg = build_ticket_picker_user_message(
        sprint_tickets=[{"id": "X-1", "title": "Thing"}],
        labeled_sentences=[("other", "talking about the thing")],
        previous_ticket_id="X-1",
        previous_topic_title="Thing",
        user_question="",
    )
    assert "## User question" in msg
    assert "(none — auto pick from transcript)" in msg


def test_user_message_handles_partial_previous_topic():
    """Previous ticket id without a title should still render cleanly."""
    msg = build_ticket_picker_user_message(
        sprint_tickets=[{"id": "X-1", "title": "Thing"}],
        labeled_sentences=[("self", "more on it")],
        previous_ticket_id="X-1",
        previous_topic_title="",
    )
    assert "## Previous topic" in msg
    # Bare id, no trailing ': '.
    assert "\nX-1\n" in msg


@pytest.mark.asyncio
async def test_pick_topic_ticket_anchors_on_explicit_previous_kwarg():
    """When the caller passes `previous_topic`, the picker must include THAT
    in the prompt — not whatever is in state.current_topic (which the
    auto-worker may have drifted between user questions)."""
    from meeting_helper.ai import client as c
    from meeting_helper.config import AppConfig
    from meeting_helper.state import AppState

    state = AppState()
    state.sprint_tickets = [
        {"id": "A-1", "title": "User-query topic"},
        {"id": "A-2", "title": "Drifted auto-worker topic"},
    ]
    # Auto-worker drifted the banner to A-2 between the previous user query
    # (which picked A-1) and this new question.
    state.current_topic = {
        "topic": "Drifted auto-worker topic",
        "ticket_ids": ["A-2"],
    }
    # But the caller is the user-query path, so it pins the anchor on A-1.
    explicit_prev = {"topic": "User-query topic", "ticket_ids": ["A-1"]}

    captured = {}

    async def _fake_call(config, sys_prompt, user_msg, kind="topic-pick"):
        captured["user_msg"] = user_msg
        return '{"ticket_id": "A-1", "topic": "User-query topic"}'

    with patch.object(c, "_call_ai_for_tasks", new=AsyncMock(side_effect=_fake_call)):
        await c.pick_topic_ticket(
            state, AppConfig(), question="tell me more",
            previous_topic=explicit_prev,
        )

    assert "A-1: User-query topic" in captured["user_msg"]
    # The drifted A-2 must NOT have leaked into the previous-topic block (it's
    # still in `## Available tickets` of course, but not as the prior anchor).
    prev_block = captured["user_msg"].split("## Previous topic")[1].split("##")[0]
    assert "A-2" not in prev_block


def test_user_message_tags_latest_substantive_line_regardless_of_speaker():
    """The picker prompt's Step 3 (auto-pick path) anchors on whichever line
    carries the `[LATEST]` marker. The marker is placed on the latest
    substantive line in the window — regardless of who spoke it. Previously
    we tagged only `[me]` lines, but that silently broke listen-mostly
    meetings (demos, code reviews) where the OTHER party drives the topic
    by asking about a specific ticket. With no `[LATEST]` to anchor on,
    Haiku fell back to whole-window attention and kept the banner frozen.
    """
    msg = build_ticket_picker_user_message(
        sprint_tickets=[{"id": "X", "title": "T"}],
        labeled_sentences=[
            ("self",  "first me line"),
            ("other", "they replied"),
            ("self",  "second me line"),
            ("other", "they replied AGAIN — this is the latest"),
        ],
        user_question="",
    )
    transcript_block = msg.split("## Recent transcript", 1)[1]
    # Exactly one [LATEST] marker, on the genuinely latest line.
    assert transcript_block.count("[LATEST]") == 1
    assert "[other] [LATEST] they replied AGAIN" in transcript_block
    # Earlier lines never get tagged.
    assert "[me] [LATEST]" not in transcript_block.split("[other] [LATEST]")[0]


def test_user_message_tags_other_only_window():
    """When the window contains only `[other]` lines (listen-mostly
    meetings), the latest one MUST still get `[LATEST]` so the picker has
    an anchor to act on. The old behavior (tag only `[me]`) silently
    produced no marker here — exactly the bug the user reported."""
    msg = build_ticket_picker_user_message(
        sprint_tickets=[{"id": "X", "title": "T"}],
        labeled_sentences=[
            ("other", "first thing they said"),
            ("other", "newest thing they said"),
        ],
        user_question="",
    )
    transcript_block = msg.split("## Recent transcript", 1)[1]
    assert "[other] [LATEST] newest thing they said" in transcript_block
    # Only one marker, on the truly latest entry.
    assert transcript_block.count("[LATEST]") == 1


def test_user_message_tags_latest_me_when_me_is_last():
    """Sanity: when `[me]` IS the latest substantive line, it gets the
    marker — preserves the original happy-path behavior."""
    msg = build_ticket_picker_user_message(
        sprint_tickets=[{"id": "X", "title": "T"}],
        labeled_sentences=[
            ("other", "they spoke first"),
            ("self",  "I responded — latest"),
        ],
        user_question="",
    )
    transcript_block = msg.split("## Recent transcript", 1)[1]
    assert "[me] [LATEST] I responded — latest" in transcript_block


def test_user_message_no_latest_when_window_empty():
    """Empty windows produce no marker (and no crash)."""
    msg = build_ticket_picker_user_message(
        sprint_tickets=[{"id": "X", "title": "T"}],
        labeled_sentences=[],
        user_question="",
    )
    assert "[LATEST]" not in msg


def test_system_prompt_documents_latest_marker_rule():
    """The system prompt must mention `[LATEST]` so the LLM knows what the
    tag means — otherwise the marker is decoration and the model ignores it."""
    text = TICKET_PICKER_SYSTEM_PROMPT
    assert "[LATEST]" in text
    # And the prompt must instruct using it as the auto-pick anchor.
    assert "anchor" in text.lower()
