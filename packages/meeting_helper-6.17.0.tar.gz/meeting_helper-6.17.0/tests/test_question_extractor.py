"""Unit tests for `_extract_likely_question` — chronological + cutoff-aware."""

from meeting_helper.ai.client import _extract_likely_question


def test_returns_most_recent_question_after_cutoff():
    sentences = [
        (100.0, "self", "I'm working on ENGT-4147."),
        (101.0, "self", "What does the remapper do?"),
        (102.0, "other", "And what about ENGT-4212?"),
    ]
    # Cutoff at 99 — everything is fresh; latest `?` wins
    assert (
        _extract_likely_question(sentences, cutoff_ts=99.0)
        == "And what about ENGT-4212?"
    )


def test_cutoff_filters_out_stale_questions():
    sentences = [
        (100.0, "self", "What does the remapper do?"),  # stale `?` — before cutoff
        (101.0, "self", "Followed up declarative statement."),
        (102.0, "other", "Some other-party statement, no question mark."),
    ]
    # Cutoff at 100 excludes the stale `?`. We no longer reach back to an old
    # `?`; the latest FRESH substantive line is pinned instead (so a current
    # request/statement wins over a question from a while ago).
    assert (
        _extract_likely_question(sentences, cutoff_ts=100.0)
        == "Some other-party statement, no question mark."
    )


def test_chronological_ordering_beats_role_order():
    # Other speaks first, then self — most recent `?` should be self's
    sentences = [
        (100.0, "other", "Earlier other question?"),
        (110.0, "self", "Later self question?"),
    ]
    assert (
        _extract_likely_question(sentences, cutoff_ts=0.0)
        == "Later self question?"
    )


def test_substantive_statement_is_pinned_even_without_question_mark():
    # A substantive line (>= 3 real words) is now pinned even without a `?`,
    # so the copilot can respond to a request or a point the other party made.
    sentences = [
        (100.0, "self", "Just a statement."),
        (101.0, "other", "Another statement, no questions here."),
    ]
    assert (
        _extract_likely_question(sentences, cutoff_ts=0.0)
        == "Another statement, no questions here."
    )


def test_bare_acknowledgements_return_empty():
    # Short acknowledgements (no `?`, under 3 real words) must NOT be pinned as
    # the question; they fall back to the topic prompt.
    sentences = [
        (100.0, "self", "Yeah."),
        (101.0, "other", "Ok, sure."),
    ]
    assert _extract_likely_question(sentences, cutoff_ts=0.0) == ""


def test_empty_input_returns_empty():
    assert _extract_likely_question([], cutoff_ts=0.0) == ""


def test_cutoff_zero_includes_all():
    sentences = [(100.0, "self", "Everything is in scope?")]
    assert (
        _extract_likely_question(sentences, cutoff_ts=0.0)
        == "Everything is in scope?"
    )
