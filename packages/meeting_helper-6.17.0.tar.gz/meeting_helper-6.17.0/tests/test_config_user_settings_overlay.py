"""Tests for user-settings overlay flags: diarization toggles, auto-name
speakers on end, and user display name.

Uses `monkeypatch.setenv("HOME", str(tmp_path))` + an `importlib.reload`
so the module-level constants in `meeting_helper.config` (which capture
`Path.home()` at import time) are re-derived from the patched HOME and
each test gets an isolated workspace dir.
"""

from __future__ import annotations

import importlib


def _fresh_config(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("TEST_MODE", raising=False)
    import meeting_helper.config as cfg_mod
    importlib.reload(cfg_mod)
    return cfg_mod


def test_deepgram_diarize_other_default_true(tmp_path, monkeypatch):
    cfg_mod = _fresh_config(monkeypatch, tmp_path)
    cfg = cfg_mod.Config()
    assert cfg.deepgram_diarize_other is True


def test_deepgram_diarize_self_default_false(tmp_path, monkeypatch):
    cfg_mod = _fresh_config(monkeypatch, tmp_path)
    cfg = cfg_mod.Config()
    assert cfg.deepgram_diarize_self is False


def test_auto_name_speakers_on_end_default_true(tmp_path, monkeypatch):
    cfg_mod = _fresh_config(monkeypatch, tmp_path)
    cfg = cfg_mod.Config()
    assert cfg.auto_name_speakers_on_end is True


def test_user_display_name_default_empty(tmp_path, monkeypatch):
    cfg_mod = _fresh_config(monkeypatch, tmp_path)
    cfg = cfg_mod.Config()
    assert cfg.user_display_name == ""


def test_config_setters_persist(tmp_path, monkeypatch):
    cfg_mod = _fresh_config(monkeypatch, tmp_path)
    cfg = cfg_mod.Config()
    cfg.deepgram_diarize_other = False
    cfg.user_display_name = "Victor"
    cfg.save()
    reloaded = cfg_mod.Config()
    assert reloaded.deepgram_diarize_other is False
    assert reloaded.user_display_name == "Victor"


def test_to_app_config_forwards_new_flags(tmp_path, monkeypatch):
    """Regression: AppConfig snapshot must carry the four diarization /
    naming flags added by ticket #243. Without this, session.py
    (which reads `config.deepgram_diarize_self` etc. from the runtime
    AppConfig) crashes on every meeting start.
    """
    monkeypatch.setenv("HOME", str(tmp_path))
    import importlib
    import meeting_helper.config as _cfg
    importlib.reload(_cfg)
    try:
        cfg = _cfg.Config()
        cfg.deepgram_diarize_other = False
        cfg.deepgram_diarize_self = True
        cfg.auto_name_speakers_on_end = False
        cfg.user_display_name = "Victor"
        app = cfg.to_app_config()
        assert app.deepgram_diarize_other is False
        assert app.deepgram_diarize_self is True
        assert app.auto_name_speakers_on_end is False
        assert app.user_display_name == "Victor"
    finally:
        importlib.reload(_cfg)


def test_app_config_defaults_match_dataclass_definition():
    """Sanity: AppConfig() with no args has the right defaults
    for the new flags (matches DEFAULT_CONFIG).
    """
    from meeting_helper.config import AppConfig
    a = AppConfig()
    assert a.deepgram_diarize_other is True
    assert a.deepgram_diarize_self is False
    assert a.auto_name_speakers_on_end is True
    assert a.user_display_name == ""


# Cleanup: reload config without our HOME override so other tests in the
# suite see the prod constants.
def teardown_module(module):
    import meeting_helper.config as cfg_mod
    importlib.reload(cfg_mod)
