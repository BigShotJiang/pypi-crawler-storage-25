from meeting_helper.chat import paths as chat_paths, state as chat_state


def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


def test_read_state_empty(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    assert chat_state.read_state() == {"active_thread_id": None}


def test_write_then_read_active(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    chat_state.set_active("thr_abc")
    assert chat_state.read_state() == {"active_thread_id": "thr_abc"}


def test_clear_active(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    chat_state.set_active("thr_abc")
    chat_state.set_active(None)
    assert chat_state.read_state() == {"active_thread_id": None}
