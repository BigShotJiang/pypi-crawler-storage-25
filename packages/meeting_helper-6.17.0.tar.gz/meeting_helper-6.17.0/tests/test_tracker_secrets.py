# tests/test_tracker_secrets.py
from unittest.mock import MagicMock
import pytest
from meeting_helper.trackers import secrets as secrets_mod
from meeting_helper.trackers.secrets import (
    KeychainUnavailable, read_secrets, write_secrets, purge_tracker,
)


@pytest.fixture
def fake_keyring(monkeypatch):
    store: dict[tuple[str, str], str] = {}
    kr = MagicMock()
    kr.set_password = lambda svc, acct, val: store.__setitem__((svc, acct), val)
    kr.get_password = lambda svc, acct: store.get((svc, acct))
    kr.delete_password = lambda svc, acct: store.pop((svc, acct), None)
    monkeypatch.setattr(secrets_mod, "keyring", kr)
    return store


def test_write_then_read(fake_keyring):
    write_secrets("work", "jira-1", {"api_token": "tok-abc"})
    assert fake_keyring[("meeting-helper", "work.jira-1.api_token")] == "tok-abc"
    out = read_secrets("work", "jira-1", ["api_token"])
    assert out == {"api_token": "tok-abc"}


def test_read_missing_returns_empty_value(fake_keyring):
    out = read_secrets("work", "jira-1", ["api_token"])
    assert out == {"api_token": ""}


def test_purge_tracker_removes_all_keys(fake_keyring):
    write_secrets("work", "jira-1", {"api_token": "t1", "other": "t2"})
    purge_tracker("work", "jira-1", ["api_token", "other"])
    assert read_secrets("work", "jira-1", ["api_token", "other"]) == {"api_token": "", "other": ""}


def test_keyring_unavailable_raised(monkeypatch):
    bad = MagicMock()
    bad.set_password.side_effect = RuntimeError("no backend")
    monkeypatch.setattr(secrets_mod, "keyring", bad)
    with pytest.raises(KeychainUnavailable):
        write_secrets("work", "jira-1", {"k": "v"})
