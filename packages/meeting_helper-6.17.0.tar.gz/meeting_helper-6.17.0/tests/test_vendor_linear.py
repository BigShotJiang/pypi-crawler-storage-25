# tests/test_vendor_linear.py
import pytest
from meeting_helper.trackers.vendors.linear import LinearProfile


def test_profile_class_attributes():
    p = LinearProfile
    assert p.id == "linear"
    assert p.label == "Linear"
    assert p.transport.type == "http"
    assert p.auth_mode == "mcp_oauth"
    assert p.supports == frozenset()
    assert p.agent_terminology
    assert p.agent_hints
