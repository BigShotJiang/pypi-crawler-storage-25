import pytest

from meeting_helper.chat.registry import Registry, Tool


def test_register_and_dispatch():
    async def run(args, ctx):
        return {"status": "ok", "result": args["q"].upper()}

    reg = Registry()
    reg.register(
        Tool(
            name="echo.upper",
            description="echo upper",
            input_schema={"q": "string"},
            run=run,
            is_mutation=False,
        )
    )
    assert "echo.upper" in [t.name for t in reg.tools()]


@pytest.mark.asyncio
async def test_call_returns_tool_result():
    async def run(args, ctx):
        return {"status": "ok", "result": args["q"].upper()}

    reg = Registry()
    reg.register(
        Tool(
            name="echo.upper",
            description="d",
            input_schema={"q": "string"},
            run=run,
            is_mutation=False,
        )
    )
    out = await reg.call("echo.upper", {"q": "hi"}, ctx={})
    assert out == {"status": "ok", "result": "HI"}


@pytest.mark.asyncio
async def test_call_unknown_tool_returns_error():
    reg = Registry()
    out = await reg.call("nope.nope", {}, ctx={})
    assert out["status"] == "error"
    assert "unknown" in out["error"].lower()


@pytest.mark.asyncio
async def test_call_swallows_exception_into_status_error():
    async def run(args, ctx):
        raise RuntimeError("boom")

    reg = Registry()
    reg.register(
        Tool(
            name="bad",
            description="d",
            input_schema={},
            run=run,
            is_mutation=False,
        )
    )
    out = await reg.call("bad", {}, ctx={})
    assert out["status"] == "error"
    assert "boom" in out["error"]


def test_mutating_tool_flagged():
    async def run(args, ctx):
        return {"status": "ok"}

    reg = Registry()
    reg.register(
        Tool(
            name="w",
            description="d",
            input_schema={},
            run=run,
            is_mutation=True,
        )
    )
    assert reg.get("w").is_mutation
