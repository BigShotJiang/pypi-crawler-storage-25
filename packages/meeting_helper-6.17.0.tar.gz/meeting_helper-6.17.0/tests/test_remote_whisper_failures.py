"""Tests for RemoteWhisperTranscriber failure handling.

When the remote faster-whisper-server stops responding (the production
symptom that produced ticket #150 — "Whisper Badly Working / not listing
what I say"), every call to `/v1/audio/transcriptions` either times out
or returns a non-200. We need the transcriber to:

1. Bound each HTTP request so the feed loop isn't stuck for 30 s per
   segment while the user's mic queue silently fills and drop-oldest
   erases their audio.
2. Count consecutive failures and emit a one-shot `transcriber_dead`
   broadcast so the UI shows the failure instead of a green Whisper
   pill on a dead pipe.
3. Reset the counter and the latch on the next 200 so partial-recovery
   leaves the transcriber working again.

These tests stub the HTTP path; no real socket calls.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np

from meeting_helper.audio.transcriber import RemoteWhisperTranscriber


def _make_transcriber() -> RemoteWhisperTranscriber:
    """Build a RemoteWhisperTranscriber with stub buffer + capture."""
    capture = MagicMock()
    capture.get_transcriber_audio = MagicMock(return_value=None)
    buffer = MagicMock()
    buffer.role = "self"
    return RemoteWhisperTranscriber(
        audio_capture=capture,
        transcript_buffer=buffer,
        host="http://example.invalid:8000",
        language="en",
    )


def _silence(seconds: float = 0.5) -> np.ndarray:
    """Audio chunk with no signal — passes through _transcribe_remote's
    WAV-encoding without tripping the speech threshold."""
    return np.zeros(int(seconds * 16000), dtype=np.float32)


def test_http_timeout_is_tight():
    """Per-request HTTP timeout must be tight enough that a hung remote
    backend can't block the feed loop for 30 s per call (the original
    bug). 10 s is the documented contract — covers a slow GPU response
    but still lets the failure-counter trip in < 1 min."""
    t = _make_transcriber()
    with patch("http.client.HTTPConnection") as mock_conn_cls:
        t._get_conn()
    _, kwargs = mock_conn_cls.call_args
    assert kwargs["timeout"] == RemoteWhisperTranscriber.HTTP_REQUEST_TIMEOUT_SEC
    assert kwargs["timeout"] <= 15  # explicit guard against accidental regression


def test_transcribe_failure_counts_toward_dead_broadcast():
    """Repeated exceptions from the HTTP path bump `_consecutive_failures`
    and trip `_broadcast_dead` once the threshold is crossed. Without
    this, a wedged backend looks identical to silence from the user's
    seat — green pill, no transcripts, no failure indication."""
    t = _make_transcriber()
    t.MAX_CONSECUTIVE_FAILURES = 3  # tighten so the test stays fast

    def boom(*_a, **_kw):
        raise TimeoutError("simulated hang")

    with patch.object(t, "_get_conn", side_effect=boom), \
         patch.object(t, "_broadcast_dead") as mock_dead:
        # First MAX-1 failures do not broadcast.
        for _ in range(t.MAX_CONSECUTIVE_FAILURES - 1):
            t._transcribe_remote(_silence())
        mock_dead.assert_not_called()
        # The Nth failure trips the broadcast.
        t._transcribe_remote(_silence())
        mock_dead.assert_called_once()
        # And the reason string carries forward the exception class so
        # the UI can show a useful message instead of a vague "dead".
        args, _ = mock_dead.call_args
        assert "TimeoutError" in args[0]


def test_dead_broadcast_is_one_shot_per_outage():
    """`_broadcast_dead` must latch — emit once per outage, not on every
    subsequent failure. Otherwise the UI would get a `transcriber_dead`
    event 50 times a minute and chip-state would flicker."""
    t = _make_transcriber()
    t.MAX_CONSECUTIVE_FAILURES = 2
    with patch.object(t, "_get_conn", side_effect=TimeoutError("x")), \
         patch.object(t, "_broadcast_dead", wraps=t._broadcast_dead) as spy, \
         patch.object(t, "_schedule_dead_broadcast", create=True):
        # Stub out the actual loop dispatch — we only care that the
        # method body was invoked once.
        with patch("meeting_helper.audio.transcriber._schedule_threadsafe"):
            for _ in range(5):
                t._transcribe_remote(_silence())
    # Spy fires every time _note_failure decides to send; the latch
    # inside _broadcast_dead handles the one-shot behavior. We assert
    # `_dead_broadcast_sent` ends True regardless of how many call
    # attempts were made.
    assert t._dead_broadcast_sent is True


def test_success_resets_failure_counter_and_latch():
    """A 200 response — even an empty one — resets the counter so we
    don't carry an old outage forward, and clears the latch so a fresh
    outage can broadcast again."""
    t = _make_transcriber()
    t._consecutive_failures = 4
    t._dead_broadcast_sent = True

    # Build a fake `getresponse()` result.
    fake_resp = MagicMock()
    fake_resp.status = 200
    fake_resp.read.return_value = b'{"text": ""}'

    fake_conn = MagicMock()
    fake_conn.getresponse.return_value = fake_resp

    with patch.object(t, "_get_conn", return_value=fake_conn):
        result = t._transcribe_remote(_silence())

    assert result == ""
    assert t._consecutive_failures == 0
    assert t._dead_broadcast_sent is False


def test_non_200_response_counts_as_failure():
    """A 500 from the backend is just as fatal as a timeout — we still
    can't transcribe. Make sure it bumps the failure counter so an
    always-5xx backend trips the dead broadcast on the same threshold."""
    t = _make_transcriber()
    t.MAX_CONSECUTIVE_FAILURES = 2

    fake_resp = MagicMock()
    fake_resp.status = 502
    fake_resp.read.return_value = b"Bad Gateway"

    fake_conn = MagicMock()
    fake_conn.getresponse.return_value = fake_resp

    with patch.object(t, "_get_conn", return_value=fake_conn), \
         patch.object(t, "_broadcast_dead") as mock_dead:
        t._transcribe_remote(_silence())
        assert t._consecutive_failures == 1
        mock_dead.assert_not_called()
        t._transcribe_remote(_silence())
        assert t._consecutive_failures == 2
        mock_dead.assert_called_once()


def test_start_rejects_unreachable_host():
    """If both /health and / fail to respond, start() returns False so
    `create_transcriber` falls back to local Whisper instead of starting
    a remote transcriber that will drop every segment."""
    t = _make_transcriber()

    def always_fail(*_a, **_kw):
        raise TimeoutError("backend wedged")

    with patch("urllib.request.urlopen", side_effect=always_fail):
        assert t.start() is False


def test_start_accepts_host_returning_4xx():
    """Some deployments answer /health with 404 but still serve the
    transcription endpoint. The reachability check must treat any HTTP
    response (even an error code) as 'server is up enough to try'."""
    import urllib.error

    t = _make_transcriber()

    def http_error(*_a, **_kw):
        raise urllib.error.HTTPError("http://x", 404, "nope", {}, None)  # type: ignore[arg-type]

    with patch("urllib.request.urlopen", side_effect=http_error), \
         patch.object(t, "_supervised_run"):
        assert t.start() is True
    # Tidy up the daemon thread so pytest doesn't complain about a
    # leaked Thread on session teardown.
    t.stop()
