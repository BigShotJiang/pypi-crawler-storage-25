import pytest

from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig
from meeting_helper.state import state as global_state


@pytest.fixture(autouse=True)
def _reset():
    global_state.topic_auto_paused = False
    yield
    global_state.topic_auto_paused = False


@pytest.fixture
async def client(aiohttp_client):
    app = create_app(AppConfig())
    return await aiohttp_client(app)


async def test_mode_manual_sets_paused(client):
    resp = await client.post("/topic/mode", json={"mode": "manual"})
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body["topic_mode"] == "manual"
    assert global_state.topic_auto_paused is True


async def test_mode_auto_clears_paused(client):
    global_state.topic_auto_paused = True
    resp = await client.post("/topic/mode", json={"mode": "auto"})
    assert resp.status == 200
    body = await resp.json()
    assert body["topic_mode"] == "auto"
    assert global_state.topic_auto_paused is False


async def test_mode_rejects_invalid(client):
    resp = await client.post("/topic/mode", json={"mode": "sideways"})
    assert resp.status == 400
    assert global_state.topic_auto_paused is False


async def test_current_topic_includes_topic_mode(client):
    global_state.topic_auto_paused = True
    resp = await client.get("/current_topic")
    assert resp.status == 200
    body = await resp.json()
    assert body["topic_mode"] == "manual"

    global_state.topic_auto_paused = False
    resp2 = await client.get("/current_topic")
    body2 = await resp2.json()
    assert body2["topic_mode"] == "auto"
