"""Tests for /topics, /topic/set, and /brief using a real Tracker + FakeMCPSession.

These tests do NOT mock state.local_todo as a MagicMock. Instead they wire a
real Tracker (with a FakeMCPSession) onto state.tracker so that any
AttributeError from calling removed methods would surface as a real failure.
"""
from __future__ import annotations

import json
import time
from unittest.mock import MagicMock, patch

import pytest

from tests.helpers.fake_mcp import FakeMCPSession
from meeting_helper.trackers.tracker import Tracker
from meeting_helper.trackers.vendors.local_todo import LocalTodoProfile


def _tracker_with_session(session: FakeMCPSession) -> Tracker:
    t = Tracker(
        profile=LocalTodoProfile(),
        transport={"type": "stdio", "command": "x", "args": [], "env": {}},
    )
    t._session = session  # bypass _ensure_started for tests
    return t


def _make_app(config=None):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes

    app = web.Application()
    app["config"] = config or _FakeConfig()
    setup_routes(app)
    return app


class _FakeConfig:
    anthropic_api_key = "test-key"
    max_tokens = 800
    local_todo_configured = True
    workspace_name = "test-ws"
    active_tracker_id = None
    trackers = []
    # Brief reads config.claude_model directly (no fallback) so tests must
    # supply it — same shape AppConfig produces in production.
    claude_model = "claude-haiku-4-5-20251001"


# ---------------------------------------------------------------------------
# /topics
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_topics_returns_tasks_from_sprint_tickets(aiohttp_client):
    """GET /topics serves from state.sprint_tickets (agent-fetched)."""
    from meeting_helper.state import state as global_state

    session = FakeMCPSession()
    tracker = _tracker_with_session(session)
    global_state.tracker = tracker
    global_state.sprint_tickets = [
        {
            "id": "42", "title": "Fix auth bug", "status": "in_progress",
            "status_kind": "in_progress", "priority": "high", "body_md": "",
            "workspace_id": "10", "workspace_name": "WorkBoard",
            "board_id": "10", "board_name": "WorkBoard",
            "sprint_name": "Sprint 1", "url": None,
            "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
            "recent_history": [], "linked_docs": [],
        },
    ]
    global_state.sprint_tickets_loaded_at = time.time()

    client = await aiohttp_client(_make_app())
    resp = await client.get("/topics")
    assert resp.status == 200, await resp.text()
    body = await resp.json()

    assert "topics" in body
    assert len(body["topics"]) == 1
    topic = body["topics"][0]
    assert topic["id"] == "42"
    assert topic["title"] == "Fix auth bug"
    assert "sprint_name" in topic
    assert body["columns"] == []

    # Reset
    global_state.tracker = None
    global_state.sprint_tickets = []


@pytest.mark.asyncio
async def test_topics_returns_200_with_action_items_when_tracker_none(aiohttp_client):
    """GET /topics → 200 with action items only when no tracker is configured.

    Earlier behavior returned 503; the response is now 200 so the Copilot
    panel can still render open action items even without a wired tracker.
    """
    from meeting_helper.state import state as global_state

    global_state.tracker = None

    client = await aiohttp_client(_make_app())
    resp = await client.get("/topics")
    assert resp.status == 200
    body = await resp.json()
    # No tracker → no ticket topics. No action items in this test → empty list.
    assert body["topics"] == []
    assert body["columns"] == []


@pytest.mark.asyncio
async def test_topics_returns_empty_when_no_sprint_tickets(aiohttp_client):
    """GET /topics returns empty topics when no sprint tickets loaded yet."""
    from meeting_helper.state import state as global_state

    session = FakeMCPSession()
    tracker = _tracker_with_session(session)
    global_state.tracker = tracker
    global_state.sprint_tickets = []

    client = await aiohttp_client(_make_app())
    resp = await client.get("/topics")
    assert resp.status == 200
    body = await resp.json()
    assert body["topics"] == []
    assert body["columns"] == []

    global_state.tracker = None
    global_state.sprint_tickets = []


# ---------------------------------------------------------------------------
# /topic/set
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_topic_set_uses_sprint_ticket_when_found(aiohttp_client):
    """POST /topic/set uses the pre-fetched card from state.sprint_tickets."""
    from meeting_helper.state import state as global_state

    session = FakeMCPSession()
    tracker = _tracker_with_session(session)
    global_state.tracker = tracker
    global_state.sprint_tickets = [
        {
            "id": "T-7", "title": "Migrate DB schema",
            "status": "in_progress", "status_kind": "in_progress",
            "body_md": "## Details\nMigrate postgres schema.",
            "workspace_id": "5", "workspace_name": "BoardA",
            "board_id": "5", "board_name": "BoardA",
            "sprint_name": "Sprint 2", "url": None,
            "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
            "recent_history": [], "linked_docs": [],
        },
    ]
    global_state.current_topic = {"topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": ""}
    global_state.current_topic_cards = []
    global_state.topic_manual_mode = False

    client = await aiohttp_client(_make_app())
    resp = await client.post("/topic/set", json={
        "ticket_id": "T-7",
        "title": "Migrate DB schema",
        "board_id": 5,
    })
    assert resp.status == 200, await resp.text()
    body = await resp.json()
    assert body["ok"] is True
    assert body["ticket_id"] == "T-7"

    # The card from sprint_tickets should be set on state
    assert len(global_state.current_topic_cards) == 1
    card = global_state.current_topic_cards[0]
    assert card["id"] == "T-7"
    assert "Migrate postgres" in (card.get("body_md") or "")

    # Reset
    global_state.tracker = None
    global_state.sprint_tickets = []
    global_state.current_topic_cards = []
    global_state.topic_manual_mode = False


@pytest.mark.asyncio
async def test_topic_set_fallback_to_thin_card_when_not_in_sprint_tickets(aiohttp_client):
    """POST /topic/set falls back to a thin card when ticket not in sprint_tickets."""
    from meeting_helper.state import state as global_state

    session = FakeMCPSession()
    tracker = _tracker_with_session(session)
    global_state.tracker = tracker
    global_state.sprint_tickets = []
    global_state.current_topic_cards = []
    global_state.topic_manual_mode = False

    client = await aiohttp_client(_make_app())
    resp = await client.post("/topic/set", json={
        "ticket_id": "MISSING-1",
        "title": "Unknown ticket",
        "board_id": 7,
    })
    # Should still succeed (fall back to thin card)
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True

    # Thin card should be set
    assert len(global_state.current_topic_cards) == 1
    assert global_state.current_topic_cards[0]["id"] == "MISSING-1"

    global_state.tracker = None
    global_state.sprint_tickets = []
    global_state.current_topic_cards = []
    global_state.topic_manual_mode = False


# ---------------------------------------------------------------------------
# /brief
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_brief_returns_503_when_tracker_none(aiohttp_client):
    """POST /brief → 503 when no tracker configured."""
    from meeting_helper.state import state as global_state

    global_state.tracker = None

    client = await aiohttp_client(_make_app())
    resp = await client.post("/brief")
    assert resp.status == 503


@pytest.mark.asyncio
async def test_brief_uses_agent_fetched_sprint_tickets(aiohttp_client):
    """POST /brief uses state.sprint_tickets (pre-populated by agent fetch)."""
    from meeting_helper.state import state as global_state

    session = FakeMCPSession()
    tracker = _tracker_with_session(session)
    global_state.tracker = tracker
    # Pre-populate sprint_tickets in agent-fetched dict shape.
    global_state.sprint_tickets = [{
        "id": "BUG-1", "title": "Fix login", "status": "in_progress",
        "status_kind": "in_progress", "body_md": "Fix the OAuth login flow.",
        "workspace_id": "3", "workspace_name": "MyBoard", "board_id": "3",
        "board_name": "MyBoard", "sprint_name": "Sprint 3", "url": None,
        "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
        "recent_history": [], "linked_docs": [],
    }]
    global_state.sprint_tickets_loaded_at = time.time()

    fake_message = MagicMock()
    fake_message.content = [MagicMock(text=json.dumps({
        "script": "**Today**\n- I'm fixing BUG-1 login issue.",
        "card_ids": ["BUG-1"],
    }))]

    class FakeMessages:
        async def create(self, **kwargs):
            return fake_message

    class FakeAnthropic:
        def __init__(self, *a, **k):
            self.messages = FakeMessages()

    with patch("meeting_helper.server.routes.AsyncAnthropic", new=FakeAnthropic, create=True):
        client = await aiohttp_client(_make_app())
        resp = await client.post("/brief")

    assert resp.status == 200, await resp.text()
    body = await resp.json()
    assert "Today" in body["script"] or "BUG-1" in body["script"]
    # Cards should be returned from the pre-populated sprint_tickets
    assert isinstance(body["cards"], list)

    global_state.tracker = None
    global_state.sprint_tickets = []
    global_state.sprint_tickets_loaded_at = 0


@pytest.mark.asyncio
async def test_brief_returns_correct_task_fields_from_sprint_tickets(aiohttp_client):
    """Verify that agent-fetched sprint_tickets are correctly used by /brief."""
    from meeting_helper.state import state as global_state
    from unittest.mock import AsyncMock

    session = FakeMCPSession()
    tracker = _tracker_with_session(session)
    global_state.tracker = tracker
    # Pre-populate sprint_tickets in agent-fetched dict shape.
    global_state.sprint_tickets = [{
        "id": "TKT-5", "title": "Build API", "status": "in_progress",
        "status_kind": "in_progress", "priority": "high",
        "body_md": "Build the REST API.", "workspace_id": "99",
        "workspace_name": "APIBoard", "board_id": "99", "board_name": "APIBoard",
        "sprint_name": "Sprint 5", "url": "https://example.com/TKT-5",
        "subtasks": [], "subtasks_summary": {}, "recent_comments": [],
        "recent_history": [], "linked_docs": [],
    }]
    global_state.sprint_tickets_loaded_at = time.time()

    fake_message = MagicMock()
    fake_message.content = [MagicMock(text=json.dumps({
        "script": "**Today**\n- I'm building TKT-5.",
        "card_ids": ["TKT-5"],
    }))]

    class FakeMessages:
        async def create(self, **kwargs):
            return fake_message

    class FakeAnthropic:
        def __init__(self, *a, **k):
            self.messages = FakeMessages()

    with patch("meeting_helper.server.routes.AsyncAnthropic", new=FakeAnthropic, create=True):
        client = await aiohttp_client(_make_app())
        resp = await client.post("/brief")

    assert resp.status == 200
    body = await resp.json()
    assert "TKT-5" in body["script"]
    # cards should contain the task from sprint_tickets
    assert len(body["cards"]) >= 1

    global_state.tracker = None
    global_state.sprint_tickets = []
    global_state.sprint_tickets_loaded_at = 0
