"""Config knobs for the MH-32 internal action items feature.

The plan calls for two booleans:

* ``action_items_extract_after_meeting`` (default False) — auto-run the LLM
  extractor when a meeting ends.
* ``action_items_inject_into_copilot`` (default True) — feed the action item
  list into the copilot system prompt context.

Both must round-trip through ``Config`` and flow through ``to_app_config()``
so route handlers reading ``request.app["config"]`` see consistent values.
"""

from pathlib import Path

from meeting_helper.config import Config


def test_action_items_defaults(tmp_path: Path):
    cfg = Config(tmp_path / "ws.json")
    assert cfg.action_items_extract_after_meeting is False
    assert cfg.action_items_inject_into_copilot is True


def test_action_items_setters_persist(tmp_path: Path):
    path = tmp_path / "ws.json"
    cfg = Config(path)
    cfg.action_items_extract_after_meeting = True
    cfg.action_items_inject_into_copilot = False
    cfg.save()

    reloaded = Config(path)
    assert reloaded.action_items_extract_after_meeting is True
    assert reloaded.action_items_inject_into_copilot is False


def test_action_items_in_app_config(tmp_path: Path):
    cfg = Config(tmp_path / "ws.json")
    snap = cfg.to_app_config()
    assert snap.action_items_extract_after_meeting is False
    assert snap.action_items_inject_into_copilot is True


def test_action_items_app_config_reflects_overrides(tmp_path: Path):
    cfg = Config(tmp_path / "ws.json")
    cfg.action_items_extract_after_meeting = True
    cfg.action_items_inject_into_copilot = False
    snap = cfg.to_app_config()
    assert snap.action_items_extract_after_meeting is True
    assert snap.action_items_inject_into_copilot is False
