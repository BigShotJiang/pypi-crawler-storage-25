"""TopicWorker engagement/manual gate — see spec 2026-05-20."""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from meeting_helper.buffer import SentenceBuffer
from meeting_helper.state import state
from meeting_helper.topic_worker import TopicWorker


@pytest.fixture(autouse=True)
def reset_gate_state():
    state.topic_auto_paused = False
    state.hot_moment_until = 0.0
    yield
    state.topic_auto_paused = False
    state.hot_moment_until = 0.0


def test_topic_auto_paused_defaults_false():
    # Fresh process default: AUTO (picker allowed to run).
    assert state.topic_auto_paused is False


def test_meeting_end_resets_topic_auto_paused_to_config_default():
    from meeting_helper.daemon import _broadcast_meeting_ended

    # Default "manual" -> meeting end leaves the picker paused for next meeting.
    state.topic_auto_paused = False
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        asyncio.run(_broadcast_meeting_ended(None, default_topic_mode="manual"))
    assert state.topic_auto_paused is True

    # Default "auto" -> meeting end clears it so the next meeting auto-picks.
    state.topic_auto_paused = True
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        asyncio.run(_broadcast_meeting_ended(None, default_topic_mode="auto"))
    assert state.topic_auto_paused is False


def _worker_with_one_sentence():
    """A worker whose buffer has one substantive sentence, with both picker
    legs replaced by AsyncMocks so _run never touches a real LLM."""
    state.topic_auto_paused = False
    state.hot_moment_until = 0.0
    state.pinned_topics = []
    self_buf = SentenceBuffer(role="self")
    state.self_buffer = self_buf
    state.other_buffer = None
    self_buf.append_final("Let us go through the remapper ticket this morning.")
    w = TopicWorker(config=MagicMock(), self_buffer=self_buf)
    w._pick_from_sprint_and_action_items = AsyncMock()
    w._pick_from_basket = AsyncMock()
    return w


def test_run_skips_when_manual():
    w = _worker_with_one_sentence()
    state.topic_auto_paused = True
    state.arm_hot_moment(window_sec=60)  # hot, but MANUAL wins
    asyncio.run(w._run())
    w._pick_from_sprint_and_action_items.assert_not_called()
    w._pick_from_basket.assert_not_called()


def test_run_skips_when_not_hot():
    w = _worker_with_one_sentence()
    state.topic_auto_paused = False
    state.hot_moment_until = 0.0  # cold
    asyncio.run(w._run())
    w._pick_from_sprint_and_action_items.assert_not_called()
    w._pick_from_basket.assert_not_called()


def test_run_proceeds_when_auto_and_hot():
    w = _worker_with_one_sentence()
    state.topic_auto_paused = False
    state.arm_hot_moment(window_sec=60)
    asyncio.run(w._run())
    w._pick_from_sprint_and_action_items.assert_awaited_once()
