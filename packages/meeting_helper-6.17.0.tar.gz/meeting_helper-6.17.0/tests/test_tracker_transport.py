import pytest
from meeting_helper.trackers.profile import AuthField, TransportTemplate
from meeting_helper.trackers.transport import expand_transport, redact_for_log


def test_stdio_expansion_with_secrets():
    tpl = TransportTemplate(
        type="stdio",
        command="npx",
        args=("@jira-mcp/server", "--host", "{base_url}"),
        env_template={"JIRA_EMAIL": "{email}", "JIRA_TOKEN": "{api_token}"},
    )
    auth_values = {"base_url": "https://acme.atlassian.net", "email": "x@y.com"}
    secrets = {"api_token": "secret-abc"}
    out = expand_transport(tpl, auth_values, secrets)
    assert out["type"] == "stdio"
    assert out["command"] == "npx"
    assert out["args"] == ["@jira-mcp/server", "--host", "https://acme.atlassian.net"]
    assert out["env"] == {"JIRA_EMAIL": "x@y.com", "JIRA_TOKEN": "secret-abc"}


def test_http_expansion():
    tpl = TransportTemplate(
        type="http",
        url_template="{base_url}/mcp",
        headers_template={"Authorization": "Bearer {api_token}"},
    )
    out = expand_transport(tpl, {"base_url": "https://x"}, {"api_token": "tok"})
    assert out["type"] == "http"
    assert out["url"] == "https://x/mcp"
    assert out["headers"] == {"Authorization": "Bearer tok"}


def test_missing_placeholder_raises():
    tpl = TransportTemplate(type="stdio", command="{not_provided}")
    with pytest.raises(KeyError) as exc:
        expand_transport(tpl, {}, {})
    assert "not_provided" in str(exc.value)


def test_redact_strips_secret_values():
    expanded = {
        "type": "stdio",
        "env": {"JIRA_TOKEN": "secret-abc", "JIRA_EMAIL": "x@y.com"},
        "args": [],
        "command": "npx",
    }
    redacted = redact_for_log(expanded, secret_field_keys=["api_token"], secret_values=["secret-abc"])
    assert redacted["env"]["JIRA_TOKEN"] == "***"
    assert redacted["env"]["JIRA_EMAIL"] == "x@y.com"
