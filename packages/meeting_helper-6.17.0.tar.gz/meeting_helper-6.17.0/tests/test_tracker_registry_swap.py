# tests/test_tracker_registry_swap.py
import asyncio
import pytest
from tests.helpers.fake_mcp import FakeMCPSession
from meeting_helper.trackers.profile import Workspace
from meeting_helper.trackers.registry import (
    TrackerRegistry, UnknownVendor, get_profile,
)
from meeting_helper.trackers.tracker import Tracker
from meeting_helper.trackers.vendors.local_todo import LocalTodoProfile


def _prebuilt_tracker(session) -> Tracker:
    t = Tracker(profile=LocalTodoProfile(), transport={"type": "stdio", "command": "x", "args": [], "env": {}})
    t._session = session
    return t


def test_get_profile_known():
    assert get_profile("local_todo") is LocalTodoProfile


def test_get_profile_unknown():
    with pytest.raises(UnknownVendor):
        get_profile("nope")


@pytest.mark.asyncio
async def test_registry_boot_sets_current():
    reg = TrackerRegistry()
    session = FakeMCPSession()
    session.set_response("list_boards", {}, [])
    await reg.set_for_test(tracker_id="t1", tracker=_prebuilt_tracker(session))
    assert reg.current is not None
    assert reg.active_id == "t1"


@pytest.mark.asyncio
async def test_swap_closes_old_and_installs_new():
    reg = TrackerRegistry()
    s1 = FakeMCPSession({("list_boards", ()): []})
    s2 = FakeMCPSession({("list_boards", ()): []})
    a = _prebuilt_tracker(s1)
    b = _prebuilt_tracker(s2)
    await reg.set_for_test(tracker_id="a", tracker=a)
    await reg.set_for_test(tracker_id="b", tracker=b)  # second set triggers swap
    assert reg.current is b
    assert reg.active_id == "b"
    # a should have been closed
    assert a._session is None


@pytest.mark.asyncio
async def test_swap_under_lock_serializes():
    """Two concurrent swaps must serialize (no torn state)."""
    reg = TrackerRegistry()
    a = _prebuilt_tracker(FakeMCPSession({("list_boards", ()): []}))
    b = _prebuilt_tracker(FakeMCPSession({("list_boards", ()): []}))
    c = _prebuilt_tracker(FakeMCPSession({("list_boards", ()): []}))
    await reg.set_for_test(tracker_id="a", tracker=a)
    await asyncio.gather(
        reg.set_for_test(tracker_id="b", tracker=b),
        reg.set_for_test(tracker_id="c", tracker=c),
    )
    assert reg.current in (b, c)
    assert reg.active_id in ("b", "c")
