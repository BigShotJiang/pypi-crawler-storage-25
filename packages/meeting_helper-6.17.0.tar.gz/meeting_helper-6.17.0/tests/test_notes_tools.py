"""Tests for the notes.* chat tools (MH-38 tasks 11, 12, 13)."""
from pathlib import Path
import pytest

from meeting_helper.chat.tools.notes import (
    build_notes_list, build_notes_get,
)
from meeting_helper.state import state as global_state


class _FakeCfg:
    """Minimal Config stand-in for the chat-tool tests.

    Mirrors the surface the chat tools touch: ``recordings_dir``,
    ``workspace_name``, KB list mutators, favorite list mutators, and
    ``save``. The KB / favorite lists are plain Python lists so tests
    can assert against them directly.
    """

    def __init__(self, recordings: Path, kb: list[str] | None = None, favs: list[str] | None = None):
        self.recordings_dir = recordings
        self.workspace_name = "test"
        self._kb: list[str] = list(kb or [])
        self._favs: list[str] = list(favs or [])
        self.saved = False

    @property
    def kb_artifacts(self) -> list[str]:
        return self._kb

    def is_kb(self, filename: str) -> bool:
        return filename in self._kb

    def add_kb(self, filename: str) -> None:
        if filename not in self._kb:
            self._kb.append(filename)

    def remove_kb(self, filename: str) -> None:
        if filename in self._kb:
            self._kb.remove(filename)

    def is_favorite(self, filename: str) -> bool:
        return filename in self._favs

    def add_favorite(self, filename: str) -> None:
        if filename not in self._favs:
            self._favs.append(filename)

    def remove_favorite(self, filename: str) -> None:
        if filename in self._favs:
            self._favs.remove(filename)

    def save(self) -> None:
        self.saved = True


@pytest.fixture
def workspace(tmp_path: Path, monkeypatch):
    recordings = tmp_path / "rec"
    recordings.mkdir()
    (recordings / "alpha.note.md").write_text("First note body")
    (recordings / "beta.note.md").write_text("Second note body")

    cfg = _FakeCfg(recordings, kb=["beta.note.md"])
    monkeypatch.setattr("meeting_helper.config.get_config", lambda: cfg)
    return cfg


@pytest.fixture(autouse=True)
def _clean_state():
    global_state.clear_pins()
    yield
    global_state.clear_pins()


async def test_notes_list_returns_all_notes(workspace):
    tool = build_notes_list()
    res = await tool.run({}, ctx=None)
    assert res["status"] == "ok"
    titles = [n["title"] for n in res["result"]["notes"]]
    assert set(titles) == {"alpha", "beta"}


async def test_notes_list_marks_kb_and_url(workspace):
    tool = build_notes_list()
    res = await tool.run({}, ctx=None)
    by_id = {n["id"]: n for n in res["result"]["notes"]}
    assert by_id["beta.note.md"]["in_kb"] is True
    assert by_id["alpha.note.md"]["in_kb"] is False
    assert by_id["alpha.note.md"]["url"] == "/notes/?id=alpha.note.md"


async def test_notes_list_reflects_pinned(workspace):
    from meeting_helper.state import PinnedItem
    global_state.pin_topic(PinnedItem(kind="note", id="alpha.note.md", title="alpha"))
    tool = build_notes_list()
    res = await tool.run({}, ctx=None)
    by_id = {n["id"]: n for n in res["result"]["notes"]}
    assert by_id["alpha.note.md"]["pinned"] is True
    assert by_id["beta.note.md"]["pinned"] is False


async def test_notes_get_returns_body(workspace):
    tool = build_notes_get()
    res = await tool.run({"id": "alpha.note.md"}, ctx=None)
    assert res["status"] == "ok"
    assert "First note body" in res["result"]["body"]


async def test_notes_get_rejects_traversal(workspace):
    tool = build_notes_get()
    res = await tool.run({"id": "../etc/passwd"}, ctx=None)
    assert res["status"] == "error"


async def test_notes_get_missing_returns_error(workspace):
    tool = build_notes_get()
    res = await tool.run({"id": "ghost.note.md"}, ctx=None)
    assert res["status"] == "error"


async def test_notes_create_writes_file(workspace):
    from meeting_helper.chat.tools.notes import build_notes_create

    tool = build_notes_create()
    res = await tool.run({"title": "Gamma plan", "body": "Body of gamma"}, ctx=None)
    assert res["status"] == "ok"
    new_path = workspace.recordings_dir / "gamma-plan.note.md"
    assert new_path.is_file()
    assert new_path.read_text() == "Body of gamma"


async def test_notes_create_in_kb_adds_to_kb(workspace):
    from meeting_helper.chat.tools.notes import build_notes_create

    tool = build_notes_create()
    res = await tool.run(
        {"title": "Delta", "body": "D", "in_kb": True}, ctx=None,
    )
    assert res["status"] == "ok"
    assert "delta.note.md" in workspace.kb_artifacts


async def test_notes_create_collision_suffix(workspace):
    from meeting_helper.chat.tools.notes import build_notes_create

    tool = build_notes_create()
    await tool.run({"title": "Conflict", "body": "1"}, ctx=None)
    res = await tool.run({"title": "Conflict", "body": "2"}, ctx=None)
    assert res["status"] == "ok"
    assert (workspace.recordings_dir / "conflict-2.note.md").is_file()


async def test_notes_update_replaces_body(workspace):
    from meeting_helper.chat.tools.notes import build_notes_update

    tool = build_notes_update()
    res = await tool.run({"id": "alpha.note.md", "body": "Updated body"}, ctx=None)
    assert res["status"] == "ok"
    assert (workspace.recordings_dir / "alpha.note.md").read_text() == "Updated body"


async def test_notes_update_rename_migrates_kb(workspace):
    from meeting_helper.chat.tools.notes import build_notes_update

    tool = build_notes_update()
    res = await tool.run({"id": "beta.note.md", "title": "Renamed Beta"}, ctx=None)
    assert res["status"] == "ok"
    assert res["result"]["id"] == "renamed-beta.note.md"
    assert (workspace.recordings_dir / "renamed-beta.note.md").is_file()
    assert not (workspace.recordings_dir / "beta.note.md").exists()
    assert "renamed-beta.note.md" in workspace.kb_artifacts
    assert "beta.note.md" not in workspace.kb_artifacts


async def test_notes_delete_removes(workspace):
    from meeting_helper.chat.tools.notes import build_notes_delete

    tool = build_notes_delete()
    res = await tool.run({"id": "beta.note.md"}, ctx=None)
    assert res["status"] == "ok"
    assert not (workspace.recordings_dir / "beta.note.md").exists()
    assert "beta.note.md" not in workspace.kb_artifacts


async def test_notes_set_kb_toggles(workspace):
    from meeting_helper.chat.tools.notes import build_notes_set_kb

    tool = build_notes_set_kb()
    res = await tool.run({"id": "alpha.note.md", "value": True}, ctx=None)
    assert res["status"] == "ok"
    assert "alpha.note.md" in workspace.kb_artifacts

    res = await tool.run({"id": "alpha.note.md", "value": False}, ctx=None)
    assert res["status"] == "ok"
    assert "alpha.note.md" not in workspace.kb_artifacts


async def test_notes_set_kb_missing_file_errors(workspace):
    from meeting_helper.chat.tools.notes import build_notes_set_kb

    tool = build_notes_set_kb()
    res = await tool.run({"id": "ghost.note.md", "value": True}, ctx=None)
    assert res["status"] == "error"


async def test_mutation_flags():
    from meeting_helper.chat.tools.notes import (
        build_notes_create, build_notes_update, build_notes_delete,
        build_notes_set_kb,
    )

    assert build_notes_create().is_mutation is True
    assert build_notes_update().is_mutation is True
    assert build_notes_delete().is_mutation is True
    assert build_notes_set_kb().is_mutation is True
    # list / get are read-only
    assert build_notes_list().is_mutation is False
    assert build_notes_get().is_mutation is False
