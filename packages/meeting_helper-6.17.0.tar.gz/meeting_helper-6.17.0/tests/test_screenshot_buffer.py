import pytest

from meeting_helper.state import AppState
from meeting_helper.state import state as global_state
from meeting_helper.ai.client import _attach_images_to_turn
from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig


@pytest.fixture
async def client(aiohttp_client):
    return await aiohttp_client(create_app(AppConfig()))


async def test_screenshot_clear_endpoint(client):
    global_state.clear_screenshots()
    global_state.add_screenshot(
        path="/tmp/nonexistent_mh_test.jpg", thumb="data:image/jpeg;base64,x"
    )
    assert len(global_state.screenshot_buffer) == 1
    resp = await client.post("/screenshot/clear", json={})
    assert resp.status == 200
    assert global_state.screenshot_buffer == []


def test_buffer_append_cap_and_clear():
    s = AppState()
    s.clear_screenshots()
    for i in range(10):
        s.add_screenshot(path=f"/tmp/{i}.jpg", thumb="data:image/jpeg;base64,x")
    # capped at 8, oldest dropped, order preserved
    assert len(s.screenshot_buffer) == 8
    assert s.screenshot_buffer[0]["path"] == "/tmp/2.jpg"
    assert s.screenshot_buffer[-1]["path"] == "/tmp/9.jpg"
    drained = s.drain_screenshots()
    assert len(drained) == 8
    assert s.screenshot_buffer == []


def test_attach_images_builds_block_list():
    turn = {"role": "user", "content": "hello"}
    out = _attach_images_to_turn(turn, ["AAA", "BBB"])
    assert isinstance(out["content"], list)
    assert out["content"][0] == {"type": "text", "text": "hello"}
    assert out["content"][1]["type"] == "image"
    assert out["content"][1]["source"]["data"] == "AAA"
    assert len(out["content"]) == 3  # text + 2 images


def test_attach_images_noop_when_empty():
    turn = {"role": "user", "content": "hello"}
    assert _attach_images_to_turn(turn, []) is turn


def test_drain_and_clear_reset_consumed_flag():
    s = AppState()
    s.clear_screenshots()
    s.add_screenshot(path="/tmp/x.jpg", thumb="")
    s.screenshots_consumed = True
    s.drain_screenshots()
    assert s.screenshots_consumed is False
    s.add_screenshot(path="/tmp/y.jpg", thumb="")
    s.screenshots_consumed = True
    s.clear_screenshots()
    assert s.screenshots_consumed is False


def test_new_capture_replaces_consumed_sticky_set(monkeypatch, tmp_path):
    """Once a screenshot set has ridden along on a query, the next Esc+Down
    capture starts a fresh set: old shots and their temp files are purged."""
    from meeting_helper import hotkeys
    from meeting_helper import screenshot as ss
    from meeting_helper.state import state as gs

    old = tmp_path / "old.jpg"
    old.write_bytes(b"old")
    gs.clear_screenshots()
    gs.add_screenshot(path=str(old), thumb="")
    gs.screenshots_consumed = True
    gs.pending_screenshot_captures = 0

    new = tmp_path / "new.jpg"
    new.write_bytes(b"new")
    monkeypatch.setattr(hotkeys, "_is_meeting_active", lambda: True)
    monkeypatch.setattr(ss, "capture_frontmost_window", lambda: str(new))
    monkeypatch.setattr(ss, "make_thumbnail_data_url", lambda p: "")
    monkeypatch.setattr(hotkeys, "_beep", lambda *a, **k: None)
    monkeypatch.setattr(hotkeys, "_schedule", lambda coro: coro.close())

    hotkeys._do_capture()

    assert not old.exists()  # old sticky shot purged
    assert [s["path"] for s in gs.screenshot_buffer] == [str(new)]
    assert gs.screenshots_consumed is False
    gs.clear_screenshots()


def test_capture_before_query_accumulates(monkeypatch, tmp_path):
    """Multiple captures BEFORE any query accumulate (not consumed yet)."""
    from meeting_helper import hotkeys
    from meeting_helper import screenshot as ss
    from meeting_helper.state import state as gs

    gs.clear_screenshots()
    gs.pending_screenshot_captures = 0
    monkeypatch.setattr(hotkeys, "_is_meeting_active", lambda: True)
    monkeypatch.setattr(ss, "make_thumbnail_data_url", lambda p: "")
    monkeypatch.setattr(hotkeys, "_beep", lambda *a, **k: None)
    monkeypatch.setattr(hotkeys, "_schedule", lambda coro: coro.close())

    a = tmp_path / "a.jpg"; a.write_bytes(b"a")
    b = tmp_path / "b.jpg"; b.write_bytes(b"b")
    monkeypatch.setattr(ss, "capture_frontmost_window", lambda: str(a))
    hotkeys._do_capture()
    monkeypatch.setattr(ss, "capture_frontmost_window", lambda: str(b))
    hotkeys._do_capture()

    assert [s["path"] for s in gs.screenshot_buffer] == [str(a), str(b)]
    gs.clear_screenshots()
