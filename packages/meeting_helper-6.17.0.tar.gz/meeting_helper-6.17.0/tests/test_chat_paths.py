from pathlib import Path
from meeting_helper.chat import paths as chat_paths


def test_chat_dir_uses_active_workspace(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "Grepr")
    d = chat_paths.chat_dir()
    assert d == tmp_path / "chat" / "Grepr"
    assert d.exists()
    assert (d / "threads").exists()


def test_chat_dir_falls_back_to_default(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: None)
    d = chat_paths.chat_dir()
    assert d == tmp_path / "chat" / "default"


def test_active_workspace_name_returns_none_on_load_state_failure(monkeypatch):
    """Daemon state unloadable → fall back to None, never propagate."""
    import meeting_helper.config as cfg_mod
    def _boom():
        raise RuntimeError("state file corrupted")
    monkeypatch.setattr(cfg_mod, "load_state", _boom)
    from meeting_helper.chat import paths as chat_paths
    assert chat_paths._active_workspace_name() is None
