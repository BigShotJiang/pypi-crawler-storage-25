"""End-to-end check on the user-flow that broke in production:

  Q1: 'tell me about the Phase 1 Rebased onto main...'
  Q2: 'give me last updates of the Review Skip pipeline'
  Q3: 'what last update on this?'

After Q2 picks SCRUM-8, Q3's follow-up must keep SCRUM-8 even if the
auto-worker (TopicWorker) has drifted `current_topic` to SCRUM-3 in between.
The picker must read `state.last_user_query_topic` as the follow-up anchor,
NOT `state.current_topic`.
"""

from unittest.mock import AsyncMock, patch

import pytest

from meeting_helper.ai import client as c
from meeting_helper.config import AppConfig
from meeting_helper.state import AppState


_SPRINT = [
    {"id": "SCRUM-3", "title": "Phase 1 — ClickHouse query path"},
    {"id": "SCRUM-7", "title": "WindowBasedLogarithmicSampleManager overflow"},
    {"id": "SCRUM-8", "title": "Review Skip backlog on restart"},
]


def _fresh_state() -> AppState:
    s = AppState()
    s.sprint_tickets = list(_SPRINT)
    s.sprint_tickets_loaded_at = 1e18  # block refresh in pre_flight
    s.tracker = object()  # truthy so pre_flight doesn't bail
    return s


def _previous_topic_block(captured_msg: str) -> str:
    """Slice out just the `## Previous topic` block of the picker prompt."""
    assert "## Previous topic" in captured_msg
    return captured_msg.split("## Previous topic", 1)[1].split("##", 1)[0]


@pytest.mark.asyncio
async def test_followup_anchors_on_last_user_query_not_current_topic(monkeypatch):
    """The picker for Q3 must receive Q2's pick as the previous_topic,
    even when the auto-worker has overwritten state.current_topic in
    between."""
    state = _fresh_state()
    config = AppConfig(anthropic_api_key="x")

    # Silence broadcasts.
    import meeting_helper.server.websocket as ws
    monkeypatch.setattr(ws, "broadcast", AsyncMock())

    calls: list[dict] = []
    # Each LLM call returns a scripted ticket_id, and we record the prompt.
    script = iter([
        {"ticket_id": "SCRUM-7", "topic": "Window overflow"},          # Q1
        {"ticket_id": "SCRUM-8", "topic": "Review Skip backlog"},      # Q2
        {"ticket_id": "SCRUM-8", "topic": "Review Skip backlog"},      # Q3 (good)
    ])

    async def _fake_call(cfg, sys_prompt, user_msg, *, kind="topic-pick"):
        result = next(script)
        calls.append({"user_msg": user_msg, "result": result})
        import json
        return json.dumps(result)

    monkeypatch.setattr(c, "_call_ai_for_tasks", _fake_call)

    # ---- Q1 ----
    await c._pre_flight_topic_refresh(state, config, question="tell me about phase 1")
    assert state.last_user_query_topic["ticket_ids"] == ["SCRUM-7"]

    # ---- Q2 ----
    await c._pre_flight_topic_refresh(state, config, question="give me last updates of the Review Skip pipeline")
    assert state.last_user_query_topic["ticket_ids"] == ["SCRUM-8"]
    assert state.current_topic["ticket_ids"] == ["SCRUM-8"]

    # ---- Auto-worker drift between Q2 and Q3 ----
    # Simulate TopicWorker picking SCRUM-3 from transcript drift. This MUST
    # update current_topic (banner) but MUST NOT touch last_user_query_topic.
    state.current_topic = {
        "topic": "Phase 1 — ClickHouse query path",
        "ticket_ids": ["SCRUM-3"],
        "search_query": "ClickHouse",
        "last_user_statement": "",
    }
    state.current_topic_cards = [{"id": "SCRUM-3", "title": "Phase 1 — ClickHouse query path"}]

    # ---- Q3 ----
    await c._pre_flight_topic_refresh(state, config, question="what last update on this?")

    # The picker for Q3 must have seen SCRUM-8 (Q2's pick), NOT SCRUM-3
    # (the drifted banner).
    q3_prev_block = _previous_topic_block(calls[2]["user_msg"])
    assert "SCRUM-8" in q3_prev_block, (
        "Q3's picker received the wrong previous_topic. "
        f"Got: {q3_prev_block!r}"
    )
    assert "SCRUM-3" not in q3_prev_block, (
        "Q3's picker leaked the auto-worker drift into previous_topic. "
        f"Got: {q3_prev_block!r}"
    )


@pytest.mark.asyncio
async def test_topic_worker_path_does_NOT_feed_current_topic_back_as_previous(monkeypatch):
    """The TopicWorker path (question='') must NOT pass any previous_topic
    to the picker prompt — passing one creates a self-reinforcing feedback
    loop where a wrong first auto-pick locks itself in: wrong pick →
    `state.current_topic` becomes wrong → next tick sees wrong-pick as
    'previous' → Haiku stays on it even when the transcript clearly shifts.

    Step 3 of the picker prompt now explicitly tells the LLM to ignore
    `## Previous topic` for auto-picks, and the code-side guard here makes
    that doubly safe by emitting `(none — first pick)` for the auto path."""
    state = _fresh_state()
    state.last_user_query_topic = {"topic": "Old user query", "ticket_ids": ["SCRUM-7"]}
    state.current_topic = {"topic": "Auto-worker drift", "ticket_ids": ["SCRUM-3"]}

    state.self_buffer = type("B", (), {})()
    state.other_buffer = type("B", (), {})()

    captured: dict = {}

    async def _fake_call(cfg, sys_prompt, user_msg, *, kind="topic-pick"):
        captured["user_msg"] = user_msg
        return '{"ticket_id": "SCRUM-3", "topic": "x"}'

    monkeypatch.setattr(c, "_call_ai_for_tasks", _fake_call)
    monkeypatch.setattr(
        c, "_collect_timestamped_sentences",
        lambda state, n_per_buffer=8: [(0.0, "other", "talking about something")],
    )

    # Auto-worker path: question="", no explicit previous_topic kwarg.
    await c.pick_topic_ticket(state, AppConfig(anthropic_api_key="x"), question="")

    prev_block = _previous_topic_block(captured["user_msg"])
    # Auto path must show (none — first pick) — neither current_topic nor
    # last_user_query_topic should leak into the previous-topic anchor.
    assert "(none — first pick)" in prev_block, (
        f"Auto-pick path must emit no prior anchor; got: {prev_block!r}"
    )
    assert "SCRUM-3" not in prev_block
    assert "SCRUM-7" not in prev_block
