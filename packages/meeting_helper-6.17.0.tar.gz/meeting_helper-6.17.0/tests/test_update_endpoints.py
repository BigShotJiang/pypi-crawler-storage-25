"""Tests for the user-triggered update endpoints (`/update/check` + `/update/now`)."""

from __future__ import annotations

import json

import pytest
from aiohttp.test_utils import make_mocked_request

from meeting_helper.server.routes import update_check_handler, update_now_handler


@pytest.mark.asyncio
async def test_check_reports_update_available(monkeypatch):
    """When PyPI is newer than the running version, the endpoint flags it."""
    import meeting_helper
    monkeypatch.setattr(meeting_helper, "__version__", "1.0.0")
    from meeting_helper import auto_updater
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: "1.0.1")
    monkeypatch.setattr(auto_updater, "is_editable_install", lambda: (False, None))

    resp = await update_check_handler(make_mocked_request("POST", "/update/check"))
    data = json.loads(resp.text)
    assert data["current_version"] == "1.0.0"
    assert data["latest_version"] == "1.0.1"
    assert data["update_available"] is True
    assert data["editable"] is False


@pytest.mark.asyncio
async def test_check_handles_pypi_offline(monkeypatch):
    from meeting_helper import auto_updater
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: None)
    monkeypatch.setattr(auto_updater, "is_editable_install", lambda: (False, None))

    resp = await update_check_handler(make_mocked_request("POST", "/update/check"))
    data = json.loads(resp.text)
    assert data["latest_version"] is None
    assert data["update_available"] is False


@pytest.mark.asyncio
async def test_now_refuses_editable_install(monkeypatch):
    """Editable installs can't be upgraded by pipx — surface that clearly."""
    from meeting_helper import auto_updater
    monkeypatch.setattr(auto_updater, "is_editable_install", lambda: (True, "/tmp/dev"))

    resp = await update_now_handler(make_mocked_request("POST", "/update/now"))
    assert resp.status == 409
    data = json.loads(resp.text)
    assert data["ok"] is False
    assert data["reason"] == "editable_install"
    assert "/tmp/dev" in data["message"]


@pytest.mark.asyncio
async def test_now_reports_already_latest(monkeypatch):
    import meeting_helper
    monkeypatch.setattr(meeting_helper, "__version__", "2.0.0")
    from meeting_helper import auto_updater
    monkeypatch.setattr(auto_updater, "is_editable_install", lambda: (False, None))
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: "2.0.0")

    resp = await update_now_handler(make_mocked_request("POST", "/update/now"))
    assert resp.status == 200
    data = json.loads(resp.text)
    assert data["ok"] is True
    assert data["reason"] == "already_latest"


@pytest.mark.asyncio
async def test_now_runs_pipx_upgrade_without_restart(monkeypatch):
    """The happy path: PyPI is newer → run pipx upgrade on a worker, but
    do NOT kick off the daemon-respawn dance. The sidebar's existing
    `restart_needed` flow handles the actual restart cleanly."""
    import meeting_helper
    monkeypatch.setattr(meeting_helper, "__version__", "1.0.0")
    from meeting_helper import auto_updater
    monkeypatch.setattr(auto_updater, "is_editable_install", lambda: (False, None))
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: "1.0.1")

    upgrade_calls: list[tuple[str, str]] = []
    bundle_calls: list[str] = []
    restart_calls: list[str] = []

    def _stub_upgrade_to_latest(latest: str, current: str) -> str | None:
        upgrade_calls.append((latest, current))
        return latest

    def _stub_refresh_bundle(new_version: str) -> None:
        bundle_calls.append(new_version)

    def _stub_trigger_restart(new_version: str) -> None:
        restart_calls.append(new_version)

    monkeypatch.setattr(auto_updater, "upgrade_to_latest", _stub_upgrade_to_latest)
    monkeypatch.setattr(auto_updater, "_refresh_or_install_app_bundle", _stub_refresh_bundle)
    monkeypatch.setattr(auto_updater, "_trigger_post_update_restart", _stub_trigger_restart)

    resp = await update_now_handler(make_mocked_request("POST", "/update/now"))
    assert resp.status == 202
    data = json.loads(resp.text)
    assert data["ok"] is True
    assert data["reason"] == "started"
    assert data["latest_version"] == "1.0.1"

    import asyncio
    for _ in range(20):
        if upgrade_calls:
            break
        await asyncio.sleep(0.05)
    assert upgrade_calls == [("1.0.1", "1.0.0")]
    assert bundle_calls == ["1.0.1"]
    # Critically: the respawn dance MUST NOT fire. The sidebar takes over.
    assert restart_calls == []


@pytest.mark.asyncio
async def test_now_reports_pypi_offline(monkeypatch):
    import meeting_helper
    monkeypatch.setattr(meeting_helper, "__version__", "1.0.0")
    from meeting_helper import auto_updater
    monkeypatch.setattr(auto_updater, "is_editable_install", lambda: (False, None))
    monkeypatch.setattr(auto_updater, "fetch_latest_version", lambda: None)

    resp = await update_now_handler(make_mocked_request("POST", "/update/now"))
    assert resp.status == 503
    data = json.loads(resp.text)
    assert data["ok"] is False
    assert data["reason"] == "pypi_unreachable"
