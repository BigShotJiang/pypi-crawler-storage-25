# tests/test_vendor_notion.py
import pytest
from meeting_helper.trackers.vendors.notion import NotionProfile


def test_profile_class_attributes():
    p = NotionProfile
    assert p.id == "notion"
    assert p.label == "Notion"
    assert p.transport.type == "http"
    assert p.auth_mode == "mcp_oauth"
    assert p.supports == frozenset()
    assert p.agent_terminology
    assert p.agent_hints
