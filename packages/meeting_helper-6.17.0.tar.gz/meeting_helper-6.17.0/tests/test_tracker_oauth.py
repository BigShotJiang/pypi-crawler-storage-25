"""Unit tests for the OAuth foundation: KeychainTokenStorage + LocalCallbackServer."""
import asyncio
import json
from unittest.mock import MagicMock
import pytest

from mcp.shared.auth import OAuthToken, OAuthClientInformationFull
from meeting_helper.trackers import oauth as oauth_mod
from meeting_helper.trackers.oauth import KeychainTokenStorage, LocalCallbackServer


@pytest.fixture
def fake_keyring(monkeypatch):
    store: dict[tuple[str, str], str] = {}
    kr = MagicMock()
    kr.get_password = lambda svc, acct: store.get((svc, acct))
    kr.set_password = lambda svc, acct, val: store.__setitem__((svc, acct), val)
    kr.delete_password = lambda svc, acct: store.pop((svc, acct), None)
    monkeypatch.setattr(oauth_mod, "keyring", kr)
    return store


@pytest.mark.asyncio
async def test_storage_roundtrip_tokens(fake_keyring):
    s = KeychainTokenStorage("ws", "tid")
    assert await s.get_tokens() is None
    tok = OAuthToken(access_token="abc", token_type="Bearer", expires_in=3600, refresh_token="r")
    await s.set_tokens(tok)
    got = await s.get_tokens()
    assert got.access_token == "abc"
    assert got.refresh_token == "r"


@pytest.mark.asyncio
async def test_storage_roundtrip_client_info(fake_keyring):
    s = KeychainTokenStorage("ws", "tid")
    info = OAuthClientInformationFull(
        client_id="cid",
        client_secret="csecret",
        redirect_uris=["http://127.0.0.1:9999/callback"],
    )
    await s.set_client_info(info)
    got = await s.get_client_info()
    assert got.client_id == "cid"


def test_storage_purge_removes_both(fake_keyring):
    s = KeychainTokenStorage("ws", "tid")
    fake_keyring[("meeting-helper", "ws.tid.oauth_token")] = "{}"
    fake_keyring[("meeting-helper", "ws.tid.oauth_client_info")] = "{}"
    s.purge()
    assert ("meeting-helper", "ws.tid.oauth_token") not in fake_keyring
    assert ("meeting-helper", "ws.tid.oauth_client_info") not in fake_keyring


@pytest.mark.asyncio
async def test_callback_server_receives_code():
    srv = LocalCallbackServer()
    await srv.start()
    try:
        # simulate the browser hitting the callback
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(srv.redirect_url + "?code=auth123&state=xyz") as r:
                assert r.status == 200
        code, state = await srv.wait_for_code(timeout=1.0)
        assert code == "auth123"
        assert state == "xyz"
    finally:
        await srv.stop()


@pytest.mark.asyncio
async def test_callback_server_propagates_error():
    srv = LocalCallbackServer()
    await srv.start()
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(srv.redirect_url + "?error=access_denied") as r:
                assert r.status == 200
        with pytest.raises(RuntimeError, match="access_denied"):
            await srv.wait_for_code(timeout=1.0)
    finally:
        await srv.stop()
