"""Agent context block - the `Pinned topics` markdown section.

`_format_pinned_topics_markdown` is the helper both query handlers call to
prepend a basket summary to the system prompt. Notes inline their full
body; action items render title + description gated on
`action_items_inject_into_copilot`; tickets reuse the cached sprint card
when available.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from meeting_helper.ai.client import _format_pinned_topics_markdown
from meeting_helper.state import state as global_state, PinnedItem


@pytest.fixture(autouse=True)
def _clean_pins():
    global_state.clear_pins()
    yield
    global_state.clear_pins()


def test_renders_ticket_note_action_item(tmp_path: Path, monkeypatch):
    note = tmp_path / "design-doc.note.md"
    note.write_text("Body of the design doc")

    monkeypatch.setattr(
        "meeting_helper.ai.client._lookup_action_item_for_pin",
        lambda _cfg, ai_id: {
            "id": ai_id, "title": "Follow up", "description": "Reach out",
        },
    )

    global_state.pin_topic(
        PinnedItem(kind="ticket", id="MH-1", title="A", board_id="bd"),
    )
    global_state.pin_topic(
        PinnedItem(kind="note", id="design-doc.note.md", title="Design"),
    )
    global_state.pin_topic(
        PinnedItem(kind="action_item", id="ai_1", title="Follow up"),
    )

    cfg = type(
        "Cfg", (),
        {
            "recordings_dir": str(tmp_path),
            "workspace_name": "test",
            "action_items_inject_into_copilot": True,
        },
    )()
    md = _format_pinned_topics_markdown(cfg)

    assert "Pinned topics" in md
    assert "MH-1" in md and "A" in md
    assert "Body of the design doc" in md
    assert "Follow up" in md and "Reach out" in md


def test_empty_basket_returns_empty_string():
    cfg = type("Cfg", (), {})()
    assert _format_pinned_topics_markdown(cfg) == ""
