"""AppConfig snapshot must carry copilot_tracker_id so the daemon's in-memory
state matches the on-disk Config after to_app_config()."""
from meeting_helper.config import AppConfig, Config
from pathlib import Path
import json


def test_appconfig_carries_copilot_tracker_id(tmp_path):
    f = tmp_path / "ws.json"
    f.write_text(json.dumps({
        "trackers": [{"id": "x", "vendor": "local_todo", "label": "X",
                       "transport": {}, "auth_values": {}, "secret_keys": []}],
        "copilot_tracker_id": "x",
    }))
    cfg = Config(f)
    snap = cfg.to_app_config()
    assert snap.copilot_tracker_id == "x"
    assert snap.active_tracker_id == "x"
