"""Session stop empties the pinned-topic basket.

`stop_session` is the lowest-level hook the daemon calls when a meeting
ends. It clears `state.pinned_topics` and broadcasts an empty basket so
the GUI's topic strip resets.
"""

from __future__ import annotations

import pytest

from meeting_helper.state import state as global_state, PinnedItem


@pytest.fixture(autouse=True)
def _clean_pins():
    global_state.clear_pins()
    yield
    global_state.clear_pins()


@pytest.mark.asyncio
async def test_session_stop_clears_pins(monkeypatch):
    global_state.pin_topic(
        PinnedItem(kind="ticket", id="MH-1", title="A"),
    )
    assert global_state.pinned_topics

    sent: list[dict] = []

    async def _fake_broadcast(payload):
        sent.append(payload)

    monkeypatch.setattr(
        "meeting_helper.server.websocket.broadcast",
        _fake_broadcast,
        raising=False,
    )

    from meeting_helper.session import stop_session
    await stop_session()

    assert global_state.pinned_topics == []
    assert any(
        p.get("type") == "topic" and p.get("pinned") == []
        for p in sent
    )
