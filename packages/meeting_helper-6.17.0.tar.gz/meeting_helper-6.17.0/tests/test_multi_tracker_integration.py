"""End-to-end: 3 trackers in one workspace, chat sees them namespaced,
disabling chat removes one from the registry, removing the copilot
auto-promotes the next chat-enabled one."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from aiohttp.test_utils import TestClient, TestServer
from types import SimpleNamespace

from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig


@pytest.mark.asyncio
async def test_three_trackers_chat_dispatch_to_correct_session(monkeypatch):
    monkeypatch.setattr("meeting_helper.trackers.secrets.write_secrets",
                        lambda ws, tid, values: None)
    monkeypatch.setattr("meeting_helper.trackers.secrets.read_secrets",
                        lambda ws, tid, keys: {})

    # Build app with 3 pre-existing trackers (skip OAuth) and a fake registry
    # so we can assert on dispatch.
    cfg = AppConfig(
        trackers=[
            {"id": "lt", "vendor": "local_todo", "label": "Local",
             "auth_values": {"url": "http://l"}, "secret_keys": [],
             "chat_enabled": True},
            {"id": "nw", "vendor": "notion", "label": "Notion Work",
             "auth_values": {"url": "http://nw"}, "secret_keys": [],
             "chat_enabled": True},
            {"id": "np", "vendor": "notion", "label": "Notion Personal",
             "auth_values": {"url": "http://np"}, "secret_keys": [],
             "chat_enabled": True},
        ],
        copilot_tracker_id="lt",
        active_tracker_id="lt",
        workspace_name="W",
    )

    # Fake registry + per-tracker sessions.
    fakes = {tid: _fake_tracker_with_tool(["search"]) for tid in ("lt", "nw", "np")}

    class FakeReg:
        def chat_enabled_ids(self, c):
            return [t["id"] for t in c.trackers if t.get("chat_enabled", True)]
        async def ensure_session(self, entry, workspace_name="", **kwargs):
            return fakes[entry["id"]]
        async def shutdown(self, tid=None): pass

    from meeting_helper.chat.tools.mcp_passthrough import build_mcp_passthrough_tools_multi

    tools = await build_mcp_passthrough_tools_multi(FakeReg(), cfg, workspace_name="W")
    names = sorted(t.name for t in tools)
    assert names == ["local__search", "notion-personal__search", "notion-work__search"]

    # Dispatch the Notion Personal tool — only the np tracker is called.
    by_name = {t.name: t for t in tools}
    await by_name["notion-personal__search"].run(
        {"q": "foo"}, {"trackers": FakeReg(), "config": cfg, "workspace_name": "W"},
    )
    fakes["np"].call_tool.assert_awaited_once_with("search", {"q": "foo"})
    fakes["lt"].call_tool.assert_not_called()
    fakes["nw"].call_tool.assert_not_called()


def _fake_tracker_with_tool(tool_names):
    sess = MagicMock()
    sess.list_tools = AsyncMock(return_value=SimpleNamespace(
        tools=[SimpleNamespace(name=n, description=f"d-{n}",
                                 inputSchema={"type": "object"}) for n in tool_names]))
    t = MagicMock()
    t._ensure_started = AsyncMock()
    t._session = sess
    t.call_tool = AsyncMock(return_value={"ok": True})
    return t
