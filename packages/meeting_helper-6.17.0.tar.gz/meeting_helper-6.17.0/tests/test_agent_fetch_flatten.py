"""agent_fetch must flatten each parent's subtasks into top-level items.

Without this, the Topics card / topic picker / Brief backfill see only
parents and silently drop any reference to a subtask. The user's report:
- Real Jira board: MH-3, MH-4, MH-5, MH-6, MH-14 + 2 subtasks (MH-12, MH-13)
- agent_fetch returned 4 parents only — UI showed 4 tickets
- Brief LLM still mentioned MH-13 (from the nested subtasks field) → backfill
  failed with "card_id MH-13 not in agent-fetched items; skipping"
"""

import json
import pytest

from meeting_helper.ai.agent_fetch import _parse_items, _flatten_subtasks


def test_flatten_promotes_subtasks_to_top_level():
    items = [
        {
            "id": "MH-4", "title": "AI Copilot Improvement",
            "status": "In Progress", "status_kind": "in_progress",
            "workspace_id": "MH", "workspace_name": "Meeting Helper",
            "sprint_name": "Sprint 1",
            "subtasks": [
                {"id": "MH-13", "title": "Right Panel seems on top",
                 "status": "In Progress", "status_kind": "in_progress"},
            ],
        },
        {
            "id": "MH-3", "title": "AI Chat Improvements",
            "status": "To Do", "status_kind": "todo",
            "workspace_id": "MH", "workspace_name": "Meeting Helper",
            "sprint_name": "Sprint 1",
            "subtasks": [
                {"id": "MH-12", "title": "Show duration",
                 "status": "To Do", "status_kind": "todo"},
            ],
        },
        {
            "id": "MH-6", "title": "Make local-todo mcp a vendor",
            "status": "In Progress", "status_kind": "in_progress",
            "subtasks": [],
        },
    ]
    out = _flatten_subtasks(items)
    ids = [item["id"] for item in out]
    assert ids == ["MH-4", "MH-13", "MH-3", "MH-12", "MH-6"]


def test_flatten_inherits_workspace_and_sprint_from_parent():
    items = [
        {
            "id": "MH-3", "title": "Parent",
            "workspace_id": "MH-board", "workspace_name": "MH",
            "sprint_name": "Sprint 1",
            "subtasks": [
                # subtask record from a nested Jira JQL response has no
                # workspace/sprint metadata of its own
                {"id": "MH-12", "title": "Child", "status": "To Do",
                 "status_kind": "todo"},
            ],
        },
    ]
    out = _flatten_subtasks(items)
    child = next(i for i in out if i["id"] == "MH-12")
    assert child["workspace_id"] == "MH-board"
    assert child["workspace_name"] == "MH"
    assert child["sprint_name"] == "Sprint 1"
    assert child["parent_id"] == "MH-3"
    assert child["parent_title"] == "Parent"


def test_flatten_is_idempotent_on_already_flat_items():
    items = [
        {"id": "A-1", "title": "no subs", "subtasks": []},
        {"id": "A-2", "title": "no subs"},  # missing key
    ]
    out = _flatten_subtasks(items)
    assert [i["id"] for i in out] == ["A-1", "A-2"]


def test_flatten_dedupes_when_a_subtask_id_also_appears_as_top_level():
    """If the agent returns the same id both as a top-level item AND nested
    inside another parent's subtasks, keep only the first occurrence (the
    top-level one — that's the more canonical record). This guards against
    a tracker that lists subtasks in BOTH places."""
    items = [
        {"id": "MH-13", "title": "explicitly listed", "subtasks": []},
        {"id": "MH-4", "title": "parent", "subtasks": [
            {"id": "MH-13", "title": "nested duplicate"},
        ]},
    ]
    out = _flatten_subtasks(items)
    ids = [i["id"] for i in out]
    assert ids.count("MH-13") == 1
    # The top-level record wins.
    assert next(i for i in out if i["id"] == "MH-13")["title"] == "explicitly listed"


def test_parse_items_runs_the_flatten_step():
    """End-to-end: a JSON reply with nested subtasks comes out flattened
    after _parse_items processes it."""
    reply = json.dumps({"items": [
        {"id": "P", "title": "Parent", "status_kind": "todo",
         "subtasks": [{"id": "C", "title": "Child", "status_kind": "todo"}]},
    ]})
    items = _parse_items(reply)
    ids = [i["id"] for i in items]
    assert ids == ["P", "C"]
    assert items[1]["parent_id"] == "P"
