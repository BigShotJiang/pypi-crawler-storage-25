from meeting_helper.state import AppState, PinnedItem


def _new_state() -> AppState:
    return AppState()


def test_pin_topic_appends():
    state = _new_state()
    item = PinnedItem(kind="ticket", id="MH-1", title="A", board_id="bd")
    state.pin_topic(item)
    assert state.pinned_topics == [item]


def test_pin_topic_dedupes_by_kind_and_id():
    state = _new_state()
    item = PinnedItem(kind="note", id="foo.note.md", title="Foo")
    state.pin_topic(item)
    state.pin_topic(item)
    assert state.pinned_topics == [item]


def test_pin_topic_keeps_distinct_kinds_even_with_same_id():
    state = _new_state()
    a = PinnedItem(kind="ticket", id="MH-1", title="Ticket")
    b = PinnedItem(kind="action_item", id="MH-1", title="AI dupe")
    state.pin_topic(a)
    state.pin_topic(b)
    assert state.pinned_topics == [a, b]


def test_unpin_topic_removes_and_returns_true():
    state = _new_state()
    item = PinnedItem(kind="note", id="foo.note.md", title="Foo")
    state.pin_topic(item)
    assert state.unpin_topic("note", "foo.note.md") is True
    assert state.pinned_topics == []


def test_unpin_missing_returns_false():
    state = _new_state()
    assert state.unpin_topic("ticket", "nope") is False


def test_clear_pins_empties_basket():
    state = _new_state()
    state.pin_topic(PinnedItem(kind="ticket", id="MH-1", title="A"))
    state.pin_topic(PinnedItem(kind="note", id="foo.note.md", title="Foo"))
    state.clear_pins()
    assert state.pinned_topics == []


def test_is_manual_mode_reflects_basket():
    state = _new_state()
    assert state.is_manual_mode is False
    state.pin_topic(PinnedItem(kind="ticket", id="MH-1", title="A"))
    assert state.is_manual_mode is True
    state.clear_pins()
    assert state.is_manual_mode is False
