"""Provider adapter tests — focused on the Anthropic -> Gemini message
translation that the agent loop depends on for multi-cycle tool use."""
import json

import pytest

from meeting_helper.chat.providers import (
    ClaudeProvider,
    GeminiProvider,
    OpenAIProvider,
    _friendly_openai_error,
    _is_transient_openai_error,
    _to_gemini_contents,
    _to_openai_messages,
)


def _parts_with(content, attr):
    return [getattr(p, attr) for p in content.parts if getattr(p, attr, None) is not None]


def _tool_round_trip_convo():
    """The exact shape agent_loop appends after one tool cycle: a plain user
    turn, an assistant tool_use turn, then a user tool_result turn."""
    return [
        {"role": "user", "content": "check my last meeting and summarise"},
        {
            "role": "assistant",
            "content": [
                {
                    "type": "tool_use",
                    "id": "abc123",
                    "name": "library.get_note",
                    "input": {"note_id": "engt-4212-phase-2-meeting-notes.note.md"},
                }
            ],
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "abc123",
                    "content": json.dumps({"status": "ok", "result": {"title": "Standup"}}),
                }
            ],
        },
    ]


def test_tool_use_block_becomes_function_call_not_stringified():
    contents = _to_gemini_contents(_tool_round_trip_convo())

    # Regression guard: no part anywhere may carry the python-repr of a block
    # list. That repr ("[{'type': 'tool_use', ...}]") is what leaked into the
    # chat bubble before this fix.
    for c in contents:
        for text in _parts_with(c, "text"):
            assert "'type': 'tool_use'" not in text
            assert "'type': 'tool_result'" not in text

    assistant = contents[1]
    assert assistant.role == "model"
    calls = _parts_with(assistant, "function_call")
    assert len(calls) == 1
    fc = calls[0]
    # dotted registry name translated to the underscored wire name.
    assert fc.name == "library_get_note"
    assert dict(fc.args) == {"note_id": "engt-4212-phase-2-meeting-notes.note.md"}


def test_tool_result_block_becomes_function_response_with_matching_name():
    contents = _to_gemini_contents(_tool_round_trip_convo())

    tool_turn = contents[2]
    assert tool_turn.role == "user"
    responses = _parts_with(tool_turn, "function_response")
    assert len(responses) == 1
    fr = responses[0]
    # functionResponse name must match the functionCall name so Gemini can
    # pair them across the turn boundary.
    assert fr.name == "library_get_note"
    assert fr.response["status"] == "ok"


def test_plain_string_messages_still_become_text_parts():
    contents = _to_gemini_contents(
        [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi there"},
        ]
    )
    assert contents[0].role == "user"
    assert _parts_with(contents[0], "text") == ["hello"]
    assert contents[1].role == "model"
    assert _parts_with(contents[1], "text") == ["hi there"]


def test_truncated_tool_result_content_is_wrapped_not_dropped():
    # _truncate_for_convo appends a non-JSON marker, so json.loads fails.
    # The response must still be a dict (Gemini requires it), not crash.
    convo = [
        {
            "role": "assistant",
            "content": [
                {"type": "tool_use", "id": "x", "name": "lib.search", "input": {}}
            ],
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "x",
                    "content": '{"status": "ok"} ...[truncated: result was huge]',
                }
            ],
        },
    ]
    contents = _to_gemini_contents(convo)
    fr = _parts_with(contents[1], "function_response")[0]
    assert isinstance(fr.response, dict)


class _FakeChunk:
    """Mimics a google-genai streaming chunk (text only; no tool parts)."""

    def __init__(self, text=None):
        self.text = text
        self.candidates = []


class _FakeModels:
    def __init__(self, streams):
        self._streams = list(streams)
        self.calls = 0

    def generate_content_stream(self, **kwargs):
        idx = min(self.calls, len(self._streams) - 1)
        self.calls += 1
        return iter(self._streams[idx])


def _gemini_with_streams(streams):
    prov = GeminiProvider.__new__(GeminiProvider)  # skip real client construction
    prov._client = type("_C", (), {})()
    prov._client.models = _FakeModels(streams)
    prov._model_name = "gemini-2.5-flash-lite"
    return prov


@pytest.mark.asyncio
async def test_gemini_retries_on_empty_completion():
    """Flash Lite intermittently returns an empty stream after a tool result;
    the provider re-samples and recovers the real text without losing it."""
    prov = _gemini_with_streams([
        [],                                  # attempt 1: empty completion
        [_FakeChunk(text="Hello there.")],   # attempt 2: real text
    ])
    events = [
        ev async for ev in prov.stream_completion(
            system="s", messages=[{"role": "user", "content": "hi"}], tools=[]
        )
    ]
    text = "".join(e["text"] for e in events if e["type"] == "chunk")
    assert text == "Hello there."
    assert prov._client.models.calls == 2  # retried once


@pytest.mark.asyncio
async def test_gemini_gives_up_after_repeated_empty():
    """If every attempt is empty, stop after max_attempts and emit no text
    (the handler then surfaces its empty-reply fallback)."""
    prov = _gemini_with_streams([[], [], [], []])
    events = [
        ev async for ev in prov.stream_completion(
            system="s", messages=[{"role": "user", "content": "hi"}], tools=[]
        )
    ]
    assert not any(e["type"] == "chunk" for e in events)
    assert events[-1]["type"] == "done"
    assert prov._client.models.calls == 3  # bounded by max_attempts


# --- Claude parity: transient retry + friendly errors ----------------------

def _text_event(t):
    delta = type("_D", (), {"type": "text_delta", "text": t})()
    return type("_E", (), {"type": "content_block_delta", "delta": delta})()


class _FakeAnthropicStreamCtx:
    def __init__(self, events=None, raise_exc=None):
        self._events = events or []
        self._raise = raise_exc

    async def __aenter__(self):
        if self._raise is not None:
            raise self._raise
        return self

    async def __aexit__(self, *exc):
        return False

    def __aiter__(self):
        async def _gen():
            for e in self._events:
                yield e
        return _gen()


class _FakeAnthropicMessages:
    def __init__(self, ctxs):
        self._ctxs = list(ctxs)
        self.calls = 0

    def stream(self, **kwargs):
        ctx = self._ctxs[min(self.calls, len(self._ctxs) - 1)]
        self.calls += 1
        return ctx


def _claude_with(ctxs):
    prov = ClaudeProvider.__new__(ClaudeProvider)
    prov._client = type("_C", (), {})()
    prov._client.messages = _FakeAnthropicMessages(ctxs)
    prov._model = "claude-test"
    prov._max_tokens = 8192
    return prov


@pytest.mark.asyncio
async def test_claude_retries_transient_overload(monkeypatch):
    import asyncio

    async def _no_sleep(*a, **k):
        return None

    monkeypatch.setattr(asyncio, "sleep", _no_sleep)
    prov = _claude_with([
        _FakeAnthropicStreamCtx(raise_exc=RuntimeError("Error code: 529 - overloaded")),
        _FakeAnthropicStreamCtx(events=[_text_event("Hi "), _text_event("there.")]),
    ])
    events = [
        ev async for ev in prov.stream_completion(
            system="s", messages=[{"role": "user", "content": "hi"}], tools=[]
        )
    ]
    text = "".join(e["text"] for e in events if e["type"] == "chunk")
    assert text == "Hi there."
    assert prov._client.messages.calls == 2  # retried once


@pytest.mark.asyncio
async def test_claude_non_transient_error_is_friendly():
    prov = _claude_with([
        _FakeAnthropicStreamCtx(raise_exc=RuntimeError("authentication_error: invalid x-api-key")),
    ])
    with pytest.raises(RuntimeError) as ei:
        async for _ in prov.stream_completion(
            system="s", messages=[{"role": "user", "content": "hi"}], tools=[]
        ):
            pass
    assert "API key" in str(ei.value)
    assert prov._client.messages.calls == 1  # not retried


# --- OpenAI provider ---------------------------------------------------------

def _oai_chunk(content=None, tool_calls=None):
    delta = type("_D", (), {"content": content, "tool_calls": tool_calls})()
    choice = type("_C", (), {"delta": delta})()
    return type("_Ch", (), {"choices": [choice]})()


def _oai_tc(index, id=None, name=None, args=None):
    fn = type("_F", (), {"name": name, "arguments": args})()
    return type("_TC", (), {"index": index, "id": id, "function": fn})()


class _FakeOpenAIStream:
    def __init__(self, chunks):
        self._chunks = chunks

    def __aiter__(self):
        async def _gen():
            for c in self._chunks:
                yield c
        return _gen()


class _FakeOpenAICompletions:
    def __init__(self, streams):
        self._streams = list(streams)
        self.calls = 0

    async def create(self, **kwargs):
        s = self._streams[min(self.calls, len(self._streams) - 1)]
        self.calls += 1
        return _FakeOpenAIStream(s)


def _openai_with(streams):
    prov = OpenAIProvider.__new__(OpenAIProvider)
    prov._client = type("_Cl", (), {})()
    prov._client.chat = type("_Chat", (), {})()
    prov._client.chat.completions = _FakeOpenAICompletions(streams)
    prov._model = "gpt-4.1-nano"
    prov._max_tokens = 8192
    return prov


def test_to_openai_messages_tool_round_trip():
    msgs = [
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": [
            {"type": "tool_use", "id": "c1", "name": "library.get_meeting", "input": {"meeting_id": "m"}}]},
        {"role": "user", "content": [
            {"type": "tool_result", "tool_use_id": "c1", "content": '{"ok": true}'}]},
    ]
    out = _to_openai_messages("SYS", msgs)
    assert out[0] == {"role": "system", "content": "SYS"}
    assert out[1] == {"role": "user", "content": "hi"}
    assert out[2]["role"] == "assistant"
    assert out[2]["tool_calls"][0]["function"]["name"] == "library_get_meeting"  # dotted -> wire
    assert out[2]["tool_calls"][0]["id"] == "c1"
    assert out[3] == {"role": "tool", "tool_call_id": "c1", "content": '{"ok": true}'}


@pytest.mark.asyncio
async def test_openai_streams_text():
    prov = _openai_with([[_oai_chunk(content="Hello "), _oai_chunk(content="there.")]])
    events = [
        ev async for ev in prov.stream_completion(
            system="s", messages=[{"role": "user", "content": "hi"}], tools=[]
        )
    ]
    assert "".join(e["text"] for e in events if e["type"] == "chunk") == "Hello there."
    assert events[-1]["type"] == "done"


@pytest.mark.asyncio
async def test_openai_accumulates_streamed_tool_call():
    prov = _openai_with([[
        _oai_chunk(tool_calls=[_oai_tc(0, id="call_1", name="library_list_recent", args='{"li')]),
        _oai_chunk(tool_calls=[_oai_tc(0, args='mit": 5}')]),
    ]])
    tools = [{"name": "library.list_recent", "description": "d", "input_schema": {"limit": "integer?"}}]
    events = [
        ev async for ev in prov.stream_completion(
            system="s", messages=[{"role": "user", "content": "hi"}], tools=tools
        )
    ]
    tus = [e for e in events if e["type"] == "tool_use"]
    assert len(tus) == 1
    assert tus[0]["name"] == "library.list_recent"  # mapped back from underscored
    assert tus[0]["input"] == {"limit": 5}
    assert tus[0]["id"] == "call_1"


@pytest.mark.asyncio
async def test_openai_retries_on_empty_completion():
    prov = _openai_with([[], [_oai_chunk(content="Recovered.")]])
    events = [
        ev async for ev in prov.stream_completion(
            system="s", messages=[{"role": "user", "content": "hi"}], tools=[]
        )
    ]
    assert "".join(e["text"] for e in events if e["type"] == "chunk") == "Recovered."
    assert prov._client.chat.completions.calls == 2


def test_openai_error_helpers():
    assert _is_transient_openai_error(Exception("503 service unavailable"))
    assert _is_transient_openai_error(Exception("Rate limit reached"))
    assert not _is_transient_openai_error(Exception("invalid request: bad schema"))
    assert "API key" in str(_friendly_openai_error(Exception("Incorrect API key provided")))
    assert "rate limit" in str(_friendly_openai_error(Exception("429 rate limit"))).lower()
