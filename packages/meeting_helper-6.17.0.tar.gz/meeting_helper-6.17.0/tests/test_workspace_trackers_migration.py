import json
import pytest
from pathlib import Path
from meeting_helper.config import Config


def test_copilot_instructions_roundtrip(tmp_path):
    p = tmp_path / "ws.json"
    p.write_text('{"copilot_instructions": "Project key MH, focus on engineering board"}')
    cfg = Config(p)
    assert cfg.copilot_instructions == "Project key MH, focus on engineering board"
    cfg.copilot_instructions = "updated"
    cfg.save()
    assert json.loads(p.read_text())["copilot_instructions"] == "updated"


def test_copilot_learned_memory_roundtrip(tmp_path):
    entries = [
        {"at": 1700000000.0, "text": "Project key: MH", "source": "agent"},
        {"at": 1700000001.0, "text": "Board: Engineering", "source": "agent"},
    ]
    p = tmp_path / "ws.json"
    p.write_text(json.dumps({"copilot_learned_memory": entries}))
    cfg = Config(p)
    assert cfg.copilot_learned_memory == entries

    # Delete one entry and save
    cfg.copilot_learned_memory = [entries[0]]
    cfg.save()
    saved = json.loads(p.read_text())["copilot_learned_memory"]
    assert saved == [entries[0]]

    # Clear all
    cfg.copilot_learned_memory = []
    cfg.save()
    assert json.loads(p.read_text())["copilot_learned_memory"] == []


def test_copilot_learned_memory_defaults_empty(tmp_path):
    p = tmp_path / "ws.json"
    p.write_text("{}")
    cfg = Config(p)
    assert cfg.copilot_learned_memory == []


def _write_workspace(tmp_path: Path, data: dict) -> Path:
    p = tmp_path / "ws.json"
    p.write_text(json.dumps(data))
    return p


def test_legacy_local_todo_mcp_stdio_drops_tracker(tmp_path):
    """Legacy stdio installs cannot auto-derive an OAuth URL — migrated to
    empty trackers list so the user re-adds via Settings."""
    p = _write_workspace(tmp_path, {
        "local_todo_mcp": {
            "type": "stdio", "command": "npx",
            "args": ["@local-todo/mcp"], "env": {},
            "url": "", "headers": {},
        }
    })
    cfg = Config(p)
    trackers = cfg.trackers
    assert trackers == []
    assert cfg.active_tracker_id is None


def test_legacy_local_todo_mcp_http_migrates_to_trackers_list(tmp_path):
    """Legacy HTTP installs migrate to the new OAuth+url shape."""
    p = _write_workspace(tmp_path, {
        "local_todo_mcp": {
            "type": "http",
            "url": "https://my-todo.local/mcp",
            "headers": {},
        }
    })
    cfg = Config(p)
    trackers = cfg.trackers
    assert len(trackers) == 1
    entry = trackers[0]
    assert entry["vendor"] == "local_todo"
    assert entry["transport"]["type"] == "http"
    assert entry["transport"]["url"] == "https://my-todo.local/mcp"
    assert entry["auth_values"]["url"] == "https://my-todo.local/mcp"
    assert cfg.active_tracker_id == entry["id"]


def test_new_shape_round_trips(tmp_path):
    p = _write_workspace(tmp_path, {
        "trackers": [
            {
                "id": "lt-1", "vendor": "local_todo", "label": "Local",
                "transport": {"type": "http", "url": "https://my-todo.local/mcp", "headers": {}},
                "auth_values": {"url": "https://my-todo.local/mcp"}, "secret_keys": [],
            }
        ],
        "active_tracker_id": "lt-1",
    })
    cfg = Config(p)
    assert cfg.active_tracker_id == "lt-1"
    assert cfg.trackers[0]["vendor"] == "local_todo"


def test_legacy_key_dropped_on_first_save_stdio(tmp_path):
    """Legacy stdio: legacy key dropped, trackers written as empty list."""
    p = _write_workspace(tmp_path, {
        "local_todo_mcp": {"type": "stdio", "command": "npx", "args": [], "env": {}, "url": "", "headers": {}}
    })
    cfg = Config(p)
    _ = cfg.trackers  # triggers migration
    cfg.save()
    data = json.loads(p.read_text())
    assert "local_todo_mcp" not in data
    assert "trackers" in data
    assert data["trackers"] == []
    assert data["active_tracker_id"] is None


def test_legacy_key_dropped_on_first_save_http(tmp_path):
    """Legacy HTTP: legacy key dropped, tracker entry written with url shape."""
    p = _write_workspace(tmp_path, {
        "local_todo_mcp": {"type": "http", "url": "https://my-todo.local/mcp", "headers": {}}
    })
    cfg = Config(p)
    _ = cfg.trackers  # triggers migration
    cfg.save()
    data = json.loads(p.read_text())
    assert "local_todo_mcp" not in data
    assert "trackers" in data
    assert len(data["trackers"]) == 1
    assert data["trackers"][0]["auth_values"]["url"] == "https://my-todo.local/mcp"
    assert data["active_tracker_id"] is not None


def test_legacy_local_todo_mcp_property_still_works(tmp_path):
    """One-release back-compat: old `local_todo_mcp` getter returns the
    active tracker's transport if it's a local_todo tracker."""
    p = _write_workspace(tmp_path, {
        "trackers": [
            {
                "id": "lt-1", "vendor": "local_todo", "label": "Local",
                "transport": {"type": "http", "url": "https://my-todo.local/mcp", "headers": {}},
                "auth_values": {"url": "https://my-todo.local/mcp"}, "secret_keys": [],
            }
        ],
        "active_tracker_id": "lt-1",
    })
    cfg = Config(p)
    legacy = cfg.local_todo_mcp
    assert legacy["type"] == "http"
    assert legacy["url"] == "https://my-todo.local/mcp"
