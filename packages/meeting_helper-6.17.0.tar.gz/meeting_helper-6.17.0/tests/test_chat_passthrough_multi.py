"""Chat passthrough must enumerate tools from every chat-enabled tracker
and namespace them with a per-tracker slug. Dispatch routes calls back to
the right tracker session by parsing the slug prefix off the tool name."""
import pytest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

from meeting_helper.chat.tools.mcp_passthrough import (
    build_mcp_passthrough_tools_multi,
    _parse_slug_prefix,
)


def _tracker(tool_names: list[str]):
    """Build a fake Tracker whose _session.list_tools returns the named tools."""
    tools = [SimpleNamespace(name=n, description=f"d for {n}",
                              inputSchema={"type": "object", "properties": {}})
             for n in tool_names]
    sess = MagicMock()
    sess.list_tools = AsyncMock(return_value=SimpleNamespace(tools=tools))
    t = MagicMock()
    t._ensure_started = AsyncMock()
    t._session = sess
    t.call_tool = AsyncMock(return_value={"ok": True})
    return t


@pytest.mark.asyncio
async def test_two_trackers_produce_namespaced_tool_names():
    """Two chat-enabled trackers each exposing `search_pages` produce two
    distinct chat-tool names: `<slug-A>__search_pages` and
    `<slug-B>__search_pages`."""
    reg = MagicMock()
    reg.chat_enabled_ids = MagicMock(return_value=["a", "b"])
    reg.ensure_session = AsyncMock(side_effect=[
        _tracker(["search_pages"]),
        _tracker(["search_pages"]),
    ])
    config = SimpleNamespace(trackers=[
        {"id": "a", "label": "Notion Work", "chat_enabled": True},
        {"id": "b", "label": "Notion Personal", "chat_enabled": True},
    ])

    tools = await build_mcp_passthrough_tools_multi(reg, config, workspace_name="W")

    names = sorted(t.name for t in tools)
    assert names == ["notion-personal__search_pages", "notion-work__search_pages"]


@pytest.mark.asyncio
async def test_descriptions_get_label_prefix():
    reg = MagicMock()
    reg.chat_enabled_ids = MagicMock(return_value=["a"])
    reg.ensure_session = AsyncMock(return_value=_tracker(["x"]))
    config = SimpleNamespace(trackers=[
        {"id": "a", "label": "Notion Work", "chat_enabled": True},
    ])
    tools = await build_mcp_passthrough_tools_multi(reg, config, workspace_name="W")
    assert "[Notion Work]" in tools[0].description


@pytest.mark.asyncio
async def test_dispatch_routes_call_by_slug_prefix():
    """Calling the registered chat tool must invoke call_tool on the right
    tracker's session, with the slug stripped off."""
    fake_a = _tracker(["search_pages"])
    fake_b = _tracker(["search_pages"])
    reg = MagicMock()
    reg.chat_enabled_ids = MagicMock(return_value=["a", "b"])
    # ensure_session is called once per tracker during build AND once per
    # call during dispatch. Return whichever is asked for.
    reg.ensure_session = AsyncMock(side_effect=lambda entry, workspace_name="", **kwargs: {
        "a": fake_a, "b": fake_b,
    }[entry["id"]])
    config = SimpleNamespace(trackers=[
        {"id": "a", "label": "Notion Work", "chat_enabled": True},
        {"id": "b", "label": "Notion Personal", "chat_enabled": True},
    ])
    tools = await build_mcp_passthrough_tools_multi(reg, config, workspace_name="W")
    by_name = {t.name: t for t in tools}

    await by_name["notion-work__search_pages"].run(
        {"q": "alpha"},
        {"trackers": reg, "config": config, "workspace_name": "W"},
    )
    fake_a.call_tool.assert_awaited_once_with("search_pages", {"q": "alpha"})
    fake_b.call_tool.assert_not_called()


def test_parse_slug_prefix_splits_on_double_underscore_once():
    assert _parse_slug_prefix("notion-work__search_pages") == ("notion-work", "search_pages")
    # Tool names can themselves contain underscores — only the FIRST __ is the boundary.
    assert _parse_slug_prefix("notion-work__do_a__thing") == ("notion-work", "do_a__thing")


def test_parse_slug_prefix_returns_none_for_unprefixed_names():
    assert _parse_slug_prefix("not_prefixed") is None
    assert _parse_slug_prefix("") is None


@pytest.mark.asyncio
async def test_round_robin_caps_at_20_tools_across_trackers():
    """With 3 trackers each exposing 15 tools (45 total), the cap takes the
    first 20 round-robin across all 3 trackers."""
    fakes = [_tracker([f"t{n}" for n in range(15)]) for _ in range(3)]
    reg = MagicMock()
    reg.chat_enabled_ids = MagicMock(return_value=["a", "b", "c"])
    reg.ensure_session = AsyncMock(side_effect=fakes)
    config = SimpleNamespace(trackers=[
        {"id": "a", "label": "A", "chat_enabled": True},
        {"id": "b", "label": "B", "chat_enabled": True},
        {"id": "c", "label": "C", "chat_enabled": True},
    ])

    tools = await build_mcp_passthrough_tools_multi(reg, config, workspace_name="W")

    # Round-robin: a__t0, b__t0, c__t0, a__t1, b__t1, c__t1, ... — first 20.
    assert len(tools) == 20
    names = [t.name for t in tools]
    # Each tracker contributes either 7 or 6 tools (20 / 3 rounded).
    a_count = sum(1 for n in names if n.startswith("a__"))
    b_count = sum(1 for n in names if n.startswith("b__"))
    c_count = sum(1 for n in names if n.startswith("c__"))
    assert {a_count, b_count, c_count} <= {6, 7}
    assert a_count + b_count + c_count == 20


@pytest.mark.asyncio
async def test_failed_tracker_does_not_block_others():
    """If one tracker's list_tools raises, the builder skips it and continues
    with the rest — chat stays usable."""
    fake_good = _tracker(["x"])
    fake_bad = MagicMock()
    fake_bad._ensure_started = AsyncMock(side_effect=RuntimeError("boot failed"))

    reg = MagicMock()
    reg.chat_enabled_ids = MagicMock(return_value=["bad", "good"])
    reg.ensure_session = AsyncMock(side_effect=lambda entry, workspace_name="", **kwargs: {
        "bad": fake_bad, "good": fake_good,
    }[entry["id"]])
    config = SimpleNamespace(trackers=[
        {"id": "bad", "label": "Bad", "chat_enabled": True},
        {"id": "good", "label": "Good", "chat_enabled": True},
    ])

    tools = await build_mcp_passthrough_tools_multi(reg, config, workspace_name="W")
    assert [t.name for t in tools] == ["good__x"]
