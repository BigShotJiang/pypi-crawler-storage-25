import base64
import io
from pathlib import Path

from PIL import Image

import meeting_helper.screenshot as ss


def test_encode_b64_roundtrips(tmp_path):
    img = Image.new("RGB", (40, 30), (10, 20, 30))
    p = tmp_path / "shot.jpg"
    img.save(p, "JPEG", quality=70)
    b64 = ss.encode_b64(p)
    assert isinstance(b64, str) and len(b64) > 0
    # decodes back to a JPEG
    Image.open(io.BytesIO(base64.b64decode(b64)))


def test_make_thumbnail_data_url_downscales(tmp_path):
    img = Image.new("RGB", (1200, 800), (10, 20, 30))
    p = tmp_path / "shot.jpg"
    img.save(p, "JPEG", quality=70)
    thumb = ss.make_thumbnail_data_url(p, max_w=320)
    assert thumb.startswith("data:image/jpeg;base64,")
    raw = thumb.split(",", 1)[1]
    timg = Image.open(io.BytesIO(base64.b64decode(raw)))
    assert timg.width <= 320


def test_capture_uses_window_id(monkeypatch, tmp_path):
    monkeypatch.setattr(ss, "SCREENSHOTS_DIR", tmp_path)
    monkeypatch.setattr(ss, "_frontmost_window_id", lambda: 4242)
    seen = {}

    def fake_run(args):
        seen["args"] = args
        # screencapture writes the output file (last arg is the path)
        Image.new("RGB", (100, 100), (0, 0, 0)).save(args[-1], "JPEG")
        return True

    monkeypatch.setattr(ss, "_run_screencapture", fake_run)
    path = ss.capture_frontmost_window()
    assert path is not None and Path(path).exists()
    assert any(a == "-l4242" for a in seen["args"])


def test_capture_falls_back_to_display_when_no_window(monkeypatch, tmp_path):
    monkeypatch.setattr(ss, "SCREENSHOTS_DIR", tmp_path)
    monkeypatch.setattr(ss, "_frontmost_window_id", lambda: None)
    seen = {}

    def fake_run(args):
        seen["args"] = args
        Image.new("RGB", (50, 50), (0, 0, 0)).save(args[-1], "JPEG")
        return True

    monkeypatch.setattr(ss, "_run_screencapture", fake_run)
    path = ss.capture_frontmost_window()
    assert path is not None
    assert not any(a.startswith("-l") for a in seen["args"])  # no window id


def test_frontmost_window_id_takes_front_skipping_own_ui(monkeypatch):
    import sys
    import types

    fake_q = types.SimpleNamespace(
        kCGWindowListOptionOnScreenOnly=1,
        kCGWindowListExcludeDesktopElements=2,
        kCGNullWindowID=0,
        CGWindowListCopyWindowInfo=lambda opt, wid: [
            # front-to-back: our own UI first (skipped), then the real window
            {"kCGWindowLayer": 0, "kCGWindowOwnerName": "Meeting Helper",
             "kCGWindowBounds": {"Width": 800, "Height": 600}, "kCGWindowNumber": 1},
            {"kCGWindowLayer": 25, "kCGWindowOwnerName": "Dock",
             "kCGWindowBounds": {"Width": 2000, "Height": 80}, "kCGWindowNumber": 2},
            {"kCGWindowLayer": 0, "kCGWindowOwnerName": "zoom.us",
             "kCGWindowBounds": {"Width": 1200, "Height": 800}, "kCGWindowNumber": 99},
        ],
    )
    monkeypatch.setitem(sys.modules, "Quartz", fake_q)
    assert ss._frontmost_window_id() == 99


def test_frontmost_window_id_none_when_only_own_ui(monkeypatch):
    import sys
    import types

    fake_q = types.SimpleNamespace(
        kCGWindowListOptionOnScreenOnly=1,
        kCGWindowListExcludeDesktopElements=2,
        kCGNullWindowID=0,
        CGWindowListCopyWindowInfo=lambda opt, wid: [
            {"kCGWindowLayer": 0, "kCGWindowOwnerName": "Meeting Helper",
             "kCGWindowBounds": {"Width": 800, "Height": 600}, "kCGWindowNumber": 1},
        ],
    )
    monkeypatch.setitem(sys.modules, "Quartz", fake_q)
    assert ss._frontmost_window_id() is None


def test_capture_returns_none_on_failure(monkeypatch, tmp_path):
    monkeypatch.setattr(ss, "SCREENSHOTS_DIR", tmp_path)
    monkeypatch.setattr(ss, "_frontmost_window_id", lambda: None)
    monkeypatch.setattr(ss, "_run_screencapture", lambda args: False)
    assert ss.capture_frontmost_window() is None


def test_encode_b64_downscales_large_grab(tmp_path):
    """A big Retina-sized grab is downscaled to the vision long-edge target so
    code text stays sharp instead of being blindly downscaled provider-side."""
    img = Image.new("RGB", (4000, 2500), (240, 240, 240))
    p = tmp_path / "big.jpg"
    img.save(p, "JPEG", quality=90)
    b64 = ss.encode_b64(p)
    out = Image.open(io.BytesIO(base64.b64decode(b64)))
    assert max(out.width, out.height) <= ss._VISION_MAX_EDGE
    # aspect ratio preserved
    assert abs((out.width / out.height) - (4000 / 2500)) < 0.02


def test_encode_b64_keeps_small_grab_unscaled(tmp_path):
    img = Image.new("RGB", (800, 600), (10, 20, 30))
    p = tmp_path / "small.jpg"
    img.save(p, "JPEG", quality=90)
    out = Image.open(io.BytesIO(base64.b64decode(ss.encode_b64(p))))
    assert (out.width, out.height) == (800, 600)
