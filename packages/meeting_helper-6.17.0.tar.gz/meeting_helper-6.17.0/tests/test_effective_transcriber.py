"""Tests for `compute_effective_transcriber` and the `off` opt-out path.

The Settings UI surfaces the resolved transcriber up front so users always
know what will run — even when they haven't touched the config (the
batteries-included local Whisper). These tests pin the resolution table
so a future config change can't silently change which fallback wins.
"""

from __future__ import annotations

from unittest.mock import patch

from meeting_helper.audio.transcriber import (
    _whisper_model_file_present,
    compute_effective_transcriber,
    create_transcriber,
)


def test_off_returns_dedicated_kind():
    out = compute_effective_transcriber(preferred_transcriber="off")
    assert out["kind"] == "off"
    assert out["ready"] is True
    assert out["warning"] is None
    assert "no live transcript" in out["details"].lower()


def test_create_transcriber_off_returns_none(monkeypatch):
    """When `preferred_transcriber='off'`, no transcriber is started.
    The session still records audio; it just doesn't transcribe."""
    monkeypatch.setattr(
        "meeting_helper.audio.transcriber._make_whisper",
        None,
        raising=False,
    )
    out = create_transcriber(
        audio_capture=object(),  # never used on the `off` path
        transcript_buffer=object(),
        preferred_transcriber="off",
    )
    assert out is None


def test_empty_pref_with_no_keys_falls_back_to_local_whisper():
    """The 'new SoFi workspace with no config' scenario — auto-mode +
    no Deepgram key + no whisper host → local Whisper. This is the
    behavior users were surprised by; it must stay reachable AND
    visible via the effective payload."""
    out = compute_effective_transcriber(preferred_transcriber="")
    assert out["kind"] == "local_whisper"
    assert out["label"] == "Local Whisper"
    assert "model: base" in out["details"]
    # `ready` depends on the real machine — assert it's a bool, not what.
    assert isinstance(out["ready"], bool)


def test_local_whisper_warns_when_model_not_downloaded(monkeypatch):
    monkeypatch.setattr(
        "meeting_helper.audio.transcriber._whisper_model_file_present",
        lambda *_a, **_k: False,
    )
    out = compute_effective_transcriber(preferred_transcriber="")
    assert out["kind"] == "local_whisper"
    assert out["ready"] is False
    assert "download" in (out["warning"] or "").lower()


def test_local_whisper_no_warning_when_model_present(monkeypatch):
    monkeypatch.setattr(
        "meeting_helper.audio.transcriber._whisper_model_file_present",
        lambda *_a, **_k: True,
    )
    out = compute_effective_transcriber(preferred_transcriber="")
    assert out["kind"] == "local_whisper"
    assert out["ready"] is True
    assert out["warning"] is None


def test_auto_with_deepgram_key_prefers_deepgram():
    out = compute_effective_transcriber(
        preferred_transcriber="",
        deepgram_api_key="dg_test_xxx",
    )
    assert out["kind"] == "deepgram"
    assert out["ready"] is True
    assert out["warning"] is None


def test_force_deepgram_without_key_flags_warning():
    out = compute_effective_transcriber(
        preferred_transcriber="deepgram",
        deepgram_api_key="",
    )
    assert out["kind"] == "deepgram"
    assert out["ready"] is False
    assert "no" in (out["warning"] or "").lower() and "key" in (out["warning"] or "").lower()


def test_whisper_host_set_resolves_to_remote():
    out = compute_effective_transcriber(
        preferred_transcriber="whisper",
        whisper_host="http://192.168.8.201:8000",
    )
    assert out["kind"] == "remote_whisper"
    assert "192.168.8.201" in out["details"]
    assert out["ready"] is True


def test_pref_whisper_no_host_resolves_to_local():
    out = compute_effective_transcriber(preferred_transcriber="whisper")
    assert out["kind"] == "local_whisper"


def test_whisper_model_file_present_checks_standard_path(tmp_path, monkeypatch):
    """The download-status check must look at the real Whisper cache —
    we don't want to claim 'ready' just because some other directory
    happened to have a `base.pt` lying around."""
    # Point HOME at an empty temp dir → no cached model.
    monkeypatch.setattr("os.path.expanduser", lambda p: str(tmp_path) + p[1:] if p.startswith("~") else p)
    assert _whisper_model_file_present() is False
    # Drop a fake model file into the expected location.
    cache = tmp_path / ".cache" / "whisper"
    cache.mkdir(parents=True)
    (cache / "base.pt").write_bytes(b"x")
    assert _whisper_model_file_present() is True


def test_config_get_includes_effective_transcriber(monkeypatch):
    """The Settings UI hydrates from /config — the `effective_transcriber`
    block must be present in the payload."""
    from meeting_helper.server import routes as routes_mod

    class _G:
        def __call__(self, name, default):
            return {
                "preferred_transcriber": "",
                "deepgram_api_key": "",
                "whisper_host": "",
                "transcription_language": "en",
            }.get(name, default)

    payload = routes_mod._compute_effective_transcriber_payload(_G())
    assert payload["kind"] == "local_whisper"
