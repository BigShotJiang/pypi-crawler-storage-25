"""agent_fetch must not silently drop task rows the tracker actually returned.

The fetch is an LLM agent loop: it calls the tracker's MCP read tool (e.g.
`list_tasks`), gets every row back, then is trusted to re-serialize each row
into its final `items` JSON. Smaller models (Haiku/Gemini) drop rows
non-deterministically — the daemon log showed the same 4-task board fetched
as items=1 / items=3 / items=4 across identical runs, and the Topics panel
rendered only the rows that survived.

Fix: capture the rows the read tool returned during the run and reconcile
them against the LLM's emitted items, re-injecting any dropped row so no
fetched task can vanish from Topics. These tests pin that reconciliation.
"""

import pytest

from meeting_helper.ai.agent_fetch import (
    _extract_rows,
    _is_task_listing_tool,
    _recover_dropped_rows,
)


def _ok(payload):
    """Wrap a payload the way the mcp passthrough tool returns it."""
    return {"status": "ok", "result": payload}


# The 4-task board from the bug report (1 Todo + 3 In Review).
_BOARD_ROWS = [
    {"id": 44, "title": "ENGT-4212 Phase 2: frontend wires", "status": "Todo",
     "priority": "Medium", "sprint_id": 1, "parent_id": None},
    {"id": 3, "title": "ENGT-4524: Review Skip backlog on restart - Fix Revert",
     "status": "In Review", "priority": "Medium", "sprint_id": 1, "parent_id": None},
    {"id": 4, "title": "ENGT-4573: Phase 1 - ClickHouse client library foundation",
     "status": "In Review", "priority": "Medium", "sprint_id": 1, "parent_id": None},
    {"id": 7, "title": "[Audit][URGENT] Datadog API key logged in plaintext",
     "status": "In Review", "priority": "High", "sprint_id": 1, "parent_id": None},
]


def test_reinjects_the_row_the_llm_dropped():
    # LLM emitted only 3 of the 4 rows the tracker returned — it dropped #3.
    emitted = [
        {"id": "44", "title": "ENGT-4212 Phase 2: frontend wires",
         "status": "Todo", "status_kind": "todo", "workspace_id": ""},
        {"id": "4", "title": "ENGT-4573: Phase 1 - ClickHouse client library foundation",
         "status": "In Review", "status_kind": "in_progress", "workspace_id": ""},
        {"id": "7", "title": "[Audit][URGENT] Datadog API key logged in plaintext",
         "status": "In Review", "status_kind": "in_progress", "workspace_id": ""},
    ]
    captured = [("mcp.list_tasks", _ok(_BOARD_ROWS))]

    out = _recover_dropped_rows(emitted, captured)

    ids = [i["id"] for i in out]
    assert "3" in ids, "dropped row #3 must be recovered"
    assert ids == ["44", "4", "7", "3"], "existing items kept, dropped row appended"
    recovered = next(i for i in out if i["id"] == "3")
    assert recovered["title"].startswith("ENGT-4524")
    # vendor-native status preserved so the Topics panel groups it under the
    # same "In Review" column as #4 / #7.
    assert recovered["status"] == "In Review"


def test_no_change_when_llm_emitted_every_row():
    emitted = [
        {"id": "44", "title": "t", "status": "Todo", "workspace_id": ""},
        {"id": "3", "title": "t", "status": "In Review", "workspace_id": ""},
        {"id": "4", "title": "t", "status": "In Review", "workspace_id": ""},
        {"id": "7", "title": "t", "status": "In Review", "workspace_id": ""},
    ]
    captured = [("mcp.list_tasks", _ok(_BOARD_ROWS))]
    out = _recover_dropped_rows(emitted, captured)
    assert [i["id"] for i in out] == ["44", "3", "4", "7"]


def test_recovered_row_inherits_dominant_board_id_for_grouping():
    # Emitted items all share board_id "MH"; the dropped row carries no board
    # field, so it must inherit "MH" to land in the same status group rather
    # than a lonely "Other" bucket.
    emitted = [
        {"id": "4", "title": "t", "status": "In Review", "workspace_id": "MH"},
        {"id": "7", "title": "t", "status": "In Review", "workspace_id": "MH"},
    ]
    rows = [{"id": 3, "title": "dropped", "status": "In Review"}]
    out = _recover_dropped_rows(emitted, [("mcp.list_tasks", _ok(rows))])
    recovered = next(i for i in out if i["id"] == "3")
    assert recovered["board_id"] == "MH"
    assert recovered["workspace_id"] == "MH"


def test_structural_listing_tools_are_not_harvested():
    # list_boards rows have id + name but are NOT tasks; harvesting them would
    # inject phantom topics. The tool-name allow-list must exclude them.
    boards = [{"id": 1, "name": "Engineering"}, {"id": 2, "name": "Design"}]
    emitted = [{"id": "4", "title": "t", "status": "In Review", "workspace_id": ""}]
    out = _recover_dropped_rows(emitted, [("mcp.list_boards", _ok(boards))])
    assert [i["id"] for i in out] == ["4"], "no board rows injected"

    assert not _is_task_listing_tool("mcp.list_boards")
    assert not _is_task_listing_tool("mcp.list_statuses")
    assert not _is_task_listing_tool("mcp.list_sprints")
    assert not _is_task_listing_tool("mcp.search_docs")
    assert _is_task_listing_tool("mcp.list_tasks")
    assert _is_task_listing_tool("mcp.search_tasks")
    assert _is_task_listing_tool("mcp.get_task")
    assert _is_task_listing_tool("mcp.searchJiraIssuesUsingJql")


def test_jira_nested_fields_shape_recovers():
    # Jira returns {issues: [{key, fields: {summary, status: {name}}}]}.
    payload = {"issues": [
        {"key": "ENGT-4524", "fields": {
            "summary": "Review Skip backlog on restart",
            "status": {"name": "In Review"},
            "priority": {"name": "Medium"},
        }},
    ]}
    emitted = [{"id": "ENGT-4573", "title": "t", "status": "In Review",
                "workspace_id": "ENGT"}]
    out = _recover_dropped_rows(
        emitted, [("mcp.searchJiraIssuesUsingJql", _ok(payload))]
    )
    recovered = next((i for i in out if i["id"] == "ENGT-4524"), None)
    assert recovered is not None
    assert recovered["title"] == "Review Skip backlog on restart"
    assert recovered["status"] == "In Review"


def test_errored_tool_results_are_ignored():
    emitted = [{"id": "4", "title": "t", "status": "In Review", "workspace_id": ""}]
    captured = [("mcp.list_tasks", {"status": "error", "error": "boom"})]
    out = _recover_dropped_rows(emitted, captured)
    assert [i["id"] for i in out] == ["4"]


def test_extract_rows_handles_bare_array_and_wrappers():
    assert len(_extract_rows([{"id": 1, "title": "a"}, {"id": 2, "title": "b"}])) == 2
    assert len(_extract_rows({"tasks": [{"id": 1, "title": "a"}]})) == 1
    assert len(_extract_rows({"results": [{"id": 1, "title": "a"}]})) == 1
    # single-object (get_task) treated as one row when it looks task-like
    assert len(_extract_rows({"id": 9, "title": "solo"})) == 1
    # junk yields nothing
    assert _extract_rows(None) == []
    assert _extract_rows("not json") == []


@pytest.mark.asyncio
async def test_fetch_active_topics_recovers_row_llm_dropped(monkeypatch):
    """End-to-end wiring: the on_tool_result capture must feed the recovery
    pass so a row the LLM omits from its final JSON still reaches the caller.
    """
    from unittest.mock import MagicMock

    from meeting_helper.ai.agent_fetch import fetch_active_topics

    cfg = MagicMock()
    cfg.preferred_provider = "claude"
    cfg.anthropic_api_key = "k"
    cfg.claude_model = "haiku"
    cfg.copilot_instructions = ""
    cfg.copilot_learned_memory = []

    async def _stub_mcp_tools(_tracker):
        return []
    monkeypatch.setattr(
        "meeting_helper.chat.tools.mcp_passthrough.build_mcp_passthrough_tools",
        _stub_mcp_tools,
    )

    async def _stub_run_agent(*, on_tool_result, **_):
        # Simulate the agent calling list_tasks and getting all 4 board rows.
        await on_tool_result("mcp.list_tasks", _ok(_BOARD_ROWS))
        # ...then emitting a final JSON that dropped #3 (the reported bug).
        return {"text": (
            '{"items":['
            '{"id":"44","title":"ENGT-4212 Phase 2","status":"Todo","workspace_id":""},'
            '{"id":"4","title":"ENGT-4573","status":"In Review","workspace_id":""},'
            '{"id":"7","title":"Datadog audit","status":"In Review","workspace_id":""}'
            ']}'
        )}
    monkeypatch.setattr(
        "meeting_helper.chat.agent_loop.run_agent", _stub_run_agent
    )

    out = await fetch_active_topics(tracker=MagicMock(), config=cfg)
    ids = {i["id"] for i in out}
    assert ids == {"44", "4", "7", "3"}, "dropped #3 recovered through full path"
