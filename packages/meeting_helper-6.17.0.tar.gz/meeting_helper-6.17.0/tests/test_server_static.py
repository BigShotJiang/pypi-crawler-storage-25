"""Daemon static-file route tests (Plan 1 of UI migration).

The aiohttp app must serve src/meeting_helper/web/dist/ at the root path so
the new shell can load the bundled UI. The static route must not shadow any
existing API route, and unknown text/html GETs must fall back to index.html
to support client-side routing (Plan 2+).
"""

from __future__ import annotations

import pytest

from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client):
    app = create_app(AppConfig())
    return await aiohttp_client(app)


async def test_root_serves_index_html(app_client):
    resp = await app_client.get("/")
    assert resp.status == 200
    body = await resp.text()
    assert "<title>Meeting Helper</title>" in body


async def test_static_asset_served(app_client):
    """Sanity check that the daemon serves arbitrary static assets from web/dist with the right Content-Type.

    Uses `/index.txt` — a stable file Next.js's static export emits for the root route — so the test doesn't break when content-hashed JS chunk names change between builds.
    Next.js RSC payloads (index.txt) must be served as text/x-component, not text/plain.
    """
    resp = await app_client.get("/index.txt")
    assert resp.status == 200
    assert resp.headers["Content-Type"].startswith("text/x-component")


async def test_api_route_not_shadowed(app_client):
    """`/health` is an API route; the static handler must not intercept it."""
    resp = await app_client.get("/health")
    assert resp.status == 200
    body = await resp.json()
    assert isinstance(body, dict)


async def test_spa_fallback_returns_index_for_unknown_html(app_client):
    """Unknown paths with Accept: text/html return index.html (SPA routing)."""
    resp = await app_client.get(
        "/settings/providers", headers={"Accept": "text/html"}
    )
    assert resp.status == 200
    body = await resp.text()
    assert "<title>Meeting Helper</title>" in body


async def test_spa_fallback_does_not_intercept_json_requests(app_client):
    """A request that doesn't accept HTML must 404 instead of returning HTML."""
    resp = await app_client.get(
        "/api/does-not-exist", headers={"Accept": "application/json"}
    )
    assert resp.status == 404
