import pytest

from meeting_helper.chat import paths as chat_paths
from meeting_helper.chat.tools.memory import (
    build_memory_add,
    build_memory_delete,
    build_memory_read,
    build_memory_update,
)


@pytest.fixture(autouse=True)
def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


@pytest.mark.asyncio
async def test_read_all_returns_ok_with_entries():
    out = await build_memory_read().run({}, {})
    assert out["status"] == "ok"
    assert out["result"] == {"entries": []}


@pytest.mark.asyncio
async def test_add_returns_ok_with_entry():
    out = await build_memory_add().run({"text": "I like vim"}, {})
    assert out["status"] == "ok"
    assert out["result"]["text"] == "I like vim"
    assert out["result"]["source"] == "agent"
    assert out["result"]["pinned"] is False


@pytest.mark.asyncio
async def test_add_pinned():
    out = await build_memory_add().run({"text": "pin me", "pinned": True}, {})
    assert out["status"] == "ok"
    assert out["result"]["pinned"] is True


@pytest.mark.asyncio
async def test_add_missing_text_returns_error():
    out = await build_memory_add().run({}, {})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_update_returns_ok_with_entry():
    add_out = await build_memory_add().run({"text": "original"}, {})
    mid = add_out["result"]["id"]
    out = await build_memory_update().run({"id": mid, "text": "edited"}, {})
    assert out["status"] == "ok"
    assert out["result"]["text"] == "edited"


@pytest.mark.asyncio
async def test_update_missing_id_returns_error():
    out = await build_memory_update().run({}, {})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_update_unknown_returns_error():
    out = await build_memory_update().run({"id": "mem_nope", "text": "x"}, {})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_delete_returns_ok():
    add_out = await build_memory_add().run({"text": "delete me"}, {})
    mid = add_out["result"]["id"]
    out = await build_memory_delete().run({"id": mid}, {})
    assert out["status"] == "ok"
    assert out["result"] == {"deleted": mid}


@pytest.mark.asyncio
async def test_delete_missing_id_returns_error():
    out = await build_memory_delete().run({}, {})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_delete_unknown_returns_error():
    out = await build_memory_delete().run({"id": "mem_nope"}, {})
    assert out["status"] == "error"
