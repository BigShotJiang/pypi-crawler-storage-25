"""End-to-end: spin up the daemon test client + a stub provider, send a
message, assert thread state + WS events."""
import asyncio
import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from meeting_helper.chat import paths as chat_paths, handlers as chat_handlers
from meeting_helper.chat.registry import Registry


def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


@pytest.mark.asyncio
async def test_e2e_create_thread_send_message_receive_response(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)

    class _Prov:
        async def stream_completion(self, *, system, messages, tools):
            for w in ["I'", "ll ", "help."]:
                yield {"type": "chunk", "text": w}
            yield {"type": "done"}

    monkeypatch.setattr("meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _Prov())
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry", lambda: Registry())

    app = web.Application()
    app.router.add_post("/chat/threads", chat_handlers.threads_create_handler)
    app.router.add_get("/chat/threads", chat_handlers.threads_list_handler)
    app.router.add_get(r"/chat/threads/{thread_id}", chat_handlers.threads_get_handler)
    app.router.add_post(r"/chat/threads/{thread_id}/messages", chat_handlers.messages_post_handler)

    broadcasts = []
    async def _b(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _b)

    async with TestClient(TestServer(app)) as client:
        r = await client.post("/chat/threads", json={"title": "E2E"})
        thr = await r.json()
        tid = thr["id"]
        r = await client.post(f"/chat/threads/{tid}/messages", json={"text": "Hi"})
        assert r.status == 202

        # Wait for completion.
        for _ in range(40):
            await asyncio.sleep(0.05)
            if any(b["type"] == "chat.turn_done" for b in broadcasts):
                break

        r = await client.get(f"/chat/threads/{tid}")
        got = await r.json()
    chunks = [b["text"] for b in broadcasts if b["type"] == "chat.chunk"]
    assert "".join(chunks) == "I'll help."
    assistant_turns = [t for t in got["turns"] if t["role"] == "assistant"]
    assert assistant_turns[-1]["text"] == "I'll help."


@pytest.mark.asyncio
async def test_empty_completion_gets_fallback_text(monkeypatch, tmp_path):
    """Ticket #44: a turn that finishes with no text must not leave a blank
    bubble. The daemon substitutes a fallback so turn_done carries content and
    the UI clears the 'Thinking…' indicator with something visible."""
    _isolate(monkeypatch, tmp_path)

    class _Prov:
        async def stream_completion(self, *, system, messages, tools):
            # Model produced nothing — no chunks, just done.
            yield {"type": "done"}

    monkeypatch.setattr("meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _Prov())
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry", lambda: Registry())

    app = web.Application()
    app.router.add_post("/chat/threads", chat_handlers.threads_create_handler)
    app.router.add_get(r"/chat/threads/{thread_id}", chat_handlers.threads_get_handler)
    app.router.add_post(r"/chat/threads/{thread_id}/messages", chat_handlers.messages_post_handler)

    broadcasts = []
    async def _b(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _b)

    async with TestClient(TestServer(app)) as client:
        r = await client.post("/chat/threads", json={"title": "Empty"})
        tid = (await r.json())["id"]
        await client.post(f"/chat/threads/{tid}/messages", json={"text": "Hi"})
        for _ in range(40):
            await asyncio.sleep(0.05)
            if any(b["type"] == "chat.turn_done" for b in broadcasts):
                break
        got = await (await client.get(f"/chat/threads/{tid}")).json()

    done = [b for b in broadcasts if b["type"] == "chat.turn_done"]
    assert len(done) == 1
    assert done[0]["error"] is None
    assistant = [t for t in got["turns"] if t["role"] == "assistant"][-1]
    assert assistant["text"], "empty completion should get a fallback message"
    assert "rephras" in assistant["text"].lower()


@pytest.mark.asyncio
async def test_turn_done_fires_even_if_persist_fails(monkeypatch, tmp_path):
    """Ticket #44: if persisting the assistant turn raises, turn_done must
    still fire (it's what clears the indicator) and carry the error."""
    _isolate(monkeypatch, tmp_path)

    class _Prov:
        async def stream_completion(self, *, system, messages, tools):
            yield {"type": "chunk", "text": "hello"}
            yield {"type": "done"}

    monkeypatch.setattr("meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _Prov())
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry", lambda: Registry())

    # Fail only the final assistant-turn persist (the write whose payload
    # carries an assistant turn with non-empty text); thread create + user/
    # empty-assistant appends still succeed.
    orig = chat_paths.atomic_write_json

    def _selective_boom(path, data):
        turns = data.get("turns", []) if isinstance(data, dict) else []
        if any(t.get("role") == "assistant" and (t.get("text") or "") for t in turns):
            raise OSError("disk full")
        return orig(path, data)

    monkeypatch.setattr(chat_paths, "atomic_write_json", _selective_boom)

    app = web.Application()
    app.router.add_post("/chat/threads", chat_handlers.threads_create_handler)
    app.router.add_post(r"/chat/threads/{thread_id}/messages", chat_handlers.messages_post_handler)

    broadcasts = []
    async def _b(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _b)

    async with TestClient(TestServer(app)) as client:
        r = await client.post("/chat/threads", json={"title": "Persist"})
        tid = (await r.json())["id"]
        await client.post(f"/chat/threads/{tid}/messages", json={"text": "Hi"})
        for _ in range(40):
            await asyncio.sleep(0.05)
            if any(b["type"] == "chat.turn_done" for b in broadcasts):
                break

    done = [b for b in broadcasts if b["type"] == "chat.turn_done"]
    assert len(done) == 1, "turn_done must fire even when persistence fails"
    assert done[0]["error"] and "disk full" in done[0]["error"]


@pytest.mark.asyncio
async def test_cancel_stops_turn_and_persists_partial(monkeypatch, tmp_path):
    """Ticket #39: the Stop button cancels the in-flight turn; the partial
    answer is persisted with a stopped marker and turn_done fires cleanly."""
    _isolate(monkeypatch, tmp_path)
    started = asyncio.Event()

    class _Prov:
        async def stream_completion(self, *, system, messages, tools):
            yield {"type": "chunk", "text": "partial answer"}
            started.set()
            await asyncio.sleep(30)  # block until the turn is cancelled
            yield {"type": "done"}

    monkeypatch.setattr("meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _Prov())
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry", lambda: Registry())

    app = web.Application()
    app.router.add_post("/chat/threads", chat_handlers.threads_create_handler)
    app.router.add_get(r"/chat/threads/{thread_id}", chat_handlers.threads_get_handler)
    app.router.add_post(r"/chat/threads/{thread_id}/messages", chat_handlers.messages_post_handler)
    app.router.add_post(r"/chat/threads/{thread_id}/cancel", chat_handlers.messages_cancel_handler)

    broadcasts = []
    async def _b(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _b)

    async with TestClient(TestServer(app)) as client:
        tid = (await (await client.post("/chat/threads", json={"title": "C"})).json())["id"]
        await client.post(f"/chat/threads/{tid}/messages", json={"text": "go"})
        await asyncio.wait_for(started.wait(), timeout=2)
        r = await client.post(f"/chat/threads/{tid}/cancel")
        assert r.status == 200
        for _ in range(40):
            await asyncio.sleep(0.05)
            if any(b["type"] == "chat.turn_done" for b in broadcasts):
                break
        got = await (await client.get(f"/chat/threads/{tid}")).json()

    done = [b for b in broadcasts if b["type"] == "chat.turn_done"]
    assert len(done) == 1
    assert done[0]["error"] is None
    assistant = [t for t in got["turns"] if t["role"] == "assistant"][-1]
    assert "partial answer" in assistant["text"]
    assert "stopped" in assistant["text"].lower()


@pytest.mark.asyncio
async def test_cancel_with_no_running_turn_returns_404(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    app = web.Application()
    app.router.add_post("/chat/threads", chat_handlers.threads_create_handler)
    app.router.add_post(r"/chat/threads/{thread_id}/cancel", chat_handlers.messages_cancel_handler)

    async with TestClient(TestServer(app)) as client:
        tid = (await (await client.post("/chat/threads", json={"title": "C"})).json())["id"]
        r = await client.post(f"/chat/threads/{tid}/cancel")
        assert r.status == 404
