"""AppConfig.local_todo_configured must return True whenever any tracker
is active, regardless of vendor. The Brief panel + topic picker read this
gate; if it only checks the legacy local_todo_mcp block, OAuth vendors
(Jira, Notion, Linear, etc.) silently hide the Brief button."""
from meeting_helper.config import AppConfig


def test_local_todo_configured_true_when_active_tracker_set():
    cfg = AppConfig(
        trackers=[{
            "id": "jir-x",
            "vendor": "jira",
            "label": "Jira",
            "transport": {"type": "http", "url": "https://mcp.atlassian.com/v1/sse", "headers": {}},
            "auth_values": {"url": "https://mcp.atlassian.com/v1/sse"},
            "secret_keys": [],
        }],
        active_tracker_id="jir-x",
    )
    assert cfg.local_todo_configured is True


def test_local_todo_configured_false_when_no_active_tracker():
    cfg = AppConfig()
    assert cfg.local_todo_configured is False


def test_local_todo_configured_back_compat_with_legacy_http_block():
    """Pre-migration: a legacy http local_todo_mcp block also counts."""
    cfg = AppConfig(local_todo_mcp={"type": "http", "url": "https://example/mcp"})
    assert cfg.local_todo_configured is True


def test_local_todo_configured_back_compat_with_legacy_stdio_block():
    cfg = AppConfig(local_todo_mcp={"type": "stdio", "command": "npx"})
    assert cfg.local_todo_configured is True
