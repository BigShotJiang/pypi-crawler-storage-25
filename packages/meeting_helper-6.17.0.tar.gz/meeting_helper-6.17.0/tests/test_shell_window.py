"""Tests for shell.window — verify the pywebview create_window call shape."""

from __future__ import annotations

from unittest.mock import MagicMock, patch


def _make_appkit(visible_frame, *, has_main_screen=True):
    """Build a fake AppKit module whose mainScreen().visibleFrame() returns
    the given (origin_x, origin_y, width, height) tuple. When
    has_main_screen is False, mainScreen() returns None.
    """
    ox, oy, w, h = visible_frame

    class _Size:
        width = w
        height = h

    class _Origin:
        x = ox
        y = oy

    class _Frame:
        size = _Size()
        origin = _Origin()

    fake_screen = MagicMock()
    fake_screen.visibleFrame = MagicMock(return_value=_Frame())
    fake_nsscreen = MagicMock()
    fake_nsscreen.mainScreen = MagicMock(return_value=fake_screen if has_main_screen else None)
    return MagicMock(NSScreen=fake_nsscreen)


def test_create_window_fills_visible_frame_when_appkit_available():
    """When AppKit's visibleFrame is healthy, the window fills the work area."""
    fake_webview = MagicMock()
    fake_appkit = _make_appkit((0, 0, 1920, 1055))

    with patch.dict("sys.modules", {"webview": fake_webview, "AppKit": fake_appkit}):
        from meeting_helper.shell import window

        window.create_window(url="http://127.0.0.1:9876/")

    fake_webview.create_window.assert_called_once()
    args, kwargs = fake_webview.create_window.call_args
    assert args[0] == "Meeting Helper"
    assert (len(args) >= 2 and args[1] == "http://127.0.0.1:9876/") or (
        kwargs.get("url") == "http://127.0.0.1:9876/"
    )
    assert kwargs.get("width") == 1920
    assert kwargs.get("height") == 1055
    assert kwargs.get("x") == 0
    assert kwargs.get("y") == 0
    assert kwargs.get("min_size") == (900, 600)
    assert kwargs.get("resizable") is True
    assert kwargs.get("text_select") is True


def test_create_window_uses_origin_from_visible_frame():
    """The origin from visibleFrame (e.g. dock-shifted) is passed through to
    pywebview as x/y."""
    fake_webview = MagicMock()
    fake_appkit = _make_appkit((0, 23, 1920, 1055))

    with patch.dict("sys.modules", {"webview": fake_webview, "AppKit": fake_appkit}):
        from meeting_helper.shell import window

        window.create_window(url="http://127.0.0.1:1/")

    _args, kwargs = fake_webview.create_window.call_args
    assert kwargs.get("width") == 1920
    assert kwargs.get("height") == 1055
    assert kwargs.get("x") == 0
    assert kwargs.get("y") == 23


def test_create_window_falls_back_when_visible_frame_is_zero():
    """visibleFrame returning a zero-sized rect falls back to 1200x800 centered."""
    fake_webview = MagicMock()
    fake_appkit = _make_appkit((0, 0, 0, 0))

    with patch.dict("sys.modules", {"webview": fake_webview, "AppKit": fake_appkit}):
        from meeting_helper.shell import window

        window.create_window(url="http://127.0.0.1:1/")

    _args, kwargs = fake_webview.create_window.call_args
    assert kwargs.get("width") == 1200
    assert kwargs.get("height") == 800
    # With no usable screen size we cannot compute a center, so x/y should
    # be omitted and pywebview's default positioning kicks in.
    assert "x" not in kwargs
    assert "y" not in kwargs


def test_create_window_falls_back_when_screen_is_none():
    """If AppKit returns no main screen, fall back to 1200x800 with no x/y."""
    fake_webview = MagicMock()
    fake_appkit = _make_appkit((0, 0, 1920, 1055), has_main_screen=False)

    with patch.dict("sys.modules", {"webview": fake_webview, "AppKit": fake_appkit}):
        from meeting_helper.shell import window

        window.create_window(url="http://127.0.0.1:1/")

    _args, kwargs = fake_webview.create_window.call_args
    assert kwargs.get("width") == 1200
    assert kwargs.get("height") == 800
    assert "x" not in kwargs
    assert "y" not in kwargs


def test_create_window_falls_back_when_appkit_unavailable():
    """When AppKit can't be imported, fall back to 1200x800 with no x/y."""
    fake_webview = MagicMock()

    import builtins

    real_import = builtins.__import__

    def _fake_import(name, *args, **kwargs):
        if name == "AppKit":
            raise ImportError("AppKit not available")
        return real_import(name, *args, **kwargs)

    with patch.dict("sys.modules", {"webview": fake_webview}):
        # Make sure any cached AppKit module is gone so the import path runs.
        with patch.dict("sys.modules", {"AppKit": None}):
            with patch("builtins.__import__", side_effect=_fake_import):
                from meeting_helper.shell import window

                window.create_window(url="http://127.0.0.1:1/")

    _args, kwargs = fake_webview.create_window.call_args
    assert kwargs.get("width") == 1200
    assert kwargs.get("height") == 800
    assert "x" not in kwargs
    assert "y" not in kwargs
