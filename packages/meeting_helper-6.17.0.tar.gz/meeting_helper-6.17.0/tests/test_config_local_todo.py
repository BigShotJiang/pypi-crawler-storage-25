"""Round-trip + migration tests for the local_todo_mcp config field.

NOTE: The `local_todo_mcp` property is a deprecated back-compat shim.
LocalTodoProfile now uses HTTP+OAuth (url field only). Legacy stdio installs
are dropped on migration; legacy HTTP installs migrate with the url field.
"""

from __future__ import annotations

import json

from meeting_helper.config import Config


def test_config_round_trips_http(tmp_path):
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    config.local_todo_mcp = {
        "type": "http",
        "command": "",
        "args": [],
        "env": {},
        "url": "http://vcloud.local/local-todo/mcp",
        "headers": {"Authorization": "Bearer ltb_xxxx"},
    }
    config.save()

    reloaded = Config(cfg_path)
    cfg = reloaded.local_todo_mcp
    assert cfg["type"] == "http"
    assert cfg["url"] == "http://vcloud.local/local-todo/mcp"
    assert cfg["headers"] == {"Authorization": "Bearer ltb_xxxx"}


def test_config_default_local_todo(tmp_path):
    """A fresh config has no local_todo_mcp legacy key and no trackers yet.
    The getter returns the empty sentinel."""
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    cfg = config.local_todo_mcp
    # No tracker configured — returns empty sentinel.
    assert cfg["type"] in ("stdio", "http")
    assert cfg.get("command", "") == "" or cfg["type"] == "http"


def test_config_migrates_legacy_flat_list(tmp_path):
    """Legacy flat-list command → stored as local_todo_mcp stdio shape.
    With the new migration, stdio drops the tracker (can't derive OAuth URL).
    """
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({"local_todo_mcp_command": ["npx", "@old/pkg"]}))
    config = Config(cfg_path)
    # Migration: stdio → trackers=[], active_tracker_id=None
    assert config.trackers == []
    assert config.active_tracker_id is None


def test_config_detects_http_when_url_present_but_type_missing(tmp_path):
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps({
        "local_todo_mcp": {"url": "http://x/mcp", "headers": {"Authorization": "Bearer y"}}
    }))
    config = Config(cfg_path)
    cfg = config.local_todo_mcp
    assert cfg["type"] == "http"
    assert cfg["url"] == "http://x/mcp"


def test_config_back_compat_command_property_returns_empty_for_oauth_http(tmp_path):
    """local_todo_mcp_command is always empty for HTTP/OAuth trackers."""
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    config.local_todo_mcp = {"type": "http", "url": "http://x/mcp"}
    assert config.local_todo_mcp_command == []


def test_config_command_property_returns_empty_for_http(tmp_path):
    cfg_path = tmp_path / "config.json"
    config = Config(cfg_path)
    config.local_todo_mcp = {"type": "http", "url": "http://x/mcp"}
    assert config.local_todo_mcp_command == []
