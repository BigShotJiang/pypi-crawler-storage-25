"""Background paths (workspace switch pre-warm, chat passthrough build,
Test connection) must NEVER pop a browser. Only the explicit Connect button
is allowed to trigger interactive OAuth.

Without this guard, every workspace switch on a workspace with expired
refresh tokens opens an OAuth browser tab unsolicited — the user came to
look at messages, the daemon hijacks their screen.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from meeting_helper.trackers.tracker import Tracker, InteractiveOAuthRequired


def _oauth_profile():
    """A minimal vendor profile in mcp_oauth mode."""
    p = MagicMock()
    p.auth_mode = "mcp_oauth"
    return p


@pytest.mark.asyncio
async def test_non_interactive_redirect_handler_raises_instead_of_opening_browser(monkeypatch):
    """When the Tracker is constructed with interactive_oauth=False, the SDK's
    redirect handler must raise InteractiveOAuthRequired rather than calling
    open_browser. This is the load-bearing invariant for pre-warm / chat /
    test paths."""
    transport = {"type": "http", "url": "https://mcp.example/mcp", "headers": {}}
    t = Tracker(
        profile=_oauth_profile(),
        transport=transport,
        oauth_workspace="W",
        oauth_tracker_id="t-1",
        interactive_oauth=False,
    )

    # Capture the redirect_handler the Tracker hands to build_oauth_provider.
    captured = {}

    def _fake_build(*, redirect_handler, callback_handler, **kwargs):
        captured["redirect_handler"] = redirect_handler
        captured["callback_handler"] = callback_handler
        return MagicMock()  # not actually used past capture

    # Patch everything downstream of the redirect_handler capture so we
    # don't need a real MCP server.
    monkeypatch.setattr("meeting_helper.trackers.oauth.build_oauth_provider", _fake_build)
    monkeypatch.setattr("meeting_helper.trackers.oauth.open_browser",
                        MagicMock(side_effect=AssertionError("open_browser must not be called in passive mode")))

    # Patch LocalCallbackServer to a no-op so we don't actually bind a socket.
    class _NoopCBServer:
        redirect_url = "http://127.0.0.1:9999/callback"
        async def start(self): pass
        async def stop(self): pass
        async def wait_for_code(self, timeout=300.0):  # noqa: ARG002
            raise AssertionError("wait_for_code must not be called in passive mode")
    monkeypatch.setattr("meeting_helper.trackers.oauth.LocalCallbackServer", _NoopCBServer)

    # Patch the SSE/streamable_http client so we hit the auth construction
    # path and then bail before touching the network.
    class _FailSession:
        async def __aenter__(self): raise RuntimeError("intentional: stop after auth set up")
        async def __aexit__(self, *_a): return False
    monkeypatch.setattr("mcp.client.streamable_http.streamablehttp_client",
                        lambda *a, **kw: _FailSession())

    with pytest.raises(RuntimeError, match="intentional"):
        await t._ensure_started()

    # The Tracker's redirect_handler was captured. Calling it must raise,
    # not open a browser.
    assert "redirect_handler" in captured, "redirect_handler was never wired up"
    with pytest.raises(InteractiveOAuthRequired):
        await captured["redirect_handler"]("https://example.com/authorize?...")
    with pytest.raises(InteractiveOAuthRequired):
        await captured["callback_handler"]()


@pytest.mark.asyncio
async def test_interactive_redirect_handler_calls_open_browser_as_before(monkeypatch):
    """Regression guard — interactive_oauth=True (the Connect button path)
    must still open a browser via open_browser."""
    transport = {"type": "http", "url": "https://mcp.example/mcp", "headers": {}}
    t = Tracker(
        profile=_oauth_profile(),
        transport=transport,
        oauth_workspace="W",
        oauth_tracker_id="t-2",
        interactive_oauth=True,
    )

    captured = {}
    def _fake_build(*, redirect_handler, callback_handler, **kwargs):
        captured["redirect_handler"] = redirect_handler
        captured["callback_handler"] = callback_handler
        return MagicMock()
    monkeypatch.setattr("meeting_helper.trackers.oauth.build_oauth_provider", _fake_build)
    open_browser_calls = []
    monkeypatch.setattr("meeting_helper.trackers.oauth.open_browser",
                        lambda url: open_browser_calls.append(url))

    class _NoopCBServer:
        redirect_url = "http://127.0.0.1:9999/callback"
        async def start(self): pass
        async def stop(self): pass
        async def wait_for_code(self, timeout=300.0):  # noqa: ARG002
            return ("code-123", "state-abc")
    monkeypatch.setattr("meeting_helper.trackers.oauth.LocalCallbackServer", _NoopCBServer)

    class _FailSession:
        async def __aenter__(self): raise RuntimeError("intentional")
        async def __aexit__(self, *_a): return False
    monkeypatch.setattr("mcp.client.streamable_http.streamablehttp_client",
                        lambda *a, **kw: _FailSession())

    with pytest.raises(RuntimeError, match="intentional"):
        await t._ensure_started()

    # Calling the captured handler opens the browser (does NOT raise).
    await captured["redirect_handler"]("https://example.com/authorize?...")
    assert open_browser_calls == ["https://example.com/authorize?..."]


@pytest.mark.asyncio
async def test_passthrough_evicts_failed_session_so_next_turn_retries(monkeypatch):
    """When a chat passthrough build fails with InteractiveOAuthRequired,
    the half-built session must be evicted from the registry. Otherwise
    every subsequent chat turn reuses the broken session and re-raises."""
    from meeting_helper.chat.tools import mcp_passthrough as mp
    from types import SimpleNamespace

    fake_failed_tracker = MagicMock()
    fake_failed_tracker._ensure_started = AsyncMock(side_effect=InteractiveOAuthRequired("needs re-auth"))

    reg = MagicMock()
    reg.chat_enabled_ids = MagicMock(return_value=["t-1"])
    reg.ensure_session = AsyncMock(return_value=fake_failed_tracker)
    reg.shutdown = AsyncMock()

    config = SimpleNamespace(trackers=[{"id": "t-1", "label": "Jira", "chat_enabled": True}])

    # Silence broadcasts.
    import meeting_helper.server.websocket as ws
    monkeypatch.setattr(ws, "broadcast", AsyncMock())

    tools = await mp.build_mcp_passthrough_tools_multi(reg, config, workspace_name="W")
    assert tools == []
    reg.shutdown.assert_awaited_once_with("t-1")
