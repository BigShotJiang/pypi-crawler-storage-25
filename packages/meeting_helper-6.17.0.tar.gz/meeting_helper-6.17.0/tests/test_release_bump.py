"""Unit tests for scripts/release_bump.py.

The script is intentionally dependency-free so we import its module-level
helpers directly and feed them synthetic commit histories.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

SPEC_PATH = Path(__file__).resolve().parent.parent / "scripts" / "release_bump.py"


@pytest.fixture(scope="module")
def bump_module():
    spec = importlib.util.spec_from_file_location("release_bump", SPEC_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules["release_bump"] = module
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize(
    "subject,body,expected",
    [
        # User-facing types -> release
        ("feat: add picker", "", "minor"),
        ("feat(scope): add picker", "", "minor"),
        ("fix: stop crash", "", "patch"),
        ("fix(scope): stop crash", "", "patch"),
        ("perf: faster query", "", "patch"),
        # Internal-only types -> no release
        ("chore: bump deps", "", None),
        ("docs: update README", "", None),
        ("refactor: split module", "", None),
        ("test: add coverage", "", None),
        ("ci: pin runner", "", None),
        ("build: switch to uv", "", None),
        ("style: format", "", None),
        ("revert: undo feat", "", None),
        # `!` or BREAKING CHANGE still wins, even on internal types
        ("feat!: drop legacy api", "", "major"),
        ("fix!: change return type", "", "major"),
        ("docs!: rewrite migration guide", "", "major"),
        ("revert!: undo major feat", "", "major"),
        ("chore: deprecation", "BREAKING CHANGE: removed v1 endpoint", "major"),
        ("feat: change api", "BREAKING CHANGE: removed v1 endpoint", "major"),
        # Non-conformant -> no release (pr-title-lint blocks these anyway)
        ("just a plain message", "", None),
        # Skip markers
        ("Bump version to 5.0.2", "", None),
        ("chore: housekeeping [skip ci]", "", None),
        ("feat: but skip [skip ci]", "", None),
    ],
)
def test_classify(bump_module, subject, body, expected):
    assert bump_module.classify(subject, body) == expected


def test_decide_bump_picks_highest_rank(bump_module):
    commits = [
        ("fix: a", ""),
        ("feat: b", ""),
        ("docs: c", ""),
    ]
    bump, eligible = bump_module.decide_bump(commits)
    # `docs: c` is now a no-release type, so it doesn't appear in `eligible`.
    # `fix` (patch) and `feat` (minor) both qualify; highest wins.
    assert bump == "minor"
    assert {kind for _, kind in eligible} == {"patch", "minor"}


def test_decide_bump_returns_none_when_only_skip_commits(bump_module):
    commits = [
        ("Bump version to 1.2.3", ""),
        ("chore: silence [skip ci]", ""),
    ]
    bump, eligible = bump_module.decide_bump(commits)
    assert bump is None
    assert eligible == []


def test_decide_bump_returns_none_when_only_internal_types(bump_module):
    """A release window that only contains docs/chore/ci/refactor/test/style
    work must NOT publish a new PyPI version - the workflow's
    `if: outputs.new_version != ''` guard short-circuits on the empty
    output."""
    commits = [
        ("docs: update README", ""),
        ("chore: bump dev deps", ""),
        ("ci: tighten cache key", ""),
        ("test: more coverage", ""),
        ("refactor: split module", ""),
    ]
    bump, eligible = bump_module.decide_bump(commits)
    assert bump is None
    assert eligible == []


def test_decide_bump_one_fix_among_internal_types_still_releases_patch(bump_module):
    """A single user-facing commit in an otherwise internal-only range
    still triggers a release for that one change."""
    commits = [
        ("docs: update README", ""),
        ("fix: tighten parser", ""),
        ("chore: bump deps", ""),
    ]
    bump, eligible = bump_module.decide_bump(commits)
    assert bump == "patch"
    assert [(s, k) for s, k in eligible] == [("fix: tighten parser", "patch")]


def test_decide_bump_breaking_wins_over_feat(bump_module):
    commits = [
        ("feat: small", ""),
        ("feat!: api removed", ""),
    ]
    bump, _ = bump_module.decide_bump(commits)
    assert bump == "major"


@pytest.mark.parametrize(
    "version,bump,expected",
    [
        ("5.0.1", "patch", "5.0.2"),
        ("5.0.1", "minor", "5.1.0"),
        ("5.0.1", "major", "6.0.0"),
        ("5.4.9", "minor", "5.5.0"),
        ("0.9.0", "major", "1.0.0"),
    ],
)
def test_apply_bump(bump_module, version, bump, expected):
    assert bump_module.apply_bump(version, bump) == expected


def test_apply_bump_rejects_garbage(bump_module):
    with pytest.raises(SystemExit):
        bump_module.parse_version("not.a.version")


def test_build_changelog_groups_by_section(bump_module):
    eligible = [
        ("feat: x", "minor"),
        ("fix: y", "patch"),
        ("feat!: z", "major"),
    ]
    out = bump_module.build_changelog("6.0.0", eligible)
    assert "Release v6.0.0" in out
    assert "Breaking changes:" in out
    assert "- feat!: z" in out
    assert "New features:" in out
    assert "- feat: x" in out
    assert "Fixes and chores:" in out
    assert "- fix: y" in out


def test_build_changelog_handles_only_one_section(bump_module):
    eligible = [("fix: y", "patch")]
    out = bump_module.build_changelog("5.0.2", eligible)
    assert "Release v5.0.2" in out
    assert "Fixes and chores:" in out
    assert "Breaking changes:" not in out
    assert "New features:" not in out


def test_build_changelog_no_eligible_falls_back_to_plain(bump_module):
    assert bump_module.build_changelog("5.0.2", []) == "Release v5.0.2"


def test_main_refuses_to_release_when_no_tag(bump_module, monkeypatch, capsys, tmp_path):
    """First-ever run must not auto-release: years of history can include
    `feat!:` or BREAKING CHANGE markers that would otherwise jump major."""
    monkeypatch.setattr(bump_module, "read_current_version", lambda: "5.0.1")
    monkeypatch.setattr(bump_module, "last_tag", lambda: None)

    def _explode(_tag):
        raise AssertionError("commits_since must not be called when no tag exists")

    monkeypatch.setattr(bump_module, "commits_since", _explode)

    output_file = tmp_path / "gh-output"
    monkeypatch.setenv("GITHUB_OUTPUT", str(output_file))

    rc = bump_module.main(["--dry-run"])
    assert rc == 0
    rendered = output_file.read_text()
    assert "new_version=" in rendered
    # No version is emitted, so the workflow's `if:` guard short-circuits.
    assert "new_version=\n" in rendered or rendered.rstrip().endswith("new_version=")


def test_main_emits_outputs_on_normal_run(bump_module, monkeypatch, tmp_path):
    monkeypatch.setattr(bump_module, "read_current_version", lambda: "5.0.1")
    monkeypatch.setattr(bump_module, "last_tag", lambda: "v5.0.1")
    monkeypatch.setattr(
        bump_module,
        "commits_since",
        lambda _tag: [("feat: new picker", ""), ("fix: tiny", "")],
    )
    monkeypatch.setattr(bump_module, "write_version", lambda _v: None)

    output_file = tmp_path / "gh-output"
    monkeypatch.setenv("GITHUB_OUTPUT", str(output_file))

    rc = bump_module.main(["--dry-run"])
    assert rc == 0
    rendered = output_file.read_text()
    assert "new_version=5.1.0" in rendered
    assert "bump=minor" in rendered
    assert "previous_version=5.0.1" in rendered
    # Multi-line changelog uses heredoc framing.
    assert "changelog<<__END__" in rendered
