from meeting_helper.config import Config


def test_dev_mode_defaults_off(tmp_path):
    cfg = Config(tmp_path / "ws.json")
    assert cfg.dev_mode is False
    assert cfg.dev_repos == []


def test_dev_repos_roundtrip(tmp_path):
    cfg = Config(tmp_path / "ws.json")
    cfg.dev_mode = True
    cfg.dev_repos = [{"path": "/tmp/r", "base_branch": "main"}]
    cfg.save()
    reloaded = Config(tmp_path / "ws.json")
    assert reloaded.dev_mode is True
    assert reloaded.dev_repos == [{"path": "/tmp/r", "base_branch": "main"}]


def test_dev_repos_normalizes_missing_base(tmp_path):
    cfg = Config(tmp_path / "ws.json")
    cfg.dev_repos = [{"path": "/tmp/r"}, {"base_branch": "main"}]  # 2nd has no path
    assert cfg.dev_repos == [{"path": "/tmp/r", "base_branch": "main"}]


def test_app_config_carries_dev_fields(tmp_path):
    cfg = Config(tmp_path / "ws.json")
    cfg.dev_mode = True
    cfg.dev_repos = [{"path": "/tmp/r", "base_branch": "dev"}]
    app = cfg.to_app_config()
    assert app.dev_mode is True
    assert app.dev_repos == [{"path": "/tmp/r", "base_branch": "dev"}]
