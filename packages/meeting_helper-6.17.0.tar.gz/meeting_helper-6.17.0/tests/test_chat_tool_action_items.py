"""Chat agent tools for action items: list / create / update / complete / delete."""
from __future__ import annotations

import asyncio

import pytest

from meeting_helper.action_items import models, store
from meeting_helper.chat.tools.action_items import (
    build_complete_action_item,
    build_create_action_item,
    build_delete_action_item,
    build_list_action_items,
    build_update_action_item,
)


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    recordings = tmp_path / "recordings"
    recordings.mkdir()
    ws_json = tmp_path / "ws.json"
    monkeypatch.setattr(
        "meeting_helper.chat.tools.action_items._resolve_paths",
        lambda ctx: (recordings, ws_json),
    )
    return recordings, ws_json


def test_create_then_list(workspace):
    create = build_create_action_item().run
    out = asyncio.run(create({"title": "T"}, {}))
    assert out["status"] == "ok"
    assert out["result"]["item"]["title"] == "T"

    listed = asyncio.run(build_list_action_items().run({}, {}))
    titles = [i["title"] for i in listed["result"]["items"]]
    assert titles == ["T"]


def test_create_into_meeting_persists_to_sidecar(workspace):
    recordings, _ws_json = workspace
    out = asyncio.run(
        build_create_action_item().run(
            {"title": "M1", "meeting_id": "m1"}, {}
        )
    )
    assert out["status"] == "ok"
    assert out["result"]["item"]["meeting_id"] == "m1"
    assert [i["title"] for i in store.load(recordings, "m1")] == ["M1"]


def test_create_empty_title_errors(workspace):
    out = asyncio.run(build_create_action_item().run({"title": "  "}, {}))
    assert out["status"] == "error"


def test_status_filter(workspace):
    _recordings, ws_json = workspace
    open_item = models.new_item(title="open")
    done = models.new_item(title="done")
    done["completed"] = True
    store.save_orphans(ws_json, [open_item, done])

    res_open = asyncio.run(
        build_list_action_items().run({"status": "open"}, {})
    )
    assert [i["title"] for i in res_open["result"]["items"]] == ["open"]

    res_done = asyncio.run(
        build_list_action_items().run({"status": "completed"}, {})
    )
    assert [i["title"] for i in res_done["result"]["items"]] == ["done"]

    res_all = asyncio.run(
        build_list_action_items().run({"status": "all"}, {})
    )
    titles = sorted(i["title"] for i in res_all["result"]["items"])
    assert titles == ["done", "open"]


def test_meeting_id_filter(workspace):
    recordings, ws_json = workspace
    a = models.new_item(title="A", meeting_id="m1")
    b = models.new_item(title="B", meeting_id="m2")
    store.save(recordings, "m1", [a])
    store.save(recordings, "m2", [b])
    out = asyncio.run(
        build_list_action_items().run({"meeting_id": "m1"}, {})
    )
    titles = [i["title"] for i in out["result"]["items"]]
    assert titles == ["A"]


def test_update_and_complete_and_delete(workspace):
    _recordings, ws_json = workspace
    item = models.new_item(title="t")
    store.save_orphans(ws_json, [item])

    upd = asyncio.run(
        build_update_action_item().run(
            {"id": item["id"], "title": "renamed"}, {}
        )
    )
    assert upd["result"]["item"]["title"] == "renamed"

    comp = asyncio.run(
        build_complete_action_item().run({"id": item["id"]}, {})
    )
    assert comp["result"]["item"]["completed"] is True

    rm = asyncio.run(build_delete_action_item().run({"id": item["id"]}, {}))
    assert rm["status"] == "ok"
    assert store.load_orphans(ws_json) == []


def test_unknown_id_returns_error(workspace):
    out = asyncio.run(
        build_update_action_item().run({"id": "ai_x", "title": "y"}, {})
    )
    assert out["status"] == "error"

    out_del = asyncio.run(
        build_delete_action_item().run({"id": "ai_x"}, {})
    )
    assert out_del["status"] == "error"


def test_builders_register_with_correct_names_and_mutation_flags():
    list_tool = build_list_action_items()
    assert list_tool.name == "action_items.list"
    assert list_tool.is_mutation is False
    for builder, mutation_name in (
        (build_create_action_item, "action_items.create"),
        (build_update_action_item, "action_items.update"),
        (build_complete_action_item, "action_items.complete"),
        (build_delete_action_item, "action_items.delete"),
    ):
        t = builder()
        assert t.name == mutation_name
        assert t.is_mutation is True


def test_registry_includes_action_items_tools():
    """The chat agent registry should ship the action-items tools out of the
    box, otherwise the agent can't reach them at runtime."""
    from meeting_helper.chat.handlers import _build_registry

    reg = _build_registry()
    names = {t.name for t in reg.tools()}
    assert {
        "action_items.list",
        "action_items.create",
        "action_items.update",
        "action_items.complete",
        "action_items.delete",
    }.issubset(names)


def test_resolve_paths_reads_ctx_keys_set_by_chat_handler(tmp_path):
    """Reproduces the runtime ctx shape `messages_post_handler` builds.

    The original ctx dict in `handlers.py` had `config` but no `disk`, so
    every action_items chat tool errored with `chat tool ctx missing
    config/disk` when invoked through the real agent loop. Existing tests
    monkeypatched `_resolve_paths` and so never noticed. This test makes
    sure the helper accepts the dict-shape the dispatcher actually
    populates today, and that the bare keys it needs (`config`, `disk`)
    are both present.
    """
    from meeting_helper.chat.tools.action_items import _resolve_paths

    class _Cfg:
        recordings_dir = str(tmp_path / "recordings")

    class _Disk:
        config_path = tmp_path / "ws.json"

    recordings, ws_json = _resolve_paths({"config": _Cfg(), "disk": _Disk()})
    assert recordings == _Cfg().recordings_dir or str(recordings) == _Cfg().recordings_dir
    assert ws_json == _Disk().config_path


def test_chat_handler_ctx_populates_disk_for_tools():
    """End-to-end check on the dispatcher's ctx shape: `messages_post_handler`
    must put a Config-shaped object under `ctx['disk']` so action_items tools
    can resolve the workspace JSON path. Catches the v6.0.0 regression where
    the chat agent reported `chat tool ctx missing config/disk` on every
    action_items.* call."""
    import inspect
    from meeting_helper.chat import handlers

    src = inspect.getsource(handlers.messages_post_handler)
    # The handler must seed `disk` (any spelling) into the ctx dict it passes
    # to run_agent. The simplest reliable signal is that the ctx literal
    # references the key.
    assert '"disk"' in src or "'disk'" in src, (
        "messages_post_handler must populate ctx['disk'] so action_items chat "
        "tools can resolve the workspace JSON path"
    )
