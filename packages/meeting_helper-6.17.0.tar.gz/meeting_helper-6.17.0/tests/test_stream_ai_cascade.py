"""Tests for the _stream_ai orchestrator and provider generators."""

from __future__ import annotations

import asyncio

import pytest

from meeting_helper.config import AppConfig
from meeting_helper.state import AppState


@pytest.fixture
def captured_broadcasts(monkeypatch):
    """Capture every broadcast(...) call from ai.client during a test."""
    msgs: list[dict] = []

    async def _fake_broadcast(m: dict) -> None:
        msgs.append(m)

    import meeting_helper.server.websocket as ws
    monkeypatch.setattr(ws, "broadcast", _fake_broadcast)
    return msgs


async def _gen_from(deltas, *, first_token_delay=0.0, error=None):
    """Build an async-generator factory matching the _stream_*_gen signature
    `async def f(state, config, messages, system_prompt)` that yields `deltas`,
    waiting `first_token_delay` s before the first one, and optionally raising
    `error` instead of yielding anything."""
    async def _factory(state, config, messages, system_prompt):
        if first_token_delay:
            await asyncio.sleep(first_token_delay)
        if error is not None:
            raise error
        for d in deltas:
            yield d
    return _factory


# ---------------------------------------------------------------------------
# Task 3: provider-generator test for Claude
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_claude_gen_raises_without_key():
    from meeting_helper.ai import client as c
    from meeting_helper.config import AppConfig
    from meeting_helper.state import AppState
    config = AppConfig(anthropic_api_key="")
    with pytest.raises(RuntimeError):
        async for _ in c._stream_claude_gen(AppState(), config, [{"role": "user", "content": "hi"}], "sys"):
            pass


# ---------------------------------------------------------------------------
# Task 5 tests — _PROVIDER_GENERATORS cascade + new wire messages
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_single_provider_streams_and_broadcasts(captured_broadcasts, monkeypatch):
    from meeting_helper.ai import client as c

    state = AppState()
    config = AppConfig(anthropic_api_key="sk-x", ai_provider_order=["anthropic"], ai_failover_delay_ms=2000)

    fake = await _gen_from(["Hello", " world"])
    monkeypatch.setattr(c, "_PROVIDER_GENERATORS", {"anthropic": ("Claude", fake)}, raising=False)

    out = await c._stream_ai(state, config, messages=[{"role": "user", "content": "hi"}], system_prompt="sys", kind="query")
    assert out == "Hello world"

    types = [m["type"] for m in captured_broadcasts]
    assert "answer_open" in types
    chunks = [m for m in captured_broadcasts if m["type"] == "chunk"]
    assert "".join(m["text"] for m in chunks) == "Hello world"
    assert all("answer_id" in m for m in chunks)
    assert any(m["type"] == "done" for m in captured_broadcasts)
    assert any(m["type"] == "all_done" for m in captured_broadcasts)


def _provider_table(**factories):
    """{'anthropic': ('Claude', factory), ...} — labels are cosmetic."""
    labels = {"anthropic": "Claude", "google": "Gemini", "local": "Local"}
    return {k: (labels.get(k, k.title()), f) for k, f in factories.items()}


@pytest.mark.asyncio
async def test_primary_fast_no_second_provider(captured_broadcasts, monkeypatch):
    from meeting_helper.ai import client as c
    state, config = AppState(), AppConfig(
        anthropic_api_key="x", google_api_key="y",
        ai_provider_order=["anthropic", "google"], ai_failover_delay_ms=200)
    a = await _gen_from(["A1", "A2"], first_token_delay=0.0)
    b_started = {"v": False}
    async def b_factory(*args):
        b_started["v"] = True
        yield "B1"
    monkeypatch.setattr(c, "_PROVIDER_GENERATORS", _provider_table(anthropic=a, google=b_factory), raising=False)
    out = await c._stream_ai(state, config, [{"role": "user", "content": "hi"}], "sys", kind="query")
    assert out == "A1A2"
    assert b_started["v"] is False
    assert sum(1 for m in captured_broadcasts if m["type"] == "answer_open") == 1


@pytest.mark.asyncio
async def test_primary_slow_launches_second_keeps_both(captured_broadcasts, monkeypatch):
    from meeting_helper.ai import client as c
    state, config = AppState(), AppConfig(
        anthropic_api_key="x", google_api_key="y",
        ai_provider_order=["anthropic", "google"], ai_failover_delay_ms=100)
    a = await _gen_from(["A1", "A2"], first_token_delay=0.3)
    b = await _gen_from(["B1", "B2"], first_token_delay=0.0)
    monkeypatch.setattr(c, "_PROVIDER_GENERATORS", _provider_table(anthropic=a, google=b), raising=False)
    out = await c._stream_ai(state, config, [{"role": "user", "content": "hi"}], "sys", kind="query")
    assert out == "A1A2"
    opens = [m for m in captured_broadcasts if m["type"] == "answer_open"]
    assert len(opens) == 2
    # answer_ids are now per-query nonces (e.g. "abc12345-0", "abc12345-1")
    # so consecutive queries can't collide in the UI's chunk router.
    ids = sorted(m["answer_id"] for m in opens)
    nonce = ids[0].rsplit("-", 1)[0]
    assert {ids[0], ids[1]} == {f"{nonce}-0", f"{nonce}-1"}, ids
    primary_id, secondary_id = f"{nonce}-0", f"{nonce}-1"
    a_text = "".join(m["text"] for m in captured_broadcasts if m["type"] == "chunk" and m["answer_id"] == primary_id)
    b_text = "".join(m["text"] for m in captured_broadcasts if m["type"] == "chunk" and m["answer_id"] == secondary_id)
    assert a_text == "A1A2" and b_text == "B1B2"
    assert sum(1 for m in captured_broadcasts if m["type"] == "done") == 2
    assert sum(1 for m in captured_broadcasts if m["type"] == "all_done") == 1


@pytest.mark.asyncio
async def test_primary_errors_early_starts_second_immediately(captured_broadcasts, monkeypatch):
    from meeting_helper.ai import client as c
    state, config = AppState(), AppConfig(
        anthropic_api_key="x", google_api_key="y",
        ai_provider_order=["anthropic", "google"], ai_failover_delay_ms=5000)
    a = await _gen_from([], error=RuntimeError("boom"))
    b = await _gen_from(["B1"], first_token_delay=0.0)
    monkeypatch.setattr(c, "_PROVIDER_GENERATORS", _provider_table(anthropic=a, google=b), raising=False)
    import time as _t
    t0 = _t.monotonic()
    out = await c._stream_ai(state, config, [{"role": "user", "content": "hi"}], "sys", kind="query")
    assert _t.monotonic() - t0 < 2.0
    assert out == "B1"


@pytest.mark.asyncio
async def test_delay_zero_launches_all_at_once(captured_broadcasts, monkeypatch):
    from meeting_helper.ai import client as c
    state, config = AppState(), AppConfig(
        anthropic_api_key="x", google_api_key="y",
        ai_provider_order=["anthropic", "google"], ai_failover_delay_ms=0)
    a = await _gen_from(["A1"], first_token_delay=0.05)
    b = await _gen_from(["B1"], first_token_delay=0.05)
    monkeypatch.setattr(c, "_PROVIDER_GENERATORS", _provider_table(anthropic=a, google=b), raising=False)
    await c._stream_ai(state, config, [{"role": "user", "content": "hi"}], "sys", kind="query")
    assert sum(1 for m in captured_broadcasts if m["type"] == "answer_open") == 2


@pytest.mark.asyncio
async def test_all_providers_fail_single_error(captured_broadcasts, monkeypatch):
    from meeting_helper.ai import client as c
    state, config = AppState(), AppConfig(
        anthropic_api_key="x", google_api_key="y",
        ai_provider_order=["anthropic", "google"], ai_failover_delay_ms=50)
    a = await _gen_from([], error=RuntimeError("a-fail"))
    b = await _gen_from([], error=RuntimeError("b-fail"))
    monkeypatch.setattr(c, "_PROVIDER_GENERATORS", _provider_table(anthropic=a, google=b), raising=False)
    out = await c._stream_ai(state, config, [{"role": "user", "content": "hi"}], "sys", kind="query")
    assert out == ""
    errs = [m for m in captured_broadcasts if m["type"] == "error"]
    assert len(errs) == 1
    assert not any(m["type"] == "all_done" for m in captured_broadcasts)


@pytest.mark.asyncio
async def test_skips_provider_without_key(captured_broadcasts, monkeypatch):
    from meeting_helper.ai import client as c
    state, config = AppState(), AppConfig(
        anthropic_api_key="", google_api_key="y",
        ai_provider_order=["anthropic", "google"], ai_failover_delay_ms=50)
    a = await _gen_from(["NOPE"])
    b = await _gen_from(["B1"])
    monkeypatch.setattr(c, "_PROVIDER_GENERATORS", _provider_table(anthropic=a, google=b), raising=False)
    out = await c._stream_ai(state, config, [{"role": "user", "content": "hi"}], "sys", kind="query")
    assert out == "B1"
