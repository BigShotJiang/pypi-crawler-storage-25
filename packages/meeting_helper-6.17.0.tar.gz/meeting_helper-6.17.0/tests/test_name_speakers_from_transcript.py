"""AI speaker-naming step — provider switch + JSON robustness."""
import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def _write_transcript(tmp_path: Path) -> Path:
    p = tmp_path / "m.live.txt"
    p.write_text(
        "[00:01] OTHER#0: Hey Victor, how are you doing?\n"
        "[00:02] SELF: Good thanks. This is Victor.\n"
        "[00:03] OTHER#1: Maria here, joining late.\n"
    )
    return p


@pytest.fixture
def fake_config():
    cfg = MagicMock()
    cfg.preferred_provider = ""  # default = claude
    cfg.anthropic_api_key = "sk-test"
    cfg.claude_model = "claude-sonnet-4-6"
    cfg.max_tokens = 1024
    return cfg


def test_claude_path_parses_clean_json(tmp_path, fake_config):
    from meeting_helper.ai import client as ai_client

    path = _write_transcript(tmp_path)
    fake_response = MagicMock()
    fake_response.content = [MagicMock(text=json.dumps({
        "SELF": {"name": "Victor", "evidence": "This is Victor."},
        "OTHER#0": {"name": None, "evidence": ""},
        "OTHER#1": {"name": "Maria", "evidence": "Maria here, joining late."},
    }))]
    fake_client = MagicMock()
    fake_client.messages.create = AsyncMock(return_value=fake_response)

    with patch("anthropic.AsyncAnthropic", return_value=fake_client):
        result = asyncio.run(
            ai_client.name_speakers_from_transcript(str(path), fake_config)
        )
    assert result.names == {"SELF": "Victor", "OTHER#0": None, "OTHER#1": "Maria"}
    assert result.evidence["SELF"] == "This is Victor."
    assert result.evidence["OTHER#1"] == "Maria here, joining late."
    assert result.source == {"SELF": "ai", "OTHER#0": "ai", "OTHER#1": "ai"}


def test_claude_path_tolerates_markdown_fence(tmp_path, fake_config):
    from meeting_helper.ai import client as ai_client

    path = _write_transcript(tmp_path)
    fenced = "```json\n" + json.dumps({
        "SELF": {"name": "Victor", "evidence": "x"},
        "OTHER#0": {"name": None, "evidence": ""},
        "OTHER#1": {"name": "Maria", "evidence": "y"},
    }) + "\n```"
    fake_response = MagicMock()
    fake_response.content = [MagicMock(text=fenced)]
    fake_client = MagicMock()
    fake_client.messages.create = AsyncMock(return_value=fake_response)

    with patch("anthropic.AsyncAnthropic", return_value=fake_client):
        result = asyncio.run(
            ai_client.name_speakers_from_transcript(str(path), fake_config)
        )
    assert result.names["SELF"] == "Victor"


def test_returns_empty_map_on_unparseable_json(tmp_path, fake_config):
    from meeting_helper.ai import client as ai_client

    path = _write_transcript(tmp_path)
    fake_response = MagicMock()
    fake_response.content = [MagicMock(text="sorry, I can't.")]
    fake_client = MagicMock()
    fake_client.messages.create = AsyncMock(return_value=fake_response)

    with patch("anthropic.AsyncAnthropic", return_value=fake_client):
        result = asyncio.run(
            ai_client.name_speakers_from_transcript(str(path), fake_config)
        )
    assert result.names == {}
    assert result.evidence == {}


def test_raises_on_missing_transcript(tmp_path, fake_config):
    from meeting_helper.ai import client as ai_client
    with pytest.raises(FileNotFoundError):
        asyncio.run(
            ai_client.name_speakers_from_transcript(
                str(tmp_path / "does-not-exist.live.txt"), fake_config,
            )
        )


def test_parser_strips_whitespace_and_empties_name():
    from meeting_helper.ai.client import _parse_speaker_naming_json
    r = _parse_speaker_naming_json(
        '{"SELF":{"name":"  Maria  ","evidence":"x"},'
        '"OTHER#0":{"name":"","evidence":""}}'
    )
    assert r.names == {"SELF": "Maria", "OTHER#0": None}


def test_parser_truncates_evidence_to_200():
    from meeting_helper.ai.client import _parse_speaker_naming_json
    r = _parse_speaker_naming_json(
        '{"SELF":{"name":"V","evidence":"' + "a" * 300 + '"}}'
    )
    assert len(r.evidence["SELF"]) == 200


def test_parser_rejects_non_dict_entry_and_handles_missing_name():
    from meeting_helper.ai.client import _parse_speaker_naming_json
    r = _parse_speaker_naming_json(
        '{"SELF":"Victor","OTHER#0":{"evidence":"x"}}'
    )
    # SELF entry rejected (not a dict); OTHER#0 has no "name" key → None.
    assert r.names == {"OTHER#0": None}
