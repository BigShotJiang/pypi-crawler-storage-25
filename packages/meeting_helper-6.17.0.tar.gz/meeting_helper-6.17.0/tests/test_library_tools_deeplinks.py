"""Tests for the library tool deeplink emitter (MH-38 task 14).

Notes now live at `/notes/?id=<encoded>` (no `kind` query parameter).
Meetings keep the existing `/library/?id=...&kind=meeting` shape.
"""
from meeting_helper.chat.tools.library import _deeplink, build_library_get_note


def test_note_kind_emits_notes_path():
    assert _deeplink({"id": "x.note.md", "kind": "note"}) == "/notes/?id=x.note.md"


def test_note_kind_url_encodes_special_chars():
    # Spaces and other special chars in note ids must be percent-encoded.
    link = _deeplink({"id": "a b.note.md", "kind": "note"})
    assert link == "/notes/?id=a%20b.note.md"


def test_meeting_kind_keeps_library_path():
    link = _deeplink({"id": "2026-05-08_193029", "kind": "meeting"})
    assert link.startswith("/library/")
    assert "kind=meeting" in link


def test_unknown_kind_returns_none():
    assert _deeplink({"id": "x", "kind": "skill"}) is None


def test_missing_id_returns_none():
    assert _deeplink({"kind": "note"}) is None


def test_library_get_note_description_marks_deprecated():
    tool = build_library_get_note()
    assert "DEPRECATED" in tool.description
    assert "notes.get" in tool.description
