"""GET /notes/list — thin HTTP wrapper around the notes._list chat tool.

Verifies the endpoint returns 200 and a JSON body with a `notes` array.
The chat tool itself (and its content) is covered by `test_notes_tools.py`.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
async def client(aiohttp_client, tmp_path: Path, monkeypatch):
    """Aiohttp test client pointed at a temp recordings dir.

    The chat tool reads `get_config().recordings_dir`, so we monkeypatch
    `get_config` to a stub whose `recordings_dir` lives in `tmp_path`.
    The stub also implements the `is_kb`/`is_favorite` shape that the
    chat tool calls on each row.
    """

    class _StubCfg:
        def __init__(self, rec: Path) -> None:
            self.recordings_dir = rec

        def is_kb(self, _filename: str) -> bool:
            return False

        def is_favorite(self, _filename: str) -> bool:
            return False

    stub = _StubCfg(tmp_path)
    monkeypatch.setattr(
        "meeting_helper.config.get_config",
        lambda: stub,
    )
    app = create_app(AppConfig())
    return await aiohttp_client(app)


async def test_notes_list_returns_empty_when_no_files(client):
    resp = await client.get("/notes/list")
    assert resp.status == 200
    body = await resp.json()
    assert body == {"notes": []}


async def test_notes_list_lists_note_files(client, tmp_path: Path):
    # The fixture pointed recordings_dir at tmp_path; drop two notes.
    (tmp_path / "alpha.note.md").write_text("hello")
    (tmp_path / "beta.note.md").write_text("world")
    resp = await client.get("/notes/list")
    assert resp.status == 200
    body = await resp.json()
    ids = sorted(n["id"] for n in body["notes"])
    assert ids == ["alpha.note.md", "beta.note.md"]
    # Each row carries the shape the web client consumes.
    for row in body["notes"]:
        assert {"id", "title", "in_kb", "favorited", "pinned"} <= set(row.keys())
