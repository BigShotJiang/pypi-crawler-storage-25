"""The 'What was just asked' question must come from the OTHER speaker only.

In a meeting the question the user needs answered is what the other party just
asked, not the user's own rhetorical "...right?". Before the fix, question
extraction merged both buffers and the most-recent '?' won, so a later
self-question shadowed the real question from the other side.
"""
import time
from types import SimpleNamespace

from meeting_helper.ai.client import _assemble_messages
from meeting_helper.buffer import SentenceBuffer


def _state_with(self_lines, other_lines):
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    # Interleave by append order so timestamps reflect "other asked, then I
    # spoke after". time.time() is monotonic enough across these appends.
    for text in other_lines:
        other_buf.append_final(text, fire_listeners=False)
        time.sleep(0.001)
    for text in self_lines:
        self_buf.append_final(text, fire_listeners=False)
        time.sleep(0.001)
    return SimpleNamespace(
        self_buffer=self_buf,
        other_buffer=other_buf,
        last_query_at=0.0,
        current_topic={},
        conversation_history=[],
    )


def _question_section(messages):
    content = messages[-1]["content"]
    marker = "## What was just asked\n"
    return content.split(marker, 1)[1].split("\n\n", 1)[0]


def test_picks_other_question_over_more_recent_self_question():
    cfg = SimpleNamespace(sentence_window=10)
    # OTHER asks the real question; the user then says their own '?' line AFTER.
    state = _state_with(
        self_lines=["So that piece could change, right?"],
        other_lines=["How does the new flow know which metric to query?"],
    )
    asked = _question_section(_assemble_messages(state, cfg))
    assert asked == "How does the new flow know which metric to query?"


def test_no_other_question_falls_back_to_topic_prompt():
    cfg = SimpleNamespace(sentence_window=10)
    state = _state_with(
        self_lines=["I think that piece could change, right?"],
        other_lines=["Sounds good."],
    )
    asked = _question_section(_assemble_messages(state, cfg))
    assert "no explicit question" in asked


def test_latest_nonquestion_request_wins_over_older_question():
    """A fresh non-'?' request must beat an older '?' still in the buffer,
    otherwise we answer a question from a while ago."""
    cfg = SimpleNamespace(sentence_window=10)
    state = _state_with(
        self_lines=[],
        other_lines=[
            "Why did we pick ClickHouse over Prometheus?",
            "Walk me through the adapter file",
        ],
    )
    asked = _question_section(_assemble_messages(state, cfg))
    assert asked == "Walk me through the adapter file"


def test_short_question_followup_is_kept():
    """Short '?' follow-ups ('why?') are real questions and must be pinned."""
    cfg = SimpleNamespace(sentence_window=10)
    state = _state_with(self_lines=[], other_lines=["The deploy caused it.", "Why?"])
    asked = _question_section(_assemble_messages(state, cfg))
    assert asked == "Why?"
