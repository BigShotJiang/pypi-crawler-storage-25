"""Regression tests for ticket #253 — the Copilot toolbar Stop button must
end auto-started sessions, not only sessions started manually via the
Start button.

Before the fix, `MeetingSession._manual_stop` was only initialized inside
`manual_start()`. The auto-detect path (`_run` → `_run_active_session`)
ran with `stop_event=None`, and its capture loop only checked MicProbe
to decide when to end. So clicking Stop fired `manual_stop()` (which set
an event nobody was watching) and the user was stuck waiting for
MicProbe to notice the meeting app released the mic.

The fix:
1. Always initialize `_manual_stop` in `__init__` so `manual_stop()` is
   safe to call regardless of how the session started.
2. The active-session loop now watches `self._manual_stop` on every
   iteration — both for sessions launched via `manual_start` (existing
   behaviour) and for sessions started by mic auto-detection.
"""

from __future__ import annotations

import threading
import time

import pytest


def _bare_session():
    """A MeetingSession with only the attributes the tests touch.

    Bypasses `__init__` (which would try to wire on_meeting_start/end
    callbacks we don't have here). Matches the pattern used in
    test_auto_rename.py for the single-session-guard tests.
    """
    from meeting_helper.session import MeetingSession

    session = MeetingSession.__new__(MeetingSession)
    session._active_session_lock = threading.Lock()
    session._manual_stop = threading.Event()
    return session


def test_manual_stop_is_safe_without_manual_start():
    """`manual_stop()` must NOT raise when the active session was started
    by mic auto-detection (i.e. `manual_start()` was never called). The
    pre-fix code stored `_manual_stop` only inside `manual_start`, so
    calling `manual_stop` on an auto-session was either a silent no-op
    (hasattr-guarded) or an AttributeError depending on the path.
    """
    session = _bare_session()
    # Simulate: an auto-session is running, user clicks Stop in the
    # Copilot toolbar. Must not raise; must set the shared event so the
    # active-session loop can observe it.
    session.manual_stop()
    assert session._manual_stop.is_set()


def test_active_session_clears_stale_manual_stop():
    """A previous session set `_manual_stop` (e.g. user clicked Stop, the
    daemon recovered without a fresh process). The NEXT session must NOT
    inherit that signal and tear itself down on entry."""
    session = _bare_session()
    session._manual_stop.set()  # stale signal from a prior session

    inner_saw_stop_already_set = []

    def fake_inner(meeting_info, stop_event=None):
        inner_saw_stop_already_set.append(session._manual_stop.is_set())

    session._run_active_session_locked = fake_inner

    from types import SimpleNamespace
    info = SimpleNamespace(app_name="Zoom", meeting_name="Standup")
    ran = session._run_active_session(info)

    assert ran is True
    assert inner_saw_stop_already_set == [False], (
        "_run_active_session must clear `_manual_stop` before entering "
        "the inner body — otherwise a stale set() from a previous "
        "session would tear the new one down immediately"
    )


def test_constructor_initializes_manual_stop():
    """`__init__` must create `_manual_stop` so the toolbar Stop button
    works from the very first auto-detected meeting, before any
    `manual_start` ever runs."""
    from meeting_helper.session import MeetingSession
    from meeting_helper.config import AppConfig
    from meeting_helper.buffer import SentenceBuffer

    cfg = AppConfig()
    session = MeetingSession(
        config=cfg,
        self_buffer=SentenceBuffer(),
        other_buffer=SentenceBuffer(),
        on_meeting_start=lambda info: None,
        on_meeting_end=lambda path: None,
    )
    assert isinstance(session._manual_stop, threading.Event)
    assert not session._manual_stop.is_set()


def test_session_stop_handler_calls_manual_stop_on_auto_session():
    """POST /session/stop must call MeetingSession.manual_stop() even when
    the active session was auto-started. The handler doesn't know (or
    care) which path started it — it just delegates."""
    import asyncio
    from unittest.mock import MagicMock
    from meeting_helper.server import routes
    from meeting_helper import state as state_mod

    fake_session = MagicMock()
    original_session = state_mod.state.meeting_session
    original_active = state_mod.state.session_active
    state_mod.state.meeting_session = fake_session
    state_mod.state.session_active = True
    try:
        req = MagicMock()
        loop = asyncio.new_event_loop()
        try:
            resp = loop.run_until_complete(routes.session_stop_handler(req))
        finally:
            loop.close()
        assert resp.status == 200
        fake_session.manual_stop.assert_called_once()
    finally:
        state_mod.state.meeting_session = original_session
        state_mod.state.session_active = original_active


def test_active_loop_breaks_on_manual_stop_for_auto_session():
    """End-to-end shape: when `_run_active_session_locked` is running in
    auto mode (stop_event=None), setting `self._manual_stop` from another
    thread must cause the capture loop to break.

    We exercise the loop guard logic directly with a tiny standin: a
    while loop that mirrors the `is_manual` / `self._manual_stop` checks.
    This isolates the contract without standing up real audio/transcriber
    machinery.
    """
    session = _bare_session()
    session._stop_event = threading.Event()

    # Mirror the guards used inside _run_active_session_locked.
    def mini_loop(stop_event):
        is_manual = stop_event is not None
        iters = 0
        while not session._stop_event.is_set():
            iters += 1
            if is_manual and stop_event.is_set():
                return ("manual-stop-event", iters)
            if not is_manual and session._manual_stop.is_set():
                return ("toolbar-stop-auto", iters)
            time.sleep(0.005)
            if iters > 500:
                return ("timeout", iters)

    # Auto-started case: pass stop_event=None, then trigger toolbar Stop.
    result_box = {}

    def runner():
        result_box["res"] = mini_loop(stop_event=None)

    t = threading.Thread(target=runner, daemon=True)
    t.start()
    time.sleep(0.05)
    session.manual_stop()
    t.join(timeout=2.0)
    assert result_box["res"][0] == "toolbar-stop-auto", (
        f"auto-session loop should break on self._manual_stop; got {result_box['res']}"
    )


def test_active_loop_still_breaks_on_passed_stop_event_for_manual_session():
    """Existing behaviour preserved: when started via `manual_start`, the
    explicit `stop_event` argument is what `_run_manual_session` watches,
    and it still ends the loop. The new shared `_manual_stop` check is
    additive, not a replacement."""
    session = _bare_session()
    session._stop_event = threading.Event()

    def mini_loop(stop_event):
        is_manual = stop_event is not None
        iters = 0
        while not session._stop_event.is_set():
            iters += 1
            if is_manual and stop_event.is_set():
                return ("manual-stop-event", iters)
            if not is_manual and session._manual_stop.is_set():
                return ("toolbar-stop-auto", iters)
            time.sleep(0.005)
            if iters > 500:
                return ("timeout", iters)

    # Manual case: stop_event IS self._manual_stop (the wiring in
    # `_run_manual_session`). Setting it breaks the loop via the manual
    # branch.
    result_box = {}

    def runner():
        result_box["res"] = mini_loop(stop_event=session._manual_stop)

    t = threading.Thread(target=runner, daemon=True)
    t.start()
    time.sleep(0.05)
    session.manual_stop()
    t.join(timeout=2.0)
    assert result_box["res"][0] == "manual-stop-event", (
        f"manual-session loop should break on its explicit stop_event; got {result_box['res']}"
    )
