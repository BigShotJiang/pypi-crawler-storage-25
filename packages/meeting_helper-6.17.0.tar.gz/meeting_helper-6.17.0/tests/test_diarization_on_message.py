"""Verifies _on_message picks the dominant Deepgram speaker per final result."""
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from meeting_helper.audio.transcriber import DeepgramTranscriber
from meeting_helper.buffer import SentenceBuffer


def _make_result(transcript: str, is_final: bool, word_speakers: list[int | None]):
    words = [
        SimpleNamespace(word=f"w{i}", start=i * 0.1, end=i * 0.1 + 0.1, speaker=sp)
        for i, sp in enumerate(word_speakers)
    ]
    alt = SimpleNamespace(transcript=transcript, words=words)
    channel = SimpleNamespace(alternatives=[alt])
    return SimpleNamespace(channel=channel, is_final=is_final)


def _make_transcriber(diarize: bool):
    capture = MagicMock()
    buf = SentenceBuffer(role="other")
    t = DeepgramTranscriber(capture, buf, api_key="x", language="en", diarize=diarize)
    return t, buf


def test_dominant_speaker_is_assigned_when_diarize_on():
    t, buf = _make_transcriber(diarize=True)
    t._on_message(None, result=_make_result("hello world", True, [0, 0, 1]))
    entries = list(buf._sentences)
    assert len(entries) == 1
    assert entries[0].speaker == 0  # majority of 3 words


def test_no_words_means_speaker_none():
    t, buf = _make_transcriber(diarize=True)
    t._on_message(None, result=_make_result("hello", True, []))
    entries = list(buf._sentences)
    assert len(entries) == 1
    assert entries[0].speaker is None


def test_all_word_speakers_none_means_speaker_none():
    t, buf = _make_transcriber(diarize=True)
    t._on_message(None, result=_make_result("hello", True, [None, None]))
    entries = list(buf._sentences)
    assert entries[0].speaker is None


def test_diarize_off_ignores_words_and_keeps_speaker_none():
    t, buf = _make_transcriber(diarize=False)
    t._on_message(None, result=_make_result("hello", True, [0, 1]))
    entries = list(buf._sentences)
    assert entries[0].speaker is None


def test_interim_results_do_not_finalize():
    t, buf = _make_transcriber(diarize=True)
    t._on_message(None, result=_make_result("partial", False, [0, 0]))
    assert len(list(buf._sentences)) == 0
