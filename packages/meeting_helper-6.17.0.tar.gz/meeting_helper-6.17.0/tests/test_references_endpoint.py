"""Tests for /references/search and reference-token expansion (ticket #268).

The endpoint backs the chat composer's `@` picker. It exposes a unified
view across meetings + notes + KB-only artifacts, with ONE row per meeting
(not one per .live/.summary/audio file). Expansion runs server-side at
send time so the agent sees inline Reference blocks alongside the user's
prompt.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from meeting_helper.config import AppConfig
from meeting_helper.chat.handlers import expand_chat_references
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client, tmp_path: Path):
    cfg = AppConfig()
    cfg.recordings_dir = tmp_path
    app = create_app(cfg)
    return await aiohttp_client(app)


async def test_references_search_empty_workspace(app_client):
    resp = await app_client.get("/references/search")
    assert resp.status == 200
    body = await resp.json()
    assert body == {"items": []}


async def test_references_search_collapses_meeting_to_single_row(
    app_client, tmp_path: Path,
):
    """Critical UX guard: one meeting -> one entry in the picker.

    The meeting has all four files on disk (mp3, live, transcript, summary)
    yet the picker must surface a single row keyed by the meeting stem.
    """
    stem = "2026-05-14_100000_design-sync"
    (tmp_path / f"{stem}.mp3").write_bytes(b"\x00")
    (tmp_path / f"{stem}.live.txt").write_text("live captions")
    (tmp_path / f"{stem}.transcript.txt").write_text("full transcript")
    (tmp_path / f"{stem}.summary.txt").write_text("# Summary")

    resp = await app_client.get("/references/search")
    assert resp.status == 200
    body = await resp.json()
    meeting_rows = [it for it in body["items"] if it["kind"] == "meeting"]
    assert len(meeting_rows) == 1
    row = meeting_rows[0]
    assert row["id"] == stem
    # Title is the human label parsed off the stem (only `_` -> space).
    assert "design-sync" in row["title"].lower()
    # Subtitle should reflect that summary + transcript are available without
    # listing the underlying files as separate rows.
    assert "summary" in (row.get("subtitle") or "")


async def test_references_search_filters_by_substring(
    app_client, tmp_path: Path,
):
    (tmp_path / "2026-05-14_100000_design-sync.mp3").write_bytes(b"\x00")
    (tmp_path / "2026-05-13_140000_retro.mp3").write_bytes(b"\x00")
    (tmp_path / "interview-notes.note.md").write_text("body")

    resp = await app_client.get("/references/search?q=sync")
    assert resp.status == 200
    body = await resp.json()
    titles = [it["title"].lower() for it in body["items"]]
    assert any("sync" in t for t in titles)
    assert not any("retro" in t for t in titles)
    assert not any("interview" in t for t in titles)


async def test_references_search_includes_notes(app_client, tmp_path: Path):
    (tmp_path / "kickoff.note.md").write_text("kickoff doc body")
    resp = await app_client.get("/references/search")
    assert resp.status == 200
    body = await resp.json()
    note_rows = [it for it in body["items"] if it["kind"] == "note"]
    assert len(note_rows) == 1
    assert note_rows[0]["title"] == "kickoff"


async def test_expand_chat_references_inlines_meeting_content(
    tmp_path: Path,
):
    cfg = AppConfig()
    cfg.recordings_dir = tmp_path
    stem = "2026-05-14_100000_design-sync"
    summary_body = "Decisions: ship by Friday."
    transcript_body = "Alice: hi.\nBob: hello."
    (tmp_path / f"{stem}.mp3").write_bytes(b"\x00")
    (tmp_path / f"{stem}.summary.txt").write_text(summary_body)
    (tmp_path / f"{stem}.transcript.txt").write_text(transcript_body)

    raw = f"What did we decide in [meeting:{stem}:Design sync]?"
    expanded = expand_chat_references(raw, cfg)

    assert '[Reference: Meeting "Design sync"]' in expanded
    assert "[/Reference]" in expanded
    # Summary should be inlined before transcript.
    assert summary_body in expanded
    assert transcript_body in expanded
    assert expanded.index(summary_body) < expanded.index(transcript_body)
    # The plain-text scaffolding around the token must survive expansion.
    assert expanded.startswith("What did we decide in ")
    assert expanded.endswith("?")


async def test_expand_chat_references_handles_missing_files(tmp_path: Path):
    cfg = AppConfig()
    cfg.recordings_dir = tmp_path
    raw = "Look at [meeting:does-not-exist:Foo]."
    expanded = expand_chat_references(raw, cfg)
    assert '[Reference: Meeting "Foo"]' in expanded
    assert "content unavailable" in expanded


async def test_expand_chat_references_truncates_long_bodies(tmp_path: Path):
    cfg = AppConfig()
    cfg.recordings_dir = tmp_path
    stem = "2026-05-14_100000_long"
    (tmp_path / f"{stem}.mp3").write_bytes(b"\x00")
    (tmp_path / f"{stem}.summary.txt").write_text("A" * 20_000)

    raw = f"[meeting:{stem}:Long]"
    expanded = expand_chat_references(raw, cfg)
    # 8k cap + scaffolding (Reference block, "Summary:" prefix, ellipsis,
    # closing tag) keeps the total well under 9k chars.
    assert len(expanded) < 9000
    assert "…" in expanded


async def test_expand_chat_references_no_tokens_is_identity(tmp_path: Path):
    cfg = AppConfig()
    cfg.recordings_dir = tmp_path
    assert expand_chat_references("plain message", cfg) == "plain message"
    assert expand_chat_references("", cfg) == ""
