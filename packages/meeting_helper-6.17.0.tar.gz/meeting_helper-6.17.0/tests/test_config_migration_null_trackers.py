"""Migration must treat trackers:null the same as missing — re-run migration."""
import json
from meeting_helper.config import Config


def test_null_trackers_triggers_migration_from_http_legacy(tmp_path):
    p = tmp_path / "ws.json"
    p.write_text(json.dumps({
        "local_todo_mcp": {
            "type": "http",
            "url": "https://example.com/mcp",
            "headers": {"Authorization": "Bearer xyz"},
        },
        "trackers": None,
        "active_tracker_id": None,
    }))
    cfg = Config(p)
    trackers = cfg.trackers
    assert len(trackers) == 1
    assert trackers[0]["vendor"] == "local_todo"
    assert trackers[0]["auth_values"]["url"] == "https://example.com/mcp"
    assert trackers[0]["transport"]["url"] == "https://example.com/mcp"
    assert cfg.active_tracker_id is not None


def test_empty_trackers_list_is_left_alone(tmp_path):
    p = tmp_path / "ws.json"
    p.write_text(json.dumps({"trackers": [], "active_tracker_id": None}))
    cfg = Config(p)
    assert cfg.trackers == []
    assert cfg.active_tracker_id is None
