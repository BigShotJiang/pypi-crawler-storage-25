"""Daemon boot path uses TrackerRegistry, not LocalTodoClient directly."""
from unittest.mock import AsyncMock, MagicMock, patch
import pytest


@pytest.mark.asyncio
async def test_daemon_boot_uses_tracker_registry(monkeypatch, tmp_path):
    # Skip — this is best covered by inspection of the new code path.
    # Manual verification: grep `daemon.py` for `TrackerRegistry`, no direct
    # `LocalTodoClient(` instantiation.
    import meeting_helper.daemon as daemon_mod
    src = open(daemon_mod.__file__).read()
    assert "TrackerRegistry" in src
    assert "LocalTodoClient(" not in src or "# deprecated" in src
