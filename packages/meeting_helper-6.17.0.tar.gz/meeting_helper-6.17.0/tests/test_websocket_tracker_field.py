import json
from meeting_helper.server import websocket as ws_mod


def test_status_payload_has_tracker_active_field(monkeypatch):
    monkeypatch.setattr("meeting_helper.state.state.tracker", object())
    payload = ws_mod.build_status_payload()
    assert "tracker_active" in payload
    assert payload["tracker_active"] is True
    # Back-compat: keep local_todo_configured for one release
    assert payload.get("local_todo_configured") is True


def test_status_payload_tracker_inactive(monkeypatch):
    monkeypatch.setattr("meeting_helper.state.state.tracker", None)
    payload = ws_mod.build_status_payload()
    assert payload["tracker_active"] is False
    assert payload.get("local_todo_configured") is False
