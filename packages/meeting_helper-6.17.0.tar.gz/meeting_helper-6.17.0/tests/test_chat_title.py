import pytest
from meeting_helper.chat import title as chat_title, paths as chat_paths, store as chat_store


def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


@pytest.mark.asyncio
async def test_skips_when_already_titled(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    th = chat_store.create_thread(title="Custom title")
    called = []

    async def _stub_call(prompt): called.append(prompt); return "AI title"
    monkeypatch.setattr(chat_title, "_one_shot", _stub_call)

    await chat_title.maybe_generate_title(th.id)
    assert called == []
    assert chat_store.read_thread(th.id).title == "Custom title"


@pytest.mark.asyncio
async def test_generates_for_new_conversation(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    th = chat_store.create_thread(title="New conversation")
    chat_store.append_turn(th.id, role="user", text="Help me with Gradle release")
    chat_store.append_turn(th.id, role="assistant", text="Sure, I'll pull the ticket.")

    async def _stub(prompt): return "Gradle release help"
    monkeypatch.setattr(chat_title, "_one_shot", _stub)

    await chat_title.maybe_generate_title(th.id)
    assert chat_store.read_thread(th.id).title == "Gradle release help"


@pytest.mark.asyncio
async def test_does_not_regenerate_after_first_pass(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    th = chat_store.create_thread(title="New conversation")
    chat_store.append_turn(th.id, role="user", text="Help me with Gradle release")
    chat_store.append_turn(th.id, role="assistant", text="Sure, I'll pull the ticket.")

    calls = []
    async def _stub(prompt): calls.append(prompt); return "Gradle release help"
    monkeypatch.setattr(chat_title, "_one_shot", _stub)

    await chat_title.maybe_generate_title(th.id)
    await chat_title.maybe_generate_title(th.id)
    assert len(calls) == 1
