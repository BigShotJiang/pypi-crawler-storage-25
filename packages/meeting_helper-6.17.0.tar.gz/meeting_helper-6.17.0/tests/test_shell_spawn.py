"""Tests for ``meeting_helper.shell.spawn`` — the daemon spawn helper."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from meeting_helper.shell import spawn as spawn_mod


def test_resolve_cli_prefers_binary_next_to_python(tmp_path, monkeypatch):
    """When ``Path(sys.executable).parent / "meeting-helper"`` exists, that
    wins over ``shutil.which`` — important so a developer .venv doesn't
    get a daemon spawned from a globally-installed copy on PATH."""
    fake_bin = tmp_path / "meeting-helper"
    fake_bin.write_text("#!/bin/sh\necho fake")
    fake_python = tmp_path / "python"
    fake_python.write_text("#!/bin/sh\nexec python \"$@\"")
    monkeypatch.setattr(sys, "executable", str(fake_python))

    resolved = spawn_mod._resolve_cli()
    assert resolved == str(fake_bin)


def test_resolve_cli_falls_back_to_path(tmp_path, monkeypatch):
    """If no binary exists next to ``sys.executable``, fall back to PATH lookup."""
    empty_dir = tmp_path / "bin"
    empty_dir.mkdir()
    monkeypatch.setattr(sys, "executable", str(empty_dir / "python"))
    monkeypatch.setattr(
        spawn_mod.shutil, "which", lambda name: "/usr/local/bin/meeting-helper",
    )
    assert spawn_mod._resolve_cli() == "/usr/local/bin/meeting-helper"


def test_spawn_daemon_uses_cli_binary_when_available(tmp_path, monkeypatch):
    """``spawn_daemon`` must invoke the ``meeting-helper`` entry-point
    script when present — NOT ``python -m meeting_helper.cli``. The CLI
    script's shebang resolves to the right interpreter even when the
    shell process was launched from a .venv with stale code."""
    fake_bin = tmp_path / "meeting-helper"
    fake_bin.write_text("#!/bin/sh\nexit 0")
    fake_bin.chmod(0o755)
    fake_python = tmp_path / "python"
    fake_python.write_text("#!/bin/sh\nexec python \"$@\"")
    monkeypatch.setattr(sys, "executable", str(fake_python))

    captured: dict = {}

    class _FakeProc:
        def __init__(self, cmd):
            self._cmd = cmd
            self.returncode = 0

        def poll(self):
            return self.returncode

        def wait(self, timeout=None):
            return self.returncode

    def _fake_popen(cmd, **kwargs):
        captured["cmd"] = cmd
        return _FakeProc(cmd)

    monkeypatch.setattr(spawn_mod.subprocess, "Popen", _fake_popen)
    monkeypatch.setattr(
        spawn_mod, "DAEMON_SPAWN_LOG", str(tmp_path / "spawn.log"),
    )

    spawn_mod.spawn_daemon()
    assert captured["cmd"] == [str(fake_bin), "start"]


def test_spawn_daemon_fallback_to_module_when_no_binary(tmp_path, monkeypatch):
    """If neither ``Path(sys.executable).parent / "meeting-helper"`` nor
    a PATH lookup finds the binary, we degrade to ``python -m
    meeting_helper.cli`` rather than silently doing nothing."""
    empty_dir = tmp_path / "bin"
    empty_dir.mkdir()
    fake_python = empty_dir / "python"
    fake_python.write_text("#!/bin/sh\nexec python \"$@\"")
    monkeypatch.setattr(sys, "executable", str(fake_python))
    monkeypatch.setattr(spawn_mod.shutil, "which", lambda name: None)

    captured: dict = {}

    class _FakeProc:
        def __init__(self, cmd):
            self._cmd = cmd
            self.returncode = 0

        def poll(self):
            return self.returncode

        def wait(self, timeout=None):
            return self.returncode

    def _fake_popen(cmd, **kwargs):
        captured["cmd"] = cmd
        return _FakeProc(cmd)

    monkeypatch.setattr(spawn_mod.subprocess, "Popen", _fake_popen)
    monkeypatch.setattr(
        spawn_mod, "DAEMON_SPAWN_LOG", str(tmp_path / "spawn.log"),
    )

    spawn_mod.spawn_daemon()
    assert captured["cmd"] == [str(fake_python), "-m", "meeting_helper.cli", "start"]


def test_read_spawn_log_tail_returns_recent_bytes(tmp_path, monkeypatch):
    log_path = tmp_path / "spawn.log"
    log_path.write_text("Traceback (most recent call last):\n  File 'x.py', line 1\nImportError: bad\n")
    monkeypatch.setattr(spawn_mod, "DAEMON_SPAWN_LOG", str(log_path))

    out = spawn_mod.read_spawn_log_tail()
    assert "ImportError: bad" in out


def test_read_spawn_log_tail_returns_empty_when_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(
        spawn_mod, "DAEMON_SPAWN_LOG", str(tmp_path / "does-not-exist.log"),
    )
    assert spawn_mod.read_spawn_log_tail() == ""


def test_read_spawn_log_tail_truncates_to_max_bytes(tmp_path, monkeypatch):
    log_path = tmp_path / "spawn.log"
    log_path.write_text("a" * 5000 + "TAIL")
    monkeypatch.setattr(spawn_mod, "DAEMON_SPAWN_LOG", str(log_path))

    out = spawn_mod.read_spawn_log_tail(max_bytes=100)
    assert len(out) == 100
    assert out.endswith("TAIL")


def test_spawn_daemon_returns_popen_for_caller_to_check(tmp_path, monkeypatch):
    """The Popen handle MUST be returned so ``ShellAPI.spawn_daemon`` can
    poll for early crash and surface the spawn log to the UI."""
    fake_bin = tmp_path / "meeting-helper"
    fake_bin.write_text("#!/bin/sh\nexit 0")
    fake_bin.chmod(0o755)
    fake_python = tmp_path / "python"
    fake_python.write_text("#!/bin/sh\nexec python \"$@\"")
    monkeypatch.setattr(sys, "executable", str(fake_python))
    monkeypatch.setattr(
        spawn_mod, "DAEMON_SPAWN_LOG", str(tmp_path / "spawn.log"),
    )

    proc = spawn_mod.spawn_daemon()
    try:
        assert isinstance(proc, subprocess.Popen)
        proc.wait(timeout=5)
        assert proc.returncode == 0
    finally:
        if proc.poll() is None:
            proc.kill()
