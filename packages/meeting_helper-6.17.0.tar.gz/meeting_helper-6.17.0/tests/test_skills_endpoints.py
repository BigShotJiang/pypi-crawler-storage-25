"""HTTP integration tests for /skills CRUD (ticket #269)."""
from __future__ import annotations

from pathlib import Path

import pytest

from meeting_helper.config import AppConfig
from meeting_helper.chat import paths as chat_paths
from meeting_helper.server.app import create_app


@pytest.fixture
async def app_client(aiohttp_client, tmp_path: Path, monkeypatch):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")
    cfg = AppConfig()
    cfg.recordings_dir = tmp_path
    app = create_app(cfg)
    return await aiohttp_client(app)


async def test_list_empty(app_client):
    resp = await app_client.get("/skills")
    assert resp.status == 200
    assert await resp.json() == {"entries": []}


async def test_create_and_list(app_client):
    resp = await app_client.post(
        "/skills",
        json={"name": "Start Ticket", "description": "d", "body": "do it"},
    )
    assert resp.status == 200
    created = await resp.json()
    assert created["name"] == "start-ticket"
    assert created["body"] == "do it"

    resp = await app_client.get("/skills")
    body = await resp.json()
    assert len(body["entries"]) == 1
    assert body["entries"][0]["id"] == created["id"]


async def test_create_missing_name_returns_400(app_client):
    resp = await app_client.post("/skills", json={"body": "x"})
    assert resp.status == 400


async def test_create_missing_body_returns_400(app_client):
    resp = await app_client.post("/skills", json={"name": "x"})
    assert resp.status == 400


async def test_create_duplicate_returns_409(app_client):
    await app_client.post("/skills", json={"name": "dup", "body": "a"})
    resp = await app_client.post("/skills", json={"name": "Dup", "body": "b"})
    assert resp.status == 409


async def test_patch_updates_entry(app_client):
    resp = await app_client.post(
        "/skills", json={"name": "abc", "body": "old"},
    )
    created = await resp.json()
    resp = await app_client.patch(
        f"/skills/{created['id']}", json={"body": "new", "description": "ok"},
    )
    assert resp.status == 200
    updated = await resp.json()
    assert updated["body"] == "new"
    assert updated["description"] == "ok"


async def test_patch_unknown_returns_404(app_client):
    resp = await app_client.patch("/skills/skl_nope", json={"body": "x"})
    assert resp.status == 404


async def test_patch_duplicate_slug_returns_409(app_client):
    a = await (await app_client.post(
        "/skills", json={"name": "a", "body": "x"},
    )).json()
    await app_client.post("/skills", json={"name": "b", "body": "y"})
    resp = await app_client.patch(f"/skills/{a['id']}", json={"name": "b"})
    assert resp.status == 409


async def test_delete_removes(app_client):
    created = await (await app_client.post(
        "/skills", json={"name": "abc", "body": "x"},
    )).json()
    resp = await app_client.delete(f"/skills/{created['id']}")
    assert resp.status == 200
    listed = await (await app_client.get("/skills")).json()
    assert listed["entries"] == []


async def test_delete_unknown_returns_404(app_client):
    resp = await app_client.delete("/skills/skl_nope")
    assert resp.status == 404
