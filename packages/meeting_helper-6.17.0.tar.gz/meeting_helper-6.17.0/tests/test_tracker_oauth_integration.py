"""Verify Tracker accepts oauth_workspace + oauth_tracker_id and raises
when auth_mode='mcp_oauth' but they're missing."""
import pytest
from typing import ClassVar
from meeting_helper.trackers.profile import (
    AuthField, TransportTemplate, VendorProfile,
)
from meeting_helper.trackers.tracker import Tracker


class _OAuthFixture:
    """Minimal MCP-OAuth profile for testing the constructor wiring."""
    id: ClassVar[str] = "_test_oauth"
    label: ClassVar[str] = "Test OAuth"
    auth_form: ClassVar[tuple] = (AuthField(key="url", label="url", kind="url"),)
    transport: ClassVar = TransportTemplate(type="http", url_template="{url}")
    supports: ClassVar[frozenset] = frozenset()
    auth_mode: ClassVar[str] = "mcp_oauth"
    agent_terminology: ClassVar[str] = "test entries"
    agent_hints: ClassVar[str] = "use the test tools"
    default_url: ClassVar[str] = ""


@pytest.mark.asyncio
async def test_oauth_tracker_requires_workspace_and_id():
    t = Tracker(profile=_OAuthFixture(), transport={"type": "http", "url": "http://x"})
    with pytest.raises(ValueError, match="requires oauth_workspace"):
        # Force the startup path
        await t._ensure_started_locked()


def test_manual_tracker_does_not_require_oauth_args():
    # No exception at construction time for manual mode
    from meeting_helper.trackers.vendors.local_todo import LocalTodoProfile
    t = Tracker(profile=LocalTodoProfile(), transport={"type": "stdio", "command": "x", "args": [], "env": {}})
    assert t._oauth_workspace == ""
    assert t._oauth_tracker_id == ""
