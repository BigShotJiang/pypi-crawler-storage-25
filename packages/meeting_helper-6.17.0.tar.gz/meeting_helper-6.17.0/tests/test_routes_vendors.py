"""HTTP integration test for GET /vendors."""
from __future__ import annotations

import pytest
from aiohttp.test_utils import TestClient, TestServer

from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.mark.asyncio
async def test_vendors_endpoint_returns_catalog():
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        resp = await client.get("/vendors")
        assert resp.status == 200
        data = await resp.json()
        ids = [v["id"] for v in data["vendors"]]
        assert "local_todo" in ids
        local = next(v for v in data["vendors"] if v["id"] == "local_todo")
        assert local["label"] == "Local Todo"
        assert isinstance(local["auth_form"], list)
        assert isinstance(local["capabilities"], list)
        assert "list_workspaces" in local["capabilities"]
        assert local["transport_default"]["type"] == "http"
        # Every vendor must expose default_url as a string (may be empty).
        for vendor in data["vendors"]:
            assert isinstance(vendor.get("default_url"), str), (
                f"vendor {vendor['id']!r} missing or non-string default_url"
            )
