from meeting_helper.config import model_supports_vision
from meeting_helper.ai.client import _vision_provider_order


def test_vision_flags():
    assert model_supports_vision("claude-sonnet-4-6") is True
    assert model_supports_vision("gemini-2.5-flash") is True
    assert model_supports_vision("gpt-5.4-nano") is False  # conservative default
    assert model_supports_vision("unknown-model") is False


class _Cfg:
    anthropic_api_key = "x"
    google_api_key = "y"
    openai_api_key = "z"
    claude_model = "claude-haiku-4-5-20251001"
    gemini_model = "gemini-2.5-flash"
    openai_model = "gpt-5.4-nano"
    preferred_provider = "openai"
    ai_provider_order = ["openai", "anthropic", "google"]


def test_routes_away_from_textonly_model_when_images_present():
    order = _vision_provider_order(_Cfg(), has_images=True)
    # openai/nano is text-only -> dropped; vision-capable providers remain
    assert "openai" not in order
    assert order[0] in ("anthropic", "google")


def test_unchanged_when_no_images():
    cfg = _Cfg()
    assert _vision_provider_order(cfg, has_images=False) == cfg.ai_provider_order


def test_drops_provider_without_key():
    class NoGoogle(_Cfg):
        google_api_key = ""
        openai_model = "gpt-5.4-mini"  # vision-capable

    order = _vision_provider_order(NoGoogle(), has_images=True)
    assert "google" not in order
    # openai (mini, vision) and anthropic (haiku, vision) survive
    assert set(order) == {"openai", "anthropic"}
