# tests/test_appconfig_tracker_fields.py
"""Verify AppConfig exposes tracker fields needed by daemon boot."""
import json
import tempfile
from pathlib import Path

from meeting_helper.config import Config


def test_appconfig_has_tracker_fields():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump({
            "trackers": [{
                "id": "lt-deadbeef",
                "vendor": "local_todo",
                "label": "Local",
                "transport": {"type": "stdio", "command": "npx", "args": [], "env": {}},
                "auth_values": {},
                "secret_keys": [],
            }],
            "active_tracker_id": "lt-deadbeef",
        }, f)
        path = Path(f.name)
    cfg = Config(path)
    ac = cfg.to_app_config()
    assert hasattr(ac, "trackers")
    assert hasattr(ac, "active_tracker_id")
    assert hasattr(ac, "workspace_name")
    assert ac.active_tracker_id == "lt-deadbeef"
    assert len(ac.trackers) == 1
    assert ac.trackers[0]["vendor"] == "local_todo"
    assert ac.workspace_name == path.stem


def test_appconfig_defaults_when_no_trackers():
    # An empty workspace JSON still inherits DEFAULT_CONFIG which includes
    # local_todo_mcp; the migration converts it to one tracker entry.
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump({}, f)
        path = Path(f.name)
    cfg = Config(path)
    ac = cfg.to_app_config()
    # Fields must be present and typed correctly even when populated by migration.
    assert isinstance(ac.trackers, list)
    assert ac.active_tracker_id is None or isinstance(ac.active_tracker_id, str)
    assert ac.workspace_name == path.stem
