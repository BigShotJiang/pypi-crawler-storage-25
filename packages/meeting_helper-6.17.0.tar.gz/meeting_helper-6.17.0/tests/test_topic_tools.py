"""Tests for the polymorphic topic.* chat tools (MH-38 task 10)."""
import pytest

from meeting_helper.chat.tools.topic import (
    build_topic_pin, build_topic_unpin, build_topic_clear,
)
from meeting_helper.state import state as global_state


@pytest.fixture(autouse=True)
def _clean():
    global_state.clear_pins()
    yield
    global_state.clear_pins()


async def test_topic_pin_appends():
    tool = build_topic_pin()
    res = await tool.run({"kind": "note", "id": "a.note.md", "title": "A"}, ctx=None)
    assert res["status"] == "ok"
    assert len(global_state.pinned_topics) == 1


async def test_topic_unpin_removes():
    pin = build_topic_pin()
    unpin = build_topic_unpin()
    await pin.run({"kind": "ticket", "id": "MH-1", "title": "A"}, ctx=None)
    res = await unpin.run({"kind": "ticket", "id": "MH-1"}, ctx=None)
    assert res["status"] == "ok"
    assert global_state.pinned_topics == []


async def test_topic_clear_empties():
    pin = build_topic_pin()
    clear = build_topic_clear()
    await pin.run({"kind": "note", "id": "a.note.md", "title": "A"}, ctx=None)
    await pin.run({"kind": "note", "id": "b.note.md", "title": "B"}, ctx=None)
    res = await clear.run({}, ctx=None)
    assert res["status"] == "ok"
    assert global_state.pinned_topics == []


async def test_topic_pin_rejects_bad_kind():
    tool = build_topic_pin()
    res = await tool.run({"kind": "skill", "id": "x", "title": "y"}, ctx=None)
    assert res["status"] == "error"


async def test_topic_pin_is_marked_mutation():
    assert build_topic_pin().is_mutation is True
    assert build_topic_unpin().is_mutation is True
    assert build_topic_clear().is_mutation is True
