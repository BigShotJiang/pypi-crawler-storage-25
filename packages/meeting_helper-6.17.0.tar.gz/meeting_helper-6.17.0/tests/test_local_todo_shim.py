"""Verify LocalTodoClient still importable as a deprecation shim."""
import warnings
import pytest
from meeting_helper.local_todo import LocalTodoClient
from meeting_helper.trackers.tracker import Tracker


def test_local_todo_client_is_a_tracker_subclass():
    assert issubclass(LocalTodoClient, Tracker)


def test_local_todo_client_emits_deprecation_warning():
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        LocalTodoClient(mcp_config={
            "type": "stdio", "command": "x", "args": [], "env": {},
            "url": "", "headers": {},
        })
        assert any(issubclass(w.category, DeprecationWarning) for w in caught), (
            "expected DeprecationWarning on LocalTodoClient(...)"
        )
