from meeting_helper.trackers.profile import (
    AuthField, TransportTemplate, Workspace, Task, TaskFull, Column,
    SearchHit, CapabilityNotSupported, VendorProfile,
)


def test_authfield_defaults():
    f = AuthField(key="api_token", label="vendors.jira.fields.api_token.label", kind="password")
    assert f.required is True
    assert f.secret is False
    assert f.placeholder == ""


def test_transport_template_stdio_defaults():
    t = TransportTemplate(type="stdio")
    assert t.command == ""
    assert t.args == ()
    assert dict(t.env_template) == {}


def test_task_fields():
    t = Task(
        id="42", title="Hello", status="todo", status_kind="todo",
        priority=None, body_md="", workspace_id="b1", workspace_name="Board 1",
        sprint_name="", url=None,
    )
    assert t.id == "42"
    assert t.status_kind == "todo"


def test_taskfull_extends_task():
    tf = TaskFull(
        id="42", title="t", status="todo", status_kind="todo", priority=None,
        body_md="", workspace_id="b1", workspace_name="Board 1", sprint_name="",
        url=None, subtasks=[], subtasks_summary={}, recent_comments=[],
        recent_history=[], linked_docs=[],
    )
    assert isinstance(tf, Task)


def test_capability_not_supported_is_exception():
    assert issubclass(CapabilityNotSupported, Exception)


def test_protocol_class_attributes_declared():
    # Profiles must declare these ClassVars; the protocol itself is a typing
    # construct, so we just check the protocol exists and is importable.
    assert VendorProfile is not None
