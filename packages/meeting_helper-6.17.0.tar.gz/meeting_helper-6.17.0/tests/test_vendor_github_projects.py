# tests/test_vendor_github_projects.py
import pytest
from meeting_helper.trackers.vendors.github_projects import GitHubProjectsProfile


def test_profile_class_attributes():
    p = GitHubProjectsProfile
    assert p.id == "github_projects"
    assert p.label == "GitHub Projects"
    assert p.transport.type == "http"
    assert p.auth_mode == "mcp_oauth"
    assert p.supports == frozenset()
    assert p.agent_terminology
    assert p.agent_hints
