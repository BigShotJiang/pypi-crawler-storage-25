import pytest

from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig
from meeting_helper.state import state as global_state, PinnedItem


@pytest.fixture(autouse=True)
def _clean_pins():
    global_state.clear_pins()
    global_state.current_topic = {}
    global_state.current_topic_cards = []
    yield
    global_state.clear_pins()


@pytest.fixture
async def client(aiohttp_client):
    app = create_app(AppConfig())
    return await aiohttp_client(app)


# --- Task 3: POST /topic/pin ---

async def test_pin_appends_to_basket(client):
    resp = await client.post(
        "/topic/pin",
        json={"kind": "ticket", "id": "MH-1", "title": "A", "board_id": "bd"},
    )
    assert resp.status == 200
    assert global_state.pinned_topics == [
        PinnedItem(kind="ticket", id="MH-1", title="A", board_id="bd"),
    ]


async def test_pin_dedupes(client):
    payload = {"kind": "note", "id": "foo.note.md", "title": "Foo"}
    await client.post("/topic/pin", json=payload)
    await client.post("/topic/pin", json=payload)
    assert len(global_state.pinned_topics) == 1


async def test_pin_rejects_unknown_kind(client):
    resp = await client.post(
        "/topic/pin", json={"kind": "skill", "id": "x", "title": "y"},
    )
    assert resp.status == 400


async def test_pin_rejects_missing_fields(client):
    resp = await client.post("/topic/pin", json={"kind": "ticket"})
    assert resp.status == 400


# --- Task 4: POST /topic/unpin ---

async def test_unpin_removes(client):
    await client.post("/topic/pin", json={"kind": "note", "id": "a.note.md", "title": "A"})
    resp = await client.post("/topic/unpin", json={"kind": "note", "id": "a.note.md"})
    assert resp.status == 200
    body = await resp.json()
    assert body == {"ok": True, "removed": True, "pinned_count": 0}
    assert global_state.pinned_topics == []


async def test_unpin_missing_returns_false(client):
    resp = await client.post("/topic/unpin", json={"kind": "note", "id": "nope"})
    body = await resp.json()
    assert body["removed"] is False


# --- Task 5: POST /topic/clear, /topic/auto alias, /topic/manual gone ---

async def test_clear_empties_basket(client):
    await client.post("/topic/pin", json={"kind": "ticket", "id": "MH-1", "title": "A"})
    await client.post("/topic/pin", json={"kind": "note", "id": "n.note.md", "title": "N"})
    resp = await client.post("/topic/clear")
    assert resp.status == 200
    assert global_state.pinned_topics == []


async def test_topic_auto_aliases_clear(client):
    await client.post("/topic/pin", json={"kind": "ticket", "id": "MH-1", "title": "A"})
    resp = await client.post("/topic/auto")
    assert resp.status == 200
    assert global_state.pinned_topics == []


async def test_topic_manual_route_is_gone(client):
    # Either 404 (no GET fallback caught it) or 405 (SPA fallback handles GET
    # but not POST). Both mean the POST handler is gone.
    resp = await client.post("/topic/manual")
    assert resp.status in (404, 405)
