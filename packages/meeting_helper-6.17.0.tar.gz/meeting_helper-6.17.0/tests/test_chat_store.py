from meeting_helper.chat.models import Thread, Turn
from meeting_helper.chat import store as chat_store, paths as chat_paths


def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


def test_turn_user_round_trips():
    t = Turn(id="tur_1", role="user", text="hi", created_at="2026-05-14T00:00:00Z")
    assert Turn.from_dict(t.to_dict()) == t


def test_turn_tool_call_round_trips():
    t = Turn(
        id="tur_2",
        role="tool_call",
        tool_name="mcp.search_tasks",
        tool_args={"q": "gradle"},
        created_at="2026-05-14T00:00:00Z",
    )
    d = t.to_dict()
    assert d["tool_name"] == "mcp.search_tasks"
    assert Turn.from_dict(d) == t


def test_thread_round_trips():
    th = Thread(
        id="thr_1",
        title="Test",
        created_at="2026-05-14T00:00:00Z",
        updated_at="2026-05-14T00:00:00Z",
        turns=[Turn(id="tur_1", role="user", text="hi", created_at="2026-05-14T00:00:00Z")],
    )
    assert Thread.from_dict(th.to_dict()) == th


def test_create_thread_writes_file_and_index(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    th = chat_store.create_thread(title="Hello")
    assert th.title == "Hello"
    assert chat_paths.thread_path(th.id).exists()
    idx = chat_store.read_index()
    assert any(e["id"] == th.id and e["title"] == "Hello" for e in idx)


def test_append_turn_updates_thread_and_index(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    th = chat_store.create_thread(title="t")
    turn = chat_store.append_turn(
        th.id,
        role="user",
        text="hi",
    )
    loaded = chat_store.read_thread(th.id)
    assert len(loaded.turns) == 1
    assert loaded.turns[0].id == turn.id
    idx = chat_store.read_index()
    entry = next(e for e in idx if e["id"] == th.id)
    assert entry["msg_count"] == 1
    assert entry["updated_at"] == loaded.updated_at


def test_rename_thread_updates_title_and_index(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    th = chat_store.create_thread(title="old")
    chat_store.rename_thread(th.id, "new")
    assert chat_store.read_thread(th.id).title == "new"
    idx = chat_store.read_index()
    assert next(e for e in idx if e["id"] == th.id)["title"] == "new"


def test_delete_thread_removes_file_and_index_entry(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    th = chat_store.create_thread(title="x")
    chat_store.delete_thread(th.id)
    assert not chat_paths.thread_path(th.id).exists()
    assert not any(e["id"] == th.id for e in chat_store.read_index())


def test_read_missing_thread_raises(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    import pytest
    with pytest.raises(FileNotFoundError):
        chat_store.read_thread("nope")


def test_index_sorted_by_updated_at_desc(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)
    a = chat_store.create_thread(title="a")
    b = chat_store.create_thread(title="b")
    chat_store.append_turn(a.id, role="user", text="touch")  # makes a newer
    idx = chat_store.read_index()
    assert [e["id"] for e in idx] == [a.id, b.id]
