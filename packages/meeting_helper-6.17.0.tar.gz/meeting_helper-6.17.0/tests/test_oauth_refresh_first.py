"""``build_oauth_provider`` uses the stock MCP ``OAuthClientProvider``.

This file used to test a custom ``_RefreshFirstOAuthClientProvider`` subclass
that force-refreshed loaded tokens on every daemon boot. The override turned
out to be harmful for vendors whose refresh endpoint is unreliable (Atlassian
MCP returns 404 on refresh even with brand-new tokens). The current
implementation uses the stock provider — the SDK tries the loaded bearer,
falls back to refresh on 401, and only opens the OAuth flow as a last resort
(where our passive handler raises ``InteractiveOAuthRequired``).
"""

import pytest
from unittest.mock import AsyncMock

from mcp.client.auth import OAuthClientProvider
from meeting_helper.trackers.oauth import build_oauth_provider


def test_build_oauth_provider_returns_stock_provider():
    """No more custom subclass — the stock SDK behavior is what we want.

    See the docstring on ``build_oauth_provider`` for the rationale.
    """
    provider = build_oauth_provider(
        server_url="https://mcp.example/mcp",
        workspace="W", tracker_id="t-1",
        callback_url="http://127.0.0.1:12345/callback",
        redirect_handler=AsyncMock(),
        callback_handler=AsyncMock(),
    )
    # Stock provider — exact class, not a subclass.
    assert type(provider) is OAuthClientProvider
