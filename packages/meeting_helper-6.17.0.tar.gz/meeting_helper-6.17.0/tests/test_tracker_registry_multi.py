"""TrackerRegistry must support N concurrent Tracker sessions, with a single
designated Copilot tracker mirrored into state.tracker for back-compat."""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from meeting_helper.trackers.registry import TrackerRegistry


def _entry(tid: str, vendor: str = "local_todo", label: str = "L") -> dict:
    return {
        "id": tid,
        "vendor": vendor,
        "label": label,
        "auth_values": {"url": f"http://example/{tid}"},
        "secret_keys": [],
        "chat_enabled": True,
    }


@pytest.mark.asyncio
async def test_ensure_session_lazy_boots_then_caches():
    """Calling ensure_session twice with the same id returns the same Tracker
    object — second call does NOT rebuild."""
    reg = TrackerRegistry()
    fake = MagicMock()

    with patch.object(reg, "_build", return_value=fake) as build:
        t1 = await reg.ensure_session(_entry("a"), workspace_name="W")
        t2 = await reg.ensure_session(_entry("a"), workspace_name="W")
        assert t1 is fake and t2 is fake
        assert build.call_count == 1


@pytest.mark.asyncio
async def test_ensure_session_isolates_distinct_trackers():
    reg = TrackerRegistry()
    fakes = [MagicMock(name="A"), MagicMock(name="B")]
    with patch.object(reg, "_build", side_effect=fakes):
        a = await reg.ensure_session(_entry("a"), workspace_name="W")
        b = await reg.ensure_session(_entry("b"), workspace_name="W")
        assert a is not b


@pytest.mark.asyncio
async def test_set_copilot_swaps_state_tracker_via_provided_state():
    """set_copilot must accept the AppState-like object and mirror the current
    Tracker session for the copilot tracker_id."""
    reg = TrackerRegistry()
    fake = MagicMock()
    state = MagicMock()
    state.tracker = None

    with patch.object(reg, "_build", return_value=fake):
        await reg.ensure_session(_entry("a"), workspace_name="W")
        await reg.set_copilot("a", state=state)
        assert state.tracker is fake


@pytest.mark.asyncio
async def test_set_copilot_to_none_clears_state_tracker():
    reg = TrackerRegistry()
    state = MagicMock()
    state.tracker = MagicMock()
    await reg.set_copilot(None, state=state)
    assert state.tracker is None


@pytest.mark.asyncio
async def test_shutdown_one_closes_that_session_only():
    reg = TrackerRegistry()
    a, b = MagicMock(), MagicMock()
    a.close = AsyncMock()
    b.close = AsyncMock()
    with patch.object(reg, "_build", side_effect=[a, b]):
        await reg.ensure_session(_entry("a"), workspace_name="W")
        await reg.ensure_session(_entry("b"), workspace_name="W")
    await reg.shutdown("a")
    a.close.assert_awaited_once()
    b.close.assert_not_called()
    assert reg.get("a") is None
    assert reg.get("b") is b


@pytest.mark.asyncio
async def test_shutdown_all_closes_every_session():
    reg = TrackerRegistry()
    a, b = MagicMock(), MagicMock()
    a.close = AsyncMock()
    b.close = AsyncMock()
    with patch.object(reg, "_build", side_effect=[a, b]):
        await reg.ensure_session(_entry("a"), workspace_name="W")
        await reg.ensure_session(_entry("b"), workspace_name="W")
    await reg.shutdown()
    a.close.assert_awaited_once()
    b.close.assert_awaited_once()
    assert reg.get("a") is None and reg.get("b") is None


def test_chat_enabled_ids_filters_and_preserves_order():
    """chat_enabled_ids reads config.trackers and returns only entries flagged
    chat_enabled=True, in their declared order."""
    from types import SimpleNamespace
    cfg = SimpleNamespace(trackers=[
        {"id": "a", "vendor": "v", "label": "A", "chat_enabled": True},
        {"id": "b", "vendor": "v", "label": "B", "chat_enabled": False},
        {"id": "c", "vendor": "v", "label": "C", "chat_enabled": True},
        {"id": "d", "vendor": "v", "label": "D"},  # missing → default True
    ])
    reg = TrackerRegistry()
    assert reg.chat_enabled_ids(cfg) == ["a", "c", "d"]


@pytest.mark.asyncio
async def test_concurrent_ensure_session_calls_build_only_once():
    """Two parallel ensure_session() calls for the same tracker_id must
    coalesce — the build only runs once and both callers get the same Tracker.
    """
    reg = TrackerRegistry()
    fake = MagicMock()
    build_calls = 0

    def slow_build(*args, **kwargs):
        nonlocal build_calls
        build_calls += 1
        return fake

    with patch.object(reg, "_build", side_effect=slow_build):
        results = await asyncio.gather(
            reg.ensure_session(_entry("a"), workspace_name="W"),
            reg.ensure_session(_entry("a"), workspace_name="W"),
        )
    assert results[0] is fake and results[1] is fake
    assert build_calls == 1
