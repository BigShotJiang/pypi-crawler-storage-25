"""Verify Tracker picks the right MCP HTTP transport based on URL shape.

Atlassian + Linear expose SSE endpoints (/sse) — using streamable_http
against them silently terminates the session, leaving the chat agent with
no tools. Notion + GitHub use /mcp (streamable_http). The Tracker must
detect this from the URL's last path segment.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from typing import ClassVar
import pytest

from meeting_helper.trackers.profile import (
    AuthField, TransportTemplate, VendorProfile,
)
from meeting_helper.trackers.tracker import Tracker


class _FakeProfile:
    id: ClassVar[str] = "_test"
    label: ClassVar[str] = "Test"
    auth_form: ClassVar[tuple] = (AuthField(key="url", label="url", kind="url"),)
    transport: ClassVar = TransportTemplate(type="http", url_template="{url}")
    supports: ClassVar[frozenset] = frozenset()
    auth_mode: ClassVar[str] = "manual"  # no OAuth → simpler test path
    default_url: ClassVar[str] = ""
    agent_terminology: ClassVar[str] = "x"
    agent_hints: ClassVar[str] = "x"


@pytest.mark.asyncio
async def test_sse_url_uses_sse_client():
    """URL ending in /sse should use mcp.client.sse.sse_client."""
    sse_calls = []
    sh_calls = []

    class _CtxManager:
        async def __aenter__(self): return (MagicMock(), MagicMock())
        async def __aexit__(self, *args): return False

    class _StreamableCtxManager:
        async def __aenter__(self): return (MagicMock(), MagicMock(), MagicMock())
        async def __aexit__(self, *args): return False

    def fake_sse(url, *args, **kw):
        sse_calls.append(url)
        return _CtxManager()

    def fake_streamable(url, *args, **kw):
        sh_calls.append(url)
        return _StreamableCtxManager()

    fake_session = MagicMock()
    fake_session.initialize = AsyncMock()
    session_ctx = MagicMock()
    session_ctx.__aenter__ = AsyncMock(return_value=fake_session)
    session_ctx.__aexit__ = AsyncMock(return_value=False)

    with patch("mcp.client.sse.sse_client", fake_sse), \
         patch("mcp.client.streamable_http.streamablehttp_client", fake_streamable), \
         patch("mcp.client.session.ClientSession", return_value=session_ctx):
        t = Tracker(
            profile=_FakeProfile(),
            transport={"type": "http", "url": "https://mcp.atlassian.com/v1/sse"},
        )
        await t._ensure_started_locked()

    assert sse_calls == ["https://mcp.atlassian.com/v1/sse"], (
        f"expected sse_client called, got sse={sse_calls} sh={sh_calls}"
    )
    assert sh_calls == []


@pytest.mark.asyncio
async def test_mcp_url_uses_streamable_http():
    """URL ending in /mcp should use streamable_http."""
    sse_calls = []
    sh_calls = []

    class _CtxManager:
        async def __aenter__(self): return (MagicMock(), MagicMock())
        async def __aexit__(self, *args): return False

    class _StreamableCtxManager:
        async def __aenter__(self): return (MagicMock(), MagicMock(), MagicMock())
        async def __aexit__(self, *args): return False

    def fake_sse(url, *args, **kw):
        sse_calls.append(url)
        return _CtxManager()

    def fake_streamable(url, *args, **kw):
        sh_calls.append(url)
        return _StreamableCtxManager()

    fake_session = MagicMock()
    fake_session.initialize = AsyncMock()
    session_ctx = MagicMock()
    session_ctx.__aenter__ = AsyncMock(return_value=fake_session)
    session_ctx.__aexit__ = AsyncMock(return_value=False)

    with patch("mcp.client.sse.sse_client", fake_sse), \
         patch("mcp.client.streamable_http.streamablehttp_client", fake_streamable), \
         patch("mcp.client.session.ClientSession", return_value=session_ctx):
        t = Tracker(
            profile=_FakeProfile(),
            transport={"type": "http", "url": "https://mcp.notion.com/mcp"},
        )
        await t._ensure_started_locked()

    assert sh_calls == ["https://mcp.notion.com/mcp"], (
        f"expected streamable_http called, got sse={sse_calls} sh={sh_calls}"
    )
    assert sse_calls == []
