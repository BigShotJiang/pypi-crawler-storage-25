"""POST /provider must accept openai_model.

The Copilot toolbar model chip posts {openai_model: <alias>} to /provider.
provider_post_handler had branches for claude_model, gemini_model and
local_model but NOT openai_model, so changing the OpenAI model from the Copilot
screen was accepted with 200 and silently dropped — the user "couldn't change
the model". This pins the in-memory mutation AND the disk persist.
"""

from __future__ import annotations

import json

import pytest

from meeting_helper import config as config_mod
from meeting_helper.config import AppConfig
from meeting_helper.server.app import create_app


@pytest.fixture
def isolated_config(tmp_path, monkeypatch):
    ws_dir = tmp_path / "workspaces"
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", ws_dir)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json.legacy")
    monkeypatch.setattr(config_mod, "LEGACY_BACKUP", tmp_path / "config.bak")
    monkeypatch.setattr(config_mod, "_config", None)
    yield ws_dir / "default.json"
    monkeypatch.setattr(config_mod, "_config", None)


@pytest.fixture
async def app_client(aiohttp_client, isolated_config):
    app = create_app(AppConfig())
    return await aiohttp_client(app)


async def test_provider_post_persists_openai_model_alias(app_client, isolated_config):
    resp = await app_client.post("/provider", json={"openai_model": "mini"})
    assert resp.status == 200

    disk = json.loads(isolated_config.read_text())
    # Config stores the alias under the bare key, same as claude_model/gemini_model.
    assert disk["openai_model"] == "mini"


async def test_provider_post_resolves_openai_alias_to_full_model(app_client, isolated_config):
    """The runtime model id the streamer uses must resolve to a vision-capable
    model so screenshots actually reach ChatGPT."""
    resp = await app_client.post("/provider", json={"openai_model": "mini"})
    assert resp.status == 200
    cfg = config_mod.get_config()
    assert cfg.openai_model == "gpt-5.4-mini"
