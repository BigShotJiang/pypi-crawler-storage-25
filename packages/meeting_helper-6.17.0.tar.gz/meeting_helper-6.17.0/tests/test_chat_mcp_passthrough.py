"""Tests for the dynamic MCP passthrough tool builder."""

from __future__ import annotations

import asyncio

import pytest

from meeting_helper.chat.tools.mcp_passthrough import (
    _HAND_WRAPPED,
    _is_mutation,
    build_mcp_passthrough_tools,
)


class _StubMCPTool:
    def __init__(self, name: str, description: str = "", input_schema=None):
        self.name = name
        self.description = description
        self.inputSchema = input_schema or {"type": "object", "properties": {}}


class _StubListToolsResponse:
    def __init__(self, tools):
        self.tools = tools


class _StubSession:
    def __init__(self, tools):
        self._tools = tools
        self.calls: list[tuple[str, dict]] = []

    async def list_tools(self):
        return _StubListToolsResponse(self._tools)

    async def call_tool(self, name, args):
        self.calls.append((name, args))
        return {"name": name, "args": args}


class _StubMCP:
    """Mimics the bits of LocalTodoClient that mcp_passthrough touches."""

    def __init__(self, tools):
        self._session = _StubSession(tools)

    async def _ensure_started(self):
        return None

    async def call_tool(self, name, args=None):
        return await self._session.call_tool(name, args or {})


@pytest.mark.asyncio
async def test_oauth_failure_wrapped_in_baseexceptiongroup_sets_needs_reauth():
    """Regression test: an `InteractiveOAuthRequired` raised inside the MCP
    SDK's anyio TaskGroup gets wrapped in a `BaseExceptionGroup` (not a
    plain `ExceptionGroup`, because anyio also wraps a GeneratorExit cleanup
    error in the same group — GeneratorExit is BaseException-only, forcing
    the base-type group).

    A bare `except Exception` in `build_mcp_passthrough_tools` would NOT
    catch `BaseExceptionGroup` (it inherits from BaseException), so the
    OAuth signal would never reach `_contains_exception`, `tracker_needs_reauth`
    would never be set, and the brief task would die silently mid-cleanup.

    This test pins the contract: `build_mcp_passthrough_tools` must catch
    BaseExceptionGroup AND set `state.tracker_needs_reauth` when the group
    contains `InteractiveOAuthRequired`. Removing the BaseExceptionGroup
    branch from the except clause breaks this test."""
    from meeting_helper.trackers.tracker import InteractiveOAuthRequired
    from meeting_helper.state import state as global_state

    class _OAuthFailingMCP:
        _oauth_tracker_id = "tracker-stub"
        _session = None

        async def _ensure_started(self):
            # Mimic anyio's wrapping: BaseExceptionGroup with the OAuth
            # error AND a BaseException-only sibling (here, GeneratorExit)
            # — which forces the GROUP to be `BaseExceptionGroup` rather
            # than `ExceptionGroup`. This is the exact shape we see from
            # the MCP SDK on Notion/Atlassian token expiry.
            raise BaseExceptionGroup(
                "unhandled errors in a TaskGroup (2 sub-exceptions)",
                [
                    InteractiveOAuthRequired(
                        "OAuth re-auth needed for tracker tracker-stub"
                    ),
                    GeneratorExit("cleanup"),
                ],
            )

    # Reset state so we can observe the side effect cleanly.
    global_state.tracker_needs_reauth = None

    tools = await build_mcp_passthrough_tools(_OAuthFailingMCP())

    # Tool listing returned empty — the OAuth-failure path degrades cleanly
    # instead of propagating the BaseExceptionGroup.
    assert tools == []
    # AND the re-auth signal made it into state, which is what the UI's
    # notification toast + Settings StatusDot read.
    assert global_state.tracker_needs_reauth == "tracker-stub", (
        "InteractiveOAuthRequired wrapped in BaseExceptionGroup must trigger "
        "tracker_needs_reauth so the UI can surface a notification"
    )

    global_state.tracker_needs_reauth = None


@pytest.mark.asyncio
async def test_ensure_started_hang_falls_back_to_side_channel_flag(monkeypatch):
    """Regression for the production hang: `_redirect` raises
    `InteractiveOAuthRequired` inside the MCP SDK's anyio TaskGroup. The
    group's cross-task cancel-scope cleanup ORPHANS the OAuth task, so the
    main coroutine awaiting `_ensure_started` never gets the exception —
    it just hangs forever (observed with the Notion expired-token bug).

    Defense: `build_mcp_passthrough_tools` wraps `_ensure_started` with
    `asyncio.wait_for(timeout=15s)` AND checks `mcp._needs_reauth_signaled`
    (set by `_redirect` before it raises) on timeout. This test simulates
    the hang with a never-completing `_ensure_started` and a pre-set flag,
    then asserts the timeout path correctly routes into the needs_reauth
    handling.

    If this test ever stops triggering the timeout branch (e.g. someone
    deletes the `wait_for` wrapper), the production bug returns."""
    from meeting_helper.state import state as global_state

    class _PreFlaggedMCP:
        # Pre-flagged: simulates the state AFTER a previous call already
        # hit the OAuth-redirect-in-passive-mode path and set the side-
        # channel signal. `_ensure_started` is a sentinel that would
        # explode if called — the contract being verified is that
        # build_mcp_passthrough_tools short-circuits BEFORE calling it.
        _oauth_tracker_id = "tracker-stub"
        _session = None
        _needs_reauth_signaled = True
        ensure_called = False

        async def _ensure_started(self):
            self.ensure_called = True
            raise AssertionError(
                "Pre-flagged tracker must short-circuit; _ensure_started "
                "should not be called (otherwise it'd hang on the held "
                "Tracker._lock from the previous attempt)."
            )

    global_state.tracker_needs_reauth = None
    mcp = _PreFlaggedMCP()
    tools = await build_mcp_passthrough_tools(mcp)

    assert tools == []
    assert mcp.ensure_called is False, "must short-circuit before _ensure_started"
    assert global_state.tracker_needs_reauth == "tracker-stub", (
        "Side-channel flag must route a flagged tracker into the "
        "needs_reauth handling — otherwise the production hang returns"
    )

    global_state.tracker_needs_reauth = None


def test_mutation_prefix_classifier():
    assert _is_mutation("create_task") is True
    assert _is_mutation("update_doc") is True
    assert _is_mutation("delete_sprint") is True
    assert _is_mutation("start_sprint") is True
    assert _is_mutation("add_comment") is True
    assert _is_mutation("move_task_to_sprint") is True
    assert _is_mutation("remove_board_member") is True
    assert _is_mutation("revoke_board_invitation") is True
    assert _is_mutation("reorder_custom_fields") is True
    assert _is_mutation("rename_board_column_key") is True
    assert _is_mutation("replace_custom_field_option") is True
    assert _is_mutation("favorite_doc") is True
    assert _is_mutation("close_sprint") is True

    # Reads
    assert _is_mutation("list_boards") is False
    assert _is_mutation("get_doc") is False
    assert _is_mutation("search_tasks") is False
    assert _is_mutation("task_activity") is False
    assert _is_mutation("global_search") is False


@pytest.mark.asyncio
async def test_passthrough_exposes_every_mcp_tool():
    """The dynamic refactor removed all hand-wrapped ``tickets.*`` tools.
    Every MCP tool — including ones we historically wrapped (create_task,
    get_task, add_comment, …) — must now surface under ``mcp.<name>``."""
    tools = [
        _StubMCPTool("create_task"),  # formerly hand-wrapped → now included
        _StubMCPTool("get_task"),  # formerly hand-wrapped → now included
        _StubMCPTool("add_comment"),  # formerly hand-wrapped → now included
        _StubMCPTool("create_sprint"),
        _StubMCPTool("close_sprint"),
    ]
    out = await build_mcp_passthrough_tools(_StubMCP(tools))
    names = {t.name for t in out}
    assert names == {
        "mcp.create_task",
        "mcp.get_task",
        "mcp.add_comment",
        "mcp.create_sprint",
        "mcp.close_sprint",
    }
    # _HAND_WRAPPED is intentionally empty so future MCP tools auto-appear.
    assert _HAND_WRAPPED == frozenset()


@pytest.mark.asyncio
async def test_passthrough_marks_mutations():
    tools = [
        _StubMCPTool("create_sprint"),
        _StubMCPTool("start_sprint"),
        _StubMCPTool("list_my_invitations"),
        _StubMCPTool("get_board"),
    ]
    out = await build_mcp_passthrough_tools(_StubMCP(tools))
    by_name = {t.name: t for t in out}
    assert by_name["mcp.create_sprint"].is_mutation is True
    assert by_name["mcp.start_sprint"].is_mutation is True
    assert by_name["mcp.list_my_invitations"].is_mutation is False
    assert by_name["mcp.get_board"].is_mutation is False


@pytest.mark.asyncio
async def test_passthrough_preserves_jsonschema_verbatim():
    """The MCP returns proper JSON Schema. We must pass it through so
    Anthropic/Gemini accept it directly — re-translating breaks it."""
    schema = {
        "type": "object",
        "required": ["board_id", "name"],
        "properties": {
            "board_id": {"type": "integer", "description": "Target board."},
            "name": {"type": "string"},
            "goal": {"type": "string", "description": "Optional goal."},
        },
    }
    tools = [_StubMCPTool("create_sprint", "Create a sprint.", schema)]
    out = await build_mcp_passthrough_tools(_StubMCP(tools))
    assert len(out) == 1
    assert out[0].input_schema == schema  # verbatim
    assert out[0].description == "Create a sprint."


@pytest.mark.asyncio
async def test_passthrough_run_invokes_mcp_with_args():
    schema = {"type": "object", "properties": {"board_id": {"type": "integer"}}}
    stub = _StubMCP([_StubMCPTool("create_sprint", "d", schema)])
    out = await build_mcp_passthrough_tools(stub)
    result = await out[0].run({"board_id": 1, "name": "S1"}, {"local_todo": stub})
    assert result["status"] == "ok"
    assert stub._session.calls[-1] == ("create_sprint", {"board_id": 1, "name": "S1"})


@pytest.mark.asyncio
async def test_passthrough_run_uses_tracker_key():
    """ctx['tracker'] should be used when available; ctx['local_todo'] is the back-compat fallback."""
    schema = {"type": "object", "properties": {"board_id": {"type": "integer"}}}
    stub = _StubMCP([_StubMCPTool("create_sprint", "d", schema)])
    out = await build_mcp_passthrough_tools(stub)
    # 'tracker' key takes precedence
    result = await out[0].run({"board_id": 2}, {"tracker": stub})
    assert result["status"] == "ok"
    assert stub._session.calls[-1] == ("create_sprint", {"board_id": 2})


@pytest.mark.asyncio
async def test_passthrough_surfaces_mcp_errors_as_tool_results():
    class _Broken:
        async def _ensure_started(self):
            return None

        async def call_tool(self, name, args=None):
            raise RuntimeError("mcp blew up")

    schema = {"type": "object", "properties": {}}
    out = await build_mcp_passthrough_tools(
        _StubMCP([_StubMCPTool("create_sprint", "d", schema)])
    )
    result = await out[0].run({}, {"local_todo": _Broken()})
    assert result["status"] == "error"
    assert "mcp blew up" in result["error"]


@pytest.mark.asyncio
async def test_passthrough_empty_when_mcp_missing():
    out = await build_mcp_passthrough_tools(None)
    assert out == []


@pytest.mark.asyncio
async def test_passthrough_empty_when_introspection_fails():
    class _NoListTools:
        async def _ensure_started(self):
            raise RuntimeError("transport closed")

    out = await build_mcp_passthrough_tools(_NoListTools())
    assert out == []


@pytest.mark.asyncio
async def test_provider_passes_jsonschema_through_unchanged():
    """The ClaudeProvider's _to_jsonschema must detect already-valid
    JSON Schema and pass it through. Otherwise the mcp.* tools' schemas
    would get re-translated into garbage."""
    from meeting_helper.chat.providers import _to_jsonschema

    jsonschema = {
        "type": "object",
        "required": ["board_id"],
        "properties": {
            "board_id": {"type": "integer"},
            "title": {"type": "string"},
        },
    }
    assert _to_jsonschema(jsonschema) == jsonschema

    # Compact still works.
    compact = {"q": "string", "limit": "integer?"}
    out = _to_jsonschema(compact)
    assert out["type"] == "object"
    assert out["properties"]["q"] == {"type": "string"}
    assert out["required"] == ["q"]


def test_sanitize_for_gemini_collapses_union_types():
    """Real MCP schemas declare ``"type": ["string", "number", "null"]`` for
    nullable union fields. Gemini's FunctionDeclaration enum rejects lists,
    so the sanitizer must collapse to a single non-null type before sending."""
    from meeting_helper.chat.providers import _sanitize_for_gemini

    schema = {
        "type": "object",
        "properties": {
            "parent_doc_id": {"type": ["string", "number", "null"], "description": "Doc"},
            "name": {"type": "string"},
            "tags": {
                "type": "array",
                "items": {"type": ["string", "null"]},
            },
            "nested": {
                "type": "object",
                "properties": {
                    "opt": {"type": ["integer", "null"]},
                },
            },
        },
    }
    out = _sanitize_for_gemini(schema)
    # Union collapsed to the first non-null entry.
    assert out["properties"]["parent_doc_id"]["type"] == "string"
    # Plain string field untouched.
    assert out["properties"]["name"]["type"] == "string"
    # Array items recursed.
    assert out["properties"]["tags"]["items"]["type"] == "string"
    # Nested object properties recursed.
    assert out["properties"]["nested"]["properties"]["opt"]["type"] == "integer"


def test_friendly_gemini_error_rewrites_common_codes():
    """We don't want the raw `{'error': {'code': 503, ...}}` dict bubbling
    up to the chat UI. The provider replaces it with a one-line readable
    message that names a concrete action the user can take."""
    from meeting_helper.chat.providers import _friendly_gemini_error

    cases = [
        ("503 UNAVAILABLE. {'error': {'code': 503, 'status': 'UNAVAILABLE'}}", "overloaded"),
        ("429 RESOURCE_EXHAUSTED rate limit", "rate limit"),
        ("404 NOT_FOUND model gemini-3.0-flash not found", "model not available"),
        ("401 PERMISSION_DENIED invalid api key", "rejected the API key"),
    ]
    for raw, expected_phrase in cases:
        friendly = _friendly_gemini_error(RuntimeError(raw))
        assert expected_phrase.lower() in str(friendly).lower(), (raw, friendly)


def test_is_transient_gemini_error_handles_common_cases():
    """Retry on 5xx + 429, fail-fast on 4xx auth/validation."""
    from meeting_helper.chat.providers import _is_transient_gemini_error

    assert _is_transient_gemini_error(RuntimeError("503 UNAVAILABLE high demand"))
    assert _is_transient_gemini_error(RuntimeError("429 quota exhausted"))
    assert _is_transient_gemini_error(RuntimeError("502 BAD_GATEWAY"))
    assert _is_transient_gemini_error(RuntimeError("model is overloaded, retry"))

    assert not _is_transient_gemini_error(RuntimeError("404 NOT_FOUND model x"))
    assert not _is_transient_gemini_error(RuntimeError("401 PERMISSION_DENIED"))
    assert not _is_transient_gemini_error(RuntimeError("400 INVALID_ARGUMENT bad schema"))


def test_sanitize_for_gemini_drops_oneof_anyof():
    """oneOf / anyOf siblings are not modelable in Gemini's function-call
    schema. Keep the first variant and drop the rest."""
    from meeting_helper.chat.providers import _sanitize_for_gemini

    schema = {
        "type": "object",
        "properties": {
            "ref": {
                "oneOf": [
                    {"type": "string"},
                    {"type": "integer"},
                ],
            },
        },
    }
    out = _sanitize_for_gemini(schema)
    assert "oneOf" not in out["properties"]["ref"]
    assert out["properties"]["ref"]["type"] == "string"
