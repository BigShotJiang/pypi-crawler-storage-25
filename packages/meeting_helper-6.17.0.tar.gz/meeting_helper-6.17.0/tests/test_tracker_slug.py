"""Slug derivation for per-tracker chat tool namespacing.

The slug stitches into chat tool names as `<slug>__<original_tool>`, so it
must round-trip through Anthropic/Gemini tool-name validation
(`^[a-zA-Z0-9_-]{1,128}$`).
"""

import pytest
from meeting_helper.trackers.slug import slug_for_label, slugify_unique


@pytest.mark.parametrize("label,expected", [
    ("Notion", "notion"),
    ("Notion — Work", "notion-work"),
    ("Notion (Personal)", "notion-personal"),
    ("Jira / Sprint #1", "jira-sprint-1"),
    ("  Local  Todo  ", "local-todo"),
    ("CAMEL_case_Label", "camel-case-label"),
])
def test_slug_for_label_normalises(label, expected):
    assert slug_for_label(label) == expected


def test_slug_for_label_falls_back_when_empty():
    """Whitespace/punctuation-only labels collapse to empty; fall back to a
    safe placeholder so chat tools still register."""
    assert slug_for_label("") == "tracker"
    assert slug_for_label("   ") == "tracker"
    assert slug_for_label("!!!") == "tracker"


def test_slugify_unique_disambiguates_collisions():
    """Two labels that slug to the same value get -2, -3 suffixes in order."""
    out = []
    taken: set[str] = set()
    out.append(slugify_unique("Notion", taken))
    out.append(slugify_unique("notion!", taken))   # collides
    out.append(slugify_unique("NOTION ", taken))   # collides again
    assert out == ["notion", "notion-2", "notion-3"]


def test_slugify_unique_idempotent_with_distinct_labels():
    taken: set[str] = set()
    assert slugify_unique("Jira", taken) == "jira"
    assert slugify_unique("Notion", taken) == "notion"
    assert slugify_unique("Local Todo", taken) == "local-todo"
    assert taken == {"jira", "notion", "local-todo"}
