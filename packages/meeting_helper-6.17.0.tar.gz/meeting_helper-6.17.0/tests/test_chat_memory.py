import pytest

from meeting_helper.chat import memory as chat_memory
from meeting_helper.chat import paths as chat_paths


@pytest.fixture(autouse=True)
def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


def test_read_all_empty_when_no_file():
    assert chat_memory.read_all() == []


def test_add_and_read_returns_entry():
    e = chat_memory.add(text="user prefers TypeScript")
    assert e["id"].startswith("mem_")
    assert e["text"] == "user prefers TypeScript"
    assert e["source"] == "agent"
    assert e["pinned"] is False
    assert e["created_at"]
    assert e["updated_at"]
    entries = chat_memory.read_all()
    assert len(entries) == 1
    assert entries[0]["id"] == e["id"]


def test_add_empty_raises():
    with pytest.raises(ValueError):
        chat_memory.add(text="   ")


def test_update_text_and_pinned():
    e = chat_memory.add(text="original")
    upd = chat_memory.update(e["id"], text="refined", pinned=True)
    assert upd is not None
    assert upd["text"] == "refined"
    assert upd["pinned"] is True
    entries = chat_memory.read_all()
    assert entries[0]["text"] == "refined"
    assert entries[0]["pinned"] is True


def test_update_missing_returns_none():
    assert chat_memory.update("mem_missing", text="x") is None


def test_update_empty_text_raises():
    e = chat_memory.add(text="original")
    with pytest.raises(ValueError):
        chat_memory.update(e["id"], text="   ")


def test_delete_removes_entry():
    e = chat_memory.add(text="x")
    assert chat_memory.delete(e["id"]) is True
    assert chat_memory.read_all() == []


def test_delete_missing_returns_false():
    assert chat_memory.delete("mem_nope") is False


def test_as_prompt_block_empty():
    assert chat_memory.as_prompt_block() == ""


def test_as_prompt_block_includes_entries_and_pinned_first():
    chat_memory.add(text="first")
    chat_memory.add(text="second", pinned=True)
    block = chat_memory.as_prompt_block()
    assert "Long-term memory" in block
    assert "- first" in block
    assert "- second" in block
    # Pinned should come before others
    assert block.index("second") < block.index("first")
