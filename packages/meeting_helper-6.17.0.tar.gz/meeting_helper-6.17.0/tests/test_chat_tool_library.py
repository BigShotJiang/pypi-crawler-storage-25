import pytest

from meeting_helper.chat.tools.library import (
    build_library_fetch_kb,
    build_library_get_meeting,
    build_library_get_note,
    build_library_list_recent,
    build_library_search_meetings,
)


@pytest.mark.asyncio
async def test_search_meetings_filters_by_query(monkeypatch):
    canned = [
        {"id": "m1", "title": "Cliff sync", "date": "2026-05-13", "has_transcript": True},
        {"id": "m2", "title": "Standup", "date": "2026-05-14", "has_transcript": True},
    ]
    from meeting_helper.chat.tools import library as mod

    async def _list():
        return {"items": canned}

    monkeypatch.setattr(mod, "_load_library_items", _list)
    out = await build_library_search_meetings().run({"q": "Cliff"}, {})
    assert out["status"] == "ok"
    assert len(out["result"]["matches"]) == 1
    assert out["result"]["matches"][0]["id"] == "m1"


@pytest.mark.asyncio
async def test_get_meeting_returns_transcript_summary_kb(monkeypatch):
    from meeting_helper.chat.tools import library as mod

    async def _fetch(mid):
        assert mid == "m1"
        return {"transcript": "T", "summary": "S", "kb": [{"id": "k1", "text": "note"}]}

    monkeypatch.setattr(mod, "_fetch_meeting_bundle", _fetch)
    out = await build_library_get_meeting().run({"meeting_id": "m1"}, {})
    assert out["result"]["transcript"] == "T"
    assert out["result"]["summary"] == "S"
    assert out["result"]["kb"][0]["id"] == "k1"


@pytest.mark.asyncio
async def test_get_meeting_resolves_title_to_id(monkeypatch):
    """Weak models pass the title instead of the id; get_meeting should resolve
    it against the meeting list rather than dead-ending (Gemini parity)."""
    from meeting_helper.chat.tools import library as mod
    real_id = "2026-05-20_120000_Datadog_API_Keys_Logging.summary.txt"
    items = [{"id": real_id, "kind": "meeting", "title": "Datadog API Keys Logging", "date": "2026-05-20"}]

    async def _list():
        return {"items": items}

    async def _fetch(mid):
        return {"id": mid, "summary_text": "S"} if mid == real_id else None

    monkeypatch.setattr(mod, "_load_library_items", _list)
    monkeypatch.setattr(mod, "_fetch_meeting_bundle", _fetch)
    out = await mod.build_library_get_meeting().run(
        {"meeting_id": "Datadog API Keys Logging"}, {}
    )
    assert out["status"] == "ok"
    assert out["result"]["id"] == real_id


@pytest.mark.asyncio
async def test_get_meeting_resolves_underscored_and_id_forms(monkeypatch):
    """Flash Lite passed 'Manual_Recording' (underscores) and dead-ended on the
    space-vs-underscore mismatch. Normalized matching must resolve it, plus a
    partial id form, to the real meeting."""
    from meeting_helper.chat.tools import library as mod
    real_id = "2026-05-20_141633_Manual_Recording"
    items = [{"id": real_id, "kind": "meeting", "title": "Manual Recording", "date": "2026-05-20"}]

    async def _list():
        return {"items": items}

    async def _fetch(mid):
        return {"id": mid, "summary_text": "S"} if mid == real_id else None

    monkeypatch.setattr(mod, "_load_library_items", _list)
    monkeypatch.setattr(mod, "_fetch_meeting_bundle", _fetch)
    for probe in ["Manual_Recording", "manual_recording", "2026-05-20_141633_Manual_Recording"]:
        out = await mod.build_library_get_meeting().run({"meeting_id": probe}, {})
        assert out["status"] == "ok", f"{probe!r} should resolve"
        assert out["result"]["id"] == real_id


@pytest.mark.asyncio
async def test_get_meeting_unknown_returns_helpful_error(monkeypatch):
    from meeting_helper.chat.tools import library as mod
    items = [{"id": "m1", "kind": "meeting", "title": "Standup", "date": "2026-05-19"}]

    async def _list():
        return {"items": items}

    async def _fetch(mid):
        return None

    monkeypatch.setattr(mod, "_load_library_items", _list)
    monkeypatch.setattr(mod, "_fetch_meeting_bundle", _fetch)
    out = await mod.build_library_get_meeting().run({"meeting_id": "no such meeting"}, {})
    assert out["status"] == "error"
    assert out["recent_meetings"][0]["id"] == "m1"


@pytest.mark.asyncio
async def test_fetch_kb_returns_single_entry(monkeypatch):
    from meeting_helper.chat.tools import library as mod

    async def _fetch_kb(kb_id):
        assert kb_id == "k1"
        return {"id": "k1", "text": "Note body"}

    monkeypatch.setattr(mod, "_fetch_kb_entry", _fetch_kb)
    out = await build_library_fetch_kb().run({"kb_id": "k1"}, {})
    assert out["result"]["text"] == "Note body"


@pytest.mark.asyncio
async def test_list_recent_returns_newest_first_capped(monkeypatch):
    from meeting_helper.chat.tools import library as mod
    canned = [
        {"id": f"m{i}", "title": f"M{i}", "date": "2026-05-14", "has_transcript": True}
        for i in range(30)
    ]

    async def _list():
        return {"items": canned}

    monkeypatch.setattr(mod, "_load_library_items", _list)
    out = await build_library_list_recent().run({"limit": 5}, {})
    assert out["status"] == "ok"
    assert len(out["result"]["meetings"]) == 5
    assert out["result"]["meetings"][0]["id"] == "m0"


@pytest.mark.asyncio
async def test_list_recent_excludes_notes(monkeypatch):
    """Ticket #45: 'last meeting' must not return a note. The library list is
    newest-first and mixes meetings + notes; list_recent filters to meetings."""
    from meeting_helper.chat.tools import library as mod
    canned = [
        {"id": "n1", "kind": "note", "title": "Newest note", "date": "2026-05-20"},
        {"id": "m1", "kind": "meeting", "title": "Standup", "date": "2026-05-19"},
        {"id": "n2", "kind": "note", "title": "Older note", "date": "2026-05-18"},
    ]

    async def _list():
        return {"items": canned}

    monkeypatch.setattr(mod, "_load_library_items", _list)
    out = await build_library_list_recent().run({"limit": 10}, {})
    assert out["status"] == "ok"
    returned = out["result"]["meetings"]
    assert [m["id"] for m in returned] == ["m1"]
    assert all(m.get("kind") != "note" for m in returned)


@pytest.mark.asyncio
async def test_search_meetings_falls_back_to_summary_content(monkeypatch, tmp_path):
    from meeting_helper.chat.tools import library as mod
    summary_path = tmp_path / "2026-05-14_141518_Stand_Up.summary.txt"
    summary_path.write_text("Discussed ClickHouse phase 1 and next steps.")
    canned = [
        {"id": "m1", "title": "Stand Up", "date": "2026-05-14",
         "has_transcript": True, "summary_filename": summary_path.name},
    ]

    async def _list():
        return {"items": canned}

    monkeypatch.setattr(mod, "_load_library_items", _list)

    class _StubCfg:
        recordings_dir = tmp_path

    import meeting_helper.config as _config_mod
    monkeypatch.setattr(_config_mod, "get_config", lambda: _StubCfg())
    out = await build_library_search_meetings().run({"q": "clickhouse"}, {})
    assert out["status"] == "ok"
    assert len(out["result"]["matches"]) == 1
    assert out["result"]["matches"][0]["id"] == "m1"


@pytest.mark.asyncio
async def test_get_note_reads_note_body(monkeypatch, tmp_path):
    note_path = tmp_path / "2026-05-14_Sync_with_Cliff.note.md"
    note_path.write_text("# Sync with Cliff\n\nDiscussed gradle release plugin steps.")
    class _StubCfg:
        recordings_dir = tmp_path
    from meeting_helper import config as cfg_mod
    monkeypatch.setattr(cfg_mod, "get_config", lambda: _StubCfg())
    from meeting_helper.chat.tools import library as mod
    out = await mod.build_library_get_note().run({"note_id": note_path.name}, {})
    assert out["status"] == "ok"
    assert "gradle release plugin" in out["result"]["body"]


@pytest.mark.asyncio
async def test_get_note_appends_suffix_when_missing(monkeypatch, tmp_path):
    note_path = tmp_path / "design.note.md"
    note_path.write_text("design notes here")
    class _StubCfg:
        recordings_dir = tmp_path
    from meeting_helper import config as cfg_mod
    monkeypatch.setattr(cfg_mod, "get_config", lambda: _StubCfg())
    from meeting_helper.chat.tools import library as mod
    out = await mod.build_library_get_note().run({"note_id": "design"}, {})
    assert out["status"] == "ok"


@pytest.mark.asyncio
async def test_get_note_rejects_path_traversal():
    from meeting_helper.chat.tools import library as mod
    out = await mod.build_library_get_note().run({"note_id": "../../etc/passwd"}, {})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_search_meetings_falls_back_to_note_body(monkeypatch, tmp_path):
    note_path = tmp_path / "design.note.md"
    note_path.write_text("Decided to use ClickHouse for the new pipeline.")
    canned = [
        {"id": note_path.name, "kind": "note", "title": "Design notes", "date": "",
         "summary_filename": "", "note_filename": note_path.name},
    ]
    from meeting_helper.chat.tools import library as mod
    async def _list(): return {"items": canned}
    monkeypatch.setattr(mod, "_load_library_items", _list)
    from meeting_helper import config as cfg_mod
    class _StubCfg:
        recordings_dir = tmp_path
    monkeypatch.setattr(cfg_mod, "get_config", lambda: _StubCfg())
    out = await mod.build_library_search_meetings().run({"q": "clickhouse"}, {})
    assert out["status"] == "ok"
    assert len(out["result"]["matches"]) == 1
