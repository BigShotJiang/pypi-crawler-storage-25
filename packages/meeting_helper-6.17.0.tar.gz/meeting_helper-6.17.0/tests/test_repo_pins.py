import subprocess

import pytest

from meeting_helper.state import AppState, PinnedItem
from meeting_helper.state import state as global_state
from meeting_helper.ai.client import _format_pinned_topics_markdown
from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig


def _git(path, *args):
    subprocess.run(
        ["git", "-C", str(path), *args],
        check=True, capture_output=True, text=True,
    )


@pytest.fixture
def git_repo(tmp_path):
    p = tmp_path / "r"
    p.mkdir()
    _git(p, "init", "-q", "-b", "main")
    _git(p, "config", "user.email", "t@t")
    _git(p, "config", "user.name", "t")
    (p / "a.txt").write_text("base\n")
    _git(p, "add", "-A")
    _git(p, "commit", "-qm", "base")
    _git(p, "checkout", "-q", "-b", "feat")
    (p / "a.txt").write_text("base\nchange\n")
    _git(p, "commit", "-qam", "feat change")
    return p


@pytest.fixture
async def client(aiohttp_client, git_repo):
    cfg = AppConfig(
        dev_mode=True,
        dev_repos=[{"path": str(git_repo), "base_branch": "main"}],
    )
    app = create_app(cfg)
    return await aiohttp_client(app)


@pytest.fixture(autouse=True)
def _clean_state():
    global_state.clear_pins()
    global_state.repo_diffs.clear()
    yield
    global_state.clear_pins()
    global_state.repo_diffs.clear()


async def test_repo_load_runs_diff(client, git_repo):
    resp = await client.post(
        "/topic/repo/load", json={"path": str(git_repo), "base_branch": "main"}
    )
    assert resp.status == 200
    data = await resp.json()
    assert data["ok"] is True
    assert data["branch"] == "feat"
    assert data["truncated"] is False
    ct = await client.get("/current_topic")
    body = await ct.json()
    repo_pins = [p for p in body["pinned"] if p["kind"] == "repo"]
    assert len(repo_pins) == 1
    assert repo_pins[0]["loaded_branch"] == "feat"
    assert repo_pins[0]["loaded_sha"]


async def test_repo_load_rejects_unconfigured(client):
    resp = await client.post("/topic/repo/load", json={"path": "/not/configured"})
    assert resp.status == 400


async def test_config_get_includes_dev_fields(client, git_repo):
    resp = await client.get("/config")
    assert resp.status == 200
    body = await resp.json()
    assert "dev_mode" in body
    assert isinstance(body["dev_repos"], list)
    assert body["dev_repos"][0]["path"] == str(git_repo)


async def test_dev_repos_list(client, git_repo):
    resp = await client.get("/dev/repos")
    assert resp.status == 200
    body = await resp.json()
    assert len(body["repos"]) == 1
    assert body["repos"][0]["exists"] is True
    assert body["repos"][0]["current_branch"] == "feat"


async def test_topic_clear_drops_repo_diff(client, git_repo):
    await client.post(
        "/topic/repo/load", json={"path": str(git_repo), "base_branch": "main"}
    )
    assert str(git_repo) in global_state.repo_diffs
    resp = await client.post("/topic/clear", json={})
    assert resp.status == 200
    # Repos are per-meeting: clearing the basket drops the loaded diff too.
    assert global_state.repo_diffs == {}
    assert not any(p.kind == "repo" for p in global_state.pinned_topics)


async def test_dev_repos_hidden_when_dev_mode_off(aiohttp_client, git_repo):
    cfg = AppConfig(
        dev_mode=False,
        dev_repos=[{"path": str(git_repo), "base_branch": "main"}],
    )
    c = await aiohttp_client(create_app(cfg))
    resp = await c.get("/dev/repos")
    assert resp.status == 200
    assert (await resp.json())["repos"] == []


class _Cfg:
    action_items_inject_into_copilot = True
    recordings_dir = "/tmp"


def test_repo_pin_renders_diff_block():
    global_state.clear_pins()
    global_state.repo_diffs.clear()
    global_state.pin_topic(PinnedItem(kind="repo", id="/tmp/r", title="r"))
    global_state.set_repo_diff("/tmp/r", {
        "branch": "feat", "head_sha": "abc1234",
        "stat": "a.txt | 2 +-", "body": "+change", "truncated": False,
    })
    try:
        md = _format_pinned_topics_markdown(_Cfg())
        assert "[repo] r" in md
        assert "feat@abc1234" in md
        assert "a.txt | 2 +-" in md
        assert "+change" in md
    finally:
        global_state.clear_pins()
        global_state.repo_diffs.clear()


def test_repo_pin_not_loaded_yet():
    global_state.clear_pins()
    global_state.repo_diffs.clear()
    global_state.pin_topic(PinnedItem(kind="repo", id="/tmp/r", title="r"))
    try:
        md = _format_pinned_topics_markdown(_Cfg())
        assert "not loaded yet" in md
    finally:
        global_state.clear_pins()
        global_state.repo_diffs.clear()


def test_repo_diff_set_get_clear():
    s = AppState()
    assert s.repo_diffs == {}
    s.set_repo_diff("/tmp/r", {
        "branch": "feat", "head_sha": "abc1234",
        "stat": "1 file", "body": "+x", "truncated": False,
    })
    assert s.repo_diffs["/tmp/r"]["branch"] == "feat"
    assert s.clear_repo_diff("/tmp/r") is True
    assert s.clear_repo_diff("/tmp/r") is False
    assert s.repo_diffs == {}
