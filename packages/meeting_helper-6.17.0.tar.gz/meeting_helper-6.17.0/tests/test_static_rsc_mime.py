"""Verify Next.js RSC payload (.txt) files are served with text/x-component
so the App Router client doesn't display them as raw page content."""
import pytest
from aiohttp.test_utils import TestServer, TestClient
from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig


@pytest.mark.asyncio
async def test_index_txt_is_served_as_x_component(tmp_path, monkeypatch):
    # Build a minimal fake bundle that mirrors Next.js static-export layout.
    from meeting_helper.server import app as app_mod
    bundle = tmp_path / "dist"
    (bundle / "settings").mkdir(parents=True)
    (bundle / "index.html").write_text("<html>root</html>")
    (bundle / "settings" / "index.html").write_text("<html>settings</html>")
    (bundle / "settings" / "index.txt").write_text('1:"$Sreact.fragment"\n')
    monkeypatch.setattr(app_mod, "WEB_DIST", bundle)

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        # RSC payload — must be text/x-component, NOT text/plain
        r = await client.get("/settings/index.txt")
        assert r.status == 200
        ct = r.headers.get("Content-Type", "")
        assert "x-component" in ct, f"got {ct!r}"

        # HTML page still served as text/html
        r = await client.get("/settings/")
        assert r.status == 200
        assert "text/html" in r.headers.get("Content-Type", "")


@pytest.mark.asyncio
async def test_non_index_txt_still_text_plain(tmp_path, monkeypatch):
    """Other .txt files (e.g. a robots.txt, a static asset .txt) should NOT
    be reclassified — only Next's index.txt RSC payloads need x-component."""
    from meeting_helper.server import app as app_mod
    bundle = tmp_path / "dist"
    bundle.mkdir()
    (bundle / "index.html").write_text("root")
    (bundle / "robots.txt").write_text("User-agent: *\n")
    monkeypatch.setattr(app_mod, "WEB_DIST", bundle)

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        r = await client.get("/robots.txt")
        assert r.status == 200
        ct = r.headers.get("Content-Type", "")
        # Should NOT be x-component
        assert "x-component" not in ct, f"got {ct!r}"


@pytest.mark.asyncio
async def test_index_txt_browser_navigation_serves_html(tmp_path, monkeypatch):
    """A browser-level navigation to /settings/index.txt (pywebview restoring
    last URL, hard reload, address-bar paste) sends Accept: text/html. We must
    serve the sibling index.html in that case, NOT the raw RSC payload — same
    fix shape as 42658b8 (/library).
    """
    from meeting_helper.server import app as app_mod
    bundle = tmp_path / "dist"
    (bundle / "settings").mkdir(parents=True)
    (bundle / "index.html").write_text("<html>root</html>")
    (bundle / "settings" / "index.html").write_text("<html>real settings page</html>")
    (bundle / "settings" / "index.txt").write_text('1:"$Sreact.fragment"\n')
    monkeypatch.setattr(app_mod, "WEB_DIST", bundle)

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        # Browser navigation: Accept advertises HTML, no RSC header.
        r = await client.get(
            "/settings/index.txt",
            headers={"Accept": "text/html,application/xhtml+xml,*/*;q=0.8"},
        )
        assert r.status == 200
        assert "text/html" in r.headers.get("Content-Type", "")
        body = await r.text()
        assert "real settings page" in body
        assert "$Sreact.fragment" not in body

        # Next.js RSC prefetch (RSC: 1 header) still gets the x-component payload.
        r = await client.get("/settings/index.txt", headers={"RSC": "1"})
        assert r.status == 200
        assert "x-component" in r.headers.get("Content-Type", "")
        assert "$Sreact.fragment" in await r.text()


@pytest.mark.asyncio
async def test_directory_index_html_served(tmp_path, monkeypatch):
    """Regression: /settings/ resolves to dist/settings/index.html."""
    from meeting_helper.server import app as app_mod
    bundle = tmp_path / "dist"
    (bundle / "settings").mkdir(parents=True)
    (bundle / "index.html").write_text("root")
    (bundle / "settings" / "index.html").write_text("<html>settings</html>")
    monkeypatch.setattr(app_mod, "WEB_DIST", bundle)

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        r = await client.get("/settings/")
        assert r.status == 200
        assert "settings" in await r.text()
