import warnings
from meeting_helper.state import state


def test_local_todo_alias_returns_tracker_with_warning():
    state.tracker = "marker"  # type: ignore[assignment]
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            assert state.local_todo == "marker"
            assert any(issubclass(w.category, DeprecationWarning) for w in caught)
    finally:
        state.tracker = None  # type: ignore[assignment]


def test_record_tracker_call_separates_vendor():
    state.reset_local_todo_counters()
    state.record_tracker_call("jira", "search")
    state.record_tracker_call("jira", "search")
    state.record_tracker_call("local_todo", "list_boards")
    # New counter shape
    stats = state.tracker_call_stats()
    assert stats["jira"]["search"] == 2
    assert stats["local_todo"]["list_boards"] == 1
