"""Speaker-map I/O, merge, render-time substitution, label extraction."""
import json

import pytest

from meeting_helper import speakers


def test_write_then_read_roundtrip(tmp_path):
    path = tmp_path / "m.speakers.json"
    speakers.write_speaker_map(
        path,
        names={"OTHER#0": "Maria", "OTHER#1": None},
        evidence={"OTHER#0": "Hey Maria"},
        source={"OTHER#0": "ai", "OTHER#1": "ai"},
    )
    data = speakers.read_speaker_map(path)
    assert data.names == {"OTHER#0": "Maria", "OTHER#1": None}
    assert data.evidence == {"OTHER#0": "Hey Maria"}
    assert data.source == {"OTHER#0": "ai", "OTHER#1": "ai"}


def test_read_missing_returns_empty(tmp_path):
    data = speakers.read_speaker_map(tmp_path / "nope.json")
    assert data.names == {}
    assert data.evidence == {}
    assert data.source == {}


def test_merge_manual_wins_over_ai():
    existing = speakers.SpeakerMap(
        names={"OTHER#0": "Maria"},
        evidence={},
        source={"OTHER#0": "manual"},
    )
    incoming = speakers.SpeakerMap(
        names={"OTHER#0": "Wrong", "OTHER#1": "Alex"},
        evidence={"OTHER#0": "x", "OTHER#1": "y"},
        source={"OTHER#0": "ai", "OTHER#1": "ai"},
    )
    merged = speakers.merge_speaker_map(existing, incoming)
    # Manual entry for OTHER#0 preserved.
    assert merged.names["OTHER#0"] == "Maria"
    assert merged.source["OTHER#0"] == "manual"
    # New AI entry for OTHER#1 accepted.
    assert merged.names["OTHER#1"] == "Alex"
    assert merged.source["OTHER#1"] == "ai"


def test_merge_ai_overwrites_existing_ai_or_null():
    existing = speakers.SpeakerMap(
        names={"OTHER#0": None, "OTHER#1": "OldGuess"},
        evidence={},
        source={"OTHER#0": "ai", "OTHER#1": "ai"},
    )
    incoming = speakers.SpeakerMap(
        names={"OTHER#0": "NewGuess", "OTHER#1": "BetterGuess"},
        evidence={"OTHER#0": "e0", "OTHER#1": "e1"},
        source={"OTHER#0": "ai", "OTHER#1": "ai"},
    )
    merged = speakers.merge_speaker_map(existing, incoming)
    assert merged.names["OTHER#0"] == "NewGuess"
    assert merged.names["OTHER#1"] == "BetterGuess"


def test_extract_speaker_labels_from_live_txt():
    text = (
        "[00:01] SELF: hi\n"
        "[00:02] OTHER#0: hello\n"
        "[00:03] OTHER#1: hi back\n"
        "[00:04] OTHER#0: same speaker again\n"
        "[00:05] OTHER: undiarized line\n"
    )
    labels = speakers.extract_speaker_labels(text)
    assert labels == ["SELF", "OTHER", "OTHER#0", "OTHER#1"]


def test_apply_speaker_map_replaces_in_text():
    text = "[00:01] OTHER#0: hello\n[00:02] OTHER#1: hi\n[00:03] SELF: ok"
    names = {"OTHER#0": "Maria", "OTHER#1": "Alex", "SELF": "Victor"}
    out = speakers.apply_speaker_map(text, names)
    assert out == "[00:01] Maria: hello\n[00:02] Alex: hi\n[00:03] Victor: ok"


def test_apply_speaker_map_leaves_unknown_labels():
    text = "[00:01] OTHER#0: hi\n[00:02] OTHER#1: hello"
    out = speakers.apply_speaker_map(text, {"OTHER#0": "Maria"})
    assert "Maria: hi" in out
    assert "OTHER#1: hello" in out


def test_apply_speaker_map_only_at_role_position():
    # "OTHER#0" inside a sentence is NOT replaced.
    text = "[00:01] SELF: I told OTHER#0 to relax"
    out = speakers.apply_speaker_map(text, {"OTHER#0": "Maria", "SELF": "Victor"})
    assert out == "[00:01] Victor: I told OTHER#0 to relax"


def test_apply_speaker_map_skips_null_names():
    text = "[00:01] OTHER#0: hi"
    out = speakers.apply_speaker_map(text, {"OTHER#0": None})
    assert out == text


def test_read_malformed_json_returns_empty(tmp_path):
    path = tmp_path / "bad.speakers.json"
    path.write_text("{ not valid json")
    data = speakers.read_speaker_map(path)
    assert data.names == {}
    assert data.evidence == {}
    assert data.source == {}


def test_read_non_dict_json_returns_empty(tmp_path):
    path = tmp_path / "wrong.speakers.json"
    path.write_text("[1, 2, 3]")
    data = speakers.read_speaker_map(path)
    assert data.names == {}
    assert data.evidence == {}
    assert data.source == {}


def test_as_payload_returns_shallow_copies():
    m = speakers.SpeakerMap(
        names={"SELF": "Victor"},
        evidence={"SELF": "x"},
        source={"SELF": "manual"},
    )
    payload = m.as_payload()
    payload["names"]["SELF"] = "Mutated"
    payload["evidence"]["SELF"] = "Mutated"
    payload["source"]["SELF"] = "ai"
    # Original SpeakerMap must be unaffected.
    assert m.names == {"SELF": "Victor"}
    assert m.evidence == {"SELF": "x"}
    assert m.source == {"SELF": "manual"}
