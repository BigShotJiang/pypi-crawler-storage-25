"""POST /trackers/{id}/connect — happy + error paths."""
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from aiohttp.test_utils import TestServer, TestClient
from meeting_helper.server.app import create_app
from meeting_helper.config import AppConfig


@pytest.mark.asyncio
async def test_connect_rejects_manual_vendors(monkeypatch):
    """If a vendor is patched to auth_mode='manual', connect must reject with 400."""
    from meeting_helper.trackers.vendors.local_todo import LocalTodoProfile
    monkeypatch.setattr(LocalTodoProfile, "auth_mode", "manual", raising=False)

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        resp = await client.post("/trackers", json={
            "vendor": "local_todo", "label": "LT",
            "auth_values": {"url": "http://127.0.0.1:9/mcp"},
            "secrets": {},
        })
        tid = (await resp.json())["id"]
        resp = await client.post(f"/trackers/{tid}/connect")
        # auth_mode='manual' → connect must reject
        assert resp.status == 400
        body = await resp.json()
        assert "OAuth" in body["error"] or "not support" in body["error"]


@pytest.mark.asyncio
async def test_connect_returns_404_for_unknown_tracker():
    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        resp = await client.post("/trackers/does-not-exist/connect")
        assert resp.status == 404


@pytest.mark.asyncio
async def test_connect_runs_for_oauth_vendor_when_present(monkeypatch):
    """When a vendor has auth_mode='mcp_oauth', the handler should attempt
    the flow. We stub Tracker._ensure_started + _session.list_tools to
    avoid real network — that's the vendor-agnostic probe the handler
    runs after OAuth (works for any MCP server, not just local-todo)."""
    from meeting_helper.trackers.vendors.local_todo import LocalTodoProfile
    # Force auth_mode='mcp_oauth' on LocalTodoProfile for this test
    monkeypatch.setattr(LocalTodoProfile, "auth_mode", "mcp_oauth", raising=False)
    # Also force the transport to http so the OAuth path is taken
    from meeting_helper.trackers.profile import TransportTemplate
    monkeypatch.setattr(
        LocalTodoProfile, "transport",
        TransportTemplate(type="http", url_template="http://127.0.0.1:9/mcp"),
        raising=False,
    )

    class _FakeTool:
        def __init__(self, name): self.name = name

    class _FakeToolsResp:
        tools = [_FakeTool("mcp.search_boards")]

    fake_session = MagicMock()
    fake_session.list_tools = AsyncMock(return_value=_FakeToolsResp())

    # The handler calls await tracker._ensure_started() and then reads
    # tracker._session.list_tools(). Stub _ensure_started to assign the fake
    # session onto the instance (per-instance attr, not class attr — so a
    # plain class-level monkeypatch doesn't reach it).
    async def _fake_ensure_started(self):
        self._session = fake_session
    monkeypatch.setattr(
        "meeting_helper.trackers.tracker.Tracker._ensure_started",
        _fake_ensure_started,
    )

    monkeypatch.setattr(
        "meeting_helper.trackers.tracker.Tracker.close",
        AsyncMock(),
    )
    monkeypatch.setattr(
        "meeting_helper.trackers.registry.reboot_active_tracker",
        AsyncMock(),
    )
    # Probe succeeds → keychain check still happens; stub get_tokens so
    # the handler returns ok:True without touching the OS keychain.
    fake_token = MagicMock()
    monkeypatch.setattr(
        "meeting_helper.trackers.oauth.KeychainTokenStorage.get_tokens",
        AsyncMock(return_value=fake_token),
    )

    app = create_app(AppConfig())
    async with TestClient(TestServer(app)) as client:
        resp = await client.post("/trackers", json={
            "vendor": "local_todo", "label": "LT",
            "auth_values": {"url": "http://127.0.0.1:9/mcp"},
            "secrets": {},
        })
        tid = (await resp.json())["id"]
        resp = await client.post(f"/trackers/{tid}/connect")
        assert resp.status == 200, await resp.text()
        body = await resp.json()
        assert body["ok"] is True
        # Probe now returns a sample of MCP tool names instead of vendor
        # workspaces, but the field is still called `workspaces` for
        # back-compat with the UI.
        assert "mcp.search_boards" in body["workspaces"]
