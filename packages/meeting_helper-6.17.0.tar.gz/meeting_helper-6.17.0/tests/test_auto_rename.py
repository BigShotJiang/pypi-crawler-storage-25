"""Tests for the auto-rename plumbing on meeting end.

Covers the pure helpers in session.py (`_rename_meeting_artifacts`,
`_has_ai_provider`) and the AI client's name cleaner.
"""

from __future__ import annotations

from pathlib import Path

from meeting_helper.ai.client import _clean_meeting_name
from meeting_helper.config import AppConfig
from meeting_helper.session import _has_ai_provider, _rename_meeting_artifacts


# ---------------------------------------------------------------------------
# _clean_meeting_name
# ---------------------------------------------------------------------------

def test_clean_meeting_name_strips_quotes_and_punctuation():
    assert _clean_meeting_name('"Payments API Migration"') == "Payments API Migration"
    assert _clean_meeting_name("Payments API Migration.") == "Payments API Migration"
    assert _clean_meeting_name("`Payments API Sync`") == "Payments API Sync"


def test_clean_meeting_name_caps_at_eight_words():
    raw = "one two three four five six seven eight nine ten"
    assert _clean_meeting_name(raw).split() == [
        "one", "two", "three", "four", "five", "six", "seven", "eight",
    ]


def test_clean_meeting_name_drops_non_ascii():
    assert _clean_meeting_name("Reunião Semanal Equipe") == "Reuni o Semanal Equipe"


def test_clean_meeting_name_handles_empty():
    assert _clean_meeting_name("") == ""
    assert _clean_meeting_name("   \n\n") == ""
    # Punctuation-only collapses to empty
    assert _clean_meeting_name("---") == ""


def test_clean_meeting_name_takes_first_line():
    assert _clean_meeting_name("Payments Sync\nExtra junk\nMore") == "Payments Sync"


# ---------------------------------------------------------------------------
# _has_ai_provider
# ---------------------------------------------------------------------------

def test_has_ai_provider_anthropic():
    assert _has_ai_provider(AppConfig(anthropic_api_key="sk-x")) is True


def test_has_ai_provider_google():
    assert _has_ai_provider(AppConfig(google_api_key="g-x")) is True


def test_has_ai_provider_local():
    assert _has_ai_provider(AppConfig(preferred_provider="local")) is True


def test_has_ai_provider_none():
    assert _has_ai_provider(AppConfig()) is False


# ---------------------------------------------------------------------------
# _rename_meeting_artifacts
# ---------------------------------------------------------------------------

def _touch(p: Path, body: str = "x") -> None:
    p.write_text(body)


def test_rename_artifacts_renames_full_set(tmp_path):
    base = tmp_path / "2026-05-13_143000_Old_Title.mp3"
    _touch(base)
    _touch(base.with_suffix(".live.txt"))
    _touch(base.with_suffix(".transcript.txt"))
    _touch(base.with_suffix(".summary.txt"))
    _touch(base.with_suffix(".tasks.json"))

    new_mp3 = _rename_meeting_artifacts(base, "Payments API Migration")
    assert new_mp3 is not None
    assert new_mp3.name == "2026-05-13_143000_Payments_API_Migration.mp3"
    for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt", ".tasks.json"):
        assert (tmp_path / f"2026-05-13_143000_Payments_API_Migration{suffix}").exists()
        assert not base.with_suffix(suffix).exists()


def test_rename_artifacts_renames_when_only_mp3_exists(tmp_path):
    base = tmp_path / "2026-05-13_143000.mp3"
    _touch(base)

    new_mp3 = _rename_meeting_artifacts(base, "Standup")
    assert new_mp3 is not None
    assert new_mp3.name == "2026-05-13_143000_Standup.mp3"


def test_rename_artifacts_skips_when_no_timestamp_prefix(tmp_path):
    base = tmp_path / "MyRecording.mp3"
    _touch(base)
    assert _rename_meeting_artifacts(base, "Something") is None
    assert base.exists()


def test_rename_artifacts_skips_when_label_sanitizes_to_empty(tmp_path):
    base = tmp_path / "2026-05-13_143000.mp3"
    _touch(base)
    assert _rename_meeting_artifacts(base, "!!! ???") is None
    assert base.exists()


def test_rename_artifacts_skips_on_collision(tmp_path):
    base = tmp_path / "2026-05-13_143000_Old.mp3"
    _touch(base)
    # Pre-create the destination file
    _touch(tmp_path / "2026-05-13_143000_New.mp3")
    assert _rename_meeting_artifacts(base, "New") is None
    assert base.exists()


def test_rename_artifacts_no_op_when_label_unchanged(tmp_path):
    base = tmp_path / "2026-05-13_143000_Sync.mp3"
    _touch(base)
    assert _rename_meeting_artifacts(base, "Sync") is None
    assert base.exists()


# ---------------------------------------------------------------------------
# _maybe_auto_add_to_kb
# ---------------------------------------------------------------------------

def _make_session_with_config(cfg):
    """Build a MeetingSession bypassing __init__ — only `_config` is needed."""
    from meeting_helper.session import MeetingSession
    session = MeetingSession.__new__(MeetingSession)
    session._config = cfg
    return session


def _isolate_workspace(monkeypatch, tmp_path):
    """Point the workspace config layer at tmp_path so Config() doesn't touch ~/.config."""
    from meeting_helper import config as config_mod
    workspaces = tmp_path / "workspaces"
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", workspaces)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json.legacy")
    monkeypatch.setattr(config_mod, "LEGACY_BACKUP", tmp_path / "config.bak")


def test_auto_add_to_kb_indexes_summary(tmp_path, monkeypatch):
    _isolate_workspace(monkeypatch, tmp_path)
    from meeting_helper.config import Config

    cfg = Config()  # creates default workspace under tmp_path
    cfg.auto_add_to_kb = True
    cfg.save()

    mp3 = tmp_path / "2026-05-13_143000_Standup.mp3"
    mp3.write_bytes(b"x")
    mp3.with_suffix(".summary.txt").write_text("summary body")

    app_cfg = cfg.to_app_config()
    session = _make_session_with_config(app_cfg)
    session._maybe_auto_add_to_kb(mp3)

    assert Config().kb_artifacts == ["2026-05-13_143000_Standup.summary.txt"]


def test_auto_add_to_kb_skips_when_no_summary(tmp_path, monkeypatch):
    _isolate_workspace(monkeypatch, tmp_path)
    from meeting_helper.config import Config

    cfg = Config()
    cfg.auto_add_to_kb = True
    cfg.save()

    mp3 = tmp_path / "2026-05-13_143000_Standup.mp3"
    mp3.write_bytes(b"x")  # no .summary.txt sibling

    session = _make_session_with_config(cfg.to_app_config())
    session._maybe_auto_add_to_kb(mp3)

    assert Config().kb_artifacts == []


def test_auto_add_to_kb_idempotent(tmp_path, monkeypatch):
    _isolate_workspace(monkeypatch, tmp_path)
    from meeting_helper.config import Config

    cfg = Config()
    cfg.auto_add_to_kb = True
    cfg.add_kb("2026-05-13_143000_Standup.summary.txt")

    mp3 = tmp_path / "2026-05-13_143000_Standup.mp3"
    mp3.write_bytes(b"x")
    mp3.with_suffix(".summary.txt").write_text("summary body")

    session = _make_session_with_config(cfg.to_app_config())
    session._maybe_auto_add_to_kb(mp3)

    assert Config().kb_artifacts == ["2026-05-13_143000_Standup.summary.txt"]


# ---------------------------------------------------------------------------
# _run_active_session: single-session guard
# ---------------------------------------------------------------------------


def test_active_session_lock_blocks_concurrent_invocations(monkeypatch, caplog):
    """Two callers racing into _run_active_session must NOT both run the inner
    body, otherwise the system opens two RecordingSession instances on the
    same mic and produces duplicate MP3s (real-world bug: mic auto-detect
    and Start-button click at the same instant).
    """
    import logging
    import threading
    from meeting_helper.session import MeetingSession

    session = MeetingSession.__new__(MeetingSession)
    session._active_session_lock = threading.Lock()
    session._manual_stop = threading.Event()

    calls: list[int] = []
    enter = threading.Event()
    proceed = threading.Event()

    def fake_inner(meeting_info, stop_event=None):
        calls.append(1)
        enter.set()
        # Block here so the second caller arrives while we hold the lock.
        proceed.wait(timeout=2.0)

    session._run_active_session_locked = fake_inner

    info = object()  # _run_active_session doesn't inspect its fields when lock fails
    t1 = threading.Thread(target=session._run_active_session, args=(info,))
    t1.start()
    assert enter.wait(timeout=2.0), "first invocation never entered the locked body"

    with caplog.at_level(logging.WARNING):
        # Second concurrent call must bail out without entering fake_inner.
        # Use a real MeetingInfo-ish object because the bail-out path logs
        # app_name/meeting_name. A bare object() would AttributeError there.
        from types import SimpleNamespace
        ns = SimpleNamespace(app_name="X", meeting_name="Y")
        ret = session._run_active_session(ns)

    assert calls == [1], "second invocation should not run the body"
    assert ret is False, (
        "lock-bail MUST return False so the caller (auto-detect _run loop "
        "or manual _run_manual_session) can skip the post-meeting cleanup "
        "that would otherwise kill the in-flight session via daemon restart"
    )
    assert any(
        "another session already active" in rec.message for rec in caplog.records
    ), "expected warning log for the dropped concurrent invocation"

    proceed.set()
    t1.join(timeout=2.0)


def test_active_session_returns_true_when_body_runs():
    import threading
    from meeting_helper.session import MeetingSession

    session = MeetingSession.__new__(MeetingSession)
    session._active_session_lock = threading.Lock()
    session._manual_stop = threading.Event()
    session._run_active_session_locked = lambda info, stop_event=None: None

    from types import SimpleNamespace
    ret = session._run_active_session(SimpleNamespace(app_name="X", meeting_name="Y"))
    assert ret is True


def test_active_session_lock_released_after_completion():
    """After the first invocation completes, a subsequent (non-concurrent)
    call must be able to run.
    """
    import threading
    from meeting_helper.session import MeetingSession

    session = MeetingSession.__new__(MeetingSession)
    session._active_session_lock = threading.Lock()
    session._manual_stop = threading.Event()

    calls: list[int] = []
    def fake_inner(meeting_info, stop_event=None):
        calls.append(1)

    session._run_active_session_locked = fake_inner

    from types import SimpleNamespace
    info = SimpleNamespace(app_name="X", meeting_name="Y")
    session._run_active_session(info)
    session._run_active_session(info)
    assert calls == [1, 1], "sequential calls should both run"
