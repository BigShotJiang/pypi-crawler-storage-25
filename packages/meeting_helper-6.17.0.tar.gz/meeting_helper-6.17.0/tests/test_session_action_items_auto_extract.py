"""Auto-extract action items hook at meeting end.

Gated on ``Config.action_items_extract_after_meeting``. When on, the
finalize sequence runs the extractor against the same bundle the library
endpoint returns and appends new items to the meeting's sidecar. When off
(default), the extractor is never called.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace

import pytest

from meeting_helper.action_items import models, store
from meeting_helper.session import MeetingSession, _maybe_auto_extract_action_items


def _make_cfg(tmp_path: Path, *, on: bool):
    recordings = tmp_path / "recordings"
    recordings.mkdir(exist_ok=True)
    return SimpleNamespace(
        recordings_dir=str(recordings),
        action_items_extract_after_meeting=on,
    )


async def test_auto_extract_off_by_default(monkeypatch, tmp_path):
    """Default state: extractor must NOT run."""
    cfg = _make_cfg(tmp_path, on=False)
    called: list = []

    async def fake_extract(bundle, *, ai_client):
        called.append(bundle["id"])
        return []

    monkeypatch.setattr(
        "meeting_helper.action_items.extractor.extract", fake_extract
    )
    monkeypatch.setattr(
        "meeting_helper.server.routes._fetch_library_bundle",
        lambda mid, **_kw: {"id": mid, "title": "t"},
    )

    await _maybe_auto_extract_action_items(cfg, "m1")
    assert called == [], "extractor must not run when toggle is off"


async def test_auto_extract_on_runs_extractor_and_appends(monkeypatch, tmp_path):
    """When toggle is on, the extractor runs and the new items are persisted
    to the meeting's sidecar."""
    cfg = _make_cfg(tmp_path, on=True)
    extracted = [models.new_item(title="new", meeting_id="m1", source="auto")]

    async def fake_extract(bundle, *, ai_client):
        return list(extracted)

    monkeypatch.setattr(
        "meeting_helper.action_items.extractor.extract", fake_extract
    )
    monkeypatch.setattr(
        "meeting_helper.server.routes._fetch_library_bundle",
        lambda mid, **_kw: {"id": mid, "title": "t"},
    )

    await _maybe_auto_extract_action_items(cfg, "m1")
    stored = store.load(Path(cfg.recordings_dir), "m1")
    assert [i["title"] for i in stored] == ["new"]


async def test_auto_extract_skips_missing_bundle(monkeypatch, tmp_path):
    """If the library bundle can't be found, the extractor isn't called and
    nothing is written to disk."""
    cfg = _make_cfg(tmp_path, on=True)

    called: list = []

    async def fake_extract(bundle, *, ai_client):
        called.append(bundle["id"])
        return []

    monkeypatch.setattr(
        "meeting_helper.action_items.extractor.extract", fake_extract
    )
    monkeypatch.setattr(
        "meeting_helper.server.routes._fetch_library_bundle",
        lambda mid, **_kw: None,
    )

    await _maybe_auto_extract_action_items(cfg, "missing")
    assert called == []
    assert store.load(Path(cfg.recordings_dir), "missing") == []


async def test_auto_extract_swallows_extractor_errors(monkeypatch, tmp_path):
    """A failing extractor must not raise out of the finalize hook — the
    meeting end should still complete cleanly."""
    cfg = _make_cfg(tmp_path, on=True)

    async def boom(bundle, *, ai_client):
        raise RuntimeError("LLM down")

    monkeypatch.setattr(
        "meeting_helper.action_items.extractor.extract", boom
    )
    monkeypatch.setattr(
        "meeting_helper.server.routes._fetch_library_bundle",
        lambda mid, **_kw: {"id": mid, "title": "t"},
    )

    # Must not raise.
    await _maybe_auto_extract_action_items(cfg, "m1")
    assert store.load(Path(cfg.recordings_dir), "m1") == []
