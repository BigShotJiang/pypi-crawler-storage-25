# tests/test_tracker_profile_contract.py
"""Contract suite: every shipped profile passes these checks.

When a new vendor profile is added to ALL_PROFILES it automatically
gets tested here — no per-vendor test boilerplate.
"""
import pytest
from meeting_helper.trackers.profile import (
    ALL_CAPABILITIES, AuthField, TransportTemplate, VendorProfile,
)
from meeting_helper.trackers.vendors import ALL_PROFILES


@pytest.mark.parametrize("ProfileCls", ALL_PROFILES, ids=[p.id for p in ALL_PROFILES])
class TestProfileContract:
    def test_implements_protocol(self, ProfileCls):
        assert isinstance(ProfileCls(), VendorProfile)

    def test_id_is_snake_case_nonempty(self, ProfileCls):
        assert ProfileCls.id
        assert ProfileCls.id.replace("_", "").isalnum()
        assert ProfileCls.id.islower() or "_" in ProfileCls.id

    def test_label_nonempty(self, ProfileCls):
        assert ProfileCls.label.strip()

    def test_auth_form_keys_unique(self, ProfileCls):
        keys = [f.key for f in ProfileCls.auth_form]
        assert len(keys) == len(set(keys)), f"duplicate auth_form keys: {keys}"

    def test_auth_form_fields_typed(self, ProfileCls):
        for f in ProfileCls.auth_form:
            assert isinstance(f, AuthField)
            assert f.kind in ("text", "password", "url", "textarea", "headers", "env")

    def test_transport_template_well_formed(self, ProfileCls):
        t = ProfileCls.transport
        assert isinstance(t, TransportTemplate)
        # Vendors with auth_mode="none" have no real transport — the
        # registry builds an in-process tracker for them.
        if ProfileCls.auth_mode == "none":
            return
        if t.type == "stdio":
            assert t.command  # must declare a default command (may be a template)
        else:
            assert t.url_template

    def test_supports_is_subset_of_known_capabilities(self, ProfileCls):
        assert ProfileCls.supports <= ALL_CAPABILITIES

    def test_auth_mode_is_valid(self, ProfileCls):
        assert ProfileCls.auth_mode in ("manual", "mcp_oauth", "none")

    def test_default_url_is_string(self, ProfileCls):
        assert isinstance(ProfileCls.default_url, str)

    def test_agent_strings_nonempty(self, ProfileCls):
        assert ProfileCls.agent_terminology.strip()
        assert ProfileCls.agent_hints.strip()

    def test_template_placeholders_resolve_to_auth_fields(self, ProfileCls):
        import re
        field_keys = {f.key for f in ProfileCls.auth_form}
        placeholders: set[str] = set()
        for s in [
            ProfileCls.transport.command,
            ProfileCls.transport.url_template,
            *ProfileCls.transport.args,
            *ProfileCls.transport.env_template.values(),
            *ProfileCls.transport.headers_template.values(),
        ]:
            placeholders.update(re.findall(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}", s))
        unknown = placeholders - field_keys
        assert not unknown, f"template placeholders not in auth_form: {unknown}"
