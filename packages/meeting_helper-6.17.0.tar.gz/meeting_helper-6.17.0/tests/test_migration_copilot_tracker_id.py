"""Migration: active_tracker_id → copilot_tracker_id (with alias) and
chat_enabled = true on every existing tracker entry.

Both are one-shot and idempotent. Workspaces written by an old daemon must
load cleanly into a new daemon; workspaces written by a new daemon must
still degrade gracefully when read by an old daemon (alias preserved).
"""

import json
from pathlib import Path
import pytest

from meeting_helper.config import Config


def _write_workspace(tmp_path: Path, payload: dict) -> Config:
    f = tmp_path / "ws.json"
    f.write_text(json.dumps(payload))
    return Config(f)


def test_active_tracker_id_promoted_to_copilot_tracker_id(tmp_path):
    cfg = _write_workspace(tmp_path, {
        "trackers": [{"id": "loc-1", "vendor": "local_todo", "label": "L",
                       "transport": {"type": "http", "url": "x"},
                       "auth_values": {}, "secret_keys": []}],
        "active_tracker_id": "loc-1",
    })
    assert cfg.copilot_tracker_id == "loc-1"
    # Alias preserved for back-compat with an older daemon reading the file.
    assert cfg._data.get("active_tracker_id") == "loc-1"


def test_chat_enabled_defaults_true_on_every_existing_entry(tmp_path):
    cfg = _write_workspace(tmp_path, {
        "trackers": [
            {"id": "a", "vendor": "local_todo", "label": "L",
             "transport": {"type": "http", "url": "x"},
             "auth_values": {}, "secret_keys": []},
            {"id": "b", "vendor": "jira", "label": "J",
             "transport": {"type": "http", "url": "y"},
             "auth_values": {}, "secret_keys": []},
        ],
        "active_tracker_id": "a",
    })
    assert all(t.get("chat_enabled") is True for t in cfg.trackers)


def test_migration_is_idempotent(tmp_path):
    cfg = _write_workspace(tmp_path, {
        "trackers": [{"id": "loc-1", "vendor": "local_todo", "label": "L",
                       "transport": {"type": "http", "url": "x"},
                       "auth_values": {}, "secret_keys": [],
                       "chat_enabled": True}],
        "copilot_tracker_id": "loc-1",
        "active_tracker_id": "loc-1",
    })
    # Running the migration twice doesn't toggle or duplicate anything.
    _ = cfg.trackers
    _ = cfg.copilot_tracker_id
    assert cfg._data["trackers"][0]["chat_enabled"] is True
    assert cfg._data["copilot_tracker_id"] == "loc-1"


def test_setter_writes_copilot_tracker_id_and_alias(tmp_path):
    cfg = _write_workspace(tmp_path, {
        "trackers": [{"id": "x", "vendor": "local_todo", "label": "X",
                       "transport": {}, "auth_values": {}, "secret_keys": []}],
    })
    cfg.copilot_tracker_id = "x"
    assert cfg._data["copilot_tracker_id"] == "x"
    assert cfg._data["active_tracker_id"] == "x"  # alias preserved


def test_user_disabling_chat_persists(tmp_path):
    """Once migrated, the user can flip chat_enabled off on an entry and the
    next load preserves their choice (migration must NOT overwrite an
    explicitly-set False)."""
    cfg = _write_workspace(tmp_path, {
        "trackers": [{"id": "x", "vendor": "local_todo", "label": "X",
                       "transport": {}, "auth_values": {}, "secret_keys": [],
                       "chat_enabled": False}],
        "copilot_tracker_id": None,
        "active_tracker_id": None,
    })
    assert cfg.trackers[0]["chat_enabled"] is False


def test_config_exposes_workspace_name_property(tmp_path):
    """`Config.workspace_name` must return the on-disk filename stem so the
    chat passthrough can pass it as `oauth_workspace` when lazy-building
    Tracker sessions. Previously only AppConfig (the dataclass snapshot)
    had this — chat handlers using the file-backed Config got `""`, which
    caused `Tracker(...)` to ValueError on first MCP call for any OAuth
    vendor."""
    ws_file = tmp_path / "Personal.json"
    ws_file.write_text("{}")
    cfg = Config(ws_file)
    assert cfg.workspace_name == "Personal"
