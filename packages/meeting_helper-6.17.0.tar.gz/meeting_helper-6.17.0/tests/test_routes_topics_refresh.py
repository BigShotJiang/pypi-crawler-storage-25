"""Tests for POST /topics/refresh endpoint."""
from __future__ import annotations

import pytest


def _make_app():
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes

    app = web.Application()
    app["config"] = _FakeConfig()
    setup_routes(app)
    return app


class _FakeConfig:
    anthropic_api_key = "test-key"
    max_tokens = 800
    local_todo_configured = True
    workspace_name = "test-ws"
    active_tracker_id = None
    trackers = []


@pytest.mark.asyncio
async def test_topics_refresh_calls_force_refresh(aiohttp_client, monkeypatch):
    """POST /topics/refresh invokes refresh_sprint_tickets with force=True
    and returns the count."""
    from meeting_helper.state import state as global_state

    called_with: dict = {}

    async def fake_refresh(state_arg, force=False):
        called_with["force"] = force
        state_arg.sprint_tickets = [{"id": "X", "title": "T"}]

    monkeypatch.setattr(
        "meeting_helper.ai.client.refresh_sprint_tickets", fake_refresh
    )
    # Reset state cache so the test runs from clean slate.
    global_state.sprint_tickets = []

    client = await aiohttp_client(_make_app())
    resp = await client.post("/topics/refresh")
    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body["count"] == 1
    assert called_with["force"] is True

    # Reset
    global_state.sprint_tickets = []


@pytest.mark.asyncio
async def test_topics_refresh_surfaces_errors(aiohttp_client, monkeypatch):
    """POST /topics/refresh returns 500 with the error message when the
    refresh function raises."""

    async def fake_refresh(_state, force=False):
        raise RuntimeError("boom")

    monkeypatch.setattr(
        "meeting_helper.ai.client.refresh_sprint_tickets", fake_refresh
    )

    client = await aiohttp_client(_make_app())
    resp = await client.post("/topics/refresh")
    assert resp.status == 500
    body = await resp.json()
    assert body["ok"] is False
    assert "boom" in body["error"]
