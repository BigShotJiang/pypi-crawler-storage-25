"""Unit tests for TopicWorker buffer merging + Hot Moment gating."""

import time
from unittest.mock import MagicMock

from meeting_helper.buffer import SentenceBuffer
from meeting_helper.state import state
from meeting_helper.topic_worker import TopicWorker


def _fresh_state():
    state.hot_moment_until = 0.0
    state.self_buffer = None
    state.other_buffer = None


def test_collect_window_merges_other_regardless_of_hot_moment():
    """Previously `collect_window` ignored the `other_buffer` whenever Hot
    Moment was off. That silently froze the topic picker in listen-mostly
    meetings (demos, code reviews) where the user goes quiet for >10 min
    and Hot Moment expires — the picker stopped seeing what the OTHER party
    was saying about specific tickets. The fix: always merge both buffers
    when `other_buffer` is provided. Hot Moment still gates engagement-
    related features (transcript focus etc.) but no longer gates picker
    visibility."""
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    state.self_buffer = self_buf
    state.other_buffer = other_buf

    self_buf.append_final("I'm checking ENGT-4147.")
    other_buf.append_final("What about ENGT-4212?")

    # Hot Moment is OFF — but the picker must still see the [other] line.
    assert state.is_hot_moment() is False

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    labeled = worker.collect_window(other_buffer=other_buf, n=10)

    roles = [role for role, _ in labeled]
    assert "other" in roles, "[other] line was dropped despite Hot Moment off"
    texts = [text for _, text in labeled]
    assert "What about ENGT-4212?" in texts


def test_collect_window_hot_moment_on_merges_chronologically():
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    state.self_buffer = self_buf
    state.other_buffer = other_buf

    self_buf.append_final("First me line.")
    time.sleep(0.005)
    other_buf.append_final("First other line.")
    time.sleep(0.005)
    self_buf.append_final("Second me line.")
    time.sleep(0.005)
    other_buf.append_final("Second other line.")

    state.arm_hot_moment(window_sec=60.0)

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    labeled = worker.collect_window(other_buffer=other_buf, n=10)

    assert labeled == [
        ("self", "First me line."),
        ("other", "First other line."),
        ("self", "Second me line."),
        ("other", "Second other line."),
    ]


def test_collect_window_respects_n_cap_after_merge():
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    state.self_buffer = self_buf
    state.other_buffer = other_buf

    for i in range(5):
        self_buf.append_final(f"me {i}")
        time.sleep(0.001)
        other_buf.append_final(f"other {i}")
        time.sleep(0.001)

    state.arm_hot_moment(window_sec=60.0)

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    labeled = worker.collect_window(other_buffer=other_buf, n=4)

    assert len(labeled) == 4
    assert labeled[-1] == ("other", "other 4")
    assert labeled[-2] == ("self", "me 4")


def test_collect_window_keeps_newer_other_line_even_when_hot_moment_off():
    """Regression for the listen-mostly-meeting freeze. When the user goes
    silent long enough for Hot Moment to expire, a newer `[other]` line
    must still appear in the merged window so the picker can re-evaluate
    the topic. Old behavior dropped it — this test pins the new contract."""
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    state.self_buffer = self_buf
    state.other_buffer = other_buf

    self_buf.append_final("Older me line.")
    time.sleep(0.005)
    other_buf.append_final("Newer other line — must NOT be dropped.")

    # Hot Moment is OFF — but the new other line must survive.
    assert state.is_hot_moment() is False

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    labeled = worker.collect_window(other_buffer=other_buf, n=10)

    assert labeled[-1] == ("other", "Newer other line — must NOT be dropped.")


def test_short_or_garbage_sentence_does_not_arm_hot_moment():
    """Whisper hallucinations like '....' or one-word fillers should not flip
    engagement from Idle to Active when the user is muted."""
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    state.self_buffer = self_buf

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)

    for noise in [". . . . .", "Okay.", "Yeah", "Hmm hmm", "1 2 3 4 5"]:
        worker._on_sentence(noise)

    assert state.is_hot_moment() is False


def test_substantive_sentence_arms_hot_moment():
    _fresh_state()
    self_buf = SentenceBuffer(role="self")
    state.self_buffer = self_buf

    worker = TopicWorker(config=MagicMock(hot_moment_window_minutes=10), self_buffer=self_buf)
    worker._on_sentence("Yeah I will send the link after the meeting ends.")

    assert state.is_hot_moment() is True
