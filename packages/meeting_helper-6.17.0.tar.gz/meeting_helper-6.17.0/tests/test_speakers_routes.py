"""HTTP handlers for /library/speakers and /library/speakers/suggest."""
import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from meeting_helper.server import routes
from meeting_helper import speakers as _speakers


def test_get_speakers_returns_existing_sidecar(tmp_path):
    mp3 = tmp_path / "2026-05-14_0900_meeting.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text("[00:01] OTHER#0: hello\n")
    _speakers.write_speaker_map(
        _speakers.speakers_path_for(mp3),
        names={"OTHER#0": "Maria"},
        source={"OTHER#0": "manual"},
    )
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    request = MagicMock()
    request.app = {"config": cfg}
    request.query = {"id": mp3.stem}
    resp = asyncio.run(routes.library_speakers_get_handler(request))
    payload = json.loads(resp.body)
    assert payload["names"] == {"OTHER#0": "Maria"}
    assert payload["labels"] == ["OTHER#0"]


def test_post_speakers_persists_with_manual_source(tmp_path):
    mp3 = tmp_path / "x.mp3"
    mp3.write_bytes(b"")
    cfg = MagicMock(); cfg.recordings_dir = tmp_path

    request = MagicMock()
    request.app = {"config": cfg}
    request.json = AsyncMock(return_value={
        "id": mp3.stem,
        "names": {"OTHER#0": "Maria", "OTHER#1": "Alex"},
    })
    resp = asyncio.run(routes.library_speakers_post_handler(request))
    assert resp.status == 200
    on_disk = _speakers.read_speaker_map(_speakers.speakers_path_for(mp3))
    assert on_disk.names == {"OTHER#0": "Maria", "OTHER#1": "Alex"}
    assert on_disk.source == {"OTHER#0": "manual", "OTHER#1": "manual"}


def test_post_speakers_empty_name_stored_as_none(tmp_path):
    mp3 = tmp_path / "p.mp3"
    mp3.write_bytes(b"")
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    request = MagicMock()
    request.app = {"config": cfg}
    request.json = AsyncMock(return_value={
        "id": mp3.stem,
        "names": {"OTHER#0": "", "OTHER#1": None, "OTHER#2": "  "},
    })
    resp = asyncio.run(routes.library_speakers_post_handler(request))
    assert resp.status == 200
    on_disk = _speakers.read_speaker_map(_speakers.speakers_path_for(mp3))
    assert on_disk.names == {"OTHER#0": None, "OTHER#1": None, "OTHER#2": None}


def test_suggest_calls_ai_and_merges_without_overwriting_manual(tmp_path):
    mp3 = tmp_path / "y.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text("[00:01] OTHER#0: hey\n[00:02] OTHER#1: yo\n")
    # Pre-existing manual entry must survive AI suggestion.
    _speakers.write_speaker_map(
        _speakers.speakers_path_for(mp3),
        names={"OTHER#0": "Maria"},
        source={"OTHER#0": "manual"},
    )
    cfg = MagicMock(); cfg.recordings_dir = tmp_path; cfg.user_display_name = ""
    request = MagicMock()
    request.app = {"config": cfg}
    request.json = AsyncMock(return_value={"id": mp3.stem})

    fake_map = _speakers.SpeakerMap(
        names={"OTHER#0": "WrongAI", "OTHER#1": "Alex"},
        evidence={"OTHER#0": "x", "OTHER#1": "y"},
        source={"OTHER#0": "ai", "OTHER#1": "ai"},
    )
    with patch(
        "meeting_helper.ai.client.name_speakers_from_transcript",
        new=AsyncMock(return_value=fake_map),
    ):
        resp = asyncio.run(routes.library_speakers_suggest_handler(request))
    assert resp.status == 200
    on_disk = _speakers.read_speaker_map(_speakers.speakers_path_for(mp3))
    # Manual OTHER#0 preserved, OTHER#1 filled by AI.
    assert on_disk.names["OTHER#0"] == "Maria"
    assert on_disk.names["OTHER#1"] == "Alex"
    assert on_disk.source["OTHER#0"] == "manual"


def test_suggest_user_display_name_overrides_self(tmp_path):
    mp3 = tmp_path / "u.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text("[00:01] SELF: hi\n")
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    cfg.user_display_name = "Victor"
    request = MagicMock()
    request.app = {"config": cfg}
    request.json = AsyncMock(return_value={"id": mp3.stem})
    fake = _speakers.SpeakerMap(
        names={"SELF": "WrongAIGuess"}, source={"SELF": "ai"},
    )
    with patch(
        "meeting_helper.ai.client.name_speakers_from_transcript",
        new=AsyncMock(return_value=fake),
    ):
        resp = asyncio.run(routes.library_speakers_suggest_handler(request))
    assert resp.status == 200
    on_disk = _speakers.read_speaker_map(_speakers.speakers_path_for(mp3))
    assert on_disk.names["SELF"] == "Victor"
    assert on_disk.source["SELF"] == "manual"


def test_library_item_substitutes_speaker_labels(tmp_path):
    mp3 = tmp_path / "z.mp3"
    mp3.write_bytes(b"")
    live = mp3.with_suffix(".live.txt")
    live.write_text("[00:01] OTHER#0: hello\n[00:02] OTHER#1: hi\n")
    _speakers.write_speaker_map(
        _speakers.speakers_path_for(mp3),
        names={"OTHER#0": "Maria", "OTHER#1": None},
        source={"OTHER#0": "manual", "OTHER#1": "ai"},
    )
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    bundle = routes._fetch_library_bundle(mp3.stem, kind="meeting", cfg=cfg)
    assert bundle is not None
    assert "Maria: hello" in bundle["live_text"]
    assert "OTHER#1: hi" in bundle["live_text"]
    assert bundle["speaker_map"]["names"]["OTHER#0"] == "Maria"
    assert bundle["speaker_labels"] == ["OTHER#0", "OTHER#1"]


def test_get_speakers_missing_id_returns_400(tmp_path):
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    request = MagicMock()
    request.app = {"config": cfg}
    request.query = {}
    resp = asyncio.run(routes.library_speakers_get_handler(request))
    assert resp.status == 400


def test_suggest_missing_live_transcript_returns_404(tmp_path):
    mp3 = tmp_path / "q.mp3"
    mp3.write_bytes(b"")
    cfg = MagicMock(); cfg.recordings_dir = tmp_path; cfg.user_display_name = ""
    request = MagicMock()
    request.app = {"config": cfg}
    request.json = AsyncMock(return_value={"id": mp3.stem})
    resp = asyncio.run(routes.library_speakers_suggest_handler(request))
    assert resp.status == 404


def test_get_speakers_rejects_path_traversal(tmp_path):
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    request = MagicMock()
    request.app = {"config": cfg}
    request.query = {"id": "../../etc/passwd"}
    resp = asyncio.run(routes.library_speakers_get_handler(request))
    assert resp.status == 400


def test_post_speakers_rejects_path_traversal(tmp_path):
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    request = MagicMock()
    request.app = {"config": cfg}
    request.json = AsyncMock(return_value={
        "id": "../../tmp/evil",
        "names": {"OTHER#0": "Maria"},
    })
    resp = asyncio.run(routes.library_speakers_post_handler(request))
    assert resp.status == 400


def test_suggest_rejects_path_traversal(tmp_path):
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    request = MagicMock()
    request.app = {"config": cfg}
    request.json = AsyncMock(return_value={"id": "../../tmp/foo"})
    resp = asyncio.run(routes.library_speakers_suggest_handler(request))
    assert resp.status == 400


def test_post_speakers_returns_404_when_mp3_missing(tmp_path):
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    request = MagicMock()
    request.app = {"config": cfg}
    request.json = AsyncMock(return_value={
        "id": "ghost-meeting",
        "names": {"OTHER#0": "Maria"},
    })
    resp = asyncio.run(routes.library_speakers_post_handler(request))
    assert resp.status == 404


def test_post_speakers_malformed_json_returns_400(tmp_path):
    cfg = MagicMock(); cfg.recordings_dir = tmp_path
    request = MagicMock()
    request.app = {"config": cfg}
    # Simulate aiohttp's .json() raising on malformed body.
    request.json = AsyncMock(side_effect=Exception("invalid"))
    resp = asyncio.run(routes.library_speakers_post_handler(request))
    assert resp.status == 400
