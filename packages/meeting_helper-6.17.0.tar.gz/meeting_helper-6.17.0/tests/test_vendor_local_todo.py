import pytest
from tests.helpers.fake_mcp import FakeMCPSession
from meeting_helper.trackers.profile import Workspace
from meeting_helper.trackers.vendors.local_todo import LocalTodoProfile


@pytest.fixture
def session():
    return FakeMCPSession()


@pytest.mark.asyncio
async def test_list_workspaces_returns_readable_boards(session):
    session.set_response("list_boards", {}, [
        {"board_id": 10, "name": "Demo", "effective_permission": "write"},
        {"board_id": 11, "name": "ReadOnly", "effective_permission": "read"},
        {"board_id": 12, "name": "None", "effective_permission": "none"},
    ])
    profile = LocalTodoProfile()
    workspaces = await profile.list_workspaces(session)
    assert workspaces == [
        Workspace(id="10", name="Demo", permission="write"),
        Workspace(id="11", name="ReadOnly", permission="read"),
    ]


def test_profile_class_attributes():
    p = LocalTodoProfile
    assert p.id == "local_todo"
    assert p.label == "Local Todo"
    assert p.transport.type == "http"
    assert p.auth_mode == "mcp_oauth"
    assert "list_workspaces" in p.supports
    assert p.agent_terminology
    assert p.agent_hints
