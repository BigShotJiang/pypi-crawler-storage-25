import pytest

from meeting_helper.chat.tools.meeting_live import build_meeting_live_tool


@pytest.mark.asyncio
async def test_returns_no_meeting_when_idle():
    ctx = {"app_state": type("S", (), {"session_active": False})()}
    tool = build_meeting_live_tool()
    out = await tool.run({}, ctx)
    assert out == {"status": "no_meeting_active"}


@pytest.mark.asyncio
async def test_returns_transcript_window_and_topic():
    class StubBuf:
        def all_sentences(self):
            return [
                {"text": "Hello", "ts": 100.0},
                {"text": "world", "ts": 101.0},
            ]

    app_state = type(
        "S",
        (),
        {
            "session_active": True,
            "self_buffer": StubBuf(),
            "other_buffer": StubBuf(),
            "current_topic": {"topic": "T", "ticket_ids": ["T-1"]},
            "current_topic_cards": [{"id": "T-1", "title": "Ticket 1"}],
        },
    )()
    tool = build_meeting_live_tool()
    out = await tool.run({}, {"app_state": app_state})
    assert out["status"] == "ok"
    assert out["result"]["current_topic"]["topic"] == "T"
    # Recent transcript flat-merged from both buffers
    assert any("Hello" in t["text"] for t in out["result"]["recent_transcript"])


@pytest.mark.asyncio
async def test_full_transcript_returns_all_sentences():
    from meeting_helper.chat.tools.meeting_live import build_meeting_full_transcript_tool
    class StubBuf:
        def all_sentences(self): return [
            {"text": "Hello", "ts": 100.0},
            {"text": "world", "ts": 200.0},
            {"text": "third", "ts": 300.0},
        ]
    app_state = type("S", (), {
        "session_active": True,
        "self_buffer": StubBuf(),
        "other_buffer": StubBuf(),
        "current_topic": None,
        "current_topic_cards": [],
        "started_at": 50.0,
        "meeting_info": None,
    })()
    out = await build_meeting_full_transcript_tool().run({}, {"app_state": app_state})
    assert out["status"] == "ok"
    # Not capped — all 6 sentences (3 from self, 3 from other) present.
    assert len(out["result"]["full_transcript"]) == 6


@pytest.mark.asyncio
async def test_full_transcript_no_meeting_active():
    from meeting_helper.chat.tools.meeting_live import build_meeting_full_transcript_tool
    app_state = type("S", (), {"session_active": False})()
    out = await build_meeting_full_transcript_tool().run({}, {"app_state": app_state})
    assert out["status"] == "no_meeting_active"
