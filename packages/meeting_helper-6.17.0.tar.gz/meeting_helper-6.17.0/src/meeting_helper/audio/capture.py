"""Audio capture: microphone + system audio via ScreenCaptureKit.

CRITICAL: This module must NOT be imported before daemonize().
CoreAudio crashes if Python forks after loading audio libraries.
Import inside _run_active_session() or after the daemon fork.
"""

from __future__ import annotations

import ctypes
import logging
import sys

import numpy as np
import sounddevice as sd
from collections import deque
from queue import Queue, Empty, Full
from threading import Event, Thread
from typing import Optional, Union

logger = logging.getLogger(__name__)


SAMPLE_RATE = 16000  # 16kHz for Deepgram/Whisper (not 48kHz)
CHANNELS = 1  # Mono for transcription
BLOCK_SIZE = 1024

# Per-role transcribe queue cap. Chunks are 20ms each → 50/sec.
#
# Sized to keep transcripts close to real-time: 1500 chunks ≈ 30s means a
# sustained drain stall (slow proxy buffering the Deepgram WS, paused
# transcriber, slow remote Whisper) can only accumulate up to ~30s of lag
# before drop-oldest kicks in. Beyond that we drop the OLDEST chunks (per
# `_put_drop_oldest`) — gappy real-time text beats complete-but-30s-late
# text in a meeting context.
#
# Previously 12000 ≈ 240s, sized to span a Deepgram reconnect storm
# (`min(2**n, 30)s × 10 attempts ≈ 210s`) so every byte survived the outage.
# Trade-off reversed 2026-05-13 after a corporate-laptop incident: the
# Deepgram WS drain ran slightly slower than capture (TLS-inspecting
# corporate proxy buffering frames), the queue silently accumulated minutes
# of lag — well under the 240s cap, so no drop log ever fired — and the
# user read transcripts 30+s behind live audio. Lag-bounded > completeness.
TRANSCRIBE_QUEUE_MAX = 1500
# Log every Nth dropped chunk so we don't flood under sustained overflow.
TRANSCRIBE_DROP_LOG_EVERY = 50
# Early-warning threshold. When a per-role queue passes this depth (~15s
# of accumulated audio), the drain is falling behind and the user will
# feel lag growing. Logged once per stall episode (hysteresis on the
# RESET level — must drop below it before we'll warn again) so the signal
# appears in diag bundles *before* any chunks actually drop.
TRANSCRIBE_QUEUE_HIGH_WATER = TRANSCRIBE_QUEUE_MAX // 2
TRANSCRIBE_QUEUE_HIGH_WATER_RESET = TRANSCRIBE_QUEUE_MAX // 4
# Stall-recovery trim. When the queue ever passes this depth (transcriber
# falling behind real-time), we proactively drop oldest chunks down to a
# small live tail. Adopted from ai-interview-assistant which never sustains
# a phase offset because this trim fires the moment the queue grows past
# the threshold. Without it our `_put_drop_oldest` only fires at the hard
# cap — so any backlog *under* the cap (the 3-6 s offset installed by the
# meeting-start refresh_sprint_tickets agent_loop) persists indefinitely
# (producer rate = consumer rate ⇒ phase offset is locked).
#
# Threshold is tight on purpose: 100 chunks ≈ 2 s. Live testing showed
# equilibrium offsets settling at 3-5 s — anything looser than this leaves
# them undetected. The trade-off is that bursty producers (rare) may lose
# a chunk or two during a momentary spike; that's an acceptable cost for
# keeping transcripts in real-time phase.
TRANSCRIBE_QUEUE_STALL_TRIM = 100  # ~2 s of accumulated audio
TRANSCRIBE_QUEUE_STALL_TAIL = 25   # ~0.5 s of live tail after trim


def find_capture_device() -> tuple[Optional[int], bool]:
    """Find the default microphone for capture."""
    try:
        default_input = sd.default.device[0]
        if default_input is not None and default_input >= 0:
            device_info = sd.query_devices(default_input)
            if device_info["max_input_channels"] > 0:
                return default_input, False
    except Exception as exc:
        logger.warning(
            "find_capture_device: default-device probe failed, falling back to enumeration: %s",
            exc,
        )

    devices = sd.query_devices()
    for i, device in enumerate(devices):
        if device["max_input_channels"] > 0:
            name = device["name"].lower()
            if "blackhole" in name or "virtual" in name or "aggregate" in name:
                continue
            return i, False

    for i, device in enumerate(devices):
        if device["max_input_channels"] > 0:
            return i, False

    return None, False


class AudioCapture:
    """Captures audio from default microphone."""

    def __init__(
        self,
        device: Union[int, str, None] = None,
        sample_rate: int = SAMPLE_RATE,
        channels: Optional[int] = None,
        block_size: int = BLOCK_SIZE,
    ):
        self.sample_rate = sample_rate
        self.block_size = block_size
        self.audio_queue: Queue[np.ndarray] = Queue()
        self.stop_event = Event()
        self.stream: Optional[sd.InputStream] = None

        self.has_system_audio = False
        if device is None:
            self.device_index, _ = find_capture_device()
            if self.device_index is None:
                raise RuntimeError("No audio input device found.")
        elif isinstance(device, str):
            devices = sd.query_devices()
            self.device_index = None
            for i, d in enumerate(devices):
                if device.lower() in d["name"].lower():
                    self.device_index = i
                    break
            if self.device_index is None:
                raise RuntimeError(f"Device '{device}' not found.")
        else:
            self.device_index = device

        device_info = sd.query_devices(self.device_index)
        max_channels = device_info["max_input_channels"]
        self.channels = channels if channels is not None else min(max_channels, CHANNELS)

    def _audio_callback(self, indata, frames, time_info, status):
        # PortAudio status flags (input overflow, underflow, priming) are the
        # canonical "samples are being dropped at the OS level" signal.
        # Silencing them used to hide every "audio cuts every N seconds"
        # report. Rate-limit to avoid log floods under sustained pressure.
        if status:
            self._status_warn_count = getattr(self, "_status_warn_count", 0) + 1
            if self._status_warn_count == 1 or self._status_warn_count % 50 == 0:
                logger.warning(
                    "PortAudio status flags (count=%d): %s",
                    self._status_warn_count, status,
                )
        self.audio_queue.put(indata.copy())

    def start(self):
        self.stop_event.clear()
        self.stream = sd.InputStream(
            device=self.device_index,
            channels=self.channels,
            samplerate=self.sample_rate,
            blocksize=self.block_size,
            dtype=np.float32,
            callback=self._audio_callback,
        )
        self.stream.start()

    def pause(self):
        """Pause: fully release mic so CoreAudio reports device as free."""
        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None

    def resume(self) -> bool:
        """Resume after pause by recreating the stream.

        Returns True if the new stream is up; False on failure (callers
        should treat this as a degraded session and stop probing rather
        than letting the exception propagate up to the session loop's
        bare except, which used to kill the entire session.
        """
        if self.stream is not None:
            return True
        try:
            self.stream = sd.InputStream(
                device=self.device_index,
                channels=self.channels,
                samplerate=self.sample_rate,
                blocksize=self.block_size,
                dtype=np.float32,
                callback=self._audio_callback,
            )
            self.stream.start()
            return True
        except Exception as exc:
            # InputStream init can fail if the default device changes
            # mid-meeting (USB mic unplugged, headphones mode swap).
            logger.warning(
                "AudioCapture.resume failed to re-init InputStream "
                "(device=%s): %s — mic capture will be paused until next "
                "session restart",
                self.device_index, exc,
            )
            self.stream = None
            return False

    def stop(self):
        self.stop_event.set()
        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None

    def get_audio(self, timeout: float = 1.0) -> Optional[np.ndarray]:
        try:
            return self.audio_queue.get(timeout=timeout)
        except Empty:
            return None


class SilenceDetector:
    """Detects extended silence in audio stream."""

    def __init__(
        self,
        threshold: float = 0.01,
        silence_duration: float = 60.0,
        sample_rate: int = SAMPLE_RATE,
    ):
        self.threshold = threshold
        self.silence_samples = int(silence_duration * sample_rate)
        self.current_silence = 0
        self.sample_rate = sample_rate

    def update(self, audio: np.ndarray) -> bool:
        """Returns True if extended silence detected (meeting likely ended)."""
        rms = np.sqrt(np.mean(audio ** 2))
        if rms < self.threshold:
            self.current_silence += len(audio)
        else:
            self.current_silence = 0
        return self.current_silence >= self.silence_samples

    def reset(self):
        self.current_silence = 0

    def is_audio_present(self, audio: np.ndarray) -> bool:
        rms = np.sqrt(np.mean(audio ** 2))
        return rms >= self.threshold


class ScreenCaptureAudio:
    """Captures system audio using ScreenCaptureKit (macOS 12.3+)."""

    def __init__(self, sample_rate: int = SAMPLE_RATE, channels: int = CHANNELS):
        self.sample_rate = sample_rate
        self.channels = channels
        self.audio_queue: Queue[np.ndarray] = Queue()
        self._is_running = False
        self._stream = None
        self._delegate = None
        self._dispatch_queue = None
        # Rate-limited counter for SCK sample-buffer extraction failures.
        self._sck_frame_errors = 0

    def _check_availability(self) -> bool:
        if sys.platform != "darwin":
            logger.warning("SCK unavailable: not macOS (%s)", sys.platform)
            return False
        try:
            import ScreenCaptureKit
            return True
        except ImportError as exc:
            logger.warning("SCK unavailable: ScreenCaptureKit import failed: %s", exc)
            return False

    def start(self) -> bool:
        if not self._check_availability():
            logger.warning("ScreenCaptureAudio.start: SCK availability check failed")
            return False

        try:
            import ScreenCaptureKit as SCK
            import CoreMedia as CM
            from Foundation import NSObject
            import objc
            import threading

            dispatch_queue_create = None
            DISPATCH_QUEUE_SERIAL = None
            try:
                from libdispatch import dispatch_queue_create, DISPATCH_QUEUE_SERIAL
            except ImportError:
                try:
                    from dispatch import dispatch_queue_create, DISPATCH_QUEUE_SERIAL
                except ImportError:
                    pass

            audio_queue = self.audio_queue
            parent = self

            # PyObjC + SCStreamOutput crash workaround (round 2):
            #
            # Round 1 swapped CMSampleBufferRef from ``^{opaqueCMSampleBuffer=}``
            # to ``@`` to dodge PyObjC's (buffer, length) heuristic that was
            # routing through PyObjC_CArrayToPython2. That fixed one crash class
            # but a second one persisted: ``EXC_BAD_ACCESS`` in
            # ``pythonify_c_value → obj_get_instanceMethods_doc`` on the
            # com.meetinghelper.screencapture queue. The signature in the dump
            # implicates the *first* ``@`` arg — the ``stream`` parameter —
            # which PyObjC is trying to wrap as a Python ObjC proxy on every
            # callback. Under the heavy delivery rate SCK runs (~50 Hz mono
            # 16k) the proxy creation eventually reads a freed pointer.
            #
            # We don't actually use ``stream`` in the callback body. Mark it
            # opaque (``^v`` = void pointer) so PyObjC stops bridging it and
            # just hands us the raw address. Keep ``sampleBuffer`` as ``@``
            # because we DO need the toll-free bridge for the CM* calls below.
            # End result: ``v@:^v@q`` instead of ``v@:@@q``.
            SCStreamDelegateProto = objc.protocolNamed("SCStreamDelegate")

            class StreamOutput(NSObject, protocols=[SCStreamDelegateProto]):
                @objc.typedSelector(b"v@:^v@q")
                def stream_didOutputSampleBuffer_ofType_(self, stream, sampleBuffer, outputType):
                    # `stream` is now an integer (raw void pointer address) —
                    # we never call into it, so this is a no-op argumentation.
                    if outputType != 1:
                        return
                    try:
                        blockBuffer = CM.CMSampleBufferGetDataBuffer(sampleBuffer)
                        if blockBuffer is None:
                            return
                        length = CM.CMBlockBufferGetDataLength(blockBuffer)
                        if length == 0:
                            return

                        # Round-3 PyObjC + SCK crash fix:
                        #
                        # Earlier rounds (round-1 typedSelector v@:@@q,
                        # round-2 v@:^v@q for stream) addressed
                        # `pythonify_c_value` crashes during arg bridging.
                        # A new SIGSEGV class then surfaced at line 305
                        # (`CMBlockBufferGetDataPointer`) — load-induced:
                        # under heavy concurrent work (e.g. /brief Claude
                        # streaming + MCP fan-out + active speech), ARC
                        # reaps the `contigBuffer` returned by
                        # `CMBlockBufferCreateContiguous` between the
                        # create call and the subsequent GetDataPointer
                        # call. The contigBuffer ends up dangling.
                        #
                        # Fix: skip the create-contiguous step entirely.
                        # SCK audio sample buffers are already contiguous
                        # in practice. The ORIGINAL blockBuffer is held
                        # by the CMSampleBufferRef for the callback's
                        # lifetime — no release race possible while we're
                        # inside this function. Read directly from it.
                        # Fall back to the create-contiguous path only if
                        # the direct read returns short data (defensive;
                        # never observed in production for SCK audio).
                        dataResult = CM.CMBlockBufferGetDataPointer(
                            blockBuffer, 0, None, None, None
                        )
                        if dataResult[0] != 0:
                            # Direct read failed — try the contiguous-copy
                            # fallback. Same dangling-pointer risk applies,
                            # but losing one frame to a fallback failure is
                            # still better than a SIGSEGV taking the daemon.
                            result = CM.CMBlockBufferCreateContiguous(
                                None, blockBuffer, None, None, 0, length, 0, None
                            )
                            if result[0] != 0:
                                return
                            contigBuffer = result[1]
                            dataResult = CM.CMBlockBufferGetDataPointer(
                                contigBuffer, 0, None, None, None
                            )
                            if dataResult[0] != 0:
                                return

                        dataPtr = dataResult[3]
                        if isinstance(dataPtr, tuple) and len(dataPtr) > 0:
                            ptr_addr = dataPtr[0]
                            num_floats = length // 4
                            float_ptr = ctypes.cast(
                                ptr_addr, ctypes.POINTER(ctypes.c_float)
                            )
                            audio = np.ctypeslib.as_array(
                                float_ptr, shape=(num_floats,)
                            ).copy()
                            if len(audio) > 0:
                                audio_queue.put(audio)
                    except Exception as exc:
                        # Rate-limited — every dropped frame is system audio loss.
                        # Without this log the symptom is "system audio went away"
                        # with no diagnostic at all.
                        parent._sck_frame_errors += 1
                        if parent._sck_frame_errors == 1 or parent._sck_frame_errors % 100 == 0:
                            logger.warning(
                                "SCK sample-buffer extraction failed (count=%d): %s",
                                parent._sck_frame_errors, exc,
                            )

                def stream_didStopWithError_(self, stream, error):
                    parent._is_running = False
                    if error is not None:
                        logger.warning("SCK stream stopped with error: %s", error)

            self._delegate = StreamOutput.alloc().init()

            if dispatch_queue_create is not None:
                self._dispatch_queue = dispatch_queue_create(
                    b"com.meetinghelper.screencapture",
                    DISPATCH_QUEUE_SERIAL,
                )
            else:
                self._dispatch_queue = None

            content_ready = threading.Event()
            content_result = [None, None]

            def on_content(content, error):
                content_result[0] = content
                content_result[1] = error
                content_ready.set()

            SCK.SCShareableContent.getShareableContentWithCompletionHandler_(on_content)
            if not content_ready.wait(timeout=5.0):
                logger.warning(
                    "SCK.start: getShareableContent timed out after 5s — "
                    "Screen Recording permission likely revoked or daemon stuck. "
                    "Try `meeting-helper fix-recording`."
                )
                return False

            content, error = content_result
            if error:
                logger.warning(
                    "SCK.start: getShareableContent error: %s — "
                    "permission denied or SCK service unavailable.",
                    error,
                )
                return False
            if not content:
                logger.warning("SCK.start: getShareableContent returned no content")
                return False

            if not content.displays() or len(content.displays()) == 0:
                logger.warning("SCK.start: no displays available from SCShareableContent")
                return False

            display = content.displays()[0]
            contentFilter = SCK.SCContentFilter.alloc().initWithDisplay_excludingWindows_(
                display, []
            )

            config = SCK.SCStreamConfiguration.alloc().init()
            config.setCapturesAudio_(True)
            config.setExcludesCurrentProcessAudio_(False)
            config.setSampleRate_(self.sample_rate)
            config.setChannelCount_(self.channels)
            config.setWidth_(100)
            config.setHeight_(100)
            config.setMinimumFrameInterval_(CM.CMTimeMake(1, 2))

            self._stream = SCK.SCStream.alloc().initWithFilter_configuration_delegate_(
                contentFilter, config, self._delegate
            )
            if self._stream is None:
                logger.warning("SCK.start: SCStream init returned None")
                return False

            self._stream.addStreamOutput_type_sampleHandlerQueue_error_(
                self._delegate, 0, self._dispatch_queue, None
            )
            self._stream.addStreamOutput_type_sampleHandlerQueue_error_(
                self._delegate, 1, self._dispatch_queue, None
            )

            start_ready = threading.Event()
            start_error = [None]

            def on_start(error):
                start_error[0] = error
                start_ready.set()

            self._stream.startCaptureWithCompletionHandler_(on_start)
            if not start_ready.wait(timeout=5.0):
                logger.warning(
                    "SCK.start: startCapture timed out after 5s — "
                    "replayd may be stuck. Try the sudo step in fix-recording."
                )
                return False

            if start_error[0]:
                logger.warning("SCK.start: startCapture error: %s", start_error[0])
                return False

            logger.info("SCK.start: success — system audio capture running")
            self._is_running = True
            return True

        except Exception as exc:
            logger.warning("SCK.start: unexpected exception: %s", exc, exc_info=True)
            return False

    def stop(self):
        self._is_running = False
        if self._stream:
            try:
                stop_done = Event()
                self._stream.stopCaptureWithCompletionHandler_(lambda e: stop_done.set())
                stop_done.wait(timeout=2.0)
            except Exception as exc:
                logger.warning("SCK stopCapture failed: %s", exc)
            self._stream = None

    def get_audio(self, timeout: float = 1.0) -> Optional[np.ndarray]:
        try:
            return self.audio_queue.get(timeout=timeout)
        except Empty:
            return None

    @property
    def is_running(self) -> bool:
        return self._is_running


class CombinedAudioCapture:
    """Captures both microphone and system audio.

    Uses default microphone for user's voice and ScreenCaptureKit for system audio.
    """

    def __init__(self, sample_rate: int = SAMPLE_RATE):
        self._sample_rate = sample_rate
        self._channels = CHANNELS
        self.audio_queue: Queue[np.ndarray] = Queue()  # for recording/session
        # Per-role queues for the two-stream split (C1).
        # Bounded — see TRANSCRIBE_QUEUE_MAX. Drop-oldest behavior with logging
        # is enforced via _put_drop_oldest below; never call .put directly.
        self._mic_transcribe_q: Queue[np.ndarray] = Queue(maxsize=TRANSCRIBE_QUEUE_MAX)
        self._sys_transcribe_q: Queue[np.ndarray] = Queue(maxsize=TRANSCRIBE_QUEUE_MAX)
        self._mic_drop_count = 0
        self._sys_drop_count = 0
        # High-water "queue is filling, drain is stalling" episode flags.
        # Set when the queue first crosses TRANSCRIBE_QUEUE_HIGH_WATER going
        # up; cleared when it drains below TRANSCRIBE_QUEUE_HIGH_WATER_RESET.
        # Used to log exactly once per stall (not every chunk over the line).
        self._mic_high_water_active = False
        self._sys_high_water_active = False
        self._self_stream: Optional[AudioStream] = None
        self._other_stream: Optional[AudioStream] = None
        self.stop_event = Event()
        self._mic_capture: Optional[AudioCapture] = None
        self._system_capture: Optional[ScreenCaptureAudio] = None
        self._has_system_audio = False
        self._output_thread: Optional[Thread] = None

    def _maybe_warn_high_water(self, q: Queue, role: str) -> None:
        """Emit a one-shot warning when a per-role queue first crosses
        ~half-full going up; clear the flag once it drains back below the
        RESET level (hysteresis — avoids spam when the depth oscillates
        around the threshold). Called from `_put_drop_oldest` so it sees
        every successful enqueue. Depth read is `qsize()`, which is a
        snapshot — exact accuracy isn't needed, this is an indicator."""
        depth = q.qsize()
        attr = "_mic_high_water_active" if role == "mic" else "_sys_high_water_active"
        active = getattr(self, attr)
        if depth >= TRANSCRIBE_QUEUE_HIGH_WATER and not active:
            setattr(self, attr, True)
            secs = depth * 0.02
            logger.warning(
                "%s transcribe queue is %d/%d deep (~%.1fs of audio backed up) — "
                "transcriber drain is falling behind real-time. If this stays "
                "elevated, transcripts will lag by that much; if it grows past "
                "%d, chunks will start dropping.",
                "Mic" if role == "mic" else "System",
                depth, TRANSCRIBE_QUEUE_MAX, secs, TRANSCRIBE_QUEUE_MAX,
            )
        elif depth <= TRANSCRIBE_QUEUE_HIGH_WATER_RESET and active:
            setattr(self, attr, False)
            logger.info(
                "%s transcribe queue drained back to %d (drain has caught up)",
                "Mic" if role == "mic" else "System", depth,
            )

    def _put_drop_oldest(
        self,
        q: Queue,
        item: np.ndarray,
        role: str,
    ) -> None:
        """Put with drop-oldest fallback when the queue is full. Sole writer
        path for the per-role transcriber queues — never put directly.

        When a transcriber stalls (Whisper crash, Deepgram WS in reconnect
        backoff, corporate proxy buffering WS frames), this prevents
        unbounded memory growth at the cost of dropping the OLDEST queued
        chunk. We drop oldest because real-time transcription needs fresh
        audio: an old chunk that's been sitting in the queue for 30s is
        useless to the user.

        Also emits a one-shot high-watermark warning when the queue first
        crosses ~half-full (`TRANSCRIBE_QUEUE_HIGH_WATER`), so a stalling
        drain shows up in diag bundles *before* drops start.
        """
        try:
            q.put_nowait(item)
            self._maybe_warn_high_water(q, role)
            # Stall-recovery trim. If the queue has crept past the trim
            # threshold (consumer falling behind real-time), drop oldest
            # chunks down to a 1 s tail so the next chunk a listener
            # receives is *live*, not 6 s ago. Only fires while the
            # backlog is sustained; a momentary spike that drains
            # naturally is left alone.
            if q.qsize() > TRANSCRIBE_QUEUE_STALL_TRIM:
                trimmed = 0
                while q.qsize() > TRANSCRIBE_QUEUE_STALL_TAIL:
                    try:
                        q.get_nowait()
                        trimmed += 1
                    except Empty:
                        break
                if trimmed:
                    counter_attr = (
                        "_mic_drop_count" if role == "mic" else "_sys_drop_count"
                    )
                    prev = getattr(self, counter_attr)
                    setattr(self, counter_attr, prev + trimmed)
                    logger.warning(
                        "%s transcribe queue stall-trim: dropped %d chunks (~%.1fs) "
                        "down to %d-chunk live tail. Consumer was falling behind "
                        "and persistent lag would otherwise lock in.",
                        "Mic" if role == "mic" else "System",
                        trimmed, trimmed * 0.02, TRANSCRIBE_QUEUE_STALL_TAIL,
                    )
            return
        except Full:
            pass

        # Best-effort: pop one to make room, then put. A consumer racing here
        # may empty more than one slot — harmless; the put still succeeds.
        try:
            q.get_nowait()
        except Empty:
            pass
        try:
            q.put_nowait(item)
        except Full:
            # Catastrophic contention — drop the new item rather than block.
            pass

        if role == "mic":
            self._mic_drop_count += 1
            if self._mic_drop_count % TRANSCRIBE_DROP_LOG_EVERY == 1:
                logger.warning(
                    "Mic transcribe queue overflow — dropped %d chunks total. "
                    "Self transcriber is falling behind real-time.",
                    self._mic_drop_count,
                )
        else:
            self._sys_drop_count += 1
            if self._sys_drop_count % TRANSCRIBE_DROP_LOG_EVERY == 1:
                logger.warning(
                    "System transcribe queue overflow — dropped %d chunks total. "
                    "Other transcriber is falling behind real-time.",
                    self._sys_drop_count,
                )

    def start(self):
        self.stop_event.clear()
        self._mic_capture = AudioCapture(sample_rate=self._sample_rate)
        self._mic_capture.start()
        self._channels = self._mic_capture.channels

        self._system_capture = ScreenCaptureAudio(
            sample_rate=self._sample_rate, channels=self._channels
        )
        self._has_system_audio = self._system_capture.start()

        self._output_thread = Thread(target=self._process_audio, daemon=True)
        self._output_thread.start()

    def _process_audio(self):
        # Wrapped so an uncaught exception logs instead of silently killing
        # the daemon thread. A dead capture pump looks identical to "Whisper
        # stopped" from the user's seat — no audio reaches the transcriber.
        try:
            self._process_audio_loop()
        except Exception:
            logger.exception(
                "CombinedAudioCapture._process_audio crashed — audio pipeline "
                "stopped. Setting stop_event so the session loop notices "
                "instead of spinning on empty get_audio() calls forever."
            )
            # Without setting stop_event, the session loop reads None from
            # the empty audio_queue and keeps looping silently — recording
            # grows no further but no error is surfaced. Set it so the
            # session ends and the user sees a real failure.
            self.stop_event.set()

    def _process_audio_loop(self):
        # Safety cap of 60s per buffer: under normal load the loop drains every
        # iteration so buffers stay near empty, but if a downstream consumer
        # wedges we still cap memory growth instead of leaking forever. The old
        # 1s cap was the bug — slow CPUs couldn't drain in time and oldest
        # samples got silently dropped, which is what "audio cuts every 1–2s"
        # in playback actually was.
        max_buffer = self._sample_rate * 60
        mic_buffer: deque = deque(maxlen=max_buffer)
        sys_buffer: deque = deque(maxlen=max_buffer)
        # Separate buffer for the mp3 mix path. Sys samples are duplicated
        # into here as well as `sys_buffer`, so the *recording* mixer can
        # still align mic + sys per-window without the per-role transcription
        # queue ever being gated on mic availability.
        mix_sys_buffer: deque = deque(maxlen=self._sample_rate * 2)
        chunk_size = int(self._sample_rate * 0.02)

        while not self.stop_event.is_set():
            # Drain everything currently sitting in mic/system queues — never
            # leave samples behind on a single iteration.
            if self._mic_capture:
                while True:
                    mic_audio = self._mic_capture.get_audio(timeout=0)
                    if mic_audio is None:
                        break
                    mic_buffer.extend(mic_audio.flatten())

            if self._system_capture and self._system_capture.is_running:
                while True:
                    sys_audio = self._system_capture.get_audio(timeout=0)
                    if sys_audio is None:
                        break
                    flat = sys_audio.flatten()
                    sys_buffer.extend(flat)
                    mix_sys_buffer.extend(flat)

            produced_any = False

            # SYS → _sys_transcribe_q. Decoupled from mic — drains as fast
            # as SCK delivers samples. The old design gated sys emission
            # on mic having a chunk ready, so when mic was slow (Bluetooth
            # comms mode, silent user, anything) sys chunks accumulated in
            # this local buffer instead of the per-role queue. That hid the
            # backlog from the stall-trim and produced a steady 3-5 s phase
            # offset between live audio and the OTHER transcript.
            while self._has_system_audio and len(sys_buffer) >= chunk_size:
                sys_chunk = np.array(
                    [sys_buffer.popleft() for _ in range(chunk_size)],
                    dtype=np.float32,
                )
                self._put_drop_oldest(self._sys_transcribe_q, sys_chunk.copy(), "sys")
                produced_any = True

            # MIC → _mic_transcribe_q, plus the mixed audio_queue for the
            # mp3 recording. The mixed path still needs mic+sys aligned
            # per window, so it consumes from mix_sys_buffer (an
            # independent copy of the sys stream).
            while len(mic_buffer) >= chunk_size:
                mic_chunk = np.array(
                    [mic_buffer.popleft() for _ in range(chunk_size)],
                    dtype=np.float32,
                )
                self._put_drop_oldest(self._mic_transcribe_q, mic_chunk.copy(), "mic")

                if self._has_system_audio and len(mix_sys_buffer) >= chunk_size:
                    sys_for_mix = np.array(
                        [mix_sys_buffer.popleft() for _ in range(chunk_size)],
                        dtype=np.float32,
                    )
                    mixed = np.clip(
                        mic_chunk * 0.7 + sys_for_mix * 0.7, -1.0, 1.0
                    )
                    self.audio_queue.put(mixed)
                else:
                    self.audio_queue.put(mic_chunk)
                produced_any = True

            # Yield CPU when there's nothing to do — avoids a busy spin.
            if not produced_any:
                self.stop_event.wait(0.005)

    def pause_mic(self):
        """Pause microphone stream (for MicProbe). System audio continues."""
        if self._mic_capture:
            self._mic_capture.pause()

    def resume_mic(self) -> bool:
        """Resume microphone stream after a probe.

        Returns True on success, False on failure. MicProbe.probe checks
        this and treats False as a probe failure rather than letting the
        exception kill the session.
        """
        if self._mic_capture:
            return self._mic_capture.resume()
        return True

    def stop(self):
        self.stop_event.set()
        if self._mic_capture:
            self._mic_capture.stop()
        if self._system_capture:
            self._system_capture.stop()

    def get_audio(self, timeout: float = 1.0) -> Optional[np.ndarray]:
        """Get audio for recording/session (silence detection, MP3 encoding)."""
        try:
            return self.audio_queue.get(timeout=timeout)
        except Empty:
            return None

    @property
    def channels(self) -> int:
        return self._channels

    @property
    def sample_rate(self) -> int:
        return self._sample_rate

    @property
    def has_system_audio(self) -> bool:
        return self._has_system_audio

    @property
    def self_stream(self) -> AudioStream:
        if self._self_stream is None:
            self._self_stream = AudioStream(
                queue=self._mic_transcribe_q,
                sample_rate=self._sample_rate,
                channels=self._channels,
            )
        return self._self_stream

    @property
    def other_stream(self) -> AudioStream:
        if self._other_stream is None:
            self._other_stream = AudioStream(
                queue=self._sys_transcribe_q,
                sample_rate=self._sample_rate,
                channels=self._channels,
            )
        return self._other_stream


class AudioStream:
    """Thin adapter exposing the same `get_transcriber_audio` interface
    transcribers expect, but backed by a dedicated per-role queue.

    Lives inside CombinedAudioCapture; not instantiated by callers directly.
    """

    def __init__(self, queue: "Queue[np.ndarray]", sample_rate: int, channels: int) -> None:
        self._queue = queue
        self._sample_rate = sample_rate
        self._channels = channels

    def get_transcriber_audio(self, timeout: float = 0.01) -> Optional[np.ndarray]:
        try:
            return self._queue.get(timeout=timeout)
        except Empty:
            return None

    def flush(self) -> int:
        """Drop every chunk currently queued and return how many were dropped.

        Called by the transcriber the moment its WebSocket actually opens, so
        the audio captured during the ~1 s connect-handshake window does not
        end up as a permanent phase offset between live speech and emitted
        transcripts. Without this, SCK starts firing the instant macOS gives
        us the stream while Deepgram's WS is still negotiating, and those
        chunks sit at the head of the queue for the rest of the session
        (consumer rate = producer rate ⇒ offset never closes).
        """
        dropped = 0
        while True:
            try:
                self._queue.get_nowait()
                dropped += 1
            except Empty:
                return dropped

    @property
    def sample_rate(self) -> int:
        return self._sample_rate

    @property
    def channels(self) -> int:
        return self._channels
