"""Native macOS overlay window — always-on-top, frameless, dark panel.

Stripped-down heads-up display: live transcript (self + other), the streamed
AI response, and a small screenshot-count badge. All controls live in the web
UI now; this window is display-only.

Launched as a separate process by the daemon (on a double-Esc hotkey).
Connects to the daemon WebSocket and renders the live state. It hides from
screen capture via NSWindowSharingNone so it never leaks into a screen share.

Usage (internal):  python -m meeting_helper.overlay <port>
"""

from __future__ import annotations

import json
import sys
import threading
from dataclasses import dataclass

from PySide6.QtCore import (
    Qt,
    QObject,
    QThread,
    QTimer,
    Signal,
    Slot,
)
from PySide6.QtGui import QFont
from PySide6.QtWebSockets import QWebSocket
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizeGrip,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

# ---------------------------------------------------------------------------
# Markdown -> HTML renderer
# ---------------------------------------------------------------------------

def _md_to_html(text: str, font_size: int = 14) -> str:
    """Convert markdown to styled HTML for QTextBrowser."""
    try:
        import markdown
        from pygments.formatters import HtmlFormatter

        formatter = HtmlFormatter(style="github-dark", noclasses=True)
        pygments_css = formatter.get_style_defs(".codehilite")

        extensions = ["fenced_code", "codehilite", "tables", "nl2br"]
        body = markdown.markdown(text, extensions=extensions)

        code_size = max(8, font_size - 2)
        return f"""<style>
body {{ color: #e6edf3; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
        font-size: {font_size}px; line-height: 1.65; margin: 0; padding: 0; background: transparent; }}
h1, h2, h3 {{ color: #ffffff; margin: 14px 0 6px; }}
h1 {{ font-size: {font_size + 2}px; }}
h2 {{ font-size: {font_size + 1}px; }}
h3 {{ font-size: {font_size}px; }}
p {{ margin: 6px 0; }}
code {{ background: #1c2128; border: 1px solid #30363d; border-radius: 3px;
        padding: 1px 5px; font-family: Menlo, monospace; font-size: {code_size}px; color: #79c0ff; }}
pre {{ background: #1c2128; border: 1px solid #30363d; border-radius: 6px;
       padding: 12px; margin: 8px 0; overflow-x: auto; }}
pre code {{ background: none; border: none; padding: 0; color: #e6edf3; font-size: {code_size}px; }}
ul, ol {{ padding-left: 18px; margin: 6px 0; }}
li {{ margin: 3px 0; }}
strong {{ color: #ffffff; }}
em {{ color: #d2a8ff; }}
blockquote {{ border-left: 3px solid #30363d; margin: 6px 0; padding-left: 10px; color: #8b949e; }}
table {{ border-collapse: collapse; width: 100%; margin: 8px 0; font-size: {font_size - 1}px; }}
th, td {{ border: 1px solid #30363d; padding: 5px 10px; }}
th {{ background: #1c2128; }}
{pygments_css}
</style>
{body}"""
    except Exception:
        escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return f'<pre style="color:#e6edf3;white-space:pre-wrap">{escaped}</pre>'


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _hide_all_windows_from_capture() -> None:
    """Set NSWindowSharingNone on every window this app owns.

    Called on every showEvent and periodically, so the overlay can never leak
    into a screen share.
    """
    try:
        from AppKit import NSApp
        for window in NSApp.windows():
            try:
                window.setSharingType_(0)
            except Exception:
                pass
    except Exception:
        pass


# ---------------------------------------------------------------------------
# WebSocket worker
# ---------------------------------------------------------------------------

class WSWorker(QObject):
    message = Signal(dict)
    connected = Signal()
    disconnected = Signal()

    def __init__(self, port: int) -> None:
        super().__init__()
        self._port = port
        self._ws: QWebSocket | None = None

    def start(self) -> None:
        self._ws = QWebSocket()
        self._ws.connected.connect(self._on_connected)
        self._ws.disconnected.connect(self._on_disconnected)
        self._ws.textMessageReceived.connect(self._on_message)
        self._connect()

    def _connect(self) -> None:
        from PySide6.QtCore import QUrl
        self._ws.open(QUrl(f"ws://127.0.0.1:{self._port}/ws"))

    @Slot()
    def _on_connected(self) -> None:
        self.connected.emit()

    @Slot()
    def _on_disconnected(self) -> None:
        self.disconnected.emit()
        QTimer.singleShot(2000, self._connect)

    @Slot(str)
    def _on_message(self, raw: str) -> None:
        try:
            self.message.emit(json.loads(raw))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Overlay window
# ---------------------------------------------------------------------------

BG_COLOR = "#0d1117"
BG_ALPHA = 230


@dataclass
class OverlayState:
    """Pure-data state for OverlayWindow.

    Qt widgets, timers, threads, and the WS client stay as direct instance
    attributes on OverlayWindow — only data-only state lives here.
    """
    # Streaming / response state
    raw_md: str = ""
    current_html: str = ""

    # Display preferences
    font_size: int = 14

    # Per-segment transcript accumulation per role (for fade/clear logic)
    self_finals: str = ""
    other_finals: str = ""

    # Meeting metadata
    meeting_name: str = ""

    # UI interaction state
    drag_pos: object = None  # QPoint | None — typed loosely to keep dataclass import-light


class OverlayWindow(QWidget):
    def __init__(self, port: int) -> None:
        super().__init__()
        self._port = port
        self.state = OverlayState()
        # Coalesces fast AI chunk arrivals into one full re-render every
        # ~120 ms instead of rebuilding the entire HTML/Pygments tree on
        # every token. _md_to_html cost grows with content length, so
        # without throttling streaming chunks block the Qt main thread
        # progressively harder as the response grows.
        self._chunk_render_pending = False
        self._setup_window()
        self._build_ui()
        self._start_ws()
        # Re-apply sharing=none after 500ms — some MDM policies reset it on first paint
        QTimer.singleShot(500, self._apply_sharing_none)
        # Periodic re-apply so any newly-created child window inherits
        # NSWindowSharingNone even if its own showEvent fires before
        # NSApp.windows() returns it.
        self._sharing_timer = QTimer(self)
        self._sharing_timer.setInterval(1500)
        self._sharing_timer.timeout.connect(self._apply_sharing_none)
        self._sharing_timer.start()

    def _setup_window(self) -> None:
        self.setWindowFlags(
            Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground)

        screen = QApplication.primaryScreen().availableGeometry()
        width = min(screen.width() - 32, 720)
        height = min(screen.height() - 32, 620)
        self.resize(width, height)
        self.move(
            screen.right() - width - 90,
            screen.bottom() - height - 16,
        )

    def showEvent(self, event) -> None:
        """Hide window from screen capture/screen share."""
        super().showEvent(event)
        self._apply_sharing_none()

    def _apply_sharing_none(self) -> None:
        """Set NSWindowSharingNone on all app windows."""
        _hide_all_windows_from_capture()

    def _build_ui(self) -> None:
        # Root: transparent outer, then the card.
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self._card = QWidget()
        self._card.setObjectName("card")
        self._card.setStyleSheet(f"""
            QWidget#card {{
                background: rgba(13,17,23,{BG_ALPHA});
                border: 1px solid #30363d;
                border-radius: 12px;
            }}
        """)
        outer.addWidget(self._card)

        main_layout = QVBoxLayout(self._card)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Title bar
        title_bar = QWidget()
        title_bar.setFixedHeight(32)
        title_bar.setStyleSheet("background: transparent;")
        tb_layout = QHBoxLayout(title_bar)
        tb_layout.setContentsMargins(12, 0, 8, 0)

        self._status_dot = QLabel()
        self._status_dot.setText("●")
        self._status_dot.setStyleSheet("color: #555; font-size: 10px;")
        tb_layout.addWidget(self._status_dot)

        self._title_label = QLabel("Meeting Helper")
        self._title_label.setStyleSheet("color: #8b949e; font-size: 11px;")
        tb_layout.addWidget(self._title_label)
        tb_layout.addStretch()

        # Screenshot-count badge — shows the number of buffered screenshots.
        # Fed by the `screenshots` WS broadcast; hidden when the count is 0.
        self._shot_badge = QLabel("")
        self._shot_badge.setStyleSheet(
            "QLabel { background: rgba(30,111,235,0.18); color: #79b8ff; "
            "border: 1px solid #1f6feb; border-radius: 8px; "
            "padding: 2px 9px; font-size: 11px; }"
        )
        self._shot_badge.setToolTip("Buffered screenshots awaiting the next query")
        self._shot_badge.hide()
        tb_layout.addWidget(self._shot_badge)

        # Close (X): quits the overlay process. Double-Esc brings it back (the
        # daemon detects the dead process on the next toggle and respawns it),
        # so this is a clean dismiss that doesn't leave the daemon's visibility
        # flag stale the way a bare hide would.
        self._close_btn = QPushButton("✕")
        self._close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._close_btn.setFixedSize(20, 20)
        self._close_btn.setToolTip("Close overlay (double-Esc to bring it back)")
        self._close_btn.setStyleSheet(
            "QPushButton { background: transparent; color: #8b949e; border: none; "
            "font-size: 13px; } QPushButton:hover { color: #f85149; }"
        )
        self._close_btn.clicked.connect(self._on_close_clicked)
        tb_layout.addWidget(self._close_btn)

        main_layout.addWidget(title_bar)

        # Divider
        divider = QWidget()
        divider.setFixedHeight(1)
        divider.setStyleSheet("background: #21262d;")
        main_layout.addWidget(divider)

        # Thinking label
        self._thinking_label = QLabel("  Thinking...")
        self._thinking_label.setStyleSheet("color: #8b949e; font-size: 12px; padding: 8px 12px;")
        self._thinking_label.hide()
        main_layout.addWidget(self._thinking_label)

        # Scroll area + text browser for the streamed AI response
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical { width: 5px; background: transparent; }
            QScrollBar::handle:vertical { background: #30363d; border-radius: 2px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        """)

        self._browser = QTextBrowser()
        self._browser.setOpenExternalLinks(True)
        self._browser.setStyleSheet("background: transparent; border: none; color: #e6edf3;")
        self._browser.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        font = QFont("Helvetica Neue", self.state.font_size)
        self._browser.setFont(font)
        scroll.setWidget(self._browser)
        main_layout.addWidget(scroll)

        self._scroll = scroll

        # Two-row transcript display (self + other) — each row hides individually.
        # SELF row: your microphone speech.
        self._transcript_self_label = QLabel()
        self._transcript_self_label.setWordWrap(True)
        self._transcript_self_label.setTextFormat(Qt.TextFormat.PlainText)
        self._transcript_self_label.setStyleSheet(
            "color: #8b949e; font-size: 11px; padding: 4px 12px 0; background: transparent;"
        )
        self._transcript_self_label.hide()
        main_layout.addWidget(self._transcript_self_label)

        # OTHER row: system audio (other meeting participants).
        self._transcript_other_label = QLabel()
        self._transcript_other_label.setWordWrap(True)
        self._transcript_other_label.setTextFormat(Qt.TextFormat.PlainText)
        self._transcript_other_label.setStyleSheet(
            "color: #8b949e; font-size: 11px; padding: 0 12px 4px; background: transparent;"
        )
        self._transcript_other_label.hide()
        main_layout.addWidget(self._transcript_other_label)

        # Resize grip
        grip_row = QWidget()
        grip_row.setStyleSheet("background: transparent;")
        grip_layout = QHBoxLayout(grip_row)
        grip_layout.setContentsMargins(0, 0, 4, 4)
        grip_layout.addStretch()
        grip = QSizeGrip(self)
        grip.setStyleSheet("background: transparent;")
        grip_layout.addWidget(grip)
        main_layout.addWidget(grip_row)

    def _set_screenshot_count(self, count: int) -> None:
        """Update the screenshot badge — camera glyph + count, hidden at 0."""
        if count > 0:
            self._shot_badge.setText(f"\U0001f4f7 {count}")
            self._shot_badge.show()
        else:
            self._shot_badge.setText("")
            self._shot_badge.hide()

    def _on_close_clicked(self) -> None:
        """Close button: quit the overlay process. The daemon notices the dead
        process on the next double-Esc and respawns a fresh overlay."""
        app = QApplication.instance()
        if app is not None:
            app.quit()

    def _start_ws(self) -> None:
        self._ws_thread = QThread()
        self._ws_worker = WSWorker(self._port)
        self._ws_worker.moveToThread(self._ws_thread)
        self._ws_thread.started.connect(self._ws_worker.start)
        self._ws_worker.message.connect(self._on_message)
        self._ws_worker.connected.connect(self._on_connected)
        self._ws_worker.disconnected.connect(self._on_disconnected)
        self._ws_thread.start()

    def _render_chunk(self) -> None:
        """Render the current accumulated AI response into the browser.

        Called via a debounced QTimer to coalesce rapid chunk arrivals.
        Preserves scroll-following behavior: stays pinned to bottom if the
        user was at the bottom; otherwise restores their scroll position.
        """
        self._chunk_render_pending = False
        sb = self._scroll.verticalScrollBar()
        was_at_bottom = sb.maximum() == 0 or (sb.maximum() - sb.value()) < 60
        old_pos = sb.value()
        self._browser.setHtml(_md_to_html(self.state.raw_md, self.state.font_size))
        self.state.current_html = self.state.raw_md
        if was_at_bottom:
            QTimer.singleShot(0, lambda: self._scroll.verticalScrollBar().setValue(
                self._scroll.verticalScrollBar().maximum()
            ))
        else:
            QTimer.singleShot(0, lambda p=old_pos: self._scroll.verticalScrollBar().setValue(p))

    # ---- Message handling ----

    @Slot(dict)
    def _on_message(self, msg: dict) -> None:
        t = msg.get("type")

        if t == "status":
            val = msg.get("value", "idle")
            if val == "processing":
                self._status_dot.setStyleSheet("color: #f85149; font-size: 10px;")
            elif val == "listening":
                self._status_dot.setStyleSheet("color: #3fb950; font-size: 10px;")
            else:
                self._status_dot.setStyleSheet("color: #555; font-size: 10px;")

        elif t == "screenshots":
            items = msg.get("items") or []
            self._set_screenshot_count(len(items))

        elif t == "meeting_status":
            if msg.get("active"):
                app_name = msg.get("app", "")
                meeting_name = msg.get("meeting_name", "")
                parts = ["Meeting Helper"]
                if app_name:
                    parts.append(app_name)
                if meeting_name:
                    parts.append(f'"{meeting_name}"')
                self.state.meeting_name = meeting_name or app_name
                self._title_label.setText("  ·  ".join(parts))
                self._title_label.setStyleSheet("color: #3fb950; font-size: 11px;")
            else:
                self.state.meeting_name = ""
                self._title_label.setText("Meeting Helper  ·  idle")
                self._title_label.setStyleSheet("color: #8b949e; font-size: 11px;")

        elif t == "meeting_ended":
            self.state.raw_md = ""
            self.state.current_html = ""
            self.state.meeting_name = ""
            self._browser.setHtml("")
            self._thinking_label.hide()
            self._transcript_self_label.hide()
            self._transcript_self_label.setText("")
            self._transcript_other_label.hide()
            self._transcript_other_label.setText("")
            self.state.self_finals = ""
            self.state.other_finals = ""
            self._title_label.setText("Meeting Helper  ·  idle")
            self._title_label.setStyleSheet("color: #8b949e; font-size: 11px;")
            self._status_dot.setStyleSheet("color: #555; font-size: 10px;")
            self._set_screenshot_count(0)

        elif t == "transcript":
            text = msg.get("text", "") or ""
            role = (msg.get("role") or "self").strip().lower()
            if role not in ("self", "other"):
                role = "self"

            # Pick the right label + accumulator + accent color per role
            if role == "self":
                label = self._transcript_self_label
                tag = "\U0001f3a4"
                accent = "#3fb950"  # green
                muted = "#8b949e"
            else:
                label = self._transcript_other_label
                tag = "\U0001f50a"
                accent = "#79b8ff"  # blue
                muted = "#8b949e"

            if msg.get("interim"):
                accum = getattr(self.state, f"{role}_finals", "")
                combined = (accum + " " + text).strip()
                if len(combined) > 160:
                    combined = "…" + combined[-157:]
                display = f"{tag} {combined}"
                label.setStyleSheet(
                    f"color: {muted}; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                )
            else:
                accum = getattr(self.state, f"{role}_finals", "")
                accum = (accum + " " + text).strip()
                if len(accum) > 300:
                    accum = "…" + accum[-297:]
                setattr(self.state, f"{role}_finals", accum)
                display = f"{tag} {accum}"
                label.setStyleSheet(
                    f"color: {accent}; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                )
                # Fade the bright color back to muted after a beat
                _label_ref = label  # captured by lambda
                QTimer.singleShot(800, lambda lbl=_label_ref, mc=muted: lbl.setStyleSheet(
                    f"color: {mc}; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                ))
            label.setText(display)
            label.show()

        elif t == "start":
            self.state.raw_md = ""
            self.state.current_html = ""
            self._browser.setHtml("")
            self._transcript_self_label.hide()
            self._transcript_self_label.setText("")
            self._transcript_other_label.hide()
            self._transcript_other_label.setText("")
            self.state.self_finals = ""
            self.state.other_finals = ""
            if msg.get("proactive"):
                question = msg.get("question", "")
                label = f"  ⚡ Auto · {question[:60]}{'…' if len(question) > 60 else ''}"
                self._thinking_label.setStyleSheet("color: #4ec9b0; font-size: 11px; padding: 8px 12px;")
            else:
                label = "  Thinking..."
                self._thinking_label.setStyleSheet("color: #8b949e; font-size: 12px; padding: 8px 12px;")
            self._thinking_label.setText(label)
            self._thinking_label.show()

        elif t == "chunk":
            self._thinking_label.hide()
            self._thinking_label.setStyleSheet("color: #8b949e; font-size: 12px; padding: 8px 12px;")
            self.state.raw_md += msg.get("text", "")
            # Debounce — coalesce rapid token arrivals into one render every
            # ~120 ms. Without this, every chunk runs Pygments + setHtml on
            # the entire growing buffer, which gets quadratically expensive
            # and visibly stutters during long responses.
            if not self._chunk_render_pending:
                self._chunk_render_pending = True
                QTimer.singleShot(120, self._render_chunk)

        elif t == "done":
            self._thinking_label.hide()
            full = msg.get("full_text", "")
            if full and not self.state.raw_md:
                self.state.raw_md = full
                self._browser.setHtml(_md_to_html(self.state.raw_md, self.state.font_size))
                self.state.current_html = self.state.raw_md
            elif self.state.raw_md:
                # Force a final render so the last few tokens don't sit in the
                # 120 ms debounce window unrendered.
                self._render_chunk()

        elif t == "error":
            self._thinking_label.hide()
            err_html = f'<p style="color:#f85149">Warning: {msg.get("message", "Unknown error")}</p>'
            self._browser.setHtml(err_html)

        elif t == "transcriber_dead":
            # Make the overlay's answer area show a one-shot warning so the
            # user sees the transcriber giving up instead of guessing why
            # captions stopped.
            role = (msg.get("role") or "?").lower()
            reason = msg.get("reason") or "unknown"
            warning_html = (
                f'<p style="color:#f85149">Transcriber dead '
                f'({role}, reason={reason}). Health monitor will retry.</p>'
            )
            self._browser.setHtml(warning_html)

        elif t in ("overlay_toggle", "overlay_visibility"):
            # Daemon-driven show/hide toggle (double-Esc). Both event names are
            # accepted so older daemons that still emit `overlay_toggle` work.
            if msg.get("visible"):
                self.show()
            else:
                self.hide()

    @Slot()
    def _on_connected(self) -> None:
        title = "Meeting Helper  ·  connected"
        if self.state.meeting_name:
            title = f"Meeting Helper  ·  {self.state.meeting_name}"
        self._title_label.setText(title)
        self._title_label.setStyleSheet("color: #3fb950; font-size: 11px;")

    @Slot()
    def _on_disconnected(self) -> None:
        self._title_label.setText("Meeting Helper  ·  reconnecting...")
        self._title_label.setStyleSheet("color: #d29922; font-size: 11px;")

    # ---- Cleanup ----

    def closeEvent(self, event) -> None:
        if hasattr(self, "_ws_thread") and self._ws_thread.isRunning():
            self._ws_thread.quit()
            self._ws_thread.wait(2000)
        super().closeEvent(event)

    # ---- Drag to move ----

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.state.drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        if self.state.drag_pos and event.buttons() & Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self.state.drag_pos)

    def mouseReleaseEvent(self, event):
        self.state.drag_pos = None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    import os
    try:
        os.setsid()
    except OSError:
        pass

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 7891

    app = QApplication(sys.argv)
    app.setApplicationName("Meeting Helper")

    # Hide from Dock on macOS
    try:
        from AppKit import NSApplication, NSApplicationActivationPolicyAccessory
        NSApplication.sharedApplication().setActivationPolicy_(
            NSApplicationActivationPolicyAccessory
        )
    except Exception:
        pass

    window = OverlayWindow(port)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
