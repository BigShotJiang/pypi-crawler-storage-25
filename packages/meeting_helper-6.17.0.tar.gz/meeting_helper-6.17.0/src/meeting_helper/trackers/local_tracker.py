"""In-process Tracker for the meeting_helper vendor (MH-40).

The existing `Tracker` spawns an MCP subprocess / HTTP client; this subclass
short-circuits that and exposes an in-process session that mimics the MCP
`ClientSession` surface (`list_tools` + `call_tool`). Callers that reach
through `_session` directly — the Connect/Test handlers in `routes.py` and
the chat passthrough's `mcp._session.list_tools()` — work unchanged.
"""
from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any, Callable

from meeting_helper.server.mcp_server import _TOOLS, _dispatch
from meeting_helper.trackers.profile import VendorProfile, Workspace
from meeting_helper.trackers.tracker import Tracker
from meeting_helper.trackers.vendors.meeting_helper_store import (
    MeetingHelperStore,
)


class _InProcessSession:
    """Stand-in for an MCP `ClientSession` when the tracker is local.

    Implements the two methods consumers reach for through `_session`:
    `list_tools()` returns the same tool catalog the HTTP MCP exposes, and
    `call_tool()` runs the local dispatch and returns an MCP-shaped
    `CallToolResult` (content list + isError flag) so the chat passthrough
    can use the result without special-casing the vendor.
    """

    def __init__(self, disk_factory: Callable[[], Any]) -> None:
        self._disk_factory = disk_factory

    async def list_tools(self) -> SimpleNamespace:
        return SimpleNamespace(
            tools=[
                SimpleNamespace(
                    name=t["name"],
                    description=t.get("description", ""),
                    inputSchema=t.get("inputSchema", {}),
                )
                for t in _TOOLS
            ],
        )

    async def call_tool(
        self, name: str, arguments: dict | None = None,
    ) -> SimpleNamespace:
        # Offload to executor: store init + _dispatch do sync workspace-JSON
        # load and (on mutating tools) a full file rewrite. Running this on
        # the asyncio loop blocks transcript broadcasts during agent traffic
        # (ticket #25).
        import asyncio as _asyncio
        def _run():
            store = MeetingHelperStore(self._disk_factory())
            return _dispatch(store, name, arguments or {})
        try:
            result = await _asyncio.to_thread(_run)
        except (KeyError, ValueError) as exc:
            return SimpleNamespace(
                content=[SimpleNamespace(type="text", text=str(exc))],
                isError=True,
            )
        return SimpleNamespace(
            content=[SimpleNamespace(type="text", text=json.dumps(result))],
            isError=False,
        )


class LocalTracker(Tracker):
    """A Tracker that talks to a local MeetingHelperStore instead of MCP."""

    def __init__(
        self, *, profile: VendorProfile,
        disk_factory: Callable[[], Any],
    ) -> None:
        super().__init__(
            profile=profile,
            transport={"type": "http", "url": "local://meeting_helper"},
            oauth_workspace="", oauth_tracker_id="",
            interactive_oauth=False,
        )
        self._disk_factory = disk_factory

    async def _ensure_started_locked(self) -> None:
        # Build a fake session that mimics the MCP ClientSession surface so
        # callers reaching through `_session` (Test connection, chat
        # passthrough) work without a vendor-specific branch.
        if self._session is None:
            self._session = _InProcessSession(self._disk_factory)

    async def close(self, *, timeout: float = 5.0) -> None:
        self._session = None

    async def list_workspaces(self) -> list[Workspace]:
        return [Workspace(id="local", name="Local", permission="write")]

    async def call_tool(self, name: str, args: dict | None = None) -> Any:
        # Offload: sync workspace-JSON load + (on mutating tools) full
        # rewrite. Keep off the asyncio loop (ticket #25).
        import asyncio as _asyncio
        def _run():
            store = MeetingHelperStore(self._disk_factory())
            return _dispatch(store, name, args or {})
        return await _asyncio.to_thread(_run)
