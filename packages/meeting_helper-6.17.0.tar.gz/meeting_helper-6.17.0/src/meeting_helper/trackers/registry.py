"""Owns multiple Tracker sessions per workspace.

A workspace can have N MCP trackers connected at once (multi-tracker chat
spec). One of them is the *Copilot tracker* — Brief and the Copilot
agent_fetch loop read `state.tracker`, which always mirrors that single
session. Chat enumerates every chat-enabled tracker.

Sessions are built lazily on first `ensure_session(entry)`; subsequent calls
return the cached session. `shutdown(tid=None)` closes one or all.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Optional

from meeting_helper.trackers.profile import VendorProfile
from meeting_helper.trackers.secrets import read_secrets, KeychainUnavailable
from meeting_helper.trackers.tracker import Tracker
from meeting_helper.trackers.transport import expand_transport
from meeting_helper.trackers.vendors import ALL_PROFILES

logger = logging.getLogger(__name__)


class UnknownVendor(Exception):
    """Raised when a vendor id is not in the fixed catalog."""


_PROFILE_BY_ID = {P.id: P for P in ALL_PROFILES}


def get_profile(vendor_id: str) -> type[VendorProfile]:
    if vendor_id not in _PROFILE_BY_ID:
        raise UnknownVendor(vendor_id)
    return _PROFILE_BY_ID[vendor_id]


class TrackerRegistry:
    def __init__(self, *, disk_factory: Optional[callable] = None) -> None:
        self._lock = asyncio.Lock()
        self._sessions: dict[str, Tracker] = {}
        self._copilot_id: Optional[str] = None
        # Injected by the daemon at boot so LocalTracker (meeting_helper
        # vendor) reads through the request-scoped Config rather than the
        # process-wide singleton. Tests construct the registry with a shim
        # factory; production wires it to the daemon's disk callback.
        # Falls back to meeting_helper.config.get_config only at the
        # eleventh hour, with a logged warning.
        self._disk_factory = disk_factory

    # ----- session lifecycle ------------------------------------------------

    async def ensure_session(
        self,
        entry: dict,
        *,
        workspace_name: str = "",
        interactive_oauth: bool = False,
    ) -> Tracker:
        """Return the live Tracker for ``entry["id"]``, building one if needed.

        Concurrent callers for the same id coalesce: only one build runs,
        all of them receive the same Tracker.

        ``interactive_oauth`` defaults to ``False`` — background callers
        (pre-warm, chat passthrough, Test connection) should never silently
        open a browser. Only the explicit Connect button passes ``True``.
        """
        tid = entry["id"]
        # Fast-path: no lock contention if already cached.
        cached = self._sessions.get(tid)
        if cached is not None:
            return cached
        # Slow-path: read secrets WITHOUT holding the lock (keyring is sync +
        # can block hundreds of ms on macOS; stalling the event loop here
        # freezes the daemon on every new tracker first-touch).
        try:
            loop = asyncio.get_running_loop()
            secrets = await loop.run_in_executor(
                None, read_secrets,
                workspace_name, tid, entry.get("secret_keys", []) or [],
            )
        except KeychainUnavailable as exc:
            logger.error("ensure_session: keychain unavailable for %s: %s", tid, exc)
            secrets = {}
        # Re-check under the lock — another coroutine might have built it.
        async with self._lock:
            cached = self._sessions.get(tid)
            if cached is not None:
                return cached
            built = self._build(
                tracker_id=tid,
                vendor_id=entry.get("vendor", ""),
                auth_values=entry.get("auth_values", {}) or {},
                secrets=secrets,
                workspace_name=workspace_name,
                interactive_oauth=interactive_oauth,
            )
            self._sessions[tid] = built
            return built

    def get(self, tracker_id: str) -> Optional[Tracker]:
        """Peek without spawning."""
        return self._sessions.get(tracker_id)

    async def shutdown(self, tracker_id: Optional[str] = None) -> None:
        """Close one session or every session."""
        async with self._lock:
            if tracker_id is None:
                victims = list(self._sessions.items())
                self._sessions.clear()
                self._copilot_id = None
            else:
                t = self._sessions.pop(tracker_id, None)
                victims = [(tracker_id, t)] if t is not None else []
                if self._copilot_id == tracker_id:
                    self._copilot_id = None
        for tid, t in victims:
            try:
                await t.close(timeout=5.0)
            except Exception as exc:
                logger.warning("registry.shutdown: close %s raised: %s", tid, exc)

    # ----- copilot designation ---------------------------------------------

    @property
    def copilot_id(self) -> Optional[str]:
        return self._copilot_id

    async def set_copilot(self, tracker_id: Optional[str], *, state=None) -> None:
        """Mark which tracker is the Copilot one and mirror its session into
        ``state.tracker`` (when ``state`` is provided). The tracker for
        ``tracker_id`` must already be ensured — callers do
        ``await ensure_session(entry); await set_copilot(entry['id'], state=...)``.
        """
        async with self._lock:
            self._copilot_id = tracker_id
            mirror = self._sessions.get(tracker_id) if tracker_id else None
        if state is not None:
            state.tracker = mirror

    # ----- read-side helpers -----------------------------------------------

    def chat_enabled_ids(self, config) -> list[str]:
        """Return tracker ids flagged ``chat_enabled`` in config.trackers
        (default True when the key is absent), preserving declared order."""
        out: list[str] = []
        for t in getattr(config, "trackers", []) or []:
            if t.get("chat_enabled", True):
                out.append(t["id"])
        return out

    # ----- internal --------------------------------------------------------

    def _build(self, *, tracker_id: str, vendor_id: str, auth_values: dict,
               secrets: dict, workspace_name: str = "",
               interactive_oauth: bool = False) -> Tracker:
        if vendor_id == "meeting_helper":
            # Bypass MCP transport — build an in-process tracker.
            from meeting_helper.trackers.local_tracker import LocalTracker
            from meeting_helper.trackers.vendors.meeting_helper import MeetingHelperProfile
            disk_factory = self._disk_factory
            if disk_factory is None:
                from meeting_helper.config import get_config
                logger.warning(
                    "TrackerRegistry: no disk_factory injected — falling back to "
                    "get_config() for LocalTracker. Tests that exercise this path "
                    "should pass disk_factory= to TrackerRegistry() to avoid "
                    "touching the real workspace JSON."
                )
                disk_factory = get_config
            return LocalTracker(
                profile=MeetingHelperProfile(),
                disk_factory=disk_factory,
            )
        ProfileCls = get_profile(vendor_id)
        profile = ProfileCls()
        transport = expand_transport(profile.transport, auth_values, secrets)
        return Tracker(
            profile=profile,
            transport=transport,
            oauth_workspace=workspace_name,
            oauth_tracker_id=tracker_id,
            interactive_oauth=interactive_oauth,
        )

    # ----- legacy API (kept for back-compat with existing call sites) ----
    # These wrap the new multi-session API so old code paths continue to
    # work. New code should use ensure_session + set_copilot directly.

    @property
    def current(self) -> Optional[Tracker]:
        """Legacy: the Copilot tracker's session, or None."""
        if self._copilot_id is None:
            return None
        return self._sessions.get(self._copilot_id)

    @property
    def active_id(self) -> Optional[str]:
        """Legacy alias for copilot_id."""
        return self._copilot_id

    async def boot(self, *, tracker_id: str, vendor_id: str, auth_values: dict,
                   secrets: dict, workspace_name: str = "") -> None:
        """Legacy: initial single-tracker boot. Equivalent to
        ensure_session() + set_copilot()."""
        entry = {"id": tracker_id, "vendor": vendor_id,
                 "auth_values": auth_values, "secret_keys": list(secrets.keys())}
        # Direct build (skip read_secrets — secrets are passed in).
        async with self._lock:
            built = self._build(
                tracker_id=tracker_id, vendor_id=vendor_id,
                auth_values=auth_values, secrets=secrets,
                workspace_name=workspace_name,
            )
            self._sessions[tracker_id] = built
            self._copilot_id = tracker_id

    async def activate(self, *, tracker_id: str, vendor_id: str, auth_values: dict,
                       secrets: dict, workspace_name: str = "") -> None:
        """Legacy: swap to a new Copilot tracker, closing the prior one."""
        prev_id = self._copilot_id
        if prev_id and prev_id != tracker_id:
            await self.shutdown(prev_id)
        await self.boot(
            tracker_id=tracker_id, vendor_id=vendor_id,
            auth_values=auth_values, secrets=secrets,
            workspace_name=workspace_name,
        )

    async def set_for_test(self, *, tracker_id: str, tracker: Tracker) -> None:
        """Test-only seam: inject a pre-built (fake) Tracker as the Copilot one.

        Matches legacy single-tracker semantics: closes whatever was previously
        the Copilot session (even under a different id) before installing the
        replacement.
        """
        async with self._lock:
            prev_id = self._copilot_id
            prev = self._sessions.get(prev_id) if prev_id else None
            if prev is not None and prev is not tracker:
                try:
                    await prev.close(timeout=1.0)
                except Exception:
                    pass
                if prev_id != tracker_id:
                    self._sessions.pop(prev_id, None)
            self._sessions[tracker_id] = tracker
            self._copilot_id = tracker_id


async def reboot_copilot_tracker(state, config, workspace_name: str) -> None:
    """Re-resolve the Copilot tracker from config and mirror it into state.

    The chat-enabled trackers don't need explicit rebooting — each will
    rebuild on the next ensure_session call. Only the Copilot session is
    eagerly maintained so Brief and agent_fetch find ``state.tracker``
    populated.
    """
    registry: TrackerRegistry = getattr(state, "trackers", None)
    if registry is None:
        logger.warning("reboot_copilot_tracker: state.trackers is None — skipping")
        return

    copilot_id = getattr(config, "copilot_tracker_id", None) or getattr(config, "active_tracker_id", None)
    trackers_list = getattr(config, "trackers", []) or []
    entry = next((t for t in trackers_list if t.get("id") == copilot_id), None)

    # Shut down any previous copilot session that's no longer the target.
    prev_id = registry.copilot_id
    if prev_id and prev_id != copilot_id:
        await registry.shutdown(prev_id)

    if entry is None:
        await registry.set_copilot(None, state=state)
        logger.info("reboot_copilot_tracker: no copilot tracker configured")
        return

    vendor_id = entry.get("vendor", "")
    try:
        get_profile(vendor_id)
    except UnknownVendor:
        logger.warning("reboot_copilot_tracker: unknown vendor %r — leaving copilot inactive", vendor_id)
        await registry.set_copilot(None, state=state)
        return

    try:
        await registry.ensure_session(entry, workspace_name=workspace_name)
        await registry.set_copilot(copilot_id, state=state)
        logger.info("reboot_copilot_tracker: copilot=%s (%s)", copilot_id, vendor_id)
    except Exception as exc:
        logger.exception("reboot_copilot_tracker: ensure_session failed: %s", exc)
        await registry.set_copilot(None, state=state)


# ---- Back-compat aliases (one release) ----------------------------------

# Old name used by routes.py and daemon.py. New code calls reboot_copilot_tracker.
reboot_active_tracker = reboot_copilot_tracker
