"""In-memory `disk` shim for tests — avoids touching the user's workspace JSON.

Mirrors the subset of `Config` that the tracker route handlers use:
trackers list/setter, active_tracker_id getter/setter, workspace_name, save().
Reads its initial state from the `AppConfig` and never persists.
"""
from __future__ import annotations


class InMemoryDiskShim:
    def __init__(self, app_config) -> None:
        self._trackers = list(getattr(app_config, "trackers", []) or [])
        self._active = getattr(app_config, "active_tracker_id", None)
        self._workspace = getattr(app_config, "workspace_name", "") or "test"
        # Tests sometimes need a workspace JSON path (e.g. for the
        # action-items orphan file). Point it at /tmp so reads return empty
        # and writes are harmless in tests; production never uses the shim.
        from pathlib import Path
        self.config_path = Path("/tmp") / f"_shim_{self._workspace}.json"
        self._mh_tasks: dict | None = None
        self._home = {
            "widgets": list(getattr(app_config, "home", {}).get("widgets", []) or [])
        }

    @property
    def trackers(self) -> list[dict]:
        return list(self._trackers)

    @trackers.setter
    def trackers(self, value: list[dict]) -> None:
        self._trackers = list(value)

    @property
    def active_tracker_id(self) -> str | None:
        return self._active

    @active_tracker_id.setter
    def active_tracker_id(self, value: str | None) -> None:
        self._active = value or None

    @property
    def workspace_name(self) -> str:
        return self._workspace

    @property
    def home(self) -> dict:
        return {"widgets": list(self._home["widgets"])}

    @home.setter
    def home(self, value: dict) -> None:
        if not isinstance(value, dict) or not isinstance(value.get("widgets"), list):
            raise ValueError("home must be {'widgets': list}")
        self._home = {"widgets": list(value["widgets"])}

    def save(self) -> None:
        # Intentional no-op for tests.
        return None

    def get_mh_tasks(self) -> dict:
        """Return a deep copy of the block. Mirrors `Config.get_mh_tasks` so
        the read-modify-write contract is identical between prod and tests
        — including the sprint migration applied on every read.
        """
        import copy as _copy
        from meeting_helper.trackers.vendors.meeting_helper_types import STATUS_ORDER
        from meeting_helper.trackers.vendors.meeting_helper_store import (
            migrate_mh_tasks_for_sprints,
        )
        if self._mh_tasks is None:
            self._mh_tasks = {
                "next_task_id": 1,
                "next_comment_id": 1,
                "visible_statuses": list(STATUS_ORDER),
                "tasks": [],
                "next_sprint_id": 1,
                "active_sprint_id": None,
                "sprints": [],
            }
        else:
            migrate_mh_tasks_for_sprints(self._mh_tasks)
        return _copy.deepcopy(self._mh_tasks)

    def set_mh_tasks(self, value: dict) -> None:
        self._mh_tasks = value
        # save() is the existing no-op
        self.save()
