"""Resolve a TransportTemplate against auth values + secrets into a
concrete transport dict the MCP client can consume."""
from __future__ import annotations

import re
from typing import Mapping

from meeting_helper.trackers.profile import TransportTemplate

_PLACEHOLDER_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")


def _sub(template: str, values: Mapping[str, str]) -> str:
    def replace(m: re.Match) -> str:
        key = m.group(1)
        if key not in values:
            raise KeyError(
                f"transport placeholder '{key}' not found in auth_values; "
                "tracker config may be stale"
            )
        return values[key]
    return _PLACEHOLDER_RE.sub(replace, template)


def expand_transport(
    tpl: TransportTemplate,
    auth_values: Mapping[str, str],
    secrets: Mapping[str, str],
) -> dict:
    """Resolve placeholders in a TransportTemplate against the merged
    auth values + secrets. Secrets win on conflict (defense against a
    profile accidentally declaring the same key in both spaces)."""
    merged: dict[str, str] = {**dict(auth_values), **dict(secrets)}
    if tpl.type == "stdio":
        return {
            "type": "stdio",
            "command": _sub(tpl.command, merged),
            "args": [_sub(a, merged) for a in tpl.args],
            "env": {k: _sub(v, merged) for k, v in tpl.env_template.items()},
        }
    return {
        "type": "http",
        "url": _sub(tpl.url_template, merged),
        "headers": {k: _sub(v, merged) for k, v in tpl.headers_template.items()},
    }


def redact_for_log(
    expanded: dict,
    *,
    secret_field_keys: list[str],
    secret_values: list[str],
) -> dict:
    """Return a copy of `expanded` with any secret value replaced by '***'.

    Matches by both the auth-field key NAME (in case the template wrote it
    into an env key) and the resolved VALUE (anywhere it appears).
    """
    placeholders = {f"***" for _ in secret_field_keys}  # marker set unused but keeps shape

    def scrub(s: str) -> str:
        for v in secret_values:
            if v and v in s:
                s = s.replace(v, "***")
        return s

    out: dict = {"type": expanded.get("type", "")}
    if expanded.get("type") == "stdio":
        out["command"] = scrub(expanded.get("command", ""))
        out["args"] = [scrub(a) for a in expanded.get("args", [])]
        out["env"] = {k: scrub(v) for k, v in (expanded.get("env") or {}).items()}
    else:
        out["url"] = scrub(expanded.get("url", ""))
        out["headers"] = {k: scrub(v) for k, v in (expanded.get("headers") or {}).items()}
    _ = placeholders  # silences linter; future use for shape symmetry
    return out
