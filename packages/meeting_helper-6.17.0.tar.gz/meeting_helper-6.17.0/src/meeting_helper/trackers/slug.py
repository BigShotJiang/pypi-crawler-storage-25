"""Per-tracker label -> URL/tool-name-safe slug.

Used to namespace chat tools across multiple MCP trackers in the same
workspace: a tracker labelled "Notion - Work" surfaces its tools as
`notion-work__<original_name>` in the chat tool registry.
"""
from __future__ import annotations

import re

_NON_ALNUM = re.compile(r"[^a-z0-9]+")
_FALLBACK = "tracker"


def slug_for_label(label: str) -> str:
    """Lowercase, collapse non-alphanumerics into '-', strip edge '-'.

    Falls back to ``"tracker"`` if the label normalises to an empty string
    (whitespace-only or punctuation-only). The caller must still
    disambiguate against the workspace's other slugs via :func:`slugify_unique`
    because two distinct labels can map to the same base slug.
    """
    s = _NON_ALNUM.sub("-", (label or "").strip().lower()).strip("-")
    return s or _FALLBACK


def slugify_unique(label: str, taken: set[str]) -> str:
    """Return ``slug_for_label(label)`` if unused, else append ``-2``, ``-3``, ...

    Mutates ``taken`` by adding the chosen slug. Caller passes the same set
    across iterations to disambiguate within a single workspace's tracker list.
    """
    base = slug_for_label(label)
    if base not in taken:
        taken.add(base)
        return base
    for n in range(2, 10_000):
        candidate = f"{base}-{n}"
        if candidate not in taken:
            taken.add(candidate)
            return candidate
    raise RuntimeError(f"could not disambiguate slug for label {label!r}")
