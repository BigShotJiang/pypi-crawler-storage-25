# src/meeting_helper/trackers/oauth.py
"""OAuth foundation for MCP-OAuth-capable trackers.

Components
----------
- KeychainTokenStorage  : persists tokens + DCR client info via keyring.
- LocalCallbackServer   : spins up a local aiohttp server to receive the auth code.
- open_browser          : opens the authorization URL in the default browser.
- build_oauth_provider  : convenience factory wrapping OAuthClientProvider.
"""
from __future__ import annotations

import asyncio
import logging
import socket
import webbrowser
from collections.abc import Awaitable, Callable

import keyring  # type: ignore[import]
from aiohttp import web

from mcp.client.auth import OAuthClientProvider, TokenStorage
from mcp.shared.auth import OAuthClientInformationFull, OAuthClientMetadata, OAuthToken

from meeting_helper.trackers.secrets import SERVICE

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# KeychainTokenStorage
# ---------------------------------------------------------------------------

class KeychainTokenStorage(TokenStorage):
    """Stores OAuth tokens and DCR client info in the OS keychain via keyring."""

    def __init__(self, workspace: str, tracker_id: str) -> None:
        self._token_account = f"{workspace}.{tracker_id}.oauth_token"
        self._client_account = f"{workspace}.{tracker_id}.oauth_client_info"

    async def get_tokens(self) -> OAuthToken | None:
        raw = keyring.get_password(SERVICE, self._token_account)
        if not raw:
            return None
        return OAuthToken.model_validate_json(raw)

    async def set_tokens(self, tokens: OAuthToken) -> None:
        keyring.set_password(SERVICE, self._token_account, tokens.model_dump_json())

    async def get_client_info(self) -> OAuthClientInformationFull | None:
        raw = keyring.get_password(SERVICE, self._client_account)
        if not raw:
            return None
        return OAuthClientInformationFull.model_validate_json(raw)

    async def set_client_info(self, client_info: OAuthClientInformationFull) -> None:
        keyring.set_password(SERVICE, self._client_account, client_info.model_dump_json())

    def purge(self) -> None:
        """Best-effort delete of both keychain entries; for tracker deletion path."""
        for account in (self._token_account, self._client_account):
            try:
                keyring.delete_password(SERVICE, account)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# LocalCallbackServer
# ---------------------------------------------------------------------------

class LocalCallbackServer:
    """Async aiohttp listener on 127.0.0.1 that captures the OAuth callback code."""

    def __init__(self) -> None:
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        self._port = sock.getsockname()[1]
        sock.close()
        self._future: asyncio.Future[tuple[str, str | None]] = asyncio.get_event_loop().create_future()
        self._runner: web.AppRunner | None = None

    @property
    def redirect_url(self) -> str:
        return f"http://127.0.0.1:{self._port}/callback"

    async def start(self) -> None:
        app = web.Application()
        app.router.add_get("/callback", self._handle)
        self._runner = web.AppRunner(app)
        await self._runner.setup()
        site = web.TCPSite(self._runner, "127.0.0.1", self._port)
        await site.start()

    async def _handle(self, request: web.Request) -> web.Response:
        code = request.query.get("code")
        state = request.query.get("state")
        error = request.query.get("error")
        if error and not self._future.done():
            self._future.set_exception(RuntimeError(f"OAuth error: {error}"))
        elif code and not self._future.done():
            self._future.set_result((code, state))
        html = (
            "<html><body style='font-family:system-ui;text-align:center;padding:40px'>"
            "<h2>You can close this tab.</h2>"
            "<p>Meeting Helper has received your authorization.</p>"
            "</body></html>"
        )
        return web.Response(text=html, content_type="text/html")

    async def wait_for_code(self, timeout: float = 300.0) -> tuple[str, str | None]:
        return await asyncio.wait_for(self._future, timeout=timeout)

    async def stop(self) -> None:
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None


# ---------------------------------------------------------------------------
# open_browser
# ---------------------------------------------------------------------------

def open_browser(url: str) -> None:
    """Open *url* in the default browser. Logs it so users can copy/paste if needed."""
    logger.info("Opening browser for OAuth authorization: %s", url)
    if not webbrowser.open(url):
        logger.warning("Could not open browser automatically. Please visit: %s", url)


# ---------------------------------------------------------------------------
# build_oauth_provider
# ---------------------------------------------------------------------------

def build_oauth_provider(
    *,
    server_url: str,
    workspace: str,
    tracker_id: str,
    callback_url: str,
    redirect_handler: Callable[[str], Awaitable[None]],
    callback_handler: Callable[[], Awaitable[tuple[str, str | None]]],
) -> OAuthClientProvider:
    """Convenience factory: wires :class:`KeychainTokenStorage` into the
    stock MCP ``OAuthClientProvider``.

    History: an earlier version subclassed the provider to force a
    refresh-token round-trip on every load (``_RefreshFirstOAuthClientProvider``).
    That made sense in theory — the stock provider doesn't set
    ``token_expiry_time`` from loaded tokens, so ``is_token_valid()`` returns
    True even for expired bearers, leading to a 401 → full OAuth → browser
    on every daemon start. In practice it made things WORSE for vendors
    whose refresh endpoint is unreliable (Atlassian's
    ``mcp.atlassian.com/v1/sse`` returns 404 on the refresh exchange even
    with brand-new tokens). The forced refresh fails → SDK opens the OAuth
    browser → our passive handler raises → user is told to "Reconnect" on
    a tracker that they JUST reconnected.

    Current behavior: use the stock provider. The SDK tries the loaded
    bearer; if the server 401s it tries refresh; if refresh fails it falls
    into the full OAuth flow (where our passive handler raises cleanly).
    This matches what the user expects: once you sign in, you stay signed in
    until the access token genuinely expires server-side."""
    storage = KeychainTokenStorage(workspace, tracker_id)
    metadata = OAuthClientMetadata(
        redirect_uris=[callback_url],
        token_endpoint_auth_method="client_secret_post",
        client_name="Meeting Helper",
        scope="mcp",
    )
    return OAuthClientProvider(
        server_url=server_url,
        client_metadata=metadata,
        storage=storage,
        redirect_handler=redirect_handler,
        callback_handler=callback_handler,
    )
