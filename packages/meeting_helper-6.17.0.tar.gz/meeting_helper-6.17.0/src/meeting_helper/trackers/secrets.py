# src/meeting_helper/trackers/secrets.py
"""Thin wrapper over the `keyring` library.

Service name is constant. Account name is `<workspace>.<tracker_id>.<key>`
so per-workspace and per-tracker isolation are intrinsic.
"""
from __future__ import annotations

import logging
from typing import Iterable, Mapping

import keyring  # type: ignore[import]

logger = logging.getLogger(__name__)

SERVICE = "meeting-helper"


class KeychainUnavailable(Exception):
    """Raised when the OS keychain backend is missing or unusable."""


def _account(workspace: str, tracker_id: str, key: str) -> str:
    return f"{workspace}.{tracker_id}.{key}"


def write_secrets(workspace: str, tracker_id: str, values: Mapping[str, str]) -> None:
    for key, value in values.items():
        try:
            keyring.set_password(SERVICE, _account(workspace, tracker_id, key), value)
        except Exception as exc:
            raise KeychainUnavailable(str(exc)) from exc


def read_secrets(workspace: str, tracker_id: str, keys: Iterable[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for key in keys:
        try:
            val = keyring.get_password(SERVICE, _account(workspace, tracker_id, key))
        except Exception as exc:
            raise KeychainUnavailable(str(exc)) from exc
        out[key] = val or ""
    return out


def purge_tracker(workspace: str, tracker_id: str, keys: Iterable[str]) -> None:
    for key in keys:
        try:
            keyring.delete_password(SERVICE, _account(workspace, tracker_id, key))
        except Exception:
            # delete is best-effort; the entry may already be gone.
            continue


def purge_workspace(workspace: str, trackers: Iterable[tuple[str, Iterable[str]]]) -> None:
    for tracker_id, keys in trackers:
        purge_tracker(workspace, tracker_id, keys)
