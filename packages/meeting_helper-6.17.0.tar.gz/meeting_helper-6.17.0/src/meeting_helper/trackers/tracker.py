"""Vendor-agnostic facade over an MCP ClientSession + VendorProfile."""
from __future__ import annotations

import asyncio
import logging
from contextlib import AsyncExitStack, asynccontextmanager
from typing import Any, Optional

from meeting_helper.trackers.profile import (
    CAP_LIST_WORKSPACES,
    CapabilityNotSupported, VendorProfile, Workspace,
)

logger = logging.getLogger(__name__)


class InteractiveOAuthRequired(Exception):
    """The tracker would need to open a browser to authorize, but the caller
    explicitly asked for a non-interactive session (workspace switch pre-warm,
    chat passthrough build, Test connection button). Surface this back to the
    UI as a "re-authenticate this tracker" prompt instead of silently popping
    a browser window the user didn't ask for.
    """


class Tracker:
    """Facade over a VendorProfile + live MCP session.

    Lifecycle: lazy-spawned MCP subprocess; closed via `close(timeout)`
    which waits on `_in_flight` first. Caches `list_workspaces` for the
    object's lifetime (a tracker is replaced wholesale on swap, so a
    long-lived cache is correct).
    """

    def __init__(
        self,
        *,
        profile: VendorProfile,
        transport: dict,
        oauth_workspace: str = "",
        oauth_tracker_id: str = "",
        interactive_oauth: bool = True,
    ) -> None:
        self._profile = profile
        self._transport = transport
        self._oauth_workspace = oauth_workspace
        self._oauth_tracker_id = oauth_tracker_id
        # When False, the OAuth provider raises InteractiveOAuthRequired
        # instead of opening a browser if the SDK would otherwise need a
        # full re-auth. Background paths (pre-warm, chat passthrough, Test
        # button) use this so the user is never surprised by a browser tab.
        # Only the explicit Connect button uses interactive_oauth=True.
        self._interactive_oauth = interactive_oauth
        self._callback_server = None
        self._stack: Optional[AsyncExitStack] = None
        self._session: Any = None
        self._lock = asyncio.Lock()
        self._in_flight = 0
        self._idle = asyncio.Event()
        self._idle.set()
        self._closing = False
        self._cached_workspaces: list[Workspace] | None = None
        # Side-channel signal for the passive `_redirect` handler. When the
        # SDK's OAuth flow reaches the redirect step in non-interactive mode,
        # we set this flag BEFORE raising `InteractiveOAuthRequired` so the
        # caller can detect the need-to-reauth condition even if the raise
        # itself gets lost in anyio's cross-task cancel-scope cleanup (which
        # otherwise orphans the OAuth task and hangs the awaiting code).
        self._needs_reauth_signaled = False

    # ---- Lifecycle -------------------------------------------------------

    async def _ensure_started_locked(self) -> None:
        """Same logic as _ensure_started but assumes caller holds self._lock."""
        if self._session is not None:
            return
        # Fast-fail when a previous attempt already determined this tracker
        # needs interactive OAuth re-auth. The MCP SDK's anyio TaskGroup
        # cannot cleanly unwind a raised `InteractiveOAuthRequired` (cross-
        # task cancel-scope error), so re-entering the SDK chain each time
        # would HANG the awaiting code. Short-circuit BEFORE any anyio
        # context to keep subsequent fetches snappy. The flag is cleared by
        # `reboot_active_tracker` after a successful Connect, so this path
        # only fires for trackers we know are currently broken.
        if (not self._interactive_oauth) and self._needs_reauth_signaled:
            raise InteractiveOAuthRequired(
                f"OAuth re-auth needed for tracker "
                f"{self._oauth_tracker_id} (workspace "
                f"{self._oauth_workspace}); flagged by a previous attempt — "
                f"skipping SDK round-trip to avoid the cross-task cleanup hang."
            )
        if (getattr(self._profile, "auth_mode", "manual") == "mcp_oauth"
                and (not self._oauth_workspace or not self._oauth_tracker_id)):
            raise ValueError(
                "Tracker with auth_mode='mcp_oauth' requires oauth_workspace + oauth_tracker_id"
            )
        from mcp.client.session import ClientSession
        stack = AsyncExitStack()
        try:
            if self._transport["type"] == "stdio":
                from mcp.client.stdio import StdioServerParameters, stdio_client
                params = StdioServerParameters(
                    command=self._transport["command"],
                    args=list(self._transport.get("args") or []),
                    env=dict(self._transport.get("env") or {}) or None,
                )
                read, write = await stack.enter_async_context(stdio_client(params))
            else:
                headers = dict(self._transport.get("headers") or {}) or None
                url = self._transport["url"]

                auth = None
                if getattr(self._profile, "auth_mode", "manual") == "mcp_oauth":
                    from meeting_helper.trackers.oauth import (
                        build_oauth_provider, LocalCallbackServer, open_browser,
                    )
                    callback_server = LocalCallbackServer()
                    await callback_server.start()
                    self._callback_server = callback_server

                    if self._interactive_oauth:
                        async def _redirect(url: str) -> None:
                            logger.info("OAuth: opening browser to %s", url)
                            open_browser(url)

                        async def _wait_callback() -> tuple[str, str | None]:
                            return await callback_server.wait_for_code(timeout=300.0)
                    else:
                        # Passive mode: the daemon wants to use this tracker
                        # WITHOUT prompting the user. If the SDK reaches a
                        # redirect we abort, surfacing a clean exception to
                        # the caller (pre-warm / chat / test). The caller
                        # broadcasts a "re-authenticate this tracker" event
                        # so the UI can prompt the user explicitly.
                        async def _redirect(url: str) -> None:  # noqa: ARG001
                            # Side-channel signal: set BOTH the per-Tracker
                            # flag AND the global state field, AND schedule
                            # a fire-and-forget broadcast for the UI toast.
                            # Why this layered approach: the SDK's OAuth
                            # flow runs inside anyio's TaskGroup; when we
                            # raise here the group's cross-task cleanup
                            # often deadlocks the awaiting code, and the
                            # raise itself may never propagate up. The
                            # side-channel state IS the signal the UI sees;
                            # the raise is for the SDK to short-circuit.
                            #
                            # Critically: the broadcast is scheduled via
                            # `create_task` (fire-and-forget), NOT awaited
                            # — awaiting inside an OAuth redirect callback
                            # can interact poorly with the SDK's await
                            # chain and contribute to the hang. The toast
                            # lands a few ms after the raise either way.
                            self._needs_reauth_signaled = True
                            logger.warning(
                                "Tracker %s (workspace %s) needs interactive "
                                "OAuth re-auth — passive session refused to "
                                "open browser",
                                self._oauth_tracker_id,
                                self._oauth_workspace,
                            )
                            tid = self._oauth_tracker_id
                            try:
                                from meeting_helper.state import state as _state
                                _state.tracker_needs_reauth = tid or "unknown"
                            except Exception:
                                pass
                            try:
                                from meeting_helper.server.websocket import broadcast
                                asyncio.create_task(broadcast({
                                    "type": "tracker_chat_unreachable",
                                    "trackers": [{
                                        "tracker_id": tid,
                                        "label": tid or "this tracker",
                                        "error": "needs re-authentication (click Connect in Settings → Task tracker)",
                                    }],
                                }))
                            except Exception:
                                pass
                            raise InteractiveOAuthRequired(
                                f"OAuth re-auth needed for tracker "
                                f"{self._oauth_tracker_id} (workspace "
                                f"{self._oauth_workspace}); skipped because "
                                f"this session was opened non-interactively."
                            )

                        async def _wait_callback() -> tuple[str, str | None]:
                            # Defense in depth — if a redirect handler other
                            # than ours runs anyway, don't hang 300s.
                            self._needs_reauth_signaled = True
                            raise InteractiveOAuthRequired(
                                "Non-interactive OAuth session reached "
                                "callback wait — refusing to block."
                            )

                    auth = build_oauth_provider(
                        server_url=url,
                        workspace=self._oauth_workspace,
                        tracker_id=self._oauth_tracker_id,
                        callback_url=callback_server.redirect_url,
                        redirect_handler=_redirect,
                        callback_handler=_wait_callback,
                    )

                # Pick the right MCP HTTP transport from the URL shape.
                # Atlassian, Linear, and similar vendors expose Server-Sent
                # Events endpoints at /sse and silently terminate sessions
                # if you connect with streamable_http. Notion, GitHub, and
                # the modern spec use /mcp with streamable_http. Detect by
                # URL suffix — last path segment == "sse" → SSE transport.
                from urllib.parse import urlparse
                last_segment = urlparse(url).path.rstrip("/").rsplit("/", 1)[-1].lower()
                if last_segment == "sse":
                    from mcp.client.sse import sse_client
                    logger.info("Tracker: using SSE transport for %s", url)
                    read, write = await stack.enter_async_context(
                        sse_client(url, headers=headers, auth=auth)
                    )
                else:
                    from mcp.client.streamable_http import streamablehttp_client
                    logger.info("Tracker: using streamable_http transport for %s", url)
                    read, write, _ = await stack.enter_async_context(
                        streamablehttp_client(url, headers=headers, auth=auth)
                    )
            session = await stack.enter_async_context(ClientSession(read, write))
            await session.initialize()
            self._stack = stack
            self._session = session
        except Exception:
            await stack.aclose()
            # Make sure the local OAuth callback server doesn't leak its
            # socket when start-up bails mid-flight (e.g. passive-OAuth
            # InteractiveOAuthRequired before we ever reach session.init).
            if self._callback_server is not None:
                try:
                    await self._callback_server.stop()
                except Exception:
                    pass
                self._callback_server = None
            raise

    async def _ensure_started(self) -> None:
        async with self._lock:
            await self._ensure_started_locked()

    async def close(self, *, timeout: float = 5.0) -> None:
        """Drain in-flight, refuse new borrows, then close the session."""
        async with self._lock:
            self._closing = True
        try:
            await asyncio.wait_for(self._idle.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            logger.warning(
                "tracker.close: in-flight calls did not drain in %.1fs — forcing", timeout,
            )
        async with self._lock:
            if self._stack is not None:
                try:
                    await self._stack.aclose()
                except Exception as exc:
                    logger.warning("tracker.close: stack.aclose raised: %s", exc)
            self._stack = None
            self._session = None
            if getattr(self, "_callback_server", None) is not None:
                try:
                    await self._callback_server.stop()
                except Exception:
                    pass
                self._callback_server = None

    @asynccontextmanager
    async def _borrow(self):
        async with self._lock:
            if self._closing:
                raise RuntimeError("tracker is closing")
            await self._ensure_started_locked()
            self._in_flight += 1
            self._idle.clear()
            session = self._session
        try:
            yield session
        finally:
            async with self._lock:
                self._in_flight -= 1
                if self._in_flight == 0:
                    self._idle.set()

    # ---- Capability checks ----------------------------------------------

    def supports(self, capability: str) -> bool:
        return capability in self._profile.supports

    def _require(self, capability: str) -> None:
        if capability not in self._profile.supports:
            raise CapabilityNotSupported(f"{self._profile.id} does not support {capability}")

    # ---- Vendor-agnostic methods ----------------------------------------

    async def list_workspaces(self) -> list[Workspace]:
        self._require(CAP_LIST_WORKSPACES)
        if self._cached_workspaces is not None:
            return self._cached_workspaces
        async with self._borrow() as session:
            out = await self._profile.list_workspaces(session)
        self._cached_workspaces = out
        return out

    async def call_tool(self, name: str, args: dict | None = None) -> Any:
        """Raw passthrough — used by chat/mcp_passthrough."""
        async with self._borrow() as session:
            result = await session.call_tool(name, args or {})
        from meeting_helper.trackers.vendors.local_todo import _parse
        return _parse(result)

    # ---- Profile / vendor introspection ---------------------------------

    @property
    def vendor_id(self) -> str:
        return self._profile.id

    @property
    def profile(self) -> VendorProfile:
        return self._profile
