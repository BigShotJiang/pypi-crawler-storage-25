"""VendorProfile protocol and normalized output dataclasses."""
from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import (
    Any, ClassVar, Literal, Mapping, Protocol, runtime_checkable,
)


class CapabilityNotSupported(Exception):
    """Raised by a profile when it cannot fulfill a capability for this vendor."""


@dataclass(frozen=True)
class AuthField:
    key: str
    label: str  # i18n key, not literal text
    kind: Literal["text", "password", "url", "textarea", "headers", "env"]
    placeholder: str = ""
    required: bool = True
    secret: bool = False  # True → stored in keychain


@dataclass(frozen=True)
class TransportTemplate:
    type: Literal["stdio", "http"]
    command: str = ""
    args: tuple[str, ...] = ()
    env_template: Mapping[str, str] = field(default_factory=lambda: MappingProxyType({}))
    url_template: str = ""
    headers_template: Mapping[str, str] = field(default_factory=lambda: MappingProxyType({}))


@dataclass(frozen=True)
class Workspace:
    id: str
    name: str
    permission: Literal["read", "write", "none"]


@dataclass(frozen=True)
class Task:
    id: str
    title: str
    status: str
    status_kind: Literal["todo", "in_progress", "done"]
    priority: str | None
    body_md: str
    workspace_id: str
    workspace_name: str
    sprint_name: str
    url: str | None


@dataclass(frozen=True)
class TaskFull(Task):
    subtasks: list[Task] = field(default_factory=list)
    subtasks_summary: dict = field(default_factory=dict)
    recent_comments: list[dict] = field(default_factory=list)
    recent_history: list[dict] = field(default_factory=list)
    linked_docs: list[dict] = field(default_factory=list)


@dataclass(frozen=True)
class Column:
    key: str
    name: str
    kind: Literal["todo", "in_progress", "done"]
    position: int
    color: str | None = None


@dataclass(frozen=True)
class SearchHit:
    kind: Literal["task", "doc"]
    workspace_id: str
    workspace_name: str
    record: dict  # vendor-raw, opaque to callers


# Capability names. Profiles list which they support via `supports`.
CAP_LIST_WORKSPACES = "list_workspaces"
ALL_CAPABILITIES: frozenset[str] = frozenset({CAP_LIST_WORKSPACES})


@runtime_checkable
class VendorProfile(Protocol):
    """Per-vendor adapter.

    Implementations are plain Python classes with no required ``__init__``
    arguments — they're stateless and instantiated once by the registry.
    """
    id: ClassVar[str]
    label: ClassVar[str]
    auth_form: ClassVar[tuple[AuthField, ...]]
    transport: ClassVar[TransportTemplate]
    supports: ClassVar[frozenset[str]]
    auth_mode: ClassVar[Literal["manual", "mcp_oauth", "none"]]
    default_url: ClassVar[str]
    agent_terminology: ClassVar[str]
    agent_hints: ClassVar[str]

