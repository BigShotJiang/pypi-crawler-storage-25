"""Vendor-agnostic task-tracker abstraction.

See docs/superpowers/specs/2026-05-16-tracker-vendor-abstraction-design.md.
"""
