"""AI client: real-time queries (Claude or Ollama), post-meeting transcription & summarization."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig
    from meeting_helper.state import AppState

logger = logging.getLogger(__name__)


_SPRINT_REFRESH_INTERVAL_SEC = 5 * 60.0


async def refresh_sprint_tickets(state: "AppState", force: bool = False) -> None:
    """Refresh `state.sprint_tickets` via the agent-driven fetch.

    No-op if no tracker is connected. Cached for ~5 minutes (or force=True).

    Workspace-boundary guard: snapshots `state.tracker` at entry and discards
    results if the tracker (or active workspace's tracker_id) changes during
    the fetch. Without this, a rapid workspace switch mid-fetch would write
    the prior workspace's tickets — and any agent-learned memory entries —
    into the current workspace's disk JSON, leaking data across workspaces.

    Single-flight: if a fetch is already in progress, concurrent callers
    await the in-flight task rather than starting a second ~44s fetch.
    """
    if getattr(state, "tracker", None) is None:
        return
    if (not force and state.sprint_tickets and
            (time.time() - state.sprint_tickets_loaded_at) < _SPRINT_REFRESH_INTERVAL_SEC):
        return

    # Single-flight gate. Between the check and the assignment there are no
    # await points, so Python's single-threaded asyncio model makes this
    # check-then-set atomic: a concurrent caller arriving after this point
    # will see `sprint_tickets_inflight` set and await the in-flight task.
    inflight = getattr(state, "sprint_tickets_inflight", None)
    current = asyncio.current_task()
    if inflight is not None and not inflight.done() and inflight is not current:
        try:
            await inflight
        except Exception:
            # The in-flight task already logged its own failure. Don't
            # re-raise — the awaiter just wanted fresh-or-shared data.
            pass
        return
    state.sprint_tickets_inflight = current
    try:
        await _refresh_sprint_tickets_inner(state)
    finally:
        if state.sprint_tickets_inflight is current:
            state.sprint_tickets_inflight = None


async def _refresh_sprint_tickets_inner(state: "AppState") -> None:
    """Actual fetch body — invoked under the single-flight gate."""
    # Top-level timing — we log a single TOTAL ms line at the end so the
    # operator can answer "how long did Topics refresh actually take?"
    # without summing per-cycle agent_loop lines.
    refresh_t0 = time.monotonic()

    # Snapshot the workspace identity at the START of the fetch. If anything
    # changes (different tracker object, different workspace JSON path), we
    # discard the result rather than writing to whichever workspace happened
    # to win the race.
    tracker_snapshot = state.tracker
    from meeting_helper.config import get_config
    disk_snapshot = None
    try:
        disk_snapshot = get_config()
    except Exception:
        pass
    workspace_snapshot = getattr(disk_snapshot, "workspace_name", "") if disk_snapshot is not None else ""

    # Broadcast that a refresh is in flight so the UI can show a spinner.
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({"type": "topic_refresh", "status": "running"})
    except Exception:
        pass

    from meeting_helper.ai.agent_fetch import fetch_active_topics
    try:
        config = disk_snapshot.to_app_config() if disk_snapshot is not None else None
        items = await fetch_active_topics(
            tracker=tracker_snapshot,
            config=config,
            disk=disk_snapshot,
            workspace_name=workspace_snapshot,
        )
    except asyncio.CancelledError:
        # Workspace switch cancelled this pre-warm — exit cleanly, don't write.
        raise
    except (Exception, BaseExceptionGroup) as exc:
        # See ai/agent_fetch.py for why BaseExceptionGroup is included:
        # anyio's TaskGroup wraps MCP-time exceptions (including OAuth's
        # InteractiveOAuthRequired) in a BaseExceptionGroup that does NOT
        # inherit from Exception. Without this branch, an OAuth failure
        # would escape past the cross-workspace guard below, the "done"
        # broadcast would never fire, and the UI spinner would spin forever.
        logger.warning("sprint cache refresh failed: %s", exc)
        items = []

    # Cross-workspace guard: if the workspace switched mid-fetch, drop the
    # result on the floor rather than poisoning state with foreign data.
    current_disk = None
    try:
        current_disk = get_config()
    except Exception:
        pass
    current_workspace = getattr(current_disk, "workspace_name", "") if current_disk is not None else ""
    if (
        state.tracker is not tracker_snapshot
        or current_workspace != workspace_snapshot
    ):
        logger.info(
            "refresh_sprint_tickets: workspace switched mid-fetch "
            "(was=%r → now=%r); discarding %d items",
            workspace_snapshot, current_workspace, len(items),
        )
        return

    state.sprint_tickets = items
    state.sprint_tickets_loaded_at = time.time()
    logger.info(
        "Sprint cache refreshed via agent (%d items) — refresh_sprint_tickets TOTAL %dms",
        len(items), int((time.monotonic() - refresh_t0) * 1000),
    )

    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({
            "type": "topic_refresh",
            "status": "done",
            "count": len(items),
        })
    except Exception:
        pass


async def _hydrate_ticket(state: "AppState", picked: dict) -> dict:
    """Return the picked ticket dict.

    The agent fetch already returns items with body_md/subtasks/comments,
    so most of the time hydration is just identity. If the picked item is
    missing details (legacy code path), return as-is.
    """
    return picked


async def pick_topic_ticket(
    state: "AppState",
    config: "AppConfig",
    question: str = "",
    *,
    previous_topic: dict | None = None,
) -> dict | None:
    """Ask the LLM to pick which sprint ticket the meeting is currently
    about, from `state.sprint_tickets` + the recent transcript. Returns the
    picked ticket HYDRATED with body + comments via local-todo `get_task`.

    Why LLM-pick from a finite list instead of free-form extraction or
    keyword search: the constrained list eliminates hallucination, and the
    LLM understands semantic equivalence ("tribute remapper" / "the
    remapper" → ENGT-4147 about remapper) which keyword search misses.
    """
    from meeting_helper.ai.prompts import (
        TICKET_PICKER_SYSTEM_PROMPT,
        build_ticket_picker_user_message,
    )

    if not state.sprint_tickets:
        return None

    # Build the labeled transcript window for background context. The typed
    # question is passed in its OWN block on the picker prompt — mixing it
    # into the transcript as another `[me]` line caused the picker to drift
    # onto whatever the transcript was discussing rather than honoring the
    # follow-up rule.
    timestamped = _collect_timestamped_sentences(state, n_per_buffer=8)
    labeled: list[tuple[str, str]] = [(role, txt) for _ts, role, txt in timestamped]
    # An empty transcript is fine when there is a typed question — the picker
    # can still decide off question + previous_topic + available tickets.
    if not labeled and not question:
        return None

    # build_ticket_picker_user_message expects dicts with "id"/"title" keys.
    # sprint_tickets may be Task dataclasses (new path) or dicts (legacy).
    tickets_for_prompt = [
        {"id": getattr(t, "id", None) or (t.get("id") if isinstance(t, dict) else None),
         "title": getattr(t, "title", None) or (t.get("title", "") if isinstance(t, dict) else "")}
        for t in state.sprint_tickets
    ]
    # Pass the previously picked topic so the picker can detect a follow-up
    # ("what are the consequences?" / "why is that?" / "tell me more") and
    # keep the prior ticket instead of re-anchoring onto a different recent
    # transcript line. The LLM judges this — no brittle keyword list here.
    #
    # Callers choose the anchor:
    #  - user-query path (`_pre_flight_topic_refresh`) passes
    #    `state.last_user_query_topic` so follow-ups anchor on the previous
    #    USER question's pick.
    #  - auto-worker path (`TopicWorker`, question="") MUST NOT feed back
    #    its previous pick — the prompt's Step 3 explicitly forbids using
    #    `previous_topic` for auto-picks, and providing it creates a
    #    self-reinforcing loop where a wrong first tick locks in (the wrong
    #    pick becomes "previous", Haiku anchors on it, the right answer
    #    can't surface even after the user clearly shifts topics).
    if question:
        prev = previous_topic if previous_topic is not None else (state.current_topic or {})
    else:
        # Auto-pick path. Don't pass any prior anchor.
        prev = previous_topic if previous_topic is not None else {}
    prev_ticket_id = ""
    prev_ids = prev.get("ticket_ids") or []
    if prev_ids:
        prev_ticket_id = str(prev_ids[0])
    prev_topic_title = prev.get("topic") or ""

    user_msg = build_ticket_picker_user_message(
        sprint_tickets=tickets_for_prompt,
        labeled_sentences=labeled,
        previous_ticket_id=prev_ticket_id,
        previous_topic_title=prev_topic_title,
        user_question=question,
    )

    logger.info(
        "picker call: question=%r prev_ticket=%r prev_title=%r candidates=%d",
        (question or "")[:80], prev_ticket_id, prev_topic_title[:60],
        len(tickets_for_prompt),
    )

    pick_t0 = time.monotonic()
    try:
        raw = await _call_ai_for_tasks(
            config, TICKET_PICKER_SYSTEM_PROMPT, user_msg, kind="topic-pick"
        )
    except Exception as exc:
        logger.warning("ticket picker LLM call failed after %dms: %s",
                       int((time.monotonic() - pick_t0) * 1000), exc)
        return None
    pick_ms = int((time.monotonic() - pick_t0) * 1000)

    # Parse JSON (may be wrapped in markdown fences from a chatty model)
    try:
        match = re.search(r"\{.*?\}", raw, re.DOTALL)
        data = json.loads(match.group(0)) if match else json.loads(raw)
    except Exception as exc:
        logger.warning("ticket picker returned non-JSON: %s — %r", exc, raw[:200])
        return None

    picked_id = data.get("ticket_id")
    logger.info(
        "picker result: picked_id=%r (prev was %r) — llm=%dms",
        picked_id, prev_ticket_id, pick_ms,
    )
    if not picked_id:
        return None
    # Find the matching record in our sprint cache. The agent-driven fetch
    # (Phase B) already returns enriched items (body_md, subtasks, recent
    # comments) so we preserve ALL fields here — slimming the dict drops
    # the body and the Copilot AI then has no real content to ground on,
    # which manifests as the assistant giving the same generic answer no
    # matter what topic was picked.
    for t in state.sprint_tickets:
        tid = getattr(t, "id", None) or (t.get("id") if isinstance(t, dict) else None)
        if str(tid) == str(picked_id):
            if isinstance(t, dict):
                out = dict(t)
            else:
                out = {k: v for k, v in t.__dict__.items() if not k.startswith("_")}
            out["_llm_topic"] = data.get("topic", "") or ""
            # _hydrate_ticket is now a passthrough (agent-driven fetch
            # already enriches) but kept in the chain in case a future
            # vendor needs lazy hydration.
            return await _hydrate_ticket(state, out)
    return None


async def pick_topic_from_candidates(
    state, config, candidates: list[dict],
) -> dict | None:
    """Choose one candidate from a heterogeneous basket using buffer context.

    Mirrors pick_topic_ticket but accepts {kind, id, title, body?,
    description?} entries from the pinned-topic basket. Returns the matched
    candidate dict or None when the LLM is unsure or the call fails.
    """
    if not candidates:
        return None

    def _snippet(text: str, limit: int = 1200) -> str:
        text = (text or "").strip()
        if len(text) <= limit:
            return text
        return text[:limit] + " ..."

    listing_lines: list[str] = []
    for i, c in enumerate(candidates, start=1):
        kind = c.get("kind", "ticket")
        title = c.get("title") or "(untitled)"
        extra = ""
        if kind == "note":
            extra = f"  note body: {_snippet(c.get('body', ''))}"
        elif kind == "action_item":
            extra = (
                f"  action item: "
                f"{_snippet(c.get('description', ''), limit=400)}"
            )
        listing_lines.append(f"{i}. [{kind}] {title}\n{extra}")

    system_prompt = (
        "You are matching an in-progress meeting conversation to one of the "
        "candidates the user explicitly pinned as a topic. Reply with just "
        "the integer index of the best match, or 0 when none clearly fits."
    )
    user_msg = (
        "Conversation buffer:\n"
        + (state.current_topic or {}).get("last_user_statement", "")
        + "\n\nCandidates:\n"
        + "\n".join(listing_lines)
        + "\n\nReply with a single integer (1-N, or 0 when no clear match)."
    )

    try:
        raw = await _call_ai_for_tasks(
            config, system_prompt, user_msg, kind="topic_basket",
        )
    except Exception as exc:
        logger.warning("pick_topic_from_candidates failed: %s", exc)
        return None

    m = re.search(r"\d+", raw or "")
    if not m:
        return None
    idx = int(m.group())
    if idx <= 0 or idx > len(candidates):
        return None
    return candidates[idx - 1]


async def _pre_flight_topic_refresh(
    state: "AppState",
    config: "AppConfig",
    question: str,
) -> None:
    """Pre-flight topic identification via the ticket-picker LLM.

    Runs on every query (typed or hotkey) before the AI prompt is built,
    so the reply is grounded in the right ticket from the first token.

    Skips silently if local-todo isn't connected, the picker can't match,
    OR the user has manually pinned a topic that's still inside its
    pin window (set by POST /topic/set). The manual pin already populated
    state.current_topic_cards with a hydrated card, so we skip the
    LLM round-trip entirely — saves cost AND respects the user's choice.
    """
    if getattr(state, "tracker", None) is None:
        return
    # Honor the pinned-topic basket — without this gate, every /query rewinds
    # the user's pinned selection to whatever the LLM picks from recent
    # transcript. When the basket has any pin, the TopicWorker's basket leg
    # owns topic state; the pre-flight just exits.
    if getattr(state, "pinned_topics", None):
        logger.debug("pre_flight: pinned basket active — skipping LLM pick")
        return
    await refresh_sprint_tickets(state)
    # Anchor on the previous USER query's topic (not on current_topic, which
    # the auto-worker may have drifted to something else between questions).
    picked = await pick_topic_ticket(
        state, config, question=question,
        previous_topic=getattr(state, "last_user_query_topic", None) or {},
    )
    if picked is None:
        return

    # The picked ticket becomes the warm cache. The banner shows its title.
    cards = [picked]
    ticket_ids = [picked.get("id")] if picked.get("id") else []
    topic_str = picked.get("title") or picked.get("_llm_topic") or ""
    if not topic_str and not ticket_ids:
        return

    prev = state.current_topic or {}
    state.current_topic = {
        "topic": topic_str,
        "ticket_ids": ticket_ids,
        "search_query": picked.get("_llm_topic") or topic_str,
        "last_user_statement": prev.get("last_user_statement", ""),
    }
    state.current_topic_cards = cards
    # Record what THIS user-query pick chose so the next user-query's follow-up
    # check sees it (immune to auto-worker drift in between).
    state.last_user_query_topic = {
        "topic": topic_str,
        "ticket_ids": list(ticket_ids),
    }

    # Broadcast so the GUI banner snaps before the AI starts streaming.
    try:
        from meeting_helper.server.websocket import broadcast, slim_card_for_broadcast
        await broadcast({
            "type": "topic",
            "topic": topic_str,
            "ticket_ids": ticket_ids,
            "last_user_statement": prev.get("last_user_statement", ""),
            "cards": [slim_card_for_broadcast(c) for c in cards],
            "hot_moment": {
                "active": state.is_hot_moment(),
                "until_wallclock": state.hot_moment_until_wallclock(),
            },
        })
    except Exception as exc:
        logger.warning("pre-flight topic broadcast failed: %s", exc)


_CARD_BODY_CHAR_LIMIT = 1200
_CARD_COMMENT_CHAR_LIMIT = 600
_CARD_COMMENTS_KEPT = 5


def _summary_output_path(input_path: Path) -> Path:
    """Compute the .summary.txt path for a transcript input.

    Strips compound suffixes (.live.txt, .transcript.txt) before appending
    .summary.txt. Falls back to Path.with_suffix for anything else.
    """
    name = input_path.name
    for suffix in (".live.txt", ".transcript.txt"):
        if name.endswith(suffix):
            return input_path.with_name(name[: -len(suffix)] + ".summary.txt")
    return input_path.with_suffix(".summary.txt")


def _truncate(text: str, limit: int) -> str:
    """Trim ``text`` to ``limit`` chars, appending ``…`` when cut."""
    text = (text or "").strip()
    if not text:
        return ""
    return text if len(text) <= limit else text[:limit].rstrip() + "…"


def _lookup_action_item_for_pin(config, action_item_id: str) -> dict | None:
    """Resolve a pinned action-item id back to its store row.

    Returns None on any failure (no workspace, missing store, exception)
    so the markdown renderer falls back to the pinned title.
    """
    try:
        from pathlib import Path
        from meeting_helper.action_items import store as ai_store
        from meeting_helper.config import workspace_path

        ws_name = getattr(config, "workspace_name", "") or ""
        if not ws_name:
            return None
        ws_json = workspace_path(ws_name)
        for it in ai_store.list_all(ws_json, Path(config.recordings_dir)):
            if it.get("id") == action_item_id:
                return it
    except Exception:
        return None
    return None


def _format_pinned_topics_markdown(config) -> str:
    """Render state.pinned_topics as a `Pinned topics` markdown block.

    Returns "" when the basket is empty. Notes inline their full body
    (indented two spaces). Action items render title + description and are
    gated on `action_items_inject_into_copilot`. Tickets prefer the cached
    sprint card description, falling back to title + id only.
    """
    from pathlib import Path
    from meeting_helper.state import state as _state

    pins = list(_state.pinned_topics)
    if not pins:
        return ""

    lines: list[str] = ["## \U0001F4CC Pinned topics"]
    inject_ai = bool(
        getattr(config, "action_items_inject_into_copilot", True),
    )

    for p in pins:
        if p.kind == "ticket":
            card = None
            cache = getattr(_state, "sprint_tickets", None) or []
            for c in cache:
                cid = (
                    c.get("id") if isinstance(c, dict)
                    else getattr(c, "id", None)
                )
                if str(cid) == str(p.id):
                    card = c if isinstance(c, dict) else {
                        k: v for k, v in c.__dict__.items()
                        if not k.startswith("_")
                    }
                    break
            label = f"[ticket {p.id}] {p.title}"
            lines.append(f"- {label}")
            if card:
                desc = str(
                    card.get("description")
                    or card.get("body_md")
                    or card.get("body")
                    or "",
                ).strip()
                if desc:
                    lines.append(f"  {desc}")
        elif p.kind == "note":
            lines.append(f"- [note] {p.title}")
            note_filename = (
                p.id if p.id.endswith(".note.md") else f"{p.id}.note.md"
            )
            try:
                body = (
                    Path(config.recordings_dir) / note_filename
                ).read_text(errors="ignore")
                if body.strip():
                    indented = "\n".join(
                        "  " + line for line in body.splitlines()
                    )
                    lines.append(indented)
            except OSError as exc:
                logger.warning(
                    "pinned note body read failed for %s: %s",
                    note_filename, exc,
                )
        elif p.kind == "action_item":
            if not inject_ai:
                lines.append(f"- [action item] {p.title}")
                continue
            it = _lookup_action_item_for_pin(config, p.id)
            title = (it.get("title") if it else p.title) or p.title
            desc = (it.get("description") if it else "") or ""
            lines.append(f"- [action item] {title}")
            if desc.strip():
                lines.append(f"  {desc.strip()}")
        elif p.kind == "repo":
            snap = _state.repo_diffs.get(p.id)
            if not snap:
                lines.append(f"- [repo] {p.title} (not loaded yet)")
                continue
            lines.append(
                f"- [repo] {p.title} ({snap.get('branch', '?')}@{snap.get('head_sha', '?')})"
            )
            stat = (snap.get("stat") or "").strip()
            if stat:
                lines.append("  Changed files:")
                for ln in stat.splitlines():
                    lines.append(f"  {ln}")
            body = (snap.get("body") or "").strip()
            if body:
                lines.append("  Diff:")
                for ln in body.splitlines():
                    lines.append(f"  {ln}")

    return "\n".join(lines) + "\n\n"


def _format_cards_markdown(cards: list[dict]) -> str:
    """Render local-todo records as a Markdown block for the system prompt.

    Includes title, status/sprint/due meta, body (up to ~1200 chars), and
    the last few comments (up to ~600 chars each). Hydrated cards from
    ``get_task`` have all of this; thin cards from ``search_tasks`` only get
    the title + meta line. Empty input returns an empty string.
    """
    if not cards:
        return ""
    lines: list[str] = []
    for c in cards:
        cid = c.get("id", "?")
        title = c.get("title", "(untitled)")
        meta_parts: list[str] = []
        if c.get("status"):
            meta_parts.append(c["status"])
        if c.get("priority"):
            meta_parts.append(f"P:{c['priority']}")
        if c.get("sprint_name") or c.get("sprint"):
            meta_parts.append(f"Sprint {c.get('sprint_name') or c['sprint']}")
        if c.get("due"):
            meta_parts.append(f"Due {c['due']}")
        if c.get("updated_at"):
            meta_parts.append(f"Updated {c['updated_at']}")
        meta = " · ".join(meta_parts) if meta_parts else ""
        head = f"- [{cid}] {title}"
        if meta:
            head += f" — {meta}"
        lines.append(head)

        # Body — try body_md first (hydrated), then body / description (thin).
        body = c.get("body_md") or c.get("body") or c.get("description")
        body_snippet = _truncate(body or "", _CARD_BODY_CHAR_LIMIT)
        if body_snippet:
            # Keep newlines so markdown structure inside the body survives —
            # indented two spaces so it's clear it belongs to the card.
            lines.append("  Body:")
            for body_line in body_snippet.split("\n"):
                lines.append(f"  {body_line}")

        # Comments — most recent first. Hydrated cards have a list; thin
        # cards don't have the field.
        comments = c.get("comments") or []
        if comments:
            # Sort by created_at descending if present, else preserve order.
            try:
                sorted_comments = sorted(
                    comments,
                    key=lambda x: x.get("created_at") or "",
                    reverse=True,
                )
            except Exception:
                sorted_comments = list(comments)
            kept = sorted_comments[:_CARD_COMMENTS_KEPT]
            lines.append(f"  Recent comments (showing {len(kept)} of {len(comments)}):")
            for cm in kept:
                cm_body = cm.get("body_md") or cm.get("body") or ""
                cm_snippet = _truncate(cm_body, _CARD_COMMENT_CHAR_LIMIT)
                if not cm_snippet:
                    continue
                cm_when = cm.get("created_at") or ""
                cm_who = cm.get("author_user_id") or cm.get("author") or ""
                header_bits = [b for b in (cm_when, cm_who) if b]
                header = f"  - " + (" · ".join(header_bits) if header_bits else "(unknown)")
                lines.append(header)
                for cm_line in cm_snippet.split("\n"):
                    lines.append(f"    {cm_line}")

        # Linked docs — name only, hint that more context exists.
        linked_docs = c.get("linked_docs") or []
        if linked_docs:
            doc_titles = [d.get("title") or d.get("id", "?") for d in linked_docs[:5]]
            lines.append("  Linked docs: " + ", ".join(doc_titles))
    return "\n".join(lines)


def _format_kb_cards_markdown(cards: "list") -> str:
    """Render KB cards (past meeting summaries + notes) as a Markdown block.

    Visually distinct from _format_cards_markdown (local-todo cards) so the
    agent and the user can both tell prior-meeting context apart from
    ticket context.
    """
    if not cards:
        return ""
    lines: list[str] = ["", "### Past meetings and notes (knowledge base)"]
    for c in cards:
        kind_label = "Meeting" if c.kind == "meeting" else "Note"
        head_bits = [kind_label]
        if c.date:
            head_bits.append(c.date)
        head_bits.append(c.title)
        lines.append(f"- **{' · '.join(head_bits)}**")
        # Body is summary text or note text — keep it whole; summaries are
        # already designed to be exhaustive but compact.
        body_lines = (c.body or "").strip().split("\n")
        for body_line in body_lines:
            lines.append(f"  {body_line}")
    return "\n".join(lines)


def slim_kb_card_for_broadcast(card) -> dict:
    """Slim a KbCard down to the wire-shape used by the overlay/dashboard."""
    return {
        "id": card.id,
        "kind": card.kind,
        "title": card.title,
        "date": card.date,
        "score": card.score,
    }


async def _retrieve_and_broadcast_kb_cards(state, config, *, query_text: str) -> str:
    """Retrieve KB cards for the current query, broadcast them, and render markdown.

    Fail-isolation lives inside `retrieve_kb_cards` itself — it always returns a list
    (empty on error) and never raises. Returns the markdown block (empty string when
    no cards were retrieved).
    """
    from meeting_helper.library_retrieval import retrieve_kb_cards
    from meeting_helper.server.websocket import broadcast

    self_text = (
        "\n".join(state.self_buffer.get_last_n(config.sentence_window * 5))
        if state.self_buffer
        else ""
    )
    other_text = (
        "\n".join(state.other_buffer.get_last_n(config.sentence_window * 5))
        if state.other_buffer
        else ""
    )
    kb_cards = await retrieve_kb_cards(
        query_text=query_text,
        self_buffer_text=self_text,
        other_buffer_text=other_text,
        config=config,
    )
    if kb_cards:
        await broadcast(
            {"type": "kb_cards", "items": [slim_kb_card_for_broadcast(c) for c in kb_cards]}
        )
    return _format_kb_cards_markdown(kb_cards)


# ---------------------------------------------------------------------------
# Message assembly
# ---------------------------------------------------------------------------

_QUESTION_WORD_RE = re.compile(r"[A-Za-z]")


def _real_word_count(text: str) -> int:
    """Count whitespace tokens that contain at least one letter."""
    return sum(1 for tok in text.split() if _QUESTION_WORD_RE.search(tok))


def _extract_likely_question(
    timestamped_sentences: list[tuple[float, str, str]],
    cutoff_ts: float = 0.0,
) -> str:
    """Find the LATEST thing the other speaker actually asked or requested.

    ``timestamped_sentences`` is a list of ``(ts, role, text)`` tuples sorted
    chronologically (oldest first). Only sentences with ``ts > cutoff_ts`` are
    considered, which prevents re-extracting a line that already produced an AI
    answer (the previous query stamps the cutoff).

    Returns the most recent line that is EITHER ``?``-terminated OR a
    substantial request (>= 3 real words), walking newest-first. Crucially this
    takes the LATEST such line, not the most recent ``?`` anywhere in the window
    — a fresh non-question request ("walk me through the adapter") must win over
    an older ``?`` still sitting in the buffer, otherwise the answer addresses a
    question from a while ago. Short ``?`` follow-ups ("why?", "and the second
    one?") are kept; bare acknowledgements ("yeah", "sounds good", "got it") are
    skipped so they never get pinned as the question. Returns ``""`` if nothing
    qualifies; ``_assemble_messages`` then substitutes an "answer about the
    topic" fragment.
    """
    fresh = [(ts, txt) for ts, _role, txt in timestamped_sentences if ts > cutoff_ts]
    for _ts, txt in reversed(fresh):
        if txt.rstrip().endswith("?") or _real_word_count(txt) >= 3:
            return txt.strip()
    return ""


def _collect_timestamped_sentences(
    state: "AppState",
    n_per_buffer: int,
) -> list[tuple[float, str, str]]:
    """Read the most recent ``n_per_buffer`` entries from each buffer and
    return a chronological merge as ``[(ts, role, text), ...]``.

    Reads the raw buffers (with timestamps) under their existing locks.
    """
    self_entries: list[tuple[float, str, str]] = []
    other_entries: list[tuple[float, str, str]] = []
    if state.self_buffer is not None:
        with state.self_buffer._lock:  # noqa: SLF001 — no public ts accessor today
            self_entries = [
                (e.timestamp, "self", e.text)
                for e in list(state.self_buffer._sentences)[-n_per_buffer:]
            ]
    if state.other_buffer is not None:
        with state.other_buffer._lock:  # noqa: SLF001
            other_entries = [
                (e.timestamp, "other", e.text)
                for e in list(state.other_buffer._sentences)[-n_per_buffer:]
            ]
    return sorted(self_entries + other_entries, key=lambda t: t[0])


def _assemble_messages(state: "AppState", config: "AppConfig") -> list:
    """Build the messages list with explicit, role-tagged context sections.

    Sections (in order):
      ## Topic just discussed         — from state.current_topic (TopicWorker)
      ## What I just said             — from state.self_buffer
      ## What others just said        — from state.other_buffer
      ## What was just asked          — explicit question (last '?' in either buffer)

    The AI prompt's "answer using these sections" rule pins the model to this
    structure, eliminating "I don't have enough context" responses.
    """
    self_sentences: list[str] = []
    other_sentences: list[str] = []
    if state.self_buffer is not None:
        self_sentences = state.self_buffer.get_last_n(config.sentence_window * 5)
    if state.other_buffer is not None:
        other_sentences = state.other_buffer.get_last_n(config.sentence_window * 5)

    if not self_sentences and not other_sentences:
        content = "No transcript captured yet. The meeting may have just started."
        state.last_query_question = ""
    else:
        # Find the most recent NEW question. Look ONLY at the OTHER speaker's
        # lines: in a meeting the question the user needs answered is what the
        # other party just asked, never the user's own rhetorical "...right?"
        # or a self-question, which used to win simply by being more recent.
        # ``last_query_at`` filters out stale questions that already produced an
        # answer.
        timestamped = _collect_timestamped_sentences(state, n_per_buffer=8)
        other_only = [t for t in timestamped if t[1] == "other"]
        question = _extract_likely_question(other_only, cutoff_ts=state.last_query_at)
        # Expose the resolved question so handle_query can broadcast it and the
        # Copilot can label the answer with "re: <question>".
        state.last_query_question = question
        # Stamp the cursor — anything earlier than now is "already considered"
        # for question extraction. Updated even when no `?` was found, so the
        # next call doesn't keep searching the same window.
        state.last_query_at = time.time()

        topic = state.current_topic or {}
        topic_lines: list[str] = []
        if topic.get("topic"):
            topic_lines.append(f"- Topic: {topic['topic']}")
        if topic.get("ticket_ids"):
            topic_lines.append(f"- Tickets: {', '.join(topic['ticket_ids'])}")
        if topic.get("last_user_statement"):
            topic_lines.append(f'- Last thing I said: "{topic["last_user_statement"]}"')
        topic_block = "\n".join(topic_lines) if topic_lines else "(no topic identified yet)"

        self_block = "\n".join(self_sentences) if self_sentences else "(silent)"
        other_block = "\n".join(other_sentences) if other_sentences else "(silent)"

        content = (
            "## Topic just discussed\n"
            f"{topic_block}\n\n"
            "## What I just said (first person, my own voice)\n"
            f"{self_block}\n\n"
            "## What others just said\n"
            f"{other_block}\n\n"
            "## What was just asked\n"
            f"{question or '(no explicit question — answer about the topic above)'}\n\n"
            "Answer ONLY the question in 'What was just asked' (the latest one). Lead with the answer in ONE sentence. Use `-` bullets with **bold** labels ONLY if it genuinely has multiple distinct parts; otherwise stay one or two sentences. Do not preamble, do not restate the question, do not add status or background nobody asked for. Use the other sections only as background to resolve pronouns and follow-ups. If it is a general or conceptual question, answer directly from what you know with no ticket header. Commit; never ask for clarification."
        )

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    return messages


def _attach_images_to_turn(turn: dict, images_b64: list[str]) -> dict:
    """Return a copy of the user turn with image blocks appended (Anthropic
    shape). No-op (returns the same object) when there are no images.

    The Claude path passes ``messages`` straight to the SDK, which accepts the
    image blocks as-is. The Gemini and OpenAI converters translate them.
    """
    if not images_b64:
        return turn
    text = turn.get("content", "")
    blocks: list[dict] = [
        {"type": "text", "text": text if isinstance(text, str) else ""}
    ]
    for b in images_b64:
        blocks.append({
            "type": "image",
            "source": {"type": "base64", "media_type": "image/jpeg", "data": b},
        })
    return {"role": turn["role"], "content": blocks}


# ---------------------------------------------------------------------------
# Streaming helpers
# ---------------------------------------------------------------------------

async def _broadcast_first_token_latency(t0: float) -> None:
    """Broadcast time-to-first-token (ms) once, right after the first text token.

    `t0` is a `time.monotonic()` reading taken just before the streaming call
    started, so this measures the chosen model's real first-token latency
    (including any provider-side "thinking"), independent of context assembly.
    """
    from meeting_helper.server.websocket import broadcast
    ms = max(0, round((time.monotonic() - t0) * 1000))
    await broadcast({"type": "ai_latency", "first_token_ms": ms})


# ---------------------------------------------------------------------------
# Claude (Anthropic) streaming
# ---------------------------------------------------------------------------

async def _stream_claude_gen(
    state: "AppState", config: "AppConfig", messages: list, system_prompt: str
):
    """Async generator: yields Claude text deltas. Raises on hard error.

    On a context-too-long BadRequestError it trims `state.conversation_history`
    in place and retries once (yielding the retry's deltas).
    No broadcast() calls — callers handle broadcasting.
    """
    import anthropic
    import httpx

    if not config.anthropic_api_key:
        raise RuntimeError("No Anthropic API key configured")

    client = anthropic.AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )

    async def _once(msgs):
        async with client.messages.stream(
            model=config.claude_model,
            max_tokens=config.max_tokens,
            system=system_prompt,
            messages=msgs,
        ) as stream:
            async for text_delta in stream.text_stream:
                if text_delta:
                    yield text_delta

    try:
        async for d in _once(messages):
            yield d
    except anthropic.AuthenticationError as exc:
        raise RuntimeError("Invalid Anthropic API key") from exc
    except anthropic.BadRequestError as exc:
        if "token" not in str(exc).lower():
            raise RuntimeError(f"Claude bad request: {exc}") from exc
        # Context too long — trim history and retry once.
        half = max(2, len(state.conversation_history) // 2)
        logger.warning("Claude context too long — trimming history %d→%d, retrying",
                       len(state.conversation_history), half)
        state.conversation_history = state.conversation_history[half:]
        msgs_retry = list(state.conversation_history) + [messages[-1]]
        async for d in _once(msgs_retry):
            yield d


# ---------------------------------------------------------------------------
# Gemini (Google) streaming
# ---------------------------------------------------------------------------

def _messages_to_gemini_contents(messages: list) -> list:
    """Convert internal message format to Gemini contents list."""
    from google.genai import types

    contents = []
    for msg in messages:
        role = "user" if msg["role"] == "user" else "model"
        text = msg.get("content", "")
        if isinstance(text, str) and text:
            contents.append(types.Content(
                role=role,
                parts=[types.Part.from_text(text=text)],
            ))
        elif isinstance(text, list):
            import base64 as _b64
            parts = []
            for b in text:
                if b.get("type") == "text" and b.get("text"):
                    parts.append(types.Part.from_text(text=b["text"]))
                elif b.get("type") == "image":
                    raw = _b64.b64decode(b["source"]["data"])
                    parts.append(types.Part.from_bytes(
                        data=raw,
                        mime_type=b["source"].get("media_type", "image/jpeg"),
                    ))
            if parts:
                contents.append(types.Content(role=role, parts=parts))
    return contents


async def _stream_gemini_gen(
    state: "AppState", config: "AppConfig", messages: list, system_prompt: str
):
    """Async generator: yields Gemini text deltas. Raises on hard error.
    No broadcast() calls — callers handle broadcasting.
    """
    if not config.google_api_key:
        raise RuntimeError("No Google API key configured")

    from google import genai
    from google.genai import types

    model = config.gemini_model
    client = genai.Client(api_key=config.google_api_key)
    contents = _messages_to_gemini_contents(messages)

    gen_kwargs: dict = dict(system_instruction=system_prompt, max_output_tokens=config.max_tokens)
    # Gemini 3 models "think" before answering, which adds noticeable
    # latency. For a real-time copilot we want the fastest response, so keep
    # the thinking effort minimal.
    if "gemini-3" in model:
        gen_kwargs["thinking_config"] = types.ThinkingConfig(thinking_level="low")

    q: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_event_loop()
    _sentinel = object()

    def _produce():
        try:
            for chunk in client.models.generate_content_stream(
                model=model,
                contents=contents,
                config=types.GenerateContentConfig(**gen_kwargs),
            ):
                text = getattr(chunk, "text", None)
                if text:
                    loop.call_soon_threadsafe(q.put_nowait, text)
        except Exception as exc:  # surface the error to the consumer
            loop.call_soon_threadsafe(q.put_nowait, exc)
        finally:
            loop.call_soon_threadsafe(q.put_nowait, _sentinel)

    task = loop.run_in_executor(None, _produce)
    try:
        while True:
            item = await q.get()
            if item is _sentinel:
                break
            if isinstance(item, Exception):
                raise RuntimeError(f"Gemini error: {item}") from item
            yield item
    finally:
        await task


# ---------------------------------------------------------------------------
# OpenAI (ChatGPT) streaming
# ---------------------------------------------------------------------------

def _openai_messages_from(messages: list, *, system: str) -> list[dict]:
    """Build the OpenAI Chat Completions message list, mapping text and image
    content blocks to OpenAI content parts (text -> text part, image -> an
    image_url data URL). Plain-string content passes through unchanged."""
    out: list[dict] = [{"role": "system", "content": system}]
    for msg in messages:
        role = "user" if msg["role"] == "user" else "assistant"
        content = msg.get("content", "")
        if isinstance(content, str):
            if content:
                out.append({"role": role, "content": content})
            continue
        parts: list[dict] = []
        for b in content:
            if b.get("type") == "text" and b.get("text"):
                parts.append({"type": "text", "text": b["text"]})
            elif b.get("type") == "image":
                data = b["source"]["data"]
                mt = b["source"].get("media_type", "image/jpeg")
                parts.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{mt};base64,{data}"},
                })
        if parts:
            out.append({"role": role, "content": parts})
    return out


async def _stream_openai_gen(
    state: "AppState", config: "AppConfig", messages: list, system_prompt: str
):
    """Async generator: yields OpenAI text deltas. Raises on hard error.
    No broadcast() calls — callers handle broadcasting. No tools in the copilot
    path; uses ``max_completion_tokens`` and no temperature for broad model
    compatibility."""
    if not config.openai_api_key:
        raise RuntimeError("No OpenAI API key configured")

    from openai import AsyncOpenAI

    client = AsyncOpenAI(api_key=config.openai_api_key)
    oai_messages = _openai_messages_from(messages, system=system_prompt)

    stream = await client.chat.completions.create(
        model=config.openai_model,
        messages=oai_messages,
        max_completion_tokens=config.max_tokens,
        stream=True,
    )
    async for chunk in stream:
        choices = getattr(chunk, "choices", None) or []
        if not choices:
            continue
        text = getattr(choices[0].delta, "content", None)
        if text:
            yield text


async def _openai_complete(config: "AppConfig", system: str, user: str, *, max_tokens: int | None = None) -> str:
    """Non-streaming OpenAI chat completion used by the batch tasks (summary,
    speaker labeling, task extraction). Returns the message text."""
    from openai import AsyncOpenAI

    client = AsyncOpenAI(api_key=config.openai_api_key)
    resp = await client.chat.completions.create(
        model=config.openai_model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        max_completion_tokens=max_tokens or config.max_tokens,
    )
    return resp.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# Ollama (local) streaming
# ---------------------------------------------------------------------------

def _ensure_ollama(model: str, host: str = "http://localhost:11434") -> bool:
    """Ensure Ollama is running and the model is available. Returns True if ready."""
    from meeting_helper.ai.ollama_utils import (
        is_ollama_installed, start_ollama, get_installed_models, keep_alive, _is_remote,
    )

    remote = _is_remote(host)

    if not remote and not is_ollama_installed():
        logger.error("Ollama not installed")
        return False

    if not start_ollama(host):
        logger.error("Ollama server failed to start (host=%s)", host)
        return False

    if not remote:
        keep_alive()

    installed = get_installed_models(start_server=True, host=host)
    if model not in installed:
        logger.error("Model %s not available on %s. Download it from Settings.", model, host)
        return False

    return True


def _trim_system_prompt_for_local(system_prompt: str, max_chars: int = 4000) -> str:
    """Trim the system prompt for local models that have smaller context windows.

    Keeps the core instructions and truncates the workspace context block.
    """
    if len(system_prompt) <= max_chars:
        return system_prompt

    # Find the context block separator
    sep = "\n\n---\nThe user's workspace context is below."
    idx = system_prompt.find(sep)
    if idx == -1:
        # No context block — just truncate
        return system_prompt[:max_chars]

    # Keep core prompt + truncated context
    core = system_prompt[:idx]
    context = system_prompt[idx:]
    remaining = max_chars - len(core) - 100  # leave room for truncation notice
    if remaining > 200:
        trimmed_context = context[:remaining] + "\n\n[... context truncated for local model ...]"
        return core + trimmed_context
    else:
        return core


async def _stream_ollama_gen(
    state: "AppState", config: "AppConfig", messages: list, system_prompt: str
):
    """Async generator: yields Ollama text deltas. Raises on hard error.
    No broadcast() calls — callers handle broadcasting.
    """
    model = config.local_model
    host = config.ollama_host
    loop = asyncio.get_event_loop()
    ready = await loop.run_in_executor(None, _ensure_ollama, model, host)
    if not ready:
        raise RuntimeError(f"Ollama not reachable at {host}")
    system_prompt = _trim_system_prompt_for_local(system_prompt)

    ollama_messages = [{"role": "system", "content": system_prompt}]
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, list):
            content = "\n\n".join(b["text"] for b in content if b.get("type") == "text")
        if content:
            ollama_messages.append({"role": msg["role"], "content": content})

    q: asyncio.Queue = asyncio.Queue()
    _sentinel = object()

    def _produce():
        try:
            body = json.dumps(
                {"model": model, "messages": ollama_messages, "stream": True}
            ).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=45) as resp:
                for line in resp:
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    text = chunk.get("message", {}).get("content", "")
                    if text:
                        loop.call_soon_threadsafe(q.put_nowait, text)
        except Exception as exc:
            loop.call_soon_threadsafe(q.put_nowait, exc)
        finally:
            loop.call_soon_threadsafe(q.put_nowait, _sentinel)

    task = loop.run_in_executor(None, _produce)
    try:
        while True:
            item = await q.get()
            if item is _sentinel:
                break
            if isinstance(item, Exception):
                raise RuntimeError(f"Local AI error: {item}") from item
            yield item
    finally:
        await task


# ---------------------------------------------------------------------------
# Provider cascade orchestrator
# ---------------------------------------------------------------------------

# Provider key -> (display label, async-generator factory).
# A generator factory has signature:
#   async def f(state, config, messages, system_prompt) -> AsyncIterator[str]
_PROVIDER_GENERATORS = {
    "anthropic": ("Claude", _stream_claude_gen),
    "google": ("Gemini", _stream_gemini_gen),
    "openai": ("ChatGPT", _stream_openai_gen),
    "local": ("Local", _stream_ollama_gen),
}

# Per-query answer-id prefix. Reusing fixed ids ("A", "B"…) across queries
# meant consecutive turns saw the SAME id ("A" for Q1's primary, "A" for Q2's
# primary), which the Copilot UI matches against to route chunks. Edge cases
# in the React state ordering let chunks from Q2 land into Q1's bubble,
# producing identical-looking responses. We now generate a fresh per-query
# nonce; cascade slots become "<nonce>-0", "<nonce>-1", etc. Unique across
# turns AND across cascade siblings.
import secrets as _secrets
_HARD_CEILING_SEC = 20.0          # no first token from anyone within this → give up


def _fresh_answer_ids(n: int) -> list[str]:
    """Return n unique answer ids for ONE _stream_ai call. n ≤ 8 in practice."""
    nonce = _secrets.token_hex(4)
    return [f"{nonce}-{i}" for i in range(n)]


def _key_available(config: "AppConfig", key: str) -> bool:
    if key == "anthropic":
        return bool(config.anthropic_api_key)
    if key == "google":
        return bool(config.google_api_key)
    if key == "openai":
        return bool(config.openai_api_key)
    if key == "local":
        return True
    return False


def _provider_model(config: "AppConfig", key: str) -> str:
    if key == "anthropic":
        return (getattr(config, "claude_model_alias", "")
                or getattr(config, "claude_model", "") or "claude")
    if key == "google":
        return (getattr(config, "gemini_model_alias", "")
                or getattr(config, "gemini_model", "") or "gemini")
    if key == "openai":
        return getattr(config, "openai_model", "") or "openai"
    if key == "local":
        return getattr(config, "local_model", "") or "local"
    return key


def _vision_provider_order(config: "AppConfig", *, has_images: bool) -> list[str]:
    """Provider keys to attempt this turn. With images present, drop any
    provider whose configured model can't see images (and local, unsupported in
    v1), keeping the original preference order among the survivors. Returns the
    raw order unchanged when there are no images."""
    from meeting_helper.config import model_supports_vision

    base = list(getattr(config, "ai_provider_order", None)
                or ["anthropic", "google", "openai"])
    if not has_images:
        return base
    model_for = {
        "anthropic": getattr(config, "claude_model", ""),
        "google": getattr(config, "gemini_model", ""),
        "openai": getattr(config, "openai_model", ""),
    }
    keep: list[str] = []
    for key in base:
        if key == "local" or not _key_available(config, key):
            continue
        if model_supports_vision(model_for.get(key, "")):
            keep.append(key)
    return keep


async def _drain_answer(state, config, messages, system_prompt, *,
                        answer_id: str, provider_key: str, label: str,
                        first_token_event: "asyncio.Event", results: dict) -> None:
    """Run one provider generator to completion, broadcasting answer_open / chunk /
    done. Records full text + first_token_ms (or error) into `results[answer_id]`.
    Never raises — failures are captured in `results`."""
    from meeting_helper.server.websocket import broadcast
    model = _provider_model(config, provider_key)
    factory = _PROVIDER_GENERATORS[provider_key][1]
    results[answer_id] = {"provider": label.lower(), "model": model, "text": "",
                          "first_token_ms": None, "error": None}
    t0 = time.monotonic()
    opened = False
    try:
        async for delta in factory(state, config, messages, system_prompt):
            if not delta:
                continue
            if not opened:
                opened = True
                await broadcast({"type": "answer_open", "answer_id": answer_id,
                                 "provider": label.lower(), "model": model})
                ms = max(0, round((time.monotonic() - t0) * 1000))
                results[answer_id]["first_token_ms"] = ms
                first_token_event.set()
            results[answer_id]["text"] += delta
            await broadcast({"type": "chunk", "answer_id": answer_id, "text": delta})
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        results[answer_id]["error"] = str(exc)
        logger.warning("answer %s (%s) failed: %s", answer_id, label, exc)
        return
    if opened:
        await broadcast({"type": "done", "answer_id": answer_id,
                         "full_text": results[answer_id]["text"],
                         "first_token_ms": results[answer_id]["first_token_ms"]})


async def _stream_ai(state: "AppState", config: "AppConfig", messages: list,
                     system_prompt: str, *, kind: str = "stream") -> str:
    """Run the configured provider cascade. Returns the canonical (primary) answer
    text — or, if the primary produced nothing, the first answer that did, else ""."""
    from meeting_helper.server.websocket import broadcast
    state.record_ai_call(kind)

    # Resolve participating providers: ai_provider_order filtered by available keys.
    order = [k for k in (getattr(config, "ai_provider_order", None) or ["anthropic", "google"])
             if _key_available(config, k)]
    # When this turn carries image blocks, route to exactly ONE provider: the
    # first vision-capable provider in the user's order (gpt-5.4-nano cannot see
    # images). A blind model must never answer an image turn, and we skip the
    # multi-provider cascade entirely so the single shown answer always comes
    # from a model that can actually read the screenshot. If none qualify we
    # surface a clear error rather than letting a blind model guess.
    has_images = bool(messages) and isinstance(messages[-1].get("content"), list)
    if has_images:
        vorder = _vision_provider_order(config, has_images=True)
        # Surface which providers were skipped for this image (e.g. ChatGPT on
        # gpt-5.4-nano, which can't see images). Without this the drop is silent
        # and the user just thinks "ChatGPT isn't answering my screenshots".
        dropped = [k for k in order if k not in vorder]
        if dropped:
            logger.info(
                "vision turn: skipped non-vision provider(s) %s; routing image to %s",
                ", ".join(f"{_PROVIDER_GENERATORS[k][0]}({_provider_model(config, k)})"
                          for k in dropped),
                vorder[0] if vorder else "(none qualify)",
            )
        if not vorder:
            # No configured+keyed provider can see images. Do not let a blind
            # model guess; tell the user to pick a vision-capable model.
            await broadcast({"type": "error", "message": (
                "The selected model can't read images. Pick a vision-capable "
                "model (gpt-5.4-mini, a Claude, or a Gemini model) in Settings "
                "to ask about screenshots.")})
            return ""
        # Single-provider dispatch for image turns: only the first vision
        # survivor runs, so there is exactly one carousel entry.
        order = vorder[:1]
        try:
            await broadcast({"type": "vision_note",
                             "model": _provider_model(config, order[0]),
                             "dropped": [
                                 {"provider": _PROVIDER_GENERATORS[k][0],
                                  "model": _provider_model(config, k)}
                                 for k in dropped
                             ]})
        except Exception:
            pass
    if not order:
        await broadcast({"type": "error", "message": "No AI provider configured."})
        return ""

    delay_ms = max(0, int(getattr(config, "ai_failover_delay_ms", 2000)))
    first_token_event = asyncio.Event()
    results: dict[str, dict] = {}
    tasks: dict[str, asyncio.Task] = {}
    launched = 0
    # Generate fresh, query-unique answer ids so consecutive turns can't
    # collide via the Copilot UI's answer_id-based chunk routing.
    answer_ids = _fresh_answer_ids(len(order))

    def _launch_next() -> bool:
        nonlocal launched
        if launched >= len(order):
            return False
        key = order[launched]
        aid = answer_ids[launched]
        label = _PROVIDER_GENERATORS[key][0]
        tasks[aid] = asyncio.create_task(_drain_answer(
            state, config, messages, system_prompt,
            answer_id=aid, provider_key=key, label=label,
            first_token_event=first_token_event, results=results))
        launched += 1
        return True

    try:
        _launch_next()  # primary

        # Cascade: keep launching the next provider every `delay_ms` until SOMEONE
        # emits a first token (or every task currently launched has finished, or
        # we hit the hard ceiling). delay_ms == 0 → launch everyone immediately.
        ceiling = time.monotonic() + _HARD_CEILING_SEC
        ev_waiter: asyncio.Task | None = None
        while launched < len(order):
            if delay_ms == 0:
                _launch_next()
                continue
            # Wake as soon as either someone emits a first token OR every
            # currently-launched answer has finished (e.g. the primary errored
            # instantly) — whichever comes first, capped at `delay_ms`.
            if ev_waiter is None or ev_waiter.done():
                ev_waiter = asyncio.create_task(first_token_event.wait())
            pending_answers = [t for t in tasks.values() if not t.done()]
            await asyncio.wait({ev_waiter, *pending_answers},
                               timeout=delay_ms / 1000.0,
                               return_when=asyncio.FIRST_COMPLETED)
            if first_token_event.is_set():
                break  # someone produced a first token — stop cascading
            # If every launched task is already done and none produced a token,
            # launch the next one immediately rather than waiting another window.
            if all(t.done() for t in tasks.values()):
                if not _launch_next():
                    break
                continue
            if time.monotonic() >= ceiling:
                break
            _launch_next()
        if ev_waiter is not None and not ev_waiter.done():
            ev_waiter.cancel()

        # Wait for all launched answers to finish.
        if tasks:
            done, pending = await asyncio.wait(tasks.values(), timeout=_HARD_CEILING_SEC)
            for t in pending:
                t.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
    except asyncio.CancelledError:
        if ev_waiter is not None and not ev_waiter.done():
            ev_waiter.cancel()
        for t in tasks.values():
            t.cancel()
        await asyncio.gather(*tasks.values(), return_exceptions=True)
        raise

    # Canonical answer = primary if it produced text, else first (by launch order)
    # that did.
    primary_aid = answer_ids[0]
    ordered_aids = answer_ids[:launched]
    canonical = ""
    for aid in ordered_aids:
        r = results.get(aid)
        if r and r["text"]:
            canonical = r["text"]
            break

    if not canonical:
        await broadcast({"type": "error", "message": "All AI providers failed or timed out."})
        return ""

    await broadcast({"type": "all_done"})
    return canonical


# ---------------------------------------------------------------------------
# Real-time query (during meeting, hotkey-triggered)
# ---------------------------------------------------------------------------

async def handle_query(state: "AppState", config: "AppConfig") -> None:
    """Assemble context from buffers + warm topic, stream AI response.

    NO per-query LLM extraction or cards search — TopicWorker keeps
    state.current_topic and state.current_topic_cards updated every ~5s.
    """
    from meeting_helper.server.websocket import broadcast, slim_card_for_broadcast

    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()
    state.active_query_started_at = time.time()

    if state.proactive_monitor is not None:
        state.proactive_monitor.notify_manual_query()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    # Pre-flight topic refresh: per-query LLM extraction over the recent
    # buffers, then load the actual ticket from local-todo. Grounds the
    # AI's reply in fresh, ticket-loaded context every single time. Latency
    # cost: one Haiku-style call (~200 ms) + one local-todo search.
    try:
        _failover_ms = int(getattr(config, "ai_failover_delay_ms", 2000))
    except (TypeError, ValueError):
        _failover_ms = 2000
    _preflight_timeout = max(4.0, 2 * _failover_ms / 1000.0)
    try:
        await asyncio.wait_for(
            _pre_flight_topic_refresh(state, config, question=""),
            timeout=_preflight_timeout,
        )
    except asyncio.TimeoutError:
        logger.warning("pre-flight topic refresh timed out after %.1fs — answering with warm cache",
                       _preflight_timeout)
    except Exception as exc:
        logger.warning("pre-flight topic refresh failed: %s — answering with warm cache", exc)

    # Warm reads now reflect the pre-flight refresh.
    cards = list(state.current_topic_cards or [])
    cards_markdown = _format_cards_markdown(cards)
    # Offload: _format_pinned_topics_markdown reads note bodies from disk
    # and walks the action_items store. Keep that work off the asyncio loop
    # so it doesn't stall transcript broadcasts (ticket #25).
    pinned_markdown = await asyncio.to_thread(_format_pinned_topics_markdown, config)
    cards_markdown = pinned_markdown + cards_markdown
    state.last_cards = cards
    if cards:
        await broadcast({"type": "cards", "items": [slim_card_for_broadcast(c) for c in cards]})

    # KB retrieval (past meetings + notes flagged 📚). Fail-isolation lives
    # inside retrieve_kb_cards — it always returns a list, never raises.
    cards_markdown = cards_markdown + await _retrieve_and_broadcast_kb_cards(
        state, config, query_text=""
    )

    messages = _assemble_messages(state, config)
    # Conversation history stores the text-only turn; base64 screenshots are
    # sent to the provider for this turn only (storing them would bloat the
    # history that re-enters every subsequent turn).
    current_user_turn = messages[-1]
    from meeting_helper import screenshot as _ss
    # A capture (Esc+Down) runs in a worker thread; if the user fires the query
    # right after, the screenshot may not have landed in the buffer yet. Wait
    # briefly so it rides in THIS turn alongside the transcript context instead
    # of slipping to the next query.
    _waited = 0.0
    while getattr(state, "pending_screenshot_captures", 0) > 0 and _waited < 3.0:
        await asyncio.sleep(0.05)
        _waited += 0.05
    # PEEK, don't drain: the shots are STICKY so follow-up questions about the
    # same on-screen content reuse them. The vision model decides whether the
    # shot is still relevant (the image-aware prompt tells it to say so if it
    # isn't), so we don't guess at topic matching here. The set is replaced on
    # the next Esc+Down capture (hotkeys) and purged by /screenshot/clear; the
    # temp files therefore are NOT unlinked here.
    _shots = list(state.screenshot_buffer)
    _images_b64: list[str] = []
    for _s in _shots:
        try:
            # Resize + re-encode is CPU work (PIL); keep it off the asyncio
            # loop so it doesn't stall transcript broadcasts mid-query.
            _images_b64.append(await asyncio.to_thread(_ss.encode_b64, _s["path"]))
        except Exception:
            pass
    if _images_b64:
        messages[-1] = _attach_images_to_turn(messages[-1], _images_b64)
        # Mark consumed so the next capture replaces the set. We deliberately do
        # NOT broadcast an empty "screenshots" list: the strip and the overlay
        # badge keep showing the sticky shots until a new capture or a clear.
        state.screenshots_consumed = True

    from meeting_helper.ai.prompts import build_system_prompt
    system_prompt = build_system_prompt(
        context_block="",
        cards_markdown=cards_markdown,
        has_images=bool(_images_b64),
    )

    # Tell the Copilot which question this query is answering, so the answer
    # bubble can show "re: <question>". A hotkey answer has no user bubble in
    # front of it, so without this a slow reply looks like it's answering
    # something from a while ago. Always broadcast — an empty question CLEARS
    # the client's label, so a query with no fresh question can't inherit the
    # previous one's "re: ..." line.
    _q = getattr(state, "last_query_question", "") or ""
    await broadcast({"type": "query_question", "question": _q})

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt, kind="query")

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            logger.info("Query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Query cancelled")
        # The shots were attached but a cancelled query may never have reached a
        # provider. Un-consume them so the sticky set survives (a re-query
        # re-sends it) and the next Esc+Down doesn't purge shots no model saw.
        state.screenshots_consumed = False
        return

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Manual query (user-typed text during meeting)
# ---------------------------------------------------------------------------

async def handle_manual_query(state: "AppState", config: "AppConfig", user_text: str) -> None:
    """Send a user-typed question to AI, with both transcripts + warm topic."""
    from meeting_helper.server.websocket import broadcast, slim_card_for_broadcast

    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()
    state.active_query_started_at = time.time()

    if state.proactive_monitor is not None:
        state.proactive_monitor.notify_manual_query()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    # Pre-flight topic refresh: LLM extraction over the typed question +
    # recent buffers, then load the actual ticket from local-todo. The AI's
    # prompt that follows is grounded in the loaded ticket, not just whatever
    # TopicWorker last cached.
    try:
        _failover_ms = int(getattr(config, "ai_failover_delay_ms", 2000))
    except (TypeError, ValueError):
        _failover_ms = 2000
    _preflight_timeout = max(4.0, 2 * _failover_ms / 1000.0)
    try:
        await asyncio.wait_for(
            _pre_flight_topic_refresh(state, config, question=user_text),
            timeout=_preflight_timeout,
        )
    except asyncio.TimeoutError:
        logger.warning("pre-flight topic refresh timed out after %.1fs — answering with warm cache",
                       _preflight_timeout)
    except Exception as exc:
        logger.warning("pre-flight topic refresh failed: %s — answering with warm cache", exc)

    # Warm cache (now refreshed by pre-flight)
    cards = list(state.current_topic_cards or [])
    cards_markdown = _format_cards_markdown(cards)
    # Offload: _format_pinned_topics_markdown reads note bodies from disk
    # and walks the action_items store. Keep that work off the asyncio loop
    # so it doesn't stall transcript broadcasts (ticket #25).
    pinned_markdown = await asyncio.to_thread(_format_pinned_topics_markdown, config)
    cards_markdown = pinned_markdown + cards_markdown
    state.last_cards = cards
    if cards:
        await broadcast({"type": "cards", "items": [slim_card_for_broadcast(c) for c in cards]})

    # KB retrieval (past meetings + notes flagged 📚). Fail-isolation lives
    # inside retrieve_kb_cards — it always returns a list, never raises.
    cards_markdown = cards_markdown + await _retrieve_and_broadcast_kb_cards(
        state, config, query_text=user_text
    )

    # Build full prompt content with explicit user-typed question
    self_sentences: list[str] = []
    other_sentences: list[str] = []
    if state.self_buffer is not None:
        self_sentences = state.self_buffer.get_last_n(config.sentence_window * 5)
    if state.other_buffer is not None:
        other_sentences = state.other_buffer.get_last_n(config.sentence_window * 5)

    topic = state.current_topic or {}
    topic_lines: list[str] = []
    if topic.get("topic"):
        topic_lines.append(f"- Topic: {topic['topic']}")
    if topic.get("ticket_ids"):
        topic_lines.append(f"- Tickets: {', '.join(topic['ticket_ids'])}")
    if topic.get("last_user_statement"):
        topic_lines.append(f'- Last thing I said: "{topic["last_user_statement"]}"')
    topic_block = "\n".join(topic_lines) if topic_lines else "(no topic identified yet)"

    self_block = "\n".join(self_sentences) if self_sentences else "(silent)"
    other_block = "\n".join(other_sentences) if other_sentences else "(silent)"

    # Stamp the question cursor so the next hotkey press won't re-extract any
    # `?` from the buffer that's older than this typed query.
    state.last_query_at = time.time()

    content = (
        "## Topic just discussed\n"
        f"{topic_block}\n\n"
        "## What I just said (first person)\n"
        f"{self_block}\n\n"
        "## What others just said\n"
        f"{other_block}\n\n"
        "## What was just asked (typed by me)\n"
        f"{user_text}\n\n"
        "Answer the typed question. LEAD with the answer itself, not a status preamble like 'so I'm working on…'. If the answer has several parts (multiple causes, components, items), give a one-sentence lead-in then break the parts out as `-` bullets with **bold** labels; if it's a single point, one short sentence is enough. If it's about the work in the sections above or the loaded tickets, ground it there and resolve any pronouns or vague references from that context; if it's a general or conceptual question, just answer it directly from what you know — no forced ticket connection, no ticket header."
    )

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    current_user_turn = {"role": "user", "content": content}
    from meeting_helper.ai.prompts import build_system_prompt
    system_prompt = build_system_prompt(
        context_block="",
        cards_markdown=cards_markdown,
    )

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt, kind="query-manual")

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            logger.info("Manual query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Manual query cancelled")
        return

    except Exception as exc:
        logger.error("Manual query error: %s", exc, exc_info=True)
        await broadcast({"type": "error", "message": f"Error: {exc}"})

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Proactive query (auto-triggered when a question is detected in transcript)
# ---------------------------------------------------------------------------

async def handle_proactive_query(state: "AppState", config: "AppConfig", question: str) -> None:
    """Auto-triggered query when a question is detected. Same as manual but labeled auto."""
    # NOTE: KB retrieval (past meetings/notes) is intentionally skipped in the
    # proactive path. This handler does not go through build_system_prompt and
    # uses the cached state.system_prompt / config.system_prompt directly to
    # keep auto-detected replies snappy. If KB injection is wanted here too in
    # the future, refactor this handler to use _retrieve_and_broadcast_kb_cards
    # and build_system_prompt like handle_query / handle_manual_query.
    from meeting_helper.server.websocket import broadcast

    # Cancel any in-progress streaming task
    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one (proactive)")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()
    state.active_query_started_at = time.time()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start", "proactive": True, "question": question})

    transcript = ""
    if state.sentence_buffer is not None:
        transcript = state.sentence_buffer.get_last_n_as_text(config.sentence_window * 2)

    if transcript:
        content = f"{question}\n\n---\n## Recent meeting transcript:\n{transcript}"
    else:
        content = question

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    current_user_turn = {"role": "user", "content": content}
    system_prompt = state.system_prompt or config.system_prompt

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt, kind="query-proactive")

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            logger.info("Proactive query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Proactive query cancelled")
        return

    except Exception as exc:
        logger.error("Proactive query error: %s", exc)
        await broadcast({"type": "error", "message": f"Error: {exc}"})

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Post-meeting: transcribe MP3 with faster-whisper
# ---------------------------------------------------------------------------

def transcribe_audio_file(mp3_path: str, config: "AppConfig") -> str:
    """Transcribe an MP3 file using faster-whisper. Returns full transcript text.

    Runs synchronously — caller should wrap in asyncio.to_thread().
    """
    from faster_whisper import WhisperModel

    path = Path(mp3_path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {mp3_path}")

    logger.info("Transcribing %s with faster-whisper...", path.name)
    t0 = time.monotonic()

    from meeting_helper.ssl_fix import patch_ssl
    patch_ssl()

    model = WhisperModel("medium", compute_type="int8")
    segments, info = model.transcribe(
        str(path),
        language=config.transcription_language if config.transcription_language != "auto" else None,
        beam_size=5,
        vad_filter=True,
        condition_on_previous_text=True,
    )

    lines: list[str] = []
    for segment in segments:
        start_m, start_s = divmod(int(segment.start), 60)
        end_m, end_s = divmod(int(segment.end), 60)
        timestamp = f"[{start_m:02d}:{start_s:02d} - {end_m:02d}:{end_s:02d}]"
        lines.append(f"{timestamp} {segment.text.strip()}")

    transcript = "\n".join(lines)
    elapsed = time.monotonic() - t0
    logger.info("Transcription complete: %d segments, %.1fs", len(lines), elapsed)

    # Save alongside the MP3
    out_path = path.with_suffix(".transcript.txt")
    out_path.write_text(transcript)
    logger.info("Transcript saved: %s", out_path.name)

    return transcript


# ---------------------------------------------------------------------------
# Post-meeting: summarize transcript
# ---------------------------------------------------------------------------

async def summarize_transcript(transcript_path: str, config: "AppConfig") -> str:
    """Send a full transcript to the configured AI provider for structured summary."""
    from meeting_helper.ai.prompts import SUMMARIZE_SYSTEM_PROMPT

    path = Path(transcript_path)
    if not path.exists():
        raise FileNotFoundError(f"Transcript file not found: {transcript_path}")

    transcript = path.read_text()
    if not transcript.strip():
        raise ValueError("Transcript file is empty")

    logger.info("Summarizing transcript (%d chars)...", len(transcript))
    t0 = time.monotonic()

    user_msg = f"Please summarize this meeting transcript:\n\n{transcript}"

    if config.preferred_provider == "local":
        # Use Ollama
        model = config.local_model
        host = config.ollama_host
        ready = await asyncio.get_event_loop().run_in_executor(
            None, _ensure_ollama, model, host,
        )
        if not ready:
            raise ValueError(f"Ollama not reachable at {host}")

        def _summarize_sync():
            body = json.dumps({
                "model": model,
                "messages": [
                    {"role": "system", "content": SUMMARIZE_SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=300) as resp:
                return json.loads(resp.read()).get("message", {}).get("content", "")

        summary = await asyncio.get_event_loop().run_in_executor(None, _summarize_sync)

    elif config.preferred_provider == "gemini" and config.google_api_key:
        # Use Gemini
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=config.google_api_key)

        def _summarize_gemini():
            resp = client.models.generate_content(
                model=config.gemini_model,
                contents=user_msg,
                config=types.GenerateContentConfig(
                    system_instruction=SUMMARIZE_SYSTEM_PROMPT,
                    max_output_tokens=config.max_tokens,
                ),
            )
            return resp.text or ""

        summary = await asyncio.get_event_loop().run_in_executor(None, _summarize_gemini)

    elif config.preferred_provider == "openai" and config.openai_api_key:
        summary = await _openai_complete(config, SUMMARIZE_SYSTEM_PROMPT, user_msg)

    else:
        # Use Claude
        import anthropic
        import httpx

        if not config.anthropic_api_key:
            raise ValueError("No Anthropic API key configured")

        client = anthropic.AsyncAnthropic(
            api_key=config.anthropic_api_key,
            http_client=httpx.AsyncClient(verify=False),
        )
        message = await client.messages.create(
            model=config.claude_model,
            max_tokens=config.max_tokens,
            system=SUMMARIZE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        summary = message.content[0].text

    elapsed = time.monotonic() - t0
    logger.info("Summarization complete: %d chars, %.1fs", len(summary), elapsed)

    # Save alongside the transcript — handle both .live.txt and .transcript.txt
    out_path = _summary_output_path(path)
    out_path.write_text(summary)
    logger.info("Summary saved: %s", out_path.name)

    return summary


async def name_speakers_from_transcript(
    transcript_path: str, config: "AppConfig",
) -> "SpeakerMap":
    """Ask the configured AI provider to label speaker tags in a transcript.

    Returns a ``SpeakerMap`` with ``source[label] = "ai"`` for every label
    the model answered for. Defensive against bad JSON: returns an empty
    ``SpeakerMap`` rather than raising when the model output cannot be
    parsed, so the caller's session-end flow never blocks on this step.
    """
    from meeting_helper.ai.prompts import NAME_SPEAKERS_SYSTEM_PROMPT
    from meeting_helper.speakers import SpeakerMap

    path = Path(transcript_path)
    if not path.exists():
        raise FileNotFoundError(f"Transcript file not found: {transcript_path}")
    transcript = path.read_text()
    if not transcript.strip():
        return SpeakerMap()

    user_msg = (
        "Label the speakers in this transcript. Return JSON only.\n\n"
        f"{transcript}"
    )
    logger.info("Naming speakers (%d chars)...", len(transcript))
    t0 = time.monotonic()

    raw_text = ""
    try:
        if config.preferred_provider == "local":
            model = config.local_model
            host = config.ollama_host
            ready = await asyncio.get_event_loop().run_in_executor(
                None, _ensure_ollama, model, host,
            )
            if not ready:
                logger.warning("name_speakers: ollama not reachable at %s", host)
                return SpeakerMap()

            def _name_sync():
                body = json.dumps({
                    "model": model,
                    "messages": [
                        {"role": "system", "content": NAME_SPEAKERS_SYSTEM_PROMPT},
                        {"role": "user", "content": user_msg},
                    ],
                    "stream": False,
                    "format": "json",
                }).encode()
                req = urllib.request.Request(
                    f"{host.rstrip('/')}/api/chat",
                    data=body,
                    headers={"Content-Type": "application/json"},
                )
                with urllib.request.urlopen(req, timeout=120) as resp:
                    return json.loads(resp.read()).get("message", {}).get("content", "")

            raw_text = await asyncio.get_event_loop().run_in_executor(None, _name_sync)

        elif config.preferred_provider == "gemini" and config.google_api_key:
            from google import genai
            from google.genai import types
            client = genai.Client(api_key=config.google_api_key)

            def _name_gemini():
                resp = client.models.generate_content(
                    model=config.gemini_model,
                    contents=user_msg,
                    config=types.GenerateContentConfig(
                        system_instruction=NAME_SPEAKERS_SYSTEM_PROMPT,
                        max_output_tokens=config.max_tokens,
                    ),
                )
                return resp.text or ""

            raw_text = await asyncio.get_event_loop().run_in_executor(None, _name_gemini)

        elif config.preferred_provider == "openai" and config.openai_api_key:
            raw_text = await _openai_complete(config, NAME_SPEAKERS_SYSTEM_PROMPT, user_msg)

        else:
            import anthropic
            import httpx
            if not config.anthropic_api_key:
                logger.warning("name_speakers: no provider key configured")
                return SpeakerMap()
            client = anthropic.AsyncAnthropic(
                api_key=config.anthropic_api_key,
                http_client=httpx.AsyncClient(verify=False),
            )
            message = await client.messages.create(
                model=config.claude_model,
                max_tokens=config.max_tokens,
                system=NAME_SPEAKERS_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            )
            raw_text = message.content[0].text
    except Exception as exc:
        logger.warning("name_speakers: provider call failed: %s", exc)
        return SpeakerMap()

    parsed = _parse_speaker_naming_json(raw_text)
    elapsed = time.monotonic() - t0
    logger.info(
        "Naming speakers complete (%d labels, %.1fs)",
        len(parsed.names), elapsed,
    )
    return parsed


def _parse_speaker_naming_json(raw: str) -> "SpeakerMap":
    """Best-effort parse of the model's response into a SpeakerMap.

    Strips ``\\`\\`\\`json`` fences if present. Returns an empty map on
    failure rather than raising — the caller treats absence as 'no data'.
    """
    from meeting_helper.speakers import SpeakerMap
    text = (raw or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines:
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    if not text:
        return SpeakerMap()
    try:
        data = json.loads(text)
    except Exception:
        return SpeakerMap()
    if not isinstance(data, dict):
        return SpeakerMap()
    names: dict[str, str | None] = {}
    evidence: dict[str, str] = {}
    source: dict[str, str] = {}
    for label, entry in data.items():
        if not isinstance(label, str) or not label:
            continue
        if not isinstance(entry, dict):
            continue
        name = entry.get("name")
        if name is not None:
            name = str(name).strip() or None
        names[label] = name
        ev = entry.get("evidence")
        if isinstance(ev, str) and ev.strip():
            evidence[label] = ev.strip()[:200]
        source[label] = "ai"
    return SpeakerMap(names=names, evidence=evidence, source=source)


async def name_meeting_from_text(text: str, config: "AppConfig") -> str:
    """Ask the configured AI provider for a 3-5 (max 8) word meeting name.

    Returns the cleaned name (Title Case, ASCII letters/digits/spaces only) or
    "" if the provider has no key configured or the call fails. Caller is
    responsible for any filename sanitization.
    """
    from meeting_helper.ai.prompts import RENAME_MEETING_SYSTEM_PROMPT

    snippet = (text or "").strip()
    if not snippet:
        return ""
    # The summary itself is usually < 4k chars; cap to keep latency/cost low
    # for the rare case we get the raw transcript instead.
    if len(snippet) > 12000:
        snippet = snippet[:12000]

    user_msg = (
        "Suggest a short meeting name for this meeting. "
        "Reply with ONLY the name, nothing else.\n\n"
        f"{snippet}"
    )

    try:
        raw = await _call_ai_for_tasks(
            config, RENAME_MEETING_SYSTEM_PROMPT, user_msg, kind="name",
        )
    except Exception as exc:
        logger.warning("Meeting name generation failed: %s", exc)
        return ""

    return _clean_meeting_name(raw)


def _clean_meeting_name(raw: str) -> str:
    """Strip quotes/markdown/punctuation and cap at 8 words. Returns "" if unusable."""
    if not raw or not raw.strip():
        return ""
    name = raw.strip().splitlines()[0].strip()
    # Strip surrounding quotes/backticks the model often adds despite instructions.
    for ch in ('"', "'", "`", "*"):
        name = name.strip(ch).strip()
    # Drop trailing periods and stray punctuation.
    name = name.rstrip(".!?,;:")
    # Keep only ASCII letters, digits, and whitespace; collapse runs.
    name = re.sub(r"[^A-Za-z0-9\s]", " ", name)
    words = [w for w in name.split() if w]
    if not words:
        return ""
    if len(words) > 8:
        words = words[:8]
    return " ".join(words)


async def _call_ai_for_tasks(
    config: "AppConfig", system_prompt: str, user_msg: str, *, kind: str = "tasks"
) -> str:
    """Send a single non-streaming request to the configured provider, return raw text."""
    from meeting_helper.state import state as _state
    _state.record_ai_call(kind)
    if config.preferred_provider == "local":
        model = config.local_model
        host = config.ollama_host
        ready = await asyncio.get_event_loop().run_in_executor(
            None, _ensure_ollama, model, host,
        )
        if not ready:
            raise RuntimeError(f"Ollama not reachable at {host}")

        def _sync():
            body = json.dumps({
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_msg},
                ],
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                return json.loads(resp.read()).get("message", {}).get("content", "")
        return await asyncio.get_event_loop().run_in_executor(None, _sync)

    if config.preferred_provider == "gemini" and config.google_api_key:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=config.google_api_key)

        def _sync():
            resp = client.models.generate_content(
                model=config.gemini_model,
                contents=user_msg,
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    max_output_tokens=config.max_tokens,
                ),
            )
            return resp.text or ""
        return await asyncio.get_event_loop().run_in_executor(None, _sync)

    if config.preferred_provider == "openai" and config.openai_api_key:
        return await _openai_complete(config, system_prompt, user_msg)

    import anthropic
    import httpx

    if not config.anthropic_api_key:
        raise RuntimeError("No Anthropic API key configured")

    client = anthropic.AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )
    message = await client.messages.create(
        model=config.claude_model,
        max_tokens=config.max_tokens,
        system=system_prompt,
        messages=[{"role": "user", "content": user_msg}],
    )
    return message.content[0].text


async def extract_tasks(state: "AppState", config: "AppConfig") -> list[dict]:
    """Extract new action items from the live transcript.

    Reads state.sentence_buffer + state.session_tasks. Appends newly extracted
    tasks to state.session_tasks. Returns the list of newly added tasks
    (empty on any failure or empty transcript).
    """
    from meeting_helper.ai.prompts import (
        EXTRACT_TASKS_SYSTEM_PROMPT,
        build_extract_tasks_user_message,
    )
    from meeting_helper import tasks as tasks_mod

    if state.sentence_buffer is None:
        return []
    transcript = state.sentence_buffer.get_full_transcript().strip()
    if not transcript:
        return []

    existing_titles = [t.get("title") or t.get("text", "") for t in state.session_tasks]
    user_msg = build_extract_tasks_user_message(transcript, existing_titles)

    logger.info("extract_tasks: transcript=%d chars, existing=%d",
                len(transcript), len(existing_titles))

    try:
        raw = await _call_ai_for_tasks(
            config, EXTRACT_TASKS_SYSTEM_PROMPT, user_msg, kind="extract-tasks"
        )
    except Exception as exc:
        logger.warning("extract_tasks: AI call failed: %s", exc)
        return []

    parsed = tasks_mod.parse_ai_response(raw)
    if not parsed:
        return []

    new_tasks = tasks_mod.finalize_tasks(parsed)
    state.session_tasks.extend(new_tasks)
    logger.info("extract_tasks: added %d tasks (total=%d)",
                len(new_tasks), len(state.session_tasks))
    return new_tasks
