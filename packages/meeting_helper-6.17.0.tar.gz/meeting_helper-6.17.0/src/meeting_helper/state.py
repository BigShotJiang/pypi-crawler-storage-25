"""Shared mutable state for the daemon process."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    import aiohttp.web
    from meeting_helper.buffer import SentenceBuffer


@dataclass(frozen=True)
class PinnedItem:
    """One entry in the multi-pin topic basket.

    Identity is the pair (kind, id) - the same id can recur across kinds
    (e.g. a ticket and an action_item sharing the same external id), so
    dedupe must consider both.
    """
    kind: str           # "ticket" | "note" | "action_item"
    id: str
    title: str
    board_id: str = ""  # populated only for kind=="ticket"


class AppState:
    """Thread-safe shared state for the running daemon."""

    def __init__(self) -> None:
        self.asyncio_loop: asyncio.AbstractEventLoop | None = None
        self.self_buffer: SentenceBuffer | None = None
        self.other_buffer: SentenceBuffer | None = None
        self.ws_clients: set[aiohttp.web.WebSocketResponse] = set()

        # Processing status (drives tray icon + overlay status dot)
        self.status: Literal["idle", "listening", "processing"] = "idle"

        # Last full AI response (sent to late-joining viewers)
        self.last_response: str = ""
        self.last_cards: list[dict] = []

        # Conversation history: list of {"role": "user"|"assistant", "content": ...}
        # Cleared between meetings, kept within a meeting across queries.
        self.conversation_history: list = []

        self.started_at: float = 0.0
        self.audio_active: bool = False
        self.shutdown_event: asyncio.Event | None = None

        # Meeting-specific
        self.meeting_info: object | None = None  # MeetingInfo from meeting_detector
        self.session_active: bool = False
        # True while the post-meeting auto-summary is running. The meeting-end
        # thread blocks on it before the daemon restarts, and /health exposes
        # it so the GUI can show "Summarizing meeting…" instead of going dark.
        self.summarizing: bool = False
        self.overlay_proc: object | None = None  # subprocess.Popen
        self.overlay_visible: bool = False

        # Current system prompt (can be rebuilt mid-session via workspace change)
        self.system_prompt: str = ""

        # When non-None, a past Claude Code conversation is attached as primary context.
        # Cleared on session stop.
        # Shape: {"session_id", "title", "repo", "attached_at", "chars", "truncated"}
        self.attached_conversation: dict | None = None

        # Proactive monitor (set during active session, None otherwise)
        self.proactive_monitor: object | None = None

        # Tracker MCP client (lazy: subprocess spawns on first use)
        self.tracker: object | None = None
        # Per-vendor tracker call counters. Old `local_todo_call_count`
        # kept for one release as the sum across vendors.
        self.tracker_calls_by_vendor: dict[str, dict[str, int]] = {}

        # Topic worker state — refreshed every ~5s while a session is active
        self.current_topic: dict = {
            "topic": "",
            "ticket_ids": [],
            "search_query": "",
            "last_user_statement": "",
        }
        self.current_topic_cards: list[dict] = []
        # Distinct from current_topic: the topic the LAST USER QUERY's picker
        # chose. current_topic drifts with the auto-worker based on transcript;
        # this stays put across silent transcript drift so a follow-up question
        # ("what are the consequences?" / "more on that") anchors on what the
        # user was actually asking about, not on whatever the auto-worker
        # picked in the interim. Updated by _pre_flight_topic_refresh only.
        self.last_user_query_topic: dict = {
            "topic": "",
            "ticket_ids": [],
        }
        self.topic_worker: object | None = None  # TopicWorker instance during session
        # Multi-pin basket. Empty => AUTO mode; the topic worker uses the
        # full sprint cache + action-item fallback. Non-empty => the worker
        # narrows its picker to this basket and skips its own action-item leg.
        self.pinned_topics: list[PinnedItem] = []
        # Loaded git diffs for pinned repos (kind=="repo"), keyed by repo path.
        # Populated by the Load action; rendered into the pinned-topics block.
        self.repo_diffs: dict[str, dict] = {}
        # Buffered screenshots. Each: {id, path, thumb}. Capped; oldest dropped.
        # STICKY: kept (not drained) after a query so follow-up questions about
        # the same on-screen content reuse the shot without re-capturing. A new
        # capture after a query replaces the set; /screenshot/clear purges it.
        self.screenshot_buffer: list[dict] = []
        # True once the current buffer has been attached to a query. The next
        # Esc+Down capture then replaces the set instead of appending to it.
        self.screenshots_consumed: bool = False
        # Number of Esc+Down captures currently running in a worker thread.
        # A query (2x Cmd) waits for this to settle before draining the buffer,
        # so a screenshot fired just before the send still lands in that turn.
        self.pending_screenshot_captures: int = 0
        # Tracks the post-workspace-switch sprint-cache pre-warm task so we
        # can cancel it on a rapid switch — without cancellation two pre-warm
        # tasks can race and the loser would write the prior workspace's
        # tickets into the current workspace.
        self.prewarm_task: object | None = None
        # Last Copilot tracker that failed with InteractiveOAuthRequired.
        # Read by /brief and /topics/refresh to return a clearer "click
        # Connect to re-authenticate" error instead of "no active items".
        # Cleared on successful agent_fetch.
        self.tracker_needs_reauth: str | None = None

        # Cached active-sprint tickets across all boards. Loaded at session
        # start and refreshed periodically by TopicWorker. Used as the
        # constrained list the LLM picks from when identifying the current
        # topic — robust to transcription noise that would break a raw
        # keyword search.
        self.sprint_tickets: list[dict] = []
        self.sprint_tickets_loaded_at: float = 0.0
        # Single-flight handle: when a refresh is in progress, concurrent
        # callers await this task instead of starting a duplicate ~44s fetch.
        # Cleared when the running fetch finishes (success or failure).
        self.sprint_tickets_inflight: asyncio.Task | None = None

        # Hot Moment — when monotonic() < hot_moment_until, TopicWorker also
        # consumes other_buffer sentences (otherwise mic-only). Re-armed by
        # any engagement signal: own speech, query submission, brief click.
        self.hot_moment_until: float = 0.0
        # Configured Hot Moment window length, in seconds. Seeded from the
        # workspace config at daemon startup and kept live by POST /config so
        # every armer (TopicWorker, query, brief) uses the user's setting
        # rather than a stale snapshot.
        self.hot_moment_window_sec: float = 600.0

        # AUTO/MANUAL topic mode. When True (MANUAL), TopicWorker._run never
        # auto-calls the LLM picker, regardless of engagement. When False
        # (AUTO, the default) the picker runs only inside a Hot Moment. This
        # is a SEPARATE axis from `is_manual_mode` (which means "has pins").
        self.topic_auto_paused: bool = False

        # Wallclock timestamp of the last query we built a prompt for.
        # Used by `_extract_likely_question` to ignore sentences that already
        # produced an AI answer — prevents the hotkey from re-asking a stale
        # question when the topic has shifted but the old `?` is still in the
        # rolling buffer.
        self.last_query_at: float = 0.0

        # The exact question the last hotkey query answered (the other
        # speaker's most recent '?'). Broadcast so the Copilot can label each
        # answer with "re: <question>" — a slow provider's reply that lands
        # after the user moved on is then obviously tied to its question
        # instead of looking like the AI answered something from a while ago.
        self.last_query_question: str = ""

        # MeetingSession instance (for manual start/stop)
        self.meeting_session: object | None = None

        # Current AI streaming task (for query cancellation)
        self.active_query: asyncio.Task | None = None

        # Info bar state (broadcast to overlay via "info" messages, and shown
        # as read-only chips in the Copilot toolbar). `transcriber_name` is the
        # runtime display name (e.g. "Whisper (remote: …)" / "Deepgram");
        # `ai_provider` is "claude" / "gemini" / "local"; `ai_model` is the
        # resolved model id for that provider.
        self.transcriber_name: str = ""
        self.ai_provider: str = ""
        self.ai_model: str = ""

        # Tasks extracted during the current session (cleared on session start,
        # persisted to <recording>.tasks.json on session end).
        self.session_tasks: list[dict] = []

        # Live observability counters — surfaced in the copilot toolbar so the
        # user can see what the daemon is actually doing during a meeting.
        # Reset on session start (see daemon._broadcast_meeting_started).
        self.ai_call_count: int = 0
        self.ai_calls_by_kind: dict[str, int] = {}
        self.local_todo_call_count: int = 0
        self.local_todo_calls_by_kind: dict[str, int] = {}
        self.last_local_todo_action: str = ""
        self.last_local_todo_at: float = 0.0

        # Wallclock of the most recent AI call (set in record_ai_call) and
        # its kind. Surfaced in /health so the GUI can show "last AI call Ns ago".
        self.last_ai_call_at: float = 0.0
        self.last_ai_call_kind: str = ""
        # Wallclock when the current streaming query task started. Combined
        # with `active_query` this is the "AI call stuck" signal in /health.
        self.active_query_started_at: float = 0.0
        # Latest daemon-loop health samples (filled by the 0.5 s loop in daemon.py).
        self.proc_cpu_percent: float = 0.0
        self.host_cpu_percent: float = 0.0
        self.proc_rss_mb: float = 0.0
        self.event_loop_lag_ms: float = 0.0

        # Chat mutation gate: keyed by f"{thread_id}:{turn_id}:{tool_name}" -> Future
        # resolved by POST /chat/threads/{id}/confirm with the user's decision.
        self.chat_pending_confirmations: dict[str, asyncio.Future] = {}

        # In-flight chat agent turns, keyed by thread_id -> Task. Lets
        # POST /chat/threads/{id}/cancel stop a running turn (the Stop button).
        # Cleared by a done-callback when the turn finishes or is cancelled.
        self.chat_running_tasks: dict[str, asyncio.Task] = {}

    def record_ai_call(self, kind: str = "ai") -> None:
        self.ai_call_count += 1
        self.ai_calls_by_kind[kind] = self.ai_calls_by_kind.get(kind, 0) + 1
        self.last_ai_call_at = time.time()
        self.last_ai_call_kind = kind

    def record_tracker_call(self, vendor: str, action: str) -> None:
        self.local_todo_call_count += 1
        kind = action.split(" ", 1)[0] if action else "unknown"
        per_vendor = self.tracker_calls_by_vendor.setdefault(vendor, {})
        per_vendor[kind] = per_vendor.get(kind, 0) + 1
        self.local_todo_calls_by_kind[kind] = self.local_todo_calls_by_kind.get(kind, 0) + 1
        self.last_local_todo_action = f"[{vendor}] {action}"
        self.last_local_todo_at = time.time()

    def record_local_todo_call(self, action: str) -> None:
        # Back-compat: callers that don't yet pass vendor get "local_todo"
        # since that's the only vendor in production today.
        self.record_tracker_call("local_todo", action)

    def tracker_call_stats(self) -> dict[str, dict[str, int]]:
        return {v: dict(by) for v, by in self.tracker_calls_by_vendor.items()}

    def reset_local_todo_counters(self) -> None:
        """Reset only the tracker/local_todo call counters (used by tests and session start)."""
        self.local_todo_call_count = 0
        self.local_todo_calls_by_kind = {}
        self.tracker_calls_by_vendor = {}
        self.last_local_todo_action = ""
        self.last_local_todo_at = 0.0

    def reset_session_stats(self) -> None:
        self.ai_call_count = 0
        self.ai_calls_by_kind = {}
        self.reset_local_todo_counters()

    @property
    def local_todo(self):
        import warnings
        warnings.warn(
            "AppState.local_todo is deprecated — use AppState.tracker.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.tracker

    @local_todo.setter
    def local_todo(self, value):
        import warnings
        warnings.warn(
            "AppState.local_todo is deprecated — assign to AppState.tracker instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.tracker = value

    @property
    def sentence_buffer(self) -> "SentenceBuffer | None":
        """Back-compat alias to self_buffer. Existing callers (extract_tasks,
        transcript polling, etc.) keep working without per-call rewriting.
        Newer callers should read self_buffer / other_buffer explicitly."""
        return self.self_buffer

    @sentence_buffer.setter
    def sentence_buffer(self, value: "SentenceBuffer | None") -> None:
        self.self_buffer = value

    def pin_topic(self, item: PinnedItem) -> None:
        for existing in self.pinned_topics:
            if existing.kind == item.kind and existing.id == item.id:
                return
        self.pinned_topics.append(item)

    def unpin_topic(self, kind: str, id: str) -> bool:
        for i, existing in enumerate(self.pinned_topics):
            if existing.kind == kind and existing.id == id:
                del self.pinned_topics[i]
                return True
        return False

    def clear_pins(self) -> None:
        self.pinned_topics.clear()

    def set_repo_diff(self, repo_path: str, snapshot: dict) -> None:
        self.repo_diffs[repo_path] = snapshot

    def clear_repo_diff(self, repo_path: str) -> bool:
        return self.repo_diffs.pop(repo_path, None) is not None

    SCREENSHOT_BUFFER_CAP = 8

    def add_screenshot(self, *, path: str, thumb: str) -> dict:
        """Append a captured screenshot. Capped; oldest dropped, order kept."""
        import uuid
        item = {"id": uuid.uuid4().hex[:8], "path": path, "thumb": thumb}
        self.screenshot_buffer.append(item)
        if len(self.screenshot_buffer) > self.SCREENSHOT_BUFFER_CAP:
            self.screenshot_buffer = self.screenshot_buffer[-self.SCREENSHOT_BUFFER_CAP:]
        return item

    def drain_screenshots(self) -> list[dict]:
        items = list(self.screenshot_buffer)
        self.screenshot_buffer = []
        self.screenshots_consumed = False
        return items

    def clear_screenshots(self) -> None:
        self.screenshot_buffer = []
        self.screenshots_consumed = False

    @property
    def is_manual_mode(self) -> bool:
        return bool(self.pinned_topics)

    def is_hot_moment(self) -> bool:
        """True while the user is actively engaged (within the Hot Moment window)."""
        return time.monotonic() < self.hot_moment_until

    def arm_hot_moment(self, window_sec: float) -> None:
        """Re-stamp the Hot Moment to expire ``window_sec`` from now.

        A non-positive window is a no-op (Hot Moment effectively disabled).
        """
        if window_sec <= 0:
            return
        self.hot_moment_until = time.monotonic() + window_sec

    def hot_moment_until_wallclock(self) -> float:
        """Convert ``hot_moment_until`` (monotonic) into a wall-clock timestamp
        so GUI clients can compute time-remaining without their own monotonic
        clock. Returns 0.0 when Hot Moment is idle."""
        if not self.is_hot_moment():
            return 0.0
        seconds_left = self.hot_moment_until - time.monotonic()
        return time.time() + max(0.0, seconds_left)


# Module-level singleton
state = AppState()
