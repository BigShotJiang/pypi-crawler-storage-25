"""Frontmost-window screenshot capture for the in-meeting Copilot (#48).

Capture is done with the native macOS ``screencapture`` tool rather than PIL's
ImageGrab: on multi-monitor + Retina setups ImageGrab's point-vs-pixel bbox math
and main-display-only behavior produced wrong/empty grabs. ``screencapture -l``
captures a specific window by id at native resolution on any display, using the
same Screen Recording permission the app already holds for system audio.

The pure helpers (encode, thumbnail) are platform-neutral and still use PIL.
"""
from __future__ import annotations

import base64
import io
import logging
import subprocess
import time
from pathlib import Path
from typing import Optional

from PIL import Image

from meeting_helper.config import DEFAULT_CONFIG_DIR

logger = logging.getLogger(__name__)

SCREENSHOTS_DIR = DEFAULT_CONFIG_DIR / "screenshots"


# Window owners we never want to capture (our own UI / system chrome). The
# user reaches for a screenshot to grab what someone is SHARING, not the tool
# they're asking in.
_SKIP_OWNERS = {"Meeting Helper", "Python", "Dock", "Window Server", "Control Center"}


def _frontmost_window_id() -> Optional[int]:
    """kCGWindowNumber of the frontmost real window, or None.

    Uses CGWindowListCopyWindowInfo's front-to-back ordering directly rather
    than NSWorkspace.frontmostApplication(): the daemon is a background process
    and frontmostApplication() returns None there, so we'd never get a window
    id and would always fall back to a full-display grab on the wrong monitor.
    """
    try:
        import Quartz

        wins = Quartz.CGWindowListCopyWindowInfo(
            Quartz.kCGWindowListOptionOnScreenOnly
            | Quartz.kCGWindowListExcludeDesktopElements,
            Quartz.kCGNullWindowID,
        )
        # Windows come back front-to-back; the first normal-layer, real-sized
        # window that isn't our own UI is the one the user is looking at.
        for info in wins:
            if info.get("kCGWindowLayer", 0) != 0:
                continue
            if info.get("kCGWindowOwnerName") in _SKIP_OWNERS:
                continue
            b = info.get("kCGWindowBounds") or {}
            if int(b.get("Width", 0)) > 50 and int(b.get("Height", 0)) > 50:
                wid = info.get("kCGWindowNumber")
                if wid is not None:
                    return int(wid)
    except Exception as exc:
        logger.debug("frontmost window detect failed: %s", exc)
    return None


def _run_screencapture(args: list[str]) -> bool:
    try:
        proc = subprocess.run(
            ["screencapture", *args], capture_output=True, timeout=10
        )
    except (OSError, subprocess.SubprocessError) as exc:
        logger.error("screencapture failed: %s", exc)
        return False
    if proc.returncode != 0:
        logger.error(
            "screencapture rc=%d: %s", proc.returncode,
            (proc.stderr or b"").decode(errors="ignore").strip(),
        )
        return False
    return True


def capture_frontmost_window() -> Optional[str]:
    """Capture the frontmost window (or the main display on fallback) via the
    native screencapture tool. Returns the saved JPEG path, or None on failure.
    """
    SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    path = SCREENSHOTS_DIR / f"shot_{int(time.time() * 1000)}.jpg"
    wid = _frontmost_window_id()
    if wid is not None:
        # -o omits the window shadow; -l<id> captures that exact window at
        # native res on whichever monitor it lives on.
        ok = _run_screencapture(["-x", "-o", "-t", "jpg", f"-l{wid}", str(path)])
    else:
        # Fallback: whole main display (no window detected).
        ok = _run_screencapture(["-x", "-t", "jpg", str(path)])
    if not ok or not path.exists() or path.stat().st_size == 0:
        # Clean up an empty/partial file so it never gets sent.
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        return None
    return str(path)


# Vision models downscale anything larger than ~1568px on the long edge before
# they read it, so sending a raw 5K Retina grab just hands them a blurry
# server-side downscale. We do the resize ourselves to the same target and keep
# JPEG quality high with chroma subsampling OFF, so monospaced code glyphs stay
# sharp enough to READ. q40 (the old behavior) smeared small text into mush,
# which is why the model invented identifiers instead of reading them.
_VISION_MAX_EDGE = 1568
_VISION_JPEG_QUALITY = 85


def encode_b64(path: Path | str) -> str:
    """Base64 of the screenshot, re-encoded for code legibility.

    Downscales the long edge to ``_VISION_MAX_EDGE`` (no upscaling of smaller
    grabs) and saves JPEG at high quality with subsampling disabled. Falls back
    to the raw file bytes if PIL can't open it.
    """
    path = Path(path)
    try:
        img = Image.open(path).convert("RGB")
        long_edge = max(img.width, img.height)
        if long_edge > _VISION_MAX_EDGE:
            scale = _VISION_MAX_EDGE / long_edge
            img = img.resize(
                (max(1, round(img.width * scale)), max(1, round(img.height * scale))),
                Image.LANCZOS,
            )
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=_VISION_JPEG_QUALITY, subsampling=0)
        return base64.b64encode(buf.getvalue()).decode()
    except Exception:
        return base64.b64encode(path.read_bytes()).decode()


def make_thumbnail_data_url(path: Path | str, *, max_w: int = 320) -> str:
    """Small downscaled JPEG data URL for the web buffer strip."""
    img = Image.open(path).convert("RGB")
    if img.width > max_w:
        ratio = max_w / img.width
        img = img.resize((max_w, max(1, int(img.height * ratio))))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=50)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
