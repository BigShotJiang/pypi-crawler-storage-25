"""Auto-title the first exchange of a thread.

Uses whatever AI provider + model the user has configured for the workspace
— no hardcoded model id here. (Previously this was a hardcoded Haiku call,
which silently ignored the user's preferred_provider / gemini_model /
claude_model settings.)
"""
from __future__ import annotations

from meeting_helper.chat import store as chat_store


_DEFAULT_TITLES = {"New conversation", ""}


async def _one_shot(prompt: str) -> str:
    """Send a single short-output prompt to the user's configured AI provider.

    Respects ``preferred_provider`` and the corresponding model alias from
    the workspace config (``claude_model`` for Anthropic, ``gemini_model``
    for Google). Returns "" when the configured provider has no key — the
    caller treats empty as "skip, keep default title".
    """
    from meeting_helper.config import get_config
    cfg = get_config()
    preferred = (getattr(cfg, "preferred_provider", "") or "claude").lower()

    if preferred == "gemini" and cfg.google_api_key:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=cfg.google_api_key)
        try:
            resp = client.models.generate_content(
                model=cfg.gemini_model,
                contents=prompt,
                config=types.GenerateContentConfig(max_output_tokens=40),
            )
            return (resp.text or "").strip()
        except Exception:
            return ""

    if cfg.anthropic_api_key:
        from anthropic import AsyncAnthropic
        client = AsyncAnthropic(api_key=cfg.anthropic_api_key)
        msg = await client.messages.create(
            model=cfg.claude_model,
            max_tokens=40,
            messages=[{"role": "user", "content": prompt}],
        )
        return "".join(b.text for b in msg.content if b.type == "text").strip()

    return ""


async def maybe_generate_title(thread_id: str) -> None:
    """If the thread is still on its default title and has at least one
    user+assistant exchange, replace the title with an AI-generated summary.
    Uses the workspace's configured AI provider; no-op when none configured."""
    th = chat_store.read_thread(thread_id)
    if th.title not in _DEFAULT_TITLES:
        return
    has_user = any(t.role == "user" for t in th.turns)
    has_assistant = any(t.role == "assistant" and t.text for t in th.turns)
    if not (has_user and has_assistant):
        return
    prompt = (
        "Summarise this exchange in <=8 words for a chat title. No punctuation, no quotes.\n\n"
        + "\n".join(
            f"{t.role.upper()}: {t.text}" for t in th.turns
            if t.role in ("user", "assistant") and t.text
        )
    )
    title = await _one_shot(prompt)
    if title:
        chat_store.rename_thread(thread_id, title[:60])
