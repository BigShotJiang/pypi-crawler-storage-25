"""Provider adapters — wrap Anthropic + Gemini into a unified streaming
agent-loop contract:

    async for event in provider.stream_completion(system=..., messages=..., tools=...):
        # event = {type: "chunk", text} | {type: "tool_use", id, name, input} | {type: "done"}
"""
from __future__ import annotations

import logging
from typing import Any, AsyncIterator

logger = logging.getLogger(__name__)


class ClaudeProvider:
    # 8192 output tokens (up from 4096) so long meeting summaries / brief
    # answers don't truncate mid-sentence. Claude 4.x supports well beyond
    # this; Gemini is uncapped, so this also narrows a parity gap.
    def __init__(self, *, api_key: str, model: str, max_tokens: int = 8192):
        from anthropic import AsyncAnthropic
        self._client = AsyncAnthropic(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    async def stream_completion(
        self, *, system: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]]
    ) -> AsyncIterator[dict[str, Any]]:
        import asyncio as _asyncio

        # Anthropic enforces tool names match ^[a-zA-Z0-9_-]{1,128}$ — translate
        # dotted registry names to underscores on the wire, then map back when
        # we receive tool_use blocks so downstream consumers see the original.
        name_map_out = {t["name"]: t["name"].replace(".", "_") for t in tools}
        name_map_in = {v: k for k, v in name_map_out.items()}
        params: dict[str, Any] = {
            "model": self._model,
            "system": system,
            "messages": messages,
            "max_tokens": self._max_tokens,
        }
        if tools:
            params["tools"] = [
                {
                    "name": name_map_out[t["name"]],
                    "description": t["description"],
                    "input_schema": _to_jsonschema(t["input_schema"]),
                }
                for t in tools
            ]

        # Retry transient overload (529) / rate-limit (429) / 5xx the same way
        # GeminiProvider does, so a single Anthropic blip doesn't hard-fail the
        # turn. Only retry before any output has streamed (no duplicate text).
        attempt = 0
        max_attempts = 3
        while True:
            attempt += 1
            saw_output = False
            try:
                async with self._client.messages.stream(**params) as stream:
                    current_tu: dict[str, Any] | None = None
                    current_tu_input_acc: list[str] = []
                    async for event in stream:
                        etype = event.type
                        if etype == "content_block_start" and event.content_block.type == "tool_use":
                            current_tu = {
                                "id": event.content_block.id,
                                "name": event.content_block.name,
                            }
                            current_tu_input_acc = []
                        elif etype == "content_block_delta":
                            if event.delta.type == "text_delta":
                                saw_output = True
                                yield {"type": "chunk", "text": event.delta.text}
                            elif event.delta.type == "input_json_delta" and current_tu is not None:
                                current_tu_input_acc.append(event.delta.partial_json)
                        elif etype == "content_block_stop" and current_tu is not None:
                            import json as _json
                            try:
                                parsed = _json.loads("".join(current_tu_input_acc) or "{}")
                            except _json.JSONDecodeError:
                                parsed = {}
                            saw_output = True
                            yield {
                                "type": "tool_use",
                                "id": current_tu["id"],
                                "name": name_map_in.get(current_tu["name"], current_tu["name"]),
                                "input": parsed,
                            }
                            current_tu = None
                            current_tu_input_acc = []
                yield {"type": "done", "stop_reason": "end_turn"}
                return
            except Exception as exc:
                if not saw_output and attempt < max_attempts and _is_transient_anthropic_error(exc):
                    await _asyncio.sleep(2 ** (attempt - 1))
                    continue
                raise _friendly_anthropic_error(exc)


def _to_jsonschema(schema: dict[str, Any]) -> dict[str, Any]:
    """Translate our compact schema to JSON Schema for the API.

    Compact: ``{"q": "string", "limit": "integer?"}`` → real JSON Schema
    with a `required` list. If the input is *already* a JSON Schema
    (detected by the presence of ``type == "object"`` and a ``properties``
    dict), pass it through verbatim — this is how the MCP passthrough
    tools surface their server-side schemas without round-tripping.
    """
    if isinstance(schema, dict) and schema.get("type") == "object" and isinstance(schema.get("properties"), dict):
        return schema
    properties: dict[str, Any] = {}
    required: list[str] = []
    for k, v in schema.items():
        t = v.rstrip("?")
        optional = v.endswith("?")
        properties[k] = {"type": t}
        if not optional:
            required.append(k)
    return {"type": "object", "properties": properties, "required": required}


_TRANSIENT_ANTHROPIC_CODES = {"429", "500", "502", "503", "504", "529"}


def _is_transient_anthropic_error(exc: Exception) -> bool:
    """Should ClaudeProvider retry this call? Anthropic surfaces overloaded
    (529), rate limits (429) and 5xx as APIStatusError subclasses. Mirror the
    Gemini retry policy so neither provider hard-fails on a transient blip."""
    code = str(getattr(exc, "status_code", "") or getattr(exc, "code", "") or "")
    if code in _TRANSIENT_ANTHROPIC_CODES:
        return True
    msg = str(exc).lower()
    if any(c in msg for c in _TRANSIENT_ANTHROPIC_CODES):
        return True
    return any(
        kw in msg
        for kw in ("overloaded", "rate limit", "timeout", "connection", "internal server")
    )


def _friendly_anthropic_error(exc: Exception) -> Exception:
    """User-readable Claude error, mirroring ``_friendly_gemini_error`` so the
    chat bubble never shows a raw Anthropic exception dump."""
    msg = str(exc)
    lower = msg.lower()
    code = str(getattr(exc, "status_code", "") or "")
    if "overloaded" in lower or code == "529" or "529" in msg:
        return RuntimeError(
            "Claude is overloaded right now (Anthropic's servers). Try again in a "
            "moment, or switch to Gemini for this turn."
        )
    if "rate" in lower or code == "429" or "429" in msg:
        return RuntimeError("Claude rate limit hit. Wait a bit and retry, or switch model.")
    if code in ("401", "403") or "authentication" in lower or "api key" in lower or "x-api-key" in lower:
        return RuntimeError("Claude rejected the API key. Check Settings -> AI Providers.")
    if code == "404" or "not_found" in lower or "not found" in lower:
        return RuntimeError(
            "Claude model not available. Pick a different model in the picker."
        )
    return RuntimeError(msg[:300])


def _sanitize_for_gemini(schema: Any) -> Any:
    """Strip JSON Schema features the Gemini SDK rejects.

    Real-world MCP tool schemas frequently use ``"type": ["string", "null"]``
    or ``["string", "number", "null"]`` for nullable / union fields (valid
    JSON Schema). Gemini's ``FunctionDeclaration`` only accepts a single
    type enum value per property, so the SDK throws a pydantic validation
    error the moment a tool with a union type is sent. We pre-walk the
    schema and:

      - collapse union types to their first non-null entry
      - drop ``oneOf`` / ``anyOf`` siblings (keep the first)
      - recurse into ``properties`` and ``items``

    Anthropic accepts the union form directly — only Gemini needs this.
    """
    if isinstance(schema, list):
        return [_sanitize_for_gemini(item) for item in schema]
    if not isinstance(schema, dict):
        return schema

    out: dict[str, Any] = {}
    for key, value in schema.items():
        if key == "type" and isinstance(value, list):
            non_null = [t for t in value if t != "null"]
            out["type"] = (non_null[0] if non_null else "string")
            continue
        if key in ("oneOf", "anyOf") and isinstance(value, list) and value:
            # Keep just the first variant. Gemini doesn't model unions.
            picked = _sanitize_for_gemini(value[0])
            if isinstance(picked, dict):
                for k2, v2 in picked.items():
                    out.setdefault(k2, v2)
            continue
        if key in ("properties", "patternProperties"):
            out[key] = {k: _sanitize_for_gemini(v) for k, v in value.items()}
            continue
        if key == "items":
            out[key] = _sanitize_for_gemini(value)
            continue
        out[key] = _sanitize_for_gemini(value) if isinstance(value, (dict, list)) else value
    return out


class GeminiProvider:
    """Streaming chat provider backed by the new ``google-genai`` SDK.

    The previous implementation imported ``google.generativeai`` (the
    deprecated legacy package, never installed by this project's
    pyproject) and the constructor blew up the moment a user picked
    Gemini in the chat picker. The rest of the codebase already uses
    ``google.genai``; this class now follows the same pattern.

    Streaming is synchronous on Gemini's side, so we shovel chunks
    through an ``asyncio.Queue`` populated by a thread-pool task —
    same trick ``ai/client.py`` uses for its non-chat Gemini path.
    """

    def __init__(self, *, api_key: str, model: str):
        # Lazy-import so the test for selection doesn't pull the SDK.
        from google import genai

        self._client = genai.Client(api_key=api_key)
        self._model_name = model

    async def stream_completion(self, *, system, messages, tools):
        import asyncio as _asyncio

        from google.genai import types as gtypes

        # Gemini's function declarations also enforce a strict name regex,
        # so translate dotted chat-registry names to underscores on the wire
        # and reverse the mapping on tool_use blocks coming back.
        name_map_out = {t["name"]: t["name"].replace(".", "_") for t in tools} if tools else {}
        name_map_in = {v: k for k, v in name_map_out.items()}
        function_declarations = [
            gtypes.FunctionDeclaration(
                name=name_map_out[t["name"]],
                description=t["description"],
                parameters=_sanitize_for_gemini(_to_jsonschema(t["input_schema"])),
            )
            for t in (tools or [])
        ]
        cfg_kwargs: dict[str, Any] = {"system_instruction": system}
        if function_declarations:
            cfg_kwargs["tools"] = [gtypes.Tool(function_declarations=function_declarations)]
            # We drive the tool loop ourselves (manual function calling), so the
            # SDK's Automatic Function Calling must be OFF. Left on (the default,
            # which logs "AFC is enabled with max remote calls: 10"), the SDK can
            # interfere with the manual functionCall / functionResponse round-trip.
            cfg_kwargs["automatic_function_calling"] = gtypes.AutomaticFunctionCallingConfig(
                disable=True
            )
        if "gemini-3" in self._model_name:
            # Mirror the legacy chat path: skip the deep "thinking" budget
            # on Gemini 3 so the first token is fast.
            cfg_kwargs["thinking_config"] = gtypes.ThinkingConfig(thinking_level="low")
        config = gtypes.GenerateContentConfig(**cfg_kwargs)

        contents = _to_gemini_contents(messages)

        loop = _asyncio.get_event_loop()
        q: _asyncio.Queue = _asyncio.Queue()
        _sentinel = object()

        def _produce() -> None:
            import time as _time
            # Gemini occasionally 503s "high demand" or 429s when the
            # project hits per-minute quota. Both are transient — a short
            # backoff almost always recovers. Retry up to 3 times before
            # surfacing.
            attempt = 0
            max_attempts = 3
            while True:
                attempt += 1
                try:
                    stream = self._client.models.generate_content_stream(
                        model=self._model_name,
                        contents=contents,
                        config=config,
                    )
                    # Track whether this attempt emitted anything. Gemini —
                    # notably gemini-2.5-flash-lite — intermittently returns an
                    # empty completion (finish_reason STOP, zero parts) after a
                    # functionResponse, which surfaces to the user as "I finished
                    # without composing a reply". Because we emit as we stream,
                    # an attempt that produced nothing can be safely re-sampled
                    # (no duplicate output) and usually yields real text.
                    saw_output = False
                    for chunk in stream:
                        text = getattr(chunk, "text", None)
                        if text:
                            saw_output = True
                            loop.call_soon_threadsafe(
                                q.put_nowait, {"type": "chunk", "text": text}
                            )
                        cands = getattr(chunk, "candidates", None) or []
                        if not cands:
                            continue
                        parts = (
                            getattr(getattr(cands[0], "content", None), "parts", None)
                            or []
                        )
                        for part in parts:
                            fc = getattr(part, "function_call", None)
                            if not fc:
                                continue
                            saw_output = True
                            original = name_map_in.get(fc.name, fc.name)
                            loop.call_soon_threadsafe(
                                q.put_nowait,
                                {
                                    "type": "tool_use",
                                    "id": getattr(fc, "id", None) or fc.name,
                                    "name": original,
                                    "input": dict(fc.args or {}),
                                },
                            )
                    if not saw_output and attempt < max_attempts:
                        logger.info(
                            "gemini %s returned an empty completion; retrying "
                            "(attempt %d/%d)",
                            self._model_name, attempt, max_attempts,
                        )
                        continue
                    break  # streamed successfully (or out of retries)
                except Exception as exc:
                    if attempt < max_attempts and _is_transient_gemini_error(exc):
                        # Exponential backoff: 1s, 2s. Caps the total wait
                        # at ~3s before we give up and surface to the user.
                        _time.sleep(2 ** (attempt - 1))
                        continue
                    loop.call_soon_threadsafe(
                        q.put_nowait, _friendly_gemini_error(exc)
                    )
                    break
            loop.call_soon_threadsafe(q.put_nowait, _sentinel)

        loop.run_in_executor(None, _produce)
        while True:
            item = await q.get()
            if item is _sentinel:
                break
            if isinstance(item, Exception):
                raise item
            yield item
        yield {"type": "done", "stop_reason": "end_turn"}


_TRANSIENT_GEMINI_CODES = {"429", "500", "502", "503", "504"}
_TRANSIENT_GEMINI_KEYWORDS = ("unavailable", "deadline_exceeded", "internal", "rate", "overloaded")


def _is_transient_gemini_error(exc: Exception) -> bool:
    """Heuristic: should the GeminiProvider retry this call?

    The SDK surfaces a mix of ``google.genai.errors.APIError`` subclasses
    and bare exceptions depending on transport. Both expose the original
    HTTP status code in either ``code`` or the string repr. Treat 5xx and
    429 as transient; anything else (auth, validation, 404) gets surfaced
    immediately so the user can fix it.
    """
    code = str(getattr(exc, "code", "") or "")
    if code in _TRANSIENT_GEMINI_CODES:
        return True
    msg = str(exc).lower()
    if any(code_str in msg for code_str in _TRANSIENT_GEMINI_CODES):
        return True
    return any(kw in msg for kw in _TRANSIENT_GEMINI_KEYWORDS)


def _friendly_gemini_error(exc: Exception) -> Exception:
    """Replace the raw Google API exception with a user-readable one.

    The agent loop catches whatever we raise and surfaces ``str(exc)`` in
    the error bubble. Without this, the UI shows the raw response dict
    (``{'error': {'code': 503, 'message': '...', 'status': 'UNAVAILABLE'}}``)
    which is noisy and unhelpful. Pick out the meaningful bits.
    """
    msg = str(exc)
    lower = msg.lower()
    if "503" in msg or "unavailable" in lower or "overloaded" in lower:
        return RuntimeError(
            "Gemini is overloaded right now (Google's servers). Try again in a moment, "
            "or switch to Claude for this turn."
        )
    if "429" in msg or "rate" in lower or "quota" in lower:
        return RuntimeError(
            "Gemini rate limit hit. Wait a bit and retry, or switch model."
        )
    if "404" in msg or "not_found" in lower:
        return RuntimeError(
            f"Gemini model not available: {getattr(exc, 'code', '') or '404'}. "
            "Pick a different model in the picker."
        )
    if "401" in msg or "permission" in lower or "api key" in lower:
        return RuntimeError(
            "Gemini rejected the API key. Check Settings → AI Providers."
        )
    # Fall back to a trimmed version so we don't dump the whole response.
    return RuntimeError(msg[:300])


def _tool_result_response(content: Any) -> dict[str, Any]:
    """Coerce a tool_result's serialized content into the dict Gemini's
    ``functionResponse`` requires.

    The agent loop stores results as a JSON string, and `_truncate_for_convo`
    can append a non-JSON marker to fat results — so `json.loads` is not
    guaranteed to succeed and not guaranteed to yield an object. Wrap anything
    that isn't already a JSON object so the SDK never sees a bare string,
    list, or scalar (it rejects those)."""
    import json as _json

    if isinstance(content, dict):
        return content
    if isinstance(content, str):
        try:
            parsed = _json.loads(content)
        except (ValueError, TypeError):
            return {"result": content}
        return parsed if isinstance(parsed, dict) else {"result": parsed}
    return {"result": content}


def _to_gemini_contents(messages: list[dict[str, Any]]) -> list[Any]:
    """Translate Anthropic-shaped messages into Gemini ``Content`` objects.

    Handles the four block shapes the agent loop produces across a multi-cycle
    tool run:

      - plain string content               -> a single text part
      - ``{"type": "text"}`` blocks         -> text parts
      - ``{"type": "tool_use"}`` blocks     -> ``functionCall`` parts (model turn)
      - ``{"type": "tool_result"}`` blocks  -> ``functionResponse`` parts (user turn)

    The earlier version stringified any non-str content with ``str(content)``,
    so the assistant's tool_use block list round-tripped into the next request
    as the literal python repr ``[{'type': 'tool_use', ...}]``. Gemini never
    saw a real function call, the tool loop broke, and the model echoed that
    repr straight back into the chat bubble.

    Gemini pairs a ``functionResponse`` with its ``functionCall`` by name, and
    the tool_result block only carries ``tool_use_id`` — so we keep an
    id -> name map populated from the tool_use blocks (which always precede
    their results in the convo) and look the name up when emitting the
    response. Names are translated dotted -> underscored to match the function
    declarations sent on the wire."""
    from google.genai import types as gtypes

    id_to_name: dict[str, str] = {}
    out: list[Any] = []
    for m in messages:
        role = "model" if m["role"] == "assistant" else "user"
        content = m["content"]
        if isinstance(content, str):
            if content:
                out.append(gtypes.Content(role=role, parts=[gtypes.Part.from_text(text=content)]))
            continue

        parts: list[Any] = []
        for block in content:
            btype = block.get("type")
            if btype == "text":
                text = block.get("text") or ""
                if text:
                    parts.append(gtypes.Part.from_text(text=text))
            elif btype == "tool_use":
                wire_name = block["name"].replace(".", "_")
                id_to_name[block.get("id", "")] = wire_name
                parts.append(
                    gtypes.Part.from_function_call(
                        name=wire_name, args=dict(block.get("input") or {})
                    )
                )
            elif btype == "tool_result":
                wire_name = id_to_name.get(block.get("tool_use_id", ""), "tool")
                parts.append(
                    gtypes.Part.from_function_response(
                        name=wire_name,
                        response=_tool_result_response(block.get("content")),
                    )
                )
        if parts:
            out.append(gtypes.Content(role=role, parts=parts))
    return out


_TRANSIENT_OPENAI_CODES = {"429", "500", "502", "503", "504"}


def _is_transient_openai_error(exc: Exception) -> bool:
    """Should OpenAIProvider retry this call? Treat 429 / 5xx / overload /
    connection blips as transient, mirroring the Claude and Gemini policy."""
    code = str(getattr(exc, "status_code", "") or getattr(exc, "code", "") or "")
    if code in _TRANSIENT_OPENAI_CODES:
        return True
    msg = str(exc).lower()
    if any(c in msg for c in _TRANSIENT_OPENAI_CODES):
        return True
    return any(
        kw in msg
        for kw in ("overloaded", "rate limit", "timeout", "connection", "service unavailable", "server error")
    )


def _friendly_openai_error(exc: Exception) -> Exception:
    """User-readable OpenAI error so the chat bubble never shows a raw dump."""
    msg = str(exc)
    lower = msg.lower()
    code = str(getattr(exc, "status_code", "") or "")
    if code == "429" or "rate limit" in lower or "quota" in lower or "insufficient_quota" in lower:
        return RuntimeError("OpenAI rate limit or quota hit. Wait a bit and retry, or switch model.")
    if code in _TRANSIENT_OPENAI_CODES or "overloaded" in lower or "service unavailable" in lower:
        return RuntimeError(
            "OpenAI is having trouble right now (server error). Try again in a moment, "
            "or switch provider."
        )
    if code in ("401", "403") or "authentication" in lower or "api key" in lower or "incorrect api key" in lower:
        return RuntimeError("OpenAI rejected the API key. Check Settings -> AI Providers.")
    if code == "404" or "not_found" in lower or "does not exist" in lower or "not found" in lower:
        return RuntimeError("OpenAI model not available. Pick a different model in the picker.")
    return RuntimeError(msg[:300])


def _tool_result_text(content: Any) -> str:
    """OpenAI tool messages take a string `content`. The agent loop already
    stores tool results as a JSON string; coerce anything else."""
    if isinstance(content, str):
        return content
    import json as _json
    try:
        return _json.dumps(content)
    except (TypeError, ValueError):
        return str(content)


def _to_openai_messages(system: str, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Translate the system prompt + Anthropic-shaped messages into the OpenAI
    Chat Completions message list.

      - system                         -> a leading {"role": "system"} message
      - plain string content           -> {"role", "content"}
      - assistant ``tool_use`` blocks  -> {"role": "assistant", "tool_calls": [...]}
      - user ``tool_result`` blocks    -> one {"role": "tool", "tool_call_id"} each

    Tool names are translated dotted -> underscored to match the function
    declarations sent on the wire. OpenAI requires the assistant `tool_calls`
    message to be followed by a `tool` message per call id; the agent loop emits
    assistant(tool_use) then user(tool_result) in that order, so the pairing is
    preserved."""
    import json as _json

    out: list[dict[str, Any]] = []
    if system:
        out.append({"role": "system", "content": system})
    for m in messages:
        role = m["role"]
        content = m["content"]
        if isinstance(content, str):
            out.append({"role": role, "content": content})
            continue

        text_parts: list[str] = []
        tool_calls: list[dict[str, Any]] = []
        tool_results: list[dict[str, Any]] = []
        for block in content:
            bt = block.get("type")
            if bt == "text":
                if block.get("text"):
                    text_parts.append(block["text"])
            elif bt == "tool_use":
                tool_calls.append({
                    "id": block.get("id", ""),
                    "type": "function",
                    "function": {
                        "name": block["name"].replace(".", "_"),
                        "arguments": _json.dumps(block.get("input") or {}),
                    },
                })
            elif bt == "tool_result":
                tool_results.append({
                    "role": "tool",
                    "tool_call_id": block.get("tool_use_id", ""),
                    "content": _tool_result_text(block.get("content")),
                })

        if role == "assistant":
            msg: dict[str, Any] = {"role": "assistant"}
            # OpenAI allows content=None alongside tool_calls; an assistant
            # message must carry one or the other.
            msg["content"] = "\n".join(text_parts) if text_parts else None
            if tool_calls:
                msg["tool_calls"] = tool_calls
            if msg["content"] is None and not tool_calls:
                msg["content"] = ""
            out.append(msg)
        else:  # user turn — tool results first (they answer the preceding
            # assistant tool_calls and must immediately follow it), then any
            # plain text as fresh user input.
            out.extend(tool_results)
            if text_parts:
                out.append({"role": "user", "content": "\n".join(text_parts)})
    return out


class OpenAIProvider:
    """Streaming chat provider backed by the OpenAI Chat Completions API.

    Model-agnostic on purpose: adding a new OpenAI chat model is a one-line
    entry in ``config.OPENAI_MODELS`` and ``web/lib/models.ts`` — no change
    here. Uses ``max_completion_tokens`` (not the deprecated ``max_tokens``)
    and sets no temperature, so reasoning-class models stay compatible."""

    def __init__(self, *, api_key: str, model: str, max_tokens: int = 8192):
        from openai import AsyncOpenAI
        self._client = AsyncOpenAI(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    async def stream_completion(self, *, system, messages, tools):
        import asyncio as _asyncio
        import json as _json

        # OpenAI function names match ^[a-zA-Z0-9_-]{1,64}$ — same dotted ->
        # underscored mapping as the other providers, reversed on the way back.
        name_map_out = {t["name"]: t["name"].replace(".", "_") for t in tools}
        name_map_in = {v: k for k, v in name_map_out.items()}

        params: dict[str, Any] = {
            "model": self._model,
            "messages": _to_openai_messages(system, messages),
            "max_completion_tokens": self._max_tokens,
            "stream": True,
        }
        if tools:
            params["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": name_map_out[t["name"]],
                        "description": t["description"],
                        "parameters": _to_jsonschema(t["input_schema"]),
                    },
                }
                for t in tools
            ]

        attempt = 0
        max_attempts = 3
        while True:
            attempt += 1
            saw_output = False
            # Tool calls stream as deltas keyed by index; accumulate then emit.
            tool_acc: dict[int, dict[str, Any]] = {}
            try:
                stream = await self._client.chat.completions.create(**params)
                async for chunk in stream:
                    choices = getattr(chunk, "choices", None) or []
                    if not choices:
                        continue
                    delta = choices[0].delta
                    text = getattr(delta, "content", None)
                    if text:
                        saw_output = True
                        yield {"type": "chunk", "text": text}
                    for tc in (getattr(delta, "tool_calls", None) or []):
                        slot = tool_acc.setdefault(
                            tc.index, {"id": None, "name": None, "args": ""}
                        )
                        if getattr(tc, "id", None):
                            slot["id"] = tc.id
                        fn = getattr(tc, "function", None)
                        if fn is not None:
                            if getattr(fn, "name", None):
                                slot["name"] = fn.name
                            if getattr(fn, "arguments", None):
                                slot["args"] += fn.arguments
                for idx in sorted(tool_acc):
                    slot = tool_acc[idx]
                    if not slot["name"]:
                        continue
                    saw_output = True
                    try:
                        parsed = _json.loads(slot["args"] or "{}")
                    except _json.JSONDecodeError:
                        parsed = {}
                    yield {
                        "type": "tool_use",
                        "id": slot["id"] or slot["name"],
                        "name": name_map_in.get(slot["name"], slot["name"]),
                        "input": parsed,
                    }
                # Empty completion (no text, no tool call): re-sample, mirroring
                # the Gemini path. Nothing was emitted, so no duplicate output.
                if not saw_output and attempt < max_attempts:
                    logger.info(
                        "openai %s returned an empty completion; retrying (attempt %d/%d)",
                        self._model, attempt, max_attempts,
                    )
                    continue
                yield {"type": "done", "stop_reason": "end_turn"}
                return
            except Exception as exc:
                if not saw_output and attempt < max_attempts and _is_transient_openai_error(exc):
                    await _asyncio.sleep(2 ** (attempt - 1))
                    continue
                raise _friendly_openai_error(exc)


class NoToolsProvider:
    """Wraps a provider but strips the tools list so the model never tool-calls.

    Used for the local-LLM degraded mode where tool reliability is poor.
    """

    def __init__(self, *, inner):
        self._inner = inner

    async def stream_completion(self, *, system, messages, tools):
        async for ev in self._inner.stream_completion(
            system=system, messages=messages, tools=[]
        ):
            if ev["type"] == "tool_use":
                continue  # safety net — shouldn't fire
            yield ev
