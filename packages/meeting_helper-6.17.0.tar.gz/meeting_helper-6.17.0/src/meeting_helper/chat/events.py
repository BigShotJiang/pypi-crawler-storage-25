"""WS event envelope builders for chat events."""
from __future__ import annotations

from typing import Any


def chat_event(type_: str, **fields: Any) -> dict[str, Any]:
    return {"type": type_, **fields}
