"""Per-workspace `active_thread_id` persistence."""
from __future__ import annotations

import json
from typing import Any

from meeting_helper.chat import paths as chat_paths
from meeting_helper.chat.paths import atomic_write_json


def read_state() -> dict[str, Any]:
    p = chat_paths.state_path()
    if not p.exists():
        return {"active_thread_id": None}
    data = json.loads(p.read_text() or "{}")
    data.setdefault("active_thread_id", None)
    return data


def set_active(thread_id: str | None) -> None:
    atomic_write_json(chat_paths.state_path(), {"active_thread_id": thread_id})
