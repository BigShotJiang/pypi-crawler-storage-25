"""Persistent agentic chat — package."""
