"""Per-workspace agent memory.

Lightweight list of notes (facts, preferences, project context) that:
  - the agent can add/update/delete via tools
  - the user can edit via Settings → Memory
  - are injected into the system prompt for every conversation turn

Stored at ~/.config/meeting-helper/chat/<workspace>/memory.json as:
  [{"id": "mem_<hex>", "text": "...", "source": "agent"|"user",
    "pinned": bool, "created_at": "...", "updated_at": "..."}, ...]
"""
from __future__ import annotations

import json
import secrets
from datetime import datetime, timezone
from typing import Any

from meeting_helper.chat import paths as chat_paths


def _memory_path():
    return chat_paths.chat_dir() / "memory.json"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def read_all() -> list[dict[str, Any]]:
    p = _memory_path()
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text() or "[]")
    except json.JSONDecodeError:
        return []


def _write_all(entries: list[dict[str, Any]]) -> None:
    chat_paths.atomic_write_json(_memory_path(), entries)


def add(*, text: str, source: str = "agent", pinned: bool = False) -> dict[str, Any]:
    text = text.strip()
    if not text:
        raise ValueError("memory text cannot be empty")
    entry = {
        "id": f"mem_{secrets.token_hex(6)}",
        "text": text,
        "source": source,
        "pinned": pinned,
        "created_at": _now(),
        "updated_at": _now(),
    }
    entries = read_all()
    entries.append(entry)
    _write_all(entries)
    return entry


def update(mem_id: str, *, text: str | None = None, pinned: bool | None = None) -> dict[str, Any] | None:
    entries = read_all()
    for e in entries:
        if e["id"] == mem_id:
            if text is not None:
                t = text.strip()
                if not t:
                    raise ValueError("memory text cannot be empty")
                e["text"] = t
            if pinned is not None:
                e["pinned"] = pinned
            e["updated_at"] = _now()
            _write_all(entries)
            return e
    return None


def delete(mem_id: str) -> bool:
    entries = read_all()
    new = [e for e in entries if e["id"] != mem_id]
    if len(new) == len(entries):
        return False
    _write_all(new)
    return True


def as_prompt_block() -> str:
    """Render memory as a system-prompt block, or empty string if no entries."""
    entries = read_all()
    if not entries:
        return ""
    pinned = [e for e in entries if e.get("pinned")]
    rest = [e for e in entries if not e.get("pinned")]
    ordered = pinned + rest
    lines = [f"- {e['text']}" for e in ordered]
    return (
        "\n\nLong-term memory (facts about the user and their work, "
        "established across conversations):\n" + "\n".join(lines)
    )
