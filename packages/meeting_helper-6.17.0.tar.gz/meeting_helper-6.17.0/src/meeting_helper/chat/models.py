"""Dataclasses for chat threads and turns.

Plain dataclasses + explicit to_dict/from_dict — no pydantic, matches the
rest of this codebase.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Literal

TurnRole = Literal["user", "assistant", "tool_call", "tool_result"]


@dataclass
class Turn:
    id: str
    role: TurnRole
    created_at: str
    text: str | None = None
    tool_name: str | None = None
    tool_args: dict[str, Any] | None = None
    tool_result: dict[str, Any] | None = None
    provider: str | None = None
    model: str | None = None
    latency_ms: int | None = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return {k: v for k, v in d.items() if v is not None}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Turn":
        return cls(**{k: d.get(k) for k in cls.__dataclass_fields__})


@dataclass
class Thread:
    id: str
    title: str
    created_at: str
    updated_at: str
    turns: list[Turn] = field(default_factory=list)
    # Optional per-thread AI override. When set, the chat agent ignores
    # the workspace-level defaults and uses this provider/model for the
    # whole thread. Either field may be set independently:
    #   - provider only → use the workspace's default model for that provider
    #   - model only    → use the workspace's preferred provider but swap model
    provider: str | None = None
    model: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "id": self.id,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "turns": [t.to_dict() for t in self.turns],
        }
        if self.provider is not None:
            d["provider"] = self.provider
        if self.model is not None:
            d["model"] = self.model
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Thread":
        return cls(
            id=d["id"],
            title=d["title"],
            created_at=d["created_at"],
            updated_at=d["updated_at"],
            turns=[Turn.from_dict(t) for t in d.get("turns", [])],
            provider=d.get("provider"),
            model=d.get("model"),
        )
