"""Filesystem layout for chat threads.

One dir per workspace under ~/.config/meeting-helper/chat/<workspace>/
holds:
  - index.json   : sidebar listing
  - state.json   : {active_thread_id}
  - threads/     : per-thread JSON files
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from meeting_helper.config import DEFAULT_CONFIG_DIR, DEFAULT_WORKSPACE_NAME

CHAT_ROOT: Path = DEFAULT_CONFIG_DIR / "chat"


def _active_workspace_name() -> str | None:
    """Read the active workspace name from the daemon's workspace_state.

    Indirected through a function so tests can monkeypatch it without
    spinning up the whole daemon state machine.
    """
    try:
        from meeting_helper.config import load_state
        return load_state().get("active_workspace")
    except Exception:
        return None


def chat_dir() -> Path:
    name = _active_workspace_name() or DEFAULT_WORKSPACE_NAME
    d = CHAT_ROOT / name
    (d / "threads").mkdir(parents=True, exist_ok=True)
    return d


def threads_dir() -> Path:
    return chat_dir() / "threads"


def index_path() -> Path:
    return chat_dir() / "index.json"


def state_path() -> Path:
    return chat_dir() / "state.json"


def thread_path(thread_id: str) -> Path:
    return threads_dir() / f"{thread_id}.json"


def atomic_write_json(path: Path, data: Any) -> None:
    """Atomically write JSON to ``path`` (write to .tmp, then rename)."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    os.replace(tmp, path)
