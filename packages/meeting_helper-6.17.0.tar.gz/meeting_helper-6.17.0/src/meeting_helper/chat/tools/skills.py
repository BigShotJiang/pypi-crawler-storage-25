"""Skills tools — agent creates reusable slash-prompts.

This is one of the rare hand-wrapped tools that doesn't live behind the
MCP passthrough: skills are a Meeting-Helper concept (a JSON blob the
slash-picker reads), not a local-todo entity. Only ``create`` is exposed
to the agent today — the user manages updates/deletes through the
Settings → Skills page so the agent can't accidentally clobber a tuned
prompt.
"""
from __future__ import annotations

from meeting_helper import skills as skills_store
from meeting_helper.chat.registry import Tool


async def _create(args, ctx):
    name = (args.get("name") or "").strip()
    body = (args.get("body") or "").strip()
    description = (args.get("description") or "").strip()
    if not name:
        return {"status": "error", "error": "name is required"}
    if not body:
        return {"status": "error", "error": "body is required"}
    try:
        entry = skills_store.create_skill(
            name=name, description=description, body=body,
        )
    except skills_store.SkillError as exc:
        return {"status": "error", "error": str(exc)}
    return {"status": "ok", "result": {"skill": entry}}


def build_skills_create() -> Tool:
    return Tool(
        name="skills.create",
        description=(
            "Save a reusable prompt as a named slash-command. The user can "
            "later trigger it in the composer by typing `/<name>`, which "
            "replaces the slash token with the skill's body. Use when the "
            "user asks to remember a workflow or template (e.g. 'save this "
            "as /start-ticket'). The name will be slugified (lowercased, "
            "spaces -> hyphens, alphanumerics + hyphens only)."
        ),
        input_schema={
            "name": "string",
            "description": "string?",
            "body": "string",
        },
        run=_create,
    )
