"""Polymorphic pin/unpin/clear tools for the topic basket."""
from __future__ import annotations

import logging
from typing import Any

from meeting_helper.chat.registry import Tool

logger = logging.getLogger(__name__)

_VALID_KINDS = {"ticket", "note", "action_item"}


async def _broadcast_topic() -> None:
    """Send the same WS payload the HTTP /topic/* handlers send.

    Without this, agent-driven pins/unpins desync the UI until the next
    /current_topic poll. Importing inside the function keeps the topic
    chat tool module decoupled from the server package at import time.
    """
    try:
        from meeting_helper.server.routes import _topic_broadcast_payload
        from meeting_helper.server.websocket import broadcast
        await broadcast(_topic_broadcast_payload())
    except Exception as exc:
        logger.warning("topic.* chat tool broadcast failed: %s", exc)


async def _pin(args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.state import state, PinnedItem

    kind = str(args.get("kind") or "").strip()
    item_id = str(args.get("id") or "").strip()
    title = str(args.get("title") or "").strip()
    board_id = str(args.get("board_id") or "").strip()

    if kind not in _VALID_KINDS:
        return {"status": "error", "error": f"kind must be in {sorted(_VALID_KINDS)}"}
    if not item_id or not title:
        return {"status": "error", "error": "id and title required"}

    state.pin_topic(PinnedItem(kind=kind, id=item_id, title=title, board_id=board_id))
    await _broadcast_topic()
    return {"status": "ok", "result": {"pinned_count": len(state.pinned_topics)}}


async def _unpin(args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.state import state

    kind = str(args.get("kind") or "").strip()
    item_id = str(args.get("id") or "").strip()
    if kind not in _VALID_KINDS or not item_id:
        return {"status": "error", "error": "kind and id required"}
    removed = state.unpin_topic(kind, item_id)
    if removed:
        await _broadcast_topic()
    return {"status": "ok", "result": {"removed": removed, "pinned_count": len(state.pinned_topics)}}


async def _clear(_args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.state import state

    state.clear_pins()
    await _broadcast_topic()
    return {"status": "ok", "result": {"pinned_count": 0}}


def build_topic_pin() -> Tool:
    return Tool(
        name="topic.pin",
        description=(
            "Pin an item to the Copilot topic basket. The basket narrows the "
            "topic worker's candidate set: when non-empty, the worker chooses "
            "the active topic only from the pinned items. kind is one of "
            "'ticket' | 'note' | 'action_item'. board_id is optional and only "
            "used for tickets."
        ),
        input_schema={
            "kind": "string", "id": "string", "title": "string",
            "board_id": "string?",
        },
        run=_pin,
        is_mutation=True,
    )


def build_topic_unpin() -> Tool:
    return Tool(
        name="topic.unpin",
        description="Remove (kind, id) from the topic basket.",
        input_schema={"kind": "string", "id": "string"},
        run=_unpin,
        is_mutation=True,
    )


def build_topic_clear() -> Tool:
    return Tool(
        name="topic.clear",
        description=(
            "Clear all pinned items. The topic worker returns to AUTO mode "
            "(full sprint cache plus the existing action-item fallback leg)."
        ),
        input_schema={},
        run=_clear,
        is_mutation=True,
    )
