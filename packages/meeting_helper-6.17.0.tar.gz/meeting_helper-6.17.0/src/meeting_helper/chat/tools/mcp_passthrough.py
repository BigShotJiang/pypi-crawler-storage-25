"""Dynamic tracker MCP passthrough.

The entire active tracker's MCP surface is exposed dynamically via this
passthrough — there are no hand-wrapped ``tickets.*`` tools. New
MCP tools/fields auto-appear on daemon restart with zero schema
maintenance on our side.

At registry-build time:

1. Pull every tool definition from the connected MCP via ``list_tools()``.
2. For each tool, build a chat :class:`~meeting_helper.chat.registry.Tool`
   that:
     - is named ``mcp.<original_name>``
     - passes the MCP's JSON Schema through verbatim (Anthropic + Gemini
       accept proper JSON Schema, and our provider adapters detect that
       shape and skip the compact-schema translation)
     - is flagged ``is_mutation=True`` when the name starts with a write
       prefix (create_/update_/delete_/add_/move_/start_/close_/remove_/
       revoke_/reorder_/rename_/replace_/favorite_), so the existing
       approval gate engages.

If the active tracker is unreachable or empty, this builder returns an
empty list — the daemon stays usable, just without tracker tools.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from meeting_helper.chat.registry import Tool
from meeting_helper.trackers.slug import slugify_unique

logger = logging.getLogger(__name__)

# Max chat tools registered across all chat-enabled trackers in one workspace.
# Mirrors the agent_fetch budget — Anthropic's tool list contributes to the
# system-prompt token count and gets unhappy past a couple dozen rich schemas.
_MAX_CHAT_TOOLS = 20

_SLUG_SEP = "__"

# Intentionally empty: every MCP tool is surfaced as ``mcp.<name>``. Kept
# as a named symbol so tests / future opt-outs have a stable hook.
_HAND_WRAPPED: frozenset[str] = frozenset()

# Heuristic: any tool starting with one of these prefixes mutates state.
# The chat agent loop will route them through the user-approval gate.
_MUTATION_PREFIXES: tuple[str, ...] = (
    "add_",
    "close_",
    "create_",
    "delete_",
    "favorite_",
    "move_",
    "remove_",
    "rename_",
    "reorder_",
    "replace_",
    "revoke_",
    "start_",
    "update_",
)


def _is_mutation(name: str) -> bool:
    return name.startswith(_MUTATION_PREFIXES)


def _resolve_tracker_label(tracker_id: str | None) -> str:
    """Best-effort lookup of a tracker's user-typed friendly label.

    Falls back to the tracker ID, then to "this tracker" — always returns
    a non-empty string so the UI toast never says nothing useful. This
    runs on every needs_reauth broadcast; a missing config or stale lookup
    just yields the ID, which is the same string we'd have shown before
    the lookup existed."""
    if not tracker_id:
        return "this tracker"
    try:
        from meeting_helper.config import get_config
        cfg = get_config()
        for t in (getattr(cfg, "trackers", None) or []):
            if t.get("id") == tracker_id:
                label = (t.get("label") or "").strip()
                if label:
                    return label
                break
    except Exception:
        pass
    return tracker_id


def _contains_exception(exc: BaseException, target: type) -> bool:
    """Walk ``exc`` and its causes/contexts/sub-exceptions looking for an
    instance of ``target``. anyio TaskGroup wraps the real failure inside
    a ``BaseExceptionGroup`` (or chains it via __cause__), so a plain
    ``isinstance(exc, target)`` misses the actual root cause."""
    seen: set[int] = set()
    queue: list[BaseException] = [exc]
    while queue:
        e = queue.pop()
        if id(e) in seen or e is None:
            continue
        seen.add(id(e))
        if isinstance(e, target):
            return True
        # __cause__ / __context__ chain
        for chained in (getattr(e, "__cause__", None), getattr(e, "__context__", None)):
            if chained is not None:
                queue.append(chained)
        # ExceptionGroup sub-exceptions
        sub = getattr(e, "exceptions", None)
        if sub:
            queue.extend(sub)
    return False


async def build_mcp_passthrough_tools(tracker: Any) -> list[Tool]:
    """Build chat tools for every MCP tool the active tracker exposes.

    `tracker` is a :class:`~meeting_helper.tracker.Tracker` (or a legacy
    :class:`~meeting_helper.local_todo.LocalTodoClient`). If introspection
    fails (server down, transport error), returns an empty list rather than
    raising — the daemon stays usable; the agent just won't have tracker
    tools until the next registry rebuild.

    If the failure is an OAuth re-auth requirement (the passive-OAuth path
    refused to pop a browser), surface the tracker to the UI via the
    ``tracker_chat_unreachable`` toast so the user knows to click Connect.
    Without this, agent_fetch silently returns 0 tools, Brief reports "no
    active items", and the user has no breadcrumb pointing at the actual
    problem.
    """
    mcp = tracker
    if mcp is None:
        return []
    from meeting_helper.trackers.tracker import InteractiveOAuthRequired

    # Pre-check side-channel flag BEFORE awaiting `_ensure_started`. Why:
    # when a previous call hit the OAuth-redirect-in-passive-mode path,
    # the MCP SDK's anyio TaskGroup left the call HUNG (cross-task cancel
    # scope error — see `Tracker.__init__`). That hung task still holds
    # `Tracker._lock`, so a fresh `_ensure_started` would block forever
    # waiting on the lock. Short-circuiting here keeps subsequent fetches
    # snappy and surfaces the needs_reauth signal cleanly. The flag is
    # cleared by `reboot_active_tracker` after a successful interactive
    # Connect, so this branch only fires for trackers we know are broken.
    if getattr(mcp, "_needs_reauth_signaled", False):
        tid = getattr(mcp, "_oauth_tracker_id", "")
        logger.info("mcp_passthrough: short-circuit — tracker %s flagged needs_reauth", tid)
        try:
            from meeting_helper.state import state as _state
            _state.tracker_needs_reauth = tid or "unknown"
        except Exception:
            pass
        try:
            from meeting_helper.server.websocket import broadcast
            await broadcast({
                "type": "tracker_chat_unreachable",
                "trackers": [{
                    "tracker_id": tid,
                    "label": _resolve_tracker_label(tid),
                    "error": "needs re-authentication (click Connect in Settings → Task tracker)",
                }],
            })
        except Exception:
            pass
        return []

    needs_reauth = False
    failure_kind = ""  # "" = no failure; otherwise short reason for the log
    # Spawn _ensure_started as its own task and SHIELD it from cancellation
    # propagating from our wait_for. Why: when `_redirect` raises
    # InteractiveOAuthRequired inside the MCP SDK's anyio TaskGroup, the
    # group's cleanup attempts to cancel sibling tasks across cancel scopes
    # — that fails with "Attempted to exit cancel scope in a different
    # task" and the task becomes UNCANCELLABLE. A plain wait_for would
    # hang waiting for the cancellation to take effect. The shield lets
    # wait_for raise TimeoutError on schedule; the doomed inner task
    # lingers (a tolerated leak — it'll never block another fetch because
    # the next attempt builds a fresh Tracker) while our caller unblocks.
    try:
        await mcp._ensure_started()
        resp = await mcp._session.list_tools()
    except BaseException as exc:  # noqa: BLE001
        # BaseException casts the widest possible net: it catches Exception,
        # BaseExceptionGroup (the anyio-wrapped form that bypasses plain
        # `except Exception`), KeyboardInterrupt, SystemExit, and
        # CancelledError. We re-raise CancelledError so task cancellation
        # semantics still propagate; everything else degrades gracefully
        # to an empty tool list. The side-channel `_needs_reauth_signaled`
        # flag (set by `_redirect` BEFORE its raise) covers the case where
        # the exception arrived in some form `_contains_exception` doesn't
        # recognise — both paths route into the needs_reauth UI flow.
        if isinstance(exc, asyncio.CancelledError):
            raise
        logger.warning("mcp_passthrough: caught %s: %s",
                       type(exc).__name__, exc)
        needs_reauth = bool(getattr(mcp, "_needs_reauth_signaled", False)) \
            or _contains_exception(exc, InteractiveOAuthRequired)
        failure_kind = "exception"

    if failure_kind:
        if needs_reauth:
            tid = getattr(mcp, "_oauth_tracker_id", "")
            try:
                from meeting_helper.state import state as _state
                _state.tracker_needs_reauth = tid or "unknown"
            except Exception:
                pass
            try:
                from meeting_helper.server.websocket import broadcast
                await broadcast({
                    "type": "tracker_chat_unreachable",
                    "trackers": [{
                        "tracker_id": tid,
                        "label": _resolve_tracker_label(tid),
                        "error": "needs re-authentication (click Connect in Settings → Task tracker)",
                    }],
                })
            except Exception:
                pass
        return []

    # We made it past _ensure_started + list_tools — tracker is healthy.
    # Clear any stale "needs re-auth" hint set by a previous failure.
    try:
        from meeting_helper.state import state as _state
        tid = getattr(mcp, "_oauth_tracker_id", None)
        if getattr(_state, "tracker_needs_reauth", None) == tid:
            _state.tracker_needs_reauth = None
        # Nudge the UI so the Settings status dot flips from idle → connected.
        if tid:
            try:
                from meeting_helper.server.websocket import broadcast
                await broadcast({"type": "tracker_changed", "tracker_id": tid, "vendor": None})
            except Exception:
                pass
    except Exception:
        pass

    tools: list[Tool] = []
    for t in getattr(resp, "tools", []) or []:
        name = getattr(t, "name", "") or ""
        if not name or name in _HAND_WRAPPED:
            continue
        schema = getattr(t, "inputSchema", None) or {"type": "object", "properties": {}}
        description = (getattr(t, "description", "") or "").strip()
        chat_name = f"mcp.{name}"
        tools.append(_build_passthrough_tool(chat_name, name, description, schema))
    return tools


def _build_passthrough_tool(
    chat_name: str, mcp_name: str, description: str, schema: dict[str, Any]
) -> Tool:
    async def _run(args: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
        mcp = ctx.get("tracker") or ctx.get("local_todo")
        if mcp is None:
            return {"status": "error", "error": "tracker not configured"}
        try:
            result = await mcp.call_tool(mcp_name, args or {})
        except Exception as exc:  # noqa: BLE001 — surface as tool result
            return {"status": "error", "error": str(exc)[:300]}
        return {"status": "ok", "result": result}

    return Tool(
        name=chat_name,
        description=description or f"MCP passthrough for `{mcp_name}`.",
        input_schema=schema,
        run=_run,
        is_mutation=_is_mutation(mcp_name),
    )


def _parse_slug_prefix(chat_name: str) -> tuple[str, str] | None:
    """Inverse of the build step. Splits on the FIRST `__`; the remainder is
    the original MCP tool name (which may itself contain `__`)."""
    if not chat_name or _SLUG_SEP not in chat_name:
        return None
    slug, _, rest = chat_name.partition(_SLUG_SEP)
    return (slug, rest)


def _build_passthrough_tool_for_tracker(
    chat_name: str,
    mcp_name: str,
    description: str,
    schema: dict,
    tracker_id: str,
    label: str,
):
    """One Tool that dispatches to the named tracker's session at run time."""
    is_mut = _is_mutation(mcp_name)
    desc = f"[{label}] {description}" if description else f"[{label}] {mcp_name}"

    async def _run(args: dict, ctx: dict) -> dict:
        reg = ctx.get("trackers")
        cfg = ctx.get("config")
        ws = ctx.get("workspace_name", "")
        if reg is None or cfg is None:
            return {"status": "error", "error": "chat ctx missing trackers/config"}
        entry = next((t for t in (cfg.trackers or []) if t.get("id") == tracker_id), None)
        if entry is None:
            return {"status": "error", "error": f"tracker {tracker_id} no longer in config"}
        if not entry.get("chat_enabled", True):
            return {"status": "error", "error": f"tracker {tracker_id} is no longer chat-enabled"}
        try:
            tracker = await reg.ensure_session(entry, workspace_name=ws)
            result = await tracker.call_tool(mcp_name, args or {})
        except Exception as exc:  # noqa: BLE001 — surface as tool result
            return {"status": "error", "error": str(exc)[:300]}
        return {"status": "ok", "result": result}

    return Tool(
        name=chat_name,
        description=desc,
        input_schema=schema,
        run=_run,
        is_mutation=is_mut,
    )


async def build_mcp_passthrough_tools_multi(
    registry,
    config,
    *,
    workspace_name: str = "",
) -> list[Tool]:
    """For every chat-enabled tracker in ``config``, enumerate its MCP tools
    and surface each as `<slug>__<tool>` Chat tool. Round-robins across
    trackers up to ``_MAX_CHAT_TOOLS`` to keep the token budget bounded.
    """
    if registry is None or config is None:
        return []

    chat_ids = registry.chat_enabled_ids(config)
    if not chat_ids:
        return []

    by_id = {t["id"]: t for t in (config.trackers or [])}
    # 1. Materialise each tracker's tool list (with the slug + label).
    per_tracker: list[tuple[str, str, str, list]] = []  # (tid, slug, label, tools)
    failed: list[tuple[str, str, str]] = []  # (tid, label, error) for chat-enabled but unreachable
    taken: set[str] = set()
    for tid in chat_ids:
        entry = by_id.get(tid)
        if entry is None:
            continue
        label = entry.get("label") or tid
        try:
            # Chat passthrough is a background path — never open a browser
            # mid-build. If OAuth refresh fails, the tracker is reported
            # back to the UI as "needs re-auth" via tracker_chat_unreachable.
            tracker = await registry.ensure_session(
                entry, workspace_name=workspace_name, interactive_oauth=False,
            )
            await tracker._ensure_started()
            resp = await tracker._session.list_tools()
            tools = list(getattr(resp, "tools", []) or [])
        except (Exception, BaseExceptionGroup) as exc:  # noqa: BLE001 — degrade per-tracker, continue
            # See the matching catch in build_mcp_passthrough_tools for why
            # BaseExceptionGroup is included: anyio wraps the OAuth-time
            # InteractiveOAuthRequired in a BaseExceptionGroup that bypasses
            # plain `except Exception`.
            from meeting_helper.trackers.tracker import InteractiveOAuthRequired
            if _contains_exception(exc, InteractiveOAuthRequired):
                err = "needs re-authentication (click Connect)"
            else:
                err = f"{type(exc).__name__}: {exc}"[:200]
            logger.warning(
                "mcp_passthrough_multi: list_tools failed for tracker %s (%s) — chat will skip it: %s",
                tid, label, err,
            )
            failed.append((tid, label, err))
            # A failed ensure_session may have inserted a half-built Tracker
            # into the registry. Evict it so the next chat turn doesn't keep
            # re-using a broken session that re-raises every time.
            try:
                await registry.shutdown(tid)
            except Exception:
                pass
            continue
        # Only reserve a slug after we know the tracker is going to contribute
        # tools — keeps slug numbering deterministic across boot retries.
        slug = slugify_unique(label, taken)
        per_tracker.append((tid, slug, label, tools))

    # Summary log + WS broadcast so the user can SEE when a chat-enabled
    # tracker is silently dropping out (otherwise "chat only searches one
    # account" looks like a code bug when it's actually an unbooted session
    # in the daemon). The broadcast is fire-and-forget — failing to broadcast
    # must NEVER break chat itself.
    logger.info(
        "mcp_passthrough_multi: %d/%d chat-enabled trackers reachable (failed: %s)",
        len(per_tracker), len(chat_ids),
        [f"{tid}({err})" for tid, _label, err in failed] or "none",
    )
    if failed:
        try:
            from meeting_helper.server.websocket import broadcast
            await broadcast({
                "type": "tracker_chat_unreachable",
                "trackers": [{"tracker_id": tid, "label": label, "error": err}
                             for tid, label, err in failed],
            })
        except Exception:
            pass

    # 2. Round-robin pick up to _MAX_CHAT_TOOLS across all trackers.
    out: list[Tool] = []
    cursors = [0] * len(per_tracker)
    while len(out) < _MAX_CHAT_TOOLS:
        # The build succeeded for at least one tracker — clear the
        # "needs re-auth" flag for THOSE trackers (a per-tracker flag would
        # be richer; for now we clear the global hint if any tracker booted).
        try:
            from meeting_helper.state import state as _state
            if per_tracker:
                _state.tracker_needs_reauth = None
        except Exception:
            pass
        progressed = False
        for i, (tid, slug, label, tools) in enumerate(per_tracker):
            if cursors[i] >= len(tools):
                continue
            t = tools[cursors[i]]
            cursors[i] += 1
            progressed = True
            name = getattr(t, "name", "") or ""
            if not name or name in _HAND_WRAPPED:
                continue
            schema = getattr(t, "inputSchema", None) or {"type": "object", "properties": {}}
            description = (getattr(t, "description", "") or "").strip()
            chat_name = f"{slug}{_SLUG_SEP}{name}"
            out.append(_build_passthrough_tool_for_tracker(
                chat_name=chat_name, mcp_name=name, description=description,
                schema=schema, tracker_id=tid, label=label,
            ))
            if len(out) >= _MAX_CHAT_TOOLS:
                break
        if not progressed:
            break
    return out
