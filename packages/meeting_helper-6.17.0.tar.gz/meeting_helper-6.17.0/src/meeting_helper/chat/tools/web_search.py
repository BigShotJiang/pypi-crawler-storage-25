"""`web.search` agent tool - Brave or Tavily."""
from __future__ import annotations

import aiohttp

from meeting_helper.chat.registry import Tool

_BRAVE_URL = "https://api.search.brave.com/res/v1/web/search"
_TAVILY_URL = "https://api.tavily.com/search"


async def _brave_search(q: str, key: str, limit: int) -> list[dict[str, str]]:
    async with aiohttp.ClientSession() as session:
        async with session.get(
            _BRAVE_URL,
            params={"q": q, "count": limit},
            headers={"X-Subscription-Token": key, "Accept": "application/json"},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as r:
            r.raise_for_status()
            data = await r.json()
    out: list[dict[str, str]] = []
    for item in (data.get("web", {}).get("results") or [])[:limit]:
        out.append(
            {
                "title": item.get("title", ""),
                "url": item.get("url", ""),
                "snippet": item.get("description", ""),
            }
        )
    return out


async def _tavily_search(q: str, key: str, limit: int) -> list[dict[str, str]]:
    async with aiohttp.ClientSession() as session:
        async with session.post(
            _TAVILY_URL,
            json={"api_key": key, "query": q, "max_results": limit},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as r:
            r.raise_for_status()
            data = await r.json()
    return [
        {
            "title": h.get("title", ""),
            "url": h.get("url", ""),
            "snippet": h.get("content", ""),
        }
        for h in data.get("results", [])[:limit]
    ]


async def _run(args, ctx):
    cfg = ctx.get("config")
    if (
        cfg is None
        or not getattr(cfg, "web_search_provider", None)
        or not getattr(cfg, "web_search_api_key", None)
    ):
        return {"status": "not_configured"}
    q = (args.get("q") or "").strip()
    if not q:
        return {"status": "error", "error": "q is required"}
    limit = int(args.get("limit", 5))
    try:
        if cfg.web_search_provider == "brave":
            results = await _brave_search(q, cfg.web_search_api_key, limit)
        elif cfg.web_search_provider == "tavily":
            results = await _tavily_search(q, cfg.web_search_api_key, limit)
        else:
            return {
                "status": "error",
                "error": f"unsupported provider: {cfg.web_search_provider}",
            }
    except Exception as exc:
        return {"status": "error", "error": str(exc)}
    return {"status": "ok", "result": {"results": results}}


def build_web_search() -> Tool:
    return Tool(
        name="web.search",
        description="Search the web (Brave or Tavily, depending on user config).",
        input_schema={"q": "string", "limit": "integer?"},
        run=_run,
    )
