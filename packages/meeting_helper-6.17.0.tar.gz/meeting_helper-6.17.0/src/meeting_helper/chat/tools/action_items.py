"""Chat agent tools for action items.

Each tool wraps the in-process logic that backs the HTTP routes so there's
exactly one source of truth for persistence. The chat agent has full
autonomy over the workspace's action items (read, create, edit, complete,
delete) — the user expects it to operate freely without prompting on every
mutation. Multi-delete is the one explicit exception: the description on
``action_items.delete`` asks the agent to confirm before bulk deletes.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from meeting_helper.action_items import models, store
from meeting_helper.chat.registry import Tool


def _resolve_paths(ctx: dict[str, Any]) -> tuple[Path, Path]:
    """Return ``(recordings_dir, workspace_json_path)``.

    Overridable in tests via ``monkeypatch.setattr``. Production callers must
    supply ``ctx["config"]`` (AppConfig) and ``ctx["disk"]`` (file-backed
    Config) — the chat dispatcher seeds those when it builds the tool ctx.
    """
    cfg = ctx.get("config")
    disk = ctx.get("disk")
    if cfg is None or disk is None:
        raise RuntimeError("chat tool ctx missing config/disk")
    return Path(cfg.recordings_dir), Path(disk.config_path)


def _locate(recordings: Path, ws_json: Path, item_id: str):
    """Find an item by id across every sidecar + the orphan list.

    Returns ``(meeting_id_or_None, items_list, index)``. Raises ``KeyError``
    when the id isn't found. Delegates to the route handler helper so the
    chat path and HTTP path share one source of truth.
    """
    from meeting_helper.server.routes import _locate_item

    return _locate_item(recordings, ws_json, item_id)


async def _list(args, ctx):
    recordings, ws_json = _resolve_paths(ctx)
    # Offload disk glob+reads from the asyncio loop (ticket #25).
    items = await store.list_all_async(ws_json, recordings)
    if args.get("meeting_id"):
        items = [i for i in items if i.get("meeting_id") == args["meeting_id"]]
    status = args.get("status", "open")
    if status == "open":
        items = [i for i in items if not i.get("completed")]
    elif status == "completed":
        items = [i for i in items if i.get("completed")]
    # status == "all" -> no filter
    return {"status": "ok", "result": {"items": items}}


async def _create(args, ctx):
    recordings, ws_json = _resolve_paths(ctx)
    title = (args.get("title") or "").strip()
    if not title:
        return {"status": "error", "error": "title required"}
    item = models.new_item(
        title=title,
        description=(args.get("description") or "").strip(),
        meeting_id=args.get("meeting_id"),
        source="manual",
    )
    if item["meeting_id"]:
        existing = store.load(recordings, item["meeting_id"])
        existing.append(item)
        store.save(recordings, item["meeting_id"], existing)
    else:
        existing = store.load_orphans(ws_json)
        existing.append(item)
        store.save_orphans(ws_json, existing)
    return {"status": "ok", "result": {"item": item}}


async def _update(args, ctx):
    recordings, ws_json = _resolve_paths(ctx)
    item_id = args.get("id")
    if not item_id:
        return {"status": "error", "error": "id required"}
    try:
        meeting_id, items, idx = _locate(recordings, ws_json, item_id)
    except KeyError:
        return {"status": "error", "error": "not found"}
    item = items[idx]
    if "title" in args:
        t = (args["title"] or "").strip()
        if not t:
            return {"status": "error", "error": "title required"}
        item["title"] = t
    if "description" in args:
        item["description"] = (args["description"] or "").strip()
    if "completed" in args:
        new_completed = bool(args["completed"])
        if new_completed != item.get("completed", False):
            item["completed"] = new_completed
            item["completed_at"] = models._now() if new_completed else None
    item["updated_at"] = models._now()
    if meeting_id:
        store.save(recordings, meeting_id, items)
    else:
        store.save_orphans(ws_json, items)
    return {"status": "ok", "result": {"item": item}}


async def _complete(args, ctx):
    return await _update({"id": args.get("id"), "completed": True}, ctx)


async def _delete(args, ctx):
    recordings, ws_json = _resolve_paths(ctx)
    item_id = args.get("id")
    if not item_id:
        return {"status": "error", "error": "id required"}
    try:
        meeting_id, items, idx = _locate(recordings, ws_json, item_id)
    except KeyError:
        return {"status": "error", "error": "not found"}
    del items[idx]
    if meeting_id:
        store.save(recordings, meeting_id, items)
    else:
        store.save_orphans(ws_json, items)
    return {"status": "ok", "result": {"ok": True}}


def build_list_action_items() -> Tool:
    return Tool(
        name="action_items.list",
        description=(
            "List action items. Optional `meeting_id` filter. `status` is one "
            "of 'open' (default), 'completed', 'all'. You have full autonomy "
            "over these items: the user expects you to read, create, edit, "
            "and complete them freely. When deleting more than one in a "
            "single turn, ask the user to confirm first."
        ),
        input_schema={"meeting_id": "string?", "status": "string?"},
        run=_list,
    )


def build_create_action_item() -> Tool:
    return Tool(
        name="action_items.create",
        description=(
            "Create a new action item. Title required, description optional. "
            "Pass `meeting_id` to attach the item to a specific meeting; omit "
            "to store as a workspace-level orphan."
        ),
        input_schema={
            "meeting_id": "string?",
            "title": "string",
            "description": "string?",
        },
        run=_create,
        is_mutation=True,
    )


def build_update_action_item() -> Tool:
    return Tool(
        name="action_items.update",
        description=(
            "Update an action item by id. Any of title, description, "
            "completed."
        ),
        input_schema={
            "id": "string",
            "title": "string?",
            "description": "string?",
            "completed": "boolean?",
        },
        run=_update,
        is_mutation=True,
    )


def build_complete_action_item() -> Tool:
    return Tool(
        name="action_items.complete",
        description=(
            "Mark an action item as completed. Sugar for action_items.update "
            "with completed=true."
        ),
        input_schema={"id": "string"},
        run=_complete,
        is_mutation=True,
    )


def build_delete_action_item() -> Tool:
    return Tool(
        name="action_items.delete",
        description=(
            "Delete an action item by id. When you plan to delete more than "
            "one in a single turn, ask the user for confirmation before "
            "calling."
        ),
        input_schema={"id": "string"},
        run=_delete,
        is_mutation=True,
    )
