"""Memory tools — agent reads/writes its own long-term notes."""
from __future__ import annotations

from meeting_helper.chat import memory as chat_memory
from meeting_helper.chat.registry import Tool


async def _read_all(args, ctx):
    return {"status": "ok", "result": {"entries": chat_memory.read_all()}}


async def _add(args, ctx):
    text = (args.get("text") or "").strip()
    if not text:
        return {"status": "error", "error": "text is required"}
    pinned = bool(args.get("pinned", False))
    entry = chat_memory.add(text=text, source="agent", pinned=pinned)
    return {"status": "ok", "result": entry}


async def _update(args, ctx):
    mem_id = args.get("id")
    if not mem_id:
        return {"status": "error", "error": "id is required"}
    text = args.get("text")
    pinned = args.get("pinned")
    entry = chat_memory.update(mem_id, text=text, pinned=pinned)
    if entry is None:
        return {"status": "error", "error": "memory entry not found"}
    return {"status": "ok", "result": entry}


async def _delete(args, ctx):
    mem_id = args.get("id")
    if not mem_id:
        return {"status": "error", "error": "id is required"}
    ok = chat_memory.delete(mem_id)
    if not ok:
        return {"status": "error", "error": "memory entry not found"}
    return {"status": "ok", "result": {"deleted": mem_id}}


def build_memory_read() -> Tool:
    return Tool(
        name="memory.read_all",
        description="Read every long-term memory entry for this workspace. Always cheap; use it at the start of a turn when relevant context might help.",
        input_schema={},
        run=_read_all,
    )


def build_memory_add() -> Tool:
    return Tool(
        name="memory.add",
        description=(
            "Save a fact / preference / piece of context to long-term memory. "
            "Use when the user shares something durable about themselves, their team, "
            "ongoing projects, or how they want you to behave. Avoid logging ephemeral chat content."
        ),
        input_schema={"text": "string", "pinned": "boolean?"},
        run=_add,
    )


def build_memory_update() -> Tool:
    return Tool(
        name="memory.update",
        description="Modify an existing memory entry by id (refine wording, pin/unpin).",
        input_schema={"id": "string", "text": "string?", "pinned": "boolean?"},
        run=_update,
    )


def build_memory_delete() -> Tool:
    return Tool(
        name="memory.delete",
        description="Remove a memory entry when it's wrong or no longer relevant.",
        input_schema={"id": "string"},
        run=_delete,
    )
