"""`meeting.live` tool - returns current transcript window + topic."""
from __future__ import annotations

from typing import Any

from meeting_helper.chat.registry import Tool

_WINDOW_SECONDS = 60.0


async def _run(args: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
    app_state = ctx.get("app_state")
    if not app_state or not getattr(app_state, "session_active", False):
        return {"status": "no_meeting_active"}
    sentences: list[dict[str, Any]] = []
    for buf, role in (
        (getattr(app_state, "self_buffer", None), "self"),
        (getattr(app_state, "other_buffer", None), "other"),
    ):
        if buf is None:
            continue
        for s in buf.all_sentences():
            sentences.append(
                {
                    "text": s.get("text", ""),
                    "ts": s.get("ts", 0.0),
                    "role": role,
                }
            )
    sentences.sort(key=lambda s: s["ts"])
    # Keep the last 60 seconds.
    if sentences:
        cutoff = sentences[-1]["ts"] - _WINDOW_SECONDS
        sentences = [s for s in sentences if s["ts"] >= cutoff]
    return {
        "status": "ok",
        "result": {
            "recent_transcript": sentences,
            "current_topic": getattr(app_state, "current_topic", None),
            "current_topic_cards": getattr(app_state, "current_topic_cards", []),
        },
    }


def build_meeting_live_tool() -> Tool:
    return Tool(
        name="meeting.live",
        description=(
            "Get the live meeting context (last 60s of transcript and current topic). "
            "Returns status=no_meeting_active when no meeting is recording."
        ),
        input_schema={},
        run=_run,
        is_mutation=False,
    )


async def _full_run(args: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
    app_state = ctx.get("app_state")
    if not app_state or not getattr(app_state, "session_active", False):
        return {"status": "no_meeting_active"}
    sentences: list[dict[str, Any]] = []
    for buf, role in (
        (getattr(app_state, "self_buffer", None), "self"),
        (getattr(app_state, "other_buffer", None), "other"),
    ):
        if buf is None:
            continue
        for s in buf.all_sentences():
            sentences.append(
                {
                    "text": s.get("text", ""),
                    "ts": s.get("ts", 0.0),
                    "role": role,
                }
            )
    sentences.sort(key=lambda s: s["ts"])
    return {
        "status": "ok",
        "result": {
            "full_transcript": sentences,
            "current_topic": getattr(app_state, "current_topic", None),
            "current_topic_cards": getattr(app_state, "current_topic_cards", []),
            "session_started_at": getattr(app_state, "started_at", None),
            "meeting_info": _meeting_info_brief(
                getattr(app_state, "meeting_info", None)
            ),
        },
    }


def _meeting_info_brief(info):
    if info is None:
        return None
    try:
        return {
            "app_name": getattr(info, "app_name", None),
            "meeting_name": getattr(info, "meeting_name", None),
        }
    except Exception:
        return None


def build_meeting_full_transcript_tool() -> Tool:
    return Tool(
        name="meeting.full_transcript",
        description=(
            "Get the FULL buffered transcript for the active meeting (no 60s window). "
            "Use this when the user asks about something said earlier in the meeting, "
            "or to summarise the meeting so far. For just the latest seconds, prefer "
            "meeting.live which is cheaper."
        ),
        input_schema={},
        run=_full_run,
    )
