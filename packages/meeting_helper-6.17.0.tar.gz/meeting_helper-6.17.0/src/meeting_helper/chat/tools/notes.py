"""Notes CRUD + KB toggle + pin/unpin agent tools.

These wrap the same on-disk storage that the `/library/note*` HTTP handlers
use: notes are `*.note.md` files in `cfg.recordings_dir`, with KB and
favorite membership tracked on the workspace `Config`. The tools call
`get_config()` directly (the file-backed singleton) because they touch
disk artifacts. Route handlers, by contrast, must read
`request.app["disk"]` and never call `get_config()`.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any
from urllib.parse import quote

from meeting_helper.chat.registry import Tool


def _safe_note_filename(raw: str) -> str | None:
    """Normalize a note id to a `*.note.md` basename; reject traversal."""
    if not raw:
        return None
    name = raw if raw.endswith(".note.md") else f"{raw}.note.md"
    if "/" in name or "\\" in name or ".." in name:
        return None
    return name


def list_notes_for(cfg) -> dict[str, Any]:
    """Build the notes-list payload from any config-like object.

    Accepts either the file-backed `Config` singleton (chat-tool callers)
    or `request.app["disk"]` from a route handler (so test-mode shims work
    end-to-end). Returns the `{notes: [...]}` payload directly - the chat
    tool wraps it in the {status, result} envelope.
    """
    from meeting_helper.state import state

    rec_dir = Path(cfg.recordings_dir)
    if not rec_dir.is_dir():
        return {"notes": []}

    pinned_ids = {p.id for p in state.pinned_topics if p.kind == "note"}
    notes: list[dict[str, Any]] = []
    for path in sorted(rec_dir.glob("*.note.md")):
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        notes.append({
            "id": path.name,
            "title": path.stem.removesuffix(".note").replace("-", " "),
            "mtime": mtime,
            "in_kb": cfg.is_kb(path.name),
            "favorited": cfg.is_favorite(path.name),
            "pinned": path.name in pinned_ids,
            "url": f"/notes/?id={quote(path.name)}",
        })
    notes.sort(key=lambda n: n["mtime"], reverse=True)
    return {"notes": notes}


async def _list(_args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.config import get_config

    return {"status": "ok", "result": list_notes_for(get_config())}


async def _get(args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.config import get_config

    name = _safe_note_filename(str(args.get("id") or ""))
    if name is None:
        return {"status": "error", "error": "id must be a *.note.md basename"}

    cfg = get_config()
    path = Path(cfg.recordings_dir) / name
    if not path.is_file():
        return {"status": "error", "error": f"note not found: {name}"}
    body = await asyncio.to_thread(path.read_text, errors="ignore")
    return {
        "status": "ok",
        "result": {
            "id": name,
            "title": name.removesuffix(".note.md").replace("-", " "),
            "body": body,
            "url": f"/notes/?id={quote(name)}",
        },
    }


def _slug_base(title: str) -> str:
    """Kebab-case slug, fallback 'note'. No collision suffix here."""
    import re
    return re.sub(r"[^a-zA-Z0-9]+", "-", title.strip().lower()).strip("-") or "note"


def _atomic_rename(rec_dir: Path, old_name: str, new_base: str) -> str:
    """Rename `<old_name>` to `<new_base>.note.md` (or `-2`, `-3`, ...) atomically.

    Uses os.link + os.unlink so a concurrent file at the target name causes
    FileExistsError instead of an overwrite (which os.rename would do
    silently on POSIX). If the new base matches the existing slug, returns
    `old_name` unchanged. Returns the final filename.
    """
    import os
    old_path = rec_dir / old_name
    i = 1
    while True:
        candidate = new_base if i == 1 else f"{new_base}-{i}"
        new_filename = f"{candidate}.note.md"
        if new_filename == old_name:
            return old_name
        new_path = rec_dir / new_filename
        try:
            os.link(str(old_path), str(new_path))
        except FileExistsError:
            i += 1
            continue
        try:
            os.unlink(str(old_path))
        except OSError:
            # Unlink failed after a successful link - clean up the new
            # entry so we don't leave a duplicate.
            try:
                os.unlink(str(new_path))
            except OSError:
                pass
            raise
        return new_filename


def _atomic_create(rec_dir: Path, base: str, body: str) -> str:
    """Create `<base>.note.md` (or `<base>-2`, `-3`, ...) atomically.

    Uses O_CREAT|O_EXCL so a concurrent caller picking the same slug
    fails with FileExistsError and we retry with the next suffix instead
    of silently overwriting (which a check-then-write loop allows).
    Returns the final filename.
    """
    import os
    i = 1
    while True:
        candidate = base if i == 1 else f"{base}-{i}"
        filename = f"{candidate}.note.md"
        path = rec_dir / filename
        try:
            fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        except FileExistsError:
            i += 1
            continue
        try:
            with os.fdopen(fd, "w") as f:
                f.write(body)
        except Exception:
            try:
                path.unlink()
            except OSError:
                pass
            raise
        return filename


async def _create(args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.config import get_config

    title = str(args.get("title") or "").strip()
    body = str(args.get("body") or "")
    in_kb = bool(args.get("in_kb", False))
    if not title:
        return {"status": "error", "error": "title required"}

    cfg = get_config()
    rec_dir = Path(cfg.recordings_dir)
    rec_dir.mkdir(parents=True, exist_ok=True)
    base = _slug_base(title)
    filename = await asyncio.to_thread(_atomic_create, rec_dir, base, body)
    if in_kb:
        cfg.add_kb(filename)
        cfg.save()
    return {
        "status": "ok",
        "result": {"id": filename, "title": title, "url": f"/notes/?id={quote(filename)}"},
    }


async def _update(args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.config import get_config

    name = _safe_note_filename(str(args.get("id") or ""))
    if name is None:
        return {"status": "error", "error": "id must be a *.note.md basename"}

    cfg = get_config()
    rec_dir = Path(cfg.recordings_dir)
    path = rec_dir / name
    if not path.is_file():
        return {"status": "error", "error": f"note not found: {name}"}

    new_title = args.get("title")
    new_body = args.get("body")

    if new_body is not None:
        await asyncio.to_thread(path.write_text, str(new_body))

    if new_title is not None and str(new_title).strip():
        new_filename = await asyncio.to_thread(
            _atomic_rename, rec_dir, name, _slug_base(str(new_title)),
        )
        if new_filename != name:
            if cfg.is_kb(name):
                cfg.remove_kb(name)
                cfg.add_kb(new_filename)
            if cfg.is_favorite(name):
                cfg.remove_favorite(name)
                cfg.add_favorite(new_filename)
            cfg.save()
        return {
            "status": "ok",
            "result": {
                "id": new_filename,
                "title": str(new_title),
                "url": f"/notes/?id={quote(new_filename)}",
            },
        }

    return {"status": "ok", "result": {"id": name, "url": f"/notes/?id={quote(name)}"}}


async def _set_kb(args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.config import get_config

    name = _safe_note_filename(str(args.get("id") or ""))
    if name is None:
        return {"status": "error", "error": "id must be a *.note.md basename"}
    value = bool(args.get("value"))

    cfg = get_config()
    path = Path(cfg.recordings_dir) / name
    if not path.is_file():
        return {"status": "error", "error": f"note not found: {name}"}

    if value:
        cfg.add_kb(name)
    else:
        cfg.remove_kb(name)
    cfg.save()
    return {"status": "ok", "result": {"id": name, "in_kb": value}}


async def _delete(args: dict, ctx) -> dict[str, Any]:
    from meeting_helper.config import get_config

    name = _safe_note_filename(str(args.get("id") or ""))
    if name is None:
        return {"status": "error", "error": "id must be a *.note.md basename"}

    cfg = get_config()
    path = Path(cfg.recordings_dir) / name
    if path.is_file():
        await asyncio.to_thread(path.unlink)
    if cfg.is_kb(name):
        cfg.remove_kb(name)
    if cfg.is_favorite(name):
        cfg.remove_favorite(name)
    cfg.save()
    return {"status": "ok", "result": {"deleted": True}}


def build_notes_list() -> Tool:
    return Tool(
        name="notes.list",
        description=(
            "List every note in the active workspace. Returns id, title, "
            "in_kb, favorited, pinned (whether currently in the Copilot topic "
            "basket), and a deep-link URL into the /notes UI. Use notes.get "
            "to fetch a single note's body."
        ),
        input_schema={},
        run=_list,
    )


def build_notes_get() -> Tool:
    return Tool(
        name="notes.get",
        description=(
            "Fetch the full body of one note. id is the .note.md basename "
            "(get this from notes.list). Replaces library.get_note for new "
            "callers; library.get_note remains a one-release alias."
        ),
        input_schema={"id": "string"},
        run=_get,
    )


def build_notes_create() -> Tool:
    return Tool(
        name="notes.create",
        description=(
            "Create a new note. title required, body optional, in_kb default "
            "false. The agent has full authority over notes; create freely "
            "when the user asks."
        ),
        input_schema={"title": "string", "body": "string?", "in_kb": "boolean?"},
        run=_create,
        is_mutation=True,
    )


def build_notes_update() -> Tool:
    return Tool(
        name="notes.update",
        description=(
            "Update an existing note's body and/or title. When title changes, "
            "the file is renamed via slug and KB/favorite entries migrate "
            "automatically. Returns the (possibly new) id."
        ),
        input_schema={"id": "string", "title": "string?", "body": "string?"},
        run=_update,
        is_mutation=True,
    )


def build_notes_delete() -> Tool:
    return Tool(
        name="notes.delete",
        description=(
            "Delete a note. KB and favorite entries are cleaned up. When "
            "deleting more than one in a single turn, ask the user to "
            "confirm first."
        ),
        input_schema={"id": "string"},
        run=_delete,
        is_mutation=True,
    )


def build_notes_set_kb() -> Tool:
    return Tool(
        name="notes.set_kb",
        description=(
            "Mark a note as KB (Knowledge Base) or unmark it. KB-flagged "
            "notes get pulled into Copilot context by the retrieval ranker "
            "during meetings."
        ),
        input_schema={"id": "string", "value": "boolean"},
        run=_set_kb,
        is_mutation=True,
    )
