"""Thread + index persistence — JSON on disk, transactional writes."""
from __future__ import annotations

import json
import secrets
from datetime import datetime, timezone
from typing import Any

from meeting_helper.chat import paths as chat_paths
from meeting_helper.chat.paths import atomic_write_json
from meeting_helper.chat.models import Thread, Turn


def _now() -> str:
    # Microsecond precision so rapidly-created threads sort deterministically.
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _new_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(8)}"


def read_index() -> list[dict[str, Any]]:
    p = chat_paths.index_path()
    if not p.exists():
        return []
    return json.loads(p.read_text() or "[]")


def _write_index(entries: list[dict[str, Any]]) -> None:
    entries = sorted(entries, key=lambda e: e.get("updated_at", ""), reverse=True)
    atomic_write_json(chat_paths.index_path(), entries)


def _upsert_index(entry: dict[str, Any]) -> None:
    idx = [e for e in read_index() if e["id"] != entry["id"]]
    idx.append(entry)
    _write_index(idx)


def create_thread(*, title: str) -> Thread:
    now = _now()
    th = Thread(id=_new_id("thr"), title=title, created_at=now, updated_at=now, turns=[])
    atomic_write_json(chat_paths.thread_path(th.id), th.to_dict())
    _upsert_index({"id": th.id, "title": th.title, "updated_at": th.updated_at, "msg_count": 0})
    return th


def read_thread(thread_id: str) -> Thread:
    p = chat_paths.thread_path(thread_id)
    if not p.exists():
        raise FileNotFoundError(thread_id)
    return Thread.from_dict(json.loads(p.read_text()))


def append_turn(
    thread_id: str,
    *,
    role: str,
    text: str | None = None,
    tool_name: str | None = None,
    tool_args: dict[str, Any] | None = None,
    tool_result: dict[str, Any] | None = None,
    provider: str | None = None,
    model: str | None = None,
    latency_ms: int | None = None,
) -> Turn:
    th = read_thread(thread_id)
    turn = Turn(
        id=_new_id("tur"),
        role=role,  # type: ignore[arg-type]
        created_at=_now(),
        text=text,
        tool_name=tool_name,
        tool_args=tool_args,
        tool_result=tool_result,
        provider=provider,
        model=model,
        latency_ms=latency_ms,
    )
    th.turns.append(turn)
    th.updated_at = turn.created_at
    atomic_write_json(chat_paths.thread_path(thread_id), th.to_dict())
    _upsert_index({
        "id": th.id,
        "title": th.title,
        "updated_at": th.updated_at,
        "msg_count": len(th.turns),
    })
    return turn


def rename_thread(thread_id: str, new_title: str) -> None:
    th = read_thread(thread_id)
    th.title = new_title
    th.updated_at = _now()
    atomic_write_json(chat_paths.thread_path(thread_id), th.to_dict())
    _upsert_index({
        "id": th.id,
        "title": th.title,
        "updated_at": th.updated_at,
        "msg_count": len(th.turns),
    })


def delete_thread(thread_id: str) -> None:
    p = chat_paths.thread_path(thread_id)
    if p.exists():
        p.unlink()
    _write_index([e for e in read_index() if e["id"] != thread_id])


def set_thread_model(
    thread_id: str,
    *,
    provider: str | None,
    model: str | None,
) -> Thread:
    """Update a thread's AI override. Pass ``None`` for either field to
    fall back to the workspace's default.

    Both fields are independently optional — e.g. set ``provider="gemini"``
    with ``model=None`` to use Gemini's default model for this thread.
    """
    th = read_thread(thread_id)
    th.provider = provider if provider else None
    th.model = model if model else None
    th.updated_at = _now()
    atomic_write_json(chat_paths.thread_path(thread_id), th.to_dict())
    return th
