"""Speaker-label persistence + render-time substitution.

The canonical label keys in storage and on the wire are ``SELF`` for the
local microphone stream and ``OTHER#N`` for the Nth Deepgram-diarized
speaker on the system-audio stream. Undiarized OTHER lines (no
diarization, or words without speaker ids) get the bare ``OTHER`` label.

Sidecar JSON lives alongside the MP3 as ``<id>.speakers.json``. We keep
``.live.txt`` / ``.transcript.txt`` / ``.summary.txt`` pristine and
substitute labels at read time so the user can re-name freely without
losing the original transcript.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

_SIDECAR_VERSION = 1

# Matches a role label at the start of a transcript line, after the
# timestamp and colon-space: ``[mm:ss] LABEL: text``.
_LABEL_RE = re.compile(
    r"(?m)^(\[(?:\d+:)?\d{1,2}:\d{2}\] )(SELF(?:#\d+)?|OTHER(?:#\d+)?)(: )"
)
# Plain extractor for label discovery — anywhere a label-shaped token sits
# after the timestamp prefix.
_LABEL_DISCOVERY_RE = re.compile(
    r"(?m)^\[(?:\d+:)?\d{1,2}:\d{2}\] (SELF(?:#\d+)?|OTHER(?:#\d+)?):"
)


@dataclass
class SpeakerMap:
    names: dict[str, str | None] = field(default_factory=dict)
    evidence: dict[str, str] = field(default_factory=dict)
    source: dict[str, str] = field(default_factory=dict)  # "manual" | "ai"

    def as_payload(self) -> dict:
        return {
            "version": _SIDECAR_VERSION,
            "names": dict(self.names),
            "evidence": dict(self.evidence),
            "source": dict(self.source),
        }


def speakers_path_for(mp3_path: Path) -> Path:
    """Sidecar path for a given MP3."""
    return mp3_path.with_suffix(".speakers.json")


def read_speaker_map(path: Path) -> SpeakerMap:
    if not path.is_file():
        return SpeakerMap()
    try:
        data = json.loads(path.read_text())
    except Exception as exc:
        logger.warning("speakers: failed to read %s: %s", path, exc)
        return SpeakerMap()
    if not isinstance(data, dict):
        return SpeakerMap()
    return SpeakerMap(
        names={str(k): (v if v is None else str(v)) for k, v in (data.get("names") or {}).items()},
        evidence={str(k): str(v) for k, v in (data.get("evidence") or {}).items() if v},
        source={str(k): str(v) for k, v in (data.get("source") or {}).items()},
    )


def write_speaker_map(
    path: Path,
    *,
    names: dict[str, str | None],
    evidence: dict[str, str] | None = None,
    source: dict[str, str] | None = None,
) -> None:
    payload = SpeakerMap(
        names=dict(names),
        evidence=dict(evidence or {}),
        source=dict(source or {}),
    ).as_payload()
    path.write_text(json.dumps(payload, indent=2, sort_keys=True))


def merge_speaker_map(existing: SpeakerMap, incoming: SpeakerMap) -> SpeakerMap:
    """Merge incoming entries into existing.

    Manual entries in ``existing`` are never overwritten. Every other
    entry (ai-sourced or null-name) yields to the incoming value.
    """
    out = SpeakerMap(
        names=dict(existing.names),
        evidence=dict(existing.evidence),
        source=dict(existing.source),
    )
    for label, name in incoming.names.items():
        if existing.source.get(label) == "manual":
            continue
        out.names[label] = name
        if label in incoming.evidence:
            out.evidence[label] = incoming.evidence[label]
        out.source[label] = incoming.source.get(label, "ai")
    return out


def extract_speaker_labels(text: str) -> list[str]:
    """Return the sorted distinct labels found in a transcript blob."""
    seen = set()
    for m in _LABEL_DISCOVERY_RE.finditer(text or ""):
        seen.add(m.group(1))
    def _key(label: str) -> tuple[int, int]:
        # SELF first, then OTHER (plain), then OTHER#N ascending.
        if label == "SELF":
            return (0, 0)
        if label == "OTHER":
            return (1, 0)
        if label.startswith("OTHER#"):
            try:
                return (2, int(label.split("#", 1)[1]))
            except ValueError:
                return (3, 0)
        return (4, 0)
    return sorted(seen, key=_key)


def apply_speaker_map(text: str, names: dict[str, str | None]) -> str:
    """Replace ``LABEL:`` at the start of each line with the mapped name.

    Null-valued mappings are skipped. Substitution is anchored to the
    timestamp prefix so the same label inside a sentence body is left
    untouched.
    """
    if not text or not names:
        return text
    def _sub(m: re.Match) -> str:
        prefix, label, colon = m.group(1), m.group(2), m.group(3)
        target = names.get(label)
        if not target:
            return m.group(0)
        return f"{prefix}{target}{colon}"
    return _LABEL_RE.sub(_sub, text)
