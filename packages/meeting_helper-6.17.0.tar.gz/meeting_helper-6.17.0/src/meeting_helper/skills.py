"""Per-workspace chat skills (named prompt blueprints).

A "skill" is a reusable, named blob of instructions the user can summon in
chat by typing ``/<name>``. The slash-picker in the composer filters the
list by substring and, on select, **replaces** the ``/foo`` token with the
skill body so the body itself becomes the user's prompt for that turn.

Two creation paths:
  * the Settings → Skills page (user CRUD), and
  * the ``skills.create`` chat tool the agent can invoke when the user
    says something like "save that as a skill called …".

Storage is a JSON list at ``<workspace_dir>/skills.json`` (alongside
``memory.json``). Each entry::

    {
      "id":          "skl_<hex>",
      "name":        "start-ticket",       # slugified slash trigger
      "description": "kick off a ticket",  # one-liner shown in picker
      "body":        "<full prompt text>",
      "created_at":  "ISO-8601",
      "updated_at":  "ISO-8601",
    }

`name` is normalized by :func:`_slugify` (lowercased, spaces -> hyphens,
non-`[a-z0-9-]` stripped, collapsed hyphens). Empty slugs and duplicates
are rejected up front so the slash trigger stays unambiguous.
"""
from __future__ import annotations

import json
import re
import secrets
from datetime import datetime, timezone
from typing import Any

from meeting_helper.chat import paths as chat_paths


def _skills_path():
    return chat_paths.chat_dir() / "skills.json"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


_SLUG_RE = re.compile(r"[^a-z0-9-]+")
_DASH_COLLAPSE_RE = re.compile(r"-{2,}")


def _slugify(name: str) -> str:
    """Normalise a user-typed skill name into a slash-safe trigger.

    Lowercases, swaps whitespace + underscores for hyphens, drops anything
    outside ``[a-z0-9-]``, then collapses runs of hyphens. Leading/trailing
    hyphens are trimmed. The result is what the slash-picker matches
    against — keep it tight so ``/start-ticket`` is unambiguous.
    """
    s = (name or "").strip().lower()
    s = re.sub(r"[\s_]+", "-", s)
    s = _SLUG_RE.sub("", s)
    s = _DASH_COLLAPSE_RE.sub("-", s)
    return s.strip("-")


class SkillError(ValueError):
    """Raised for validation errors (empty name, duplicate slug, missing body)."""


def read_all() -> list[dict[str, Any]]:
    p = _skills_path()
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text() or "[]")
    except json.JSONDecodeError:
        return []


def _write_all(entries: list[dict[str, Any]]) -> None:
    chat_paths.atomic_write_json(_skills_path(), entries)


def list_skills() -> list[dict[str, Any]]:
    return read_all()


def get_skill(skill_id: str) -> dict[str, Any] | None:
    for e in read_all():
        if e["id"] == skill_id:
            return e
    return None


def create_skill(*, name: str, description: str, body: str) -> dict[str, Any]:
    slug = _slugify(name)
    if not slug:
        raise SkillError("name is required")
    body_s = (body or "").strip()
    if not body_s:
        raise SkillError("body is required")
    desc_s = (description or "").strip()
    entries = read_all()
    if any(e["name"] == slug for e in entries):
        raise SkillError(f"a skill named '{slug}' already exists")
    entry = {
        "id": f"skl_{secrets.token_hex(6)}",
        "name": slug,
        "description": desc_s,
        "body": body_s,
        "created_at": _now(),
        "updated_at": _now(),
    }
    entries.append(entry)
    _write_all(entries)
    return entry


def update_skill(
    skill_id: str,
    *,
    name: str | None = None,
    description: str | None = None,
    body: str | None = None,
) -> dict[str, Any] | None:
    entries = read_all()
    target: dict[str, Any] | None = None
    for e in entries:
        if e["id"] == skill_id:
            target = e
            break
    if target is None:
        return None
    if name is not None:
        slug = _slugify(name)
        if not slug:
            raise SkillError("name is required")
        if any(e["name"] == slug and e["id"] != skill_id for e in entries):
            raise SkillError(f"a skill named '{slug}' already exists")
        target["name"] = slug
    if description is not None:
        target["description"] = description.strip()
    if body is not None:
        body_s = body.strip()
        if not body_s:
            raise SkillError("body cannot be empty")
        target["body"] = body_s
    target["updated_at"] = _now()
    _write_all(entries)
    return target


def delete_skill(skill_id: str) -> bool:
    entries = read_all()
    new = [e for e in entries if e["id"] != skill_id]
    if len(new) == len(entries):
        return False
    _write_all(new)
    return True
