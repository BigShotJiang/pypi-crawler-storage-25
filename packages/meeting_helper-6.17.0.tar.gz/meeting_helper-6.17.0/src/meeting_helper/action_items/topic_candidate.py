"""Match the current speech buffer against open action items.

The TopicWorker calls this in parallel with the existing ticket pick.
Whichever candidate wins (highest confidence) is broadcast as the topic.
"""
from __future__ import annotations

import json
from typing import Any, Optional, Protocol


class AIClient(Protocol):
    async def chat(self, messages: list[dict], **kwargs) -> str: ...


def _build_messages(buffer_text: str, items: list[dict[str, Any]]) -> list[dict]:
    catalog = "\n".join(
        f"- id={i['id']}: {i['title']}"
        + (f" ({i['description']})" if i.get("description") else "")
        for i in items
    )
    system = (
        "You decide whether the most recent speech is clearly about any one of "
        "the open action items below. Reply ONLY with JSON: "
        "{\"item_id\": <id or null>, \"confidence\": <0..1>}.\n\n"
        "Confidence scale, use it strictly:\n"
        "  0.0-0.4 = unrelated, ambiguous, or only a passing mention. ALWAYS "
        "return item_id=null in this range.\n"
        "  0.5-0.69 = the item is mentioned but is NOT the main subject. Still "
        "return item_id=null — leave the topic banner alone.\n"
        "  0.7-0.84 = the buffer clearly discusses this item as the main subject. "
        "Return its id.\n"
        "  0.85-1.0 = the item is explicitly named or the only plausible match. "
        "Return its id.\n\n"
        "Default to null. The Copilot's topic banner is already showing whatever "
        "the previous tick chose; you only override it when the new speech is "
        "unambiguously about an action item, not when it could be."
    )
    user = f"## Buffer\n{buffer_text}\n\n## Open action items\n{catalog}\n"
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]


async def match(
    buffer_text: str,
    open_items: list[dict[str, Any]],
    *,
    ai_client: AIClient,
) -> Optional[dict[str, Any]]:
    """Return ``{"item": <item>, "confidence": <float>}`` or ``None``.

    No match cases (return None):
      - empty pool, empty buffer
      - LLM returns invalid JSON or item_id=null
      - LLM returns an id that isn't in the pool (defends against hallucination)
    """
    if not open_items or not buffer_text.strip():
        return None
    raw = await ai_client.chat(_build_messages(buffer_text, open_items))
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None
    item_id = payload.get("item_id")
    if not item_id:
        return None
    try:
        confidence = float(payload.get("confidence") or 0.0)
    except (TypeError, ValueError):
        confidence = 0.0
    for item in open_items:
        if item["id"] == item_id:
            return {"item": item, "confidence": confidence}
    return None
