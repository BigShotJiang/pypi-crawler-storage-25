"""LLM-driven extraction of action items from a meeting bundle."""
from __future__ import annotations

import json
import re
from typing import Any, Protocol

from meeting_helper.action_items.models import new_item
from meeting_helper.ai.prompts import (
    build_action_items_extraction_messages,
    build_action_items_extraction_messages_strict,
)

MAX_ITEMS = 10
_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*(.*?)\s*```\s*$", re.DOTALL)


class ExtractionError(RuntimeError):
    pass


class AIClient(Protocol):
    async def chat(self, messages: list[dict], **kwargs) -> str: ...


def _strip_fence(text: str) -> str:
    m = _FENCE_RE.match(text)
    return m.group(1) if m else text


def _parse(raw: str) -> list[dict[str, Any]]:
    payload = json.loads(_strip_fence(raw))
    items = payload.get("items") if isinstance(payload, dict) else None
    if not isinstance(items, list):
        raise ValueError("items missing or not a list")
    out: list[dict[str, Any]] = []
    for entry in items[:MAX_ITEMS]:
        if not isinstance(entry, dict):
            continue
        title = (entry.get("title") or "").strip()
        if not title:
            continue
        out.append(
            {
                "title": title,
                "description": (entry.get("description") or "").strip(),
            }
        )
    return out


async def extract(bundle: dict, *, ai_client: AIClient) -> list[dict[str, Any]]:
    """Return a list of fully-stamped action item dicts (source=auto)."""
    meeting_id = bundle.get("id")

    try:
        raw = await ai_client.chat(build_action_items_extraction_messages(bundle))
        parsed = _parse(raw)
    except (ValueError, json.JSONDecodeError):
        try:
            raw = await ai_client.chat(
                build_action_items_extraction_messages_strict(bundle)
            )
            parsed = _parse(raw)
        except (ValueError, json.JSONDecodeError) as exc:
            raise ExtractionError(
                f"LLM returned non-JSON after retry: {exc}"
            ) from exc

    return [
        new_item(
            title=p["title"],
            description=p["description"],
            meeting_id=meeting_id,
            source="auto",
        )
        for p in parsed
    ]
