"""Action item domain types and helpers."""
from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Any, Literal

Source = Literal["auto", "manual"]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def new_item(
    *,
    title: str,
    description: str = "",
    meeting_id: str | None = None,
    source: Source = "manual",
) -> dict[str, Any]:
    """Build a fresh item with id + timestamps stamped."""
    now = _now()
    return {
        "id": f"ai_{secrets.token_hex(8)}",
        "meeting_id": meeting_id,
        "title": title,
        "description": description,
        "completed": False,
        "completed_at": None,
        "source": source,
        "created_at": now,
        "updated_at": now,
    }
