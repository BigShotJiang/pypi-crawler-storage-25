"""Read-only git helpers for the dev-mode repo code-context feature.

Everything shells out to ``git`` in read-only mode (diff, --stat, rev-parse).
Nothing writes. Used by the pinned-repo Load action to snapshot a branch's
PR-equivalent diff for injection into the Copilot prompt.
"""
from __future__ import annotations

import subprocess
from dataclasses import dataclass

# Full diff is injected verbatim only under this many chars. Larger diffs fall
# back to the --stat summary plus leading per-file diffs until the budget runs
# out, then a marker. Keeps a pinned diff from eating the prompt every turn.
DIFF_CHAR_CAP = 15_000


class GitContextError(Exception):
    """A git command failed in a way the user must see (not a repo, missing
    base ref, detached HEAD)."""


@dataclass
class DiffSnapshot:
    repo_path: str
    base: str
    branch: str
    head_sha: str
    stat: str
    body: str
    truncated: bool
    char_count: int


def _run(path: str, args: list[str]) -> str:
    try:
        proc = subprocess.run(
            ["git", "-C", path, *args],
            capture_output=True, text=True, timeout=20,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise GitContextError(str(exc)) from exc
    if proc.returncode != 0:
        raise GitContextError(proc.stderr.strip() or f"git {' '.join(args)} failed")
    return proc.stdout


def current_branch(path: str) -> str:
    out = _run(path, ["rev-parse", "--abbrev-ref", "HEAD"]).strip()
    return out or "(detached)"


def head_sha(path: str) -> str:
    return _run(path, ["rev-parse", "--short", "HEAD"]).strip()


def _resolve_base(path: str, base: str) -> str:
    # Prefer origin/<base> so the diff matches the remote PR view; fall back to
    # the local ref. Raises GitContextError if neither resolves.
    try:
        _run(path, ["rev-parse", "--verify", "--quiet", f"origin/{base}"])
        return f"origin/{base}"
    except GitContextError:
        _run(path, ["rev-parse", "--verify", "--quiet", base])
        return base


def _changed_files(path: str, ref: str) -> list[str]:
    out = _run(path, ["diff", "--name-only", f"{ref}...HEAD"])
    return [ln for ln in out.splitlines() if ln.strip()]


def _pack_under_cap(path: str, ref: str, stat: str, cap: int) -> tuple[str, bool]:
    intro = "## diff too large; summary + leading files below\n"
    marker = "\n[diff truncated. Ask about a specific file to see its full diff.]"
    # If the --stat summary alone blows the cap (thousands of changed files),
    # return a truncated summary rather than overrunning the budget.
    if len(intro) + len(stat) + len(marker) >= cap:
        keep = max(0, cap - len(intro) - len(marker))
        return intro + stat[:keep] + marker, True
    header = intro + stat + "\n\n"
    budget = cap - len(header) - len(marker)
    parts: list[str] = []
    used = 0
    for f in _changed_files(path, ref):
        d = _run(path, ["diff", f"{ref}...HEAD", "--", f])
        if used + len(d) > budget:
            break
        parts.append(d)
        used += len(d)
    return header + "".join(parts) + marker, True


def load_diff(path: str, base: str, *, cap: int = DIFF_CHAR_CAP) -> DiffSnapshot:
    """Snapshot the PR-equivalent diff ``git diff <base>...HEAD``.

    Always computes --stat. Includes the full diff when it fits under ``cap``;
    otherwise summary + leading per-file diffs + a marker.
    """
    branch = current_branch(path)
    sha = head_sha(path)
    ref = _resolve_base(path, base)
    stat = _run(path, ["diff", "--stat", f"{ref}...HEAD"]).strip()
    full = _run(path, ["diff", f"{ref}...HEAD"])
    if len(full) <= cap:
        body, truncated = full, False
    else:
        body, truncated = _pack_under_cap(path, ref, stat, cap)
    return DiffSnapshot(
        repo_path=path, base=base, branch=branch, head_sha=sha,
        stat=stat, body=body, truncated=truncated, char_count=len(body),
    )
