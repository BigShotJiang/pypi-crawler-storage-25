"""Append-only writer for `.live.txt` — a chronological conversation log.

Each finalized sentence becomes one line: ``[MM:SS] ROLE: text``. Times are
measured from ``t0`` (typically the moment recording started). For meetings
longer than an hour the format extends to ``[H:MM:SS]``.

Both transcribers (SELF / OTHER) share one writer; ``append`` is thread-safe.

Writes are off-loaded to a dedicated background thread. ``append`` does the
formatting (so the timestamp matches the call site) and then enqueues the
line — it never touches the file or calls ``flush``. This keeps the
transcriber thread off synchronous file I/O, which under disk pressure was
the single biggest source of "transcripts feel slow" since every listener
behind it on ``SentenceBuffer.append_final`` waited for ``fsync``.
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from pathlib import Path
from typing import Callable, Optional, TextIO

logger = logging.getLogger(__name__)

# Generous queue cap. A writer that's keeping up sees ~0–1 items at a time;
# the cap matters only when the disk is unresponsive. ~10 000 lines covers a
# multi-hour wedged disk before we start dropping. We log on every drop.
_QUEUE_MAX = 10_000


class LiveTranscriptWriter:
    def __init__(
        self,
        path: Path,
        t0: float,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._t0 = t0
        self._clock = clock
        self._path = path
        self._queue: queue.Queue[Optional[str]] = queue.Queue(maxsize=_QUEUE_MAX)
        self._fh: Optional[TextIO] = open(path, "a", encoding="utf-8")
        self._lock = threading.Lock()
        self._closed = False
        self._dropped = 0
        self._thread = threading.Thread(
            target=self._run, name="live-transcript-writer", daemon=True
        )
        self._thread.start()

    def append(self, role: str, text: str, speaker: int | None = None) -> None:
        text = text.strip()
        if not text:
            return
        with self._lock:
            if self._closed:
                return
        # Format on the calling thread so the timestamp reflects WHEN the
        # sentence finalized, not when the writer thread happens to drain it.
        elapsed = max(0, int(self._clock() - self._t0))
        h, rem = divmod(elapsed, 3600)
        m, s = divmod(rem, 60)
        ts = f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"
        label = f"{role}#{speaker}" if speaker is not None else role
        line = f"[{ts}] {label}: {text}\n"
        try:
            self._queue.put_nowait(line)
        except queue.Full:
            self._dropped += 1
            if self._dropped == 1 or self._dropped % 25 == 0:
                logger.warning(
                    "Live transcript writer queue full (%d lines dropped) — "
                    "disk likely unresponsive at %s",
                    self._dropped, self._path,
                )

    def _run(self) -> None:
        # Pulls lines off the queue and writes them. None is the close sentinel.
        # All file I/O lives in this thread; callers never block on flush.
        while True:
            try:
                item = self._queue.get()
            except Exception as exc:
                # Queue.get() shouldn't really raise, but if interpreter shutdown
                # races us, log and exit cleanly rather than dying silently.
                logger.exception("live transcript writer queue.get failed: %s", exc)
                break
            if item is None:
                break
            if self._fh is None:
                # Closed mid-flight; drop remaining items.
                continue
            try:
                self._fh.write(item)
                self._fh.flush()
            except OSError as exc:
                logger.error(
                    "Live transcript write failed (path=%s): %s", self._path, exc,
                )
            except Exception as exc:
                logger.exception(
                    "Live transcript write crashed unexpectedly (path=%s): %s",
                    self._path, exc,
                )
        # Drain done; close the handle.
        try:
            if self._fh is not None:
                self._fh.close()
        except Exception as exc:
            logger.warning("Live transcript close failed (path=%s): %s", self._path, exc)
        finally:
            self._fh = None

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
        # Sentinel signals the writer thread to drain + exit. Use put with
        # a short timeout — if the queue is wedged on a dead disk, blocking
        # for 5s here just delays session teardown without recovering data.
        try:
            self._queue.put(None, timeout=2.0)
        except queue.Full:
            logger.warning("Live transcript close: queue still full after 2s — forcing exit")
        # 2s join is enough for a healthy writer to flush; on a wedged disk
        # the writer may take longer but we cut losses to keep teardown
        # snappy. Tighter than 5+5 so two transcribers + recording finalize
        # don't compound into a multi-second teardown.
        self._thread.join(timeout=2.0)
        if self._thread.is_alive():
            logger.warning(
                "Live transcript writer thread did not exit within 2s (path=%s) — "
                "likely a wedged disk; remaining queued lines will be lost",
                self._path,
            )
