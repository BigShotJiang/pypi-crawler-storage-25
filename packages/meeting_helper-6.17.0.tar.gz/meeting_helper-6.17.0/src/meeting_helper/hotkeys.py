"""Global hotkey listener using pynput.

Hotkey map:
  2xCmd          -> trigger Claude query (sends transcript + buffered shots)
  Esc + Down     -> capture the frontmost window into the screenshot buffer
  2xEsc          -> show/hide the screen-share-invisible overlay
"""

from __future__ import annotations

import asyncio
import io
import logging
import math
import struct
import subprocess
import sys
import threading
import time
import wave
from pathlib import Path
from typing import TYPE_CHECKING

from pynput import keyboard

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig

logger = logging.getLogger(__name__)

_DOUBLE_TAP_THRESHOLD = 0.4

_current_keys: set = set()
_last_cmd_release: float = 0.0
_cmd_was_solo: bool = True
# Esc double-tap detection (overlay toggle). Mirrors the 2xCmd logic:
# we only count an Esc *release* toward the double-tap if Esc was solo
# (no other key, e.g. Down, was pressed while Esc was held). That keeps a
# single Esc that is part of Esc+Down from also counting toward the toggle.
_last_esc_release: float = 0.0
_esc_was_solo: bool = True


def _beep(freq: float, duration: float = 0.07, volume: float = 0.4) -> None:
    """Play a short sine-wave tone via NSSound."""
    def _play():
        try:
            sr = 44100
            n = int(sr * duration)
            fade_samples = int(sr * 0.01)
            frames = bytearray()
            for i in range(n):
                s = math.sin(2 * math.pi * freq * i / sr) * volume
                if i >= n - fade_samples:
                    s *= (n - i) / fade_samples
                frames += struct.pack('<h', max(-32767, min(32767, int(s * 32767))))
            buf = io.BytesIO()
            with wave.open(buf, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sr)
                wf.writeframes(bytes(frames))
            from AppKit import NSSound
            from Foundation import NSData
            data = NSData.dataWithBytes_length_(buf.getvalue(), len(buf.getvalue()))
            sound = NSSound.alloc().initWithData_(data)
            if sound:
                sound.setVolume_(min(1.0, volume * 2))
                sound.play()
                time.sleep(duration + 0.05)
        except Exception:
            pass
    threading.Thread(target=_play, daemon=True).start()


def _schedule(coro):
    from meeting_helper.state import state
    loop = state.asyncio_loop
    if loop is not None:
        asyncio.run_coroutine_threadsafe(coro, loop)


def _is_meeting_active() -> bool:
    from meeting_helper.state import state
    return state.session_active


def _do_trigger_query(config: "AppConfig"):
    if not _is_meeting_active():
        return

    _beep(660, 0.08)

    async def _query():
        from meeting_helper.ai.client import handle_query
        from meeting_helper.state import state
        await handle_query(state, config)

    _schedule(_query())


def _do_capture():
    """Esc+Down: grab the frontmost window into the screenshot buffer and
    broadcast the updated buffer so the ask-box thumbnail strip refreshes.

    Increments state.pending_screenshot_captures up front so a query fired
    right after (2x Cmd) waits for this capture to land before draining the
    buffer - keeping the screenshot and the transcript context in one turn.
    """
    from meeting_helper.state import state

    state.pending_screenshot_captures += 1
    try:
        if not _is_meeting_active():
            return

        from meeting_helper import screenshot

        _beep(880, 0.05)
        path = screenshot.capture_frontmost_window()
        if not path:
            return
        try:
            thumb = screenshot.make_thumbnail_data_url(path)
        except Exception:
            thumb = ""
        # Sticky-set replacement: if the current buffer already rode along on a
        # query, this fresh capture starts a NEW set. Purge the old shots and
        # their temp files so they aren't re-sent or left to pile up.
        if state.screenshots_consumed:
            for _old in list(state.screenshot_buffer):
                try:
                    Path(_old["path"]).unlink(missing_ok=True)
                except OSError:
                    pass
            state.clear_screenshots()
        state.add_screenshot(path=path, thumb=thumb)
        logger.info("Esc+Down capture (buffer=%d)", len(state.screenshot_buffer))

        async def _bcast():
            from meeting_helper.server.websocket import broadcast
            await broadcast({
                "type": "screenshots",
                "items": [
                    {"id": i["id"], "thumb": i["thumb"]}
                    for i in state.screenshot_buffer
                ],
            })

        _schedule(_bcast())
    finally:
        state.pending_screenshot_captures = max(
            0, state.pending_screenshot_captures - 1
        )


def _overlay_running() -> bool:
    """True if the overlay subprocess is alive (Popen.poll() is None)."""
    from meeting_helper.state import state
    proc = state.overlay_proc
    if proc is None:
        return False
    try:
        return proc.poll() is None
    except Exception:
        return False


def _toggle_overlay(config: "AppConfig"):
    """Double-Esc handler: show/hide the screen-share-invisible overlay.

    First press spawns the overlay process (it shows on launch). Subsequent
    presses flip its visibility via a WS broadcast that OverlayWindow handles
    by calling show()/hide(). Runs on the pynput listener thread, so the
    spawn is a thread-safe subprocess.Popen and the broadcast is dispatched
    onto the asyncio loop via run_coroutine_threadsafe (see _schedule).
    """
    from meeting_helper.state import state

    _beep(520, 0.06)

    if not _overlay_running():
        # Stale handle from a closed/crashed overlay — drop it before spawning.
        state.overlay_proc = None
        try:
            proc = subprocess.Popen(
                [sys.executable, "-m", "meeting_helper.overlay", str(config.port)]
            )
        except Exception:
            logger.exception("Failed to spawn overlay")
            return
        state.overlay_proc = proc
        state.overlay_visible = True
        logger.info("Overlay spawned (pid=%s, port=%d)", proc.pid, config.port)
        return

    # Already running — flip visibility and tell the overlay over the WS.
    state.overlay_visible = not state.overlay_visible
    visible = state.overlay_visible

    async def _bcast():
        from meeting_helper.server.websocket import broadcast
        await broadcast({"type": "overlay_visibility", "visible": visible})

    logger.info("Overlay visibility -> %s", visible)
    _schedule(_bcast())


def start_hotkey_listener(config: "AppConfig") -> None:
    """Start the pynput keyboard listener in a daemon thread."""
    _CMD_KEYS = {keyboard.Key.cmd, keyboard.Key.cmd_l, keyboard.Key.cmd_r}

    def on_press(key):
        global _cmd_was_solo, _esc_was_solo

        _current_keys.add(key)

        # Esc + Down -> capture the frontmost window into the buffer.
        if key == keyboard.Key.down and keyboard.Key.esc in _current_keys:
            logger.info("Hotkey: Esc+Down (capture)")
            threading.Thread(target=_do_capture, daemon=True).start()

        if key not in _CMD_KEYS and _current_keys & _CMD_KEYS:
            _cmd_was_solo = False

        # If any non-Esc key is down while Esc is held (e.g. Esc+Down), this
        # Esc is part of a combo and must not count toward the 2xEsc toggle.
        if key != keyboard.Key.esc and keyboard.Key.esc in _current_keys:
            _esc_was_solo = False

    def on_release(key):
        global _last_cmd_release, _cmd_was_solo, _last_esc_release, _esc_was_solo

        _current_keys.discard(key)

        if key in _CMD_KEYS:
            now = time.time()
            if _cmd_was_solo and (now - _last_cmd_release) < _DOUBLE_TAP_THRESHOLD:
                logger.info("Hotkey: 2×Cmd (query)")
                threading.Thread(target=lambda: _do_trigger_query(config), daemon=True).start()
                _last_cmd_release = 0.0
            else:
                _last_cmd_release = now
            _cmd_was_solo = True

        if key == keyboard.Key.esc:
            now = time.time()
            # Only a solo Esc tap (no Down etc. while held) counts toward the
            # toggle, so Esc+Down captures never trip it.
            if _esc_was_solo and (now - _last_esc_release) < _DOUBLE_TAP_THRESHOLD:
                logger.info("Hotkey: 2×Esc (overlay toggle)")
                threading.Thread(
                    target=lambda: _toggle_overlay(config), daemon=True
                ).start()
                _last_esc_release = 0.0
            else:
                _last_esc_release = now if _esc_was_solo else 0.0
            _esc_was_solo = True

    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    t = threading.Thread(target=listener.run, daemon=True)
    t.start()
    logger.info("Hotkey listener started")
