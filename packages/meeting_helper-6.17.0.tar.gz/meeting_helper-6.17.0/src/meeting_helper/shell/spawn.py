"""Daemon spawn helper.

Used by both the shell supervisor (when the daemon dies unexpectedly) and
by the pywebview JS API (so the UI can recover from a dead daemon by
clicking Start / the Disconnected pill). Both paths need to spawn a
detached daemon subprocess that captures stderr to a known log file so
silent crashes are diagnosable.

The launcher always prefers the ``meeting-helper`` CLI binary next to
``sys.executable`` (the pipx layout) over ``python -m meeting_helper.cli``,
because the binary's shebang resolves to the right interpreter even when
a developer has a ``.venv`` activated whose Python is not the one the
installed package expects.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional


DAEMON_SPAWN_LOG = "~/.meeting-helper-daemon-spawn.log"


def _resolve_cli() -> Optional[str]:
    """Find the ``meeting-helper`` entry-point script. Prefer the binary
    next to ``sys.executable`` (pipx layout) over a PATH lookup, since
    PATH may be polluted by a developer ``.venv``."""
    candidate = Path(sys.executable).parent / "meeting-helper"
    if candidate.exists():
        return str(candidate)
    return shutil.which("meeting-helper")


def spawn_daemon() -> subprocess.Popen:
    """Spawn a detached daemon, returning the Popen handle so callers can
    quickly check whether the child died before binding the port.

    stdout and stderr are appended to ``~/.meeting-helper-daemon-spawn.log``
    so any import-time crash leaves a traceback the user can inspect.
    """
    log_path = os.path.expanduser(DAEMON_SPAWN_LOG)
    try:
        log_fh = open(log_path, "a")
    except Exception:
        log_fh = subprocess.DEVNULL  # type: ignore[assignment]

    cli = _resolve_cli()
    if cli:
        cmd = [cli, "start"]
    else:
        # Last resort: re-invoke our own interpreter. May fail if sys.executable
        # is a .venv whose meeting_helper install is stale, but it's better
        # than silently doing nothing.
        cmd = [sys.executable, "-m", "meeting_helper.cli", "start"]

    return subprocess.Popen(
        cmd,
        stdout=log_fh,
        stderr=log_fh,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )


def read_spawn_log_tail(max_bytes: int = 2048) -> str:
    """Return the last ``max_bytes`` of the spawn log as a string, or "" if
    the log doesn't exist or can't be read. Used to surface a daemon
    crash trace to the UI when ``spawn_daemon`` is called from the pywebview
    JS bridge."""
    log_path = os.path.expanduser(DAEMON_SPAWN_LOG)
    try:
        size = os.path.getsize(log_path)
        with open(log_path, "rb") as f:
            if size > max_bytes:
                f.seek(-max_bytes, os.SEEK_END)
            return f.read().decode("utf-8", errors="replace")
    except Exception:
        return ""
