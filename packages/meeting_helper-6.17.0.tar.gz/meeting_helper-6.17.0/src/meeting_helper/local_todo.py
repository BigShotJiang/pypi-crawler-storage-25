"""Back-compat shim — LocalTodoClient is now a deprecated alias for Tracker.

Import from meeting_helper.trackers instead.
"""
from __future__ import annotations

import warnings

from meeting_helper.trackers.tracker import Tracker
from meeting_helper.trackers.vendors.local_todo import LocalTodoProfile


class LocalTodoClient(Tracker):
    """Deprecated. Use ``Tracker(profile=LocalTodoProfile(), transport=...)``."""

    def __init__(self, mcp_config: dict) -> None:
        warnings.warn(
            "LocalTodoClient is deprecated; use Tracker(profile=LocalTodoProfile(), transport=mcp_config).",
            DeprecationWarning,
            stacklevel=2,
        )
        if not mcp_config:
            raise ValueError("LocalTodoClient: mcp_config must be non-empty")
        super().__init__(profile=LocalTodoProfile(), transport=mcp_config)


__all__ = ["LocalTodoClient", "Tracker"]
