"""Daemon process management: double-fork, PID files, signal handling.

IMPORTANT: Audio modules must NOT be imported at module level.
They are imported inside run_daemon() after daemonize().
"""

from __future__ import annotations

import asyncio
import atexit
import json
import logging
import os
import signal
import sys
import time
from typing import Optional

from meeting_helper.config import LOG_FILE, META_FILE, PID_FILE, AppConfig

from meeting_helper.ssl_fix import patch_ssl
patch_ssl()

logger = logging.getLogger(__name__)


# On SIGTERM, if a post-meeting auto-summary is still running on the event
# loop, hold the loop open this long so it can finish writing .summary.txt.
SHUTDOWN_SUMMARY_GRACE = 60.0


# ---------------------------------------------------------------------------
# PID file helpers
# ---------------------------------------------------------------------------

def write_pid_file(pid: Optional[int] = None) -> None:
    pid = pid or os.getpid()
    PID_FILE.write_text(str(pid))


def remove_pid_file() -> None:
    try:
        PID_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def read_pid() -> Optional[int]:
    try:
        return int(PID_FILE.read_text().strip())
    except Exception:
        return None


def is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


def _terminate_pid(pid: int) -> bool:
    """SIGTERM with SIGKILL escalation. Returns True if pid is gone."""
    if not is_process_running(pid):
        return True
    try:
        os.kill(pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        return not is_process_running(pid)
    for _ in range(50):
        time.sleep(0.1)
        if not is_process_running(pid):
            return True
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    for _ in range(20):
        time.sleep(0.1)
        if not is_process_running(pid):
            return True
    return False


_NON_DAEMON_SUBCOMMANDS = {
    "gui", "menubar", "stop", "status", "version", "logs",
    "diagnose-recording", "fix-recording", "setup", "autostart",
}


def _looks_like_daemon(cmdline: list[str]) -> bool:
    """True if `cmdline` looks like a daemon process we should kill in
    `mh stop`. Excludes GUI / menubar / overlay / short-lived CLI
    subcommands so the scan doesn't take down sibling tools."""
    if not cmdline:
        return False
    # Skip helper subprocesses with their own submodule name on argv.
    for part in cmdline:
        if part in ("meeting_helper.flet_gui", "meeting_helper.menubar",
                    "meeting_helper.overlay"):
            return False
    # `python -m meeting_helper` (no submodule).
    for i in range(len(cmdline) - 1):
        if cmdline[i] == "-m" and cmdline[i + 1] == "meeting_helper":
            return True
    # `meeting-helper` click entry point — daemon if no non-daemon subcommand.
    for i, part in enumerate(cmdline):
        is_entry = part == "meeting-helper" or part.endswith("/meeting-helper")
        if is_entry and not any(p in _NON_DAEMON_SUBCOMMANDS for p in cmdline[i + 1:]):
            return True
    return False


def _looks_like_overlay(cmdline: list[str]) -> bool:
    """True if `cmdline` is the overlay subprocess. The overlay is tied
    to the daemon's lifetime — when we kill the daemon we want any
    leftover overlay to go too."""
    return any(part == "meeting_helper.overlay" for part in cmdline)


def kill_existing() -> bool:
    """Kill any running daemon (and orphan overlays). Returns True if at
    least one process was killed.

    PID-file path runs first (fast). Then a psutil scan picks up
    orphans — daemons whose PID file was deleted, or that were
    SIGKILLed before atexit could clean up. This is the case where the
    daemon is still listening on the port (so the GUI/menubar happily
    show "Ready") but `read_pid()` returns nothing.
    """
    killed = False

    pid = read_pid()
    if pid is not None and is_process_running(pid):
        if _terminate_pid(pid):
            killed = True
    remove_pid_file()

    try:
        import psutil
    except ImportError:
        return killed

    my_pid = os.getpid()
    for proc in psutil.process_iter(["pid", "cmdline"]):
        try:
            target_pid = proc.info["pid"]
            if target_pid == my_pid:
                continue
            cmdline = proc.info.get("cmdline") or []
            if not (_looks_like_daemon(cmdline) or _looks_like_overlay(cmdline)):
                continue
            if _terminate_pid(target_pid):
                killed = True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    return killed


# ---------------------------------------------------------------------------
# Metadata helpers
# ---------------------------------------------------------------------------

def write_meta(config: AppConfig, transcriber_name: str = "") -> None:
    provider = config.preferred_provider or "claude"
    if provider == "local":
        ai_model = config.local_model
    elif provider == "gemini":
        ai_model = config.gemini_model
    else:
        ai_model = config.claude_model
    meta = {
        "started_at": time.time(),
        "port": config.port,
        "pid": os.getpid(),
        "ai_provider": provider,
        "ai_model": ai_model,
        "claude_model": config.claude_model,
        "local_model": config.local_model if provider == "local" else "",
        "transcriber": transcriber_name,
        "whisper_host": config.whisper_host,
        "transcription_language": config.transcription_language,
    }
    META_FILE.write_text(json.dumps(meta))


def read_meta() -> Optional[dict]:
    try:
        return json.loads(META_FILE.read_text())
    except Exception:
        return None


def remove_meta() -> None:
    try:
        META_FILE.unlink(missing_ok=True)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# MicProbe: detect when meeting app releases the microphone
# ---------------------------------------------------------------------------

class MicProbe:
    """Probes whether another app is still using the microphone.

    Works by briefly pausing our mic stream and checking
    kAudioDevicePropertyDeviceIsRunningSomewhere.
    """

    def __init__(
        self,
        probe_interval: float = 20.0,
        settle_time: float = 0.3,
        required_off_count: int = 2,
    ):
        self.probe_interval = probe_interval
        self.settle_time = settle_time
        self.required_off_count = required_off_count
        self._last_probe = 0.0
        self._off_count = 0

    def should_probe(self, now: float) -> bool:
        return (now - self._last_probe) >= self.probe_interval

    def probe(self, capture) -> bool:
        """Pause mic, check if anyone else uses it, resume.

        Returns True if the meeting app has released the microphone.
        Returns False on probe error (resume failure, etc.) so the session
        keeps running rather than dying — false-end-of-meeting is much
        worse than missing one probe.
        """
        self._last_probe = time.time()
        capture.pause_mic()
        time.sleep(self.settle_time)

        mic_in_use = self._check_mic_running()

        # resume_mic returns False if InputStream re-init failed (device
        # change mid-meeting, etc.). In that case the mic is permanently
        # paused for this session — but the session itself stays alive
        # with system audio so the user keeps getting partial data.
        resumed = capture.resume_mic()
        if not resumed:
            logger.warning(
                "MicProbe.probe: resume_mic failed — mic paused until "
                "session restart. Treating probe as inconclusive (session continues)"
            )
            self._off_count = 0
            return False

        if not mic_in_use:
            self._off_count += 1
            if self._off_count >= self.required_off_count:
                return True
        else:
            self._off_count = 0
        return False

    @staticmethod
    def _check_mic_running() -> bool:
        """Check if any app (besides us) is using the default input device."""
        from meeting_helper.meeting_detector import is_mic_in_use_by_another_app
        return is_mic_in_use_by_another_app()


# ---------------------------------------------------------------------------
# daemonize: double-fork to detach from terminal
# ---------------------------------------------------------------------------

def daemonize() -> None:
    """Double-fork to create a background daemon. Call BEFORE importing audio libs."""
    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError as exc:
        sys.stderr.write(f"First fork failed: {exc}\n")
        sys.exit(1)

    os.setsid()

    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError as exc:
        sys.stderr.write(f"Second fork failed: {exc}\n")
        sys.exit(1)

    os.umask(0)
    os.chdir("/")

    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    sys.stdout.flush()
    sys.stderr.flush()

    with open(os.devnull, "r") as f:
        os.dup2(f.fileno(), sys.stdin.fileno())
    with open(LOG_FILE, "a") as f:
        os.dup2(f.fileno(), sys.stdout.fileno())
        os.dup2(f.fileno(), sys.stderr.fileno())


# ---------------------------------------------------------------------------
# Main daemon entrypoint
# ---------------------------------------------------------------------------

def run_daemon(config: AppConfig) -> None:
    """Main daemon process. Called after daemonize()."""
    daemonize()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler()],
    )
    # Silence high-volume polling loggers — dashboard polls 5 endpoints
    # every ~200ms, which floods the log at INFO. Keep WARNING+ visible.
    for noisy in ("aiohttp.access", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    # SIGSEGV / SIGFPE / SIGABRT in C extensions (PyObjC, ScreenCaptureKit,
    # numpy under contention) used to kill the daemon with no trace. With
    # faulthandler enabled, the process still dies but writes a Python-side
    # stack trace to stderr (which is dup2'd to LOG_FILE), so we can tell
    # which thread / call chain triggered it.
    try:
        import faulthandler
        faulthandler.enable()
    except Exception as exc:
        logger.warning("faulthandler.enable failed: %s", exc)

    logger.info("Daemon started (pid=%d)", os.getpid())

    write_pid_file()
    atexit.register(remove_pid_file)
    atexit.register(remove_meta)

    # Hide from macOS Dock
    try:
        from AppKit import NSApplication, NSApplicationActivationPolicyProhibited
        NSApplication.sharedApplication().setActivationPolicy_(
            NSApplicationActivationPolicyProhibited
        )
    except Exception:
        pass

    shutdown_flag = {"stop": False}

    def _term_handler(signum, frame):
        logger.info("SIGTERM received, shutting down")
        shutdown_flag["stop"] = True

    signal.signal(signal.SIGTERM, _term_handler)

    # -----------------------------------------------------------------------
    # NOW safe to import audio and network libraries
    # -----------------------------------------------------------------------
    from meeting_helper.buffer import SentenceBuffer
    from meeting_helper.state import state
    from meeting_helper.session import MeetingSession
    from meeting_helper.server.app import create_app
    from meeting_helper.hotkeys import start_hotkey_listener
    from meeting_helper.auto_updater import auto_update_loop

    state.started_at = time.time()
    state.self_buffer = SentenceBuffer(max_sentences=50, role="self")
    state.other_buffer = SentenceBuffer(max_sentences=50, role="other")
    state.system_prompt = config.system_prompt
    state.hot_moment_window_sec = config.hot_moment_window_minutes * 60.0
    # Seed the topic-picker mode from the configured default so the GUI shows
    # the right mode before the first meeting starts. on_meeting_start re-applies
    # it per meeting; the in-meeting toggle overrides for the current meeting.
    state.topic_auto_paused = config.default_topic_mode == "manual"

    # Tracker bootstrap — resolve config synchronously; async boot happens in _main().
    from meeting_helper.trackers.registry import TrackerRegistry, get_profile, UnknownVendor
    from meeting_helper.trackers.secrets import read_secrets, KeychainUnavailable

    # Inject the daemon's file-backed config callback so the meeting_helper
    # vendor's LocalTracker writes through the live workspace Config rather
    # than the global meeting_helper.config singleton (CLAUDE.md rule). Same
    # callback used later by create_app's disk_factory.
    from meeting_helper.config import get_config as _get_disk_config_for_registry
    registry = TrackerRegistry(disk_factory=_get_disk_config_for_registry)
    state.trackers = registry  # type: ignore[attr-defined]
    _active_id = config.active_tracker_id
    _active_entry = next((t for t in config.trackers if t.get("id") == _active_id), None)
    if _active_entry is None:
        state.tracker = None
        logger.info("No active tracker — daemon running without a task tracker.")
        _tracker_boot_args: dict | None = None
    else:
        _vendor_id = _active_entry.get("vendor", "")
        try:
            get_profile(_vendor_id)  # raises UnknownVendor early
        except UnknownVendor:
            logger.warning("Unknown vendor %r — leaving tracker inactive.", _vendor_id)
            state.tracker = None
            _tracker_boot_args = None
        else:
            try:
                _secrets = read_secrets(
                    config.workspace_name,
                    _active_entry["id"],
                    _active_entry.get("secret_keys", []) or [],
                )
            except KeychainUnavailable as exc:
                logger.error("Keychain unavailable: %s", exc)
                _secrets = {}
            _tracker_boot_args = dict(
                tracker_id=_active_entry["id"],
                vendor_id=_vendor_id,
                auth_values=_active_entry.get("auth_values", {}) or {},
                secrets=_secrets,
                workspace_name=config.workspace_name,
            )

    # Set AI model info for overlay info pills
    if config.preferred_provider == "local":
        state.ai_model = config.local_model
    elif config.preferred_provider == "gemini":
        state.ai_model = config.gemini_model
    else:
        state.ai_model = config.claude_model

    def on_meeting_start(info):
        # Knowledge base now flows via the new query-time KB retrieval path
        # (library_retrieval.retrieve_kb_cards). System prompt at meeting
        # start contains no repos/knowledge context.
        from meeting_helper.ai.prompts import build_system_prompt
        state.system_prompt = build_system_prompt("")

        state.status = "listening"
        state.meeting_info = info
        state.session_active = True
        # New meetings start in the configured default topic mode (default
        # "manual"); the in-meeting AUTO/MANUAL toggle overrides per meeting.
        state.topic_auto_paused = config.default_topic_mode == "manual"
        state.reset_session_stats()
        loop = state.asyncio_loop
        if loop:
            asyncio.run_coroutine_threadsafe(
                _broadcast_meeting_status(True, info.app_name, info.meeting_name), loop
            )
            asyncio.run_coroutine_threadsafe(_engagement_status_ticker(), loop)

    def on_meeting_end(saved_path):
        state.status = "idle"
        state.meeting_info = None
        state.session_active = False
        state.conversation_history.clear()
        state.last_response = ""
        loop = state.asyncio_loop
        if loop:
            asyncio.run_coroutine_threadsafe(
                _broadcast_meeting_ended(
                    saved_path, default_topic_mode=config.default_topic_mode
                ),
                loop,
            )

    session = MeetingSession(
        config=config,
        self_buffer=state.self_buffer,
        other_buffer=state.other_buffer,
        on_meeting_start=on_meeting_start,
        on_meeting_end=on_meeting_end,
    )
    state.meeting_session = session
    session.start()

    write_meta(config, transcriber_name="pending")
    start_hotkey_listener(config)

    # One-time first-launch install of the macOS .app bundle. Idempotent:
    # writes a marker file on success so users who later uninstall the
    # bundle don't have it silently recreated. macOS-only — the .app
    # bundle is meaningless on Linux/Windows.
    if sys.platform == "darwin":
        try:
            from meeting_helper.install_app import ensure_app_bundle_installed
            ensure_app_bundle_installed()
        except Exception as exc:
            logger.warning("ensure_app_bundle_installed: %s", exc)

    async def _main():
        import aiohttp.web as web

        loop = asyncio.get_running_loop()
        state.asyncio_loop = loop
        state.shutdown_event = asyncio.Event()

        # Async half of tracker bootstrap: registry + args prepared above in sync scope.
        if _tracker_boot_args is not None:
            try:
                await registry.boot(**_tracker_boot_args)
                state.tracker = registry.current
            except KeyError as exc:
                _stale_id = _tracker_boot_args.get("tracker_id", "unknown")
                logger.warning(
                    "Active tracker %s is invalid (stale auth_values from older version). "
                    "Open Settings → Task tracker to reconfigure. Detail: %s",
                    _stale_id,
                    exc,
                )
                state.tracker = None
            except Exception as exc:
                logger.exception("Tracker boot failed: %s", exc)
                state.tracker = None

        # Pre-warm the topic cache for the active workspace so the Copilot
        # panel + ticket picker have items the moment the user opens the
        # tab — no need to click Refresh or wait for the first transcript
        # sentence. Fire and forget; if the agent loop fails it just logs.
        if state.tracker is not None:
            try:
                from meeting_helper.ai.client import refresh_sprint_tickets
                asyncio.create_task(refresh_sprint_tickets(state, force=True))
                logger.info("Daemon: pre-warm topics scheduled")
            except Exception as exc:
                logger.warning("Daemon: pre-warm topics failed: %s", exc)

        from meeting_helper.config import get_config as _get_disk_config
        app = create_app(config, disk_factory=_get_disk_config)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", config.port)
        await site.start()
        logger.info("Server on 0.0.0.0:%d", config.port)

        update_task = asyncio.create_task(auto_update_loop())

        _last_cpu_broadcast = 0.0
        _last_loop_tick = 0.0
        _lag_window: list[tuple[float, float]] = []

        # Prime psutil baseline — first call always returns 0.0
        try:
            import psutil as _psutil
            _psutil_proc = _psutil.Process()
            _psutil_proc.cpu_percent(interval=None)
            _psutil.cpu_percent(interval=None)
        except Exception:
            _psutil_proc = None
            _psutil = None

        while not shutdown_flag["stop"]:
            await asyncio.sleep(0.5)
            now = time.time()

            # Event-loop lag: we asked for sleep(0.5); anything beyond that is the
            # loop being blocked. Keep a rolling max over ~10s.
            _expected_wake = _last_loop_tick + 0.5 if _last_loop_tick else now
            _lag_ms = max(0.0, (now - _expected_wake) * 1000.0)
            _last_loop_tick = now
            _lag_window.append((now, _lag_ms))
            _lag_window[:] = [(t, v) for (t, v) in _lag_window if now - t <= 10.0]
            state.event_loop_lag_ms = max((v for _, v in _lag_window), default=0.0)

            # Broadcast CPU usage every 10s
            if now - _last_cpu_broadcast >= 10:
                _last_cpu_broadcast = now
                try:
                    if _psutil_proc and _psutil:
                        from meeting_helper.server.websocket import broadcast
                        proc_cpu = _psutil_proc.cpu_percent(interval=None)
                        proc_rss_mb = round(_psutil_proc.memory_info().rss / (1024 ** 2), 1)
                        _host_cpu = _psutil.cpu_percent(interval=None)
                        state.proc_cpu_percent = proc_cpu
                        state.proc_rss_mb = proc_rss_mb
                        state.host_cpu_percent = _host_cpu
                        asyncio.ensure_future(broadcast({
                            "type": "cpu",
                            "process": round(proc_cpu, 1),
                            "host": round(_host_cpu, 1),
                            "proc_rss_mb": proc_rss_mb,
                        }))
                except Exception:
                    pass

        # Shutdown requested (SIGTERM). If a post-meeting auto-summary is still
        # running on this loop, give it a bounded window to finish writing
        # .summary.txt before tearing the loop down — otherwise a stop during
        # summarization loses the summary. (Usually the meeting-end thread is
        # already blocking on it; this just keeps the loop alive for it.)
        if getattr(state, "summarizing", False):
            logger.info("Shutdown requested while summarizing — waiting up to %.0fs", SHUTDOWN_SUMMARY_GRACE)
            _grace_deadline = time.time() + SHUTDOWN_SUMMARY_GRACE
            while getattr(state, "summarizing", False) and time.time() < _grace_deadline:
                await asyncio.sleep(0.25)
            if getattr(state, "summarizing", False):
                logger.warning("Summary still running at shutdown deadline — abandoning it")

        update_task.cancel()
        try:
            await update_task
        except (asyncio.CancelledError, Exception):
            pass

        await runner.cleanup()

        # Shut down the active tracker (closes MCP subprocess/connection)
        if state.tracker is not None:
            try:
                await registry.shutdown()
            except Exception as exc:
                logger.warning("tracker shutdown error: %s", exc)

    try:
        asyncio.run(_main())
    except Exception as exc:
        logger.error("Event loop error: %s", exc)
    finally:
        session.stop()
        logger.info("Daemon exited cleanly")


async def _broadcast_meeting_status(active: bool, app_name: str, meeting_name: Optional[str]) -> None:
    from meeting_helper.server.websocket import broadcast
    await broadcast({
        "type": "meeting_status",
        "active": active,
        "app": app_name,
        "meeting_name": meeting_name or "",
    })
    await broadcast({"type": "status", "value": "listening" if active else "idle"})


async def _broadcast_meeting_ended(saved_path, *, default_topic_mode: str = "manual") -> None:
    from meeting_helper.server.websocket import broadcast
    from meeting_helper.state import state
    # Reset per-meeting state that lives across the meeting boundary so the
    # next meeting (and the GUI in the meantime) starts clean. Topic mode falls
    # back to the configured default (passed in from the daemon's live config)
    # so the between-meetings display matches what the next meeting starts in.
    state.hot_moment_until = 0.0
    state.topic_auto_paused = default_topic_mode == "manual"
    state.current_topic = {
        "topic": "",
        "ticket_ids": [],
        "search_query": "",
        "last_user_statement": "",
    }
    state.current_topic_cards = []
    state.last_user_query_topic = {"topic": "", "ticket_ids": []}
    # Drop any buffered screenshots (and their temp files) so they never leak
    # into the next meeting.
    _shots = state.drain_screenshots()
    if _shots:
        from pathlib import Path as _Path
        for _s in _shots:
            try:
                _Path(_s["path"]).unlink(missing_ok=True)
            except OSError:
                pass
        await broadcast({"type": "screenshots", "items": []})
    await broadcast({"type": "meeting_status", "active": False, "app": "", "meeting_name": ""})
    await broadcast({"type": "status", "value": "idle"})
    await broadcast({"type": "engagement_status", "active": False, "until_wallclock": 0.0})
    await broadcast({"type": "meeting_ended", "recording": str(saved_path) if saved_path else ""})


async def _engagement_status_ticker() -> None:
    """Watch Hot Moment state every 5s and broadcast on flip."""
    from meeting_helper.server.websocket import broadcast
    from meeting_helper.state import state
    last_active: bool | None = None
    while not (state.shutdown_event is not None and state.shutdown_event.is_set()):
        active = state.is_hot_moment()
        if active != last_active:
            await broadcast({
                "type": "engagement_status",
                "active": active,
                "until_wallclock": state.hot_moment_until_wallclock(),
            })
            last_active = active
        await asyncio.sleep(5)
