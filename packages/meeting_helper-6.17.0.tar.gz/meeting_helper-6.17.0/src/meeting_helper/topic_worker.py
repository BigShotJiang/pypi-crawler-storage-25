"""TopicWorker — maintains state.current_topic from rolling self-buffer speech.

Listens on self_buffer for new finalized sentences. On each one, schedules a
debounced topic extraction job (max 1/5s, skipped if the rolling text hasn't
changed). Uses the user's configured AI provider (via _call_ai_for_tasks) so
cost/latency follows their existing settings.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import re
import threading
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig
    from meeting_helper.buffer import SentenceBuffer

logger = logging.getLogger(__name__)

# Re-exported so tests can monkeypatch
# `meeting_helper.topic_worker.pick_topic_from_candidates`. The basket leg
# resolves the picker off this module symbol at call time.
from meeting_helper.ai.client import pick_topic_from_candidates  # noqa: E402


_EMPTY_TOPIC = {
    "topic": "",
    "ticket_ids": [],
    "search_query": "",
    "last_user_statement": "",
}

# Whisper hallucinates dots/short words on silence — e.g. "....." or "Okay."
# while the mic is muted. Require at least this many alphabetic-containing
# words before treating a sentence as real engagement.
MIN_ENGAGEMENT_WORDS = 5
_WORD_RE = re.compile(r"[A-Za-z]")


def _real_word_count(text: str) -> int:
    return sum(1 for tok in text.split() if _WORD_RE.search(tok))


class _TopicWorkerAIClient:
    """Adapter that satisfies the topic_candidate ``AIClient`` protocol.

    Routes the matcher's ``await chat(messages)`` call through the project's
    one-shot LLM helper so it uses the user's configured provider (Claude /
    Gemini / Ollama) without dragging in the streaming chat stack. Mirrors
    the shape of ``_SingleShotAIClient`` in ``server/routes.py`` but lives
    here to avoid a cyclic import from topic_worker -> server.routes.
    """

    def __init__(self, config) -> None:
        self._config = config

    async def chat(self, messages: list[dict], **_kwargs) -> str:
        from meeting_helper.ai.client import _call_ai_for_tasks

        system = ""
        user_parts: list[str] = []
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content", "") or ""
            if role == "system" and not system:
                system = content
            else:
                user_parts.append(content)
        user_msg = "\n\n".join(p for p in user_parts if p)
        return await _call_ai_for_tasks(
            self._config, system, user_msg, kind="action_items_match",
        )


class TopicWorker:
    """Background topic tracker bound to a self_buffer.

    Lifecycle: instantiate, call start(), then stop() on session end.
    """

    DEBOUNCE_SECS = 5.0
    WINDOW_SENTENCES = 25  # how many recent self-sentences to consider

    def __init__(self, config: "AppConfig", self_buffer: "SentenceBuffer") -> None:
        self._config = config
        self._buffer = self_buffer
        self._stop_event = threading.Event()
        self._last_run_at: float = 0.0
        self._last_hash: str = ""
        self._timer: Optional[threading.Timer] = None
        self._lock = threading.Lock()
        self._enabled: bool = True
        # Cache the bound listener so add/remove see the SAME object identity
        # (bound methods are re-created on each attribute access).
        self._listener = self._on_sentence
        self._other_listener = self._on_other_sentence

    # ---- Lifecycle ----

    def start(self) -> None:
        from meeting_helper.state import state
        self._buffer.add_sentence_listener(self._listener)
        if state.other_buffer is not None:
            state.other_buffer.add_sentence_listener(self._other_listener)
        # Pre-warm the topic cache so the Copilot panel + ticket picker
        # have items the moment the first sentence is transcribed. Without
        # this the agent fetch only fires on the FIRST speech-debounce-tick
        # which can take many seconds, and the user sees an empty panel.
        #
        # force=False on purpose: refresh_sprint_tickets internally skips
        # when the cache is fresh (<5 min). Forcing a refresh on every
        # meeting start kicked off ~16 s of LLM agent_loop work while the
        # session's audio queue was filling but the Deepgram WS hadn't
        # caught up, pinning the OTHER channel several seconds behind
        # real-time for the rest of the session. Letting the cache TTL
        # decide preserves the warm-cache hit for back-to-back meetings
        # and only pays the cost when it's genuinely needed.
        if getattr(state, "tracker", None) is not None:
            try:
                import asyncio as _asyncio
                from meeting_helper.ai.client import refresh_sprint_tickets
                # NOTE: typo bait — `AppState` exposes the running loop as
                # `asyncio_loop`, not `event_loop`. Reading the wrong attr
                # silently returned None and the pre-warm never fired —
                # which is exactly the failure mode this branch is supposed
                # to PREVENT (an empty Topics panel for the first ~10s of
                # every meeting).
                loop = getattr(state, "asyncio_loop", None)
                if loop is not None and loop.is_running():
                    _asyncio.run_coroutine_threadsafe(
                        refresh_sprint_tickets(state, force=False), loop,
                    )
            except Exception as exc:
                logger.warning("TopicWorker: pre-warm refresh failed: %s", exc)
        logger.info("TopicWorker started")

    def stop(self) -> None:
        from meeting_helper.state import state
        self._enabled = False
        self._stop_event.set()
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
        try:
            self._buffer.remove_sentence_listener(self._listener)
        except Exception:
            pass
        if state.other_buffer is not None:
            try:
                state.other_buffer.remove_sentence_listener(self._other_listener)
            except Exception:
                pass
        logger.info("TopicWorker stopped")

    # ---- Trigger ----

    def _on_sentence(self, _sentence: str, _speaker: int | None = None, *, extend_hot_moment: bool = True) -> None:
        """Called from the transcriber thread on every new finalized sentence.

        ``extend_hot_moment``: re-arm the Hot Moment window. True for the
        user's own speech (the canonical engagement signal); False for
        other-party sentences — those are consumed while hot and trigger a
        re-evaluation, but only *your* activity resets the countdown (the
        conversation may have drifted onto things you don't care about).
        """
        if not self._enabled:
            return
        # Drop silence-driven hallucinations ("....." or single fillers) so a
        # muted user doesn't keep flipping engagement from Idle to Active.
        if _real_word_count(_sentence) < MIN_ENGAGEMENT_WORDS:
            return
        if extend_hot_moment:
            # Read the window length from `state` (seeded at daemon startup,
            # kept live by POST /config) so the user's configured value is
            # honoured — not a stale snapshot or the bare default.
            from meeting_helper.state import state
            window_sec = state.hot_moment_window_sec
            state.arm_hot_moment(window_sec=window_sec)
            logger.debug("Hot Moment armed for %.0f s (%.1f min)", window_sec, window_sec / 60.0)
        now = time.monotonic()
        elapsed = now - self._last_run_at
        if elapsed >= self.DEBOUNCE_SECS:
            # Run immediately
            self._schedule_run(0.0)
        else:
            # Debounce: schedule for the remaining window if not already pending
            with self._lock:
                if self._timer is None:
                    delay = self.DEBOUNCE_SECS - elapsed
                    t = threading.Timer(delay, self._fire_via_loop)
                    t.daemon = True
                    self._timer = t
                    t.start()

    def _on_other_sentence(self, _sentence: str, _speaker: int | None = None) -> None:
        """Other-buffer sentence — always fires the worker (debounced).

        Previously this was gated on Hot Moment, which made sense when the
        worker was primarily for the user's own engagement signal. But the
        TOPIC PICKER fires from the same `_on_sentence` path, and in
        listen-mostly meetings (demos, code reviews, standups where others
        report status) the user goes quiet for long stretches — the Hot
        Moment window expires after 10 min and every subsequent `[other]`
        sentence was silently dropped, freezing the topic banner on whatever
        was active when the user last spoke. The picker never got a chance
        to switch even when the other party named a specific ticket.

        Now: always run the picker on `[other]` sentences (debounced via
        `_on_sentence`'s scheduling). We still do NOT re-arm the Hot Moment
        — that countdown still tracks the user's own engagement so it can
        gate engagement-related features (transcript focus etc.) without
        being confused by a long silence-and-listen.
        """
        if not self._enabled:
            return
        # Re-evaluate the topic, but leave the Hot Moment countdown alone.
        self._on_sentence(_sentence, _speaker, extend_hot_moment=False)

    def _schedule_run(self, delay: float) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
        if delay <= 0:
            self._fire_via_loop()
        else:
            t = threading.Timer(delay, self._fire_via_loop)
            t.daemon = True
            with self._lock:
                self._timer = t
            t.start()

    def _fire_via_loop(self) -> None:
        """Hand off to the asyncio loop where _run() can do async work."""
        with self._lock:
            self._timer = None
        if not self._enabled:
            return
        from meeting_helper.state import state
        loop = state.asyncio_loop
        if loop is None:
            return
        asyncio.run_coroutine_threadsafe(self._run(), loop)

    # ---- Buffer merge ----

    def collect_window(
        self,
        other_buffer: "SentenceBuffer | None",
        n: int,
    ) -> list[tuple[str, str]]:
        """Build the chronological, role-labeled sentence list fed to the LLM.

        Always merges both buffers when ``other_buffer`` is provided. The
        picker needs to see what the OTHER party said in order to switch
        topics when they ask about a different ticket — gating this on the
        Hot Moment caused the topic banner to freeze in listen-mostly
        meetings (demos, code reviews) where the user goes quiet and the
        Hot Moment expires.

        Returns the last ``n`` entries of the merged-by-timestamp stream
        as ``("self"|"other", text)`` tuples.
        """
        with self._buffer._lock:
            self_entries = [(e.timestamp, "self", e.text) for e in self._buffer._sentences]

        if other_buffer is None:
            return [(role, text) for _ts, role, text in self_entries[-n:]]

        with other_buffer._lock:
            other_entries = [(e.timestamp, "other", e.text) for e in other_buffer._sentences]

        merged = sorted(self_entries + other_entries, key=lambda t: t[0])
        return [(role, text) for _ts, role, text in merged[-n:]]

    # ---- Async work ----

    async def _run(self) -> None:
        """Top-level worker tick. Dispatches between the basket and auto legs.

        When `state.pinned_topics` is non-empty the user is driving the topic
        manually via the pinned basket; we route to `_pick_from_basket` and
        skip the sprint/action-item auto path entirely. With an empty basket
        we fall through to the legacy `_pick_from_sprint_and_action_items`
        flow that scans the cached sprint tickets + open action items.
        """
        if not self._enabled:
            return

        from meeting_helper.state import state as _state

        # Engagement/manual gate. MANUAL mode never auto-picks. In AUTO, the
        # picker runs only inside a Hot Moment (the user spoke a real sentence
        # within their configured window). Past that window we make ZERO LLM
        # calls until they speak again. This deliberately reverses commit
        # 7b1e0976 (the listen-mostly tracking) per the 2026-05-20 spec — when
        # the user is passively listening the picker stays silent and free.
        if _state.topic_auto_paused:
            return
        if not _state.is_hot_moment():
            return

        labeled = self.collect_window(_state.other_buffer, n=self.WINDOW_SENTENCES)
        if not labeled:
            return

        # Hash-skip: if labeled text hasn't changed since last run, do nothing.
        text = "\n".join(f"{role}:{txt}" for role, txt in labeled)
        h = hashlib.sha1(text.encode("utf-8")).hexdigest()
        if h == self._last_hash:
            return
        self._last_hash = h
        self._last_run_at = time.monotonic()

        if _state.pinned_topics:
            await self._pick_from_basket(labeled, text)
            return

        await self._pick_from_sprint_and_action_items(labeled, text)

    async def _pick_from_basket(self, labeled, text) -> None:
        """Pick one item from state.pinned_topics as the active topic.

        Builds a heterogeneous candidate list (tickets / notes / action
        items), runs the LLM picker that knows about multiple kinds, and
        writes the winner into state.current_topic / current_topic_cards.
        The legacy action-item match leg does NOT run here - the basket IS
        the candidate set.
        """
        from pathlib import Path
        from meeting_helper.state import state as _state

        candidates: list[dict] = []
        # Snapshot the basket before iterating: HTTP /topic/{pin,unpin,clear}
        # and session-stop mutate the live list from other coroutines, and a
        # mutation mid-iteration silently produces wrong basket picks (no
        # exception, just skipped or doubled entries on CPython).
        for item in list(_state.pinned_topics):
            if item.kind == "ticket":
                card = _find_ticket_card(_state, item.id) or {
                    "id": item.id,
                    "title": item.title,
                    "board_id": item.board_id,
                    "kind": "ticket",
                }
                candidates.append({**card, "kind": "ticket"})
            elif item.kind == "note":
                # Offload to executor: reads a markdown file from disk
                # (ticket #25 — sync disk I/O on the loop blocks broadcasts).
                body = await asyncio.to_thread(
                    _read_note_body,
                    Path(self._config.recordings_dir),
                    item.id,
                )
                candidates.append({
                    "kind": "note",
                    "id": item.id,
                    "title": item.title,
                    "body": body,
                })
            elif item.kind == "action_item":
                # Offload _find_action_item to executor: it walks the
                # action_items store on disk and would otherwise block the
                # asyncio loop during the topic-worker tick (ticket #25).
                ai = await asyncio.to_thread(_find_action_item, self._config, item.id)
                candidates.append({
                    "kind": "action_item",
                    "id": item.id,
                    "title": item.title,
                    "description": (ai.get("description") if ai else "") or "",
                })

        if not candidates:
            return

        picked = await pick_topic_from_candidates(
            _state, self._config, candidates,
        )
        if picked is None:
            return

        topic_str = picked.get("title") or ""
        ticket_ids = (
            [picked.get("id")] if picked.get("kind") == "ticket" else []
        )
        prev = _state.current_topic or {}
        _state.current_topic = {
            "topic": topic_str,
            "ticket_ids": ticket_ids,
            "search_query": topic_str,
            "last_user_statement": prev.get("last_user_statement", ""),
        }
        _state.current_topic_cards = [picked]

        try:
            from meeting_helper.server.websocket import (
                broadcast,
                slim_card_for_broadcast,
            )
            await broadcast({
                "type": "topic",
                "topic": topic_str,
                "source": picked.get("kind", "ticket"),
                "ticket_ids": ticket_ids,
                "search_query": topic_str,
                "last_user_statement": prev.get("last_user_statement", ""),
                "cards": [slim_card_for_broadcast(picked)],
                "pinned": [
                    {
                        "kind": p.kind,
                        "id": p.id,
                        "title": p.title,
                        "board_id": p.board_id,
                    }
                    for p in _state.pinned_topics
                ],
                "hot_moment": {
                    "active": _state.is_hot_moment(),
                    "until_wallclock": _state.hot_moment_until_wallclock(),
                },
            })
        except Exception as exc:
            logger.warning("topic broadcast failed: %s", exc)

        logger.info(
            "TopicWorker picked from basket: kind=%s topic=%r",
            picked.get("kind"), topic_str,
        )

    async def _pick_from_sprint_and_action_items(self, labeled, text) -> None:
        """Legacy auto leg: refresh sprint cache, ask the LLM picker, optionally
        fall back to the action-item matcher when no ticket clearly fits.
        """
        # Constrained pick: use the cached sprint tickets as the LLM's
        # candidate list. Avoids free-form drift and survives transcription
        # noise (the LLM understands "tribute remapper" = "the remapper").
        from meeting_helper.ai.client import (
            pick_topic_ticket,
            refresh_sprint_tickets,
        )
        from meeting_helper.state import state

        await refresh_sprint_tickets(state)
        picked = await pick_topic_ticket(state, self._config, question="")

        # Action-item candidate leg. Only fires when the ticket pick failed —
        # a successful ticket pick is treated as confidence 1.0 and an action
        # item can never beat that, so the extra LLM call is wasted. Also
        # requires a minimum confidence to win: at low confidence the matcher
        # is just guessing on transcription noise, and overriding "no topic"
        # with a random pending item is worse than leaving the banner alone.
        ACTION_ITEM_CONFIDENCE_FLOOR = 0.7

        action_item_winner = self._maybe_match_action_item_sync_safe(text)
        if (
            action_item_winner is None
            and picked is None  # only spend an LLM call when no ticket matched
            and getattr(self._config, "action_items_inject_into_copilot", True)
        ):
            action_item_winner = await self._match_action_item(text)

        ticket_confidence = 1.0 if picked is not None else 0.0
        ai_confidence = (
            float(action_item_winner.get("confidence") or 0.0)
            if action_item_winner else 0.0
        )

        if (
            action_item_winner
            and ai_confidence >= ACTION_ITEM_CONFIDENCE_FLOOR
            and ai_confidence > ticket_confidence
        ):
            item = action_item_winner["item"]
            topic_str = item.get("title") or ""
            prev = state.current_topic or {}
            state.current_topic = {
                "topic": topic_str,
                "ticket_ids": [],
                "search_query": topic_str,
                "last_user_statement": prev.get("last_user_statement", ""),
            }
            state.current_topic_cards = []
            try:
                from meeting_helper.server.websocket import broadcast
                await broadcast({
                    "type": "topic",
                    "topic": topic_str,
                    "source": "action_item",
                    "action_item_id": item.get("id"),
                    "description": item.get("description") or "",
                    "ticket_ids": [],
                    "cards": [],
                    "last_user_statement": prev.get("last_user_statement", ""),
                    "hot_moment": {
                        "active": state.is_hot_moment(),
                        "until_wallclock": state.hot_moment_until_wallclock(),
                    },
                })
            except Exception as exc:
                logger.warning("topic broadcast failed: %s", exc)
            logger.info(
                "TopicWorker picked action item: topic=%r id=%s",
                topic_str, item.get("id"),
            )
            return

        if picked is None:
            # Nothing in the sprint cache matched the conversation. Leave
            # state.current_topic alone so we don't blank the banner on a
            # transient mismatch.
            logger.debug("TopicWorker: no sprint match for current discussion")
            return

        topic_str = picked.get("title") or picked.get("_llm_topic") or ""
        ticket_ids = [picked.get("id")] if picked.get("id") else []
        cards = [picked]

        prev = state.current_topic or {}
        state.current_topic = {
            "topic": topic_str,
            "ticket_ids": ticket_ids,
            "search_query": picked.get("_llm_topic") or topic_str,
            "last_user_statement": prev.get("last_user_statement", ""),
        }
        state.current_topic_cards = cards

        # Broadcast so UIs can show what the agent thinks. Slim the cards —
        # full local-todo records can blow the WS frame and disconnect the GUI
        # (see slim_card_for_broadcast docstring).
        try:
            from meeting_helper.server.websocket import broadcast, slim_card_for_broadcast
            await broadcast({
                "type": "topic",
                "topic": topic_str,
                "source": "ticket",
                "ticket_ids": ticket_ids,
                "last_user_statement": prev.get("last_user_statement", ""),
                "cards": [slim_card_for_broadcast(c) for c in cards],
                "hot_moment": {
                    "active": state.is_hot_moment(),
                    "until_wallclock": state.hot_moment_until_wallclock(),
                },
            })
        except Exception as exc:
            logger.warning("topic broadcast failed: %s", exc)

        logger.info(
            "TopicWorker picked: topic=%r ticket_id=%s",
            topic_str,
            ticket_ids[0] if ticket_ids else None,
        )

    def _maybe_match_action_item_sync_safe(self, _text: str):
        """Hook reserved for tests that want to short-circuit the matcher
        without running it. Production always returns None — the real match
        runs via ``_match_action_item``.
        """
        return None

    async def _match_action_item(self, buffer_text: str):
        """Run the action-item topic candidate matcher against the workspace's
        open items. Returns ``{item, confidence}`` or ``None``.

        Narrow try/except: only swallow expected failure modes (LLM/network/
        timeout, malformed LLM JSON, disk I/O). Programmer bugs like
        ``AttributeError``/``KeyError``/``ImportError`` must propagate so they
        surface in dev instead of silently degrading the matcher.
        """
        try:
            from pathlib import Path
            from meeting_helper.action_items import (
                store as action_items_store,
                topic_candidate,
            )
            from meeting_helper.config import workspace_path

            recordings = Path(self._config.recordings_dir)
            ws_name = getattr(self._config, "workspace_name", "") or ""
            if not ws_name:
                # No workspace selected — nothing to match against. Skip
                # cleanly rather than feeding ``list_all`` an empty Path
                # (``with_suffix`` then raises ValueError).
                return None
            ws_json = workspace_path(ws_name)
            all_items = await action_items_store.list_all_async(ws_json, recordings)
            open_items = [i for i in all_items if not i.get("completed")]
            if not open_items:
                return None
            return await topic_candidate.match(
                buffer_text=buffer_text,
                open_items=open_items,
                ai_client=_TopicWorkerAIClient(self._config),
            )
        except (
            OSError,
            asyncio.TimeoutError,
            json.JSONDecodeError,
            RuntimeError,
        ) as exc:
            logger.warning("action-item matcher failed: %s", exc)
            return None

    async def _extract_topic(self, labeled: list[tuple[str, str]]) -> dict:
        """Call the user's configured AI provider to extract topic info."""
        from meeting_helper.ai.client import _call_ai_for_tasks
        from meeting_helper.ai.prompts import (
            TOPIC_EXTRACTION_SYSTEM_PROMPT,
            build_topic_extraction_user_message,
        )

        from meeting_helper.state import state
        prev_topic = (state.current_topic or {}).get("topic", "")
        user_msg = build_topic_extraction_user_message(
            labeled_sentences=labeled,
            previous_topic=prev_topic,
        )
        try:
            raw = await _call_ai_for_tasks(
                self._config, TOPIC_EXTRACTION_SYSTEM_PROMPT, user_msg, kind="topic"
            )
        except Exception as exc:
            logger.warning("topic extraction AI call failed: %s", exc)
            return dict(_EMPTY_TOPIC)

        if not raw or not raw.strip():
            return dict(_EMPTY_TOPIC)

        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            return dict(_EMPTY_TOPIC)
        try:
            parsed = json.loads(match.group())
        except json.JSONDecodeError:
            return dict(_EMPTY_TOPIC)

        return {
            "topic": str(parsed.get("topic", "")).strip(),
            "ticket_ids": [str(t).strip() for t in (parsed.get("ticket_ids") or []) if str(t).strip()],
            "search_query": str(parsed.get("search_query", "")).strip(),
            "last_user_statement": str(parsed.get("last_user_statement", "")).strip(),
        }


# ---------------------------------------------------------------------------
# Basket leg helpers — module-level so tests can monkeypatch them by name.
# ---------------------------------------------------------------------------


def _find_ticket_card(state, ticket_id: str) -> dict | None:
    """Look up the hydrated card for a pinned ticket id in the sprint cache."""
    cache = getattr(state, "sprint_tickets", None) or []
    for card in cache:
        if str(card.get("id")) == str(ticket_id):
            return card
    return None


def _read_note_body(recordings_dir, note_id: str) -> str:
    """Read the full body of a note file under recordings_dir.

    Accepts either the bare note id or the full `<id>.note.md` filename.
    Returns "" on any I/O failure - the caller treats missing body as
    "title-only candidate".
    """
    from pathlib import Path

    note_filename = (
        note_id if note_id.endswith(".note.md") else f"{note_id}.note.md"
    )
    path = Path(recordings_dir) / note_filename
    try:
        return path.read_text(errors="ignore")
    except OSError:
        return ""


def _find_action_item(config, action_item_id: str) -> dict | None:
    """Resolve a pinned action-item id back to its store row.

    Returns None for both "not found" and known I/O failures. Programmer
    bugs (AttributeError/KeyError/ImportError) propagate so they surface
    in dev rather than silently degrading the basket leg.
    """
    import json as _json
    from pathlib import Path
    from meeting_helper.action_items import store as ai_store
    from meeting_helper.config import workspace_path

    ws_name = getattr(config, "workspace_name", "") or ""
    if not ws_name:
        return None
    try:
        ws_json = workspace_path(ws_name)
        recordings = Path(config.recordings_dir)
        for it in ai_store.list_all(ws_json, recordings):
            if it.get("id") == action_item_id:
                return it
    except (OSError, _json.JSONDecodeError) as exc:
        logger.warning(
            "_find_action_item: store read failed for id=%s: %s",
            action_item_id, exc,
        )
        return None
    return None
