"""Retrieve KB cards (📚 meeting summaries + notes) for the current query.

Called from the query handler. Pure local file I/O, no network. Failure
isolated: any exception returns an empty list so the local-todo cards
path is unaffected.
"""

from __future__ import annotations

import asyncio
import logging
import re
import shutil
import subprocess
from dataclasses import dataclass
from datetime import date as _date
from datetime import datetime as _datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from meeting_helper.config import Config

logger = logging.getLogger(__name__)

# Duration cache keyed by (absolute path, mtime). Persists for the daemon
# lifetime so re-listing the library doesn't re-shell ffprobe for every
# mp3. Bounded by the number of recordings on disk — small enough we don't
# need a true LRU.
_duration_cache: dict[tuple[str, float], float | None] = {}

# Per-call cap on synchronous ffprobe shellouts. Listing a workspace with
# 500 recordings shouldn't pause the event loop for 250 s; everything
# beyond the cap simply gets `duration_sec=None` until a later list call
# picks it up (the cache makes that cheap once probed). Probes are
# scheduled newest-first so the rows the user is most likely to see get a
# duration on the very first listing.
_DURATION_PROBE_BUDGET = 200
_DURATION_PROBE_TIMEOUT_SEC = 0.5

# A small, English stopword list. Generic words add no signal and pollute
# the overlap score. Kept private so it can be extended without bumping
# the module's public surface.
_STOPWORDS: frozenset[str] = frozenset({
    "the", "a", "an", "and", "or", "but", "if", "then", "else", "of",
    "to", "in", "on", "at", "by", "for", "with", "without", "from",
    "is", "are", "was", "were", "be", "been", "being", "do", "does",
    "did", "have", "has", "had", "will", "would", "could", "should",
    "can", "may", "might", "this", "that", "these", "those", "it",
    "its", "i", "you", "he", "she", "we", "they", "me", "him", "her",
    "us", "them", "my", "your", "his", "our", "their", "as", "so",
    "not", "no", "yes", "ok", "okay", "just", "than", "about", "into",
    "out", "up", "down", "over", "under", "again", "more", "most",
    "some", "any", "all", "each", "every", "very", "now", "also",
})

_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")


def tokenize(text: str) -> set[str]:
    """Lowercase tokens of length >= 3, with stopwords removed."""
    if not text:
        return set()
    return {
        tok for tok in (m.group().lower() for m in _TOKEN_RE.finditer(text))
        if len(tok) >= 3 and tok not in _STOPWORDS
    }


def score_artifact(*, blob_tokens: set[str], body: str, age_days: float) -> float:
    """Score an artifact body against the query blob's tokens.

    Primary signal: count of distinct token overlaps.
    Secondary signal: a small recency boost — at most `recency_weight` × overlap.
    Zero overlap → zero score (the recency boost cannot rescue an irrelevant doc).
    """
    body_tokens = tokenize(body)
    overlap = len(blob_tokens & body_tokens)
    if overlap == 0:
        return 0.0
    # Recency: linear from 1.0 at age=0 to 0.0 at age>=30 days. Capped to a
    # 20% bonus over the overlap so it never overrides a clearly better
    # content match.
    recency = max(0.0, 1.0 - max(0.0, age_days) / 30.0)
    recency_weight = 0.2 * overlap
    return float(overlap) + recency * recency_weight


@dataclass(frozen=True)
class KbCard:
    """A retrieved KB artifact ready for prompt rendering."""
    id: str          # filename, e.g. "2026-05-03.summary.txt"
    kind: str        # "meeting" | "note"
    title: str
    date: str        # YYYY-MM-DD or "" when unknown
    body: str        # raw text content of the artifact
    score: float


_TIMESTAMP_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})_\d{6}(?:_(.+))?$")


def _parse_meeting_stem(stem: str) -> tuple[str, str]:
    """Return (date, title) parsed from a meeting filename stem.

    Stems look like '2026-05-08_193029' or '2026-05-08_193029_Daily_Standup'.
    Falls back to ('', stem) when the format doesn't match.
    """
    m = _TIMESTAMP_RE.match(stem)
    if not m:
        return "", stem
    date = m.group(1)
    if m.group(2):
        title = m.group(2).replace("_", " ")
    else:
        title = stem  # no human label; show the whole stem so it's still identifiable
    return date, title


def _meeting_stem_from_summary(filename: str) -> str:
    if filename.endswith(".summary.txt"):
        return filename[: -len(".summary.txt")]
    return Path(filename).stem


def _note_title(filename: str) -> str:
    if filename.endswith(".note.md"):
        return filename[: -len(".note.md")].replace("-", " ")
    return Path(filename).stem


def load_artifacts(*, recordings_dir: Path, kb_filenames: list[str]) -> list[KbCard]:
    """Load every KB-flagged artifact from disk into KbCards (without scoring).

    Missing files are silently skipped. Returns an empty list when the
    recordings directory itself is missing.
    """
    if not recordings_dir.is_dir():
        return []
    out: list[KbCard] = []
    for fname in kb_filenames:
        fpath = recordings_dir / fname
        if not fpath.is_file():
            continue
        try:
            body = fpath.read_text(errors="ignore")
        except OSError:
            continue
        if fname.endswith(".summary.txt"):
            stem = _meeting_stem_from_summary(fname)
            date, title = _parse_meeting_stem(stem)
            out.append(KbCard(
                id=fname,
                kind="meeting",
                title=title,
                date=date,
                body=body,
                score=0.0,
            ))
        elif fname.endswith(".note.md"):
            out.append(KbCard(
                id=fname,
                kind="note",
                title=_note_title(fname),
                date="",
                body=body,
                score=0.0,
            ))
        # Anything else → silently skipped
    return out


def _age_days(date_str: str) -> float:
    """Return age in days for a YYYY-MM-DD string. Returns a large value for unparseable input."""
    if not date_str:
        return 365.0  # unknown → treat as a year old (no recency boost)
    try:
        d = _date.fromisoformat(date_str)
    except ValueError:
        return 365.0
    delta = (_date.today() - d).days
    return float(max(0, delta))


def _retrieve_sync(
    *,
    query_text: str,
    self_buffer_text: str,
    other_buffer_text: str,
    recordings_dir: Path,
    kb_filenames: list[str],
    max_results: int,
) -> list[KbCard]:
    """Synchronous core of retrieve_kb_cards. Designed to run in a thread."""
    blob = " ".join(t for t in (query_text, self_buffer_text, other_buffer_text) if t)
    blob_tokens = tokenize(blob)
    if not blob_tokens or not kb_filenames:
        return []

    artifacts = load_artifacts(recordings_dir=recordings_dir, kb_filenames=kb_filenames)
    scored: list[KbCard] = []
    for art in artifacts:
        s = score_artifact(
            blob_tokens=blob_tokens,
            body=art.body,
            age_days=_age_days(art.date),
        )
        if s > 0:
            scored.append(KbCard(
                id=art.id,
                kind=art.kind,
                title=art.title,
                date=art.date,
                body=art.body,
                score=s,
            ))
    scored.sort(key=lambda c: c.score, reverse=True)
    return scored[:max_results]


async def retrieve_kb_cards(
    *,
    query_text: str,
    self_buffer_text: str,
    other_buffer_text: str,
    config: "Config",
) -> list[KbCard]:
    """Top-N KB cards for the current query. Failure-isolated: returns [] on error."""
    try:
        recordings_dir = Path(config.recordings_dir)
        kb_filenames = list(config.kb_artifacts)
        max_results = int(config.kb_max_results)
        return await asyncio.to_thread(
            _retrieve_sync,
            query_text=query_text,
            self_buffer_text=self_buffer_text,
            other_buffer_text=other_buffer_text,
            recordings_dir=recordings_dir,
            kb_filenames=kb_filenames,
            max_results=max_results,
        )
    except Exception as exc:
        logger.warning("retrieve_kb_cards failed: %s", exc, exc_info=True)
        return []


@dataclass(frozen=True)
class LibraryItem:
    """A row in the Library list — either a meeting (with adjacent files) or a note."""
    id: str               # for meetings: the stem (e.g. "2026-05-08_193029"); for notes: the filename
    kind: str             # "meeting" | "note"
    title: str            # human-friendly display name
    date: str             # YYYY-MM-DD or ""
    sort_key: str         # used for newest-first ordering
    has_mp3: bool         # meeting only
    has_live: bool        # meeting only
    has_transcript: bool  # meeting only
    has_summary: bool     # meeting only
    summary_filename: str # meeting only — "" when no summary exists
    note_filename: str    # note only — "" for meetings
    favorited: bool = False
    in_kb: bool = False
    duration_sec: float | None = None  # meeting only — populated by ffprobe when available


def _ffprobe_path() -> str | None:
    """Return a usable ffprobe binary path, or None when probing is impossible.

    Prefers `$PATH` (Homebrew, system) since `imageio-ffmpeg` only bundles
    ffmpeg, not ffprobe. Tries a sibling of the bundled ffmpeg as a last
    resort — some distributions ship them together.
    """
    found = shutil.which("ffprobe")
    if found:
        return found
    try:
        from meeting_helper.audio.encoder import FFMPEG_PATH
    except Exception:  # pragma: no cover — encoder is always importable in practice
        return None
    sibling = Path(FFMPEG_PATH).with_name("ffprobe")
    if sibling.is_file():
        return str(sibling)
    return None


def _probe_duration(mp3: Path, ffprobe: str) -> float | None:
    """Synchronously read the mp3 duration in seconds. Returns None on failure.

    Cached by (path, mtime) so repeated list_artifacts calls don't re-shell.
    """
    try:
        st = mp3.stat()
    except OSError:
        return None
    key = (str(mp3), st.st_mtime)
    cached = _duration_cache.get(key)
    if cached is not None or key in _duration_cache:
        return cached
    try:
        result = subprocess.run(
            [
                ffprobe, "-v", "quiet",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                str(mp3),
            ],
            capture_output=True,
            text=True,
            timeout=_DURATION_PROBE_TIMEOUT_SEC,
        )
        if result.returncode == 0:
            secs = float(result.stdout.strip())
            _duration_cache[key] = secs
            return secs
    except (subprocess.TimeoutExpired, ValueError, OSError):
        pass
    # Cache the failure too so we don't retry an unreadable file every call.
    _duration_cache[key] = None
    return None


def list_artifacts(
    *, recordings_dir: Path, config: "Config | None" = None,
) -> list[LibraryItem]:
    """Scan recordings_dir and return a unified, newest-first list of meetings + notes.

    When ``config`` is provided, each row carries the workspace's current
    favorite / KB flags so the list view can render the badges without a
    per-row roundtrip.
    """
    if not recordings_dir.is_dir():
        return []

    items: list[LibraryItem] = []
    ffprobe_bin = _ffprobe_path()
    probe_budget = _DURATION_PROBE_BUDGET

    # --- Meetings (one row per .mp3) ---
    # Probe newest-first so the rows the user sees on top of the list get a
    # duration on the very first listing. Display order is re-sorted below.
    mp3_paths = sorted(recordings_dir.glob("*.mp3"), reverse=True)
    for mp3 in mp3_paths:
        stem = mp3.stem
        date, title = _parse_meeting_stem(stem)
        live_path = mp3.with_suffix(".live.txt")
        transcript_path = mp3.with_suffix(".transcript.txt")
        summary_path = mp3.with_suffix(".summary.txt")
        # sort_key must capture the full timestamp, not just the date —
        # keying on `date` alone collapsed every same-day recording into one
        # bucket, so they fell back to filesystem (oldest-first) order. The
        # stem is `YYYY-MM-DD_HHMMSS[_title]` and sorts correctly lexically;
        # for non-timestamped stems fall back to the mp3's mtime in the same
        # format so it stays comparable.
        if date:
            sort_key = stem
        else:
            try:
                _mtime = mp3.stat().st_mtime
            except OSError:
                _mtime = 0.0
            sort_key = _datetime.fromtimestamp(_mtime).strftime("%Y-%m-%d_%H%M%S")
        mp3_name = mp3.name
        summary_name = summary_path.name
        favorited = bool(config and config.is_favorite(mp3_name))
        in_kb = bool(config and config.is_kb(summary_name))
        duration_sec: float | None = None
        if ffprobe_bin is not None:
            # Cache lookup is free; only count against the budget when we
            # actually have to shell out.
            try:
                st_mtime = mp3.stat().st_mtime
                cache_key = (str(mp3), st_mtime)
            except OSError:
                cache_key = None
            if cache_key is not None and cache_key in _duration_cache:
                duration_sec = _duration_cache[cache_key]
            elif probe_budget > 0:
                probe_budget -= 1
                duration_sec = _probe_duration(mp3, ffprobe_bin)
        items.append(LibraryItem(
            id=stem,
            kind="meeting",
            title=title,
            date=date,
            sort_key=sort_key,
            has_mp3=True,
            has_live=live_path.is_file(),
            has_transcript=transcript_path.is_file(),
            has_summary=summary_path.is_file(),
            summary_filename=summary_path.name if summary_path.is_file() else "",
            note_filename="",
            favorited=favorited,
            in_kb=in_kb,
            duration_sec=duration_sec,
        ))

    # --- Notes (one row per .note.md) ---
    note_paths = sorted(recordings_dir.glob("*.note.md"))
    for note in note_paths:
        try:
            mtime = note.stat().st_mtime
        except OSError:
            mtime = 0.0
        # Use ISO-formatted mtime so the unified sort_key field is comparable
        sort_key = _datetime.fromtimestamp(mtime).strftime("%Y-%m-%d_%H%M%S")
        note_name = note.name
        favorited = bool(config and config.is_favorite(note_name))
        in_kb = bool(config and config.is_kb(note_name))
        items.append(LibraryItem(
            id=note.name,
            kind="note",
            title=_note_title(note.name),
            date="",
            sort_key=sort_key,
            has_mp3=False,
            has_live=False,
            has_transcript=False,
            has_summary=False,
            summary_filename="",
            note_filename=note.name,
            favorited=favorited,
            in_kb=in_kb,
        ))

    # newest-first
    items.sort(key=lambda i: i.sort_key, reverse=True)
    return items
