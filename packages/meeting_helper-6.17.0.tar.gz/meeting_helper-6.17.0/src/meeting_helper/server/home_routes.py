"""HTTP handlers for `/home/layout` (per-workspace dashboard layout).

Reads / writes through `request.app["disk_factory"]()` (or the in-memory
shim in tests) -- never through `config.get_config()`. The shim's `home`
property mirrors the same shape as `Config.home`; an empty list is
returned verbatim so a user's intentional empty layout is preserved
(the frontend hook supplies defaults on its side when needed).
"""
from __future__ import annotations

import logging
from typing import Any

from aiohttp import web

logger = logging.getLogger(__name__)


def _resolve_disk(request: web.Request):
    factory = request.app.get("disk_factory")
    if factory is not None:
        try:
            return factory()
        except Exception:
            logger.warning(
                "home._resolve_disk: disk_factory raised; falling back to shim",
                exc_info=True,
            )
    from meeting_helper.trackers.shim import InMemoryDiskShim
    return InMemoryDiskShim(request.app["config"])


async def get_home_layout(request: web.Request) -> web.Response:
    disk = _resolve_disk(request)
    widgets = list((getattr(disk, "home", None) or {}).get("widgets") or [])
    return web.json_response({"widgets": widgets})


def _is_number(value: Any) -> bool:
    # bool is a subclass of int; reject it so flags can't pose as coordinates.
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _is_valid_widget(widget: Any) -> bool:
    if not isinstance(widget, dict):
        return False
    if not isinstance(widget.get("id"), str):
        return False
    if not all(_is_number(widget.get(k)) for k in ("x", "y", "w", "h")):
        return False
    if "hidden" in widget and not isinstance(widget["hidden"], bool):
        return False
    return True


async def put_home_layout(request: web.Request) -> web.Response:
    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise web.HTTPBadRequest(
            text='{"error": "invalid JSON"}',
            content_type="application/json",
        )

    widgets = payload.get("widgets")
    if not isinstance(widgets, list):
        raise web.HTTPBadRequest(
            text='{"error": "widgets must be a list"}',
            content_type="application/json",
        )

    for w in widgets:
        if not _is_valid_widget(w):
            raise web.HTTPBadRequest(
                text='{"error": "malformed widget element"}',
                content_type="application/json",
            )

    disk = _resolve_disk(request)
    disk.home = {"widgets": widgets}
    disk.save()
    return web.json_response({"ok": True})


def register(app: web.Application) -> None:
    app.router.add_get("/home/layout", get_home_layout)
    app.router.add_put("/home/layout", put_home_layout)
