"""REST endpoints for the embedded task manager (MH-40)."""
from __future__ import annotations

from typing import Any

from aiohttp import web

from meeting_helper.trackers.vendors.meeting_helper_store import (
    MeetingHelperStore,
    UNSET,
    UPLOAD_ALLOWED_MIMES,
    UPLOAD_MAX_BYTES,
)


def _store(request: web.Request) -> MeetingHelperStore:
    factory = request.app.get("disk_factory")
    if factory is None:
        raise web.HTTPInternalServerError(text="disk_factory not configured")
    return MeetingHelperStore(factory())


def _int_param(request: web.Request, name: str) -> int:
    """Convert a path-match int param, raising 400 if it isn't a valid int.

    Without this, `int()` raises ValueError which aiohttp surfaces as a bare
    500. Path params come from user input and deserve a real 400.
    """
    raw = request.match_info.get(name, "")
    try:
        return int(raw)
    except (TypeError, ValueError):
        raise web.HTTPBadRequest(text=f"{name} must be an integer")


def _parse_sprint_query(raw: str | None) -> Any:
    """Convert a `sprint_id` query string into the store's filter shape.

    Accepts: missing/empty -> UNSET (no filter), the literals `active`,
    `backlog`, `closed`, `all`, the literal `null`/`none` -> None
    (backlog), or a decimal integer. Returns 400 on anything else.
    """
    if raw is None:
        return UNSET
    val = raw.strip().lower()
    if val == "":
        return UNSET
    if val in ("null", "none"):
        return None
    if val in ("active", "backlog", "closed", "all"):
        return val
    try:
        return int(val)
    except ValueError:
        raise web.HTTPBadRequest(
            text="sprint_id must be int, 'active', 'backlog', 'closed', 'all', or 'null'"
        )


def _task_payload(t) -> dict:
    return {
        "id": t.id,
        "title": t.title,
        "description": t.description,
        "status": t.status,
        "priority": t.priority,
        "mr_links": list(t.mr_links),
        "thread_links": list(t.thread_links),
        "parent_id": t.parent_id,
        "sprint_id": t.sprint_id,
        "created_at": t.created_at,
        "updated_at": t.updated_at,
        "comments": [
            {
                "id": c.id,
                "text": c.text,
                "author": c.author,
                "created_at": c.created_at,
                "updated_at": c.updated_at,
            }
            for c in t.comments
        ],
    }


def _sprint_payload(s) -> dict:
    return {
        "id": s.id,
        "name": s.name,
        "state": s.state,
        "created_at": s.created_at,
        "closed_at": s.closed_at,
    }


async def list_tasks(request: web.Request) -> web.Response:
    store = _store(request)
    status = request.query.get("status") or None
    priority = request.query.get("priority") or None
    sort_by = request.query.get("sort_by") or None
    sort_direction = request.query.get("sort_direction") or None
    parent_id_raw = request.query.get("parent_id")
    if parent_id_raw is None:
        parent_id = UNSET
    elif parent_id_raw in ("null", "none", ""):
        parent_id = None
    else:
        try:
            parent_id = int(parent_id_raw)
        except ValueError:
            raise web.HTTPBadRequest(text="parent_id must be int or 'null'")
    sprint_filter = _parse_sprint_query(request.query.get("sprint_id"))
    try:
        out = store.list_tasks(
            status=status, priority=priority, parent_id=parent_id,
            sprint_id=sprint_filter, sort_by=sort_by,
            sort_direction=sort_direction,
        )
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response([_task_payload(t) for t in out])


async def get_task(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    try:
        return web.json_response(_task_payload(store.get_task(tid)))
    except KeyError:
        raise web.HTTPNotFound(text=f"task {tid} not found")


async def create_task(request: web.Request) -> web.Response:
    from meeting_helper.trackers.vendors.meeting_helper_types import (
        DEFAULT_PRIORITY,
    )
    store = _store(request)
    body = await request.json()
    kwargs: dict[str, Any] = {
        "title": body.get("title", ""),
        "description": body.get("description", ""),
        "status": body.get("status", "Todo"),
        "priority": body.get("priority", DEFAULT_PRIORITY),
        "parent_id": body.get("parent_id"),
        "mr_links": body.get("mr_links") or [],
        "thread_links": body.get("thread_links") or [],
    }
    # Only pass sprint_id when explicitly present so the store's UNSET
    # default (inherit active sprint) keeps working when callers omit it.
    if "sprint_id" in body:
        kwargs["sprint_id"] = body["sprint_id"]
    try:
        t = store.create_task(**kwargs)
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    except KeyError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response(_task_payload(t))


async def patch_task(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    body = await request.json()
    allowed = {
        "title",
        "description",
        "status",
        "priority",
        "parent_id",
        "mr_links",
        "thread_links",
        "sprint_id",
    }
    fields = {k: v for k, v in body.items() if k in allowed}
    try:
        t = store.update_task(tid, **fields)
    except KeyError:
        raise web.HTTPNotFound(text=f"task {tid} not found")
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response(_task_payload(t))


async def delete_task(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    try:
        return web.json_response(store.delete_task(tid))
    except KeyError:
        raise web.HTTPNotFound(text=f"task {tid} not found")


async def add_comment(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    body = await request.json()
    try:
        c = store.add_comment(tid, text=body.get("text", ""), author="user")
    except KeyError:
        raise web.HTTPNotFound(text=f"task {tid} not found")
    return web.json_response(
        {
            "id": c.id,
            "text": c.text,
            "author": c.author,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
    )


async def update_comment(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    cid = _int_param(request, "cid")
    body = await request.json()
    try:
        c = store.update_comment(tid, cid, text=body.get("text", ""))
    except KeyError:
        raise web.HTTPNotFound()
    return web.json_response(
        {
            "id": c.id,
            "text": c.text,
            "author": c.author,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
    )


async def delete_comment(request: web.Request) -> web.Response:
    store = _store(request)
    tid = _int_param(request, "id")
    cid = _int_param(request, "cid")
    try:
        store.delete_comment(tid, cid)
    except KeyError:
        raise web.HTTPNotFound()
    return web.json_response({"deleted": True})


async def list_statuses(request: web.Request) -> web.Response:
    return web.json_response(_store(request).list_statuses())


async def list_priorities(request: web.Request) -> web.Response:
    return web.json_response(_store(request).list_priorities())


async def list_sort_options(request: web.Request) -> web.Response:
    return web.json_response(_store(request).list_sort_options())


async def list_sort_directions(request: web.Request) -> web.Response:
    return web.json_response(_store(request).list_sort_directions())


async def put_visible_statuses(request: web.Request) -> web.Response:
    body = await request.json()
    names = body.get("visible_statuses") or []
    try:
        _store(request).set_visible_statuses(names)
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response({"ok": True})


# ---- sprints ------------------------------------------------------------


async def list_sprints(request: web.Request) -> web.Response:
    store = _store(request)
    sprints = [_sprint_payload(s) for s in store.list_sprints()]
    active = store.get_active_sprint()
    return web.json_response({
        "sprints": sprints,
        "active_sprint_id": active.id if active else None,
    })


async def create_sprint(request: web.Request) -> web.Response:
    store = _store(request)
    body = await request.json()
    try:
        s = store.create_sprint(
            name=body.get("name") or "",
            activate=bool(body.get("activate", True)),
        )
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response(_sprint_payload(s))


async def patch_sprint(request: web.Request) -> web.Response:
    """PATCH /api/mh-tasks/sprints/{id}.

    Supports rename ({name: "..."}) and activate ({active: true}). To
    deactivate or close a sprint, call POST /sprints/{id}/close instead —
    that endpoint also handles task carry-over.
    """
    store = _store(request)
    sid = _int_param(request, "id")
    body = await request.json()
    try:
        if body.get("active") is True:
            s = store.set_active_sprint(sid)
        elif body.get("active") is False:
            raise web.HTTPBadRequest(
                text="active=false is not supported; use POST /close to close a sprint"
            )
        elif "name" in body:
            s = store.update_sprint(sid, name=body["name"])
        else:
            raise web.HTTPBadRequest(
                text="patch requires 'name' or 'active' (true)"
            )
    except KeyError:
        raise web.HTTPNotFound(text=f"sprint {sid} not found")
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response(_sprint_payload(s))


async def close_sprint(request: web.Request) -> web.Response:
    store = _store(request)
    sid = _int_param(request, "id")
    body = await request.json() if request.body_exists else {}
    try:
        out = store.close_sprint(
            sid,
            new_sprint_name=body.get("new_sprint_name"),
            carry_over=bool(body.get("carry_over", True)),
        )
    except KeyError:
        raise web.HTTPNotFound(text=f"sprint {sid} not found")
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))
    return web.json_response(out)


async def delete_sprint(request: web.Request) -> web.Response:
    store = _store(request)
    sid = _int_param(request, "id")
    try:
        return web.json_response(store.delete_sprint(sid))
    except KeyError:
        raise web.HTTPNotFound(text=f"sprint {sid} not found")
    except ValueError as e:
        raise web.HTTPBadRequest(text=str(e))


# ---- uploads ------------------------------------------------------------


async def create_upload(request: web.Request) -> web.Response:
    """Accept a multipart image upload and store it in the workspace blob.

    Used by the task description + comment textareas in the embedded task
    manager UI. Multipart `file` field is required; allowed MIMEs are the
    common web image types, and the byte cap matches the store's cap.
    """
    # Reject obviously oversized requests before reading them into RAM. The
    # Content-Length check is cheap; the per-field check below catches the
    # case where the client lies about the header.
    declared = request.content_length
    if declared is not None and declared > UPLOAD_MAX_BYTES + 4096:
        raise web.HTTPRequestEntityTooLarge(
            max_size=UPLOAD_MAX_BYTES, actual_size=declared,
        )

    reader = await request.multipart()
    blob: bytes | None = None
    mime: str | None = None
    while True:
        part = await reader.next()
        if part is None:
            break
        if part.name != "file":
            # Drain unrelated fields to keep the parser happy.
            await part.read(decode=False)
            continue
        mime = part.headers.get("Content-Type", "").split(";", 1)[0].strip()
        # Read chunk-by-chunk so we can enforce the cap without buffering
        # an attacker-controlled multi-GB stream.
        buf = bytearray()
        while True:
            chunk = await part.read_chunk(size=64 * 1024)
            if not chunk:
                break
            buf.extend(chunk)
            if len(buf) > UPLOAD_MAX_BYTES:
                raise web.HTTPRequestEntityTooLarge(
                    max_size=UPLOAD_MAX_BYTES, actual_size=len(buf),
                )
        blob = bytes(buf)

    if blob is None or mime is None:
        raise web.HTTPBadRequest(text="missing 'file' multipart field")
    if mime not in UPLOAD_ALLOWED_MIMES:
        raise web.HTTPUnsupportedMediaType(
            text=f"unsupported mime: {mime!r}; allowed: {sorted(UPLOAD_ALLOWED_MIMES)}"
        )

    store = _store(request)
    try:
        meta = store.add_upload(blob, mime=mime)
    except ValueError as e:
        # The store enforces the same cap; surface as 413 if it tripped.
        msg = str(e)
        if "too large" in msg:
            raise web.HTTPRequestEntityTooLarge(
                max_size=UPLOAD_MAX_BYTES, actual_size=len(blob),
            )
        raise web.HTTPBadRequest(text=msg)
    return web.json_response(
        {
            "id": meta["id"],
            "url": f"/api/mh-tasks/uploads/{meta['id']}",
            "mime": meta["mime"],
            "byte_size": meta["byte_size"],
        }
    )


async def get_upload(request: web.Request) -> web.Response:
    uid = request.match_info.get("id", "")
    if not uid:
        raise web.HTTPNotFound()
    store = _store(request)
    found = store.get_upload(uid)
    if found is None:
        raise web.HTTPNotFound(text=f"upload {uid} not found")
    data, mime = found
    return web.Response(
        body=data,
        headers={
            "Content-Type": mime,
            "Cache-Control": "private, max-age=31536000, immutable",
            "X-Content-Type-Options": "nosniff",
        },
    )


# ---- mcp helpers --------------------------------------------------------


async def mcp_info(request: web.Request) -> web.Response:
    cfg = request.app["config"]
    port = getattr(cfg, "port", 7891)
    return web.json_response(
        {
            "url": f"http://127.0.0.1:{port}/mcp",
            "port": port,
        }
    )


async def mcp_workspaces(request: web.Request) -> web.Response:
    """List every workspace on disk with its pinned MCP URL.

    The UI uses this to populate the workspace dropdown on the Settings >
    MCP page. The pinned URL `/mcp/<name>` always serves that workspace's
    tasks regardless of which workspace is active in the desktop app.
    """
    from meeting_helper.config import list_workspaces, load_state

    cfg = request.app["config"]
    port = getattr(cfg, "port", 7891)
    base = f"http://127.0.0.1:{port}"
    active = load_state().get("active_workspace", "")
    workspaces = []
    for name in list_workspaces():
        workspaces.append(
            {
                "name": name,
                "url": f"{base}/mcp/{name}",
                "is_active": name == active,
            }
        )
    return web.json_response(
        {
            "workspaces": workspaces,
            "active_workspace": active,
            "shared_url": f"{base}/mcp",
        }
    )


def register(app: web.Application) -> None:
    app.router.add_get("/api/mh-tasks", list_tasks)
    app.router.add_post("/api/mh-tasks", create_task)
    app.router.add_get("/api/mh-tasks/statuses", list_statuses)
    app.router.add_put("/api/mh-tasks/statuses/visible", put_visible_statuses)
    # Register all literal-segment routes before /{id} so the literal wins.
    # Uploads first - the /{id} catch-all sits below.
    app.router.add_post("/api/mh-tasks/uploads", create_upload)
    app.router.add_get("/api/mh-tasks/uploads/{id}", get_upload)
    app.router.add_get("/api/mh-tasks/sprints", list_sprints)
    app.router.add_post("/api/mh-tasks/sprints", create_sprint)
    app.router.add_patch("/api/mh-tasks/sprints/{id}", patch_sprint)
    app.router.add_post("/api/mh-tasks/sprints/{id}/close", close_sprint)
    app.router.add_delete("/api/mh-tasks/sprints/{id}", delete_sprint)
    app.router.add_get("/api/mh-tasks/priorities", list_priorities)
    app.router.add_get("/api/mh-tasks/sort-options", list_sort_options)
    app.router.add_get("/api/mh-tasks/sort-directions", list_sort_directions)
    app.router.add_get("/api/mh-tasks/{id}", get_task)
    app.router.add_patch("/api/mh-tasks/{id}", patch_task)
    app.router.add_delete("/api/mh-tasks/{id}", delete_task)
    app.router.add_post("/api/mh-tasks/{id}/comments", add_comment)
    app.router.add_patch("/api/mh-tasks/{id}/comments/{cid}", update_comment)
    app.router.add_delete("/api/mh-tasks/{id}/comments/{cid}", delete_comment)
    app.router.add_get("/api/mcp/info", mcp_info)
    app.router.add_get("/api/mcp/workspaces", mcp_workspaces)
