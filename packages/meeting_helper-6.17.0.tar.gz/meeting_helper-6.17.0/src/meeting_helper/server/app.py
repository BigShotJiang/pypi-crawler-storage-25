"""aiohttp application factory."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from aiohttp import web

from meeting_helper.server.routes import setup_routes

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig


WEB_DIST = Path(__file__).resolve().parent.parent / "web" / "dist"


def create_app(config: "AppConfig", *, disk_factory=None) -> web.Application:
    app = web.Application()
    app["config"] = config
    app["disk_factory"] = disk_factory  # callable → current Config, or None for tests
    setup_routes(app)
    _setup_static(app)
    return app


def _setup_static(app: web.Application) -> None:
    """Mount the Next.js bundle at `/` and add an SPA fallback.

    Must run AFTER `setup_routes(app)` so API routes win over the static
    catch-all. The fallback returns `index.html` for any unknown GET that
    accepts text/html, so client-side routes (e.g. /settings/providers)
    resolve on hard refresh.

    A single catch-all handler is used instead of `add_static` + a separate
    fallback route because aiohttp's `add_static` returns a 404 itself on
    file-miss — it does NOT fall through to subsequently registered routes.
    Combining both behaviors into one handler lets us serve real bundle
    assets, return index.html for unknown HTML routes, and 404 cleanly for
    everything else (e.g. JSON API misses).
    """
    if not WEB_DIST.exists():
        # Source checkout without a built bundle — skip static registration
        # entirely so the daemon still serves the API. Plan 2's release
        # script ensures the bundle is present in published wheels.
        return

    index_path = WEB_DIST / "index.html"
    web_dist_resolved = WEB_DIST.resolve()

    async def index_handler(_: web.Request) -> web.StreamResponse:
        return web.FileResponse(index_path)

    async def static_or_spa_fallback(request: web.Request) -> web.StreamResponse:
        # Strip leading slash to get path relative to web/dist.
        rel = request.match_info.get("tail", "").lstrip("/")
        candidate = (web_dist_resolved / rel).resolve() if rel else web_dist_resolved
        # Defend against `..` traversal: candidate must stay inside web_dist.
        try:
            candidate.relative_to(web_dist_resolved)
        except ValueError:
            raise web.HTTPNotFound()
        if rel and candidate.is_file():
            # Next.js App Router emits <route>/index.txt as the RSC payload for
            # client-side hydration. The Next router fetches it with `RSC: 1`
            # and parses the response as text/x-component. But a browser-level
            # navigation (pywebview restoring last URL, a hard reload, the
            # webview's URL bar) sends `Accept: text/html` and would render
            # the raw `$Sreact.fragment` payload as the page content. Serve
            # the sibling index.html for those navigations; serve the
            # text/x-component payload only when the request looks like an
            # RSC prefetch. Same fix shape as 42658b8 for /library.
            if candidate.suffix == ".txt" and candidate.name == "index.txt":
                accept = request.headers.get("Accept", "")
                rsc_hint = request.headers.get("RSC") == "1"
                wants_rsc = rsc_hint or "x-component" in accept
                if not wants_rsc and "text/html" in accept:
                    sibling_html = candidate.with_name("index.html")
                    if sibling_html.is_file():
                        return web.FileResponse(sibling_html)
                return web.FileResponse(
                    candidate, headers={"Content-Type": "text/x-component"}
                )
            return web.FileResponse(candidate)
        # Directory match: Next's static export with `trailingSlash: true`
        # emits `<route>/index.html`, so serve that when the path resolves
        # to a directory with an `index.html` inside. This makes
        # `/settings/ai` and `/settings/ai/` both load the AI tab on hard
        # refresh, instead of falling back to the root SPA shell.
        if candidate.is_dir():
            dir_index = candidate / "index.html"
            if dir_index.is_file():
                return web.FileResponse(dir_index)
        # No matching file — SPA fallback only for HTML navigations.
        accept = request.headers.get("Accept", "")
        if "text/html" in accept:
            return web.FileResponse(index_path)
        raise web.HTTPNotFound()

    # Root handler explicitly serves index.html — handled separately from the
    # catch-all so a bare "/" request never depends on the Accept header.
    app.router.add_get("/", index_handler)
    # Catch-all GET for everything else under "/". API routes registered by
    # `setup_routes` are tried first because they were registered earlier.
    app.router.add_get("/{tail:.*}", static_or_spa_fallback)
