"""HTTP MCP endpoint exposing local task CRUD (MH-40).

Implements just enough of the MCP Streamable HTTP transport (single
JSON-RPC POST/response per request) to satisfy Claude Code and similar
clients. We don't use SSE here — every tool call is short and synchronous.
"""
from __future__ import annotations

import base64
import json
import logging
import re
from typing import Any

from aiohttp import web

from meeting_helper.server.websocket import broadcast
from meeting_helper.trackers.vendors.meeting_helper_store import (
    MeetingHelperStore,
    UNSET,
)

# Picks every distinct upload id mentioned anywhere in a task's text fields
# (description, comments). Matches the URLs the web hook inserts, e.g.
# `![alt](/api/mh-tasks/uploads/abc123)`.
_UPLOAD_URL_RE = re.compile(r"/api/mh-tasks/uploads/([A-Za-z0-9_-]+)")
from meeting_helper.trackers.vendors.meeting_helper_types import (
    PRIORITY_ORDER, SORT_BY_OPTIONS, SORT_DIRECTIONS, STATUS_ORDER,
)

logger = logging.getLogger(__name__)


# `list_tasks` defaults to the active sprint so the AI Copilot only sees
# current work. Pass `sprint_id="all"` to recover the legacy
# "every task ever" behavior, or any other recognized filter value.

_STATUS_SCHEMA = {"type": "string", "enum": list(STATUS_ORDER)}
_PRIORITY_SCHEMA = {"type": "string", "enum": list(PRIORITY_ORDER)}
_SORT_BY_SCHEMA = {
    "type": "string",
    "enum": list(SORT_BY_OPTIONS),
    "description": (
        "Sort the result. Pair with `sort_direction` to control order; if "
        "omitted, status/priority default ascending and created/updated "
        "default descending. All modes tiebreak by id ascending."
    ),
}
_SORT_DIRECTION_SCHEMA = {
    "type": "string",
    "enum": list(SORT_DIRECTIONS),
    "description": (
        "Sort direction. Only meaningful with `sort_by`. Omit to use the "
        "natural default for the chosen mode."
    ),
}


_TOOLS: list[dict[str, Any]] = [
    {
        "name": "list_tasks",
        "description": (
            "List tasks in the current (active) sprint by default. "
            "Use sprint_id to override: int (specific sprint), 'active', "
            "'backlog', 'closed', or 'all'. Optional filters: status=, "
            "priority=. Optional sort_by=status|priority|created|updated."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": _STATUS_SCHEMA,
                "priority": _PRIORITY_SCHEMA,
                "parent_id": {"type": ["integer", "null"]},
                "sprint_id": {
                    "type": ["integer", "string", "null"],
                    "description": (
                        "int -> sprint id, 'active'|'backlog'|'closed'|'all' "
                        "-> filter alias, null -> backlog."
                    ),
                },
                "sort_by": _SORT_BY_SCHEMA,
                "sort_direction": _SORT_DIRECTION_SCHEMA,
            },
        },
    },
    {
        "name": "get_task",
        "description": "Get a task by id (includes comments)",
        "inputSchema": {
            "type": "object",
            "properties": {"id": {"type": "integer"}},
            "required": ["id"],
        },
    },
    {
        "name": "create_task",
        "description": "Create a task (defaults to the active sprint)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "description": {"type": "string"},
                "status": _STATUS_SCHEMA,
                "priority": _PRIORITY_SCHEMA,
                "parent_id": {"type": ["integer", "null"]},
                "mr_links": {"type": "array", "items": {"type": "string"}},
                "thread_links": {"type": "array", "items": {"type": "string"}},
                "sprint_id": {
                    "type": ["integer", "null"],
                    "description": (
                        "Sprint to attach the task to. Omit to default to "
                        "the active sprint, or null for backlog."
                    ),
                },
            },
            "required": ["title"],
        },
    },
    {
        "name": "update_task",
        "description": "Update task fields by id",
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "integer"},
                "title": {"type": "string"},
                "description": {"type": "string"},
                "status": _STATUS_SCHEMA,
                "priority": _PRIORITY_SCHEMA,
                "parent_id": {"type": ["integer", "null"]},
                "mr_links": {"type": "array", "items": {"type": "string"}},
                "thread_links": {"type": "array", "items": {"type": "string"}},
                "sprint_id": {"type": ["integer", "null"]},
            },
            "required": ["id"],
        },
    },
    {
        "name": "delete_task",
        "description": "Delete a task and cascade its children + comments",
        "inputSchema": {
            "type": "object",
            "properties": {"id": {"type": "integer"}},
            "required": ["id"],
        },
    },
    {
        "name": "add_comment",
        "description": "Append a comment to a task (author=agent)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "integer"},
                "text": {"type": "string"},
            },
            "required": ["task_id", "text"],
        },
    },
    {
        "name": "update_comment",
        "description": "Edit an existing comment's text",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "integer"},
                "comment_id": {"type": "integer"},
                "text": {"type": "string"},
            },
            "required": ["task_id", "comment_id", "text"],
        },
    },
    {
        "name": "delete_comment",
        "description": "Delete a comment",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "integer"},
                "comment_id": {"type": "integer"},
            },
            "required": ["task_id", "comment_id"],
        },
    },
    {
        "name": "list_statuses",
        "description": "List canonical statuses with visibility",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_sprints",
        "description": (
            "List sprints (active first, then closed newest-first) along "
            "with the currently active_sprint_id."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "create_sprint",
        "description": (
            "Create a sprint. activate=true (default) makes it the new "
            "active sprint, closing the previous one. Empty name auto-fills "
            "as 'Sprint N'."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "activate": {"type": "boolean"},
            },
        },
    },
    {
        "name": "close_sprint",
        "description": (
            "Close a sprint. Done tasks stay attached to the closed sprint; "
            "non-Done tasks roll to a successor sprint (carry_over=true, "
            "the default) or to the backlog (carry_over=false). "
            "new_sprint_name names the successor when carry_over=true."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "integer"},
                "new_sprint_name": {"type": ["string", "null"]},
                "carry_over": {"type": "boolean"},
            },
            "required": ["id"],
        },
    },
    {
        "name": "move_task_to_sprint",
        "description": (
            "Set the sprint_id on a task. Pass null to move it to the "
            "backlog. Subtasks follow the parent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "integer"},
                "sprint_id": {"type": ["integer", "null"]},
            },
            "required": ["task_id", "sprint_id"],
        },
    },
    {
        "name": "list_priorities",
        "description": "List canonical priority values, highest first",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_sort_options",
        "description": "List canonical sort_by values usable on list_tasks",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_sort_directions",
        "description": "List canonical sort_direction values usable on list_tasks",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_notes",
        "description": (
            "List every note in the active workspace. Returns id, title, "
            "mtime, in_kb (knowledge-base flag), favorited, pinned, and a "
            "deep-link URL into the /notes UI."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_note",
        "description": (
            "Fetch the full body of one note by id (a *.note.md basename "
            "from list_notes)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
        },
    },
    {
        "name": "create_note",
        "description": (
            "Create a new note. title required, body optional, in_kb "
            "defaults false. Returns the new note's id and url."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "body": {"type": "string"},
                "in_kb": {"type": "boolean"},
            },
            "required": ["title"],
        },
    },
    {
        "name": "update_note",
        "description": (
            "Update a note's title and/or body. Renaming reslugs the file "
            "and migrates KB/favorite entries. Returns the (possibly new) id."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "title": {"type": "string"},
                "body": {"type": "string"},
            },
            "required": ["id"],
        },
    },
    {
        "name": "delete_note",
        "description": (
            "Delete a note. KB and favorite entries are cleaned up."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
        },
    },
    {
        "name": "set_note_kb",
        "description": (
            "Toggle a note's knowledge-base membership. KB-flagged notes "
            "are pulled into Copilot context by the retrieval ranker."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "value": {"type": "boolean"},
            },
            "required": ["id", "value"],
        },
    },
]


def _cfg(request: web.Request) -> Any:
    """Resolve the disk/Config object for this request.

    Pinned-workspace path: parse the path-encoded workspace and build a
    fresh Config. Otherwise fall back to the daemon's `disk_factory`,
    which returns the current workspace's Config (or a shim in tests).

    Note tools and store tools both flow through this so a single
    workspace pin governs every call in the request.
    """
    workspace = request.match_info.get("workspace")
    if workspace:
        from meeting_helper.config import (
            Config,
            WORKSPACE_NAME_RE,
            workspace_path,
        )
        if not WORKSPACE_NAME_RE.match(workspace):
            raise ValueError(f"invalid workspace name: {workspace!r}")
        path = workspace_path(workspace)
        if not path.exists():
            raise KeyError(f"workspace {workspace!r} not found")
        return Config(config_path=path, workspace=workspace)
    factory = request.app.get("disk_factory")
    if factory is None:
        raise RuntimeError("disk_factory not configured")
    return factory()


def _store(request: web.Request) -> MeetingHelperStore:
    """Build a store for the request — pinned workspace if the route matched
    one, otherwise the daemon's currently-active workspace.

    The pinned-workspace path lets multiple Claude Code MCP registrations
    coexist on one daemon (`mh-work`, `mh-personal`, etc.) without the
    agent's writes silently following whatever workspace the desktop app
    happens to have open. Each registration's URL embeds the workspace
    name, and this helper resolves a fresh `Config` for that workspace.
    """
    return MeetingHelperStore(_cfg(request))


def _task_dict(t) -> dict:
    return {
        "id": t.id,
        "title": t.title,
        "description": t.description,
        "status": t.status,
        "priority": t.priority,
        "mr_links": list(t.mr_links),
        "thread_links": list(t.thread_links),
        "parent_id": t.parent_id,
        "sprint_id": t.sprint_id,
        "created_at": t.created_at,
        "updated_at": t.updated_at,
        "comments": [
            {
                "id": c.id,
                "text": c.text,
                "author": c.author,
                "created_at": c.created_at,
                "updated_at": c.updated_at,
            }
            for c in t.comments
        ],
    }


def _sprint_dict(s) -> dict:
    return {
        "id": s.id,
        "name": s.name,
        "state": s.state,
        "created_at": s.created_at,
        "closed_at": s.closed_at,
    }


def _resolve_sprint_arg(raw: Any) -> Any:
    """Normalize a tool-call sprint_id argument into a store filter value.

    The MCP schema declares sprint_id as `["integer", "string", "null"]`.
    Map strings to filter aliases (case-insensitive), pass int/null
    through unchanged, reject anything else.
    """
    if raw is None:
        return None
    if isinstance(raw, bool):
        raise ValueError("sprint_id must be int|string|null, got bool")
    if isinstance(raw, int):
        return raw
    if isinstance(raw, str):
        val = raw.strip().lower()
        if val in ("active", "backlog", "closed", "all"):
            return val
        if val in ("null", "none"):
            return None
        try:
            return int(val)
        except ValueError:
            raise ValueError(
                "sprint_id string must be 'active', 'backlog', 'closed', 'all', or 'null'"
            )
    raise ValueError(f"sprint_id has unsupported type: {type(raw).__name__}")


_NOTE_TOOL_NAMES = frozenset(
    ("list_notes", "get_note", "create_note", "update_note", "delete_note", "set_note_kb")
)


# Tools that mutate task-manager state. After one of these dispatches
# succeeds we broadcast `{"type": "mh_tasks_changed"}` so connected web
# clients invalidate their task cache and refresh without a workspace
# switch (ticket #35). Read-only tools (list_*, get_*) are intentionally
# excluded so a future read-only tool can't accidentally fire the event.
_MUTATING_TOOL_NAMES = frozenset(
    (
        "create_task",
        "update_task",
        "delete_task",
        "add_comment",
        "update_comment",
        "delete_comment",
        "create_sprint",
        "close_sprint",
        "move_task_to_sprint",
        "create_note",
        "update_note",
        "delete_note",
        "set_note_kb",
    )
)


def _image_blocks_for_task(
    store: MeetingHelperStore, task_payload: dict,
) -> list[dict]:
    """Return MCP image content blocks for every upload referenced in the
    task's description or comments.

    Agents that talk to us over MCP can't reach the daemon HTTP routes, so
    we ship the image bytes inline alongside the text payload. Each unique
    upload id is included once, in the order it appears.
    """
    haystack_parts: list[str] = []
    desc = task_payload.get("description")
    if isinstance(desc, str):
        haystack_parts.append(desc)
    comments = task_payload.get("comments")
    if isinstance(comments, list):
        for c in comments:
            text = c.get("text") if isinstance(c, dict) else None
            if isinstance(text, str):
                haystack_parts.append(text)
    haystack = "\n".join(haystack_parts)

    seen: set[str] = set()
    blocks: list[dict] = []
    for match in _UPLOAD_URL_RE.finditer(haystack):
        upload_id = match.group(1)
        if upload_id in seen:
            continue
        seen.add(upload_id)
        try:
            row = store.get_upload(upload_id)
        except AttributeError:
            # Older stores without uploads support - silently skip.
            return blocks
        if row is None:
            continue
        data, mime = row
        blocks.append(
            {
                "type": "image",
                "data": base64.b64encode(data).decode("ascii"),
                "mimeType": mime,
            }
        )
    return blocks


def _dispatch_note(cfg: Any, name: str, args: dict) -> Any:
    """Sync handler for the note tools.

    Mirrors the chat-layer helpers in `meeting_helper.chat.tools.notes`,
    but reads/writes through the workspace-pinned `cfg` rather than the
    file-backed singleton. The chat tools wrap each call in a
    {status, result} envelope; here we return the bare payload (or raise
    KeyError/ValueError, which the JSON-RPC layer maps to the right
    error shape).
    """
    from urllib.parse import quote
    from pathlib import Path

    from meeting_helper.chat.tools.notes import (
        _atomic_create,
        _atomic_rename,
        _safe_note_filename,
        _slug_base,
        list_notes_for,
    )

    if name == "list_notes":
        return list_notes_for(cfg)

    if name == "get_note":
        fname = _safe_note_filename(str(args.get("id") or ""))
        if fname is None:
            raise ValueError("id must be a *.note.md basename")
        path = Path(cfg.recordings_dir) / fname
        if not path.is_file():
            raise KeyError(f"note not found: {fname}")
        body = path.read_text(errors="ignore")
        return {
            "id": fname,
            "title": fname.removesuffix(".note.md").replace("-", " "),
            "body": body,
            "in_kb": cfg.is_kb(fname),
            "favorited": cfg.is_favorite(fname),
            "url": f"/notes/?id={quote(fname)}",
        }

    if name == "create_note":
        title = str(args.get("title") or "").strip()
        body = str(args.get("body") or "")
        in_kb = bool(args.get("in_kb", False))
        if not title:
            raise ValueError("title required")
        rec_dir = Path(cfg.recordings_dir)
        rec_dir.mkdir(parents=True, exist_ok=True)
        base = _slug_base(title)
        filename = _atomic_create(rec_dir, base, body)
        if in_kb:
            cfg.add_kb(filename)
            cfg.save()
        return {
            "id": filename,
            "title": title,
            "in_kb": in_kb,
            "url": f"/notes/?id={quote(filename)}",
        }

    if name == "update_note":
        fname = _safe_note_filename(str(args.get("id") or ""))
        if fname is None:
            raise ValueError("id must be a *.note.md basename")
        rec_dir = Path(cfg.recordings_dir)
        path = rec_dir / fname
        if not path.is_file():
            raise KeyError(f"note not found: {fname}")
        new_title = args.get("title")
        new_body = args.get("body")
        if new_body is not None:
            path.write_text(str(new_body))
        if new_title is not None and str(new_title).strip():
            new_filename = _atomic_rename(
                rec_dir, fname, _slug_base(str(new_title)),
            )
            if new_filename != fname:
                if cfg.is_kb(fname):
                    cfg.remove_kb(fname)
                    cfg.add_kb(new_filename)
                if cfg.is_favorite(fname):
                    cfg.remove_favorite(fname)
                    cfg.add_favorite(new_filename)
                cfg.save()
            return {
                "id": new_filename,
                "title": str(new_title),
                "in_kb": cfg.is_kb(new_filename),
                "url": f"/notes/?id={quote(new_filename)}",
            }
        return {
            "id": fname,
            "title": fname.removesuffix(".note.md").replace("-", " "),
            "in_kb": cfg.is_kb(fname),
            "url": f"/notes/?id={quote(fname)}",
        }

    if name == "delete_note":
        fname = _safe_note_filename(str(args.get("id") or ""))
        if fname is None:
            raise ValueError("id must be a *.note.md basename")
        path = Path(cfg.recordings_dir) / fname
        if path.is_file():
            path.unlink()
        if cfg.is_kb(fname):
            cfg.remove_kb(fname)
        if cfg.is_favorite(fname):
            cfg.remove_favorite(fname)
        cfg.save()
        return {"ok": True}

    if name == "set_note_kb":
        fname = _safe_note_filename(str(args.get("id") or ""))
        if fname is None:
            raise ValueError("id must be a *.note.md basename")
        if "value" not in args:
            raise ValueError("value is required for set_note_kb")
        value = bool(args["value"])
        path = Path(cfg.recordings_dir) / fname
        if not path.is_file():
            raise KeyError(f"note not found: {fname}")
        if value:
            cfg.add_kb(fname)
        else:
            cfg.remove_kb(fname)
        cfg.save()
        return {"id": fname, "in_kb": value}

    raise ValueError(f"unknown note tool: {name}")


def _dispatch(store: MeetingHelperStore, name: str, args: dict) -> Any:
    if name == "list_tasks":
        kwargs: dict[str, Any] = {}
        if "status" in args:
            kwargs["status"] = args["status"]
        if "priority" in args:
            kwargs["priority"] = args["priority"]
        if "sort_by" in args:
            kwargs["sort_by"] = args["sort_by"]
        if "sort_direction" in args:
            kwargs["sort_direction"] = args["sort_direction"]
        if "parent_id" in args:
            kwargs["parent_id"] = args["parent_id"]
        else:
            kwargs["parent_id"] = UNSET
        # MCP default: scope to the active sprint. Pass sprint_id explicitly
        # (string, int, or null) to override. This is the change the user
        # asked for in ticket #22 — Copilot stops seeing closed-sprint
        # Done items because they belong to closed sprints, not the active
        # one.
        if "sprint_id" in args:
            kwargs["sprint_id"] = _resolve_sprint_arg(args["sprint_id"])
        else:
            kwargs["sprint_id"] = "active"
        return [_task_dict(t) for t in store.list_tasks(**kwargs)]
    if name == "get_task":
        return _task_dict(store.get_task(int(args["id"])))
    if name == "create_task":
        from meeting_helper.trackers.vendors.meeting_helper_types import (
            DEFAULT_PRIORITY,
        )
        create_kwargs: dict[str, Any] = dict(
            title=args["title"],
            description=args.get("description", ""),
            status=args.get("status", "Todo"),
            priority=args.get("priority", DEFAULT_PRIORITY),
            parent_id=args.get("parent_id"),
            mr_links=args.get("mr_links") or [],
            thread_links=args.get("thread_links") or [],
        )
        if "sprint_id" in args:
            create_kwargs["sprint_id"] = args["sprint_id"]
        return _task_dict(store.create_task(**create_kwargs))
    if name == "update_task":
        fields = {k: v for k, v in args.items() if k != "id"}
        return _task_dict(store.update_task(int(args["id"]), **fields))
    if name == "delete_task":
        return store.delete_task(int(args["id"]))
    if name == "add_comment":
        c = store.add_comment(
            int(args["task_id"]), text=args["text"], author="agent",
        )
        return {
            "id": c.id,
            "text": c.text,
            "author": c.author,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
    if name == "update_comment":
        c = store.update_comment(
            int(args["task_id"]),
            int(args["comment_id"]),
            text=args["text"],
        )
        return {
            "id": c.id,
            "text": c.text,
            "author": c.author,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
    if name == "delete_comment":
        store.delete_comment(int(args["task_id"]), int(args["comment_id"]))
        return {"deleted": True}
    if name == "list_statuses":
        return store.list_statuses()
    if name == "list_sprints":
        sprints = [_sprint_dict(s) for s in store.list_sprints()]
        active = store.get_active_sprint()
        return {
            "sprints": sprints,
            "active_sprint_id": active.id if active else None,
        }
    if name == "create_sprint":
        s = store.create_sprint(
            name=args.get("name") or "",
            activate=bool(args.get("activate", True)),
        )
        return _sprint_dict(s)
    if name == "close_sprint":
        out = store.close_sprint(
            int(args["id"]),
            new_sprint_name=args.get("new_sprint_name"),
            carry_over=bool(args.get("carry_over", True)),
        )
        return out
    if name == "move_task_to_sprint":
        if "sprint_id" not in args:
            # Schema requires it, but defend against a permissive client.
            # Without this an omitted sprint_id would silently move the
            # task to the backlog (args.get returns None).
            raise ValueError("sprint_id is required for move_task_to_sprint")
        t = store.update_task(
            int(args["task_id"]),
            sprint_id=args["sprint_id"],
        )
        return _task_dict(t)
    if name == "list_priorities":
        return store.list_priorities()
    if name == "list_sort_options":
        return store.list_sort_options()
    if name == "list_sort_directions":
        return store.list_sort_directions()
    raise ValueError(f"unknown tool: {name}")


async def mcp_handler(request: web.Request) -> web.Response:
    """Single-endpoint MCP Streamable HTTP server (POST JSON-RPC).

    Error mapping:
    - Parse errors / malformed JSON -> JSON-RPC -32700.
    - Unknown method -> -32601.
    - Missing required arg / unknown status / validation -> -32602.
    - Task or comment not found -> tool result with `isError: true` (per MCP
      spec, application-layer tool errors come back inside the result, not
      as JSON-RPC errors).
    - Anything else -> -32603.
    """
    rpc_id: Any = None
    try:
        body = await request.json()
    except Exception as e:
        return web.json_response(
            {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": f"parse error: {e}"},
            },
            status=200,
        )
    if not isinstance(body, dict):
        return web.json_response(
            {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32600, "message": "request must be a JSON object"},
            },
            status=200,
        )
    rpc_id = body.get("id")
    method = body.get("method")
    params = body.get("params") or {}

    def _ok(result: Any) -> web.Response:
        return web.json_response(
            {"jsonrpc": "2.0", "id": rpc_id, "result": result}
        )

    def _err(code: int, message: str) -> web.Response:
        return web.json_response(
            {
                "jsonrpc": "2.0",
                "id": rpc_id,
                "error": {"code": code, "message": message},
            },
            status=200,
        )

    def _tool_error(message: str) -> web.Response:
        return _ok(
            {
                "content": [{"type": "text", "text": message}],
                "isError": True,
            }
        )

    try:
        if method == "initialize":
            return _ok(
                {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "meeting-helper-mh", "version": "1"},
                }
            )
        if method == "tools/list":
            return _ok({"tools": _TOOLS})
        if method == "tools/call":
            tool_name = params.get("name")
            if not isinstance(tool_name, str):
                return _err(-32602, "tools/call requires a string 'name'")
            arguments = params.get("arguments") or {}
            try:
                # Offload to executor: _dispatch does sync workspace-JSON
                # load/mutate/save (`Config.save` writes the whole file).
                # Running it on the asyncio loop blocks transcript
                # broadcasts during sustained MCP traffic (ticket #25).
                # Note tools also touch disk (read/write *.note.md and
                # KB/favorite sets), so they run through to_thread too.
                import asyncio as _asyncio
                if tool_name in _NOTE_TOOL_NAMES:
                    result = await _asyncio.to_thread(
                        _dispatch_note, _cfg(request), tool_name, arguments,
                    )
                    extra_blocks: list[dict] = []
                else:
                    store = _store(request)
                    result = await _asyncio.to_thread(
                        _dispatch, store, tool_name, arguments,
                    )
                    if tool_name == "get_task" and isinstance(result, dict):
                        extra_blocks = await _asyncio.to_thread(
                            _image_blocks_for_task, store, result,
                        )
                    else:
                        extra_blocks = []
            except KeyError as e:
                # Resource not found (task, comment, or sprint). Per MCP
                # spec this is a tool-level error, surfaced inside the
                # result with isError=true so agents can distinguish
                # "missing resource" from "bad request shape".
                return _tool_error(str(e))
            except ValueError as e:
                # Validation: bad status, blank title, depth violation,
                # unknown tool. JSON-RPC -32602 (invalid params).
                return _err(-32602, str(e))
            except RuntimeError as e:
                # disk_factory not configured — daemon-wiring bug.
                logger.error("mcp_handler: %s", e)
                return _err(-32603, str(e))
            # Dispatch succeeded (no early return from the except chain). If
            # the tool mutated task-manager state, push a live update to web
            # clients so cards refresh without a workspace switch (ticket #35).
            # Tiny JSON message; awaited here on the loop after to_thread.
            if tool_name in _MUTATING_TOOL_NAMES:
                try:
                    await broadcast({"type": "mh_tasks_changed"})
                except Exception:  # pragma: no cover - never fail a tool call
                    logger.warning(
                        "mcp_handler: mh_tasks_changed broadcast failed",
                        exc_info=True,
                    )
            content_blocks: list[dict] = [
                {"type": "text", "text": json.dumps(result)},
            ]
            content_blocks.extend(extra_blocks)
            return _ok({"content": content_blocks, "isError": False})
        if method in ("notifications/initialized", "ping"):
            return _ok({})
        return _err(-32601, f"method not found: {method}")
    except Exception as e:
        logger.exception("mcp_handler: unhandled exception")
        return _err(-32603, f"internal error: {e}")


def register(app: web.Application) -> None:
    app.router.add_post("/mcp", mcp_handler)
    # Workspace-pinned variant. Same handler, but `_store(request)` reads
    # the workspace name from the path and builds a fresh Config for it.
    # Lets one daemon serve N Claude Code registrations deterministically.
    app.router.add_post("/mcp/{workspace}", mcp_handler)
