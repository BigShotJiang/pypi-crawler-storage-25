"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "6.17.0"
