import unittest
import numpy as np
from trplearn.scheduling import PERTAnalyst

class TestPERTAnalyst(unittest.TestCase):
    def test_simple_project(self):
        # 0 -> 1 (3)
        # 0 -> 2 (2)
        # 1 -> 3 (4)
        # 2 -> 3 (6)
        inf = -np.inf
        adj = [
            [0,   3,   2,   inf],
            [inf, 0,   inf, 4],
            [inf, inf, 0,   6],
            [inf, inf, inf, 0]
        ]
        
        analyst = PERTAnalyst()
        analyst.compute(adj)
        
        # Earliest Times:
        # Event 0: 0
        # Event 1: max(0+3) = 3
        # Event 2: max(0+2) = 2
        # Event 3: max(3+4, 2+6) = 8
        np.testing.assert_array_equal(analyst.earliest_times, [0, 3, 2, 8])
        self.assertEqual(analyst.project_duration(), 8)
        
        # Latest Times (Project ends at 8):
        # Event 3: 8 - 0 = 8
        # Event 1: 8 - 4 = 4
        # Event 2: 8 - 6 = 2
        # Event 0: 8 - max(3+4, 2+6) = 0
        np.testing.assert_array_equal(analyst.latest_times, [0, 4, 2, 8])
        
        # Slack: [0-0, 4-3, 2-2, 8-8] = [0, 1, 0, 0]
        np.testing.assert_array_equal(analyst.slack, [0, 1, 0, 0])
        
        # Critical Path: [0, 2, 3]
        self.assertEqual(analyst.critical_path(), [0, 2, 3])

    def test_serial_project(self):
        # 0 -> 1 (10) -> 2 (5)
        inf = -np.inf
        adj = [
            [0,   10,  inf],
            [inf, 0,   5],
            [inf, inf, 0]
        ]
        analyst = PERTAnalyst().compute(adj)
        np.testing.assert_array_equal(analyst.earliest_times, [0, 10, 15])
        self.assertEqual(analyst.critical_path(), [0, 1, 2])

if __name__ == "__main__":
    unittest.main()
