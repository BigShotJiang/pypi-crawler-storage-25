import numpy as np
from .trpalg import MaxPlus

class PERTAnalyst:
    """
    Project Evaluation and Review Technique (PERT) analyst using Max-Plus algebra.
    This class computes earliest/latest times and critical paths by interpreting 
    the Kleene star (closure) of a task duration matrix.

    The input adjacency matrix A should have A[i, j] = duration of task from event i to j.
    Use -np.inf where no direct task exists between events.

    Attributes
    ----------
    longest_path_matrix_ : MaxPlus
        The all-pairs longest path matrix (Kleene star).
    durations_ : ndarray
        The original task duration matrix.
    """

    def __init__(self):
        self.longest_path_matrix_ = None
        self.durations_ = None

    def compute(self, adjacency_matrix):
        """
        Compute the longest path matrix and prepare for analysis.

        Parameters
        ----------
        adjacency_matrix : array-like
            Square matrix where [i, j] is the duration of the task starting at 
            event i and ending at event j. Use -np.inf for no dependency.

        Returns
        -------
        self : object
        """
        self.durations_ = np.array(adjacency_matrix)
        # Ensure diagonal is 0 for events (self-dependency with 0 duration)
        # unless otherwise specified by the input.
        A = MaxPlus(self.durations_)
        self.longest_path_matrix_ = A.star()
        return self

    @property
    def earliest_times(self):
        """
        Earliest Start Times (EST) for each event, assuming project starts at event 0.
        
        Returns
        -------
        ndarray
        """
        if self.longest_path_matrix_ is None:
            raise RuntimeError("Analysis has not been computed. Call compute() first.")
        # E_i = A*[0, i]
        return self.longest_path_matrix_.data[0, :]

    @property
    def latest_times(self):
        """
        Latest Start Times (LST) for each event without delaying the project.
        
        Returns
        -------
        ndarray
        """
        if self.longest_path_matrix_ is None:
            raise RuntimeError("Analysis has not been computed. Call compute() first.")
        
        est = self.earliest_times
        # Project completion time T is the earliest time of the last event
        T = est[-1]
        if T == -np.inf:
            # Handle disconnected or empty graphs
            return np.full_like(est, -np.inf)
            
        # L_i = T - A*[i, n-1]
        # This calculates how late event i can occur while still reaching 
        # the final event by time T.
        return T - self.longest_path_matrix_.data[:, -1]

    @property
    def slack(self):
        """
        Total slack (float) for each event.
        Slack = Latest Time - Earliest Time.
        
        Returns
        -------
        ndarray
        """
        return self.latest_times - self.earliest_times

    def critical_path(self):
        """
        Identify the sequence of event indices forming the critical path.
        An event is on a critical path if its slack is zero.
        
        Returns
        -------
        list of int
            List of event indices on the critical path.
        """
        slack = self.slack
        # Indices where slack is approximately zero
        cp_indices = np.where(np.isclose(slack, 0))[0]
        return cp_indices.tolist()

    def project_duration(self):
        """
        Total duration of the project (earliest time of the final event).
        
        Returns
        -------
        float
        """
        return self.earliest_times[-1]
