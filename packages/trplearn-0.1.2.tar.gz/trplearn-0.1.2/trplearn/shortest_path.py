import numpy as np
from .trpalg import MinPlus

def all_pairs_shortest_paths(adjacency_matrix):
    """
    Compute all-pairs shortest paths using Min-Plus algebra.

    Parameters
    ----------
    adjacency_matrix : array-like
        Weighted adjacency matrix of the graph.
        Use np.inf for no edge between nodes.

    Returns
    -------
    MinPlus
        The all-pairs shortest path distance matrix.
    """
    A = MinPlus(adjacency_matrix)
    return A.star()

class TropicalShortestPath:
    """
    All-pairs shortest path solver using tropical (min-plus) algebra.
    This class acts as an interpretation layer over the algebraic star() operation.

    Attributes
    ----------
    distance_matrix_ : MinPlus
        The calculated all-pairs shortest path distance matrix.

    Examples
    --------
    >>> import numpy as np
    >>> from trplearn.shortest_path import TropicalShortestPath
    >>> adj = [[0, 3, np.inf], [np.inf, 0, 1], [np.inf, np.inf, 0]]
    >>> tsp = TropicalShortestPath()
    >>> tsp.compute(adj)
    >>> tsp.distances
    array([[0., 3., 4.],
           [inf, 0., 1.],
           [inf, inf, 0.]])
    """

    def __init__(self):
        self.distance_matrix_ = None

    def compute(self, adjacency_matrix):
        """
        Compute the shortest path distance matrix.

        Parameters
        ----------
        adjacency_matrix : array-like
            Weighted adjacency matrix of the graph.

        Returns
        -------
        self : object
        """
        self.distance_matrix_ = all_pairs_shortest_paths(adjacency_matrix)
        return self

    @property
    def distances(self):
        """
        Return the calculated distance matrix as a numpy array.
        """
        if self.distance_matrix_ is None:
            raise RuntimeError("Distance matrix has not been computed yet.")
        return self.distance_matrix_.to_numpy()

    def get_distance(self, start_node, end_node):
        """
        Get the shortest distance between two specific nodes.

        Parameters
        ----------
        start_node : int
            Index of the starting node.
        end_node : int
            Index of the destination node.

        Returns
        -------
        distance : float
        """
        if self.distance_matrix_ is None:
            raise RuntimeError("Distance matrix has not been computed yet.")
        return self.distance_matrix_.data[start_node, end_node]
