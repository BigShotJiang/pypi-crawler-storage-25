"""sync-project-coco CLI entrypoint."""
from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

import click

from .api import ApiError, iter_pages
from .config import ConfigError, resolve_config
from .downloader import DownloadJob, download_all
from .writer import timestamped_filename, write_dataset


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.argument(
    "input_path",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
)
@click.option("--admin-url", envvar="QUICLABEL_ADMIN_URL", help="Admin base URL")
@click.option("--api-key", envvar="QUICLABEL_API_KEY", help="API key (qk_...)")
@click.option("--project-id", help="Overrides meta.project_id")
@click.option("--statuses", help="Comma-separated, overrides meta.filters.statuses")
@click.option("--tag-ids", help="Comma-separated, overrides meta.filters.tag_ids")
@click.option(
    "--image-source",
    type=click.Choice(["compressed", "original"]),
    help="Overrides meta.image_source",
)
@click.option(
    "--concurrency",
    type=click.IntRange(1, 128),
    default=16,
    show_default=True,
    help="Image download threads",
)
@click.option(
    "--limit",
    type=click.IntRange(1, 1000),
    default=500,
    show_default=True,
    help="Per-page limit",
)
@click.option("-v", "--verbose", is_flag=True, help="Verbose logging")
def main(
    input_path: Path,
    admin_url: str | None,
    api_key: str | None,
    project_id: str | None,
    statuses: str | None,
    tag_ids: str | None,
    image_source: str | None,
    concurrency: int,
    limit: int,
    verbose: bool,
) -> None:
    """Sync a QuicLabel COCO dataset: pulls a fresh annotations json (named
    ``annotations-YYYYMMDD-HHMMSS.json``) and downloads any missing images
    next to it. The input ``annotations.json`` and existing images are never
    modified.

    Config priority: CLI flag > env var > meta block in the input json.
    """
    _setup_logging(verbose)
    log = logging.getLogger("sync-project-coco")

    try:
        input_doc = json.loads(input_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        click.echo(f"failed to read {input_path}: {e}", err=True)
        sys.exit(2)
    if not isinstance(input_doc, dict):
        click.echo(f"input {input_path} is not a JSON object", err=True)
        sys.exit(2)

    input_meta = input_doc.get("meta")
    if input_meta is not None and not isinstance(input_meta, dict):
        log.warning("meta in input is not an object — ignoring")
        input_meta = None

    try:
        cfg = resolve_config(
            input_meta=input_meta,
            cli_admin_url=admin_url,
            cli_api_key=api_key,
            cli_project_id=project_id,
            cli_statuses=statuses,
            cli_tag_ids=tag_ids,
            cli_image_source=image_source,
            cli_concurrency=concurrency,
        )
    except ConfigError as e:
        click.echo(str(e), err=True)
        sys.exit(2)

    log.info(
        "project=%s statuses=%s tag_ids=%s image_source=%s",
        cfg.project_id,
        cfg.statuses,
        cfg.tag_ids,
        cfg.image_source,
    )

    out_dir = input_path.parent
    new_annotations_path = out_dir / timestamped_filename()
    images_dir = out_dir / "images"

    try:
        pages = iter_pages(
            cfg.admin_url,
            cfg.api_key,
            cfg.project_id,
            statuses=cfg.statuses,
            tag_ids=cfg.tag_ids,
            image_source=cfg.image_source,
            limit=limit,
        )
        dataset = write_dataset(pages, new_annotations_path)
    except ApiError as e:
        click.echo(f"API error: {e}", err=True)
        sys.exit(1)

    log.info(
        "wrote %s (%d images, %d annotations)",
        new_annotations_path.name,
        len(dataset["images"]),
        len(dataset["annotations"]),
    )

    # Diff against the input doc directly (already parsed, no re-read).
    old_ids = {
        img["task_id"]
        for img in (input_doc.get("images") or [])
        if img.get("task_id")
    }
    new_images = [
        img for img in dataset["images"] if img.get("task_id") not in old_ids
    ]
    log.info("new task_ids since input: %d", len(new_images))

    jobs = [
        DownloadJob(file_name=img["file_name"], url=img.get("url", ""))
        for img in new_images
    ]

    if jobs:
        with click.progressbar(
            length=len(jobs),
            label="downloading",
            file=sys.stderr,
        ) as bar:
            results = download_all(
                jobs,
                images_dir,
                concurrency=cfg.concurrency,
                progress=lambda done, _total: bar.update(1),
            )
    else:
        results = []

    downloaded = sum(1 for r in results if r.ok and not r.skipped)
    skipped = sum(1 for r in results if r.skipped)
    failed = [r for r in results if not r.ok]

    log.info(
        "done — downloaded=%d skipped=%d failed=%d",
        downloaded,
        skipped,
        len(failed),
    )

    if failed:
        click.echo("Failed downloads:", err=True)
        for r in failed[:20]:
            click.echo(f"  {r.file_name}: {r.error}", err=True)
        if len(failed) > 20:
            click.echo(f"  ... and {len(failed) - 20} more", err=True)
        click.echo(
            "Re-run the same command to retry — already-downloaded files are skipped.",
            err=True,
        )
        sys.exit(1)


if __name__ == "__main__":  # pragma: no cover
    main()
