"""Parallel image downloader for the sync CLI.

Threads (not asyncio) since the bottleneck is network I/O and requests +
Azure Blob's CDN handle connection reuse just fine within a thread pool.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import requests

logger = logging.getLogger(__name__)

RETRYABLE_STATUS = {429, 500, 502, 503, 504}


@dataclass
class DownloadJob:
    file_name: str
    url: str


@dataclass
class DownloadResult:
    file_name: str
    ok: bool
    skipped: bool = False
    error: str | None = None


def _stream_to_file(response, dest: Path) -> None:
    tmp = dest.with_suffix(dest.suffix + ".part")
    try:
        with open(tmp, "wb") as f:
            for chunk in response.iter_content(chunk_size=1 << 16):
                if chunk:
                    f.write(chunk)
        tmp.replace(dest)
    except BaseException:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise


def _download_one(
    job: DownloadJob,
    images_dir: Path,
    session: requests.Session,
    timeout: float,
    max_retries: int,
) -> DownloadResult:
    target = images_dir / job.file_name
    if target.exists():
        return DownloadResult(file_name=job.file_name, ok=True, skipped=True)

    if not job.url:
        return DownloadResult(file_name=job.file_name, ok=False, error="no url")

    last_err: str | None = None
    for attempt in range(max_retries + 1):
        try:
            with session.get(job.url, stream=True, timeout=timeout) as r:
                if r.status_code == 200:
                    _stream_to_file(r, target)
                    return DownloadResult(file_name=job.file_name, ok=True)
                if r.status_code in RETRYABLE_STATUS and attempt < max_retries:
                    last_err = f"HTTP {r.status_code}"
                    time.sleep(2**attempt)
                    continue
                last_err = f"HTTP {r.status_code}"
                break
        except requests.RequestException as e:
            last_err = str(e)[:200]
            if attempt < max_retries:
                time.sleep(2**attempt)
                continue
            break

    return DownloadResult(file_name=job.file_name, ok=False, error=last_err)


def download_all(
    jobs: Iterable[DownloadJob],
    images_dir: Path,
    *,
    concurrency: int = 16,
    timeout: float = 60.0,
    max_retries: int = 3,
    session_factory=None,
    progress=None,
) -> list[DownloadResult]:
    """Download jobs in parallel. Returns one result per job. Failures don't
    abort the run — the caller decides what to do with the failure list.

    Each worker thread gets its own ``requests.Session`` via threading.local —
    Session is not documented thread-safe for cookie/auth state mutation.

    ``progress(done, total)`` callback invoked after each result, if supplied.
    """
    images_dir.mkdir(parents=True, exist_ok=True)
    job_list = list(jobs)
    results: list[DownloadResult] = []

    if not job_list:
        return results

    make_session = session_factory or requests.Session
    local = threading.local()

    def _per_thread_session() -> requests.Session:
        s = getattr(local, "session", None)
        if s is None:
            s = make_session()
            local.session = s
        return s

    def _task(job: DownloadJob) -> DownloadResult:
        return _download_one(
            job, images_dir, _per_thread_session(), timeout, max_retries
        )

    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        futures = {pool.submit(_task, j): j for j in job_list}
        for fut in as_completed(futures):
            res = fut.result()
            results.append(res)
            if progress is not None:
                progress(len(results), len(job_list))

    return results
