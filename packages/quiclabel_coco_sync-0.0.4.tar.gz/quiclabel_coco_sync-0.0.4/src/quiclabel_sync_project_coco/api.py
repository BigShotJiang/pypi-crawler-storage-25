"""HTTP client for GET /api/v1/projects/:id/coco with cursor pagination."""
from __future__ import annotations

import logging
import time
from typing import Any, Iterator

import requests

logger = logging.getLogger(__name__)

RETRYABLE_STATUS = {429, 500, 502, 503, 504}


class ApiError(Exception):
    """Raised for non-retryable HTTP failures (4xx other than 429)."""


def _request_page(
    session: requests.Session,
    url: str,
    params: dict[str, Any],
    headers: dict[str, str],
    *,
    max_retries: int = 3,
    timeout: float = 30.0,
) -> dict[str, Any]:
    """Fetch one page with retry-on-5xx. Raises ApiError for 4xx."""
    for attempt in range(max_retries + 1):
        try:
            resp = session.get(url, params=params, headers=headers, timeout=timeout)
        except requests.RequestException as e:
            if attempt == max_retries:
                raise ApiError(f"Network error after {max_retries + 1} attempts: {e}") from e
            logger.warning("network error (attempt %d): %s", attempt + 1, e)
            time.sleep(2**attempt)
            continue

        if resp.status_code == 200:
            return resp.json()

        if resp.status_code in (401, 403):
            raise ApiError(
                f"Authentication failed ({resp.status_code}): check --api-key"
            )

        if resp.status_code in RETRYABLE_STATUS and attempt < max_retries:
            logger.warning(
                "server %d (attempt %d), retrying", resp.status_code, attempt + 1
            )
            time.sleep(2**attempt)
            continue

        raise ApiError(f"API error {resp.status_code}: {resp.text[:500]}")

    raise ApiError("retry loop exhausted")  # pragma: no cover


def iter_pages(
    admin_url: str,
    api_key: str,
    project_id: str,
    *,
    statuses: list[str],
    tag_ids: list[str],
    image_source: str,
    limit: int = 500,
    session: requests.Session | None = None,
) -> Iterator[dict[str, Any]]:
    """Yield each page dict in turn. The first page has meta/info/categories;
    subsequent pages only have images/annotations/next_cursor."""
    s = session or requests.Session()
    headers = {"Authorization": f"Bearer {api_key}"}
    url = f"{admin_url}/api/v1/projects/{project_id}/coco"
    params: dict[str, Any] = {
        "statuses": ",".join(statuses),
        "image_source": image_source,
        "limit": limit,
    }
    if tag_ids:
        params["tag_ids"] = ",".join(tag_ids)

    cursor: str | None = None
    page_num = 0
    while True:
        page_params = dict(params)
        if cursor:
            page_params["cursor"] = cursor

        page = _request_page(s, url, page_params, headers)
        page_num += 1
        logger.info("page %d: %d images", page_num, len(page.get("images") or []))
        yield page

        cursor = page.get("next_cursor")
        if not cursor:
            return
