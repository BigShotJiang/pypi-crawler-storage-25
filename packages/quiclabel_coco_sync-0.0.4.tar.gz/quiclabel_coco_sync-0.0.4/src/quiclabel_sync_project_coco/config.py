"""Resolve sync configuration from CLI flags, env vars, and the input json's
``meta`` block. Priority: CLI > env > json.meta.

All required parameters must come from somewhere — missing config raises
``ConfigError`` with a message explaining which key is missing and where the
user can provide it.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any


class ConfigError(Exception):
    """Raised when a required configuration value cannot be resolved."""


@dataclass(frozen=True)
class SyncConfig:
    admin_url: str
    api_key: str
    project_id: str
    statuses: list[str]
    tag_ids: list[str]
    image_source: str
    concurrency: int


def _csv(value: str | None) -> list[str] | None:
    """Split comma-separated string into list, returning None when value is
    None so callers can distinguish "user didn't pass" from "user passed empty"."""
    if value is None:
        return None
    return [s.strip() for s in value.split(",") if s.strip()]


def resolve_config(
    *,
    input_meta: dict[str, Any] | None,
    cli_admin_url: str | None,
    cli_api_key: str | None,
    cli_project_id: str | None,
    cli_statuses: str | None,
    cli_tag_ids: str | None,
    cli_image_source: str | None,
    cli_concurrency: int,
    env: dict[str, str] | None = None,
) -> SyncConfig:
    """Resolve all sync parameters. ``input_meta`` is the ``meta`` block from
    the input annotations.json (may be None for legacy exports)."""
    env = env if env is not None else os.environ
    meta = input_meta or {}
    filters = meta.get("filters") or {}

    admin_url = cli_admin_url or env.get("QUICLABEL_ADMIN_URL")
    api_key = cli_api_key or env.get("QUICLABEL_API_KEY")
    project_id = cli_project_id or meta.get("project_id")

    cli_statuses_list = _csv(cli_statuses)
    statuses = (
        cli_statuses_list
        if cli_statuses_list is not None
        else (filters.get("statuses") or None)
    )

    cli_tag_ids_list = _csv(cli_tag_ids)
    tag_ids = (
        cli_tag_ids_list
        if cli_tag_ids_list is not None
        else (filters.get("tag_ids") or [])
    )

    image_source = (
        cli_image_source or meta.get("image_source") or None
    )

    missing: list[tuple[str, str]] = []
    if not admin_url:
        missing.append(("admin_url", "--admin-url or QUICLABEL_ADMIN_URL"))
    if not api_key:
        missing.append(("api_key", "--api-key or QUICLABEL_API_KEY"))
    if not project_id:
        missing.append(
            ("project_id", "input json meta.project_id or --project-id")
        )
    if statuses is None:
        missing.append(
            ("statuses", "input json meta.filters.statuses or --statuses")
        )
    if image_source is None:
        missing.append(
            ("image_source", "input json meta.image_source or --image-source")
        )

    if missing:
        lines = [f"  - {key}: provide via {src}" for key, src in missing]
        raise ConfigError(
            "Missing required configuration:\n" + "\n".join(lines)
        )

    return SyncConfig(
        admin_url=admin_url.rstrip("/"),  # type: ignore[union-attr]
        api_key=api_key,  # type: ignore[arg-type]
        project_id=project_id,  # type: ignore[arg-type]
        statuses=statuses,  # type: ignore[arg-type]
        tag_ids=tag_ids,
        image_source=image_source,  # type: ignore[arg-type]
        concurrency=cli_concurrency,
    )
