"""Merge paged COCO API responses into a single annotations JSON file.

Pages are accumulated in memory and written once at the end. OK up to
~100k tasks (a few hundred MB); cursor pagination handles the server side.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


def timestamped_filename(now: datetime | None = None) -> str:
    """Return ``annotations-YYYYMMDD-HHMMSS.json`` for the current local time."""
    t = now or datetime.now()
    return f"annotations-{t:%Y%m%d-%H%M%S}.json"


def write_dataset(
    pages: Iterable[dict[str, Any]],
    output_path: Path,
) -> dict[str, Any]:
    """Merge paged responses into a single COCO file at ``output_path``.

    Returns the assembled dataset dict. Raises ValueError if the stream is
    empty or an annotation references a missing image_id.
    """
    first: dict[str, Any] | None = None
    images: list[dict[str, Any]] = []
    annotations: list[dict[str, Any]] = []
    # Server numbers per-page from 1; re-key to globally-unique ids so
    # consumers can use image.id as a join key if they want.
    image_id_offset = 0

    for page in pages:
        if first is None:
            first = page
        page_images = page.get("images") or []
        page_annotations = page.get("annotations") or []

        old_to_new: dict[int, int] = {}
        for img in page_images:
            new_id = image_id_offset + img["id"]
            old_to_new[img["id"]] = new_id
            img["id"] = new_id
            images.append(img)
        for ann in page_annotations:
            old = ann["image_id"]
            if old not in old_to_new:
                raise ValueError(
                    f"Annotation references unknown image_id={old} on page "
                    f"starting at offset {image_id_offset}"
                )
            ann["image_id"] = old_to_new[old]
            annotations.append(ann)

        image_id_offset += len(page_images)

    if first is None:
        raise ValueError("No pages received from API")

    # Renumber annotation ids contiguously 1..N across pages.
    for new_id, ann in enumerate(annotations, start=1):
        ann["id"] = new_id

    dataset: dict[str, Any] = {
        "meta": first.get("meta", {}),
        "info": first.get("info", {}),
        "categories": first.get("categories", []),
        "images": images,
        "annotations": annotations,
    }
    output_path.write_text(json.dumps(dataset, indent=2), encoding="utf-8")
    return dataset
