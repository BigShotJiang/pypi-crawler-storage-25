# Changelog

All notable changes to `quiclabel-coco-sync` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.0.4] — 2026-05-25

### Fixed
- CI: pin `astral-sh/setup-uv` to `v8.1.0`. The action stopped publishing
  moving major-version tags (e.g. `v8`) starting at v8.0 "Immutable
  releases", so the previous `@v8` reference failed to resolve.

### Notes
- 0.0.3 was tagged but never reached PyPI (release workflow died at
  setup-uv). 0.0.4 is the first version actually shipped via the
  tag-driven OIDC pipeline.

## [0.0.3] — 2026-05-25

### Changed
- No code changes. First release shipped via the tag-driven GitHub Actions
  workflow and PyPI Trusted Publisher (OIDC) — proving the automated
  release pipeline end-to-end.

## [0.0.2] — 2026-05-25

### Added
- `LICENSE` file (MIT) bundled into the source/wheel distribution.
- Full PyPI project metadata: license SPDX, authors, keywords,
  classifiers, and `[project.urls]` (Homepage / Repository / Issues).
- `CHANGELOG.md`.
- GitHub Actions:
  - `coco-sync-ci.yml` — pytest matrix (Python 3.10–3.13) + `uv build`
    smoke test, path-filtered to this package.
  - `coco-sync-release.yml` — `coco-sync-v*` tag triggers OIDC publish
    to PyPI via Trusted Publishers; asserts tag/pyproject version
    agreement; creates a GitHub Release with the built dist files.

### Changed
- README rewritten: `uvx quiclabel-coco-sync` is now the primary install
  path; tag-driven release flow documented with Trusted Publisher setup
  instructions; manual `uv publish` kept as fallback. README also clarifies
  that `uv publish` does not read `~/.pypirc` and needs
  `UV_PUBLISH_TOKEN` instead.

### Notes
- Published manually (not via CI) because the Trusted Publisher on the
  PyPI side had not yet been configured at release time. The very next
  release (0.0.3+) is expected to ship via the tag-driven OIDC workflow.

## [0.0.1] — 2026-05-24

### Added
- Initial PyPI release.
- `quiclabel-coco-sync` CLI: incrementally syncs a QuicLabel COCO dataset
  from `quiclabel-admin`, writing a timestamped fresh `annotations-*.json`
  next to the existing dataset and downloading only the missing images.
- Backward-compatible `sync-project-coco` console alias for monorepo use.
- Configuration resolution priority: CLI flag > env var > input json `meta`
  block.
- Threaded image downloader with per-file skip-if-exists; `.part` files
  signal crashed downloads and are safe to delete.

[Unreleased]: https://github.com/weavejam/quiclabel/compare/coco-sync-v0.0.4...HEAD
[0.0.4]: https://github.com/weavejam/quiclabel/compare/coco-sync-v0.0.3...coco-sync-v0.0.4
[0.0.3]: https://github.com/weavejam/quiclabel/compare/coco-sync-v0.0.2...coco-sync-v0.0.3
[0.0.2]: https://github.com/weavejam/quiclabel/compare/coco-sync-v0.0.1...coco-sync-v0.0.2
[0.0.1]: https://github.com/weavejam/quiclabel/releases/tag/coco-sync-v0.0.1
