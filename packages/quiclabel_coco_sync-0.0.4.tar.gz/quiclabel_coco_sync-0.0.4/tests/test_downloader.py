import threading
import time
from pathlib import Path

from quiclabel_sync_project_coco.downloader import (
    DownloadJob,
    download_all,
)


class _FakeResponse:
    def __init__(self, body: bytes = b"image-bytes", status: int = 200):
        self._body = body
        self.status_code = status

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def iter_content(self, chunk_size: int):
        yield self._body


class _FakeSession:
    """Records each .get() call and serves a configurable response."""

    def __init__(self, by_url: dict[str, _FakeResponse | list[_FakeResponse]]):
        self.by_url = by_url
        self.calls: list[str] = []
        self._lock = threading.Lock()

    def get(self, url: str, *, stream: bool = False, timeout: float = 0):
        with self._lock:
            self.calls.append(url)
            entry = self.by_url[url]
            if isinstance(entry, list):
                # Pop the first response; subsequent calls (retry path) get the next.
                self.by_url[url] = entry[1:] or [entry[-1]]
                return entry[0]
            return entry

    def close(self):
        pass


def test_download_skips_already_present(tmp_path: Path):
    (tmp_path / "t1.jpg").write_bytes(b"old")
    session = _FakeSession({})  # never called — proves we don't hit network
    results = download_all(
        [DownloadJob(file_name="t1.jpg", url="http://blob/t1.jpg")],
        tmp_path,
        concurrency=1,
        session_factory=lambda: session,
    )
    assert results[0].ok and results[0].skipped
    assert session.calls == []


def test_download_writes_new_files(tmp_path: Path):
    session = _FakeSession(
        {
            "http://blob/t1.jpg": _FakeResponse(b"aaa"),
            "http://blob/t2.jpg": _FakeResponse(b"bbb"),
        }
    )
    results = download_all(
        [
            DownloadJob(file_name="t1.jpg", url="http://blob/t1.jpg"),
            DownloadJob(file_name="t2.jpg", url="http://blob/t2.jpg"),
        ],
        tmp_path,
        concurrency=4,
        session_factory=lambda: session,
    )
    ok_files = {r.file_name for r in results if r.ok and not r.skipped}
    assert ok_files == {"t1.jpg", "t2.jpg"}
    assert (tmp_path / "t1.jpg").read_bytes() == b"aaa"
    assert (tmp_path / "t2.jpg").read_bytes() == b"bbb"
    # No .part files left behind.
    assert list(tmp_path.glob("*.part")) == []


def test_download_records_failure_and_continues(tmp_path: Path):
    session = _FakeSession(
        {
            "http://blob/good.jpg": _FakeResponse(b"good"),
            # Force non-retryable 404 so the bad one fails fast without retry loop.
            "http://blob/bad.jpg": _FakeResponse(b"", status=404),
        }
    )
    results = download_all(
        [
            DownloadJob(file_name="good.jpg", url="http://blob/good.jpg"),
            DownloadJob(file_name="bad.jpg", url="http://blob/bad.jpg"),
        ],
        tmp_path,
        concurrency=2,
        session_factory=lambda: session,
        max_retries=0,
    )
    by_name = {r.file_name: r for r in results}
    assert by_name["good.jpg"].ok
    assert not by_name["bad.jpg"].ok and by_name["bad.jpg"].error
    assert (tmp_path / "good.jpg").exists()


def test_download_empty_jobs(tmp_path: Path):
    assert download_all([], tmp_path, session_factory=lambda: _FakeSession({})) == []


def test_progress_callback_invoked(tmp_path: Path):
    session = _FakeSession({"http://blob/t1.jpg": _FakeResponse(b"a")})
    calls: list[tuple[int, int]] = []
    download_all(
        [DownloadJob(file_name="t1.jpg", url="http://blob/t1.jpg")],
        tmp_path,
        concurrency=1,
        session_factory=lambda: session,
        progress=lambda d, t: calls.append((d, t)),
    )
    assert calls == [(1, 1)]


def test_download_retries_5xx(tmp_path: Path):
    """3 retries with exponential backoff. 503, 503, 200 → ok."""
    session = _FakeSession(
        {
            "http://blob/t1.jpg": [
                _FakeResponse(b"", status=503),
                _FakeResponse(b"", status=503),
                _FakeResponse(b"hello"),
            ]
        }
    )
    # patch time.sleep so the test runs fast
    import quiclabel_sync_project_coco.downloader as dl

    orig_sleep = dl.time.sleep
    dl.time.sleep = lambda _s: None
    try:
        results = download_all(
            [DownloadJob(file_name="t1.jpg", url="http://blob/t1.jpg")],
            tmp_path,
            concurrency=1,
            session_factory=lambda: session,
            max_retries=3,
        )
    finally:
        dl.time.sleep = orig_sleep

    assert results[0].ok
    assert (tmp_path / "t1.jpg").read_bytes() == b"hello"
    assert len(session.calls) == 3


def test_download_does_not_retry_404(tmp_path: Path):
    session = _FakeSession({"http://blob/t1.jpg": _FakeResponse(b"", status=404)})
    results = download_all(
        [DownloadJob(file_name="t1.jpg", url="http://blob/t1.jpg")],
        tmp_path,
        concurrency=1,
        session_factory=lambda: session,
        max_retries=3,
    )
    assert not results[0].ok
    assert "404" in (results[0].error or "")
    assert len(session.calls) == 1  # exactly one — no retries on 4xx


class _BarrierResponse:
    """Response whose iter_content blocks until a barrier is satisfied,
    proving that N workers genuinely run in parallel."""

    def __init__(self, barrier: threading.Barrier, body: bytes):
        self._barrier = barrier
        self._body = body
        self.status_code = 200

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def iter_content(self, chunk_size: int):
        # Block until N peers also reach here.
        self._barrier.wait(timeout=5.0)
        yield self._body


def test_download_runs_in_parallel(tmp_path: Path):
    """Without true parallelism the Barrier deadlocks and the test fails the
    overall timeout. With concurrency=N and N concurrent jobs, all rendezvous."""
    n = 4
    barrier = threading.Barrier(n)
    session = _FakeSession(
        {
            f"http://blob/t{i}.jpg": _BarrierResponse(barrier, f"b{i}".encode())
            for i in range(n)
        }
    )
    jobs = [
        DownloadJob(file_name=f"t{i}.jpg", url=f"http://blob/t{i}.jpg")
        for i in range(n)
    ]
    start = time.monotonic()
    results = download_all(
        jobs,
        tmp_path,
        concurrency=n,
        session_factory=lambda: session,
    )
    elapsed = time.monotonic() - start
    assert all(r.ok for r in results)
    # Should complete in well under the barrier's 5s timeout if parallel.
    assert elapsed < 4.0, f"Took {elapsed:.2f}s — likely serial execution"
