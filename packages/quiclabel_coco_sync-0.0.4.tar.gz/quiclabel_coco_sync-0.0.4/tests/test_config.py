import pytest
from quiclabel_sync_project_coco.config import ConfigError, resolve_config


def _kwargs(**overrides):
    base = dict(
        input_meta=None,
        cli_admin_url=None,
        cli_api_key=None,
        cli_project_id=None,
        cli_statuses=None,
        cli_tag_ids=None,
        cli_image_source=None,
        cli_concurrency=16,
        env={},
    )
    base.update(overrides)
    return base


class TestResolveConfig:
    def test_all_from_meta(self):
        meta = {
            "project_id": "proj-1",
            "filters": {"statuses": ["REVIEWED"], "tag_ids": ["a", "b"]},
            "image_source": "original",
        }
        cfg = resolve_config(
            **_kwargs(
                input_meta=meta,
                cli_admin_url="https://admin",
                cli_api_key="qk_x",
            )
        )
        assert cfg.project_id == "proj-1"
        assert cfg.statuses == ["REVIEWED"]
        assert cfg.tag_ids == ["a", "b"]
        assert cfg.image_source == "original"
        assert cfg.admin_url == "https://admin"

    def test_cli_overrides_meta(self):
        meta = {
            "project_id": "from-meta",
            "filters": {"statuses": ["REVIEWED"]},
            "image_source": "compressed",
        }
        cfg = resolve_config(
            **_kwargs(
                input_meta=meta,
                cli_admin_url="https://admin",
                cli_api_key="qk_x",
                cli_project_id="from-cli",
                cli_statuses="REVIEWING,REVIEWED",
                cli_image_source="original",
            )
        )
        assert cfg.project_id == "from-cli"
        assert cfg.statuses == ["REVIEWING", "REVIEWED"]
        assert cfg.image_source == "original"

    def test_env_used_when_cli_missing(self):
        meta = {
            "project_id": "p",
            "filters": {"statuses": ["REVIEWED"]},
            "image_source": "compressed",
        }
        cfg = resolve_config(
            **_kwargs(
                input_meta=meta,
                env={"QUICLABEL_API_KEY": "qk_env", "QUICLABEL_ADMIN_URL": "https://env/"},
            )
        )
        assert cfg.api_key == "qk_env"
        assert cfg.admin_url == "https://env"  # trailing slash stripped

    def test_missing_meta_raises_with_clear_message(self):
        with pytest.raises(ConfigError) as exc_info:
            resolve_config(
                **_kwargs(
                    cli_admin_url="https://admin",
                    cli_api_key="qk_x",
                )
            )
        msg = str(exc_info.value)
        assert "project_id" in msg
        assert "statuses" in msg
        assert "image_source" in msg

    def test_missing_meta_but_full_cli_works(self):
        cfg = resolve_config(
            **_kwargs(
                cli_admin_url="https://admin",
                cli_api_key="qk_x",
                cli_project_id="p",
                cli_statuses="REVIEWED",
                cli_image_source="compressed",
            )
        )
        assert cfg.project_id == "p"
        assert cfg.tag_ids == []

    def test_missing_admin_url_raises(self):
        with pytest.raises(ConfigError, match="admin_url"):
            resolve_config(
                **_kwargs(
                    cli_api_key="qk_x",
                    cli_project_id="p",
                    cli_statuses="REVIEWED",
                    cli_image_source="compressed",
                )
            )

    def test_missing_api_key_raises(self):
        with pytest.raises(ConfigError, match="api_key"):
            resolve_config(
                **_kwargs(
                    cli_admin_url="https://admin",
                    cli_project_id="p",
                    cli_statuses="REVIEWED",
                    cli_image_source="compressed",
                )
            )

    def test_explicit_empty_csv_overrides_meta(self):
        """Passing whitespace-only CSV is treated as 'user said empty list',
        which IS an override — meta's tag_ids should be discarded. This
        distinguishes 'not passed' (use meta) from 'passed but empty'."""
        meta = {
            "project_id": "p",
            "filters": {"statuses": ["REVIEWED"], "tag_ids": ["x"]},
            "image_source": "compressed",
        }
        cfg = resolve_config(
            **_kwargs(
                input_meta=meta,
                cli_admin_url="https://admin",
                cli_api_key="qk_x",
                cli_tag_ids="  ,  ",
            )
        )
        # "  ,  " parses to [] (after strip+filter), which is the override.
        assert cfg.tag_ids == []
