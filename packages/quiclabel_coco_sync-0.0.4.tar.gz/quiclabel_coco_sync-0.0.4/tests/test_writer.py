import json
from datetime import datetime
from pathlib import Path

import pytest

from quiclabel_sync_project_coco.writer import (
    timestamped_filename,
    write_dataset,
)


def test_timestamped_filename_format():
    name = timestamped_filename(datetime(2026, 5, 19, 14, 30, 45))
    assert name == "annotations-20260519-143045.json"


def test_write_dataset_merges_pages(tmp_path: Path):
    pages = [
        {
            "meta": {"project_id": "p"},
            "info": {"description": "x"},
            "categories": [{"id": 1, "name": "Lesion", "supercategory": "none"}],
            "images": [
                {"id": 1, "task_id": "t1", "file_name": "t1.jpg"},
                {"id": 2, "task_id": "t2", "file_name": "t2.jpg"},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1},
                {"id": 2, "image_id": 2, "category_id": 1},
            ],
            "next_cursor": "t2",
        },
        {
            "images": [
                {"id": 1, "task_id": "t3", "file_name": "t3.jpg"},
            ],
            "annotations": [
                {"id": 1, "image_id": 1, "category_id": 1},
            ],
            "next_cursor": None,
        },
    ]
    out = tmp_path / "annotations-test.json"
    ds = write_dataset(pages, out)

    assert ds["meta"] == {"project_id": "p"}
    assert ds["categories"][0]["name"] == "Lesion"
    assert [i["task_id"] for i in ds["images"]] == ["t1", "t2", "t3"]
    # IDs renumbered globally across pages.
    assert [i["id"] for i in ds["images"]] == [1, 2, 3]
    assert [a["image_id"] for a in ds["annotations"]] == [1, 2, 3]
    assert [a["id"] for a in ds["annotations"]] == [1, 2, 3]
    assert json.loads(out.read_text())["meta"]["project_id"] == "p"


def test_write_dataset_empty_raises(tmp_path: Path):
    with pytest.raises(ValueError):
        write_dataset([], tmp_path / "out.json")


def test_write_dataset_orphan_annotation_raises(tmp_path: Path):
    """An annotation pointing at a non-existent image_id is silent data
    corruption — refuse to write."""
    pages = [
        {
            "meta": {"project_id": "p"},
            "info": {},
            "categories": [],
            "images": [
                {"id": 1, "task_id": "t1", "file_name": "t1.jpg"},
            ],
            "annotations": [
                # 999 is not in the page's images.
                {"id": 1, "image_id": 999, "category_id": 1},
            ],
            "next_cursor": None,
        },
    ]
    with pytest.raises(ValueError, match="unknown image_id"):
        write_dataset(pages, tmp_path / "out.json")
