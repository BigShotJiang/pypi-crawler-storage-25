import numpy as np
import pandas as pd
import pytest

from privsyn import PrivSyn, PrivSynModel
from privsyn.lib_marginal import marg_determine as marg_determine_mod
from privsyn.lib_marginal import marg_select_helper as marg_select_helper_mod


def test_two_way_marginal_selection_returns_pairs():
    rng = np.random.default_rng(0)
    df = pd.DataFrame(
        {
            "x": rng.integers(0, 3, size=100),
            "y": rng.integers(0, 2, size=100),
            "z": rng.integers(0, 4, size=100),
        }
    )
    domain = {"x": 3, "y": 2, "z": 4}

    pairs = PrivSyn.two_way_marginal_selection(df, domain, rho_indif=0.0, rho_measure=0.1)

    assert isinstance(pairs, list)
    assert pairs
    assert all(isinstance(item, tuple) for item in pairs)


def test_privsyn_model_fit_and_sample_discrete():
    rng = np.random.default_rng(7)
    df = pd.DataFrame(
        {
            "x": rng.integers(0, 3, size=150),
            "y": rng.integers(0, 2, size=150),
            "z": rng.integers(0, 4, size=150),
        }
    )
    domain = {"x": 3, "y": 2, "z": 4}

    model = PrivSynModel(
        epsilon=1.0,
        delta=1e-6,
        random_state=123,
        extra_params={
            "update_iterations": 2,
            "consist_iterations": 5,
        },
    ).fit(df, domain)

    sample_a = model.sample(40, seed=999)
    sample_b = model.sample(40, seed=999)

    assert list(sample_a.columns) == list(df.columns)
    assert sample_a.shape == (40, 3)
    assert sample_a.equals(sample_b)
    for col, size in domain.items():
        assert sample_a[col].between(0, size - 1).all()


def test_privsyn_model_aligns_columns_to_domain_order():
    df = pd.DataFrame({"y": [0, 1, 1, 0], "x": [1, 0, 1, 0]})
    domain = {"x": 2, "y": 2}

    model = PrivSynModel(
        epsilon=1.0,
        random_state=0,
        extra_params={"update_iterations": 1, "consist_iterations": 3},
    ).fit(df, domain)

    out = model.sample(4, seed=0)

    assert list(out.columns) == ["x", "y"]


def test_privsyn_model_rejects_non_integer_encoded_input():
    df = pd.DataFrame({"x": [0.0, 1.5, 1.0], "y": [0, 1, 0]})
    domain = {"x": 2, "y": 2}

    try:
        PrivSynModel(epsilon=1.0).fit(df, domain)
    except ValueError as exc:
        assert "integer-coded" in str(exc)
    else:
        raise AssertionError("Expected non-integer encoded input to be rejected.")


def test_privsyn_model_single_column_fit_and_sample():
    df = pd.DataFrame({"x": [0, 1, 0, 1, 0, 1]})
    domain = {"x": 2}

    model = PrivSynModel(
        epsilon=1.0,
        random_state=0,
        extra_params={"update_iterations": 1, "consist_iterations": 3},
    ).fit(df, domain)

    out = model.sample(4, seed=0)

    assert out.shape == (4, 1)
    assert list(out.columns) == ["x"]
    assert out["x"].between(0, 1).all()


def test_privsyn_model_rejects_non_positive_rho():
    df = pd.DataFrame({"x": [0, 1, 0, 1], "y": [1, 0, 1, 0]})
    domain = {"x": 2, "y": 2}

    with pytest.raises(ValueError, match="rho"):
        PrivSynModel(
            epsilon=1.0,
            rho=0.0,
            random_state=0,
            extra_params={"update_iterations": 1, "consist_iterations": 3},
        ).fit(df, domain)


def test_privsyn_model_reuses_cached_dependency_statistics(tmp_path, monkeypatch):
    dep_dir = tmp_path / "dependency"
    dep_dir.mkdir()
    monkeypatch.setattr(
        marg_select_helper_mod.config,
        "DEPENDENCY_PATH",
        str(dep_dir),
        raising=False,
    )
    monkeypatch.setattr(
        marg_determine_mod.config,
        "DEPENDENCY_PATH",
        str(dep_dir),
        raising=False,
    )

    df = pd.DataFrame({"x": [0, 1, 0, 1], "y": [1, 0, 1, 0]})
    domain = {"x": 2, "y": 2}

    PrivSynModel(
        epsilon=1.0,
        random_state=0,
        dataset_name="demo",
        extra_params={"update_iterations": 1, "consist_iterations": 3},
    ).fit(df, domain)

    assert (dep_dir / "demo").exists()

    reused = PrivSynModel(
        epsilon=1.0,
        random_state=0,
        dataset_name="demo",
        extra_params={
            "update_iterations": 1,
            "consist_iterations": 3,
            "is_cal_depend": False,
        },
    ).fit(df, domain)

    assert reused.selected_marginals_
