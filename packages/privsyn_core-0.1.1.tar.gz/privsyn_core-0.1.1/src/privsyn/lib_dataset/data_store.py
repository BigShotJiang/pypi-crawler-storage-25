import pickle
import os

from .. import config


class DataStore:
    def __init__(self, args):
        self.args = args
        exp_root = self.args.get("artifact_root") or getattr(
            config,
            "EXPERIMENT_BASE_PATH",
            os.path.join("privsyn", "temp_data", "exp"),
        )
        dataset = str(self.args.get("dataset", "dataset"))
        method = str(self.args.get("method", "privsyn-core"))
        epsilon = self.args.get("epsilon", "unknown")
        num_preprocess = self.args.get("num_preprocess", "discrete")
        rare_threshold = self.args.get("rare_threshold", 0.0)
        self.parent_dir = os.path.join(
            exp_root,
            dataset,
            method,
            f"{epsilon}_{num_preprocess}_{rare_threshold}",
        )
        self.determine_data_path()
        self.generate_folder()
    
    def determine_data_path(self):
        dataset_name = str(self.args.get("dataset_name", self.args.get("dataset", "dataset")))
        synthesized_records_name = "_".join((dataset_name, "records"))
        marginal_name = "_".join((dataset_name, "marginal"))
        
        self.synthesized_records_file = os.path.join(self.parent_dir, synthesized_records_name)
        self.marginal_file = os.path.join(self.parent_dir, marginal_name)
        
    def generate_folder(self):
        # Ensure core temp/data paths exist
        for path in config.ALL_PATH:
            os.makedirs(path, exist_ok=True)
        # Ensure experiment parent dir exists for saving marginals/records
        os.makedirs(self.parent_dir, exist_ok=True)
    
    def load_processed_data(self):
        processed_file = os.path.join(
            config.PROCESSED_DATA_PATH,
            str(self.args.get("dataset_name", self.args.get("dataset", "dataset"))),
        )
        with open(processed_file, 'rb') as fh:
            return pickle.load(fh)
    
    def save_synthesized_records(self, records, save_path = None):
        if save_path is None:
            with open(self.synthesized_records_file, 'wb') as fh:
                pickle.dump(records, fh)
        else:
            dataset_name = str(self.args.get("dataset_name", self.args.get("dataset", "dataset")))
            target = os.path.join(save_path, '_'.join((dataset_name, str(self.args.get("epsilon", "unknown")))))
            with open(target, 'wb') as fh:
                pickle.dump(records, fh)
        
    def save_marginal(self, marginals):
        with open(self.marginal_file, 'wb') as fh:
            pickle.dump(marginals, fh)
    
    def load_marginal(self):
        with open(self.marginal_file, 'rb') as fh:
            return pickle.load(fh)
