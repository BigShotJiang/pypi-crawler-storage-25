"""Package-local paths for optional PrivSyn artifacts."""

import os
import tempfile


_BASE_TEMP_DIR = os.environ.get(
    "PRIVSYN_CORE_DATA_ROOT",
    os.environ.get(
        "PRIVSYN_DATA_ROOT",
        os.path.join(tempfile.gettempdir(), "privsyn_core"),
    ),
)

RAW_DATA_PATH = os.environ.get(
    "PRIVSYN_CORE_RAW_ROOT",
    os.environ.get("PRIVSYN_RAW_ROOT", "data"),
)
PROCESSED_DATA_PATH = os.path.join(_BASE_TEMP_DIR, "processed_data")
SYNTHESIZED_RECORDS_PATH = os.path.join(_BASE_TEMP_DIR, "synthesized_records")
MARGINAL_PATH = os.path.join(_BASE_TEMP_DIR, "marginal")
DEPENDENCY_PATH = os.path.join(_BASE_TEMP_DIR, "dependency")
EXPERIMENT_BASE_PATH = os.environ.get(
    "PRIVSYN_CORE_EXP_ROOT",
    os.environ.get(
        "PRIVSYN_EXP_ROOT",
        os.path.join(_BASE_TEMP_DIR, "exp"),
    ),
)

ALL_PATH = [
    PROCESSED_DATA_PATH,
    SYNTHESIZED_RECORDS_PATH,
    MARGINAL_PATH,
    DEPENDENCY_PATH,
]

TYPE_CONFIG_PATH = os.path.join(_BASE_TEMP_DIR, "fields")
