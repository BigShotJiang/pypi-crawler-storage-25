from __future__ import annotations

from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Any, Dict, Mapping, Optional

import numpy as np
import pandas as pd

from .core import PrivSyn, add_default_params
from .random import temporary_numpy_seed
from .rho_cdp import cdp_rho


@dataclass
class PrivSynModel:
    """Standalone wrapper around the discrete PrivSyn core.

    This API expects an already discrete/encoded dataframe whose values are
    integer category ids in ``[0, domain[col])`` for each column.
    """

    epsilon: float
    delta: float = 1e-6
    rho: Optional[float] = None
    random_state: Optional[int] = None
    dataset_name: str = "dataset"
    artifact_root: Optional[str] = None
    extra_params: Dict[str, Any] = field(default_factory=dict)

    _generator: Optional[PrivSyn] = field(default=None, init=False, repr=False)

    def fit(self, df_encoded: pd.DataFrame, domain: Mapping[str, int]) -> "PrivSynModel":
        df_aligned = _validate_discrete_input(df_encoded, domain)

        rho = self.rho if self.rho is not None else cdp_rho(self.epsilon, self.delta)
        if rho <= 0:
            raise ValueError("rho must be positive.")
        args = SimpleNamespace(
            dataset=self.dataset_name,
            dataset_name=self.dataset_name,
            method="privsyn-core",
            epsilon=self.epsilon,
            delta=self.delta,
            num_preprocess="discrete",
            rare_threshold=0.0,
            artifact_root=self.artifact_root,
            **self.extra_params,
        )
        args = add_default_params(args)
        args_dict = vars(args)

        generator = PrivSyn(args_dict, df_aligned, dict(domain), rho)
        with temporary_numpy_seed(self.random_state):
            if self.random_state is not None:
                generator.set_seed(self.random_state)
            generator.marginal_selection()

        self._generator = generator
        return self

    def sample(self, n: int, seed: Optional[int] = None) -> pd.DataFrame:
        if self._generator is None:
            raise RuntimeError("PrivSynModel must be fit before sample().")

        run_seed = self.random_state if seed is None else seed
        with temporary_numpy_seed(run_seed):
            if run_seed is not None:
                self._generator.set_seed(run_seed)
            self._generator.syn(n_sample=n, preprocesser=None, parent_dir=None)
        return self._generator.synthesized_df.copy()

    @property
    def selected_marginals_(self):
        if self._generator is None:
            raise RuntimeError("PrivSynModel must be fit before accessing selected_marginals_.")
        return list(self._generator.sel_marg_name)


def fit_privsyn(
    df_encoded: pd.DataFrame,
    domain: Mapping[str, int],
    *,
    epsilon: float,
    delta: float = 1e-6,
    rho: Optional[float] = None,
    random_state: Optional[int] = None,
    dataset_name: str = "dataset",
    artifact_root: Optional[str] = None,
    **extra_params: Any,
) -> PrivSynModel:
    """Fit the discrete PrivSyn core on an already encoded dataframe."""
    model = PrivSynModel(
        epsilon=epsilon,
        delta=delta,
        rho=rho,
        random_state=random_state,
        dataset_name=dataset_name,
        artifact_root=artifact_root,
        extra_params=dict(extra_params),
    )
    return model.fit(df_encoded, domain)


def _validate_discrete_input(df_encoded: pd.DataFrame, domain: Mapping[str, int]) -> pd.DataFrame:
    missing = [col for col in domain if col not in df_encoded.columns]
    if missing:
        raise ValueError(f"Input dataframe is missing domain columns: {missing}")

    ordered_columns = list(domain.keys())
    aligned = df_encoded.loc[:, ordered_columns].copy()

    for col, size in domain.items():
        if int(size) <= 0:
            raise ValueError(f"Domain size for column {col!r} must be positive.")
        series = pd.to_numeric(aligned[col], errors="raise")
        if series.isna().any():
            raise ValueError(f"Column {col!r} contains NaN values.")
        if not np.allclose(series.to_numpy(), np.round(series.to_numpy())):
            raise ValueError(f"Column {col!r} must contain integer-coded values.")
        integer_series = series.astype(int)
        if (integer_series < 0).any() or (integer_series >= int(size)).any():
            raise ValueError(
                f"Column {col!r} must contain encoded integer values in [0, {int(size)})."
            )
        aligned[col] = integer_series

    return aligned
