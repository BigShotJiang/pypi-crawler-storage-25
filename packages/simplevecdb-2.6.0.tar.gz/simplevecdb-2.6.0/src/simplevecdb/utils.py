from __future__ import annotations

import importlib
import itertools
import logging
import os
import random
import sqlite3
import sys
import time
from collections.abc import Iterable, Sequence
from contextlib import contextmanager
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Generator, TypeVar

F = TypeVar("F", bound=Callable[..., Any])

# Use standard logging to avoid circular import with logging module
_logger = logging.getLogger("simplevecdb.utils")


def _batched(iterable: Iterable[Any], n: int) -> Iterable[Sequence[Any]]:
    """Batch data into lists of length n. The last batch may be shorter."""
    if isinstance(iterable, Sequence):
        for i in range(0, len(iterable), n):
            yield iterable[i : i + n]
    else:
        it = iter(iterable)
        while True:
            batch = list(itertools.islice(it, n))
            if not batch:
                return
            yield batch


def _import_optional(name: str) -> Any:
    """Attempt to import a module while honoring tests that stub sys.modules."""
    sentinel = object()
    existing = sys.modules.get(name, sentinel)
    if existing is None:
        return None
    if existing is not sentinel:
        return existing
    try:
        return importlib.import_module(name)
    except Exception:
        return None


class DatabaseLockedError(Exception):
    """Raised when database remains locked after all retry attempts."""

    def __init__(self, message: str, attempts: int, total_wait: float):
        super().__init__(message)
        self.attempts = attempts
        self.total_wait = total_wait


def retry_on_lock(
    max_retries: int = 5,
    base_delay: float = 0.1,
    max_delay: float = 2.0,
    jitter: bool = True,
    total_timeout: float = 10.0,
) -> Callable[[F], F]:
    """
    Decorator that retries database operations on SQLite lock errors.

    Uses exponential backoff with optional jitter to handle concurrent write
    contention gracefully. Only retries on "database is locked" errors;
    other SQLite errors are raised immediately.

    Args:
        max_retries: Maximum number of retry attempts (default: 5).
        base_delay: Initial delay in seconds before first retry (default: 0.1).
        max_delay: Maximum delay between retries in seconds (default: 2.0).
        jitter: Add randomness to delay to avoid thundering herd (default: True).
        total_timeout: Absolute wall-clock budget in seconds (default: 10.0).
            Gives up early if cumulative sleep would exceed this, even if
            max_retries has not been reached.

    Returns:
        Decorated function with retry behavior.

    Raises:
        DatabaseLockedError: If all retry attempts fail due to lock contention.
        sqlite3.OperationalError: For non-lock SQLite errors.

    Example:
        >>> @retry_on_lock(max_retries=3, base_delay=0.05)
        ... def insert_data(conn, data):
        ...     conn.execute("INSERT INTO items VALUES (?)", (data,))
        ...     conn.commit()
    """

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: sqlite3.OperationalError | None = None
            total_wait = 0.0

            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except sqlite3.OperationalError as e:
                    error_msg = str(e).lower()
                    if "database is locked" not in error_msg:
                        # Not a lock error - raise immediately
                        raise

                    last_exception = e

                    if attempt < max_retries:
                        # Calculate delay with exponential backoff
                        delay = min(base_delay * (2**attempt), max_delay)

                        # Add jitter (±25%) to avoid thundering herd
                        if jitter:
                            delay *= 0.75 + random.random() * 0.5

                        # Enforce total_timeout budget
                        if total_wait + delay > total_timeout:
                            _logger.warning(
                                "Database lock retry would exceed total_timeout "
                                "(%.2fs spent, %.2fs budget) — giving up",
                                total_wait,
                                total_timeout,
                                extra={"operation": func.__name__},
                            )
                            break

                        total_wait += delay

                        _logger.warning(
                            "Database locked, retrying in %.3fs (attempt %d/%d)",
                            delay,
                            attempt + 1,
                            max_retries,
                            extra={
                                "operation": func.__name__,
                                "attempt": attempt + 1,
                                "max_retries": max_retries,
                                "delay_seconds": round(delay, 3),
                            },
                        )
                        time.sleep(delay)

            # All retries exhausted
            _logger.error(
                "Database locked after %d attempts (%.2fs total wait)",
                max_retries + 1,
                total_wait,
                extra={
                    "operation": func.__name__,
                    "attempts": max_retries + 1,
                    "total_wait_seconds": round(total_wait, 2),
                },
            )
            raise DatabaseLockedError(
                f"Database remained locked after {max_retries + 1} attempts "
                f"(waited {total_wait:.2f}s total)",
                attempts=max_retries + 1,
                total_wait=total_wait,
            ) from last_exception

        return wrapper  # type: ignore[return-value]

    return decorator


def async_retry_on_lock(
    max_retries: int = 5,
    base_delay: float = 0.1,
    max_delay: float = 2.0,
    jitter: bool = True,
    total_timeout: float = 10.0,
) -> Callable[[F], F]:
    """
    Async decorator that retries database operations on SQLite lock errors.

    Uses asyncio.sleep instead of time.sleep, avoiding executor thread blocking.
    Same backoff logic as retry_on_lock.

    Args:
        max_retries: Maximum number of retry attempts (default: 5).
        base_delay: Initial delay in seconds before first retry (default: 0.1).
        max_delay: Maximum delay between retries in seconds (default: 2.0).
        jitter: Add randomness to delay to avoid thundering herd (default: True).
        total_timeout: Absolute wall-clock budget in seconds (default: 10.0).

    Returns:
        Decorated async function with retry behavior.

    Raises:
        DatabaseLockedError: If all retry attempts fail due to lock contention.
        sqlite3.OperationalError: For non-lock SQLite errors.
    """
    import asyncio

    def decorator(func: F) -> F:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: sqlite3.OperationalError | None = None
            total_wait = 0.0

            for attempt in range(max_retries + 1):
                try:
                    return await func(*args, **kwargs)
                except sqlite3.OperationalError as e:
                    error_msg = str(e).lower()
                    if "database is locked" not in error_msg:
                        raise

                    last_exception = e

                    if attempt < max_retries:
                        delay = min(base_delay * (2**attempt), max_delay)

                        if jitter:
                            delay *= 0.75 + random.random() * 0.5

                        if total_wait + delay > total_timeout:
                            _logger.warning(
                                "Database lock retry would exceed total_timeout "
                                "(%.2fs spent, %.2fs budget) — giving up",
                                total_wait,
                                total_timeout,
                                extra={"operation": func.__name__},
                            )
                            break

                        total_wait += delay

                        _logger.warning(
                            "Database locked, retrying in %.3fs (attempt %d/%d)",
                            delay,
                            attempt + 1,
                            max_retries,
                            extra={
                                "operation": func.__name__,
                                "attempt": attempt + 1,
                                "max_retries": max_retries,
                                "delay_seconds": round(delay, 3),
                            },
                        )
                        await asyncio.sleep(delay)

            _logger.error(
                "Database locked after %d attempts (%.2fs total wait)",
                max_retries + 1,
                total_wait,
                extra={
                    "operation": func.__name__,
                    "attempts": max_retries + 1,
                    "total_wait_seconds": round(total_wait, 2),
                },
            )
            raise DatabaseLockedError(
                f"Database remained locked after {max_retries + 1} attempts "
                f"(waited {total_wait:.2f}s total)",
                attempts=max_retries + 1,
                total_wait=total_wait,
            ) from last_exception

        return wrapper  # type: ignore[return-value]

    return decorator


def validate_filter(filter_dict: dict[str, Any] | None) -> None:
    """
    Validate metadata filter structure before SQL generation.

    Ensures filter keys are strings and values are supported types.
    Call this before building SQL WHERE clauses to provide clear error
    messages for invalid filters.

    Args:
        filter_dict: Metadata filter dictionary to validate.

    Raises:
        ValueError: If filter keys are not strings or values are unsupported types.

    Example:
        >>> validate_filter({"category": "tech", "score": 0.95})  # OK
        >>> validate_filter({123: "value"})  # Raises ValueError
    """
    if filter_dict is None:
        return

    for key, value in filter_dict.items():
        if not isinstance(key, str):
            raise ValueError(
                f"Filter keys must be strings, got {type(key).__name__}: {key!r}"
            )
        if not isinstance(value, (int, float, str, list)):
            raise ValueError(
                f"Filter value for '{key}' must be int, float, str, or list, "
                f"got {type(value).__name__}: {value!r}"
            )
        if isinstance(value, float) and (
            value != value or value == float("inf") or value == float("-inf")
        ):
            raise ValueError(
                f"Filter value for '{key}' must be finite, got {value!r}"
            )
        if isinstance(value, list):
            if not value:
                raise ValueError(
                    f"Filter list for '{key}' must not be empty"
                )
            for i, item in enumerate(value):
                if not isinstance(item, (int, float, str)):
                    raise ValueError(
                        f"Filter list items for '{key}' must be int, float, or str, "
                        f"got {type(item).__name__} at index {i}: {item!r}"
                    )
                if isinstance(item, float) and (
                    item != item
                    or item == float("inf")
                    or item == float("-inf")
                ):
                    raise ValueError(
                        f"Filter list item for '{key}' at index {i} must be finite, "
                        f"got {item!r}"
                    )



@contextmanager
def file_lock(path: Path) -> Generator[None, None, None]:
    """Advisory file lock for cross-process safety.

    Uses fcntl.flock on Unix and msvcrt.locking on Windows.
    Creates a .lock file alongside the target path.

    Args:
        path: Path to the file to lock (a .lock sibling is created).

    Yields:
        None — the lock is held for the duration of the context.
    """
    lock_path = path.with_suffix(path.suffix + ".lock")
    # Open with O_CREAT|O_RDWR — no truncation. A stale lock file from a
    # crashed prior run is reused as-is (its contents are irrelevant; the
    # lock is on the FD via fcntl/msvcrt). Permissions are restricted so
    # other users on the host cannot tamper with the lock target.
    fd_int = os.open(str(lock_path), os.O_CREAT | os.O_RDWR, 0o600)
    fd = os.fdopen(fd_int, "r+b")  # noqa: SIM115
    try:
        if sys.platform == "win32":
            import msvcrt

            msvcrt.locking(fd.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl

            fcntl.flock(fd.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            try:
                if sys.platform == "win32":
                    import msvcrt

                    msvcrt.locking(fd.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(fd.fileno(), fcntl.LOCK_UN)
            except OSError:
                # Even if unlock fails (rare), the close below still runs.
                pass
    finally:
        # Always close the fd so we don't leak file handles when an unlock
        # call raises. The lock file itself is intentionally NOT unlinked:
        # flock/LK_LOCK are inode-bound, so removing the path while
        # another process is still queued on flock(fd) on the old inode
        # would let a third process create a new path → new inode →
        # acquire a different lock concurrently. A surviving zero-byte
        # ``.lock`` sidecar is far cheaper than a torn save.
        try:
            fd.close()
        except OSError:
            pass
