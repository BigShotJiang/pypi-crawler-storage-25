"""Tests for NolaxQueue — batching, cap, and timer behaviour."""
from __future__ import annotations

import threading
import time
import unittest
from unittest.mock import MagicMock, call, patch

from nolax.config import NolaxConfig
from nolax.queue import NolaxQueue


def make_config(**overrides) -> NolaxConfig:
    defaults = dict(
        api_key="test-key",
        environment="production",
        batch_size=5,
        flush_interval=60,  # long interval — use explicit flush in most tests
        debug=False,
    )
    defaults.update(overrides)
    return NolaxConfig(**defaults)


def make_event(path: str = "/test") -> dict:
    return {
        "method": "GET",
        "path": path,
        "statusCode": 200,
        "responseTime": 10,
        "payloadSize": 100,
        "timestamp": "2025-01-01T00:00:00.000Z",
    }


class TestBatchFlush(unittest.TestCase):
    """Events trigger a flush when batchSize is reached."""

    def setUp(self) -> None:
        self.send_patch = patch("nolax.queue._sender.send")
        self.mock_send = self.send_patch.start()

    def tearDown(self) -> None:
        self.send_patch.stop()

    def test_no_flush_before_batch_size(self) -> None:
        q = NolaxQueue(make_config(batch_size=3))
        q.push(make_event())
        q.push(make_event())
        time.sleep(0.05)  # let any spurious threads settle
        self.mock_send.assert_not_called()
        q.destroy()

    def test_flush_when_batch_size_reached(self) -> None:
        q = NolaxQueue(make_config(batch_size=3))
        q.push(make_event())
        q.push(make_event())
        q.push(make_event())
        # Give the daemon thread time to run
        time.sleep(0.1)
        self.mock_send.assert_called_once()
        batch = self.mock_send.call_args[0][0]
        self.assertEqual(len(batch), 3)
        q.destroy()

    def test_queue_is_empty_after_flush(self) -> None:
        q = NolaxQueue(make_config(batch_size=2))
        q.push(make_event("/a"))
        q.push(make_event("/b"))  # flush triggered
        time.sleep(0.1)
        # Pushing one more should not trigger another flush yet
        self.mock_send.reset_mock()
        q.push(make_event("/c"))
        time.sleep(0.05)
        self.mock_send.assert_not_called()
        q.destroy()

    def test_send_called_with_correct_events(self) -> None:
        q = NolaxQueue(make_config(batch_size=2))
        q.push(make_event("/x"))
        q.push(make_event("/y"))
        time.sleep(0.1)
        batch = self.mock_send.call_args[0][0]
        paths = [e["path"] for e in batch]
        self.assertEqual(paths, ["/x", "/y"])
        q.destroy()


class TestTimerFlush(unittest.TestCase):
    """Events are flushed when the timer fires."""

    def setUp(self) -> None:
        self.send_patch = patch("nolax.queue._sender.send")
        self.mock_send = self.send_patch.start()

    def tearDown(self) -> None:
        self.send_patch.stop()

    def test_timer_triggers_flush(self) -> None:
        # Very short interval so the test doesn't take long
        q = NolaxQueue(make_config(batch_size=1000, flush_interval=0))
        q.push(make_event())
        # Max jitter is +500 ms; sleep 750 ms to reliably outlast any jitter
        time.sleep(0.75)
        self.mock_send.assert_called()
        q.destroy()

    def test_no_flush_on_empty_queue(self) -> None:
        q = NolaxQueue(make_config(batch_size=1000, flush_interval=0))
        time.sleep(0.75)
        self.mock_send.assert_not_called()
        q.destroy()


class TestQueueCap(unittest.TestCase):
    """Oldest events are dropped when the 1 000-event cap is hit."""

    def setUp(self) -> None:
        self.send_patch = patch("nolax.queue._sender.send")
        self.send_patch.start()

    def tearDown(self) -> None:
        self.send_patch.stop()

    def test_cap_at_1000(self) -> None:
        q = NolaxQueue(make_config(batch_size=10_000, flush_interval=9999))
        for i in range(1001):
            q.push(make_event(f"/path/{i}"))
        with q._lock:
            self.assertEqual(len(q._queue), 1000)
            # /path/0 should have been dropped
            self.assertEqual(q._queue[0]["path"], "/path/1")
        q.destroy()

    def test_newest_events_survive(self) -> None:
        q = NolaxQueue(make_config(batch_size=10_000, flush_interval=9999))
        for i in range(1001):
            q.push(make_event(f"/path/{i}"))
        with q._lock:
            self.assertEqual(q._queue[-1]["path"], "/path/1000")
        q.destroy()


class TestDestroy(unittest.TestCase):
    def setUp(self) -> None:
        self.send_patch = patch("nolax.queue._sender.send")
        self.mock_send = self.send_patch.start()

    def tearDown(self) -> None:
        self.send_patch.stop()

    def test_destroy_cancels_timer(self) -> None:
        q = NolaxQueue(make_config(batch_size=1000, flush_interval=0))
        q.destroy()
        q.push(make_event())
        time.sleep(0.3)
        # After destroy the timer is gone; no new timer scheduled
        # (the push may still trigger batch flush if batchSize reached, but
        #  here batch_size=1000 so no batch flush either)
        self.mock_send.assert_not_called()


if __name__ == "__main__":
    unittest.main()
