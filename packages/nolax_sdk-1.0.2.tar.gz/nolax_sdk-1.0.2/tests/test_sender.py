"""Tests for the sender — gzip compression, HTTP, and retry logic."""
from __future__ import annotations

import gzip
import json
import unittest
from io import BytesIO
from unittest.mock import MagicMock, call, patch

from nolax.config import INGEST_ENDPOINT, NolaxConfig
from nolax.sender import send


def make_config(**overrides) -> NolaxConfig:
    defaults = dict(
        api_key="test-key",
        environment="production",
        debug=False,
    )
    defaults.update(overrides)
    return NolaxConfig(**defaults)


SAMPLE_EVENTS = [
    {
        "method": "GET",
        "path": "/users/:id",
        "statusCode": 200,
        "responseTime": 42,
        "payloadSize": 256,
        "ip": "127.0.0.1",
        "userAgent": "pytest",
        "timestamp": "2025-01-01T00:00:00.000Z",
    }
]


def _make_response(status: int = 202) -> MagicMock:
    """Build a mock context-manager response with the given status code."""
    resp = MagicMock()
    resp.status = status
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


class TestSendPayload(unittest.TestCase):
    """Verify the shape and encoding of the outbound request."""

    @patch("nolax.sender.urllib.request.urlopen")
    def test_posts_to_configured_endpoint(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _make_response(202)
        send(SAMPLE_EVENTS, make_config())
        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.full_url, INGEST_ENDPOINT)
        self.assertEqual(req.get_method(), "POST")

    @patch("nolax.sender.urllib.request.urlopen")
    def test_sets_correct_headers(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _make_response(202)
        send(SAMPLE_EVENTS, make_config())
        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.get_header("X-nolax-key"), "test-key")
        self.assertEqual(req.get_header("Content-type"), "application/json")
        self.assertEqual(req.get_header("Content-encoding"), "gzip")

    @patch("nolax.sender.urllib.request.urlopen")
    def test_body_is_valid_gzip_json(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _make_response(202)
        send(SAMPLE_EVENTS, make_config())
        req = mock_urlopen.call_args[0][0]
        decompressed = gzip.decompress(req.data)
        parsed = json.loads(decompressed)
        self.assertEqual(parsed["environment"], "PRODUCTION")
        self.assertEqual(len(parsed["events"]), 1)
        self.assertEqual(parsed["events"][0]["path"], "/users/:id")


class TestPlanLimit(unittest.TestCase):
    """HTTP 429 must not trigger a retry."""

    @patch("nolax.sender.urllib.request.urlopen")
    def test_no_retry_on_429(self, mock_urlopen: MagicMock) -> None:
        import urllib.error
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="https://server.nolax.net/ingest",
            code=429,
            msg="Too Many Requests",
            hdrs=MagicMock(),
            fp=None,
        )
        send(SAMPLE_EVENTS, make_config())
        self.assertEqual(mock_urlopen.call_count, 1)


class TestRetryLogic(unittest.TestCase):
    """Verify exponential-backoff retry and silent drop after 3 failures."""

    @patch("nolax.sender.time.sleep")
    @patch("nolax.sender.urllib.request.urlopen")
    def test_retries_three_times_on_network_error(
        self, mock_urlopen: MagicMock, mock_sleep: MagicMock
    ) -> None:
        mock_urlopen.side_effect = OSError("ECONNREFUSED")
        send(SAMPLE_EVENTS, make_config())
        self.assertEqual(mock_urlopen.call_count, 3)

    @patch("nolax.sender.time.sleep")
    @patch("nolax.sender.urllib.request.urlopen")
    def test_exponential_backoff_delays(
        self, mock_urlopen: MagicMock, mock_sleep: MagicMock
    ) -> None:
        mock_urlopen.side_effect = OSError("timeout")
        send(SAMPLE_EVENTS, make_config())
        sleep_calls = [c[0][0] for c in mock_sleep.call_args_list]
        # First two attempts sleep before the next try; no sleep after the third fail
        self.assertEqual(sleep_calls, [1, 2])

    @patch("nolax.sender.time.sleep")
    @patch("nolax.sender.urllib.request.urlopen")
    def test_succeeds_on_second_attempt(
        self, mock_urlopen: MagicMock, mock_sleep: MagicMock
    ) -> None:
        mock_urlopen.side_effect = [OSError("timeout"), _make_response(202)]
        send(SAMPLE_EVENTS, make_config())
        self.assertEqual(mock_urlopen.call_count, 2)

    @patch("nolax.sender.time.sleep")
    @patch("nolax.sender.urllib.request.urlopen")
    def test_logs_warning_after_all_retries_exhausted(
        self, mock_urlopen: MagicMock, mock_sleep: MagicMock
    ) -> None:
        mock_urlopen.side_effect = OSError("network gone")
        with self.assertLogs("nolax", level="WARNING") as log:
            send(SAMPLE_EVENTS, make_config())
        self.assertTrue(any("3 attempts" in msg for msg in log.output))

    @patch("nolax.sender.time.sleep")
    @patch("nolax.sender.urllib.request.urlopen")
    def test_does_not_raise_on_failure(
        self, mock_urlopen: MagicMock, _mock_sleep: MagicMock
    ) -> None:
        mock_urlopen.side_effect = OSError("gone")
        # Must not raise
        try:
            send(SAMPLE_EVENTS, make_config())
        except Exception as exc:  # pragma: no cover
            self.fail(f"send() raised unexpectedly: {exc}")


if __name__ == "__main__":
    unittest.main()
