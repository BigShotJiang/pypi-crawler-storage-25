"""Tests for NolaxFlask and NolaxFastAPI middleware."""
from __future__ import annotations

import asyncio
import unittest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_flask_app():
    """Return a minimal Flask app with NolaxFlask registered."""
    from flask import Flask
    from nolax import NolaxFlask

    app = Flask(__name__)
    nolax = NolaxFlask(api_key="test-key", environment="testing")
    nolax.init_app(app)
    return app, nolax


# ---------------------------------------------------------------------------
# Flask tests
# ---------------------------------------------------------------------------

class TestNolaxFlask(unittest.TestCase):
    def setUp(self) -> None:
        try:
            import flask  # noqa: F401
        except ImportError:
            self.skipTest("flask not installed")

        self.queue_patch = patch("nolax.middleware.NolaxQueue")
        self.MockQueue = self.queue_patch.start()
        self.mock_push = MagicMock()
        self.MockQueue.return_value.push = self.mock_push

    def tearDown(self) -> None:
        self.queue_patch.stop()

    def test_push_called_after_request(self) -> None:
        app, _ = make_flask_app()

        @app.route("/hello")
        def hello():
            return "ok", 200

        with app.test_client() as client:
            client.get("/hello")

        self.mock_push.assert_called_once()
        event = self.mock_push.call_args[0][0]
        self.assertEqual(event["method"], "GET")
        self.assertEqual(event["statusCode"], 200)
        self.assertEqual(event["path"], "/hello")

    def test_path_uses_route_pattern(self) -> None:
        app, _ = make_flask_app()

        @app.route("/users/<int:user_id>")
        def get_user(user_id: int):
            return f"user {user_id}", 200

        with app.test_client() as client:
            client.get("/users/42")

        event = self.mock_push.call_args[0][0]
        self.assertEqual(event["path"], "/users/<int:user_id>")

    def test_userAgent_truncated_to_255(self) -> None:
        app, _ = make_flask_app()

        @app.route("/ping")
        def ping():
            return "pong", 200

        long_ua = "x" * 400
        with app.test_client() as client:
            client.get("/ping", headers={"User-Agent": long_ua})

        event = self.mock_push.call_args[0][0]
        self.assertEqual(len(event["userAgent"]), 255)

    def test_no_exception_raised_when_push_fails(self) -> None:
        self.mock_push.side_effect = RuntimeError("boom")
        app, _ = make_flask_app()

        @app.route("/safe")
        def safe():
            return "ok", 200

        with app.test_client() as client:
            resp = client.get("/safe")

        # The response must still be 200 even though push raised
        self.assertEqual(resp.status_code, 200)

    def test_response_time_is_positive_number(self) -> None:
        app, _ = make_flask_app()

        @app.route("/timed")
        def timed():
            return "ok", 200

        with app.test_client() as client:
            client.get("/timed")

        event = self.mock_push.call_args[0][0]
        self.assertIsInstance(event["responseTime"], int)
        self.assertGreaterEqual(event["responseTime"], 0)

    def test_timestamp_ends_with_z(self) -> None:
        app, _ = make_flask_app()

        @app.route("/ts")
        def ts_route():
            return "ok", 200

        with app.test_client() as client:
            client.get("/ts")

        event = self.mock_push.call_args[0][0]
        self.assertTrue(event["timestamp"].endswith("Z"))


# ---------------------------------------------------------------------------
# FastAPI / ASGI tests
# ---------------------------------------------------------------------------

class TestNolaxFastAPI(unittest.TestCase):
    def setUp(self) -> None:
        try:
            from fastapi import FastAPI  # noqa: F401
            from httpx import AsyncClient  # noqa: F401
        except ImportError:
            self.skipTest("fastapi or httpx not installed")

        self.queue_patch = patch("nolax.middleware.NolaxQueue")
        self.MockQueue = self.queue_patch.start()
        self.mock_push = MagicMock()
        self.MockQueue.return_value.push = self.mock_push

    def tearDown(self) -> None:
        self.queue_patch.stop()

    def _make_app(self):
        from fastapi import FastAPI
        from nolax import NolaxFastAPI

        app = FastAPI()
        app.add_middleware(NolaxFastAPI, api_key="test-key", environment="testing")

        @app.get("/items/{item_id}")
        async def get_item(item_id: int):
            return {"item_id": item_id}

        return app

    def _run(self, coro):
        return asyncio.run(coro)

    async def _get(self, path: str, **kwargs):
        import httpx
        app = self._make_app()
        transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            return await client.get(path, **kwargs)

    def test_push_called_after_request(self) -> None:
        self._run(self._get("/items/1"))
        self.mock_push.assert_called_once()

    def test_status_code_captured(self) -> None:
        self._run(self._get("/items/1"))
        event = self.mock_push.call_args[0][0]
        self.assertEqual(event["statusCode"], 200)

    def test_method_captured(self) -> None:
        self._run(self._get("/items/1"))
        event = self.mock_push.call_args[0][0]
        self.assertEqual(event["method"], "GET")

    def test_userAgent_truncated(self) -> None:
        long_ua = "z" * 400
        self._run(self._get("/items/1", headers={"user-agent": long_ua}))
        event = self.mock_push.call_args[0][0]
        self.assertLessEqual(len(event["userAgent"]), 255)

    def test_no_exception_propagates(self) -> None:
        self.mock_push.side_effect = RuntimeError("boom")
        # Should complete without error
        resp = self._run(self._get("/items/1"))
        self.assertEqual(resp.status_code, 200)

    def test_timestamp_ends_with_z(self) -> None:
        self._run(self._get("/items/1"))
        event = self.mock_push.call_args[0][0]
        self.assertTrue(event["timestamp"].endswith("Z"))


if __name__ == "__main__":
    unittest.main()
