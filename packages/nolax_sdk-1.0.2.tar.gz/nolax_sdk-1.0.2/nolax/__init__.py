"""
nolax-sdk — Python observability SDK for the Nolax platform.

Captures HTTP request/response metadata from Flask and FastAPI applications
and streams it asynchronously to the Nolax ingest endpoint.

Ingest contract version: 1.0
"""
from .config import NolaxConfig
from .middleware import NolaxFastAPI, NolaxFlask

__version__ = "1.0.2"
__all__ = ["NolaxFlask", "NolaxFastAPI", "NolaxConfig"]
