"""Thread-safe in-memory event queue with timer- and batch-triggered flushing."""
from __future__ import annotations

import random
import threading
from typing import Any, Dict, List

from .config import NolaxConfig
from . import sender as _sender

_MAX_SIZE = 1000


class NolaxQueue:
    """
    Thread-safe in-memory queue that batches captured events and flushes
    them to the Nolax backend asynchronously.

    Flush is triggered when either:
    - The queue length reaches ``config.batch_size``, or
    - The ``config.flush_interval`` timer fires (with ±500 ms jitter).

    The queue is capped at 1 000 events.  When the cap is reached the
    oldest event is dropped to make room for the new one.

    All flushes run on daemon threads so they never block the host
    application and never prevent process exit.
    """

    def __init__(self, config: NolaxConfig) -> None:
        """
        Initialise the queue and start the background flush timer.

        Args:
            config: SDK configuration.
        """
        self._config = config
        self._queue: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None
        self._start_timer()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def push(self, event: Dict[str, Any]) -> None:
        """
        Add *event* to the queue.  Triggers an immediate flush if the
        queue has reached ``batch_size``.

        Args:
            event: Captured HTTP event dict.
        """
        with self._lock:
            if len(self._queue) >= _MAX_SIZE:
                self._queue.pop(0)  # drop oldest
            self._queue.append(event)
            if len(self._queue) >= self._config.batch_size:
                self._flush_async_locked()

    def flush_now(self) -> None:
        """Force an immediate synchronous flush (useful for shutdown hooks)."""
        with self._lock:
            batch, self._queue = self._queue[:], []
        if batch:
            _sender.send(batch, self._config)

    def destroy(self) -> None:
        """Cancel the background timer (useful in tests)."""
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _flush_async_locked(self) -> None:
        """Drain the queue and send on a daemon thread. Must be called under _lock."""
        batch, self._queue = self._queue[:], []
        t = threading.Thread(target=_sender.send, args=(batch, self._config), daemon=True)
        t.start()

    def _start_timer(self) -> None:
        """Schedule the next timer-based flush with ±500 ms jitter."""
        jitter = random.uniform(-0.5, 0.5)
        interval = max(0.0, self._config.flush_interval + jitter)
        self._timer = threading.Timer(interval, self._on_timer)
        self._timer.daemon = True
        self._timer.start()

    def _on_timer(self) -> None:
        """Timer callback — flushes if there is anything queued, then reschedules."""
        with self._lock:
            if self._queue:
                self._flush_async_locked()
        self._start_timer()  # always reschedule
