"""WSGI (Flask) and ASGI (FastAPI) middleware implementations."""
from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict

from .config import NolaxConfig
from .queue import NolaxQueue


class NolaxFlask:
    """
    Flask middleware that captures HTTP request/response metadata and
    streams it asynchronously to the Nolax ingest endpoint.

    Usage::

        from nolax import NolaxFlask

        nolax = NolaxFlask(api_key="nlx_proj_xxx", environment="production")
        nolax.init_app(app)

    Or with the application factory pattern::

        nolax = NolaxFlask(api_key="nlx_proj_xxx", environment="production")
        # later …
        nolax.init_app(app)
    """

    def __init__(self, api_key: str, environment: str, **kwargs: Any) -> None:
        """
        Create a NolaxFlask instance.

        Args:
            api_key: Your Nolax project API key.
            environment: Deployment environment (e.g. ``'production'``).
            **kwargs: Additional :class:`~nolax.config.NolaxConfig` fields
                (``endpoint``, ``batch_size``, ``flush_interval``, ``debug``).
        """
        self._config = NolaxConfig(api_key=api_key, environment=environment, **kwargs)
        self._queue = NolaxQueue(self._config)

    def init_app(self, app: Any) -> None:
        """
        Register before/after request hooks on a Flask application.

        Args:
            app: A Flask application instance.
        """
        app.before_request(self._before_request)
        app.after_request(self._after_request)

    def _before_request(self) -> None:
        """Record the start time on Flask's ``g`` object."""
        try:
            from flask import g  # type: ignore[import]

            g._nolax_start = time.perf_counter()
        except Exception:
            pass

    def _after_request(self, response: Any) -> Any:
        """Capture event metadata and push to the queue."""
        try:
            from flask import g, request  # type: ignore[import]

            start = getattr(g, "_nolax_start", None)
            if start is None:
                return response

            elapsed = (time.perf_counter() - start) * 1000
            raw_ua = request.headers.get("User-Agent") or ""

            self._queue.push(
                {
                    "method": request.method,
                    "path": str(request.url_rule) if request.url_rule else request.path,
                    "statusCode": response.status_code,
                    "responseTime": round(elapsed),
                    "payloadSize": len(response.get_data()),
                    "ip": request.remote_addr,
                    "userAgent": raw_ua[:255] or None,
                    "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                }
            )
        except Exception:
            pass  # the SDK must never affect the host response
        return response


class NolaxFastAPI:
    """
    Pure-ASGI middleware for FastAPI (and any Starlette-compatible app).

    Implemented as a raw ASGI callable so that importing this class does
    **not** require Starlette/FastAPI to be installed — the import is only
    needed at instantiation time.

    Usage::

        from nolax import NolaxFastAPI
        from fastapi import FastAPI

        app = FastAPI()
        app.add_middleware(
            NolaxFastAPI,
            api_key="nlx_proj_xxx",
            environment="production",
        )
    """

    def __init__(self, app: Any, *, api_key: str, environment: str, **kwargs: Any) -> None:
        """
        Wrap *app* with the Nolax ASGI middleware.

        Args:
            app: The inner ASGI application.
            api_key: Your Nolax project API key.
            environment: Deployment environment (e.g. ``'production'``).
            **kwargs: Additional :class:`~nolax.config.NolaxConfig` fields.
        """
        self._app = app
        self._config = NolaxConfig(api_key=api_key, environment=environment, **kwargs)
        self._queue = NolaxQueue(self._config)

    async def __call__(self, scope: Dict[str, Any], receive: Callable, send: Callable) -> None:
        """ASGI callable entry point."""
        if scope["type"] != "http":
            await self._app(scope, receive, send)
            return

        start = time.perf_counter()
        # Mutable containers for values captured inside the send wrapper closure
        status_holder = [200]
        content_length_holder = [0]

        async def send_wrapper(message: Dict[str, Any]) -> None:
            if message["type"] == "http.response.start":
                status_holder[0] = message.get("status", 200)
                for raw_name, raw_value in message.get("headers", []):
                    if raw_name.lower() == b"content-length":
                        try:
                            content_length_holder[0] = int(raw_value)
                        except (ValueError, TypeError):
                            pass
            await send(message)

        await self._app(scope, receive, send_wrapper)

        try:
            elapsed = (time.perf_counter() - start) * 1000

            # Prefer matched route pattern over raw path
            path: str = scope.get("path", "/")
            route = scope.get("route")
            if route and hasattr(route, "path"):
                path = route.path

            # Extract user-agent from raw ASGI headers (list of byte tuples)
            headers_raw: Dict[bytes, bytes] = dict(scope.get("headers", []))
            raw_ua = headers_raw.get(b"user-agent", b"").decode("utf-8", errors="replace")

            client = scope.get("client")

            self._queue.push(
                {
                    "method": scope.get("method", "GET"),
                    "path": path,
                    "statusCode": status_holder[0],
                    "responseTime": round(elapsed),
                    "payloadSize": content_length_holder[0],
                    "ip": client[0] if client else None,
                    "userAgent": raw_ua[:255] or None,
                    "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                }
            )
        except Exception:
            pass  # the SDK must never affect the host response
