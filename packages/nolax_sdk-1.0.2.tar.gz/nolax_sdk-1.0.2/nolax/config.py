"""Configuration dataclass for the Nolax SDK."""
from __future__ import annotations

from dataclasses import dataclass

# Change this line between SDK deployments
INGEST_ENDPOINT = "https://server.nolax.net/ingest"


@dataclass
class NolaxConfig:
    """
    Configuration for the Nolax observability SDK.

    Args:
        api_key: Your Nolax project API key (e.g. ``nlx_proj_xxxxxxxxxxxx``).
        environment: Deployment environment tag included in every event.
        batch_size: Number of events that trigger an immediate flush. Default 20.
        flush_interval: Seconds between timer-based flushes. Default 5.
        debug: Enable verbose flush logging via the ``nolax`` logger. Default False.
    """

    api_key: str
    environment: str
    batch_size: int = 20
    flush_interval: int = 5  # seconds
    debug: bool = False

    def __post_init__(self) -> None:
        if not self.api_key:
            raise ValueError("[nolax] api_key is required")
