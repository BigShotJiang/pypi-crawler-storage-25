"""HTTP sender with gzip compression and exponential-backoff retry."""
from __future__ import annotations

import gzip
import json
import logging
import time
import urllib.error
import urllib.request
from typing import Any, Dict, List

from .config import INGEST_ENDPOINT, NolaxConfig

logger = logging.getLogger("nolax")


def send(events: List[Dict[str, Any]], config: NolaxConfig) -> None:
    """
    Compress *events* and POST the batch to the Nolax ingest endpoint.

    Retries up to 3 times with exponential backoff (1 s, 2 s, 4 s).
    After 3 failures the batch is silently dropped and the error is logged
    at WARNING level.  This function never raises.

    Args:
        events: List of captured event dicts to send.
        config: SDK configuration including API key and endpoint.
    """
    payload = json.dumps(
        {
            "environment": config.environment.upper(),
            "events": events,
        }
    ).encode("utf-8")

    compressed = gzip.compress(payload)

    for attempt in range(3):
        try:
            req = urllib.request.Request(
                INGEST_ENDPOINT,
                data=compressed,
                headers={
                    "X-Nolax-Key": config.api_key,
                    "Content-Type": "application/json",
                    "Content-Encoding": "gzip",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                status = resp.status
                if config.debug:
                    logger.debug(
                        "nolax: flushed %d events → HTTP %d", len(events), status
                    )
                if status == 429:
                    # Plan limit reached — don't retry
                    return
                return  # 2xx success

        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                return  # plan limit, don't retry
            _handle_attempt_error(exc, attempt, len(events), config)
        except Exception as exc:  # network errors, timeouts, etc.
            _handle_attempt_error(exc, attempt, len(events), config)


def _handle_attempt_error(
    exc: Exception, attempt: int, event_count: int, config: NolaxConfig
) -> None:
    """Sleep before the next retry, or log and give up after the final attempt."""
    if attempt < 2:
        time.sleep(2**attempt)  # 1 s, 2 s
    else:
        logger.warning(
            "nolax: flush failed after 3 attempts, dropping %d events: %s",
            event_count,
            exc,
        )
