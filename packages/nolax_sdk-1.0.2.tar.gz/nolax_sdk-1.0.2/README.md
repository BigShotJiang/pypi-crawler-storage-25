# nolax-sdk (Python)

Python observability middleware for the [Nolax](https://nolax.io) platform.
Supports Flask (WSGI) and FastAPI (ASGI).

## Installation

```bash
pip install nolax-sdk
```

## Quick start

### Flask

```python
from flask import Flask
from nolax import NolaxFlask

app = Flask(__name__)
NolaxFlask(api_key='nlx_proj_xxx', environment='production').init_app(app)
```

### FastAPI

```python
from fastapi import FastAPI
from nolax import NolaxFastAPI

app = FastAPI()
app.add_middleware(NolaxFastAPI, api_key='nlx_proj_xxx', environment='production')
```

## Configuration

See the [root README](../README.md) for the complete configuration reference and
shared behaviour documentation.

## Development

```bash
pip install -e ".[dev]"
pytest
```

## Ingest contract version

`1.0` — see [root README](../README.md#ingest-contract--v1).
