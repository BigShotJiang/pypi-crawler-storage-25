"""Lazy DB/auth/observability setup for ops-plane commands.

Call ``init_ops_context(ctx)`` at the start of any ops-plane command
(or via the Typer group callback registered in ``main.py``).
"""

from __future__ import annotations

import logging
import os
from enum import Enum

import typer

from cli.console import error, info, warning


class AuthMethod(str, Enum):
    """Database authentication method."""

    IAM = "iam"
    PASSWORD = "password"


def _parse_env(value: str) -> str:
    normalized = value.strip().lower()
    if normalized in {"dev", "prod"}:
        error(
            f"Invalid environment '{value}'. "
            "Use full name: development, preview, production, or test."
        )
        raise typer.Exit(1)
    return normalized


def _auth_env_prefix(settings_app_env: object) -> str:
    if str(settings_app_env) == "production":
        return "PROD"
    if str(settings_app_env) == "development":
        return "DEV"
    if str(settings_app_env) == "test":
        return "DEV"
    return "PREVIEW"


def init_ops_context(ctx: typer.Context):
    """Heavy DB/auth/observability init — called lazily by ops-plane commands.

    Reads raw flags stashed in ``ctx.obj`` by the lightweight main callback
    and performs the full Settings / IAM / observability setup.  Sets
    ``ctx.obj["settings"]`` and ``ctx.obj["_ops_ready"] = True``.

    Returns the ``Settings`` instance for convenience.
    """
    if ctx.obj.get("_ops_ready"):
        return ctx.obj["settings"]

    from cli._has_core import require_core

    require_core("this command")

    from infra.auth import AuthError, get_effective_user_for_iam, validate_auth_config
    from infra.settings import Environment, ExecutionContext, Settings, get_settings

    from infra import init_observability

    verbose = ctx.obj.get("_verbose", False)
    log_level = logging.DEBUG if verbose else logging.WARNING
    init_observability("cli", log_level=log_level, enable_json_logs=False)

    env_flag = ctx.obj.get("_env")
    auth_flag = ctx.obj.get("_auth")
    user_flag = ctx.obj.get("_user")

    # --- resolve environment ------------------------------------------------
    if env_flag is not None:
        try:
            app_env = Environment(_parse_env(env_flag))
        except ValueError:
            error(
                f"Invalid environment '{env_flag}'. Valid: development, preview, production, test."
            )
            raise typer.Exit(1)
    else:
        app_env_str = os.getenv("APP_ENV") or Environment.PRODUCTION.value
        try:
            app_env = Environment(_parse_env(app_env_str))
        except ValueError:
            app_env = Environment.PRODUCTION

    os.environ["APP_ENV"] = app_env.value
    settings = Settings(app_env=app_env, execution_context=ExecutionContext.HUMAN)

    # --- resolve auth -------------------------------------------------------
    auth_info: list[str] = []
    env_prefix = _auth_env_prefix(settings.app_env)

    default_user = settings.effective_db_user
    default_use_iam = settings.effective_use_iam_auth
    default_password = settings.effective_alloydb_password

    if auth_flag is not None:
        use_iam_auth = auth_flag == AuthMethod.IAM
    else:
        use_iam_auth = default_use_iam

    if user_flag is not None:
        effective_user = user_flag
    elif use_iam_auth:
        try:
            effective_user = get_effective_user_for_iam(None, default_user)
        except AuthError as e:
            error(str(e))
            raise typer.Exit(1)
    else:
        effective_user = default_user

    try:
        validate_auth_config(
            username=effective_user,
            use_iam_auth=use_iam_auth,
            password=default_password if not use_iam_auth else "",
        )
    except AuthError as e:
        error(str(e))
        raise typer.Exit(1)

    if use_iam_auth:
        os.environ[f"ALLOYDB_IAM_AUTH_{env_prefix}"] = "true"
        auth_info.append("IAM auth")
    else:
        os.environ[f"ALLOYDB_IAM_AUTH_{env_prefix}"] = "false"
        auth_info.append("password auth")

    os.environ[f"ALLOYDB_USER_{env_prefix}"] = effective_user
    auth_info.append(f"user={effective_user}")

    # Reload settings with overrides
    get_settings.cache_clear()
    settings = Settings(app_env=settings.app_env, execution_context=ExecutionContext.HUMAN)

    try:
        settings.validate_environment_access()
    except PermissionError as e:
        error(str(e))
        raise typer.Exit(1)

    # --- store in context ---------------------------------------------------
    ctx.obj["settings"] = settings
    ctx.obj["_ops_ready"] = True

    profile = ctx.obj.get("cli_profile") or os.getenv("BUILDAI_CLI_PROFILE") or "internal_admin"
    ctx.obj["cli_profile"] = profile
    os.environ["BUILDAI_CLI_PROFILE"] = profile
    if ctx.obj.get("allow_write"):
        os.environ["BUILDAI_CLI_WRITE"] = "true"

    # --- banner -------------------------------------------------------------
    auth_str = f" [{', '.join(auth_info)}]"
    if settings.is_production:
        warning(f"Environment: PRODUCTION ({settings.db_name}){auth_str} | profile={profile}")
    else:
        message = (
            f"Environment: {settings.app_env.value} ({settings.db_name})"
            f"{auth_str} | profile={profile}"
        )
        info(message)

    return settings
