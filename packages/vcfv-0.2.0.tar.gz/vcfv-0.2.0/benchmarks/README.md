# Benchmarks

Place your own VCF file in `benchmarks/fixtures/` and run:

    python benchmarks/benchmark.py benchmarks/fixtures/your_file.vcf --runs 10