"""
**Introduction**:
    Smart-AJ Calendar Engine
    Developed by: Ajay Sah

    This module provides a unified intelligent calendar system that combines Hindu Panchang-Based festivals, Islamic (Hijri) calendar events, and fixed-date national/international holidays.

**Key Features**:
    - Hindu Festivals:
    Calculated using accurate Panchang logic baseed on astronomical positions of Sun and Moon (Tithi, Nakshatra, Maas, Paksha).

    - Islamic Festivals:
    Determind using Hijri calendar calculations with sunset-based day transition, ensuring realistic Islamic date handling.

    - National & International Holidays:
    Fixed-date events such as Republic Day, Independence Day, etc.

    - Astronomy-Based Engine:
    Uses precise astronomical computations for High Accuracy.
    
**Purpose**:
    Given a Gregorian datetime, returns Hindu & Islamic festivals with National holiday names.

**Agrs**:
    df: pandas.DataFrame, str: date_column_name

**Returns**:
    df: pandas.DataFrame with New column 'festival'

**Example**:
    from smart import Indian_Calendar()
    ic = Indian_Calendar()
    df = ic.get_festival(df, 'date_column_name')

**Module Name (PyPI)**:
    smart-aj (planned)

**Author**:
    Ajay Sah
"""
try:
    from skyfield.api import load, Topos
    from skyfield import almanac
    import pandas as pd
    from datetime import timedelta, datetime
    import pytz


    class Indian_Calendar:

        # ─────────────────────────────────────────────────────────────────────────
        # SECTION 1 — ASTRONOMY BOOTSTRAP  (lazy, runs once)
        # ─────────────────────────────────────────────────────────────────────────

        def __initialize_astronomy(self):
            """Load skyfield ephemeris and observers once; reuse across calls."""
            if hasattr(self, '_EPH'):
                return
            self._EPH   = load('de421.bsp')
            self._SUN   = self._EPH['sun']
            self._MOON  = self._EPH['moon']
            self._EARTH = self._EPH['earth']
            self._TS    = load.timescale()
            self._DELHI = Topos('28.6139 N', '77.2090 E', elevation_m=213)
            self._IST   = pytz.timezone('Asia/Kolkata')

        # ─────────────────────────────────────────────────────────────────────────
        # SECTION 2 — HINDU PANCHANG CORE
        # ─────────────────────────────────────────────────────────────────────────

        def __get_nirayana_lon(self, target, time_obj):
            """
            Nirayana (sidereal) longitude using Lahiri ayanamsha.
            Moved out of nested scope so it's a proper reusable method.
            """
            T        = (time_obj.tt - 2451545.0) / 36525
            ayanamsha = (84404.78 + 5028.7965 * T + 1.111 * T**2) / 3600.0
            astrometric = self._EARTH.at(time_obj).observe(target)
            _, lon, _ = astrometric.ecliptic_latlon()
            return (lon.degrees - ayanamsha) % 360

        def __get_accurate_panchang(self, year, month, day, hour, minute, purnimanta):
            self.__initialize_astronomy()

            # Convert IST to UTC
            t = self._TS.utc(year, month, day, hour - 5, minute - 30)

            sun_nir  = self.__get_nirayana_lon(self._SUN,  t)
            moon_nir = self.__get_nirayana_lon(self._MOON, t)

            # ── Nakshatra ──────────────────────────────────────────────────────
            _nakshatras = [
                'Ashwini', 'Bharani', 'Krittika', 'Rohini', 'Mrigashira',
                'Ardra', 'Punarvasu', 'Pushya', 'Ashlesha', 'Magha',
                'Purva_Phalguni', 'Uttara_Phalguni', 'Hasta', 'Chitra',
                'Swati', 'Vishakha', 'Anuradha', 'Jyeshta', 'Mula',
                'Purva_Ashadha', 'Uttara_Ashadha', 'Shravan',
                'Dhanishta', 'Shatabhisha', 'Purva_Bhadrapada',
                'Uttara_Bhadrapada', 'Revati'
            ]
            nakshatra = _nakshatras[int(moon_nir / (360 / 27))]

            # ── Maas (Month) — based on Sun longitude at last Amavasya ─────────
            t_start = self._TS.utc(year, month, day - 45)
            f       = almanac.moon_phases(self._EPH)
            times, phases = almanac.find_discrete(t_start, t, f)

            last_nm_t  = times[phases == 0][-1]          # last new moon
            sun_at_nm  = self.__get_nirayana_lon(self._SUN, last_nm_t)

            _hindu_months = [
                "Chaitra", "Vaishakha", "Jyeshtha", "Ashadha",
                "Shravana", "Bhadrapada", "Ashvina", "Kartika",
                "Margashirsha", "Pausha", "Magha", "Phalguna"
            ]
            amanta_idx = (int(sun_at_nm / 30) + 1) % 12

            # ── Tithi & Paksha ─────────────────────────────────────────────────
            diff     = (moon_nir - sun_nir) % 360
            tithi_no = int(diff / 12) + 1
            paksha   = "Shukla" if diff < 180 else "Krishna"

            # Purnimanta correction: Krishna paksha belongs to next month
            if purnimanta and paksha == "Krishna":
                final_maas = _hindu_months[(amanta_idx + 1) % 12]
            else:
                final_maas = _hindu_months[amanta_idx]

            # ── Rashi ──────────────────────────────────────────────────────────
            _rashis = [
                'Mesh', 'Vrishabh', 'Mithun', 'Kark',
                'Sinha', 'Kanya', 'Tula', 'Vrishchik',
                'Dhanu', 'Makar', 'Kumbh', 'Meen'
            ]
            sun_rashi  = _rashis[int(sun_nir  / 30)]
            moon_rashi = _rashis[int(moon_nir / 30)]

            return {
                "date"         : f"{day}-{month}-{year} {hour}:{minute}",
                "method"       : "Purnimanta (North India)" if purnimanta else "Amanta (South/West)",
                "maas"         : final_maas,
                "paksha"       : paksha,
                "tithi"        : tithi_no if tithi_no <= 15 else tithi_no - 15,
                "nakshatra"    : nakshatra,
                "sun_rashi"    : sun_rashi,
                "moon_rashi"   : moon_rashi,
                "last_amavasya": last_nm_t,
            }

        # ─────────────────────────────────────────────────────────────────────────
        # SECTION 3 — HINDU FESTIVALS
        # ─────────────────────────────────────────────────────────────────────────

        def __get_festivals(self, result: dict) -> str | None:
            maas      = result['maas']
            paksha    = result['paksha']
            tithi     = result['tithi']     # int
            nakshatra = result['nakshatra']

            # IMPORTANT: All month names must exactly match _hindu_months list above.
            # Previous bugs were: 'Shravan', 'Bhadrapapda', 'Ashwina' — all fixed below.
            _festivals = {
                # ── Chaitra ───────────────────────────────────────────────────
                ('Chaitra',      'Shukla',  1):  'Hindu_Nav_Varsh/Gudi_Padwa/Ugadi',
                ('Chaitra',      'Shukla',  9):  'Shree_Ram_Navami',
                ('Chaitra',      'Shukla', 15):  'Shree_Hanuman_Janmotsav',
                # ── Vaishakha ─────────────────────────────────────────────────
                ('Vaishakha',    'Shukla',  3):  'Akshaya_Tritiya',
                ('Vaishakha',    'Shukla', 15):  'Buddha_Purnima',
                # ── Ashadha ───────────────────────────────────────────────────
                ('Ashadha',      'Shukla', 11):  'Devshayani_Ekadashi',
                ('Ashadha',      'Shukla', 15):  'Guru_Purnima',
                # ── Shravana  (was 'Shravan' — TYPO FIXED) ────────────────────
                ('Shravana',     'Krishna', 8):  'Shree_Krishna_Janmashtami',
                ('Shravana',     'Shukla', 15):  'Raksha_Bandhan',
                # ── Bhadrapada (was 'Bhadrapapda' — TYPO FIXED) ───────────────
                ('Bhadrapada',   'Shukla',  4):  'Ganesh_Chaturthi',
                ('Bhadrapada',   'Krishna', 8):  'Shree_Radha_Ashtami',
                # ── Ashvina   (was 'Ashwina' — TYPO FIXED) ────────────────────
                ('Ashvina',      'Shukla',  1):  'Navratri_Start',
                ('Ashvina',      'Shukla',  8):  'Durga_Ashtami',
                ('Ashvina',      'Shukla',  9):  'Maha_Navami',
                ('Ashvina',      'Shukla', 10):  'Dassehra',
                # ── Kartika ───────────────────────────────────────────────────
                ('Kartika',      'Krishna', 13): 'Dhanteras',
                ('Kartika',      'Krishna', 14): 'Narak_Chaturdashi',
                ('Kartika',      'Krishna', 15): 'Dipawali',
                ('Kartika',      'Shukla',   1): 'Gowardhan_Pooja',
                ('Kartika',      'Shukla',   2): 'Bhai_Dooj',
                ('Kartika',      'Shukla',   6): 'Chhath_Pooja',
                # ── Margashirsha ──────────────────────────────────────────────
                ('Margashirsha', 'Shukla',  11): 'Mokshada_Ekadashi',
                # ── Pausha ────────────────────────────────────────────────────
                ('Pausha',       'Shukla',  15): 'Pausha_Purnima',
                # ── Magha ─────────────────────────────────────────────────────
                ('Magha',        'Shukla',   5): 'Basant_Panchami/Saraswati_Pooja',
                ('Magha',        'Krishna', 14): 'Maha_Shiv_Ratri',
                # ── Phalguna ──────────────────────────────────────────────────
                ('Phalguna',     'Shukla',  14): 'Holika_Dahan',
                ('Phalguna',     'Shukla',  15): 'Holi',
            }

            festival = _festivals.get((maas, paksha, tithi))

            # Janmashtami special rule: Rohini nakshatra override
            # BUG FIX: original had  tithi == 'Krishna_Ashtami'  (string vs int → always False)
            if maas == 'Shravana' and paksha == 'Krishna' and tithi == 8 and nakshatra == 'Rohini':
                festival = 'Shree_Krishna_Janmashtami'

            return festival

        # ─────────────────────────────────────────────────────────────────────────
        # SECTION 4 — ISLAMIC / HIJRI CALENDAR
        # ─────────────────────────────────────────────────────────────────────────

        def __get_sunset(self, g_date):
            """Return Skyfield Time of sunset for Delhi on the given Gregorian date."""
            self.__initialize_astronomy()
            t0 = self._TS.from_datetime(
                self._IST.localize(datetime.combine(g_date, datetime.min.time()))
            )
            t1 = self._TS.from_datetime(
                self._IST.localize(datetime.combine(g_date, datetime.max.time()))
            )
            f = almanac.sunrise_sunset(self._EPH, self._DELHI)
            times, events = almanac.find_discrete(t0, t1, f)
            for t, event in zip(times, events):
                if event == 0:   # 0 = sunset in Skyfield
                    return t
            return None

        def __get_hijri_date(self, dt_obj):
            """
            Convert a Gregorian datetime to Hijri (y, m, d) using the
            Fliegel-Van Flandern algorithm.

            BUG FIX: original had  jd = toordinal() + 1721424.5 - 1
            The '- 1' shifted every Hijri date 1 day earlier, causing
            Islamic festival lookups to miss by one day.
            Correct formula: jd = toordinal() + 1721424.5
            """
            self.__initialize_astronomy()

            if not isinstance(dt_obj, datetime):
                dt_obj = datetime.combine(dt_obj, datetime.min.time())
            if dt_obj.tzinfo is None:
                dt_obj = self._IST.localize(dt_obj)

            g_date   = dt_obj.date()
            t_sunset = self.__get_sunset(g_date)

            # Islamic day starts at sunset — if past sunset, use tomorrow's date
            working_date = g_date
            if t_sunset is not None:              # safe check
                sunset_ist = t_sunset.utc_datetime().replace(tzinfo=pytz.utc).astimezone(self._IST)
                if dt_obj > sunset_ist:
                    working_date = g_date + timedelta(days=1)

            # ── Gregorian → Julian Day Number (FIXED: no spurious -1) ─────────
            jd = working_date.toordinal() + 1721424.5 

            # ── Julian Day → Hijri (Fliegel-Van Flandern) ─────────────────────
            l = int(jd - 1948440 + 10632)
            n = int((l - 1) / 10631)
            l = l - 10631 * n + 354
            j = (  int((10985 - l) / 5316) * int((50 * l) / 17719)
                + int(l / 5670)           * int((43 * l) / 15238)  )
            l = (  l
                - int((30 - j) / 15) * int((17719 * j) / 50)
                - int(j / 16)        * int((15238 * j) / 43)
                + 29  )
            m = int((24 * l) / 709)
            d = l - int((709 * m) / 24)
            y = 30 * n + j - 30

            return y, m, d

        def __get_islamic_festival(self, year, month, day, hour, minute):
            dt_obj      = datetime(year, month, day, hour, minute)
            _, h_m, h_d = self.__get_hijri_date(dt_obj)

            _islamic_festivals = {
                (1,  1):  "Muharram",
                (1,  10): "Day_of_Ashura",
                (3,  12): "Eid_Milad_un_Nabi",
                (7,  27): "Shab_e_Miraj",
                (8,  15): "Shab_e_Barat",
                (9,  1):  "Ramadan_Start",
                (9,  27): "Shab_e_Qadr",
                (10, 1):  "Eid_ul_Fitr",
                (12, 9):  "Arafah",
                (12, 10): "Bakrid",
            }
            return _islamic_festivals.get((h_m, h_d), None)

        # ─────────────────────────────────────────────────────────────────────────
        # SECTION 5 — FIXED NATIONAL / INTERNATIONAL HOLIDAYS
        # ─────────────────────────────────────────────────────────────────────────

        _FIXED_HOLIDAYS = {
            # January
            (1,  1):  'New_Year',
            (1,  12): 'National_Youth_Day',
            (1,  15): 'Indian_Army_Day',
            (1,  23): 'Netaji_Subhash_Chandra_Bose_Jayanti',
            (1,  26): 'Republic_Day',
            (1,  30): 'Martyrs_Day',
            # February
            (2,  14): 'Valentines_Day/Black_Day',
            (2,  28): 'National_Science_Day',
            # March
            (3,  8):  'International_Womens_Day',
            (3,  23): 'Shaheed_Diwas_Veer_Bhagat_Singh',
            # April
            (4,  1):  'April_Fool_Day',
            (4,  7):  'World_Health_Day',
            (4,  17): 'Baba_Shaheb_Ambedkar_Jayanti',
            (4,  22): 'Earth_Day',
            # May
            (5,  1):  'Labour_Day',
            (5,  8):  'World_Red_Cross_Day',
            (5,  11): 'National_Technology_Day',
            (5,  21): 'Anti_Terrorism_Day',
            (5,  31): 'No_Tobacco_Day',
            # June
            (6,  5):  'World_Environment_Day',
            (6,  21): 'International_Yoga_Day',
            # July
            (7,  1):  'Doctors_Day',
            (7,  26): 'Kargil_Vijay_Diwas',
            # August
            (8,  15): 'Independence_Day',
            (8,  29): 'National_Sports_Day',
            # September
            (9,  5):  'Teachers_Day',
            (9,  14): 'Hindi_Diwas',
            # October
            (10, 2):  'Mahatma_Gandhi_Jayanti',
            (10, 8):  'Indian_Air_Force_Day',
            (10, 31): 'National_Unit_Day',
            # November
            (11, 14): 'Childrens_Day',
            (11, 26): 'Constitution_Day',
            # December
            (12, 4):  'Indian_Navy_Day',
            (12, 25): 'Christmas',
        }

        # ─────────────────────────────────────────────────────────────────────────
        # SECTION 6 — COMBINED FESTIVAL + HOLIDAY RESOLVER
        # ─────────────────────────────────────────────────────────────────────────

        def __get_festival_holiday(self, year, month, day, hour, minute, purnimanta):
            panchang     = self.__get_accurate_panchang(year, month, day, hour, minute, purnimanta)
            hindu_fest   = self.__get_festivals(panchang)
            islamic_fest = self.__get_islamic_festival(year, month, day, hour, minute)
            fixed_hol    = self._FIXED_HOLIDAYS.get((month, day))

            # Merge all non-None values with "/"
            parts = [f for f in [hindu_fest, islamic_fest, fixed_hol] if f]
            return "/".join(parts) if parts else None

        # ─────────────────────────────────────────────────────────────────────────
        # SECTION 7 — PUBLIC API
        # ─────────────────────────────────────────────────────────────────────────

        def get_festival(self, df: pd.DataFrame, date_col_name: str) -> pd.DataFrame:
            df[date_col_name] = pd.to_datetime(
                df[date_col_name], dayfirst=False, format="mixed", errors='coerce'
            )
            # If time is midnight (00:00), assume midday for accurate panchang
            df[date_col_name] = df[date_col_name].apply(
                lambda x: x.replace(hour=12) if pd.notna(x) and x.hour == 0 else x
            )
            df['festival'] = df[date_col_name].apply(
                lambda date: self.__get_festival_holiday(
                    date.year, date.month, date.day,
                    date.hour, date.minute,
                    purnimanta=True          # North India (Purnimanta) system
                ) if pd.notna(date) else None
            )
            return df

except Exception as e:
    print(f"Unexpected Error: {e}\nTry this format: YYYY-mm-dd HH:MM !")
# =============================================================================
#  QUICK TEST
# =============================================================================
# if __name__ == "__main__":
    # df = pd.DataFrame({
    #     "date": [
    #         '2026-01-26',            # Republic Day
    #         '2026-05-01 10:30:00',   # Labour Day
    #         '15-08-2026',            # Independence Day
    #         '2026/10/02',            # Gandhi Jayanti
    #         '2026-12-25 00:00:00',   # Christmas
    #         None,                    # NaT → None
    #         'invalid_date',          # coerce → None
    #         '2026-11-12',            # ?
    #         '2026-04-01 18:45',      # April Fool
    #         '2026-03-08',            # Women's Day
    #         '2026-07-26 05:00:00',   # Kargil Vijay Diwas
    #         '2026-09-05',            # Teachers Day
    #         '2026-02-17',            # Ramadan Start (Hijri 9/1/1447)
    #         '25-02-2026',            # Ramadan 7
    #         '10-03-2026',            # Ramadan 20
    #         '19-03-2026',            # Ramadan 29
    #         '20-03-2026',            # Ramadan 30
    #         '27-05-2026',            # Bakrid (Hijri 12/10/1447)
    #         '2026-02-04',            # Shab-e-Barat (Hijri 8/15/1447)
    #         '2026-03-20 19:20',

    #         '2026-03-01',
    #         '14-03-2025',
    #         '2025-03-01 19:20',
    #         '2025-09-05 20:03',
    #         '02-08-2027 23:21',
    #         '06-03-2027',
    #         '22-03-2027',
    #         '17-03-2027 19:20',
    #         '25-08-2027',
    #         '29-10-2027'
    #     ]
    # })
    # df = pd.read_csv(r"C:\Users\RAMAN KUMAR\OneDrive\Desktop\Ajay\AI_COURSE\Z\TCS-realWorld-DataAnanlysis.csv")

    # print("── Input ──────────────────────────────────")
    # print(df)

    # hc = Indian_Calendar()
    # result_df = hc.get_festival(df, 'Date')

    # print("\n── Output ─────────────────────────────────")
    # result_df.to_csv("TCS_Festivals.csv", index=False)