# Smart-AJ Calendar Engine

Astronomical-based Hindu Panchang + Islamic Hijri + National Holidays detection engine.

## Usage

'''python
from smart import Indian_Calendar

ic = Indian_Calendar()
df = ic.get_festival(df, date_col_name)

### Installation
'''bash
pip install smart-aj