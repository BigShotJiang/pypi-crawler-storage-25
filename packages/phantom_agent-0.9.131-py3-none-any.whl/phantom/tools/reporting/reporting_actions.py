import contextlib
import re
from pathlib import PurePosixPath
from typing import Any

from phantom.tools.registry import register_tool


_CVSS_FIELDS = (
    "attack_vector",
    "attack_complexity",
    "privileges_required",
    "user_interaction",
    "scope",
    "confidentiality",
    "integrity",
    "availability",
)


_background_tasks: set[Any] = set()

_TITLE_ATTEMPT_COUNTS: dict[str, int] = {}

_MAX_ATTEMPTS_PER_TITLE = 3


def parse_cvss_xml(xml_str: str) -> dict[str, str] | None:
    """Parse CVSS breakdown from XML tags or plain CVSS vector string.

    Accepts both XML format and plain CVSS vector strings like
    'AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H' for more forgiving input.
    """
    if not xml_str or not xml_str.strip():
        return None
    result = {}
    # Try XML format first
    for field in _CVSS_FIELDS:
        match = re.search(rf"<{field}>(.*?)</{field}>", xml_str, re.DOTALL)
        if match:
            result[field] = match.group(1).strip()
    if result:
        return result

    # Fallback - try plain CVSS vector string (AV:N/AC:L/...)
    _vector_map = {
        "AV": "attack_vector",
        "AC": "attack_complexity",
        "PR": "privileges_required",
        "UI": "user_interaction",
        "S": "scope",
        "C": "confidentiality",
        "I": "integrity",
        "A": "availability",
    }
    # Strip "CVSS:3.1/" prefix if present
    clean = re.sub(r"^CVSS:[\d.]+/", "", xml_str.strip())
    for part in clean.split("/"):
        if ":" in part:
            key, val = part.split(":", 1)
            field_name = _vector_map.get(key.strip().upper())
            if field_name:
                result[field_name] = val.strip().upper()
    return result if result else None


_SEVERITY_CVSS_DEFAULTS: dict[str, dict[str, str]] = {
    "CRITICAL": {
        "attack_vector": "N",
        "attack_complexity": "L",
        "privileges_required": "N",
        "user_interaction": "N",
        "scope": "U",
        "confidentiality": "H",
        "integrity": "H",
        "availability": "H",
    },
    "HIGH": {
        "attack_vector": "N",
        "attack_complexity": "L",
        "privileges_required": "N",
        "user_interaction": "N",
        "scope": "U",
        "confidentiality": "H",
        "integrity": "H",
        "availability": "N",
    },
    "MEDIUM": {
        "attack_vector": "N",
        "attack_complexity": "L",
        "privileges_required": "N",
        "user_interaction": "N",
        "scope": "U",
        "confidentiality": "L",
        "integrity": "L",
        "availability": "N",
    },
    "LOW": {
        "attack_vector": "N",
        "attack_complexity": "H",
        "privileges_required": "N",
        "user_interaction": "N",
        "scope": "U",
        "confidentiality": "L",
        "integrity": "N",
        "availability": "N",
    },
    "INFO": {
        "attack_vector": "N",
        "attack_complexity": "H",
        "privileges_required": "N",
        "user_interaction": "N",
        "scope": "U",
        "confidentiality": "N",
        "integrity": "N",
        "availability": "N",
    },
}


def _cvss_from_severity(severity: str | None) -> dict[str, str] | None:
    if not severity:
        return None
    return _SEVERITY_CVSS_DEFAULTS.get(severity.upper().strip())


def parse_code_locations_xml(xml_str: str) -> list[dict[str, Any]] | None:
    if not xml_str or not xml_str.strip():
        return None
    locations = []
    for loc_match in re.finditer(r"<location>(.*?)</location>", xml_str, re.DOTALL):
        loc: dict[str, Any] = {}
        loc_content = loc_match.group(1)
        for field in (
            "file",
            "start_line",
            "end_line",
            "snippet",
            "label",
            "fix_before",
            "fix_after",
        ):
            field_match = re.search(rf"<{field}>(.*?)</{field}>", loc_content, re.DOTALL)
            if field_match:
                raw = field_match.group(1)
                value = (
                    raw.strip("\n")
                    if field in ("snippet", "fix_before", "fix_after")
                    else raw.strip()
                )
                if field in ("start_line", "end_line"):
                    with contextlib.suppress(ValueError, TypeError):
                        loc[field] = int(value)
                elif value:
                    loc[field] = value
        if loc.get("file") and loc.get("start_line") is not None:
            locations.append(loc)
    return locations if locations else None


def _validate_file_path(path: str) -> str | None:
    if not path or not path.strip():
        return "file path cannot be empty"
    p = PurePosixPath(path)
    if p.is_absolute():
        return f"file path must be relative, got absolute: '{path}'"
    if ".." in p.parts:
        return f"file path must not contain '..': '{path}'"
    return None


def _validate_code_locations(locations: list[dict[str, Any]]) -> list[str]:
    errors = []
    for i, loc in enumerate(locations):
        path_err = _validate_file_path(loc.get("file", ""))
        if path_err:
            errors.append(f"code_locations[{i}]: {path_err}")
        start = loc.get("start_line")
        if not isinstance(start, int) or start < 1:
            errors.append(f"code_locations[{i}]: start_line must be a positive integer")
        end = loc.get("end_line")
        if end is None:
            errors.append(f"code_locations[{i}]: end_line is required")
        elif not isinstance(end, int) or end < 1:
            errors.append(f"code_locations[{i}]: end_line must be a positive integer")
        elif isinstance(start, int) and end < start:
            errors.append(f"code_locations[{i}]: end_line ({end}) must be >= start_line ({start})")
    return errors


def _extract_cve(cve: str) -> str:
    match = re.search(r"CVE-\d{4}-\d{4,}", cve)
    return match.group(0) if match else cve.strip()


def _validate_cve(cve: str) -> str | None:
    if not re.match(r"^CVE-\d{4}-\d{4,}$", cve):
        return f"invalid CVE format: '{cve}' (expected 'CVE-YYYY-NNNNN')"
    return None


def _extract_cwe(cwe: str) -> str:
    match = re.search(r"CWE-\d+", cwe)
    return match.group(0) if match else cwe.strip()


def _validate_cwe(cwe: str) -> str | None:
    if not re.match(r"^CWE-\d+$", cwe):
        return f"invalid CWE format: '{cwe}' (expected 'CWE-NNN')"
    return None


def calculate_cvss_and_severity(
    attack_vector: str,
    attack_complexity: str,
    privileges_required: str,
    user_interaction: str,
    scope: str,
    confidentiality: str,
    integrity: str,
    availability: str,
) -> tuple[float, str, str]:
    try:
        from cvss import CVSS3

        vector = (
            f"CVSS:3.1/AV:{attack_vector}/AC:{attack_complexity}/"
            f"PR:{privileges_required}/UI:{user_interaction}/S:{scope}/"
            f"C:{confidentiality}/I:{integrity}/A:{availability}"
        )

        c = CVSS3(vector)
        scores = c.scores()
        severities = c.severities()

        base_score = scores[0]
        base_severity = severities[0]

        severity = base_severity.lower()

    except Exception:
        import logging

        logging.exception("Failed to calculate CVSS")
        return 7.5, "high", ""
    else:
        return base_score, severity, vector


def _validate_required_fields(**kwargs: str | None) -> list[str]:
    validation_errors: list[str] = []

    confidence = (kwargs.get("confidence") or "LIKELY").upper().strip()
    required_fields = {
        "title": "Title cannot be empty",
        "description": "Description cannot be empty",
        "impact": "Impact cannot be empty",
        "target": "Target cannot be empty",
        "technical_analysis": "Technical analysis cannot be empty",
    }
    if confidence != "SUSPECTED":
        required_fields["poc_script_code"] = "PoC script/code is REQUIRED for LIKELY/VERIFIED confidence - provide the actual exploit/payload, or change confidence to SUSPECTED"

    for field_name, error_msg in required_fields.items():
        value = kwargs.get(field_name)
        if not value or not str(value).strip():
            validation_errors.append(error_msg)

    return validation_errors


def _validate_cvss_parameters(**kwargs: str) -> list[str]:
    validation_errors: list[str] = []

    cvss_validations = {
        "attack_vector": ["N", "A", "L", "P"],
        "attack_complexity": ["L", "H"],
        "privileges_required": ["N", "L", "H"],
        "user_interaction": ["N", "R"],
        "scope": ["U", "C"],
        "confidentiality": ["N", "L", "H"],
        "integrity": ["N", "L", "H"],
        "availability": ["N", "L", "H"],
    }

    for param_name, valid_values in cvss_validations.items():
        value = kwargs.get(param_name)
        if value not in valid_values:
            validation_errors.append(
                f"Invalid {param_name}: {value}. Must be one of: {valid_values}"
            )

    return validation_errors


def _normalize_variant_field(value: str | None) -> str:
    return (value or "").strip().lower()


def _same_variant_surface(candidate: dict[str, Any], existing: dict[str, Any]) -> bool:
    endpoint_a = _normalize_variant_field(candidate.get("endpoint"))
    endpoint_b = _normalize_variant_field(existing.get("endpoint"))
    method_a = _normalize_variant_field(candidate.get("method"))
    method_b = _normalize_variant_field(existing.get("method"))
    param_a = _normalize_variant_field(candidate.get("parameter"))
    param_b = _normalize_variant_field(existing.get("parameter"))
    target_a = _normalize_variant_field(candidate.get("target"))
    target_b = _normalize_variant_field(existing.get("target"))

    if endpoint_a and endpoint_b and method_a and method_b:
        if param_a and param_b:
            return endpoint_a == endpoint_b and method_a == method_b and param_a == param_b
        return endpoint_a == endpoint_b and method_a == method_b

    if endpoint_a and endpoint_b:
        return endpoint_a == endpoint_b

    if target_a and target_b:
        return target_a == target_b

    return False


@register_tool(sandbox_execution=False)
def create_vulnerability_report(  # noqa: PLR0912
    title: str,
    description: str,
    impact: str,
    target: str,
    technical_analysis: str,
    poc_description: str | None = None,
    poc_script_code: str | None = None,
    remediation_steps: str | None = None,
    cvss_breakdown: str | None = None,
    endpoint: str | None = None,
    method: str | None = None,
    parameter: str | None = None,
    cve: str | None = None,
    cwe: str | None = None,
    code_locations: str | None = None,
    severity: str | None = None,
    # Confidence tier: VERIFIED/PoC auto-replayed, LIKELY/validated (default), SUSPECTED/discovery signal
    confidence: str = "LIKELY",
) -> dict[str, Any]:
    # Fill in defaults for optional fields
    if not poc_description:
        poc_description = description
    if not remediation_steps:
        remediation_steps = "See impact and technical analysis for remediation guidance."
    if not poc_script_code:
        poc_script_code = ""
    if not cvss_breakdown:
        cvss_breakdown = ""
    # A5: Pass confidence to _validate_required_fields so it can relax poc_script_code
    validation_errors = _validate_required_fields(
        title=title,
        description=description,
        impact=impact,
        target=target,
        technical_analysis=technical_analysis,
        poc_description=poc_description,
        poc_script_code=poc_script_code,
        remediation_steps=remediation_steps,
        confidence=confidence,
    )

    parsed_cvss = parse_cvss_xml(cvss_breakdown)
    if not parsed_cvss:
        # Try severity-based auto-calculation
        parsed_cvss = _cvss_from_severity(severity)
        if not parsed_cvss:
            # Fallback default for SUSPECTED confidence
            if (confidence or "LIKELY").upper().strip() == "SUSPECTED":
                parsed_cvss = _cvss_from_severity("LOW")
            if not parsed_cvss:
                validation_errors.append("cvss: could not parse CVSS breakdown XML or vector string (provide cvss_breakdown XML or set severity=CRITICAL/HIGH/MEDIUM/LOW/INFO)")
    else:
        validation_errors.extend(_validate_cvss_parameters(**parsed_cvss))

    parsed_locations = parse_code_locations_xml(code_locations) if code_locations else None

    if parsed_locations:
        validation_errors.extend(_validate_code_locations(parsed_locations))
    if cve:
        cve = _extract_cve(cve)
        cve_err = _validate_cve(cve)
        if cve_err:
            validation_errors.append(cve_err)
    if cwe:
        cwe = _extract_cwe(cwe)
        cwe_err = _validate_cwe(cwe)
        if cwe_err:
            validation_errors.append(cwe_err)

    if validation_errors:
        # Track failed attempts so the agent knows not to retry endlessly
        title_key = title.strip().lower()
        _TITLE_ATTEMPT_COUNTS[title_key] = _TITLE_ATTEMPT_COUNTS.get(title_key, 0) + 1
        attempt_count = _TITLE_ATTEMPT_COUNTS[title_key]
        if attempt_count >= _MAX_ATTEMPTS_PER_TITLE:
            return {
                "success": False,
                "message": (
                    f"Validation failed ({attempt_count} attempts). "
                    f"Stop retrying — fix the errors below or change confidence to SUSPECTED "
                    f"to skip optional fields like cvss_breakdown and poc_script_code."
                ),
                "errors": validation_errors,
                "attempt_count": attempt_count,
            }
        return {
            "success": False,
            "message": "Validation failed",
            "errors": validation_errors,
            "attempt_count": attempt_count,
        }

    # Rec 10 (ER-001): Validate and normalise confidence tier.
    _VALID_CONFIDENCE = ("VERIFIED", "LIKELY", "SUSPECTED")
    confidence = (confidence or "LIKELY").upper().strip()
    if confidence not in _VALID_CONFIDENCE:
        confidence = "LIKELY"  # safe fallback

    _VALID_REPLAY_STATUS = {"PENDING", "SKIPPED", "PASSED", "FAILED"}

    # Rec 5 (ER-005): PoC auto-replay — execute poc_script_code in the sandbox
    # before writing the report.  If replay succeeds, upgrade confidence to
    # VERIFIED.  If it fails, keep user-supplied confidence but tag the report.
    # Rec 5 / P1.2: PoC auto-replay — schedule as a background async task.
    # The reporting tool is ALWAYS called from within the agent's running event
    # loop, so run_until_complete() can never work.  Instead we schedule a
    # background coroutine that updates replay_status on the tracer once done.
    replay_status = "PENDING"
    if poc_script_code and poc_script_code.strip():
        import asyncio

        async def _background_replay(
            _poc_code: str, _report_title: str, _confidence: str
        ) -> None:
            """Run PoC in sandbox and update the tracer with the result."""
            _replay = "SKIPPED"
            try:
                from phantom.tools.executor import execute_tool

                replay_result = await execute_tool(
                    "terminal_execute", command=_poc_code, timeout=60,
                )
                replay_out = str(replay_result or "")
                # Only treat as FAILED on execution-failure signals or empty output.
                # Generic words like "error"/"fail" appear in legitimate exploit output
                # (e.g. "SQL error", "authentication failed") and must NOT be matched.
                _exec_failure_patterns = (
                    "command not found",
                    "no such file or directory",
                    "traceback (most recent call last)",
                    "importerror:",
                    "modulenotfounderror:",
                    "segmentation fault",
                    "killed",
                )
                if not replay_out.strip():
                    _replay = "FAILED"
                elif any(p in replay_out.lower() for p in _exec_failure_patterns):
                    _replay = "FAILED"
                else:
                    _replay = "PASSED"
            except Exception:  # noqa: BLE001
                _replay = "FAILED"

            # Update the vulnerability report telemetry with replay outcome
            try:
                from phantom.telemetry.tracer import get_global_tracer
                _tracer = get_global_tracer()
                if _tracer and hasattr(_tracer, "update_vulnerability_replay"):
                    _tracer.update_vulnerability_replay(
                        title=_report_title,
                        replay_status=_replay,
                        confidence="VERIFIED" if _replay == "PASSED" else _confidence,
                    )
            except Exception:  # noqa: BLE001
                pass

        try:
            loop = asyncio.get_running_loop()
            # Schedule non-blocking — does NOT block report creation
            task = loop.create_task(_background_replay(poc_script_code, title, confidence))
            _background_tasks.add(task)
            task.add_done_callback(lambda finished: _background_tasks.discard(finished))
            replay_status = "PENDING"  # will be updated async
        except RuntimeError:
            replay_status = "SKIPPED"
    else:
        replay_status = "SKIPPED"

    if replay_status not in _VALID_REPLAY_STATUS:
        replay_status = "SKIPPED"

    assert parsed_cvss is not None
    cvss_score, cvss_severity, cvss_vector = calculate_cvss_and_severity(**parsed_cvss)

    try:
        from phantom.telemetry.tracer import get_global_tracer

        tracer = get_global_tracer()
        if not tracer:
            return {
                "success": False,
                "message": f"Vulnerability report '{title}' was not persisted",
                "error": "Tracer unavailable - report storage failed",
            }

        from phantom.llm.dedupe import check_duplicate

        existing_reports = tracer.get_existing_vulnerabilities()

        if not parameter and endpoint:
            from urllib.parse import urlparse, parse_qs

            ep = endpoint.strip()
            if "?" in ep:
                qs = parse_qs(ep.split("?", 1)[1])
                if qs:
                    parameter = list(qs.keys())[0]

        candidate = {
            "title": title,
            "description": description,
            "impact": impact,
            "target": target,
            "technical_analysis": technical_analysis,
            "poc_description": poc_description,
            "poc_script_code": poc_script_code,
            "endpoint": endpoint,
            "method": method,
            "parameter": parameter or "",
        }

        dedupe_result = check_duplicate(candidate, existing_reports)

        if dedupe_result.get("is_duplicate"):
            duplicate_id = dedupe_result.get("duplicate_id", "")
            dedupe_confidence = float(dedupe_result.get("confidence") or 0.0)

            # Keep high precision: only hard-block if the model is confident
            # and the duplicate is on the same concrete surface.
            duplicate_report = None
            for report in existing_reports:
                if report.get("id") == duplicate_id:
                    duplicate_report = report
                    break

            same_surface = bool(duplicate_report) and _same_variant_surface(
                candidate, duplicate_report or {}
            )

            if not duplicate_id or dedupe_confidence < 0.90 or not same_surface:
                duplicate_id = ""
            else:
                duplicate_title = (duplicate_report or {}).get("title", "Unknown")

                return {
                    "success": False,
                    "message": (
                        f"Potential duplicate of '{duplicate_title}' "
                        f"(id={duplicate_id[:8]}...). Do not re-report the same vulnerability."
                    ),
                    "duplicate_of": duplicate_id,
                    "duplicate_title": duplicate_title,
                    "confidence": dedupe_confidence,
                    "reason": dedupe_result.get("reason", ""),
                    "attempt_count": 0,
                }

        report_id = tracer.add_vulnerability_report(
            title=title,
            description=description,
            severity=cvss_severity,
            impact=impact,
            target=target,
            technical_analysis=technical_analysis,
            poc_description=poc_description,
            poc_script_code=poc_script_code,
            remediation_steps=remediation_steps,
            cvss=cvss_score,
            cvss_breakdown=parsed_cvss,
            endpoint=endpoint,
            method=method,
            parameter=parameter,
            cve=cve,
            cwe=cwe,
            code_locations=parsed_locations,
            confidence=confidence,
            replay_status=replay_status,
        )

        if not report_id:
            return {
                "success": False,
                "message": "Failed to persist vulnerability report: tracer returned empty report_id",
            }

        # Reset attempt counter on success
        title_key = title.strip().lower()
        _TITLE_ATTEMPT_COUNTS.pop(title_key, None)

        return {
            "success": True,
            "message": f"Vulnerability report '{title}' created successfully",
            "report_id": report_id,
            "severity": cvss_severity,
            "cvss_score": cvss_score,
            # Rec 10: surface confidence and replay status to callers
            "confidence": confidence,
            "replay_status": replay_status,
            "attempt_count": 0,
        }

    except (ImportError, AttributeError) as e:
        return {"success": False, "message": f"Failed to create vulnerability report: {e!s}"}
