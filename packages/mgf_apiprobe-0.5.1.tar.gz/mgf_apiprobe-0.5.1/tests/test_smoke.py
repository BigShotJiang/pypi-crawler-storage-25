"""Smoke test — package imports, version is set.

This stays as the floor that subsequent Phase 1 commits build on. Until
the public surface lands, this is the only test in the suite.
"""

from __future__ import annotations


def test_package_imports() -> None:
    import mgf.apiprobe

    assert hasattr(mgf.apiprobe, "__version__")


def test_version_format() -> None:
    """``__version__`` MUST match the version declared in pyproject.toml.

    Reads the declared version dynamically so the assertion doesn't
    drift on every release. Pattern mirrors mgf-common's
    `test_version_in_sync` pin.
    """
    import re
    from pathlib import Path

    from mgf.apiprobe import __version__

    pyproject = Path(__file__).resolve().parent.parent / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    match = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
    assert match is not None, "could not find version line in pyproject.toml"
    declared = match.group(1)
    assert __version__ == declared, (
        f"version drift: __version__={__version__!r} but "
        f"pyproject says {declared!r}"
    )
