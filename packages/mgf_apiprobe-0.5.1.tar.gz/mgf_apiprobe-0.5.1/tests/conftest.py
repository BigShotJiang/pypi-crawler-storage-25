"""Top-level test configuration for ``mgf-apiprobe``.

Phase 1 fixtures land here as the implementation progresses. For now
this file exists so pytest discovers the tests/ tree.
"""

from __future__ import annotations
