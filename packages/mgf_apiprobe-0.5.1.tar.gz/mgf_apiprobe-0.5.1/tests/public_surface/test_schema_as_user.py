"""User-perspective tests for ``mgf.apiprobe.schema``.

Surfaces exercised:
  - :class:`SchemaSource` Protocol — runtime-checkable.
  - :class:`PydanticSchemaSource` — the first concrete impl.
  - :class:`SchemaValidationIssue` — the result shape.
"""

from __future__ import annotations

from pydantic import BaseModel

from mgf.apiprobe.schema import (
    PydanticSchemaSource,
    SchemaSource,
    SchemaValidationIssue,
)


class _UserModel(BaseModel):
    id: str
    name: str


class TestPydanticSchemaSource:
    def test_construct_with_pydantic_model(self) -> None:
        source = PydanticSchemaSource(model=_UserModel)
        # Implements the Protocol.
        assert isinstance(source, SchemaSource)

    def test_validation_issue_shape(self) -> None:
        issue = SchemaValidationIssue(
            path="$.id",
            message="missing required field",
            expected="str",
            actual="(absent)",
        )
        assert issue.path == "$.id"
        assert issue.message == "missing required field"
        assert issue.expected == "str"
        assert issue.actual == "(absent)"

    def test_validation_issue_is_frozen(self) -> None:
        issue = SchemaValidationIssue(
            path="$.x", message="m", expected="e", actual="a",
        )
        # Frozen dataclass — direct mutation should raise.
        try:
            issue.path = "$.y"  # type: ignore[misc]
        except (AttributeError, TypeError):
            pass
        else:
            raise AssertionError("SchemaValidationIssue should be frozen")
