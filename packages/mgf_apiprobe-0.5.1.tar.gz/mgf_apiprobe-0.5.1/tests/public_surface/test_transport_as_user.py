"""User-perspective tests for ``mgf.apiprobe.transport``.

Surfaces exercised:
  - :class:`HttpxTransport` constructs (with and without settings).
  - Implements the :class:`Transport` Protocol from
    ``mgf.apiprobe.core``.

Network behavior is exercised via ``tests/integration/`` (real
httpbin) and ``tests/unit/transport/`` (respx-mocked); this file
just verifies the consumer-visible shape.
"""

from __future__ import annotations

from mgf.apiprobe.config import ApiprobeSettings
from mgf.apiprobe.core import Transport
from mgf.apiprobe.transport import HttpxTransport


class TestHttpxTransport:
    def test_construct_default(self) -> None:
        t = HttpxTransport()
        # Implements the Transport Protocol.
        assert isinstance(t, Transport)

    def test_construct_with_settings(self) -> None:
        s = ApiprobeSettings(timeout_seconds=5.0, max_concurrency=3)
        t = HttpxTransport(settings=s)
        assert isinstance(t, Transport)
