"""User-perspective tests for ``mgf.apiprobe.reporting``.

Surfaces exercised:
  - :class:`ReportWriter` Protocol — runtime-checkable.
  - :class:`HumanReportWriter` returns a string for an empty Report.
  - :class:`JsonReportWriter` returns a JSON-serialisable dict.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime

from mgf.apiprobe.core import Report
from mgf.apiprobe.reporting import (
    HumanReportWriter,
    JsonReportWriter,
    ReportWriter,
)


def _empty_report() -> Report:
    now = datetime.now(UTC)
    return Report(
        findings=(),
        started_at=now,
        finished_at=now,
        probe_count=0,
    )


class TestHumanReportWriter:
    def test_construct_and_protocol(self) -> None:
        w = HumanReportWriter()
        assert isinstance(w, ReportWriter)

    def test_write_empty_report_returns_string(self) -> None:
        w = HumanReportWriter()
        out = w.write(_empty_report())
        assert isinstance(out, str)
        assert len(out) > 0


class TestJsonReportWriter:
    def test_construct_and_protocol(self) -> None:
        w = JsonReportWriter()
        assert isinstance(w, ReportWriter)

    def test_write_empty_report_returns_json_serialisable_dict(self) -> None:
        w = JsonReportWriter()
        out = w.write(_empty_report())
        # Must be a dict that round-trips through json.
        assert isinstance(out, dict)
        encoded = json.dumps(out)
        assert json.loads(encoded) == out
