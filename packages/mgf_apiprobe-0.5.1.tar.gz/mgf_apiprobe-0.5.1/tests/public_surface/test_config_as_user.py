"""User-perspective tests for ``mgf.apiprobe.config``.

Surfaces exercised:
  - :class:`ApiprobeSettings` constructs with defaults.
  - Subclass of :class:`mgf.common.config.BaseAppSettings`.
  - Reads from environment under ``APIPROBE_*`` prefix.
"""

from __future__ import annotations

import pytest
from mgf.common.config import BaseAppSettings
from mgf.common.exceptions import AppConfigError

from mgf.apiprobe.config import ApiprobeSettings


class TestApiprobeSettings:
    def test_default_construct(self) -> None:
        s = ApiprobeSettings()
        # Sane defaults for transport
        assert s.timeout_seconds > 0
        assert s.max_retries >= 0
        assert s.verify_tls is True
        assert s.max_concurrency >= 1
        assert "apiprobe" in s.default_user_agent

    def test_subclass_of_base_app_settings(self) -> None:
        # Inherits the layered loader behaviour from mgf-common.
        assert issubclass(ApiprobeSettings, BaseAppSettings)

    def test_override_timeout(self) -> None:
        s = ApiprobeSettings(timeout_seconds=15.0)
        assert s.timeout_seconds == 15.0

    def test_env_prefix_override(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("APIPROBE_TIMEOUT_SECONDS", "42.5")
        s = ApiprobeSettings()
        assert s.timeout_seconds == 42.5

    def test_extra_keys_rejected(self) -> None:
        # AppConfigError wraps pydantic's ValidationError for friendly
        # error messages on misconfigured env vars.
        with pytest.raises(AppConfigError):
            ApiprobeSettings(unknown_field="x")  # type: ignore[call-arg]

    def test_validation_constraints(self) -> None:
        # max_retries bounded [0, 10]; max_concurrency bounded [1, 100].
        with pytest.raises(AppConfigError):
            ApiprobeSettings(max_retries=-1)
        with pytest.raises(AppConfigError):
            ApiprobeSettings(max_concurrency=0)
