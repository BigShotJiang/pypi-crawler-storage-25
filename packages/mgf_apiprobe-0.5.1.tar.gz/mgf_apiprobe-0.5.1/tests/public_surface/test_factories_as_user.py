"""User-perspective tests for ``mgf.apiprobe.factories``.

Surfaces exercised:
  - All five factory functions return strings of the right shape.
  - Round-trip determinism is NOT promised (factories are
    deliberately fresh each call).
"""

from __future__ import annotations

import re

from mgf.apiprobe.factories import e164, iban, imei, iso8601_z, uuid


class TestFactories:
    def test_uuid_canonical_form(self) -> None:
        v = uuid()
        assert isinstance(v, str)
        # 8-4-4-4-12 hex digits.
        assert re.match(
            r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
            v,
        )

    def test_uuid_is_fresh_per_call(self) -> None:
        a, b = uuid(), uuid()
        assert a != b

    def test_iso8601_z_default_now(self) -> None:
        v = iso8601_z()
        assert isinstance(v, str)
        assert v.endswith("Z")
        # ISO 8601: YYYY-MM-DDTHH:MM:SS(.ffff)Z
        assert re.match(
            r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$", v,
        )

    def test_iban_default_country(self) -> None:
        v = iban()
        assert isinstance(v, str)
        # Default country=DE → starts with "DE".
        assert v.startswith("DE")

    def test_iban_country_override(self) -> None:
        gb = iban(country="GB")
        assert gb.startswith("GB")

    def test_imei_15_digits(self) -> None:
        v = imei()
        assert isinstance(v, str)
        assert len(v) == 15
        assert v.isdigit()

    def test_e164_starts_with_plus_and_country_code(self) -> None:
        v = e164(country_code=44, length=10)
        assert isinstance(v, str)
        assert v.startswith("+44")
        # +<cc><10 digits> → length is 1 (plus) + len(cc) + 10
        assert len(v) == 1 + len("44") + 10
