"""Tests for ``mgf.apiprobe.config``."""

from __future__ import annotations

import pytest

from mgf.apiprobe.config import ApiprobeSettings


class TestApiprobeSettings:
    def test_defaults(self) -> None:
        s = ApiprobeSettings()
        assert s.timeout_seconds == 30.0
        assert s.max_retries == 0
        assert s.default_user_agent == "mgf-apiprobe/0.1.0"
        assert s.verify_tls is True
        assert s.fail_on_severity == "critical"

    def test_constructor_overrides(self) -> None:
        s = ApiprobeSettings(timeout_seconds=5.0, max_retries=2)
        assert s.timeout_seconds == 5.0
        assert s.max_retries == 2

    def test_env_prefix(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("APIPROBE_TIMEOUT_SECONDS", "45.5")
        monkeypatch.setenv("APIPROBE_DEFAULT_USER_AGENT", "test-agent/1.0")
        s = ApiprobeSettings()
        assert s.timeout_seconds == 45.5
        assert s.default_user_agent == "test-agent/1.0"

    def test_subclasses_base_app_settings(self) -> None:
        from mgf.common.config import BaseAppSettings

        assert issubclass(ApiprobeSettings, BaseAppSettings)

    @pytest.mark.parametrize("bad_timeout", [0, -1.0])
    def test_timeout_must_be_positive(self, bad_timeout: float) -> None:
        # mgf-common v0.5+ wraps pydantic ValidationError into
        # AppConfigError with PEP 678 notes naming the env var.
        from mgf.common.exceptions import AppConfigError

        with pytest.raises(AppConfigError):
            ApiprobeSettings(timeout_seconds=bad_timeout)

    @pytest.mark.parametrize("bad_retries", [-1, 11])
    def test_max_retries_bounded(self, bad_retries: int) -> None:
        from mgf.common.exceptions import AppConfigError

        with pytest.raises(AppConfigError):
            ApiprobeSettings(max_retries=bad_retries)
