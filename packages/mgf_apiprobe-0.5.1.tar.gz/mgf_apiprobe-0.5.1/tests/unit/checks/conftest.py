"""Shared fixtures for the check-test suite."""

from __future__ import annotations

from mgf.apiprobe.core.context import Context
from mgf.apiprobe.core.response import Response


def make_response(
    *,
    status: int = 200,
    headers: dict[str, str] | None = None,
    body: bytes = b"",
    elapsed_ms: float = 12.5,
    url: str = "https://api.example.com/v1/users",
) -> Response:
    """Build a Response for tests.

    Default is a generic 200 with no body. Override what matters for
    each test; keep noise out of the test file.
    """
    return Response(
        url=url,
        status=status,
        headers=headers or {},
        body=body,
        elapsed_ms=elapsed_ms,
    )


def empty_ctx() -> Context:
    return Context.empty()
