"""Tests for ``mgf.apiprobe.core.context``."""

from __future__ import annotations

import pytest

from mgf.apiprobe.core.context import Context


class TestContext:
    def test_empty(self) -> None:
        ctx = Context.empty()
        assert ctx.variables == {}

    def test_with_variables(self) -> None:
        ctx = Context.with_variables({"user_id": "abc", "limit": 50})
        assert ctx.get("user_id") == "abc"
        assert ctx.get("limit") == 50

    def test_get_default(self) -> None:
        ctx = Context.empty()
        assert ctx.get("missing") is None
        assert ctx.get("missing", "fallback") == "fallback"

    def test_variables_immutable(self) -> None:
        ctx = Context.with_variables({"x": 1})
        with pytest.raises(TypeError):
            ctx.variables["y"] = 2  # type: ignore[index]

    def test_input_dict_isolation(self) -> None:
        # Mutating the source dict after construction does NOT mutate ctx.
        original = {"a": 1}
        ctx = Context.with_variables(original)
        original["a"] = 999
        original["b"] = 2
        assert ctx.get("a") == 1
        assert ctx.get("b") is None
