"""Tests for ``mgf.apiprobe.core.tag``."""

from __future__ import annotations

from mgf.apiprobe.core.tag import Tag


class TestTagValues:
    def test_canonical_tag_set_pinned(self) -> None:
        # Adding/removing canonical tags is a deliberate change.
        # New tags arrive in subsequent phases (LRO with v0.2,
        # SCENARIO_STEP with v0.2, MULTIPART with v0.2 — see DEFERRED.md).
        assert {t.value for t in Tag} == {"read", "write", "public", "private", "unsafe"}

    def test_str_compatibility(self) -> None:
        # StrEnum members are strings — useful for free-form string mixing.
        assert Tag.READ == "read"
        assert str(Tag.READ) == "read"
        assert Tag.READ in {"read", "write"}
