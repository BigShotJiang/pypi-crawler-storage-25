"""Coverage for ``describe()`` across every matcher type.

``describe()`` returns the human-readable string used in Finding
evidence. The text is part of the user-facing surface — empty or
trivial strings would degrade reports — so every matcher gets a
single sanity test here.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

import pytest

from mgf.apiprobe.core.matchers.format import (
    is_email,
    is_iso8601_z,
    is_url,
    is_uuid,
)
from mgf.apiprobe.core.matchers.primitives import (
    between,
    equals,
    gt,
    gte,
    in_,
    lt,
    lte,
    matches,
    not_equals,
    not_in,
)
from mgf.apiprobe.core.matchers.semantic import is_e164, is_iban, is_imei

if TYPE_CHECKING:
    from mgf.apiprobe.core.matcher import Matcher

ALL_MATCHERS: list[Matcher] = [
    equals(1),
    not_equals(1),
    gt(0),
    gte(0),
    lt(10),
    lte(10),
    between(0, 10),
    in_(1, 2),
    not_in(1, 2),
    matches(re.compile(r"x")),
    is_uuid(),
    is_iso8601_z(),
    is_url(),
    is_email(),
    is_iban(),
    is_imei(),
    is_e164(),
]


@pytest.mark.parametrize("m", ALL_MATCHERS, ids=lambda m: type(m).__name__)
def test_describe_is_non_empty_string(m: Matcher) -> None:
    desc = m.describe()
    assert isinstance(desc, str)
    assert desc.strip()  # not just whitespace
