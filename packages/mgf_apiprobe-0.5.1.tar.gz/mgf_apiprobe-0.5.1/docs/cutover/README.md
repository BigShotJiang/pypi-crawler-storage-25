# `docs/cutover/` — per-release breaking-change migration guides

**Per `DOC-05`:** every breaking change (MAJOR, or MINOR within
`0.x` per **AP-03**) MUST ship a `v<X.Y.Z>.md` guide.

## What goes here

One file per breaking release: `v<X.Y.Z>.md`. Each guide MUST
include:

1. **At-a-glance.** Before/after table summarising the
   breakage.
2. **What was removed / renamed / reshaped.** Identifier-level
   list with replacement names.
3. **Codemod recipe** (if available) — `mgf-apiprobe migrate`
   shape, with `--dry-run` preview.
4. **Manual migration block** per non-codemoddable change.
5. **FEEDBACK back-link** — every cutover guide names the
   `FEEDBACK.md` entry it closes (when applicable).

The shape is locked in by `mgf-common/docs/standards/DOCUMENTATION.md`
§5.

## What does NOT go here

- **Non-breaking changes** — those live in `CHANGELOG.md` only.
- **Release notes for the broader audience** — those are the
  CHANGELOG entry; the cutover guide is the consumer's
  migration runway.
- **Roadmaps / proposals** — those live in `docs/inprogress/`
  (if and when this project grows one).

## Index

Empty — no breaking changes shipped yet.
