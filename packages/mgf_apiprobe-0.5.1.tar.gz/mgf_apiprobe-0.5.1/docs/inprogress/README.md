# `docs/inprogress/` — the maintainer's workspace

**Per `DOC-02` + `DOC-11`** in `mgf-common`'s [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md):
this directory is the **workspace** where the maintainer's
internal-posture docs live while they're active.

## What goes here

- **Living priority trackers** (per `DOC-06`): one per concern
  area. §1..§6 canonical shape.
- **One-shot audit passes**. Finite scope; archive when complete.

## What does NOT go here

- **Consumer-reported papercuts** — `mgf-apiprobe` has no
  consumer-facing `FEEDBACK.md` of its own; consumer signal lands
  in [`mgf-common/FEEDBACK.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEEDBACK.md)
  under a `[mgf-apiprobe]` prefix.
- **Per-release breaking-change guides** — those go to
  `docs/cutover/`.
- **Permanent rules / standards** — those live in
  `mgf-common/docs/standards/`.

## Index

| File | Status | What |
|---|---|---|
| [`RELIABILITY_AND_ACCURACY.md`](RELIABILITY_AND_ACCURACY.md) | v0.1 — active | RA-* items: gather cancellation semantics, probe-id uniqueness, severity-override audit logging, cookie value sanitization, follow_redirects in API verification, transport pool reuse, empty-credential policy. |
| [`SECURITY_HARDENING.md`](SECURITY_HARDENING.md) | v0.1 — active | SH-* items: Finding evidence redaction, BodyEchoesSecret needle-in-memory, auth credential lifecycle, cookie sanitization (twin RA-04), security-check coverage gaps (CSP / Referrer-Policy / etc.), TLS-disabled finding emission, sibling SBOM + vuln-scan. |
| [`PERFORMANCE_AND_CAPACITY.md`](PERFORMANCE_AND_CAPACITY.md) | v0.1 — active | PC-* items: suite throughput at max_concurrency, per-probe wrapper tax, check-chain iteration cost, cold-import time, memory baseline after suite run, matcher DSL cost, Finding allocation profile, report serialisation throughput. |
