# USERS — who depends on mgf-apiprobe

> **Purpose:** mgf-apiprobe's user roll. Lists every consumer project and
> federation sibling that imports `mgf.apiprobe.*`.
> **Maintained by:** the mgf-common owner (Bassam — mgf-common owns the
> federation per the one-big-library mindset).
> **Per standard DOC-16** (v2.9): every `mgf-*` library MUST maintain a
> `USERS.md` at repo root.

Last verified: 2026-05-18 (post-mgf-apiprobe v0.5.0 release with security
header checks).

---

## §1 Consumer projects (external users)

| Project        | Location                                     | Import sites | Status                              | Surfaces used                        |
|----------------|----------------------------------------------|-------------:|-------------------------------------|--------------------------------------|
| **inthewords** | `/home/bassam/PycharmProjects/inthewords`    | 1            | Single use — release-smoke probe    | One check from `mgf.apiprobe.checks` |

**Single-consumer reality.** mgf-apiprobe is positioned as a CLI-first
internal-verification tool. The v0.5.0 surface (84 names) is large because
the library models a rich check API, not because it has many consumers.
Adoption will broaden when more federation consumers ship public APIs.

---

## §2 Federation siblings (`mgf-*` libraries)

No siblings depend on mgf-apiprobe today. It is not an in-process dependency
— consumers run it via its CLI against staging/prod endpoints.

---

## §3 What a "user" change MUST trigger

See [`../mgf_common/USERS.md`](../mgf_common/USERS.md) §3. For mgf-apiprobe
specifically: because the CLI is the primary surface, version-skew concerns
are about CLI flag stability rather than Python-API stability. Track CLI
breaking changes in `CHANGELOG.md` under a dedicated `### CLI` heading.

---

## §4 How this list is maintained

```sh
for proj in VManager inthewords PlasmaMapper iosRecovery; do
  grep -rE "(from|import) +mgf\.apiprobe" "/home/bassam/PycharmProjects/$proj" \
    --include='*.py' | wc -l
done
```

Re-run before each MINOR release. Also count CLI users separately when
they show up — they won't appear in `grep` but ARE users (`apiprobe run …`
invocations in CI / scripts).
