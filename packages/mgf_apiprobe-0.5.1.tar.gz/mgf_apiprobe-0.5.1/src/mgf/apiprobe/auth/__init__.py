"""``mgf.apiprobe.auth`` — concrete :class:`AuthFlow` implementations.

See: ``DESIGN.md`` §3.6 + ``HANDOFF.md`` §3.2 (the Protocol stays in
``core/auth.py``; the concrete classes live here so ``core/`` stays
I/O-free per the layering invariant).

v0.1 ships five flows:

  - :class:`BearerAuth`   — ``Authorization: Bearer <token>``
  - :class:`BasicAuth`    — ``Authorization: Basic <b64(user:pass)>``
  - :class:`ApiKeyAuth`   — header OR query param
  - :class:`CookieAuth`   — sets a single cookie
  - :class:`CustomAuth`   — caller-supplied callable

OAuth2 flows (client-credentials, auth-code, device-code) land in
v0.6.

Every flow resolves its credential value from one of two sources:

  - **Direct** — passed at construction time.
  - **Env**    — name of an environment variable read at
    :meth:`prepare` time.

Exactly one must be provided per credential — passing both is a
construction error; passing neither is a construction error. This
makes the resolution path obvious from the constructor call site.

Vault-backed credentials work via :class:`CustomAuth`::

    from mgf.common.vault import get_vault

    def _prepare() -> AuthCredentials:
        token = get_vault().get("stripe-secret-key")
        return AuthCredentials(headers=(("Authorization", f"Bearer {token}"),))

    auth = CustomAuth(name="vault:stripe", prepare_func=_prepare)
"""

from __future__ import annotations

from mgf.apiprobe.auth.flows import (
    ApiKeyAuth,
    BasicAuth,
    BearerAuth,
    CookieAuth,
    CustomAuth,
)

__all__ = [
    "ApiKeyAuth",
    "BasicAuth",
    "BearerAuth",
    "CookieAuth",
    "CustomAuth",
]
