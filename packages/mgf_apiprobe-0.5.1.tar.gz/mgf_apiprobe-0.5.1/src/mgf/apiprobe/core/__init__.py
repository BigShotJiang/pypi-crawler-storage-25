"""``mgf.apiprobe.core`` — domain primitives.

This subpackage hosts the pure-domain types: ``Finding``, ``Severity``,
``RootCause``, ``Response``, and (in subsequent commits) ``Probe``,
``Check``, ``Suite``, ``Context``, ``AuthFlow``, ``Matcher``.

Per ``DESIGN.md`` §3 + ``.importlinter`` ``mgf-apiprobe-layering``
contract: this layer has NO dependency on ``cli``, ``reporting``, or
``transport`` — those are higher layers that ASSEMBLE the domain.
The split keeps core unit-testable without httpx, argparse, or
filesystem access.
"""

from __future__ import annotations

from mgf.apiprobe.core.auth import AuthCredentials, AuthFlow
from mgf.apiprobe.core.check import Check
from mgf.apiprobe.core.context import Context
from mgf.apiprobe.core.finding import Finding, RootCause, Severity
from mgf.apiprobe.core.matcher import MISSING, Matcher
from mgf.apiprobe.core.matchers import (
    between,
    equals,
    gt,
    gte,
    in_,
    is_e164,
    is_email,
    is_iban,
    is_imei,
    is_iso8601_z,
    is_url,
    is_uuid,
    lt,
    lte,
    matches,
    not_equals,
    not_in,
)
from mgf.apiprobe.core.probe import Probe
from mgf.apiprobe.core.report import Report
from mgf.apiprobe.core.response import Response
from mgf.apiprobe.core.suite import Suite
from mgf.apiprobe.core.tag import Tag
from mgf.apiprobe.core.transport import Transport

__all__ = [
    "MISSING",
    "AuthCredentials",
    "AuthFlow",
    "Check",
    "Context",
    "Finding",
    "Matcher",
    "Probe",
    "Report",
    "Response",
    "RootCause",
    "Severity",
    "Suite",
    "Tag",
    "Transport",
    "between",
    "equals",
    "gt",
    "gte",
    "in_",
    "is_e164",
    "is_email",
    "is_iban",
    "is_imei",
    "is_iso8601_z",
    "is_url",
    "is_uuid",
    "lt",
    "lte",
    "matches",
    "not_equals",
    "not_in",
]
