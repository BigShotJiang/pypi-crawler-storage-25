"""``mgf.apiprobe.core.matchers`` — concrete matcher implementations.

Three layers:

  - :mod:`primitives` — equals / gt / lt / in / matches / between
  - :mod:`format`     — is_uuid / is_iso8601_z / is_url / is_email
  - :mod:`semantic`   — is_iban / is_imei / is_e164 (validating)

The semantic layer does REAL validation (Luhn for IMEI, MOD-97 for
IBAN), not just regex shape — DESIGN.md §3.1.5 calls these out as
the differentiator vs. Schemathesis-style schema fuzzing. Tests
prove the validators reject malformed inputs other tools accept.

Every public name is re-exported here for the standard
``from mgf.apiprobe import is_uuid, equals`` import shape (still
re-exported from the top-level package in ``mgf.apiprobe.__init__``).
"""

from __future__ import annotations

from mgf.apiprobe.core.matchers.format import (
    is_email,
    is_iso8601_z,
    is_url,
    is_uuid,
)
from mgf.apiprobe.core.matchers.primitives import (
    between,
    equals,
    gt,
    gte,
    in_,
    lt,
    lte,
    matches,
    not_equals,
    not_in,
)
from mgf.apiprobe.core.matchers.semantic import (
    is_e164,
    is_iban,
    is_imei,
)

__all__ = [
    "between",
    "equals",
    "gt",
    "gte",
    "in_",
    "is_e164",
    "is_email",
    "is_iban",
    "is_imei",
    "is_iso8601_z",
    "is_url",
    "is_uuid",
    "lt",
    "lte",
    "matches",
    "not_equals",
    "not_in",
]
