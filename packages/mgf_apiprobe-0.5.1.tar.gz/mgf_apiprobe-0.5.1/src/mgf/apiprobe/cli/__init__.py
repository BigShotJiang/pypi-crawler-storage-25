"""``mgf.apiprobe.cli`` — the v0.1 command-line interface.

See: ``DESIGN.md`` §16 Phase 1 (CLI core: ``run`` / ``checks`` /
``doctor``). The fuller subcommand set (``probe``, ``diff``, ``drift``,
``cassette``, ``snapshot``, ``mutate``, ``scaffold``, ``bisect``,
``report``) lands in v0.4-v0.5.

Entry points (declared in ``pyproject.toml``):

  - ``mgf-apiprobe`` — canonical name
  - ``apiprobe``    — short alias

Both call :func:`main`; both support the same subcommands.
"""

from __future__ import annotations

from mgf.apiprobe.cli.__main__ import main

__all__ = ["main"]
