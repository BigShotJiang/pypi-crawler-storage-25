"""The bundled httpbin self-test suite.

Used by ``apiprobe run`` when no ``--suite`` is provided. Doubles as
the v0.1 exit-criterion proof from HANDOFF.md §7 Step 4: "a hand-
written suite against httpbin runs live, exits non-zero on planted
findings."

httpbin.org is publicly reachable; running the bundled suite hits the
network. Tests of the CLI mock httpx so this module's contents don't
require live access.
"""

from __future__ import annotations

from mgf.apiprobe.checks import DEFAULT_CHECKS
from mgf.apiprobe.core.probe import Probe
from mgf.apiprobe.core.suite import Suite

_BASE_URL = "https://httpbin.org"


def build_default_suite() -> Suite:
    """Return the bundled httpbin self-test :class:`Suite`."""
    probes = [
        Probe.get(f"{_BASE_URL}/status/200")
        .id("status-200")
        .expect_status(200),
        Probe.get(f"{_BASE_URL}/status/404")
        .id("status-404")
        .expect_status(404),
        Probe.get(f"{_BASE_URL}/headers")
        .id("headers")
        .expect_status(200)
        .header("X-Test-Header", "apiprobe-self-test")
        .expect_header("Content-Type"),
        Probe.get(f"{_BASE_URL}/json")
        .id("json-body")
        .expect_status(200)
        .expect_header("Content-Type"),
        Probe.post(f"{_BASE_URL}/anything")
        .id("post-anything")
        .body({"hello": "world"})
        .expect_status(200),
    ]
    return Suite(probes=probes, checks=DEFAULT_CHECKS)


__all__ = ["build_default_suite"]
