"""``apiprobe checks`` — list the default check catalogue."""

from __future__ import annotations

from mgf.apiprobe.checks import DEFAULT_CHECKS


def handle_checks() -> int:
    """Print every default check's code + severity + root cause.

    Output is grouped by category (the prefix before the first dot in
    the code) so consumers can grep / filter::

        contract.status.unexpected           CRITICAL  PROVIDER_CONTRACT
        contract.status.server-error         CRITICAL  PROVIDER_5XX
        ...
        schema.body.shape-mismatch           CRITICAL  PROVIDER_CONTRACT
        ...
    """
    # Width-align for readable output in monospace terminals.
    max_code_len = max(len(c.code) for c in DEFAULT_CHECKS)
    max_sev_len = max(len(c.severity_default.value) for c in DEFAULT_CHECKS)

    last_category: str | None = None
    for check in DEFAULT_CHECKS:
        category = check.code.split(".", 1)[0]
        if last_category is not None and category != last_category:
            print()
        last_category = category
        print(
            f"{check.code:<{max_code_len}}  "
            f"{check.severity_default.value.upper():<{max_sev_len}}  "
            f"{check.root_cause_default.value.upper()}"
        )

    print()
    print(f"{len(DEFAULT_CHECKS)} checks total.")
    return 0


__all__ = ["handle_checks"]
