"""Entry point for ``mgf-apiprobe`` and the ``apiprobe`` short alias.

Wires argparse to the per-subcommand handlers + routes through
:func:`mgf.common.cli.run_and_translate` for exit-code translation
of typed exceptions.
"""

from __future__ import annotations

import argparse
import sys
from typing import TYPE_CHECKING

from mgf.common.cli import run_and_translate

from mgf.apiprobe.cli.checks import handle_checks
from mgf.apiprobe.cli.doctor import handle_doctor
from mgf.apiprobe.cli.run import handle_run

if TYPE_CHECKING:
    from collections.abc import Sequence


def build_parser() -> argparse.ArgumentParser:
    """Build the top-level argparse parser."""
    parser = argparse.ArgumentParser(
        prog="apiprobe",
        description=(
            "REST API verification — typed probes, checks, findings. "
            "See https://codeberg.org/magogi-admin/mgf_apiprobe."
        ),
    )
    sub = parser.add_subparsers(dest="subcommand", required=True)

    # apiprobe run
    p_run = sub.add_parser(
        "run",
        help="Execute a suite and print the report.",
    )
    p_run.add_argument(
        "--suite",
        metavar="MODULE[:ATTR]",
        default=None,
        help=(
            "Python module path to a suite (e.g., 'my.module:my_suite'). "
            "If omitted, runs the bundled httpbin self-test."
        ),
    )
    p_run.add_argument(
        "--format",
        choices=["human", "json"],
        default="human",
        help="Report format. Default: human.",
    )

    # apiprobe checks
    sub.add_parser(
        "checks",
        help="List the default check catalogue.",
    )

    # apiprobe doctor
    sub.add_parser(
        "doctor",
        help="Self-check — version, imports, default check count.",
    )

    return parser


def _dispatch(argv: Sequence[str]) -> int:
    """Dispatch to the requested subcommand."""
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.subcommand == "run":
        return handle_run(suite_path=args.suite, format=args.format)
    if args.subcommand == "checks":
        return handle_checks()
    if args.subcommand == "doctor":
        return handle_doctor()
    parser.error(f"unknown subcommand {args.subcommand!r}")  # pragma: no cover
    return 2  # pragma: no cover


def main(argv: Sequence[str] | None = None) -> int:
    """Entry point. Translates typed exceptions to exit codes."""
    if argv is None:
        argv = sys.argv[1:]
    return run_and_translate(_dispatch, list(argv))


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
