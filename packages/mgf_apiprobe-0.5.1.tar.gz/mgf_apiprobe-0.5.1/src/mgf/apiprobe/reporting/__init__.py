"""``mgf.apiprobe.reporting`` — :class:`Report` writers.

See: ``DESIGN.md`` §3.7 (Report + writers).

A :class:`ReportWriter` consumes a :class:`Report` and produces a
representation — a string, a dict, a file. v0.1 ships two writers:

  - :class:`HumanReportWriter` — terminal-friendly text
  - :class:`JsonReportWriter`  — machine-readable JSON dict

The full set (markdown, JUnit, SARIF, Slack, Discord, Teams,
PagerDuty, GitHub PR, GitLab MR, Codeberg PR, CSV, Prometheus) lands
progressively.

Writers do NOT print to stdout / files themselves — they return text
or dict objects. Routing the output is the consumer's responsibility
(or the CLI layer's, Phase 1.9).
"""

from __future__ import annotations

from mgf.apiprobe.reporting.base import ReportWriter
from mgf.apiprobe.reporting.human import HumanReportWriter
from mgf.apiprobe.reporting.json_writer import JsonReportWriter

__all__ = [
    "HumanReportWriter",
    "JsonReportWriter",
    "ReportWriter",
]
