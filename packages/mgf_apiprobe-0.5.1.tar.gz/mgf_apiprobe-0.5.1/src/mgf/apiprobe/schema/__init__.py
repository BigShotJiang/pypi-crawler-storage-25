"""``mgf.apiprobe.schema`` — response-shape validation sources.

See: ``DESIGN.md`` §5 (schema source priority) and §14 (project layout).

A :class:`SchemaSource` validates a JSON-decoded payload against a
schema. v0.1 ships only :class:`PydanticSchemaSource`; OpenAPI lands
in v0.2 and JSON Schema in v0.4.

The :class:`SchemaSource` ABC keeps every implementation behind one
typed seam — checks consume the ABC and don't care which backend
produced the schema. That's the closed-box invariant: when OpenAPI
ships, check code doesn't change.
"""

from __future__ import annotations

from mgf.apiprobe.schema.base import SchemaSource, SchemaValidationIssue
from mgf.apiprobe.schema.pydantic import PydanticSchemaSource

__all__ = [
    "PydanticSchemaSource",
    "SchemaSource",
    "SchemaValidationIssue",
]
