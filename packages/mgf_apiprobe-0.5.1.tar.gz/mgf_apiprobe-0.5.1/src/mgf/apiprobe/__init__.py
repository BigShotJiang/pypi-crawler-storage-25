"""mgf.apiprobe — REST API verification (typed probes, checks, findings).

See: ``DESIGN.md`` (the spec), ``HANDOFF.md`` (the integration plan),
``PUBLIC_API.md`` (the contract list).

This is the public surface of the package. Consumers import from here;
underscore-prefixed modules are private.

Surface:

  - ``Probe``, ``Check``, ``Suite``, ``Context``, ``AuthFlow`` — core primitives.
  - ``BearerAuth``, ``BasicAuth``, ``ApiKeyAuth``, ``CookieAuth``, ``CustomAuth`` — auth flows.
  - ``Finding``, ``Severity``, ``RootCause`` — result shapes.
  - ``Report`` — suite output.
  - Pydantic schema source.
  - Matchers DSL (primitives + format + semantic).
  - Built-in factories (UUID, ISO 8601 timestamps, IBAN, IMEI, E.164).
  - Console + JSON report writers.

This module's ``__all__`` is authoritative — adding a name to a
private module without re-exporting it here means it is NOT part of
the public surface.
"""

from __future__ import annotations

from mgf.apiprobe import factories
from mgf.apiprobe._version import __version__
from mgf.apiprobe.auth import (
    ApiKeyAuth,
    BasicAuth,
    BearerAuth,
    CookieAuth,
    CustomAuth,
)
from mgf.apiprobe.checks import (
    DEFAULT_CHECKS,
    BodyEchoesSecret,
    BodyEmptyOnSuccess,
    BodyInvalidJson,
    BodySizeOverBudget,
    ContentTypeJsonExpected,
    ContentTypeMissing,
    HeaderMissing,
    LatencyOverBudget,
    LatencySuspiciousZero,
    MissingContentTypeOptions,
    MissingFrameOptions,
    MissingHsts,
    MissingRateLimitHeaders,
    MissingRequestId,
    MissingServerHeader,
    SchemaShapeMismatch,
    Server5xx,
    StatusUnexpected,
)
from mgf.apiprobe.cli import main as cli_main
from mgf.apiprobe.config import ApiprobeSettings
from mgf.apiprobe.core import (
    MISSING,
    AuthCredentials,
    AuthFlow,
    Check,
    Context,
    Finding,
    Matcher,
    Probe,
    Report,
    Response,
    RootCause,
    Severity,
    Suite,
    Tag,
    Transport,
    between,
    equals,
    gt,
    gte,
    in_,
    is_e164,
    is_email,
    is_iban,
    is_imei,
    is_iso8601_z,
    is_url,
    is_uuid,
    lt,
    lte,
    matches,
    not_equals,
    not_in,
)
from mgf.apiprobe.exceptions import (
    ApiprobeConfigError,
    ApiprobeError,
    AuthError,
    MatcherError,
    SchemaError,
    SuiteLogicError,
    TransportError,
)
from mgf.apiprobe.reporting import (
    HumanReportWriter,
    JsonReportWriter,
    ReportWriter,
)
from mgf.apiprobe.schema import (
    PydanticSchemaSource,
    SchemaSource,
    SchemaValidationIssue,
)
from mgf.apiprobe.transport import HttpxTransport

__all__ = [
    "DEFAULT_CHECKS",
    "MISSING",
    "ApiKeyAuth",
    "ApiprobeConfigError",
    "ApiprobeError",
    "ApiprobeSettings",
    "AuthCredentials",
    "AuthError",
    "AuthFlow",
    "BasicAuth",
    "BearerAuth",
    "BodyEchoesSecret",
    "BodyEmptyOnSuccess",
    "BodyInvalidJson",
    "BodySizeOverBudget",
    "Check",
    "ContentTypeJsonExpected",
    "ContentTypeMissing",
    "Context",
    "CookieAuth",
    "CustomAuth",
    "Finding",
    "HeaderMissing",
    "HttpxTransport",
    "HumanReportWriter",
    "JsonReportWriter",
    "LatencyOverBudget",
    "LatencySuspiciousZero",
    "Matcher",
    "MatcherError",
    "MissingContentTypeOptions",
    "MissingFrameOptions",
    "MissingHsts",
    "MissingRateLimitHeaders",
    "MissingRequestId",
    "MissingServerHeader",
    "Probe",
    "PydanticSchemaSource",
    "Report",
    "ReportWriter",
    "Response",
    "RootCause",
    "SchemaError",
    "SchemaShapeMismatch",
    "SchemaSource",
    "SchemaValidationIssue",
    "Server5xx",
    "Severity",
    "StatusUnexpected",
    "Suite",
    "SuiteLogicError",
    "Tag",
    "Transport",
    "TransportError",
    "__version__",
    "between",
    "cli_main",
    "equals",
    "factories",
    "gt",
    "gte",
    "in_",
    "is_e164",
    "is_email",
    "is_iban",
    "is_imei",
    "is_iso8601_z",
    "is_url",
    "is_uuid",
    "lt",
    "lte",
    "matches",
    "not_equals",
    "not_in",
]
