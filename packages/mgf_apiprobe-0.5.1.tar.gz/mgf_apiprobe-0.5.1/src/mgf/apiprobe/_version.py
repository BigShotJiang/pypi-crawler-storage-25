"""Single source of truth for the package version.

Mirrors ``mgf-common``'s ``_version.py`` shape. The version string here
MUST match ``pyproject.toml``'s ``[project].version`` field; ``hatchling``
reads from ``pyproject.toml`` so this constant is for runtime
introspection (``mgf.apiprobe.__version__``) only.
"""

from __future__ import annotations

__version__: str = "0.5.1"
