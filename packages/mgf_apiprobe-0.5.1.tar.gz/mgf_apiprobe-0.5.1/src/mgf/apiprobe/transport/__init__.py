"""``mgf.apiprobe.transport`` — concrete transport implementations.

See: ``DESIGN.md`` §14 (transport directory) + ``HANDOFF.md`` §3.5
(layering: this is the I/O layer, depends on httpx; ``core/`` doesn't
depend on this).

v0.1 ships :class:`HttpxTransport`. Cassette-replay transport
(v0.3+), streaming-body support (v0.2+), and OAuth2 token endpoints
(v0.6+) are deferred.
"""

from __future__ import annotations

from mgf.apiprobe.transport.httpx_transport import HttpxTransport

__all__ = ["HttpxTransport"]
