"""``mgf.apiprobe.factories`` — built-in value generators.

See: ``DESIGN.md`` §3.4.2 (Factories in Context — ``{{factory:name}}``
template filter) and ``HANDOFF.md`` §6 (v0.1 cut: UUID, ISO timestamps,
IBAN, IMEI, E.164).

In v0.1 factories are direct callables — consumers invoke them when
constructing probe bodies::

    from mgf.apiprobe import factories

    probe = Probe.post("/devices").body({
        "id": factories.uuid(),
        "imei": factories.imei(),
        "phone": factories.e164(country_code=44),  # UK
    })

Variable interpolation via ``{{factory:imei}}`` — which calls these
the way DESIGN.md describes — ships in v0.2 when :class:`Context`
gains variable mutation.

Every factory produces a value that **passes the corresponding
matcher in :mod:`mgf.apiprobe.core.matchers.semantic` / .format**.
That contract is tested explicitly in
``tests/unit/factories/test_builtins.py``.
"""

from __future__ import annotations

from mgf.apiprobe.factories.builtins import (
    e164,
    iban,
    imei,
    iso8601_z,
    uuid,
)

__all__ = [
    "e164",
    "iban",
    "imei",
    "iso8601_z",
    "uuid",
]
