# glassbox_mcp_server.py - Windows compatible version
import sys
import json
import os

# Add the current directory to path so imports work
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gmail_tool import send_email_tool


try:
    from agent.tools import automl_tool, eda_tool

    TOOLS_AVAILABLE = True
except ImportError as e:
    TOOLS_AVAILABLE = False
    print(f"Warning: Could not import GlassBoxAI tools: {e}", file=sys.stderr)


def main():
    # Send ready signal
    print("GlassBoxAI MCP Server ready", file=sys.stderr)
    sys.stderr.flush()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            request = json.loads(line)
            method = request.get("method")
            req_id = request.get("id")

            if method == "initialize":
                response = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {
                        "protocolVersion": "0.1.0",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "glassbox-automl", "version": "1.0.0"}
                    }
                }

            elif method == "tools/list":
                if TOOLS_AVAILABLE:
                    tools = [
                        {
                            "name": "run_automl",
                            "description": "Run GlassBoxAI AutoML pipeline",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "csv_content": {"type": "string"},
                                    "target": {"type": "string"},
                                    "task": {"type": "string", "default": "classification"}
                                }
                            }
                        },
                        {
                            "name": "run_eda",
                            "description": "Run EDA on dataset",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "csv_content": {"type": "string"}
                                }
                            }
                        },
                        {
                            "name": "send_email",
                            "description": "Send an email using Gmail",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "to_email": {"type": "string"},
                                    "subject": {"type": "string"},
                                    "body": {"type": "string"}
                                },
                                "required": ["to_email", "subject", "body"]
                            }
                        }
                    ]
                else:
                    tools = []

                response = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {"tools": tools}
                }

            elif method == "tools/call":
                tool_name = request["params"]["name"]
                args = request["params"]["arguments"]

                if not TOOLS_AVAILABLE:
                    result_text = "Error: GlassBoxAI tools not available"
                elif tool_name == "run_automl":
                    result = automl_tool(
                        args.get("csv_content", ""),
                        target=args.get("target", "churned"),
                        task=args.get("task", "classification")
                    )
                    result_text = result
                elif tool_name == "run_eda":
                    result = eda_tool(args.get("csv_content", ""))
                    result_text = result
                elif tool_name == "send_email":
                    result_text = send_email_tool(
                        args["to_email"],
                        args["subject"],
                        args["body"]
                    )
                else:
                    result_text = f"Unknown tool: {tool_name}"

                response = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {
                        "content": [{"type": "text", "text": result_text}]
                    }
                }

            else:
                response = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "error": {"code": -32601, "message": f"Unknown method: {method}"}
                }

            print(json.dumps(response))
            sys.stdout.flush()

        except Exception as e:
            print(f"Error processing request: {e}", file=sys.stderr)
            sys.stderr.flush()


if __name__ == "__main__":
    main()