import json
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agent.tools import (
    TOOL_REGISTRY,
    automl_job_start_tool,
    automl_job_status_tool,
    automl_tool,
    data_overview_tool,
    eda_tool,
    ironclaw_tool_wrapper,
    ironclaw_tool_wrapper_json,
    preprocess_data_tool,
    preprocessing_decision_tool,
    cross_validate_tool,
    target_insights_tool,
)


class AgentToolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.csv_text = (ROOT / "data.csv").read_text()

    def test_eda_tool_returns_expected_sections(self):
        payload = json.loads(eda_tool(self.csv_text))

        self.assertIn("shape", payload)
        self.assertIn("profiles", payload)
        self.assertIn("correlations", payload)

    def test_automl_tool_returns_json_report(self):
        payload = json.loads(
            automl_tool(
                self.csv_text,
                target="churned",
                task="classification",
                cv=3,
                search_strategy="grid",
            )
        )

        self.assertEqual(payload["target"], "churned")
        self.assertIn("agent_summary", payload)
        self.assertIn("confusion_matrix", payload["eval_metrics"])

    def test_automl_async_job_tools(self):
        started = json.loads(
            automl_job_start_tool(
                self.csv_text,
                target="churned",
                task="classification",
                cv=2,
                search_strategy="grid",
                full_search=False,
                verbose=False,
            )
        )
        self.assertEqual(started["status"], "ok")
        self.assertIn("job_id", started)

        job_id = started["job_id"]
        final_payload = None
        for _ in range(40):
            polled = json.loads(automl_job_status_tool(job_id, include_result=True))
            if polled["job_status"] in ("completed", "failed"):
                final_payload = polled
                break
            time.sleep(0.2)

        self.assertIsNotNone(final_payload)
        self.assertEqual(final_payload["job_status"], "completed")
        self.assertIn("result", final_payload)
        self.assertIn("best_model", final_payload["result"])

    def test_data_overview_tool_contains_sample_rows(self):
        payload = json.loads(data_overview_tool(self.csv_text, sample_rows=3))

        self.assertIn("shape", payload)
        self.assertIn("sample_rows", payload)
        self.assertLessEqual(len(payload["sample_rows"]), 3)

    def test_target_insights_tool_returns_task_guess(self):
        payload = json.loads(target_insights_tool(self.csv_text, target="churned"))

        self.assertEqual(payload["target"], "churned")
        self.assertIn("task_guess", payload)

    def test_preprocess_data_tool_returns_transformed_output(self):
        payload = json.loads(
            preprocess_data_tool(
                self.csv_text,
                target="churned",
                scale="standard",
                encode="onehot",
                sample_rows=2,
            )
        )

        self.assertEqual(payload["status"], "ok")
        self.assertIn("operations", payload)
        self.assertIn("transformed_sample_rows", payload)

    def test_preprocessing_decision_tool_recommends_next_action(self):
        payload = json.loads(
            preprocessing_decision_tool(
                self.csv_text,
                target="churned",
            )
        )

        self.assertEqual(payload["status"], "ok")
        self.assertIn("next_action", payload)
        self.assertEqual(payload["next_action"]["recommended_tool"], "automl_tool")

    def test_ironclaw_tool_wrapper_dispatches_registered_tools(self):
        payload = json.loads(
            ironclaw_tool_wrapper(
                tool_name="eda_tool",
                arguments={"csv_text": self.csv_text},
            )
        )

        self.assertIn("shape", payload)
        self.assertIn("eda_tool", TOOL_REGISTRY)
        self.assertIn("preprocess_data_tool", TOOL_REGISTRY)
        self.assertIn("automl_job_start_tool", TOOL_REGISTRY)
        self.assertIn("automl_job_status_tool", TOOL_REGISTRY)

    def test_ironclaw_tool_wrapper_json_dispatch(self):
        request = json.dumps(
            {
                "tool_name": "target_insights_tool",
                "arguments": {"csv_text": self.csv_text, "target": "churned"},
            }
        )
        payload = json.loads(ironclaw_tool_wrapper_json(request))

        self.assertEqual(payload["target"], "churned")

    def test_cross_validate_tool_runs(self):
        payload = json.loads(
            cross_validate_tool(
                self.csv_text,
                target="churned",
                model=["DecisionTreeClassifier", "KNNClassifier"],
                cv=3,
                task="classification",
            )
        )

        self.assertEqual(payload.get("status"), "ok")
        self.assertIn("per_model", payload)
        self.assertEqual(len(payload["per_model"]), 2)
        for m in payload["per_model"]:
            self.assertIn("folds", m)
            self.assertIn("avg_metrics", m)


if __name__ == "__main__":
    unittest.main()
