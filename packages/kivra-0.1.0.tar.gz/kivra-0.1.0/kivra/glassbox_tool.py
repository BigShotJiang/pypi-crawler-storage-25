# glassbox_tool.py - Simple tool for IronClaw to call
import sys
import json
import os


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No command specified"}))
        return

    command = sys.argv[1]

    if command == "discover":
        # Tell IronClaw what tools are available
        print(json.dumps({
            "tools": [
                {
                    "name": "predict",
                    "description": "Train an ML model to predict a target column from a CSV file",
                    "parameters": {
                        "csv_file": {"type": "string", "description": "Path to CSV file"},
                        "target": {"type": "string", "description": "Column name to predict"}
                    }
                },
                {
                    "name": "analyze",
                    "description": "Analyze a CSV file and provide insights",
                    "parameters": {
                        "csv_file": {"type": "string", "description": "Path to CSV file"}
                    }
                }
            ]
        }))
        return

    elif command == "call":
        tool_name = sys.argv[2]

        if tool_name == "predict":
            # Parse arguments
            csv_file = None
            target = None

            for i, arg in enumerate(sys.argv):
                if arg == "--csv_file" and i + 1 < len(sys.argv):
                    csv_file = sys.argv[i + 1]
                elif arg == "--target" and i + 1 < len(sys.argv):
                    target = sys.argv[i + 1]

            if not csv_file or not target:
                print(json.dumps({"error": "Missing csv_file or target"}))
                return

            # Run GlassBoxAI
            try:
                # Import your GlassBoxAI
                import importlib.util
                spec = importlib.util.spec_from_file_location("agent.tools",
                                                              os.path.join(os.path.dirname(__file__), "agent",
                                                                           "tools.py"))
                tools = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(tools)

                # Read CSV
                with open(csv_file, 'r') as f:
                    csv_content = f.read()

                # Run AutoML
                result = tools.automl_tool(csv_content, target=target,
                                           task="classification", cv=3)
                print(result)

            except Exception as e:
                print(json.dumps({"error": str(e)}))

        elif tool_name == "analyze":
            csv_file = None
            for i, arg in enumerate(sys.argv):
                if arg == "--csv_file" and i + 1 < len(sys.argv):
                    csv_file = sys.argv[i + 1]

            if not csv_file:
                print(json.dumps({"error": "Missing csv_file"}))
                return

            try:
                from agent.tools import eda_tool
                with open(csv_file, 'r') as f:
                    csv_content = f.read()
                result = eda_tool(csv_content)
                print(result)
            except Exception as e:
                print(json.dumps({"error": str(e)}))


if __name__ == "__main__":
    main()