"""
GlassBox MCP Tool Wrapper
=========================
IronClaw-friendly tool surface for GlassBoxAI.

This module keeps backward compatibility with the original direct-call tools:
- automl_tool(...)
- eda_tool(...)

It additionally exposes a registry + dispatcher wrapper so IronClaw can call
more tools through one entrypoint.
IronClaw-friendly tool surface for GlassBoxAI.

This module keeps backward compatibility with the original direct-call tools:
- automl_tool(...)
- eda_tool(...)

It additionally exposes a registry + dispatcher wrapper so IronClaw can call
more tools through one entrypoint.
"""

import json
import threading
import time
import uuid
from io import StringIO

import numpy as np

from dataframes.DataFrame import DataFrame
from models.decisiontree.decisiontreeclassifier import DecisionTreeClassifier
from models.decisiontree.decisiontreeregression import DecisionTreeRegression
from models.knn.classifier import KNNClassifier
from models.knn.regressor import KNNRegressor
from models.linearregression.linear import LinearRegression
from models.logisticregression.logistic_regression import LogisticRegression
from models.naive.naive import NaiveBayes
from pipeline.autofit import AutoFit
from preprocessing.encode.onehot import OneHotEncoder
from preprocessing.impute.simple import MedianImputer, ModeImputer, SimpleImputer
from preprocessing.scale.minmax import MinMaxScaler
from preprocessing.scale.standard import StandardScaler
from evaluation.classification.classification import accuracy as _cls_accuracy, f1_score as _cls_f1, classification_report as _cls_report
from evaluation.regression.regression import regression_report as _reg_report


_AUTOML_JOBS = {}
_AUTOML_JOBS_LOCK = threading.Lock()


# =========================================================
# Core tools
# Core tools
# =========================================================

def automl_tool(
    csv_text: str,
    target: str,
    task: str = "auto",
    cv: int = 3,
    test_size: float = 0.2,
    seed: int = 42,
    search_strategy: str = "grid",
    random_iter: int = 10,
    full_search: bool = False,
    verbose: bool = False,
) -> str:
    """
    Run end-to-end AutoML and return a JSON report.
    Run end-to-end AutoML and return a JSON report.
    """
    try:
        df = _load_csv_from_string(csv_text)
        resolved_task = _resolve_task_hint(df=df, target=target, task=task)
        candidates = None if full_search else _timeout_safe_candidates(task=resolved_task)

        pipeline = AutoFit(
            target=target,
            task=task,
            cv=cv,
            test_size=test_size,
            seed=seed,
            search_strategy=search_strategy,
            random_iter=random_iter,
            verbose=verbose,
            candidates=candidates,
        )
        report = pipeline.fit(df)
        report["agent_summary"] = _build_summary(report)
        report["search_mode"] = "full" if full_search else "timeout_safe"
        return json.dumps(report, default=_json_safe, indent=2)
    except Exception as exc:
        return _error_json(f"The AutoML pipeline failed: {exc}")


def automl_job_start_tool(
    csv_text: str,
    target: str,
    task: str = "auto",
    cv: int = 3,
    test_size: float = 0.2,
    seed: int = 42,
    search_strategy: str = "grid",
    random_iter: int = 10,
    full_search: bool = True,
    verbose: bool = False,
) -> str:
    """
    Start AutoML as an async job and return a job_id immediately.
    """
    try:
        job_id = str(uuid.uuid4())
        with _AUTOML_JOBS_LOCK:
            _AUTOML_JOBS[job_id] = {
                "status": "queued",
                "created_at": time.time(),
                "started_at": None,
                "finished_at": None,
                "result": None,
                "error": None,
            }

        def _run_job():
            with _AUTOML_JOBS_LOCK:
                _AUTOML_JOBS[job_id]["status"] = "running"
                _AUTOML_JOBS[job_id]["started_at"] = time.time()

            try:
                result_json = automl_tool(
                    csv_text=csv_text,
                    target=target,
                    task=task,
                    cv=cv,
                    test_size=test_size,
                    seed=seed,
                    search_strategy=search_strategy,
                    random_iter=random_iter,
                    full_search=full_search,
                    verbose=verbose,
                )
                result = json.loads(result_json)
                with _AUTOML_JOBS_LOCK:
                    _AUTOML_JOBS[job_id]["status"] = "completed"
                    _AUTOML_JOBS[job_id]["result"] = result
                    _AUTOML_JOBS[job_id]["finished_at"] = time.time()
            except Exception as exc:
                with _AUTOML_JOBS_LOCK:
                    _AUTOML_JOBS[job_id]["status"] = "failed"
                    _AUTOML_JOBS[job_id]["error"] = str(exc)
                    _AUTOML_JOBS[job_id]["finished_at"] = time.time()

        threading.Thread(target=_run_job, daemon=True).start()

        return json.dumps(
            {
                "status": "ok",
                "job_id": job_id,
                "job_status": "queued",
                "message": "AutoML job started. Use automl_job_status_tool to poll results.",
            },
            indent=2,
        )
    except Exception as exc:
        return _error_json(str(exc))


def automl_job_status_tool(job_id: str, include_result: bool = True) -> str:
    """
    Check async AutoML job status and optionally include final report.
    """
    try:
        with _AUTOML_JOBS_LOCK:
            job = _AUTOML_JOBS.get(job_id)
            if job is None:
                raise ValueError(f"Unknown job_id '{job_id}'.")
            job_view = {
                "status": "ok",
                "job_id": job_id,
                "job_status": job["status"],
                "created_at": job["created_at"],
                "started_at": job["started_at"],
                "finished_at": job["finished_at"],
                "error": job["error"],
            }
            if include_result and job["status"] == "completed":
                job_view["result"] = job["result"]

        return json.dumps(job_view, default=_json_safe, indent=2)
    except Exception as exc:
        return _error_json(str(exc))


def eda_tool(csv_text: str) -> str:
    """
    Run full EDA Inspector report and return JSON.
    Run full EDA Inspector report and return JSON.
    """
    try:
        from eda.inspector import EDAInspector

        df = _load_csv_from_string(csv_text)

        df = _load_csv_from_string(csv_text)
        report = EDAInspector(df).run()
        return json.dumps(report, default=_json_safe, indent=2)
    except Exception as exc:
        return _error_json(str(exc))


def cross_validate_tool(
    csv_text: str,
    target: str,
    model,  # str or list[str]
    params: dict | None = None,
    task: str = "auto",
    cv: int = 5,
    seed: int = 42,
    metrics: list | None = None,
) -> str:
    """
    Run K-fold cross validation for a specified model and return per-fold metrics.

    Parameters:
    - csv_text: raw CSV
    - target: target column name
    - model: model class name (e.g. 'DecisionTreeClassifier')
    - params: dict of constructor params for the model
    - task: 'auto'|'classification'|'regression'
    - cv: number of folds
    - seed: RNG seed
    """
    try:
        # Normalize models input to a list
        models = model if isinstance(model, (list, tuple)) else [model]
        params = params or {}

        # Small local registry for common models
        MODEL_REGISTRY = {
            "DecisionTreeClassifier": DecisionTreeClassifier,
            "DecisionTreeRegression": DecisionTreeRegression,
            "KNNClassifier": KNNClassifier,
            "KNNRegressor": KNNRegressor,
            "LinearRegression": LinearRegression,
            "LogisticRegression": LogisticRegression,
            "NaiveBayes": NaiveBayes,
        }

        df = _load_csv_from_string(csv_text)
        resolved_task = _resolve_task_hint(df=df, target=target, task=task)

        # default metrics per task
        if metrics is None:
            if resolved_task == "classification":
                metrics = ["accuracy", "f1_macro"]
            else:
                metrics = ["MSE", "RMSE", "R2"]

        af = AutoFit(target=target, task=resolved_task, cv=cv, seed=seed, verbose=False)
        X, y, _ = af._build_features(df, task=resolved_task)

        n = len(X)
        if n == 0:
            return _error_json("No rows found in dataset.")

        rng = np.random.default_rng(seed)
        idx = rng.permutation(n)
        folds = np.array_split(idx, max(1, int(cv)))

        results = []

        for m in models:
            # Resolve model class: try registry first, then dynamic import
            ModelClass = None
            if m in MODEL_REGISTRY:
                ModelClass = MODEL_REGISTRY[m]
            else:
                # support fully-qualified imports like 'models.foo.Bar'
                try:
                    from importlib import import_module

                    if "." in m:
                        mod_path, attr = m.rsplit(".", 1)
                        mod = import_module(mod_path)
                        ModelClass = getattr(mod, attr)
                    else:
                        raise ImportError()
                except Exception:
                    return _error_json(f"Unknown model '{m}'. Provide a known model name or a fully-qualified import path.")

            model_params = params.get(m, params) if isinstance(params, dict) else {}

            per_fold = []
            for i, test_idx in enumerate(folds):
                train_idx = np.concatenate([f for j, f in enumerate(folds) if j != i]) if len(folds) > 1 else np.array([], dtype=int)
                if train_idx.size == 0:
                    train_idx = np.setdiff1d(idx, test_idx)

                X_train, X_test = X[train_idx], X[test_idx]
                y_train, y_test = y[train_idx], y[test_idx]

                inst = ModelClass(**model_params) if model_params else ModelClass()
                inst.fit(X_train, y_train)
                preds = inst.predict(X_test)

                if resolved_task == "classification":
                    row = {"fold": i + 1, "n_test": int(len(test_idx))}
                    if "accuracy" in metrics:
                        row["accuracy"] = round(float(_cls_accuracy(y_test, preds)), 4)
                    if "f1_macro" in metrics or "f1" in metrics:
                        row["f1_macro"] = round(float(_cls_f1(y_test, preds, average="macro")), 4)
                    if "precision_macro" in metrics:
                        from evaluation.classification.classification import precision as _cls_precision

                        row["precision_macro"] = round(float(_cls_precision(y_test, preds, average="macro")), 4)
                    if "recall_macro" in metrics:
                        from evaluation.classification.classification import recall as _cls_recall

                        row["recall_macro"] = round(float(_cls_recall(y_test, preds, average="macro")), 4)
                    per_fold.append(row)
                else:
                    reg = _reg_report(y_test, preds)
                    # keep only requested metrics
                    row = {"fold": i + 1, "n_test": int(len(test_idx))}
                    for k in metrics:
                        if k in reg:
                            row[k] = round(float(reg[k]), 4)
                    per_fold.append(row)

            # aggregate
            if resolved_task == "classification":
                agg = {}
                for metric_name in ("accuracy", "f1_macro", "precision_macro", "recall_macro"):
                    vals = [p[metric_name] for p in per_fold if metric_name in p]
                    if vals:
                        agg[metric_name] = round(float(np.mean(vals)), 4)
                results.append({"model": m, "folds": per_fold, "avg_metrics": agg})
            else:
                agg = {}
                metric_keys = [k for k in metrics if k in per_fold[0]] if per_fold else []
                for k in metric_keys:
                    agg[k] = round(float(np.mean([p[k] for p in per_fold])), 4)
                results.append({"model": m, "folds": per_fold, "avg_metrics": agg})

        payload = {"status": "ok", "cv": int(cv), "n_samples": int(n), "per_model": results}
        return json.dumps(payload, default=_json_safe, indent=2)
    except Exception as exc:
        return _error_json(str(exc))


def data_overview_tool(csv_text: str, sample_rows: int = 5) -> str:
    """
    Return a compact dataset overview for fast agent grounding.
    """
    try:
        from eda.inspector import EDAInspector

        df = _load_csv_from_string(csv_text)
        eda = EDAInspector(df).run()
        columns = df.get_features()

        n_rows, _ = df.format()
        sample_count = max(0, min(int(sample_rows), n_rows))
        sample = []
        for row_idx in range(sample_count):
            row = {}
            for col in columns:
                row[col] = _json_safe_or_raw(df[col][row_idx])
            sample.append(row)

        payload = {
            "shape": eda["shape"],
            "columns": columns,
            "column_types": eda["column_types"],
            "missing_summary": eda["missing_summary"],
            "sample_rows": sample,
        }
        return json.dumps(payload, default=_json_safe, indent=2)
    except Exception as exc:
        return _error_json(str(exc))


def target_insights_tool(csv_text: str, target: str) -> str:
    """
    Return target-specific diagnostics to help prompt planning.
    """
    try:
        df = _load_csv_from_string(csv_text)
        if target not in df.get_features():
            raise ValueError(f"Target column '{target}' not found.")

        dtype = df.dtypes.get(target, "str")
        values = np.array(df[target], dtype=object)

        if dtype in ("str", "bool"):
            non_missing = np.array([v for v in values if not _is_missing(v)], dtype=object)
            unique, counts = np.unique(non_missing, return_counts=True) if non_missing.size else (np.array([]), np.array([]))
            value_counts = {
                str(k): int(v)
                for k, v in sorted(zip(unique.tolist(), counts.tolist()), key=lambda item: item[1], reverse=True)
            }
            task_guess = "classification"
            summary = {
                "target": target,
                "dtype": dtype,
                "task_guess": task_guess,
                "n_unique": len(value_counts),
                "value_counts": value_counts,
            }
        else:
            arr = np.array(df[target], dtype=np.float64)
            valid = arr[~np.isnan(arr)]
            unique = np.unique(valid)
            integer_like = all(float(v).is_integer() for v in unique) if unique.size else False
            task_guess = "classification" if (len(unique) <= 10 and integer_like) else "regression"
            summary = {
                "target": target,
                "dtype": dtype,
                "task_guess": task_guess,
                "n_unique": int(unique.size),
                "mean": float(np.mean(valid)) if valid.size else None,
                "std": float(np.std(valid)) if valid.size else None,
                "min": float(np.min(valid)) if valid.size else None,
                "max": float(np.max(valid)) if valid.size else None,
            }

        return json.dumps(summary, default=_json_safe, indent=2)
    except Exception as exc:
        return _error_json(str(exc))


def preprocess_data_tool(
    csv_text: str,
    target: str = "",
    scale: str = "standard",
    encode: str = "onehot",
    impute_numeric: str = "median",
    impute_categorical: str = "mode",
    sample_rows: int = 5,
) -> str:
    """
    Apply practical preprocessing (imputation, encoding, scaling) and return a
    transformed sample + operation log for agent reasoning.
    """
    try:
        if scale not in ("standard", "minmax", "none"):
            raise ValueError("scale must be 'standard', 'minmax', or 'none'.")
        if encode not in ("onehot", "none"):
            raise ValueError("encode must be 'onehot' or 'none'.")
        if impute_numeric not in ("median",):
            raise ValueError("impute_numeric currently supports: 'median'.")
        if impute_categorical not in ("mode",):
            raise ValueError("impute_categorical currently supports: 'mode'.")

        df = _load_csv_from_string(csv_text)
        features = [column for column in df.get_features() if column != target]

        transformed_columns = []
        transformed_feature_names = []
        operations = {}

        for column in features:
            dtype = df.dtypes.get(column, "str")
            operations[column] = {
                "dtype": dtype,
                "imputer": None,
                "encoder": None,
                "scaler": None,
            }

            if dtype in ("bool", "int", "float"):
                values = np.array(df[column], dtype=np.float64)
                missing_before = int(np.isnan(values).sum())

                imputer = SimpleImputer(strategy=MedianImputer())
                values = imputer.fit_transform(values)

                scaler = None
                if scale == "standard":
                    scaler = StandardScaler()
                    values = scaler.fit_transform(values)
                elif scale == "minmax":
                    scaler = MinMaxScaler()
                    values = scaler.fit_transform(values)

                transformed_columns.append(values)
                transformed_feature_names.append(column)

                operations[column].update(
                    {
                        "imputer": "median",
                        "missing_before": missing_before,
                        "missing_after": int(np.isnan(values).sum()),
                        "scaler": scale if scaler is not None else "none",
                    }
                )

            else:
                values = np.array(df[column], dtype=object)
                missing_before = int(sum(1 for value in values if _is_missing(value)))

                imputer = SimpleImputer(strategy=ModeImputer())
                values = imputer.fit_transform(values)

                if encode == "onehot":
                    encoder = OneHotEncoder(handle_unknown="ignore")
                    encoded = encoder.fit_transform(values)
                    names = encoder.get_feature_names(prefix=column)

                    transformed_columns.append(encoded)
                    transformed_feature_names.extend(names)

                    operations[column].update(
                        {
                            "imputer": "mode",
                            "encoder": "onehot",
                            "encoded_features": names,
                            "missing_before": missing_before,
                            "missing_after": int(sum(1 for value in values if _is_missing(value))),
                        }
                    )
                else:
                    transformed_columns.append(values)
                    transformed_feature_names.append(column)
                    operations[column].update(
                        {
                            "imputer": "mode",
                            "encoder": "none",
                            "missing_before": missing_before,
                            "missing_after": int(sum(1 for value in values if _is_missing(value))),
                        }
                    )

        if transformed_columns:
            matrix = np.column_stack(transformed_columns)
        else:
            matrix = np.empty((len(df), 0))

        n_rows = matrix.shape[0]
        sample_count = max(0, min(int(sample_rows), n_rows))
        transformed_sample = []
        for row_idx in range(sample_count):
            transformed_sample.append(
                {
                    transformed_feature_names[col_idx]: _json_safe_or_raw(matrix[row_idx, col_idx])
                    for col_idx in range(matrix.shape[1])
                }
            )

        target_info = None
        if target:
            if target not in df.get_features():
                raise ValueError(f"Target column '{target}' not found.")
            target_info = json.loads(target_insights_tool(csv_text=csv_text, target=target))

        payload = {
            "status": "ok",
            "n_samples": int(matrix.shape[0]),
            "n_transformed_features": int(matrix.shape[1]),
            "transformed_feature_names": transformed_feature_names,
            "operations": operations,
            "transformed_sample_rows": transformed_sample,
            "target_info": target_info,
        }
        return json.dumps(payload, default=_json_safe, indent=2)
    except Exception as exc:
        return _error_json(str(exc))


def preprocessing_decision_tool(csv_text: str, target: str = "") -> str:
    """
    Return agent-ready recommendations for preprocessing and next model action.
    """
    try:
        df = _load_csv_from_string(csv_text)
        missing_summary = _missing_summary_from_df(df)

        column_plan = {}
        for column in df.get_features():
            dtype = df.dtypes.get(column, "str")
            if dtype in ("bool", "int", "float"):
                column_plan[column] = {
                    "imputer": "median",
                    "scaler": "standard",
                    "encoder": "none",
                    "reason": "numeric column",
                }
            else:
                column_plan[column] = {
                    "imputer": "mode",
                    "scaler": "none",
                    "encoder": "onehot",
                    "reason": "categorical column",
                }

        target_decision = None
        if target:
            if target not in df.get_features():
                raise ValueError(f"Target column '{target}' not found.")
            target_decision = json.loads(target_insights_tool(csv_text=csv_text, target=target))

        task_guess = (target_decision or {}).get("task_guess", "auto")
        recommended_tool = "automl_tool" if target else "preprocess_data_tool"
        next_arguments = (
            {
                "csv_text": csv_text,
                "target": target,
                "task": task_guess,
                "search_strategy": "grid",
            }
            if target
            else {
                "csv_text": csv_text,
                "scale": "standard",
                "encode": "onehot",
            }
        )

        payload = {
            "status": "ok",
            "recommended_preprocessing": column_plan,
            "missing_summary": missing_summary,
            "target_decision": target_decision,
            "next_action": {
                "recommended_tool": recommended_tool,
                "arguments": next_arguments,
            },
        }
        return json.dumps(payload, default=_json_safe, indent=2)
    except Exception as exc:
        return _error_json(str(exc))


def list_tools_tool() -> str:
    """
    Return available tool names + schema for wrapper-based invocation.
    """
    return json.dumps(TOOL_SCHEMA, indent=2)


# =========================================================
# IronClaw wrapper
# IronClaw wrapper
# =========================================================

def ironclaw_tool_wrapper(tool_name: str, arguments: dict = None) -> str:
    """
    Dispatch to any registered tool by name.

    Parameters
    ----------
    tool_name : str
        Name of a tool in `TOOL_REGISTRY`.
    arguments : dict
        Keyword arguments for that tool.

    Returns
    -------
    str
        JSON string returned by the selected tool.
    """
    try:
        if tool_name not in TOOL_REGISTRY:
            raise ValueError(
                f"Unknown tool '{tool_name}'. Available tools: {sorted(TOOL_REGISTRY.keys())}"
            )
        args = arguments or {}
        if not isinstance(args, dict):
            raise ValueError("arguments must be a dict.")
        return TOOL_REGISTRY[tool_name](**args)
    except Exception as exc:
        return _error_json(str(exc))


def ironclaw_tool_wrapper_json(request_json: str) -> str:
    """
    JSON transport wrapper for runtimes that pass a single JSON payload.

    Expected format:
    {
      "tool_name": "eda_tool",
      "arguments": {"csv_text": "..."}
    }
    """
    try:
        request = json.loads(request_json)
        tool_name = request.get("tool_name")
        arguments = request.get("arguments", {})
        if not tool_name:
            raise ValueError("request_json must include 'tool_name'.")
        return ironclaw_tool_wrapper(tool_name=tool_name, arguments=arguments)
    except Exception as exc:
        return _error_json(str(exc))
def ironclaw_tool_wrapper(tool_name: str, arguments: dict = None) -> str:
    """
    Dispatch to any registered tool by name.

    Parameters
    ----------
    tool_name : str
        Name of a tool in `TOOL_REGISTRY`.
    arguments : dict
        Keyword arguments for that tool.

    Returns
    -------
    str
        JSON string returned by the selected tool.
    """
    try:
        if tool_name not in TOOL_REGISTRY:
            raise ValueError(
                f"Unknown tool '{tool_name}'. Available tools: {sorted(TOOL_REGISTRY.keys())}"
            )
        args = arguments or {}
        if not isinstance(args, dict):
            raise ValueError("arguments must be a dict.")
        return TOOL_REGISTRY[tool_name](**args)
    except Exception as exc:
        return _error_json(str(exc))


def ironclaw_tool_wrapper_json(request_json: str) -> str:
    """
    JSON transport wrapper for runtimes that pass a single JSON payload.

    Expected format:
    {
      "tool_name": "eda_tool",
      "arguments": {"csv_text": "..."}
    }
    """
    try:
        request = json.loads(request_json)
        tool_name = request.get("tool_name")
        arguments = request.get("arguments", {})
        if not tool_name:
            raise ValueError("request_json must include 'tool_name'.")
        return ironclaw_tool_wrapper(tool_name=tool_name, arguments=arguments)
    except Exception as exc:
        return _error_json(str(exc))


# =========================================================
# Registry + schema
# Registry + schema
# =========================================================

TOOL_REGISTRY = {
    "automl_tool": automl_tool,
    "automl_job_start_tool": automl_job_start_tool,
    "automl_job_status_tool": automl_job_status_tool,
    "eda_tool": eda_tool,
    "data_overview_tool": data_overview_tool,
    "target_insights_tool": target_insights_tool,
    "preprocess_data_tool": preprocess_data_tool,
    "preprocessing_decision_tool": preprocessing_decision_tool,
    "list_tools_tool": list_tools_tool,
    "cross_validate_tool": cross_validate_tool,
}

TOOL_SCHEMA = {
    "tools": [
        {
            "name": "automl_tool",
            "description": (
                "Runs an end-to-end AutoML pipeline (EDA → Preprocessing → "
                "Model Search → Evaluation) on CSV data and returns a JSON report."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "csv_text": {"type": "string", "description": "Raw CSV content as a string."},
                    "target": {"type": "string", "description": "Target column name."},
                    "task": {
                        "type": "string",
                        "enum": ["auto", "classification", "regression"],
                        "default": "auto",
                    },
                    "cv": {"type": "integer", "default": 3},
                    "test_size": {"type": "number", "default": 0.2},
                    "seed": {"type": "integer", "default": 42},
                    "search_strategy": {
                        "type": "string",
                        "enum": ["grid", "random"],
                        "default": "grid",
                    },
                    "random_iter": {"type": "integer", "default": 10},
                    "full_search": {
                        "type": "boolean",
                        "default": False,
                        "description": "When true, uses the full (slower) model grid. False uses timeout-safe search.",
                    },
                    "verbose": {"type": "boolean", "default": False},
                },
                "required": ["csv_text", "target"],
            },
        },
        {
            "name": "automl_job_start_tool",
            "description": "Starts async AutoML job and returns job_id immediately (for long full_search runs).",
            "parameters": {
                "type": "object",
                "properties": {
                    "csv_text": {"type": "string", "description": "Raw CSV content as a string."},
                    "target": {"type": "string", "description": "Target column name."},
                    "task": {"type": "string", "enum": ["auto", "classification", "regression"], "default": "auto"},
                    "cv": {"type": "integer", "default": 3},
                    "test_size": {"type": "number", "default": 0.2},
                    "seed": {"type": "integer", "default": 42},
                    "search_strategy": {"type": "string", "enum": ["grid", "random"], "default": "grid"},
                    "random_iter": {"type": "integer", "default": 10},
                    "full_search": {"type": "boolean", "default": True},
                    "verbose": {"type": "boolean", "default": False},
                },
                "required": ["csv_text", "target"],
            },
        },
        {
            "name": "automl_job_status_tool",
            "description": "Returns status/result of an async AutoML job by job_id.",
            "parameters": {
                "type": "object",
                "properties": {
                    "job_id": {"type": "string", "description": "Job id returned by automl_job_start_tool."},
                    "include_result": {"type": "boolean", "default": True},
                },
                "required": ["job_id"],
            },
        },
        {
            "name": "eda_tool",
            "description": "Runs full EDA inspection and returns a JSON report.",
            "parameters": {
                "type": "object",
                "properties": {
                    "csv_text": {"type": "string", "description": "Raw CSV content as a string."},
                },
                "required": ["csv_text"],
            },
        },
        {
            "name": "data_overview_tool",
            "description": "Returns shape, types, missing summary, and sampled rows.",
            "parameters": {
                "type": "object",
                "properties": {
                    "csv_text": {"type": "string", "description": "Raw CSV content as a string."},
                    "sample_rows": {"type": "integer", "default": 5},
                },
                "required": ["csv_text"],
            },
        },
        {
            "name": "target_insights_tool",
            "description": "Returns target-column diagnostics and inferred task hint.",
            "parameters": {
                "type": "object",
                "properties": {
                    "csv_text": {"type": "string", "description": "Raw CSV content as a string."},
                    "target": {"type": "string", "description": "Target column name."},
                },
                "required": ["csv_text", "target"],
            },
        },
        {
            "name": "preprocess_data_tool",
            "description": "Runs imputation/encoding/scaling and returns transformed sample + operation log.",
            "parameters": {
                "type": "object",
                "properties": {
                    "csv_text": {"type": "string", "description": "Raw CSV content as a string."},
                    "target": {"type": "string", "default": "", "description": "Optional target column to exclude from features."},
                    "scale": {"type": "string", "enum": ["standard", "minmax", "none"], "default": "standard"},
                    "encode": {"type": "string", "enum": ["onehot", "none"], "default": "onehot"},
                    "impute_numeric": {"type": "string", "enum": ["median"], "default": "median"},
                    "impute_categorical": {"type": "string", "enum": ["mode"], "default": "mode"},
                    "sample_rows": {"type": "integer", "default": 5},
                },
                "required": ["csv_text"],
            },
        },
        {
            "name": "preprocessing_decision_tool",
            "description": "Suggests per-column preprocessing and next model/tool action.",
            "parameters": {
                "type": "object",
                "properties": {
                    "csv_text": {"type": "string", "description": "Raw CSV content as a string."},
                    "target": {"type": "string", "default": "", "description": "Optional target column for task recommendation."},
                },
                "required": ["csv_text"],
            },
        },
        {
            "name": "cross_validate_tool",
            "description": "Runs K-fold cross validation for one or more models and returns per-fold metrics.",
            "parameters": {
                "type": "object",
                "properties": {
                    "csv_text": {"type": "string", "description": "Raw CSV content as a string."},
                    "target": {"type": "string", "description": "Target column name."},
                    "model": {
                        "oneOf": [
                            {"type": "string"},
                            {"type": "array", "items": {"type": "string"}}
                        ],
                        "description": "Model class name or list of model names (e.g. DecisionTreeClassifier) or fully-qualified import paths.",
                    },
                    "params": {"type": "object", "description": "Constructor params for the model.", "default": {}},
                    "task": {"type": "string", "enum": ["auto", "classification", "regression"], "default": "auto"},
                    "cv": {"type": "integer", "default": 5},
                    "seed": {"type": "integer", "default": 42},
                    "metrics": {"type": "array", "items": {"type": "string"}, "description": "List of metric names to compute (task-dependent)."},
                },
                "required": ["csv_text", "target", "model"],
            },
        },
        {
            "name": "list_tools_tool",
            "description": "Returns this tool schema so an agent can introspect available tools.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
        {
            "name": "ironclaw_tool_wrapper",
            "description": "Dispatches by tool_name to any registered GlassBox tool.",
            "parameters": {
                "type": "object",
                "properties": {
                    "tool_name": {"type": "string", "description": "A registered tool name."},
                    "arguments": {
                        "type": "object",
                        "description": "Arguments dict forwarded to the selected tool.",
                        "default": {},
                    },
                },
                "required": ["tool_name"],
            },
        },
        {
            "name": "ironclaw_tool_wrapper_json",
            "description": "JSON-transport dispatcher wrapper with request_json payload.",
            "parameters": {
                "type": "object",
                "properties": {
                    "request_json": {
                        "type": "string",
                        "description": "JSON string: {\"tool_name\": ..., \"arguments\": {...}}",
                    },
                },
                "required": ["request_json"],
            },
        },
    ]
}


# =========================================================
# Internal helpers
# Internal helpers
# =========================================================

def _load_csv_from_string(csv_text: str) -> DataFrame:
    return DataFrame.load_csv(StringIO(csv_text))


def _is_missing(value) -> bool:
    return value is None or (isinstance(value, float) and np.isnan(value))


def _json_safe(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError(f"Object of type {type(obj)} is not JSON serialisable.")


def _json_safe_or_raw(value):
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if np.isnan(value) else float(value)
    return value


def _missing_summary_from_df(df: DataFrame) -> dict:
    n_rows, _ = df.format()
    summary = {}
    for column in df.get_features():
        values = np.array(df[column], dtype=object)
        missing_count = int(sum(1 for value in values if _is_missing(value)))
        summary[column] = {
            "missing_count": missing_count,
            "missing_pct": round(100.0 * missing_count / n_rows, 2) if n_rows else 0.0,
        }
    return summary


def _resolve_task_hint(df: DataFrame, target: str, task: str) -> str:
    if task in ("classification", "regression"):
        return task

    dtype = df.dtypes.get(target, "str")
    if dtype in ("str", "bool"):
        return "classification"

    values = np.array(df[target], dtype=np.float64)
    valid = values[~np.isnan(values)]
    unique = np.unique(valid)
    if len(unique) <= 10 and all(float(value).is_integer() for value in unique):
        return "classification"
    return "regression"


def _timeout_safe_candidates(task: str):
    if task == "classification":
        return [
            (LogisticRegression, {"lr": [0.05, 0.1], "max_iters": [300, 600]}),
            (KNNClassifier, {"k": [3, 5, 7]}),
            (DecisionTreeClassifier, {"max_depth": [3, 5, None]}),
            (NaiveBayes, {}),
        ]

    return [
        (LinearRegression, {"lr": [0.01, 0.05], "epochs": [600, 1200]}),
        (KNNRegressor, {"k": [3, 5]}),
        (DecisionTreeRegression, {"max_depth": [3, 5, None]}),
    ]


def _error_json(message: str) -> str:
    return json.dumps({"status": "error", "message": str(message)}, indent=2)


def _build_summary(report: dict) -> str:
    task = report.get("task", "unknown")
    target = report.get("target", "the target")
    model = report.get("best_model", "unknown model")
    params = report.get("best_params", {})
    metrics = report.get("eval_metrics", {})
    fi = report.get("feature_importance", [])
    top_feature = fi[0]["feature"] if fi else "N/A"
    elapsed = report.get("elapsed_seconds", "?")

    if task == "classification":
        score_val = metrics.get("accuracy", "N/A")
        score_str = f"accuracy of {score_val:.2%}" if isinstance(score_val, float) else str(score_val)
    else:
        r2 = metrics.get("R2", "N/A")
        score_str = f"R² of {r2:.4f}" if isinstance(r2, float) else str(r2)

    params_str = ", ".join(f"{k}={v}" for k, v in params.items()) if params else "default settings"

    return (
        f"I trained a {task} model to predict '{target}'. "
        f"The best model was {model} ({params_str}), with {score_str}. "
        f"Top feature: '{top_feature}'. Pipeline finished in {elapsed} seconds."
    )


if __name__ == "__main__":
    import pathlib


    csv_path = pathlib.Path("data.csv")
    if csv_path.exists():
        csv_text = csv_path.read_text()
        print("=== list_tools_tool ===")
        print(list_tools_tool())
        print("\n=== ironclaw wrapper call: data_overview_tool ===")
        print(
            ironclaw_tool_wrapper(
                "data_overview_tool",
                {"csv_text": csv_text, "sample_rows": 2},
            )
        )
        print("=== list_tools_tool ===")
        print(list_tools_tool())
        print("\n=== ironclaw wrapper call: data_overview_tool ===")
        print(
            ironclaw_tool_wrapper(
                "data_overview_tool",
                {"csv_text": csv_text, "sample_rows": 2},
            )
        )
    else:
        print("data.csv not found — skipping smoke test.")
