import json

from mcp.server.fastmcp import FastMCP

from agent.tools import (
    TOOL_SCHEMA,
    automl_job_start_tool,
    automl_job_status_tool,
    automl_tool,
    data_overview_tool,
    eda_tool,
    ironclaw_tool_wrapper,
    list_tools_tool,
    preprocess_data_tool,
    preprocessing_decision_tool,
    target_insights_tool,
    cross_validate_tool,
)

mcp = FastMCP("glassboxai")


@mcp.tool(name="list_tools_tool", description="List all available GlassBox tools and their JSON schema.")
def list_tools() -> dict:
    return json.loads(list_tools_tool())


@mcp.tool(name="eda_tool", description="Run EDA report on CSV data.")
def eda(csv_text: str) -> dict:
    return json.loads(eda_tool(csv_text=csv_text))


@mcp.tool(name="data_overview_tool", description="Get compact shape/types/missing/sample overview.")
def data_overview(csv_text: str, sample_rows: int = 5) -> dict:
    return json.loads(data_overview_tool(csv_text=csv_text, sample_rows=sample_rows))


@mcp.tool(name="target_insights_tool", description="Get target-specific diagnostics and inferred task type.")
def target_insights(csv_text: str, target: str) -> dict:
    return json.loads(target_insights_tool(csv_text=csv_text, target=target))


@mcp.tool(name="preprocess_data_tool", description="Run preprocessing (impute/encode/scale) and return transformed sample.")
def preprocess_data(
    csv_text: str,
    target: str = "",
    scale: str = "standard",
    encode: str = "onehot",
    impute_numeric: str = "median",
    impute_categorical: str = "mode",
    sample_rows: int = 5,
) -> dict:
    return json.loads(
        preprocess_data_tool(
            csv_text=csv_text,
            target=target,
            scale=scale,
            encode=encode,
            impute_numeric=impute_numeric,
            impute_categorical=impute_categorical,
            sample_rows=sample_rows,
        )
    )


@mcp.tool(name="preprocessing_decision_tool", description="Return recommended preprocessing plan and next model action.")
def preprocessing_decision(csv_text: str, target: str = "") -> dict:
    return json.loads(preprocessing_decision_tool(csv_text=csv_text, target=target))


@mcp.tool(name="cross_validate_tool", description="Run K-fold cross validation for one or more models and return per-fold metrics.")
def cross_validate(
    csv_text: str,
    target: str,
    model,  # str or list[str]
    params: dict | None = None,
    task: str = "auto",
    cv: int = 5,
    seed: int = 42,
    metrics: list | None = None,
) -> dict:
    return json.loads(
        cross_validate_tool(csv_text=csv_text, target=target, model=model, params=params or {}, task=task, cv=cv, seed=seed, metrics=metrics)
    )


@mcp.tool(name="automl_tool", description="Run end-to-end AutoML and return model/evaluation report.")
def automl(
    csv_text: str,
    target: str,
    task: str = "auto",
    cv: int = 3,
    test_size: float = 0.2,
    seed: int = 42,
    search_strategy: str = "grid",
    random_iter: int = 10,
    full_search: bool = False,
    verbose: bool = False,
) -> dict:
    return json.loads(
        automl_tool(
            csv_text=csv_text,
            target=target,
            task=task,
            cv=cv,
            test_size=test_size,
            seed=seed,
            search_strategy=search_strategy,
            random_iter=random_iter,
            full_search=full_search,
            verbose=verbose,
        )
    )


@mcp.tool(name="automl_job_start_tool", description="Start async AutoML job and return job_id.")
def automl_job_start(
    csv_text: str,
    target: str,
    task: str = "auto",
    cv: int = 3,
    test_size: float = 0.2,
    seed: int = 42,
    search_strategy: str = "grid",
    random_iter: int = 10,
    full_search: bool = True,
    verbose: bool = False,
) -> dict:
    return json.loads(
        automl_job_start_tool(
            csv_text=csv_text,
            target=target,
            task=task,
            cv=cv,
            test_size=test_size,
            seed=seed,
            search_strategy=search_strategy,
            random_iter=random_iter,
            full_search=full_search,
            verbose=verbose,
        )
    )


@mcp.tool(name="automl_job_status_tool", description="Check async AutoML job status/result by job_id.")
def automl_job_status(job_id: str, include_result: bool = True) -> dict:
    return json.loads(
        automl_job_status_tool(
            job_id=job_id,
            include_result=include_result,
        )
    )


@mcp.tool(
    name="ironclaw_tool_wrapper",
    description="Generic dispatcher: call any registered GlassBox tool by name with arguments.",
)
def wrapper(tool_name: str, arguments: dict | None = None) -> dict:
    return json.loads(ironclaw_tool_wrapper(tool_name=tool_name, arguments=arguments or {}))


@mcp.resource("glassbox://tool-schema")
def tool_schema_resource() -> str:
    return json.dumps(TOOL_SCHEMA, indent=2)


if __name__ == "__main__":
    mcp.run(transport="stdio")
