"""Generated sync package."""
