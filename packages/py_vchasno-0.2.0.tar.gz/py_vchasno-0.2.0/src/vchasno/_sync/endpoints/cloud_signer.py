"""Cloud signer endpoints."""

from __future__ import annotations

from typing import Any

from vchasno._sync.endpoints._base import SyncEndpoint
from vchasno.models.cloud_signer import (
    CloudSignerRefresh,
    CloudSignerRefreshCheck,
    CloudSignerSession,
    CloudSignerSessionCheck,
    SignSession,
)


class SyncCloudSigner(SyncEndpoint):
    """Asynchronous cloud signer endpoint group."""

    def create_session(
        self, *, duration: int, client_id: str, use_refresh_token: bool = False
    ) -> CloudSignerSession:
        data = self._request(
            "POST",
            "/api/v2/cloud-signer/sessions/create",
            json={
                "duration": duration,
                "client_id": client_id,
                "use_refresh_token": use_refresh_token,
            },
        )
        return CloudSignerSession.model_validate(data)

    def check_session(self, *, auth_session_id: str) -> CloudSignerSessionCheck:
        data = self._request(
            "POST", "/api/v2/cloud-signer/sessions/check", json={"auth_session_id": auth_session_id}
        )
        return CloudSignerSessionCheck.model_validate(data)

    def check_refresh_session(self, *, auth_session_id: str) -> CloudSignerRefreshCheck:
        data = self._request(
            "POST", "/api/v2/cloud-signer/sessions/refresh/check", json={"auth_session_id": auth_session_id}
        )
        return CloudSignerRefreshCheck.model_validate(data)

    def refresh_token(self, *, auth_session_id: str, refresh_token: str) -> CloudSignerRefresh:
        data = self._request(
            "POST",
            "/api/v2/cloud-signer/sessions/refresh",
            json={
                "auth_session_id": auth_session_id,
                "refresh_token": refresh_token,
            },
        )
        return CloudSignerRefresh.model_validate(data)

    def sign_document(
        self,
        *,
        client_id: str,
        password: str,
        document_id: str,
        auth_session_token: str | None = None,
        access_token: str | None = None,
    ) -> None:
        """Sign a document using the cloud signer (Vchasno.KEP).

        Warning:
            ``password`` is the private-key password for your cloud signer (KEP).
            Ensure it is never logged or printed.  The SDK does **not** log
            request bodies, but consumer-side logging middleware may capture them.
        """
        body: dict[str, Any] = {"client_id": client_id, "password": password, "document_id": document_id}
        if auth_session_token is not None:
            body["auth_session_token"] = auth_session_token
        if access_token is not None:
            body["access_token"] = access_token
        self._request("POST", "/api/v2/cloud-signer/sessions/sign-document", json=body)

    def create_sign_session(
        self,
        *,
        document_id: str,
        edrpou: str,
        email: str,
        session_type: str,
        on_cancel_url: str | None = None,
        on_finish_url: str | None = None,
    ) -> SignSession:
        body: dict[str, Any] = {
            "document_id": document_id,
            "edrpou": edrpou,
            "email": email,
            "type": session_type,
        }
        if on_cancel_url is not None:
            body["on_cancel_url"] = on_cancel_url
        if on_finish_url is not None:
            body["on_finish_url"] = on_finish_url
        data = self._request("POST", "/api/v2/sign-sessions", json=body)
        return SignSession.model_validate(data)
