"""Generated sync endpoint modules."""
