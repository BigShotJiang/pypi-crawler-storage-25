"""
Consumer task pool implementation.
"""

import asyncio
from dataclasses import dataclass
import traceback

from event_collector import messagebus as bus
from event_collector.data import AsyncFunc, Error, ResultList
from event_collector.helpers import error_string, gen_unique_id
from event_collector.logger import AppLogger, get_logger
from event_collector.publisher import CollectorEvent, StopEvent
from event_collector.router import Router


@dataclass(slots=True)
class ConsumersInitialized(bus.Message):
    pass


@dataclass(slots=True)
class ConsumersShutDown(bus.Message):
    pass


@dataclass(slots=True)
class EventStarted(bus.Message):
    event: CollectorEvent


@dataclass(slots=True)
class EventFinished(bus.Message):
    event: CollectorEvent


@dataclass(slots=True)
class ConsumersAdded(bus.Message):
    num: int
    target: int


@dataclass(slots=True)
class ConsumersDeleted(bus.Message):
    num: int
    target: int


CONSUMER_SHUTDOWN_TIMEOUT: float = 10.0
"""
Timeout value when stopping consumers.
If shutting down consumers takes more than this value,
the shutdown function will shut down the event_queue
and cause all consumers to stop immediately.
"""

DELETE_CONSUMER_WAIT_TIMEOUT: float = 10.0
"""Timeout value when deleting consumers."""


class ConsumerPool:
    """The ConsumerPool manages background consumer tasks."""

    def __init__(
        self,
        event_queue: asyncio.Queue,
        router: Router,
        bus: bus.MessageBus,
        consumer_shutdown_timeout: float = CONSUMER_SHUTDOWN_TIMEOUT,
    ) -> None:
        unique_id = gen_unique_id()
        self.id = f"{type(self).__name__}-{unique_id}"
        self.log: AppLogger = get_logger(self.id)

        self.event_queue = event_queue
        """an asyncio.Queue"""

        self.router = router
        """a Router instance to handle event payloads"""

        self.bus = bus
        """the MessageBus instance to send BusEvents to"""

        self.consumer_shutdown_timeout = consumer_shutdown_timeout
        """Timeout value when shutting down"""

        self.consumers: dict[str, asyncio.Task] = {}
        """Registry to keep track of consumer asyncio.Tasks"""

        self._consumer_id_count: int = 0
        """Counter for creating consumer ids"""

        self._busy: int = 0
        """The number of consumer tasks currently busy processing events"""

        self._registry_lock = asyncio.Lock()
        """Used by the create and delete methods to prevent conflicts."""

        self._is_running: bool = False
        """Flag indicating that we have initialized."""

    def count(self) -> int:
        return len(self.consumers)

    def busy(self) -> int:
        return self._busy

    def _new_consumer_id(self) -> str:
        """
        Every consumer task is assigned a unique ID string
        ("cid-N"). The "cid" is used as a key to store the consumer
        task in the task registry dict.
        """
        self._consumer_id_count += 1
        cid = f"cid-{self._consumer_id_count}"
        return cid

    def _done_callback(self, task: asyncio.Task) -> None:
        """A generic done callback function for asyncio tasks."""
        try:
            task.exception()
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.log.error(f"task {task.get_name()} got exception", exc=e)

    def _create_async_task(self, func: AsyncFunc, name: str) -> asyncio.Task:
        """Create an async task and add done_callback."""
        task: asyncio.Task = asyncio.create_task(func, name=name)
        task.add_done_callback(self._done_callback)
        return task

    async def create(self, n: int) -> None:
        """Create "n" number of consumer tasks."""
        if n <= 0:
            return

        await self._registry_lock.acquire()
        try:
            target = self.count()
            for _ in range(n):
                cid = self._new_consumer_id()
                task = self._create_async_task(self._consume(cid), name=cid)
                self.consumers[cid] = task
                target += 1
        finally:
            await self.bus.dispatch(ConsumersAdded(num=n, target=target))
            self._registry_lock.release()

    async def delete(self, n: int) -> None:
        """Delete "n" number of consumer tasks. If n is greater than
        the current consumer count, then set n to current consumer
        count. This method waits for the consumer registry to
        reconcile after deletes before returning to ensure the
        consumer count is correct."""
        if n <= 0:
            return

        await self._registry_lock.acquire()
        try:
            initial = self.count()
            if n > initial:
                n = initial

            wait = 0

            for _ in range(n):
                try:
                    await self.event_queue.put(StopEvent)
                    wait += 1
                except asyncio.QueueShutDown:
                    break

            timeout = DELETE_CONSUMER_WAIT_TIMEOUT
            target = initial - wait

            try:
                async with asyncio.timeout(timeout):
                    while self.count() > target:
                        await asyncio.sleep(0)
            except TimeoutError:
                await self.log.aerror(
                    "delete consumer waiter timed out",
                    timeout=timeout,
                    delete=n,
                    target=target,
                )

        finally:
            await self.bus.dispatch(ConsumersDeleted(num=n, target=target))
            self._registry_lock.release()

    async def _consume(self, cid: str) -> None:
        """
        The "_consume" background task pulls `CollectorEvent` objects
        off the `event_queue` and forwards the payloads to the event
        processing function (`_process_event`).
        """
        try:
            while True:
                event = await self.event_queue.get()
                if event is StopEvent:
                    self.event_queue.task_done()
                    break

                try:
                    await self._process_event(event)
                finally:
                    self.event_queue.task_done()

        except (asyncio.CancelledError, asyncio.QueueShutDown):
            pass
        except Exception as e:
            details = traceback.format_exc()
            await self.log.aerror("consumer exception", exc=e, details=details)
        finally:
            self._consumer_stopped(cid)

    async def _process_event(self, event: CollectorEvent) -> None:
        """
        Call the router's "handle_event" method with the event payload
        and update the CollectorEvent's result. If an error occurs,
        add the error as an Error object to a ResultList and set the
        CollectorEvent's result to the ResultList.
        """
        result_list = ResultList()
        try:
            await self._start_event(event)
            result_list = await self.router.handle_event(event.payload)
        except Exception as e:
            result_list.append(Error(error_string(e)))
        finally:
            await self._finish_event(event, result_list)

    async def _start_event(self, event: CollectorEvent) -> None:
        """Called when a consumer starts an event."""
        self._busy += 1
        event.start_event()
        await self.bus.dispatch(EventStarted(event))

    async def _finish_event(
        self, event: CollectorEvent, result: ResultList
    ) -> None:
        """Called when a consumer finishes an event."""
        event.set_result(result)
        self._busy -= 1
        await self.bus.dispatch(EventFinished(event))

    def _consumer_stopped(self, cid: str) -> None:
        """Unregister consumer after it's stopped."""
        del self.consumers[cid]

    async def _cancel_task(self, task: asyncio.Task) -> None:
        """Force cancel a task (used in shut_down)."""
        if not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception as e:
                await self.log.aerror("task cancel exception", exc=e)

    async def initialize(self, num: int) -> None:
        """Initialize consumer tasks."""
        if self._is_running:
            return

        await self.create(num)
        self._is_running = True
        await self.bus.dispatch(ConsumersInitialized())

    async def shut_down(self) -> None:
        """
        Shut down consumer tasks. To shut down consumers, we send a
        "StopEvent" sentinel payload to each consumer and wait for all
        consumers and background tasks to finish and return before
        calling it quits. But if self.consumer_shutdown_timeout is set
        and > 0, the consumer shutdown operations will run with a
        timeout using asyncio.timeout().
        """
        if not self._is_running:
            return

        timeout: float | None = None
        if self.consumer_shutdown_timeout > 0:
            timeout = self.consumer_shutdown_timeout

        try:
            async with asyncio.timeout(timeout):
                await self.delete(self.count())
                while True:
                    tasks = [
                        task
                        for task in self.consumers.values()
                        if not task.done()
                    ]
                    if len(tasks) == 0:
                        break
                    for task in tasks:
                        await self._cancel_task(task)
                        del self.consumers[task.get_name()]
        except TimeoutError:
            await self.log.aerror(
                "consumer shutdown timed out", timeout=timeout
            )

        self.consumers.clear()
        self._is_running = False
        await self.bus.dispatch(ConsumersShutDown())
