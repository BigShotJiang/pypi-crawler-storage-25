"""
event-collector exceptions.
"""


class EventCollectorException(Exception):
    """
    Base exception class for event-collector exceptions.
    """


class ConfigError(EventCollectorException):
    """
    Raised when configuration values are missing or incorrect.
    """
