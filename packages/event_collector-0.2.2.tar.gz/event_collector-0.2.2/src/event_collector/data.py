"""
Base data structures and data-related helper functions.
"""

from typing import (
    Any,
    Awaitable,
    Callable,
    cast,
    Coroutine,
    Iterator,
    NoReturn,
    Sequence,
)

from collections import UserList
import enum
import traceback


type AsyncFunc = Coroutine[Any, Any, Any]

type MonotonicTime = int
type TimeInterval = float
type Count = int
type ComputedValue = float

type Record = dict[str, Any]


class Ok[T]:
    __match_args__ = ("value",)

    __slots__ = ["value", "is_error"]

    def __init__(self, value: T) -> None:
        self.value: T = value
        self.is_error = False

    def error(self) -> bool:
        """Returns False."""
        return self.is_error

    def ok(self) -> bool:
        """Returns True."""
        return not self.is_error

    def unwrap(self) -> T:
        """The ``unwrap`` function returns the value set when the
        ``Ok`` object was initialized."""
        return self.value

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Ok value='{self.value}'>"


class Error[E: (Exception, str)]:
    __match_args__ = ("err",)

    __slots__ = ["err", "details", "is_error"]

    def __init__(self, err: E, details: dict[str, Any] | None = None) -> None:
        self.err: E = err
        self.is_error: bool = True
        self.details = details

    def error(self) -> bool:
        """Returns True."""
        return self.is_error

    def ok(self) -> bool:
        """Returns False."""
        return not self.is_error

    @property
    def value(self) -> None:
        return None

    def unwrap(self) -> NoReturn:
        """The ``unwrap`` function will raise a ``RuntimeError`` or
        the exception that was set when the ``Error`` object was
        initialized."""
        if not isinstance(self.err, Exception):
            raise RuntimeError(str(self.err))
        else:
            raise cast(Exception, self.err)

    def __repr__(self) -> str:  # pragma: no cover
        """
        Examples:

            >>> from event_collector.data import Error
            >>> result = Error(ValueError("bad input"))
            >>> result
            <Error err='bad input' details=None>
            >>> result = Error("bad input")
            >>> result
            <Error err='bad input' details=None>
            >>> result = Error(ValueError)
            >>> result
            <Error err='<class "ValueError">' details=None>

        """
        if isinstance(self.err, str):
            return f"<Error err='{self.err}' details={self.details}>"
        elif isinstance(self.err, Exception):
            return f"<Error err='{self.err}' details={self.details}>"
        else:
            err = repr(self.err).replace("'", '"')
            return f"<Error err='{err}' details={self.details}>"


type Result = Ok | Error


class ResultList(UserList):
    """
    A ``ResultList`` is a container for a collection of Result
    objects.  ``ResultList`` is a subclass of collections.UserList, so
    it has the behavior of a list. In addition, "ResultList.iter"
    returns a generator that the caller can iterate with to get each
    Result.  The "ResultList.first" method will return the first
    Result in the list.  This is a convenience for callers that expect
    only one Result being returned. And "ResultList.size" is the
    same as ``len(ResultList)``.
    """

    __slots__ = ["data"]

    def __init__(self, results: Sequence[Result] | None = None) -> None:
        if results is None:
            results = []
        super().__init__(results)

    @property
    def results(self) -> list[Result]:
        """The list of Result objects."""
        return self.data

    def first(self) -> Result:
        """Return the first Result in the Result list, or an Error if
        the list is empty."""
        try:
            return self.data[0]
        except IndexError:
            return Error("result list is empty")

    def iter(self) -> Iterator[Result]:
        """Return a generator to access the Result list."""
        for result in self:
            yield result

    def size(self) -> int:
        """Return the size of the Result list."""
        return len(self.data)


async def abind(f: Callable[..., Awaitable[Any]], *args, **kwargs) -> Result:
    """
    Bind async function to arguments and ensure return value is a
    Result object.
    """

    def _traceback(ex: Exception) -> str:
        return "".join(
            traceback.format_exception(None, ex, ex.__traceback__)
        ).strip()

    try:
        result = await f(*args, **kwargs)
        if isinstance(result, (Ok, Error)):
            return result
        else:
            return Ok(result)
    except Exception as e:
        details = {
            "func": f,
            "args": args,
            "kwargs": kwargs,
            "exc": e,
            "trace": _traceback(e),
        }
        return Error(e, details=details)


class Delivery(enum.Enum):
    BROADCAST = 0
    KEY = 1
    TOPIC = 2


class Payload[T]:
    """
    The ``Payload`` object is a wrapper for a value. The Payload also
    carries metadata about how to deliver the payload.
    """

    __slots__ = [
        "_value",
        "delivery",
        "keys",
        "topics",
        "priority",
    ]

    def __init__(
        self,
        value: T,
        delivery: Delivery = Delivery.BROADCAST,
        keys: Sequence[str] | None = None,
        topics: Sequence[str] | None = None,
        priority: int | None = None,
    ) -> None:
        self._value: T = value
        self.delivery: Delivery = delivery
        self.keys: Sequence[str] = keys if keys is not None else []
        self.topics: Sequence[str] = topics if topics is not None else []
        self.priority: int | None = priority

    @property
    def value(self) -> T:
        return self._value

    def set_delivery(
        self,
        delivery: Delivery,
        keys: Sequence[str] | None = None,
        topics: Sequence[str] | None = None,
    ) -> None:
        """Set the delivery mode, the collector keys (if delivery mode
        is ``Delivery.KEY``), and topics (if delivery mode is
        ``Delivery.TOPIC``)."""
        self.delivery = delivery

        if keys is not None:
            self.keys = keys

        if topics is not None:
            self.topics = topics

    def set_priority(self, priority: int) -> None:
        """
        Set the priority level (if using a priority queue).
        """
        self.priority = priority

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<{type(self).__name__} "
            f"value={self.value} "
            f"delivery_mode={self.delivery} "
            f"keys={self.keys} "
            f"topics={self.topics} "
            f"priority={self.priority}>"
        )


class Undefined:  # pragma: no cover
    """
    A class to represent an undefined object or value.
    """

    pass


class Context:
    """
    An object to store application-specific values.

    Based on the ``State`` class in Starlette.
    https://github.com/Kludex/starlette/blob/main/starlette/datastructures.py
    """

    _data: dict[str, Any]

    def __init__(self, data: dict[str, Any] | None = None) -> None:
        if data is None:
            data = {}
        super().__setattr__("_data", data)

    def __setattr__(self, key: str, val: Any) -> None:
        if key:
            self._data[key] = val

    def __getattr__(self, key: str) -> Any:
        try:
            return self._data[key]
        except KeyError:
            raise AttributeError(
                f"attribute {key} not found in {type(self).__name__}"
            )

    def __delattr__(self, key: str) -> None:
        if key in self._data:
            del self._data[key]

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, val: Any) -> None:
        self._data[key] = val

    def __delitem__(self, key: str) -> None:
        del self._data[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"<{type(self).__name__}: {self._data}>"
