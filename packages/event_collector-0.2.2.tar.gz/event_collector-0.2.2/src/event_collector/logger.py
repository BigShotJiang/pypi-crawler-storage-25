"""
Log management module.
"""

from typing import Any

import logging
import os

try:  # pragma: no cover
    import orjson as json

    use_orjson = True
except ImportError:  # pragma: no cover
    import json  # type: ignore[no-redef]

    use_orjson = False

import structlog


type AppLogger = structlog.types.WrappedLogger | NullLogger
type AppLoggerDict = dict[str, AppLogger]

LOGGER_NAME = "event-collector"
DEFAULT_LOG_LEVEL = "INFO"
"""
If ``LOG_LEVEL`` is not exported as an environment variable,
the default log level will be set using this value.
"""

ENV_DEBUG_KEY = "DEBUG"
ENV_LOG_LEVEL_KEY = "LOG_LEVEL"


def get_log_level() -> str:
    """
    Get default log level from environment. Log level is based on
    exported LOG_LEVEL variable or use default log level if no log
    level is defined. If DEBUG is exported and is one of ("true",
    "yes", "1"), then set log level to "debug."  Returns log level as
    lowercase string.
    """
    level_name: str = ""

    debug = str(os.getenv(ENV_DEBUG_KEY))
    if debug.lower() in ("true", "yes", "1"):
        level_name = "debug"

    if not level_name:
        level_name = str(os.getenv(ENV_LOG_LEVEL_KEY) or DEFAULT_LOG_LEVEL)

    level_names_map = logging.getLevelNamesMapping()
    if level_name.upper() not in level_names_map:
        level_name = DEFAULT_LOG_LEVEL

    return level_name.lower()


class LogRegistry:
    """A registry to store all structlog bound loggers identified by name."""

    def __init__(self, default_name: str, log_level: str) -> None:
        self.loggers: AppLoggerDict = {}
        self.default_name: str = default_name
        self.default_logger: structlog.types.WrappedLogger = (
            structlog.get_logger()
        )
        self.init_logger(log_level=log_level)

    def init_logger(self, log_level: str = DEFAULT_LOG_LEVEL) -> None:
        """Initialize logger by configuring *structlog*."""
        structlog.configure(
            wrapper_class=structlog.make_filtering_bound_logger(log_level),
            processors=[
                structlog.contextvars.merge_contextvars,
                structlog.processors.add_log_level,
                structlog.processors.format_exc_info,
                structlog.processors.TimeStamper(fmt="iso", utc=True),
                structlog.processors.JSONRenderer(serializer=json.dumps),
            ],
            logger_factory=(
                structlog.BytesLoggerFactory() if use_orjson else None
            ),
        )
        self.add_logger(self.default_name)

    def add_logger(self, name: str) -> AppLogger:
        """Add a logger and bound to ``name``."""
        logger = self.default_logger.bind(logger=name)
        self.loggers[name] = logger
        return logger

    def get_logger(self, name: str | None = None) -> AppLogger:
        """
        Return a logger bound to ``name`` or create a new logger
        if no logger exists with ``name`` as key. This method is
        called by the ``get_logger`` function.
        """
        logger_name: str = name if name else self.default_name

        if logger_name in self.loggers:
            return self.loggers[logger_name]

        return self.add_logger(logger_name)


class NullLogger:
    """A logger that discards input and produces no output."""

    def __getattr__(self, method: str) -> Any:
        if method.startswith("a"):
            return self.async_null_method
        else:
            return self.null_method

    def null_method(self, *args, **kwargs) -> None:
        pass

    async def async_null_method(self, *args, **kwargs) -> None:
        pass


log_registry: LogRegistry | None = None
null_logger = NullLogger()


def set_log_registry(registry: LogRegistry) -> None:
    """Use registry as the default LogRegistry."""
    global log_registry
    log_registry = registry


def get_log_registry() -> LogRegistry | None:
    """Return the global LogRegistry instance."""
    return log_registry


def get_logger(name: str | None = None, is_null: bool = False) -> AppLogger:
    """
    Returns a *structlog* logger. If name is not supplied, logger
    will output using the default name (defined in ``LOGGER_NAME``).

    When first called, will initialize a global ``LogResgistry``
    instance and create a default *struclog* logger.

    If ``is_null`` is True, return a ``NullLogger``.
    """
    global log_registry, null_logger

    if is_null:
        return null_logger

    if not log_registry:
        log_registry = LogRegistry(LOGGER_NAME, get_log_level())

    return log_registry.get_logger(name)
