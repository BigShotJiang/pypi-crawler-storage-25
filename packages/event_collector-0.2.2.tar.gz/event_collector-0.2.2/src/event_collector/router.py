"""
Event router definitions.
"""

from typing import Any, Sequence

from abc import ABC, abstractmethod
import asyncio
from collections import defaultdict

from event_collector.collector import Collector, CollectorDict
from event_collector.data import (
    abind,
    Delivery,
    Error,
    Ok,
    Payload,
    ResultList,
)
from event_collector.helpers import error_string, gen_unique_id
from event_collector.logger import get_logger


class Router(ABC):
    def __init__(self, collectors: CollectorDict | None = None) -> None:
        self.collectors: CollectorDict = (
            collectors if collectors is not None else {}
        )

    @abstractmethod
    async def handle_event(
        self, payload: Payload
    ) -> ResultList:  # pragma: no cover
        """
        The ``handle_event`` method should implement logic to dispatch
        an event payload to one or more collectors. The return value
        must be a ``ResultList``.
        """


type CollectorSet = set[Collector]
type TopicHandlerDict = dict[str, CollectorSet]


class SimpleRouter(Router):
    """
    The ``SimpleRouter`` is the default router used by the collector
    queue to handle payload dispatching. This router handles the 3
    delivery modes implemented by the collector queue: direct key,
    topics, and broadcast. The ``handle_event`` ensures that all event
    payloads sent to the collectors return valid ``Result`` object(s).
    """

    def __init__(self, collectors: CollectorDict | None = None) -> None:
        super().__init__(collectors)

        unique_id = gen_unique_id()
        self.id = f"{type(self).__name__}-{unique_id}"
        self.log = get_logger(self.id)

        self.topic_handlers = self.get_topic_handlers(self.collectors)

    def get_topic_handlers(self, collectors: CollectorDict) -> TopicHandlerDict:
        handlers: TopicHandlerDict = defaultdict(set)

        for key, collector in collectors.items():
            if collector.topics:
                for topic in collector.topics:
                    handlers[topic].add(collector)

        return handlers

    async def handle_event(self, payload: Payload) -> ResultList:
        """
        Handle incoming event payload by sending payload to collectors
        using the payload's delivery mode.

        This method will return a ResultList, because, depending on the
        delivery mode, the event payload will be sent to one or more
        collectors. So it's valid to have multiple return values.
        """
        collectors: CollectorSet = set()

        match payload.delivery:
            case Delivery.KEY:
                for key in payload.keys:
                    collector = self.collectors.get(key)
                    if collector:
                        collectors.add(collector)

            case Delivery.TOPIC:
                for topic in payload.topics:
                    cs: CollectorSet = self.topic_handlers.get(topic, set())
                    collectors.update(cs)

            case Delivery.BROADCAST:
                collectors = set(self.collectors.values())

        result_list: ResultList

        if len(collectors) == 1:
            collector = collectors.pop()
            result = await abind(collector.process, payload)
            result_list = self.gather_results([result])
        elif len(collectors) > 1:
            result_list = await self.async_collector_process(
                payload, collectors
            )
        else:
            result_list = ResultList()

        return result_list

    def gather_results(self, results: Sequence[Any]) -> ResultList:
        """
        Results is a list of asyncio.Task return values. This function
        ensures each item in the list is a valid Result, stores each
        item in a list, then returns the list of Result objects
        wrapped in a ResultList.
        """
        result_list = ResultList()

        for result in results:
            if isinstance(result, (Ok, Error)):
                result_list.append(result)
            else:
                msg = f"collector must return Result, got {result}"
                result_list.append(Error(msg))

        return result_list

    async def async_collector_process(
        self, payload: Payload, collectors: CollectorSet
    ) -> ResultList:
        """
        Send payload to a set of collectors -- for len(collectors) > 1
        -- using async tasks.
        """
        result_list: ResultList

        try:
            task_list: list[asyncio.Task] = []
            for collector in collectors:
                name = collector.key
                coro = abind(collector.process, payload)
                task = asyncio.create_task(coro, name=name)
                task_list.append(task)

            task_results = await asyncio.gather(
                *task_list, return_exceptions=True
            )

        except* Exception as e:
            result_list = ResultList()
            result_list.append(Error(error_string(e)))
        else:
            result_list = self.gather_results(task_results)

        return result_list
