"""
Utility functions and constants.
"""

from typing import Any

import datetime
import traceback
import uuid

import orjson


TIMESTAMP_FORMAT_FRAC = "%Y-%m-%dT%H:%M:%S.%fZ"
TIMESTAMP_FORMAT_TZ = "%Y-%m-%dT%H:%M:%S%z"
VALID_TIMESTAMP_FORMATS = [
    TIMESTAMP_FORMAT_FRAC,
    TIMESTAMP_FORMAT_TZ,
]


def current_timestamp(fmt: str = TIMESTAMP_FORMAT_FRAC) -> str:
    """
    Return current timestamp.

    :param fmt: timestamp string format
    :returns: current UTC timestamp (str)
    """
    timestamp = datetime.datetime.now(datetime.timezone.utc)
    return timestamp.strftime(fmt)


def parse_timestamp(timestamp: str) -> datetime.datetime:
    """
    Parse a timestamp string and return a datetime object.
    """
    dt = None

    for fmt in VALID_TIMESTAMP_FORMATS:
        try:
            dt = datetime.datetime.strptime(timestamp, fmt)
        except ValueError:
            pass

    if dt:
        return dt.replace(tzinfo=datetime.timezone.utc)

    raise ValueError(f"cannot parse timestamp: {timestamp}")


def now() -> datetime.datetime:
    """
    Return a datetime object for 'now' in UTC.
    """
    return datetime.datetime.now(datetime.timezone.utc)


def json_loads(s: str) -> dict[str, Any]:
    """
    Wrapper for orjson.loads.
    """
    try:
        data = orjson.loads(s)
    except orjson.JSONDecodeError as exc:
        raise ValueError(str(exc))
    return data


def json_dumps(s: dict[str, Any]) -> str:
    """
    Wrapper for orjson.dumps.
    """
    data = orjson.dumps(s)
    return data.decode("utf-8")


def gen_unique_id() -> str:
    """
    Generate a unique id.
    """
    return uuid.uuid4().hex


# Source - https://stackoverflow.com/a/76333127
# Posted by winwin
# Retrieved 2026-04-11, License - CC BY-SA 4.0


def error_string(ex: Exception) -> str:
    return "\n".join(
        [
            "".join(traceback.format_exception_only(None, ex)).strip(),
            "".join(
                traceback.format_exception(None, ex, ex.__traceback__)
            ).strip(),
        ]
    )
