"""
A Collector is a pipeline for processing events.
"""

from typing import Awaitable, Sequence

from collections.abc import Callable, Mapping
from contextlib import AbstractAsyncContextManager

from event_collector.data import Context, Payload, Result


type CollectorList = Sequence[Collector]
type CollectorDict = Mapping[str, Collector]

type Processor = Callable[[Payload, Context], Awaitable[Result]]
type LifecycleManager = Callable[[Context], AbstractAsyncContextManager[None]]


class Collector:
    def __init__(
        self,
        key: str,
        processor: Processor,
        *,
        topics: Sequence[str] | None = None,
        ctx: Context | None = None,
        lifecycle: LifecycleManager | None = None,
    ) -> None:
        assert len(key) > 0, "Key cannot be empty"
        assert callable(processor), "Processor must be callable"

        self.key: str = key
        """The collector key is used for routing event payloads by direct key."""

        self.processor: Processor = processor
        """The processor is the event handler."""

        self.topics: Sequence[str] = topics if topics is not None else []
        """Topics is a list of topics the collector is listening to."""

        self.ctx: Context = ctx if ctx is not None else Context()
        """The Context object is used for storing application-specific values."""

        self.lifecycle: LifecycleManager | None = lifecycle
        """The lifecycle async context manager is used to run setup
        and shutdown operations."""

    async def process(self, payload: Payload) -> Result:
        """Process an event payload."""
        return await self.processor(payload, self.ctx)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} key={self.key} ctx={self.ctx}>"
