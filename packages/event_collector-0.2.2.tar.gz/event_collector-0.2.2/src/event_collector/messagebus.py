"""
Message bus implementation.
"""

from typing import Awaitable, Callable, TypeAlias, TypeVar

from collections import defaultdict, deque


class Message:
    pass


class Command:
    pass


T_Message = TypeVar("T_Message", bound=Message)
T_Command = TypeVar("T_Command", bound=Command)

BusEvent = TypeVar("BusEvent", Message, Command)
BusEventQueue = deque[BusEvent]

AsyncMsgHandler: TypeAlias = Callable[
    [T_Message, BusEventQueue], Awaitable[None]
]
AsyncCmdHandler: TypeAlias = Callable[
    [T_Command, BusEventQueue], Awaitable[None]
]

MsgHandlers: TypeAlias = dict[type[T_Message], list[AsyncMsgHandler]]
CmdHandlers: TypeAlias = dict[type[T_Command], AsyncCmdHandler]


class MessageBus[BusEvent]:
    def __init__(
        self,
        msg_handlers: MsgHandlers | None = None,
        cmd_handlers: CmdHandlers | None = None,
    ) -> None:
        if msg_handlers is None:
            msg_handlers = {}

        self.msg_handlers: MsgHandlers = defaultdict(list)
        for msg, handlers in msg_handlers.items():
            for handler in handlers:
                self.add_msg_handler(msg, handler)

        if cmd_handlers is None:
            cmd_handlers = {}

        self.cmd_handlers: CmdHandlers = {}
        for cmd, handler in cmd_handlers.items():
            self.add_cmd_handler(cmd, handler)

    def add_msg_handler(
        self, msg: type[T_Message], handler: AsyncMsgHandler
    ) -> None:
        if issubclass(msg, Message) and callable(handler):
            self.msg_handlers[msg].append(handler)

    def del_msg_handler(self, msg: type[T_Message]) -> None:
        if msg in self.msg_handlers and len(self.msg_handlers[msg]) > 0:
            del self.msg_handlers[msg]

    def add_cmd_handler(
        self, cmd: type[T_Command], handler: AsyncCmdHandler
    ) -> None:
        if issubclass(cmd, Command) and callable(handler):
            self.cmd_handlers[cmd] = handler

    def del_cmd_handler(self, cmd: type[T_Command]) -> None:
        if cmd in self.cmd_handlers:
            del self.cmd_handlers[cmd]

    async def dispatch(self, evt: BusEvent) -> None:
        queue: BusEventQueue = deque([evt])
        while len(queue) > 0:
            evt = queue.popleft()
            match evt:
                case Message():
                    await self._handle_msg(evt, queue)
                case Command():
                    await self._handle_cmd(evt, queue)
                case _:
                    break

    async def _handle_msg(self, msg: T_Message, queue: BusEventQueue) -> None:
        for handler in self.msg_handlers[type(msg)]:
            await handler(msg, queue)

    async def _handle_cmd(self, cmd: T_Command, queue: BusEventQueue) -> None:
        try:
            handler = self.cmd_handlers[type(cmd)]
            await handler(cmd, queue)
        except KeyError:
            pass
