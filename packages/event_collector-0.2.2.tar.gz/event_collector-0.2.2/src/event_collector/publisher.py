"""
Definitions for CollectorEvent and EventPublisher.
"""

from __future__ import annotations

from typing import Awaitable, Callable, cast

import asyncio
import enum
import time


from event_collector.data import MonotonicTime, Payload, ResultList, Undefined


# CollectorEvent ID variables
event_id: int = 0
NoEventID: int = 0


def _gen_event_id() -> int:
    global event_id
    event_id += 1
    return event_id


DEFAULT_PRIORITY: int = 1000
"""Default priority level for a priority queue."""


class CollectorEvent:
    """
    A ``CollectorEvent`` is a container for an event payload and the
    event's result after processing. It's created automatically by
    the ``EventPublisher`` for each event payload sent to the collector
    queue.
    """

    __slots__ = [
        "id",
        "payload",
        "priority",
        "_result",
        "_finished",
        "_waiters",
        "_created_at",
        "_start_time",
        "_stop_time",
    ]

    def __init__(
        self,
        event_id: int,
        payload: Payload,
        *,
        priority: int = DEFAULT_PRIORITY,
    ) -> None:
        self.id = event_id
        self.payload = payload
        self.priority: int = priority

        self._result: ResultList
        self._finished: bool = False
        self._waiters: list[asyncio.Future] = []
        self._created_at: MonotonicTime = time.monotonic_ns()
        self._start_time: MonotonicTime = 0
        self._stop_time: MonotonicTime = 0

    def set_result(self, result: ResultList) -> None:
        if not self._finished:
            self._result = result
            self._finished = True
            self._stop_time = time.monotonic_ns()

            for fut in self._waiters:
                if not fut.done():
                    fut.set_result(True)

    def get_result(self) -> ResultList | None:
        """
        :returns: a ResultList or None if result is not yet available.
        """
        if not self._finished:
            return None

        return self._result

    def is_done(self) -> bool:
        return self._finished

    async def wait(self) -> ResultList:
        """
        Return the ResultList if the event is finished, or else create
        a ``Future`` object and await its completion.  This will block
        until the ``Future`` is marked as finished by a consumer
        setting its result.
        """
        if self._finished:
            return cast(ResultList, self.get_result())

        loop = asyncio.get_event_loop()
        fut = loop.create_future()
        self._waiters.append(fut)

        try:
            await fut
            return cast(ResultList, self.get_result())
        finally:
            self._waiters.remove(fut)

    def start_event(self) -> None:
        self._start_time = time.monotonic_ns()

    def service_time(self) -> MonotonicTime:
        """
        Return service_time (in nanoseconds) If event is not yet
        finished, return 0.
        """
        if not self._finished:
            return 0

        return self._stop_time - self._start_time

    def wait_time(self) -> MonotonicTime:
        """
        Return total processing time (in nanoseconds) from creation to
        stop. If event is not yet finished, return 0.
        """
        if not self._finished:
            return 0

        return self._stop_time - self._created_at

    def __lt__(self, other: CollectorEvent) -> bool:
        """Compare entries in a priority queue."""
        if self.priority == other.priority:
            return self._created_at < other._created_at

        return self.priority < other.priority

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<{type(self).__name__} "
            f"id={self.id} "
            f"priority={self.priority} "
            f"payload={self.payload} "
            f"is_done={self.is_done()}>"
        )


# "StopEvent" is a sentinel for signalling to consumers to shut down.
StopEvent: CollectorEvent = CollectorEvent(NoEventID, Payload(Undefined))


class QueueType(enum.Enum):
    FIFO = 0
    PRIORITY = 1
    LIFO = 2


type PayloadSender = Callable[..., Awaitable[CollectorEvent]]


class EventPublisher:
    """
    The ``EventPublisher`` is used to send events to the event queue.

    An ``EventPublisher`` is automatically created by the
    ``CollectorQueue`` at initialization so you do not need to create
    this manually. The ``CollectorQueue`` will also set the
    ``queue_type`` based on its input parameters.

    When the ``CollectorQueue`` is running, you can access the
    ``EventPublisher`` using the ``CollectorQueue.get_publisher``
    method. To send event payloads to the queue, use the
    ``EventPublisher.send``  method.
    """

    def __init__(
        self,
        event_queue: asyncio.Queue,
        *,
        queue_type: QueueType = QueueType.FIFO,
        default_priority: int = DEFAULT_PRIORITY,
    ) -> None:
        self.event_queue = event_queue
        self.queue_type = queue_type
        self.default_priority = default_priority

        self.send: PayloadSender
        match self.queue_type:
            case QueueType.PRIORITY:
                self.send = self._send_with_priority
            case _:
                self.send = self._send

    async def _send_with_priority(self, payload: Payload) -> CollectorEvent:
        event_id = _gen_event_id()

        priority: int
        if payload.priority is None:
            priority = self.default_priority
        else:
            priority = payload.priority

        event = CollectorEvent(
            event_id,
            payload,
            priority=priority,
        )
        await self.event_queue.put(event)
        return event

    async def _send(self, payload: Payload) -> CollectorEvent:
        event_id = _gen_event_id()
        event = CollectorEvent(event_id, payload)
        await self.event_queue.put(event)
        return event

    async def wait(self) -> None:
        """
        The ``wait`` method waits for all events to be processed and
        will block until all events sent the collector queue are
        processed.
        """
        await self.event_queue.join()

    def __repr__(self) -> str:  # pragma: no cover
        return f"<{type(self).__name__} event_queue={self.event_queue}>"
