"""
Create and run a publisher-consumer queue using only standard library
functions and asyncio primitives.
"""

from __future__ import annotations

from typing import Any, Callable, Tuple

import asyncio
import collections
import contextlib
import dataclasses
import datetime
import decimal as dec
import functools
import math
import time
import traceback

from event_collector import messagebus as bus
from event_collector.collector import (
    CollectorDict,
    CollectorList,
)
from event_collector.consumer import (
    CONSUMER_SHUTDOWN_TIMEOUT,
    ConsumerPool,
    ConsumersAdded,
    ConsumersDeleted,
    ConsumersInitialized,
    ConsumersShutDown,
    EventFinished,
)
from event_collector.data import (
    AsyncFunc,
    ComputedValue,
    Count,
    MonotonicTime,
    TimeInterval,
)
from event_collector.exceptions import ConfigError
from event_collector.helpers import gen_unique_id
from event_collector.logger import AppLogger, get_logger
from event_collector.publisher import (
    CollectorEvent,
    DEFAULT_PRIORITY,
    EventPublisher,
    QueueType,
)
from event_collector.router import (
    Router,
    SimpleRouter,
)


type GenericAsyncTaskFunc = Callable[..., AsyncFunc]


PRECISION = 4
"""Rounding precision."""

DEFAULT_PRECISION = 32
"""Default decimal module context precision."""

AVG_DATA_DECIMAL_PRECISION = 150
"""decimal module context precision value for AvgData data."""

DEFAULT_MIN_CONSUMERS = 1
"""Default min_consumer value."""

DEFAULT_MAX_CONSUMERS = 100000
"""Default max_consumer value."""

WIP_MARGIN: float = 0.15
"""
Margin to calculate additional consumers to add to
the average WIP task value (15%).
"""

REDUCTION_THRESHOLD: float = 0.75
"""If the average load value is below this threshold,
the collector queue will reduce the consumer pool size."""

MONITOR_INTERVAL: float = 0.01
"""Consumer monitor sleep interval (in seconds)."""

MIN_MONITOR_INTERVAL: float = 0.005
"""Minimum monitor interval (input below this maximum will be set to
this value)."""

MAX_MONITOR_INTERVAL: float = 0.1
"""Maximum monitor interval (input above this maximum will be set to
this value)."""

REPORT_INTERVAL: float = 0.0
"""Collector queue status report log interval (in seconds)."""

AVG_LOAD_INTERVAL: float = 60.0
"""Keep load values for this interval (in seconds) to calculate average load."""

MIN_AVG_LOAD_INTERVAL: float = 1.0
"""Minimum average load interval (input below this minimum will be
set to this value)."""

METRICS_WARMUP_INTERVAL: float = 3.0
"""Time to allow for metrics to stabilize on startup before reporting
actual values. In the warmup period, averages will return 0."""

METRICS_COLLECTOR_WINDOW_SIZE: float = 60.0
"""Keep arrival and departure data for this period (in seconds) to
calculate arrival and departure rates."""

MIN_METRICS_COLLECTOR_WINDOW_SIZE: float = 5.0
"""Minimum data collector window size (input below this minimum will be
set to this value)."""

METRICS_COLLECTOR_TASK_PERIOD: float = 0.1
"""metrics_collector periodic task interval (in seconds)."""

EVENT_SERVICE_DATA_WINDOW_SIZE: int = 1000
"""Keep this number of event service data points to calculate service and wait times."""

MIN_EVENT_SERVICE_DATA_WINDOW_SIZE: int = 10
"""Minimum event service data deque size."""

METRICS_HISTORY_SIZE: int = 1000
"""Queue metrics history size (number of queue metrics snapshots to
keep in sliding window)"""

MIN_METRICS_HISTORY_SIZE: int = 1
"""Minimum metrics history size."""


_localcontext_initialized: bool = False
_local_decimal_context: contextlib.AbstractContextManager = dec.localcontext()


def decimal_context() -> contextlib.AbstractContextManager:
    """Return decimal Context initialized with default precision."""
    global _localcontext_initialized, _local_decimal_context

    if not _localcontext_initialized:
        with _local_decimal_context as ctx:
            ctx.prec = DEFAULT_PRECISION

        _localcontext_decimal_initialized = True

    return _local_decimal_context


def with_decimal_context(func: Callable[..., Any]) -> Any:
    """Decorator for using local decimal context."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        with decimal_context():
            result = func(*args, **kwargs)
        return result

    return wrapper


def rd(value: dec.Decimal, prec: int = PRECISION) -> ComputedValue:
    """Round Decimal to float with precision."""
    return round(float(value), prec)


@dataclasses.dataclass(slots=True)
class Load:
    """
    Values for measuring the collector queue's load ratio.

    The load value is:

        in_progress = items in event_queue + busy
        ratio = in_progress / number of consumer tasks

    """

    qsize: int
    busy: int
    consumers: int
    ratio: float = dataclasses.field(init=False)

    @with_decimal_context
    def __post_init__(self):
        """
        `ratio` is the current load value.
        """
        try:
            assert self.qsize >= 0
            assert self.busy >= 0
            assert self.consumers >= 0
        except AssertionError:
            raise ValueError(
                "Load input values must be greater than or equal to 0"
            )

        if self.consumers <= 0:
            self.ratio = 0.0
        else:
            in_progress = self.qsize + self.busy
            ratio = dec.Decimal(in_progress) / dec.Decimal(self.consumers)
            self.ratio = rd(ratio)


class AvgData[T: (int, float)]:
    """
    Fixed-size deque with moving average calculation.

    Note: Calculations in this class assume values are small enough to
    not cause overflows during accumulation. This should be true for
    the measurements we're working with.
    """

    __slots__ = ["maxlen", "data", "sum", "decimal_context", "prec"]

    def __init__(
        self, maxlen: int, prec: int = AVG_DATA_DECIMAL_PRECISION
    ) -> None:
        try:
            assert maxlen > 0
        except AssertionError:
            raise ConfigError("AvgData maxlen must be greater than 0")

        self.maxlen = maxlen
        self.data: collections.deque[dec.Decimal] = collections.deque(
            maxlen=maxlen
        )
        self.sum: dec.Decimal = dec.Decimal(0)
        self.decimal_context = dec.localcontext()
        self.prec = prec
        with self.decimal_context as ctx:
            ctx.prec = self.prec

    def append(self, value: T) -> None:
        with self.decimal_context:
            if self.len() == self.maxlen:
                discard = self.data.popleft()
                self.sum -= discard

            decimal_val = dec.Decimal(value)
            self.data.append(decimal_val)
            self.sum += decimal_val

    def len(self) -> int:
        return len(self.data)

    def __len__(self) -> int:
        return self.len()

    def avg_decimal(self) -> dec.Decimal:
        dlen = self.len()
        if dlen == 0:
            return dec.Decimal(0)

        with self.decimal_context:
            avg = self.sum / dec.Decimal(dlen)
            return avg

    def avg(self) -> ComputedValue:
        return float(self.avg_decimal())


@dataclasses.dataclass(frozen=True, slots=True)
class Metrics:
    """
    A container for collector queue runtime metrics.

    The latest metrics can be retrieved using the
    ``CollectorQueue.get_metrics`` method.
    """

    timestamp: datetime.datetime
    qsize: int
    busy: int
    consumers: int
    load: float
    avg_load: float
    service_time: float
    wait_time: float
    arrival_rate: float
    departure_rate: float
    wip: float
    t_delta: float
    event_count: int


EmptyMetrics = Metrics(
    timestamp=datetime.datetime(
        1970, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc
    ),
    qsize=0,
    busy=0,
    consumers=0,
    load=0.0,
    avg_load=0.0,
    service_time=0.0,
    wait_time=0.0,
    arrival_rate=0.0,
    departure_rate=0.0,
    wip=0.0,
    t_delta=0.0,
    event_count=0,
)


class QueueMetrics:
    def __init__(
        self,
        load_data_window_size: int,
        arrive_depart_window_size: int,
        event_service_data_window_size: int = EVENT_SERVICE_DATA_WINDOW_SIZE,
        metrics_history_size: int = METRICS_HISTORY_SIZE,
        metrics_warmup_interval: float = METRICS_WARMUP_INTERVAL,
    ) -> None:
        try:
            assert load_data_window_size > 0
        except AssertionError:
            raise ConfigError(
                "QueueMetrics.load_data_window_size must be greater than 0"
            )

        try:
            assert arrive_depart_window_size > 0
        except AssertionError:
            raise ConfigError(
                "QueueMetrics.arrive_depart_window_size must be greater than 0"
            )

        try:
            assert event_service_data_window_size > 0
        except AssertionError:
            raise ConfigError(
                "QueueMetrics.event_service_data_window_size must be greater than 0"
            )

        try:
            assert metrics_history_size > 0
        except AssertionError:
            raise ConfigError(
                "QueueMetrics.metrics_history_size must be greater than 0"
            )

        try:
            assert metrics_warmup_interval >= 0.0
        except AssertionError:
            raise ConfigError(
                "QueueMetrics.metrics_warmup_interval must be greater than or equal to 0"
            )

        # The collector queue load ratio
        self.load_data: AvgData[float] = AvgData(load_data_window_size)

        # Arrival and departure rates
        self.arrival_data: collections.deque[Tuple[MonotonicTime, Count]] = (
            collections.deque(maxlen=arrive_depart_window_size)
        )
        self.departure_data: collections.deque[Tuple[MonotonicTime, Count]] = (
            collections.deque(maxlen=arrive_depart_window_size)
        )

        self.metrics_warmup_interval = metrics_warmup_interval

        # Service and wait time averages
        if event_service_data_window_size < MIN_EVENT_SERVICE_DATA_WINDOW_SIZE:
            event_service_data_window_size = MIN_EVENT_SERVICE_DATA_WINDOW_SIZE

        self.event_service_data: AvgData[MonotonicTime] = AvgData(
            event_service_data_window_size
        )
        self.event_wait_data: AvgData[MonotonicTime] = AvgData(
            event_service_data_window_size
        )

        self.metrics_history: collections.deque[Metrics] = collections.deque(
            maxlen=metrics_history_size
        )

    def store_load_data(self, load: ComputedValue) -> None:
        self.load_data.append(load)

    def avg_load(self) -> ComputedValue:
        """
        Return the mean load value for the last N readings
        where N is "load_data_window_size."
        """
        avg_load = self.load_data.avg()
        return round(avg_load, PRECISION)

    @with_decimal_context
    def wip_decimal(
        self,
    ) -> Tuple[dec.Decimal, dec.Decimal, dec.Decimal, dec.Decimal]:
        """
        Calculate average according to Little's Law:

            https://en.wikipedia.org/wiki/Little%27s_law

        The work-in-progress value is defined by:

            L = a * W

        where:

            L = events waiting in queue or being worked on (the
                "work-in-progress")
            a = average arrival rate of events into the queue
                (lambda in the actual Little's Law equation)
            W = service time (the response latency of the event
                handler)

        The time span for the average is determined by the size of
        the metrics collector window.

        Return values as Decimals.
        """
        arrival_rate, t_delta = self.arrival_rate_decimal()
        service_time = self.service_time_decimal()
        wip = arrival_rate * service_time
        return wip, arrival_rate, service_time, t_delta

    def wip(
        self,
    ) -> Tuple[ComputedValue, ComputedValue, ComputedValue, TimeInterval]:
        """
        Returns (wip, average arrival rate, average service time,
        time period for measurements) as floats
        """
        wip_dec, arrival_rate_dec, service_time_dec, t_delta_dec = (
            self.wip_decimal()
        )

        wip = rd(wip_dec)
        arrival_rate = rd(arrival_rate_dec)
        service_time = rd(service_time_dec)
        t_delta = rd(t_delta_dec)

        return wip, arrival_rate, service_time, t_delta

    def store_event_service_data(self, event: CollectorEvent) -> None:
        self.event_service_data.append(event.service_time())
        self.event_wait_data.append(event.wait_time())

    @with_decimal_context
    def service_time_decimal(self) -> dec.Decimal:
        """
        Calculate the average service time:

            avg. service time = sum(event_service_time) / number_of_entries

        Return average service time in seconds as Decimal.
        """
        avg = self.event_service_data.avg_decimal()
        service_time = avg / dec.Decimal(1.0e9)
        return service_time

    def service_time(self) -> ComputedValue:
        """
        Returns average service time in seconds (float)
        """
        service_time_dec = self.service_time_decimal()
        return rd(service_time_dec)

    @with_decimal_context
    def wait_time_decimal(self) -> dec.Decimal:
        """
        Calculate the average service wait time:

            avg. wait time = sum(event_wait_time) / number_of_entries

        Returns average service wait time in seconds as Decimal
        """
        avg = self.event_wait_data.avg_decimal()
        wait_time = avg / dec.Decimal(1.0e9)
        return wait_time

    def wait_time(self) -> ComputedValue:
        """
        Returns average service wait time in seconds as float.
        """
        wait_time_dec = self.wait_time_decimal()
        return rd(wait_time_dec)

    def store_arrival_departure_data(
        self, busy: Count, departed: Count, qsize: Count
    ) -> None:
        """Store event arrival and departure entries."""
        t = time.monotonic_ns()

        arrived = departed + busy + qsize

        self.arrival_data.append((t, arrived))
        self.departure_data.append((t, departed))

    @with_decimal_context
    def arrival_rate_decimal(self) -> Tuple[dec.Decimal, dec.Decimal]:
        """
        Calculate the average event arrival rate:

            arrival rate = number_of_events / time_interval

        If t_delta is less than "metrics_warmup_interval," return 0
        since the rate has not settled yet and is going to be
        inaccurate.

        Return arrival rate and time delta as Decimals.
        """
        if len(self.arrival_data) == 0:
            return dec.Decimal(0), dec.Decimal(0)

        t0, a0 = self.arrival_data[0]
        t1, a1 = self.arrival_data[len(self.arrival_data) - 1]

        t = t1 - t0
        a = a1 - a0
        t_delta = dec.Decimal(t) / dec.Decimal(1.0e9)
        if t_delta < dec.Decimal(self.metrics_warmup_interval):
            return dec.Decimal(0), dec.Decimal(0)

        arrival_rate = dec.Decimal(a) / t_delta
        return arrival_rate, t_delta

    def arrival_rate(self) -> Tuple[ComputedValue, TimeInterval]:
        """
        Return arrival rate and time delta as floats.
        """
        arrival_rate_dec, t_delta_dec = self.arrival_rate_decimal()

        arrival_rate = rd(arrival_rate_dec)
        t_delta = rd(t_delta_dec)

        return arrival_rate, t_delta

    @with_decimal_context
    def departure_rate_decimal(self) -> Tuple[dec.Decimal, dec.Decimal]:
        """
        Calculate the average event departure rate (rate at which events
        were processed and then left the system):

            departure rate = number_of_events / time_interval

        If t_delta is less than "metrics_warmup_interval," return 0
        since the rate has not settled yet and is going to be
        inaccurate.

        Return departure rate and time delta as Decimals.
        """
        if len(self.departure_data) == 0:
            return dec.Decimal(0), dec.Decimal(0)

        t0, d0 = self.departure_data[0]
        t1, d1 = self.departure_data[len(self.departure_data) - 1]

        t = t1 - t0
        d = d1 - d0
        t_delta = dec.Decimal(t) / dec.Decimal(1.0e9)
        if t_delta < dec.Decimal(self.metrics_warmup_interval):
            return dec.Decimal(0), dec.Decimal(0)

        departure_rate = dec.Decimal(d) / t_delta
        return departure_rate, t_delta

    def departure_rate(self) -> Tuple[ComputedValue, TimeInterval]:
        """
        Return departure rate and time delta as floats.
        """
        departure_rate_dec, t_delta_dec = self.departure_rate_decimal()

        departure_rate = rd(departure_rate_dec)
        t_delta = rd(t_delta_dec)

        return departure_rate, t_delta

    def store_metrics(
        self,
        busy: Count,
        qsize: Count,
        consumers: Count,
        load: ComputedValue,
        event_count: Count,
    ) -> None:
        """
        Store a Metrics entry in the metrics_history deque.
        """
        avg_load = self.avg_load()
        wip, arrival_rate, service_time, t_delta = self.wip()
        wait_time = self.wait_time()
        departure_rate, _ = self.departure_rate()

        snapshot = Metrics(
            timestamp=datetime.datetime.now(datetime.timezone.utc),
            busy=busy,
            qsize=qsize,
            consumers=consumers,
            load=load,
            avg_load=avg_load,
            service_time=service_time,
            wait_time=wait_time,
            arrival_rate=arrival_rate,
            departure_rate=departure_rate,
            wip=wip,
            t_delta=t_delta,
            event_count=event_count,
        )
        self.metrics_history.append(snapshot)

    def latest_metrics(self) -> Metrics:
        hist_size = len(self.metrics_history)
        if hist_size == 0:
            return EmptyMetrics

        return self.metrics_history[hist_size - 1]


@dataclasses.dataclass(slots=True)
class ReportedMetrics(bus.Message):
    """A message that is sent to the MessageBus after the collector
    queue outputs a Metrics report to the log output."""

    metrics: Metrics


@dataclasses.dataclass(slots=True)
class InitializedQueue(bus.Message):
    """A message that is sent to the MessageBus after the collector
    queue is initialized and before processing any event payloads."""

    collector_queue: CollectorQueue


@dataclasses.dataclass(slots=True)
class ShutDownQueue(bus.Message):
    """A message that is sent to the MessageBus after the collector
    queue has shut down."""

    collector_queue: CollectorQueue


class CollectorQueue:
    """
    The ``CollectorQueue`` manages a pool of consumers to process
    incoming event payloads (sent using the ``EventPublisher``).
    Each consumer runs as a background asyncio.Task.
    """

    def __init__(
        self,
        collectors: CollectorList,
        router: type[Router] = SimpleRouter,
        autoscale: bool = True,
        min_consumers: int = DEFAULT_MIN_CONSUMERS,
        max_consumers: int = DEFAULT_MAX_CONSUMERS,
        wip_margin: float = WIP_MARGIN,
        monitor_interval: float = MONITOR_INTERVAL,
        report_interval: float = REPORT_INTERVAL,
        avg_load_interval: float = AVG_LOAD_INTERVAL,
        metrics_collector_window_size: float = METRICS_COLLECTOR_WINDOW_SIZE,
        metrics_warmup_interval: float = METRICS_WARMUP_INTERVAL,
        event_service_data_window_size: int = EVENT_SERVICE_DATA_WINDOW_SIZE,
        metrics_history_size: int = METRICS_HISTORY_SIZE,
        queue_type: QueueType = QueueType.FIFO,
        default_priority: int = DEFAULT_PRIORITY,
        consumer_shutdown_timeout: float = CONSUMER_SHUTDOWN_TIMEOUT,
        logging: bool = True,
    ) -> None:
        # Create a unique id for logging
        unique_id = gen_unique_id()
        self.id = f"{type(self).__name__}-{unique_id}"

        # Set up logger:
        # - If logging if True, send all log method calls to the
        #   structlog logger.
        # - If logging is False, send calls to a NullLogger.
        self.logging: bool = logging
        self.log: AppLogger = get_logger(self.id, is_null=(logging is False))

        # A list of Collector objects
        self.collectors: CollectorDict = {c.key: c for c in collectors}

        # AsyncExitStack to manage collector lifecycles
        self.async_exit_stack: contextlib.AsyncExitStack | None = None

        # Event handling router
        self.router = router(self.collectors)

        # References to background tasks
        self.admin_tasks: list[asyncio.Task] = []

        # asyncio Tasks references
        # - This set keeps references to the asyncio tasks
        #   so the Python interpreter doesn't garbage collect
        #   them by mistake
        self.tasks: set[asyncio.Task] = set()

        # autoscale flag: if True, the consumer monitor
        # will automatically scale consumer tasks to reduce
        # load; if False, then the task queue will rely on
        # consumer tasks created at startup to handle all
        # events.
        #
        # Note: If autoscale is True, "init_queue" will create
        # "min_consumers" at startup, but if autoscale if False,
        # init_queue will create "max_consumers."
        self.autoscale: bool = autoscale
        # The number of consumer tasks to create
        # (lower and upper limits)
        self.min_consumers: int = max(min_consumers, DEFAULT_MIN_CONSUMERS)
        self.max_consumers: int = max(max_consumers, self.min_consumers)

        # WIP task margin (used when adding and reducing consumer
        # tasks)
        self.wip_margin: float = max(wip_margin, 0)

        # Internal counter for number of events processed
        self.event_count: Count = 0

        # If using priority queue
        self.default_priority: int = default_priority

        # Queue to pass payloads to the consumers
        self.queue_type: QueueType = queue_type

        self.event_queue: asyncio.Queue[CollectorEvent]
        self.publisher: EventPublisher

        match self.queue_type:
            case QueueType.LIFO:
                self.event_queue = asyncio.LifoQueue()
                self.publisher = EventPublisher(
                    self.event_queue, queue_type=self.queue_type
                )
            case QueueType.PRIORITY:
                self.event_queue = asyncio.PriorityQueue()
                self.publisher = EventPublisher(
                    self.event_queue,
                    queue_type=self.queue_type,
                    default_priority=self.default_priority,
                )
            case _:
                self.event_queue = asyncio.Queue()
                self.publisher = EventPublisher(
                    self.event_queue, queue_type=self.queue_type
                )

        # Event to signal to background tasks that we're shutting down
        self.shutdown_event: asyncio.Event = asyncio.Event()

        # Consumer monitor asyncio.sleep interval in seconds
        # - sleep should be >= MIN_MONITOR_INTERVAL and
        #   <= MAX_MONITOR_INTERVAL sec (default is 0.01)
        if monitor_interval < MIN_MONITOR_INTERVAL:
            monitor_interval = MIN_MONITOR_INTERVAL
        if monitor_interval > MAX_MONITOR_INTERVAL:
            monitor_interval = MAX_MONITOR_INTERVAL
        self.monitor_interval: float = monitor_interval

        # Status logging interval in seconds
        # - The reporter background task will report on the task queue
        #   status to log output.
        # - If report interval is <= 0, disable reporter.
        if report_interval < 0.0:
            report_interval = 0.0
        self.reporter_enabled: bool = report_interval > 0.0
        self.report_interval: float = report_interval

        # The interval (in seconds) to keep data for calculating the
        # average load value
        self.avg_load_interval: float = avg_load_interval
        if self.avg_load_interval < MIN_AVG_LOAD_INTERVAL:
            self.avg_load_interval = MIN_AVG_LOAD_INTERVAL

        self.load_data_window_size: int = math.ceil(
            self.avg_load_interval / self.monitor_interval
        )

        # The window size (in seconds) to keep arrival and departure
        # data for calculating the average arrival and departure rates
        # - Require mininum sie to be 5 seconds.
        # - For long-term averages this value should be >= 60 seconds.
        self.metrics_collector_window_size: float = (
            metrics_collector_window_size
        )
        if (
            self.metrics_collector_window_size
            < MIN_METRICS_COLLECTOR_WINDOW_SIZE
        ):
            self.metrics_collector_window_size = (
                MIN_METRICS_COLLECTOR_WINDOW_SIZE
            )

        # Period in seconds to run the metrics_collector task
        self.metrics_collector_task_period: float = (
            METRICS_COLLECTOR_TASK_PERIOD
        )

        self.arrive_depart_window_size: int = math.ceil(
            self.metrics_collector_window_size
            / self.metrics_collector_task_period
        )

        # Window size data structure for measuring service and wait times
        self.event_service_data_window_size: int = (
            event_service_data_window_size
        )

        # Window size for metrics history
        if metrics_history_size < MIN_METRICS_HISTORY_SIZE:
            metrics_history_size = MIN_METRICS_HISTORY_SIZE
        self.metrics_history_size: int = metrics_history_size

        # Warm-up interval for metrics before reporting valid averages
        if metrics_warmup_interval < 0.0:
            metrics_warmup_interval = 0.0
        self.metrics_warmup_interval = metrics_warmup_interval

        # Helper class to keep track of metrics
        self.metrics = QueueMetrics(
            load_data_window_size=self.load_data_window_size,
            arrive_depart_window_size=self.arrive_depart_window_size,
            event_service_data_window_size=self.event_service_data_window_size,
            metrics_history_size=self.metrics_history_size,
            metrics_warmup_interval=self.metrics_warmup_interval,
        )

        # consumer_shutdown_timeout specifies how to handle consumer
        # tasks when shutting down.
        #
        # If consumer_shutdown_timeout > 0, the shutdown function will
        # carry out consumer shutdown operations with the specified
        # timeout value using asyncio.timeout(); if consumer shutdown
        # operations take longer than the specified value, the
        # event_queue will shut down immediately and cause all
        # consumers to return regardless of the remaining items that
        # were in the queue.
        #
        # If consumer_shutdown_timeout is <= 0, timeout will not
        # trigger; the shutdown function will wait for all consumers
        # to process leftover events in the event_queue (this could
        # take a while if processing a queue full of events).
        self.consumer_shutdown_timeout: float = consumer_shutdown_timeout

        msg_handlers: bus.MsgHandlers = {
            ConsumersInitialized: [self._handle_consumers_initialized],
            ConsumersShutDown: [self._handle_consumers_shut_down],
            EventFinished: [self._handle_event_finished],
            ConsumersAdded: [self._handle_consumers_added],
            ConsumersDeleted: [self._handle_consumers_deleted],
        }
        self.bus: bus.MessageBus = bus.MessageBus(msg_handlers=msg_handlers)

        self.consumer_pool = ConsumerPool(
            event_queue=self.event_queue,
            router=self.router,
            bus=self.bus,
            consumer_shutdown_timeout=self.consumer_shutdown_timeout,
        )

        self._is_running: bool = False

    def get_publisher(self) -> EventPublisher:
        """
        Return an EventPublisher.

        Use the publisher to send event payloads to the event queue.

        Example::

            collector_queue = CollectorQueue(
                collectors,
                min_consumers=min_consumers,
                max_consumers=max_consumers,
            )

            async with collector_queue:
                publisher = collector_queue.get_publisher()
                payload = Payload({
                    "data": "payload data",
                })
                event = await event_publisher.send(payload)
                result_list = await event.wait()

        """
        return self.publisher

    def get_metrics(self) -> Metrics:
        """Return the latest Metrics snapshot."""
        return self.metrics.latest_metrics()

    def consumer_count(self) -> int:
        """Get the current consumer pool size."""
        return self.consumer_pool.count()

    def current_load(self) -> Load:
        """Get current load values."""
        qsize = self.event_queue.qsize()
        busy = self.consumer_pool.busy()
        consumers = max(self.consumer_count(), 1)
        return Load(qsize, busy, consumers)

    def get_message_bus(self) -> bus.MessageBus:
        return self.bus

    def _calc_positive_delta(self, load: Load) -> Tuple[Count, Count]:
        """
        Calculate the number of consumers to add given the current
        load ratio.

        Algorithm:

        Assumes: load ratio >= 1.0

        1. Calculate an "allowance" value equal to "max_consumers"
           minus the current number of consumers.

        2. Calculate the number of additional consumer tasks needed to
           match the current queue size plus the number of currently
           busy consumers and an additional margin (default is 15%).

        3. If the number of additional consumers is greater than
           the allowance, then adjust the number of additional
           consumers to make the total consumer pool size equal to the
           "max_consumers" value.

        The calculation will *try* to bring the load ratio to 1,
        unless "max_consumers" is limiting the number of consumers
        that can be added, in which case "target consumers" will
        match the "max_consumers" value.

        :returns: consumers_to_add, target_consumers
        """
        if load.ratio < 1.0:
            return 0, load.consumers

        allowance = self.max_consumers - load.consumers
        margin = self.wip_margin
        demand = load.qsize + load.busy
        demand += math.ceil(demand * margin)
        add_consumers = demand - load.consumers
        delta = add_consumers if add_consumers < allowance else allowance
        target_consumers = delta + load.consumers

        return delta, target_consumers

    async def _add_consumers(self) -> None:
        """
        Scale up consumer pool by add new consumers.

        This method is called by the consumer monitor when the current
        load is greater than or equal to 1.
        """
        # If the system is shutting down, the consumer count could go
        # to 0, so we need to do a sanity check here and only
        # autoscale if the consumer count is positive.
        if self.consumer_count() <= 0:
            return

        load = self.current_load()
        delta, _ = self._calc_positive_delta(load)

        if delta > 0:
            await self.consumer_pool.create(delta)

    def _calc_negative_delta(
        self, load: Load, avg_load: ComputedValue, wip: ComputedValue
    ) -> Tuple[Count, Count]:
        """
        Calculate the number of consumers to delete given the current
        load ratio.

        Algorithm:

        Assumes: load ratio is < 1.0

        1. If the average load value is less than REDUCTION_THRESHOLD,
           then proceed to calculate the number of consumer tasks to
           delete, otherwise skip.

        2. Set a lower limit by comparing the average WIP value (plus
           margin) and "min_consumers." Whichever one is larger becomes
           the lower limit.

        3. Calculate the number of consumers needed to match the queue
           size plus busy consumers and an additional margin (default
           is 15%).

           Example: If the "demand" value of (qsize + busy + margin)
           is 10 and the current consumer size is 50, then we can
           reduce the consumer pool size by 40.

        4. If the target consumer pool size is less than the calculated
           lower limit, reduce the number of consumers to match that
           value.

        The calculation will bring the load ratio to the "WIP" value
        (calculated by QueueMetrics.wip), plus a small margin
        ("wip_margin"), unless "min_consumers" is greater, in which
        case it will set the number of consumers to match
        "min_consumers."

        :returns: consumers_to_delete, target_consumers
        """
        if avg_load >= REDUCTION_THRESHOLD:
            return 0, load.consumers

        if load.ratio >= 1.0:
            return 0, load.consumers

        margin = self.wip_margin
        lower_limit = math.ceil(wip + wip * margin)
        lower_limit = max(lower_limit, self.min_consumers)
        if load.consumers < lower_limit:
            return 0, load.consumers

        demand = load.qsize + load.busy
        demand += math.ceil(demand * margin)
        delta = load.consumers - demand
        target_consumers = load.consumers - delta
        if target_consumers < lower_limit:
            target_consumers = lower_limit
            delta = load.consumers - lower_limit

        return delta, target_consumers

    async def _reduce_consumers(self) -> None:
        """
        Scale down consumer pool by deleting consumers.

        This method is called by the consumer monitor when the average
        load ratio is less than 1.
        """
        # If the system is shutting down, the consumer count could go
        # to 0, so we need to do a sanity check here and only
        # autoscale if the consumer count is greater than
        # "min_consumers."
        if self.consumer_count() <= self.min_consumers:
            return

        load = self.current_load()
        avg_load = self.metrics.avg_load()
        wip, _, _, _ = self.metrics.wip()
        delta, _ = self._calc_negative_delta(load, avg_load, wip)

        if delta > 0:
            await self.consumer_pool.delete(delta)

    async def _report_metrics(self) -> None:
        """Print collector queue metrics to the log output."""
        metrics = self.get_metrics()

        await self.log.ainfo(
            "collector queue metrics",
            metrics_timestamp=metrics.timestamp,
            qsize=metrics.qsize,
            busy=metrics.busy,
            consumers=metrics.consumers,
            load=metrics.load,
            avg_load=metrics.avg_load,
            service_time=metrics.service_time,
            wait_time=metrics.wait_time,
            arrival_rate=metrics.arrival_rate,
            departure_rate=metrics.departure_rate,
            wip=metrics.wip,
            t_delta=metrics.t_delta,
            event_count=metrics.event_count,
        )

        await self.bus.dispatch(ReportedMetrics(metrics))

    async def _collect_metrics(self) -> None:
        """
        The "_collect_metrics" data collector runs as a periodic
        background task using `_run_periodic_task`. It stores
        queue-related runtime metrics in the Metrics object.
        """
        load = self.current_load()
        event_count = self.event_count

        self.metrics.store_arrival_departure_data(
            busy=load.busy,
            departed=event_count,
            qsize=load.qsize,
        )

        self.metrics.store_metrics(
            qsize=load.qsize,
            busy=load.busy,
            consumers=load.consumers,
            load=load.ratio,
            event_count=event_count,
        )

    async def _monitor_load(self) -> None:
        """
        "_monitor_load" runs as a background task that checks the
        collector queue load ratio at a periodic interval and adjusts
        consumers to reduce the load when possible.

        Checks are performed between asyncio.sleep intervals.
        """
        await self.log.adebug(
            "load monitor started", interval=self.monitor_interval
        )

        try:
            while True:
                if self.shutdown_event.is_set():
                    break

                load = self.current_load()
                self.metrics.store_load_data(load.ratio)

                if self.autoscale:
                    if load.ratio >= 1.0:
                        await self._add_consumers()
                    else:
                        await self._reduce_consumers()

                await asyncio.sleep(self.monitor_interval)

        except (asyncio.CancelledError, asyncio.QueueShutDown):
            pass
        except Exception as e:
            details = traceback.format_exc()
            await self.log.aerror(
                "load monitor exception", exc=e, details=details
            )
        finally:
            await self.log.adebug("load monitor stopped")

    async def _run_periodic_task(
        self,
        interval: float,
        name: str,
        func: GenericAsyncTaskFunc,
        *args,
        **kwargs,
    ) -> None:
        """Run a background task at periodic interval."""
        await self.log.adebug(
            f"{name} periodic task started", interval=interval
        )

        try:
            while True:
                async with asyncio.TaskGroup() as tg:
                    task_name = f"{name}_periodic_task"
                    task = tg.create_task(func(*args, **kwargs), name=task_name)
                    task.add_done_callback(self._done_callback)
                    self.tasks.add(task)

                    task_name = f"{name}_sleep_task"
                    task = tg.create_task(
                        asyncio.sleep(interval), name=task_name
                    )
                    task.add_done_callback(self._done_callback)
                    self.tasks.add(task)

        except asyncio.CancelledError:
            pass
        except Exception as e:
            details = traceback.format_exc()
            await self.log.aerror(
                "periodic task exception", name=name, exc=e, details=details
            )
        finally:
            await self.log.adebug(f"{name} stopped")

    def _incr_event(self) -> None:
        """event_count is the total number of event payloads already
        processed by consumers."""
        self.event_count += 1

    async def _handle_event_finished(
        self, msg: EventFinished, queue: bus.BusEventQueue
    ) -> None:
        self._incr_event()
        self.metrics.store_event_service_data(msg.event)

    async def _handle_consumers_added(
        self,
        msg: ConsumersAdded,
        queue: bus.BusEventQueue,
    ) -> None:
        await self.log.adebug("added consumers", add=msg.num, target=msg.target)

    async def _handle_consumers_deleted(
        self,
        msg: ConsumersDeleted,
        queue: bus.BusEventQueue,
    ) -> None:
        await self.log.adebug(
            "deleted consumers", delete=msg.num, target=msg.target
        )

    async def _handle_consumers_initialized(
        self,
        msg: ConsumersInitialized,
        queue: bus.BusEventQueue,
    ) -> None:
        await self.log.adebug(
            "started consumers",
            consumers=self.consumer_count(),
        )

    async def _handle_consumers_shut_down(
        self,
        msg: ConsumersShutDown,
        queue: bus.BusEventQueue,
    ) -> None:
        self.event_queue.shutdown()
        await self.log.adebug(
            "stopped consumers",
            consumers=self.consumer_count(),
        )

    async def _cancel_task(self, task: asyncio.Task) -> None:
        if not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception as e:
                await self.log.aerror("cancel task exception", exc=e)

    def _done_callback(self, task: asyncio.Task) -> None:
        """A generic done callback function for asyncio tasks."""
        self.tasks.discard(task)

        try:
            task.exception()
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.log.error(f"task {task.get_name()} got exception", exc=e)

    def _create_async_task(self, func: AsyncFunc, name: str) -> asyncio.Task:
        """
        Create an async task and add done_callback. Store a reference
        to the task in self.tasks.
        """
        task: asyncio.Task = asyncio.create_task(func, name=name)
        task.add_done_callback(self._done_callback)
        self.tasks.add(task)

        return task

    async def init_queue(self) -> None:
        """Initialize the collector queue."""
        if self._is_running:
            return

        # Set up collectors
        self.async_exit_stack = contextlib.AsyncExitStack()
        for c in self.collectors.values():
            if c.lifecycle:
                await self.async_exit_stack.enter_async_context(
                    c.lifecycle(c.ctx)
                )

        # Create admin tasks and background consumer pool
        self.shutdown_event.clear()

        task_name = "load_monitor"
        task = self._create_async_task(self._monitor_load(), task_name)
        self.admin_tasks.append(task)

        task_name = "metrics_collector"
        func = self._run_periodic_task(
            self.metrics_collector_task_period,
            task_name,
            self._collect_metrics,
        )
        task = self._create_async_task(func, task_name)
        self.admin_tasks.append(task)

        if self.reporter_enabled:
            task_name = "reporter"
            func = self._run_periodic_task(
                self.report_interval,
                task_name,
                self._report_metrics,
            )
            task = self._create_async_task(func, task_name)
            self.admin_tasks.append(task)

        consumers = self.min_consumers if self.autoscale else self.max_consumers
        await self.consumer_pool.initialize(consumers)

        # Initialize metrics data
        await self._collect_metrics()

        await asyncio.sleep(0)

        self._is_running = True

        await self.log.adebug("collector queue initialized")

        await self.bus.dispatch(InitializedQueue(self))

    async def shut_down_queue(self) -> None:
        """Shut down the collector queue."""
        if not self._is_running:
            return

        self.shutdown_event.set()

        for task in self.admin_tasks:
            await self._cancel_task(task)

        self.admin_tasks.clear()

        await self.log.adebug(
            "stopping all consumers",
            consumers=self.consumer_count(),
        )
        await self.consumer_pool.shut_down()

        # Shut down collectors
        if self.async_exit_stack:
            await self.async_exit_stack.aclose()

        self._is_running = False

        await self.log.adebug("collector queue shutdown complete")

        await self.bus.dispatch(ShutDownQueue(self))

    async def __aenter__(self) -> CollectorQueue:
        """
        Async context manager entry function.

        Example usage::

            collector = Collector("demo-collector", event_handler)
            collectors = [collector]
            min_consumers = 1
            max_consumers = 1000

            collector_queue = CollectorQueue(
                collectors,
                min_consumers=min_consumers,
                max_consumers=max_consumers,
            )

            async with collector_queue:
                publisher = queue.get_publisher()
                ...


        The ContextManager interface is equivalent to::

            try:
                collector = Collector("demo-collector", event_handler)
                collectors = [collector]
                min_consumers = 1
                max_consumers = 1000

                collector_queue = CollectorQueue(
                    collectors,
                    min_consumers=min_consumers,
                    max_consumers=max_consumers,
                )
                await collector_queue.init_queue()

                publisher = queue.get_publisher()
                ...

            except Exception as e:
                # handle exception
                ...

            finally:
                # shut down collector queue
                await collector_queue.shut_down_queue()

        """
        await self.init_queue()
        return self

    async def __aexit__(self, exc_type, exc_value, exc_tb):
        """
        Async context manager exit function.

        When exiting the context manager, this function will
        call "shut_down_queue."
        """
        if exc_type:
            match exc_type:
                case asyncio.CancelledError:
                    pass
                case _:
                    exc_details = traceback.format_exc()
                    await self.log.aerror(
                        "collector queue got exception",
                        exc=exc_value,
                        details=exc_details,
                    )

        await self.shut_down_queue()
