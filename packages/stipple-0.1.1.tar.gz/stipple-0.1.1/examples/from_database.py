"""Plug Stipple straight into a database.

Stipple ingests any pandas / polars / pyarrow result by column name, so a SQL
query drops straight in. `Stipple.from_sql` runs the query for you and feeds
the result to the widget.

This example is self-contained: it synthesizes a NYC-shaped point cloud in
DuckDB so it runs anywhere. In a Jupyter notebook, make `w` the last line of a
cell to render it; here we just construct it and print a confirmation.

    pip install stipple duckdb
    python examples/from_database.py
"""

import duckdb

from stipple import Stipple

con = duckdb.connect()

# Synthesize ~500k pickups in two clusters (a dense "downtown" + a far
# "airport" with higher fares) so the average-fare jump is visible on a lasso.
con.execute(
    """
    CREATE TABLE trips AS
    SELECT
        -73.99 + 0.02 * (random() - 0.5) AS lon,
         40.75 + 0.02 * (random() - 0.5) AS lat,
         8 + 6 * random()                AS fare
    FROM range(400000)
    UNION ALL
    SELECT
        -73.78 + 0.01 * (random() - 0.5) AS lon,
         40.64 + 0.01 * (random() - 0.5) AS lat,
         48 + 8 * random()               AS fare
    FROM range(100000)
    """
)

# The one-liner: query -> widget, by column name. No manual fetch/normalize.
w = Stipple.from_sql(
    con,
    "SELECT lon, lat, fare FROM trips WHERE fare > 0",
    x="lon",
    y="lat",
    color="fare",
    color_kind="continuous",
)

print(f"from_sql -> {w.n_points:,} points, color_range={w.color_range}")
print("In a notebook, end a cell with `w` to render it, then shift+drag to lasso.")

# Equivalent paths if you already have the data in hand:
#   w = Stipple(con.sql(q).arrow(), x="lon", y="lat", color="fare")  # pyarrow
#   w = Stipple(df, x="lon", y="lat", color="fare")                  # pandas/polars
