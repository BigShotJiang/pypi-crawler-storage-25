"""chatwire: install / uninstall / inspect the local bridge.

A user-facing wrapper around launchd. Renders the plist templates from
templates/launchd/, drops them into ~/Library/LaunchAgents/, and loads them.
Also bundles a `doctor` subcommand that surfaces TCC and config issues, a
`logs` subcommand that tails launchd output, and `migrate` for the
legacy-.env-to-config.json hop.

Phase 1 scope: this file replaces the ad-hoc shell scripts and the
hand-installed plists. The `setup` subcommand currently just prints the URL
of the (not-yet-built) web wizard; Phase 2 implements the wizard itself.

Usage:
    chatwire setup
    chatwire install-agents
    chatwire uninstall-agents
    chatwire logs [--service bridge|web|all] [-f]
    chatwire doctor
    chatwire migrate
"""
from __future__ import annotations

import argparse
import os
import shutil
import string
import subprocess
import sys
import webbrowser
from pathlib import Path

import _version
import config

DEFAULT_LABEL_PREFIX = "dev.chatwire"
DEFAULT_LOG_DIR = Path.home() / "Library" / "Logs" / "chatwire"
LAUNCH_AGENTS_DIR = Path.home() / "Library" / "LaunchAgents"
TEMPLATE_DIR = Path(__file__).resolve().parent / "templates" / "launchd"

PLIST_NAMES = ("bridge", "web", "keepawake")


def _require_macos() -> None:
    if sys.platform != "darwin":
        sys.exit("chatwire runs on macOS only (the bridge needs chat.db + AppleScript).")


def _warn_non_framework_python() -> None:
    """TCC binds Full Disk Access and Automation grants to the specific Python
    binary, not the venv that wraps it. A pipx install built off Homebrew (or
    any non-python.org) Python will need its OWN re-grant — the user's existing
    grants to python.org's Python won't carry over. Surface this loudly the
    first time they run a subcommand."""
    if sys.platform != "darwin":
        return
    if os.environ.get("CHATWIRE_ALLOW_NON_FRAMEWORK_PYTHON") == "1":
        return
    # sys.base_prefix is the prefix of the interpreter the venv was built off
    # (or sys.prefix when not in a venv) — the public, stable signal for
    # "which Python identity am I really under." sys.base_executable looks
    # tempting but it's a private attribute, missing on some 3.x builds.
    base_prefix = sys.base_prefix
    framework_prefixes = (
        "/Library/Frameworks/Python.framework/",
        "/opt/local/Library/Frameworks/Python.framework/",  # MacPorts
    )
    if any(base_prefix.startswith(p) for p in framework_prefixes):
        return
    msg = (
        f"WARNING: chatwire is running under a Python whose base prefix is\n"
        f"  {base_prefix}\n"
        "which is not python.org's framework Python. macOS TCC tracks each\n"
        "Python binary as a distinct identity, so the Full Disk Access +\n"
        "Automation grants you'll need won't carry over from another install.\n"
        "\n"
        "Recommended: install python.org Python from\n"
        "  https://www.python.org/downloads/macos/\n"
        "and reinstall chatwire with\n"
        "  pipx install --python /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 chatwire\n"
        "\n"
        "Suppress this warning with CHATWIRE_ALLOW_NON_FRAMEWORK_PYTHON=1."
    )
    print(msg, file=sys.stderr)


def _default_install_dir() -> Path:
    return Path(__file__).resolve().parent


def _default_venv_python() -> Path:
    """Return the venv's bin/python<major.minor> (the binary whose sys.path
    includes the chatwire install).

    NOT sys.executable: on macOS framework Python (python.org), the pipx
    venv's bin/python3.X is a symlink/copy of the framework binary, and
    sys.executable returns the *resolved* base path. Plists rendered with
    sys.executable would invoke the base Python and miss the venv's
    site-packages, so the web agent fails on `import fastapi` and the
    bridge runs but sees no integrations (lazy imports mask the same root
    cause).

    Outside a venv, sys.prefix == sys.base_prefix and we just hand back
    sys.executable.
    """
    if sys.prefix != sys.base_prefix:
        venv_bin = Path(sys.prefix) / "bin"
        for name in (f"python{sys.version_info.major}.{sys.version_info.minor}",
                     f"python{sys.version_info.major}",
                     "python"):
            p = venv_bin / name
            if p.exists():
                return p
    return Path(sys.executable)


def _render_template(template: Path, vars: dict[str, str]) -> str:
    return string.Template(template.read_text()).substitute(vars)


def _agent_path(label_prefix: str, name: str) -> Path:
    return LAUNCH_AGENTS_DIR / f"{label_prefix}.{name}.plist"


def _label(label_prefix: str, name: str) -> str:
    return f"{label_prefix}.{name}"


# ---------- subcommands ----------

def cmd_install_agents(args: argparse.Namespace) -> int:
    _require_macos()
    install_dir = Path(args.install_dir).resolve()
    # NOT .resolve() — on macOS framework Python (python.org), the pipx
    # venv's bin/python3.X is a symlink to the framework binary, and
    # resolve() would dereference it. The plist needs the VENV-form path
    # so that Python boots with sys.prefix pointing at the venv (and so
    # finds the venv's site-packages); invoking the framework binary
    # directly skips the venv and the import of fastapi etc. fails.
    venv_python = Path(args.venv_python).absolute()
    log_dir = Path(args.log_dir).resolve()
    label_prefix = args.label_prefix

    if not (install_dir / "bridge.py").exists():
        sys.exit(f"--install-dir {install_dir} doesn't look like the repo (no bridge.py)")
    if not venv_python.exists():
        sys.exit(f"--venv-python {venv_python} doesn't exist")

    log_dir.mkdir(parents=True, exist_ok=True)
    LAUNCH_AGENTS_DIR.mkdir(parents=True, exist_ok=True)

    vars = {
        "LABEL_PREFIX": label_prefix,
        "INSTALL_DIR": str(install_dir),
        "VENV_PYTHON": str(venv_python),
        "LOG_DIR": str(log_dir),
    }

    rendered: list[Path] = []
    for name in PLIST_NAMES:
        tpl = TEMPLATE_DIR / f"{name}.plist.template"
        if not tpl.exists():
            sys.exit(f"missing template: {tpl}")
        out = _agent_path(label_prefix, name)
        out.write_text(_render_template(tpl, vars))
        rendered.append(out)
        print(f"wrote {out}")

    for path in rendered:
        # `launchctl load -w` is deprecated on Sequoia+ but still works on 12-15.
        # Switch to bootstrap-domain syntax once the Sequoia minimum is set.
        r = subprocess.run(
            ["launchctl", "load", "-w", str(path)],
            capture_output=True, text=True,
        )
        if r.returncode != 0:
            # Already loaded → harmless. Anything else worth surfacing.
            stderr = (r.stderr or "").strip()
            if "already loaded" not in stderr.lower():
                print(f"launchctl load failed for {path}: {stderr}", file=sys.stderr)
        else:
            print(f"loaded {path.name}")
    return 0


def cmd_uninstall_agents(args: argparse.Namespace) -> int:
    _require_macos()
    label_prefix = args.label_prefix
    for name in PLIST_NAMES:
        path = _agent_path(label_prefix, name)
        if not path.exists():
            continue
        subprocess.run(["launchctl", "unload", str(path)], capture_output=True, text=True)
        path.unlink()
        print(f"removed {path}")
    return 0


def cmd_setup(args: argparse.Namespace) -> int:
    """Phase 1 stub: prints the wizard URL. Phase 2 ships the wizard itself."""
    cfg = config.apply_to_environ()
    port = int(cfg.get("WEB_PORT") or os.environ.get("WEB_PORT") or 8723)
    url = f"http://127.0.0.1:{port}/setup"
    print(f"setup wizard (when implemented): {url}")
    print("for now, run `chatwire install-agents` and configure via")
    print(f"~/.chatwire/config.json (chmod 600).")
    if args.open:
        webbrowser.open(url)
    return 0


def cmd_logs(args: argparse.Namespace) -> int:
    _require_macos()
    log_dir = Path(args.log_dir)
    targets: list[Path] = []
    if args.service in ("bridge", "all"):
        targets.append(log_dir / "stderr.log")
    if args.service in ("web", "all"):
        targets.append(log_dir / "web-stderr.log")
    targets = [t for t in targets if t.exists()]
    if not targets:
        print(f"no log files yet at {log_dir}", file=sys.stderr)
        return 1
    cmd = ["tail"]
    if args.follow:
        cmd.append("-F")
    cmd.append("-n")
    cmd.append(str(args.lines))
    cmd.extend(str(t) for t in targets)
    return subprocess.call(cmd)


def cmd_doctor(args: argparse.Namespace) -> int:
    """Quick sanity check. Real TCC probing lives in scripts/check-permissions.sh
    today — we'll fold it in here once the setup wizard needs structured output."""
    _require_macos()
    issues = 0

    # 1. config present?
    if config.CONFIG_PATH.exists():
        mode = config.CONFIG_PATH.stat().st_mode & 0o777
        marker = "✓" if mode == 0o600 else "✗"
        print(f"{marker} config.json: {config.CONFIG_PATH} (mode {oct(mode)})")
        if mode != 0o600:
            issues += 1
    elif config.LEGACY_ENV_PATH.exists():
        print(f"… legacy .env present at {config.LEGACY_ENV_PATH}; "
              f"run `chatwire migrate` to upgrade")
    else:
        print(f"✗ no config: neither {config.CONFIG_PATH} nor {config.LEGACY_ENV_PATH} exist")
        issues += 1

    # 2. agents installed?
    label_prefix = args.label_prefix
    for name in PLIST_NAMES:
        path = _agent_path(label_prefix, name)
        marker = "✓" if path.exists() else "✗"
        print(f"{marker} agent: {path.name}")
        if not path.exists():
            issues += 1

    # 3. agents loaded?
    if shutil.which("launchctl"):
        listing = subprocess.run(
            ["launchctl", "list"], capture_output=True, text=True,
        ).stdout
        for name in PLIST_NAMES:
            label = _label(label_prefix, name)
            loaded = label in listing
            marker = "✓" if loaded else "✗"
            print(f"{marker} loaded: {label}")
            if not loaded:
                issues += 1

    print(f"\n{issues} issue(s)" if issues else "\nall checks passed")
    return 0 if issues == 0 else 1


def cmd_migrate(args: argparse.Namespace) -> int:
    env_ran = config.migrate_legacy_env()
    if env_ran:
        print(f"migrated {config.LEGACY_ENV_PATH} → {config.CONFIG_PATH}")
        print(f"chmod 600 enforced. legacy file left in place — delete after verification.")

    state_copied = config.migrate_state_dir()
    if state_copied:
        print(f"copied {len(state_copied)} state file(s) "
              f"{config.LEGACY_STATE_DIR} → {config.STATE_DIR}: "
              f"{', '.join(state_copied)}")
        print(f"legacy dir left in place — `rm -rf {config.LEGACY_STATE_DIR}` "
              f"after verifying agents are healthy.")

    if env_ran or state_copied:
        return 0
    if config.CONFIG_PATH.exists():
        print(f"already migrated: {config.CONFIG_PATH} exists. nothing to do.")
        return 0
    print(f"nothing to migrate: neither {config.CONFIG_PATH} "
          f"nor {config.LEGACY_ENV_PATH} exist")
    return 1


# ---------- arg parser ----------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="chatwire")
    p.add_argument(
        "--version",
        action="version",
        version=f"chatwire {_version.__version__}",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("install-agents", help="render and load launchd agents")
    sp.add_argument("--label-prefix", default=DEFAULT_LABEL_PREFIX)
    sp.add_argument("--install-dir", default=str(_default_install_dir()))
    sp.add_argument("--venv-python", default=str(_default_venv_python()))
    sp.add_argument("--log-dir", default=str(DEFAULT_LOG_DIR))
    sp.set_defaults(func=cmd_install_agents)

    sp = sub.add_parser("uninstall-agents", help="unload and remove launchd agents")
    sp.add_argument("--label-prefix", default=DEFAULT_LABEL_PREFIX)
    sp.set_defaults(func=cmd_uninstall_agents)

    sp = sub.add_parser("setup", help="open the web setup wizard")
    sp.add_argument("--no-open", dest="open", action="store_false", default=True)
    sp.set_defaults(func=cmd_setup)

    sp = sub.add_parser("logs", help="tail bridge / web logs")
    sp.add_argument("--service", choices=("bridge", "web", "all"), default="all")
    sp.add_argument("-f", "--follow", action="store_true")
    sp.add_argument("-n", "--lines", type=int, default=50)
    sp.add_argument("--log-dir", default=str(DEFAULT_LOG_DIR))
    sp.set_defaults(func=cmd_logs)

    sp = sub.add_parser("doctor", help="check config + permissions + agent state")
    sp.add_argument("--label-prefix", default=DEFAULT_LABEL_PREFIX)
    sp.set_defaults(func=cmd_doctor)

    sp = sub.add_parser("migrate", help="legacy .env → config.json (one-shot)")
    sp.set_defaults(func=cmd_migrate)

    return p


def main() -> int:
    args = build_parser().parse_args()
    _warn_non_framework_python()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
