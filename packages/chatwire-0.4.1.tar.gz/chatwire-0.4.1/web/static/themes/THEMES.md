# Themes

chatwire's web UI is themeable via CSS custom properties. Each theme is a
small file that sets `--app-*` variables; the bridge file
(`_bridge.css`) propagates those onto Shoelace's `--sl-*` tokens so
custom CSS and Shoelace components stay coherent.

Themes are picked up via the `data-theme` attribute on `<html>`:

```html
<html data-theme="dracula">
```

A future "Appearance" step in the setup wizard (see
`docs/OPEN_SOURCE_PLAN.md`) will surface theme selection and persist
the choice as `web.theme` in `config.json`.

## Shipped themes

| Slug | Source | License | Notes |
|------|--------|---------|-------|
| `default` | (chatwire-internal) | — | Current look. Pre-redesign placeholder. |

## Roadmap (per OPEN_SOURCE_PLAN.md)

All ports below are MIT-licensed and will be added under their
upstream names. Attribution links go in the table above as each
ports lands.

- Dracula — <https://draculatheme.com/>
- Nord — <https://www.nordtheme.com/>
- Solarized Light, Solarized Dark — <https://ethanschoonover.com/solarized/>
- Tokyo Night — <https://github.com/folke/tokyonight.nvim>
- One Dark, One Light — <https://github.com/atom/atom/tree/master/packages/one-dark-ui>
- Gruvbox — <https://github.com/morhetz/gruvbox>
- GitHub Light, GitHub Dark — <https://primer.style/foundations/color>
- Night Owl — <https://github.com/sdras/night-owl-vscode-theme>
- Catppuccin (Latte / Frappé / Macchiato / Mocha) — <https://catppuccin.com/>
- Rosé Pine — <https://rosepinetheme.com/>

## Adding a new theme

1. Copy `default.css` to `<slug>.css`. Use the upstream name as the slug
   wherever possible (no renames — "dracula", not "vampire").
2. Replace the `--app-color-*` values with the theme's palette. The
   bridge handles propagation onto Shoelace components; usually no
   `--sl-*` overrides are needed.
3. Add a `<link rel="stylesheet" href="/static/themes/<slug>.css">`
   tag in the base templates, or load it dynamically based on
   `web.theme`.
4. Register the theme in the table above with its source URL and
   license. Per most theme licenses, "attribution + don't rename" is
   the entire compliance bar.

## Why no `prefers-color-scheme` selectors here

Themes are explicit choices, not auto-toggles. The wizard will surface
a `system` option that flips between a paired light/dark theme based
on `prefers-color-scheme`, but each individual theme file commits to
one mode. Easier to reason about, easier to debug.
