"""Send iMessages via AppleScript -> Messages.app.

Requires Automation permission for the running binary to control Messages.
"""
from __future__ import annotations

import logging
import sqlite3
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from chat_db import CHAT_DB

log = logging.getLogger("chat_send")

OSASCRIPT_TIMEOUT_S = 30

# chat.db error codes we translate to human hints. Everything else surfaces
# as the bare integer so the UI tells you *something* meaningful to grep.
ERROR_HINTS = {
    0: "",
    3: "network error",
    22: "not registered on iMessage — try SMS / a different number",
    41: "blocked by recipient or invalid address",
    100: "delivery failed",
    102: "server rejected message",
}


@dataclass
class SendResult:
    """Outcome of a send attempt, enriched by reading chat.db after osascript.

    - osascript_ok: Messages.app accepted the send command.
    - rowid / service / is_sent / is_delivered / error: from the matching
      outgoing row in chat.db. None/False when we didn't find it in time.
    - fell_back_to_sms: the first iMessage attempt returned an identity error
      (22) and we auto-retried via SMS. The other fields describe the SMS
      attempt in that case; `original_error` carries the original iMessage code.
    """

    osascript_ok: bool = False
    rowid: int | None = None
    service: str | None = None
    is_sent: bool = False
    is_delivered: bool = False
    error: int = 0
    fell_back_to_sms: bool = False
    original_error: int = 0

    @property
    def delivered(self) -> bool:
        return self.error == 0 and self.is_delivered

    @property
    def failed(self) -> bool:
        return self.error != 0

    @property
    def hint(self) -> str:
        if self.error:
            base = ERROR_HINTS.get(self.error) or f"error {self.error}"
            if self.fell_back_to_sms:
                return f"iMessage err={self.original_error}, SMS also failed: {base}"
            return base
        if not self.osascript_ok:
            return "Messages.app rejected the send command"
        if self.rowid is None:
            return "no chat.db row after send — Messages.app may not have queued it"
        if self.is_delivered:
            return "delivered via SMS (iMessage unavailable)" if self.fell_back_to_sms else "delivered"
        if self.is_sent:
            return (
                "sent via SMS (iMessage unavailable), awaiting delivery receipt"
                if self.fell_back_to_sms
                else "sent, awaiting delivery receipt"
            )
        return "SMS fallback pending" if self.fell_back_to_sms else "pending"

    @property
    def status(self) -> str:
        """Short one-word status for UI badges."""
        if self.failed:
            return "failed"
        if self.delivered:
            return "delivered"
        if self.is_sent:
            return "sent"
        if self.osascript_ok:
            return "pending"
        return "failed"


def _run_osascript(script: str) -> None:
    proc = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True, text=True, timeout=OSASCRIPT_TIMEOUT_S,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"osascript failed (exit {proc.returncode}): {proc.stderr.strip()}"
        )


def _escape(s: str) -> str:
    """Escape a string for embedding inside an AppleScript double-quoted literal."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _service_const(service: str) -> str:
    """Map caller-visible service name to the AppleScript identifier."""
    if service == "iMessage":
        return "iMessage"
    if service == "SMS":
        return "SMS"
    raise ValueError(f"unsupported service: {service!r}")


def send_text(handle: str, body: str, service: str = "iMessage") -> None:
    svc = _service_const(service)
    script = f'''
    tell application "Messages"
        set targetService to 1st service whose service type = {svc}
        set targetBuddy to buddy "{_escape(handle)}" of targetService
        send "{_escape(body)}" to targetBuddy
    end tell
    '''
    _run_osascript(script)
    log.info("sent text -> %s len=%d service=%s", handle, len(body), service)


def send_file(handle: str, path: Path, service: str = "iMessage") -> None:
    svc = _service_const(service)
    script = f'''
    tell application "Messages"
        set targetService to 1st service whose service type = {svc}
        set targetBuddy to buddy "{_escape(handle)}" of targetService
        send (POSIX file "{_escape(str(path))}") to targetBuddy
    end tell
    '''
    _run_osascript(script)
    log.info("sent file -> %s path=%s service=%s", handle, path, service)


# Group chats are addressed by chat GUID (e.g. "iMessage;+;chat629…"), not by
# a buddy. AppleScript accepts `chat id "<GUID>"` directly; no service lookup
# is needed because the service is embedded in the GUID itself. No SMS
# fallback for groups — the service is fixed by how the chat was created.

def send_text_to_chat(chat_guid: str, body: str) -> None:
    script = f'''
    tell application "Messages"
        set targetChat to chat id "{_escape(chat_guid)}"
        send "{_escape(body)}" to targetChat
    end tell
    '''
    _run_osascript(script)
    log.info("sent text -> chat=%s len=%d", chat_guid, len(body))


def send_file_to_chat(chat_guid: str, path: Path) -> None:
    script = f'''
    tell application "Messages"
        set targetChat to chat id "{_escape(chat_guid)}"
        send (POSIX file "{_escape(str(path))}") to targetChat
    end tell
    '''
    _run_osascript(script)
    log.info("sent file -> chat=%s path=%s", chat_guid, path)


# ------- chat.db confirmation -------
#
# Apple's `osascript … send` returns success the moment Messages.app accepts
# the command — that's many seconds before iMessage reports delivery or
# failure. To surface real outcomes we poll chat.db for the outgoing row
# Messages.app just wrote, then watch its is_sent / is_delivered / error
# fields update.

_confirm_src: sqlite3.Connection | None = None
_confirm_lock = threading.Lock()


def _confirm_snapshot() -> sqlite3.Connection:
    """Backup-snapshot of chat.db — same pattern as chat_db.ChatDBReader.

    A separate persistent source is kept here so confirmations don't contend
    with the bridge/web long-lived readers. (Each process opens its own; the
    module-global is per-process.)
    """
    global _confirm_src
    with _confirm_lock:
        if _confirm_src is None:
            _confirm_src = sqlite3.connect(
                f"file:{CHAT_DB}?mode=ro", uri=True, check_same_thread=False,
            )
        mem = sqlite3.connect(":memory:")
        mem.row_factory = sqlite3.Row
        _confirm_src.backup(mem)
        return mem


def _max_rowid() -> int:
    conn = _confirm_snapshot()
    try:
        return int(conn.execute(
            "SELECT COALESCE(MAX(ROWID), 0) FROM message"
        ).fetchone()[0])
    finally:
        conn.close()


def _find_outgoing(handle: str, after_rowid: int) -> sqlite3.Row | None:
    """First is_from_me row to `handle` with ROWID > after_rowid, if any."""
    conn = _confirm_snapshot()
    try:
        return conn.execute(
            """
            SELECT m.ROWID AS rowid, h.service AS service,
                   m.is_sent AS is_sent,
                   m.is_delivered AS is_delivered,
                   m.error AS error
            FROM message m LEFT JOIN handle h ON m.handle_id = h.ROWID
            WHERE m.is_from_me = 1
              AND LOWER(h.id) = ?
              AND m.ROWID > ?
            ORDER BY m.ROWID ASC LIMIT 1
            """,
            (handle.lower(), after_rowid),
        ).fetchone()
    finally:
        conn.close()


def _find_outgoing_in_chat(chat_guid: str, after_rowid: int) -> sqlite3.Row | None:
    """First is_from_me row in chat `chat_guid` with ROWID > after_rowid.

    Outgoing group messages have handle_id=NULL (the sender is us, not a peer),
    so the 1:1 matcher can't find them. Join chat_message_join instead. The
    service is derived from the chat's GUID prefix ("iMessage" / "SMS").
    """
    conn = _confirm_snapshot()
    try:
        return conn.execute(
            """
            SELECT m.ROWID AS rowid,
                   c.service_name AS service,
                   m.is_sent AS is_sent,
                   m.is_delivered AS is_delivered,
                   m.error AS error
            FROM message m
            JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
            JOIN chat c ON c.ROWID = cmj.chat_id
            WHERE m.is_from_me = 1
              AND c.guid = ?
              AND m.ROWID > ?
            ORDER BY m.ROWID ASC LIMIT 1
            """,
            (chat_guid, after_rowid),
        ).fetchone()
    finally:
        conn.close()


def _read_row(rowid: int) -> sqlite3.Row | None:
    conn = _confirm_snapshot()
    try:
        return conn.execute(
            """
            SELECT m.ROWID AS rowid, h.service AS service,
                   m.is_sent AS is_sent,
                   m.is_delivered AS is_delivered,
                   m.error AS error
            FROM message m LEFT JOIN handle h ON m.handle_id = h.ROWID
            WHERE m.ROWID = ?
            """,
            (rowid,),
        ).fetchone()
    finally:
        conn.close()


def _confirm(handle: str, after_rowid: int, timeout_s: float) -> SendResult:
    """Poll chat.db for up to timeout_s, reporting the richest state we see."""
    return _confirm_with(
        lambda: _find_outgoing(handle, after_rowid),
        timeout_s,
    )


def _confirm_in_chat(chat_guid: str, after_rowid: int, timeout_s: float) -> SendResult:
    """Same as _confirm but matches the outgoing row by chat GUID. Used for
    group sends where handle_id is NULL on the outgoing row."""
    return _confirm_with(
        lambda: _find_outgoing_in_chat(chat_guid, after_rowid),
        timeout_s,
    )


def _confirm_with(finder, timeout_s: float) -> SendResult:
    deadline = time.monotonic() + timeout_s
    r = SendResult(osascript_ok=True)

    # Phase 1: find the outgoing row Messages.app wrote for this send.
    while time.monotonic() < deadline and r.rowid is None:
        row = finder()
        if row is not None:
            r.rowid = int(row["rowid"])
            r.service = row["service"]
            r.is_sent = bool(row["is_sent"])
            r.is_delivered = bool(row["is_delivered"])
            r.error = int(row["error"] or 0)
            break
        time.sleep(0.3)

    # Phase 2: watch the row until delivered / errored / timed out.
    while r.rowid is not None and time.monotonic() < deadline:
        if r.failed or r.delivered:
            break
        time.sleep(0.5)
        row = _read_row(r.rowid)
        if row is None:
            break
        r.service = row["service"] or r.service
        r.is_sent = bool(row["is_sent"])
        r.is_delivered = bool(row["is_delivered"])
        r.error = int(row["error"] or 0)

    return r


def _should_fallback_to_sms(r: SendResult) -> bool:
    """Auto-retry via SMS only when the iMessage identity is permanently dead.

    Error 22 ("not registered on iMessage") is the one code where iMessage
    will never succeed for this recipient — safe to SMS now without risk of
    Apple later succeeding via iMessage and double-delivering. Other errors
    (3 network, 100 delivery-failed, 102 server-rejected) can be transient,
    so we don't auto-fallback on those.
    """
    return (
        r.osascript_ok
        and r.rowid is not None
        and r.service == "iMessage"
        and r.error == 22
    )


def _send_with_fallback(
    handle: str,
    send_fn,
    payload,
    timeout_s: float,
    kind: str,
) -> SendResult:
    """Run send_fn once as iMessage; on identity error (22) retry via SMS.

    send_fn must accept (handle, payload, service=<str>). Returned SendResult
    describes the SMS attempt when fallback triggered; fell_back_to_sms and
    original_error carry the iMessage error that justified the retry.
    """
    before = _max_rowid()
    try:
        send_fn(handle, payload)
    except Exception:
        log.exception("osascript %s failed", kind)
        return SendResult(osascript_ok=False)
    r = _confirm(handle, before, timeout_s)
    if not _should_fallback_to_sms(r):
        return r

    original_err = r.error
    log.info("iMessage err=%d for %s; retrying via SMS", original_err, handle)
    before2 = _max_rowid()
    try:
        send_fn(handle, payload, service="SMS")
    except Exception:
        log.exception("osascript %s SMS fallback failed", kind)
        r.fell_back_to_sms = True
        r.original_error = original_err
        r.osascript_ok = False
        return r
    r2 = _confirm(handle, before2, timeout_s)
    r2.fell_back_to_sms = True
    r2.original_error = original_err
    return r2


def send_text_confirm(handle: str, body: str, timeout_s: float = 8.0) -> SendResult:
    """send_text + poll chat.db for delivery. Always returns a SendResult.

    On iMessage error 22 (not registered) auto-retries via SMS and returns
    the SMS result with fell_back_to_sms=True.
    """
    return _send_with_fallback(handle, send_text, body, timeout_s, "send_text")


def send_file_confirm(handle: str, path: Path, timeout_s: float = 8.0) -> SendResult:
    return _send_with_fallback(handle, send_file, path, timeout_s, "send_file")


def _send_to_chat_confirm(
    chat_guid: str, send_fn, payload, timeout_s: float, kind: str
) -> SendResult:
    """Send to a group chat and report the outcome.

    No SMS fallback: the chat's service is fixed by its GUID and Messages.app
    handles retries within the chat itself. err=22 on a group iMessage is rare
    and wouldn't be fixable by switching to SMS without the user explicitly
    choosing to switch chat threads.
    """
    before = _max_rowid()
    try:
        send_fn(chat_guid, payload)
    except Exception:
        log.exception("osascript %s to chat failed", kind)
        return SendResult(osascript_ok=False)
    return _confirm_in_chat(chat_guid, before, timeout_s)


def send_text_to_chat_confirm(
    chat_guid: str, body: str, timeout_s: float = 8.0
) -> SendResult:
    return _send_to_chat_confirm(chat_guid, send_text_to_chat, body, timeout_s, "send_text")


def send_file_to_chat_confirm(
    chat_guid: str, path: Path, timeout_s: float = 8.0
) -> SendResult:
    return _send_to_chat_confirm(chat_guid, send_file_to_chat, path, timeout_s, "send_file")
