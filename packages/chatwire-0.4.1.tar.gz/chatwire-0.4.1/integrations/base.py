"""The Integration interface.

A chatwire integration is anything that wants to receive iMessage events
or send iMessages: a Telegram bot, the web UI, a generic webhook poster, an
ntfy push notifier, an SMTP-mirror, etc. Each lives in `integrations/<name>/`
and exposes a class satisfying the `Integration` Protocol below.

The runtime contract:
  - On startup the bridge core builds a `BridgeContext` and calls
    `Integration.start(ctx)` on every enabled integration.
  - Inbound iMessage events (read from chat.db) are pushed to every
    integration via `Integration.on_inbound(msg)`.
  - Outbound is initiated by the integration itself via `ctx.send_text` or
    `ctx.send_file`. The integration owns the trigger (Telegram callback,
    HTTP form submit, etc.); the context handles the iMessage send and
    the cross-integration echo dedup.
  - On shutdown `Integration.stop()` is called.

This module imports nothing integration-specific so it's safe to import from
anywhere — including from a third-party package whose entry-point declares
the integration class.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable

from chat_db import InboundMessage  # re-export for integrations to type against

__all__ = [
    "BridgeContext",
    "InboundMessage",
    "Integration",
    "SendOutcome",
    "SendTarget",
]


@dataclass
class SendTarget:
    """Where an outbound iMessage is going. Either a 1:1 handle (kind="handle",
    value is e.g. "+15551234567") or a group chat (kind="chat", value is the
    AppleScript GUID like "iMessage;+;chat629…").
    """
    kind: str   # "handle" or "chat"
    value: str
    label: str  # human-readable — contact name or group display_name

    @property
    def is_group(self) -> bool:
        return self.kind == "chat"


@dataclass
class SendOutcome:
    """Outcome of an outbound send, in integration-friendly shape.

    `status` is one of "delivered", "sent", "pending", "failed":
      - delivered: peer confirmed receipt (iMessage only; SMS never returns
        a delivery receipt to Messages.app, so successful SMS sends report
        "sent" not "delivered").
      - sent: Messages.app accepted the send but no delivery receipt yet.
      - pending: AppleScript hasn't confirmed even acceptance — usually a
        race with Messages.app's outgoing queue.
      - failed: Messages.app reported an error code; `hint` carries the
        human-readable reason.

    `service` is "iMessage", "SMS", or "" if not yet known.
    `fell_back_to_sms` is True when iMessage was tried first and failed.
    `error` is the Messages.app error code from chat.db (0 on success).
    `original_error` carries the *initial* iMessage error code when
    `fell_back_to_sms` is True; otherwise 0. UI surfaces both so users
    can distinguish "iMessage deregistered, SMS worked" (success with
    diagnostic) from "everything failed" (true failure).
    """
    status: str
    hint: str
    service: str
    fell_back_to_sms: bool
    error: int = 0
    original_error: int = 0


class BridgeContext(Protocol):
    """Surface the bridge core exposes to each integration.

    Integrations don't construct this themselves — the core builds it once
    and passes it to `Integration.start()`. Stash it on `self` if you need
    it later.
    """

    async def send_text(self, target: SendTarget, body: str) -> SendOutcome:
        """Send a text iMessage to `target`. Returns once Messages.app has
        either accepted, rejected, or timed out the send."""
        ...

    async def send_file(self, target: SendTarget, path: Path) -> SendOutcome:
        """Send a file (image / video / arbitrary) to `target`."""
        ...

    def name_for(self, handle: str) -> str | None:
        """Resolve a handle ('+15551234567' or 'name@example.com') to its
        Contacts.app display name. Returns None if the handle isn't in the
        user's address book."""
        ...

    def mirror(self, event: str, **fields: object) -> None:
        """Append one JSONL line to the debug mirror file, if enabled.

        Integrations should call this for outbound sends they originate, so
        cross-integration consumers (notifications, the web UI's SSE feed)
        see them. Inbound mirroring is done by the core before it fans out.
        """
        ...


@runtime_checkable
class Integration(Protocol):
    """The contract every integration satisfies.

    Implement this as a regular class — `runtime_checkable` Protocols don't
    require explicit inheritance, but doing so (e.g. `class TelegramIntegration:`
    with no base) is fine and is what the auto-discovery walker expects.
    """

    NAME: str
    """Stable short name. Used as the config key and for log lines.
    Examples: "telegram", "webhook", "web", "slack". Must be a valid
    Python identifier so it can also be a module name."""

    SETTINGS_SCHEMA: dict
    """JSON Schema describing this integration's config block. The web UI's
    settings page renders form controls from this; the core uses it to
    validate config.json before start(). May be empty `{}` if the
    integration has no settings."""

    async def start(self, ctx: BridgeContext) -> None:
        """Begin running. Connect to the remote service, register handlers,
        spawn background tasks. Should not return until the integration is
        fully ready to receive inbound calls; long-running loops belong in
        tasks spawned here, not in the body of start()."""
        ...

    async def stop(self) -> None:
        """Shut down cleanly. Cancel background tasks, close connections,
        flush state. Called on bridge shutdown and on config reload."""
        ...

    async def on_inbound(self, msg: InboundMessage) -> None:
        """Handle one inbound iMessage event.

        The bridge has already filtered for whitelist scope and bridge-
        echo dedup; the integration just decides how to render this event
        on its surface (post to Telegram, push to a webhook, store in a
        DB, etc.).
        """
        ...
