"""Unit tests for embeddings."""
