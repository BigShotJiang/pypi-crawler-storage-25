# Rendex Python SDK

**Package**: `rendex` (PyPI)
**Parent**: Copperline Labs LLC
**Product**: Rendex (rendex.dev)

## Overview

Official Python SDK for the Rendex screenshot API. Thin wrapper (~80 lines of core logic) around the REST API at api.rendex.dev. Single dependency: `httpx`.

## Architecture

- `src/rendex/client.py` — `Rendex` class with 3 methods: `screenshot`, `screenshot_json`, `screenshot_url`
- `src/rendex/types.py` — TypedDict/dataclass definitions + camelCase conversion helpers
- `src/rendex/errors.py` — Exception hierarchy: `RendexError` → `RendexApiError` / `RendexNetworkError`
- `src/rendex/__init__.py` — Public exports
- `tests/test_client.py` — Unit tests with httpx MockTransport

## Key Design Decisions

- **snake_case API**: Python-idiomatic (`full_page`, `dark_mode`), auto-converts to camelCase for the API.
- **httpx over requests**: Supports sync + async, HTTP/2, modern timeout handling.
- **Context manager**: `with Rendex("key") as r:` for connection reuse.
- **Positional url arg**: `rendex.screenshot("https://example.com")` reads naturally.

## Development

```bash
pip install -e ".[dev]"     # Install in development mode
python -m pytest tests/      # Run tests
python -m mypy src/rendex/   # Type-check
```

## Publishing

Push a `sdk-py-v*` tag to trigger `.github/workflows/publish-sdk-python.yml`.

## Type Sync

Options must match `ScreenshotRequestSchema` in `packages/screenshot-api/src/services/screenshot.ts`. If the API adds new parameters, update `src/rendex/types.py` (snake_case version).
