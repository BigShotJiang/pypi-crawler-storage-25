"""Rendex SDK error classes."""

from __future__ import annotations

from typing import Any, Optional


class RendexError(Exception):
    """Base error for all Rendex SDK errors."""

    pass


class RendexApiError(RendexError):
    """Error returned by the Rendex API (non-2xx response with a parsed body)."""

    def __init__(
        self,
        message: str,
        status_code: int,
        error_code: str,
        request_id: Optional[str] = None,
        details: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        """HTTP status code (e.g. 400, 401, 429, 500)."""
        self.error_code = error_code
        """API error code (e.g. "RATE_LIMITED", "VALIDATION_ERROR")."""
        self.request_id = request_id
        """Unique request ID for debugging with Rendex support."""
        self.details = details
        """Additional error details (e.g. validation field errors)."""

    def __str__(self) -> str:
        parts = [f"[{self.error_code}] {super().__str__()}"]
        if self.request_id:
            parts.append(f"(request: {self.request_id})")
        return " ".join(parts)


class RendexNetworkError(RendexError):
    """Network-level error (DNS failure, timeout, connection refused, etc.)."""

    def __init__(self, message: str, cause: Optional[Exception] = None) -> None:
        super().__init__(message)
        self.__cause__ = cause
