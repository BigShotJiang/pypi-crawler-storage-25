"""Rendex SDK client."""

from __future__ import annotations

from typing import Any
from urllib.parse import urlencode

import httpx

from .errors import RendexApiError, RendexError, RendexNetworkError
from .types import (
    ScreenshotJsonResponse,
    ScreenshotMetadata,
    ScreenshotResult,
    _build_body,
    _to_camel,
)

DEFAULT_BASE_URL = "https://api.rendex.dev"


class Rendex:
    """Official Python client for the Rendex screenshot API.

    Usage::

        from rendex import Rendex

        rendex = Rendex("your-api-key")
        result = rendex.screenshot("https://example.com", full_page=True)
        Path("screenshot.png").write_bytes(result.image)

    Or as a context manager::

        with Rendex("your-api-key") as rendex:
            result = rendex.screenshot("https://example.com")
    """

    def __init__(self, api_key: str, *, base_url: str = DEFAULT_BASE_URL) -> None:
        if not api_key:
            raise RendexError("API key is required. Get one at https://rendex.dev")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=90.0,
        )

    def screenshot(self, url: str, **options: Any) -> ScreenshotResult:
        """Capture a screenshot and return the binary image with metadata.

        Args:
            url: The webpage URL to capture.
            **options: Screenshot options (snake_case). See ScreenshotOptions.

        Returns:
            ScreenshotResult with ``image`` (bytes) and ``metadata``.
        """
        body = _build_body(url, options)
        response = self._request("/v1/screenshot", body)

        metadata = self._parse_metadata_headers(response.headers, len(response.content))

        return ScreenshotResult(image=response.content, metadata=metadata)

    def screenshot_json(self, url: str, **options: Any) -> ScreenshotJsonResponse:
        """Capture a screenshot and return JSON with a base64-encoded image.

        Args:
            url: The webpage URL to capture.
            **options: Screenshot options (snake_case). See ScreenshotOptions.

        Returns:
            ScreenshotJsonResponse with ``data`` and ``meta``.
        """
        body = _build_body(url, options)
        response = self._request("/v1/screenshot/json", body)
        data = response.json()

        if not data.get("success"):
            error = data.get("error", {})
            meta = data.get("meta", {})
            raise RendexApiError(
                message=error.get("message", "Unknown error"),
                status_code=response.status_code,
                error_code=error.get("code", "UNKNOWN"),
                request_id=meta.get("requestId"),
                details=error.get("details"),
            )

        return data  # type: ignore[return-value]

    def screenshot_url(self, url: str, **options: Any) -> str:
        """Generate a signed GET URL for embedding (no network call).

        Useful for ``<img>`` tags, OpenGraph images, or anywhere you need a URL.

        **Note**: The API key is included in the URL. Use server-side only.

        Args:
            url: The webpage URL to capture.
            **options: Screenshot options (snake_case).

        Returns:
            A complete URL string to the screenshot endpoint.
        """
        params: list[tuple[str, str]] = [("key", self._api_key), ("url", url)]

        for key, value in options.items():
            if value is None:
                continue
            camel_key = _to_camel(key)
            if isinstance(value, list):
                for item in value:
                    params.append((camel_key, str(item)))
            elif isinstance(value, bool):
                params.append((camel_key, str(value).lower()))
            else:
                params.append((camel_key, str(value)))

        return f"{self._base_url}/v1/screenshot?{urlencode(params)}"

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> Rendex:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ─── Private ─────────────────────────────────────────────────────

    def _request(self, path: str, body: dict[str, Any]) -> httpx.Response:
        try:
            response = self._client.post(path, json=body)
        except httpx.HTTPError as exc:
            raise RendexNetworkError(
                f"Network request to {self._base_url}{path} failed: {exc}",
                cause=exc,
            ) from exc

        if response.status_code >= 400:
            self._handle_error_response(response)

        return response

    def _handle_error_response(self, response: httpx.Response) -> None:
        try:
            data = response.json()
        except Exception:
            raise RendexApiError(
                message=f"HTTP {response.status_code}",
                status_code=response.status_code,
                error_code="UNKNOWN",
            )

        error = data.get("error", {})
        meta = data.get("meta", {})

        raise RendexApiError(
            message=error.get("message", f"HTTP {response.status_code}"),
            status_code=response.status_code,
            error_code=error.get("code", "UNKNOWN"),
            request_id=meta.get("requestId"),
            details=error.get("details"),
        )

    @staticmethod
    def _parse_metadata_headers(headers: httpx.Headers, fallback_size: int) -> ScreenshotMetadata:
        return ScreenshotMetadata(
            url=headers.get("x-screenshot-url", ""),
            width=int(headers.get("x-screenshot-width", "0")),
            height=int(headers.get("x-screenshot-height", "0")),
            format=headers.get("x-rendex-format", "png"),
            bytes_size=int(headers.get("x-screenshot-size", str(fallback_size))),
            captured_at=headers.get("x-screenshot-captured-at", ""),
            quality=headers.get("x-rendex-quality", "full"),
            wait_strategy=headers.get("x-rendex-wait-strategy", "unknown"),
            load_time_ms=int(headers.get("x-rendex-load-time-ms", "0")),
            truncated=headers.get("x-rendex-truncated") == "true",
        )
