"""Rendex SDK type definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Literal, Optional, TypedDict


class ScreenshotOptions(TypedDict, total=False):
    """Options for capturing a screenshot. Only ``url`` is required."""

    url: str  # Required — set via positional arg in client methods
    format: Literal["png", "jpeg", "webp"]
    width: int
    height: int
    full_page: bool
    quality: int
    delay: int
    dark_mode: bool
    device_scale_factor: float
    block_ads: bool
    block_resource_types: List[Literal["font", "image", "media", "stylesheet", "other"]]
    timeout: int
    wait_until: Literal["load", "domcontentloaded", "networkidle0", "networkidle2"]
    wait_for_selector: str
    best_attempt: bool
    selector: str


class UsageInfo(TypedDict):
    credits: int
    remaining: int


class ResponseMeta(TypedDict, total=False):
    requestId: str
    timestamp: str
    usage: UsageInfo


class ScreenshotData(TypedDict, total=False):
    image: str  # base64
    contentType: str
    url: str
    width: int
    height: int
    format: str
    bytesSize: int
    capturedAt: str
    quality: Literal["full", "degraded", "best_attempt"]
    waitStrategy: str
    loadTimeMs: int
    truncated: bool


class ScreenshotJsonResponse(TypedDict):
    success: bool
    data: ScreenshotData
    meta: ResponseMeta


@dataclass(frozen=True)
class ScreenshotMetadata:
    """Metadata from response headers for binary screenshots."""

    url: str
    width: int
    height: int
    format: str
    bytes_size: int
    captured_at: str
    quality: str  # "full", "degraded", or "best_attempt"
    wait_strategy: str
    load_time_ms: int
    truncated: bool


@dataclass(frozen=True)
class ScreenshotResult:
    """Result from ``Rendex.screenshot()`` — binary image with metadata."""

    image: bytes
    """Raw image bytes. Write to file, upload to S3, etc."""

    metadata: ScreenshotMetadata
    """Capture metadata extracted from response headers."""


# camelCase conversion for API requests
def _to_camel(key: str) -> str:
    """Convert snake_case to camelCase."""
    parts = key.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def _build_body(url: str, options: Any) -> dict[str, Any]:
    """Build the JSON request body from url + snake_case kwargs."""
    body: dict[str, Any] = {"url": url}
    for key, value in options.items():
        if value is not None:
            body[_to_camel(key)] = value
    return body
