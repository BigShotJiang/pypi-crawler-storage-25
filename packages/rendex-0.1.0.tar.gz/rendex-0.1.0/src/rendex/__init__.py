"""Rendex — Official Python SDK for the Rendex screenshot API."""

from .client import Rendex
from .errors import RendexApiError, RendexError, RendexNetworkError
from .types import (
    ScreenshotData,
    ScreenshotJsonResponse,
    ScreenshotMetadata,
    ScreenshotOptions,
    ScreenshotResult,
    ResponseMeta,
    UsageInfo,
)

__version__ = "0.1.0"

__all__ = [
    "Rendex",
    "RendexError",
    "RendexApiError",
    "RendexNetworkError",
    "ScreenshotOptions",
    "ScreenshotResult",
    "ScreenshotMetadata",
    "ScreenshotJsonResponse",
    "ScreenshotData",
    "ResponseMeta",
    "UsageInfo",
]
