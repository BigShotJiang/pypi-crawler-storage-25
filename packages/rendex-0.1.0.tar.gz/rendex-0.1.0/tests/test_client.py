"""Tests for the Rendex Python SDK."""

import json
from unittest.mock import MagicMock

import httpx
import pytest

from rendex import Rendex, RendexApiError, RendexError, RendexNetworkError


# ─── Constructor ──────────────────────────────────────────────────────


def test_missing_api_key():
    with pytest.raises(RendexError, match="API key is required"):
        Rendex("")


def test_custom_base_url():
    client = Rendex("test-key", base_url="https://custom.api.dev/")
    assert client._base_url == "https://custom.api.dev"
    client.close()


# ─── screenshot_url ───────────────────────────────────────────────────


def test_screenshot_url_basic():
    client = Rendex("test-key")
    url = client.screenshot_url("https://example.com")
    assert "key=test-key" in url
    assert "url=https" in url
    assert url.startswith("https://api.rendex.dev/v1/screenshot?")
    client.close()


def test_screenshot_url_with_options():
    client = Rendex("test-key")
    url = client.screenshot_url(
        "https://example.com",
        format="webp",
        full_page=True,
        width=1920,
    )
    assert "format=webp" in url
    assert "fullPage=true" in url
    assert "width=1920" in url
    client.close()


def test_screenshot_url_array_params():
    client = Rendex("test-key")
    url = client.screenshot_url(
        "https://example.com",
        block_resource_types=["font", "image"],
    )
    assert "blockResourceTypes=font" in url
    assert "blockResourceTypes=image" in url
    client.close()


# ─── camelCase conversion ────────────────────────────────────────────


def test_to_camel():
    from rendex.types import _to_camel

    assert _to_camel("full_page") == "fullPage"
    assert _to_camel("dark_mode") == "darkMode"
    assert _to_camel("device_scale_factor") == "deviceScaleFactor"
    assert _to_camel("url") == "url"
    assert _to_camel("block_resource_types") == "blockResourceTypes"


def test_build_body():
    from rendex.types import _build_body

    body = _build_body("https://example.com", {"full_page": True, "dark_mode": False, "quality": None})
    assert body == {"url": "https://example.com", "fullPage": True, "darkMode": False}


# ─── Error handling ──────────────────────────────────────────────────


def test_api_error_str():
    err = RendexApiError(
        message="Rate limit exceeded",
        status_code=429,
        error_code="RATE_LIMITED",
        request_id="req-123",
    )
    assert "[RATE_LIMITED]" in str(err)
    assert "req-123" in str(err)
    assert err.status_code == 429
    assert err.error_code == "RATE_LIMITED"


def test_api_error_no_request_id():
    err = RendexApiError(
        message="Bad request",
        status_code=400,
        error_code="VALIDATION_ERROR",
    )
    assert "[VALIDATION_ERROR]" in str(err)
    assert "request:" not in str(err)


# ─── Context manager ────────────────────────────────────────────────


def test_context_manager():
    with Rendex("test-key") as client:
        assert client._api_key == "test-key"
    # Should not raise after close


# ─── Mocked HTTP tests ──────────────────────────────────────────────


def test_screenshot_json_success():
    """Test screenshotJson with a mocked transport."""
    mock_response_data = {
        "success": True,
        "data": {
            "image": "iVBORw0KGgo=",
            "contentType": "image/png",
            "url": "https://example.com",
            "width": 1280,
            "height": 800,
            "format": "png",
            "bytesSize": 1234,
            "capturedAt": "2026-04-02T00:00:00Z",
            "quality": "full",
            "waitStrategy": "networkidle2",
            "loadTimeMs": 500,
        },
        "meta": {
            "requestId": "req-abc",
            "timestamp": "2026-04-02T00:00:00Z",
            "usage": {"credits": 1, "remaining": 499},
        },
    }

    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            200,
            json=mock_response_data,
        )
    )

    client = Rendex("test-key")
    client._client = httpx.Client(
        base_url="https://api.rendex.dev",
        headers={"Authorization": "Bearer test-key", "Content-Type": "application/json"},
        transport=transport,
        timeout=90.0,
    )

    result = client.screenshot_json("https://example.com")
    assert result["success"] is True
    assert result["data"]["bytesSize"] == 1234
    assert result["meta"]["usage"]["remaining"] == 499
    client.close()


def test_screenshot_binary_success():
    """Test screenshot with mocked binary response + headers."""
    fake_image = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100

    transport = httpx.MockTransport(
        lambda request: httpx.Response(
            200,
            content=fake_image,
            headers={
                "content-type": "image/png",
                "x-screenshot-url": "https://example.com",
                "x-screenshot-width": "1280",
                "x-screenshot-height": "800",
                "x-screenshot-size": str(len(fake_image)),
                "x-screenshot-captured-at": "2026-04-02T00:00:00Z",
                "x-rendex-format": "png",
                "x-rendex-quality": "full",
                "x-rendex-wait-strategy": "networkidle2",
                "x-rendex-load-time-ms": "350",
            },
        )
    )

    client = Rendex("test-key")
    client._client = httpx.Client(
        base_url="https://api.rendex.dev",
        headers={"Authorization": "Bearer test-key", "Content-Type": "application/json"},
        transport=transport,
        timeout=90.0,
    )

    result = client.screenshot("https://example.com")
    assert result.image == fake_image
    assert result.metadata.width == 1280
    assert result.metadata.format == "png"
    assert result.metadata.load_time_ms == 350
    assert result.metadata.truncated is False
    client.close()


def test_api_error_response():
    """Test that API errors are properly parsed."""
    error_body = {
        "success": False,
        "error": {
            "code": "RATE_LIMITED",
            "message": "Rate limit exceeded",
        },
        "meta": {
            "requestId": "req-xyz",
            "timestamp": "2026-04-02T00:00:00Z",
        },
    }

    transport = httpx.MockTransport(
        lambda request: httpx.Response(429, json=error_body)
    )

    client = Rendex("test-key")
    client._client = httpx.Client(
        base_url="https://api.rendex.dev",
        headers={"Authorization": "Bearer test-key", "Content-Type": "application/json"},
        transport=transport,
        timeout=90.0,
    )

    with pytest.raises(RendexApiError) as exc_info:
        client.screenshot("https://example.com")

    assert exc_info.value.status_code == 429
    assert exc_info.value.error_code == "RATE_LIMITED"
    assert exc_info.value.request_id == "req-xyz"
    client.close()
