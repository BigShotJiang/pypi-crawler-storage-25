"""
AxiomCore - Autonomous ML Optimization Framework
"""

__version__ = "0.1.0"
__author__ = "AxiomCore Team"
__license__ = "MIT"

# Make CLI accessible
from axiomcore_pkg import cli

__all__ = ['cli', '__version__']

# Made with Bob
