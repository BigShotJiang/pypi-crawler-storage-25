# Calcuwidg
Calcuwidg is an easy Python library for creating calculators in Tkinter.
Example usage:
```python
from calcuwidg import *
from tkinter import *
import tkinter as tk
w=tk.Tk()
w.geometry("400x400")
w.title("Calcuwidg Example")

calc=Calcuwidg(tkinter-window=w, operators=["+","-","*","/"], btn-color="black")

w.mainloop()
```