from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="calcuwidg",
    version="1.0.0",
    author="Your Name",
    author_email="dusablon.ben@icloud.com",
    description="A Tkinter addon for easy calculator widget creation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/calcuwidg",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3.14",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: User Interfaces",
    ],
    python_requires='>=3.7',
    install_requires=[], # Tkinter is standard lib, so no extra requirements
    include_package_data=True,
)