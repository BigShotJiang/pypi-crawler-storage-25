# fasr-punc-ct-transformer

基于 CT-Transformer 的标点恢复模型插件，为 fasr 提供中英文混合标点恢复能力。

## 安装

```bash
pip install fasr-punc-ct-transformer
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `ct_transformer` | `CTTransformerForPunc` | `iic/punc_ct-transformer_zh-cn-common-vocab272727-pytorch` | CT-Transformer 标点恢复，支持中英文混合 |

模型权重默认从 ModelScope 自动下载。

## 使用方式

### 在流水线中使用

标点模型通常作为 `sentencizer` 组件在流水线末端使用：

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="fsmn")
    .add_pipe("recognizer", model="paraformer")
    .add_pipe("sentencizer", model="ct_transformer")
)
```

### 单独使用模型

```python
from fasr.config import registry

model = registry.punc_models.get("ct_transformer")()
model.from_checkpoint()

spans = model.restore("今天天气真好我想出去玩你觉得呢")
for span in spans:
    print(span.text)  # 带标点的句子
```

## `from_checkpoint` 参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint_dir` | `str \| Path \| None` | `None`（自动下载） | 模型权重目录 |
| `disable_update` | `bool` | `True` | 禁用 FunASR 自动更新检查 |
| `disable_log` | `bool` | `True` | 禁用 FunASR 日志输出 |
| `disable_pbar` | `bool` | `True` | 禁用进度条 |

额外 `**kwargs` 会直接传递给 `funasr.AutoModel()`。

## 依赖

- `fasr`
- `funasr`
- Python 3.10–3.12
