"""OpenRunner SDK - W&B-compatible ML experiment tracking.

Public API:
    openrunner.init(project=..., name=..., config=...)  -> Run
    openrunner.log({"loss": 0.5}, step=10)              -> None
    openrunner.finish(exit_code=0)                      -> None
    openrunner.config       -> Config proxy
    openrunner.summary      -> Summary proxy
    openrunner.run          -> active Run or None
    openrunner.Image        -> Image class for media logging
    openrunner.Html         -> Html class for raw HTML logging
    openrunner.Table        -> Table class for structured data
    openrunner.JoinedTable  -> Merge two Tables on a common column
    openrunner.Audio        -> Audio class for audio logging
    openrunner.Video        -> Video class for video logging
    openrunner.Histogram    -> Histogram class for distribution logging
    openrunner.Plotly       -> Plotly class for interactive charts
    openrunner.PlotlyChart  -> Enhanced Plotly with static PNG fallback
    openrunner.MatplotlibFigure -> Capture matplotlib figure as PNG
    openrunner.PointCloud3D -> 3D point cloud visualization
    openrunner.Embedding    -> Embedding projection (t-SNE/PCA/UMAP)
    openrunner.BoundingBoxes2D -> Bounding box overlay on images
    openrunner.Classes      -> Shared label set for masks/boxes
    openrunner.Transcript   -> Speech-to-text transcript with word timestamps
    openrunner.AudioComparison -> Side-by-side audio comparison (TTS eval)
    openrunner.SpectrogramImage -> Spectrogram visualization (mel/STFT/MFCC)
    openrunner.Artifact     -> Artifact class for versioned file collections
    openrunner.Api          -> Query API for read-only access to runs/projects
    openrunner.define_metric -> Define custom x-axis, summary aggregation
    openrunner.alert        -> Send an alert for the active run
    openrunner.log_artifact -> Upload an artifact
    openrunner.use_artifact -> Download an artifact (cached)
    openrunner.sweep        -> Create a hyperparameter sweep
    openrunner.agent        -> Run a sweep agent loop
    openrunner.launch       -> Create a remote execution job
    openrunner.launch.from_run -> Re-launch from a previous run's config
    openrunner.LaunchJob    -> Job handle with .wait() and .cancel()
    openrunner.trace        -> Decorator for LLM call tracing (supports sample_rate)
    openrunner.trace.patch_openai -> Auto-trace OpenAI chat completions
    openrunner.Prompt       -> Versioned prompt management (get/render/publish)
    openrunner.StringPrompt -> Client-side string template with format()
    openrunner.MessagesPrompt -> Multi-turn chat prompt template
    openrunner.Model        -> Versioned model with predict/save/load/serve
    openrunner.Dataset      -> Versioned dataset for evaluations
    openrunner.add_cost     -> Register custom LLM cost per model
    openrunner.evaluate     -> Run LLM evaluation against a dataset
    openrunner.scorer       -> Decorator to mark a function as an eval scorer
    openrunner.Scorer       -> Base class for class-based evaluation scorers
    openrunner.EvaluationLogger -> Log evaluation results piecemeal
    openrunner.scorers      -> Built-in scorers (exact_match, contains, LLM-as-judge)
    openrunner.plot.line    -> Create a line chart from a Table
    openrunner.plot.scatter -> Create a scatter chart from a Table
    openrunner.plot.bar     -> Create a bar chart from a Table
    openrunner.plot.histogram -> Create a histogram from a Table column
    openrunner.plot.pr_curve -> Create precision-recall curves
    openrunner.plot.roc_curve -> Create ROC curves with AUC
    openrunner.plot.confusion_matrix -> Create an interactive confusion matrix
    openrunner.plot.plot_table -> Custom chart from Table + field mapping
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from openrunner.artifact import Artifact
from openrunner.config import Config
from openrunner.model import Model
from openrunner.prompt import MessagesPrompt, Prompt, StringPrompt
from openrunner.launch import LaunchJob, launch, from_run as _launch_from_run
from openrunner.media import (
    Audio,
    AudioComparison,
    BoundingBoxes2D,
    Classes,
    Embedding,
    Histogram,
    Html,
    Image,
    JoinedTable,
    MatplotlibFigure,
    Molecule,
    Plotly,
    PlotlyChart,
    PointCloud3D,
    SpectrogramImage,
    Table,
    Transcript,
    Video,
)
from openrunner.cost import add_cost
from openrunner.dataset import Dataset
from openrunner.query_api import Api
from openrunner.run import Run
from openrunner.settings import SDKSettings
from openrunner.summary import Summary
from openrunner.sweep import agent, sweep
from openrunner.evaluation import EvaluationLogger, Scorer, evaluate, scorer
from openrunner.wer import WERScorer, compute_wer, compute_wer_batch
from openrunner.guardrails import (
    GuardrailCheckResult,
    GuardrailResult,
    add_guardrail,
    check_guardrails,
    clear_guardrails,
    remove_guardrail,
)
from openrunner.feedback import add_feedback, get_feedback
from openrunner.pii import configure_pii, redact
from openrunner.trace import trace, patch_openai as _patch_openai, set_thread_id, set_session_id
import openrunner.scorers as scorers
import openrunner.plot as plot

# Attach from_run as a method on the launch function for
# openrunner.launch.from_run() syntax
launch.from_run = _launch_from_run  # type: ignore[attr-defined]

# Attach patch_openai as a method on the trace function for
# openrunner.trace.patch_openai() syntax
trace.patch_openai = _patch_openai  # type: ignore[attr-defined]

__version__ = "2.12.0"

logger = logging.getLogger("openrunner")

# Active run state
_active_run: Run | None = None

# Setup settings for multi-process safety (set by setup())
_setup_settings: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Disabled-mode no-op run
# ---------------------------------------------------------------------------

class _DisabledRun:
    """No-op run for mode='disabled'. All calls are silent.

    Returned by ``init()`` when the SDK mode is set to ``"disabled"``.
    Every public method is a no-op; no network calls, file writes, or
    stdout capture occurs.
    """

    id = "disabled"
    name = "disabled"
    project = ""
    config = Config()
    summary = Summary()
    should_stop = False
    entity = None
    url = ""

    def log(self, *args: Any, **kwargs: Any) -> None:
        pass

    def finish(self, *args: Any, **kwargs: Any) -> None:
        pass

    def define_metric(self, *args: Any, **kwargs: Any) -> None:
        pass

    def define_computed_metric(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_artifact(self, *args: Any, **kwargs: Any) -> None:
        return None

    def finish_artifact(self, *args: Any, **kwargs: Any) -> None:
        return None

    def link_artifact(self, *args: Any, **kwargs: Any) -> None:
        return None

    def use_artifact(self, *args: Any, **kwargs: Any) -> None:
        return None

    def alert(self, *args: Any, **kwargs: Any) -> None:
        return None

    def log_text(self, *args: Any, **kwargs: Any) -> None:
        pass

    def log_code(self, *args: Any, **kwargs: Any) -> None:
        return None

    def mark_preempting(self) -> None:
        pass

    def status(self) -> dict:
        return {}

    def join(self, timeout: float | None = None) -> None:
        pass

    def log_model(self, *args: Any, **kwargs: Any) -> None:
        pass

    def use_model(self, *args: Any, **kwargs: Any) -> None:
        return None

    def link_model(self, *args: Any, **kwargs: Any) -> None:
        pass

    def get_url(self) -> str:
        return ""

    def get_project_url(self) -> str:
        return ""

    start_time = None
    sweep_id = None
    dir = ""
    path = ("", "", "disabled")


# ---------------------------------------------------------------------------
# Proxy objects for module-level config/summary access
# ---------------------------------------------------------------------------

class _ConfigProxy:
    """Proxy that delegates attribute access to the active run's Config.

    Since Python modules can't have properties, this proxy object sits
    at ``openrunner.config`` and forwards all access to ``_active_run.config``.
    """

    def __getattr__(self, name: str) -> Any:
        if _active_run is not None:
            return getattr(_active_run.config, name)
        raise AttributeError(f"No active run -- call openrunner.init() first")

    def __setattr__(self, name: str, value: Any) -> None:
        if _active_run is not None:
            setattr(_active_run.config, name, value)
        else:
            logger.warning("openrunner.config: no active run -- call openrunner.init() first")

    def __getitem__(self, key: str) -> Any:
        if _active_run is not None:
            return _active_run.config[key]
        raise KeyError(f"No active run -- call openrunner.init() first")

    def __setitem__(self, key: str, value: Any) -> None:
        if _active_run is not None:
            _active_run.config[key] = value
        else:
            logger.warning("openrunner.config: no active run -- call openrunner.init() first")

    def __repr__(self) -> str:
        if _active_run is not None:
            return repr(_active_run.config)
        return "ConfigProxy(no active run)"


class _SummaryProxy:
    """Proxy that delegates attribute access to the active run's Summary."""

    def __getattr__(self, name: str) -> Any:
        if _active_run is not None:
            return getattr(_active_run.summary, name)
        raise AttributeError(f"No active run -- call openrunner.init() first")

    def __setattr__(self, name: str, value: Any) -> None:
        if _active_run is not None:
            setattr(_active_run.summary, name, value)
        else:
            logger.warning("openrunner.summary: no active run -- call openrunner.init() first")

    def __getitem__(self, key: str) -> Any:
        if _active_run is not None:
            return _active_run.summary[key]
        raise KeyError(f"No active run -- call openrunner.init() first")

    def __setitem__(self, key: str, value: Any) -> None:
        if _active_run is not None:
            _active_run.summary[key] = value
        else:
            logger.warning("openrunner.summary: no active run -- call openrunner.init() first")

    def __repr__(self) -> str:
        if _active_run is not None:
            return repr(_active_run.summary)
        return "SummaryProxy(no active run)"


# Module-level proxy instances
config = _ConfigProxy()
summary = _SummaryProxy()


# ---------------------------------------------------------------------------
# Public API functions
# ---------------------------------------------------------------------------


def setup(settings: dict[str, Any] | None = None) -> None:
    """Initialize OpenRunner service for multi-process safety.

    Call this in the main process before spawning child processes
    to ensure proper initialization. This is a no-op in single-process
    mode but ensures the settings are cached for child processes.

    Args:
        settings: Optional dict of settings overrides (e.g.,
            ``{"base_url": "...", "api_key": "..."}``).
    """
    global _setup_settings
    _setup_settings = settings or {}


def _load_config_defaults() -> dict:
    """Load config-defaults.yaml if it exists in CWD.

    Searches for ``config-defaults.yaml`` or ``config-defaults.yml`` in the
    current working directory. Returns the parsed dict, or an empty dict if
    no file is found or parsing fails.
    """
    import os

    for name in ("config-defaults.yaml", "config-defaults.yml"):
        path = os.path.join(os.getcwd(), name)
        if os.path.exists(path):
            try:
                import yaml  # type: ignore[import-untyped]

                with open(path) as f:
                    data = yaml.safe_load(f)
                if isinstance(data, dict):
                    return data
            except ImportError:
                logger.debug(
                    "PyYAML not installed; skipping config-defaults.yaml. "
                    "Install with: pip install pyyaml"
                )
            except Exception:
                pass
    return {}


def init(
    project: str | None = None,
    name: str | None = None,
    config: dict[str, Any] | None = None,
    tags: list[str] | None = None,
    notes: str | None = None,
    group: str | None = None,
    job_type: str | None = None,
    id: str | None = None,
    resume: bool | str | None = None,
    fork_from: str | None = None,
    resume_from: str | None = None,
    reinit: bool = False,
    save_code: bool | str | None = True,
    sync_tensorboard_path: bool | str | None = None,
    config_exclude_keys: list[str] | None = None,
    config_include_keys: list[str] | None = None,
    allow_val_change: bool = False,
    **kwargs: Any,
) -> Run | None:
    """Initialize a new run.

    Creates a run on the server, starts the background sender thread,
    and returns the Run object. Never raises -- SDK failures must not
    crash training code.

    Args:
        project: Project name (or OPENRUNNER_PROJECT env var, or "uncategorized").
        name: Display name for the run.
        config: Hyperparameter dict (sent to server at init time, SDK-12).
        tags: List of tags for the run.
        notes: Notes/description for the run.
        group: Group name for related runs.
        job_type: Job type label.
        id: Custom run ID (8-char alphanumeric generated if not provided).
        resume: Resume mode -- True/"allow" (resume if exists, fresh otherwise)
                or "must" (error if parent not found). The ``id`` parameter
                is treated as the parent run ID when resuming.
        fork_from: Fork from an existing run. Format: "run_id?_step=N" or
                   just "run_id" (fork from latest step). Creates a new run
                   that continues from the parent's metrics.
        resume_from: Resume from a specific step. Format: "run_id?_step=N" or
                     just "run_id". Truncates the parent run's history at that
                     step and continues as the same run.
        reinit: If True and an active run exists, finish it before creating
                a new one. If False (default), warn and return the existing run.
        save_code: Capture source code as an artifact at init time (default: True).
                   ``True`` captures ``.py`` files from the current directory.
                   A string path captures ``.py`` files from that directory.
                   ``False`` / ``None`` disables.
        sync_tensorboard_path: Import TensorBoard event files after run creation.
                   A string path imports from that directory.
                   ``True`` searches the current directory for ``tfevent`` files.
                   ``None`` / ``False`` disables (default).
        config_exclude_keys: List of config keys to exclude from logging.
                   If both exclude and include are specified, exclude is
                   applied first (but typically use one or the other).
        config_include_keys: List of config keys to include (whitelist).
                   Only these keys will be sent to the server.
        allow_val_change: If True, allow overwriting existing config values.
                   If False (default), setting a config key that already has
                   a different value raises ValueError.

    Returns:
        The Run object, or None if initialization fails.
    """
    global _active_run

    try:
        # Convert argparse.Namespace or similar objects to dict (Gap #49)
        if config is not None and hasattr(config, '__dict__') and not isinstance(config, dict):
            config = vars(config)

        # Load YAML config defaults and merge under explicit config (Gap #50)
        yaml_defaults = _load_config_defaults()
        if yaml_defaults:
            config = {**yaml_defaults, **(config or {})}

        # Handle reinit behavior
        if _active_run is not None:
            if reinit:
                _active_run.finish(quiet=True)
                _active_run = None
            else:
                logger.warning(
                    "openrunner.init() called with an active run (%s). "
                    "Use reinit=True to finish the existing run first.",
                    _active_run.id,
                )
                return _active_run

        settings = SDKSettings()

        # Merge setup() settings if they were cached
        if _setup_settings:
            for key, val in _setup_settings.items():
                if hasattr(settings, key) and getattr(settings, key) is None:
                    object.__setattr__(settings, key, val)

        # Disabled mode: return a no-op run immediately
        if settings.mode == "disabled":
            _active_run = _DisabledRun()
            return _active_run

        # Apply env var defaults from settings for parameters not explicitly passed
        if name is None and settings.name:
            name = settings.name
        if tags is None and settings.tags:
            tags = [t.strip() for t in settings.tags.split(",") if t.strip()]
        if notes is None and settings.notes:
            notes = settings.notes
        if group is None and settings.run_group:
            group = settings.run_group
        if job_type is None and settings.job_type:
            job_type = settings.job_type
        if id is None and settings.run_id:
            id = settings.run_id
        if resume is None and settings.resume:
            resume = settings.resume

        # Resolve project
        resolved_project = project or settings.project or "uncategorized"

        # Warn if no API key (skip in offline mode)
        if not settings.api_key and settings.mode != "offline":
            logger.warning(
                "No API key set. Set OPENRUNNER_API_KEY or WANDB_API_KEY "
                "environment variable for server communication."
            )

        # Filter config keys before passing to Run
        filtered_config = dict(config) if config else None
        if filtered_config:
            if config_exclude_keys:
                filtered_config = {
                    k: v for k, v in filtered_config.items()
                    if k not in config_exclude_keys
                }
            if config_include_keys:
                filtered_config = {
                    k: v for k, v in filtered_config.items()
                    if k in config_include_keys
                }

        # Create run
        run = Run(
            project=resolved_project,
            name=name,
            config_dict=filtered_config,
            tags=tags,
            notes=notes,
            group=group,
            job_type=job_type,
            run_id=id,
            settings=settings,
            resume=resume,
            fork_from=fork_from,
            resume_from=resume_from,
            allow_val_change=allow_val_change,
        )

        _active_run = run

        # Auto-capture source code if requested
        if save_code:
            try:
                code_root = save_code if isinstance(save_code, str) else "."
                run.log_code(code_root)
            except Exception as e:
                logger.warning("openrunner.init() save_code failed: %s", e)

        # Auto-import TensorBoard logs if requested
        if sync_tensorboard_path:
            try:
                import glob as _glob

                if isinstance(sync_tensorboard_path, str):
                    tb_dir = sync_tensorboard_path
                else:
                    # True: search current directory for tfevent files
                    import os as _os

                    tb_dir = None
                    for f in _glob.glob(
                        _os.path.join(_os.getcwd(), "**", "*.tfevents.*"),
                        recursive=True,
                    ):
                        tb_dir = _os.path.dirname(f)
                        break

                if tb_dir:
                    sync_tensorboard(tb_dir, run=run)
                else:
                    logger.info(
                        "sync_tensorboard=True but no tfevent files found "
                        "in current directory"
                    )
            except Exception as e:
                logger.warning("openrunner.init() sync_tensorboard failed: %s", e)

        return run

    except Exception as e:
        logger.warning("openrunner.init() failed: %s", e)
        return None


def log_code(
    root: str = ".",
    name: str | None = None,
    include_fn: Any = None,
    exclude_fn: Any = None,
) -> dict[str, Any] | None:
    """Capture source code as an artifact for the active run. Never raises.

    Walks the directory tree starting at ``root``, collects matching files,
    and uploads them as a versioned artifact of type ``"code"``.

    Args:
        root: Root directory to capture (default: current directory).
        name: Artifact name (default: ``"source-code"``).
        include_fn: Optional filter ``(path: str) -> bool``.
        exclude_fn: Optional filter ``(path: str) -> bool``.

    Returns:
        Server response dict with version info, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.log_code(): no active run")
            return None
        return _active_run.log_code(
            root=root, name=name, include_fn=include_fn, exclude_fn=exclude_fn
        )
    except Exception as e:
        logger.warning("openrunner.log_code() failed: %s", e)
        return None


def log(
    data: dict[str, Any],
    step: int | None = None,
    commit: bool = True,
) -> None:
    """Log metrics. Never raises -- training must not be interrupted.

    Args:
        data: Dict of metric key-value pairs.
        step: Explicit step value.
        commit: If True (default), finalize the current step.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.log(): no active run -- call openrunner.init() first")
            return
        _active_run.log(data, step=step, commit=commit)
    except Exception as e:
        logger.warning("openrunner.log() failed: %s", e)


def finish(
    exit_code: int | None = None,
    quiet: bool | None = None,
) -> None:
    """Finish the active run. Never raises.

    Args:
        exit_code: Optional exit code.
        quiet: If True, suppress the finish message.
    """
    global _active_run

    try:
        if _active_run is None:
            return
        _active_run.finish(exit_code=exit_code, quiet=quiet or False)
        _active_run = None
    except Exception as e:
        logger.warning("openrunner.finish() failed: %s", e)
        _active_run = None


def alert(
    title: str,
    text: str | None = None,
    level: str = "INFO",
    wait_duration: float | None = None,
) -> dict[str, Any] | None:
    """Send an alert for the active run. Never raises.

    Alerts are stored on the server and dispatched to configured
    notification channels (console, Slack webhook).

    Args:
        title: Short alert title.
        text: Detailed alert description (optional).
        level: Alert severity -- INFO, WARN, or ERROR. Default INFO.
        wait_duration: Minimum seconds between alerts with the same
            title. If set and the same title was alerted less than
            ``wait_duration`` seconds ago, the alert is silently
            skipped (throttled).

    Returns:
        Server response dict with alert details, or None on failure
        or throttled.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.alert(): no active run -- call openrunner.init() first")
            return None
        return _active_run.alert(
            title=title, text=text, level=level, wait_duration=wait_duration,
        )
    except Exception as e:
        logger.warning("openrunner.alert() failed: %s", e)
        return None


def log_artifact(artifact: Artifact) -> dict[str, Any] | None:
    """Upload an artifact to the active run. Never raises.

    Args:
        artifact: The Artifact object with files added via add_file/add_dir.

    Returns:
        Server response dict with version info, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.log_artifact(): no active run")
            return None
        return _active_run.log_artifact(artifact)
    except Exception as e:
        logger.warning("openrunner.log_artifact() failed: %s", e)
        return None


def finish_artifact(artifact: Artifact) -> dict[str, Any] | None:
    """Finalize an artifact that was incrementally built. Never raises.

    Flushes any buffered data and confirms the artifact upload.
    This is called automatically by log_artifact(), but can be
    called explicitly for artifacts built incrementally.

    Args:
        artifact: The Artifact object to finalize.

    Returns:
        Server response dict with version info, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.finish_artifact(): no active run")
            return None
        return _active_run.finish_artifact(artifact)
    except Exception as e:
        logger.warning("openrunner.finish_artifact() failed: %s", e)
        return None


def link_artifact(
    artifact: Artifact, aliases: list[str] | None = None
) -> dict[str, Any] | None:
    """Upload an artifact and set aliases. Never raises.

    Combines log_artifact with alias setting. Useful for model registry
    workflows where you want to tag a version as "production" or "staging".

    Args:
        artifact: The Artifact object with files added via add_file/add_dir.
        aliases: List of alias names to set (e.g., ["production"]).

    Returns:
        Server response dict with version info, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.link_artifact(): no active run")
            return None
        return _active_run.link_artifact(artifact, aliases=aliases)
    except Exception as e:
        logger.warning("openrunner.link_artifact() failed: %s", e)
        return None


def use_artifact(
    name: str, version: int | None = None, alias: str | None = None
) -> Path | None:
    """Download an artifact and cache locally. Never raises.

    Supports alias-based lookup and "name:alias" syntax
    (e.g., "my-model:production").

    Args:
        name: Artifact name. Can use "name:alias" syntax.
        version: Specific version number, or None for latest.
        alias: Alias name to resolve (e.g., "production").

    Returns:
        Path to the local artifact directory, or None on failure.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.use_artifact(): no active run")
            return None
        return _active_run.use_artifact(name, version, alias)
    except Exception as e:
        logger.warning("openrunner.use_artifact() failed: %s", e)
        return None


def should_stop() -> bool:
    """Check if the server has requested the active run to stop.

    Returns False if no active run. Users call this in their training
    loop: ``if openrunner.should_stop(): break``
    """
    if _active_run is None:
        return False
    return _active_run.should_stop


def log_text(text: str) -> None:
    """Log explicit text to the console log without printing. Never raises.

    Args:
        text: Text string to log.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.log_text(): no active run")
            return
        _active_run.log_text(text)
    except Exception as e:
        logger.warning("openrunner.log_text() failed: %s", e)


def define_metric(
    name: str,
    step_metric: str | None = None,
    step_sync: bool | None = None,
    summary: str | None = None,
    goal: str | None = None,
    hidden: bool = False,
    overwrite: bool = False,
) -> None:
    """Define how a metric is tracked and summarized. Never raises.

    Module-level convenience -- delegates to the active run's
    ``define_metric()`` method. Supports glob patterns.

    Args:
        name: Metric key name or glob pattern (e.g., ``"train/*"``).
        step_metric: Use this metric's value as the x-axis instead of _step.
        step_sync: If True, sync step values with the step_metric.
        summary: Aggregation mode: "min", "max", "mean", "last", "best",
            "copy", or "none".
        goal: "minimize" or "maximize" -- used with summary="best".
        hidden: If True, the frontend should not render a chart.
        overwrite: If True, replace any existing definition for this name.
    """
    try:
        if _active_run is None:
            logger.warning("openrunner.define_metric(): no active run -- call openrunner.init() first")
            return
        _active_run.define_metric(
            name,
            step_metric=step_metric,
            step_sync=step_sync,
            summary=summary,
            goal=goal,
            hidden=hidden,
            overwrite=overwrite,
        )
    except Exception as e:
        logger.warning("openrunner.define_metric() failed: %s", e)


def define_computed_metric(name: str, expression: str) -> None:
    """Define a computed metric from an expression. Never raises.

    Supports basic arithmetic on existing metrics:
    - ``"train/loss - val/loss"`` computes the difference
    - ``"accuracy * 100"`` scales a metric
    - ``"loss / initial_loss"`` normalizes

    The expression is evaluated client-side using logged metric values
    at each step.

    Args:
        name: Name for the computed metric.
        expression: Arithmetic expression referencing other metric keys.
    """
    try:
        if _active_run is None:
            logger.warning(
                "openrunner.define_computed_metric(): no active run "
                "-- call openrunner.init() first"
            )
            return
        _active_run.define_computed_metric(name, expression)
    except Exception as e:
        logger.warning("openrunner.define_computed_metric() failed: %s", e)


def sync_tensorboard(
    logdir: str,
    run: Run | None = None,
    root_logdir: str | None = None,
    project: str | None = None,
) -> Run | None:
    """Import TensorBoard event files into an OpenRunner run. Never raises.

    Reads scalar metrics from TensorBoard event files and logs them
    to an OpenRunner run. Creates a new run if one is not provided.

    Args:
        logdir: Path to TensorBoard log directory.
        run: Optional active OpenRunner run (creates one if ``None``).
        root_logdir: Root directory for relative path computation.
        project: Project name (used when creating a new run).

    Returns:
        The OpenRunner run, or None on failure.
    """
    try:
        from openrunner.tensorboard import sync_tensorboard as _sync
        return _sync(logdir, run=run, root_logdir=root_logdir, project=project)
    except Exception as e:
        logger.warning("openrunner.sync_tensorboard() failed: %s", e)
        return None


@property  # type: ignore[misc]
def run() -> Run | None:
    """Return the active run, or None."""
    return _active_run
