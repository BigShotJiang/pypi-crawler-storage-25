# Animation design notes

## `dirplot watch` — is non-animated mode useful?

The watch command has two modes:

- **Non-animated** (`dirplot watch . --output treemap.png`): regenerates and overwrites the
  PNG on every debounced filesystem change. Useful paired with an auto-refreshing image
  viewer (e.g. `feh --reload` on Linux) as a live dashboard.
- **Animated** (`dirplot watch . --output treemap.mp4 --animate`): each debounced render
  becomes one frame; the complete APNG or MP4 is written on Ctrl-C.

The non-animated mode is a niche use case. The compelling reason to use `dirplot watch`
at all — vs. running `dirplot map .` on demand — is the animation: a timelapse of how
the filesystem changed over time.

The current design is also asymmetric: `--animate` produces a file *on exit*, while
non-animated produces a file *on every change*. They're almost opposite behaviours on
the same command.

### Options to consider

1. **Keep as-is**, but lead the docs with `--animate` as the primary use case.
2. **Make `--animate` the default** for `watch`, keeping `--no-animate` for the
   live-refresh use case — but this is a breaking change.
3. **Document the live-refresh pattern explicitly** so non-animated mode doesn't look
   like a half-baked feature.
