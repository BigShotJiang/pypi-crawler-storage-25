========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/keystonemiddleware.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

Middleware for the OpenStack Identity API (Keystone)
====================================================

.. image:: https://img.shields.io/pypi/v/keystonemiddleware.svg
    :target: https://pypi.org/project/keystonemiddleware/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/keystonemiddleware.svg
    :target: https://pypi.org/project/keystonemiddleware/
    :alt: Downloads

This package contains middleware modules designed to provide authentication and
authorization features to web services other than `Keystone
<https://github.com/openstack/keystone>`. The most prominent module is
``keystonemiddleware.auth_token``. This package does not expose any CLI or
Python API features.

For information on contributing, see ``CONTRIBUTING.rst``.

* License: Apache License, Version 2.0
* Documentation: https://docs.openstack.org/keystonemiddleware/latest/
* Source: https://opendev.org/openstack/keystonemiddleware
* Bugs: https://bugs.launchpad.net/keystonemiddleware
* Release notes: https://docs.openstack.org/releasenotes/keystonemiddleware/

For any other information, refer to the parent project, Keystone:

    https://github.com/openstack/keystone
