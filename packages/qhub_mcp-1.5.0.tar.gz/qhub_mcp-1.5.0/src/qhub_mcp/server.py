import logging

import httpx
from fastmcp import FastMCP
from qhub.api.context import ContextResolver
from qhub.api.credentials import DefaultCredentialsProvider
from qhub.service.client import HubServiceClient, HubServiceExecution

from qhub_mcp import __version__

logger = logging.getLogger(__name__)

kipu_access_token = DefaultCredentialsProvider().get_access_token()

context = ContextResolver().get_context()
organization_id = context.get_organization_id() if context is not None else None
_org_headers = {"x-OrganizationId": organization_id} if organization_id else {}
_auth_headers = {"X-Auth-Token": kipu_access_token, **_org_headers}

hub_client = httpx.AsyncClient(
    base_url="https://api.hub.kipu-quantum.com/qc-catalog",
    headers=_auth_headers,
)

quantum_client = httpx.AsyncClient(
    base_url="https://api.hub.kipu-quantum.com/quantum",
    headers=_auth_headers,
)

hub_spec = httpx.get("https://api.hub.kipu-quantum.com/qc-catalog/docs").json()
quantum_spec = httpx.get("https://api.hub.kipu-quantum.com/quantum/docs").json()

hub_server = FastMCP.from_openapi(openapi_spec=hub_spec, client=hub_client)
quantum_server = FastMCP.from_openapi(openapi_spec=quantum_spec, client=quantum_client)

mcp = FastMCP(
    name="Kipu Quantum Hub MCP",
    instructions="""
        This server provides tools related to the Kipu Quantum Hub platform.
        It allows you to interact with the platform and perform various tasks.

        Tools are organized into two namespaces:
        - hub_*: Tools for the core Hub platform API (services, data pools, applications, etc.)
        - quantum_*: Tools for the Quantum Workloads API (quantum jobs, quantum sessions, quantum backends, etc.)

        Service Jobs and Service Executions:
        - A service job can only be created for a service that the user owns.
        - A service job is an abstraction for a service execution. Even after creating a service job,
          the service execution endpoints are used to retrieve execution details and results.
        - A service execution is triggered by subscribing to a service through an application.
          Users can subscribe to their own services or services offered by other users.
        - The service must be published internally or to the marketplace before it can be subscribed to.
    """,
)

mcp.mount(hub_server, namespace="hub")
mcp.mount(quantum_server, namespace="quantum")


@mcp.tool
def run_subscribed_service(service_endpoint: str, access_key_id: str, secret_access_key: str, request: dict) -> HubServiceExecution:
    """
    Executes a subscribed service, creating a new service execution.
    A subscription to the service via an application is required before execution.
    The service_endpoint must be retrieved from the service details available through the marketplace API.
    The access_key_id and secret_access_key are the credentials of the application used to subscribe to the service.
    For the request format, refer to the service's OpenAPI specification.
    """
    service_client = HubServiceClient(
        service_endpoint=service_endpoint,
        access_key_id=access_key_id,
        secret_access_key=secret_access_key
    )

    return service_client.run(request=request)


def main():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger.info(f"Starting Kipu Quantum Hub MCP Server v{__version__}")
    mcp.run()


if __name__ == "__main__":
    main()
