"""
Shell operation tasks for executing commands and managing processes.
"""

import logging
import os
import platform
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from jinja2 import StrictUndefined, Template, TemplateSyntaxError, UndefinedError

from ..exceptions import TaskExecutionError, TemplateError
from . import TaskConfig, register_task
from .base import get_task_logger, log_task_error, log_task_execution, log_task_result
from .error_handling import ErrorContext, handle_task_error


def _get_shell_executable() -> Optional[str]:
    """Get the appropriate shell executable for the current platform.

    On Windows, prefers PowerShell (pwsh or powershell) for better
    compatibility with common shell patterns. On Unix, returns None
    to use the system default shell.

    Returns:
        Path to shell executable, or None for system default.
    """
    if platform.system() == "Windows":
        # Prefer PowerShell Core (pwsh) over Windows PowerShell
        for shell_name in ("pwsh", "powershell"):
            path = shutil.which(shell_name)
            if path:
                return path
    return None


def resolve_platform_command(command: Any) -> str:
    """Resolve a platform-specific command dict to the appropriate string.

    When ``command`` is a :class:`dict` with ``unix`` and/or ``windows`` keys
    the correct variant is chosen based on :func:`platform.system`.  Any other
    value is returned unchanged (callers are expected to validate the type).

    Example workflow YAML::

        - name: list_files
          task: shell
          inputs:
            command:
              unix: "ls -la"
              windows: "dir /W"

    Args:
        command: A command string, list, or a dict with ``unix``/``windows``
            keys.

    Returns:
        The resolved command string or list (unchanged if not a platform dict).

    Raises:
        ValueError: If ``command`` is a dict but contains neither a
            ``unix`` nor a ``windows`` key.
    """
    if not isinstance(command, dict):
        return command  # type: ignore[return-value]

    system = platform.system()
    if system == "Windows":
        key = "windows"
        fallback = "unix"
    else:
        key = "unix"
        fallback = "windows"

    if key in command:
        return command[key]
    if fallback in command:
        logging.getLogger(__name__).warning(
            "No '%s' key found in platform command dict; "
            "falling back to '%s' variant.",
            key,
            fallback,
        )
        return command[fallback]

    raise ValueError(
        "platform command dict must contain at least a 'unix' or 'windows' key; "
        f"got keys: {list(command.keys())}"
    )


# Patterns that are valid bash/sh syntax but will fail or behave differently
# under Windows cmd.exe.  We emit a warning when these are detected so users
# know to either skip the task on Windows or supply a 'windows' variant via
# the platform command dict.
_BASH_SYNTAX_PATTERNS = (
    "$(",  # command substitution
    " && ",  # bash AND operator (cmd uses & not &&)
    " || ",  # bash OR operator
    "\n",  # multi-line shell script
)


def _warn_if_bash_syntax(command: str, step_name: str) -> None:
    """Emit a logger warning when *command* contains bash-specific constructs.

    This is a best-effort heuristic; it will not catch every case.  The
    warning is only emitted on Windows.

    Args:
        command: The resolved shell command string.
        step_name: Name of the current workflow step (for log context).
    """
    if platform.system() != "Windows":
        return
    for pattern in _BASH_SYNTAX_PATTERNS:
        if pattern in command:
            logging.getLogger(__name__).warning(
                "Step '%s': shell command may contain bash-specific syntax "
                "(%r) that is not supported on Windows.  Consider using "
                "shell=false with a command list, or provide a platform-"
                "specific command dict with 'unix'/'windows' keys.",
                step_name,
                pattern,
            )
            break


def run_command(
    command: Union[str, List[str]],
    cwd: Optional[str] = None,
    env: Optional[Dict[str, str]] = None,
    shell: bool = False,
    timeout: Optional[float] = None,
) -> Tuple[int, str, str]:
    """
    Run a shell command and return its output.

    Args:
        command: Command to run (string or list of arguments)
        cwd: Working directory for the command
        env: Environment variables to set
        shell: Whether to run command through shell
        timeout: Timeout in seconds

    Returns:
        Tuple[int, str, str]: Return code, stdout, and stderr
    """
    executable = None
    if isinstance(command, str) and not shell:
        command = command.split()

    if shell and platform.system() == "Windows":
        executable = _get_shell_executable()

    result = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        shell=shell,
        capture_output=True,
        text=True,
        timeout=timeout,
        executable=executable,
    )

    return result.returncode, result.stdout, result.stderr


def check_command(
    command: Union[str, List[str]],
    cwd: Optional[str] = None,
    env: Optional[Dict[str, str]] = None,
    shell: bool = False,
    timeout: Optional[float] = None,
) -> str:
    """
    Run a command and raise an error if it fails.

    Args:
        command: Command to run (string or list of arguments)
        cwd: Working directory for the command
        env: Environment variables to set
        shell: Whether to run command through shell
        timeout: Timeout in seconds

    Returns:
        str: Command output (stdout)

    Raises:
        subprocess.CalledProcessError: If command returns non-zero exit code
    """
    if isinstance(command, str) and not shell:
        command = command.split()

    result = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        shell=shell,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=True,
    )

    return result.stdout


def get_environment() -> Dict[str, str]:
    """
    Get current environment variables.

    Returns:
        Dict[str, str]: Dictionary of environment variables
    """
    return dict(os.environ)


def set_environment(env_vars: Dict[str, str]) -> Dict[str, str]:
    """
    Set environment variables.

    Args:
        env_vars: Dictionary of environment variables to set

    Returns:
        Dict[str, str]: Updated environment variables
    """
    os.environ.update(env_vars)
    return dict(os.environ)


def process_command(command: str, context: Dict[str, Any]) -> str:
    """
    Process a shell command template with the given context.

    Args:
        command: Shell command template
        context: Template context

    Returns:
        str: Processed shell command

    Raises:
        TaskExecutionError: If template resolution fails (via handle_task_error)
    """
    try:
        template = Template(command, undefined=StrictUndefined)
        return template.render(**context)
    except UndefinedError as e:
        task_name = context.get("step_name", "shell_template")
        task_type = context.get("task_type", "shell")
        var_name = str(e).split("'")[1] if "'" in str(e) else "unknown"

        available = {
            "args": list(context.get("args", {}).keys()),
            "env": list(context.get("env", {}).keys()),
            "steps": list(context.get("steps", {}).keys()),
            "batch": (
                list(context.get("batch", {}).keys()) if "batch" in context else []
            ),
        }

        msg = f"Undefined variable '{var_name}' in shell command template. "
        msg += "Available variables by namespace:\n"
        for ns, vars in available.items():
            msg += f"  {ns}: {', '.join(vars) if vars else '(empty)'}\n"

        template_error = TemplateError(msg)
        err_context = ErrorContext(
            step_name=str(task_name),
            task_type=str(task_type),
            error=template_error,
            task_config=context.get("task_config"),
            template_context=context,
        )
        handle_task_error(err_context)
        return ""  # Unreachable
    except (TemplateSyntaxError, TypeError, ValueError) as e:
        task_name = context.get("step_name", "shell_template")
        task_type = context.get("task_type", "shell")
        handle_task_error(
            ErrorContext(
                step_name=str(task_name),
                task_type=str(task_type),
                error=e,
                task_config=context.get("task_config"),
                template_context=context,
            )
        )
        return ""  # Unreachable


@register_task("shell")
def shell_task(config: TaskConfig) -> Dict[str, Any]:
    """
    Run a shell command with namespace support.

    Args:
        config: Task configuration with namespace support

    Returns:
        Dict[str, Any]: Command execution results

    Raises:
        TaskExecutionError: If command execution fails or template resolution fails
    """
    task_name = str(config.name or "shell_task")
    task_type = str(config.type or "shell")
    logger = get_task_logger(config.workspace, task_name)

    try:
        log_task_execution(logger, config.step, config.context, config.workspace)

        processed = config.process_inputs()
        config.processed_inputs = processed

        if "command" not in processed:
            missing_cmd_error = ValueError("command parameter is required")
            raise missing_cmd_error
        command = resolve_platform_command(processed["command"])

        cwd = config.workspace
        if "working_dir" in processed:
            working_dir = processed["working_dir"]
            if not os.path.isabs(working_dir):
                cwd = config.workspace / working_dir
            else:
                cwd = Path(working_dir)

        env = get_environment()
        if "env" in processed:
            env.update(processed["env"])

        shell = processed.get("shell", True)

        # Get timeout
        timeout = processed.get("timeout", None)

        # Process command template ONLY if it's a string
        if isinstance(command, str):
            # Pass necessary context for error reporting within process_command
            command_context = {
                **config.context,
                "step_name": task_name,
                "task_type": task_type,
                "task_config": config.step,
            }
            command = process_command(command, command_context)
            if shell:
                _warn_if_bash_syntax(command, task_name)
        elif not isinstance(command, list):
            # Raise error if command is neither string nor list
            invalid_type_error = TypeError(
                f"Invalid command type: {type(command).__name__}. Expected string or list."
            )
            raise TaskExecutionError(
                step_name=task_name, original_error=invalid_type_error
            )

        # Run command
        returncode, stdout, stderr = run_command(
            command, cwd=str(cwd), env=env, shell=shell, timeout=timeout
        )

        if returncode != 0:
            error_message = f"Command failed with exit code {returncode}"
            if stderr:
                error_message += f"\nStderr:\n{stderr}"
            cmd_error = subprocess.CalledProcessError(
                returncode, cmd=command, output=stdout, stderr=stderr
            )
            raise cmd_error

        result = {"return_code": returncode, "stdout": stdout, "stderr": stderr}
        log_task_result(logger, result)
        return result

    except (
        TaskExecutionError,
        TemplateError,
        subprocess.CalledProcessError,
        subprocess.TimeoutExpired,
        OSError,
        ValueError,
        TypeError,
    ) as e:
        context = ErrorContext(
            step_name=task_name,
            task_type=task_type,
            error=e,
            task_config=config.step,
            template_context=config.context,
        )
        handle_task_error(context)
        return {}  # Unreachable
