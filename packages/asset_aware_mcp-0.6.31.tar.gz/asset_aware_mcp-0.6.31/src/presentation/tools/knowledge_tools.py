"""
Knowledge Tools - 知識圖譜 MCP 工具

包含：
- consult_knowledge_graph: 查詢知識圖譜
- export_knowledge_graph: 匯出知識圖譜
"""

from __future__ import annotations

import asyncio
import re
from typing import TYPE_CHECKING, Any, cast

from src.presentation.dependencies import knowledge_graph, knowledge_service
from src.presentation.mcp_app import mcp
from src.presentation.mcp_context import log_message, report_progress

if TYPE_CHECKING:
    from mcp.server.fastmcp import Context
else:
    Context = Any

KNOWLEDGE_TOOL_TIMEOUT_SECONDS = 45.0


def _normalize_op(op: str) -> str:
    return op.strip().lower().replace("-", "_")


def _extract_doc_ids(value: Any) -> list[str]:
    """Best-effort doc_id extraction from structured LightRAG responses."""
    doc_ids: set[str] = set()

    def visit(item: Any) -> None:
        if isinstance(item, dict):
            for key, child in item.items():
                normalized = str(key).lower()
                if (
                    normalized in {"doc_id", "source_doc_id", "document_id"}
                    and isinstance(child, str)
                    and child.startswith("doc_")
                ):
                    doc_ids.add(child)
                visit(child)
        elif isinstance(item, list | tuple | set):
            for child in item:
                visit(child)
        elif isinstance(item, str):
            doc_ids.update(re.findall(r"\bdoc_[A-Za-z0-9_]+\b", item))

    visit(value)
    return sorted(doc_ids)


async def _verified_evidence_payload(
    *,
    query: str,
    doc_ids: list[str] | None,
    result: Any,
    evidence_limit: int,
) -> dict[str, Any]:
    from src.presentation.tools.document_tools import citation_bundle

    target_doc_ids = list(dict.fromkeys(doc_ids or _extract_doc_ids(result)))
    if not target_doc_ids:
        return {
            "success": False,
            "status": "skipped",
            "reason": (
                "No doc_ids were provided or discoverable in the knowledge graph "
                "response. Pass doc_ids=[...] to verify against citation indexes."
            ),
            "query": query,
            "bundles": [],
        }

    bundles: list[dict[str, Any]] = []
    for doc_id in target_doc_ids:
        bundle = await citation_bundle(
            doc_id,
            query=query,
            limit=evidence_limit,
            include_verification=True,
            output_format="json",
        )
        if isinstance(bundle, dict):
            bundles.append(bundle)

    return {
        "success": any(bundle.get("success") for bundle in bundles),
        "status": "verified"
        if any(bundle.get("success") for bundle in bundles)
        else "empty",
        "query": query,
        "doc_ids": target_doc_ids,
        "bundles": bundles,
    }


def _format_verified_evidence(payload: dict[str, Any]) -> str:
    if payload.get("status") == "skipped":
        return f"## Verified Evidence\n\nSkipped: {payload.get('reason', '')}"
    lines = ["## Verified Evidence", ""]
    for bundle in payload.get("bundles", []):
        doc_id = bundle.get("doc_id", "")
        if not bundle.get("success"):
            lines.append(f"- `{doc_id}`: {bundle.get('error', 'no evidence')}")
            continue
        lines.append(
            f"- `{doc_id}`: {bundle.get('returned', 0)}/{bundle.get('matched_count', 0)} spans"
        )
        for entry in bundle.get("entries", [])[:3]:
            lines.append(
                "  - "
                f"`{entry.get('span_id')}` "
                f"p.{entry.get('page') or '?'} "
                f"{entry.get('line_display') or ''}: "
                f"{str(entry.get('quote') or '')[:120]}"
            )
    return "\n".join(lines)


@mcp.tool()
async def consult_knowledge_graph(
    query: str,
    mode: str = "hybrid",
    response_mode: str = "structured",
    user_prompt: str | None = None,
    include_references: bool = False,
    verify_references: bool = False,
    doc_ids: list[str] | None = None,
    evidence_limit: int = 5,
    ctx: Context | None = None,
) -> dict[str, Any] | str:
    """
    Query the LightRAG knowledge graph for cross-document insights.

    Query Modes:
    - "local": Specific details from nearby context
    - "global": High-level patterns and themes
    - "hybrid": Both local and global (recommended for most queries)
    - "mix": Knowledge graph + vector retrieval (recommended by newer LightRAG versions)
    - "naive": Vector-only retrieval
    - "bypass": Direct LLM answer path without retrieval

    Best for:
    - Comparing findings across multiple papers
    - Finding drug interactions or dosage patterns
    - Exploring relationships between concepts

    Args:
        query: Natural language question
        mode: Query mode ("local", "global", "hybrid", "mix", "naive", or "bypass")
        response_mode: "structured" (default), "data", or "text"
        user_prompt: Optional instruction applied after retrieval, before answer generation
        include_references: Include source reference list when LightRAG supports it
        verify_references: Attach citation-index evidence bundles for referenced docs
        doc_ids: Optional explicit document IDs to verify against
        evidence_limit: Max evidence spans per document bundle

    Returns:
        Structured MCP-friendly result by default, or plain text when response_mode="text"

    Example:
        consult_knowledge_graph("What are the dosing recommendations for remimazolam?")
        consult_knowledge_graph("Compare sedation outcomes between propofol and remimazolam", mode="global")
    """
    if response_mode not in {"structured", "data", "text"}:
        raise ValueError("response_mode must be one of: structured, data, text")

    await log_message(ctx, "info", f"consult_knowledge_graph start: mode={mode}")
    await report_progress(ctx, 10, message="Querying knowledge graph")
    effective_include_references = include_references or verify_references

    query_task: Any
    if response_mode == "text":
        query_task = knowledge_service.query(
            query,
            mode=mode,
            user_prompt=user_prompt,
            include_references=effective_include_references,
        )
    elif response_mode == "data":
        query_task = knowledge_service.query_data(
            query,
            mode=mode,
            user_prompt=user_prompt,
        )
    else:
        query_task = knowledge_service.query_structured(
            query,
            mode=mode,
            user_prompt=user_prompt,
            include_references=effective_include_references,
        )

    try:
        result: dict[str, Any] | str = await asyncio.wait_for(
            query_task,
            timeout=KNOWLEDGE_TOOL_TIMEOUT_SECONDS,
        )
    except TimeoutError:
        await log_message(ctx, "error", "consult_knowledge_graph timed out")
        payload: dict[str, Any] = {
            "success": False,
            "status": "timeout",
            "error": (
                "Knowledge graph query exceeded the MCP request timeout guard. "
                "Retry with a narrower query or inspect the LightRAG runtime logs."
            ),
            "query": query,
            "mode": mode,
            "response_mode": response_mode,
            "timeout_seconds": KNOWLEDGE_TOOL_TIMEOUT_SECONDS,
        }
        if response_mode == "text":
            return str(payload["error"])
        return payload

    if verify_references:
        await report_progress(ctx, 90, message="Verifying knowledge graph evidence")
        verified = await _verified_evidence_payload(
            query=query,
            doc_ids=doc_ids,
            result=result,
            evidence_limit=evidence_limit,
        )
        if isinstance(result, dict):
            result = {**result, "verified_evidence": verified}
        else:
            result = f"{result}\n\n{_format_verified_evidence(verified)}"

    await report_progress(ctx, 100, message="Knowledge graph query finished")
    await log_message(ctx, "info", "consult_knowledge_graph complete")
    return result


@mcp.tool()
async def export_knowledge_graph(
    format: str = "summary",
    limit: int = 50,
    ctx: Context | None = None,
) -> str:
    """
    Export the knowledge graph for visualization.

    Use this to understand what entities and relationships exist in the graph.

    Output Formats:
    - "summary": Statistics + sample nodes/edges (default, recommended)
    - "json": Full node and edge data as JSON
    - "mermaid": Mermaid.js diagram syntax for visualization

    Args:
        format: Output format - "summary", "json", or "mermaid"
        limit: Maximum nodes to include (default 50, use smaller for mermaid)

    Returns:
        Graph data in requested format

    Examples:
        # Get overview of the knowledge graph
        export_knowledge_graph("summary")

        # Get Mermaid diagram for visualization (use limit=20 for readability)
        export_knowledge_graph("mermaid", limit=20)

        # Get full JSON data
        export_knowledge_graph("json", limit=100)
    """
    if knowledge_graph is None:
        return "Error: LightRAG is not enabled. Set ENABLE_LIGHTRAG=true in .env"

    await log_message(
        ctx, "info", f"export_knowledge_graph start: format={format} limit={limit}"
    )
    await report_progress(ctx, 10, message="Exporting knowledge graph")
    try:
        result = await asyncio.wait_for(
            knowledge_graph.export_graph(
                format=format,
                limit=limit,
            ),
            timeout=KNOWLEDGE_TOOL_TIMEOUT_SECONDS,
        )
    except TimeoutError:
        await log_message(ctx, "error", "export_knowledge_graph timed out")
        return (
            "Knowledge graph export timed out before completion. "
            f"format={format}, limit={limit}, "
            f"timeout_seconds={KNOWLEDGE_TOOL_TIMEOUT_SECONDS}"
        )
    await report_progress(ctx, 100, message="Knowledge graph export finished")
    await log_message(ctx, "info", "export_knowledge_graph complete")

    if format == "mermaid" and "diagram" in result:
        return (
            "## Knowledge Graph Visualization\n\n"
            f"**Nodes:** {result.get('node_count', 0)} | "
            f"**Edges:** {result.get('edge_count', 0)}\n\n"
            f"```mermaid\n{result['diagram']}\n```\n"
        )
    elif format == "summary":
        lines = [
            "## Knowledge Graph Summary",
            "",
            f"**Total Nodes:** {result.get('total_nodes', 0)}",
            f"**Total Edges:** {result.get('total_edges', 0)}",
            "",
            "### Entity Types",
        ]
        for etype, count in cast(
            "dict[str, int]", result.get("entity_types", {})
        ).items():
            lines.append(f"- {etype}: {count}")

        lines.append("\n### Sample Nodes")
        for node in cast("list[dict[str, str]]", result.get("sample_nodes", []))[:5]:
            lines.append(f"- **{node['id']}** ({node['type']})")
            if node.get("description"):
                lines.append(f"  _{node['description'][:100]}_")

        lines.append("\n### Sample Relationships")
        for edge in cast("list[dict[str, str]]", result.get("sample_edges", []))[:5]:
            lines.append(f"- {edge['source']} → {edge['target']}")
            if edge.get("keywords"):
                lines.append(f"  _Keywords: {edge['keywords']}_")

        return "\n".join(lines)
    else:
        import json

        return json.dumps(result, indent=2, ensure_ascii=False)


@mcp.tool()
async def knowledge(
    op: str,
    query: str | None = None,
    mode: str = "hybrid",
    response_mode: str = "structured",
    user_prompt: str | None = None,
    include_references: bool = False,
    verify_references: bool = False,
    doc_ids: list[str] | None = None,
    evidence_limit: int = 5,
    format: str = "summary",
    limit: int = 50,
    ctx: Context | None = None,
) -> Any:
    """
    Consolidated knowledge-graph entrypoint.

    Existing consult/export tools remain registered and keep their separate
    contracts for clients that prefer explicit tool names.
    """
    operation = _normalize_op(op)
    if operation in {"consult", "query"}:
        if not query:
            return "Missing required parameter: query is required."
        return await consult_knowledge_graph(
            query,
            mode=mode,
            response_mode=response_mode,
            user_prompt=user_prompt,
            include_references=include_references,
            verify_references=verify_references,
            doc_ids=doc_ids,
            evidence_limit=evidence_limit,
            ctx=ctx,
        )
    if operation == "export":
        return await export_knowledge_graph(format, limit, ctx=ctx)
    return (
        f"Unsupported knowledge op `{op}`. "
        "Supported operations: consult, export, query."
    )
