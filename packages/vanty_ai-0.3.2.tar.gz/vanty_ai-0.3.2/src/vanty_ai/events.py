"""Domain events published by vanty-ai.

These events fire from inside the agent's capability stack (ThreadCapability,
UsageMeteringCapability, ToolApprovalCapability) and let the host application
react to chat lifecycle moments without coupling to pydantic-ai internals.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

from vanty_core.events import event


@event("ai.thread.created")
@dataclass(frozen=True)
class ThreadCreated:
    thread_id: str
    organization_id: UUID | None
    actor_user_id: UUID | None
    title: str | None = None


@event("ai.thread.archived")
@dataclass(frozen=True)
class ThreadArchived:
    thread_id: str
    organization_id: UUID | None
    actor_user_id: UUID | None


@event("ai.message.sent")
@dataclass(frozen=True)
class MessageSent:
    thread_id: str
    organization_id: UUID | None
    actor_user_id: UUID | None
    role: str
    content_summary: str | None = None


@event("ai.message.received")
@dataclass(frozen=True)
class MessageReceived:
    thread_id: str
    organization_id: UUID | None
    actor_user_id: UUID | None
    model_name: str | None = None
    finish_reason: str | None = None


@event("ai.tool.called")
@dataclass(frozen=True)
class ToolCalled:
    thread_id: str | None
    organization_id: UUID | None
    actor_user_id: UUID | None
    tool_name: str
    tool_call_id: str | None = None
    arguments: dict[str, Any] = field(default_factory=dict)


@event("ai.tool.approval_requested")
@dataclass(frozen=True)
class ToolApprovalRequested:
    thread_id: str
    organization_id: UUID
    tool_name: str
    request_ids: list[str] = field(default_factory=list)


@event("ai.usage.metered")
@dataclass(frozen=True)
class UsageMetered:
    thread_id: str | None
    organization_id: UUID | None
    actor_user_id: UUID | None
    model_name: str | None
    input_tokens: int = 0
    output_tokens: int = 0
    cost: Decimal = Decimal("0")
    occurred_at: datetime | None = None
