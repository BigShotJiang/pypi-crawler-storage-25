from __future__ import annotations

from fastapi import APIRouter

from vanty_ai.embedded.router import router as embedded_router
from vanty_ai.fastapi.router import router as chat_router

router = APIRouter()
router.include_router(chat_router)
router.include_router(embedded_router)
