"""HTTP router for vanty-ai chat surface.

Routes (mounted under `/ai/chat` by ``AIApp`` via ``AppRegistry.mount``):

- `GET    /threads`                      list threads in the active organization
- `POST   /threads`                      create a thread
- `GET    /threads/{id}`                 fetch a single thread
- `PATCH  /threads/{id}`                 rename / update metadata
- `DELETE /threads/{id}`                 archive (soft delete via metadata flag)
- `GET    /threads/{id}/messages`        paginated message history
- `POST   /threads/{id}/messages`        post a user turn (non-streaming, returns final reply)
- `POST   /stream`                       SSE stream of agent events for a turn
- `GET    /threads/{id}/stream`          resumable SSE stream (for reconnects)
- `GET    /configure`                    active model + available tools + capability stack
- `GET    /threads/{id}/notifications`   list pending tool-approval requests for the thread
- `POST   /notifications/process`        approve / reject a tool call

The router depends on `AIRequestIdentity`, which is supplied by vanty-auth's
middleware in production and by request headers in tests.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from vanty_core.events import publish

from vanty_ai.events import MessageSent, ThreadArchived, ThreadCreated
from vanty_ai.fastapi.dependencies import AIRequestIdentity, build_runtime_deps, get_ai_app, get_ai_identity
from vanty_ai.fastapi.schemas import (
    ApprovalDecisionIn,
    ApprovalRequestOut,
    ConfigureOut,
    CreateMessageIn,
    CreateThreadIn,
    KnowledgeIndexIn,
    KnowledgeSearchIn,
    KnowledgeSearchOut,
    KnowledgeSearchResultOut,
    MessageListOut,
    MessageOut,
    NotificationListOut,
    StreamRequestIn,
    ThreadListOut,
    ThreadOut,
    UpdateThreadIn,
)
from vanty_ai.persistence.models import AgentApprovalRequest, AgentMessage, AgentThread, ApprovalStatus
from vanty_ai.services.approvals import (
    apply_approval_decision,
    list_pending_approval_requests,
)

router = APIRouter(prefix="/ai/chat", tags=["ai-chat"])


# ---------------------------------------------------------------------------
# Threads
# ---------------------------------------------------------------------------


@router.get("/threads", response_model=ThreadListOut)
async def list_threads(
    identity: AIRequestIdentity = Depends(get_ai_identity),
    limit: int = 50,
    offset: int = 0,
) -> ThreadListOut:
    qs = AgentThread.unscoped.filter(organization_id=identity.organization_id)
    total = await qs.count()
    items = await qs.order_by("-updated_at").offset(offset).limit(limit)
    return ThreadListOut(items=[ThreadOut.model_validate(item) for item in items], total=total)


@router.post("/threads", response_model=ThreadOut, status_code=status.HTTP_201_CREATED)
async def create_thread(
    body: CreateThreadIn,
    identity: AIRequestIdentity = Depends(get_ai_identity),
) -> ThreadOut:
    thread = await AgentThread.create(
        organization_id=identity.organization_id,
        actor_user_id=identity.actor_user_id,
        title=body.title or "New Chat",
        channel=body.channel,
        metadata=body.metadata,
    )
    await publish(
        ThreadCreated(
            thread_id=str(thread.id),
            organization_id=identity.organization_id,
            actor_user_id=identity.actor_user_id,
            title=thread.title,
        )
    )
    return ThreadOut.model_validate(thread)


@router.get("/threads/{thread_id}", response_model=ThreadOut)
async def get_thread(
    thread_id: UUID,
    identity: AIRequestIdentity = Depends(get_ai_identity),
) -> ThreadOut:
    thread = await _load_thread(thread_id, identity)
    return ThreadOut.model_validate(thread)


@router.patch("/threads/{thread_id}", response_model=ThreadOut)
async def update_thread(
    thread_id: UUID,
    body: UpdateThreadIn,
    identity: AIRequestIdentity = Depends(get_ai_identity),
) -> ThreadOut:
    thread = await _load_thread(thread_id, identity)
    update_fields: list[str] = []
    if body.title is not None:
        thread.title = body.title
        update_fields.append("title")
    if body.metadata is not None:
        thread.metadata = {**(thread.metadata or {}), **body.metadata}
        update_fields.append("metadata")
    if body.archived is not None:
        thread.metadata = {**(thread.metadata or {}), "archived": body.archived}
        update_fields.append("metadata")
        if body.archived:
            await publish(
                ThreadArchived(
                    thread_id=str(thread.id),
                    organization_id=identity.organization_id,
                    actor_user_id=identity.actor_user_id,
                )
            )
    if update_fields:
        await thread.save(update_fields=[*set(update_fields), "updated_at"])
    return ThreadOut.model_validate(thread)


@router.delete("/threads/{thread_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_thread(
    thread_id: UUID,
    identity: AIRequestIdentity = Depends(get_ai_identity),
) -> None:
    thread = await _load_thread(thread_id, identity)
    await thread.delete()
    await publish(
        ThreadArchived(
            thread_id=str(thread_id),
            organization_id=identity.organization_id,
            actor_user_id=identity.actor_user_id,
        )
    )


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------


@router.get("/threads/{thread_id}/messages", response_model=MessageListOut)
async def list_messages(
    thread_id: UUID,
    identity: AIRequestIdentity = Depends(get_ai_identity),
    limit: int = 200,
    offset: int = 0,
) -> MessageListOut:
    await _load_thread(thread_id, identity)
    qs = AgentMessage.unscoped.filter(thread_id=thread_id)
    total = await qs.count()
    items = await qs.order_by("created_at").offset(offset).limit(limit)
    return MessageListOut(items=[MessageOut.model_validate(item) for item in items], total=total)


@router.post(
    "/threads/{thread_id}/messages",
    response_model=MessageListOut,
    status_code=status.HTTP_201_CREATED,
)
async def post_message(
    thread_id: UUID,
    body: CreateMessageIn,
    identity: AIRequestIdentity = Depends(get_ai_identity),
    kit=Depends(get_ai_app),
) -> MessageListOut:
    """Run a single agent turn and return the new messages.

    Use the streaming endpoint (`POST /stream`) for incremental UI updates.
    """
    thread = await _load_thread(thread_id, identity)
    deps = build_runtime_deps(
        identity,
        thread_id=str(thread.id),
        thread_title=thread.title,
        channel=thread.channel,
        metadata=body.metadata,
    )
    await publish(
        MessageSent(
            thread_id=str(thread.id),
            organization_id=identity.organization_id,
            actor_user_id=identity.actor_user_id,
            role="user",
        )
    )
    await kit.agent_service.run(prompt=body.content, deps=deps)

    new_messages = await AgentMessage.unscoped.filter(thread_id=thread_id).order_by("-created_at").limit(10)
    return MessageListOut(
        items=[MessageOut.model_validate(item) for item in reversed(new_messages)],
        total=len(new_messages),
    )


# ---------------------------------------------------------------------------
# Streaming
# ---------------------------------------------------------------------------


@router.post("/stream")
async def stream_chat(
    body: StreamRequestIn,
    identity: AIRequestIdentity = Depends(get_ai_identity),
    kit=Depends(get_ai_app),
) -> StreamingResponse:
    """Stream agent events as Server-Sent Events.

    The response uses the standard text/event-stream format. Each SSE event has
    a `data:` line containing JSON of `{type, payload}`. The `type` matches
    pydantic-ai's `AgentStreamEvent` discriminator (`PartStartEvent`,
    `PartDeltaEvent`, `FinalResultEvent`, etc.) plus a final `done` sentinel.
    """
    if body.thread_id is not None:
        thread = await _load_thread(body.thread_id, identity)
    else:
        thread = await AgentThread.create(
            organization_id=identity.organization_id,
            actor_user_id=identity.actor_user_id,
            title=body.title or "New Chat",
            channel=body.channel,
            metadata=body.metadata,
        )
        await publish(
            ThreadCreated(
                thread_id=str(thread.id),
                organization_id=identity.organization_id,
                actor_user_id=identity.actor_user_id,
                title=thread.title,
            )
        )

    deps = build_runtime_deps(
        identity,
        thread_id=str(thread.id),
        thread_title=thread.title,
        channel=thread.channel,
        metadata=body.metadata,
    )

    async def _event_stream():
        yield _sse_event("thread", {"thread_id": str(thread.id)})
        try:
            async for event in kit.agent_service.stream_events(prompt=body.prompt, deps=deps):
                payload = _serialise_event(event)
                if _is_reasoning_payload(payload):
                    continue
                yield _sse_event(type(event).__name__, payload)
        except Exception as exc:
            yield _sse_event("error", {"message": str(exc)})
        yield _sse_event("done", {})

    return StreamingResponse(_event_stream(), media_type="text/event-stream")


@router.get("/threads/{thread_id}/stream")
async def resumable_stream(
    thread_id: UUID,
    identity: AIRequestIdentity = Depends(get_ai_identity),
) -> StreamingResponse:
    """Replay the latest persisted messages for a thread as SSE.

    The frontend uses this on reconnect to rebuild local UI state without
    triggering a new model run.
    """
    await _load_thread(thread_id, identity)
    messages = await AgentMessage.unscoped.filter(thread_id=thread_id).order_by("created_at")

    async def _event_stream():
        for message in messages:
            yield _sse_event(
                "message",
                {
                    "id": str(message.id),
                    "role": message.role,
                    "kind": message.kind,
                    "payload": message.payload,
                    "created_at": message.created_at.isoformat() if message.created_at else None,
                },
            )
        yield _sse_event("done", {})

    return StreamingResponse(_event_stream(), media_type="text/event-stream")


# ---------------------------------------------------------------------------
# Configure
# ---------------------------------------------------------------------------


@router.get("/configure", response_model=ConfigureOut)
async def configure(
    _identity: AIRequestIdentity = Depends(get_ai_identity),
    kit=Depends(get_ai_app),
) -> ConfigureOut:
    info = await kit.agent_service.configure()
    return ConfigureOut(**info)


# ---------------------------------------------------------------------------
# Knowledge
# ---------------------------------------------------------------------------


@router.post("/knowledge/index", status_code=status.HTTP_201_CREATED)
async def index_knowledge(
    body: KnowledgeIndexIn,
    identity: AIRequestIdentity = Depends(get_ai_identity),
    kit=Depends(get_ai_app),
) -> dict[str, str | None]:
    document = await kit.knowledge_service.index_document(
        organization_id=identity.organization_id,
        source_name=body.source_name,
        source_type=body.source_type,
        external_id=body.external_id,
        title=body.title,
        text=body.text,
        url=body.url,
        metadata=body.metadata,
    )
    return {"document_id": str(document.id) if document is not None else None}


@router.post("/knowledge/search", response_model=KnowledgeSearchOut)
async def search_knowledge(
    body: KnowledgeSearchIn,
    identity: AIRequestIdentity = Depends(get_ai_identity),
    kit=Depends(get_ai_app),
) -> KnowledgeSearchOut:
    results = await kit.knowledge_service.search(
        organization_id=identity.organization_id,
        query=body.query,
        limit=body.limit,
    )
    return KnowledgeSearchOut(
        items=[KnowledgeSearchResultOut(**asdict(result)) for result in results],
        total=len(results),
    )


# ---------------------------------------------------------------------------
# Notifications / approvals
# ---------------------------------------------------------------------------


@router.get("/threads/{thread_id}/notifications", response_model=NotificationListOut)
async def list_notifications(
    thread_id: UUID,
    identity: AIRequestIdentity = Depends(get_ai_identity),
) -> NotificationListOut:
    await _load_thread(thread_id, identity)
    requests = await list_pending_approval_requests(thread_id=str(thread_id))
    return NotificationListOut(
        items=[ApprovalRequestOut.model_validate(req) for req in requests],
        total=len(requests),
    )


@router.post("/notifications/process", response_model=ApprovalRequestOut)
async def process_notification(
    body: ApprovalDecisionIn,
    identity: AIRequestIdentity = Depends(get_ai_identity),
) -> ApprovalRequestOut:
    request = await AgentApprovalRequest.unscoped.get_or_none(id=body.request_id)
    if request is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")
    if str(request.organization_id) != str(identity.organization_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")

    updated = await apply_approval_decision(
        request,
        approved=body.decision == ApprovalStatus.approved,
        reviewed_by_user_id=str(identity.actor_user_id) if identity.actor_user_id else None,
        override_args=body.override_args,
        reason=body.reason,
    )
    return ApprovalRequestOut.model_validate(updated)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


async def _load_thread(thread_id: UUID, identity: AIRequestIdentity) -> AgentThread:
    thread = await AgentThread.unscoped.get_or_none(id=thread_id)
    if thread is None or str(thread.organization_id) != str(identity.organization_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Thread not found")
    return thread


def _sse_event(event_type: str, payload: Any) -> str:
    return f"event: {event_type}\ndata: {json.dumps(payload, default=str)}\n\n"


def _serialise_event(event: Any) -> dict[str, Any]:
    """Convert a pydantic-ai stream event to a JSON-friendly dict."""
    for attr in ("model_dump", "to_dict", "__dict__"):
        if hasattr(event, attr):
            try:
                value = getattr(event, attr)
                if callable(value):
                    return value()
                return dict(value)
            except Exception:  # noqa: BLE001
                continue
    return {"repr": repr(event)}


def _is_reasoning_payload(payload: dict[str, Any]) -> bool:
    text = json.dumps(payload, default=str)
    return "ThinkingPart" in text or "ThinkingPartDelta" in text or "reasoning.text" in text
