"""FastAPI integration for vanty-ai."""

from vanty_ai.fastapi.dependencies import (
    AIRequestIdentity,
    build_runtime_deps,
    get_ai_app,
    get_ai_identity,
)
from vanty_ai.fastapi.router import router

__all__ = [
    "AIRequestIdentity",
    "build_runtime_deps",
    "get_ai_identity",
    "get_ai_app",
    "router",
]
