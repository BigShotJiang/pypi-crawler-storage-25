"""FastAPI dependencies for the vanty-ai chat router.

The router needs three things from the host application:

1. The `AIApp` instance (resolved from `app.state.registry`).
2. The active `AuthContext` (provided by vanty-auth's middleware via
   `request.state.auth_context`). vanty-auth is an *optional* dependency:
   if it isn't installed or no context exists, the dependency returns a
   minimal stub that respects the host-supplied `X-Organization-ID` and
   `X-Actor-User-ID` headers — handy for tests and trusted internal
   service-to-service calls.
3. An `AgentRuntimeDeps` builder that wires the auth context into
   per-request dependencies for pydantic-ai.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any
from uuid import UUID

from fastapi import Depends, HTTPException, Request, status

from vanty_ai.runtime.deps import AgentRuntimeDeps

if TYPE_CHECKING:
    from vanty_ai.apps import AIApp


@dataclass(slots=True)
class AIRequestIdentity:
    """Minimal identity envelope the AI router needs."""

    organization_id: UUID
    actor_user_id: UUID | None


def get_ai_app(request: Request) -> AIApp:
    """Return the installed ``AIApp`` from the registry on the request app."""
    registry = getattr(request.app.state, "registry", None)
    if registry is None or not registry.has("ai"):
        raise RuntimeError(
            "AIApp is not installed. Construct AppRegistry, install AIApp, then registry.mount(app)."
        )
    return registry.get("ai")


async def get_ai_identity(request: Request) -> AIRequestIdentity:
    """Resolve the identity behind the current request.

    Order of resolution:

    1. `request.state.auth_context` populated by vanty-auth middleware.
    2. `X-Organization-ID` (+ optional `X-Actor-User-ID`) headers — useful
       in tests and for first-party services that bypass the cookie session.

    Raises 401 if neither is available.
    """
    context = getattr(request.state, "auth_context", None)
    if context is not None and getattr(context, "organization_id", None) is not None:
        user_id = getattr(context, "user_id", None)
        return AIRequestIdentity(
            organization_id=_as_uuid(context.organization_id),
            actor_user_id=_as_uuid(user_id) if user_id is not None else None,
        )
    org_header = request.headers.get("x-organization-id")
    if org_header is not None:
        actor_header = request.headers.get("x-actor-user-id")
        return AIRequestIdentity(
            organization_id=_as_uuid(org_header),
            actor_user_id=_as_uuid(actor_header) if actor_header else None,
        )
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")


def build_runtime_deps(
    identity: AIRequestIdentity,
    *,
    thread_id: str | None = None,
    channel: str | None = None,
    metadata: dict[str, Any] | None = None,
    thread_title: str | None = None,
) -> AgentRuntimeDeps:
    return AgentRuntimeDeps(
        organization_id=identity.organization_id,
        actor_user_id=identity.actor_user_id,
        thread_id=thread_id,
        thread_title=thread_title,
        channel=channel,
        metadata=metadata or {},
    )


def runtime_deps_dependency(
    identity: AIRequestIdentity = Depends(get_ai_identity),
) -> AgentRuntimeDeps:
    return build_runtime_deps(identity)


def _as_uuid(value: Any) -> UUID:
    if isinstance(value, UUID):
        return value
    try:
        return UUID(str(value))
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid identity UUID") from exc
