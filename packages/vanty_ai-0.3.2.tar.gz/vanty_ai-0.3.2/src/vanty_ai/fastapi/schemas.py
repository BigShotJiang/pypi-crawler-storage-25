"""Pydantic schemas for the vanty-ai HTTP layer.

Schemas intentionally stay close to the persistence shape so that the
generated OpenAPI spec is easy to consume from a typed frontend.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from vanty_ai.persistence.models import ApprovalStatus, ThreadStatus


class ThreadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    organization_id: UUID
    actor_user_id: UUID | None = None
    title: str
    channel: str | None = None
    status: ThreadStatus
    message_count: int
    last_run_started_at: datetime | None = None
    last_run_finished_at: datetime | None = None
    last_error: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class ThreadListOut(BaseModel):
    items: list[ThreadOut]
    total: int


class CreateThreadIn(BaseModel):
    title: str | None = None
    channel: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class UpdateThreadIn(BaseModel):
    title: str | None = None
    metadata: dict[str, Any] | None = None
    archived: bool | None = None


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    thread_id: UUID
    role: str
    kind: str
    payload: dict[str, Any]
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime


class MessageListOut(BaseModel):
    items: list[MessageOut]
    total: int


class CreateMessageIn(BaseModel):
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class StreamRequestIn(BaseModel):
    """Request body for `POST /ai/chat/stream`.

    Either `thread_id` (continue an existing conversation) or `title`
    (create a new one) must be provided. `prompt` is the user turn.
    """

    thread_id: UUID | None = None
    title: str | None = None
    channel: str | None = None
    prompt: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class ConfigureOut(BaseModel):
    """`GET /ai/chat/configure` — describes what the agent is capable of."""

    model_name: str
    available_tools: list[str]
    capabilities: list[str]


class KnowledgeIndexIn(BaseModel):
    source_name: str
    source_type: str = "manual"
    external_id: str
    title: str
    text: str
    url: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class KnowledgeSearchIn(BaseModel):
    query: str
    limit: int = Field(default=5, ge=1, le=20)


class KnowledgeSearchResultOut(BaseModel):
    chunk_id: str
    source: str
    score: float
    title: str
    url: str | None = None
    text: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class KnowledgeSearchOut(BaseModel):
    items: list[KnowledgeSearchResultOut]
    total: int


class ApprovalRequestOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    thread_id: UUID
    tool_call_id: str
    tool_name: str
    status: ApprovalStatus
    args: dict[str, Any]
    override_args: dict[str, Any] | None = None
    reason: str | None = None
    requested_by_user_id: UUID | None = None
    reviewed_by_user_id: UUID | None = None
    reviewed_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class NotificationListOut(BaseModel):
    items: list[ApprovalRequestOut]
    total: int


class ApprovalDecisionIn(BaseModel):
    """`POST /ai/chat/notifications/process` body."""

    request_id: UUID
    decision: ApprovalStatus = Field(description="approved | rejected")
    override_args: dict[str, Any] | None = None
    reason: str | None = None
