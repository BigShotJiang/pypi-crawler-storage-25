from __future__ import annotations

from pydantic_ai.capabilities import AbstractCapability

from vanty_ai.runtime.deps import AgentRuntimeDeps


class KnowledgeBaseCapability(AbstractCapability[AgentRuntimeDeps]):
    """Marker capability for agents that can retrieve organization knowledge."""
