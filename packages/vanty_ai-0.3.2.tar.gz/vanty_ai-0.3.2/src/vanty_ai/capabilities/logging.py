from __future__ import annotations

import json
import logging
from typing import Any

from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.run import AgentRunResult
from pydantic_ai.tools import RunContext, ToolDefinition

from vanty_ai.runtime.deps import AgentRuntimeDeps


class LoggingCapability(AbstractCapability[AgentRuntimeDeps]):
    """Structured logging for runs and tool execution."""

    def __init__(self, logger_name: str = "vanty_ai.agent", max_value_chars: int = 400) -> None:
        self.logger = logging.getLogger(logger_name)
        self.max_value_chars = max_value_chars

    async def before_run(self, ctx: RunContext[AgentRuntimeDeps]) -> None:
        self.logger.info(
            "agent.run.started",
            extra=self._base_extra(ctx),
        )

    async def after_run(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        *,
        result: AgentRunResult[Any],
    ) -> AgentRunResult[Any]:
        self.logger.info(
            "agent.run.completed",
            extra={
                **self._base_extra(ctx),
                "output_type": type(result.output).__name__,
            },
        )
        return result

    async def on_run_error(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        *,
        error: BaseException,
    ) -> AgentRunResult[Any]:
        self.logger.exception(
            "agent.run.failed",
            extra={
                **self._base_extra(ctx),
                "error_type": type(error).__name__,
                "error_message": str(error),
            },
        )
        raise error

    async def before_tool_execute(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        call,
        tool_def: ToolDefinition,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        self.logger.info(
            "agent.tool.started",
            extra={
                **self._base_extra(ctx),
                "tool_name": tool_def.name,
                "tool_call_id": call.tool_call_id,
                "args": self._truncate(args),
            },
        )
        return args

    async def after_tool_execute(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        call,
        tool_def: ToolDefinition,
        args: dict[str, Any],
        result: Any,
    ) -> Any:
        self.logger.info(
            "agent.tool.completed",
            extra={
                **self._base_extra(ctx),
                "tool_name": tool_def.name,
                "tool_call_id": call.tool_call_id,
                "args": self._truncate(args),
                "result": self._truncate(result),
            },
        )
        return result

    def _base_extra(self, ctx: RunContext[AgentRuntimeDeps]) -> dict[str, Any]:
        return {
            "organization_id": ctx.deps.organization_ref(),
            "actor_user_id": ctx.deps.actor_ref(),
            "thread_id": ctx.deps.thread_id,
            "channel": ctx.deps.channel,
        }

    def _truncate(self, value: Any) -> str:
        try:
            rendered = json.dumps(value, default=str, ensure_ascii=False)
        except Exception:
            rendered = str(value)
        if len(rendered) <= self.max_value_chars:
            return rendered
        return f"{rendered[: self.max_value_chars]}…"
