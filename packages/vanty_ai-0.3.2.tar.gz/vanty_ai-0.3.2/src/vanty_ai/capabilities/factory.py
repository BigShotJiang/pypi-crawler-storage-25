"""Default capability stack for Vanty AI agents.

Built on top of pydantic-ai 1.84's `Capabilities` API. Composes:

- `LoggingCapability`             – structured logs around runs and tools
- `ThreadCapability`              – persists messages and emits thread events
- `ToolApprovalCapability`        – gates risky tools and persists approval requests
- `UsageMeteringCapability`       – records token + cost snapshots and emits `usage.metered`
- `Hooks(after_model_request=…)`  – publishes `usage.metered` from model responses too
- `HistoryProcessor(_truncate)`   – cap large histories before the model sees them
- `ThreadExecutor`                – runs sync tools in a worker pool so they don't block

Callers can append `OpenAICompaction()` (or the provider-specific compaction
capability shipped in a later pydantic-ai release) themselves; we keep the
default stack minimal so it works on any provider.
"""

from __future__ import annotations

from collections.abc import Callable
from concurrent.futures import Executor, ThreadPoolExecutor
from typing import Any
from uuid import UUID

from pydantic_ai.capabilities import (
    AbstractCapability,
    HistoryProcessor,
    Hooks,
    ThreadExecutor,
)
from pydantic_ai.messages import ModelMessage
from vanty_core.events import publish

from vanty_ai.capabilities.approvals import ToolApprovalCapability
from vanty_ai.capabilities.knowledge import KnowledgeBaseCapability
from vanty_ai.capabilities.logging import LoggingCapability
from vanty_ai.capabilities.threads import ThreadCapability
from vanty_ai.capabilities.usage import UsageMeteringCapability
from vanty_ai.events import UsageMetered
from vanty_ai.runtime.deps import AgentRuntimeDeps
from vanty_ai.runtime.usage import UsageEventRecorder
from vanty_ai.services.approvals import ApprovalNotificationSink

DEFAULT_HISTORY_LIMIT = 60


def _truncate_history(messages: list[ModelMessage]) -> list[ModelMessage]:
    """Keep only the most recent `DEFAULT_HISTORY_LIMIT` messages.

    pydantic-ai will call this with the full history before each model
    request; we keep the tail so prompts stay bounded without losing the
    most recent context.
    """
    if len(messages) <= DEFAULT_HISTORY_LIMIT:
        return messages
    return messages[-DEFAULT_HISTORY_LIMIT:]


def _build_event_publishing_hooks() -> Hooks[AgentRuntimeDeps]:
    """Hooks that mirror pydantic-ai 1.84's lifecycle into vanty-core events."""

    async def _after_model_request(ctx: Any, /, *, request_context: Any, response: Any) -> Any:
        deps = ctx.deps
        usage = getattr(response, "usage", None)
        if usage is None:
            return response
        await publish(
            UsageMetered(
                thread_id=deps.thread_id,
                organization_id=_as_uuid(deps.organization_id),
                actor_user_id=_as_uuid(deps.actor_user_id),
                model_name=getattr(response, "model_name", None),
                input_tokens=int(getattr(usage, "input_tokens", 0) or 0),
                output_tokens=int(getattr(usage, "output_tokens", 0) or 0),
            )
        )
        return response

    return Hooks(after_model_request=_after_model_request)


def build_default_capabilities(
    *,
    approval_tools: set[str] | None = None,
    approval_sink: ApprovalNotificationSink | None = None,
    usage_recorder: UsageEventRecorder | None = None,
    executor: Executor | None = None,
    history_processor: Callable[[list[ModelMessage]], list[ModelMessage]] | None = None,
    extra_capabilities: list[AbstractCapability[AgentRuntimeDeps]] | None = None,
) -> list[AbstractCapability[AgentRuntimeDeps]]:
    """Construct the default capability stack.

    Pass `extra_capabilities=[OpenAICompaction(), MCP(...)]` (or any other
    pydantic-ai capability) to extend the default stack without re-declaring it.
    """
    capabilities: list[AbstractCapability[AgentRuntimeDeps]] = [
        ThreadExecutor(executor or ThreadPoolExecutor(max_workers=4)),
        HistoryProcessor(history_processor or _truncate_history),
        _build_event_publishing_hooks(),
        LoggingCapability(),
        ThreadCapability(),
        ToolApprovalCapability(tools=approval_tools, notification_sink=approval_sink),
        UsageMeteringCapability(recorder=usage_recorder),
        KnowledgeBaseCapability(),
    ]
    if extra_capabilities:
        capabilities.extend(extra_capabilities)
    return capabilities


def _as_uuid(value: str | UUID | None) -> UUID | None:
    if value is None:
        return None
    if isinstance(value, UUID):
        return value
    try:
        return UUID(str(value))
    except (ValueError, TypeError):
        return None
