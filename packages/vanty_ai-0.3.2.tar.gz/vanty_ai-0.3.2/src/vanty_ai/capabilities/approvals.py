from __future__ import annotations

from collections.abc import Callable
from typing import Any
from uuid import UUID

from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.exceptions import ApprovalRequired
from pydantic_ai.run import AgentRunResult
from pydantic_ai.tools import DeferredToolRequests, RunContext, ToolDefinition
from vanty_core.events import publish

from vanty_ai.events import ToolApprovalRequested, ToolCalled
from vanty_ai.runtime.deps import AgentRuntimeDeps
from vanty_ai.services.approvals import (
    ApprovalNotificationEvent,
    ApprovalNotificationSink,
    LoggerApprovalSink,
    approval_requests_from_deferred,
    persist_approval_requests,
)

ApprovalPredicate = Callable[[ToolDefinition], bool]


class ToolApprovalCapability(AbstractCapability[AgentRuntimeDeps]):
    """Mark selected tools as approval-gated and persist resulting approval requests."""

    def __init__(
        self,
        *,
        tools: set[str] | None = None,
        predicate: ApprovalPredicate | None = None,
        notification_sink: ApprovalNotificationSink | None = None,
    ) -> None:
        self.tools = set(tools or set())
        self.predicate = predicate
        self.notification_sink = notification_sink or LoggerApprovalSink()

    async def before_tool_execute(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        call,
        tool_def: ToolDefinition,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        if self._requires_approval(tool_def) and not ctx.tool_call_approved:
            raise ApprovalRequired(
                metadata={
                    "tool_name": tool_def.name,
                    "thread_id": ctx.deps.thread_id,
                    "organization_id": ctx.deps.organization_ref(),
                    "args": args,
                }
            )
        return args

    async def after_run(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        *,
        result: AgentRunResult[Any],
    ) -> AgentRunResult[Any]:
        output = result.output
        if not isinstance(output, DeferredToolRequests) or not output.approvals:
            return result

        organization_id = ctx.deps.organization_ref()
        thread_id = ctx.deps.thread_id
        if organization_id is None or thread_id is None:
            return result

        requests = await persist_approval_requests(
            output=output,
            organization_id=organization_id,
            thread_id=thread_id,
            actor_user_id=ctx.deps.actor_ref(),
        )
        request_ids = [str(request.id) for request in requests]
        await self.notification_sink.publish(
            ApprovalNotificationEvent(
                organization_id=organization_id,
                thread_id=thread_id,
                request_ids=request_ids,
                approvals=approval_requests_from_deferred(output),
            )
        )
        org_uuid = _as_uuid(organization_id)
        if org_uuid is not None:
            for approval in output.approvals:
                await publish(
                    ToolApprovalRequested(
                        thread_id=thread_id,
                        organization_id=org_uuid,
                        tool_name=approval.tool_name,
                        request_ids=request_ids,
                    )
                )
        return result

    async def after_tool_execute(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        call,
        tool_def: ToolDefinition,
        args: dict[str, Any],
        result: Any,
    ) -> Any:
        await publish(
            ToolCalled(
                thread_id=ctx.deps.thread_id,
                organization_id=_as_uuid(ctx.deps.organization_id),
                actor_user_id=_as_uuid(ctx.deps.actor_user_id),
                tool_name=tool_def.name,
                tool_call_id=call.tool_call_id,
            )
        )
        return result

    def _requires_approval(self, tool_def: ToolDefinition) -> bool:
        if tool_def.name in self.tools:
            return True
        if self.predicate is not None:
            return self.predicate(tool_def)
        return False


def _as_uuid(value: Any) -> UUID | None:
    if value is None:
        return None
    if isinstance(value, UUID):
        return value
    try:
        return UUID(str(value))
    except (ValueError, TypeError):
        return None
