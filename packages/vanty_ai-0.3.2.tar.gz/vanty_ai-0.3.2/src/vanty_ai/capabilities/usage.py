from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.messages import ModelResponse
from pydantic_ai.run import AgentRunResult
from pydantic_ai.tools import RunContext
from vanty_core.events import publish

from vanty_ai.events import UsageMetered
from vanty_ai.runtime.deps import AgentRuntimeDeps
from vanty_ai.runtime.usage import UsageEventRecorder, UsageRecordContext, compute_response_costs
from vanty_ai.services.usage import TortoiseUsageRecorder


class UsageMeteringCapability(AbstractCapability[AgentRuntimeDeps]):
    """Capture token and cost snapshots for every model response in a run.

    Each captured response is stored via the configured `UsageEventRecorder`
    and emitted as a `vanty_ai.usage.metered` domain event so other systems
    (billing meters, analytics, CRM activity) can react.
    """

    def __init__(self, recorder: UsageEventRecorder | None = None) -> None:
        self.recorder = recorder or TortoiseUsageRecorder()

    async def after_run(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        *,
        result: AgentRunResult[Any],
    ) -> AgentRunResult[Any]:
        record_context = UsageRecordContext.from_run_context(ctx)
        for message in result.new_messages():
            if not isinstance(message, ModelResponse):
                continue
            event = compute_response_costs(message)
            if event.value <= 0:
                continue
            await self.recorder.record(event, record_context)
            await publish(
                UsageMetered(
                    thread_id=ctx.deps.thread_id,
                    organization_id=_as_uuid(ctx.deps.organization_id),
                    actor_user_id=_as_uuid(ctx.deps.actor_user_id),
                    model_name=event.model_name,
                    input_tokens=event.input_tokens,
                    output_tokens=event.output_tokens,
                    cost=event.total_cost,
                )
            )
        return result


def _as_uuid(value: Any) -> UUID | None:
    if value is None:
        return None
    if isinstance(value, UUID):
        return value
    try:
        return UUID(str(value))
    except (ValueError, TypeError):
        return None
