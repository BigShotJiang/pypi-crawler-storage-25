from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.run import AgentRunResult
from pydantic_ai.tools import RunContext
from vanty_core.events import publish

from vanty_ai.events import MessageReceived, MessageSent, ThreadCreated
from vanty_ai.runtime.deps import AgentRuntimeDeps
from vanty_ai.services.history import ThreadHistoryService


class ThreadCapability(AbstractCapability[AgentRuntimeDeps]):
    """Persist run history, keep thread lifecycle in sync, and publish thread/message events."""

    def __init__(self, default_title: str = "New Chat", history_service: ThreadHistoryService | None = None) -> None:
        self.default_title = default_title
        self.history_service = history_service or ThreadHistoryService()

    async def before_run(self, ctx: RunContext[AgentRuntimeDeps]) -> None:
        was_new = ctx.deps.thread is None
        await self.history_service.start_run(ctx.deps, default_title=self.default_title)
        if was_new and ctx.deps.thread_id is not None:
            await publish(
                ThreadCreated(
                    thread_id=ctx.deps.thread_id,
                    organization_id=_as_uuid(ctx.deps.organization_id),
                    actor_user_id=_as_uuid(ctx.deps.actor_user_id),
                    title=ctx.deps.thread_title or self.default_title,
                )
            )

    async def after_run(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        *,
        result: AgentRunResult[Any],
    ) -> AgentRunResult[Any]:
        messages = result.new_messages()
        await self.history_service.finish_run(
            ctx.deps,
            messages=messages,
            output=result.output,
            default_title=self.default_title,
        )
        if ctx.deps.thread_id is not None:
            await publish(
                MessageSent(
                    thread_id=ctx.deps.thread_id,
                    organization_id=_as_uuid(ctx.deps.organization_id),
                    actor_user_id=_as_uuid(ctx.deps.actor_user_id),
                    role="user",
                )
            )
            await publish(
                MessageReceived(
                    thread_id=ctx.deps.thread_id,
                    organization_id=_as_uuid(ctx.deps.organization_id),
                    actor_user_id=_as_uuid(ctx.deps.actor_user_id),
                )
            )
        return result

    async def on_run_error(
        self,
        ctx: RunContext[AgentRuntimeDeps],
        *,
        error: BaseException,
    ) -> AgentRunResult[Any]:
        await self.history_service.fail_run(ctx.deps, error=error, default_title=self.default_title)
        raise error


def _as_uuid(value: str | UUID | None) -> UUID | None:
    if value is None:
        return None
    if isinstance(value, UUID):
        return value
    try:
        return UUID(str(value))
    except (ValueError, TypeError):
        return None
