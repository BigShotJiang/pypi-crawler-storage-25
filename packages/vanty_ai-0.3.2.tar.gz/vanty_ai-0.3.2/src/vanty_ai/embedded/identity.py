from __future__ import annotations

from dataclasses import dataclass
from uuid import UUID


@dataclass(slots=True)
class EmbeddedChatIdentity:
    """Identity resolved from an embedded chat session token."""

    organization_id: UUID
    session_id: UUID
    config_id: UUID
    actor_user_id: UUID | None = None
    customer_id: str | None = None
    is_internal: bool = False
    origin: str | None = None
