from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from fastapi.responses import StreamingResponse
from vanty_core.events import publish

from vanty_ai.embedded.identity import EmbeddedChatIdentity
from vanty_ai.embedded.schemas import (
    CreateEmbeddedSessionIn,
    CreateEmbeddedThreadIn,
    EmbeddedConfigOut,
    EmbeddedCreateMessageIn,
    EmbeddedFileOut,
    EmbeddedMessagesOut,
    EmbeddedSessionGrantOut,
    EmbeddedSessionMeOut,
    EmbeddedSessionOut,
    EmbeddedThreadListOut,
    RegisterEmbeddedFileIn,
)
from vanty_ai.embedded.tokens import EmbeddedTokenService
from vanty_ai.events import MessageSent, ThreadCreated
from vanty_ai.fastapi.dependencies import AIRequestIdentity, build_runtime_deps, get_ai_app
from vanty_ai.fastapi.schemas import MessageOut, ThreadOut
from vanty_ai.persistence.models import (
    AgentMessage,
    AgentThread,
    EmbeddedAgentConfig,
    EmbeddedChatSession,
    EmbeddedChatToken,
)

router = APIRouter(prefix="/ai/embed", tags=["ai-embed"])

EMBEDDED_CHANNEL = "embedded_support"


async def _get_embed_identity(
    request: Request,
    authorization: str | None = Header(default=None),
    kit=Depends(get_ai_app),
) -> EmbeddedChatIdentity:
    if authorization is None or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Embedded token required")
    token = authorization.split(" ", 1)[1].strip()
    service = _token_service(kit)
    payload = service.verify(token)
    token_row = await EmbeddedChatToken.unscoped.get_or_none(
        token_id=UUID(payload["token_id"]),
        token_hash=service.hash_token(token),
        revoked_at=None,
    )
    if token_row is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Embedded token revoked")

    origin = request.headers.get("origin") or payload.get("origin")
    config = await EmbeddedAgentConfig.unscoped.get_or_none(id=payload["config_id"])
    if config is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Embedded config not found")
    _assert_config_enabled_for_origin(config, origin)

    return EmbeddedChatIdentity(
        organization_id=UUID(payload["organization_id"]),
        session_id=UUID(payload["session_id"]),
        config_id=UUID(payload["config_id"]),
        customer_id=payload.get("customer_id"),
        is_internal=bool(payload.get("is_internal")),
        origin=origin,
    )


@router.post("/sessions", response_model=EmbeddedSessionGrantOut, status_code=status.HTTP_201_CREATED)
async def create_session(
    body: CreateEmbeddedSessionIn,
    request: Request,
    kit=Depends(get_ai_app),
) -> EmbeddedSessionGrantOut:
    config = await _load_or_create_config(body.organization_id, body.config_id)
    _assert_config_enabled_for_origin(config, body.origin or request.headers.get("origin"))

    session = await EmbeddedChatSession.create(
        organization_id=body.organization_id,
        config=config,
        customer_id=body.customer_id,
        is_internal=body.is_internal,
        origin=body.origin or request.headers.get("origin"),
        visitor=body.visitor,
    )

    token_service = _token_service(kit)
    token, payload, expires_at = token_service.issue(
        organization_id=body.organization_id,
        session_id=session.id,
        config_id=config.id,
        origin=session.origin,
        customer_id=session.customer_id,
        is_internal=session.is_internal,
    )
    await EmbeddedChatToken.create(
        organization_id=body.organization_id,
        session=session,
        config=config,
        token_id=UUID(payload["token_id"]),
        token_hash=token_service.hash_token(token),
        origin=session.origin,
        expires_at=expires_at,
    )
    return EmbeddedSessionGrantOut(
        session=EmbeddedSessionOut.model_validate(session),
        config=EmbeddedConfigOut.model_validate(config),
        token=token,
        expires_at=expires_at,
    )


@router.get("/sessions/me", response_model=EmbeddedSessionMeOut)
async def get_session(identity: EmbeddedChatIdentity = Depends(_get_embed_identity)) -> EmbeddedSessionMeOut:
    session = await _load_session(identity)
    config = await EmbeddedAgentConfig.unscoped.get(id=identity.config_id)
    return EmbeddedSessionMeOut(
        session=EmbeddedSessionOut.model_validate(session),
        config=EmbeddedConfigOut.model_validate(config),
    )


@router.get("/threads", response_model=EmbeddedThreadListOut)
async def list_threads(
    identity: EmbeddedChatIdentity = Depends(_get_embed_identity),
    limit: int = 50,
    offset: int = 0,
) -> EmbeddedThreadListOut:
    candidates = await AgentThread.unscoped.filter(
        organization_id=identity.organization_id,
        channel=EMBEDDED_CHANNEL,
    ).order_by("-updated_at")
    filtered = [
        thread for thread in candidates if thread.metadata.get("embedded_session_id") == str(identity.session_id)
    ]
    total = len(filtered)
    items = filtered[offset : offset + limit]
    return EmbeddedThreadListOut(items=[ThreadOut.model_validate(item) for item in items], total=total)


@router.post("/threads", response_model=ThreadOut, status_code=status.HTTP_201_CREATED)
async def create_thread(
    body: CreateEmbeddedThreadIn,
    identity: EmbeddedChatIdentity = Depends(_get_embed_identity),
) -> ThreadOut:
    metadata = _embedded_metadata(identity, body.metadata)
    thread = await AgentThread.create(
        organization_id=identity.organization_id,
        actor_user_id=identity.actor_user_id,
        title=body.title or "New conversation",
        channel=EMBEDDED_CHANNEL,
        metadata=metadata,
    )
    await publish(
        ThreadCreated(
            thread_id=str(thread.id),
            organization_id=identity.organization_id,
            actor_user_id=identity.actor_user_id,
            title=thread.title,
        )
    )
    return ThreadOut.model_validate(thread)


@router.get("/threads/{thread_id}/messages", response_model=EmbeddedMessagesOut)
async def list_messages(
    thread_id: UUID,
    identity: EmbeddedChatIdentity = Depends(_get_embed_identity),
    limit: int = 200,
    offset: int = 0,
) -> EmbeddedMessagesOut:
    await _load_thread(thread_id, identity)
    qs = AgentMessage.unscoped.filter(thread_id=thread_id)
    total = await qs.count()
    items = await qs.order_by("created_at").offset(offset).limit(limit)
    return EmbeddedMessagesOut(items=[MessageOut.model_validate(item) for item in items], total=total)


@router.post("/threads/{thread_id}/messages", response_model=EmbeddedMessagesOut, status_code=status.HTTP_201_CREATED)
async def post_message(
    thread_id: UUID,
    body: EmbeddedCreateMessageIn,
    identity: EmbeddedChatIdentity = Depends(_get_embed_identity),
    kit=Depends(get_ai_app),
) -> EmbeddedMessagesOut:
    thread = await _load_thread(thread_id, identity)
    config = await EmbeddedAgentConfig.unscoped.get(id=identity.config_id)
    metadata = _embedded_metadata(
        identity,
        {
            **body.metadata,
            "attachments": body.attachments,
        },
    )
    deps = build_runtime_deps(
        AIRequestIdentity(organization_id=identity.organization_id, actor_user_id=identity.actor_user_id),
        thread_id=str(thread.id),
        thread_title=thread.title,
        channel=EMBEDDED_CHANNEL,
        metadata={
            **metadata,
            "knowledge_enabled": bool(config.capabilities.get("knowledge", False)),
        },
    )
    await publish(
        MessageSent(
            thread_id=str(thread.id),
            organization_id=identity.organization_id,
            actor_user_id=identity.actor_user_id,
            role="user",
        )
    )
    await kit.agent_service.run(prompt=body.content, deps=deps)
    new_messages = await AgentMessage.unscoped.filter(thread_id=thread_id).order_by("-created_at").limit(20)
    return EmbeddedMessagesOut(
        items=[MessageOut.model_validate(item) for item in reversed(new_messages)],
        total=len(new_messages),
    )


@router.post("/threads/{thread_id}/stream")
async def stream_message(
    thread_id: UUID,
    body: EmbeddedCreateMessageIn,
    identity: EmbeddedChatIdentity = Depends(_get_embed_identity),
    kit=Depends(get_ai_app),
) -> StreamingResponse:
    """Stream an embedded customer-support turn as Server-Sent Events."""
    thread = await _load_thread(thread_id, identity)
    config = await EmbeddedAgentConfig.unscoped.get(id=identity.config_id)
    metadata = _embedded_metadata(
        identity,
        {
            **body.metadata,
            "attachments": body.attachments,
        },
    )
    deps = build_runtime_deps(
        AIRequestIdentity(organization_id=identity.organization_id, actor_user_id=identity.actor_user_id),
        thread_id=str(thread.id),
        thread_title=thread.title,
        channel=EMBEDDED_CHANNEL,
        metadata={
            **metadata,
            "knowledge_enabled": bool(config.capabilities.get("knowledge", False)),
        },
    )
    await publish(
        MessageSent(
            thread_id=str(thread.id),
            organization_id=identity.organization_id,
            actor_user_id=identity.actor_user_id,
            role="user",
        )
    )

    async def _event_stream():
        yield _sse_event("thread", {"thread_id": str(thread.id)})
        try:
            async for event in kit.agent_service.stream_events(prompt=body.content, deps=deps):
                payload = _serialise_event(event)
                if _is_reasoning_payload(payload):
                    continue
                yield _sse_event(type(event).__name__, payload)
        except Exception as exc:
            yield _sse_event("error", {"message": str(exc)})
        yield _sse_event("done", {})

    return StreamingResponse(_event_stream(), media_type="text/event-stream")


@router.post("/files", response_model=EmbeddedFileOut, status_code=status.HTTP_201_CREATED)
async def register_file_ref(
    body: RegisterEmbeddedFileIn,
    identity: EmbeddedChatIdentity = Depends(_get_embed_identity),
) -> EmbeddedFileOut:
    """Register a browser file reference for a message attachment.

    Host apps can replace this with a real file-service backed implementation.
    Keeping this endpoint in the AI surface gives the widget a stable contract
    while the actual storage/indexing service remains pluggable.
    """
    return EmbeddedFileOut(
        id=f"embed-file:{identity.session_id}:{body.name}",
        name=body.name,
        content_type=body.content_type,
        size=body.size,
        metadata={
            **body.metadata,
            "session_id": str(identity.session_id),
            "config_id": str(identity.config_id),
        },
    )


async def _load_or_create_config(organization_id: UUID, config_id: UUID | None) -> EmbeddedAgentConfig:
    if config_id is not None:
        config = await EmbeddedAgentConfig.unscoped.get_or_none(id=config_id)
        if config is None or str(config.organization_id) != str(organization_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Embedded config not found")
        return await _ensure_default_capabilities(config)
    config = await EmbeddedAgentConfig.unscoped.filter(organization_id=organization_id, enabled=True).first()
    if config is not None:
        return await _ensure_default_capabilities(config)
    return await EmbeddedAgentConfig.create(
        organization_id=organization_id,
        name="Aurora support",
        branding={
            "name": "Aurora",
            "subtitle": "AI support agent",
            "launcher_label": "Open support",
            "primary_color": "#11130d",
        },
        capabilities={
            "threads": True,
            "files": True,
            "usage": True,
            "knowledge": True,
        },
    )


async def _ensure_default_capabilities(config: EmbeddedAgentConfig) -> EmbeddedAgentConfig:
    capabilities = {"threads": True, "files": True, "usage": True, "knowledge": True}
    next_capabilities = {**(config.capabilities or {}), **capabilities}
    if next_capabilities != (config.capabilities or {}):
        config.capabilities = next_capabilities
        await config.save(update_fields=["capabilities", "updated_at"])
    return config


async def _load_session(identity: EmbeddedChatIdentity) -> EmbeddedChatSession:
    session = await EmbeddedChatSession.unscoped.get_or_none(id=identity.session_id)
    if session is None or str(session.organization_id) != str(identity.organization_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Embedded session not found")
    return session


async def _load_thread(thread_id: UUID, identity: EmbeddedChatIdentity) -> AgentThread:
    thread = await AgentThread.unscoped.get_or_none(id=thread_id)
    if thread is None or str(thread.organization_id) != str(identity.organization_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Thread not found")
    if thread.channel != EMBEDDED_CHANNEL or thread.metadata.get("embedded_session_id") != str(identity.session_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Thread not found")
    return thread


def _embedded_metadata(identity: EmbeddedChatIdentity, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        **(metadata or {}),
        "embedded": True,
        "embedded_session_id": str(identity.session_id),
        "embedded_config_id": str(identity.config_id),
        "customer_id": identity.customer_id,
        "is_internal": identity.is_internal,
    }


def _assert_config_enabled_for_origin(config: EmbeddedAgentConfig, origin: str | None) -> None:
    if not config.enabled:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Embedded agent disabled")
    allowed = config.allowed_origins or []
    if allowed and origin not in allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Origin is not allowed")


def _token_service(kit: Any) -> EmbeddedTokenService:
    settings = getattr(kit, "settings", None)
    return EmbeddedTokenService(
        secret=getattr(settings, "embedded_token_secret", "vanty-ai-dev-embedded-secret"),
        ttl_seconds=getattr(settings, "embedded_token_ttl_seconds", 60 * 60 * 24 * 30),
    )


def _sse_event(event_type: str, payload: Any) -> str:
    return f"event: {event_type}\ndata: {json.dumps(payload, default=str)}\n\n"


def _serialise_event(event: Any) -> dict[str, Any]:
    for attr in ("model_dump", "to_dict", "__dict__"):
        if hasattr(event, attr):
            try:
                value = getattr(event, attr)
                if callable(value):
                    return value()
                return dict(value)
            except Exception:  # noqa: BLE001
                continue
    return {"repr": repr(event)}


def _is_reasoning_payload(payload: dict[str, Any]) -> bool:
    text = json.dumps(payload, default=str)
    return "ThinkingPart" in text or "ThinkingPartDelta" in text or "reasoning.text" in text
