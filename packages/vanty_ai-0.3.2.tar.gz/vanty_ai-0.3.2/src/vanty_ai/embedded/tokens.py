from __future__ import annotations

import base64
import hashlib
import hmac
import json
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID, uuid4

from fastapi import HTTPException, status


class EmbeddedTokenService:
    """Small signed-token helper for browser embedded chat sessions."""

    def __init__(self, *, secret: str, ttl_seconds: int) -> None:
        self.secret = secret.encode()
        self.ttl_seconds = ttl_seconds

    def issue(
        self,
        *,
        organization_id: UUID,
        session_id: UUID,
        config_id: UUID,
        origin: str | None = None,
        customer_id: str | None = None,
        is_internal: bool = False,
    ) -> tuple[str, dict[str, Any], datetime]:
        expires_at = datetime.now(UTC) + timedelta(seconds=self.ttl_seconds)
        payload: dict[str, Any] = {
            "token_id": str(uuid4()),
            "organization_id": str(organization_id),
            "session_id": str(session_id),
            "config_id": str(config_id),
            "origin": origin,
            "customer_id": customer_id,
            "is_internal": is_internal,
            "expires_at": expires_at.isoformat(),
        }
        return self._encode(payload), payload, expires_at

    def verify(self, token: str) -> dict[str, Any]:
        try:
            payload_part, signature = token.split(".", 1)
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid embedded token") from exc

        expected = self._sign(payload_part)
        if not hmac.compare_digest(signature, expected):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid embedded token")

        try:
            payload = json.loads(_b64decode(payload_part).decode())
            expires_at = datetime.fromisoformat(payload["expires_at"])
        except (KeyError, ValueError, TypeError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid embedded token") from exc

        if expires_at <= datetime.now(UTC):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Embedded token expired")
        return payload

    def hash_token(self, token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()

    def _encode(self, payload: dict[str, Any]) -> str:
        payload_part = _b64encode(json.dumps(payload, separators=(",", ":"), default=str).encode())
        return f"{payload_part}.{self._sign(payload_part)}"

    def _sign(self, payload_part: str) -> str:
        digest = hmac.new(self.secret, payload_part.encode(), hashlib.sha256).digest()
        return _b64encode(digest)


def _b64encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode()


def _b64decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(f"{value}{padding}")
