from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from vanty_ai.fastapi.schemas import MessageOut, ThreadOut


class EmbeddedBranding(BaseModel):
    name: str = "Aurora"
    subtitle: str = "AI support agent"
    launcher_label: str = "Open support"
    primary_color: str = "#11130d"


class EmbeddedConfigOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    organization_id: UUID
    name: str
    enabled: bool
    allowed_origins: list[str] = Field(default_factory=list)
    branding: dict[str, Any] = Field(default_factory=dict)
    capabilities: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class CreateEmbeddedSessionIn(BaseModel):
    organization_id: UUID
    config_id: UUID | None = None
    origin: str | None = None
    customer_id: str | None = None
    visitor: dict[str, Any] = Field(default_factory=dict)
    is_internal: bool = False


class EmbeddedSessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    organization_id: UUID
    config_id: UUID
    customer_id: str | None = None
    is_internal: bool
    visitor: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class EmbeddedSessionGrantOut(BaseModel):
    session: EmbeddedSessionOut
    config: EmbeddedConfigOut
    token: str
    expires_at: datetime


class EmbeddedSessionMeOut(BaseModel):
    session: EmbeddedSessionOut
    config: EmbeddedConfigOut


class CreateEmbeddedThreadIn(BaseModel):
    title: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EmbeddedThreadListOut(BaseModel):
    items: list[ThreadOut]
    total: int


class EmbeddedCreateMessageIn(BaseModel):
    content: str
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class RegisterEmbeddedFileIn(BaseModel):
    name: str
    content_type: str | None = None
    size: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EmbeddedFileOut(BaseModel):
    id: str
    name: str
    content_type: str | None = None
    size: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EmbeddedMessagesOut(BaseModel):
    items: list[MessageOut]
    total: int
