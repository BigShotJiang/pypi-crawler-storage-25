from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Protocol

from genai_prices import calc_price
from pydantic_ai.messages import ModelResponse

from vanty_ai.runtime.deps import AgentRuntimeDeps


@dataclass(slots=True)
class UsageEvent:
    event_name: str = "ai_tokens"
    value: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    reasoning_tokens: int = 0
    input_cost: Decimal = Decimal("0")
    output_cost: Decimal = Decimal("0")
    total_cost: Decimal = Decimal("0")
    cost_source: str = "zero_fallback"
    model_name: str | None = None
    provider_name: str | None = None
    provider_response_id: str | None = None
    dimensions: dict[str, Any] = field(default_factory=dict)

    def with_dimensions(self) -> dict[str, Any]:
        return {
            **self.dimensions,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "cache_write_tokens": self.cache_write_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "input_cost": str(self.input_cost),
            "output_cost": str(self.output_cost),
            "total_cost": str(self.total_cost),
            "cost_source": self.cost_source,
            "model_name": self.model_name,
            "provider_name": self.provider_name,
            "provider_response_id": self.provider_response_id,
        }


@dataclass(slots=True)
class UsageRecordContext:
    """Explicit runtime context passed to usage sinks.

    Sinks should use this instead of retaining mutable state from a previous
    capability hook. `run_context` is intentionally typed as `Any` so this value
    object stays lightweight and does not force downstream integrations to import
    Pydantic AI types unless they need them.
    """

    deps: AgentRuntimeDeps
    organization_id: str | None
    thread_id: str | None
    run_context: Any | None = None

    @classmethod
    def from_run_context(cls, ctx: Any) -> UsageRecordContext:
        deps = ctx.deps
        return cls(
            deps=deps,
            organization_id=deps.organization_ref(),
            thread_id=deps.thread_id,
            run_context=ctx,
        )


class UsageEventRecorder(Protocol):
    async def record(self, event: UsageEvent, context: UsageRecordContext) -> None: ...


def _estimate_costs(
    *,
    response: ModelResponse,
    model_name: str | None,
    provider_name: str | None,
) -> tuple[Decimal, Decimal]:
    if not model_name:
        return Decimal("0"), Decimal("0")

    try:
        if provider_name:
            price = calc_price(response.usage, model_ref=model_name, provider_id=provider_name)
        else:
            price = calc_price(response.usage, model_ref=model_name)
    except Exception:
        try:
            price = calc_price(response.usage, model_ref=model_name)
        except Exception:
            return Decimal("0"), Decimal("0")

    input_cost = Decimal(str(getattr(price, "input_cost", 0) or 0))
    output_cost = Decimal(str(getattr(price, "output_cost", 0) or 0))
    return input_cost, output_cost


def compute_response_costs(response: ModelResponse, fallback_model: str | None = None) -> UsageEvent:
    usage = response.usage
    provider_details = response.provider_details or {}

    input_tokens = int(usage.input_tokens or 0)
    output_tokens = int(usage.output_tokens or 0)
    cache_read_tokens = int(usage.cache_read_tokens or 0)
    cache_write_tokens = int(usage.cache_write_tokens or 0)
    reasoning_tokens = int((usage.details or {}).get("reasoning_tokens", 0) or 0)
    total_tokens = int(usage.total_tokens or 0)
    model_name = response.model_name or fallback_model
    provider_name = response.provider_name

    input_cost = Decimal("0")
    output_cost = Decimal("0")
    total_cost = Decimal("0")
    cost_source = "zero_fallback"

    provider_cost = provider_details.get("cost")
    if isinstance(provider_cost, int | float):
        total_cost = Decimal(str(provider_cost))
        input_cost, output_cost = _estimate_costs(
            response=response,
            model_name=model_name,
            provider_name=provider_name,
        )
        cost_source = "provider_details"
    elif total_tokens > 0:
        input_cost, output_cost = _estimate_costs(
            response=response,
            model_name=model_name,
            provider_name=provider_name,
        )
        total_cost = input_cost + output_cost
        cost_source = "genai_prices" if total_cost > 0 else "zero_fallback"

    event = UsageEvent(
        value=total_tokens,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cache_read_tokens=cache_read_tokens,
        cache_write_tokens=cache_write_tokens,
        reasoning_tokens=reasoning_tokens,
        input_cost=input_cost,
        output_cost=output_cost,
        total_cost=total_cost,
        cost_source=cost_source,
        model_name=model_name,
        provider_name=provider_name,
        provider_response_id=response.provider_response_id,
    )
    event.dimensions = event.with_dimensions()
    return event
