from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from uuid import UUID


@dataclass(slots=True)
class AgentRuntimeDeps:
    """Mutable runtime context passed into Vanty AI capabilities.

    The object intentionally stays lightweight and framework-agnostic so the app can
    enrich it with whatever extra state it needs during a run.
    """

    organization_id: str | UUID | None = None
    actor_user_id: str | UUID | None = None
    thread_id: str | None = None
    thread_title: str | None = None
    channel: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    thread: Any | None = None

    def organization_ref(self) -> str | None:
        return str(self.organization_id) if self.organization_id is not None else None

    def actor_ref(self) -> str | None:
        return str(self.actor_user_id) if self.actor_user_id is not None else None
