"""Default toolsets shipped with vanty-ai.

These are intentionally minimal so the chat router boots end-to-end without
network credentials. Hosts are expected to register richer toolsets via
`AIApp.register_toolset(...)`.
"""

from __future__ import annotations

from datetime import UTC, datetime


def current_time() -> str:
    """Return the current UTC timestamp in ISO 8601 format.

    Useful as a no-op tool while testing the chat surface end-to-end.
    """
    return datetime.now(UTC).isoformat()


DEFAULT_TOOLS = [current_time]
