from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class AISettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="AI_",
        env_file=".env",
        env_nested_delimiter="__",
        extra="ignore",
    )

    app_name: str = "vanty-ai"
    model: str | None = None
    embedded_token_secret: str = "vanty-ai-dev-embedded-secret"
    embedded_token_ttl_seconds: int = 60 * 60 * 24 * 30
    embedding_model: str = "openai/text-embedding-3-small"
    embedding_dimensions: int = 1536
