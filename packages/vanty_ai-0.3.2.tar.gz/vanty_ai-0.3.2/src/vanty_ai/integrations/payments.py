from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from vanty_ai.runtime.usage import UsageEvent, UsageEventRecorder, UsageRecordContext

BillingAccountResolver = Callable[[UsageRecordContext, UsageEvent], Awaitable[Any]]


class PaymentsMeterRecorder(UsageEventRecorder):
    """Bridge `UsageEvent`s into `vanty-payments` billing meter events.

    Pass a `BillingService` instance plus a resolver that turns the explicit
    usage record context into the billing account the usage should attach to.
    The recorder is stateless between calls; it does not require `bind(ctx)`.
    """

    def __init__(
        self,
        *,
        billing_service: Any,
        account_resolver: BillingAccountResolver,
        event_name: str = "ai_tokens",
    ) -> None:
        self.billing_service = billing_service
        self.account_resolver = account_resolver
        self.event_name = event_name

    async def record(self, event: UsageEvent, context: UsageRecordContext) -> None:
        account = await self.account_resolver(context, event)
        await self.billing_service.record_usage(
            account,
            event_name=self.event_name,
            value=event.value,
            dimensions={
                **event.dimensions,
                "thread_id": context.thread_id,
            },
        )
