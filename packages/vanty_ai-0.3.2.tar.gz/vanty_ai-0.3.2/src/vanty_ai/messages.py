from __future__ import annotations

import json
from typing import Any

from pydantic_ai.messages import ModelMessage, ModelMessagesTypeAdapter, ModelRequest, ModelResponse, ToolCallPart


def dump_model_messages(messages: list[ModelMessage]) -> list[dict[str, Any]]:
    return json.loads(ModelMessagesTypeAdapter.dump_json(messages))


def dump_model_message(message: ModelMessage) -> dict[str, Any]:
    return dump_model_messages([message])[0]


def load_model_messages(payload: list[dict[str, Any]]) -> list[ModelMessage]:
    messages = ModelMessagesTypeAdapter.validate_python(payload)
    return list(messages)


def infer_role(message: ModelMessage) -> str:
    if isinstance(message, ModelResponse):
        return "assistant"
    if isinstance(message, ModelRequest):
        return "user"
    return getattr(message, "kind", "unknown")


def tool_call_payload(call: ToolCallPart, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = {
        "tool_call_id": call.tool_call_id,
        "tool_name": call.tool_name,
        "args": call.args_as_dict(),
    }
    if metadata:
        payload["metadata"] = metadata
    return payload
