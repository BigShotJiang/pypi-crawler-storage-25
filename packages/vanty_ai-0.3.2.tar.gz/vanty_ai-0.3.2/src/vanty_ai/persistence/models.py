from __future__ import annotations

from decimal import Decimal
from enum import StrEnum

from tortoise import fields
from vanty_core.db.models import OrganizationScopedModel


class ThreadStatus(StrEnum):
    idle = "idle"
    running = "running"
    paused = "paused"
    complete = "complete"
    error = "error"


class ApprovalStatus(StrEnum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"


class AgentThread(OrganizationScopedModel):
    title = fields.CharField(max_length=255, default="New Chat")
    actor_user_id = fields.UUIDField(null=True)
    channel = fields.CharField(max_length=64, null=True)
    status = fields.CharEnumField(ThreadStatus, default=ThreadStatus.idle, max_length=32)
    message_count = fields.IntField(default=0)
    last_run_started_at = fields.DatetimeField(null=True)
    last_run_finished_at = fields.DatetimeField(null=True)
    last_error = fields.TextField(null=True)
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "agent_threads"
        ordering = ["-updated_at"]


class AgentMessage(OrganizationScopedModel):
    thread = fields.ForeignKeyField("models.AgentThread", related_name="messages", on_delete=fields.CASCADE)
    role = fields.CharField(max_length=32, db_index=True)
    kind = fields.CharField(max_length=32, db_index=True)
    payload = fields.JSONField()
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "agent_messages"
        ordering = ["created_at"]


class AgentApprovalRequest(OrganizationScopedModel):
    thread = fields.ForeignKeyField(
        "models.AgentThread",
        related_name="approval_requests",
        on_delete=fields.CASCADE,
    )
    run_id = fields.CharField(max_length=255, null=True)
    tool_call_id = fields.CharField(max_length=255, unique=True, db_index=True)
    tool_name = fields.CharField(max_length=255, db_index=True)
    status = fields.CharEnumField(ApprovalStatus, default=ApprovalStatus.pending, max_length=32)
    args = fields.JSONField(default=dict)
    override_args = fields.JSONField(null=True)
    reason = fields.TextField(null=True)
    requested_by_user_id = fields.UUIDField(null=True)
    reviewed_by_user_id = fields.UUIDField(null=True)
    reviewed_at = fields.DatetimeField(null=True)
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "agent_approval_requests"
        ordering = ["created_at"]


class AgentUsageEvent(OrganizationScopedModel):
    thread = fields.ForeignKeyField(
        "models.AgentThread",
        related_name="usage_events",
        null=True,
        on_delete=fields.SET_NULL,
    )
    event_name = fields.CharField(max_length=64, default="ai_tokens", db_index=True)
    value = fields.IntField(default=0)
    input_tokens = fields.IntField(default=0)
    output_tokens = fields.IntField(default=0)
    cache_read_tokens = fields.IntField(default=0)
    cache_write_tokens = fields.IntField(default=0)
    reasoning_tokens = fields.IntField(default=0)
    input_cost = fields.DecimalField(max_digits=12, decimal_places=8, default=Decimal("0"))
    output_cost = fields.DecimalField(max_digits=12, decimal_places=8, default=Decimal("0"))
    total_cost = fields.DecimalField(max_digits=12, decimal_places=8, default=Decimal("0"))
    cost_source = fields.CharField(max_length=64, default="zero_fallback")
    model_name = fields.CharField(max_length=255, null=True)
    provider_name = fields.CharField(max_length=128, null=True)
    provider_response_id = fields.CharField(max_length=255, null=True)
    dimensions = fields.JSONField(default=dict)

    class Meta:
        table = "agent_usage_events"
        ordering = ["-created_at"]


class KnowledgeSource(OrganizationScopedModel):
    name = fields.CharField(max_length=255)
    source_type = fields.CharField(max_length=64, default="manual", db_index=True)
    external_id = fields.CharField(max_length=255, null=True, db_index=True)
    url = fields.CharField(max_length=1024, null=True)
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "agent_knowledge_sources"
        unique_together = (("organization_id", "source_type", "external_id"),)
        ordering = ["name"]


class KnowledgeDocument(OrganizationScopedModel):
    source = fields.ForeignKeyField(
        "models.KnowledgeSource",
        related_name="documents",
        on_delete=fields.CASCADE,
    )
    title = fields.CharField(max_length=500)
    url = fields.CharField(max_length=1024, null=True)
    content_hash = fields.CharField(max_length=64, db_index=True)
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "agent_knowledge_documents"
        unique_together = (("organization_id", "source", "content_hash"),)
        ordering = ["title"]


class KnowledgeChunk(OrganizationScopedModel):
    document = fields.ForeignKeyField(
        "models.KnowledgeDocument",
        related_name="chunks",
        on_delete=fields.CASCADE,
    )
    source = fields.ForeignKeyField(
        "models.KnowledgeSource",
        related_name="chunks",
        on_delete=fields.CASCADE,
    )
    ordinal = fields.IntField(default=0)
    text = fields.TextField()
    embedding = fields.JSONField(default=list)
    embedding_model = fields.CharField(max_length=255)
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "agent_knowledge_chunks"
        unique_together = (("document", "ordinal"),)
        ordering = ["document_id", "ordinal"]


class EmbeddedAgentConfig(OrganizationScopedModel):
    name = fields.CharField(max_length=255, default="Support agent")
    enabled = fields.BooleanField(default=True)
    allowed_origins = fields.JSONField(default=list)
    branding = fields.JSONField(default=dict)
    capabilities = fields.JSONField(default=dict)
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "embedded_agent_configs"
        ordering = ["name"]


class EmbeddedChatSession(OrganizationScopedModel):
    config = fields.ForeignKeyField(
        "models.EmbeddedAgentConfig",
        related_name="sessions",
        on_delete=fields.CASCADE,
    )
    customer_id = fields.CharField(max_length=255, null=True, db_index=True)
    actor_user_id = fields.UUIDField(null=True)
    is_internal = fields.BooleanField(default=False)
    origin = fields.CharField(max_length=512, null=True)
    visitor = fields.JSONField(default=dict)
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "embedded_chat_sessions"
        ordering = ["-updated_at"]


class EmbeddedChatToken(OrganizationScopedModel):
    session = fields.ForeignKeyField(
        "models.EmbeddedChatSession",
        related_name="tokens",
        on_delete=fields.CASCADE,
    )
    config = fields.ForeignKeyField(
        "models.EmbeddedAgentConfig",
        related_name="tokens",
        on_delete=fields.CASCADE,
    )
    token_id = fields.UUIDField(unique=True, db_index=True)
    token_hash = fields.CharField(max_length=64, unique=True, db_index=True)
    origin = fields.CharField(max_length=512, null=True)
    expires_at = fields.DatetimeField()
    revoked_at = fields.DatetimeField(null=True)
    metadata = fields.JSONField(default=dict)

    class Meta:
        table = "embedded_chat_tokens"
        ordering = ["-created_at"]
