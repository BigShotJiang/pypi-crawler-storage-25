from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from vanty_ai.persistence.models import AgentApprovalRequest, ApprovalStatus


class ApprovalRequestStore:
    async def persist_deferred_requests(
        self,
        *,
        approvals: list[dict[str, Any]],
        organization_id: str,
        thread_id: str,
        actor_user_id: str | None,
    ) -> list[AgentApprovalRequest]:
        requests: list[AgentApprovalRequest] = []
        for approval in approvals:
            request, _created = await AgentApprovalRequest.get_or_create(
                tool_call_id=approval["tool_call_id"],
                defaults={
                    "organization_id": organization_id,
                    "thread_id": thread_id,
                    "run_id": approval.get("run_id"),
                    "tool_name": approval["tool_name"],
                    "args": approval["args"],
                    "metadata": approval.get("metadata") or {},
                    "requested_by_user_id": actor_user_id,
                },
            )
            requests.append(request)
        return requests

    async def list_pending(self, *, thread_id: str) -> list[AgentApprovalRequest]:
        return await AgentApprovalRequest.unscoped.filter(
            thread_id=thread_id,
            status=ApprovalStatus.pending,
        ).order_by("created_at")

    async def apply_decision(
        self,
        request: AgentApprovalRequest,
        *,
        approved: bool,
        reviewed_by_user_id: str | None = None,
        override_args: dict[str, Any] | None = None,
        reason: str | None = None,
    ) -> AgentApprovalRequest:
        request.status = ApprovalStatus.approved if approved else ApprovalStatus.rejected
        request.reviewed_by_user_id = reviewed_by_user_id
        request.override_args = override_args if approved else None
        request.reason = reason
        request.reviewed_at = datetime.now(UTC)
        await request.save()
        return request
