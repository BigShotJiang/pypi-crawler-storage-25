from __future__ import annotations

from vanty_ai.persistence.models import AgentUsageEvent
from vanty_ai.runtime.usage import UsageEvent, UsageRecordContext


class UsageEventStore:
    async def record(self, event: UsageEvent, context: UsageRecordContext) -> None:
        if context.organization_id is None:
            return
        await AgentUsageEvent.create(
            organization_id=context.organization_id,
            thread_id=context.thread_id,
            event_name=event.event_name,
            value=event.value,
            input_tokens=event.input_tokens,
            output_tokens=event.output_tokens,
            cache_read_tokens=event.cache_read_tokens,
            cache_write_tokens=event.cache_write_tokens,
            reasoning_tokens=event.reasoning_tokens,
            input_cost=event.input_cost,
            output_cost=event.output_cost,
            total_cost=event.total_cost,
            cost_source=event.cost_source,
            model_name=event.model_name,
            provider_name=event.provider_name,
            provider_response_id=event.provider_response_id,
            dimensions=event.dimensions,
        )
