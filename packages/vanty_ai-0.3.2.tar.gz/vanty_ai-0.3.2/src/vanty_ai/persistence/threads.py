from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic_ai.messages import ModelMessage
from pydantic_ai.tools import DeferredToolRequests

from vanty_ai.messages import dump_model_message, infer_role, load_model_messages
from vanty_ai.persistence.models import AgentMessage, AgentThread, ThreadStatus
from vanty_ai.runtime.deps import AgentRuntimeDeps


class ThreadStore:
    async def ensure_thread(self, deps: AgentRuntimeDeps, *, default_title: str = "New Chat") -> AgentThread:
        if deps.organization_ref() is None:
            raise ValueError("AgentRuntimeDeps.organization_id is required for ThreadCapability")
        if deps.thread is not None:
            return deps.thread
        if deps.thread_id is not None:
            thread = await AgentThread.unscoped.get(id=deps.thread_id)
            deps.thread = thread
            return thread
        thread = await AgentThread.create(
            organization_id=deps.organization_ref(),
            actor_user_id=deps.actor_ref(),
            channel=deps.channel,
            title=deps.thread_title or default_title,
            metadata=deps.metadata or {},
        )
        deps.thread = thread
        deps.thread_id = str(thread.id)
        return thread

    async def mark_running(self, thread: AgentThread) -> None:
        thread.status = ThreadStatus.running
        thread.last_run_started_at = datetime.now(UTC)
        thread.last_error = None
        await thread.save(update_fields=["status", "last_run_started_at", "last_error", "updated_at"])

    async def mark_finished(self, thread: AgentThread, *, new_message_count: int, output: Any) -> None:
        thread.message_count += new_message_count
        thread.status = ThreadStatus.paused if isinstance(output, DeferredToolRequests) else ThreadStatus.complete
        thread.last_run_finished_at = datetime.now(UTC)
        await thread.save(update_fields=["message_count", "status", "last_run_finished_at", "updated_at"])

    async def mark_error(self, thread: AgentThread, error: BaseException) -> None:
        thread.status = ThreadStatus.error
        thread.last_error = str(error)
        thread.last_run_finished_at = datetime.now(UTC)
        await thread.save(update_fields=["status", "last_error", "last_run_finished_at", "updated_at"])


class MessageStore:
    async def persist_messages(self, *, thread: AgentThread, messages: list[ModelMessage]) -> None:
        for message in messages:
            await AgentMessage.create(
                organization_id=thread.organization_id,
                thread=thread,
                role=infer_role(message),
                kind=getattr(message, "kind", "unknown"),
                payload=dump_model_message(message),
            )

    async def load_history(self, thread_id: str) -> list[ModelMessage]:
        rows = await AgentMessage.unscoped.filter(thread_id=thread_id).order_by("created_at")
        payload = [row.payload for row in rows]
        return load_model_messages(payload)
