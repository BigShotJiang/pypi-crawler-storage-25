from __future__ import annotations

from typing import Any

from pydantic_ai.messages import ModelMessage

from vanty_ai.persistence.threads import MessageStore, ThreadStore
from vanty_ai.runtime.deps import AgentRuntimeDeps


class ThreadHistoryService:
    def __init__(self, *, thread_store: ThreadStore | None = None, message_store: MessageStore | None = None) -> None:
        self.thread_store = thread_store or ThreadStore()
        self.message_store = message_store or MessageStore()

    async def start_run(self, deps: AgentRuntimeDeps, *, default_title: str) -> None:
        thread = await self.thread_store.ensure_thread(deps, default_title=default_title)
        deps.thread = thread
        deps.thread_id = str(thread.id)
        await self.thread_store.mark_running(thread)

    async def finish_run(
        self,
        deps: AgentRuntimeDeps,
        *,
        messages: list[ModelMessage],
        output: Any,
        default_title: str,
    ) -> None:
        thread = await self.thread_store.ensure_thread(deps, default_title=default_title)
        await self.message_store.persist_messages(thread=thread, messages=messages)
        await self.thread_store.mark_finished(thread, new_message_count=len(messages), output=output)

    async def fail_run(self, deps: AgentRuntimeDeps, *, error: BaseException, default_title: str) -> None:
        thread = await self.thread_store.ensure_thread(deps, default_title=default_title)
        await self.thread_store.mark_error(thread, error)

    async def load_thread_history(self, thread_id: str) -> list[ModelMessage]:
        return await self.message_store.load_history(thread_id)


async def load_thread_history(thread_id: str) -> list[ModelMessage]:
    return await ThreadHistoryService().load_thread_history(thread_id)
