from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Protocol
from uuid import UUID

from pydantic_ai.tools import RunContext, Tool
from tortoise import Tortoise

from vanty_ai.persistence.models import KnowledgeChunk, KnowledgeDocument, KnowledgeSource
from vanty_ai.runtime.deps import AgentRuntimeDeps
from vanty_ai.settings import AISettings


@dataclass(slots=True)
class KnowledgeSearchResult:
    chunk_id: str
    source: str
    score: float
    title: str
    url: str | None
    text: str
    metadata: dict[str, Any] = field(default_factory=dict)


class EmbeddingProvider(Protocol):
    model: str
    dimensions: int

    async def embed(self, texts: list[str]) -> list[list[float]]: ...


class DeterministicEmbeddingProvider:
    """Small provider-safe embedding implementation for tests and local no-key runs."""

    def __init__(self, *, model: str = "deterministic-hash", dimensions: int = 128) -> None:
        self.model = model
        self.dimensions = dimensions

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._embed_one(text) for text in texts]

    def _embed_one(self, text: str) -> list[float]:
        vector = [0.0] * self.dimensions
        tokens = [token.strip(".,!?;:()[]{}\"'").lower() for token in text.split()]
        for token in filter(None, tokens):
            digest = hashlib.sha256(token.encode("utf-8")).digest()
            index = int.from_bytes(digest[:4], "big") % self.dimensions
            vector[index] += 1.0
        return _normalise(vector)


class OpenRouterEmbeddingProvider:
    def __init__(self, *, api_key: str, model: str, dimensions: int) -> None:
        self.api_key = api_key
        self.model = model
        self.dimensions = dimensions

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return await asyncio.to_thread(self._embed_sync, texts)

    def _embed_sync(self, texts: list[str]) -> list[list[float]]:
        request = urllib.request.Request(
            "https://openrouter.ai/api/v1/embeddings",
            data=json.dumps({"model": self.model, "input": texts}).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://vanty.ai",
                "X-Title": "Vanty AI Knowledge Base",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"OpenRouter embeddings request failed ({exc.code}): {detail}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"OpenRouter embeddings request failed: {exc.reason}") from exc

        rows = sorted(payload.get("data", []), key=lambda row: row.get("index", 0))
        vectors = [row.get("embedding") for row in rows]
        if len(vectors) != len(texts) or not all(isinstance(vector, list) for vector in vectors):
            raise RuntimeError("OpenRouter embeddings response did not include all embeddings")
        return [[float(value) for value in vector] for vector in vectors]


class KnowledgeBaseService:
    def __init__(self, embedding_provider: EmbeddingProvider) -> None:
        self.embedding_provider = embedding_provider

    @classmethod
    def from_settings(cls, settings: AISettings) -> KnowledgeBaseService:
        api_key = os.environ.get("OPENROUTER_API_KEY")
        if api_key:
            provider: EmbeddingProvider = OpenRouterEmbeddingProvider(
                api_key=api_key,
                model=settings.embedding_model,
                dimensions=settings.embedding_dimensions,
            )
        else:
            provider = DeterministicEmbeddingProvider(dimensions=settings.embedding_dimensions)
        return cls(provider)

    async def ensure_vector_extension(self) -> None:
        """Enable pgvector-backed storage where supported."""
        conn = Tortoise.get_connection("default")
        if conn.capabilities.dialect != "postgres":
            return
        try:
            await conn.execute_script("CREATE EXTENSION IF NOT EXISTS vector;")
            await conn.execute_script(
                "ALTER TABLE agent_knowledge_chunks "
                f"ADD COLUMN IF NOT EXISTS embedding_vector vector({self.embedding_provider.dimensions});"
            )
            await conn.execute_script(
                "CREATE INDEX IF NOT EXISTS agent_knowledge_chunks_embedding_vector_hnsw "
                "ON agent_knowledge_chunks USING hnsw (embedding_vector vector_cosine_ops);"
            )
        except Exception:
            return

    async def index_document(
        self,
        *,
        organization_id: UUID | str,
        source_name: str,
        source_type: str,
        external_id: str,
        title: str,
        text: str,
        url: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> KnowledgeDocument | None:
        clean_text = " ".join(text.split())
        if not clean_text:
            return None

        source = await KnowledgeSource.unscoped.filter(
            organization_id=organization_id,
            source_type=source_type,
            external_id=external_id,
        ).first()
        if source is None:
            source = await KnowledgeSource.create(
                organization_id=organization_id,
                source_type=source_type,
                external_id=external_id,
                name=source_name,
                url=url,
                metadata=metadata or {},
            )
        source.name = source_name
        source.url = url
        source.metadata = {**(source.metadata or {}), **(metadata or {})}
        await source.save(update_fields=["name", "url", "metadata", "updated_at"])

        content_hash = hashlib.sha256(clean_text.encode("utf-8")).hexdigest()
        document = await KnowledgeDocument.unscoped.filter(
            organization_id=organization_id,
            source=source,
            content_hash=content_hash,
        ).first()
        if document is None:
            await KnowledgeDocument.unscoped.filter(
                organization_id=organization_id,
                source=source,
                title=title,
            ).delete()
            document = await KnowledgeDocument.create(
                organization_id=organization_id,
                source=source,
                title=title,
                url=url,
                content_hash=content_hash,
                metadata=metadata or {},
            )
        else:
            document.title = title
            document.url = url
            document.metadata = {**(document.metadata or {}), **(metadata or {})}
            await document.save(update_fields=["title", "url", "metadata", "updated_at"])
            await KnowledgeChunk.unscoped.filter(document=document).delete()

        chunks = _chunk_text(clean_text)
        embeddings = await self.embedding_provider.embed(chunks)
        for ordinal, (chunk, embedding) in enumerate(zip(chunks, embeddings, strict=True)):
            knowledge_chunk = await KnowledgeChunk.create(
                organization_id=organization_id,
                source=source,
                document=document,
                ordinal=ordinal,
                text=chunk,
                embedding=embedding,
                embedding_model=self.embedding_provider.model,
                metadata=metadata or {},
            )
            await self._store_native_vector(knowledge_chunk.id, embedding)
        return document

    async def search(
        self,
        *,
        organization_id: UUID | str,
        query: str,
        limit: int = 5,
    ) -> list[KnowledgeSearchResult]:
        clean_query = query.strip()
        if not clean_query:
            return []
        query_vector = (await self.embedding_provider.embed([clean_query]))[0]
        native_results = await self._search_native_vectors(
            organization_id=organization_id,
            query_vector=query_vector,
            limit=limit,
        )
        if native_results:
            return native_results
        chunks = await KnowledgeChunk.unscoped.filter(
            organization_id=organization_id,
            embedding_model=self.embedding_provider.model,
        )
        documents = {
            str(document.id): document
            for document in await KnowledgeDocument.unscoped.filter(
                id__in=[chunk.document_id for chunk in chunks]
            )
        }
        sources = {
            str(source.id): source
            for source in await KnowledgeSource.unscoped.filter(
                id__in=[chunk.source_id for chunk in chunks]
            )
        }
        ranked: list[KnowledgeSearchResult] = []
        for chunk in chunks:
            document = documents.get(str(chunk.document_id))
            source = sources.get(str(chunk.source_id))
            if document is None or source is None:
                continue
            score = _cosine(query_vector, [float(value) for value in chunk.embedding or []])
            ranked.append(
                KnowledgeSearchResult(
                    chunk_id=str(chunk.id),
                    source=source.name,
                    score=score,
                    title=document.title,
                    url=document.url or source.url,
                    text=chunk.text,
                    metadata=chunk.metadata or {},
                )
            )
        ranked.sort(key=lambda item: item.score, reverse=True)
        return ranked[:limit]

    def as_tool(self) -> Tool[AgentRuntimeDeps]:
        async def search_knowledge_base(ctx: RunContext[AgentRuntimeDeps], query: str) -> list[dict[str, Any]]:
            """Search the organization's product/support knowledge base for relevant facts."""
            if not ctx.deps.metadata.get("knowledge_enabled", True):
                return [{"source": "knowledge", "text": "Knowledge base search is disabled for this conversation."}]
            organization_id = ctx.deps.organization_ref()
            if organization_id is None:
                return [{"source": "knowledge", "text": "Knowledge base search requires an organization."}]
            results = await self.search(organization_id=organization_id, query=query, limit=5)
            return [
                {
                    "chunk_id": result.chunk_id,
                    "source": result.source,
                    "score": round(result.score, 4),
                    "title": result.title,
                    "url": result.url,
                    "text": result.text,
                }
                for result in results
            ]

        return Tool(search_knowledge_base, takes_ctx=True, name="search_knowledge_base")

    async def _store_native_vector(self, chunk_id: UUID | str, embedding: list[float]) -> None:
        conn = Tortoise.get_connection("default")
        if conn.capabilities.dialect != "postgres":
            return
        try:
            await conn.execute_query(
                "UPDATE agent_knowledge_chunks "
                "SET embedding_vector = $1::vector "
                "WHERE id = $2::uuid",
                [_vector_literal(embedding), str(chunk_id)],
            )
        except Exception:
            return

    async def _search_native_vectors(
        self,
        *,
        organization_id: UUID | str,
        query_vector: list[float],
        limit: int,
    ) -> list[KnowledgeSearchResult]:
        conn = Tortoise.get_connection("default")
        if conn.capabilities.dialect != "postgres":
            return []
        try:
            rows = await conn.execute_query_dict(
                """
                SELECT
                    c.id::text AS chunk_id,
                    s.name AS source,
                    1 - (c.embedding_vector <=> $3::vector) AS score,
                    d.title AS title,
                    COALESCE(d.url, s.url) AS url,
                    c.text AS text,
                    c.metadata AS metadata
                FROM agent_knowledge_chunks c
                JOIN agent_knowledge_documents d ON d.id = c.document_id
                JOIN agent_knowledge_sources s ON s.id = c.source_id
                WHERE c.organization_id = $1::uuid
                  AND c.embedding_model = $2
                  AND c.embedding_vector IS NOT NULL
                ORDER BY c.embedding_vector <=> $3::vector
                LIMIT $4
                """,
                [
                    str(organization_id),
                    self.embedding_provider.model,
                    _vector_literal(query_vector),
                    limit,
                ],
            )
        except Exception:
            return []
        return [
            KnowledgeSearchResult(
                chunk_id=str(row["chunk_id"]),
                source=str(row["source"]),
                score=float(row["score"] or 0),
                title=str(row["title"]),
                url=str(row["url"]) if row.get("url") else None,
                text=str(row["text"]),
                metadata=row.get("metadata") if isinstance(row.get("metadata"), dict) else {},
            )
            for row in rows
        ]


def _chunk_text(text: str, *, max_chars: int = 1200, overlap: int = 160) -> list[str]:
    if len(text) <= max_chars:
        return [text]
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + max_chars)
        chunks.append(text[start:end].strip())
        if end == len(text):
            break
        start = max(0, end - overlap)
    return [chunk for chunk in chunks if chunk]


def _normalise(vector: list[float]) -> list[float]:
    norm = math.sqrt(sum(value * value for value in vector))
    if norm == 0:
        return vector
    return [value / norm for value in vector]


def _cosine(left: list[float], right: list[float]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    if left_norm == 0 or right_norm == 0:
        return 0.0
    return sum(a * b for a, b in zip(left, right, strict=True)) / (left_norm * right_norm)


def _vector_literal(vector: list[float]) -> str:
    return "[" + ",".join(f"{value:.12g}" for value in vector) + "]"
