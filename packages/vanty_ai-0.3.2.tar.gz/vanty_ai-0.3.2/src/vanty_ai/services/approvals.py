from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, cast

from pydantic_ai.tools import DeferredToolRequests, DeferredToolResults, ToolApproved, ToolDenied

from vanty_ai.persistence.approvals import ApprovalRequestStore
from vanty_ai.persistence.models import AgentApprovalRequest, ApprovalStatus


@dataclass(slots=True)
class ApprovalNotificationEvent:
    organization_id: str | None
    thread_id: str | None
    request_ids: list[str]
    approvals: list[dict[str, Any]]


class ApprovalNotificationSink(Protocol):
    async def publish(self, event: ApprovalNotificationEvent) -> None: ...


class LoggerApprovalSink:
    def __init__(self, logger_name: str = "vanty_ai.approvals") -> None:
        import logging

        self.logger = logging.getLogger(logger_name)

    async def publish(self, event: ApprovalNotificationEvent) -> None:
        self.logger.info(
            "approval.requests.created",
            extra={
                "organization_id": event.organization_id,
                "thread_id": event.thread_id,
                "request_ids": event.request_ids,
                "approvals": event.approvals,
            },
        )


def approval_requests_from_deferred(output: DeferredToolRequests) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for call in output.approvals:
        metadata = output.metadata.get(call.tool_call_id or "", {}) if output.metadata else {}
        out.append(
            {
                "run_id": getattr(call, "run_id", None),
                "tool_call_id": call.tool_call_id,
                "tool_name": call.tool_name,
                "args": call.args_as_dict(),
                "metadata": metadata,
            }
        )
    return out


async def persist_approval_requests(
    *,
    output: DeferredToolRequests,
    organization_id: str,
    thread_id: str,
    actor_user_id: str | None,
) -> list[AgentApprovalRequest]:
    approvals = approval_requests_from_deferred(output)
    return await ApprovalRequestStore().persist_deferred_requests(
        approvals=approvals,
        organization_id=organization_id,
        thread_id=thread_id,
        actor_user_id=actor_user_id,
    )


async def list_pending_approval_requests(*, thread_id: str) -> list[AgentApprovalRequest]:
    return await ApprovalRequestStore().list_pending(thread_id=thread_id)


async def apply_approval_decision(
    request: AgentApprovalRequest,
    *,
    approved: bool,
    reviewed_by_user_id: str | None = None,
    override_args: dict[str, Any] | None = None,
    reason: str | None = None,
) -> AgentApprovalRequest:
    return await ApprovalRequestStore().apply_decision(
        request,
        approved=approved,
        reviewed_by_user_id=reviewed_by_user_id,
        override_args=override_args,
        reason=reason,
    )


async def approval_requests_to_deferred_results(
    requests: list[AgentApprovalRequest],
) -> DeferredToolResults:
    results = DeferredToolResults()
    for request in requests:
        if request.status == ApprovalStatus.pending:
            raise ValueError(f"Approval request {request.id} is still pending")
        if request.status == ApprovalStatus.approved:
            results.approvals[request.tool_call_id] = ToolApproved(
                override_args=cast(dict[str, Any] | None, request.override_args),
            )
            continue
        results.approvals[request.tool_call_id] = ToolDenied(
            message=request.reason or "The tool call was denied.",
        )
    return results
