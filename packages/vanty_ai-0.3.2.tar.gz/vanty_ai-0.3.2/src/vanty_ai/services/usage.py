from __future__ import annotations

from collections.abc import Iterable

from vanty_ai.persistence.usage import UsageEventStore
from vanty_ai.runtime.usage import UsageEvent, UsageEventRecorder, UsageRecordContext


class TortoiseUsageRecorder(UsageEventRecorder):
    def __init__(self, store: UsageEventStore | None = None) -> None:
        self.store = store or UsageEventStore()

    async def record(self, event: UsageEvent, context: UsageRecordContext) -> None:
        await self.store.record(event, context)


class CompositeUsageRecorder(UsageEventRecorder):
    def __init__(self, recorders: Iterable[UsageEventRecorder]) -> None:
        self.recorders = [recorder for recorder in recorders]

    async def record(self, event: UsageEvent, context: UsageRecordContext) -> None:
        for recorder in self.recorders:
            await recorder.record(event, context)
