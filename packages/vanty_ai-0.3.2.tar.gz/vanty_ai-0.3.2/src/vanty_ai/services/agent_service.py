"""Agent runner used by the vanty-ai HTTP router.

This service owns a configured `pydantic_ai.Agent` instance plus the default
capability stack. It exposes:

- `run(prompt, deps)` — single shot, returns final output and persisted history
- `stream_events(prompt, deps)` — yields pydantic-ai `AgentStreamEvent`s for SSE
- `configure()` — describes the active model + toolset to the frontend

A single `AgentService` instance is shared across requests; per-request state
flows through `AgentRuntimeDeps`.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator, Callable, Iterable
from dataclasses import dataclass, field
from typing import Any

from pydantic_ai import Agent
from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.messages import AgentStreamEvent, ModelMessage
from pydantic_ai.models.test import TestModel
from pydantic_ai.tools import Tool

from vanty_ai.capabilities.factory import build_default_capabilities
from vanty_ai.runtime.default_toolsets import DEFAULT_TOOLS
from vanty_ai.runtime.deps import AgentRuntimeDeps
from vanty_ai.services.history import ThreadHistoryService
from vanty_ai.services.knowledge import KnowledgeBaseService
from vanty_ai.settings import AISettings

ModelFactory = Callable[[], Any]

DEFAULT_ANTHROPIC_MODEL = "anthropic:claude-3-5-haiku-latest"
DEFAULT_OPENROUTER_MODEL = "openrouter:z-ai/glm-5.1"
DEFAULT_OPENAI_MODEL = "openai:gpt-4o-mini"


def resolve_default_model(env: os._Environ[str] | dict[str, str] | None = None) -> str | TestModel:
    """Resolve the default model without requiring app-level service wiring."""
    values = env or os.environ
    if values.get("AI_MODEL"):
        return values["AI_MODEL"]
    if values.get("ANTHROPIC_API_KEY"):
        return DEFAULT_ANTHROPIC_MODEL
    if values.get("OPENROUTER_API_KEY"):
        return DEFAULT_OPENROUTER_MODEL
    if values.get("OPENAI_API_KEY"):
        return DEFAULT_OPENAI_MODEL
    return TestModel()


def _default_model_factory() -> Any:
    """Pick a sensible default model for the current environment.

    `AI_MODEL` can be any Pydantic AI model string. Without it, provider API
    keys select production-ready defaults while offline development still uses
    `TestModel`.
    """
    return resolve_default_model()


@dataclass
class AgentService:
    model_factory: ModelFactory = _default_model_factory
    instructions: str = (
        "You are Aurora support, a concise customer-facing support agent for "
        "the Aurora product. You are not a general-purpose assistant. If asked "
        "what you can do, describe only Aurora customer-support help: product "
        "questions, setup, billing, troubleshooting, and handoff to the team. "
        "Ask one concise customer-support question when the user's request is "
        "ambiguous or missing account/product context. "
        "Search the knowledge base before answering product, billing, setup, "
        "or policy questions. Cite the relevant source title when knowledge is "
        "returned. Do not use emoji, emoticons, decorative symbols, hype, "
        "generic assistant capability lists, or casual filler. "
        "Keep responses practical, calm, and customer-facing. If you cannot "
        "find enough context, say that clearly instead of guessing."
    )
    tools: list[Callable[..., Any]] = field(default_factory=lambda: list(DEFAULT_TOOLS))
    extra_capabilities: list[AbstractCapability[AgentRuntimeDeps]] = field(default_factory=list)
    history_service: ThreadHistoryService = field(default_factory=ThreadHistoryService)
    knowledge_service: KnowledgeBaseService = field(
        default_factory=lambda: KnowledgeBaseService.from_settings(AISettings())
    )

    def build_agent(self) -> Agent[AgentRuntimeDeps, str]:
        tools: list[Callable[..., Any] | Tool[AgentRuntimeDeps]] = [
            *self.tools,
            self.knowledge_service.as_tool(),
        ]
        return Agent(
            self.model_factory(),
            deps_type=AgentRuntimeDeps,
            instructions=self.instructions,
            tools=tools,
            capabilities=build_default_capabilities(extra_capabilities=self.extra_capabilities),
        )

    async def run(
        self,
        *,
        prompt: str,
        deps: AgentRuntimeDeps,
        message_history: Iterable[ModelMessage] | None = None,
    ) -> Any:
        agent = self.build_agent()
        history = list(message_history or await self._load_history(deps))
        result = await agent.run(prompt, deps=deps, message_history=history)
        return result

    async def stream_events(
        self,
        *,
        prompt: str,
        deps: AgentRuntimeDeps,
        message_history: Iterable[ModelMessage] | None = None,
    ) -> AsyncIterator[AgentStreamEvent | Any]:
        agent = self.build_agent()
        history = list(message_history or await self._load_history(deps))
        async for event in agent.run_stream_events(prompt, deps=deps, message_history=history):
            yield event

    async def configure(self) -> dict[str, Any]:
        agent = self.build_agent()
        model = agent.model
        model_name = getattr(model, "model_name", None) or getattr(model, "_model_name", None) or str(model)
        capabilities = build_default_capabilities(extra_capabilities=self.extra_capabilities)
        return {
            "model_name": str(model_name),
            "available_tools": [getattr(tool, "__name__", str(tool)) for tool in self.tools],
            "capabilities": [type(cap).__name__ for cap in capabilities],
        }

    async def _load_history(self, deps: AgentRuntimeDeps) -> list[ModelMessage]:
        if deps.thread_id is None:
            return []
        try:
            return await self.history_service.load_thread_history(deps.thread_id)
        except Exception:
            return []
