"""``AIApp`` — vanty-ai's AppConfig.

Composition root and registration entry. Wires the agent service and
default capability factory, then exposes the metadata that
``AppRegistry`` needs to mount the chat router and aggregate models.
"""

from __future__ import annotations

from fastapi import APIRouter
from vanty_core.apps import AppConfig

from vanty_ai.capabilities.factory import build_default_capabilities
from vanty_ai.fastapi.routes import router as ai_router
from vanty_ai.services.agent_service import AgentService
from vanty_ai.services.knowledge import KnowledgeBaseService
from vanty_ai.settings import AISettings


class AIApp(AppConfig):
    """vanty-ai AppConfig: agent runtime, threads, usage metering, tool approvals."""

    name = "vanty_ai"
    label = "ai"
    version = "0.3.0"
    depends_on = ()
    models_module = "vanty_ai.persistence.models"
    router_attr = "vanty_ai.fastapi.routes:router"
    events_module = "vanty_ai.events"

    def __init__(
        self,
        settings: AISettings | None = None,
        *,
        agent_service: AgentService | None = None,
    ) -> None:
        super().__init__(settings=settings or AISettings())
        self.knowledge_service = KnowledgeBaseService.from_settings(self.settings)
        self.agent_service = agent_service or AgentService(knowledge_service=self.knowledge_service)
        self.router: APIRouter = ai_router

    def default_capabilities(self, **kwargs):
        return build_default_capabilities(**kwargs)

    async def on_startup(self, registry) -> None:
        await self.knowledge_service.ensure_vector_extension()
