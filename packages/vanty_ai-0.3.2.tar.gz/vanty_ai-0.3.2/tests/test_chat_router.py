"""Integration tests for the vanty-ai chat HTTP router.

The router runs a real `Agent` with a `TestModel` so we exercise the full
pydantic-ai 1.84 capability stack end-to-end.

Note: we use ``httpx.AsyncClient`` over ``ASGITransport`` instead of
FastAPI's ``TestClient``. ``TestClient`` spawns a fresh event loop per
request, which would force Tortoise to reconnect on every foreign loop and
orphan ``aiosqlite`` worker threads — those non-daemon threads then block
process exit. Sharing a single loop with the lifespan keeps the connection
(and its worker thread) tied to that loop and cleaned up on shutdown.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path
from uuid import uuid4

import httpx
import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import ASGITransport
from pydantic_ai.models.test import TestModel
from vanty_core.apps import AppRegistry

from vanty_ai.apps import AIApp
from vanty_ai.persistence.models import AgentApprovalRequest, AgentMessage, AgentThread, ApprovalStatus
from vanty_ai.services.agent_service import AgentService
from vanty_ai.settings import AISettings


@pytest_asyncio.fixture
async def app(tmp_path: Path) -> AsyncIterator[FastAPI]:
    settings = AISettings()
    agent_service = AgentService(model_factory=lambda: TestModel())
    registry = AppRegistry(database_url=f"sqlite://{tmp_path / 'vanty-ai.db'}")
    registry.install(AIApp(settings=settings, agent_service=agent_service))
    fastapi_app = FastAPI()
    registry.mount(fastapi_app)
    async with registry.lifespan(fastapi_app):
        yield fastapi_app


@pytest_asyncio.fixture
async def client(app: FastAPI) -> AsyncIterator[httpx.AsyncClient]:
    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


@pytest.fixture
def org_id() -> str:
    return str(uuid4())


@pytest.fixture
def headers(org_id: str) -> dict[str, str]:
    return {"X-Organization-ID": org_id, "X-Actor-User-ID": str(uuid4())}


pytestmark = pytest.mark.asyncio


async def test_configure_returns_active_model_and_capabilities(
    client: httpx.AsyncClient, headers: dict[str, str]
) -> None:
    response = await client.get("/ai/chat/configure", headers=headers)
    assert response.status_code == 200
    body = response.json()
    assert "model_name" in body
    assert isinstance(body["available_tools"], list)
    assert isinstance(body["capabilities"], list)
    assert any("Hooks" in cap or "ThreadCapability" in cap for cap in body["capabilities"])


async def test_create_get_list_thread(
    client: httpx.AsyncClient, org_id: str, headers: dict[str, str]
) -> None:
    create = await client.post("/ai/chat/threads", json={"title": "Demo"}, headers=headers)
    assert create.status_code == 201, create.text
    thread = create.json()
    assert thread["title"] == "Demo"
    assert thread["organization_id"] == org_id

    got = await client.get(f"/ai/chat/threads/{thread['id']}", headers=headers)
    assert got.status_code == 200
    assert got.json()["id"] == thread["id"]

    listing = await client.get("/ai/chat/threads", headers=headers)
    assert listing.status_code == 200
    body = listing.json()
    assert body["total"] >= 1
    assert any(item["id"] == thread["id"] for item in body["items"])


async def test_unauthenticated_requests_are_rejected(client: httpx.AsyncClient) -> None:
    response = await client.get("/ai/chat/threads")
    assert response.status_code == 401


async def test_other_org_cannot_read_thread(
    client: httpx.AsyncClient, headers: dict[str, str]
) -> None:
    create = await client.post("/ai/chat/threads", json={"title": "Demo"}, headers=headers)
    assert create.status_code == 201
    thread_id = create.json()["id"]

    other_headers = {"X-Organization-ID": str(uuid4())}
    leaked = await client.get(f"/ai/chat/threads/{thread_id}", headers=other_headers)
    assert leaked.status_code == 404


async def test_post_message_runs_agent_and_persists_history(
    client: httpx.AsyncClient, headers: dict[str, str]
) -> None:
    thread = (await client.post("/ai/chat/threads", json={"title": "Demo"}, headers=headers)).json()
    response = await client.post(
        f"/ai/chat/threads/{thread['id']}/messages",
        json={"content": "Hello"},
        headers=headers,
    )
    assert response.status_code == 201, response.text
    body = response.json()
    assert body["total"] >= 1
    roles = {msg["role"] for msg in body["items"]}
    assert {"user", "assistant"}.issubset(roles)


async def test_stream_endpoint_yields_sse_frames(
    client: httpx.AsyncClient, headers: dict[str, str]
) -> None:
    thread = (await client.post("/ai/chat/threads", json={"title": "Demo"}, headers=headers)).json()
    async with client.stream(
        "POST",
        "/ai/chat/stream",
        json={"thread_id": thread["id"], "prompt": "Hello"},
        headers=headers,
    ) as response:
        assert response.status_code == 200
        chunks = [chunk async for chunk in response.aiter_bytes()]
        text = b"".join(chunks).decode()
    assert "event: thread" in text
    assert "event: done" in text


async def test_resumable_stream_replays_history(
    client: httpx.AsyncClient, headers: dict[str, str]
) -> None:
    thread = (await client.post("/ai/chat/threads", json={"title": "Demo"}, headers=headers)).json()
    await client.post(
        f"/ai/chat/threads/{thread['id']}/messages",
        json={"content": "Hello"},
        headers=headers,
    )
    async with client.stream(
        "GET",
        f"/ai/chat/threads/{thread['id']}/stream",
        headers=headers,
    ) as response:
        assert response.status_code == 200
        chunks = [chunk async for chunk in response.aiter_bytes()]
        text = b"".join(chunks).decode()
    assert text.count("event: message") >= 1
    assert "event: done" in text


async def test_update_and_delete_thread(
    client: httpx.AsyncClient, headers: dict[str, str]
) -> None:
    thread = (await client.post("/ai/chat/threads", json={"title": "Demo"}, headers=headers)).json()
    renamed = await client.patch(
        f"/ai/chat/threads/{thread['id']}",
        json={"title": "Renamed", "metadata": {"pinned": True}},
        headers=headers,
    )
    assert renamed.status_code == 200
    assert renamed.json()["title"] == "Renamed"
    assert renamed.json()["metadata"]["pinned"] is True

    deleted = await client.delete(f"/ai/chat/threads/{thread['id']}", headers=headers)
    assert deleted.status_code == 204

    gone = await client.get(f"/ai/chat/threads/{thread['id']}", headers=headers)
    assert gone.status_code == 404


async def test_notifications_list_and_process(
    client: httpx.AsyncClient, headers: dict[str, str], org_id: str
) -> None:
    thread = await AgentThread.create(organization_id=org_id, title="approvals")
    request = await AgentApprovalRequest.create(
        organization_id=org_id,
        thread=thread,
        tool_call_id=f"call-{uuid4()}",
        tool_name="dangerous_tool",
        args={"foo": "bar"},
    )

    listing = await client.get(f"/ai/chat/threads/{thread.id}/notifications", headers=headers)
    assert listing.status_code == 200
    items = listing.json()["items"]
    assert len(items) == 1

    decision = await client.post(
        "/ai/chat/notifications/process",
        json={
            "request_id": str(request.id),
            "decision": ApprovalStatus.approved.value,
            "override_args": {"foo": "approved"},
            "reason": "looks fine",
        },
        headers=headers,
    )
    assert decision.status_code == 200, decision.text
    assert decision.json()["status"] == ApprovalStatus.approved.value
    assert decision.json()["override_args"] == {"foo": "approved"}


async def test_messages_listing_after_run(
    client: httpx.AsyncClient, headers: dict[str, str], org_id: str
) -> None:
    thread = await AgentThread.create(organization_id=org_id, title="messages")
    await AgentMessage.create(
        organization_id=org_id,
        thread=thread,
        role="user",
        kind="request",
        payload={"text": "hi"},
    )

    response = await client.get(f"/ai/chat/threads/{thread.id}/messages", headers=headers)
    assert response.status_code == 200
    assert response.json()["total"] == 1
    assert response.json()["items"][0]["payload"] == {"text": "hi"}
