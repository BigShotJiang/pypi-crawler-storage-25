from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path
from uuid import uuid4

import httpx
import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import ASGITransport
from pydantic_ai.models.test import TestModel
from vanty_core.apps import AppRegistry

from vanty_ai.apps import AIApp
from vanty_ai.persistence.models import AgentMessage, AgentThread, EmbeddedAgentConfig
from vanty_ai.services.agent_service import AgentService
from vanty_ai.settings import AISettings


@pytest_asyncio.fixture
async def app(tmp_path: Path) -> AsyncIterator[FastAPI]:
    settings = AISettings(embedded_token_secret="test-secret", embedded_token_ttl_seconds=3600)
    agent_service = AgentService(model_factory=lambda: TestModel())
    registry = AppRegistry(database_url=f"sqlite://{tmp_path / 'vanty-ai-embed.db'}")
    registry.install(AIApp(settings=settings, agent_service=agent_service))
    fastapi_app = FastAPI()
    registry.mount(fastapi_app)
    async with registry.lifespan(fastapi_app):
        yield fastapi_app


@pytest_asyncio.fixture
async def client(app: FastAPI) -> AsyncIterator[httpx.AsyncClient]:
    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


pytestmark = pytest.mark.asyncio


async def test_embedded_session_grants_token_and_restores_me(client: httpx.AsyncClient) -> None:
    org_id = str(uuid4())

    created = await client.post(
        "/ai/embed/sessions",
        json={
            "organization_id": org_id,
            "origin": "https://demo.example",
            "customer_id": "cus_123",
            "visitor": {"email": "customer@example.com"},
        },
    )

    assert created.status_code == 201, created.text
    grant = created.json()
    assert grant["token"]
    assert grant["session"]["organization_id"] == org_id
    assert grant["session"]["customer_id"] == "cus_123"
    assert grant["config"]["capabilities"]["threads"] is True

    me = await client.get(
        "/ai/embed/sessions/me",
        headers={"Authorization": f"Bearer {grant['token']}", "Origin": "https://demo.example"},
    )
    assert me.status_code == 200, me.text
    assert me.json()["session"]["id"] == grant["session"]["id"]


async def test_embedded_threads_and_messages_are_session_scoped(client: httpx.AsyncClient) -> None:
    first = await _grant(client, customer_id="first")
    second = await _grant(client, customer_id="second")

    created = await client.post(
        "/ai/embed/threads",
        json={"title": "Support request"},
        headers=_auth(first["token"]),
    )
    assert created.status_code == 201, created.text
    thread = created.json()
    assert thread["channel"] == "embedded_support"
    assert thread["metadata"]["embedded_session_id"] == first["session"]["id"]

    first_threads = await client.get("/ai/embed/threads", headers=_auth(first["token"]))
    assert first_threads.status_code == 200
    assert first_threads.json()["total"] == 1

    second_threads = await client.get("/ai/embed/threads", headers=_auth(second["token"]))
    assert second_threads.status_code == 200
    assert second_threads.json()["total"] == 0

    blocked = await client.get(f"/ai/embed/threads/{thread['id']}/messages", headers=_auth(second["token"]))
    assert blocked.status_code == 404

    response = await client.post(
        f"/ai/embed/threads/{thread['id']}/messages",
        json={
            "content": "Hello",
            "attachments": [{"id": "file_1", "name": "screenshot.png"}],
        },
        headers=_auth(first["token"]),
    )
    assert response.status_code == 201, response.text
    roles = {item["role"] for item in response.json()["items"]}
    assert {"user", "assistant"}.issubset(roles)

    persisted = await AgentMessage.unscoped.filter(thread_id=thread["id"]).order_by("created_at")
    assert len(persisted) >= 2


async def test_embedded_origin_restrictions_are_enforced(client: httpx.AsyncClient) -> None:
    org_id = uuid4()
    config = await EmbeddedAgentConfig.create(
        organization_id=org_id,
        name="Locked widget",
        allowed_origins=["https://allowed.example"],
    )

    denied = await client.post(
        "/ai/embed/sessions",
        json={
            "organization_id": str(org_id),
            "config_id": str(config.id),
            "origin": "https://blocked.example",
        },
    )
    assert denied.status_code == 403

    allowed = await client.post(
        "/ai/embed/sessions",
        json={
            "organization_id": str(org_id),
            "config_id": str(config.id),
            "origin": "https://allowed.example",
        },
    )
    assert allowed.status_code == 201


async def test_embedded_file_registration_returns_session_scoped_reference(client: httpx.AsyncClient) -> None:
    grant = await _grant(client, customer_id="files")

    response = await client.post(
        "/ai/embed/files",
        json={"name": "invoice.pdf", "content_type": "application/pdf", "size": 1234},
        headers=_auth(grant["token"]),
    )

    assert response.status_code == 201, response.text
    body = response.json()
    assert body["id"].startswith(f"embed-file:{grant['session']['id']}:")
    assert body["metadata"]["session_id"] == grant["session"]["id"]


async def test_regular_chat_router_still_mounts(client: httpx.AsyncClient) -> None:
    headers = {"X-Organization-ID": str(uuid4()), "X-Actor-User-ID": str(uuid4())}
    response = await client.post("/ai/chat/threads", json={"title": "Normal"}, headers=headers)
    assert response.status_code == 201, response.text
    assert await AgentThread.unscoped.filter(id=response.json()["id"]).exists()


async def _grant(client: httpx.AsyncClient, *, customer_id: str) -> dict:
    response = await client.post(
        "/ai/embed/sessions",
        json={
            "organization_id": str(uuid4()),
            "origin": "https://demo.example",
            "customer_id": customer_id,
        },
    )
    assert response.status_code == 201, response.text
    return response.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}", "Origin": "https://demo.example"}
