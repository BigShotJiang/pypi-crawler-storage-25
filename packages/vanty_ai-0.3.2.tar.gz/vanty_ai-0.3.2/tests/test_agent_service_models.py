from pydantic_ai.models.test import TestModel

from vanty_ai.services.agent_service import resolve_default_model


def test_explicit_ai_model_wins() -> None:
    assert resolve_default_model({"AI_MODEL": "anthropic:custom-model", "OPENAI_API_KEY": "sk-test"}) == (
        "anthropic:custom-model"
    )


def test_provider_keys_select_production_defaults() -> None:
    assert resolve_default_model({"ANTHROPIC_API_KEY": "sk-ant-test"}) == "anthropic:claude-3-5-haiku-latest"
    assert resolve_default_model({"OPENROUTER_API_KEY": "sk-or-test"}) == "openrouter:z-ai/glm-5.1"
    assert resolve_default_model({"OPENAI_API_KEY": "sk-test"}) == "openai:gpt-4o-mini"


def test_missing_provider_keys_uses_test_model() -> None:
    assert isinstance(resolve_default_model({}), TestModel)
