from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path
from uuid import uuid4

import httpx
import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import ASGITransport
from pydantic_ai.models.test import TestModel
from vanty_core.apps import AppRegistry

from vanty_ai.apps import AIApp
from vanty_ai.services.agent_service import AgentService
from vanty_ai.services.knowledge import DeterministicEmbeddingProvider, KnowledgeBaseService
from vanty_ai.settings import AISettings


@pytest_asyncio.fixture
async def app(tmp_path: Path) -> AsyncIterator[FastAPI]:
    service = KnowledgeBaseService(DeterministicEmbeddingProvider(dimensions=64))
    agent_service = AgentService(model_factory=lambda: TestModel(), knowledge_service=service)
    registry = AppRegistry(database_url=f"sqlite://{tmp_path / 'kb.db'}")
    registry.install(AIApp(settings=AISettings(), agent_service=agent_service))
    fastapi_app = FastAPI()
    registry.mount(fastapi_app)
    async with registry.lifespan(fastapi_app):
        yield fastapi_app


@pytest_asyncio.fixture
async def client(app: FastAPI) -> AsyncIterator[httpx.AsyncClient]:
    async with httpx.AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


pytestmark = pytest.mark.asyncio


async def test_knowledge_index_and_search_are_org_scoped(client: httpx.AsyncClient) -> None:
    org_id = str(uuid4())
    other_org_id = str(uuid4())
    headers = {"X-Organization-ID": org_id}

    created = await client.post(
        "/ai/chat/knowledge/index",
        headers=headers,
        json={
            "source_name": "Help Center",
            "source_type": "content_page",
            "external_id": "billing",
            "title": "Billing setup",
            "text": "Aurora billing connects Stripe subscriptions and invoices to support answers.",
        },
    )
    assert created.status_code == 201, created.text
    assert created.json()["document_id"]

    found = await client.post(
        "/ai/chat/knowledge/search",
        headers=headers,
        json={"query": "How does Stripe billing work?"},
    )
    assert found.status_code == 200, found.text
    assert found.json()["total"] >= 1
    assert "Stripe" in found.json()["items"][0]["text"]

    isolated = await client.post(
        "/ai/chat/knowledge/search",
        headers={"X-Organization-ID": other_org_id},
        json={"query": "Stripe billing"},
    )
    assert isolated.status_code == 200
    assert isolated.json()["total"] == 0


async def test_embedded_default_config_enables_knowledge(client: httpx.AsyncClient) -> None:
    response = await client.post(
        "/ai/embed/sessions",
        json={"organization_id": str(uuid4()), "origin": "https://demo.example"},
    )
    assert response.status_code == 201, response.text
    assert response.json()["config"]["capabilities"]["knowledge"] is True
