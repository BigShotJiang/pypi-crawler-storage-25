from __future__ import annotations

from uuid import uuid4

import pytest
from pydantic_ai import Agent
from pydantic_ai.models.test import TestModel

from vanty_ai import AgentRuntimeDeps, ThreadCapability
from vanty_ai.persistence.models import AgentThread, ThreadStatus
from vanty_ai.services.history import load_thread_history


@pytest.mark.integration
async def test_thread_capability_persists_messages_and_status(ai_app):
    del ai_app
    deps = AgentRuntimeDeps(
        organization_id=uuid4(),
        actor_user_id=uuid4(),
        thread_title="Customer support",
        channel="web",
    )
    agent = Agent(model=TestModel(custom_output_text="Hello back"), capabilities=[ThreadCapability()])

    result = await agent.run("Hello", deps=deps)

    assert result.output == "Hello back"
    assert deps.thread_id is not None

    thread = await AgentThread.unscoped.get(id=deps.thread_id)
    assert thread.title == "Customer support"
    assert thread.status == ThreadStatus.complete
    assert thread.message_count == 2

    history = await load_thread_history(deps.thread_id)
    assert len(history) == 2
    assert history[0].kind == "request"
    assert history[1].kind == "response"
