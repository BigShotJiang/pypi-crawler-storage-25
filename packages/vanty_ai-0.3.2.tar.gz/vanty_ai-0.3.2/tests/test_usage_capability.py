from __future__ import annotations

from uuid import uuid4

import pytest
from pydantic_ai import Agent
from pydantic_ai.models.test import TestModel

from vanty_ai import AgentRuntimeDeps, ThreadCapability, UsageMeteringCapability
from vanty_ai.integrations.payments import PaymentsMeterRecorder
from vanty_ai.persistence.models import AgentUsageEvent
from vanty_ai.runtime import UsageEvent, UsageRecordContext
from vanty_ai.services.usage import CompositeUsageRecorder, TortoiseUsageRecorder


class BillingService:
    def __init__(self) -> None:
        self.calls = []

    async def record_usage(self, account, *, event_name, value, dimensions):
        self.calls.append(
            {
                "account": account,
                "event_name": event_name,
                "value": value,
                "dimensions": dimensions,
            }
        )


async def resolve_account(context: UsageRecordContext, event: UsageEvent) -> str:
    assert context.organization_id is not None
    assert event.value > 0
    return f"account:{context.organization_id}"


@pytest.mark.integration
async def test_usage_capability_records_usage_events(ai_app):
    del ai_app
    deps = AgentRuntimeDeps(
        organization_id=uuid4(),
        actor_user_id=uuid4(),
        thread_title="Billing test",
    )
    agent = Agent(
        model=TestModel(custom_output_text="Measured"),
        capabilities=[ThreadCapability(), UsageMeteringCapability()],
    )

    await agent.run("How much did this cost?", deps=deps)

    events = await AgentUsageEvent.unscoped.filter(thread_id=deps.thread_id)
    assert len(events) == 1
    event = events[0]
    assert event.value > 0
    assert event.input_tokens > 0
    assert event.output_tokens > 0
    assert event.event_name == "ai_tokens"


@pytest.mark.integration
async def test_usage_capability_can_persist_and_forward_to_payments(ai_app):
    del ai_app
    billing_service = BillingService()
    deps = AgentRuntimeDeps(
        organization_id=uuid4(),
        actor_user_id=uuid4(),
        thread_title="Composite billing test",
    )
    recorder = CompositeUsageRecorder(
        [
            TortoiseUsageRecorder(),
            PaymentsMeterRecorder(billing_service=billing_service, account_resolver=resolve_account),
        ]
    )
    agent = Agent(
        model=TestModel(custom_output_text="Measured and billed"),
        capabilities=[ThreadCapability(), UsageMeteringCapability(recorder=recorder)],
    )

    await agent.run("Persist and bill this", deps=deps)

    events = await AgentUsageEvent.unscoped.filter(thread_id=deps.thread_id)
    assert len(events) == 1
    assert len(billing_service.calls) == 1
    assert billing_service.calls[0]["event_name"] == "ai_tokens"
    assert billing_service.calls[0]["value"] == events[0].value
    assert billing_service.calls[0]["dimensions"]["thread_id"] == deps.thread_id
    assert billing_service.calls[0]["account"] == f"account:{deps.organization_id}"
