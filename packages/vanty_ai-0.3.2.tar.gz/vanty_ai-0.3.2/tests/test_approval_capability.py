from __future__ import annotations

from uuid import uuid4

import pytest
from pydantic_ai import Agent, Tool
from pydantic_ai.messages import ModelResponse, TextPart, ToolCallPart
from pydantic_ai.models.function import FunctionModel
from pydantic_ai.tools import DeferredToolRequests

from vanty_ai import (
    AgentRuntimeDeps,
    ThreadCapability,
    ToolApprovalCapability,
    apply_approval_decision,
    approval_requests_to_deferred_results,
)
from vanty_ai.persistence.models import AgentApprovalRequest, ApprovalStatus
from vanty_ai.services.history import load_thread_history


class MemorySink:
    def __init__(self) -> None:
        self.events = []

    async def publish(self, event) -> None:
        self.events.append(event)


async def dangerous_tool() -> str:
    return "tool finished"


async def approval_model(messages, agent_info) -> ModelResponse:
    del agent_info
    if not any(isinstance(message, ModelResponse) for message in messages):
        return ModelResponse(
            parts=[ToolCallPart("dangerous_tool", {}, tool_call_id="dangerous-call-1")]
        )
    return ModelResponse(parts=[TextPart("All done")])


@pytest.mark.integration
async def test_approval_capability_persists_requests_and_supports_resume(ai_app):
    del ai_app
    sink = MemorySink()
    deps = AgentRuntimeDeps(
        organization_id=uuid4(),
        actor_user_id=uuid4(),
        thread_title="Ops approval",
        channel="cli",
    )
    agent = Agent(
        model=FunctionModel(function=approval_model),
        tools=[Tool(dangerous_tool)],
        output_type=[str, DeferredToolRequests],
        capabilities=[ThreadCapability(), ToolApprovalCapability(tools={"dangerous_tool"}, notification_sink=sink)],
    )

    first = await agent.run("Run the tool", deps=deps)

    assert isinstance(first.output, DeferredToolRequests)
    assert len(first.output.approvals) == 1
    assert len(sink.events) == 1

    requests = await AgentApprovalRequest.unscoped.filter(thread_id=deps.thread_id).order_by("created_at")
    assert len(requests) == 1
    assert requests[0].status == ApprovalStatus.pending

    await apply_approval_decision(requests[0], approved=True, reviewed_by_user_id=str(uuid4()))
    requests = await AgentApprovalRequest.unscoped.filter(thread_id=deps.thread_id).order_by("created_at")
    deferred = await approval_requests_to_deferred_results(requests)
    history = await load_thread_history(deps.thread_id)

    resumed = await agent.run(None, deps=deps, message_history=history, deferred_tool_results=deferred)

    assert resumed.output == "All done"
    refreshed = await AgentApprovalRequest.unscoped.get(id=requests[0].id)
    assert refreshed.status == ApprovalStatus.approved
