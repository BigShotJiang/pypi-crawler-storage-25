from __future__ import annotations

import vanty_ai

EXPECTED_PUBLIC_API = {
    "AIApp",
    "AISettings",
    "AgentRuntimeDeps",
    "AgentService",
    "KnowledgeBaseCapability",
    "KnowledgeBaseService",
    "LoggingCapability",
    "ThreadCapability",
    "ToolApprovalCapability",
    "UsageMeteringCapability",
    "apply_approval_decision",
    "approval_requests_to_deferred_results",
    "build_default_capabilities",
    "events",
}


def test_root_public_api_is_intentional():
    assert set(vanty_ai.__all__) == EXPECTED_PUBLIC_API
    for name in EXPECTED_PUBLIC_API:
        assert hasattr(vanty_ai, name)

    for internal_name in {
        "AgentApprovalRequest",
        "AgentMessage",
        "AgentThread",
        "AgentUsageEvent",
        "ApprovalStatus",
        "ThreadStatus",
        "TortoiseUsageRecorder",
        "UsageEvent",
        "UsageEventRecorder",
        "compute_response_costs",
        "load_thread_history",
    }:
        assert not hasattr(vanty_ai, internal_name)


async def test_payments_recorder_uses_explicit_usage_context():
    from uuid import uuid4

    from vanty_ai.integrations.payments import PaymentsMeterRecorder
    from vanty_ai.runtime import AgentRuntimeDeps, UsageEvent, UsageRecordContext

    class BillingService:
        def __init__(self) -> None:
            self.calls = []

        async def record_usage(self, account, *, event_name, value, dimensions):
            self.calls.append(
                {
                    "account": account,
                    "event_name": event_name,
                    "value": value,
                    "dimensions": dimensions,
                }
            )

    async def resolve_account(context: UsageRecordContext, event: UsageEvent) -> str:
        assert context.organization_id == "org-1"
        assert event.value == 42
        return "acct-1"

    billing_service = BillingService()
    recorder = PaymentsMeterRecorder(billing_service=billing_service, account_resolver=resolve_account)
    context = UsageRecordContext(
        deps=AgentRuntimeDeps(organization_id="org-1", actor_user_id=uuid4(), thread_id="thread-1"),
        organization_id="org-1",
        thread_id="thread-1",
    )

    await recorder.record(UsageEvent(value=42, dimensions={"model_name": "test"}), context)

    assert billing_service.calls == [
        {
            "account": "acct-1",
            "event_name": "ai_tokens",
            "value": 42,
            "dimensions": {"model_name": "test", "thread_id": "thread-1"},
        }
    ]
    assert not hasattr(recorder, "bind")
