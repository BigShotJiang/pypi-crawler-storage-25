from __future__ import annotations

import sys
from pathlib import Path

import pytest_asyncio
from fastapi import FastAPI

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PACKAGE_ROOT.parents[0]
for path in [PACKAGE_ROOT / "src", REPO_ROOT / "vanty-core" / "src", REPO_ROOT / "vanty-payments" / "src"]:
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from vanty_core.apps import AppRegistry  # noqa: E402

from vanty_ai.apps import AIApp  # noqa: E402
from vanty_ai.settings import AISettings  # noqa: E402


@pytest_asyncio.fixture
async def ai_setup(tmp_path: Path):
    settings = AISettings()
    registry = AppRegistry(database_url=f"sqlite://{tmp_path / 'vanty-ai.db'}")
    app = registry.install(AIApp(settings=settings))
    fake = FastAPI()
    async with registry.lifespan(fake):
        yield registry, app


@pytest_asyncio.fixture
async def ai_app(ai_setup):
    _, app = ai_setup
    yield app
