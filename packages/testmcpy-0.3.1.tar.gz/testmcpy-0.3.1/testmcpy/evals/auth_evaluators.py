"""
Authentication-specific evaluators for testmcpy.

These evaluators validate authentication flows including OAuth2, JWT,
and Bearer token authentication. They can be used to test auth success,
token validity, OAuth flow completion, error handling, and JWT claim
validation.
"""

import base64
import json
import re
import time
from typing import Any

from testmcpy.evals.base_evaluators import BaseEvaluator, EvalResult


class AuthSuccessfulEvaluator(BaseEvaluator):
    """
    Evaluate if authentication was successful.

    Checks if authentication completed without errors by examining:
    - auth_success flag in metadata
    - absence of auth_error in metadata
    - presence of auth_token in metadata

    Args:
        args: Optional configuration dict (currently unused)

    Example:
        ```python
        evaluator = AuthSuccessfulEvaluator()
        result = evaluator.evaluate({
            "metadata": {
                "auth_success": True,
                "auth_error": None
            }
        })
        ```
    """

    def __init__(self, args: dict[str, Any] | None = None):
        """
        Initialize the evaluator.

        Args:
            args: Optional configuration dictionary
        """
        self.args = args or {}

    @property
    def name(self) -> str:
        return "auth_successful"

    @property
    def description(self) -> str:
        return "Checks if authentication was successful"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """
        Evaluate authentication success.

        Args:
            context: Dictionary containing metadata with auth information

        Returns:
            EvalResult with pass/fail status
        """
        metadata = context.get("metadata", {})

        # Check for auth success flag
        auth_success = metadata.get("auth_success", False)
        auth_error = metadata.get("auth_error")
        auth_token = metadata.get("auth_token")

        # Success if auth_success is True and no error
        if auth_success and not auth_error:
            return EvalResult(
                passed=True,
                score=1.0,
                reason="Authentication completed successfully",
                details={
                    "has_token": bool(auth_token),
                    "token_length": len(auth_token) if auth_token else 0,
                },
            )

        # Partial success if we have a token but no explicit success flag
        if auth_token and not auth_error:
            return EvalResult(
                passed=True,
                score=0.9,
                reason="Authentication token present (success flag not set)",
                details={"token_length": len(auth_token)},
            )

        # Failure cases
        if auth_error:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"Authentication failed: {auth_error}",
                details={"error": auth_error},
            )

        return EvalResult(
            passed=False, score=0.0, reason="No authentication information found in metadata"
        )


class TokenValidEvaluator(BaseEvaluator):
    """
    Evaluate if OAuth/JWT token is valid and meets format requirements.

    Validates tokens based on:
    - Format (JWT, Bearer, etc.)
    - Minimum length requirements
    - JWT structure and claims (if format=jwt)
    - Expiration (if included in JWT claims)

    Args:
        args: Configuration dict with optional keys:
            - format: Token format to validate ("jwt", "bearer", or None for any)
            - min_length: Minimum token length (default: 10)
            - check_expiration: Whether to validate JWT expiration (default: False)

    Example:
        ```python
        # Check for valid JWT token
        evaluator = TokenValidEvaluator(args={
            "format": "jwt",
            "min_length": 100,
            "check_expiration": True
        })
        ```
    """

    def __init__(self, args: dict[str, Any] | None = None):
        """
        Initialize the evaluator.

        Args:
            args: Configuration dictionary
        """
        self.args = args or {}

    @property
    def name(self) -> str:
        token_format = self.args.get("format", "any")
        return f"token_valid:{token_format}"

    @property
    def description(self) -> str:
        token_format = self.args.get("format", "any")
        min_length = self.args.get("min_length", 10)
        return f"Checks if {token_format} token is valid (min length: {min_length})"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """
        Evaluate token validity.

        Args:
            context: Dictionary containing metadata with auth_token

        Returns:
            EvalResult with validation details
        """
        metadata = context.get("metadata", {})
        auth_token = metadata.get("auth_token")

        if not auth_token:
            return EvalResult(
                passed=False, score=0.0, reason="No authentication token found in metadata"
            )

        # Check minimum length
        min_length = self.args.get("min_length", 10)
        if len(auth_token) < min_length:
            return EvalResult(
                passed=False,
                score=0.3,
                reason=f"Token too short: {len(auth_token)} chars (minimum: {min_length})",
                details={"token_length": len(auth_token)},
            )

        # Format-specific validation
        token_format = self.args.get("format")

        if token_format == "jwt":
            return self._validate_jwt(auth_token)
        elif token_format == "bearer":
            return self._validate_bearer(auth_token)
        else:
            # Generic validation - just check it's a reasonable string
            return EvalResult(
                passed=True,
                score=1.0,
                reason=f"Token present and valid length ({len(auth_token)} chars)",
                details={"token_length": len(auth_token)},
            )

    def _validate_jwt(self, token: str) -> EvalResult:
        """
        Validate JWT token structure and claims.

        Args:
            token: JWT token string

        Returns:
            EvalResult with JWT validation details
        """
        # Check JWT structure (header.payload.signature)
        parts = token.split(".")
        if len(parts) != 3:
            return EvalResult(
                passed=False,
                score=0.5,
                reason=f"Invalid JWT structure: expected 3 parts, got {len(parts)}",
                details={"parts": len(parts)},
            )

        # Try to decode JWT (without signature verification)
        try:
            # Decode header (first part) for alg/typ validation
            header_part = parts[0]
            header_padding = 4 - len(header_part) % 4
            if header_padding != 4:
                header_part += "=" * header_padding
            header_bytes = base64.urlsafe_b64decode(header_part)
            header = json.loads(header_bytes)

            # Decode payload (second part)
            # Add padding if needed
            payload_part = parts[1]
            padding = 4 - len(payload_part) % 4
            if padding != 4:
                payload_part += "=" * padding

            payload_bytes = base64.urlsafe_b64decode(payload_part)
            payload = json.loads(payload_bytes)

            details = {
                "token_length": len(token),
                "has_payload": True,
                "claims": list(payload.keys()),
                "header": header,
            }

            # Validate JWT header - check for alg: "none" attack (RFC 7519 Section 5)
            alg = header.get("alg")
            if alg is None:
                return EvalResult(
                    passed=False,
                    score=0.5,
                    reason="JWT header missing 'alg' claim (RFC 7519 Section 5)",
                    details=details,
                )
            if alg.lower() == "none":
                return EvalResult(
                    passed=False,
                    score=0.0,
                    reason="JWT uses alg='none' - unsigned token is a security vulnerability",
                    details=details,
                )

            # Check expiration if requested
            if self.args.get("check_expiration", False):
                if "exp" in payload:
                    import time

                    exp_time = payload["exp"]
                    current_time = time.time()

                    if exp_time < current_time:
                        return EvalResult(
                            passed=False,
                            score=0.7,
                            reason="JWT token has expired",
                            details={**details, "expired": True, "exp": exp_time},
                        )

                    details["expires_in"] = int(exp_time - current_time)
                else:
                    return EvalResult(
                        passed=False,
                        score=0.8,
                        reason="JWT token missing expiration claim",
                        details={**details, "has_exp": False},
                    )

            return EvalResult(
                passed=True,
                score=1.0,
                reason="JWT token is valid and properly formatted",
                details=details,
            )

        except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as e:
            return EvalResult(
                passed=False,
                score=0.4,
                reason=f"Failed to decode JWT payload: {str(e)}",
                details={"error": str(e)},
            )

    def _validate_bearer(self, token: str) -> EvalResult:
        """
        Validate Bearer token format.

        Args:
            token: Bearer token string

        Returns:
            EvalResult with Bearer token validation
        """
        # Bearer tokens should be alphanumeric with possible special chars
        if not re.match(r"^[A-Za-z0-9_\-\.~\+\/=]+$", token):
            return EvalResult(
                passed=False,
                score=0.6,
                reason="Bearer token contains invalid characters",
                details={"token_length": len(token)},
            )

        return EvalResult(
            passed=True,
            score=1.0,
            reason="Bearer token is valid",
            details={"token_length": len(token)},
        )


class OAuth2FlowEvaluator(BaseEvaluator):
    """
    Evaluate OAuth2 flow completion by checking all required steps.

    Verifies that the OAuth2 flow completed all necessary steps:
    1. Request prepared (with client_id, client_secret, scopes)
    2. Token endpoint called (POST to token URL)
    3. Response received (200 OK)
    4. Token extracted (access_token parsed from response)

    Args:
        args: Optional configuration dict with:
            - required_steps: List of step names that must be present
                            (default: standard OAuth2 flow steps)

    Example:
        ```python
        evaluator = OAuth2FlowEvaluator(args={
            "required_steps": [
                "request_prepared",
                "token_endpoint_called",
                "response_received",
                "token_extracted"
            ]
        })
        ```
    """

    def __init__(self, args: dict[str, Any] | None = None):
        """
        Initialize the evaluator.

        Args:
            args: Configuration dictionary
        """
        self.args = args or {}

    @property
    def name(self) -> str:
        return "oauth2_flow_complete"

    @property
    def description(self) -> str:
        return "Checks if OAuth2 flow completed all required steps"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """
        Evaluate OAuth2 flow completion.

        Args:
            context: Dictionary containing metadata with auth_flow_steps

        Returns:
            EvalResult with flow completion details
        """
        metadata = context.get("metadata", {})
        auth_flow_steps = metadata.get("auth_flow_steps", [])

        if not auth_flow_steps:
            return EvalResult(
                passed=False, score=0.0, reason="No OAuth2 flow steps recorded in metadata"
            )

        # Get required steps from args or use defaults
        required_steps = self.args.get(
            "required_steps",
            ["request_prepared", "token_endpoint_called", "response_received", "token_extracted"],
        )

        # Check which steps are present
        completed_steps = []
        missing_steps = []

        for step in required_steps:
            if step in auth_flow_steps:
                completed_steps.append(step)
            else:
                missing_steps.append(step)

        # Calculate score based on completion
        score = len(completed_steps) / len(required_steps) if required_steps else 0.0

        if not missing_steps:
            return EvalResult(
                passed=True,
                score=1.0,
                reason=f"OAuth2 flow completed all {len(required_steps)} required steps",
                details={"completed_steps": completed_steps, "total_steps": len(auth_flow_steps)},
            )

        return EvalResult(
            passed=False,
            score=score,
            reason=f"OAuth2 flow incomplete: {len(missing_steps)} step(s) missing",
            details={
                "completed_steps": completed_steps,
                "missing_steps": missing_steps,
                "total_steps": len(auth_flow_steps),
            },
        )


class AuthErrorHandlingEvaluator(BaseEvaluator):
    """
    Evaluate proper error handling for authentication failures.

    Validates that when authentication fails, the error messages contain
    useful information for debugging. Checks for:
    - Clear error message presence
    - Required information in error message (e.g., "invalid_client", "unauthorized")
    - Error message quality (not generic "error occurred")

    Args:
        args: Configuration dict with:
            - required_info: List of strings that must appear in error message
            - min_length: Minimum error message length (default: 10)
            - forbid_generic: Reject generic error messages (default: True)

    Example:
        ```python
        # Ensure error mentions invalid client
        evaluator = AuthErrorHandlingEvaluator(args={
            "required_info": ["invalid_client", "401"],
            "min_length": 20
        })
        ```
    """

    def __init__(self, args: dict[str, Any] | None = None):
        """
        Initialize the evaluator.

        Args:
            args: Configuration dictionary
        """
        self.args = args or {}

    @property
    def name(self) -> str:
        return "auth_error_handling"

    @property
    def description(self) -> str:
        required = self.args.get("required_info", [])
        if required:
            return f"Checks auth error message contains: {', '.join(required)}"
        return "Checks for proper authentication error handling"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """
        Evaluate authentication error handling quality.

        Args:
            context: Dictionary containing metadata with auth_error

        Returns:
            EvalResult with error handling validation
        """
        metadata = context.get("metadata", {})
        auth_error = metadata.get("auth_error")
        auth_error_message = metadata.get("auth_error_message", "")

        # Use auth_error as message if auth_error_message not present
        if not auth_error_message and auth_error:
            auth_error_message = str(auth_error)

        if not auth_error and not auth_error_message:
            return EvalResult(
                passed=False,
                score=0.0,
                reason="No authentication error found (this evaluator expects auth failure)",
            )

        # Check minimum length
        min_length = self.args.get("min_length", 10)
        if len(auth_error_message) < min_length:
            return EvalResult(
                passed=False,
                score=0.3,
                reason=f"Error message too short: {len(auth_error_message)} chars (minimum: {min_length})",
                details={"message": auth_error_message},
            )

        # Check for generic error messages (if not forbidden, this passes)
        forbid_generic = self.args.get("forbid_generic", True)
        generic_patterns = [
            r"^error$",
            r"^error occurred$",
            r"^failed$",
            r"^authentication failed$",
            r"^auth error$",
        ]

        if forbid_generic:
            for pattern in generic_patterns:
                if re.match(pattern, auth_error_message.strip(), re.IGNORECASE):
                    return EvalResult(
                        passed=False,
                        score=0.4,
                        reason=f"Error message too generic: '{auth_error_message}'",
                        details={"message": auth_error_message},
                    )

        # Check for required information
        required_info = self.args.get("required_info", [])
        if required_info:
            found = []
            missing = []

            error_lower = auth_error_message.lower()
            for info in required_info:
                if info.lower() in error_lower:
                    found.append(info)
                else:
                    missing.append(info)

            score = len(found) / len(required_info) if required_info else 1.0

            if missing:
                return EvalResult(
                    passed=False,
                    score=score,
                    reason=f"Error message missing required info: {', '.join(missing)}",
                    details={"message": auth_error_message, "found": found, "missing": missing},
                )

        # All checks passed
        return EvalResult(
            passed=True,
            score=1.0,
            reason="Error message provides clear, detailed information",
            details={"message": auth_error_message, "length": len(auth_error_message)},
        )


class JWTClaimsValidEvaluator(BaseEvaluator):
    """
    Evaluate JWT token claims for correctness.

    Decodes a JWT token (without cryptographic verification by default) and
    validates specified claims: iss, aud, exp, sub, and any custom claims.

    Args:
        args: Configuration dict with optional keys:
            - token_field: Metadata field containing the JWT token
                          (default: "auth_token")
            - iss: Expected issuer claim value
            - aud: Expected audience claim value (string or list)
            - sub: Expected subject claim value
            - check_exp: Whether to check expiration (default: True)
            - custom_claims: Dict of claim_name -> expected_value pairs

    Example:
        ```python
        evaluator = JWTClaimsValidEvaluator(args={
            "iss": "https://auth.example.com",
            "aud": "my-api",
            "check_exp": True,
            "custom_claims": {"role": "admin"}
        })
        ```
    """

    def __init__(self, args: dict[str, Any] | None = None):
        self.args = args or {}

    @property
    def name(self) -> str:
        return "jwt_claims_valid"

    @property
    def description(self) -> str:
        checks = []
        if self.args.get("iss"):
            checks.append(f"iss={self.args['iss']}")
        if self.args.get("aud"):
            checks.append(f"aud={self.args['aud']}")
        if self.args.get("sub"):
            checks.append(f"sub={self.args['sub']}")
        if self.args.get("check_exp", True):
            checks.append("exp")
        if self.args.get("check_nbf"):
            checks.append("nbf")
        if self.args.get("check_iat"):
            checks.append("iat")
        if self.args.get("check_header"):
            checks.append("header")
        if self.args.get("custom_claims"):
            checks.append(f"custom({len(self.args['custom_claims'])})")
        return f"Validates JWT claims: {', '.join(checks) or 'structure only'}"

    @staticmethod
    def decode_jwt_payload(token: str) -> dict[str, Any]:
        """Decode the payload of a JWT token without verification.

        Args:
            token: JWT token string (header.payload.signature)

        Returns:
            Decoded payload as a dictionary.

        Raises:
            ValueError: If the token is not a valid JWT structure.
        """
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError(f"Invalid JWT structure: expected 3 parts, got {len(parts)}")

        payload_part = parts[1]
        # Add padding if needed for base64 decoding
        padding = 4 - len(payload_part) % 4
        if padding != 4:
            payload_part += "=" * padding

        payload_bytes = base64.urlsafe_b64decode(payload_part)
        return json.loads(payload_bytes)

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        """
        Evaluate JWT token claims.

        Args:
            context: Dictionary containing metadata with the JWT token.

        Returns:
            EvalResult with claim validation details.
        """
        metadata = context.get("metadata", {})
        token_field = self.args.get("token_field", "auth_token")
        token = metadata.get(token_field)

        if not token:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"No JWT token found in metadata field '{token_field}'",
            )

        # Decode JWT
        try:
            payload = self.decode_jwt_payload(token)
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as e:
            return EvalResult(
                passed=False,
                score=0.1,
                reason=f"Failed to decode JWT: {e}",
                details={"error": str(e)},
            )

        failed_claims: list[str] = []
        passed_claims: list[str] = []
        details: dict[str, Any] = {"claims": list(payload.keys())}

        # Check issuer (iss)
        expected_iss = self.args.get("iss")
        if expected_iss is not None:
            actual_iss = payload.get("iss")
            if actual_iss == expected_iss:
                passed_claims.append("iss")
            else:
                failed_claims.append(f"iss: expected '{expected_iss}', got '{actual_iss}'")

        # Check audience (aud)
        expected_aud = self.args.get("aud")
        if expected_aud is not None:
            actual_aud = payload.get("aud")
            # aud can be a string or list
            if isinstance(actual_aud, list):
                if expected_aud in actual_aud:
                    passed_claims.append("aud")
                else:
                    failed_claims.append(f"aud: expected '{expected_aud}' in {actual_aud}")
            elif actual_aud == expected_aud:
                passed_claims.append("aud")
            else:
                failed_claims.append(f"aud: expected '{expected_aud}', got '{actual_aud}'")

        # Check subject (sub)
        expected_sub = self.args.get("sub")
        if expected_sub is not None:
            actual_sub = payload.get("sub")
            if actual_sub == expected_sub:
                passed_claims.append("sub")
            else:
                failed_claims.append(f"sub: expected '{expected_sub}', got '{actual_sub}'")

        # Check expiration (exp)
        check_exp = self.args.get("check_exp", True)
        if check_exp:
            exp = payload.get("exp")
            if exp is None:
                failed_claims.append("exp: missing expiration claim")
            elif not isinstance(exp, (int, float)):
                failed_claims.append(f"exp: invalid type {type(exp).__name__}")
            elif exp < time.time():
                failed_claims.append(f"exp: token expired at {exp} (current: {int(time.time())})")
                details["expired"] = True
            else:
                passed_claims.append("exp")
                details["expires_in_seconds"] = int(exp - time.time())

        # Check not-before (nbf) - RFC 7519 Section 4.1.5
        check_nbf = self.args.get("check_nbf", False)
        if check_nbf:
            nbf = payload.get("nbf")
            if nbf is None:
                failed_claims.append("nbf: missing not-before claim")
            elif not isinstance(nbf, (int, float)):
                failed_claims.append(f"nbf: invalid type {type(nbf).__name__}")
            elif nbf > time.time():
                failed_claims.append(
                    f"nbf: token not yet valid (nbf={int(nbf)}, now={int(time.time())})"
                )
            else:
                passed_claims.append("nbf")

        # Check issued-at (iat) - RFC 7519 Section 4.1.6
        check_iat = self.args.get("check_iat", False)
        if check_iat:
            iat = payload.get("iat")
            if iat is None:
                failed_claims.append("iat: missing issued-at claim")
            elif not isinstance(iat, (int, float)):
                failed_claims.append(f"iat: invalid type {type(iat).__name__}")
            elif iat > time.time():
                failed_claims.append(
                    f"iat: issued in the future (iat={int(iat)}, now={int(time.time())})"
                )
            else:
                passed_claims.append("iat")
                details["issued_at"] = int(iat)

        # Check JWT header - RFC 7519 Section 5
        check_header = self.args.get("check_header", False)
        if check_header:
            try:
                parts = token.split(".")
                header_part = parts[0]
                header_padding = 4 - len(header_part) % 4
                if header_padding != 4:
                    header_part += "=" * header_padding
                header_bytes = base64.urlsafe_b64decode(header_part)
                header = json.loads(header_bytes)
                details["header"] = header

                alg = header.get("alg")
                if alg is None:
                    failed_claims.append("header.alg: missing algorithm claim")
                elif alg.lower() == "none":
                    failed_claims.append("header.alg: 'none' is a security vulnerability")
                else:
                    passed_claims.append("header.alg")

                typ = header.get("typ")
                if typ is not None:
                    if typ.upper() == "JWT":
                        passed_claims.append("header.typ")
                    else:
                        failed_claims.append(f"header.typ: expected 'JWT', got '{typ}'")
            except (ValueError, json.JSONDecodeError) as e:
                failed_claims.append(f"header: failed to decode - {e}")

        # Check custom claims
        custom_claims = self.args.get("custom_claims", {})
        for claim_name, expected_value in custom_claims.items():
            actual_value = payload.get(claim_name)
            if actual_value == expected_value:
                passed_claims.append(claim_name)
            else:
                failed_claims.append(
                    f"{claim_name}: expected '{expected_value}', got '{actual_value}'"
                )

        details["passed_claims"] = passed_claims
        details["failed_claims"] = failed_claims

        total_checks = len(passed_claims) + len(failed_claims)
        score = len(passed_claims) / total_checks if total_checks > 0 else 1.0

        if failed_claims:
            return EvalResult(
                passed=False,
                score=score,
                reason=f"JWT claim validation failed: {'; '.join(failed_claims)}",
                details=details,
            )

        return EvalResult(
            passed=True,
            score=1.0,
            reason=f"All JWT claims valid ({len(passed_claims)} checked)",
            details=details,
        )


class OAuthDiscoveryEvaluator(BaseEvaluator):
    """
    Evaluate OAuth discovery metadata against RFC 8414.

    Fetches the well-known OAuth authorization server metadata and validates
    that required fields are present and contain expected values.

    Args:
        args: Configuration dict with optional keys:
            - required_fields: List of fields that must be present
              (default: ["issuer", "token_endpoint"])
            - expected_grant_types: List of grant types that must be supported
            - require_pkce: Whether code_challenge_methods_supported must include "S256"
    """

    def __init__(self, args: dict[str, Any] | None = None):
        self.args = args or {}

    @property
    def name(self) -> str:
        return "oauth_discovery_valid"

    @property
    def description(self) -> str:
        return "Validates OAuth discovery metadata (RFC 8414)"

    def evaluate(self, context: dict[str, Any]) -> EvalResult:
        # This evaluator needs async; delegate to aevaluate
        raise NotImplementedError("Use aevaluate() for OAuthDiscoveryEvaluator")

    async def aevaluate(self, context: dict[str, Any]) -> EvalResult:
        from testmcpy.auth_debugger import discover_oauth_endpoints

        metadata = context.get("metadata", {})
        mcp_url = metadata.get("mcp_url")

        if not mcp_url:
            # Try to get from mcp_client
            mcp_client = context.get("mcp_client")
            if mcp_client and hasattr(mcp_client, "url"):
                mcp_url = mcp_client.url

        if not mcp_url:
            return EvalResult(
                passed=False,
                score=0.0,
                reason="No MCP URL available for OAuth discovery",
            )

        try:
            discovery_metadata = await discover_oauth_endpoints(mcp_url)
        except Exception as e:
            return EvalResult(
                passed=False,
                score=0.0,
                reason=f"OAuth discovery failed: {e}",
                details={"error": str(e)},
            )

        # Validate required fields
        required_fields = self.args.get("required_fields", ["issuer", "token_endpoint"])
        missing_fields = []
        present_fields = []

        for field in required_fields:
            if field in discovery_metadata and discovery_metadata[field]:
                present_fields.append(field)
            else:
                missing_fields.append(field)

        details = {
            "present_fields": present_fields,
            "missing_fields": missing_fields,
            "metadata_keys": list(discovery_metadata.keys()),
        }

        # Validate expected grant types
        expected_grant_types = self.args.get("expected_grant_types")
        if expected_grant_types:
            supported = discovery_metadata.get("grant_types_supported", [])
            missing_grants = [g for g in expected_grant_types if g not in supported]
            if missing_grants:
                details["missing_grant_types"] = missing_grants
                missing_fields.append(f"grant_types({', '.join(missing_grants)})")

        # Validate PKCE support
        if self.args.get("require_pkce"):
            challenge_methods = discovery_metadata.get("code_challenge_methods_supported", [])
            if "S256" not in challenge_methods:
                details["code_challenge_methods"] = challenge_methods
                missing_fields.append("PKCE S256 support")

        if missing_fields:
            total = (
                len(required_fields)
                + (1 if expected_grant_types else 0)
                + (1 if self.args.get("require_pkce") else 0)
            )
            score = len(present_fields) / total if total > 0 else 0.0
            return EvalResult(
                passed=False,
                score=score,
                reason=f"OAuth discovery missing: {', '.join(missing_fields)}",
                details=details,
            )

        return EvalResult(
            passed=True,
            score=1.0,
            reason=f"OAuth discovery valid ({len(present_fields)} fields verified)",
            details=details,
        )
