#!/usr/bin/env python3

# Copyright 2019 The Kapitan Authors
# SPDX-FileCopyrightText: 2020 The Kapitan Authors <kapitan-admins@googlegroups.com>
#
# SPDX-License-Identifier: Apache-2.0

"refs tests"

import base64
import os
import string
import tempfile
import unittest

from kapitan.errors import RefError, RefFromFuncError, RefHashMismatchError
from kapitan.refs.base import PlainRef, RefController, RefParams, Revealer
from kapitan.refs.base64 import Base64Ref
from kapitan.refs.env import DEFAULT_ENV_REF_VAR_PREFIX, EnvRef
from kapitan.utils import get_entropy


REFS_HOME = tempfile.mkdtemp()
REF_CONTROLLER = RefController(REFS_HOME)
REVEALER = Revealer(REF_CONTROLLER)
REF_CONTROLLER_EMBEDDED = RefController(REFS_HOME, embed_refs=True)
REVEALER_EMBEDDED = Revealer(REF_CONTROLLER_EMBEDDED)


class Base64RefsTest(unittest.TestCase):
    "Test refs"

    def test_plain_ref_compile(self):
        "check plain ref compile() output is not hashed"
        tag = "?{plain:my/ref1_plain}"
        REF_CONTROLLER[tag] = PlainRef(b"ref plain data")
        ref_obj = REF_CONTROLLER[tag]
        compiled = ref_obj.compile()
        self.assertEqual(compiled, "ref plain data")

    def test_plain_ref_reveal(self):
        "check plain ref reveal() output is original plain data"
        tag = "?{plain:my/ref2_plain}"
        REF_CONTROLLER[tag] = PlainRef(b"ref 2 plain data")
        ref_obj = REF_CONTROLLER[tag]
        revealed = ref_obj.reveal()
        self.assertEqual(revealed, "ref 2 plain data")

    def test_env_ref_compile(self):
        "check env ref compile() output is valid"
        tag = "?{env:my/ref1_env}"
        REF_CONTROLLER[tag] = EnvRef(b"ref 1 env data")
        ref_obj = REF_CONTROLLER[tag]
        revealed = ref_obj.compile()
        self.assertEqual(revealed, "?{env:my/ref1_env:877234e3}")

    def test_env_ref_reveal_default(self):
        "check env ref reveal() output is original plain env data when environment var is not set"
        tag = "?{env:my/ref1_env}"
        REF_CONTROLLER[tag] = EnvRef(b"ref 1 env data")
        ref_obj = REF_CONTROLLER[tag]
        revealed = ref_obj.reveal()
        self.assertEqual(revealed, "ref 1 env data")

    def test_env_ref_reveal_from_env(self):
        "check env ref reveal() output is value of environment var data when environment var is set"
        tag = "?{env:my/ref1_env}"
        REF_CONTROLLER[tag] = EnvRef(b"ref 1 env data")
        ref_obj = REF_CONTROLLER[tag]
        os.environ["{}{}".format(DEFAULT_ENV_REF_VAR_PREFIX, "ref1_env")] = (
            "ref 1 env data from EV"
        )
        revealed = ref_obj.reveal()
        self.assertEqual(revealed, "ref 1 env data from EV")

    def test_base64_ref_compile(self):
        "check ref compile() output is valid"
        tag = "?{base64:my/ref1}"
        REF_CONTROLLER[tag] = Base64Ref(b"ref 1 data")
        ref_obj = REF_CONTROLLER[tag]
        compiled = ref_obj.compile()
        self.assertEqual(compiled, "?{base64:my/ref1:3342a45c}")

    def test_base64_ref_embedded_compile(self):
        "check ref embedded compile() output is valid"
        tag = "?{base64:my/ref1}"
        REF_CONTROLLER_EMBEDDED[tag] = Base64Ref(b"ref 1 data")
        ref_obj = REF_CONTROLLER_EMBEDDED[tag]
        compiled_embedded = ref_obj.compile()
        embedded_tag = (
            "?{base64:eyJkYXRhIjogImNtVm1JREVnWkdGMFlRPT0iLCAiZW5jb2"
            "RpbmciOiAib3JpZ2luYWwiLCAidHlwZSI6ICJiYXNlNjQifQ==:embedded}"
        )
        self.assertEqual(compiled_embedded, embedded_tag)

    def test_base64_ref_recompile(self):
        "check ref recompile() output is valid"
        tag = "?{base64:my/ref1}"
        # Ensure the ref exists (test isolation for parallel execution)
        REF_CONTROLLER[tag] = Base64Ref(b"ref 1 data")
        ref_obj = REF_CONTROLLER[tag]
        compiled = ref_obj.compile()
        self.assertEqual(compiled, "?{base64:my/ref1:3342a45c}")

    def test_base64_ref_update_compile(self):
        "check ref update and compile() output is valid"
        tag = "?{base64:my/ref1}"
        REF_CONTROLLER[tag] = Base64Ref(b"ref 1 more data")
        ref_obj = REF_CONTROLLER[tag]
        compiled = ref_obj.compile()
        self.assertEqual(compiled, "?{base64:my/ref1:ed438a62}")

    def test_base64_ref_reveal(self):
        "check ref reveal() output is valid"
        tag = "?{base64:my/ref2}"
        REF_CONTROLLER[tag] = Base64Ref(b"ref 2 data")
        ref_obj = REF_CONTROLLER[tag]
        revealed = ref_obj.reveal()
        self.assertEqual(revealed, "ref 2 data")

    def test_base64_ref_embedded_reveal(self):
        "check ref embedded reveal() output is valid"
        tag = "?{base64:my/ref2}"
        REF_CONTROLLER_EMBEDDED[tag] = Base64Ref(b"ref 2 data")
        ref_obj = REF_CONTROLLER_EMBEDDED[tag]
        revealed = ref_obj.reveal()
        self.assertEqual(revealed, "ref 2 data")

    def test_base64_ref_embedded_reveal_encoding_original(self):
        "check ref embedded reveal() encoding metadata is persisted"
        tag = "?{base64:my/ref2}"
        REF_CONTROLLER_EMBEDDED[tag] = Base64Ref(b"ref 2 data")
        ref_obj = REF_CONTROLLER_EMBEDDED[tag]
        revealed = ref_obj.reveal()
        self.assertEqual(revealed, "ref 2 data")
        self.assertEqual(ref_obj.encoding, "original")

    def test_base64_ref_embedded_reveal_encoding_base64(self):
        "check ref embedded reveal() encoding metadata is persisted"
        tag = "?{base64:my/ref3}"
        REF_CONTROLLER_EMBEDDED[tag] = Base64Ref(
            base64.b64encode(b"ref 3 data"), encoding="base64"
        )
        ref_obj = REF_CONTROLLER_EMBEDDED[tag]
        revealed = ref_obj.reveal()
        self.assertEqual(revealed, base64.b64encode(b"ref 3 data").decode())
        self.assertEqual(ref_obj.encoding, "base64")

    def test_base64_ref_non_existent_raises_KeyError(self):
        "check RefController raises KeyError for non existent Base64Ref"
        tag = "?{base64:non/existent}"
        with self.assertRaises(KeyError):
            REF_CONTROLLER[tag]

    def test_base64_ref_tag_type(self):
        "check ref tag type is Base64Ref"
        tag = "?{base64:my/ref3}"
        tag_type = REF_CONTROLLER.tag_type(tag)
        self.assertEqual(tag_type, Base64Ref)

    def test_base64_ref_tag_type_name(self):
        "check ref tag type name is ref"
        tag = "?{base64:my/ref4}"
        tag, token, func_str = REF_CONTROLLER.tag_params(tag)
        type_name = REF_CONTROLLER.token_type_name(token)
        self.assertEqual(tag, "?{base64:my/ref4}")
        self.assertEqual(token, "base64:my/ref4")
        self.assertEqual(func_str, None)
        self.assertEqual(type_name, "base64")

    def test_base64_ref_tag_func_name(self):
        "check ref tag func name is correct"
        tag = "?{base64:my/ref5||random:str}"
        tag, token, func_str = REF_CONTROLLER.tag_params(tag)
        self.assertEqual(tag, "?{base64:my/ref5||random:str}")
        self.assertEqual(token, "base64:my/ref5")
        self.assertEqual(func_str, "||random:str")

    def test_base64_ref_embedded_attr(self):
        "check embedded ref has embed_refs set to True"
        tag = "?{base64:my/ref2}"
        REF_CONTROLLER_EMBEDDED[tag] = Base64Ref(b"ref 2 data")
        ref_obj = REF_CONTROLLER_EMBEDDED[tag]
        self.assertTrue(ref_obj.embed_refs)

    def test_base64_ref_attr(self):
        "check ref has embed_refs set to False"
        tag = "?{base64:my/ref2}"
        REF_CONTROLLER[tag] = Base64Ref(b"ref 2 data")
        ref_obj = REF_CONTROLLER[tag]
        self.assertFalse(ref_obj.embed_refs)

    def test_base64_ref_path(self):
        "check ref tag path is correct"
        tag = "?{base64:my/ref6}"
        tag, token, func_str = REF_CONTROLLER.tag_params(tag)
        self.assertEqual(tag, "?{base64:my/ref6}")
        self.assertEqual(token, "base64:my/ref6")
        self.assertEqual(func_str, None)
        REF_CONTROLLER[tag] = Base64Ref(b"ref 6 data")
        ref_obj = REF_CONTROLLER[tag]
        self.assertEqual(ref_obj.path, "my/ref6")

    def test_base64_ref_func_raise_RefFromFuncError(self):
        """
        check new ref tag with function raises RefFromFuncError
        and then creates it using RefParams()
        """
        tag = "?{base64:my/ref7||random:str}"
        with self.assertRaises(RefFromFuncError):
            REF_CONTROLLER[tag]
        try:
            REF_CONTROLLER[tag]
        except RefFromFuncError:
            REF_CONTROLLER[tag] = RefParams()
        REF_CONTROLLER[tag]

    def test_base64_ref_revealer_reveal_raw_data_tag(self):
        "check Revealer reveals raw data"
        tag = "?{base64:my/ref2}"
        REF_CONTROLLER[tag] = Base64Ref(b"ref 2 data")
        data = f"data with {tag}, period."
        revealed_data = REVEALER.reveal_raw(data)
        self.assertEqual(revealed_data, "data with ref 2 data, period.")

    def test_base64_ref_revealer_reveal_raw_data_tag_compiled_hash(self):
        "check Revealer reveals raw data with compiled tag (with hash)"
        tag = "?{base64:my/ref2}"
        REF_CONTROLLER[tag] = Base64Ref(b"ref 2 data")
        tag_compiled = REF_CONTROLLER[tag].compile()
        data = f"data with {tag_compiled}, period."
        revealed_data = REVEALER.reveal_raw(data)
        self.assertEqual(revealed_data, "data with ref 2 data, period.")

    def test_base64_ref_revealer_reveal_raw_data_tag_compiled_hash_mismatch(self):
        """
        check Revealer reveals raises RefHashMismatchError
        on mismatch compiled tag hashes
        """
        tag = "?{base64:my/ref2}"
        REF_CONTROLLER[tag] = Base64Ref(b"ref 2 data")
        tag_compiled_hash_mismatch = "?{base64:my/ref2:deadbeef}"
        with self.assertRaises(RefHashMismatchError):
            data = f"data with {tag_compiled_hash_mismatch}, period."
            REVEALER.reveal_raw(data)

    def test_compile_subvars(self):
        """
        test that refs with sub-variables compile properly,
        and refs with different sub-variables stored in the same file has the same hash
        """
        subvar_tag1 = "?{base64:ref/subvars@var1}"
        subvar_tag2 = "?{base64:ref/subvars@var2}"
        REF_CONTROLLER["?{base64:ref/subvars}"] = Base64Ref(b"ref 1 data")
        ref_obj1 = REF_CONTROLLER[subvar_tag1]
        ref_obj2 = REF_CONTROLLER[subvar_tag2]
        self.assertEqual(ref_obj1.compile(), "?{base64:ref/subvars@var1:4357a29b}")
        self.assertEqual(ref_obj2.compile(), "?{base64:ref/subvars@var2:4357a29b}")

    def test_compile_embedded_subvar_path(self):
        """
        test that embedded refs with sub-variables have
        valid embedded_subvar_path key and value
        """
        subvar_tag = "?{base64:ref/subvars}"
        subvar_tag_var1 = "?{base64:ref/subvars@var1}"
        subvar_tag_var2 = "?{base64:ref/subvars@var2}"
        subvar_tag_var3 = "?{base64:ref/subvars@var3.var4}"
        REF_CONTROLLER_EMBEDDED[subvar_tag] = Base64Ref(b"I am not yaml, just testing")
        REF_CONTROLLER_EMBEDDED[subvar_tag_var1] = Base64Ref(
            b"I am not yaml, just testing"
        )
        REF_CONTROLLER_EMBEDDED[subvar_tag_var2] = Base64Ref(
            b"I am not yaml, just testing"
        )
        ref_obj1 = REF_CONTROLLER_EMBEDDED[subvar_tag_var1]
        ref_obj2 = REF_CONTROLLER_EMBEDDED[subvar_tag_var2]
        ref_obj3 = REF_CONTROLLER_EMBEDDED[subvar_tag_var3]

        self.assertTrue(ref_obj1.embed_refs)
        self.assertTrue(ref_obj2.embed_refs)
        self.assertTrue(ref_obj3.embed_refs)

        # now get compiled embedded ref tags from controller
        ref_obj1 = REF_CONTROLLER_EMBEDDED[ref_obj1.compile()]
        ref_obj2 = REF_CONTROLLER_EMBEDDED[ref_obj2.compile()]
        ref_obj3 = REF_CONTROLLER_EMBEDDED[ref_obj3.compile()]

        # and validate meta data
        self.assertEqual(ref_obj1.embedded_subvar_path, "var1")
        self.assertEqual(ref_obj2.embedded_subvar_path, "var2")
        self.assertEqual(ref_obj3.embedded_subvar_path, "var3.var4")

    def test_compile_embedded_subvars(self):
        """
        test that embedded refs with sub-variables compile properly,
        embedded refs with sub-variables will _not_ have equal compiled tags
        """
        subvar_tag = "?{base64:ref/subvars}"
        subvar_tag_var1 = "?{base64:ref/subvars@var1}"
        subvar_tag_var2 = "?{base64:ref/subvars@var2}"
        REF_CONTROLLER_EMBEDDED[subvar_tag] = Base64Ref(b"I am not yaml, just testing")
        REF_CONTROLLER_EMBEDDED[subvar_tag_var1] = Base64Ref(
            b"I am not yaml, just testing"
        )
        REF_CONTROLLER_EMBEDDED[subvar_tag_var2] = Base64Ref(
            b"I am not yaml, just testing"
        )
        ref_obj1 = REF_CONTROLLER_EMBEDDED[subvar_tag_var1]
        ref_obj2 = REF_CONTROLLER_EMBEDDED[subvar_tag_var2]
        self.assertNotEqual(ref_obj1.compile(), ref_obj2.compile())

    def test_reveal_subvars_raise_RefError(self):
        """
        test that reveal with sub-variable fails should the secret not
        be in valid yaml format
        """
        tag_to_save = "?{base64:ref/subvars_error}"
        yaml_secret = b"this is not yaml"
        REF_CONTROLLER[tag_to_save] = Base64Ref(yaml_secret)
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/subvars_error")))

        with self.assertRaises(RefError):
            tag_subvar = "?{base64:ref/subvars_error@var3.var4}"
            data = f"message here: {tag_subvar}"
            REVEALER.reveal_raw(data)

    def test_reveal_subvars(self):
        "write yaml secret, and access sub-variables in secrets"
        tag_to_save = "?{base64:ref/subvars}"
        yaml_secret = b"""
        var1:
          var2: hello
        var3:
          var4: world
        """
        REF_CONTROLLER[tag_to_save] = Base64Ref(yaml_secret)
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/subvars")))

        tag_subvar = "?{base64:ref/subvars@var1.var2}"
        data = f"message here: {tag_subvar}"
        revealed_data = REVEALER.reveal_raw(data)
        self.assertEqual("message here: hello", revealed_data)

        tag_subvar = "?{base64:ref/subvars@var3.var4}"
        data = f"message here: {tag_subvar}"
        revealed_data = REVEALER.reveal_raw(data)
        self.assertEqual("message here: world", revealed_data)

        with self.assertRaises(RefError):
            tag_subvar = "?{base64:ref/subvars@var3.varDoesntExist}"
            data = f"message here: {tag_subvar}"
            revealed_data = REVEALER.reveal_raw(data)

    def test_reveal_embedded_subvars(self):
        "write yaml ref data, and access sub-variables in embedded compiled refs"
        tag_to_save = "?{base64:ref/subvars}"
        tag_var1 = "?{base64:ref/subvars@var1.var2}"
        tag_var2 = "?{base64:ref/subvars@var3.var4}"
        tag_var_doesnt_exist = "?{base64:ref/subvars@var3.varDoesntExist}"
        yaml_secret = b"""
        var1:
          var2: hello
        var3:
          var4: world
        """
        REF_CONTROLLER_EMBEDDED[tag_to_save] = Base64Ref(yaml_secret)
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/subvars")))

        REF_CONTROLLER_EMBEDDED[tag_var1] = Base64Ref(yaml_secret)
        REF_CONTROLLER_EMBEDDED[tag_var2] = Base64Ref(yaml_secret)
        REF_CONTROLLER_EMBEDDED[tag_var_doesnt_exist] = Base64Ref(yaml_secret)

        ref_var1 = REF_CONTROLLER_EMBEDDED[tag_var1]
        ref_var2 = REF_CONTROLLER_EMBEDDED[tag_var2]
        ref_var_doesnt_exist = REF_CONTROLLER_EMBEDDED[tag_var_doesnt_exist]

        data = f"message here: {ref_var1.compile()}"
        revealed_data = REVEALER_EMBEDDED.reveal_raw(data)
        self.assertEqual("message here: hello", revealed_data)

        data = f"message here: {ref_var2.compile()}"
        revealed_data = REVEALER_EMBEDDED.reveal_raw(data)
        self.assertEqual("message here: world", revealed_data)

        with self.assertRaises(RefError):
            data = f"message here: {ref_var_doesnt_exist.compile()}"
            revealed_data = REVEALER_EMBEDDED.reveal_raw(data)

    def test_ref_function_randomstr(self):
        "write randomstr to secret, confirm ref file exists, reveal and check"

        tag = "?{base64:ref/randomstr||randomstr}"
        REF_CONTROLLER[tag] = RefParams()
        # The file should exist in either location depending on implementation
        file_exists = os.path.isfile(
            os.path.join(REFS_HOME, "ref/base64")
        ) or os.path.isfile(os.path.join(REFS_HOME, "ref/randomstr"))
        self.assertTrue(file_exists)

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{base64:ref/randomstr}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(
            len(revealed), 43
        )  # default length of token_urlsafe() string is 43
        self.assertTrue(get_entropy(revealed) > 4)

        # Test with parameter nbytes=16, correlating with string length 16
        tag = "?{base64:ref/randomstr||randomstr:16}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 16)

    def test_ref_function_base64(self):
        "write randomstr to ref and base64, confirm ref file exists, reveal and check"

        tag = "?{base64:ref/base64||random:str|base64}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/base64")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{base64:ref/base64}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        # If the following succeeds, we guarantee that ref is base64-encoded
        self.assertEqual(
            base64.b64encode(base64.b64decode(revealed)).decode("UTF-8"), revealed
        )

    def test_ref_function_sha256(self):
        "write randomstr to ref and sha256, confirm ref file exists, reveal and check"

        tag = "?{base64:ref/sha256||random:str|sha256}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/sha256")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{base64:ref/sha256}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 64)
        try:
            int(revealed, 16)  # sha256 should convert to hex
        except ValueError:
            raise Exception("ref is not sha256 hash")

    # TODO write tests for RefController errors (lookups, etc..)

    def test_ref_function_random_loweralphanum(self):
        "write loweralphanum to secret, confirm ref file exists, reveal and check"

        tag = "?{plain:ref/loweralphanum||loweralphanum}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/loweralphanum")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{plain:ref/loweralphanum}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(
            len(revealed), 8
        )  # default length of loweralphanum string is 8

        # Test with parameter chars=16, correlating with string length 16
        tag = "?{plain:ref/loweralphanum||loweralphanum:16}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 16)

    def test_ref_function_random_upperalphanum(self):
        "write random:upperalphanum to secret, confirm ref file exists, reveal and check"

        tag = "?{plain:ref/upperalphanum||random:upperalphanum}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/upperalphanum")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{plain:ref/upperalphanum}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(
            len(revealed), 8
        )  # default length of upperalphanum string is 8

        # Test with parameter nchars=16, correlating with string length 16
        tag = "?{plain:ref/upperalphanum||random:upperalphanum:16}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 16)

    def test_ref_function_loweralpha(self):
        "write random:loweralpha to secret, confirm ref file exists, reveal and check"

        tag = "?{plain:ref/loweralpha||random:loweralpha}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/loweralpha")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{plain:ref/loweralpha}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 8)  # default length of loweralpha string is 8

        # Test with parameter nchars=16, correlating with string length 16
        tag = "?{plain:ref/loweralpha||random:loweralpha:16}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 16)

    def test_ref_function_upperalpha(self):
        "write random:upperalpha to secret, confirm ref file exists, reveal and check"

        tag = "?{plain:ref/upperalpha||random:upperalpha}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/upperalpha")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{plain:ref/upperalpha}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 8)  # default length of upperalpha string is 8

        # Test with parameter nchars=16, correlating with string length 16
        tag = "?{plain:ref/upperalpha||random:upperalpha:16}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 16)

    def test_ref_function_randomint(self):
        "write random:int to secret, confirm ref file exists, reveal and check"

        tag = "?{plain:ref/randomint||random:int}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/randomint")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{plain:ref/randomint}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 16)  # default length of randomint string is 16

        # Test with parameter nchars=32, correlating with string length 32
        tag = "?{plain:ref/randomint||random:int:32}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 32)

    def test_ref_function_special(self):
        "write random:special to secret, confirm ref file exists, reveal and check"
        tag = "?{plain:ref/special||random:special}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/special")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{plain:ref/special}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 8)  # default length of special string is 8

        # Test with parameter nchars=16, correlating with string length 16
        tag = "?{plain:ref/special||random:special:16}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 16)

        # Test with every allowed special char, nchars=32
        allowed_special_chars = "".join(set(string.punctuation).difference(":|"))
        tag = "?{plain:ref/special||random:special:32:" + allowed_special_chars + "}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 32)
        intersection = set(string.punctuation).intersection(revealed)
        self.assertTrue(intersection.issubset(set(allowed_special_chars)))

    def test_ref_function_basicauth(self):
        "write basicauth to secret, confirm ref file exists, reveal and check"
        tag = "?{plain:ref/basicauth||basicauth}"
        REF_CONTROLLER[tag] = RefParams()
        self.assertTrue(os.path.isfile(os.path.join(REFS_HOME, "ref/basicauth")))

        file_with_tags = tempfile.mktemp()
        with open(file_with_tags, "w") as fp:
            fp.write("?{plain:ref/basicauth}")
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(len(revealed), 24)  # default length of basicauth is 17

        # Test with parameters username=user123 and password=mysecretpassword
        tag = "?{plain:ref/basicauth||basicauth:user123:mysecretpassword}"
        REF_CONTROLLER[tag] = RefParams()
        REVEALER._reveal_tag_without_subvar.cache_clear()
        revealed = REVEALER.reveal_raw_file(file_with_tags)
        self.assertEqual(revealed, "dXNlcjEyMzpteXNlY3JldHBhc3N3b3Jk")

    def test_ref_dependency_ordering_rsa_keypair(self):
        """
        Test that RSA private and public key can be generated in a single compile.

        This tests the fix for https://github.com/kapicorp/kapitan/issues/749
        where attempting to create both keys in one compile would fail with:
        "|reveal function error: ... does not exist"

        The fix enables on-demand creation of dependencies in the reveal() function.
        """
        from cryptography.hazmat.backends import default_backend
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa

        # Simulate the exact scenario from the issue:
        # 1. Private key with ||rsa function
        # 2. Public key with ||reveal:path/to/privkey|publickey function
        # The public key depends on the private key existing first.
        test_obj = {
            "ssh_keys": {
                "private_key": "?{base64:test/keypair/private||rsa:2048}",
                "public_key": "?{base64:test/keypair/public||reveal:test/keypair/private|publickey}",
            }
        }

        # This should work without errors - compile_obj processes dictionary items
        # in order, so the private key is created before the public key is revealed
        REVEALER.compile_obj(test_obj)

        # Verify both references were created
        priv_tag = "?{base64:test/keypair/private||rsa:2048}"
        pub_tag = "?{base64:test/keypair/public||reveal:test/keypair/private|publickey}"

        priv_ref = REF_CONTROLLER[priv_tag]
        pub_ref = REF_CONTROLLER[pub_tag]

        # Verify the private key is valid RSA with correct key size
        priv_revealed = priv_ref.reveal()
        private_key = serialization.load_pem_private_key(
            priv_revealed.encode(), password=None, backend=default_backend()
        )
        self.assertEqual(private_key.key_size, 2048)

        # Verify the public key is valid and correctly derived from the private key
        pub_revealed = pub_ref.reveal()
        public_key = serialization.load_pem_public_key(
            pub_revealed.encode(), backend=default_backend()
        )
        # Verify it's an RSA public key
        self.assertIsInstance(public_key, rsa.RSAPublicKey)

        # Verify public key matches private key by comparing PEM representations
        expected_public = private_key.public_key()
        expected_pub_pem = expected_public.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode()
        self.assertEqual(pub_revealed, expected_pub_pem)

    def test_ref_dependency_ordering_rsa_keypair_reverse(self):
        """
        Test RSA keypair generation with public key defined BEFORE private key.

        This verifies that the dependency ordering is truly independent of definition order.
        """
        from cryptography.hazmat.backends import default_backend
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa

        # Define public key BEFORE private key (reverse order)
        test_obj = {
            "ssh_keys": {
                "public_key": "?{base64:test/keypair_rev/public||reveal:test/keypair_rev/private|publickey}",
                "private_key": "?{base64:test/keypair_rev/private||rsa:2048}",
            }
        }

        # This should work regardless of definition order
        REVEALER.compile_obj(test_obj)

        # Verify both references were created
        priv_tag = "?{base64:test/keypair_rev/private||rsa:2048}"
        pub_tag = "?{base64:test/keypair_rev/public||reveal:test/keypair_rev/private|publickey}"

        priv_ref = REF_CONTROLLER[priv_tag]
        pub_ref = REF_CONTROLLER[pub_tag]

        # Verify the keys are valid and match
        priv_revealed = priv_ref.reveal()
        private_key = serialization.load_pem_private_key(
            priv_revealed.encode(), password=None, backend=default_backend()
        )
        self.assertEqual(private_key.key_size, 2048)

        pub_revealed = pub_ref.reveal()
        public_key = serialization.load_pem_public_key(
            pub_revealed.encode(), backend=default_backend()
        )
        self.assertIsInstance(public_key, rsa.RSAPublicKey)

        # Verify public key matches private key
        expected_public = private_key.public_key()
        expected_pub_pem = expected_public.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode()
        self.assertEqual(pub_revealed, expected_pub_pem)

    def test_ref_dependency_ordering_ed25519_keypair(self):
        """
        Test that Ed25519 private and public key can be generated in a single compile.

        This tests the same dependency ordering fix as test_ref_dependency_ordering_rsa_keypair
        but with Ed25519 keys instead of RSA.
        """
        from cryptography.hazmat.backends import default_backend
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ed25519

        # Create Ed25519 keypair with dependency
        # 1. Private key with ||ed25519 function
        # 2. Public key with ||reveal:path/to/privkey|publickey function
        test_obj = {
            "signing_keys": {
                "private_key": "?{base64:test/ed25519/private||ed25519}",
                "public_key": "?{base64:test/ed25519/public||reveal:test/ed25519/private|publickey}",
            }
        }

        # This should work without errors - compile_obj processes in order
        REVEALER.compile_obj(test_obj)

        # Verify both references were created
        priv_tag = "?{base64:test/ed25519/private||ed25519}"
        pub_tag = "?{base64:test/ed25519/public||reveal:test/ed25519/private|publickey}"

        priv_ref = REF_CONTROLLER[priv_tag]
        pub_ref = REF_CONTROLLER[pub_tag]

        # Verify the private key is valid Ed25519
        priv_revealed = priv_ref.reveal()
        private_key = serialization.load_pem_private_key(
            priv_revealed.encode(), password=None, backend=default_backend()
        )
        self.assertIsInstance(private_key, ed25519.Ed25519PrivateKey)

        # Verify the public key is valid and correctly derived from the private key
        pub_revealed = pub_ref.reveal()
        public_key = serialization.load_pem_public_key(
            pub_revealed.encode(), backend=default_backend()
        )
        self.assertIsInstance(public_key, ed25519.Ed25519PublicKey)

        # Verify public key matches private key by comparing PEM representations
        expected_public = private_key.public_key()
        expected_pub_pem = expected_public.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode()
        self.assertEqual(pub_revealed, expected_pub_pem)

    def test_ref_dependency_ordering_ed25519_keypair_reverse(self):
        """
        Test Ed25519 keypair with public key defined BEFORE private key.

        This verifies that the dependency ordering is truly independent of definition order.
        """
        from cryptography.hazmat.backends import default_backend
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ed25519

        # Define public key BEFORE private key (reverse order)
        test_obj = {
            "signing_keys": {
                "public_key": "?{base64:test/ed25519_rev/public||reveal:test/ed25519_rev/private|publickey}",
                "private_key": "?{base64:test/ed25519_rev/private||ed25519}",
            }
        }

        # This should work regardless of definition order
        REVEALER.compile_obj(test_obj)

        # Verify both references were created
        priv_tag = "?{base64:test/ed25519_rev/private||ed25519}"
        pub_tag = "?{base64:test/ed25519_rev/public||reveal:test/ed25519_rev/private|publickey}"

        priv_ref = REF_CONTROLLER[priv_tag]
        pub_ref = REF_CONTROLLER[pub_tag]

        # Verify the keys are valid and match
        priv_revealed = priv_ref.reveal()
        private_key = serialization.load_pem_private_key(
            priv_revealed.encode(), password=None, backend=default_backend()
        )
        self.assertIsInstance(private_key, ed25519.Ed25519PrivateKey)

        pub_revealed = pub_ref.reveal()
        public_key = serialization.load_pem_public_key(
            pub_revealed.encode(), backend=default_backend()
        )
        self.assertIsInstance(public_key, ed25519.Ed25519PublicKey)

        # Verify public key matches private key
        expected_public = private_key.public_key()
        expected_pub_pem = expected_public.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode()
        self.assertEqual(pub_revealed, expected_pub_pem)

    def test_ref_dependency_ordering_multiple_dependencies(self):
        """
        Test that multi-level dependency chains are resolved correctly.

        This verifies that the recursive on-demand creation works through
        multiple levels: base -> derived1 -> derived2
        Each level depends on the previous one being created first.
        """
        import hashlib

        # Create a 3-level dependency chain:
        # base: random string (no dependencies)
        # derived1: sha256(reveal(base)) - depends on base
        # derived2: sha256(reveal(derived1)) - depends on derived1, which depends on base
        test_obj = {
            "secrets": {
                "base": "?{base64:test/chain/base||random:str:16}",
                "derived1": "?{base64:test/chain/derived1||reveal:test/chain/base|sha256}",
                "derived2": "?{base64:test/chain/derived2||reveal:test/chain/derived1|sha256}",
            }
        }

        # All dependencies should be created during compilation
        REVEALER.compile_obj(test_obj)

        # Verify all three references were created
        base_ref = REF_CONTROLLER["?{base64:test/chain/base||random:str:16}"]
        derived1_ref = REF_CONTROLLER[
            "?{base64:test/chain/derived1||reveal:test/chain/base|sha256}"
        ]
        derived2_ref = REF_CONTROLLER[
            "?{base64:test/chain/derived2||reveal:test/chain/derived1|sha256}"
        ]

        # Verify the dependency chain is correctly resolved
        base_val = base_ref.reveal()
        derived1_val = derived1_ref.reveal()
        derived2_val = derived2_ref.reveal()

        # derived1 should be sha256(":base_val") - kapitan sha256 uses salt format
        expected_derived1 = hashlib.sha256(f":{base_val}".encode()).hexdigest()
        self.assertEqual(derived1_val, expected_derived1)

        # derived2 should be sha256(":derived1_val")
        expected_derived2 = hashlib.sha256(f":{derived1_val}".encode()).hexdigest()
        self.assertEqual(derived2_val, expected_derived2)

    def test_ref_dependency_ordering_multiple_dependencies_reverse(self):
        """
        Test multi-level dependency chain with REVERSE definition order.

        This verifies that dependencies are resolved regardless of definition order:
        derived2 -> derived1 -> base (reverse of dependency chain)
        """
        import hashlib

        # Define in REVERSE order: derived2 first, then derived1, then base
        test_obj = {
            "secrets": {
                "derived2": "?{base64:test/chain_rev/derived2||reveal:test/chain_rev/derived1|sha256}",
                "derived1": "?{base64:test/chain_rev/derived1||reveal:test/chain_rev/base|sha256}",
                "base": "?{base64:test/chain_rev/base||random:str:16}",
            }
        }

        # All dependencies should be created regardless of definition order
        REVEALER.compile_obj(test_obj)

        # Verify all three references were created
        base_ref = REF_CONTROLLER["?{base64:test/chain_rev/base||random:str:16}"]
        derived1_ref = REF_CONTROLLER[
            "?{base64:test/chain_rev/derived1||reveal:test/chain_rev/base|sha256}"
        ]
        derived2_ref = REF_CONTROLLER[
            "?{base64:test/chain_rev/derived2||reveal:test/chain_rev/derived1|sha256}"
        ]

        # Verify the dependency chain is correctly resolved
        base_val = base_ref.reveal()
        derived1_val = derived1_ref.reveal()
        derived2_val = derived2_ref.reveal()

        # derived1 should be sha256(":base_val")
        expected_derived1 = hashlib.sha256(f":{base_val}".encode()).hexdigest()
        self.assertEqual(derived1_val, expected_derived1)

        # derived2 should be sha256(":derived1_val")
        expected_derived2 = hashlib.sha256(f":{derived1_val}".encode()).hexdigest()
        self.assertEqual(derived2_val, expected_derived2)

    def test_ref_dependency_ordering_complex_object(self):
        """
        Test dependency ordering with nested objects and lists
        """
        test_obj = {
            "level1": {
                "keys": [
                    {
                        "private": "?{base64:test/complex/key1||rsa:2048}",
                        "public": "?{base64:test/complex/pub1||reveal:test/complex/key1|publickey}",
                    },
                    {
                        "private": "?{base64:test/complex/key2||rsa:2048}",
                        "public": "?{base64:test/complex/pub2||reveal:test/complex/key2|publickey}",
                    },
                ],
                "level2": {
                    "base_secret": "?{base64:test/complex/base||random:str}",
                    "derived": "?{base64:test/complex/derived||reveal:test/complex/base|sha256}",
                },
            }
        }

        # Should compile without errors
        REVEALER.compile_obj(test_obj)

        # Verify all refs were created
        key1_priv = REF_CONTROLLER["?{base64:test/complex/key1||rsa:2048}"]
        key1_pub = REF_CONTROLLER[
            "?{base64:test/complex/pub1||reveal:test/complex/key1|publickey}"
        ]
        key2_priv = REF_CONTROLLER["?{base64:test/complex/key2||rsa:2048}"]
        key2_pub = REF_CONTROLLER[
            "?{base64:test/complex/pub2||reveal:test/complex/key2|publickey}"
        ]

        # Verify they exist
        self.assertIsNotNone(key1_priv)
        self.assertIsNotNone(key1_pub)
        self.assertIsNotNone(key2_priv)
        self.assertIsNotNone(key2_pub)
