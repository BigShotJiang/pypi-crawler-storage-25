import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Box, Text } from 'ink';
import {
  createSession, deleteSession, fetchConfig, fetchProviders,
  fetchSession, fetchSessions, fetchVersion, Session, ProviderInfo,
} from './api.js';
import { SessionList } from './SessionList.js';
import { ChatView } from './ChatView.js';
import { ModelSelect } from './ModelSelect.js';
import { ProviderSelect } from './ProviderSelect.js';
import { ProviderConfig } from './ProviderConfig.js';
import { ConfigPanel } from './ConfigPanel.js';
import { Onboarding } from './Onboarding.js';
import { ChatMessage, Phase, Modal } from './types.js';

// ── App state machine ──────────────────────────────────────────────────────────
//
//  Phase (base screen):   loading → onboarding | sessions | chat
//  Modal (overlay):       null | model-select | provider-select | provider-config | config
//
//  Transitions:
//    loading  →  onboarding      (no provider authenticated)
//    loading  →  sessions        (provider exists)
//    sessions →  chat            (open / new session)
//    any      →  modal           (open overlay)
//    modal    →  null            (close overlay, return to base phase)
//
// ─────────────────────────────────────────────────────────────────────────────

export function App() {
  const [phase, setPhase]       = useState<Phase>({ tag: 'loading', retries: 0 });
  const [modal, setModal]       = useState<Modal>(null);
  const [providers, setProviders] = useState<ProviderInfo[]>([]);
  const [sessions, setSessions]   = useState<Session[]>([]);
  const [version, setVersion]     = useState('');

  // Stable ref: sessions list for callbacks that close over stale state
  const sessionsRef = useRef<Session[]>([]);
  useEffect(() => { sessionsRef.current = sessions; }, [sessions]);

  // ── helpers ──────────────────────────────────────────────────────────────────

  function updateChatPhase(update: Partial<Extract<Phase, { tag: 'chat' }>>) {
    setPhase(p => p.tag === 'chat' ? { ...p, ...update } : p);
  }

  function currentModel(): { model: string; provider: string } {
    if (phase.tag === 'chat') return { model: phase.model, provider: phase.provider };
    return { model: '', provider: '' };
  }

  // ── init: connect to server ───────────────────────────────────────────────────

  useEffect(() => {
    let cancelled = false;
    let retries = 0;

    async function init() {
      while (!cancelled) {
        try {
          const [cfg, sess, provs, ver] = await Promise.all([
            fetchConfig(), fetchSessions(), fetchProviders(), fetchVersion(),
          ]);
          if (cancelled) return;

          const provList = provs.providers ?? [];
          setProviders(provList);
          setVersion(ver);
          setSessions(sess);

          const autoSession = process.env['CODRNINJA_SESSION'];
          if (autoSession) {
            const exists = sess.find(s => s.name === autoSession);
            if (!exists) await createSession(autoSession);
            await openSession(autoSession, provList, cfg);
          } else if (!provList.some(p => p.authenticated)) {
            setPhase({ tag: 'onboarding' });
          } else {
            setPhase({ tag: 'sessions' });
          }
          return;

        } catch {
          retries++;
          if (!cancelled) {
            setPhase({ tag: 'loading', retries });
          }
          await new Promise(r => setTimeout(r, 3000));
        }
      }
    }

    void init();
    return () => { cancelled = true; };
  }, []);  // eslint-disable-line react-hooks/exhaustive-deps

  // ── session open ─────────────────────────────────────────────────────────────

  const openSession = useCallback(async (
    name: string,
    providerList?: ProviderInfo[],
    cfg?: Record<string, unknown>,
  ) => {
    try {
      const [data, config] = await Promise.all([
        fetchSession(name),
        cfg ? Promise.resolve(cfg as Record<string, string>) : fetchConfig(),
      ]);
      const pList = providerList ?? providers;

      const msgs: ChatMessage[] = (data.messages ?? [])
        .filter(m => m.role === 'user' || m.role === 'assistant')
        .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));

      const sess = sessionsRef.current.find(s => s.name === name);
      const model    = (sess?.model    || String(config['model']    || ''));
      const provider = (sess?.provider || String(config['provider'] || ''));

      setPhase({
        tag: 'chat',
        session: name,
        history: msgs,
        model,
        provider,
        permMode: String(config['permissions_mode'] ?? 'ask'),
        running: sess?.running ?? false,
      });
    } catch {
      // Even on error, open chat with empty history — let user try
      setPhase({
        tag: 'chat',
        session: name,
        history: [],
        model: '',
        provider: '',
        permMode: 'ask',
        running: false,
      });
    }
  }, [providers]);

  // ── session management ────────────────────────────────────────────────────────

  async function newSession(name: string) {
    try {
      await createSession(name);
      const [sess] = await Promise.all([fetchSessions()]);
      setSessions(sess);
      await openSession(name);
    } catch { /* server error — ignore, user will see empty session */ }
  }

  function backToSessions() {
    setModal(null);
    setPhase({ tag: 'sessions' });
    fetchSessions()
      .then(sess => { setSessions(sess); })
      .catch(() => {});
  }

  async function handleDeleteSession(name: string) {
    try {
      await deleteSession(name);
      fetchSessions().then(setSessions).catch(() => {});
    } catch { /* ignore */ }
  }

  // ── model selection ───────────────────────────────────────────────────────────

  function openModelSelect() {
    setModal({ type: 'model-select' });
  }

  function onModelSelected(model: string, provider: string) {
    // Always update both model+provider atomically inside chat phase
    updateChatPhase({ model, provider });
    setModal(null);
  }

  // ── provider management ───────────────────────────────────────────────────────

  function openProviderSelect() {
    setModal({ type: 'provider-select' });
  }

  function onProviderChosen(p: ProviderInfo) {
    setModal({ type: 'provider-config', providerName: p.name });
  }

  function onProviderConfigDone(newProvider: string, newModel?: string) {
    // Mark provider as authenticated in local state (optimistic)
    setProviders(ps => ps.map(p =>
      p.name === newProvider
        ? { ...p, authenticated: true, active: true }
        : { ...p, active: false }
    ));

    if (phase.tag === 'chat') {
      updateChatPhase({
        provider: newProvider,
        ...(newModel ? { model: newModel } : {}),
      });
    } else if (newModel) {
      // After onboarding: navigate to sessions
      setPhase({ tag: 'sessions' });
    } else {
      setPhase({ tag: 'sessions' });
    }
    setModal(null);

    // Refresh sessions list
    fetchSessions().then(setSessions).catch(() => {});
  }

  // ── config panel ──────────────────────────────────────────────────────────────

  function openConfig() {
    setModal({ type: 'config' });
  }

  // ── render ────────────────────────────────────────────────────────────────────

  // Loading screen
  if (phase.tag === 'loading') {
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text dimColor>Connecting to server…</Text>
        {phase.retries > 0 && (
          <Box marginTop={1}>
            <Text color="yellow">Still trying… ({phase.retries}s elapsed)</Text>
          </Box>
        )}
      </Box>
    );
  }

  // Error screen (permanent failure)
  if (phase.tag === 'error') {
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text bold color="red">Connection failed</Text>
        <Text>{phase.msg}</Text>
      </Box>
    );
  }

  // Modal overlays (render on top of any base phase)
  if (modal?.type === 'model-select') {
    const { model, provider } = currentModel();
    return (
      <ModelSelect
        currentModel={model}
        currentProvider={provider}
        providers={providers}
        sessionName={phase.tag === 'chat' ? phase.session : undefined}
        onSelect={onModelSelected}
        onCancel={() => setModal(null)}
      />
    );
  }

  if (modal?.type === 'provider-select') {
    return (
      <ProviderSelect
        onSelect={onProviderChosen}
        onCancel={() => setModal(null)}
      />
    );
  }

  if (modal?.type === 'provider-config') {
    const provider = providers.find(p => p.name === modal.providerName);
    if (!provider) { setModal(null); return null; }
    return (
      <ProviderConfig
        provider={provider}
        onDone={onProviderConfigDone}
        onCancel={() => setModal(null)}
      />
    );
  }

  if (modal?.type === 'config') {
    return (
      <ConfigPanel
        providers={providers}
        onDone={() => setModal(null)}
      />
    );
  }

  // Base phases

  if (phase.tag === 'onboarding') {
    return (
      <Onboarding
        providers={providers}
        onSetup={onProviderChosen}
      />
    );
  }

  if (phase.tag === 'chat') {
    return (
      <ChatView
        sessionName={phase.session}
        history={phase.history}
        onBack={backToSessions}
        onOpenModelSelect={openModelSelect}
        onOpenProviderSelect={openProviderSelect}
        onOpenConfig={openConfig}
        provider={phase.provider}
        model={phase.model}
        permissionsMode={phase.permMode}
        initiallyRunning={phase.running}
      />
    );
  }

  // sessions (default)
  return (
    <SessionList
      sessions={sessions}
      onSelect={name => void openSession(name)}
      onNew={newSession}
      onDelete={handleDeleteSession}
      version={version}
      providers={providers}
      currentModel={''}
      currentProvider={''}
    />
  );
}
