import React, { useEffect, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { fetchModelPrefs, fetchModels, saveModelPrefs, ProviderInfo } from './api.js';
import { PROVIDER_MODELS, PROVIDER_ORDER, PROVIDER_COLORS, KnownModel } from './models.js';
import { C } from './styles.js';

interface Props {
  providers: ProviderInfo[];
  onDone: () => void;
}

interface Row {
  provider: string;
  model: KnownModel;
}

export function ConfigPanel({ providers, onDone }: Props) {
  const [rows, setRows]       = useState<Row[]>([]);
  const [enabled, setEnabled] = useState<Record<string, string[]>>({});
  const [idx, setIdx]         = useState(0);
  const [saving, setSaving]   = useState(false);
  const [loading, setLoading] = useState(true);
  const [dirty, setDirty]     = useState(false);

  const authProviders = PROVIDER_ORDER.filter(p =>
    providers.some(pi => pi.name === p && pi.authenticated)
  );

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const [prefs, serverModels] = await Promise.all([
          fetchModelPrefs(),
          fetchModels(),
        ]);
        if (cancelled) return;

        // Build rows: curated lists + dynamic (ollama/openrouter from server)
        const built: Row[] = [];
        for (const p of authProviders) {
          let known = PROVIDER_MODELS[p] ?? [];
          if ((p === 'ollama' || p === 'openrouter') && serverModels.models.length > 0) {
            // Use models from server for dynamic providers
            const dynamic = serverModels.models
              .filter(m => !m.includes('|') || true)  // include all
              .map(m => {
                const i = m.indexOf('|');
                return { id: i >= 0 ? m.slice(i + 1) : m, label: i >= 0 ? m.slice(0, i).trim() : m, ctx: '' };
              });
            known = dynamic;
          }
          for (const model of known) {
            built.push({ provider: p, model });
          }
        }

        setRows(built);
        setEnabled(prefs);
        setLoading(false);
      } catch {
        if (!cancelled) setLoading(false);
      }
    }

    void load();
    return () => { cancelled = true; };
  }, []);  // eslint-disable-line react-hooks/exhaustive-deps

  function isEnabled(provider: string, modelId: string): boolean {
    const list = enabled[provider];
    if (!list || list.length === 0) return true; // empty = all enabled
    return list.includes(modelId);
  }

  function toggle(provider: string, modelId: string) {
    setEnabled(prev => {
      const prevList = prev[provider] ?? [];
      const allIds = (PROVIDER_MODELS[provider] ?? rows.filter(r => r.provider === provider).map(r => r.model)).map(m => typeof m === 'string' ? m : m.id);

      let next: string[];
      if (prevList.length === 0) {
        // Currently "all enabled" — disable this one = enable all except this
        next = allIds.filter(id => id !== modelId);
      } else if (prevList.includes(modelId)) {
        next = prevList.filter(id => id !== modelId);
      } else {
        next = [...prevList, modelId];
      }
      // If all are selected, normalize back to [] (all enabled)
      if (next.length === allIds.length) next = [];
      return { ...prev, [provider]: next };
    });
    setDirty(true);
  }

  async function save() {
    setSaving(true);
    try {
      // Clean up empty arrays before saving
      const clean: Record<string, string[]> = {};
      for (const [p, list] of Object.entries(enabled)) {
        if (list.length > 0) clean[p] = list;
      }
      await saveModelPrefs(clean);
    } finally {
      setSaving(false);
      onDone();
    }
  }

  useInput((input, key) => {
    if (saving || loading) return;
    if (key.escape) { onDone(); return; }
    if (key.upArrow)   setIdx(i => Math.max(0, i - 1));
    if (key.downArrow) setIdx(i => Math.min(rows.length - 1, i + 1));
    if (input === ' ' && rows[idx]) toggle(rows[idx]!.provider, rows[idx]!.model.id);
    if (key.return || input === 's') void save();
  });

  if (loading) {
    return <Box paddingX={2}><Text dimColor>Loading…</Text></Box>;
  }

  // Group rows for rendering (show provider headers)
  let lastProvider = '';

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color={C.acc}> CONFIG — Model List</Text>
      <Text color={C.dim}> Toggle which models appear in /model selection.</Text>
      <Text color={C.dim}> {'─'.repeat(60)}</Text>

      <Box flexDirection="column" marginTop={1}>
        {rows.map((row, i) => {
          const showHeader = row.provider !== lastProvider;
          lastProvider = row.provider;
          const sel  = i === idx;
          const on   = isEnabled(row.provider, row.model.id);
          const col  = PROVIDER_COLORS[row.provider] ?? C.dim;

          return (
            <React.Fragment key={`${row.provider}/${row.model.id}`}>
              {showHeader && (
                <Box marginTop={1}>
                  <Text color={col} bold>  {row.provider.toUpperCase()}</Text>
                </Box>
              )}
              <Box>
                <Text color={sel ? C.acc : C.dim}>{sel ? '  ▶ ' : '    '}</Text>
                <Text color={on ? C.grn : '#3a3a52'}>{on ? '✓ ' : '○ '}</Text>
                <Box minWidth={28}>
                  <Text color={sel ? C.wh : (on ? C.txt : C.dim)} bold={sel}>
                    {row.model.label}
                  </Text>
                </Box>
                {row.model.ctx ? (
                  <Text color={sel ? C.dim : '#2a2a3e'}>{row.model.ctx}</Text>
                ) : null}
              </Box>
            </React.Fragment>
          );
        })}
      </Box>

      {rows.length === 0 && (
        <Text color={C.dim}>  No models available. Connect a provider first.</Text>
      )}

      <Text color={C.dim}> {'─'.repeat(60)}</Text>
      <Box gap={3} marginTop={1}>
        <Box><Text color={C.dim}>↑↓ </Text><Text color={C.acc}>navigate</Text></Box>
        <Box><Text color={C.dim}>Space </Text><Text color={C.acc}>toggle</Text></Box>
        <Box><Text color={C.dim}>Enter/s </Text><Text color={dirty ? C.grn : C.acc}>save</Text></Box>
        <Box><Text color={C.dim}>Esc </Text><Text color={C.acc}>cancel</Text></Box>
      </Box>
      {saving && <Text color={C.dim}> Saving…</Text>}
    </Box>
  );
}
