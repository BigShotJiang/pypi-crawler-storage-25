import React, { useEffect, useRef, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import {
  configureOllama, ProviderInfo, setActiveProvider, setApiKey,
  streamOpenAIOAuth, loadOpenAICredentials, loadAnthropicCredentials, OAuthEvent,
  fetchOllamaServers, addOllamaServer, removeOllamaServer, toggleOllamaServer, OllamaServer,
  submitOAuthCallback,
} from './api.js';

interface Props {
  provider: ProviderInfo;
  onDone: (newProvider: string, newModel?: string) => void;
  onCancel: () => void;
}

// ── shared OAuth browser-waiting screen ──────────────────────────────────────

function OAuthRunning({ providerName, authUrl, urlFile, onCancel }: { providerName: string; authUrl?: string; urlFile?: string | null; onCancel: () => void }) {
  const [dots, setDots] = useState('');
  const [input, setInput] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setDots((d) => d.length >= 3 ? '' : d + '.'), 500);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (!authUrl) return;
    // OSC 52: copies to clipboard in any modern terminal, including over SSH
    const b64 = Buffer.from(authUrl).toString('base64');
    process.stdout.write(`\x1b]52;c;${b64}\x07`);
    setCopied(true);
  }, [authUrl]);

  useInput((ch, key) => {
    if (key.escape) { onCancel(); return; }
    if (key.return && input.trim()) {
      submitOAuthCallback('openai', input.trim()).catch(() => {});
      setInput('');
      return;
    }
    if (key.backspace || key.delete) setInput((s) => s.slice(0, -1));
    else if (ch && !key.ctrl && !key.meta) setInput((s) => s + ch);
  });
  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color="cyan"> {providerName} OAuth</Text>
      <Text dimColor> ──────────────────────────────</Text>
      <Text color="yellow"> Browser opened{dots}</Text>
      <Text dimColor> Log in and authorize codrninja in your browser.</Text>
      {authUrl
        ? <Text color="green"> {copied ? '✓ Auth URL copied to clipboard' : 'Auth URL ready'}</Text>
        : <Text dimColor> Waiting for auth URL…</Text>
      }
      {authUrl && urlFile && (
        <Text dimColor>  (fallback: cat {urlFile})</Text>
      )}
      <Box marginTop={1}><Text dimColor> After login, paste the redirect URL from the browser:</Text></Box>
      <Box borderStyle="round" borderColor={input ? 'cyan' : '#444444'}>
        <Text color={input ? 'white' : '#555555'}> {input || 'http://localhost:1455/auth/callback?code=…'}</Text>
      </Box>
      <Box marginTop={1}><Text dimColor>{input ? ' enter to submit  ' : ' '}esc to cancel</Text></Box>
    </Box>
  );
}

// ── OpenAI — 3 methods: OAuth (browser) | Credentials | API Key ──────────────

function OpenAIConfig({ onDone, onCancel }: Props) {
  type Screen = 'method' | 'oauth-running' | 'credentials-loading' | 'apikey';
  const [screen, setScreen] = useState<Screen>('method');
  const [methodIdx, setMethodIdx] = useState(0);
  const [apiKey, setApiKey_] = useState('');
  const [error, setError] = useState('');
  const [authUrl, setAuthUrl] = useState<string | undefined>();
  const [urlFile, setUrlFile] = useState<string | null | undefined>();
  const cancelOAuth = useRef<(() => void) | null>(null);

  const METHODS = [
    'OAuth  (browser login)',
    'Credentials  (~/.codrninja/auth.json)',
    'API Key  (paste sk-…)',
  ];

  useEffect(() => () => { cancelOAuth.current?.(); }, []);

  function startOAuth() {
    setScreen('oauth-running');
    setAuthUrl(undefined);
    setUrlFile(undefined);
    setError('');
    const cancel = streamOpenAIOAuth(
      (e: OAuthEvent) => {
        if (e.type === 'url') { setAuthUrl(e.url); setUrlFile(e.url_file); }
        else if (e.type === 'success') setActiveProvider('openai').finally(() => onDone('openai'));
        else if (e.type === 'error') { setError(e.error); setScreen('method'); }
      },
      () => { /* done */ },
    );
    cancelOAuth.current = cancel;
  }

  function loadCredentials() {
    setScreen('credentials-loading');
    setError('');
    loadOpenAICredentials()
      .then((res) => {
        if (res.success) {
          setActiveProvider('openai').finally(() => onDone('openai'));
        } else {
          setError(res.error ?? 'Failed to load credentials');
          setScreen('method');
        }
      })
      .catch((e: unknown) => { setError(String(e)); setScreen('method'); });
  }

  useInput((ch, key) => {
    if (screen === 'oauth-running' || screen === 'credentials-loading') return;

    if (key.escape) {
      if (screen === 'method') { onCancel(); return; }
      setScreen('method'); setError(''); return;
    }

    if (screen === 'method') {
      if (key.upArrow)   setMethodIdx((i) => Math.max(0, i - 1));
      if (key.downArrow) setMethodIdx((i) => Math.min(METHODS.length - 1, i + 1));
      if (key.return) {
        if (methodIdx === 0) startOAuth();
        else if (methodIdx === 1) loadCredentials();
        else setScreen('apikey');
      }
      return;
    }

    if (screen === 'apikey') {
      if (key.return) {
        const k = apiKey.trim();
        if (!k) { setError('API key cannot be empty'); return; }
        setApiKey('openai', k)
          .then(() => setActiveProvider('openai'))
          .then(() => onDone('openai'))
          .catch((e: unknown) => setError(String(e)));
        return;
      }
      if (key.backspace || key.delete) setApiKey_((s) => s.slice(0, -1));
      else if (ch && !key.ctrl && !key.meta) setApiKey_((s) => s + ch);
    }
  });

  if (screen === 'oauth-running') {
    return <OAuthRunning providerName="OpenAI" authUrl={authUrl} urlFile={urlFile} onCancel={() => { cancelOAuth.current?.(); setScreen('method'); }} />;
  }

  if (screen === 'credentials-loading') {
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text bold color="cyan"> OpenAI Credentials</Text>
        <Text dimColor> ──────────────────────────────</Text>
        <Text color="yellow"> Reading ~/.codrninja/auth.json…</Text>
      </Box>
    );
  }

  if (screen === 'method') {
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text bold color="cyan"> Configure OpenAI</Text>
        <Text dimColor> ──────────────────────────────</Text>
        <Text dimColor> Choose authentication method:</Text>
        <Box flexDirection="column" marginTop={1}>
          {METHODS.map((m, i) => (
            <Box key={m}>
              <Text color={i === methodIdx ? 'cyan' : undefined} bold={i === methodIdx}>
                {i === methodIdx ? ' ❯ ' : '   '}{m}
              </Text>
            </Box>
          ))}
        </Box>
        {error && <Text color="red"> {error}</Text>}
        <Box marginTop={1}><Text dimColor> ↑↓ navigate  enter select  esc cancel</Text></Box>
      </Box>
    );
  }

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color="cyan"> OpenAI API Key</Text>
      <Text dimColor> ──────────────────────────────</Text>
      <Text dimColor> Paste your API key (sk-… or sk-proj-…):</Text>
      <Box borderStyle="round" borderColor="cyan" marginTop={1}>
        <Text> {apiKey.replace(/./g, '•')}<Text color="cyan">_</Text></Text>
      </Box>
      {error && <Text color="red"> {error}</Text>}
      <Text dimColor> enter save  esc back</Text>
    </Box>
  );
}

// ── Anthropic — 2 methods: Credentials | API Key ─────────────────────────────

function AnthropicConfig({ onDone, onCancel }: Props) {
  type Screen = 'method' | 'credentials-loading' | 'apikey';
  const [screen, setScreen] = useState<Screen>('method');
  const [methodIdx, setMethodIdx] = useState(0);
  const [apiKey, setApiKey_] = useState('');
  const [error, setError] = useState('');

  const METHODS = [
    'Credentials  (~/.claude/.credentials.json)',
    'API Key  (paste sk-ant-…)',
  ];

  function loadCredentials() {
    setScreen('credentials-loading');
    setError('');
    loadAnthropicCredentials()
      .then((res) => {
        if (res.success) {
          setActiveProvider('anthropic').finally(() => onDone('anthropic'));
        } else {
          setError(res.error ?? 'Failed to load credentials');
          setScreen('method');
        }
      })
      .catch((e: unknown) => { setError(String(e)); setScreen('method'); });
  }

  useInput((ch, key) => {
    if (screen === 'credentials-loading') return;

    if (key.escape) {
      if (screen === 'method') { onCancel(); return; }
      setScreen('method'); setError(''); return;
    }

    if (screen === 'method') {
      if (key.upArrow)   setMethodIdx((i) => Math.max(0, i - 1));
      if (key.downArrow) setMethodIdx((i) => Math.min(METHODS.length - 1, i + 1));
      if (key.return) {
        if (methodIdx === 0) loadCredentials();
        else setScreen('apikey');
      }
      return;
    }

    if (screen === 'apikey') {
      if (key.return) {
        const k = apiKey.trim();
        if (!k) { setError('API key cannot be empty'); return; }
        setApiKey('anthropic', k)
          .then(() => setActiveProvider('anthropic'))
          .then(() => onDone('anthropic'))
          .catch((e: unknown) => setError(String(e)));
        return;
      }
      if (key.backspace || key.delete) setApiKey_((s) => s.slice(0, -1));
      else if (ch && !key.ctrl && !key.meta) setApiKey_((s) => s + ch);
    }
  });

  if (screen === 'credentials-loading') {
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text bold color="cyan"> Anthropic Credentials</Text>
        <Text dimColor> ──────────────────────────────</Text>
        <Text color="yellow"> Reading ~/.claude/.credentials.json…</Text>
      </Box>
    );
  }

  if (screen === 'method') {
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text bold color="cyan"> Configure Anthropic</Text>
        <Text dimColor> ──────────────────────────────</Text>
        <Text dimColor> Choose authentication method:</Text>
        <Box flexDirection="column" marginTop={1}>
          {METHODS.map((m, i) => (
            <Box key={m}>
              <Text color={i === methodIdx ? 'cyan' : undefined} bold={i === methodIdx}>
                {i === methodIdx ? ' ❯ ' : '   '}{m}
              </Text>
            </Box>
          ))}
        </Box>
        {error && <Text color="red"> {error}</Text>}
        <Box marginTop={1}><Text dimColor> ↑↓ navigate  enter select  esc cancel</Text></Box>
      </Box>
    );
  }

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color="cyan"> Anthropic API Key</Text>
      <Text dimColor> ──────────────────────────────</Text>
      <Text dimColor> Paste your Anthropic API key (sk-ant-…):</Text>
      <Box borderStyle="round" borderColor="cyan" marginTop={1}>
        <Text> {apiKey.replace(/./g, '•')}<Text color="cyan">_</Text></Text>
      </Box>
      {error && <Text color="red"> {error}</Text>}
      <Text dimColor> enter save  esc back</Text>
    </Box>
  );
}

// ── Ollama ────────────────────────────────────────────────────────────────────

function OllamaConfig({ onDone, onCancel }: Props) {
  type Step = 'list' | 'add-url' | 'connecting' | 'removing';
  const [step, setStep] = useState<Step>('list');
  const [servers, setServers] = useState<OllamaServer[]>([]);
  const [serverIdx, setServerIdx] = useState(0);
  const [newUrl, setNewUrl] = useState('http://localhost:11434');
  const [error, setError] = useState('');
  const [loadingServers, setLoadingServers] = useState(true);

  function reload() {
    setLoadingServers(true);
    fetchOllamaServers()
      .then((data) => {
        const list = data?.servers ?? [];
        setServers(list);
        setServerIdx((i) => Math.min(i, Math.max(0, list.length - 1)));
      })
      .catch(() => {})
      .finally(() => setLoadingServers(false));
  }

  useEffect(() => { reload(); }, []);

  useInput((ch, key) => {
    if (key.escape) {
      if (step === 'add-url') { setStep('list'); setError(''); return; }
      onCancel();
      return;
    }

    if (step === 'connecting' || step === 'removing') return;

    if (step === 'add-url') {
      if (key.return) {
        const url = newUrl.trim();
        if (!url) return;
        setStep('connecting');
        setError('');
        addOllamaServer(url)
          .then(() => { reload(); setNewUrl('http://localhost:11434'); setStep('list'); })
          .catch((e: unknown) => { setError(String(e)); setStep('add-url'); });
        return;
      }
      if (key.backspace || key.delete) setNewUrl((s) => s.slice(0, -1));
      else if (ch && !key.ctrl && !key.meta) setNewUrl((s) => s + ch);
      return;
    }

    // list step
    if (key.upArrow)   setServerIdx((i) => Math.max(0, i - 1));
    if (key.downArrow) setServerIdx((i) => Math.min(servers.length - 1, i + 1));

    if (ch === 'a') { setStep('add-url'); setError(''); return; }

    if (ch === 't' || ch === ' ') {
      const s = servers[serverIdx];
      if (s) {
        toggleOllamaServer(s.url).then(() => reload()).catch(() => {});
      }
      return;
    }

    if (ch === 'd') {
      const s = servers[serverIdx];
      if (s) {
        setStep('removing');
        removeOllamaServer(s.url)
          .then(() => { reload(); setStep('list'); })
          .catch(() => setStep('list'));
      }
      return;
    }

    if (key.return) {
      setActiveProvider('ollama').then(() => onDone('ollama')).catch(() => onDone('ollama'));
    }
  });

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color="cyan"> Configure Ollama</Text>
      <Text dimColor> ──────────────────────────────</Text>

      {step === 'connecting' && <Text color="yellow"> Adding server…</Text>}
      {step === 'removing'   && <Text color="yellow"> Removing server…</Text>}

      {(step === 'list' || step === 'add-url') && (
        <Box flexDirection="column">
          {loadingServers ? (
            <Text dimColor> Loading servers…</Text>
          ) : servers.length === 0 ? (
            <Text dimColor> No servers configured. Press a to add one.</Text>
          ) : (
            <Box flexDirection="column" marginBottom={1}>
              {servers.map((s, i) => {
                const sel = step === 'list' && i === serverIdx;
                const activeLabel = s.active ? <Text color="green"> [active]</Text> : <Text dimColor> [off]</Text>;
                const onlineLabel = s.online ? <Text color="green"> online</Text> : <Text color="red"> offline</Text>;
                return (
                  <Box key={s.url}>
                    <Text color={sel ? 'cyan' : undefined} bold={sel}>
                      {sel ? ' ❯ ' : '   '}{s.url}
                    </Text>
                    {activeLabel}
                    {onlineLabel}
                    {s.online && <Text dimColor>  {s.models.length} model{s.models.length !== 1 ? 's' : ''}</Text>}
                  </Box>
                );
              })}
            </Box>
          )}

          {step === 'add-url' && (
            <Box flexDirection="column" marginTop={1}>
              <Text dimColor> New server URL:</Text>
              <Box borderStyle="round" borderColor="cyan">
                <Text> {newUrl}<Text color="cyan">_</Text></Text>
              </Box>
              {error && <Text color="red"> {error}</Text>}
              <Text dimColor> enter add  esc cancel</Text>
            </Box>
          )}

          {step === 'list' && (
            <Box flexDirection="column" marginTop={1}>
              {error && <Text color="red"> {error}</Text>}
              <Text dimColor> ↑↓ navigate  t toggle active  d remove  a add  enter confirm</Text>
            </Box>
          )}
        </Box>
      )}
    </Box>
  );
}

// ── OpenRouter ────────────────────────────────────────────────────────────────

function OpenRouterConfig({ onDone, onCancel }: Props) {
  const [apiKey, setApiKey_] = useState('');
  const [error, setError] = useState('');

  useInput((ch, key) => {
    if (key.escape) { onCancel(); return; }
    if (key.return) {
      const k = apiKey.trim();
      if (!k) { setError('API key cannot be empty'); return; }
      setApiKey('openrouter', k)
        .then(() => setActiveProvider('openrouter'))
        .then(() => onDone('openrouter'))
        .catch((e: unknown) => setError(String(e)));
      return;
    }
    if (key.backspace || key.delete) setApiKey_((s) => s.slice(0, -1));
    else if (ch && !key.ctrl && !key.meta) setApiKey_((s) => s + ch);
  });

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color="cyan"> Configure OpenRouter</Text>
      <Text dimColor> ──────────────────────────────</Text>
      <Text dimColor> Paste your OpenRouter API key (sk-or-…):</Text>
      <Box borderStyle="round" borderColor="cyan" marginTop={1}>
        <Text> {apiKey.replace(/./g, '•')}<Text color="cyan">_</Text></Text>
      </Box>
      {error && <Text color="red"> {error}</Text>}
      <Text dimColor> enter to save  esc cancel</Text>
    </Box>
  );
}

// ── Dispatcher ────────────────────────────────────────────────────────────────

// ── Claude CLI ────────────────────────────────────────────────────────────────

function ClaudeCliConfig({ onDone, onCancel }: Props) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'error'>('idle');
  const [error, setError] = useState('');

  useEffect(() => {
    setStatus('loading');
    setActiveProvider('claude-cli')
      .then(() => onDone('claude-cli'))
      .catch((e: unknown) => {
        setError(String(e));
        setStatus('error');
      });
  }, []);

  useInput((_ch, key) => { if (key.escape) onCancel(); });

  if (status === 'error') {
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text bold color="red"> claude-cli error</Text>
        <Text color="red"> {error}</Text>
        <Box marginTop={1}><Text dimColor> esc to cancel</Text></Box>
      </Box>
    );
  }

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color="cyan"> claude-cli</Text>
      <Text dimColor> ──────────────────────────────</Text>
      <Text color="green"> Routes requests through your local Claude Code CLI.</Text>
      <Text dimColor> Uses your Claude Code subscription — no API key needed.</Text>
      <Box marginTop={1}><Text dimColor> Activating…</Text></Box>
    </Box>
  );
}

export function ProviderConfig(props: Props) {
  // VERIFIED WORKING — keep claude-cli case here.
  // claude-cli needs no API key or OAuth; ClaudeCliConfig auto-activates via setActiveProvider.
  // Missing this case shows "Unknown provider: claude-cli" error (the default branch).
  switch (props.provider.name) {
    case 'openai':      return <OpenAIConfig {...props} />;
    case 'anthropic':   return <AnthropicConfig {...props} />;
    case 'ollama':      return <OllamaConfig {...props} />;
    case 'openrouter':  return <OpenRouterConfig {...props} />;
    case 'claude-cli':  return <ClaudeCliConfig {...props} />;
    default:            return <Box paddingX={2}><Text color="red">Unknown provider: {props.provider.name}</Text></Box>;
  }
}
