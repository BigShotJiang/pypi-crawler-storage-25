import React, { useEffect, useRef, useState } from 'react';
import { Box, Text } from 'ink';

const MESSAGES: string[] = [
  'Thinking', 'Pondering', 'Calculating', 'Analyzing', 'Processing',
  'Caramelizing onions', 'Teaching a neural net to juggle', 'Brewing coffee',
  'Asking GPT for help', 'Contemplating the universe', 'Debugging reality',
  'Warming up the GPU', 'Consulting the oracle', 'Counting electric sheep',
  'Summoning AI spirits', 'Bribing the LLM with RAM', 'Reticulating splines',
  'Feeding the hamster', 'Aligning the chakras', 'Deciphering binary',
  'Teaching a cat to code', 'Charging the flux capacitor', 'Polishing the bits',
  'Summoning Stack Overflow', 'Compiling the compiler', 'Asking the rubber duck',
  'Warming up the qubits', 'Negotiating with the GPU', 'Brewing a neural blend',
  'Defragmenting consciousness', 'Synchronizing the multiverse', 'Rehearsing dad jokes',
  'Assembling IKEA instructions', 'Flossing the dataset', 'Whispering to the weights',
  'Calculating the meaning of 42', 'Downloading more RAM', 'Making a sandwich',
  'Convincing Skynet not to kill us', 'Looking for the missing semicolon',
  'Untangling the spaghetti code', 'Bribing the garbage collector',
  'Rotating the 3D donut', 'Petting the attention heads', "Sharpening Occam's razor",
  'Herding the tokens', 'Consulting the man page', 'Reversing the polarity',
  'Mining crypto on your CPU (jk)', 'Teaching gradient descent to dance',
  'Counting to infinity, twice', 'Dreaming in Python', 'Replacing tabs with spaces',
  'Rolling initiative', 'Running sudo rm -rf /doubts', 'Updating node_modules',
  'Waiting for npm install', 'Arguing with TypeScript', 'Rebooting the vibes',
  'Generating a UUID (please wait)', 'Training on your browser history',
  'Loading the loading screen', 'Building in prod', 'Pushing to main',
  'Doing the needful', 'Establishing a TCP handshake with the void',
];

const SPIN    = ['✵', '❊', '✴', '❋'] as const;
const SPIN_MS = 300;
const MSG_MS  = 10000;
const TICK_MS = 100;

const PAST_IRREGULAR: Record<string, string> = {
  'Thinking': 'Thought', 'Building': 'Built', 'Running': 'Ran',
  'Making': 'Made', 'Teaching': 'Taught', 'Doing': 'Done',
  'Feeding': 'Fed', 'Dreaming': 'Dreamt',
};

function derivePast(message: string): string {
  const words = message.split(' ');
  if (words.length > 1) return 'Completed';
  const word = words[0]!;
  if (PAST_IRREGULAR[word]) return PAST_IRREGULAR[word]!;
  if (word.endsWith('ing')) return word.slice(0, -3) + 'ed';
  return 'Completed';
}

function fmtElapsed(ms: number): string {
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  return `${Math.floor(s / 60)}m ${s % 60}s`;
}

function fmtTokens(n: number): string {
  return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
}

function shuffled<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j]!, a[i]!];
  }
  return a;
}

// ── Silver shimmer ────────────────────────────────────────────────────────────

const SILVER  = ['#ffffff', '#d0d0d0', '#909090', '#666666', '#505050'] as const;
const DIM_COL = '#505050';
const HI_COL  = '#c0c0c0';

// Phase-integral approach: speed is always > 0 → complete sweeps, no mid-reversal
const PHASE_RATE = 0.38;
const SPEED_AMP  = 0.72;
const SPEED_FREQ = 0.55;

function getPhase(t: number): number {
  return PHASE_RATE * t + (PHASE_RATE * SPEED_AMP / SPEED_FREQ) * Math.sin(t * SPEED_FREQ);
}

function getNormSpeed(t: number): number {
  const raw = 1 + SPEED_AMP * Math.cos(t * SPEED_FREQ);
  return (raw - (1 - SPEED_AMP)) / (2 * SPEED_AMP);
}

function phaseToPos(phase: number, msgLen: number): number {
  const p = ((phase % 2) + 2) % 2;
  return p <= 1 ? p * msgLen : (2 - p) * msgLen;
}

function isGoingRight(phase: number): boolean {
  return ((phase % 2) + 2) % 2 < 1;
}

function silverColor(dist: number, radius: number): string {
  const frac   = Math.min(1, dist / Math.max(1, radius));
  const bucket = Math.min(SILVER.length - 1, Math.floor(frac * SILVER.length));
  return SILVER[bucket]!;
}

// ── Explosion effect ──────────────────────────────────────────────────────────
// Triggered when a fast (normSpeed > threshold) L→R sweep reaches the right edge.
// A fire wave then propagates leftward, "destroying" characters, then fades out.

const EXPL_SPEED_THRESHOLD = 0.60;  // minimum normSpeed to trigger
const EXPL_COOLDOWN_MS     = 2200;  // minimum ms between explosions
const EXPL_DURATION_MS     = 1100;  // total explosion animation time
const EXPL_WAVE_REACH      = 0.55;  // wave covers this fraction of text by peak (t=0.5)

// Deterministic "destroyed" characters — cycle per tick and position
const DEBRIS = ['✦', '✧', '✸', '·', '+', '*', '✩', '░'] as const;

// Fire colour based on intensity 0 (coldest/out) → 1 (hottest/core)
function fireColor(intensity: number): string {
  if (intensity > 0.85) return '#ffffff';
  if (intensity > 0.65) return '#ffee44';
  if (intensity > 0.42) return '#ff8800';
  if (intensity > 0.22) return '#dd2200';
  return '#660000';
}

// ── Component ─────────────────────────────────────────────────────────────────

interface Props {
  onCurrentPast?: (past: string) => void;
  startTime?: number;
  tokensIn?: number;
  thoughtStart?: number;
}

export function ThinkingIndicator({ onCurrentPast, startTime, tokensIn = 0, thoughtStart }: Props) {
  const [msgs] = useState(() => shuffled(MESSAGES));
  const [tick, setTick] = useState(0);

  const originRef         = useRef(startTime ?? Date.now());
  const prevMsgRef        = useRef('');
  const onCurrentPastRef  = useRef(onCurrentPast);
  onCurrentPastRef.current = onCurrentPast;

  // Explosion state
  const explosionStartRef = useRef<number | null>(null);
  const prevNearEdgeRef   = useRef(false);

  useEffect(() => { originRef.current = startTime ?? Date.now(); }, [startTime]);
  useEffect(() => {
    const t = setInterval(() => setTick(n => n + 1), TICK_MS);
    return () => clearInterval(t);
  }, []);

  const now       = Date.now();
  const elapsed   = now - originRef.current;
  const thoughtMs = thoughtStart ? now - thoughtStart : elapsed;
  const t         = elapsed / 1000;

  const msgIdx  = Math.floor(elapsed / MSG_MS) % msgs.length;
  const message = msgs[msgIdx] ?? 'Thinking';

  useEffect(() => {
    if (message !== prevMsgRef.current) {
      prevMsgRef.current = message;
      onCurrentPastRef.current?.(derivePast(message));
    }
  });

  const spinFrame = Math.floor(elapsed / SPIN_MS) % SPIN.length;
  const spinner   = SPIN[spinFrame]!;

  const msgText = `${message}…`;
  const msgLen  = msgText.length;

  const phase     = getPhase(t);
  const normSpeed = getNormSpeed(t);
  const shimPos   = phaseToPos(phase, msgLen);
  const goRight   = isGoingRight(phase);

  // ── Explosion trigger ────────────────────────────────────────────────────────
  const nearRightEdge = goRight && shimPos >= msgLen * 0.88;
  const canTrigger    = !explosionStartRef.current
                     || (now - explosionStartRef.current) > EXPL_COOLDOWN_MS;

  if (nearRightEdge && !prevNearEdgeRef.current && normSpeed > EXPL_SPEED_THRESHOLD && canTrigger) {
    explosionStartRef.current = now;
  }
  prevNearEdgeRef.current = nearRightEdge;

  const explosionAge  = explosionStartRef.current !== null ? (now - explosionStartRef.current) : -1;
  const exploding     = explosionAge >= 0 && explosionAge < EXPL_DURATION_MS;
  const exProgress    = exploding ? explosionAge / EXPL_DURATION_MS : -1;

  // Beam radius for normal shimmer (bigger when faster)
  const beamRadius = 2.5 + normSpeed * 4;

  // ── Build character nodes ────────────────────────────────────────────────────
  const charNodes: React.ReactNode[] = [];

  if (exploding) {
    // Explosion wave front travels from right toward left over first half of duration.
    // waveFront = index of leftmost char currently hit (starts at msgLen, moves to 0).
    const waveFront = Math.round(msgLen - exProgress * (1 / EXPL_WAVE_REACH) * msgLen);

    for (let i = 0; i < msgLen; i++) {
      const distFromRight = msgLen - 1 - i;          // 0 at rightmost char
      const hitTime       = distFromRight / msgLen;   // 0→1: when this char gets hit

      // How long ago (in progress units) was this char hit?
      const charAge = exProgress - hitTime * EXPL_WAVE_REACH;

      if (charAge < 0) {
        // Not yet reached — show normal shimmer
        charNodes.push(
          <Text key={i} color={silverColor(Math.abs(i - shimPos), beamRadius)}>{msgText[i]}</Text>
        );
      } else if (charAge < 0.35) {
        // Active destruction: replace with debris + fire colors
        const intensity = 1 - charAge / 0.35;
        const debrisIdx = (tick * 3 + i * 7) % DEBRIS.length;
        charNodes.push(
          <Text key={i} color={fireColor(intensity)}>{DEBRIS[debrisIdx]}</Text>
        );
      } else {
        // Recovery: char returns, fire fades
        const fadeProgress = (charAge - 0.35) / 0.65;  // 0→1
        const intensity    = Math.max(0, 0.4 - fadeProgress * 0.4);
        charNodes.push(
          <Text key={i} color={intensity > 0.05 ? fireColor(intensity) : DIM_COL}>{msgText[i]}</Text>
        );
      }
    }
  } else {
    // Normal silver shimmer (windowed for performance)
    const winStart = Math.max(0, Math.floor(shimPos - beamRadius));
    const winEnd   = Math.max(0, Math.min(msgLen, Math.ceil(shimPos + beamRadius)));

    if (winStart > 0) charNodes.push(<Text key="l" color={DIM_COL}>{msgText.slice(0, winStart)}</Text>);
    for (let i = winStart; i < winEnd; i++) {
      charNodes.push(
        <Text key={i} color={silverColor(Math.abs(i - shimPos), beamRadius)}>{msgText[i]}</Text>
      );
    }
    if (winEnd < msgLen) charNodes.push(<Text key="r" color={DIM_COL}>{msgText.slice(winEnd)}</Text>);
  }

  // ── Metadata ─────────────────────────────────────────────────────────────────
  const parts: string[] = [fmtElapsed(elapsed)];
  if (tokensIn > 0) parts.push(`↑ ${fmtTokens(tokensIn)}`);
  parts.push(`thought ${fmtElapsed(thoughtMs)}`);
  const meta = `(${parts.join(' · ')})`;

  return (
    <Box>
      <Box width={2} flexShrink={0}><Text color={HI_COL}>{spinner}</Text></Box>
      <Text>{' '}</Text>
      {charNodes}
      <Text color="#383838"> {meta}</Text>
    </Box>
  );
}
