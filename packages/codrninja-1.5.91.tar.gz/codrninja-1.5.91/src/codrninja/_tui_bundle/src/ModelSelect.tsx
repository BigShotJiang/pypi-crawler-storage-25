import React, { useEffect, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { fetchModelPrefs, fetchModels, setModel, setSessionModel, ProviderInfo } from './api.js';
import { PROVIDER_MODELS, PROVIDER_ORDER, PROVIDER_COLORS, KnownModel } from './models.js';
import { C } from './styles.js';

interface Props {
  currentModel: string;
  currentProvider: string;
  providers: ProviderInfo[];
  sessionName?: string;
  onSelect: (model: string, provider: string) => void;
  onCancel: () => void;
}

interface Row {
  provider: string;
  model: KnownModel;
}

const SCOPE_OPTIONS = ['This session only', 'Set as global default'] as const;

export function ModelSelect({ currentModel, currentProvider, providers, sessionName, onSelect, onCancel }: Props) {
  const [rows, setRows]     = useState<Row[]>([]);
  const [idx, setIdx]       = useState(0);
  const [filter, setFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState('');
  const [scopeMode, setScopeMode] = useState(false);
  const [scopeIdx, setScopeIdx]   = useState(0);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const [prefs, serverModels] = await Promise.all([
          fetchModelPrefs(),
          fetchModels(),
        ]);
        if (cancelled) return;

        const authProviders = PROVIDER_ORDER.filter(p =>
          providers.some(pi => pi.name === p && pi.authenticated)
        );

        const built: Row[] = [];
        for (const p of authProviders) {
          let known = PROVIDER_MODELS[p] ?? [];

          // Dynamic providers: use server model list
          if (p === 'ollama' || p === 'openrouter') {
            known = serverModels.models.map(m => {
              const i = m.indexOf('|');
              return { id: i >= 0 ? m.slice(i + 1) : m, label: i >= 0 ? m.slice(0, i).trim() : m, ctx: '' };
            });
          }

          // Filter by model prefs (empty list = all enabled)
          const pref = prefs[p] ?? [];
          const visible = pref.length > 0 ? known.filter(k => pref.includes(k.id)) : known;

          for (const model of visible) {
            built.push({ provider: p, model });
          }
        }

        setRows(built);

        // Pre-select current model
        const cur = built.findIndex(r => r.model.id === currentModel && r.provider === currentProvider);
        if (cur >= 0) setIdx(cur);

        setLoading(false);
      } catch (e: unknown) {
        if (!cancelled) { setError(String(e)); setLoading(false); }
      }
    }

    void load();
    return () => { cancelled = true; };
  }, [currentModel, currentProvider]);  // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = filter
    ? rows.filter(r =>
        r.model.label.toLowerCase().includes(filter.toLowerCase()) ||
        r.model.id.toLowerCase().includes(filter.toLowerCase()) ||
        r.provider.toLowerCase().includes(filter.toLowerCase())
      )
    : rows;

  function confirmModel(row: Row, asDefault: boolean) {
    setSaving(true);
    if (sessionName) {
      setSessionModel(sessionName, row.model.id, row.provider, asDefault)
        .then(res => onSelect(res.model, res.provider))
        .catch(() => onSelect(row.model.id, row.provider));
    } else {
      setModel(row.model.id, row.provider)
        .then(res => onSelect(res.model, res.provider))
        .catch(() => onSelect(row.model.id, row.provider));
    }
  }

  useInput((input, key) => {
    if (saving) return;

    if (scopeMode) {
      if (key.escape) { setScopeMode(false); return; }
      if (key.upArrow)   setScopeIdx(i => Math.max(0, i - 1));
      if (key.downArrow) setScopeIdx(i => Math.min(SCOPE_OPTIONS.length - 1, i + 1));
      if (key.return) {
        const row = filtered[idx];
        if (row) confirmModel(row, scopeIdx === 1);
      }
      return;
    }

    if (key.escape) { onCancel(); return; }
    if (key.upArrow) { setIdx(i => Math.max(0, i - 1)); return; }
    if (key.downArrow) { setIdx(i => Math.min(filtered.length - 1, i + 1)); return; }
    if (key.return) {
      const row = filtered[idx];
      if (!row) return;
      if (sessionName) { setScopeIdx(0); setScopeMode(true); }
      else confirmModel(row, false);
      return;
    }
    if (key.backspace || key.delete) { setFilter(f => f.slice(0, -1)); setIdx(0); return; }
    if (input && !key.ctrl && !key.meta) { setFilter(f => f + input); setIdx(0); }
  });

  if (loading) return <Box paddingX={2}><Text dimColor>Loading models…</Text></Box>;

  if (error) {
    return (
      <Box flexDirection="column" paddingX={2}>
        <Text color={C.red}>Could not load models: {error}</Text>
        <Text color={C.dim}>Esc to go back</Text>
      </Box>
    );
  }

  if (scopeMode) {
    const row = filtered[idx];
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text bold color={C.acc}> Apply model change</Text>
        <Text color={C.dim}> {'─'.repeat(40)}</Text>
        <Text color={C.dim}> Selected: <Text color={C.wh}>{row?.model.label ?? ''}</Text>
          <Text color={PROVIDER_COLORS[row?.provider ?? ''] ?? C.dim}> ({row?.provider})</Text>
        </Text>
        <Box flexDirection="column" marginTop={1}>
          {SCOPE_OPTIONS.map((opt, i) => (
            <Box key={opt}>
              <Text color={i === scopeIdx ? C.acc : C.dim} bold={i === scopeIdx}>
                {i === scopeIdx ? ' ▶ ' : '   '}{opt}
              </Text>
            </Box>
          ))}
        </Box>
        <Box marginTop={1}><Text color={C.dim}> ↑↓ navigate  Enter confirm  Esc back</Text></Box>
      </Box>
    );
  }

  // Render with provider group headers
  let lastProvider = '';

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color={C.acc}> Select Model</Text>
      <Text color={C.dim}> Current: <Text color={C.wh}>{currentModel}</Text>
        <Text color={PROVIDER_COLORS[currentProvider] ?? C.dim}> ({currentProvider})</Text>
      </Text>
      <Text color={C.dim}> {'─'.repeat(50)}</Text>

      {/* Filter input */}
      <Box marginBottom={1}>
        <Text color={C.acc}> Filter: </Text>
        <Text color={C.wh}>{filter}</Text>
        <Text color={C.acc}>▌</Text>
      </Box>

      {filtered.length === 0 && <Text color={C.dim}> No models match.</Text>}

      <Box flexDirection="column">
        {filtered.slice(0, 20).map((row, i) => {
          const showHeader = row.provider !== lastProvider;
          lastProvider = row.provider;
          const sel = i === idx;
          const isCurrent = row.model.id === currentModel && row.provider === currentProvider;
          const pCol = PROVIDER_COLORS[row.provider] ?? C.dim;

          return (
            <React.Fragment key={`${row.provider}/${row.model.id}`}>
              {showHeader && (
                <Box marginTop={i > 0 ? 1 : 0}>
                  <Text color={pCol} bold>  {row.provider.toUpperCase()}</Text>
                </Box>
              )}
              <Box>
                <Text color={sel ? C.acc : C.dim} bold={sel}>{sel ? '  ▶ ' : '    '}</Text>
                <Box minWidth={28}>
                  <Text color={sel ? C.wh : C.txt} bold={sel}>{row.model.label}</Text>
                </Box>
                {row.model.ctx ? (
                  <Box minWidth={8}><Text color={sel ? C.dim : '#2a2a3e'}>{row.model.ctx}</Text></Box>
                ) : null}
                {isCurrent && <Text color={C.grn}> ← current</Text>}
              </Box>
            </React.Fragment>
          );
        })}
      </Box>

      {filtered.length > 20 && (
        <Text color={C.dim}>  … {filtered.length - 20} more (type to filter)</Text>
      )}

      <Text color={C.dim}> {'─'.repeat(50)}</Text>
      <Box gap={3} marginTop={1}>
        <Box><Text color={C.dim}>↑↓ </Text><Text color={C.acc}>navigate</Text></Box>
        <Box><Text color={C.dim}>Enter </Text><Text color={C.acc}>select</Text></Box>
        <Box><Text color={C.dim}>type </Text><Text color={C.acc}>filter</Text></Box>
        <Box><Text color={C.dim}>Esc </Text><Text color={C.acc}>cancel</Text></Box>
      </Box>
    </Box>
  );
}
