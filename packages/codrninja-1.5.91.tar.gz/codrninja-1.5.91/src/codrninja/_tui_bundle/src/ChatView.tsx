import React, { useEffect, useRef, useState } from 'react';
import { Box, Static, Text, useInput } from 'ink';
import {
  runCommit, runExec, runFetch, runSearch, runTest,
  setReasoningLevel,
  streamAgent, reconnectStream, respondPermission,
} from './api.js';
import type { AgentModeName } from './api.js';
import { ChatMessage, ToolCall } from './types.js';
import { ThinkingIndicator } from './ThinkingIndicator.js';
import { ToolCallLine } from './ToolCallLine.js';
import { Markdown } from './Markdown.js';
import { C, LOGO } from './styles.js';

// ── slash command registry ────────────────────────────────────────────────────

interface SlashCmd {
  description: string;
  aliases?: string[];
}

const SLASH_COMMANDS: Record<string, SlashCmd> = {
  '/help':        { description: 'Show available commands' },
  '/new':         { description: 'Go back to session list / create new session' },
  '/clear':       { description: 'Clear the current conversation' },
  '/compact':     { description: 'Summarize and compact the conversation' },
  '/fork':        { description: 'Duplicate this session under a new name' },
  '/undo':        { description: 'Remove the last message pair' },
  '/session':     { description: 'Show session info' },
  '/sessions':    { description: 'Go back to session list', aliases: ['/resume', '/continue'] },
  '/status':      { description: 'Show provider / model / session status' },
  '/context':     { description: 'Show context window usage and token counts' },
  '/model':       { description: 'Show or change the current model' },
  '/provider':    { description: 'Show current provider' },
  '/connect':     { description: 'Show how to connect / configure a provider' },
  '/build':       { description: 'Run build agent on a task' },
  '/plan':        { description: 'Run plan agent on a task' },
  '/agent':       { description: 'Show current agent mode (build / plan)' },
  '/exec':        { description: 'Execute a shell command' },
  '/terminal':    { description: 'Execute a shell command', aliases: ['/exec'] },
  '/diff':        { description: 'Show current git diff' },
  '/commit':      { description: 'Git add -A and commit with a message' },
  '/search':      { description: 'Search the web' },
  '/fetch':       { description: 'Fetch and read a web page' },
  '/open':        { description: 'Read a file and show its contents' },
  '/test':        { description: 'Run tests (default: pytest -q)' },
  '/todo':        { description: 'Manage todos (powered by agent)' },
  '/skills':      { description: 'List available agent skills' },
  '/mcp':         { description: 'Show connected MCP servers' },
  '/warp':        { description: 'Change working directory for this session' },
  '/share':       { description: 'Print a shareable session summary' },
  '/themes':      { description: 'Toggle light/dark color hint' },
  '/config':      { description: 'Configure model list per provider' },
  '/permissions': { description: 'Cycle agent mode  (or shift+tab)' },
  '/reasoning':   { description: 'Set reasoning effort via menu' },
  '/exit':        { description: 'Exit codrninja', aliases: ['/quit', '/q'] },
};

const CMD_NAMES = Object.keys(SLASH_COMMANDS).sort();

// ── rainbow-aware text input ──────────────────────────────────────────────────

const RAINBOW_COLORS = ['red', 'yellow', 'green', 'cyan', 'blue', 'magenta'] as const;

/** Splits text into plain / ultrathink segments for rainbow rendering. */
function renderRainbow(text: string, offset: number): React.ReactNode[] {
  const parts = text.split(/(\bultrathink\b)/gi);
  return parts.map((part, pi) => {
    if (/^ultrathink$/i.test(part)) {
      return (
        <React.Fragment key={pi}>
          {part.split('').map((ch, ci) => (
            <Text key={ci} color={RAINBOW_COLORS[(ci + offset) % RAINBOW_COLORS.length]} bold>{ch}</Text>
          ))}
        </React.Fragment>
      );
    }
    return <Text key={pi}>{part}</Text>;
  });
}

interface RainbowInputProps {
  value: string;
  onChange: (v: string) => void;
  onSubmit: (v: string) => void;
  focus: boolean;
}

function RainbowInput({ value, onChange, onSubmit, focus }: RainbowInputProps) {
  const [cursor, setCursor] = React.useState(value.length);
  const [offset, setOffset]  = React.useState(0);
  const hasUltrathink = /ultrathink/i.test(value);

  // Keep cursor at end when value is replaced externally (history nav, clear)
  React.useEffect(() => { setCursor(value.length); }, [value]);

  // Animate rainbow when ultrathink is present
  React.useEffect(() => {
    if (!hasUltrathink) return;
    const id = setInterval(() => setOffset(o => (o + 1) % RAINBOW_COLORS.length), 110);
    return () => clearInterval(id);
  }, [hasUltrathink]);

  useInput((input, key) => {
    if (!focus) return;

    if (key.return) { onSubmit(value); return; }

    if (key.backspace || key.delete) {
      if (cursor > 0) {
        onChange(value.slice(0, cursor - 1) + value.slice(cursor));
        setCursor(c => c - 1);
      }
      return;
    }
    if (key.leftArrow)  { setCursor(c => Math.max(0, c - 1)); return; }
    if (key.rightArrow) { setCursor(c => Math.min(value.length, c + 1)); return; }

    // ctrl+a — beginning of line
    if (key.ctrl && input === 'a') { setCursor(0); return; }
    // ctrl+e — end of line
    if (key.ctrl && input === 'e') { setCursor(value.length); return; }
    // ctrl+u — clear to start
    if (key.ctrl && input === 'u') {
      onChange(value.slice(cursor));
      setCursor(0);
      return;
    }
    // ctrl+k — clear to end
    if (key.ctrl && input === 'k') {
      onChange(value.slice(0, cursor));
      return;
    }

    if (input && !key.ctrl && !key.meta && !key.shift && input.length > 0) {
      onChange(value.slice(0, cursor) + input + value.slice(cursor));
      setCursor(c => c + input.length);
    }
  }, { isActive: focus });

  const beforeCursor = value.slice(0, cursor);
  const cursorChar   = value[cursor] ?? ' ';
  const afterCursor  = value.slice(cursor + 1);

  return (
    <Box>
      {renderRainbow(beforeCursor, offset)}
      <Text inverse>{cursorChar}</Text>
      {renderRainbow(afterCursor, offset)}
    </Box>
  );
}

// ── agent modes ───────────────────────────────────────────────────────────────

type UIAgentMode = 'build-auto' | 'build-ask' | 'build-readonly' | 'plan' | 'review' | 'vision';

const AGENT_MODES: UIAgentMode[] = ['build-auto', 'build-ask', 'build-readonly', 'plan', 'review', 'vision'];

interface ModeConfig { icon: string; label: string; color: string; temperature: number }

const MODE_CONFIG: Record<UIAgentMode, ModeConfig> = {
  'build-auto':     { icon: '▶▶', label: 'Build · auto',         color: 'green',   temperature: 0.2 },
  'build-ask':      { icon: '▶ ', label: 'Build · ask on edits', color: 'yellow',  temperature: 0.2 },
  'build-readonly': { icon: '⏸ ', label: 'Build · read only',    color: 'red',     temperature: 0.2 },
  'plan':           { icon: '≡ ', label: 'Plan',                  color: 'blue',    temperature: 0.4 },
  'review':         { icon: '◎ ', label: 'Review',                color: 'cyan',    temperature: 0.1 },
  'vision':         { icon: '◈ ', label: 'Vision',                color: 'magenta', temperature: 0.85 },
};

// ── reasoning levels ──────────────────────────────────────────────────────────

const REASONING_LEVELS = ['none', 'low', 'medium', 'high'] as const;
const REASONING_DESCS  = [
  'No reasoning tokens',
  'Brief  (Anthropic 1 024 t · OpenAI low)',
  'Standard  (Anthropic 8 000 t · OpenAI medium)',
  'Deep  (Anthropic 32 000 t · OpenAI high)',
] as const;

// ── helpers ───────────────────────────────────────────────────────────────────

const COMPLETION_WINDOW = 12;

const CTX_SIZES: Record<string, number> = {
  'claude-opus-4-7': 200_000, 'claude-sonnet-4-6': 200_000, 'claude-haiku-4-5': 200_000,
  'claude-3-7-sonnet-20250219': 200_000, 'claude-3-5-sonnet-20241022': 200_000,
  'claude-3-5-haiku-20241022': 200_000, 'claude-3-opus-20240229': 200_000, 'claude-3-haiku-20240307': 200_000,
  'gpt-4o': 128_000, 'gpt-4o-mini': 128_000,
  'gpt-4.1': 1_047_576, 'gpt-4.1-mini': 1_047_576, 'gpt-4.1-nano': 1_047_576,
  'gpt-4-turbo': 128_000, 'gpt-4': 8_192,
  'o1': 200_000, 'o1-mini': 128_000, 'o1-pro': 200_000,
  'o3': 200_000, 'o3-mini': 200_000, 'o4-mini': 200_000,
  'codex-mini-latest': 200_000,
};

function ctxMax(model: string): number | undefined {
  if (CTX_SIZES[model]) return CTX_SIZES[model];
  for (const [k, v] of Object.entries(CTX_SIZES)) {
    if (model.startsWith(k) || k.startsWith(model.split(':')[0]!)) return v;
  }
  return undefined;
}

function fmtTokens(n: number): string {
  return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
}

// ── context bar component ─────────────────────────────────────────────────────

const CTX_BAR_LEN = 36;

function ContextBar({ tokIn, tokOut, maxCtx, sessionName, provider, model: mdl, exchangeCount }: NonNullable<ChatMessage['contextData']>) {
  const hasTok = tokIn > 0;
  const pct    = maxCtx && tokIn ? Math.min(100, Math.round((tokIn / maxCtx) * 100)) : undefined;
  const filled = pct !== undefined ? Math.round((pct / 100) * CTX_BAR_LEN) : 0;
  return (
    <Box flexDirection="column" borderStyle="round" borderColor={C.acc} paddingX={1} marginBottom={1}>
      <Text bold color={C.acc}> Context Window</Text>
      <Text> </Text>
      <Box><Text color={C.dim}>  Session   </Text><Text color={C.txt}>{sessionName}</Text></Box>
      <Box><Text color={C.dim}>  Provider  </Text><Text color={C.txt}>{provider}</Text></Box>
      <Box><Text color={C.dim}>  Model     </Text><Text color={C.txt}>{mdl}</Text></Box>
      <Box><Text color={C.dim}>  Window    </Text><Text color={C.txt}>{maxCtx ? fmtTokens(maxCtx) + ' tokens' : 'unknown'}</Text></Box>
      <Box marginTop={1}>
        {hasTok ? (
          <Box flexDirection="column">
            {pct !== undefined && (
              <Box>
                <Text>  </Text>
                <Text color={C.cyn}>{'█'.repeat(filled)}</Text>
                <Text color={C.dim}>{'░'.repeat(CTX_BAR_LEN - filled)}</Text>
                <Text color={C.wh} bold>  {pct}%</Text>
              </Box>
            )}
            <Box>
              <Text color={C.dim}>  </Text>
              <Text color={C.cyn}>{fmtTokens(tokIn)} in</Text>
              {tokOut > 0 ? <Text color={C.dim}>  ·  </Text> : null}
              {tokOut > 0 ? <Text color={C.txt}>{fmtTokens(tokOut)} out</Text> : null}
              {maxCtx ? <Text color={C.dim}>  ·  {fmtTokens(maxCtx - tokIn)} free</Text> : null}
            </Box>
          </Box>
        ) : (
          <Text color={C.dim}>  Token counts not reported by this provider.</Text>
        )}
      </Box>
      <Text> </Text>
      <Box><Text color={C.dim}>  Exchanges </Text><Text color={C.txt}>{String(exchangeCount)}</Text></Box>
    </Box>
  );
}

// ── memoised message list ─────────────────────────────────────────────────────

interface MessageListProps {
  messages: ChatMessage[];
  model: string;
}

const MessageList = React.memo(function MessageList({ messages, model }: MessageListProps) {
  const rendered: React.ReactNode[] = [];
  let idx = 0;

  while (idx < messages.length) {
    const msg = messages[idx]!;

    // context display
    if (msg.contextData) {
      rendered.push(<ContextBar key={idx} {...msg.contextData} />);
      idx++; continue;
    }

    if (msg.role === 'user') {
      rendered.push(
        <Box key={idx} marginBottom={1}>
          <Text color={C.acc} bold>you  </Text>
          <Text color={C.wh} wrap="wrap" backgroundColor="#282828"> {msg.content} </Text>
        </Box>
      );
      idx++; continue;
    }

    if (msg.isModelSwitch) {
      rendered.push(
        <Box key={idx} marginBottom={1}>
          <Text dimColor>{'─'.repeat(6)} </Text>
          <Text color={C.cyn}>{msg.switchProvider}/{msg.switchModel}</Text>
          <Text dimColor> {'─'.repeat(6)}</Text>
        </Box>
      );
      idx++; continue;
    }

    const turnStart = idx;
    const turn: ChatMessage[] = [];
    while (idx < messages.length) {
      const m = messages[idx]!;
      if (m.role === 'user' || m.isModelSwitch || m.contextData) break;
      turn.push(m);
      idx++;
    }

    let lastTok: number | undefined;
    let lastTokIn: number | undefined;
    for (let ti = turn.length - 1; ti >= 0; ti--) {
      const m = turn[ti]!;
      if (m.role === 'assistant' && !m.isThinkingComplete && (m.tokens || m.tokensIn)) {
        lastTok   = m.tokens;
        lastTokIn = m.tokensIn;
        break;
      }
    }

    const contentItems = turn.filter(m => !m.isThinkingComplete);
    const tc = turn.find(m => m.isThinkingComplete);

    rendered.push(
      <Box key={`ninja-${turnStart}`} flexDirection="column" marginBottom={tc ? 0 : 1}>
        <Box>
          <Text color={C.cyn} bold>ninja</Text>
          {(lastTok || lastTokIn) ? (() => {
            const maxCtxVal = ctxMax(model);
            const ctxPct = maxCtxVal && lastTokIn ? Math.min(100, Math.round((lastTokIn / maxCtxVal) * 100)) : undefined;
            const parts: string[] = [];
            if (lastTokIn) parts.push(`${fmtTokens(lastTokIn)} in`);
            if (lastTok)   parts.push(`${fmtTokens(lastTok)} out`);
            if (ctxPct !== undefined) parts.push(`ctx ${ctxPct}%`);
            return <Text color={C.dim}>  [{parts.join(' · ')}]</Text>;
          })() : null}
        </Box>
        {contentItems.map((m, mi) => {
          if (m.role === 'pre_tool') {
            return (
              <Box key={mi} marginLeft={6}>
                <Markdown content={m.content} />
              </Box>
            );
          }
          if (m.role === 'tool') {
            return m.toolData ? <ToolCallLine key={mi} call={m.toolData} /> : null;
          }
          if (m.role === 'assistant' && !m.streaming && m.content === '' && m.tokens === undefined && !m.isThinkingComplete && !m.contextData) {
            return null;
          }
          if (m.role === 'assistant' && m.streaming) {
            return null;
          }
          return (
            <Box key={mi} marginLeft={6}>
              <Markdown content={m.content} streaming={m.streaming} />
            </Box>
          );
        })}
      </Box>
    );

    if (tc && tc.thinkingMs !== undefined) {
      const secs = (tc.thinkingMs / 1000).toFixed(1);
      const iterInfo = (tc.thinkingIter != null || tc.thinkingTools != null)
        ? `  [${tc.thinkingIter ?? 1} iter${(tc.thinkingTools ?? 0) > 0 ? `, ${tc.thinkingTools} tools` : ''}]`
        : '';
      rendered.push(
        <Box key={`tc-${turnStart}`} marginTop={1} marginBottom={1}>
          <Text color={C.dim}>  ✻ {tc.thinkingLabel ?? 'Completed'} in {secs}s{iterInfo}</Text>
        </Box>
      );
    }
  }

  return <>{rendered}</>;
});

// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  sessionName: string;
  history: ChatMessage[];
  onBack: () => void;
  onOpenModelSelect: () => void;
  onOpenProviderSelect: () => void;
  onOpenConfig: () => void;
  provider: string;
  model: string;
  permissionsMode?: string;
  initiallyRunning?: boolean;
}

export function ChatView({ sessionName, history, onBack, onOpenModelSelect, onOpenProviderSelect, onOpenConfig, provider, model, permissionsMode, initiallyRunning }: Props) {

  // ── Static exchange history (never redrawn on keypress) ───────────────────
  // Each completed user↔assistant cycle is one "exchange" appended to this list.
  // Ink's <Static> prints each item once and scrolls it into terminal history.
  const [staticKey, setStaticKey] = useState(0);
  const [exchanges, setExchanges] = useState<ChatMessage[][]>(() =>
    history.length > 0 ? [history] : []
  );

  // ── Live messages: the currently-in-progress exchange ─────────────────────
  // Redrawn on every render — kept small (≤ 1 exchange at a time).
  const liveRef = useRef<ChatMessage[]>([]);
  const [liveMessages, setLiveMessagesState] = useState<ChatMessage[]>([]);

  function setLiveMessages(upd: ChatMessage[] | ((p: ChatMessage[]) => ChatMessage[])) {
    const next = typeof upd === 'function' ? upd(liveRef.current) : upd;
    liveRef.current = next;
    setLiveMessagesState(next);
  }

  // ── Other state ────────────────────────────────────────────────────────────
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [statusLine, setStatusLine] = useState('');
  const [inputHistory, setInputHistoryState] = useState<string[]>(() =>
    history
      .filter((m) => m.role === 'user' && !m.content.startsWith('Working directory:'))
      .map((m) => m.content)
      .reverse()
  );
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [completionIdx, setCompletionIdx] = useState(0);
  const [completionScrollTop, setCompletionScrollTop] = useState(0);
  const cancelRef = useRef<(() => void) | null>(null);
  const thinkingStart = useRef<number>(0);
  const thoughtStart  = useRef<number>(0);   // resets on each tool result
  const lastThinkingPast = useRef<string>('Thought');
  const [liveTokensIn, setLiveTokensIn] = useState(0);
  const [liveTokensOut, setLiveTokensOut] = useState(0);
  const liveTokensInRef  = useRef(0);
  const liveTokensOutRef = useRef(0);
  const [streamingText, setStreamingText] = useState('');
  const streamingTextRef = useRef('');
  const streamingFlushRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── Agent mode ─────────────────────────────────────────────────────────────
  const [agentMode, setAgentMode] = useState<UIAgentMode>(() => {
    if (permissionsMode === 'auto') return 'build-auto';
    if (permissionsMode === 'none') return 'build-readonly';
    return 'build-ask';
  });

  // ── Reasoning menu ─────────────────────────────────────────────────────────
  const [showReasoningMenu, setShowReasoningMenu] = useState(false);
  const [reasoningMenuIdx, setReasoningMenuIdx] = useState(2);
  const [escPending, setEscPending] = useState(false);
  const escTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── Permission request dialog ──────────────────────────────────────────────
  interface PermRequest { callId: string; tool: string; action: string; target: string; params: Record<string, unknown> }
  const [permRequest, setPermRequest] = useState<PermRequest | null>(null);
  const [permDialogIdx, setPermDialogIdx] = useState(0);
  const PERM_DIALOG_OPTIONS = ['Yes (once)', 'Yes (always this session)', 'No'] as const;
  const PERM_DIALOG_DECISIONS: ('yes' | 'always' | 'no')[] = ['yes', 'always', 'no'];

  // ── Reconnect to in-progress server run on mount ──────────────────────────
  useEffect(() => {
    if (!initiallyRunning) return;
    setThinking(true);
    thinkingStart.current = Date.now();
    thoughtStart.current  = Date.now();

    const cancel = reconnectStream(
      sessionName,
      (event) => {
        if (event.type === 'token_update') {
          if ((event.tokens_input  ?? 0) > 0) { liveTokensInRef.current  = event.tokens_input!;  setLiveTokensIn(event.tokens_input!); }
          if ((event.tokens_output ?? 0) > 0) { liveTokensOutRef.current = event.tokens_output!; setLiveTokensOut(event.tokens_output!); }
          return;
        }
        if (event.type === 'permission_request') {
          setPermRequest({
            callId: event.call_id!,
            tool: event.tool!,
            action: event.action!,
            target: event.target ?? '',
            params: event.params ?? {},
          });
          setPermDialogIdx(0);
          return;
        }
        if (permRequest) setPermRequest(null);
        if (event.type === 'assistant_chunk' && event.text !== undefined) {
          streamingTextRef.current = event.text;
          setStreamingText(event.text);
        } else if (event.type === 'result') {
          const elapsedMs   = Date.now() - thinkingStart.current;
          const finalContent = event.result?.response || streamingTextRef.current;
          const outputTokens = event.result?.tokens?.output ?? undefined;
          const inputTokens  = (event.result?.tokens?.input ?? liveTokensInRef.current) || undefined;
          setThinking(false);
          cancelRef.current = null;
          if (streamingFlushRef.current) { clearTimeout(streamingFlushRef.current); streamingFlushRef.current = null; }
          setStreamingText('');
          streamingTextRef.current = '';
          if (finalContent) {
            setExchanges(exs => [...exs, [
              { role: 'assistant' as const, content: finalContent, tokens: outputTokens, tokensIn: inputTokens },
              { role: 'assistant' as const, content: '', isThinkingComplete: true,
                thinkingMs: elapsedMs, thinkingLabel: lastThinkingPast.current,
                thinkingIter: event.result?.iterations, thinkingTools: event.result?.tool_calls },
            ]]);
          }
          if (!event.result?.success) setStatusLine(`Error: ${event.result?.error ?? 'unknown'}`);
        }
      },
      () => { setThinking(false); cancelRef.current = null; setStreamingText(''); streamingTextRef.current = ''; },
      (err) => {
        setThinking(false); cancelRef.current = null;
        setStreamingText(''); streamingTextRef.current = '';
        setStatusLine(`Reconnect error: ${err.message}`);
      },
    );
    cancelRef.current = cancel;
    return () => { cancel(); };
  }, []); // only runs on mount — intentionally no deps

  // ── Slash completions ──────────────────────────────────────────────────────
  const firstWord = input.split(' ')[0] ?? '';
  const showCompletions =
    historyIdx === -1 &&
    input.startsWith('/') &&
    !input.includes(' ') &&
    firstWord.length > 0;
  const completions = showCompletions
    ? CMD_NAMES.filter((c) => c.startsWith(firstWord))
    : [];

  const aiIsStreaming = streamingText.length > 0;

  // ── Key handler ────────────────────────────────────────────────────────────
  useInput((ch, key) => {
    // Permission dialog captures all input — even while thinking (agent is blocked waiting)
    if (permRequest) {
      if (key.escape) {
        const pr = permRequest;
        setPermRequest(null);
        respondPermission(sessionName, pr.callId, 'no').catch(() => {});
        return;
      }
      if (key.upArrow)   { setPermDialogIdx(i => Math.max(0, i - 1)); return; }
      if (key.downArrow) { setPermDialogIdx(i => Math.min(PERM_DIALOG_OPTIONS.length - 1, i + 1)); return; }
      if (key.return) {
        const pr = permRequest;
        const dec = PERM_DIALOG_DECISIONS[permDialogIdx] ?? 'no';
        setPermRequest(null);
        respondPermission(sessionName, pr.callId, dec).catch(() => {});
        return;
      }
      return;
    }

    if (thinking) {
      if (key.escape && cancelRef.current) {
        cancelRef.current();
        cancelRef.current = null;
        setThinking(false);
        setStatusLine('Cancelled.');
      }
      return;
    }

    if (showReasoningMenu) {
      if (key.escape)    { setShowReasoningMenu(false); return; }
      if (key.upArrow)   { setReasoningMenuIdx(i => Math.max(0, i - 1)); return; }
      if (key.downArrow) { setReasoningMenuIdx(i => Math.min(REASONING_LEVELS.length - 1, i + 1)); return; }
      if (key.return) {
        const lvl = REASONING_LEVELS[reasoningMenuIdx];
        if (lvl) {
          setReasoningLevel(lvl)
            .then(res => addSystem(`Reasoning effort set to: ${res.reasoning_level}`))
            .catch((e: unknown) => addSystem(`Error: ${String(e)}`));
        }
        setShowReasoningMenu(false);
        return;
      }
      return;
    }

    if (key.escape) {
      if (escPending) {
        if (escTimerRef.current) clearTimeout(escTimerRef.current);
        setEscPending(false);
        onBack();
      } else {
        setEscPending(true);
        if (escTimerRef.current) clearTimeout(escTimerRef.current);
        escTimerRef.current = setTimeout(() => setEscPending(false), 2500);
      }
      return;
    }
    if (escPending) { setEscPending(false); if (escTimerRef.current) clearTimeout(escTimerRef.current); }

    // shift+tab: cycle agent mode
    if (key.shift && key.tab) {
      const cur  = AGENT_MODES.indexOf(agentMode);
      const next = AGENT_MODES[(cur + 1) % AGENT_MODES.length]!;
      setAgentMode(next);
      return;
    }

    if (key.upArrow) {
      if (showCompletions && completions.length > 0) {
        const newIdx = Math.max(0, completionIdx - 1);
        setCompletionIdx(newIdx);
        setCompletionScrollTop(top => newIdx < top ? top - 1 : top);
      } else {
        const newIdx = Math.min(historyIdx + 1, inputHistory.length - 1);
        if (newIdx >= 0 && newIdx !== historyIdx) {
          setHistoryIdx(newIdx);
          setInputFull(inputHistory[newIdx] ?? '');
        }
      }
      return;
    }
    if (key.downArrow) {
      if (showCompletions && completions.length > 0) {
        const newIdx = Math.min(completions.length - 1, completionIdx + 1);
        setCompletionIdx(newIdx);
        setCompletionScrollTop(top => newIdx >= top + COMPLETION_WINDOW ? top + 1 : top);
      } else if (historyIdx > 0) {
        const newIdx = historyIdx - 1;
        setHistoryIdx(newIdx);
        setInputFull(inputHistory[newIdx] ?? '');
      } else if (historyIdx === 0) {
        setHistoryIdx(-1);
        setInputFull('');
      }
      return;
    }

    if (key.tab && completions.length > 0) {
      const chosen = completions[completionIdx] ?? completions[0];
      if (chosen) { setInput(chosen + ' '); setHistoryIdx(-1); setCompletionIdx(0); setCompletionScrollTop(0); }
      return;
    }
  });

  function setInputFull(val: string) { setInput(val); }

  function handleSubmit(value: string) {
    if (thinking) return;
    if (showCompletions && completions.length > 0 && value === (completions[completionIdx] ?? '')) {
      setInput(value + ' ');
      setCompletionIdx(0);
      setCompletionScrollTop(0);
      return;
    }
    const text = value.trim();
    if (!text) return;
    setInputHistoryState(h => h[0] === text ? h : [text, ...h].slice(0, 100));
    setHistoryIdx(-1);
    setCompletionIdx(0);
    setCompletionScrollTop(0);
    setInput('');
    setStatusLine('');
    if (text.startsWith('/')) handleSlash(text);
    else submit(text);
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  function addSystem(text: string) {
    setExchanges(exs => [...exs, [{ role: 'assistant' as const, content: text }]]);
  }

  function addContextDisplay(data: NonNullable<ChatMessage['contextData']>) {
    const msg: ChatMessage = { role: 'assistant', content: '', contextData: data };
    setExchanges(exs => [...exs, [msg]]);
  }

  // ── Slash dispatcher ───────────────────────────────────────────────────────

  function handleSlash(raw: string) {
    const parts = raw.trim().split(/\s+/);
    const cmd   = parts[0]!.toLowerCase();
    const args  = parts.slice(1);

    const canonical = CMD_NAMES.find(
      (c) => c === cmd || (SLASH_COMMANDS[c]?.aliases ?? []).includes(cmd),
    ) ?? cmd;

    switch (canonical) {
      case '/exit':
        process.exit(0);
        return;

      case '/clear':
        setStaticKey(k => k + 1);
        setExchanges([]);
        setLiveMessages([]);
        return;

      case '/new':
      case '/sessions':
        onBack();
        return;

      case '/undo':
        if (liveRef.current.length > 0) {
          setLiveMessages([]);
        } else {
          setStaticKey(k => k + 1);
          setExchanges(exs => exs.slice(0, -1));
        }
        return;

      case '/compact':
        submit('Please summarize our conversation so far in a compact form, then continue from here.');
        return;

      case '/fork':
        addSystem(`Fork: open a new terminal and run: codrninja ${sessionName}-fork`);
        return;

      case '/help': {
        const lines = CMD_NAMES.map(
          (c) => `${c.padEnd(14)} ${SLASH_COMMANDS[c]?.description ?? ''}`,
        ).join('\n');
        addSystem(lines);
        return;
      }

      case '/status':
      case '/session':
        addSystem(`Session:  ${sessionName}\nProvider: ${provider}\nModel:    ${model}`);
        return;

      case '/context': {
        const maxCtx = ctxMax(model);
        let tokIn  = liveTokensInRef.current  || liveTokensIn;
        let tokOut = liveTokensOutRef.current || liveTokensOut;
        if (!tokIn && !tokOut) {
          outerLoop:
          for (let ei = exchanges.length - 1; ei >= 0; ei--) {
            const ex = exchanges[ei]!;
            for (let mi = ex.length - 1; mi >= 0; mi--) {
              const m = ex[mi]!;
              if (m.role === 'assistant' && !m.isThinkingComplete && !m.contextData && (m.tokensIn || m.tokens)) {
                tokIn  = m.tokensIn ?? 0;
                tokOut = m.tokens   ?? 0;
                break outerLoop;
              }
            }
          }
        }
        const exchangeCount = exchanges.filter(ex => ex.some(m => m.role === 'user')).length;
        addContextDisplay({ tokIn, tokOut, maxCtx, sessionName, provider, model, exchangeCount });
        return;
      }

      case '/model':
      case '/models':
        onOpenModelSelect();
        return;

      case '/provider':
      case '/connect':
        onOpenProviderSelect();
        return;

      case '/agent':
        addSystem(`Current mode: ${agentMode}  (shift+tab to cycle)\nModes: build-auto · build-ask · build-readonly · plan · review · vision`);
        return;

      case '/build':
        if (!args.length) { setStatusLine('Usage: /build <task>'); return; }
        submit(args.join(' '), 'build-auto');
        return;

      case '/plan':
        if (!args.length) { setStatusLine('Usage: /plan <task>'); return; }
        submit(args.join(' '), 'plan');
        return;

      case '/exec':
      case '/terminal':
        if (!args.length) { setStatusLine('Usage: /exec <command>'); return; }
        runSlashExec(args.join(' '));
        return;

      case '/diff':
        runSlashExec('git diff HEAD');
        return;

      case '/commit':
        if (!args.length) { setStatusLine('Usage: /commit <message>'); return; }
        runSlashCommit(args.join(' '));
        return;

      case '/search':
        if (!args.length) { setStatusLine('Usage: /search <query>'); return; }
        runSlashSearch(args.join(' '));
        return;

      case '/fetch':
        if (!args.length) { setStatusLine('Usage: /fetch <url>'); return; }
        runSlashFetch(args[0]!);
        return;

      case '/open':
        if (!args.length) { setStatusLine('Usage: /open <file>'); return; }
        runSlashExec(`cat ${args[0]}`);
        return;

      case '/test':
        runSlashTest(args.length ? args.join(' ') : undefined);
        return;

      case '/todo':
        submit('Show and manage my todos for this session.');
        return;

      case '/skills':
        runSlashExec('codrninja skills');
        return;

      case '/mcp':
        runSlashExec('codrninja mcp list');
        return;

      case '/warp':
        if (!args.length) { setStatusLine('Usage: /warp <directory>'); return; }
        runSlashExec(`cd ${args[0]} && pwd`);
        return;

      case '/share':
        addSystem(`Session: ${sessionName}\nMessages: ${exchanges.reduce((n, ex) => n + ex.length, 0)}\nProvider: ${provider} / ${model}`);
        return;

      case '/config':
        onOpenConfig();
        return;

      case '/permissions': {
        const cur  = AGENT_MODES.indexOf(agentMode);
        const next = AGENT_MODES[(cur + 1) % AGENT_MODES.length]!;
        setAgentMode(next);
        return;
      }

      case '/reasoning':
        setShowReasoningMenu(true);
        return;

      case '/themes':
        addSystem("Theme switching: set TERM_PROGRAM or use your terminal's theme.");
        return;

      default:
        setStatusLine(`Unknown command: ${cmd}  — type /help`);
    }
  }

  // ── REST slash runners ─────────────────────────────────────────────────────

  async function runSlashExec(command: string) {
    setThinking(true);
    addSystem(`$ ${command}`);
    const res = await runExec(command).catch((e: unknown) => ({ success: false, output: '', error: String(e) }));
    setThinking(false);
    addSystem(res.success ? (res.output ?? '(no output)') : `Error: ${res.error}`);
  }

  async function runSlashSearch(query: string) {
    setThinking(true);
    const res = await runSearch(query).catch((e: unknown) => ({ success: false, output: '', error: String(e) }));
    setThinking(false);
    addSystem(res.success ? (res.output ?? '') : `Error: ${res.error}`);
  }

  async function runSlashFetch(url: string) {
    setThinking(true);
    const res = await runFetch(url).catch((e: unknown) => ({ success: false, output: '', error: String(e) }));
    setThinking(false);
    addSystem(res.success ? (res.output ?? '') : `Error: ${res.error}`);
  }

  async function runSlashTest(command?: string) {
    setThinking(true);
    const res = await runTest(command).catch((e: unknown) => ({ success: false, output: '', error: String(e) }));
    setThinking(false);
    addSystem(res.success ? (res.output ?? 'Tests passed.') : `Error: ${res.error}`);
  }

  async function runSlashCommit(message: string) {
    setThinking(true);
    const res = await runCommit(message).catch((e: unknown) => ({ success: false, output: '', error: String(e) }));
    setThinking(false);
    addSystem(res.success ? (res.output ?? 'Committed.') : `Error: ${res.error}`);
  }

  // ── Agent submit ───────────────────────────────────────────────────────────

  function submit(text: string, modeOverride?: AgentModeName) {
    const mode: AgentModeName = modeOverride ?? agentMode;
    const temperature = MODE_CONFIG[mode as UIAgentMode]?.temperature;
    thinkingStart.current = Date.now();
    thoughtStart.current  = Date.now();
    setThinking(true);
    setLiveTokensIn(0);  liveTokensInRef.current  = 0;
    setLiveTokensOut(0); liveTokensOutRef.current = 0;
    setStreamingText('');
    streamingTextRef.current = '';

    // Seed live messages for this exchange
    setLiveMessages([
      { role: 'user', content: text },
      { role: 'assistant', content: '', streaming: true },
    ]);
    setInputHistoryState((h) => (h[0] === text ? h : [text, ...h].slice(0, 100)));

    const cancel = streamAgent(
      sessionName,
      text,
      (event) => {
        if (event.type === 'token_update') {
          if ((event.tokens_input  ?? 0) > 0) { liveTokensInRef.current  = event.tokens_input!;  setLiveTokensIn(event.tokens_input!); }
          if ((event.tokens_output ?? 0) > 0) { liveTokensOutRef.current = event.tokens_output!; setLiveTokensOut(event.tokens_output!); }
          return;
        }

        if (event.type === 'permission_request') {
          setPermRequest({
            callId: event.call_id!,
            tool: event.tool!,
            action: event.action!,
            target: event.target ?? '',
            params: event.params ?? {},
          });
          setPermDialogIdx(0);
          return;
        }

        // Clear any lingering permission dialog when agent continues
        if (permRequest) setPermRequest(null);

        if (event.type === 'assistant_chunk' && event.text !== undefined) {
          streamingTextRef.current = event.text;
          // Debounce: flush to state at most every 60ms to avoid scroll hang on fast output
          if (!streamingFlushRef.current) {
            streamingFlushRef.current = setTimeout(() => {
              streamingFlushRef.current = null;
              setStreamingText(streamingTextRef.current);
            }, 60);
          }

        } else if (event.type === 'pre_tool_text') {
          setLiveMessages((live) => {
            const copy = [...live];
            const preToolMsg: ChatMessage = { role: 'pre_tool', content: event.text! };
            copy.splice(copy.length - 1, 0, preToolMsg);
            const lastIdx = copy.length - 1;
            const last = copy[lastIdx];
            if (last?.role === 'assistant') copy[lastIdx] = { ...last, content: '' };
            return copy;
          });

        } else if (event.type === 'tool_start') {
          const toolMsg: ChatMessage = {
            role: 'tool',
            content: '',
            toolData: { call_id: event.call_id!, tool: event.tool!, args: event.args ?? {}, step: event.step ?? 0, done: false, permMode: event.perm_mode },
          };
          setLiveMessages((live) => {
            const copy = [...live];
            copy.splice(copy.length - 1, 0, toolMsg);
            return copy;
          });

        } else if (event.type === 'tool_result') {
          thoughtStart.current = Date.now();
          setLiveMessages((live) =>
            live.map((msg) =>
              msg.role === 'tool' && msg.toolData?.call_id === event.call_id
                ? { ...msg, toolData: { ...msg.toolData!, output: event.output, success: event.success, done: true, durationMs: event.duration_ms, lineStart: event.line_start, contextBefore: event.context_before, contextAfter: event.context_after } }
                : msg,
            ),
          );

        } else if (event.type === 'result') {
          const elapsedMs    = Date.now() - thinkingStart.current;
          cancelRef.current  = null;
          setThinking(false);

          const outputTokens = event.result?.tokens?.output ?? undefined;
          const inputTokens  = (event.result?.tokens?.input ?? liveTokensInRef.current) || undefined;
          const finalContent = event.result?.response || streamingTextRef.current;
          if (streamingFlushRef.current) { clearTimeout(streamingFlushRef.current); streamingFlushRef.current = null; }
          setStreamingText('');
          streamingTextRef.current = '';

          // Build the finalised live array from the ref (always up-to-date)
          const currentLive = liveRef.current;
          const lastIdx = currentLive.length - 1;
          const finalLive: ChatMessage[] = currentLive.map((msg, i) => {
            if (i === lastIdx && msg.role === 'assistant' && msg.streaming) {
              return { ...msg, content: finalContent, streaming: false, tokens: outputTokens, tokensIn: inputTokens };
            }
            return msg;
          });
          finalLive.push({
            role: 'assistant' as const,
            content: '',
            isThinkingComplete: true,
            thinkingMs:    elapsedMs,
            thinkingLabel: lastThinkingPast.current,
            thinkingIter:  event.result?.iterations,
            thinkingTools: event.result?.tool_calls,
          });

          // Freeze exchange → Static, clear live
          setExchanges(exs => [...exs, finalLive]);
          setLiveMessages([]);

          if (!event.result?.success) setStatusLine(`Error: ${event.result?.error ?? 'unknown'}`);
        }
      },
      () => {
        cancelRef.current = null;
        setThinking(false);
        const finalText = streamingTextRef.current;
        setStreamingText('');
        streamingTextRef.current = '';
        // Freeze incomplete exchange
        const currentLive = liveRef.current;
        const lastIdx     = currentLive.length - 1;
        const finalLive: ChatMessage[] = currentLive.map((msg, i) => {
          if (i === lastIdx && msg.streaming) return { ...msg, content: finalText || msg.content, streaming: false };
          return msg;
        });
        setExchanges(exs => [...exs, finalLive]);
        setLiveMessages([]);
      },
      (err) => {
        cancelRef.current = null;
        setThinking(false);
        setStreamingText('');
        streamingTextRef.current = '';
        setStatusLine(`Error: ${err.message}`);
        setLiveMessages([]);
      },
      mode,
      temperature,
    );

    cancelRef.current = cancel;
  }

  // ── Render ─────────────────────────────────────────────────────────────────

  const termCols  = (process.stdout.columns ?? 80) - 4;
  const inputLine = '─'.repeat(Math.max(termCols, 10));
  const lineColor = thinking ? C.dim : C.acc;
  const perm      = MODE_CONFIG[agentMode];
  const isEmpty   = exchanges.length === 0 && liveMessages.length === 0;

  return (
    <Box flexDirection="column">

      {/* ── Completed exchanges (Static: never redrawn on keypress) ─────────── */}
      <Static key={staticKey} items={exchanges}>
        {(exchange, i) => (
          <Box key={i} paddingX={2} flexDirection="column">
            <MessageList messages={exchange} model={model} />
          </Box>
        )}
      </Static>

      {/* ── Dynamic area: header + live exchange + input ─────────────────────── */}
      <Box flexDirection="column" paddingX={2}>

        {/* header — only shown on empty session */}
        {isEmpty && (
          <Box flexDirection="column" marginBottom={1}>
            <Box marginBottom={1}>
              <Text bold color={C.acc}> {sessionName}</Text>
              <Text color={C.dim}>  {provider}/{model}</Text>
            </Box>
            <Text color={C.acc}>{LOGO}</Text>
            <Text color={C.dim}>  Type a message or / for commands</Text>
          </Box>
        )}

        {/* live messages (current in-progress exchange) */}
        <MessageList messages={liveMessages} model={model} />

        {/* streaming text */}
        {streamingText && (
          <Box marginLeft={6}>
            <Markdown content={streamingText} streaming={true} />
          </Box>
        )}

        {/* reasoning menu */}
        {showReasoningMenu && (
          <Box flexDirection="column" marginBottom={1} paddingX={1} borderStyle="single" borderColor={C.mnt}>
            <Text bold color={C.mnt}> Reasoning effort</Text>
            <Text dimColor> ───────────────────────────────────────────────</Text>
            {REASONING_LEVELS.map((lvl, i) => {
              const sel = i === reasoningMenuIdx;
              return (
                <Box key={lvl}>
                  <Text color={sel ? C.mnt : C.dim}>{sel ? ' ❯ ' : '   '}</Text>
                  <Box minWidth={10}><Text color={sel ? C.wh : C.txt} bold={sel}>{lvl}</Text></Box>
                  <Text color={C.dim}>{REASONING_DESCS[i]}</Text>
                </Box>
              );
            })}
            <Box marginTop={1}>
              <Text dimColor>  ↑↓ navigate  enter confirm  esc cancel</Text>
            </Box>
          </Box>
        )}

        {/* status line */}
        {escPending && <Text color="yellow"> press Esc again to go back</Text>}
        {!escPending && statusLine && <Text color={C.red}> {statusLine}</Text>}

        {/* slash completion popup */}
        {completions.length > 0 && (
          <Box flexDirection="column" marginBottom={1} paddingLeft={2} borderStyle="single" borderColor={C.acc}>
            {completionScrollTop > 0 && (
              <Text color={C.dim}>  ↑ {completionScrollTop} more</Text>
            )}
            {completions.slice(completionScrollTop, completionScrollTop + COMPLETION_WINDOW).map((c, ci) => {
              const absIdx = completionScrollTop + ci;
              const sel    = absIdx === completionIdx;
              return (
                <Box key={c}>
                  <Text color={sel ? C.acc : C.dim}>{sel ? '▶ ' : '  '}</Text>
                  <Box minWidth={16}><Text color={sel ? C.acc : C.txt} bold={sel}>{c}</Text></Box>
                  <Text color={C.dim}>{SLASH_COMMANDS[c]?.description ?? ''}</Text>
                </Box>
              );
            })}
            {completionScrollTop + COMPLETION_WINDOW < completions.length && (
              <Text color={C.dim}>  ↓ {completions.length - completionScrollTop - COMPLETION_WINDOW} more</Text>
            )}
            <Text color={C.dim}>  ↑↓ navigate  tab/enter select</Text>
          </Box>
        )}

        {/* thinking indicator — always visible while thinking, even during streaming */}
        {thinking && (
          <Box marginTop={1} justifyContent="space-between">
            <ThinkingIndicator
              onCurrentPast={(past) => { lastThinkingPast.current = past; }}
              startTime={thinkingStart.current}
              tokensIn={liveTokensIn}
              thoughtStart={thoughtStart.current}
            />
            <Text color={C.dim}>esc cancel  </Text>
          </Box>
        )}

        {/* input (two-line style) */}
        <Box flexDirection="column">
          <Text color={lineColor}>{inputLine}</Text>
          <Box>
            <Text color={C.acc}> ❯ </Text>
            <RainbowInput
              value={input}
              onChange={v => { setInput(v); setHistoryIdx(-1); setCompletionIdx(0); setCompletionScrollTop(0); }}
              onSubmit={handleSubmit}
              focus={!thinking && !showReasoningMenu && !permRequest}
            />
          </Box>
          <Text color={lineColor}>{inputLine}</Text>
        </Box>

        {/* permission request dialog — appears below input, above footer */}
        {permRequest && (
          <Box flexDirection="column" marginTop={1} paddingX={1} borderStyle="round" borderColor="yellow">
            <Text bold color="yellow"> Permission Request</Text>
            <Text dimColor> ───────────────────────────────────────────────</Text>
            <Box>
              <Text color={C.dim}>  Tool    </Text>
              <Text color="white">{permRequest.tool}</Text>
            </Box>
            <Box>
              <Text color={C.dim}>  Action  </Text>
              <Text color="white">{permRequest.action}</Text>
            </Box>
            {permRequest.target && (
              <Box>
                <Text color={C.dim}>  Target  </Text>
                <Text color="white">{permRequest.target}</Text>
              </Box>
            )}
            <Text> </Text>
            {PERM_DIALOG_OPTIONS.map((opt, i) => {
              const sel = i === permDialogIdx;
              const col = i < 2 ? 'green' : 'red';
              return (
                <Box key={opt}>
                  <Text color={sel ? col : C.dim}>{sel ? ' ❯ ' : '   '}</Text>
                  <Text color={sel ? 'white' : C.dim} bold={sel}>{opt}</Text>
                </Box>
              );
            })}
            <Box marginTop={1}>
              <Text dimColor>  ↑↓ navigate  enter confirm  esc deny</Text>
            </Box>
          </Box>
        )}

        {/* permission mode footer */}
        <Box marginTop={0}>
          <Text color={perm.color}> {perm.icon} {perm.label}</Text>
          <Text color={C.dim}>  (shift+tab to cycle)</Text>
        </Box>

      </Box>
    </Box>
  );
}
