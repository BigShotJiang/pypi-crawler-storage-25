import React, { useEffect, useState } from 'react';
import { Box, Text } from 'ink';
import { ToolCall } from './types.js';

interface Props {
  call: ToolCall;
}

const SPIN = ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'];

function trunc(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + '…' : s;
}

function shortPath(p: string): string {
  return p.replace(/^\/Users\/[^/]+/, '~').replace(/^\/root/, '~');
}

// ── Diff renderer for edit_file ──────────────────────────────────────────────

const MAX_DIFF_LINES = 12;

function strip(lines: string[]): string[] {
  return lines[lines.length - 1] === '' ? lines.slice(0, -1) : lines;
}

function diffSummary(add: number, rem: number): string {
  if (add > 0 && rem > 0) return `Added ${add} line${add !== 1 ? 's' : ''}, removed ${rem} line${rem !== 1 ? 's' : ''}`;
  if (add > 0) return `Added ${add} line${add !== 1 ? 's' : ''}`;
  if (rem > 0) return `Removed ${rem} line${rem !== 1 ? 's' : ''}`;
  return 'No changes';
}

function LineNum({ n, color }: { n?: number; color: string }) {
  if (n === undefined) return <Text color="#484848">{'    '}</Text>;
  return <Text color={color}>{String(n).padStart(4)}</Text>;
}

interface DiffBlockProps {
  oldText: string;
  newText: string;
  lineStart?: number;
  contextBefore?: string[];
  contextAfter?: string[];
}

// Full-width diff row: pads text so the background colour fills the terminal line.
// paddingX={2} (ChatView) + marginLeft={6} (ToolCallLine) + marginLeft={2} (DiffBlock) = 10.
const DIFF_LEFT_OFFSET = 10;

function DiffBlock({ oldText, newText, lineStart, contextBefore, contextAfter }: DiffBlockProps) {
  const termCols = (process.stdout.columns ?? 80);
  const rem = strip(oldText ? oldText.split('\n') : []);
  const add = strip(newText ? newText.split('\n') : []);

  // Build rows: context-before, removed, added, context-after
  type Row =
    | { kind: 'ctx';  line: number; text: string }
    | { kind: '-';    line: number; text: string }
    | { kind: '+';    line: number; text: string }
    | { kind: 'more'; count: number };

  const rows: Row[] = [];

  // Context before
  const ctxBefore = contextBefore ?? [];
  const ctxBeforeStart = lineStart ? lineStart - ctxBefore.length : undefined;
  ctxBefore.forEach((text, i) => {
    rows.push({ kind: 'ctx', line: ctxBeforeStart ? ctxBeforeStart + i : 0, text });
  });

  // Removed lines
  rem.forEach((text, i) => {
    rows.push({ kind: '-', line: lineStart ? lineStart + i : 0, text });
  });

  // Added lines
  add.forEach((text, i) => {
    rows.push({ kind: '+', line: lineStart ? lineStart + i : 0, text });
  });

  // Context after
  const ctxAfter = contextAfter ?? [];
  const ctxAfterStart = lineStart ? lineStart + rem.length : undefined;
  ctxAfter.forEach((text, i) => {
    rows.push({ kind: 'ctx', line: ctxAfterStart ? ctxAfterStart + i : 0, text });
  });

  // Truncate diff section (not context)
  const diffRows = rows.filter(r => r.kind === '-' || r.kind === '+');
  const hiddenDiff = Math.max(0, diffRows.length - MAX_DIFF_LINES);
  let diffShown = 0;
  const visibleRows: Row[] = [];
  for (const row of rows) {
    if (row.kind === '-' || row.kind === '+') {
      if (diffShown >= MAX_DIFF_LINES) continue;
      diffShown++;
    }
    visibleRows.push(row);
  }
  if (hiddenDiff > 0) visibleRows.push({ kind: 'more', count: hiddenDiff });

  const hasLineNums = lineStart !== undefined && lineStart > 0;

  return (
    <Box flexDirection="column" marginLeft={2}>
      <Box>
        <Text color="#555566">⎿  </Text>
        <Text dimColor>{diffSummary(add.length, rem.length)}</Text>
      </Box>
      {visibleRows.map((row, i) => {
        if (row.kind === 'more') {
          return (
            <Box key={i} marginLeft={hasLineNums ? 6 : 3}>
              <Text dimColor>… +{row.count} more line{row.count !== 1 ? 's' : ''}</Text>
            </Box>
          );
        }
        if (row.kind === 'ctx') {
          return (
            <Box key={i}>
              {hasLineNums && <LineNum n={row.line} color="#484848" />}
              <Text color="#484848">   </Text>
              <Text dimColor>{trunc(row.text, hasLineNums ? 68 : 72)}</Text>
            </Box>
          );
        }
        const isRem = row.kind === '-';
        const bg    = isRem ? '#2d1010' : '#0f2d0f';
        const numStr = hasLineNums ? String(row.line).padStart(4) : '    ';
        const sign   = isRem ? ' - ' : ' + ';
        const taken  = numStr.length + sign.length + DIFF_LEFT_OFFSET;
        const avail  = Math.max(10, termCols - taken);
        const txt    = trunc(row.text, avail).padEnd(avail);
        return (
          <Box key={i}>
            <Text backgroundColor={bg} color={isRem ? '#cc6666' : '#66cc88'}>{numStr}</Text>
            <Text backgroundColor={bg} color={isRem ? '#ff5555' : '#55ff55'} bold>{sign}</Text>
            <Text backgroundColor={bg} color={isRem ? '#ffaaaa' : '#aaffaa'}>{txt}</Text>
          </Box>
        );
      })}
    </Box>
  );
}

// ── Output block for bash / generic tools ───────────────────────────────────

const MAX_OUTPUT_LINES = 6;

function OutputBlock({ output }: { output: string }) {
  const lines  = output.trim().split('\n').filter(l => l.trim() !== '');
  const shown  = lines.slice(0, MAX_OUTPUT_LINES);
  const hidden = lines.length - shown.length;
  return (
    <Box flexDirection="column" marginLeft={2}>
      <Box>
        <Text color="#555566">⎿  </Text>
        <Text dimColor>{trunc(shown[0] ?? '', 74)}</Text>
      </Box>
      {shown.slice(1).map((l, i) => (
        <Box key={i} marginLeft={5}>
          <Text dimColor>{trunc(l, 74)}</Text>
        </Box>
      ))}
      {hidden > 0 && (
        <Box marginLeft={5}>
          <Text dimColor>… +{hidden} more line{hidden !== 1 ? 's' : ''}</Text>
        </Box>
      )}
    </Box>
  );
}

// ── Permission / duration footer ─────────────────────────────────────────────

function fmtDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

function permLabel(mode: string | undefined): string {
  if (mode === 'auto') return 'auto mode';
  if (mode === 'ask')  return 'ask · allowed';
  return '';
}

function PermLine({ permMode, durationMs }: { permMode?: string; durationMs?: number }) {
  const parts: string[] = [];
  if (durationMs !== undefined && durationMs >= 50) parts.push(fmtDuration(durationMs));
  const label = permLabel(permMode);
  if (label) parts.push(label);
  if (!parts.length) return null;
  return (
    <Box marginLeft={2}>
      <Text color="#555566">⎿  </Text>
      <Text color="#484848">{parts.join(' · ')}</Text>
    </Box>
  );
}

// ── Main component ───────────────────────────────────────────────────────────

export function ToolCallLine({ call }: Props) {
  const [spinIdx, setSpinIdx] = useState(0);
  useEffect(() => {
    if (call.done) return;
    const t = setInterval(() => setSpinIdx(i => (i + 1) % SPIN.length), 80);
    return () => clearInterval(t);
  }, [call.done]);

  const a = call.args as Record<string, string>;

  // ── In-progress ────────────────────────────────────────────────────────────
  if (!call.done) {
    let label: React.ReactNode;
    switch (call.tool) {
      case 'write_file':
      case 'edit_file':
        label = (
          <>
            <Text color="yellow">Update</Text>
            <Text dimColor>(</Text>
            <Text color="yellow">{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </>
        );
        break;
      case 'execute_command':
        label = (
          <>
            <Text color="yellow">Bash</Text>
            <Text dimColor>(</Text>
            <Text color="yellow">{trunc(a.command ?? '', 60)}</Text>
            <Text dimColor>)</Text>
          </>
        );
        break;
      case 'read_file':
        label = (
          <>
            <Text color="yellow">Read</Text>
            <Text dimColor>(</Text>
            <Text color="yellow">{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </>
        );
        break;
      default: {
        const name = call.tool.startsWith('mcp_') ? call.tool.slice(4) :
                     call.tool.startsWith('lsp_') ? call.tool.slice(4) : call.tool;
        label = <Text color="yellow">{name}{trunc(JSON.stringify(call.args), 50)}</Text>;
      }
    }
    return (
      <Box marginLeft={6}>
        <Text color="yellow">{SPIN[spinIdx]}  </Text>
        <Text color="yellow">⏺ </Text>
        {label}
      </Box>
    );
  }

  // ── Completed ──────────────────────────────────────────────────────────────
  const ok    = call.success !== false;
  const icon  = ok ? '⏺' : '⏺';
  const col   = ok ? '#c0c0c0' : 'red';

  switch (call.tool) {

    case 'write_file': {
      const lines = (a.content ?? '').split('\n').length;
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Write</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </Box>
          <Box marginLeft={2}>
            <Text color="#555566">⎿  </Text>
            <Text color="green">+{lines} </Text>
            <Text dimColor>line{lines !== 1 ? 's' : ''}</Text>
          </Box>
          <PermLine permMode={call.permMode} durationMs={call.durationMs} />
        </Box>
      );
    }

    case 'edit_file': {
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Update</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </Box>
          {ok
            ? <DiffBlock oldText={a.old_text ?? ''} newText={a.new_text ?? ''} lineStart={call.lineStart} contextBefore={call.contextBefore} contextAfter={call.contextAfter} />
            : <Box marginLeft={2}><Text color="red">✗ {trunc(call.output ?? 'failed', 70)}</Text></Box>
          }
          <PermLine permMode={call.permMode} durationMs={call.durationMs} />
        </Box>
      );
    }

    case 'execute_command': {
      const out = (call.output ?? '').trim();
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Bash</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{trunc(a.command ?? '', 60)}</Text>
            <Text dimColor>)</Text>
          </Box>
          {out ? <OutputBlock output={out} /> : null}
          <PermLine permMode={call.permMode} durationMs={call.durationMs} />
        </Box>
      );
    }

    case 'read_file': {
      const lines = (call.output ?? '').split('\n').length;
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Read</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </Box>
          <Box marginLeft={2}>
            <Text color="#555566">⎿  </Text>
            <Text dimColor>{lines} line{lines !== 1 ? 's' : ''}</Text>
          </Box>
          <PermLine permMode={call.permMode} durationMs={call.durationMs} />
        </Box>
      );
    }

    case 'search_files': {
      const matches = (call.output ?? '').split('\n').filter(Boolean).length;
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Grep</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{trunc(String(a.pattern ?? ''), 55)}</Text>
            <Text dimColor>)</Text>
          </Box>
          <Box marginLeft={2}>
            <Text color="#555566">⎿  </Text>
            <Text dimColor>{matches} match{matches !== 1 ? 'es' : ''}</Text>
          </Box>
          <PermLine permMode={call.permMode} durationMs={call.durationMs} />
        </Box>
      );
    }

    case 'list_files': {
      const items = (call.output ?? '').split('\n').filter(Boolean).length;
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Ls</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{shortPath(String(a.path ?? '.'))}</Text>
            <Text dimColor>)  </Text>
            <Text dimColor>{items} item{items !== 1 ? 's' : ''}</Text>
          </Box>
          <PermLine permMode={call.permMode} durationMs={call.durationMs} />
        </Box>
      );
    }

    default: {
      const name = call.tool.startsWith('mcp_') ? call.tool.slice(4) :
                   call.tool.startsWith('lsp_') ? call.tool.slice(4) : call.tool;
      const out = (call.output ?? '').trim();
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>{name}</Text>
            <Text dimColor>  {trunc(JSON.stringify(call.args), 45)}</Text>
          </Box>
          {out ? <OutputBlock output={out} /> : null}
          <PermLine permMode={call.permMode} durationMs={call.durationMs} />
        </Box>
      );
    }
  }
}
