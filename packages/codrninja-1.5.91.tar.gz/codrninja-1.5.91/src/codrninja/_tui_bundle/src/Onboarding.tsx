import React, { useState } from 'react';
import { Box, Text, useInput, useApp } from 'ink';
import { ProviderInfo } from './api.js';
import { C, LOGO } from './styles.js';

interface Props {
  providers: ProviderInfo[];
  onSetup: (provider: ProviderInfo) => void;
}

const PROVIDER_META: Record<string, { desc: string; models: string; auth: string; color: string }> = {
  openai:       { desc: 'OpenAI',      models: 'GPT-4o · o3 · Codex',     auth: 'API key or OAuth',  color: '#10a37f' },
  anthropic:    { desc: 'Anthropic',   models: 'Claude Opus · Sonnet',     auth: 'API key',           color: '#d97706' },
  ollama:       { desc: 'Ollama',      models: 'Local models, private',    auth: 'no key needed',     color: '#60a5fa' },
  openrouter:   { desc: 'OpenRouter',  models: '400+ models',              auth: 'API key',           color: '#a78bfa' },
  'claude-cli': { desc: 'Claude CLI',  models: 'via Claude Code CLI',      auth: 'no key needed',     color: '#f472b6' },
};

export function Onboarding({ providers, onSetup }: Props) {
  const { exit } = useApp();
  const [idx, setIdx] = useState(0);

  useInput((input, key) => {
    if (key.upArrow)   setIdx(i => Math.max(0, i - 1));
    if (key.downArrow) setIdx(i => Math.min(providers.length - 1, i + 1));
    if (key.return && providers[idx]) onSetup(providers[idx]!);
    if (input === 'q') exit();
  });

  const sel = providers[idx];

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>

      {/* Logo */}
      <Text color={C.acc}>{LOGO}</Text>

      {/* Headline */}
      <Box flexDirection="column" marginTop={1} marginBottom={1}>
        <Text color={C.wh} bold>  Welcome to codrninja</Text>
        <Text color={C.dim}>  Connect an AI provider to get started.</Text>
      </Box>

      <Text color={C.dim}>{'─'.repeat(72)}</Text>

      {/* Provider picker */}
      <Box flexDirection="column" marginTop={1}>
        <Text color={C.acc} bold>  CHOOSE A PROVIDER</Text>
        <Box flexDirection="column" marginTop={1} borderStyle="single" borderColor="#2a2a3e">
          {providers.map((p, i) => {
            const meta   = PROVIDER_META[p.name] ?? { desc: p.name, models: '', auth: '', color: C.dim };
            const active = i === idx;
            const already = p.authenticated;
            return (
              <Box key={p.name} paddingX={1}>
                <Text color={active ? C.acc : C.dim} bold={active}>{active ? '▶ ' : '  '}</Text>

                {/* Provider name */}
                <Box minWidth={14}>
                  <Text color={active ? C.wh : C.txt} bold={active}>{meta.desc}</Text>
                </Box>

                {/* Models */}
                <Box minWidth={28}>
                  <Text color={active ? meta.color : '#3a3a52'}>{meta.models}</Text>
                </Box>

                {/* Auth type */}
                <Box minWidth={22}>
                  <Text color={active ? C.dim : '#2a2a3e'}>{meta.auth}</Text>
                </Box>

                {/* Already configured badge */}
                {already && (
                  <Text color={C.grn}>✓ configured</Text>
                )}
              </Box>
            );
          })}
        </Box>
      </Box>

      {/* Selected provider detail card */}
      {sel && (
        <Box
          flexDirection="column"
          marginTop={1}
          paddingX={2}
          paddingY={1}
          borderStyle="round"
          borderColor={PROVIDER_META[sel.name]?.color ?? C.acc}
        >
          <Text color={PROVIDER_META[sel.name]?.color ?? C.acc} bold>
            {PROVIDER_META[sel.name]?.desc ?? sel.name}
          </Text>
          <Text color={C.dim}>
            {sel.authenticated
              ? 'Already connected — press Enter to reconfigure.'
              : `Press Enter to set up ${PROVIDER_META[sel.name]?.desc ?? sel.name}.`}
          </Text>
        </Box>
      )}

      <Text color={C.dim}>{'─'.repeat(72)}</Text>

      {/* Key hints */}
      <Box gap={4} marginTop={1}>
        {([['↑↓', 'navigate'], ['Enter', 'configure'], ['q', 'quit']] as const).map(([k, l]) => (
          <Box key={k}>
            <Text color={C.dim}>{k} </Text>
            <Text color={C.acc}>{l}</Text>
          </Box>
        ))}
      </Box>

    </Box>
  );
}
