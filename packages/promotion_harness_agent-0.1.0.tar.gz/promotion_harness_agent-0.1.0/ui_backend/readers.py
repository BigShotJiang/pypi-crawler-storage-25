from __future__ import annotations

import json
import os
from collections import deque
from typing import Any, Iterable

from core.context_manager import read_json_file_safe


def read_progress(progress_path: str) -> dict[str, Any] | None:
    if not progress_path or not os.path.exists(progress_path):
        return None
    data = read_json_file_safe(progress_path, retries=3, sleep_sec=0.05)
    return data if isinstance(data, dict) else None


def iter_ndjson(path: str) -> Iterable[dict[str, Any]]:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict):
                yield obj


def tail_ndjson(path: str, *, limit: int = 200) -> list[dict[str, Any]]:
    if limit <= 0:
        return []
    limit = min(limit, 2000)
    buf: deque[dict[str, Any]] = deque(maxlen=limit)
    for ev in iter_ndjson(path):
        buf.append(ev)
    return list(buf)


def tail_ndjson_filtered(
    path: str,
    *,
    limit: int = 200,
    state: str | None = None,
    type_: str | None = None,
) -> list[dict[str, Any]]:
    """Tail NDJSON but keep only the last N events matching the filters.

    This is used for the trace endpoint `tail=1` mode. Applying filters after tailing
    can easily return an empty set when `limit` is small (e.g. limit=1), even if the file
    contains matching events earlier.
    """
    if limit <= 0:
        return []
    limit = min(limit, 2000)
    buf: deque[dict[str, Any]] = deque(maxlen=limit)
    for ev in iter_ndjson(path):
        if state and ev.get("state") != state:
            continue
        if type_ and ev.get("type") != type_:
            continue
        buf.append(ev)
    return list(buf)


def slice_events(
    events: Iterable[dict[str, Any]],
    *,
    offset: int = 0,
    limit: int = 200,
    state: str | None = None,
    type_: str | None = None,
) -> tuple[list[dict[str, Any]], int]:
    if offset < 0:
        offset = 0
    if limit <= 0:
        limit = 200
    limit = min(limit, 2000)

    out: list[dict[str, Any]] = []
    skipped = 0
    for ev in events:
        if state and ev.get("state") != state:
            continue
        if type_ and ev.get("type") != type_:
            continue
        if skipped < offset:
            skipped += 1
            continue
        out.append(ev)
        if len(out) >= limit:
            break
    next_offset = offset + len(out)
    return out, next_offset


def list_runs(workspace_runs_dir: str) -> list[dict[str, Any]]:
    if not os.path.isdir(workspace_runs_dir):
        return []
    runs: list[dict[str, Any]] = []
    for name in sorted(os.listdir(workspace_runs_dir)):
        run_dir = os.path.join(workspace_runs_dir, name)
        if not os.path.isdir(run_dir):
            continue
        runs.append(
            {
                "run_id": name,
                "run_dir": run_dir,
                "trace_path": os.path.join(run_dir, "trace.ndjson"),
                "progress_path": os.path.join(run_dir, "progress.json"),
            }
        )
    return runs
