from __future__ import annotations

import os

import uvicorn


def main() -> None:
    host = str(os.environ.get("HARNESS_UI_BACKEND_HOST") or "127.0.0.1")
    port = int(os.environ.get("HARNESS_UI_BACKEND_PORT", "8000"))
    reload_enabled = str(os.environ.get("HARNESS_UI_BACKEND_RELOAD") or "").strip().lower() in {"1", "true", "yes", "on"}
    uvicorn.run("ui_backend.app:app", host=host, port=port, reload=reload_enabled)


if __name__ == "__main__":
    main()

