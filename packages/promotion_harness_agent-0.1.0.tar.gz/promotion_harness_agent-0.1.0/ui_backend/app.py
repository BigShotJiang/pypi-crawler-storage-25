from __future__ import annotations

import os
from typing import Any

from fastapi import Body, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from core.runtime_paths import active_run_paths
from ui_backend.paths import ensure_within_repo, frontend_static_root, repo_root
from ui_backend.process_control import RetryStageError, reset_outputs, resume_run, retry_stage_run, start_run, stop_run
from ui_backend.readers import iter_ndjson, list_runs, read_progress, slice_events, tail_ndjson, tail_ndjson_filtered
from ui_backend import mcp_probe


app = FastAPI(title="Harness UI Backend", version="0.1.0")

# Dev-friendly CORS (Vite defaults to 5173). Users can tighten later.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _active_paths():
    return active_run_paths(repo_root())


def _require_active_paths():
    active = _active_paths()
    if active is None:
        raise HTTPException(status_code=409, detail="active_run_required")
    return active


@app.get("/api/health")
def health() -> dict[str, Any]:
    active = _active_paths()
    return {
        "ok": True,
        "repo_root": repo_root(),
        "harness_root": active.harness_root if active else os.path.join(repo_root(), ".harness"),
        "active_run_id": active.run_id if active else None,
    }


@app.get("/api/progress")
def get_progress() -> dict[str, Any]:
    active = _require_active_paths()
    progress_path = active.progress_file
    data = read_progress(progress_path)
    return {"path": progress_path, "data": data}


@app.get("/api/runs")
def get_runs() -> dict[str, Any]:
    active = _require_active_paths()
    runs_dir = active.runs_root
    return {"runs_dir": runs_dir, "runs": list_runs(runs_dir)}


@app.get("/api/tools/catalog")
def get_tool_catalog(stage: str | None = Query(None)) -> dict[str, Any]:
    """Return the full tool catalog.

    `stage` is optional and used only as UI metadata; the catalog itself is not
    stage-filtered so the UI can highlight per-entry allowlists.
    """
    from core.tool_catalog import build_tool_catalog_payload

    payload = build_tool_catalog_payload(stage=None, workspace_root=repo_root())
    return {
        "scope": "all",
        "requested_stage": stage,
        "entries": payload.get("entries", []),
        "skipped": payload.get("skipped", {}),
    }


@app.get("/api/tools/stage-config")
def get_stage_tool_config() -> dict[str, Any]:
    from core.stage_tool_config import ensure_user_stage_tool_config_seeded, load_stage_tool_config

    # On first read (no personal config yet), seed the user config with repo-declared
    # defaults so the UI immediately reflects a reasonable starting allowlist.
    seeded_path, seeded = ensure_user_stage_tool_config_seeded(repo_root())
    cfg = load_stage_tool_config(repo_root())
    return {
        "schema_version": cfg.schema_version,
        "stages": cfg.stages,
        "sources": cfg.sources,
        "seeded": seeded,
        "seeded_path": seeded_path if seeded else None,
    }


@app.put("/api/tools/stage-config")
def put_stage_tool_config(payload: dict[str, Any]) -> dict[str, Any]:
    from core.stage_tool_config import load_stage_tool_config, save_stage_tool_config

    stages = payload.get("stages")
    if not isinstance(stages, dict):
        raise HTTPException(status_code=400, detail="invalid_stages")
    scope = str(payload.get("scope") or "user").strip().lower()
    path = save_stage_tool_config(repo_root(), stages, scope=scope)
    cfg = load_stage_tool_config(repo_root())
    return {"ok": True, "saved_to": path, "schema_version": cfg.schema_version, "stages": cfg.stages, "sources": cfg.sources}


@app.post("/api/tools/stage-config/reset")
def reset_stage_tool_config() -> dict[str, Any]:
    """Overwrite user stage_tools.json with the repo-declared defaults."""
    from core.stage_tool_config import load_stage_tool_config, reset_user_stage_tool_config_to_defaults

    path = reset_user_stage_tool_config_to_defaults(repo_root())
    cfg = load_stage_tool_config(repo_root())
    return {
        "ok": True,
        "saved_to": path,
        "schema_version": cfg.schema_version,
        "stages": cfg.stages,
        "sources": cfg.sources,
    }


@app.get("/api/tools/stage-config/defaults")
def get_stage_tool_config_defaults() -> dict[str, Any]:
    """Preview repo-declared defaults without writing any file."""
    from core.stage_tool_config import default_stage_tool_config

    return {"stages": default_stage_tool_config(repo_root())}


@app.get("/api/context/policy")
def get_context_policy(stage: str | None = Query(None)) -> dict[str, Any]:
    from core.stage_context_policy import (
        ensure_user_stage_context_policy_seeded,
        get_stage_output_requirements,
        get_stage_policy_rules,
        get_stage_tool_instructions,
        load_stage_context_policy,
    )

    seeded = False
    seeded_path = None
    normalized_stage = str(stage or "").strip()
    if normalized_stage:
        seeded_path, seeded = ensure_user_stage_context_policy_seeded(repo_root(), stage=normalized_stage)
    cfg = load_stage_context_policy(repo_root())
    if stage:
        return {
            "schema_version": cfg.schema_version,
            "stage": stage,
            "rules": get_stage_policy_rules(cfg, stage),
            "output_requirements": get_stage_output_requirements(cfg, stage),
            "tool_instructions": get_stage_tool_instructions(cfg, stage),
            "source": cfg.source,
            "seeded": seeded,
            "seeded_path": seeded_path if seeded else None,
        }
    return {
        "schema_version": cfg.schema_version,
        "policies": cfg.policies,
        "source": cfg.source,
        "seeded": seeded,
        "seeded_path": seeded_path if seeded else None,
    }


@app.put("/api/context/policy")
def put_context_policy(payload: dict[str, Any]) -> dict[str, Any]:
    from core.stage_context_policy import (
        StageContextPolicyValidationError,
        get_stage_output_requirements,
        get_stage_policy_rules,
        get_stage_tool_instructions,
        save_stage_context_policy,
    )

    stage = str(payload.get("stage") or "").strip()
    rules = payload.get("rules")
    output_requirements = str(payload.get("output_requirements") or "")
    tool_instructions = str(payload.get("tool_instructions") or "")
    if not stage:
        raise HTTPException(status_code=400, detail="stage is required")
    try:
        cfg = save_stage_context_policy(
            repo_root(),
            stage,
            rules,
            output_requirements=output_requirements,
            tool_instructions=tool_instructions,
        )
    except StageContextPolicyValidationError as e:
        raise HTTPException(status_code=400, detail={"code": "invalid_context_policy", "errors": e.errors})
    return {
        "ok": True,
        "schema_version": cfg.schema_version,
        "stage": stage,
        "rules": get_stage_policy_rules(cfg, stage),
        "output_requirements": get_stage_output_requirements(cfg, stage),
        "tool_instructions": get_stage_tool_instructions(cfg, stage),
        "source": cfg.source,
    }


@app.post("/api/context/policy/reset")
def reset_context_policy(payload: dict[str, Any] | None = Body(default=None)) -> dict[str, Any]:
    from core.stage_context_policy import (
        get_stage_output_requirements,
        get_stage_policy_rules,
        get_stage_tool_instructions,
        reset_stage_context_policy,
        reset_stage_context_policy_to_defaults,
    )

    body = payload if isinstance(payload, dict) else {}
    stage = str(body.get("stage") or "").strip() or None
    cfg = reset_stage_context_policy_to_defaults(repo_root(), stage=stage) if stage else reset_stage_context_policy(repo_root(), stage)
    if stage:
        return {
            "ok": True,
            "schema_version": cfg.schema_version,
            "stage": stage,
            "rules": get_stage_policy_rules(cfg, stage),
            "output_requirements": get_stage_output_requirements(cfg, stage),
            "tool_instructions": get_stage_tool_instructions(cfg, stage),
            "source": cfg.source,
        }
    return {
        "ok": True,
        "schema_version": cfg.schema_version,
        "policies": cfg.policies,
        "source": cfg.source,
    }


@app.get("/api/context/policy/tools")
def get_context_policy_tools(stage: str = Query(..., min_length=1)) -> dict[str, Any]:
    from core.stage_context_policy import list_effective_stage_policy_tools, stage_supports_context_policy

    return {
        "stage": stage,
        "supported": stage_supports_context_policy(stage),
        "entries": list_effective_stage_policy_tools(repo_root(), stage),
    }


@app.get("/api/acceptance/policy")
def get_acceptance_policy(stage: str | None = Query(None)) -> dict[str, Any]:
    from core.stage_acceptance import (
        acceptance_result_from_metadata,
        load_stage_acceptance_state,
        stage_output_result_from_repo,
    )
    from core.stage_acceptance_policy import ensure_user_stage_acceptance_policy_seeded, load_stage_acceptance_policy

    seeded = False
    seeded_path = None
    normalized_stage = str(stage or "").strip()
    if normalized_stage:
        seeded_path, seeded = ensure_user_stage_acceptance_policy_seeded(repo_root(), stage=normalized_stage)
    cfg = load_stage_acceptance_policy(repo_root())
    if stage:
        active = _active_paths()
        progress = read_progress(active.progress_file) or {} if active is not None else {}
        metadata = progress.get("metadata") if isinstance(progress.get("metadata"), dict) else {}
        state = load_stage_acceptance_state(stage, repo_root=repo_root())
        return {
            **state,
            "stage": stage,
            "latest_result": acceptance_result_from_metadata(metadata, stage),
            "latest_stage_output": stage_output_result_from_repo(metadata=metadata, stage=stage, repo_root=repo_root()),
            "seeded": seeded,
            "seeded_path": seeded_path if seeded else None,
        }
    return {
        "schema_version": cfg.schema_version,
        "policies": cfg.policies,
        "source": cfg.source,
        "seeded": seeded,
        "seeded_path": seeded_path if seeded else None,
    }


@app.get("/api/acceptance/policy/tools")
def get_acceptance_policy_tools(stage: str = Query(..., min_length=1)) -> dict[str, Any]:
    from core.stage_acceptance_policy import list_available_acceptance_policy_tools, stage_supports_acceptance_policy

    return {
        "stage": stage,
        "supported": stage_supports_acceptance_policy(stage),
        "entries": list_available_acceptance_policy_tools(repo_root(), stage),
    }


@app.put("/api/acceptance/policy")
def put_acceptance_policy(payload: dict[str, Any]) -> dict[str, Any]:
    from core.stage_acceptance import (
        acceptance_result_from_metadata,
        load_stage_acceptance_state,
        stage_output_result_from_repo,
    )
    from core.stage_acceptance_policy import StageAcceptancePolicyValidationError, save_stage_acceptance_policy

    stage = str(payload.get("stage") or "").strip()
    if not stage:
        raise HTTPException(status_code=400, detail="stage is required")
    body = {
        "enabled": bool(payload.get("enabled", True)),
        "prompt": str(payload.get("prompt") or ""),
        "model": str(payload.get("model") or ""),
        "rules": payload.get("rules") if "rules" in payload else [],
        "max_retries": payload.get("max_retries", 2),
    }
    try:
        save_stage_acceptance_policy(repo_root(), stage, body)
    except StageAcceptancePolicyValidationError as e:
        raise HTTPException(status_code=400, detail={"code": "invalid_acceptance_policy", "errors": e.errors})
    active = _active_paths()
    progress_path = active.progress_file if active is not None else os.path.join(repo_root(), ".harness", "preview-progress.json")
    progress = read_progress(progress_path) or {}
    metadata = progress.get("metadata") if isinstance(progress.get("metadata"), dict) else {}
    state = load_stage_acceptance_state(stage, repo_root=repo_root())
    return {
        **state,
        "stage": stage,
        "latest_result": acceptance_result_from_metadata(metadata, stage),
        "latest_stage_output": stage_output_result_from_repo(metadata=metadata, stage=stage, repo_root=repo_root()),
    }


@app.post("/api/acceptance/policy/reset")
def reset_acceptance_policy(payload: dict[str, Any] | None = Body(default=None)) -> dict[str, Any]:
    from core.stage_acceptance import (
        acceptance_result_from_metadata,
        load_stage_acceptance_state,
        stage_output_result_from_repo,
    )
    from core.stage_acceptance_policy import reset_stage_acceptance_policy, reset_stage_acceptance_policy_to_defaults

    body = payload if isinstance(payload, dict) else {}
    stage = str(body.get("stage") or "").strip() or None
    cfg = reset_stage_acceptance_policy_to_defaults(repo_root(), stage=stage) if stage else reset_stage_acceptance_policy(repo_root(), stage)
    if stage:
        active = _active_paths()
        progress = read_progress(active.progress_file) or {} if active is not None else {}
        metadata = progress.get("metadata") if isinstance(progress.get("metadata"), dict) else {}
        state = load_stage_acceptance_state(stage, repo_root=repo_root())
        return {
            **state,
            "stage": stage,
            "latest_result": acceptance_result_from_metadata(metadata, stage),
            "latest_stage_output": stage_output_result_from_repo(metadata=metadata, stage=stage, repo_root=repo_root()),
        }
    return {
        "ok": True,
        "schema_version": cfg.schema_version,
        "policies": cfg.policies,
        "source": cfg.source,
    }


@app.post("/api/acceptance/policy/preview")
def preview_acceptance_policy(
    stage: str = Query(..., min_length=1),
    payload: dict[str, Any] | None = Body(default=None),
) -> dict[str, Any]:
    from core.stage_acceptance import (
        AcceptanceValidationError,
        acceptance_result_from_metadata,
        build_acceptance_preview_prompt,
        load_stage_acceptance_state,
        stage_output_result_from_repo,
    )
    from core.stage_output import StageOutputValidationError
    from core.stage_acceptance_policy import (
        StageAcceptancePolicyValidationError,
        build_acceptance_preview_warnings,
        get_stage_acceptance_entry,
        load_stage_acceptance_policy,
        validate_stage_acceptance_entry,
    )
    from core.context_manager import ContextManager

    body = payload if isinstance(payload, dict) else {}
    loaded_cfg = load_stage_acceptance_policy(repo_root())
    loaded_entry = get_stage_acceptance_entry(loaded_cfg, stage)
    state = load_stage_acceptance_state(stage, repo_root=repo_root())
    draft = {
        "enabled": bool(body.get("enabled", loaded_entry.enabled)),
        "prompt": str(body.get("prompt") if "prompt" in body else loaded_entry.prompt),
        "model": str(body.get("model") if "model" in body else loaded_entry.model),
        "max_retries": body.get("max_retries", loaded_entry.max_retries),
        "rules": body.get("rules") if "rules" in body else loaded_entry.rules,
    }
    warnings = build_acceptance_preview_warnings(repo_root(), stage, draft)
    if not bool(state.get("supported")):
        warnings = list(warnings or [])
        warnings.append(f"acceptance_preview_unsupported_stage: {stage}")
        active = _active_paths()
        progress = read_progress(active.progress_file) or {} if active is not None else {}
        metadata = progress.get("metadata") if isinstance(progress.get("metadata"), dict) else {}
        return {
            "stage": stage,
            "supported": False,
            "enabled": bool(draft.get("enabled")),
            "model": str(draft.get("model") or ""),
            "max_retries": int(draft.get("max_retries", 2)),
            "rules": draft.get("rules") if isinstance(draft.get("rules"), list) else [],
            "warnings": warnings,
            "prompt": "",
            "latest_result": acceptance_result_from_metadata(metadata, stage),
            "latest_stage_output": stage_output_result_from_repo(metadata=metadata, stage=stage, repo_root=repo_root()),
        }
    try:
        entry = validate_stage_acceptance_entry(repo_root(), stage, draft)
    except StageAcceptancePolicyValidationError as e:
        if draft.get("enabled"):
            raise HTTPException(status_code=400, detail={"code": "invalid_acceptance_policy", "errors": e.errors})
        entry = type("AcceptancePreviewEntry", (), draft)()
    active = _active_paths()
    progress_file = active.progress_file if active is not None else os.path.join(repo_root(), ".harness", "preview-progress.json")
    progress = read_progress(progress_file) or {}
    metadata = progress.get("metadata") if isinstance(progress.get("metadata"), dict) else {}
    prompt = ""
    if entry.enabled and bool(state.get("supported")):
        cm = ContextManager(progress_file, repo_root=repo_root())
        stage_ctx = cm.build_stage_context(stage, repo_root=repo_root())
        try:
            prompt, blocked_reason = build_acceptance_preview_prompt(
                stage_ctx=stage_ctx,
                stage=stage,
                acceptance_prompt=entry.prompt,
                acceptance_rules=entry.rules if hasattr(entry, "rules") else [],
            )
            if blocked_reason:
                warnings = list(warnings or [])
                warnings.append(f"acceptance_preview_blocked: {blocked_reason}")
        except (StageOutputValidationError, AcceptanceValidationError) as exc:
            warnings = list(warnings or [])
            warnings.append(f"acceptance_preview_blocked: {exc}")
            prompt = ""
    elif entry.enabled and not bool(state.get("supported")):
        warnings = list(warnings or [])
        warnings.append(f"acceptance_preview_unsupported_stage: {stage}")
    return {
        "stage": stage,
        "supported": bool(state.get("supported")),
        "enabled": bool(entry.enabled),
        "model": entry.model,
        "max_retries": int(getattr(entry, "max_retries", 2)),
        "rules": entry.rules if hasattr(entry, "rules") else [],
        "warnings": warnings,
        "prompt": prompt,
        "latest_result": acceptance_result_from_metadata(metadata, stage),
        "latest_stage_output": stage_output_result_from_repo(metadata=metadata, stage=stage, repo_root=repo_root()),
    }


@app.post("/api/context/policy/preview")
def preview_context_policy(
    stage: str = Query(..., min_length=1),
    payload: dict[str, Any] | None = Body(default=None),
) -> dict[str, Any]:
    from core.context_layer import render_stage_prompt
    from core.context_manager import ContextManager
    from core.stage_context_policy import (
        StageContextPolicyValidationError,
        build_policy_preview_warnings,
        get_stage_output_requirements,
        get_stage_policy_rules,
        get_stage_tool_instructions,
        list_effective_stage_policy_tools,
        load_stage_context_policy,
        stage_supports_context_policy,
        validate_stage_policy_rules,
    )

    active = _active_paths()
    progress_file = active.progress_file if active is not None else os.path.join(repo_root(), ".harness", "preview-progress.json")
    cm = ContextManager(progress_file, repo_root=repo_root())
    body = payload if isinstance(payload, dict) else {}
    draft_rules = body.get("rules")
    draft_output_requirements = body.get("output_requirements")
    draft_tool_instructions = body.get("tool_instructions")
    requirement_override = body.get("requirement")
    warnings = build_policy_preview_warnings(stage, draft_rules if draft_rules is not None else [])
    loaded_cfg = load_stage_context_policy(repo_root())
    if draft_rules is None:
        rules = get_stage_policy_rules(loaded_cfg, stage)
    else:
        try:
            rules = validate_stage_policy_rules(repo_root(), stage, draft_rules)
        except StageContextPolicyValidationError as e:
            raise HTTPException(status_code=400, detail={"code": "invalid_context_policy", "errors": e.errors})
    output_requirements = (
        str(draft_output_requirements).strip()
        if draft_output_requirements is not None
        else get_stage_output_requirements(loaded_cfg, stage)
    )
    tool_instructions = (
        str(draft_tool_instructions).strip()
        if draft_tool_instructions is not None
        else get_stage_tool_instructions(loaded_cfg, stage)
    )
    stage_ctx = cm.build_stage_context(
        stage,
        repo_root=repo_root(),
        policy_rules_override=rules,
        output_requirements_override=output_requirements,
        tool_instructions_override=tool_instructions,
        requirement_override=str(requirement_override) if requirement_override is not None else None,
    )
    prompt = render_stage_prompt(stage, stage_ctx)
    return {
        "stage": stage,
        "supported": stage_supports_context_policy(stage),
        "rules": rules,
        "output_requirements": output_requirements,
        "tool_instructions": tool_instructions,
        "warnings": warnings,
        "effective_tools": list_effective_stage_policy_tools(repo_root(), stage),
        "prompt": prompt,
    }


@app.get("/api/tools/cli-registry")
def list_cli_registry() -> dict[str, Any]:
    from core.cli_registry import cli_tools_path, list_registered

    return {"entries": list_registered(repo_root()), "path": cli_tools_path(repo_root())}


@app.post("/api/tools/cli-registry")
def register_cli_registry(payload: dict[str, Any]) -> dict[str, Any]:
    from core.cli_registry import CliRegistryError, list_registered, register_cli

    overwrite = bool(payload.get("overwrite") or False)
    try:
        saved, created_new = register_cli(repo_root(), payload, overwrite=overwrite)
    except CliRegistryError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {
        "ok": True,
        "saved_to": saved,
        "created_new": created_new,
        "entries": list_registered(repo_root()),
    }


@app.delete("/api/tools/cli-registry/{name}")
def delete_cli_registry(name: str) -> dict[str, Any]:
    from core.cli_registry import CliRegistryError, delete_cli, list_registered

    try:
        saved, removed = delete_cli(repo_root(), name)
    except CliRegistryError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    if not removed:
        raise HTTPException(status_code=404, detail=f"not_found: {name}")
    return {"ok": True, "saved_to": saved, "removed": removed, "entries": list_registered(repo_root())}


@app.get("/api/tools/mcp-registry")
def list_mcp_registry() -> dict[str, Any]:
    from core.mcp_registry import list_registered, mcp_path

    return {"entries": list_registered(repo_root()), "path": mcp_path(repo_root())}


@app.post("/api/tools/mcp-registry")
def register_mcp_registry(payload: dict[str, Any]) -> dict[str, Any]:
    from core.mcp_registry import McpRegistryError, list_registered, register_mcp

    overwrite = bool(payload.get("overwrite") or False)
    try:
        saved, created_new = register_mcp(repo_root(), payload, overwrite=overwrite)
    except McpRegistryError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {
        "ok": True,
        "saved_to": saved,
        "created_new": created_new,
        "entries": list_registered(repo_root()),
    }


@app.delete("/api/tools/mcp-registry/{name}")
def delete_mcp_registry(name: str) -> dict[str, Any]:
    from core.mcp_registry import McpRegistryError, delete_mcp, list_registered

    try:
        saved, removed = delete_mcp(repo_root(), name)
    except McpRegistryError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not removed:
        raise HTTPException(status_code=404, detail=f"not_found: {name}")
    return {"ok": True, "saved_to": saved, "removed": removed, "entries": list_registered(repo_root())}


@app.get("/api/mcp/status")
async def api_mcp_status(stage: str | None = Query(None)) -> dict[str, Any]:
    return await mcp_probe.get_status_payload(stage=stage, workspace_root=repo_root())


@app.post("/api/mcp/probe")
async def api_mcp_probe(
    stage: str | None = Query(None),
    name: str | None = Query(None),
    force: bool = Query(False),
) -> dict[str, Any]:
    return await mcp_probe.run_probe(stage=stage, workspace_root=repo_root(), name=name, force=force)


@app.get("/api/runs/{run_id}/trace")
def get_trace(
    run_id: str,
    offset: int = Query(0, ge=0),
    limit: int = Query(200, ge=1, le=2000),
    state: str | None = Query(None),
    type: str | None = Query(None),
    tail: bool = Query(False),
) -> dict[str, Any]:
    active = _require_active_paths()
    trace_path = os.path.join(active.runs_root, run_id, "trace.ndjson")
    try:
        ensure_within_repo(trace_path)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    if not os.path.exists(trace_path):
        raise HTTPException(status_code=404, detail="trace_not_found")
    if tail:
        # Tail with filters applied to avoid returning empty sets when limit is small.
        events = tail_ndjson_filtered(trace_path, limit=limit, state=state, type_=type)
        next_offset = None
        offset = None
    else:
        events, next_offset = slice_events(
            iter_ndjson(trace_path),
            offset=offset,
            limit=limit,
            state=state,
            type_=type,
        )
    return {
        "run_id": run_id,
        "trace_path": trace_path,
        "offset": offset,
        "next_offset": next_offset,
        "limit": limit,
        "filters": {"state": state, "type": type, "tail": tail},
        "events": events,
    }


@app.get("/api/fs/preview")
def preview_path(
    path: str = Query(..., description="Path under repo root, absolute or relative to repo root."),
    max_entries: int = Query(200, ge=1, le=2000),
    max_chars: int = Query(200_000, ge=1, le=2_000_000),
) -> dict[str, Any]:
    # Resolve path against repo root when relative.
    candidate = path
    if not os.path.isabs(candidate):
        candidate = os.path.join(repo_root(), candidate)
    try:
        candidate = ensure_within_repo(candidate)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    if not os.path.exists(candidate):
        return {"type": "missing", "path": candidate}
    if os.path.isdir(candidate):
        entries: list[str] = []
        for root, dirs, files in os.walk(candidate):
            for d in sorted(dirs):
                entries.append(os.path.relpath(os.path.join(root, d), candidate) + os.sep)
                if len(entries) >= max_entries:
                    break
            if len(entries) >= max_entries:
                break
            for f in sorted(files):
                entries.append(os.path.relpath(os.path.join(root, f), candidate))
                if len(entries) >= max_entries:
                    break
            if len(entries) >= max_entries:
                break
        return {"type": "dir", "path": candidate, "entries": entries, "truncated": len(entries) >= max_entries}

    # file
    ext = os.path.splitext(candidate)[1].lower()
    with open(candidate, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()
    truncated = False
    if max_chars and len(content) > max_chars:
        content = content[:max_chars]
        truncated = True
    return {"type": "file", "path": candidate, "ext": ext, "content": content, "truncated": truncated}


@app.post("/api/run/start")
def api_start_run(
    requirement: str = Query(..., min_length=1),
    max_quality_loop_retries: int = Query(5, ge=0, le=20),
    coco_model_name: str | None = Query(None),
) -> dict[str, Any]:
    pid = start_run(
        requirement=requirement,
        max_quality_loop_retries=max_quality_loop_retries,
        coco_model_name=coco_model_name,
        repo_root=repo_root(),
    )
    return {"pid": pid}

@app.post("/api/run/resume")
def api_resume_run(
    coco_model_name: str | None = Query(None),
) -> dict[str, Any]:
    pid = resume_run(coco_model_name=coco_model_name, repo_root=repo_root())
    return {"pid": pid}


@app.post("/api/run/retry-stage")
def api_retry_stage_run(
    stage: str = Query(..., min_length=1),
    coco_model_name: str | None = Query(None),
) -> dict[str, Any]:
    try:
        pid, resume_state = retry_stage_run(stage=stage, coco_model_name=coco_model_name, repo_root=repo_root())
    except RetryStageError as exc:
        detail = str(exc)
        if detail == "active_run_required":
            raise HTTPException(status_code=409, detail=detail) from exc
        raise HTTPException(status_code=400, detail=detail) from exc
    return {"pid": pid, "retried_stage": stage, "resume_state": resume_state}


@app.post("/api/run/stop")
def api_stop_run() -> dict[str, Any]:
    ok = stop_run(repo_root=repo_root())
    return {"stopped": bool(ok)}


@app.post("/api/run/reset")
def api_reset() -> dict[str, Any]:
    reset_outputs(repo_root=repo_root())
    return {"ok": True}


@app.get("/api/settings")
def get_settings() -> dict[str, Any]:
    from core.context_manager import (
        ContextManager,
        DEFAULT_MAX_STAGE_RETRIES,
        normalize_stage_max_retries_map,
        resolve_stage_max_retries,
    )
    from core.orchestrator import DEFAULT_STAGE_TIMEOUTS_SEC, FlowState

    active = _require_active_paths()
    cm = ContextManager(active.progress_file, repo_root=repo_root())
    meta = cm.context.get("metadata", {}) if isinstance(cm.context.get("metadata"), dict) else {}

    raw_timeouts = meta.get("stage_timeouts_sec", {})
    if not isinstance(raw_timeouts, dict):
        raw_timeouts = {}
    effective_timeouts = dict(DEFAULT_STAGE_TIMEOUTS_SEC)
    for k, v in raw_timeouts.items():
        effective_timeouts[str(k)] = v

    stage_keys = {
        FlowState.PRD_DRAFTING.value,
        FlowState.TECH_SPEC_DRAFTING.value,
        FlowState.CODING.value,
        FlowState.QUALITY_LOOP.value,
        FlowState.DEPLOYING.value,
        FlowState.REGRESSION_TESTING.value,
    }
    stage_keys.update({str(k) for k in DEFAULT_STAGE_TIMEOUTS_SEC.keys()})
    stage_keys.update({str(k) for k in (meta.get("stage_retry_count") or {}).keys() if str(k).strip()})
    stage_keys.update({str(k) for k in (meta.get("stage_max_retries") or {}).keys() if str(k).strip()})
    raw_stage_max_retries = normalize_stage_max_retries_map(meta.get("stage_max_retries"))
    effective_stage_max_retries = {
        stage: resolve_stage_max_retries(meta, stage)
        for stage in sorted(stage_keys)
    }

    quality_loop = meta.get("quality_loop") if isinstance(meta.get("quality_loop"), dict) else {}
    max_quality_loop_retries = quality_loop.get("max_retries", 5)
    return {
        "max_stage_retries": meta.get("max_stage_retries", DEFAULT_MAX_STAGE_RETRIES),
        "stage_max_retries": effective_stage_max_retries,
        "stage_max_retries_overrides": raw_stage_max_retries,
        "max_quality_loop_retries": max_quality_loop_retries,
        "stage_timeouts_sec": effective_timeouts,
        "stage_timeouts_overrides_sec": raw_timeouts,
        "defaults": {
            "max_stage_retries": DEFAULT_MAX_STAGE_RETRIES,
            "max_quality_loop_retries": 5,
            "stage_timeouts_sec": DEFAULT_STAGE_TIMEOUTS_SEC,
        },
    }


@app.put("/api/settings")
def update_settings(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
    from core.context_manager import ContextManager, normalize_stage_max_retries_map

    active = _require_active_paths()
    cm = ContextManager(active.progress_file, repo_root=repo_root())
    meta = cm.context.get("metadata", {}) if isinstance(cm.context.get("metadata"), dict) else {}

    if "max_stage_retries" in payload:
        try:
            meta["max_stage_retries"] = int(payload["max_stage_retries"])
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="invalid_max_stage_retries")

    if "stage_max_retries" in payload:
        raw = payload["stage_max_retries"]
        if not isinstance(raw, dict):
            raise HTTPException(status_code=400, detail="invalid_stage_max_retries")
        prev = normalize_stage_max_retries_map(meta.get("stage_max_retries"))
        next_stage_max_retries: dict[str, int] = {str(k): int(v) for k, v in prev.items()}
        for k, v in raw.items():
            key = str(k or "").strip()
            if not key:
                continue
            if v is None:
                next_stage_max_retries.pop(key, None)
                continue
            try:
                parsed = int(v)
            except (TypeError, ValueError):
                raise HTTPException(status_code=400, detail=f"invalid_stage_max_retries:{key}")
            if parsed < 0:
                raise HTTPException(status_code=400, detail=f"invalid_stage_max_retries:{key}")
            next_stage_max_retries[key] = parsed
        meta["stage_max_retries"] = next_stage_max_retries

    if "max_quality_loop_retries" in payload:
        try:
            quality_loop = meta.get("quality_loop") if isinstance(meta.get("quality_loop"), dict) else {}
            quality_loop["max_retries"] = int(payload["max_quality_loop_retries"])
            meta["quality_loop"] = quality_loop
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="invalid_max_quality_loop_retries")
    if "stage_timeouts_sec" in payload:
        raw = payload["stage_timeouts_sec"]
        if not isinstance(raw, dict):
            raise HTTPException(status_code=400, detail="invalid_stage_timeouts_sec")
        # Normalize keys to strings, values to floats; allow null to delete a key.
        prev = meta.get("stage_timeouts_sec", {})
        if not isinstance(prev, dict):
            prev = {}
        next_timeouts: dict[str, Any] = {str(k): v for k, v in prev.items()}
        for k, v in raw.items():
            key = str(k)
            if v is None:
                next_timeouts.pop(key, None)
                continue
            try:
                next_timeouts[key] = float(v)
            except (TypeError, ValueError):
                raise HTTPException(status_code=400, detail=f"invalid_stage_timeout_sec:{key}")
        meta["stage_timeouts_sec"] = next_timeouts

    cm.context["metadata"] = meta
    cm.save()
    return {"status": "ok", "settings": get_settings()}


def _ui_index_path() -> str:
    static_root = frontend_static_root()
    if not static_root:
        raise HTTPException(status_code=503, detail="ui_static_not_built")
    index_path = os.path.join(static_root, "index.html")
    if not os.path.exists(index_path):
        raise HTTPException(status_code=503, detail="ui_static_not_built")
    return index_path


@app.get("/", include_in_schema=False)
def serve_ui_index() -> FileResponse:
    return FileResponse(_ui_index_path())


@app.get("/{path:path}", include_in_schema=False)
def serve_ui_path(path: str) -> FileResponse:
    normalized = str(path or "").strip().lstrip("/")
    if not normalized or normalized == "api" or normalized.startswith("api/"):
        raise HTTPException(status_code=404, detail="not_found")

    index_path = _ui_index_path()
    static_root = os.path.dirname(index_path)
    candidate = os.path.realpath(os.path.join(static_root, normalized))
    if os.path.commonpath([candidate, static_root]) != static_root:
        raise HTTPException(status_code=404, detail="not_found")
    if os.path.isfile(candidate):
        return FileResponse(candidate)
    return FileResponse(index_path)
