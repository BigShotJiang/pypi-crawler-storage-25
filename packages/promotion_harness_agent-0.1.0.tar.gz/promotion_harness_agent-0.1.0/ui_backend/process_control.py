from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any, Sequence

from core.context_manager import update_progress_json_atomic
from core.orchestrator import FlowState
from core.run_trace import append_event, generate_run_id, init_trace
from core.runtime_paths import active_run_paths, clear_current_run, resolve_repo_root, runtime_paths_for_run
from core.stage_acceptance import clear_acceptance_result
from ui_runtime import launch_pipeline_process, reset_workspace_outputs, stop_previous_run


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _mark_run_stopped(progress_path: str) -> None:
    def _apply(current: dict[str, object]) -> dict[str, object]:
        metadata = current.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        previous_state = str(current.get("state") or "").strip()
        metadata["stopped_at"] = _utc_now_iso()
        if previous_state:
            metadata["last_stopped_state"] = previous_state
        current["metadata"] = metadata
        current["state"] = "STOPPED"
        return current

    update_progress_json_atomic(progress_path, _apply)


def _stop_previous_run_compat(*, repo_root: str) -> bool:
    try:
        return bool(stop_previous_run(repo_root=repo_root))
    except TypeError:
        return bool(stop_previous_run())


def start_run(
    requirement: str,
    max_quality_loop_retries: int = 5,
    coco_model_name: str | None = None,
    repo_root: str | None = None,
) -> int:
    resolved_repo_root = resolve_repo_root(repo_root)
    # Keep behavior aligned with existing UI runtime:
    # - stop previous run
    # - clear active run metadata
    # - reset .harness run outputs
    _stop_previous_run_compat(repo_root=resolved_repo_root)
    active = active_run_paths(resolved_repo_root)
    if active and os.path.exists(active.progress_file):
        os.remove(active.progress_file)
    clear_current_run(resolved_repo_root)
    reset_workspace_outputs(repo_root=resolved_repo_root)
    run_id = generate_run_id()
    paths = runtime_paths_for_run(run_id, resolved_repo_root)
    os.makedirs(paths.logs_root, exist_ok=True)

    cmd: list[str] = [
        "uv",
        "run",
        "python",
        "run.py",
        "--requirement",
        requirement,
        "--max-quality-loop-retries",
        str(int(max_quality_loop_retries)),
        "--repo-root",
        resolved_repo_root,
        "--run-id",
        run_id,
    ]
    if coco_model_name:
        cmd += ["--coco-model-name", coco_model_name]
    return launch_pipeline_process(
        cmd,
        cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        repo_root=resolved_repo_root,
        log_path=os.path.join(paths.logs_root, "ui_run.log"),
    )

def resume_run(coco_model_name: str | None = None, repo_root: str | None = None) -> int:
    resolved_repo_root = resolve_repo_root(repo_root)
    # Resume an existing run WITHOUT clearing active-run progress or run outputs.
    # This is required for the "authorize then continue" UX.
    _stop_previous_run_compat(repo_root=resolved_repo_root)
    cmd: list[str] = ["uv", "run", "python", "run.py", "--resume", "--repo-root", resolved_repo_root]
    if coco_model_name:
        cmd += ["--coco-model-name", coco_model_name]
    active = active_run_paths(resolved_repo_root)
    return launch_pipeline_process(
        cmd,
        cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        repo_root=resolved_repo_root,
        log_path=os.path.join(active.logs_root, "ui_run.log") if active is not None else None,
    )


_RETRYABLE_STAGE_VALUES = {
    FlowState.PRD_DRAFTING.value,
    FlowState.TECH_SPEC_DRAFTING.value,
    FlowState.CODING.value,
    FlowState.QUALITY_LOOP.value,
    FlowState.DEPLOYING.value,
    FlowState.REGRESSION_TESTING.value,
    FlowState.VERIFYING.value,
    FlowState.FIXING.value,
}


class RetryStageError(ValueError):
    pass


def _mapped_retry_state(stage: str) -> tuple[str, str | None]:
    normalized = str(stage or "").strip()
    if normalized not in _RETRYABLE_STAGE_VALUES:
        raise RetryStageError("invalid_retry_stage")
    if normalized == FlowState.VERIFYING.value:
        return FlowState.QUALITY_LOOP.value, "verify"
    if normalized == FlowState.FIXING.value:
        return FlowState.QUALITY_LOOP.value, "fix"
    return normalized, None


def _clear_stage_result_state(metadata: dict[str, Any], stage: str) -> None:
    normalized = str(stage or "").strip()
    stage_results = metadata.get("stage_results")
    if isinstance(stage_results, dict):
        stage_results.pop(normalized, None)
    refs = metadata.get("stage_output_refs")
    if isinstance(refs, dict):
        refs.pop(normalized, None)
    last_result = metadata.get("last_stage_result")
    if isinstance(last_result, dict) and str(last_result.get("stage") or "").strip() == normalized:
        metadata.pop("last_stage_result", None)
    last_output_path = metadata.get("last_stage_output_path")
    if isinstance(last_output_path, str) and normalized and normalized in last_output_path:
        metadata.pop("last_stage_output_path", None)


def _rewrite_progress_for_stage_retry(progress_path: str, *, stage: str, active_run_auth_block_file: str) -> tuple[str, dict[str, Any] | None]:
    normalized = str(stage or "").strip()
    resume_state, quality_loop_phase = _mapped_retry_state(normalized)
    updated_doc: dict[str, Any] | None = None

    def _apply(current: dict[str, Any]) -> dict[str, Any]:
        nonlocal updated_doc
        metadata = current.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
            current["metadata"] = metadata

        requested_from_state = str(current.get("state") or "").strip()
        current["state"] = resume_state
        metadata["manual_retry"] = {
            "stage": normalized,
            "requested_at": _utc_now_iso(),
            "requested_from_state": requested_from_state,
            "mapped_resume_state": resume_state,
        }

        if quality_loop_phase:
            metadata["quality_loop_phase"] = quality_loop_phase
            quality_loop = metadata.get("quality_loop")
            if isinstance(quality_loop, dict):
                quality_loop["phase"] = quality_loop_phase
        elif resume_state == FlowState.QUALITY_LOOP.value:
            quality_loop = metadata.get("quality_loop")
            if isinstance(quality_loop, dict):
                phase = str(quality_loop.get("phase") or "").strip().lower()
                if phase:
                    metadata["quality_loop_phase"] = phase

        last_gate_denial = metadata.get("last_gate_denial")
        if isinstance(last_gate_denial, dict) and str(last_gate_denial.get("stage") or "").strip() == normalized:
            metadata.pop("last_gate_denial", None)

        metadata.pop("auth_block", None)
        metadata.pop("auth_block_stage", None)
        metadata.pop("auth_block_path", None)
        if metadata.get("run_outcome") == "auth_blocked":
            metadata.pop("run_outcome", None)

        clear_acceptance_result(metadata, normalized)
        _clear_stage_result_state(metadata, normalized)
        updated_doc = current
        return current

    update_progress_json_atomic(progress_path, _apply)
    try:
        if active_run_auth_block_file and os.path.exists(active_run_auth_block_file):
            os.remove(active_run_auth_block_file)
    except OSError:
        pass
    return resume_state, updated_doc


def retry_stage_run(stage: str, coco_model_name: str | None = None, repo_root: str | None = None) -> tuple[int, str]:
    resolved_repo_root = resolve_repo_root(repo_root)
    active = active_run_paths(resolved_repo_root)
    if active is None or not os.path.exists(active.progress_file):
        raise RetryStageError("active_run_required")

    _stop_previous_run_compat(repo_root=resolved_repo_root)
    resume_state, progress = _rewrite_progress_for_stage_retry(
        active.progress_file,
        stage=stage,
        active_run_auth_block_file=active.auth_block_file,
    )
    init_trace(active.run_id, active.run_root)
    append_event(
        "manual_stage_retry_requested",
        state=resume_state,
        data={
            "stage": str(stage or "").strip(),
            "requested_from_state": ((progress or {}).get("metadata") or {}).get("manual_retry", {}).get("requested_from_state"),
            "mapped_resume_state": resume_state,
        },
    )
    pid = resume_run(coco_model_name=coco_model_name, repo_root=resolved_repo_root)
    return pid, resume_state


def stop_run(repo_root: str | None = None) -> bool:
    resolved_repo_root = resolve_repo_root(repo_root)
    stopped = _stop_previous_run_compat(repo_root=resolved_repo_root)
    active = active_run_paths(resolved_repo_root)
    if stopped and active and os.path.exists(active.progress_file):
        _mark_run_stopped(active.progress_file)
    return stopped


def reset_outputs(repo_root: str | None = None) -> None:
    resolved_repo_root = resolve_repo_root(repo_root)
    clear_current_run(resolved_repo_root)
    reset_workspace_outputs(repo_root=resolved_repo_root)
