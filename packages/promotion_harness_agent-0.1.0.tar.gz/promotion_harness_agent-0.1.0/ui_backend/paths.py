from __future__ import annotations

import os
from pathlib import Path

from core.runtime_paths import active_run_paths, harness_root as runtime_harness_root, resolve_repo_root


def repo_root() -> str:
    return resolve_repo_root(os.environ.get("HARNESS_REPO_ROOT") or os.getcwd())


def frontend_static_root() -> str | None:
    package_dir = Path(__file__).resolve().parent
    candidates = [
        package_dir / "static",
        package_dir.parent / "ui_frontend" / "dist",
    ]
    for candidate in candidates:
        if (candidate / "index.html").exists():
            return str(candidate)
    return None


def workspace_root() -> str:
    active = active_run_paths(repo_root())
    if active is None:
        raise ValueError("active_run_required")
    return active.run_root


def harness_root() -> str:
    return runtime_harness_root(repo_root())


def _real(path: str) -> str:
    return os.path.realpath(os.path.abspath(path))


def ensure_within_workspace(path: str) -> str:
    """Return real path if it is within the active run root, otherwise raise ValueError."""
    ws = _real(workspace_root())
    candidate = _real(path)
    common = os.path.commonpath([candidate, ws])
    if common != ws:
        raise ValueError("path_must_be_within_workspace")
    return candidate


def ensure_within_repo(path: str) -> str:
    """Return real path if it is within repo root, otherwise raise ValueError."""
    rr = _real(repo_root())
    candidate = _real(path)
    common = os.path.commonpath([candidate, rr])
    if common != rr:
        raise ValueError("path_must_be_within_repo")
    return candidate
