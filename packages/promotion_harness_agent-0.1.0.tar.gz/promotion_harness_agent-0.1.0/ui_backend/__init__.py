"""Local web console backend (FastAPI)."""

