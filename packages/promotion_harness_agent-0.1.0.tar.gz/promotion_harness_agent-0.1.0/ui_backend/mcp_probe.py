from __future__ import annotations

import asyncio
import threading
import time
from dataclasses import asdict, dataclass
from typing import Any, Literal

from acp.schema import EnvVariable, HttpHeader, HttpMcpServer, McpServerStdio, SseMcpServer

from core.mcp_config import load_effective_mcp_servers

McpServer = HttpMcpServer | SseMcpServer | McpServerStdio
ProbeStatus = Literal["unknown", "ok", "fail"]


def _now_iso() -> str:
    # Keep it stable/simple; UI can format.
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _server_identity(server: McpServer) -> tuple[Any, ...]:
    if isinstance(server, HttpMcpServer):
        return ("http", server.url)
    if isinstance(server, SseMcpServer):
        return ("sse", server.url)
    if isinstance(server, McpServerStdio):
        return ("stdio", server.command, tuple(server.args or ()))
    return ("unknown", getattr(server, "name", None))


def _redact_headers(headers: list[HttpHeader] | None) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for h in headers or []:
        # Do not leak header values (auth tokens, cookies, etc.)
        out.append({"name": str(getattr(h, "name", ""))})
    return out


def _redact_env(env: list[EnvVariable] | None) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for e in env or []:
        # Do not leak env values (secrets).
        out.append({"name": str(getattr(e, "name", ""))})
    return out


def _public_server_meta(server: McpServer) -> dict[str, Any]:
    name = str(getattr(server, "name", "") or "")
    transport = str(getattr(server, "type", "") or "")
    if not transport:
        # Some server definitions (e.g. our default coco stdio) don't populate `type`.
        if isinstance(server, HttpMcpServer):
            transport = "http"
        elif isinstance(server, SseMcpServer):
            transport = "sse"
        elif isinstance(server, McpServerStdio):
            transport = "stdio"
    meta: dict[str, Any] = {
        "name": name,
        "transport": transport,
        "identity": list(_server_identity(server)),
    }
    if isinstance(server, (HttpMcpServer, SseMcpServer)):
        meta["url"] = server.url
        meta["headers"] = _redact_headers(getattr(server, "headers", None))
    if isinstance(server, McpServerStdio):
        meta["command"] = server.command
        meta["args"] = list(server.args or [])
        meta["env"] = _redact_env(getattr(server, "env", None))
    return meta


@dataclass
class ProbeResult:
    status: ProbeStatus
    tool_count: int | None = None
    tools: list[str] | None = None
    error_code: str | None = None
    error_detail: str | None = None
    last_checked_at: str | None = None
    last_ok_at: str | None = None


@dataclass
class CachedProbe:
    result: ProbeResult
    expires_at: float


_cache_lock = threading.Lock()
_probe_cache: dict[tuple[Any, ...], CachedProbe] = {}


def get_cached(server: McpServer, *, allow_stale: bool = True) -> tuple[ProbeResult | None, bool]:
    """Return (result, stale) if present, else (None, False)."""
    key = _server_identity(server)
    now = time.time()
    with _cache_lock:
        item = _probe_cache.get(key)
        if not item:
            return None, False
        stale = now > item.expires_at
        if stale and not allow_stale:
            return None, True
        return item.result, stale


def set_cached(server: McpServer, result: ProbeResult, *, ttl_sec: float) -> None:
    key = _server_identity(server)
    with _cache_lock:
        _probe_cache[key] = CachedProbe(result=result, expires_at=time.time() + ttl_sec)


def list_effective_servers(*, stage: str | None, workspace_root: str) -> list[McpServer]:
    return load_effective_mcp_servers(stage=stage, workspace_folder=workspace_root, record_event=False) or []


async def _probe_stdio(server: McpServerStdio, *, timeout_sec: float) -> tuple[int, list[str]]:
    # Import lazily so the backend can start even if the dependency is missing.
    from mcp import ClientSession, StdioServerParameters  # type: ignore
    from mcp.client.stdio import stdio_client  # type: ignore

    env_map: dict[str, str] = {}
    for ev in server.env or []:
        k = str(getattr(ev, "name", "") or "")
        v = str(getattr(ev, "value", "") or "")
        if k:
            env_map[k] = v

    server_params = StdioServerParameters(
        command=server.command,
        args=list(server.args or []),
        env=env_map or None,
    )

    async def _run() -> tuple[int, list[str]]:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools = await session.list_tools()
                names = [str(t.name) for t in getattr(tools, "tools", []) if getattr(t, "name", None)]
                return len(names), names

    return await asyncio.wait_for(_run(), timeout=timeout_sec)


async def _probe_http(server: HttpMcpServer, *, timeout_sec: float) -> tuple[int, list[str]]:
    from mcp import ClientSession  # type: ignore
    from mcp.client.streamable_http import streamable_http_client  # type: ignore

    async def _run() -> tuple[int, list[str]]:
        async with streamable_http_client(server.url) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools = await session.list_tools()
                names = [str(t.name) for t in getattr(tools, "tools", []) if getattr(t, "name", None)]
                return len(names), names

    return await asyncio.wait_for(_run(), timeout=timeout_sec)


async def deep_probe_server(
    server: McpServer,
    *,
    timeout_sec: float = 8.0,
) -> ProbeResult:
    checked_at = _now_iso()
    try:
        if isinstance(server, McpServerStdio):
            tool_count, tools = await _probe_stdio(server, timeout_sec=timeout_sec)
        elif isinstance(server, HttpMcpServer):
            tool_count, tools = await _probe_http(server, timeout_sec=timeout_sec)
        elif isinstance(server, SseMcpServer):
            return ProbeResult(
                status="fail",
                error_code="unsupported_transport",
                error_detail="sse transport probe not implemented",
                last_checked_at=checked_at,
            )
        else:
            return ProbeResult(
                status="fail",
                error_code="unsupported_server_type",
                error_detail="unknown server type",
                last_checked_at=checked_at,
            )
        return ProbeResult(
            status="ok",
            tool_count=int(tool_count),
            tools=tools[:200],
            last_checked_at=checked_at,
            last_ok_at=checked_at,
        )
    except asyncio.TimeoutError:
        return ProbeResult(status="fail", error_code="timeout", error_detail="probe timed out", last_checked_at=checked_at)
    except ModuleNotFoundError as e:
        return ProbeResult(
            status="fail",
            error_code="dependency_missing",
            error_detail=str(e),
            last_checked_at=checked_at,
        )
    except Exception as e:
        return ProbeResult(status="fail", error_code="probe_failed", error_detail=str(e), last_checked_at=checked_at)


async def get_status_payload(
    *,
    stage: str | None,
    workspace_root: str,
    ttl_sec: float = 45.0,
) -> dict[str, Any]:
    servers = list_effective_servers(stage=stage, workspace_root=workspace_root)
    out: list[dict[str, Any]] = []
    for s in servers:
        cached, stale = get_cached(s, allow_stale=True)
        out.append(
            {
                "server": _public_server_meta(s),
                "probe": asdict(cached) if cached else asdict(ProbeResult(status="unknown")),
                "stale": bool(stale) if cached else False,
                "ttl_sec": ttl_sec,
            }
        )
    return {"requested_stage": stage, "servers": out}


async def run_probe(
    *,
    stage: str | None,
    workspace_root: str,
    name: str | None = None,
    force: bool = False,
    ttl_sec: float = 45.0,
    timeout_sec: float = 8.0,
) -> dict[str, Any]:
    servers = list_effective_servers(stage=stage, workspace_root=workspace_root)
    if name:
        servers = [s for s in servers if str(getattr(s, "name", "") or "") == name]

    results: list[dict[str, Any]] = []
    for s in servers:
        cached, stale = get_cached(s, allow_stale=True)
        if cached and not stale and not force:
            results.append({"server": _public_server_meta(s), "probe": asdict(cached), "cached": True})
            continue

        r = await deep_probe_server(s, timeout_sec=timeout_sec)
        # Preserve "last_ok_at" if a previous success exists and this run fails.
        if r.status != "ok" and cached and cached.last_ok_at:
            r.last_ok_at = cached.last_ok_at

        set_cached(s, r, ttl_sec=ttl_sec)
        results.append({"server": _public_server_meta(s), "probe": asdict(r), "cached": False})

    return {"requested_stage": stage, "results": results}
