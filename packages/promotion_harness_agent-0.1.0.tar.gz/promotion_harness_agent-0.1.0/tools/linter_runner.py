from __future__ import annotations

import os
import py_compile
from dataclasses import dataclass


@dataclass
class RunnerResult:
    returncode: int
    output: str


def run_generated_lint(paths: tuple[str, ...] = ("src", "tests"), cwd: str | None = None) -> RunnerResult:
    target_cwd = cwd or os.getcwd()
    abs_paths = [path if os.path.isabs(path) else os.path.join(target_cwd, path) for path in paths]

    python_files: list[str] = []
    missing_paths: list[str] = []
    for path in abs_paths:
        if not os.path.exists(path):
            missing_paths.append(path)
            continue
        for root, _, files in os.walk(path):
            for file_name in files:
                if file_name.endswith(".py"):
                    python_files.append(os.path.join(root, file_name))

    if missing_paths:
        return RunnerResult(returncode=1, output="Missing generated paths:\n" + "\n".join(missing_paths))

    if not python_files:
        return RunnerResult(returncode=1, output="No generated Python files found for lint validation.")

    errors: list[str] = []
    for file_path in sorted(python_files):
        try:
            py_compile.compile(file_path, doraise=True)
        except py_compile.PyCompileError as exc:
            errors.append(str(exc))

    if errors:
        return RunnerResult(returncode=1, output="\n\n".join(errors))

    return RunnerResult(returncode=0, output=f"Validated {len(python_files)} Python file(s).")


def main() -> int:
    result = run_generated_lint()
    if result.output:
        print(result.output)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
