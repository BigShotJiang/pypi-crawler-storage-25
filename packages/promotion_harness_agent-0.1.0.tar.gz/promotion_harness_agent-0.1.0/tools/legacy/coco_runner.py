import logging
import subprocess


logger = logging.getLogger(__name__)


def run_coco_task(prompt: str, cwd: str = None, log_file: str = None) -> subprocess.CompletedProcess:
    import os
    import shutil

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"

    coco_bin = "coco"
    if not shutil.which(coco_bin):
        logger.warning("coco not found in PATH, relying on system environment.")
        home = os.path.expanduser("~")
        trae_bin = os.path.join(home, ".trae", "bin", "coco")
        if os.path.exists(trae_bin):
            coco_bin = trae_bin

    cmd = [coco_bin, "--json", "--allowed-tool", "Bash,Edit,Write", "-p", prompt]

    logger.info(f"Running coco command: {' '.join(cmd)}")
    if cwd:
        logger.info(f"Working directory: {cwd}")

    try:
        if log_file:
            with open(log_file, "w", encoding="utf-8") as f:
                process = subprocess.Popen(
                    cmd,
                    cwd=cwd,
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
                for line in process.stdout:
                    f.write(line)
                    f.flush()
                    print(line, end="", flush=True)
                process.wait()
                if process.returncode != 0:
                    raise subprocess.CalledProcessError(process.returncode, cmd)
                result = subprocess.CompletedProcess(args=cmd, returncode=process.returncode)
        else:
            result = subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=True,
                text=True,
                check=True,
            )
        logger.info("Coco task completed successfully.")
        return result
    except subprocess.CalledProcessError as e:
        logger.error(f"Coco task failed with exit code {e.returncode}")
        if not log_file:
            logger.error(f"Stdout: {e.stdout}")
            logger.error(f"Stderr: {e.stderr}")
        raise
