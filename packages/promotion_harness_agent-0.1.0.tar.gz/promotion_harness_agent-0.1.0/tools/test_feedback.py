from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class FeedbackPreset:
    name: str
    label: str
    description: str
    marker_expression: str | None = None


@dataclass(frozen=True)
class Recommendation:
    title: str
    reason: str
    command: str
    matched_paths: tuple[str, ...]
    tests: tuple[str, ...] = ()


@dataclass(frozen=True)
class RecommendationRule:
    prefixes: tuple[str, ...]
    title: str
    reason: str
    tests: tuple[str, ...]


PRESETS: dict[str, FeedbackPreset] = {
    "fast": FeedbackPreset(
        name="fast",
        label="本地快反馈",
        description="默认开发反馈，排除 slow 和 real_coco。",
        marker_expression="not slow and not real_coco",
    ),
    "stage": FeedbackPreset(
        name="stage",
        label="阶段级验证",
        description="适合阶段开发，优先运行 stage 与 unit 测试。",
        marker_expression="(stage or unit) and not slow and not real_coco",
    ),
    "regression": FeedbackPreset(
        name="regression",
        label="仓库级回归",
        description="提交前回归，默认排除 real_coco。",
        marker_expression="not real_coco",
    ),
    "acceptance": FeedbackPreset(
        name="acceptance",
        label="完整验收",
        description="完整仓库验收，等价于原始 uv run pytest -q。",
        marker_expression=None,
    ),
}


RECOMMENDATION_RULES: tuple[RecommendationRule, ...] = (
    RecommendationRule(
        prefixes=("core/context_", "core/context_layer.py"),
        title="上下文层聚焦测试",
        reason="上下文层改动优先验证上下文装配、快照持久化与编排联动。",
        tests=("tests/test_context_manager.py", "tests/test_context_layer.py", "tests/test_orchestrator.py"),
    ),
    RecommendationRule(
        prefixes=("core/orchestrator.py", "core/middlewares.py"),
        title="编排与状态机聚焦测试",
        reason="编排器改动优先覆盖状态流转、超时与中间件行为。",
        tests=("tests/test_orchestrator.py", "tests/test_orchestrator_timeout.py", "tests/test_middlewares.py"),
    ),
    RecommendationRule(
        prefixes=("agents/trae_prd_agent.py",),
        title="PRD 阶段聚焦测试",
        reason="PRD 阶段改动优先覆盖阶段行为与真实 coco 场景。",
        tests=("tests/test_prd_stage.py",),
    ),
    RecommendationRule(
        prefixes=("agents/trae_tech_spec_agent.py",),
        title="Tech Spec 阶段聚焦测试",
        reason="Tech Spec 阶段改动优先覆盖技术方案生成与 manifest 相关测试。",
        tests=("tests/test_tech_spec_stage.py",),
    ),
    RecommendationRule(
        prefixes=("agents/trae_coding_agent.py",),
        title="Coding 阶段聚焦测试",
        reason="Coding 阶段改动优先覆盖代码生成与验证衔接。",
        tests=("tests/test_coding_stage.py", "tests/test_verifying_stage.py"),
    ),
    RecommendationRule(
        prefixes=("agents/trae_fixing_agent.py", "agents/trae_verifying_agent.py"),
        title="修复闭环聚焦测试",
        reason="修复与验证改动优先覆盖 verifying/fixing 闭环与阶段测试。",
        tests=("tests/test_fixing_stage.py", "tests/test_verifying_stage.py", "tests/test_verifying_fixing_loop.py"),
    ),
    RecommendationRule(
        prefixes=("core/acp_agent.py", "tools/acp_client_wrapper.py"),
        title="ACP Runtime 聚焦测试",
        reason="ACP 运行时改动优先覆盖 runtime、shutdown、toolcall tracing。",
        tests=(
            "tests/test_acp_runtime.py",
            "tests/test_acp_shutdown.py",
            "tests/test_acp_client.py",
            "tests/test_acp_toolcall_tracing.py",
            "tests/test_acp_fs_tracing.py",
        ),
    ),
    RecommendationRule(
        prefixes=("ui.py", "ui_runtime.py", "ui_trace.py"),
        title="UI 聚焦测试",
        reason="UI 改动优先覆盖 runtime、trace 与 artifacts 展示测试。",
        tests=(
            "tests/test_ui_runtime.py",
            "tests/test_ui_trace.py",
            "tests/test_ui_trace_acp_toolcalls.py",
            "tests/test_ui_artifacts.py",
        ),
    ),
)


def list_feedback_presets() -> list[FeedbackPreset]:
    return [PRESETS[name] for name in ("fast", "stage", "regression", "acceptance")]


def _normalize_paths(paths: Iterable[str]) -> list[str]:
    normalized: list[str] = []
    for path in paths:
        if not path:
            continue
        normalized.append(Path(path).as_posix().lstrip("./"))
    return normalized


def build_pytest_args(mode: str, extra_paths: Iterable[str] | None = None) -> list[str]:
    preset = PRESETS[mode]
    args = [sys.executable, "-m", "pytest", "-q"]
    if preset.marker_expression:
        args.extend(["-m", preset.marker_expression])
    paths = _normalize_paths(extra_paths or [])
    args.extend(paths)
    return args


def build_feedback_command(mode: str, extra_paths: Iterable[str] | None = None) -> str:
    preset = PRESETS[mode]
    parts = ["uv", "run", "pytest", "-q"]
    if preset.marker_expression:
        parts.extend(["-m", preset.marker_expression])
    for path in _normalize_paths(extra_paths or []):
        parts.append(path)
    return " ".join(shlex.quote(part) for part in parts)


def run_feedback_mode(mode: str, cwd: str | None = None, extra_paths: Iterable[str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        build_pytest_args(mode, extra_paths=extra_paths),
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )


def recommend_test_commands(paths: Iterable[str]) -> list[Recommendation]:
    normalized = _normalize_paths(paths)
    recommendations: list[Recommendation] = []

    for rule in RECOMMENDATION_RULES:
        matched = tuple(
            path
            for path in normalized
            if any(path.startswith(prefix) for prefix in rule.prefixes)
        )
        if not matched:
            continue
        recommendations.append(
            Recommendation(
                title=rule.title,
                reason=rule.reason,
                command=build_feedback_command("fast", extra_paths=rule.tests),
                matched_paths=matched,
                tests=rule.tests,
            )
        )

    if recommendations:
        return recommendations

    return [
        Recommendation(
            title="默认快反馈",
            reason="未命中特定规则时，先使用仓库默认快反馈命令。",
            command=build_feedback_command("fast"),
            matched_paths=tuple(normalized),
            tests=(),
        )
    ]


def discover_changed_files(repo_root: str) -> list[str]:
    root = os.path.abspath(repo_root)
    changed: set[str] = set()
    commands = [
        ["git", "diff", "--name-only", "--relative", "HEAD"],
        ["git", "ls-files", "--others", "--exclude-standard"],
    ]
    for command in commands:
        try:
            result = subprocess.run(command, cwd=root, capture_output=True, text=True, check=False)
        except OSError:
            continue
        if result.returncode != 0:
            continue
        for line in result.stdout.splitlines():
            path = line.strip()
            if path:
                changed.add(Path(path).as_posix())
    return sorted(changed)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Harness repository test feedback utilities")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="List feedback modes")

    recommend = sub.add_parser("recommend", help="Recommend focused test commands")
    recommend.add_argument("--path", action="append", default=[], help="Changed path (can be repeated)")
    recommend.add_argument("--repo-root", default=".", help="Repository root for auto-discovery when no paths are provided")

    run = sub.add_parser("run", help="Run one feedback mode")
    run.add_argument("mode", choices=tuple(PRESETS.keys()))
    run.add_argument("--path", action="append", default=[], help="Optional explicit test paths")
    run.add_argument("--cwd", default=".", help="Working directory")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "list":
        for preset in list_feedback_presets():
            print(f"{preset.name}: {preset.label} -> {build_feedback_command(preset.name)}")
        return 0

    if args.command == "recommend":
        paths = args.path or discover_changed_files(args.repo_root)
        for rec in recommend_test_commands(paths):
            print(f"[{rec.title}]")
            print(f"reason: {rec.reason}")
            if rec.matched_paths:
                print(f"matched: {', '.join(rec.matched_paths)}")
            print(rec.command)
            print()
        return 0

    if args.command == "run":
        result = run_feedback_mode(args.mode, cwd=args.cwd, extra_paths=args.path)
        if result.stdout:
            print(result.stdout, end="")
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr)
        return int(result.returncode)

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
