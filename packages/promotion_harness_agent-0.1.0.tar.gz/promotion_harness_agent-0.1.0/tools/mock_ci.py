#!/usr/bin/env python3
import sys
import random

def main():
    print("Running Mock CI...")
    # Randomly fail 50% of the time to test the forced loop
    if random.choice([True, False]):
        print("Mock CI Failed! Code coverage is below 80%.")
        sys.exit(1)
    else:
        print("Mock CI Passed! All tests green.")
        sys.exit(0)

if __name__ == "__main__":
    main()
