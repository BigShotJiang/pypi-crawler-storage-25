import asyncio
import asyncio.subprocess as aio_subprocess
import logging
import os
from typing import Any, Dict

from acp import PROTOCOL_VERSION, Client, RequestError, connect_to_agent, text_block
from acp.schema import (
    ClientCapabilities,
    Implementation,
    PermissionOption,
    RequestPermissionResponse,
    AllowedOutcome,
    DeniedOutcome,
    WriteTextFileResponse,
    ReadTextFileResponse,
    CreateTerminalResponse,
    TerminalOutputResponse,
    ReleaseTerminalResponse,
    WaitForTerminalExitResponse,
    KillTerminalResponse,
    ToolCall,
    EnvVariable,
    FileSystemCapabilities,
)

logger = logging.getLogger(__name__)


def _normalize_session_cwd(cwd: str) -> str:
    candidate = str(cwd or "").strip()
    if not candidate:
        raise ValueError("cwd is required")
    return os.path.realpath(candidate if os.path.isabs(candidate) else os.path.abspath(candidate))


def _validate_initialize_response(init_response: Any) -> dict[str, Any]:
    dumped = init_response.model_dump()
    protocol_version = dumped.get("protocol_version")
    if protocol_version != PROTOCOL_VERSION:
        raise RuntimeError(
            f"ACP protocol version mismatch: client={PROTOCOL_VERSION}, agent={protocol_version}"
        )
    return dumped


def _extract_session_support(agent_capabilities: dict[str, Any] | None) -> tuple[bool, bool]:
    capabilities = agent_capabilities or {}
    session_capabilities = capabilities.get("session_capabilities") or capabilities.get("sessionCapabilities") or {}
    list_capability = session_capabilities.get("list") if isinstance(session_capabilities, dict) else None
    supports_session_list = list_capability is not None
    supports_load_session = bool(capabilities.get("load_session") or capabilities.get("loadSession"))
    return supports_session_list, supports_load_session


def _normalize_stop_reason(stop_reason: Any) -> str | None:
    raw = str(stop_reason or "").strip()
    if not raw:
        return None
    lowered = raw.lower().replace("-", "_")
    aliases = {
        "finished": "end_turn",
        "endturn": "end_turn",
        "maxturnrequests": "max_turn_requests",
        "maxtokens": "max_tokens",
        "canceled": "cancelled",
    }
    normalized = aliases.get(lowered, lowered)
    valid = {"end_turn", "max_tokens", "max_turn_requests", "refusal", "cancelled"}
    return normalized if normalized in valid else raw


def _normalize_prompt_response(prompt_response: Any) -> dict[str, Any]:
    if hasattr(prompt_response, "model_dump"):
        payload = prompt_response.model_dump()
    elif isinstance(prompt_response, dict):
        payload = dict(prompt_response)
    else:
        payload = {"raw": str(prompt_response)}
    stop_reason = payload.get("stop_reason") or payload.get("stopReason")
    normalized = _normalize_stop_reason(stop_reason)
    if normalized is not None:
        payload["stop_reason"] = normalized
    return payload


def _is_cancelled_error(exc: BaseException) -> bool:
    if isinstance(exc, asyncio.CancelledError):
        return True
    msg = str(exc or "").lower()
    return any(token in msg for token in ("cancelled", "canceled", "abort", "aborted", "interrupted"))


def _pick_preferred_permission_option(options: list[PermissionOption]) -> PermissionOption | None:
    best: PermissionOption | None = None
    for option in options:
        if getattr(option, "kind", None) in {"allow_once", "allow_always"}:
            return option
        best = best or option
    return best


def _extract_prompt_capabilities(agent_capabilities: dict[str, Any] | None) -> dict[str, bool]:
    capabilities = agent_capabilities or {}
    prompt_caps = capabilities.get("prompt_capabilities") or capabilities.get("promptCapabilities") or {}
    return {
        "text": True,
        "resource_link": True,
        "image": bool(prompt_caps.get("image")),
        "audio": bool(prompt_caps.get("audio")),
        "embedded_context": bool(prompt_caps.get("embedded_context") or prompt_caps.get("embeddedContext")),
    }


def _normalize_prompt_blocks(prompt_text: str | None, prompt_blocks: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    if prompt_blocks is not None:
        if not isinstance(prompt_blocks, list) or not prompt_blocks:
            raise ValueError("prompt_blocks must be a non-empty list")
        normalized: list[dict[str, Any]] = []
        for block in prompt_blocks:
            if hasattr(block, "model_dump"):
                normalized.append(block.model_dump())
            elif isinstance(block, dict):
                normalized.append(dict(block))
            else:
                raise ValueError("prompt_blocks entries must be dict-like ACP content blocks")
        return normalized
    default_block = text_block(str(prompt_text or ""))
    if hasattr(default_block, "model_dump"):
        return [{k: v for k, v in default_block.model_dump().items() if v is not None}]
    if isinstance(default_block, dict):
        return [{k: v for k, v in dict(default_block).items() if v is not None}]
    return [{"type": "text", "text": str(prompt_text or "")}]


def _validate_embedded_resource(resource: Any) -> None:
    if not isinstance(resource, dict):
        raise ValueError("resource content block must contain a resource object")
    uri = str(resource.get("uri") or "").strip()
    has_text = isinstance(resource.get("text"), str)
    has_blob = isinstance(resource.get("blob"), str)
    if not uri:
        raise ValueError("embedded resource must include resource.uri")
    if has_text == has_blob:
        raise ValueError("embedded resource must include exactly one of resource.text or resource.blob")


def _validate_prompt_blocks(prompt_blocks: list[dict[str, Any]], prompt_capabilities: dict[str, bool]) -> None:
    if not prompt_blocks:
        raise ValueError("prompt must contain at least one content block")
    for idx, block in enumerate(prompt_blocks):
        if not isinstance(block, dict):
            raise ValueError(f"prompt block #{idx + 1} must be an object")
        block_type = str(block.get("type") or "").strip()
        if block_type == "text":
            if not isinstance(block.get("text"), str):
                raise ValueError(f"text block #{idx + 1} must include text")
            continue
        if block_type == "resource_link":
            if not isinstance(block.get("uri"), str) or not str(block.get("uri") or "").strip():
                raise ValueError(f"resource_link block #{idx + 1} must include uri")
            if not isinstance(block.get("name"), str) or not str(block.get("name") or "").strip():
                raise ValueError(f"resource_link block #{idx + 1} must include name")
            continue
        if block_type == "resource":
            if not prompt_capabilities.get("embedded_context"):
                raise ValueError("agent does not advertise embeddedContext prompt capability")
            _validate_embedded_resource(block.get("resource"))
            continue
        if block_type == "image":
            if not prompt_capabilities.get("image"):
                raise ValueError("agent does not advertise image prompt capability")
            if not isinstance(block.get("data"), str) or not isinstance(block.get("mimeType"), str):
                raise ValueError(f"image block #{idx + 1} must include data and mimeType")
            continue
        if block_type == "audio":
            if not prompt_capabilities.get("audio"):
                raise ValueError("agent does not advertise audio prompt capability")
            if not isinstance(block.get("data"), str) or not isinstance(block.get("mimeType"), str):
                raise ValueError(f"audio block #{idx + 1} must include data and mimeType")
            continue
        raise ValueError(f"unsupported ACP content block type: {block_type or '<missing>'}")


def _build_client_capabilities() -> ClientCapabilities:
    fs_cap = FileSystemCapabilities(write_text_file=False, read_text_file=False)
    return ClientCapabilities(fs=fs_cap, terminal=False, auth=None)


def _cancelled_tool_call_meta() -> dict[str, Any]:
    return {
        "harness": {
            "cancelled": True,
            "synthetic": True,
            "reason": "prompt_turn_cancelled",
        }
    }


def _build_cancelled_tool_call_update(tool_call_id: str, record: dict[str, Any] | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "sessionUpdate": "tool_call_update",
        "toolCallId": tool_call_id,
        "status": "failed",
        "_meta": _cancelled_tool_call_meta(),
        "content": [
            {
                "type": "content",
                "content": {
                    "type": "text",
                    "text": "Tool call cancelled because the current prompt turn was cancelled.",
                },
            }
        ],
    }
    if isinstance(record, dict):
        if record.get("title") is not None:
            payload["title"] = record.get("title")
        if record.get("kind") is not None:
            payload["kind"] = record.get("kind")
    return payload

class HarnessClientImpl(Client):
    """
    Implementation of the ACP Client protocol.
    Provides callbacks for capabilities requested by the Agent.
    """
    def __init__(self, updates_list: list):
        self.updates = updates_list
        self.session_infos: dict[str, dict[str, Any]] = {}
        self.pending_tool_calls: dict[str, dict[str, dict[str, Any]]] = {}

    def seed_session_info(self, session_id: str, cwd: str) -> None:
        self.session_infos[session_id] = {"sessionId": session_id, "cwd": cwd}

    def get_session_info(self, session_id: str) -> dict[str, Any] | None:
        info = self.session_infos.get(session_id)
        return dict(info) if isinstance(info, dict) else None

    def _track_tool_call(self, session_id: str, tool_call_id: str | None, title: Any, kind: Any, status: Any) -> None:
        if not tool_call_id:
            return
        per_session = self.pending_tool_calls.setdefault(session_id, {})
        record = dict(per_session.get(tool_call_id) or {})
        if title is not None:
            record["title"] = title
        if kind is not None:
            record["kind"] = kind
        if status is not None:
            record["status"] = status
        if str(status or "").lower() in {"completed", "failed", "cancelled", "canceled"}:
            per_session.pop(tool_call_id, None)
            if not per_session:
                self.pending_tool_calls.pop(session_id, None)
            return
        per_session[tool_call_id] = record

    def cancel_pending_tool_calls(self, session_id: str) -> list[dict[str, Any]]:
        per_session = self.pending_tool_calls.pop(session_id, {})
        cancelled_updates: list[dict[str, Any]] = []
        for tool_call_id, record in per_session.items():
            payload = _build_cancelled_tool_call_update(tool_call_id, record if isinstance(record, dict) else None)
            cancelled_updates.append(payload)
            self.updates.append(payload)
        return cancelled_updates

    async def request_permission(self, options: list[PermissionOption], session_id: str, tool_call: ToolCall, **kwargs: Any) -> RequestPermissionResponse:
        if not options:
            return RequestPermissionResponse(outcome=DeniedOutcome(outcome="cancelled"))
        option = _pick_preferred_permission_option(options)
        if option is None:
            return RequestPermissionResponse(outcome=DeniedOutcome(outcome="cancelled"))
        return RequestPermissionResponse(outcome=AllowedOutcome(option_id=option.option_id, outcome="selected"))

    async def write_text_file(self, content: str, path: str, session_id: str, **kwargs: Any) -> WriteTextFileResponse | None:
        raise RequestError.method_not_found("fs/write_text_file")

    async def read_text_file(self, path: str, session_id: str, limit: int | None = None, line: int | None = None, **kwargs: Any) -> ReadTextFileResponse:
        raise RequestError.method_not_found("fs/read_text_file")

    async def create_terminal(self, command: str, session_id: str, args: list[str] | None = None, cwd: str | None = None, env: list[EnvVariable] | None = None, output_byte_limit: int | None = None, **kwargs: Any) -> CreateTerminalResponse:
        raise RequestError.method_not_found("terminal/create")

    async def terminal_output(self, session_id: str, terminal_id: str, **kwargs: Any) -> TerminalOutputResponse:
        raise RequestError.method_not_found("terminal/output")

    async def release_terminal(self, session_id: str, terminal_id: str, **kwargs: Any) -> ReleaseTerminalResponse | None:
        raise RequestError.method_not_found("terminal/release")

    async def wait_for_terminal_exit(self, session_id: str, terminal_id: str, **kwargs: Any) -> WaitForTerminalExitResponse:
        raise RequestError.method_not_found("terminal/wait_for_exit")

    async def kill_terminal(self, session_id: str, terminal_id: str, **kwargs: Any) -> KillTerminalResponse | None:
        raise RequestError.method_not_found("terminal/kill")

    async def session_update(self, session_id: str, update: Any, **kwargs: Any) -> None:
        """Called by the agent to stream updates (thoughts, messages, etc)"""
        try:
            payload = update.model_dump()
            session_update_kind = payload.get("session_update") or payload.get("sessionUpdate")
            if session_update_kind in {"tool_call", "tool_call_update"}:
                self._track_tool_call(
                    session_id,
                    payload.get("tool_call_id") or payload.get("toolCallId"),
                    payload.get("title"),
                    payload.get("kind"),
                    payload.get("status"),
                )
            if session_update_kind == "session_info_update":
                merged = dict(self.session_infos.get(session_id) or {"sessionId": session_id})
                if "title" in payload:
                    merged["title"] = payload.get("title")
                if "updatedAt" in payload:
                    merged["updatedAt"] = payload.get("updatedAt")
                elif "updated_at" in payload:
                    merged["updatedAt"] = payload.get("updated_at")
                if "_meta" in payload:
                    merged["_meta"] = payload.get("_meta")
                self.session_infos[session_id] = merged
            self.updates.append(payload)
        except AttributeError:
            self.updates.append(update)

    async def ext_method(self, method: str, params: dict) -> dict:
        raise RequestError.method_not_found(method)

    async def ext_notification(self, method: str, params: dict) -> None:
        logger.debug("Ignoring unsupported ACP notification: %s", method)
        return None


async def run_acp_prompt_test(
    prompt_text: str, 
    cwd: str, 
    command: str = "coco", 
    args: list[str] | None = None,
    prompt_blocks: list[dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    """
    A helper function to spawn an ACP agent, initialize, start a session,
    send a prompt, and collect the updates.
    """
    results = {
        "updates": [],
        "final_response": None,
        "error": None
    }

    proc = None
    effective_args = args if args is not None else ["acp", "serve", "-y"]
    try:
        session_cwd = _normalize_session_cwd(cwd)
        logger.info(f"Spawning ACP agent: {command} {' '.join(effective_args)}")
        proc = await asyncio.create_subprocess_exec(
            command,
            *effective_args,
            stdin=aio_subprocess.PIPE,
            stdout=aio_subprocess.PIPE,
        )

        if proc.stdin is None or proc.stdout is None:
            raise RuntimeError("Agent process does not expose stdio pipes")

        # 1. Initialize Connection
        client_impl = HarnessClientImpl(results["updates"])
        async with connect_to_agent(client_impl, proc.stdin, proc.stdout) as conn:
            logger.info("Sending initialize request")
            init_response = await conn.initialize(
                protocol_version=PROTOCOL_VERSION,
                client_capabilities=_build_client_capabilities(),
                client_info=Implementation(name="harness-acp-client", title="Harness Client", version="0.1.0"),
            )
            init_dump = _validate_initialize_response(init_response)
            
            logger.info(f"Initialized successfully.")
            results["protocolVersion"] = init_dump.get("protocol_version")
            results["agentCapabilities"] = init_dump.get("agent_capabilities", {})
            results["agentInfo"] = init_dump.get("agent_info")
            results["authMethods"] = init_dump.get("auth_methods") or []
            supports_session_list, supports_load_session = _extract_session_support(results["agentCapabilities"])
            prompt_capabilities = _extract_prompt_capabilities(results["agentCapabilities"])
            results["supportsSessionList"] = supports_session_list
            results["supportsLoadSession"] = supports_load_session
            results["promptCapabilities"] = prompt_capabilities

            logger.info(f"Starting new session in cwd: {session_cwd}")
            # ACP schema requires mcpServers in session/new. Test helper should be schema-compliant.
            session = await conn.new_session(cwd=session_cwd, mcp_servers=[])
            session_id = session.session_id
            client_impl.seed_session_info(session_id, session_cwd)
            logger.info(f"Session started: {session_id}")
            results["sessionId"] = session_id

            logger.info(f"Sending prompt: {prompt_text}")
            normalized_prompt = _normalize_prompt_blocks(prompt_text, prompt_blocks)
            _validate_prompt_blocks(normalized_prompt, prompt_capabilities)
            prompt_response = await conn.prompt(
                session_id=session_id,
                prompt=normalized_prompt
            )
            
            logger.info("Prompt finished")
            results["final_response"] = _normalize_prompt_response(prompt_response)
            results["sessionInfo"] = client_impl.get_session_info(session_id)
        
        return results

    except Exception as e:
        if _is_cancelled_error(e):
            logger.info("ACP prompt test cancelled: %s", e)
            if 'client_impl' in locals() and results.get("sessionId"):
                client_impl.cancel_pending_tool_calls(str(results.get("sessionId")))
                results["sessionInfo"] = client_impl.get_session_info(str(results.get("sessionId")))
            results["final_response"] = {"stop_reason": "cancelled"}
            results["error"] = None
            return results
        logger.error(f"Failed to run ACP process: {e}")
        results["error"] = str(e)
        return results
    finally:
        # Clean up the subprocess
        if proc and proc.returncode is None:
            proc.terminate()
            try:
                await proc.wait()
            except ProcessLookupError:
                pass

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    async def main():
        cwd = os.getcwd()
        res = await run_acp_prompt_test("Please calculate 1 + 1 and reply with just the number.", cwd)
        print(f"Final Result: {res['final_response']}")
        print(f"Updates count: {len(res['updates'])}")
        
    asyncio.run(main())
