from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import dataclass
from typing import Iterable

from tools.test_feedback import build_feedback_command, build_pytest_args, list_feedback_presets


@dataclass
class RunnerResult:
    returncode: int
    output: str


def run_generated_tests(test_path: str = "tests", cwd: str | None = None) -> RunnerResult:
    target_cwd = cwd or os.getcwd()
    abs_test_path = test_path if os.path.isabs(test_path) else os.path.join(target_cwd, test_path)

    if not os.path.exists(abs_test_path):
        return RunnerResult(returncode=1, output=f"Generated test path does not exist: {abs_test_path}")

    has_test_file = False
    for root, _, files in os.walk(abs_test_path):
        for file_name in files:
            if file_name.startswith("test_") and file_name.endswith(".py"):
                has_test_file = True
                break
        if has_test_file:
            break

    if not has_test_file:
        return RunnerResult(returncode=1, output=f"No generated test files found under: {abs_test_path}")

    completed = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", abs_test_path],
        cwd=target_cwd,
        capture_output=True,
        text=True,
    )
    output = "\n".join(part for part in [completed.stdout.strip(), completed.stderr.strip()] if part).strip()
    return RunnerResult(returncode=completed.returncode, output=output)


def run_repository_feedback(mode: str = "fast", cwd: str | None = None, extra_paths: Iterable[str] | None = None) -> RunnerResult:
    target_cwd = cwd or os.getcwd()
    completed = subprocess.run(
        build_pytest_args(mode, extra_paths=extra_paths),
        cwd=target_cwd,
        capture_output=True,
        text=True,
    )
    output = "\n".join(part for part in [completed.stdout.strip(), completed.stderr.strip()] if part).strip()
    return RunnerResult(returncode=completed.returncode, output=output)


def main() -> int:
    if len(sys.argv) > 1 and sys.argv[1] == "--list-feedback":
        for preset in list_feedback_presets():
            print(f"{preset.name}: {preset.label} -> {build_feedback_command(preset.name)}")
        return 0
    if len(sys.argv) > 2 and sys.argv[1] == "--mode":
        result = run_repository_feedback(mode=sys.argv[2], extra_paths=sys.argv[3:] or None)
        if result.output:
            print(result.output)
        return result.returncode
    result = run_generated_tests()
    if result.output:
        print(result.output)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
