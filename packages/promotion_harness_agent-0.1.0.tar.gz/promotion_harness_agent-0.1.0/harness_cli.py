from __future__ import annotations

import argparse
import json
import os
import threading
import webbrowser
from typing import Any

import uvicorn

from core.runtime_paths import (
    CURRENT_RUN_FILE,
    current_run_file,
    ensure_repo_initialized,
    read_current_run,
    resolve_repo_root,
    validate_repo_init_target,
)
from core.stage_acceptance_policy import (
    build_default_repo_stage_acceptance_policy_payload,
    repo_acceptance_policy_config_path,
)
from core.stage_context_policy import (
    build_default_repo_stage_context_policy_payload,
    repo_policy_config_path,
)
from run import setup_orchestrator


def _init_payload(repo_root: str) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "repo_root": repo_root,
        "current_run_file": os.path.relpath(current_run_file(repo_root), repo_root),
        "runs_dir": os.path.relpath(os.path.join(repo_root, ".harness", "runs"), repo_root),
    }


def _write_json_if_missing(path: str, payload: Any) -> None:
    if os.path.exists(path):
        return
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False)


def cmd_init(args: argparse.Namespace) -> int:
    repo_root = resolve_repo_root(args.repo_root or None)
    ok, reason = validate_repo_init_target(repo_root)
    if not ok:
        print(f"init failed: {reason}")
        return 1
    ensure_repo_initialized(repo_root)
    payload = _init_payload(repo_root)
    _write_json_if_missing(os.path.join(repo_root, ".harness", "config.json"), payload)
    _write_json_if_missing(os.path.join(repo_root, ".harness", CURRENT_RUN_FILE), {"run_id": None})
    _write_json_if_missing(
        repo_policy_config_path(repo_root),
        build_default_repo_stage_context_policy_payload(),
    )
    _write_json_if_missing(
        repo_acceptance_policy_config_path(repo_root),
        build_default_repo_stage_acceptance_policy_payload(),
    )
    print(f"initialized Promotion Harness Agent repo: {repo_root}")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    repo_root = resolve_repo_root(args.repo_root or None)
    os.environ["HARNESS_REPO_ROOT"] = repo_root
    os.chdir(repo_root)
    orch = setup_orchestrator(
        False,
        args.requirement,
        max_quality_loop_retries=args.max_quality_loop_retries,
        repo_root=repo_root,
    )
    orch.run()
    return 0


def cmd_resume(args: argparse.Namespace) -> int:
    repo_root = resolve_repo_root(args.repo_root or None)
    current = read_current_run(repo_root)
    if not isinstance(current, dict) or not str(current.get("run_id") or "").strip():
        print("resume failed: no active run")
        return 1
    os.environ["HARNESS_REPO_ROOT"] = repo_root
    os.chdir(repo_root)
    orch = setup_orchestrator(
        True,
        "",
        max_quality_loop_retries=args.max_quality_loop_retries,
        repo_root=repo_root,
    )
    orch.run()
    return 0


def cmd_ui(args: argparse.Namespace) -> int:
    from ui_backend.paths import frontend_static_root

    repo_root = resolve_repo_root(args.repo_root or None)
    os.environ["HARNESS_REPO_ROOT"] = repo_root
    os.environ["HARNESS_UI_BACKEND_HOST"] = args.host
    os.environ["HARNESS_UI_BACKEND_PORT"] = str(int(args.port))

    static_root = frontend_static_root()
    if not static_root:
        print("ui failed: frontend static assets are missing; run `python build_ui_static.py` or `npm run ui:bundle` first")
        return 1

    if args.open_browser:
        target_url = f"http://{args.host}:{int(args.port)}"
        threading.Timer(0.8, lambda: webbrowser.open(target_url)).start()

    os.chdir(repo_root)
    uvicorn.run("ui_backend.app:app", host=args.host, port=int(args.port), reload=False)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="promotion-harness", description="Promotion Harness Agent CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    init_parser = sub.add_parser("init", help="Initialize the current repository for Promotion Harness Agent")
    init_parser.add_argument("--repo-root", default="", help="Repository root to initialize")
    init_parser.set_defaults(func=cmd_init)

    run_parser = sub.add_parser("run", help="Run the Promotion Harness Agent pipeline in the current repository")
    run_parser.add_argument("--repo-root", default="", help="Target repository root")
    run_parser.add_argument("--requirement", required=True, help="Requirement to execute")
    run_parser.add_argument("--max-quality-loop-retries", type=int, default=5)
    run_parser.set_defaults(func=cmd_run)

    resume_parser = sub.add_parser("resume", help="Resume the current active run")
    resume_parser.add_argument("--repo-root", default="", help="Target repository root")
    resume_parser.add_argument("--max-quality-loop-retries", type=int, default=5)
    resume_parser.set_defaults(func=cmd_resume)

    ui_parser = sub.add_parser("ui", help="Launch the local Promotion Harness Agent UI")
    ui_parser.add_argument("--repo-root", default="", help="Target repository root")
    ui_parser.add_argument("--host", default="127.0.0.1", help="Host to bind the local UI server")
    ui_parser.add_argument("--port", "--backend-port", dest="port", type=int, default=8000, help="Port to bind the local UI server")
    ui_parser.add_argument("--open-browser", action="store_true", help="Open the UI in a browser after startup")
    ui_parser.set_defaults(func=cmd_ui)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
