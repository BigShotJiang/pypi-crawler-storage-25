import os


def load_artifact_preview(path: str, max_entries: int = 200, max_chars: int = 200_000) -> dict:
    if not path:
        return {"type": "missing", "path": path}

    if not os.path.exists(path):
        return {"type": "missing", "path": path}

    if os.path.isdir(path):
        entries = []
        for root, dirs, files in os.walk(path):
            for d in sorted(dirs):
                entries.append(os.path.relpath(os.path.join(root, d), path) + os.sep)
                if len(entries) >= max_entries:
                    break
            if len(entries) >= max_entries:
                break
            for f in sorted(files):
                entries.append(os.path.relpath(os.path.join(root, f), path))
                if len(entries) >= max_entries:
                    break
            if len(entries) >= max_entries:
                break
        return {"type": "dir", "path": path, "entries": entries, "truncated": len(entries) >= max_entries}

    if os.path.isfile(path):
        ext = os.path.splitext(path)[1].lower()
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        truncated = False
        if isinstance(max_chars, int) and max_chars > 0 and len(content) > max_chars:
            content = content[:max_chars]
            truncated = True
        return {"type": "file", "path": path, "ext": ext, "content": content, "truncated": truncated}

    return {"type": "other", "path": path}
