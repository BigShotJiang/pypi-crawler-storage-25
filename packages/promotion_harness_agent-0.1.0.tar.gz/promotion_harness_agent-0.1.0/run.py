import argparse
import logging
import os
from core.context_manager import ContextManager
from core.orchestrator import Orchestrator, FlowState
from core.middlewares import VerificationMiddleware
from core.runtime_paths import active_run_paths, resolve_repo_root, runtime_paths_for_run, write_current_run
from agents.trae_prd_agent import trae_prd_agent
from agents.trae_tech_spec_agent import trae_tech_spec_agent
from agents.trae_coding_agent import trae_coding_agent
from agents.trae_verifying_agent import trae_verifying_agent
from agents.trae_fixing_agent import trae_fixing_agent
from agents.trae_deploying_agent import trae_deploying_agent
from agents.trae_regression_testing_agent import trae_regression_testing_agent
from core.run_trace import append_event, generate_run_id, init_trace


def quality_loop_agent(ctx: ContextManager) -> FlowState:
    meta = ctx.context.get("metadata", {}) if isinstance(ctx.context.get("metadata"), dict) else {}
    quality_loop = meta.get("quality_loop") if isinstance(meta.get("quality_loop"), dict) else {}
    phase = str(quality_loop.get("phase") or meta.get("quality_loop_phase") or "verify").strip().lower()
    if phase == "fix":
        return trae_fixing_agent(ctx)
    return trae_verifying_agent(ctx)

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def setup_orchestrator(
    resume: bool,
    requirement: str,
    max_quality_loop_retries: int = 5,
    *,
    repo_root: str | None = None,
    run_id: str | None = None,
) -> Orchestrator:
    resolved_repo_root = resolve_repo_root(repo_root)
    if not resume:
        resolved_run_id = str(run_id or "").strip() or generate_run_id()
        paths = runtime_paths_for_run(resolved_run_id, resolved_repo_root)
        os.makedirs(paths.run_root, exist_ok=True)
        write_current_run(paths)
        cm = ContextManager(paths.progress_file, repo_root=resolved_repo_root)
        cm.clear()
        cm.set_state(FlowState.PLANNING.value)
        cm.update_metadata("requirement", requirement)
        cm.update_metadata("stage_timeouts_sec", {
            FlowState.PRD_DRAFTING.value: 600,
            FlowState.TECH_SPEC_DRAFTING.value: 600,
            FlowState.CODING.value: 1200,
            FlowState.QUALITY_LOOP.value: 1200,
            FlowState.VERIFYING.value: 1200,
            FlowState.FIXING.value: 1200,
            FlowState.DEPLOYING.value: 1200,
            FlowState.REGRESSION_TESTING.value: 1200,
        })
        cm.update_metadata("quality_loop", {
            "phase": "verify",
            "retry_count": 0,
            "max_retries": int(max_quality_loop_retries),
            "last_failure_summary": "",
            "history": [],
        })
        cm.update_metadata("quality_loop_phase", "verify")
        cm.update_metadata(
            "coco_runtime",
            {
                "model_name": os.environ.get("HARNESS_COCO_MODEL_NAME", ""),
            },
        )
        run_dir = paths.run_root_relative
        cm.update_metadata("run_id", resolved_run_id)
        cm.update_metadata("run_dir", run_dir)
        cm.update_metadata("trace_path", os.path.relpath(paths.trace_file, resolved_repo_root))
        init_trace(run_id=resolved_run_id, run_dir=paths.run_root)
        append_event("run_start", state=cm.get_state(), data={"requirement": requirement})
    else:
        logger.info("Resuming from existing active run state")
        active_paths = active_run_paths(resolved_repo_root)
        if active_paths is None:
            raise RuntimeError("active_run_required_for_resume")
        cm = ContextManager(active_paths.progress_file, repo_root=resolved_repo_root)
        run_id = cm.context.get("metadata", {}).get("run_id")
        run_dir = cm.context.get("metadata", {}).get("run_dir")
        if run_id and run_dir:
            init_trace(run_id=run_id, run_dir=os.path.join(resolved_repo_root, run_dir))
            # If the previous run was blocked on authorization, resume by retrying the blocked stage
            # without clearing progress/workspace. This keeps the same run_id/trace.
            if cm.get_state() == FlowState.AUTH_BLOCKED.value:
                meta = cm.context.get("metadata", {})
                back_to = None
                if isinstance(meta, dict):
                    back_to = meta.get("auth_block_stage")
                    if not back_to:
                        auth_block = meta.get("auth_block")
                        if isinstance(auth_block, dict):
                            back_to = auth_block.get("stage")
                if not back_to:
                    back_to = FlowState.PRD_DRAFTING.value
                back_to = str(back_to)
                if back_to == FlowState.FIXING.value:
                    cm.update_metadata("quality_loop_phase", "fix")
                    back_to = FlowState.QUALITY_LOOP.value
                elif back_to == FlowState.VERIFYING.value:
                    cm.update_metadata("quality_loop_phase", "verify")
                    back_to = FlowState.QUALITY_LOOP.value
                cm.set_state(back_to)

                # Remove the old auth_block.json so the UI doesn't keep showing a stale modal
                # and the stage retry can re-signal if authorization is still missing.
                auth_path = None
                if isinstance(meta, dict):
                    auth_path = meta.get("auth_block_path")
                if not isinstance(auth_path, str) or not auth_path:
                    auth_path = os.path.join(resolved_repo_root, str(run_dir), "auth_block.json")
                try:
                    if auth_path and os.path.exists(auth_path):
                        os.remove(auth_path)
                except OSError:
                    pass

                append_event(
                    "run_resume_after_auth",
                    state=cm.get_state(),
                    data={"from_state": FlowState.AUTH_BLOCKED.value, "retry_state": cm.get_state()},
                )

            append_event("run_resume", state=cm.get_state(), data={})

    orch = Orchestrator(cm)

    # Register handlers
    orch.register_handler(FlowState.INIT, lambda ctx: FlowState.PLANNING)
    orch.register_handler(FlowState.PLANNING, lambda ctx: FlowState.PRD_DRAFTING)
    orch.register_handler(FlowState.PRD_DRAFTING, trae_prd_agent)
    orch.register_handler(FlowState.TECH_SPEC_DRAFTING, trae_tech_spec_agent)
    orch.register_handler(FlowState.CODING, trae_coding_agent)
    orch.register_handler(FlowState.QUALITY_LOOP, quality_loop_agent)
    orch.register_handler(FlowState.VERIFYING, quality_loop_agent)
    orch.register_handler(FlowState.FIXING, trae_fixing_agent)
    orch.register_handler(FlowState.DEPLOYING, trae_deploying_agent)
    orch.register_handler(FlowState.REGRESSION_TESTING, trae_regression_testing_agent)

    orch.add_middleware(VerificationMiddleware())

    return orch

def main():
    parser = argparse.ArgumentParser(description="Harness Agent MVP Core")
    parser.add_argument("--requirement", type=str, help="Initial requirement to start the pipeline", default="")
    parser.add_argument("--resume", action="store_true", help="Resume from the active .harness run")
    parser.add_argument("--max-quality-loop-retries", type=int, default=5, help="Maximum quality-loop failures before failing the run")
    parser.add_argument("--coco-model-name", type=str, default="", help="Coco model name (passed via -c model.name=...)")
    parser.add_argument("--repo-root", type=str, default="", help="Target repository root for this run")
    parser.add_argument("--run-id", type=str, default="", help="Optional preallocated run id")
    args = parser.parse_args()

    if not args.resume and not args.requirement:
        print("Error: Must provide --requirement if not resuming.")
        parser.print_help()
        return

    # Pass Coco runtime config via env so the ACP runner can append it to `coco acp serve`.
    if args.coco_model_name:
        os.environ["HARNESS_COCO_MODEL_NAME"] = str(args.coco_model_name)

    resolved_repo_root = resolve_repo_root(args.repo_root or None)
    os.environ["HARNESS_REPO_ROOT"] = resolved_repo_root
    os.chdir(resolved_repo_root)

    orch = setup_orchestrator(
        args.resume,
        args.requirement,
        max_quality_loop_retries=args.max_quality_loop_retries,
        repo_root=resolved_repo_root,
        run_id=args.run_id or None,
    )
    orch.run()

if __name__ == "__main__":
    main()
