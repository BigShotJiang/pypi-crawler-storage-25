"""Backward-compatible shim for trace read-model utilities.

The implementation moved to `core.read_model.trace` to keep the repo root cleaner
and to make the parsing layer reusable without Streamlit dependencies.
"""

from core.read_model.trace import *  # noqa: F401,F403

