import logging
import os

from core.acp_agent import AcpAgent
from core.auth_block import clear_auth_block, load_auth_block
from core.context_manager import ContextManager
from core.orchestrator import FlowState
from core.run_trace import append_event
from core.capability_registry import default_registry


logger = logging.getLogger(__name__)


def _list_workspace_files(base_dir: str) -> list[str]:
    files: list[str] = []
    if not os.path.exists(base_dir):
        return files
    for root, _, filenames in os.walk(base_dir):
        for filename in sorted(filenames):
            files.append(os.path.relpath(os.path.join(root, filename), os.getcwd()))
    return sorted(files)


def trae_fixing_agent(ctx: ContextManager) -> FlowState:
    logger.info("Trae Fixing Agent running...")

    stage_name = FlowState.QUALITY_LOOP.value if ctx.get_state() == FlowState.QUALITY_LOOP.value else FlowState.FIXING.value
    ctx.update_quality_loop(phase="fix")
    stage_ctx = ctx.prepare_stage_context(stage_name, repo_root=os.getcwd())
    cap_md, cap_payload = default_registry().advertise_for_stage(stage_name)
    append_event("capabilities_advertised", state=stage_name, data=cap_payload)

    tech_spec_artifact = stage_ctx.get("artifacts", {}).get("tech_spec", {})
    tech_spec_path = tech_spec_artifact.get("path", "")
    if not tech_spec_artifact.get("exists"):
        ctx.update_metadata("last_error_log", "Tech spec file missing.")
        return FlowState.FAILED

    error_log = str(stage_ctx.get("evidence", {}).get("last_error_log", "")).strip()
    if not error_log:
        ctx.update_metadata("last_error_log", "Missing delivery-validation evidence for fixing.")
        return FlowState.FAILED

    workspace_files = stage_ctx.get("prompt_inputs", {}).get("workspace_files", [])
    workspace_listing = "\n".join(f"- {path}" for path in workspace_files) if workspace_files else "- (no files found)"
    auth_block_path = stage_ctx.get("prompt_inputs", {}).get("auth_block_abs_path", "")
    fix_seq = int(ctx.context.get("metadata", {}).get("fix_seq", 0)) + 1
    ctx.update_metadata("fix_seq", fix_seq)
    append_event("fix_attempt", state=FlowState.FIXING.value, data={
        "seq": fix_seq,
        "workspace_file_count": len(workspace_files),
        "error_log_size": len(error_log),
    })

    prompt = ctx.render_and_persist_stage_prompt(stage_name, repo_root=os.getcwd())

    try:
        clear_auth_block(auth_block_path)
        result = AcpAgent().run_task(prompt_text=prompt, cwd=os.getcwd(), stage=stage_name)
        if result.get("error"):
            raise RuntimeError(f"AcpAgent run_task returned error: {result['error']}")
        ctx.record_acp_session(stage_name, result)

        # If the model hit an auth wall, stop the pipeline as BLOCKED (resumable) instead of
        # marching on to the next delivery-validation pass with no real fix applied.
        auth_block = load_auth_block(auth_block_path)
        if auth_block is not None:
            logger.warning("Detected auth_block.json from model signal; halting FIXING as BLOCKED (not FAILED).")
            ctx.update_metadata("run_outcome", "auth_blocked")
            ctx.update_metadata("auth_block", auth_block)
            ctx.update_metadata("auth_block_path", auth_block_path)
            ctx.update_metadata("auth_block_stage", stage_name)
            ctx.update_quality_loop(phase="fix")
            ctx.append_quality_loop_history({"seq": fix_seq, "phase": "fix", "result": "auth_blocked"})
            ctx.update_metadata(
                "last_error_log",
                "BLOCKED_AUTH: model reported authorization required; see auth_block.json",
            )
            return FlowState.AUTH_BLOCKED

        ctx.append_quality_loop_history({"seq": fix_seq, "phase": "fix", "result": "fixed"})
        ctx.update_quality_loop(phase="verify")
        append_event("fix_attempt", state=stage_name, data={"seq": fix_seq, "result": "success"})
        return FlowState.QUALITY_LOOP if stage_name == FlowState.QUALITY_LOOP.value else FlowState.QUALITY_LOOP
    except Exception as e:
        ctx.update_metadata("last_error_log", str(e))
        ctx.append_quality_loop_history({"seq": fix_seq, "phase": "fix", "result": "fix_failed", "error": str(e)})
        append_event("fix_attempt", state=stage_name, data={"seq": fix_seq, "result": "failed", "error": str(e)})
        return FlowState.FAILED
