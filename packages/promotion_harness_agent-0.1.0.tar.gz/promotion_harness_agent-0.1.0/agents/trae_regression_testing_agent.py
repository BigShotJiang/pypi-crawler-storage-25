import logging
import os

from core.acp_agent import AcpAgent
from core.auth_block import clear_auth_block, load_auth_block
from core.context_manager import ContextManager
from core.orchestrator import FlowState
from core.stage_output import validate_stage_output
from core.stage_validation import validate_regression_report

logger = logging.getLogger(__name__)



def trae_regression_testing_agent(ctx: ContextManager) -> FlowState:
    logger.info("Trae Regression Testing Agent running...")

    stage_ctx = ctx.prepare_stage_context(FlowState.REGRESSION_TESTING.value, repo_root=os.getcwd())
    regression_report_artifact = stage_ctx.get("artifacts", {}).get("regression_report", {})
    prompt_inputs = stage_ctx.get("prompt_inputs", {}) if isinstance(stage_ctx.get("prompt_inputs"), dict) else {}
    regression_report_path = str(regression_report_artifact.get("path") or "").strip()
    abs_regression_report_path = str(regression_report_artifact.get("absolute_path") or "").strip()
    auth_block_path = str(prompt_inputs.get("auth_block_abs_path") or "").strip()
    stage_output_abs_path = str(prompt_inputs.get("stage_output_abs_path") or "").strip()

    if not regression_report_path or not abs_regression_report_path:
        ctx.update_metadata("last_error_log", "Regression report artifact path missing.")
        return FlowState.FAILED

    os.makedirs(os.path.dirname(abs_regression_report_path), exist_ok=True)
    os.makedirs(os.path.dirname(stage_output_abs_path), exist_ok=True)
    prompt = ctx.render_and_persist_stage_prompt(FlowState.REGRESSION_TESTING.value, repo_root=os.getcwd())

    try:
        clear_auth_block(auth_block_path)
        agent = AcpAgent()
        result = agent.run_task(prompt_text=prompt, cwd=os.getcwd(), stage=FlowState.REGRESSION_TESTING.value)
        ctx.record_acp_session(FlowState.REGRESSION_TESTING.value, result)
        ctx.reload()

        if result.get("error"):
            meta = ctx.context.get("metadata", {}) if isinstance(ctx.context.get("metadata"), dict) else {}
            gate_denial = meta.get("last_gate_denial")
            if isinstance(gate_denial, dict) and str(gate_denial.get("stage") or "") == FlowState.REGRESSION_TESTING.value:
                gate_details = gate_denial.get("details", {}) if isinstance(gate_denial.get("details"), dict) else {}
                should_retry, _, _ = ctx.record_noncompliance(
                    stage=FlowState.REGRESSION_TESTING.value,
                    kind="tool_gate",
                    reason=str(gate_denial.get("reason") or "tool_gate_denied"),
                    details={
                        "last_gate_denial": gate_denial,
                        "error": str(result.get("error")),
                        "tool_id": gate_details.get("tool_id"),
                        "enabled_tool_ids": gate_details.get("enabled_tool_ids"),
                        "resolved_capability": gate_details.get("resolved_capability"),
                        "suggestion": gate_denial.get("suggestion"),
                        "reason": gate_denial.get("reason"),
                    },
                    suggestion="Fix the blocked tool usage or enable an allowed alternative for this stage.",
                )
                return FlowState.REGRESSION_TESTING if should_retry else FlowState.FAILED
            raise RuntimeError(f"AcpAgent run_task returned error: {result['error']}")

        auth_block = load_auth_block(auth_block_path)
        if auth_block is not None:
            ctx.update_metadata("run_outcome", "auth_blocked")
            ctx.update_metadata("auth_block", auth_block)
            ctx.update_metadata("auth_block_path", auth_block_path)
            ctx.update_metadata("auth_block_stage", FlowState.REGRESSION_TESTING.value)
            ctx.update_metadata(
                "last_error_log",
                "BLOCKED_AUTH: model reported authorization required; see auth_block.json",
            )
            return FlowState.AUTH_BLOCKED

        regression_report_payload = validate_regression_report(abs_regression_report_path)
        stage_output_payload = validate_stage_output(ctx.get_stage_result(FlowState.REGRESSION_TESTING.value), expected_stage=FlowState.REGRESSION_TESTING.value)

        ctx.add_artifact("regression_report", regression_report_path)
        ctx.record_stage_result(FlowState.REGRESSION_TESTING.value, stage_output_payload.to_dict())
        ctx.update_metadata("regression_result", str(regression_report_payload.get("final_verdict") or "").strip())
        ctx.update_metadata("regression_summary", str(regression_report_payload.get("summary") or "").strip())
        return FlowState.FINISHED
    except Exception as e:
        logger.error(f"Failed to execute REGRESSION_TESTING via ACP: {e}")
        ctx.update_metadata("last_error_log", str(e))
        return FlowState.FAILED
