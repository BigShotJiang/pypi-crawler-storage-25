import json
import logging
import os
from typing import Any

from core.auth_block import clear_auth_block, load_auth_block
from core.context_manager import ContextManager
from core.orchestrator import FlowState
from core.run_trace import append_event, get_trace
from core.capability_registry import default_registry
from core.stage_acceptance import run_stage_acceptance_verifier
from core.stage_output import StageOutputValidationError, stage_output_absolute_path, validate_stage_output
from core.stage_validation import path_exists_and_nonempty
from tools.test_feedback import recommend_test_commands


logger = logging.getLogger(__name__)


def _quality_report_path(*, run_dir_relative: str) -> str:
    return os.path.join(run_dir_relative, "outputs", "quality_report.json")


def _write_quality_report(payload: dict[str, Any], *, repo_root: str, run_dir_relative: str) -> str:
    rel_path = _quality_report_path(run_dir_relative=run_dir_relative)
    abs_path = os.path.join(repo_root, rel_path)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return rel_path


def _quality_loop_stage_output_payload(*, repo_root: str, quality_report_rel_path: str, validation: dict[str, Any], seq: int, status: str) -> dict[str, Any]:
    quality_report_abs_path = os.path.join(repo_root, quality_report_rel_path)
    return {
        "schema_version": 1,
        "stage": FlowState.QUALITY_LOOP.value,
        "status": status,
        "summary": str(validation.get("summary") or "质量校验完成").strip(),
        "artifacts": [
            {
                "artifact_type": "quality_report",
                "path": quality_report_rel_path,
                "absolute_path": quality_report_abs_path,
                "exists": True,
                "is_dir": False,
                "size_bytes": os.path.getsize(quality_report_abs_path),
                "summary": "当前阶段生成的质量闭环报告。",
            }
        ],
        "key_points": [f"validated_stage={validation.get('validated_stage')}", f"history_seq={seq}"],
        "evidence": list((validation.get("blocking_errors") if status == "fail" else validation.get("findings")) or []),
        "metadata": {
            "artifact_key": "quality_report",
            "validated_stage": validation.get("validated_stage"),
            "hard_validation_verdict": "fail" if status == "fail" else "pass",
        },
    }


def _load_quality_loop_stage_output_or_raise(*, repo_root: str, run_dir: str) -> dict[str, Any]:
    stage_output_abs_path = stage_output_absolute_path(run_dir, FlowState.QUALITY_LOOP.value)
    if not os.path.exists(stage_output_abs_path):
        raise FileNotFoundError(f"Missing QUALITY_LOOP stage output file: {stage_output_abs_path}")
    if os.path.isdir(stage_output_abs_path):
        raise FileNotFoundError(f"QUALITY_LOOP stage output path is a directory: {stage_output_abs_path}")
    with open(stage_output_abs_path, "r", encoding="utf-8", errors="replace") as f:
        raw_stage_output = json.load(f)
    if not isinstance(raw_stage_output, dict):
        raise ValueError("QUALITY_LOOP stage output must be a JSON object")
    validated_stage_output = validate_stage_output(raw_stage_output, expected_stage=FlowState.QUALITY_LOOP.value)
    artifact_types = {artifact.artifact_type for artifact in validated_stage_output.artifacts}
    if "quality_report" not in artifact_types:
        raise ValueError("QUALITY_LOOP stage output artifacts must include quality_report")
    metadata = validated_stage_output.metadata if isinstance(validated_stage_output.metadata, dict) else {}
    for key in ("validated_stage", "hard_validation_verdict"):
        if key not in metadata:
            raise ValueError(f"QUALITY_LOOP stage output metadata.{key} is required")
    return validated_stage_output.to_dict()


def _validate_previous_stage_delivery(ctx: ContextManager, *, repo_root: str) -> dict[str, Any]:
    metadata = ctx.context.get("metadata", {}) if isinstance(ctx.context.get("metadata"), dict) else {}
    artifacts = ctx.context.get("artifacts", {}) if isinstance(ctx.context.get("artifacts"), dict) else {}
    validated_stage = FlowState.CODING.value
    raw_stage_output = ctx.get_stage_result(validated_stage)
    if not isinstance(raw_stage_output, dict):
        return {
            "passed": False,
            "validated_stage": validated_stage,
            "summary": "缺少上一阶段的标准化输出 JSON。",
            "blocking_errors": [f"missing_stage_result:{validated_stage}"],
            "findings": [],
            "checked_artifacts": [],
        }

    try:
        validated_output = validate_stage_output(raw_stage_output, expected_stage=validated_stage)
    except StageOutputValidationError as exc:
        return {
            "passed": False,
            "validated_stage": validated_stage,
            "summary": f"上一阶段标准化输出校验失败：{exc}",
            "blocking_errors": [str(exc)],
            "findings": [],
            "checked_artifacts": [
                {
                    "artifact_type": item.get("artifact_type"),
                    "path": item.get("path"),
                    "exists": item.get("exists"),
                    "is_dir": item.get("is_dir"),
                }
                for item in raw_stage_output.get("artifacts", [])
                if isinstance(item, dict)
            ],
        }

    checked_artifacts: list[dict[str, Any]] = []
    blocking_errors: list[str] = []
    for artifact in validated_output.artifacts:
        exists_and_nonempty = path_exists_and_nonempty(artifact.absolute_path)
        checked_artifacts.append(
            {
                "artifact_type": artifact.artifact_type,
                "path": artifact.path,
                "absolute_path": artifact.absolute_path,
                "exists": artifact.exists,
                "is_dir": artifact.is_dir,
                "nonempty": exists_and_nonempty,
            }
        )
        if not exists_and_nonempty:
            blocking_errors.append(f"artifact_missing_or_empty:{artifact.artifact_type}")

    if not checked_artifacts:
        for artifact_key, artifact_path in artifacts.items():
            if not isinstance(artifact_path, str) or not artifact_path.strip():
                continue
            absolute_path = os.path.join(repo_root, artifact_path)
            exists_and_nonempty = path_exists_and_nonempty(absolute_path)
            checked_artifacts.append(
                {
                    "artifact_type": artifact_key,
                    "path": artifact_path,
                    "absolute_path": absolute_path,
                    "exists": os.path.exists(absolute_path),
                    "is_dir": os.path.isdir(absolute_path),
                    "nonempty": exists_and_nonempty,
                }
            )
            if not exists_and_nonempty:
                blocking_errors.append(f"artifact_missing_or_empty:{artifact_key}")

    if not checked_artifacts:
        blocking_errors.append("no_checked_artifacts")

    verification_targets: list[str] = []
    if isinstance(validated_output.metadata, dict):
        verification_targets = [
            str(item).strip()
            for item in (validated_output.metadata.get("changed_files") or [])
            if str(item).strip()
        ]
    if not verification_targets:
        verification_targets = [str(item.get("path") or "").strip() for item in checked_artifacts if str(item.get("path") or "").strip()]
    recommendations = recommend_test_commands(verification_targets) if verification_targets else []
    recommendation_payload = [
        {
            "title": rec.title,
            "reason": rec.reason,
            "command": rec.command,
            "matched_paths": list(rec.matched_paths),
            "tests": list(rec.tests),
        }
        for rec in recommendations
    ]

    passed = not blocking_errors
    return {
        "passed": passed,
        "validated_stage": validated_stage,
        "summary": (
            "上一阶段交付已通过本地结构校验。"
            if passed
            else "上一阶段交付未通过本地结构校验。"
        ),
        "blocking_errors": blocking_errors,
        "findings": [validated_output.summary]
        + (
            [f"recommended_verification_command={recommendations[0].command}"]
            if recommendations
            else ["verification_target_discovery_failed: no changed_files or artifact paths"]
        ),
        "checked_artifacts": checked_artifacts,
        "stage_output": validated_output.to_dict(),
        "verification_targets": verification_targets,
        "verification_recommendations": recommendation_payload,
    }


def trae_verifying_agent(ctx: ContextManager) -> FlowState:
    logger.info("Trae Verifying Agent running...")

    stage_name = FlowState.QUALITY_LOOP.value if ctx.get_state() == FlowState.QUALITY_LOOP.value else FlowState.VERIFYING.value
    _, cap_payload = default_registry().advertise_for_stage(stage_name)
    append_event("capabilities_advertised", state=stage_name, data=cap_payload)
    ctx.update_quality_loop(phase="verify")

    meta = ctx.context.get("metadata", {}) if isinstance(ctx.context.get("metadata"), dict) else {}
    quality_loop = meta.get("quality_loop") if isinstance(meta.get("quality_loop"), dict) else {}
    gate_denial = meta.get("last_gate_denial")
    if isinstance(gate_denial, dict) and str(gate_denial.get("stage") or "") in {FlowState.VERIFYING.value, FlowState.QUALITY_LOOP.value}:
        gate_details = gate_denial.get("details", {}) if isinstance(gate_denial.get("details"), dict) else {}
        should_retry, _, _ = ctx.record_noncompliance(
            stage=stage_name,
            kind="tool_gate",
            reason=str(gate_denial.get("reason") or "tool_gate_denied"),
            details={
                "last_gate_denial": gate_denial,
                "tool_id": gate_details.get("tool_id"),
                "enabled_tool_ids": gate_details.get("enabled_tool_ids"),
                "resolved_capability": gate_details.get("resolved_capability"),
                "suggestion": gate_denial.get("suggestion"),
                "reason": gate_denial.get("reason"),
            },
            suggestion="Fix the blocked tool usage or enable an allowed alternative for this stage.",
        )
        return FlowState.QUALITY_LOOP if should_retry else FlowState.FAILED

    seq = int(meta.get("verify_seq", 0)) + 1
    ctx.update_metadata("verify_seq", seq)
    trace = get_trace()
    repo_root = os.getcwd()
    run_dir_relative = str(meta.get("run_dir") or "").strip()
    if not run_dir_relative:
        raise RuntimeError("active_run_required_for_verifying")
    run_dir = trace.run_dir if trace else os.path.abspath(os.path.join(repo_root, run_dir_relative))
    os.makedirs(run_dir, exist_ok=True)
    stage_ctx = ctx.prepare_stage_context(stage_name, repo_root=repo_root)
    prompt_inputs = stage_ctx.get("prompt_inputs", {}) if isinstance(stage_ctx.get("prompt_inputs"), dict) else {}
    auth_block_path = str(prompt_inputs.get("auth_block_abs_path") or "").strip()
    clear_auth_block(auth_block_path)

    validation = _validate_previous_stage_delivery(ctx, repo_root=repo_root)
    quality_report = {
        "validated_stage": validation.get("validated_stage"),
        "hard_validation_verdict": "pass" if validation.get("passed") else "fail",
        "summary": validation.get("summary"),
        "blocking_errors": list(validation.get("blocking_errors") or []),
        "findings": list(validation.get("findings") or []),
        "checked_artifacts": list(validation.get("checked_artifacts") or []),
        "verification_targets": list(validation.get("verification_targets") or []),
        "verification_recommendations": list(validation.get("verification_recommendations") or []),
        "history_seq": seq,
    }
    quality_report_rel_path = _write_quality_report(
        quality_report,
        repo_root=repo_root,
        run_dir_relative=run_dir_relative,
    )
    ctx.add_artifact("quality_report", quality_report_rel_path)

    if not validation.get("passed"):
        retry_count = int(quality_loop.get("retry_count", 0) or 0) + 1
        max_retries = int(quality_loop.get("max_retries", 5) or 5)
        abort = retry_count > max_retries
        error_summary = str(validation.get("summary") or "质量校验失败").strip()
        blocking_text = "\n".join(str(item) for item in (validation.get("blocking_errors") or []) if str(item).strip())
        combined_output = error_summary if not blocking_text else f"{error_summary}\n{blocking_text}"
        abort_msg = f"\n\n[loop_guard] max_quality_loop_retries exceeded: {retry_count} > {max_retries}"
        ctx.update_metadata("last_error_log", combined_output + (abort_msg if abort else ""))
        stage_output_payload = _quality_loop_stage_output_payload(
            repo_root=repo_root,
            quality_report_rel_path=quality_report_rel_path,
            validation=validation,
            seq=seq,
            status="fail",
        )
        stage_output_abs_path = stage_output_absolute_path(run_dir, FlowState.QUALITY_LOOP.value)
        os.makedirs(os.path.dirname(stage_output_abs_path), exist_ok=True)
        with open(stage_output_abs_path, "w", encoding="utf-8") as f:
            json.dump(stage_output_payload, f, ensure_ascii=False, indent=2)
        ctx.record_stage_result(
            FlowState.QUALITY_LOOP.value,
            _load_quality_loop_stage_output_or_raise(repo_root=repo_root, run_dir=run_dir),
        )
        entry = {
            "seq": seq,
            "phase": "verify",
            "result": "abort" if abort else "fail",
            "retry_count": retry_count,
            "max_retries": max_retries,
            "quality_report_path": quality_report_rel_path,
            "validated_stage": validation.get("validated_stage"),
            "summary": error_summary,
        }
        ctx.append_quality_loop_history(entry)
        ctx.update_quality_loop(
            phase="verify" if abort else "fix",
            retry_count=retry_count,
            max_retries=max_retries,
            last_failure_summary=combined_output.strip(),
        )
        append_event("verify_result", state=stage_name, data=entry)
        if abort:
            append_event("loop_abort", state=stage_name, data={"retry_count": retry_count, "max_retries": max_retries})
            return FlowState.FAILED
        return FlowState.FIXING

    stage_output_payload = _quality_loop_stage_output_payload(
        repo_root=repo_root,
        quality_report_rel_path=quality_report_rel_path,
        validation=validation,
        seq=seq,
        status="pass",
    )
    stage_output_abs_path = stage_output_absolute_path(run_dir, FlowState.QUALITY_LOOP.value)
    os.makedirs(os.path.dirname(stage_output_abs_path), exist_ok=True)
    with open(stage_output_abs_path, "w", encoding="utf-8") as f:
        json.dump(stage_output_payload, f, ensure_ascii=False, indent=2)
    ctx.record_stage_result(
        FlowState.QUALITY_LOOP.value,
        _load_quality_loop_stage_output_or_raise(repo_root=repo_root, run_dir=run_dir),
    )

    acceptance = run_stage_acceptance_verifier(ctx, stage=FlowState.QUALITY_LOOP.value, metadata=ctx.context.get("metadata"))
    auth_block = load_auth_block(auth_block_path)
    if auth_block is not None:
        ctx.update_metadata("run_outcome", "auth_blocked")
        ctx.update_metadata("auth_block", auth_block)
        ctx.update_metadata("auth_block_path", auth_block_path)
        ctx.update_metadata("auth_block_stage", stage_name)
        ctx.update_quality_loop(phase="verify")
        ctx.append_quality_loop_history({
            "seq": seq,
            "phase": "verify",
            "result": "auth_blocked",
            "quality_report_path": quality_report_rel_path,
            "validated_stage": validation.get("validated_stage"),
        })
        ctx.update_metadata(
            "last_error_log",
            "BLOCKED_AUTH: model reported authorization required; see auth_block.json",
        )
        append_event("verify_result", state=stage_name, data={"seq": seq, "result": "auth_blocked"})
        return FlowState.AUTH_BLOCKED
    acceptance_outcome = str(acceptance.get("outcome") or "pass").strip().lower()
    if acceptance_outcome != "pass":
        retry_count = int((ctx.context.get("metadata", {}).get("quality_loop", {}) or {}).get("retry_count", 0) or 0) + 1
        max_retries = int((ctx.context.get("metadata", {}).get("quality_loop", {}) or {}).get("max_retries", 5) or 5)
        abort = retry_count > max_retries
        summary = str((acceptance.get("acceptance_result") or {}).get("summary") or acceptance.get("reason") or "质量准出失败").strip()
        if ctx.context.get("metadata", {}).get("last_error_log"):
            summary = str(ctx.context.get("metadata", {}).get("last_error_log"))
        entry = {
            "seq": seq,
            "phase": "verify",
            "result": "abort" if abort else "fail",
            "retry_count": retry_count,
            "max_retries": max_retries,
            "quality_report_path": quality_report_rel_path,
            "validated_stage": validation.get("validated_stage"),
            "summary": summary,
            "acceptance_reason": acceptance.get("reason"),
        }
        ctx.append_quality_loop_history(entry)
        ctx.update_quality_loop(
            phase="verify" if abort else "fix",
            retry_count=retry_count,
            max_retries=max_retries,
            last_failure_summary=summary,
        )
        append_event("verify_result", state=stage_name, data=entry)
        if abort:
            append_event("loop_abort", state=stage_name, data={"retry_count": retry_count, "max_retries": max_retries})
            return FlowState.FAILED
        return FlowState.FIXING

    ctx.update_metadata("last_error_log", "")
    ctx.append_quality_loop_history({
        "seq": seq,
        "phase": "verify",
        "result": "pass",
        "retry_count": 0,
        "quality_report_path": quality_report_rel_path,
        "validated_stage": validation.get("validated_stage"),
        "summary": str(validation.get("summary") or "质量校验通过").strip(),
    })
    ctx.update_quality_loop(phase="verify", retry_count=0, max_retries=int(quality_loop.get("max_retries", 5) or 5), last_failure_summary="")
    append_event("verify_result", state=stage_name, data={
        "seq": seq,
        "result": "pass",
        "retry_count": 0,
        "quality_report_path": quality_report_rel_path,
        "validated_stage": validation.get("validated_stage"),
        "message": "verification passed",
    })
    return FlowState.DEPLOYING
