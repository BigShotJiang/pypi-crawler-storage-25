import logging
import os

from core.acp_agent import AcpAgent
from core.auth_block import clear_auth_block, load_auth_block
from core.context_manager import ContextManager
from core.orchestrator import FlowState
from core.stage_output import validate_stage_output
from core.stage_validation import validate_deploy_report

logger = logging.getLogger(__name__)



def trae_deploying_agent(ctx: ContextManager) -> FlowState:
    logger.info("Trae Deploying Agent running...")

    stage_ctx = ctx.prepare_stage_context(FlowState.DEPLOYING.value, repo_root=os.getcwd())
    deploy_report_artifact = stage_ctx.get("artifacts", {}).get("deploy_report", {})
    prompt_inputs = stage_ctx.get("prompt_inputs", {}) if isinstance(stage_ctx.get("prompt_inputs"), dict) else {}
    deploy_report_path = str(deploy_report_artifact.get("path") or "").strip()
    abs_deploy_report_path = str(deploy_report_artifact.get("absolute_path") or "").strip()
    auth_block_path = str(prompt_inputs.get("auth_block_abs_path") or "").strip()
    stage_output_abs_path = str(prompt_inputs.get("stage_output_abs_path") or "").strip()

    if not deploy_report_path or not abs_deploy_report_path:
        ctx.update_metadata("last_error_log", "Deploy report artifact path missing.")
        return FlowState.FAILED

    os.makedirs(os.path.dirname(abs_deploy_report_path), exist_ok=True)
    os.makedirs(os.path.dirname(stage_output_abs_path), exist_ok=True)
    prompt = ctx.render_and_persist_stage_prompt(FlowState.DEPLOYING.value, repo_root=os.getcwd())

    try:
        clear_auth_block(auth_block_path)
        agent = AcpAgent()
        result = agent.run_task(prompt_text=prompt, cwd=os.getcwd(), stage=FlowState.DEPLOYING.value)
        ctx.record_acp_session(FlowState.DEPLOYING.value, result)
        ctx.reload()

        if result.get("error"):
            meta = ctx.context.get("metadata", {}) if isinstance(ctx.context.get("metadata"), dict) else {}
            gate_denial = meta.get("last_gate_denial")
            if isinstance(gate_denial, dict) and str(gate_denial.get("stage") or "") == FlowState.DEPLOYING.value:
                gate_details = gate_denial.get("details", {}) if isinstance(gate_denial.get("details"), dict) else {}
                should_retry, _, _ = ctx.record_noncompliance(
                    stage=FlowState.DEPLOYING.value,
                    kind="tool_gate",
                    reason=str(gate_denial.get("reason") or "tool_gate_denied"),
                    details={
                        "last_gate_denial": gate_denial,
                        "error": str(result.get("error")),
                        "tool_id": gate_details.get("tool_id"),
                        "enabled_tool_ids": gate_details.get("enabled_tool_ids"),
                        "resolved_capability": gate_details.get("resolved_capability"),
                        "suggestion": gate_denial.get("suggestion"),
                        "reason": gate_denial.get("reason"),
                    },
                    suggestion="Fix the blocked tool usage or enable an allowed alternative for this stage.",
                )
                return FlowState.DEPLOYING if should_retry else FlowState.FAILED
            raise RuntimeError(f"AcpAgent run_task returned error: {result['error']}")

        auth_block = load_auth_block(auth_block_path)
        if auth_block is not None:
            ctx.update_metadata("run_outcome", "auth_blocked")
            ctx.update_metadata("auth_block", auth_block)
            ctx.update_metadata("auth_block_path", auth_block_path)
            ctx.update_metadata("auth_block_stage", FlowState.DEPLOYING.value)
            ctx.update_metadata(
                "last_error_log",
                "BLOCKED_AUTH: model reported authorization required; see auth_block.json",
            )
            return FlowState.AUTH_BLOCKED

        deploy_report_payload = validate_deploy_report(abs_deploy_report_path)
        stage_output_payload = validate_stage_output(ctx.get_stage_result(FlowState.DEPLOYING.value), expected_stage=FlowState.DEPLOYING.value)

        ctx.add_artifact("deploy_report", deploy_report_path)
        ctx.record_stage_result(FlowState.DEPLOYING.value, stage_output_payload.to_dict())
        ctx.update_metadata("deploy_status", str(deploy_report_payload.get("status") or "").strip())
        ctx.update_metadata("deploy_summary", str(deploy_report_payload.get("summary") or "").strip())
        ctx.update_metadata("deploy_evidence", "\n".join(str(item).strip() for item in (deploy_report_payload.get("evidence") or []) if str(item).strip()))
        env_name = str(deploy_report_payload.get("env_name") or "").strip()
        if env_name:
            ctx.update_metadata("deploy_targets", [env_name])
        return FlowState.REGRESSION_TESTING
    except Exception as e:
        logger.error(f"Failed to execute DEPLOYING via ACP: {e}")
        ctx.update_metadata("last_error_log", str(e))
        return FlowState.FAILED
