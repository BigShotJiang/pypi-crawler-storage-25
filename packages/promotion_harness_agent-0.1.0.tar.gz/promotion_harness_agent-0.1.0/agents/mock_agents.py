import os
from core.orchestrator import FlowState
from core.context_manager import ContextManager
import logging

logger = logging.getLogger(__name__)

def mock_prd_agent(ctx: ContextManager) -> FlowState:
    logger.info("Mock PRD Agent running...")
    run_dir = str((ctx.context.get("metadata") or {}).get("run_dir") or "").strip()
    if not run_dir:
        raise ValueError("run_dir_required")
    docs_dir = os.path.join(run_dir, "docs")
    os.makedirs(docs_dir, exist_ok=True)

    prd_path = os.path.join(docs_dir, "prd.md")
    with open(prd_path, "w") as f:
        f.write("# Mock PRD\n\nThis is a mock PRD.")
        
    ctx.add_artifact("prd", prd_path)
    return FlowState.TECH_SPEC_DRAFTING

def mock_tech_spec_agent(ctx: ContextManager) -> FlowState:
    logger.info("Mock Tech Spec Agent running...")
    run_dir = str((ctx.context.get("metadata") or {}).get("run_dir") or "").strip()
    if not run_dir:
        raise ValueError("run_dir_required")
    docs_dir = os.path.join(run_dir, "docs")
    os.makedirs(docs_dir, exist_ok=True)

    ts_path = os.path.join(docs_dir, "tech_spec.md")
    with open(ts_path, "w") as f:
        f.write("# Mock Tech Spec\n\nThis is a mock tech spec.")
        
    ctx.add_artifact("tech_spec", ts_path)
    return FlowState.CODING

def mock_coding_agent(ctx: ContextManager) -> FlowState:
    logger.info("Mock Coding Agent running...")
    repo_root = ctx._repo_root()
    src_dir = os.path.join(repo_root, "src")
    os.makedirs(src_dir, exist_ok=True)

    code_path = os.path.join(src_dir, "main.py")
    with open(code_path, "w") as f:
        f.write("def main():\n    print('Hello World')\n")
        
    ctx.add_artifact("code", code_path)
    return FlowState.QUALITY_LOOP
