import os
import logging
from core.orchestrator import FlowState
from core.context_manager import ContextManager
from core.acp_agent import AcpAgent
from core.auth_block import clear_auth_block, load_auth_block
from core.stage_validation import read_nonempty_text_file

logger = logging.getLogger(__name__)

def trae_prd_agent(ctx: ContextManager) -> FlowState:
    logger.info("Trae PRD Agent running...")

    stage_ctx = ctx.prepare_stage_context(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())
    prd_artifact = stage_ctx.get("artifacts", {}).get("prd", {})
    prd_path = str(prd_artifact.get("path") or "").strip()
    abs_prd_path = prd_artifact.get("absolute_path", os.path.abspath(prd_path))
    if not prd_path:
        ctx.update_metadata("last_error_log", "PRD artifact path missing.")
        return FlowState.FAILED
    os.makedirs(os.path.dirname(abs_prd_path), exist_ok=True)
    prompt_inputs = stage_ctx.get("prompt_inputs", {}) if isinstance(stage_ctx.get("prompt_inputs"), dict) else {}
    requirement = prompt_inputs.get("requirement", "未提供需求")
    auth_block_path = prompt_inputs.get("auth_block_abs_path", "")
    prompt = ctx.render_and_persist_stage_prompt(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())

    logger.info(f"Invoking AcpAgent to generate PRD based on requirement: {requirement}")

    try:
        if os.path.exists(abs_prd_path):
            os.remove(abs_prd_path)
        clear_auth_block(auth_block_path)
        agent = AcpAgent()
        result = agent.run_task(prompt_text=prompt, cwd=os.getcwd(), stage=FlowState.PRD_DRAFTING.value)

        ctx.record_acp_session(FlowState.PRD_DRAFTING.value, result)
        # Observe any evidence/gating metadata recorded during ACP execution.
        ctx.reload()

        if result.get("error"):
            # Preserve the raw agent error for downstream (UI/FIXING) and tests.
            ctx.update_metadata("last_error_log", f"AcpAgent run_task returned error: {result.get('error')}")
            meta = ctx.context.get("metadata", {}) if isinstance(ctx.context.get("metadata"), dict) else {}
            gate_denial = meta.get("last_gate_denial")
            if isinstance(gate_denial, dict) and str(gate_denial.get("stage") or "") == FlowState.PRD_DRAFTING.value:
                gate_details = gate_denial.get("details", {}) if isinstance(gate_denial.get("details"), dict) else {}
                should_retry, _, _ = ctx.record_noncompliance(
                    stage=FlowState.PRD_DRAFTING.value,
                    kind="tool_gate",
                    reason=str(gate_denial.get("reason") or "tool_gate_denied"),
                    details={
                        "last_gate_denial": gate_denial,
                        "error": str(result.get("error")),
                        "tool_id": gate_details.get("tool_id"),
                        "enabled_tool_ids": gate_details.get("enabled_tool_ids"),
                        "resolved_capability": gate_details.get("resolved_capability"),
                        "suggestion": gate_denial.get("suggestion"),
                        "reason": gate_denial.get("reason"),
                    },
                    suggestion="Fix the blocked tool usage or enable an allowed alternative for this stage.",
                )
                return FlowState.PRD_DRAFTING if should_retry else FlowState.FAILED
            return FlowState.FAILED

        logger.info("AcpAgent returned from run_task.")

        auth_block = load_auth_block(auth_block_path)
        if auth_block is not None:
            logger.warning(
                "Detected auth_block.json from model signal; halting PRD_DRAFTING as BLOCKED (not FAILED)."
            )
            ctx.update_metadata("run_outcome", "auth_blocked")
            ctx.update_metadata("auth_block", auth_block)
            ctx.update_metadata("auth_block_path", auth_block_path)
            # Record which stage should be retried after the user finishes authorization.
            ctx.update_metadata("auth_block_stage", FlowState.PRD_DRAFTING.value)
            ctx.update_metadata(
                "last_error_log",
                "BLOCKED_AUTH: model reported authorization required; see auth_block.json",
            )
            return FlowState.AUTH_BLOCKED

        if not os.path.exists(abs_prd_path):
            raise FileNotFoundError(f"AcpAgent did not create the expected file at {abs_prd_path}")

        read_nonempty_text_file(
            abs_prd_path,
            empty_message=f"AcpAgent created an empty PRD file at {abs_prd_path}",
        )

        ctx.add_artifact("prd", prd_path)
        return FlowState.TECH_SPEC_DRAFTING

    except Exception as e:
        logger.error(f"Failed to generate PRD via ACP: {e}")
        ctx.update_metadata("last_error_log", str(e))
        return FlowState.FAILED
