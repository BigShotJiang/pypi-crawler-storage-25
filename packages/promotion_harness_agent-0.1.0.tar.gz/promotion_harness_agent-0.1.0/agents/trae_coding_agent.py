import json
import os
import logging

from core.orchestrator import FlowState
from core.context_manager import ContextManager
from core.acp_agent import AcpAgent
from core.auth_block import clear_auth_block, load_auth_block
from core.stage_output import validate_stage_output
from core.stage_validation import path_exists_and_nonempty

logger = logging.getLogger(__name__)

def trae_coding_agent(ctx: ContextManager) -> FlowState:
    logger.info("Trae Coding Agent running...")
    stage_ctx = ctx.prepare_stage_context(FlowState.CODING.value, repo_root=os.getcwd())
    tech_spec_artifact = stage_ctx.get("artifacts", {}).get("tech_spec", {})
    prompt_inputs = stage_ctx.get("prompt_inputs", {})
    tech_spec_path = tech_spec_artifact.get("path", "")
    if not tech_spec_artifact.get("exists"):
        ctx.update_metadata("last_error_log", "Tech spec file missing.")
        return FlowState.FAILED

    if not tech_spec_artifact.get("content"):
        ctx.update_metadata("last_error_log", "Failed to read tech spec: empty content")
        return FlowState.FAILED

    repo_root = os.getcwd()
    src_dir = prompt_inputs.get("src_dir", repo_root)
    tests_dir = prompt_inputs.get("tests_dir", repo_root)
    src_dir_hint = str(prompt_inputs.get("src_dir_hint") or ".").strip() or "."
    tests_dir_hint = str(prompt_inputs.get("tests_dir_hint") or ".").strip() or "."
    auth_block_path = prompt_inputs.get("auth_block_abs_path", "")
    prompt = ctx.render_and_persist_stage_prompt(FlowState.CODING.value, repo_root=os.getcwd())

    try:
        clear_auth_block(auth_block_path)
        agent = AcpAgent()
        result = agent.run_task(prompt_text=prompt, cwd=os.getcwd(), stage=FlowState.CODING.value)
        ctx.record_acp_session(FlowState.CODING.value, result)
        ctx.reload()

        if result.get("error"):
            meta = ctx.context.get("metadata", {}) if isinstance(ctx.context.get("metadata"), dict) else {}
            gate_denial = meta.get("last_gate_denial")
            if isinstance(gate_denial, dict) and str(gate_denial.get("stage") or "") == FlowState.CODING.value:
                gate_details = gate_denial.get("details", {}) if isinstance(gate_denial.get("details"), dict) else {}
                should_retry, _, _ = ctx.record_noncompliance(
                    stage=FlowState.CODING.value,
                    kind="tool_gate",
                    reason=str(gate_denial.get("reason") or "tool_gate_denied"),
                    details={
                        "last_gate_denial": gate_denial,
                        "error": str(result.get("error")),
                        "tool_id": gate_details.get("tool_id"),
                        "enabled_tool_ids": gate_details.get("enabled_tool_ids"),
                        "resolved_capability": gate_details.get("resolved_capability"),
                        "suggestion": gate_denial.get("suggestion"),
                        "reason": gate_denial.get("reason"),
                    },
                    suggestion="Fix the blocked tool usage or enable an allowed alternative for this stage.",
                )
                return FlowState.CODING if should_retry else FlowState.FAILED
            raise RuntimeError(f"AcpAgent run_task returned error: {result['error']}")

        auth_block = load_auth_block(auth_block_path)
        if auth_block is not None:
            logger.warning("Detected auth_block.json from model signal; halting CODING as BLOCKED (not FAILED).")
            ctx.update_metadata("run_outcome", "auth_blocked")
            ctx.update_metadata("auth_block", auth_block)
            ctx.update_metadata("auth_block_path", auth_block_path)
            ctx.update_metadata("auth_block_stage", FlowState.CODING.value)
            ctx.update_metadata(
                "last_error_log",
                "BLOCKED_AUTH: model reported authorization required; see auth_block.json",
            )
            return FlowState.AUTH_BLOCKED

        stage_output_abs_path = str(prompt_inputs.get("stage_output_abs_path") or "").strip()
        if stage_output_abs_path and os.path.exists(stage_output_abs_path) and not os.path.isdir(stage_output_abs_path):
            with open(stage_output_abs_path, "r", encoding="utf-8", errors="replace") as f:
                stage_output_payload = json.load(f)
            validated_stage_output = validate_stage_output(stage_output_payload, expected_stage=FlowState.CODING.value)
            ctx.record_stage_result(FlowState.CODING.value, validated_stage_output.to_dict())
            artifact_paths = {artifact.artifact_type: artifact.path for artifact in validated_stage_output.artifacts}
            if artifact_paths.get("code_root"):
                ctx.add_artifact("code_root", artifact_paths["code_root"])
            if artifact_paths.get("tests_root"):
                ctx.add_artifact("tests_root", artifact_paths["tests_root"])
        else:
            if not path_exists_and_nonempty(src_dir):
                raise FileNotFoundError(f"No source artifacts were found under {src_dir_hint}")

            if not path_exists_and_nonempty(tests_dir):
                raise FileNotFoundError(f"No test artifacts were found under {tests_dir_hint}")

            ctx.add_artifact("code_root", src_dir_hint)
            ctx.add_artifact("tests_root", tests_dir_hint)

        ctx.update_metadata("quality_loop_phase", "verify")
        return FlowState.QUALITY_LOOP

    except Exception as e:
        ctx.update_metadata("last_error_log", str(e))
        return FlowState.FAILED
