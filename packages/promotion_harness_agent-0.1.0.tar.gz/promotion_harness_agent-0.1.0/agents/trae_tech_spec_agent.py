import os
import logging
from core.orchestrator import FlowState
from core.context_manager import ContextManager
from core.acp_agent import AcpAgent
from core.auth_block import clear_auth_block, load_auth_block
from core.capability_registry import default_registry
from core.run_trace import append_event
from core.stage_validation import read_nonempty_text_file

logger = logging.getLogger(__name__)

def trae_tech_spec_agent(ctx: ContextManager) -> FlowState:
    logger.info("Trae Tech Spec Agent running...")

    stage_ctx = ctx.prepare_stage_context(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
    prd_artifact = stage_ctx.get("artifacts", {}).get("prd", {})
    tech_spec_artifact = stage_ctx.get("artifacts", {}).get("tech_spec", {})
    prd_path = str(prd_artifact.get("path") or "").strip()
    prd_content = prd_artifact.get("content", "")
    tech_spec_path = str(tech_spec_artifact.get("path") or "").strip()
    abs_tech_spec_path = tech_spec_artifact.get("absolute_path", os.path.abspath(tech_spec_path))
    if not prd_path:
        ctx.update_metadata("last_error_log", "PRD artifact path missing.")
        return FlowState.FAILED
    if not tech_spec_path:
        ctx.update_metadata("last_error_log", "Tech spec artifact path missing.")
        return FlowState.FAILED
    prompt_inputs = stage_ctx.get("prompt_inputs", {}) if isinstance(stage_ctx.get("prompt_inputs"), dict) else {}
    auth_block_path = prompt_inputs.get("auth_block_abs_path", "")

    if not prd_artifact.get("exists"):
        logger.error(f"PRD file not found at {prd_path}. Tech Spec Agent cannot proceed without a PRD.")
        ctx.context["metadata"]["last_error_log"] = "PRD file missing."
        return FlowState.FAILED

    if not prd_content:
        logger.error("PRD file exists but could not be read from stage context.")
        ctx.context["metadata"]["last_error_log"] = "Failed to read PRD: empty content"
        return FlowState.FAILED

    os.makedirs(os.path.dirname(abs_tech_spec_path), exist_ok=True)
    cap_md, cap_payload = default_registry().advertise_for_stage(FlowState.TECH_SPEC_DRAFTING.value)
    append_event("capabilities_advertised", state=FlowState.TECH_SPEC_DRAFTING.value, data=cap_payload)
    prompt = ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())

    logger.info("Invoking AcpAgent to generate Tech Spec based on PRD...")
    
    try:
        # 5. Execute Agent
        if os.path.exists(abs_tech_spec_path):
            os.remove(abs_tech_spec_path)
        clear_auth_block(auth_block_path)
        agent = AcpAgent()
        result = agent.run_task(prompt_text=prompt, cwd=os.getcwd(), stage=FlowState.TECH_SPEC_DRAFTING.value)
        
        ctx.record_acp_session(FlowState.TECH_SPEC_DRAFTING.value, result)
        # Observe any evidence/gating metadata recorded during ACP execution.
        ctx.reload()

        if result.get("error"):
            # Preserve the raw agent error for downstream (UI/FIXING) and tests.
            ctx.update_metadata("last_error_log", f"AcpAgent run_task returned error: {result.get('error')}")
            meta = ctx.context.get("metadata", {}) if isinstance(ctx.context.get("metadata"), dict) else {}
            gate_denial = meta.get("last_gate_denial")
            if isinstance(gate_denial, dict) and str(gate_denial.get("stage") or "") == FlowState.TECH_SPEC_DRAFTING.value:
                gate_details = gate_denial.get("details", {}) if isinstance(gate_denial.get("details"), dict) else {}
                should_retry, _, _ = ctx.record_noncompliance(
                    stage=FlowState.TECH_SPEC_DRAFTING.value,
                    kind="tool_gate",
                    reason=str(gate_denial.get("reason") or "tool_gate_denied"),
                    details={
                        "last_gate_denial": gate_denial,
                        "error": str(result.get("error")),
                        "tool_id": gate_details.get("tool_id"),
                        "enabled_tool_ids": gate_details.get("enabled_tool_ids"),
                        "resolved_capability": gate_details.get("resolved_capability"),
                        "suggestion": gate_denial.get("suggestion"),
                        "reason": gate_denial.get("reason"),
                    },
                    suggestion="Fix the blocked tool usage or enable an allowed alternative for this stage.",
                )
                return FlowState.TECH_SPEC_DRAFTING if should_retry else FlowState.FAILED
            return FlowState.FAILED

        logger.info("AcpAgent successfully completed the task.")

        auth_block = load_auth_block(auth_block_path)
        if auth_block is not None:
            logger.warning(
                "Detected auth_block.json from model signal; halting TECH_SPEC_DRAFTING as BLOCKED (not FAILED)."
            )
            ctx.update_metadata("run_outcome", "auth_blocked")
            ctx.update_metadata("auth_block", auth_block)
            ctx.update_metadata("auth_block_path", auth_block_path)
            ctx.update_metadata("auth_block_stage", FlowState.TECH_SPEC_DRAFTING.value)
            ctx.update_metadata(
                "last_error_log",
                "BLOCKED_AUTH: model reported authorization required; see auth_block.json",
            )
            return FlowState.AUTH_BLOCKED
        
        # 6. Extract Output from the prompt_response
        # We rely entirely on the agent calling fs.writeTextFile, which is handled
        # by the HarnessClientImpl interceptor and writes to the absolute path.
        if not os.path.exists(abs_tech_spec_path):
            raise FileNotFoundError(f"AcpAgent did not create the expected file at {abs_tech_spec_path}")
        read_nonempty_text_file(
            abs_tech_spec_path,
            empty_message=f"AcpAgent created an empty Tech Spec file at {abs_tech_spec_path}",
        )

        ctx.add_artifact("tech_spec", tech_spec_path)
        return FlowState.CODING

    except Exception as e:
        logger.error(f"Failed to generate Tech Spec via AcpAgent: {e}")
        ctx.update_metadata("last_error_log", str(e))
        return FlowState.FAILED
