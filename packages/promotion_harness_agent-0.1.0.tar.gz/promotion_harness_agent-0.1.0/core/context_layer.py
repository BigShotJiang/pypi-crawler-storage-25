from __future__ import annotations

import json
import os
from typing import Any

from core.runtime_paths import active_run_paths
from core.stage_output import SCHEMA_VERSION, stage_output_absolute_path, stage_output_relative_path


def _default_artifact_paths(*, repo_root: str, metadata: dict[str, Any]) -> dict[str, str]:
    run_dir_rel = str(metadata.get("run_dir") or "").strip()
    if not run_dir_rel:
        active = active_run_paths(repo_root)
        run_dir_rel = active.run_root_relative if active is not None else os.path.join(".harness", "preview-run")
    paths = {
        "code_root": ".",
        "tests_root": "tests" if os.path.isdir(os.path.join(repo_root, "tests")) else ".",
    }
    if run_dir_rel:
        paths.update(
            {
                "prd": os.path.join(run_dir_rel, "docs", "prd.md"),
                "tech_spec": os.path.join(run_dir_rel, "docs", "tech_spec.md"),
                "quality_report": os.path.join(run_dir_rel, "outputs", "quality_report.json"),
                "deploy_report": os.path.join(run_dir_rel, "outputs", "deploy_report.json"),
                "regression_report": os.path.join(run_dir_rel, "outputs", "regression_report.json"),
            }
        )
    return paths


# 下游 stage 的"输入来源优先级"契约：避免跨阶段重复拉取外部资源（飞书文档、BAM
# 链接、审批链接等），浪费 token 与时间。PRD 阶段是信息采集源头，不受此约束。
_INPUT_PRIORITY_CONTRACT = """\
## 输入来源优先级 (Input Source Priority)

1. PRIMARY（权威来源）
   - 当前目标仓库内已存在的文件，以及本 run 已落盘到 `.harness/runs/<run_id>/` 的全部产物
   - 默认假设 PRIMARY 已经包含你完成本阶段所需的全部信息
   - 第一步永远是：先在当前仓库和本 run 产物目录里查

2. SECONDARY（兜底来源）
   - 用户原始输入 (raw_requirement) 中附带的外部链接
     (飞书 / BAM / 审批 / 其它 CLI 或 MCP 可达资源)
   - 仅当 PRIMARY 明确缺少完成本阶段所必需的信息时才允许访问

3. 禁止行为
   - 不允许"为了保险再看一眼"式的重复拉取
   - 不允许在 PRIMARY 足以完成任务时访问 SECONDARY
"""


def _safe_read_text(path: str) -> str | None:
    if not path or not os.path.exists(path) or os.path.isdir(path):
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return None


def _read_agents_md(repo_root: str) -> str | None:
    candidate = os.path.join(repo_root, "AGENTS.md")
    if os.path.exists(candidate) and not os.path.isdir(candidate):
        return os.path.abspath(candidate)
    return None


def _artifact_entry(repo_root: str, rel_path: str, include_content: bool = False) -> dict[str, Any]:
    abs_path = os.path.abspath(os.path.join(repo_root, rel_path))
    exists = os.path.exists(abs_path)
    entry: dict[str, Any] = {
        "path": rel_path,
        "absolute_path": abs_path,
        "exists": exists,
        "is_dir": os.path.isdir(abs_path),
    }
    if include_content and exists and not os.path.isdir(abs_path):
        entry["content"] = _safe_read_text(abs_path) or ""
    return entry


def _build_artifacts(repo_root: str, raw_artifacts: dict[str, Any]) -> dict[str, dict[str, Any]]:
    metadata = raw_artifacts.get("__metadata__") if isinstance(raw_artifacts.get("__metadata__"), dict) else {}
    artifact_paths = _default_artifact_paths(repo_root=repo_root, metadata=metadata)
    for key, value in (raw_artifacts or {}).items():
        if key == "__metadata__":
            continue
        if isinstance(value, str) and value:
            artifact_paths[key] = value
    return {key: _artifact_entry(repo_root, path) for key, path in artifact_paths.items()}


def _global_constraints() -> list[str]:
    return [
        "如上下文提供了项目级约束文件路径，必须遵守其中约束",
        "控制面产物默认写入当前 run 对应的 `.harness/runs/<run_id>/` 目录",
        "业务修改必须限制在当前目标仓库内",
        "阶段推进依赖状态机和外部验证结果，不能由 Agent 单方面宣告完成",
    ]


def _stage_constraints(stage: str) -> list[str]:
    mapping = {
        "TECH_SPEC_DRAFTING": [
            "只能生成设计文档，不允许修改源码",
            "技术方案必须包含 Manifest 变更清单",
        ],
        "CODING": [
            "必须先理解当前仓库真实目录结构，再决定代码与测试写入位置",
            "必须同时生成代码与可供后续交付校验消费的测试产物",
        ],
        "QUALITY_LOOP": [
            "内部 phase=verify 时必须生成结构化验证证据",
            "内部 phase=fix 时修复应围绕最近一次失败证据展开",
            "失败后必须保留可供后续修复消费的错误日志",
        ],
        "DEPLOYING": [
            "部署必须围绕目标环境和部署结果展开",
            "失败时必须保留部署证据与错误信息，不能直接跳过到回归阶段",
        ],
        "REGRESSION_TESTING": [
            "回归测试必须针对已部署环境执行",
            "失败时必须保留接口结果与失败项证据",
        ],
        "FIXING": [
            "优先做最小修复",
            "修复应围绕最近一次交付校验失败证据展开",
        ],
        "VERIFYING": [
            "该阶段仅作为 QUALITY_LOOP 的兼容别名存在",
            "必须沿用统一交付校验证据与失败日志语义",
        ],
    }
    return mapping.get(stage, [])


def _stage_objective(stage: str) -> str:
    mapping = {
        "PRD_DRAFTING": "根据原始需求生成标准化 PRD 文档。",
        "TECH_SPEC_DRAFTING": "基于 PRD 生成技术方案并产出 Manifest。",
        "CODING": "基于技术方案实现当前仓库中的业务代码与测试。",
        "QUALITY_LOOP": "执行统一质量闭环；内部在结构校验/fix 子阶段之间推进并沉淀质量证据。",
        "VERIFYING": "兼容旧入口的交付校验别名；语义与 QUALITY_LOOP 的结构校验子阶段一致。",
        "FIXING": "基于最近一次交付校验失败证据完成最小修复。",
        "DEPLOYING": "执行部署到目标环境，并沉淀部署结果、环境与证据。",
        "REGRESSION_TESTING": "针对已部署环境执行回归测试，并沉淀接口结果与结论。",
    }
    return mapping.get(stage, "执行当前阶段任务。")


def _acceptance_criteria(stage: str) -> list[str]:
    mapping = {
        "TECH_SPEC_DRAFTING": [
            "生成非空 tech_spec 文档",
            "文档包含 requirement marker",
            "文档包含 Manifest 章节",
        ],
        "CODING": [
            "至少生成一个业务相关源文件",
            "至少生成一个可供后续消费的测试文件或测试入口",
        ],
        "QUALITY_LOOP": [
            "结构校验子阶段失败后必须保留可消费的失败证据",
            "fix 子阶段完成后必须回到结构校验子阶段重试，直到允许准出",
        ],
        "DEPLOYING": [
            "必须形成明确的目标环境、部署结果与证据摘要",
            "部署失败时必须保留后续可读的错误或阻塞信息",
        ],
        "REGRESSION_TESTING": [
            "必须形成明确的测试用例、环境与回归结论",
            "若失败，必须保留失败项与接口证据，不能仅给出笼统失败描述",
        ],
        "FIXING": [
            "修复动作仅围绕最近一次交付校验失败进行",
            "修复完成后返回 QUALITY_LOOP 重试",
        ],
    }
    return mapping.get(stage, [])


def _workspace_listing(repo_root: str) -> list[str]:
    out: list[str] = []
    skip_roots = {".git", ".harness", ".venv", "__pycache__"}
    for root, dirs, files in os.walk(repo_root):
        rel_root = os.path.relpath(root, repo_root)
        dirs[:] = [d for d in dirs if d not in skip_roots]
        if rel_root == ".":
            rel_root = ""
        for filename in sorted(files):
            rel_path = os.path.normpath(os.path.join(rel_root, filename))
            if rel_path.startswith(".harness") or rel_path.startswith(".git"):
                continue
            out.append(rel_path)
            if len(out) >= 200:
                return sorted(out)
    return sorted(out)


def _extract_gate_denial_feedback(non_compliance: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(non_compliance, dict):
        return {}
    details = non_compliance.get("details", {}) if isinstance(non_compliance.get("details"), dict) else {}
    nested = details.get("last_gate_denial", {}) if isinstance(details.get("last_gate_denial"), dict) else {}
    nested_details = nested.get("details", {}) if isinstance(nested.get("details"), dict) else {}

    merged: dict[str, Any] = {}
    for source in (nested, nested_details, details):
        if not isinstance(source, dict):
            continue
        for key in ("reason", "tool_id", "resolved_capability", "enabled_tool_ids", "suggestion"):
            value = source.get(key)
            if value is None or value == "":
                continue
            merged[key] = value
    if str(non_compliance.get("kind") or "").strip() == "tool_gate":
        if not merged.get("reason"):
            reason = non_compliance.get("reason")
            if reason:
                merged["reason"] = reason
        if not merged.get("suggestion"):
            suggestion = non_compliance.get("suggestion")
            if suggestion:
                merged["suggestion"] = suggestion
    return merged


def _load_run_stage_output(metadata: dict[str, Any], repo_root: str, stage: str) -> dict[str, Any] | None:
    run_dir_rel = metadata.get("run_dir")
    if not isinstance(run_dir_rel, str) or not run_dir_rel.strip():
        return None
    try:
        run_dir_abs = os.path.abspath(os.path.join(repo_root, run_dir_rel))
        abs_path = stage_output_absolute_path(run_dir_abs, stage)
    except Exception:
        return None
    if not os.path.exists(abs_path) or os.path.isdir(abs_path):
        return None
    try:
        with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
            payload = json.load(f)
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def build_full_context(raw_context: dict[str, Any], progress_file: str, repo_root: str) -> dict[str, Any]:
    metadata = raw_context.get("metadata", {}) if isinstance(raw_context.get("metadata"), dict) else {}
    artifacts = raw_context.get("artifacts", {}) if isinstance(raw_context.get("artifacts"), dict) else {}
    run_dir_rel = metadata.get("run_dir")
    if not isinstance(run_dir_rel, str) or not run_dir_rel:
        active = active_run_paths(repo_root)
        if active is not None:
            run_dir_rel = active.run_root_relative
        else:
            run_dir_rel = os.path.join(".harness", "preview-run")
    run_dir = os.path.abspath(os.path.join(repo_root, run_dir_rel))
    context_dir = os.path.join(run_dir, "context")
    stage_outputs_dir = os.path.join(run_dir, "stage_outputs")
    return {
        "schema_version": 1,
        "run": {
            "run_id": metadata.get("run_id"),
            "progress_file": os.path.abspath(progress_file),
            "repo_root": os.path.abspath(repo_root),
            "workspace_root": os.path.abspath(repo_root),
            "harness_root": os.path.abspath(os.path.join(repo_root, ".harness")),
            "run_dir": run_dir,
            "run_dir_relative": run_dir_rel,
            "context_dir": context_dir,
            "stage_outputs_dir": stage_outputs_dir,
            "trace_path": metadata.get("trace_path"),
            "current_stage": raw_context.get("state", "UNKNOWN"),
        },
        "request": {
            "raw_requirement": metadata.get("requirement", ""),
            "normalized_requirement": metadata.get("normalized_requirement", metadata.get("requirement", "")),
            "source_links": metadata.get("source_links", []),
            "user_intent": metadata.get("user_intent", metadata.get("requirement", "")),
        },
        "artifacts": _build_artifacts(repo_root, {**artifacts, "__metadata__": metadata}),
        "constraints": {
            "global": _global_constraints(),
        },
        "evidence": {
            "last_error_log": metadata.get("last_error_log", ""),
            "quality_loop": metadata.get("quality_loop", {}),
            "fix_seq": int(metadata.get("fix_seq", 0) or 0),
        },
        "memory": {
            "acp_sessions": metadata.get("acp_sessions", {}),
            "last_acp_session_id": metadata.get("last_acp_session_id"),
        },
        "metadata": metadata,
    }


def build_stage_context(
    stage: str,
    full_context: dict[str, Any],
    policy_rules_override: list[dict[str, str]] | None = None,
    output_requirements_override: str | None = None,
    tool_instructions_override: str | None = None,
    requirement_override: str | None = None,
) -> dict[str, Any]:
    repo_root = full_context["run"]["repo_root"]
    run_dir = full_context["run"]["run_dir"]
    auth_block_abs_path = os.path.join(run_dir, "auth_block.json")
    meta = full_context.get("metadata", {}) if isinstance(full_context.get("metadata"), dict) else {}
    last_nc = meta.get("last_noncompliance")
    if isinstance(last_nc, dict) and str(last_nc.get("stage") or "") == str(stage):
        non_compliance = dict(last_nc)
    else:
        non_compliance = None
    stage_retry_count_map = meta.get("stage_retry_count") if isinstance(meta.get("stage_retry_count"), dict) else {}
    try:
        stage_retry_count = int(stage_retry_count_map.get(stage, 0) or 0)
    except (TypeError, ValueError):
        stage_retry_count = 0
    from core.context_manager import resolve_stage_max_retries

    max_stage_retries = resolve_stage_max_retries(meta, stage)
    capabilities_md = ""
    capabilities_payload: dict[str, Any] = {"tools": []}
    tool_catalog_md = ""
    tool_catalog_payload: dict[str, Any] = {"tools": []}
    user_context_policy_rules: list[dict[str, str]] = []
    user_output_requirements = ""
    user_tool_instructions = ""
    user_context_policy_supported = False
    agents_md = _read_agents_md(repo_root)
    try:
        from core.capability_registry import default_registry
        from core.stage_context_policy import (
            get_stage_output_requirements,
            get_stage_policy_rules,
            get_stage_tool_instructions,
            load_stage_context_policy,
            stage_supports_context_policy,
        )
        from core.stage_tool_config import enabled_tool_ids_for_stage, load_stage_tool_config
        from core.tool_catalog import advertise_effective_tool_catalog

        capabilities_md, capabilities_payload = default_registry().advertise_for_stage(stage)
        stage_cfg = load_stage_tool_config(repo_root)
        enabled_ids = enabled_tool_ids_for_stage(stage_cfg, stage)
        tool_catalog_md, tool_catalog_payload = advertise_effective_tool_catalog(
            stage,
            workspace_root=repo_root,
            enabled_tool_ids=enabled_ids,
        )
        user_context_policy_supported = stage_supports_context_policy(stage)
        loaded_policy = load_stage_context_policy(repo_root)
        if policy_rules_override is not None:
            user_context_policy_rules = [
                {
                    "use_tool_id": str(item.get("use_tool_id") or "").strip(),
                    "do": str(item.get("do") or "").strip(),
                }
                for item in policy_rules_override
                if isinstance(item, dict)
            ]
        else:
            user_context_policy_rules = get_stage_policy_rules(loaded_policy, stage)
        user_output_requirements = (
            str(output_requirements_override).strip()
            if output_requirements_override is not None
            else get_stage_output_requirements(loaded_policy, stage)
        )
        user_tool_instructions = (
            str(tool_instructions_override).strip()
            if tool_instructions_override is not None
            else get_stage_tool_instructions(loaded_policy, stage)
        )
    except Exception:
        pass

    prompt_inputs: dict[str, Any] = {}
    artifacts: dict[str, Any] = {}
    requirement_value = (
        str(requirement_override).strip()
        if requirement_override is not None
        else str(full_context["request"].get("raw_requirement") or "").strip()
    )

    if stage == "PRD_DRAFTING":
        prd = _artifact_entry(repo_root, full_context["artifacts"]["prd"]["path"], include_content=True)
        requirement = requirement_value or "未提供需求"
        stage_output_rel_path = stage_output_relative_path(full_context["run"]["run_dir_relative"], stage)
        stage_output_abs_path = stage_output_absolute_path(full_context["run"]["run_dir"], stage)
        prompt_inputs = {
            "requirement": requirement,
            "requirement_marker": f"<!-- HARNESS_REQUIREMENT:{requirement} -->",
            "output_path": prd["path"],
            "output_abs_path": prd["absolute_path"],
            "auth_block_abs_path": auth_block_abs_path,
            "stage_output_path": stage_output_rel_path,
            "stage_output_abs_path": stage_output_abs_path,
        }
        artifacts = {"prd": prd}
    elif stage == "TECH_SPEC_DRAFTING":
        prd = _artifact_entry(repo_root, full_context["artifacts"]["prd"]["path"], include_content=True)
        tech_spec = _artifact_entry(repo_root, full_context["artifacts"]["tech_spec"]["path"], include_content=True)
        requirement = requirement_value or "未提供原始需求"
        stage_output_rel_path = stage_output_relative_path(full_context["run"]["run_dir_relative"], stage)
        stage_output_abs_path = stage_output_absolute_path(full_context["run"]["run_dir"], stage)
        prompt_inputs = {
            "requirement": requirement,
            "requirement_marker": f"<!-- HARNESS_REQUIREMENT:{requirement} -->",
            "output_path": tech_spec["path"],
            "output_abs_path": tech_spec["absolute_path"],
            "auth_block_abs_path": auth_block_abs_path,
            "stage_output_path": stage_output_rel_path,
            "stage_output_abs_path": stage_output_abs_path,
        }
        artifacts = {"prd": prd, "tech_spec": tech_spec}
    elif stage == "CODING":
        tech_spec = _artifact_entry(repo_root, full_context["artifacts"]["tech_spec"]["path"], include_content=True)
        code_root_path = str(full_context["artifacts"]["code_root"]["path"] or "").strip()
        tests_root_path = str(full_context["artifacts"]["tests_root"]["path"] or "").strip()
        if not code_root_path:
            code_root_path = "src"
        if not tests_root_path:
            tests_root_path = "tests"
        code_root = _artifact_entry(repo_root, code_root_path)
        tests_root = _artifact_entry(repo_root, tests_root_path)
        stage_output_rel_path = stage_output_relative_path(full_context["run"]["run_dir_relative"], stage)
        stage_output_abs_path = stage_output_absolute_path(full_context["run"]["run_dir"], stage)
        prompt_inputs = {
            "requirement": requirement_value or "未提供原始需求",
            "src_dir": code_root["absolute_path"],
            "tests_dir": tests_root["absolute_path"],
            "src_dir_hint": code_root["path"],
            "tests_dir_hint": tests_root["path"],
            "workspace_files": _workspace_listing(repo_root),
            "auth_block_abs_path": auth_block_abs_path,
            "stage_output_path": stage_output_rel_path,
            "stage_output_abs_path": stage_output_abs_path,
        }
        artifacts = {
            "tech_spec": tech_spec,
            "code_root": code_root,
            "tests_root": tests_root,
        }
    elif stage == "QUALITY_LOOP":
        tech_spec = _artifact_entry(repo_root, full_context["artifacts"]["tech_spec"]["path"], include_content=True)
        quality_report = _artifact_entry(repo_root, full_context["artifacts"]["quality_report"]["path"], include_content=True)
        workspace_files = _workspace_listing(repo_root)
        quality_loop = full_context["evidence"].get("quality_loop", {}) if isinstance(full_context["evidence"].get("quality_loop"), dict) else {}
        coding_result = _load_run_stage_output(meta, repo_root, "CODING") or {}
        stage_output_rel_path = stage_output_relative_path(full_context["run"]["run_dir_relative"], stage)
        stage_output_abs_path = stage_output_absolute_path(full_context["run"]["run_dir"], stage)
        prompt_inputs = {
            "error_log": full_context["evidence"]["last_error_log"] or "",
            "workspace_files": workspace_files,
            "auth_block_abs_path": auth_block_abs_path,
            "quality_loop_phase": str(quality_loop.get("phase") or "verify"),
            "quality_loop_history": quality_loop.get("history", []),
            "validated_stage": "CODING",
            "validated_stage_result": coding_result,
            "validated_stage_artifacts": coding_result.get("artifacts", []) if isinstance(coding_result, dict) else [],
            "stage_output_path": stage_output_rel_path,
            "stage_output_abs_path": stage_output_abs_path,
        }
        artifacts = {"tech_spec": tech_spec, "quality_report": quality_report}
    elif stage == "DEPLOYING":
        deploy_report = _artifact_entry(repo_root, full_context["artifacts"]["deploy_report"]["path"], include_content=True)
        deployment_targets = meta.get("deploy_targets") if isinstance(meta.get("deploy_targets"), list) else ["BOE", "PPE"]
        quality_loop_result = _load_run_stage_output(meta, repo_root, "QUALITY_LOOP") or {}
        coding_result = _load_run_stage_output(meta, repo_root, "CODING") or {}
        stage_output_rel_path = stage_output_relative_path(full_context["run"]["run_dir_relative"], stage)
        stage_output_abs_path = stage_output_absolute_path(full_context["run"]["run_dir"], stage)
        prompt_inputs = {
            "requirement": requirement_value or "未提供原始需求",
            "auth_block_abs_path": auth_block_abs_path,
            "stage_output_path": stage_output_rel_path,
            "stage_output_abs_path": stage_output_abs_path,
            "target_envs": [str(item).strip() for item in deployment_targets if str(item).strip()],
            "deployment_status": str(meta.get("deploy_status") or "pending").strip(),
            "deployment_summary": str(meta.get("deploy_summary") or full_context["evidence"].get("last_error_log") or "").strip(),
            "deployment_evidence": str(meta.get("deploy_evidence") or "").strip(),
            "quality_loop_result": quality_loop_result,
            "coding_result": coding_result,
        }
        artifacts = {"deploy_report": deploy_report}
    elif stage == "REGRESSION_TESTING":
        regression_report = _artifact_entry(repo_root, full_context["artifacts"]["regression_report"]["path"], include_content=True)
        deployment_targets = meta.get("deploy_targets") if isinstance(meta.get("deploy_targets"), list) else ["BOE", "PPE"]
        test_cases = meta.get("regression_test_cases") if isinstance(meta.get("regression_test_cases"), list) else []
        deploy_result = _load_run_stage_output(meta, repo_root, "DEPLOYING") or {}
        stage_output_rel_path = stage_output_relative_path(full_context["run"]["run_dir_relative"], stage)
        stage_output_abs_path = stage_output_absolute_path(full_context["run"]["run_dir"], stage)
        prompt_inputs = {
            "requirement": requirement_value or "未提供原始需求",
            "auth_block_abs_path": auth_block_abs_path,
            "stage_output_path": stage_output_rel_path,
            "stage_output_abs_path": stage_output_abs_path,
            "target_envs": [str(item).strip() for item in deployment_targets if str(item).strip()],
            "test_cases": [str(item).strip() for item in test_cases if str(item).strip()],
            "regression_result": str(meta.get("regression_result") or "pending").strip(),
            "regression_summary": str(meta.get("regression_summary") or full_context["evidence"].get("last_error_log") or "").strip(),
            "deploy_result": deploy_result,
        }
        artifacts = {"regression_report": regression_report}
    elif stage == "FIXING":
        tech_spec = _artifact_entry(repo_root, full_context["artifacts"]["tech_spec"]["path"], include_content=True)
        workspace_files = _workspace_listing(repo_root)
        prompt_inputs = {
            "error_log": full_context["evidence"]["last_error_log"] or "",
            "workspace_files": workspace_files,
            "auth_block_abs_path": auth_block_abs_path,
        }
        artifacts = {"tech_spec": tech_spec}
    else:
        artifacts = full_context["artifacts"]

    return {
        "schema_version": 1,
        "stage": stage,
        "run": full_context["run"],
        "request": full_context["request"],
        "non_compliance": {
            "last": non_compliance,
            "retry_count": stage_retry_count,
            "max_stage_retries": max_stage_retries,
        },
        "objective": _stage_objective(stage),
        "acceptance_criteria": _acceptance_criteria(stage),
        "constraints": {
            "global": full_context["constraints"]["global"],
            "stage": _stage_constraints(stage),
        },
        "artifacts": artifacts,
        "capabilities": {
            "markdown": capabilities_md,
            "payload": capabilities_payload,
            "tool_catalog_markdown": tool_catalog_md,
            "tool_catalog_payload": tool_catalog_payload,
        },
        "user_context_policy": {
            "supported": user_context_policy_supported,
            "rules": user_context_policy_rules,
            "output_requirements": user_output_requirements,
            "tool_instructions": user_tool_instructions,
        },
        "evidence": full_context["evidence"],
        "memory": full_context["memory"],
        "metadata": full_context.get("metadata", {}),
        "prompt_inputs": prompt_inputs,
        "constitutional": {
            "agents_md": agents_md,
        },
    }


def _render_bullet_block(title: str, items: list[str]) -> str:
    normalized = [str(item or "").strip() for item in items if str(item or "").strip()]
    if not normalized:
        return ""
    return "\n".join([title, *[f"- {item}" for item in normalized]]).strip()


def _join_prompt_sections(*sections: str) -> str:
    return "\n\n".join(section.strip() for section in sections if str(section or "").strip()).strip()


def _render_file_write_guard(stage: str) -> str:
    """Common guardrails to prevent stage gating failures around file writes.

    This is intentionally repeated in prompts because tool gating is strict:
    - Direct CLI like `mkdir` maps to tool_id `cli:mkdir` and can be denied.
    - fs.writeTextFile requires an absolute path but auto-creates parent dirs.
    """
    stage = str(stage or "").strip()
    if stage not in {"PRD_DRAFTING", "TECH_SPEC_DRAFTING", "CODING", "QUALITY_LOOP", "DEPLOYING", "REGRESSION_TESTING", "FIXING", "VERIFYING"}:
        return ""
    return _join_prompt_sections(
        "【文件写入与目录创建（重要）】",
        "- 写文件时优先使用 fs.writeTextFile；Harness 会自动创建父目录，无需单独创建目录。",
        "- fs.writeTextFile 的 path 必须使用绝对路径。",
        "- 不要直接执行 `mkdir`、`cp`、`mv` 等 CLI，也不要为了写文件切换到 shell。",
        "- 目标产物请直接一次性写入指定绝对路径；如果写入失败，报告失败原因，不要自行改用其他命令。",
    )


def _build_retry_injection_summary(stage: str, non_compliance: dict[str, Any] | None, retry_count: int) -> dict[str, Any] | None:
    if not isinstance(non_compliance, dict):
        return None
    if str(non_compliance.get("stage") or "").strip() != str(stage or "").strip():
        return None

    details = non_compliance.get("details") if isinstance(non_compliance.get("details"), dict) else {}
    acceptance = details.get("acceptance_result") if isinstance(details.get("acceptance_result"), dict) else {}
    kind = str(non_compliance.get("kind") or "").strip()

    injected_fields: list[str] = []
    if acceptance:
        if str(acceptance.get("summary") or "").strip():
            injected_fields.append("summary")
        missing_items = [str(item).strip() for item in (acceptance.get("missing_items") or []) if str(item).strip()]
        if missing_items:
            injected_fields.append("missing_items")
        findings = [str(item).strip() for item in (acceptance.get("findings") or []) if str(item).strip()]
        if findings:
            injected_fields.append("findings")
        if str(acceptance.get("suggested_fix") or "").strip():
            injected_fields.append("suggested_fix")
    if kind == "stage_output_validation":
        if str(non_compliance.get("reason") or "").strip():
            injected_fields.append("non_compliance_reason")
        if str(details.get("error_code") or "").strip():
            injected_fields.append("error_code")
        if str(details.get("error_message") or "").strip():
            injected_fields.append("error_message")
        if str(details.get("error") or "").strip():
            injected_fields.append("error")
        if str(details.get("artifact_type") or "").strip():
            injected_fields.append("artifact_type")
        error_details = details.get("error_details") if isinstance(details.get("error_details"), dict) else {}
        if error_details:
            injected_fields.append("error_details")
    if not injected_fields:
        return None

    return {
        "source": "last_noncompliance",
        "record_stage": str(non_compliance.get("stage") or "").strip(),
        "record_timestamp": str(non_compliance.get("ts") or "").strip(),
        "retry_count": int(retry_count or 0),
        "injected_fields": injected_fields,
        "record_snapshot": json.loads(json.dumps(non_compliance, ensure_ascii=False)),
    }


def _stage_output_required_fields(stage: str, artifact_type: str) -> list[str]:
    fields = [
        f"`schema_version` must be integer `{SCHEMA_VERSION}`.",
        f"`stage` must equal `{stage}`.",
        "`status` must be a non-empty string.",
        "`summary` must be a non-empty string.",
        "`artifacts` must be a non-empty array of artifact objects, not a single object.",
        "Each artifact object must contain `artifact_type`, `path`, `absolute_path`, `exists`, `is_dir`, `size_bytes`, `summary`.",
        "`key_points` must be a string array.",
        "`evidence` must be a string array.",
        "`metadata` must be an object.",
    ]
    if artifact_type:
        fields.append(f"`artifacts` must include `{artifact_type}`.")
    if stage == "CODING":
        fields.extend(
            [
                "`metadata.changed_files` must be an array.",
                "`metadata.branch_name` is required.",
                "`metadata.commit_sha` is required.",
                "`metadata.mr_url` is required.",
            ]
        )
    return fields


def _build_stage_output_example(*, stage: str, artifact_type: str, path: str, absolute_path: str) -> str:
    normalized_stage = str(stage or "").strip() or "PRD_DRAFTING"
    normalized_artifact_type = str(artifact_type or "").strip() or "prd"
    default_paths = _default_artifact_paths(repo_root=".", metadata={})
    rel_path = str(path or "").strip() or default_paths.get(normalized_artifact_type, normalized_artifact_type)
    abs_path = str(absolute_path or "").strip() or f"/abs/path/to/{rel_path.lstrip('/')}"
    metadata: dict[str, Any] = {}
    if normalized_stage == "CODING":
        metadata = {
            "changed_files": [rel_path],
            "branch_name": "<fill-if-known>",
            "commit_sha": "<fill-if-known>",
            "mr_url": "<fill-if-known>",
        }
    example = {
        "schema_version": SCHEMA_VERSION,
        "stage": normalized_stage,
        "status": "completed",
        "summary": f"{normalized_stage} stage output ready.",
        "artifacts": [
            {
                "artifact_type": normalized_artifact_type,
                "path": rel_path,
                "absolute_path": abs_path,
                "exists": True,
                "is_dir": rel_path.endswith("/src") or rel_path.endswith("/tests"),
                "size_bytes": 1,
                "summary": f"Primary artifact for {normalized_stage}.",
            }
        ],
        "key_points": [f"artifact_type={normalized_artifact_type}"],
        "evidence": [f"artifact_path={rel_path}"],
        "metadata": metadata,
    }
    return json.dumps(example, ensure_ascii=False, indent=2)


def _render_stage_output_instruction_block(*, stage: str, artifact_type: str, path: str = "", absolute_path: str = "") -> str:
    requirements = "\n".join(f"- {item}" for item in _stage_output_required_fields(stage, artifact_type))
    example = _build_stage_output_example(stage=stage, artifact_type=artifact_type, path=path, absolute_path=absolute_path)
    return _join_prompt_sections(
        "【StageOutput JSON 写法（首次生成就必须满足）】",
        requirements,
        "Minimal valid JSON example:\n```json\n" + example + "\n```",
    )


def _render_stage_output_noncompliance_block(non_compliance: dict[str, Any] | None) -> str:
    if not isinstance(non_compliance, dict):
        return ""
    details = non_compliance.get("details") if isinstance(non_compliance.get("details"), dict) else {}
    error_code = str(details.get("error_code") or "").strip()
    error_message = str(details.get("error_message") or "").strip()
    error = str(details.get("error") or "").strip()
    artifact_type = str(details.get("artifact_type") or "").strip()
    error_details = details.get("error_details") if isinstance(details.get("error_details"), dict) else {}
    stage_name = str(error_details.get("stage") or non_compliance.get("stage") or "").strip()
    declared_path = str(error_details.get("declared_path") or "").strip()
    declared_absolute_path = str(error_details.get("declared_absolute_path") or "").strip()

    sections = ["【上次 Harness 非合规事实记录（必须先满足）】"]
    reason = str(non_compliance.get("reason") or "").strip()
    if reason:
        sections.append(f"Reason: {reason}")
    if error_code:
        sections.append(f"Error code: {error_code}")
    if error_message:
        sections.append(f"Message: {error_message}")
    if error:
        sections.append(f"Validation error: {error}")
    if artifact_type:
        sections.append(f"Affected artifact_type: {artifact_type}")

    detail_lines: list[str] = []
    if declared_path:
        detail_lines.append(f"- declared_path: {declared_path}")
    if declared_absolute_path:
        detail_lines.append(f"- declared_absolute_path: {declared_absolute_path}")
    if "declared_exists" in error_details:
        detail_lines.append(f"- declared_exists: {error_details.get('declared_exists')}")
    if "declared_is_dir" in error_details:
        detail_lines.append(f"- declared_is_dir: {error_details.get('declared_is_dir')}")
    if "declared_size_bytes" in error_details:
        detail_lines.append(f"- declared_size_bytes: {error_details.get('declared_size_bytes')}")
    if str(error_details.get("missing_field") or "").strip():
        detail_lines.append(f"- missing_field: {error_details.get('missing_field')}")
    if detail_lines:
        sections.append("Observed details:\n" + "\n".join(detail_lines))

    if stage_name:
        sections.append(
            "Required StageOutput schema:\n" + "\n".join(
                f"- {item}" for item in _stage_output_required_fields(stage_name, artifact_type)
            )
        )

    mismatch_lines: list[str] = []
    field_name = str(error_details.get("field") or "").strip()
    expected_value = error_details.get("expected")
    received_value = error_details.get("received")
    if field_name:
        mismatch_lines.append(f"- field: {field_name}")
    if expected_value not in (None, ""):
        mismatch_lines.append(f"- expected: {expected_value}")
    if received_value not in (None, ""):
        mismatch_lines.append(f"- received: {received_value}")
    if error_code == "artifacts_required":
        mismatch_lines.append("- `artifacts` must be a non-empty array; if you previously wrote a single object, wrap it in `[ ... ]`.")
    if error_code == "schema_version_invalid":
        mismatch_lines.append(f"- `schema_version` must be integer `{SCHEMA_VERSION}`, not strings like `\"1.0\"`.")
    if error_code in {"key_points_invalid", "evidence_invalid"}:
        mismatch_lines.append("- `key_points` and `evidence` must each be arrays of strings.")
    if error_code == "metadata_invalid":
        mismatch_lines.append("- `metadata` must be a JSON object, not a string / array / null.")
    if error_code.startswith("coding_"):
        mismatch_lines.append("- CODING stage metadata must include `changed_files`, `branch_name`, `commit_sha`, and `mr_url`.")
    if error_code in {"artifact_not_found", "artifact_empty", "artifact_directory_empty"}:
        mismatch_lines.append("- Referenced artifact paths must already exist on disk and be non-empty before you write the StageOutput JSON.")
    if mismatch_lines:
        sections.append("Observed mismatch:\n" + "\n".join(mismatch_lines))

    if stage_name:
        sections.append(
            "Minimal valid JSON example:\n```json\n"
            + _build_stage_output_example(
                stage=stage_name,
                artifact_type=artifact_type,
                path=declared_path,
                absolute_path=declared_absolute_path,
            )
            + "\n```"
        )
    if len(sections) == 1:
        return ""
    return _join_prompt_sections(*sections)


def _render_acceptance_feedback_block(non_compliance: dict[str, Any] | None) -> str:
    if not isinstance(non_compliance, dict):
        return ""
    details = non_compliance.get("details") if isinstance(non_compliance.get("details"), dict) else {}
    acceptance = details.get("acceptance_result") if isinstance(details.get("acceptance_result"), dict) else {}
    if not acceptance:
        return ""

    summary = str(acceptance.get("summary") or "").strip()
    suggested_fix = str(acceptance.get("suggested_fix") or "").strip()
    missing_items = [str(item).strip() for item in (acceptance.get("missing_items") or []) if str(item).strip()]
    findings = [str(item).strip() for item in (acceptance.get("findings") or []) if str(item).strip()]

    sections = ["【上次 Harness 准出拒绝详情（必须逐项修复）】"]
    if summary:
        sections.append(f"Summary: {summary}")
    if missing_items:
        sections.append("Missing items:\n- " + "\n- ".join(missing_items))
    if findings:
        sections.append("Findings:\n- " + "\n- ".join(findings))
    if suggested_fix:
        sections.append(f"Suggested fix: {suggested_fix}")
    return _join_prompt_sections(*sections)


def _render_auth_block_instructions(*, stage: str, auth_block_abs_path: str, main_outputs: list[str]) -> str:
    stage = str(stage or "").strip()
    auth_block_abs_path = str(auth_block_abs_path or "").strip()
    outputs = [str(p or "").strip() for p in (main_outputs or []) if str(p or "").strip()]
    outputs_txt = "\n".join([f"   - `{p}`" for p in outputs]) if outputs else "   - (本阶段产物)"
    if not auth_block_abs_path:
        return ""
    return f"""
【授权阻塞信号（最高优先级，满足条件即唯一产物，写完立刻退出）】
当你调用 MCP/CLI 读取外部服务时，若遇到“未授权/无权限/需要授权链接/401/403”或工具返回中包含形如 `open-apis/authen/v1/authorize` 的授权 URL：
1) 不要继续重试，不要调用 bash/通用网页抓取绕过登录页，不要猜测内容。
2) 不要再尝试写本阶段正常产物：
{outputs_txt}
3) 本次阶段的唯一产物就是下面这个 JSON 文件（写到绝对路径）：
   `{auth_block_abs_path}`
4) JSON 必须是合法 JSON（严格双引号），字段固定如下（`auth_url` 必须是完整可点击 URL，`message` 原样粘贴工具返回的未授权提示）：
```json
{{
  "type": "auth_required",
  "stage": "{stage}",
  "tool": "lark-cli 或 mcp",
  "auth_url": "https://.../open-apis/authen/v1/authorize?...",
  "message": "原样粘贴工具返回的未授权提示（包含授权链接）",
  "cli_help": "lark-cli config init --new\\nlark-cli auth login --domain <domain>\\nlark-cli auth login --scope \\"<missing_scope>\\""
}}
```
5) 你必须通过 ACP 会话中的 `fs.writeTextFile` 写入该 JSON（注意：path 必须是绝对路径），写完即退出；Harness 会把本次 run 置为 AUTH_BLOCKED（可恢复），由 UI 弹窗引导用户授权。
""".strip()



def _render_constitutional_layer(
    stage: str,
    stage_context: dict[str, Any],
    stage_body: str,
    nc_prefix: str,
    cap_md: str,
    tool_md: str,
 ) -> str:
    constraints = stage_context.get("constraints", {}) if isinstance(stage_context.get("constraints"), dict) else {}
    constitutional = stage_context.get("constitutional", {}) if isinstance(stage_context.get("constitutional"), dict) else {}
    global_block = _render_bullet_block("全局硬性约束：", constraints.get("global") or [])
    stage_block = _render_bullet_block("阶段硬性约束：", constraints.get("stage") or [])
    agents_md = constitutional.get("agents_md")
    if agents_md is None:
        agents_block = ""
    else:
        agents_block = f"AGENTS.md 绝对路径：{str(agents_md).strip()}"

    sections = [
        "【宪法层】",
        "【重要约束：计划先行】\n在执行任何实质性操作前，请务必先调用制定计划（Plan）相关的工具（如 TodoWrite 等）生成详细的步骤计划，并在执行过程中不断更新计划的状态。",
        _render_file_write_guard(stage),
        nc_prefix,
        stage_body,
        global_block,
        stage_block,
        agents_block,
        cap_md,
        tool_md,
    ]
    return _join_prompt_sections(*sections)


def _render_regulatory_layer(stage_context: dict[str, Any]) -> str:
    user_context_policy = stage_context.get("user_context_policy", {}) if isinstance(stage_context.get("user_context_policy"), dict) else {}
    try:
        from core.stage_context_policy import render_output_requirements_block, render_tool_instructions_block

        output_block = render_output_requirements_block(user_context_policy.get("output_requirements"))
        tool_block = render_tool_instructions_block(user_context_policy.get("tool_instructions"))
    except Exception:
        output_block = ""
        tool_block = ""

    body = _join_prompt_sections(output_block, tool_block)
    if not body:
        return ""
    return _join_prompt_sections("【规范层】", body)


def _render_intention_layer(stage_context: dict[str, Any], requirement_label: str) -> str:
    request = stage_context.get("request", {})
    prompt_inputs = stage_context.get("prompt_inputs", {})
    user_context_policy = stage_context.get("user_context_policy", {}) if isinstance(stage_context.get("user_context_policy"), dict) else {}
    requirement = str(prompt_inputs.get("requirement", request.get("raw_requirement", "未提供需求")) or "").strip() or "未提供需求"

    policy_block = ""
    try:
        from core.stage_context_policy import render_stage_context_policy_block

        policy_block = render_stage_context_policy_block(user_context_policy.get("rules"))
    except Exception:
        policy_block = ""

    body = _join_prompt_sections(f"{requirement_label}：{requirement}", policy_block)
    return _join_prompt_sections("【意图层】", body)


def render_stage_prompt(stage: str, stage_context: dict[str, Any]) -> str:
    request = stage_context.get("request", {})
    artifacts = stage_context.get("artifacts", {})
    capabilities = stage_context.get("capabilities", {})
    prompt_inputs = stage_context.get("prompt_inputs", {})
    non_compliance = stage_context.get("non_compliance", {}) if isinstance(stage_context.get("non_compliance"), dict) else {}
    cap_md = capabilities.get("markdown", "")
    tool_md = capabilities.get("tool_catalog_markdown", "")

    nc_prefix = ""
    nc_last = non_compliance.get("last") if isinstance(non_compliance, dict) else None
    if isinstance(nc_last, dict):
        retry_count = non_compliance.get("retry_count", 0)
        max_retries = non_compliance.get("max_stage_retries", 0)
        gate_feedback = _extract_gate_denial_feedback(nc_last)
        allowed = gate_feedback.get("enabled_tool_ids")
        allowed_txt = ""
        if isinstance(allowed, list) and allowed:
            allowed_txt = "Allowed tools for this stage:\\n- " + "\\n- ".join(str(x) for x in allowed)
        denied_tool = gate_feedback.get("tool_id")
        denied_txt = f"Denied tool_id: {denied_tool}\\n" if denied_tool else ""
        resolved_capability = gate_feedback.get("resolved_capability")
        capability_txt = f"Resolved capability: {resolved_capability}\\n" if resolved_capability else ""
        gate_reason = gate_feedback.get("reason")
        gate_reason_txt = f"Gate denial reason: {gate_reason}\\n" if gate_reason else ""
        suggestion = str(gate_feedback.get("suggestion") or "").strip()
        suggestion_txt = f"Suggestion: {suggestion}\\n" if suggestion else ""
        deny_instruction_txt = ""
        if denied_tool or gate_reason:
            deny_instruction_txt = (
                "Do not retry unlisted direct CLI or shell commands. Use only the allowed tool_ids for this stage.\\n"
            )
        nc_prefix = (
            "【HARNESS 阶段规范反馈（必须优先处理）】\\n"
            "如果存在本节，表示上一次运行已被 Harness 准出/门禁规则拦截。你必须严格对照下面的拦截原因与事实记录修改本次输出，否则仍会被同类规则再次拦截。\\n"
            f"- stage_retry_count: {retry_count} / {max_retries}\\n"
            f"- non_compliance_reason: {nc_last.get('reason')}\\n"
            f"{gate_reason_txt}"
            f"{denied_txt}"
            f"{capability_txt}"
        )
        if allowed_txt:
            nc_prefix += allowed_txt + "\\n"
        nc_prefix = nc_prefix + deny_instruction_txt + suggestion_txt + "\\n"
        stage_output_feedback = _render_stage_output_noncompliance_block(nc_last)
        if stage_output_feedback:
            nc_prefix = _join_prompt_sections(nc_prefix, stage_output_feedback)
        acceptance_feedback = _render_acceptance_feedback_block(nc_last)
        if acceptance_feedback:
            nc_prefix = _join_prompt_sections(nc_prefix, acceptance_feedback)

    retry_injection = _build_retry_injection_summary(stage, nc_last, int(non_compliance.get("retry_count", 0) or 0))
    metadata = stage_context.get("metadata") if isinstance(stage_context.get("metadata"), dict) else None
    if isinstance(metadata, dict):
        stage_retry_context = metadata.get("stage_retry_context")
        if not isinstance(stage_retry_context, dict):
            stage_retry_context = {}
            metadata["stage_retry_context"] = stage_retry_context
        if retry_injection:
            stage_retry_context[stage] = retry_injection
        else:
            stage_retry_context.pop(stage, None)

    if stage == "PRD_DRAFTING":
        requirement = prompt_inputs.get("requirement", request.get("raw_requirement", "未提供需求"))
        requirement_marker = prompt_inputs.get("requirement_marker", "")
        output_abs_path = prompt_inputs.get("output_abs_path", artifacts.get("prd", {}).get("absolute_path", ""))
        auth_block_abs_path = prompt_inputs.get("auth_block_abs_path", "")
        stage_output_abs_path = prompt_inputs.get("stage_output_abs_path", "")
        stage_output_block = _render_stage_output_instruction_block(
            stage="PRD_DRAFTING",
            artifact_type="prd",
            path=artifacts.get("prd", {}).get("path", ""),
            absolute_path=output_abs_path,
        )
        stage_body = f"""
请作为产品经理，根据意图层中的原始需求编写标准 Markdown 格式的 PRD (Product Requirements Document)。
如果“原始需求”中包含任何 URL 链接（以 http:// 或 https:// 开头），请优先尝试使用会话中可用的 skills 或工具读取链接对应的内容，并结合“原始需求 + 读取到的内容”生成 PRD：
- 若存在链接：
  1) 阅读相关skills，根据skills的指导尝试使用 MCP、cli等工具读取文档正文。
  2) 若工具返回权限/登录受限、不可用、或读取失败（例如提示需要授权链接、403/401 等），尝试更换工具读取文档正文。
  3) 若 MCP 与 CLI 均失败，PRD 仍需产出：将该链接标记为“未成功读取”，并在 PRD 中说明失败原因与需人工补充信息。
- 不要改用通用网页抓取工具去追登录页、重定向页或返回原始 HTML；对飞书云文档链接，不要反复跟踪登录跳转，不要通过网页抓取去猜测文档内容。
- 若未读取到链接内容，不要将其当作确定事实写入 PRD；请改写为“假设/待澄清”并明确需要补充的证据来源。
- PRD 中必须增加“## 来源与引用”章节：列出每个链接，并用要点引用你用到的关键信息；同时标注每条引用信息来自 MCP 还是来自 CLI。
- 若任意链接因权限/不存在/网络等原因读取失败，PRD 仍需产出，但需在“## 风险与待澄清”中逐条写明：哪些链接未读到、失败原因、需要人工补充的信息。

{_render_auth_block_instructions(stage="PRD_DRAFTING", auth_block_abs_path=auth_block_abs_path, main_outputs=[output_abs_path, stage_output_abs_path])}

【正常路径（未遇到授权阻塞时才走这里）】
1) 你必须在文档中原样包含这一行（不要改写）：{requirement_marker}
2) 你必须通过 ACP 会话中可用的文件修改工具，将整个 PRD 写入绝对路径 `{output_abs_path}`，不要只是把内容打印在对话中。
3) 你必须额外写出本次 run 的结构化交付 JSON 到绝对路径 `{stage_output_abs_path}`，不要只在对话里描述。
4) 这份 JSON 必须使用 StageOutput 结构，并至少包含：`schema_version`, `stage`, `status`, `summary`, `artifacts`, `key_points`, `evidence`, `metadata`。
5) `artifacts` 中必须包含 `prd`，路径要与实际生成的 PRD 一致；无法确认的字段可以留空，但不要伪造。
6) {stage_output_block}
7) 若规范层配置了产出物要求或工具调用指令，严格遵守该配置；未配置则不要自行补默认章节要求。
8) 写入完成后请直接退出，不需要其他解释。
""".strip()
        return _join_prompt_sections(
            _render_constitutional_layer(stage, stage_context, stage_body, nc_prefix, cap_md, tool_md),
            _render_regulatory_layer(stage_context),
            _render_intention_layer(stage_context, "用户原始需求"),
        )

    if stage == "TECH_SPEC_DRAFTING":
        requirement = prompt_inputs.get("requirement", "未提供原始需求")
        requirement_marker = prompt_inputs.get("requirement_marker", "")
        prd_content = artifacts.get("prd", {}).get("content", "")
        output_abs_path = prompt_inputs.get("output_abs_path", artifacts.get("tech_spec", {}).get("absolute_path", ""))
        auth_block_abs_path = prompt_inputs.get("auth_block_abs_path", "")
        stage_output_abs_path = prompt_inputs.get("stage_output_abs_path", "")
        stage_output_block = _render_stage_output_instruction_block(
            stage="TECH_SPEC_DRAFTING",
            artifact_type="tech_spec",
            path=artifacts.get("tech_spec", {}).get("path", ""),
            absolute_path=output_abs_path,
        )
        stage_body = f"""
{_INPUT_PRIORITY_CONTRACT}
请作为资深架构师，根据意图层中的原始需求和以下 PRD，编写标准 Markdown 格式的 Tech Spec (技术方案设计文档)。
--- PRD 内容开始 ---
{prd_content}
--- PRD 内容结束 ---

{_render_auth_block_instructions(stage="TECH_SPEC_DRAFTING", auth_block_abs_path=auth_block_abs_path, main_outputs=[output_abs_path, stage_output_abs_path])}

你的任务：
1. 请生成完整的技术方案，包含架构设计、模块划分、数据结构等。
2. 【重要】你必须在文档的末尾，包含一个名为 "## 变更清单 (Manifest)" 的章节。在这个章节中，使用 Markdown 无序列表列出你计划在下一步（编码阶段）创建或修改的所有文件的路径。

Manifest 格式示例：
## 变更清单 (Manifest)
- `services/billing/calculator.py`
- `tests/test_calculator.py`

3. 【重要】你必须在文档中原样包含这一行（不要改写）：{requirement_marker}
4. 你必须通过 ACP 会话中可用的文件修改工具，将你生成的整个文档（包括 Manifest）写入到绝对路径 `{output_abs_path}` 文件中。这是必须的步骤，千万不要只是把内容打印在对话中。
5. 你必须额外写出本次 run 的结构化交付 JSON 到绝对路径 `{stage_output_abs_path}`，不要只在对话里描述。
6. 这份 JSON 必须使用 StageOutput 结构，并至少包含：`schema_version`, `stage`, `status`, `summary`, `artifacts`, `key_points`, `evidence`, `metadata`。
7. `artifacts` 中必须包含 `tech_spec`，路径要与实际生成的技术方案文档一致；无法确认的字段可以留空，但不要伪造。
8. {stage_output_block}
9. 若规范层配置了产出物要求或工具调用指令，严格遵守该配置；未配置则不要自行补默认规范。
10. 写入完成后，请直接退出，不需要其他解释。
注意：在这个阶段，你绝对不允许修改任何源代码文件，只能生成设计文档。
""".strip()
        return _join_prompt_sections(
            _render_constitutional_layer(stage, stage_context, stage_body, nc_prefix, cap_md, tool_md),
            _render_regulatory_layer(stage_context),
            _render_intention_layer(stage_context, "用户原始需求"),
        )

    if stage == "CODING":
        requirement = prompt_inputs.get("requirement", request.get("raw_requirement", "未提供原始需求"))
        tech_spec_content = artifacts.get("tech_spec", {}).get("content", "")
        src_dir = prompt_inputs.get("src_dir", "")
        tests_dir = prompt_inputs.get("tests_dir", "")
        auth_block_abs_path = prompt_inputs.get("auth_block_abs_path", "")
        stage_output_abs_path = prompt_inputs.get("stage_output_abs_path", "")
        code_stage_output_block = _render_stage_output_instruction_block(
            stage="CODING",
            artifact_type="code_root",
            path=src_dir,
            absolute_path=os.path.abspath(src_dir) if src_dir else "",
        )
        tests_stage_output_block = _render_stage_output_instruction_block(
            stage="CODING",
            artifact_type="tests_root",
            path=tests_dir,
            absolute_path=os.path.abspath(tests_dir) if tests_dir else "",
        )
        stage_body = f"""
{_INPUT_PRIORITY_CONTRACT}
请作为资深工程师，根据意图层中的原始需求与以下技术方案，在当前目标仓库中实现可运行的代码与可消费的测试产物。
--- Tech Spec 内容开始 ---
{tech_spec_content}
--- Tech Spec 内容结束 ---

{_render_auth_block_instructions(stage="CODING", auth_block_abs_path=auth_block_abs_path, main_outputs=[src_dir, tests_dir, stage_output_abs_path])}

约束：
1. 你只能创建/修改当前目标仓库中的业务文件，不允许写出仓库边界。
2. 你必须至少生成：
   - 代码：在 `{src_dir}` 或其他合理业务目录下至少 1 个源文件
   - 单测：在 `{tests_dir}` 或其他合理测试目录下至少 1 个测试文件
3. 你必须额外写出本次 run 的结构化交付 JSON 到绝对路径 `{stage_output_abs_path}`，不要只在对话里描述。
4. 这份 JSON 必须使用 StageOutput 结构，并至少包含：
   - `schema_version`, `stage`, `status`, `summary`, `artifacts`, `key_points`, `evidence`, `metadata`
   - `metadata.changed_files`（数组）
   - `metadata.branch_name`
   - `metadata.commit_sha`
   - `metadata.mr_url`
5. `artifacts` 中必须覆盖本次交付的 `code_root` 与 `tests_root`，路径要和实际产物一致。
6. 无法确认的字段可以写空字符串或空数组，但不要伪造；同时在 `evidence` 或 `metadata` 中说明原因。
7. {code_stage_output_block}
8. {tests_stage_output_block}
9. 对于大型 Go 仓库，不要主动执行 gofmt、go test、go build 等高耗时命令作为默认步骤，除非用户明确要求或当前任务非跑不可。
10. 产出的代码、测试产物和 stage output JSON 必须足以支撑后续 QUALITY_LOOP 的结构校验与交付准出。
11. 若规范层配置了产出物要求或工具调用指令，严格遵守该配置。
12. 完成后请直接退出，不需要额外解释。
""".strip()
        return _join_prompt_sections(
            _render_constitutional_layer(stage, stage_context, stage_body, nc_prefix, cap_md, tool_md),
            _render_regulatory_layer(stage_context),
            _render_intention_layer(stage_context, "用户原始需求"),
        )

    if stage == "QUALITY_LOOP":
        tech_spec_content = artifacts.get("tech_spec", {}).get("content", "")
        quality_report_content = artifacts.get("quality_report", {}).get("content", "")
        error_log = prompt_inputs.get("error_log", "")
        workspace_files = prompt_inputs.get("workspace_files", [])
        workspace_listing = "\n".join(f"- {path}" for path in workspace_files) if workspace_files else "- (no files found)"
        auth_block_abs_path = prompt_inputs.get("auth_block_abs_path", "")
        stage_output_abs_path = prompt_inputs.get("stage_output_abs_path", "")
        phase = str(prompt_inputs.get("quality_loop_phase", "verify") or "verify").strip().lower()
        validated_stage = str(prompt_inputs.get("validated_stage") or "CODING").strip()
        validated_stage_result = prompt_inputs.get("validated_stage_result") if isinstance(prompt_inputs.get("validated_stage_result"), dict) else {}
        validated_stage_artifacts = prompt_inputs.get("validated_stage_artifacts") if isinstance(prompt_inputs.get("validated_stage_artifacts"), list) else []
        validated_stage_result_text = json.dumps(validated_stage_result, ensure_ascii=False, indent=2) if validated_stage_result else "{}"
        validated_stage_artifacts_text = json.dumps(validated_stage_artifacts, ensure_ascii=False, indent=2) if validated_stage_artifacts else "[]"
        if phase == "fix":
            stage_body = f"""
{_INPUT_PRIORITY_CONTRACT}
请作为资深工程师，在统一质量闭环的 fix 子阶段中修复当前目标仓库内代码或交付产物的校验失败问题。
以下是当前技术方案：
--- Tech Spec 开始 ---
{tech_spec_content}
--- Tech Spec 结束 ---

待校验的上一阶段：{validated_stage}
--- Validated Stage Output 开始 ---
{validated_stage_result_text}
--- Validated Stage Output 结束 ---

{_render_auth_block_instructions(stage="QUALITY_LOOP", auth_block_abs_path=auth_block_abs_path, main_outputs=["目标仓库内的修复目标", stage_output_abs_path])}

以下是本轮质量校验失败日志：
--- Error Log 开始 ---
{error_log}
--- Error Log 结束 ---

当前质量报告：
--- Quality Report 开始 ---
{quality_report_content}
--- Quality Report 结束 ---

当前目标仓库中已有文件：
{workspace_listing}

约束：
1. 你只能修改当前目标仓库内的文件。
2. 请优先做最小修复，不要无关重写。
3. 如有必要，可以修复业务目录、测试目录，或补齐缺失产物。
4. 对于大型 Go 仓库，不要主动执行 gofmt、go test、go build 等高耗时命令作为默认步骤，除非用户明确要求或当前任务非跑不可。
5. 你必须额外写出本次 run 的结构化交付 JSON 到绝对路径 `{stage_output_abs_path}`，不要只在对话里描述。
6. 这份 JSON 必须使用 StageOutput 结构，并至少包含：`schema_version`, `stage`, `status`, `summary`, `artifacts`, `key_points`, `evidence`, `metadata`。
7. `artifacts` 中必须包含 `quality_report`，并在 `metadata` 中至少写出 `validated_stage` 与 `hard_validation_verdict`；可以补充本轮 findings、history 摘要，但不要伪造未验证的事实。
8. 若规范层配置了产出物要求或工具调用指令，严格遵守该配置。
9. 完成修复后请直接退出，不需要额外解释。
""".strip()
        else:
            stage_body = f"""
{_INPUT_PRIORITY_CONTRACT}
请作为质量闭环验证器，对上一阶段交付做本地结构校验并沉淀质量报告，而不是运行语言特定测试脚本。
不要修改业务代码；该子阶段的职责是检查上一阶段是否形成了有效产物，并为后续 fix/准出提供结构化证据。
对于大型 Go 仓库，不要主动执行 gofmt、go test、go build 等高耗时命令作为默认步骤，除非用户明确要求或当前任务非跑不可。

待校验的上一阶段：{validated_stage}
--- Validated Stage Output 开始 ---
{validated_stage_result_text}
--- Validated Stage Output 结束 ---

上一阶段产物清单：
{validated_stage_artifacts_text}

当前目标仓库中已有文件：
{workspace_listing}

你必须额外写出本次 run 的结构化交付 JSON 到绝对路径 `{stage_output_abs_path}`，不要只在对话里描述。
这份 JSON 必须使用 StageOutput 结构，并至少包含：`schema_version`, `stage`, `status`, `summary`, `artifacts`, `key_points`, `evidence`, `metadata`。
`artifacts` 中必须包含 `quality_report`，并在 `metadata` 中至少写出 `validated_stage` 与 `hard_validation_verdict`；可以补充本轮 findings、history 摘要，但不要伪造未验证的事实。
""".strip()
        return _join_prompt_sections(
            _render_constitutional_layer(stage, stage_context, stage_body, nc_prefix, cap_md, tool_md),
            _render_regulatory_layer(stage_context),
            _render_intention_layer(stage_context, "用户原始需求"),
        )

    if stage == "FIXING":
        tech_spec_content = artifacts.get("tech_spec", {}).get("content", "")
        error_log = prompt_inputs.get("error_log", "")
        workspace_files = prompt_inputs.get("workspace_files", [])
        workspace_listing = "\n".join(f"- {path}" for path in workspace_files) if workspace_files else "- (no files found)"
        auth_block_abs_path = prompt_inputs.get("auth_block_abs_path", "")
        stage_body = f"""
{_INPUT_PRIORITY_CONTRACT}
请作为资深工程师，修复当前目标仓库内代码或交付产物的校验失败问题。
以下是当前技术方案：
--- Tech Spec 开始 ---
{tech_spec_content}
--- Tech Spec 结束 ---

{_render_auth_block_instructions(stage="FIXING", auth_block_abs_path=auth_block_abs_path, main_outputs=["目标仓库内的修复目标"])}

以下是本轮交付校验失败日志：
--- Error Log 开始 ---
{error_log}
--- Error Log 结束 ---

当前目标仓库中已有文件：
{workspace_listing}

约束：
1. 你只能修改当前目标仓库内的文件。
2. 请优先做最小修复，不要无关重写。
3. 如有必要，可以修复业务目录、测试目录，或补齐缺失交付产物。
4. 若规范层配置了产出物要求或工具调用指令，严格遵守该配置。
5. 完成修复后请直接退出，不需要额外解释。
""".strip()
        return _join_prompt_sections(
            _render_constitutional_layer(stage, stage_context, stage_body, nc_prefix, cap_md, tool_md),
            _render_regulatory_layer(stage_context),
            _render_intention_layer(stage_context, "用户原始需求"),
        )

    if stage == "DEPLOYING":
        deploy_report = artifacts.get("deploy_report", {}) if isinstance(artifacts.get("deploy_report"), dict) else {}
        auth_block_abs_path = prompt_inputs.get("auth_block_abs_path", "")
        stage_output_abs_path = prompt_inputs.get("stage_output_abs_path", "")
        target_envs = prompt_inputs.get("target_envs", [])
        target_envs_text = "、".join(str(item) for item in target_envs) if isinstance(target_envs, list) and target_envs else "BOE、PPE"
        deployment_status = prompt_inputs.get("deployment_status", "pending")
        deployment_summary = prompt_inputs.get("deployment_summary", "")
        deploy_report_content = deploy_report.get("content", "")
        deploy_stage_output_block = _render_stage_output_instruction_block(
            stage="DEPLOYING",
            artifact_type="deploy_report",
            path=deploy_report.get("path", ""),
            absolute_path=deploy_report.get("absolute_path", ""),
        )
        stage_body = f"""
{_INPUT_PRIORITY_CONTRACT}
请作为部署执行代理，围绕已完成开发与质量闭环的产物，推进部署到目标环境，并沉淀部署结果。

目标环境：{target_envs_text}
当前部署状态：{deployment_status}
部署摘要：{deployment_summary or '暂无摘要'}
--- Deploy Report 开始 ---
{deploy_report_content}
--- Deploy Report 结束 ---

{_render_auth_block_instructions(stage="DEPLOYING", auth_block_abs_path=auth_block_abs_path, main_outputs=[deploy_report.get("absolute_path", ""), stage_output_abs_path])}

【正常路径（未遇到授权阻塞时才走这里）】
1. 你必须把部署报告写入绝对路径 `{deploy_report.get('absolute_path', '')}`，不要只在对话中描述。
2. 你必须额外写出本次 run 的结构化交付 JSON 到绝对路径 `{stage_output_abs_path}`，不要只在对话里描述。
3. deploy_report 至少要包含：`env_name`, `env_url`, `branch_name`, `psm`, `status`, `summary`；若失败或阻塞，必须写清失败/阻塞原因。
4. stage output JSON 必须使用 StageOutput 结构，且 `artifacts` 中必须包含 `deploy_report`。
5. {deploy_stage_output_block}
6. 若需要调用外部部署系统或环境接口，优先复用当前 stage 已授权能力。
7. 若规范层配置了产出物要求或工具调用指令，严格遵守该配置。
8. 完成后请直接退出，不需要额外解释。
""".strip()
        return _join_prompt_sections(
            _render_constitutional_layer(stage, stage_context, stage_body, nc_prefix, cap_md, tool_md),
            _render_regulatory_layer(stage_context),
            _render_intention_layer(stage_context, "用户原始需求"),
        )

    if stage == "REGRESSION_TESTING":
        regression_report = artifacts.get("regression_report", {}) if isinstance(artifacts.get("regression_report"), dict) else {}
        auth_block_abs_path = prompt_inputs.get("auth_block_abs_path", "")
        stage_output_abs_path = prompt_inputs.get("stage_output_abs_path", "")
        target_envs = prompt_inputs.get("target_envs", [])
        target_envs_text = "、".join(str(item) for item in target_envs) if isinstance(target_envs, list) and target_envs else "BOE、PPE"
        test_cases = prompt_inputs.get("test_cases", [])
        test_case_lines = "\n".join(f"- {item}" for item in test_cases) if isinstance(test_cases, list) and test_cases else "- (暂无显式测试用例，需结合当前需求与部署结果执行回归)"
        regression_result = prompt_inputs.get("regression_result", "pending")
        regression_summary = prompt_inputs.get("regression_summary", "")
        regression_report_content = regression_report.get("content", "")
        regression_stage_output_block = _render_stage_output_instruction_block(
            stage="REGRESSION_TESTING",
            artifact_type="regression_report",
            path=regression_report.get("path", ""),
            absolute_path=regression_report.get("absolute_path", ""),
        )
        stage_body = f"""
{_INPUT_PRIORITY_CONTRACT}
请作为回归测试代理，针对已部署环境执行接口级自测与回归，并沉淀结果。

目标环境：{target_envs_text}
当前回归状态：{regression_result}
回归摘要：{regression_summary or '暂无摘要'}
测试用例：
{test_case_lines}
--- Regression Report 开始 ---
{regression_report_content}
--- Regression Report 结束 ---

{_render_auth_block_instructions(stage="REGRESSION_TESTING", auth_block_abs_path=auth_block_abs_path, main_outputs=[regression_report.get("absolute_path", ""), stage_output_abs_path])}

【正常路径（未遇到授权阻塞时才走这里）】
1. 你必须把回归报告写入绝对路径 `{regression_report.get('absolute_path', '')}`，不要只在对话中描述。
2. 你必须额外写出本次 run 的结构化交付 JSON 到绝对路径 `{stage_output_abs_path}`，不要只在对话里描述。
3. regression_report 至少要包含：`env_name`, `env_url`, `test_cases`, `results` 或 `endpoint_results`, `final_verdict`, `summary`；若失败，必须写清失败项。
4. stage output JSON 必须使用 StageOutput 结构，且 `artifacts` 中必须包含 `regression_report`。
5. {regression_stage_output_block}
6. 回归必须面向已部署环境，不要退回本地单测语义。
7. 若规范层配置了产出物要求或工具调用指令，严格遵守该配置。
8. 完成后请直接退出，不需要额外解释。
""".strip()
        return _join_prompt_sections(
            _render_constitutional_layer(stage, stage_context, stage_body, nc_prefix, cap_md, tool_md),
            _render_regulatory_layer(stage_context),
            _render_intention_layer(stage_context, "用户原始需求"),
        )

    return (
        f"# Stage Context View: {stage}\n\n"
        f"- Objective: {stage_context.get('objective', '')}\n"
        f"- Requirement: {request.get('raw_requirement', '')}\n"
    )
