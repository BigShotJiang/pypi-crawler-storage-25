from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from typing import Any, Iterable


SCHEMA_VERSION = 1
BASH_TOOL_ID = "bash:shell"


def _atomic_write_json(path: str, payload: dict[str, Any]) -> None:
    target = os.path.abspath(path)
    os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
    dir_name = os.path.dirname(target) or "."
    fd, tmp_path = tempfile.mkstemp(prefix=".stage_tools.", suffix=".tmp", dir=dir_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_path, target)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass


def _read_json(path: str) -> dict[str, Any] | None:
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _ensure_harness_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def repo_config_path(repo_root: str) -> str:
    return os.path.join(repo_root, ".harness", "stage_tools.json")


def user_config_path() -> str:
    return os.path.join(os.path.expanduser("~"), ".harness", "stage_tools.json")


def _normalize_stage_map(raw: Any) -> dict[str, list[str]]:
    if not isinstance(raw, dict):
        return {}
    out: dict[str, list[str]] = {}
    for k, v in raw.items():
        stage = str(k).strip()
        if not stage:
            continue
        if isinstance(v, list):
            items = [str(x).strip() for x in v if str(x).strip()]
        else:
            items = []
        out[stage] = sorted(set(items))
    return out


@dataclass(frozen=True)
class StageToolConfig:
    schema_version: int
    stages: dict[str, list[str]]  # stage -> enabled tool_ids (e.g., "cli:bytedcli")
    sources: dict[str, str]       # "repo"/"user" -> file path


def load_stage_tool_config(repo_root: str) -> StageToolConfig:
    """Load merged stage tool config (user overrides repo)."""
    repo_path = repo_config_path(repo_root)
    user_path = user_config_path()
    repo_data = _read_json(repo_path) or {}
    user_data = _read_json(user_path) or {}

    repo_stages = _normalize_stage_map(repo_data.get("stages"))
    user_stages = _normalize_stage_map(user_data.get("stages"))

    merged: dict[str, list[str]] = dict(repo_stages)
    for stage, items in user_stages.items():
        merged[stage] = sorted(set(items))

    return StageToolConfig(
        schema_version=int(user_data.get("schema_version") or repo_data.get("schema_version") or SCHEMA_VERSION),
        stages=merged,
        sources={"repo": repo_path, "user": user_path},
    )


def save_stage_tool_config(repo_root: str, stages: dict[str, list[str]], *, scope: str = "user") -> str:
    """Persist stage tool config. scope in {"user","repo"}."""
    scope = str(scope or "user").strip().lower()
    if scope not in {"user", "repo"}:
        scope = "user"
    if scope == "repo":
        path = repo_config_path(repo_root)
        _ensure_harness_dir(os.path.dirname(path))
    else:
        path = user_config_path()
        _ensure_harness_dir(os.path.dirname(path))
    payload = {"schema_version": SCHEMA_VERSION, "stages": _normalize_stage_map(stages)}
    _atomic_write_json(path, payload)
    return path


def enabled_tool_ids_for_stage(config: StageToolConfig, stage: str | None) -> set[str] | None:
    """Return enabled tool ids for stage, or None if no configuration exists."""
    if not stage:
        return None
    # If config file(s) are absent, treat as "no config" (do not enforce).
    repo_exists = os.path.exists(config.sources.get("repo", ""))
    user_exists = os.path.exists(config.sources.get("user", ""))
    if not repo_exists and not user_exists:
        return None
    items = config.stages.get(str(stage)) or []
    return set(str(x) for x in items if str(x).strip())


# --- Default seed helpers (single source of truth: user's stage_tools.json) ---

# Pipeline stages that are expected to drive ACP agents and therefore need a
# seeded allowlist. Keep this aligned with core.orchestrator.FlowState values
# that have real agent handlers.
_SEEDABLE_STAGES: tuple[str, ...] = (
    "PRD_DRAFTING",
    "TECH_SPEC_DRAFTING",
    "CODING",
    "QUALITY_LOOP",
    "DEPLOYING",
    "REGRESSION_TESTING",
    "FIXING",
)


def default_enabled_tool_ids_for_stage(repo_root: str, stage: str) -> list[str]:
    """Compute default tool ids for a stage from repo-declared catalog.

    This is used as the "first-run seed" when the user has no personal
    `~/.harness/stage_tools.json` yet, and as the payload of "restore defaults".
    Repo-declared tools are discoverable across stages; `stage_tools.json` is the
    only stage-level allowlist.
    """
    from core.tool_catalog import build_tool_catalog_payload

    payload = build_tool_catalog_payload(stage=None, workspace_root=repo_root)
    seeds: set[str] = set()
    for entry in payload.get("entries", []):
        if not isinstance(entry, dict):
            continue
        tool_id = str(entry.get("tool_id") or "").strip()
        if not tool_id:
            continue
        source = str(entry.get("source") or "").strip()
        if source != "repo":
            continue
        seeds.add(tool_id)
    return sorted(seeds)


def default_stage_tool_config(repo_root: str, stages: Iterable[str] | None = None) -> dict[str, list[str]]:
    """Build the default stages->tool_ids map from the repo catalog."""
    target_stages = list(stages) if stages else list(_SEEDABLE_STAGES)
    return {stage: default_enabled_tool_ids_for_stage(repo_root, stage) for stage in target_stages}


def ensure_user_stage_tool_config_seeded(repo_root: str) -> tuple[str, bool]:
    """Seed `~/.harness/stage_tools.json` with repo defaults on first run.

    Returns (user_config_path, seeded). `seeded=True` iff this call actually
    wrote the file (i.e., it did not exist before). Existing user config is
    preserved untouched.
    """
    path = user_config_path()
    if os.path.exists(path):
        return path, False
    defaults = default_stage_tool_config(repo_root)
    saved = save_stage_tool_config(repo_root, defaults, scope="user")
    return saved, True


def reset_user_stage_tool_config_to_defaults(repo_root: str) -> str:
    """Overwrite `~/.harness/stage_tools.json` with repo defaults."""
    defaults = default_stage_tool_config(repo_root)
    return save_stage_tool_config(repo_root, defaults, scope="user")


def tool_id_for_entry(entry_type: str, name: str) -> str:
    t = str(entry_type or "").strip().lower()
    n = str(name or "").strip()
    if not t or not n:
        return ""
    return f"{t}:{n}"


def infer_tool_id_from_policy_context(
    *,
    normalized_kind: str,
    resolved_capability: str | None,
    policy_context: dict[str, Any] | None,
    title: str | None = None,
) -> str | None:
    """Best-effort mapping from a tool request to a stable tool_id.

    Note: this does NOT create per-binary capability families. It only creates identifiers
    for user-config allowlists (e.g., "cli:bytedcli", "skill:lark-doc").
    """
    ctx = policy_context if isinstance(policy_context, dict) else {}
    kind = str(normalized_kind or "")
    cap = str(resolved_capability or "")

    if kind == "execute":
        binary = str(ctx.get("binary") or "").strip()
        if cap == "terminal.cli":
            return tool_id_for_entry("cli", binary) if binary else None
        if cap == "tool.py_script":
            python_entry = str(ctx.get("python_entry") or "").strip()
            if python_entry:
                return tool_id_for_entry("script", python_entry)
            args = ctx.get("args")
            if isinstance(args, list) and args:
                return tool_id_for_entry("script", str(args[0]))
            return tool_id_for_entry("script", "tools")
        if cap == "terminal.bash":
            return BASH_TOOL_ID
        return None

    if kind == "skill":
        skill_name = str(ctx.get("skill_name") or ctx.get("name") or title or "").strip()
        if skill_name.lower() == "skill":
            return None
        return tool_id_for_entry("skill", skill_name) if skill_name else None

    if kind == "mcp":
        mcp_name = str(ctx.get("mcp_name") or ctx.get("name") or title or "").strip()
        if mcp_name.lower() == "mcp":
            return None
        return tool_id_for_entry("mcp", mcp_name) if mcp_name else None

    return None

