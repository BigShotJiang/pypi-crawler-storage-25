from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any

from core.run_trace import append_event
from core.stage_acceptance_policy import (
    _empty_entry,
    get_stage_acceptance_entry,
    load_stage_acceptance_policy,
    render_acceptance_rules_block,
)
from core.stage_output import (
    StageOutput,
    StageOutputValidationError,
    build_stage_output,
    build_stage_output_artifact,
    normalize_stage_output_payload,
    primary_artifact_type_for_stage,
    stage_output_absolute_path,
    validate_stage_output,
)


_ACCEPTANCE_STAGE_TO_ARTIFACT = {
    "PRD_DRAFTING": "prd",
    "TECH_SPEC_DRAFTING": "tech_spec",
    "CODING": "code_root",
    "QUALITY_LOOP": "quality_report",
    "DEPLOYING": "deploy_report",
    "REGRESSION_TESTING": "regression_report",
}

_ACCEPTANCE_STAGE_PASS_NEXT = {
    "PRD_DRAFTING": "TECH_SPEC_DRAFTING",
    "TECH_SPEC_DRAFTING": "CODING",
    "CODING": "QUALITY_LOOP",
    "QUALITY_LOOP": "DEPLOYING",
    "DEPLOYING": "REGRESSION_TESTING",
    "REGRESSION_TESTING": "FINISHED",
}


class AcceptanceValidationError(ValueError):
    pass


@dataclass(frozen=True)
class AcceptanceVerdict:
    stage: str
    artifact_type: str
    verdict: str
    summary: str
    missing_items: list[str]
    findings: list[str]
    suggested_fix: str
    raw: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "stage": self.stage,
            "artifact_type": self.artifact_type,
            "verdict": self.verdict,
            "summary": self.summary,
            "missing_items": list(self.missing_items),
            "findings": list(self.findings),
            "suggested_fix": self.suggested_fix,
            "raw": self.raw,
        }


def _stage_output_from_metadata(metadata: dict[str, Any] | None, stage: str) -> dict[str, Any] | None:
    meta = metadata if isinstance(metadata, dict) else {}
    stage_results = meta.get("stage_results")
    if not isinstance(stage_results, dict):
        return None
    result = stage_results.get(str(stage or "").strip())
    return dict(result) if isinstance(result, dict) else None


def _stage_output_from_run(stage_ctx: dict[str, Any] | None, stage: str) -> dict[str, Any] | None:
    ctx = stage_ctx if isinstance(stage_ctx, dict) else {}
    run = ctx.get("run") if isinstance(ctx.get("run"), dict) else {}
    run_dir = str(run.get("run_dir") or "").strip()
    if not run_dir:
        return None
    try:
        path = stage_output_absolute_path(run_dir, stage)
    except StageOutputValidationError:
        return None
    if not os.path.exists(path) or os.path.isdir(path):
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            payload = json.load(fh)
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def stage_output_result_from_repo(*, metadata: dict[str, Any] | None, stage: str, repo_root: str | None = None) -> dict[str, Any] | None:
    normalized_stage = str(stage or "").strip()
    if not normalized_stage:
        return None
    meta = metadata if isinstance(metadata, dict) else {}
    run_dir_rel = str(meta.get("run_dir") or "").strip()
    if run_dir_rel:
        base = str(repo_root or os.getcwd()).strip() or os.getcwd()
        try:
            path = stage_output_absolute_path(os.path.join(base, run_dir_rel), normalized_stage)
        except StageOutputValidationError:
            path = ""
        if path and os.path.exists(path) and not os.path.isdir(path):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    payload = json.load(fh)
            except Exception:
                payload = None
            if isinstance(payload, dict):
                return payload
    return _stage_output_from_metadata(meta, normalized_stage)


def stage_acceptance_artifact_type(stage: str) -> str | None:
    return _ACCEPTANCE_STAGE_TO_ARTIFACT.get(str(stage or "").strip())


def stage_acceptance_pass_next_state(stage: str) -> str | None:
    return _ACCEPTANCE_STAGE_PASS_NEXT.get(str(stage or "").strip())


def acceptance_result_from_metadata(metadata: dict[str, Any] | None, stage: str) -> dict[str, Any] | None:
    meta = metadata if isinstance(metadata, dict) else {}
    acceptance = meta.get("acceptance_results")
    if not isinstance(acceptance, dict):
        return None
    result = acceptance.get(str(stage or "").strip())
    return dict(result) if isinstance(result, dict) else None


def record_acceptance_result(metadata: dict[str, Any] | None, stage: str, result: dict[str, Any]) -> dict[str, Any]:
    meta = metadata if isinstance(metadata, dict) else {}
    acceptance = meta.get("acceptance_results")
    if not isinstance(acceptance, dict):
        acceptance = {}
        meta["acceptance_results"] = acceptance
    acceptance[str(stage or "").strip()] = dict(result)
    meta["last_acceptance_result"] = dict(result)
    return meta


def clear_acceptance_result(metadata: dict[str, Any] | None, stage: str) -> dict[str, Any]:
    meta = metadata if isinstance(metadata, dict) else {}
    acceptance = meta.get("acceptance_results")
    if isinstance(acceptance, dict):
        acceptance.pop(str(stage or "").strip(), None)
    last = meta.get("last_acceptance_result")
    if isinstance(last, dict) and str(last.get("stage") or "").strip() == str(stage or "").strip():
        meta.pop("last_acceptance_result", None)
    return meta


def _acceptance_retry_state_map(metadata: dict[str, Any] | None) -> dict[str, Any]:
    meta = metadata if isinstance(metadata, dict) else {}
    retry_state = meta.get("acceptance_retry_state")
    if not isinstance(retry_state, dict):
        retry_state = {}
        meta["acceptance_retry_state"] = retry_state
    return retry_state


def clear_acceptance_retry_state(metadata: dict[str, Any] | None, stage: str) -> dict[str, Any]:
    retry_state = _acceptance_retry_state_map(metadata)
    retry_state.pop(str(stage or "").strip(), None)
    return metadata if isinstance(metadata, dict) else {}


def update_acceptance_retry_state(
    metadata: dict[str, Any] | None,
    *,
    stage: str,
    attempt: int,
    max_retries: int,
    last_failure: dict[str, Any] | None = None,
    history_entry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    meta = metadata if isinstance(metadata, dict) else {}
    retry_state = _acceptance_retry_state_map(meta)
    normalized_stage = str(stage or "").strip()
    current = retry_state.get(normalized_stage)
    if not isinstance(current, dict):
        current = {}
    history = current.get("history") if isinstance(current.get("history"), list) else []
    if isinstance(history_entry, dict):
        history.append(dict(history_entry))
    current["attempt"] = int(attempt)
    current["max_retries"] = int(max_retries)
    current["history"] = history[-20:]
    current["last_failure"] = dict(last_failure or {})
    retry_state[normalized_stage] = current
    meta["last_acceptance_retry_stage"] = normalized_stage
    return meta


def acceptance_retry_state_from_metadata(metadata: dict[str, Any] | None, stage: str) -> dict[str, Any] | None:
    retry_state = _acceptance_retry_state_map(metadata)
    current = retry_state.get(str(stage or "").strip())
    return dict(current) if isinstance(current, dict) else None


def _normalize_prior_failure(*, reason: str, acceptance_result: dict[str, Any] | None) -> dict[str, Any]:
    payload = dict(acceptance_result or {}) if isinstance(acceptance_result, dict) else {}
    return {
        "reason": str(reason or "").strip(),
        "summary": str(payload.get("summary") or "").strip(),
        "missing_items": [str(item).strip() for item in payload.get("missing_items", []) if str(item).strip()] if isinstance(payload.get("missing_items"), list) else [],
        "findings": [str(item).strip() for item in payload.get("findings", []) if str(item).strip()] if isinstance(payload.get("findings"), list) else [],
        "suggested_fix": str(payload.get("suggested_fix") or "").strip(),
    }


def load_stage_acceptance_state(stage: str, repo_root: str | None = None) -> dict[str, Any]:
    cfg = load_stage_acceptance_policy(repo_root)
    normalized_stage = str(stage or "").strip()
    has_entry = normalized_stage in cfg.policies
    entry = get_stage_acceptance_entry(cfg, stage) if has_entry else type("AcceptanceStateEntry", (), _empty_entry(normalized_stage))()
    return {
        "supported": stage_acceptance_artifact_type(stage) is not None,
        "enabled": bool(entry.enabled),
        "prompt": entry.prompt,
        "model": entry.model,
        "rules": [dict(rule) for rule in getattr(entry, "rules", [])],
        "max_retries": int(getattr(entry, "max_retries", 2)),
        "schema_version": cfg.schema_version,
        "source": cfg.source,
    }


def _stage_output_summary_for_artifact(artifact_key: str, stage: str) -> str:
    if artifact_key == "prd":
        return "当前阶段生成的 PRD 文档。"
    if artifact_key == "tech_spec":
        return "当前阶段生成的技术方案文档。"
    if artifact_key == "code_root":
        return "当前阶段生成的代码目录入口。"
    if artifact_key == "tests_root":
        return "当前阶段生成的测试目录入口。"
    if artifact_key == "quality_report":
        return "当前阶段生成的质量闭环报告。"
    if artifact_key == "deploy_report":
        return "当前阶段生成的部署报告。"
    if artifact_key == "regression_report":
        return "当前阶段生成的回归测试报告。"
    return f"{stage} 阶段关联产物。"


def _collect_stage_output_artifacts(artifacts: dict[str, Any], stage: str) -> list[Any]:
    built_artifacts = []
    for artifact_key, artifact in artifacts.items():
        if not isinstance(artifact, dict):
            continue
        path = str(artifact.get("path") or "").strip()
        absolute_path = str(artifact.get("absolute_path") or "").strip()
        if not path or not absolute_path:
            continue
        built_artifacts.append(
            build_stage_output_artifact(
                artifact_type=str(artifact_key or "").strip(),
                path=path,
                absolute_path=absolute_path,
                summary=_stage_output_summary_for_artifact(str(artifact_key or "").strip(), stage),
            )
        )
    return built_artifacts


def _quality_loop_summary(stage_ctx: dict[str, Any]) -> tuple[str, list[str], list[str], dict[str, Any]]:
    prompt_inputs = stage_ctx.get("prompt_inputs", {}) if isinstance(stage_ctx.get("prompt_inputs"), dict) else {}
    evidence = stage_ctx.get("evidence", {}) if isinstance(stage_ctx.get("evidence"), dict) else {}
    quality_loop = evidence.get("quality_loop") if isinstance(evidence.get("quality_loop"), dict) else {}
    history = quality_loop.get("history") if isinstance(quality_loop.get("history"), list) else []
    latest = history[-1] if history and isinstance(history[-1], dict) else {}
    phase = str(prompt_inputs.get("quality_loop_phase") or quality_loop.get("phase") or "verify").strip()
    result = str(latest.get("result") or quality_loop.get("result") or "pending").strip()
    retry_count = latest.get("retry_count") if latest else quality_loop.get("retry_count")
    summary = f"质量闭环阶段：phase={phase}，latest_result={result or 'pending'}。"
    key_points = [
        f"phase={phase}",
        f"history_count={len(history)}",
        f"retry_count={retry_count}" if retry_count is not None else "",
    ]
    evidence_items = [
        str(latest.get("summary") or "").strip(),
        str(latest.get("error") or "").strip(),
        str(evidence.get("last_error_log") or "").strip(),
    ]
    metadata = {
        "artifact_key": primary_artifact_type_for_stage("QUALITY_LOOP") or "",
        "source": "stage_context_fallback",
        "phase": phase,
        "history_count": len(history),
        "latest_result": result or "pending",
    }
    return summary, key_points, evidence_items, metadata


def _build_stage_output_from_stage_ctx(stage_ctx: dict[str, Any], stage: str) -> dict[str, Any]:
    artifacts = stage_ctx.get("artifacts", {}) if isinstance(stage_ctx.get("artifacts"), dict) else {}
    prompt_inputs = stage_ctx.get("prompt_inputs", {}) if isinstance(stage_ctx.get("prompt_inputs"), dict) else {}
    evidence = stage_ctx.get("evidence", {}) if isinstance(stage_ctx.get("evidence"), dict) else {}
    request = stage_ctx.get("request", {}) if isinstance(stage_ctx.get("request"), dict) else {}
    primary_artifact_type = primary_artifact_type_for_stage(stage)

    built_artifacts = _collect_stage_output_artifacts(artifacts, stage)
    requirement = str(prompt_inputs.get("requirement") or request.get("raw_requirement") or "").strip()
    last_error_log = str(evidence.get("last_error_log") or "").strip()

    if stage == "CODING":
        workspace_files = prompt_inputs.get("workspace_files") if isinstance(prompt_inputs.get("workspace_files"), list) else []
        summary = "Coding 阶段已生成可供质量闭环消费的代码与测试产物。"
        key_points = [
            f"requirement={requirement}" if requirement else "",
            f"artifact_count={len(built_artifacts)}",
            f"src_dir={prompt_inputs.get('src_dir') or ''}",
            f"tests_dir={prompt_inputs.get('tests_dir') or ''}",
            f"workspace_file_count={len(workspace_files)}",
        ]
        evidence_items = [last_error_log] if last_error_log else []
        metadata = {
            "artifact_key": primary_artifact_type or "",
            "source": "stage_context_fallback",
            "src_dir": str(prompt_inputs.get("src_dir") or "").strip(),
            "tests_dir": str(prompt_inputs.get("tests_dir") or "").strip(),
        }
    elif stage == "QUALITY_LOOP":
        summary, key_points, evidence_items, metadata = _quality_loop_summary(stage_ctx)
    elif stage == "DEPLOYING":
        summary = "Deploying 阶段已形成部署目标、结果与证据摘要。"
        key_points = [
            f"requirement={requirement}" if requirement else "",
            f"target_envs={','.join(prompt_inputs.get('target_envs') or [])}" if isinstance(prompt_inputs.get("target_envs"), list) else "",
            f"deployment_status={prompt_inputs.get('deployment_status') or 'pending'}",
        ]
        evidence_items = [
            str(prompt_inputs.get("deployment_summary") or "").strip(),
            str(prompt_inputs.get("deployment_evidence") or "").strip(),
            last_error_log,
        ]
        metadata = {
            "artifact_key": primary_artifact_type or "",
            "source": "stage_context_fallback",
            "target_envs": prompt_inputs.get("target_envs") if isinstance(prompt_inputs.get("target_envs"), list) else [],
            "deployment_status": str(prompt_inputs.get("deployment_status") or "pending").strip(),
        }
    elif stage == "REGRESSION_TESTING":
        summary = "Regression Testing 阶段已形成环境回归结果摘要。"
        key_points = [
            f"requirement={requirement}" if requirement else "",
            f"target_envs={','.join(prompt_inputs.get('target_envs') or [])}" if isinstance(prompt_inputs.get("target_envs"), list) else "",
            f"case_count={len(prompt_inputs.get('test_cases') or [])}" if isinstance(prompt_inputs.get("test_cases"), list) else "",
        ]
        evidence_items = [
            str(prompt_inputs.get("regression_summary") or "").strip(),
            str(prompt_inputs.get("regression_result") or "").strip(),
            last_error_log,
        ]
        metadata = {
            "artifact_key": primary_artifact_type or "",
            "source": "stage_context_fallback",
            "target_envs": prompt_inputs.get("target_envs") if isinstance(prompt_inputs.get("target_envs"), list) else [],
            "test_cases": prompt_inputs.get("test_cases") if isinstance(prompt_inputs.get("test_cases"), list) else [],
        }
    else:
        summary = f"{stage} 阶段产物摘要。"
        key_points = [
            f"requirement={requirement}" if requirement else "",
            f"artifact_count={len(built_artifacts)}",
        ]
        evidence_items = [last_error_log] if last_error_log else []
        metadata = {
            "artifact_key": primary_artifact_type or "",
            "source": "stage_context_fallback",
        }

    result = build_stage_output(
        stage=stage,
        summary=summary,
        artifacts=built_artifacts,
        key_points=key_points,
        evidence=evidence_items,
        metadata=metadata,
    )
    return result.to_dict()


def resolve_stage_output_for_acceptance(*, stage_ctx: dict[str, Any], stage: str) -> tuple[dict[str, Any], StageOutput]:
    normalized_stage = str(stage or "").strip()
    raw_stage_output = _stage_output_from_run(stage_ctx, normalized_stage)
    if raw_stage_output is None:
        raise StageOutputValidationError(f"missing_stage_output:{normalized_stage}")
    artifacts = stage_ctx.get("artifacts", {}) if isinstance(stage_ctx.get("artifacts"), dict) else {}
    normalized_payload = normalize_stage_output_payload(
        raw_stage_output,
        fallback_artifacts=_collect_stage_output_artifacts(artifacts, normalized_stage),
    )
    validated = validate_stage_output(normalized_payload, expected_stage=normalized_stage)
    if normalized_stage == "CODING":
        output_metadata = validated.metadata if isinstance(validated.metadata, dict) else {}
        if not isinstance(output_metadata.get("changed_files"), list):
            raise StageOutputValidationError("coding_stage_output_changed_files_required")
        for key in ("branch_name", "commit_sha", "mr_url"):
            if key not in output_metadata:
                raise StageOutputValidationError(f"coding_stage_output_{key}_required")
    return normalized_payload, validated


def acceptance_output_path(*, stage: str, run_dir_relative: str | None = None) -> str:
    normalized_run_dir = str(run_dir_relative or "").strip()
    if not normalized_run_dir:
        raise AcceptanceValidationError("acceptance_run_dir_required")
    return os.path.join(normalized_run_dir, "acceptance", f"{stage}.json")


def _read_acceptance_result_file(*, repo_root: str, stage: str, run_dir_relative: str | None = None) -> str:
    rel_path = acceptance_output_path(stage=stage, run_dir_relative=run_dir_relative)
    path = os.path.join(repo_root, rel_path)
    if not os.path.exists(path):
        raise AcceptanceValidationError(f"acceptance_result_missing_file: {rel_path}")
    if os.path.isdir(path):
        raise AcceptanceValidationError(f"acceptance_result_is_directory: {rel_path}")
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read().strip()
    if not text:
        raise AcceptanceValidationError(f"acceptance_result_empty_file: {rel_path}")
    return text


def _build_harness_capability_payload() -> dict[str, Any]:
    from core.capability_registry import default_registry

    registry = default_registry()
    tools = registry.list_all()
    return {
        "tools": [
            {
                "name": t.name,
                "kind": t.kind,
                "risk_level": t.risk_level,
                "policy_tags": list(t.policy_tags),
                "summary": t.summary,
            }
            for t in tools
        ]
    }


def _render_harness_capability_markdown(payload: dict[str, Any]) -> str:
    tools = payload.get("tools") if isinstance(payload, dict) else []
    lines = ["## Available Capabilities (Harness full scope)", ""]
    for item in tools if isinstance(tools, list) else []:
        if not isinstance(item, dict):
            continue
        lines.append(
            f"- {item.get('name')} ({item.get('kind')}, risk={item.get('risk_level')}): {item.get('summary')}"
        )
    lines.append("")
    lines.append("Constraints:")
    lines.append("- Harness 准出可使用全量工具发现结果，不受当前 pipeline stage 的 tool config 缩减。")
    lines.append("- 仅在需要核对准出规则时按需读取或调用工具，不要无关扩展检查范围。")
    return "\n".join(lines).strip()


def _build_harness_tool_prompt_bundle(repo_root: str) -> tuple[str, dict[str, Any], dict[str, Any]]:
    from core.tool_catalog import build_tool_catalog_payload

    capability_payload = _build_harness_capability_payload()
    capability_md = _render_harness_capability_markdown(capability_payload)
    tool_catalog_payload = build_tool_catalog_payload(stage=None, workspace_root=repo_root)
    return capability_md, capability_payload, tool_catalog_payload


def _build_acceptance_prompt_text(
    *,
    stage: str,
    artifact_type: str,
    acceptance_prompt: str,
    acceptance_rules: list[dict[str, str]] | None,
    stage_output_payload: dict[str, Any],
    artifact_manifest: dict[str, Any],
    repo_root: str,
    run_dir_relative: str = "",
    preview_blocked_reason: str = "",
    prior_failure: dict[str, Any] | None = None,
) -> str:
    harness_capability_md, harness_capability_payload, harness_tool_catalog_payload = _build_harness_tool_prompt_bundle(repo_root)
    resolved_run_dir_relative = str(run_dir_relative or "").strip()
    if not resolved_run_dir_relative and isinstance(stage_output_payload, dict):
        resolved_run_dir_relative = str((stage_output_payload.get("metadata") or {}).get("run_dir") or "").strip()
    acceptance_file = acceptance_output_path(stage=stage, run_dir_relative=resolved_run_dir_relative or None)
    baseline_lines = [
        "- 第一层本地结构校验已经通过。" if not preview_blocked_reason else f"- Preview 提示：当前运行态会先被拦截，原因是 `{preview_blocked_reason}`。",
        "- 当前 prompt 只提供精简 manifest；需要细节时请自行读取列出的文件。",
        "- 判定时优先看用户规则，不要自行增加额外门槛。",
    ]
    baseline_text = "\n".join(baseline_lines)
    acceptance_rules_block = render_acceptance_rules_block(acceptance_rules)
    prompt_text = str(acceptance_prompt or "").strip()
    user_rule_sections: list[str] = []
    if acceptance_rules_block:
        user_rule_sections.append(acceptance_rules_block)
    if prompt_text:
        user_rule_sections.append("### 用户配置的准出补充说明\n" + prompt_text)
    if not user_rule_sections:
        user_rule_sections.append("(空)")
    user_rules_text = "\n\n".join(user_rule_sections)

    prior = dict(prior_failure or {}) if isinstance(prior_failure, dict) else {}
    prior_reason = str(prior.get("reason") or "").strip()
    prior_summary = str(prior.get("summary") or "").strip()
    prior_missing = prior.get("missing_items") if isinstance(prior.get("missing_items"), list) else []
    prior_findings = prior.get("findings") if isinstance(prior.get("findings"), list) else []
    prior_fix = str(prior.get("suggested_fix") or "").strip()
    prior_lines: list[str] = []
    if prior_reason or prior_summary or prior_missing or prior_findings or prior_fix:
        prior_lines.extend([
            "## Previous verifier feedback",
            f"- failure reason: {prior_reason or '(unknown)'}",
            f"- summary: {prior_summary or '(empty)'}",
        ])
        if prior_missing:
            prior_lines.append("- missing_items:")
            prior_lines.extend([f"  - {item}" for item in prior_missing if str(item).strip()])
        if prior_findings:
            prior_lines.append("- findings:")
            prior_lines.extend([f"  - {item}" for item in prior_findings if str(item).strip()])
        if prior_fix:
            prior_lines.append(f"- suggested_fix: {prior_fix}")
        prior_lines.append("- On this retry, use the previous verifier feedback as factual context and only fail again if the unmet requirements still remain.")

    sections = [
        "# Role\n你是 Harness 的阶段准出判定器。你的职责是做第二层准出：在第一层本地结构校验已经通过后，主要根据用户配置的准出规则判断是否放行。",
        "## Decision priority\n"
        "1. 第一优先级是【用户配置的准出规则】；只要产物满足用户明确提出的准出要求，就应倾向于通过。\n"
        "2. 你默认拿到的是精简输入：系统基线、用户准出规则、标准化 Stage Output JSON、产物清单与相对路径。\n"
        "3. 不要把系统自己的写作偏好、证据偏好、章节偏好、风险提示偏好，当成新的强制准出条件。\n"
        "4. 除非用户在准出规则中明确要求，否则像‘证据链不够完整’、‘风险说明不够充分’、‘来源引用不够细’这类问题只能写入 findings，不能单独作为 fail 理由。\n"
        "5. 只有在用户规则未满足时，才输出 fail；如果只是存在改进建议但不影响用户规则满足，应输出 pass，并把建议写入 findings。\n"
        "6. 如果需要核对细节，按需读取 manifest 中列出的相对路径产物；不要预设需要把所有产物全文塞进 prompt。",
        f"## Stage\n- stage: {stage}\n- artifact_type: {artifact_type}",
        f"## System baseline\n{baseline_text}",
        f"## User acceptance rules\n{user_rules_text}",
        f"## Standardized Stage Output\n```json\n{json.dumps(stage_output_payload, ensure_ascii=False, indent=2)}\n```",
        f"## Artifact manifest\n```json\n{json.dumps(artifact_manifest, ensure_ascii=False, indent=2)}\n```",
        f"## Available capabilities\n{harness_capability_md}",
        f"## Capability payload\n```json\n{json.dumps(harness_capability_payload, ensure_ascii=False, indent=2)}\n```",
        f"## Tool catalog\n```json\n{json.dumps(harness_tool_catalog_payload, ensure_ascii=False, indent=2)}\n```",
    ]
    if prior_lines:
        sections.append("\n".join(prior_lines))
    sections.append(
        "## Output contract\n"
        f"- 你必须把最终判定结果直接写入文件 `{acceptance_file}`，不要只输出在对话里。\n"
        "- 优先使用文件写入工具完成这次写入；父目录会自动创建，不要单独创建目录。\n"
        "- 不要执行 `mkdir`、`cp`、`mv`，也不要改用 shell 或其他 CLI。\n"
        "- 如果写入失败，直接报告失败，不要自行尝试其他命令。\n"
        "- 不要输出 markdown、解释、代码块或额外文本；完成后你的最终回复只允许写 `WROTE_ACCEPTANCE_JSON`。\n"
        "- JSON schema:\n"
        "```json\n"
        "{\n"
        '  "stage": "string",\n'
        '  "artifact_type": "string",\n'
        '  "verdict": "pass | fail",\n'
        '  "summary": "string",\n'
        '  "missing_items": ["string"],\n'
        '  "findings": ["string"],\n'
        '  "suggested_fix": "string"\n'
        "}\n"
        "```"
    )
    return "\n\n".join(sections).strip() + "\n"


def build_acceptance_prompt(
    *,
    stage_ctx: dict[str, Any],
    stage: str,
    acceptance_prompt: str,
    acceptance_rules: list[dict[str, str]] | None = None,
    prior_failure: dict[str, Any] | None = None,
) -> str:
    artifacts = stage_ctx.get("artifacts", {}) if isinstance(stage_ctx.get("artifacts"), dict) else {}
    run = stage_ctx.get("run", {}) if isinstance(stage_ctx.get("run"), dict) else {}
    artifact_type = stage_acceptance_artifact_type(stage)
    if not artifact_type:
        raise AcceptanceValidationError(f"unsupported_acceptance_stage: {stage}")

    _, stage_output = resolve_stage_output_for_acceptance(stage_ctx=stage_ctx, stage=stage)
    artifact = artifacts.get(artifact_type, {}) if isinstance(artifacts.get(artifact_type), dict) else {}
    repo_root = str(run.get("repo_root") or os.getcwd()).strip() or os.getcwd()
    artifact_manifest = {
        "primary_artifact_type": artifact_type,
        "primary_artifact_path": artifact.get("path"),
        "artifacts": [
            {
                "artifact_type": item.artifact_type,
                "path": item.path,
                "summary": item.summary,
                "exists": item.exists,
                "size_bytes": item.size_bytes,
            }
            for item in stage_output.artifacts
        ],
    }
    return _build_acceptance_prompt_text(
        stage=stage,
        artifact_type=artifact_type,
        acceptance_prompt=acceptance_prompt,
        acceptance_rules=acceptance_rules,
        stage_output_payload=stage_output.to_dict(),
        artifact_manifest=artifact_manifest,
        repo_root=repo_root,
        run_dir_relative=str(run.get("run_dir_relative") or "").strip(),
        prior_failure=prior_failure,
    )


def build_acceptance_preview_prompt(
    *,
    stage_ctx: dict[str, Any],
    stage: str,
    acceptance_prompt: str,
    acceptance_rules: list[dict[str, str]] | None = None,
    prior_failure: dict[str, Any] | None = None,
) -> tuple[str, str | None]:
    artifacts = stage_ctx.get("artifacts", {}) if isinstance(stage_ctx.get("artifacts"), dict) else {}
    run = stage_ctx.get("run", {}) if isinstance(stage_ctx.get("run"), dict) else {}
    metadata = stage_ctx.get("metadata") if isinstance(stage_ctx.get("metadata"), dict) else {}
    artifact_type = stage_acceptance_artifact_type(stage)
    if not artifact_type:
        raise AcceptanceValidationError(f"unsupported_acceptance_stage: {stage}")

    artifact = artifacts.get(artifact_type, {}) if isinstance(artifacts.get(artifact_type), dict) else {}
    repo_root = str(run.get("repo_root") or os.getcwd()).strip() or os.getcwd()

    preview_blocked_reason = None
    try:
        _, stage_output = resolve_stage_output_for_acceptance(stage_ctx=stage_ctx, stage=stage)
        stage_output_payload = stage_output.to_dict()
        manifest_artifacts = [
            {
                "artifact_type": item.artifact_type,
                "path": item.path,
                "summary": item.summary,
                "exists": item.exists,
                "size_bytes": item.size_bytes,
            }
            for item in stage_output.artifacts
        ]
    except StageOutputValidationError as exc:
        preview_blocked_reason = str(exc)
        raw_stage_output = _stage_output_from_run(stage_ctx, stage)
        if raw_stage_output is None:
            raw_stage_output = _build_stage_output_from_stage_ctx(stage_ctx, stage)
        stage_output_payload = raw_stage_output
        raw_artifacts = raw_stage_output.get("artifacts") if isinstance(raw_stage_output.get("artifacts"), list) else []
        manifest_artifacts = []
        for item in raw_artifacts:
            if not isinstance(item, dict):
                continue
            manifest_artifacts.append(
                {
                    "artifact_type": str(item.get("artifact_type") or "").strip(),
                    "path": str(item.get("path") or "").strip(),
                    "summary": str(item.get("summary") or "").strip(),
                    "exists": bool(item.get("exists")),
                    "size_bytes": int(item.get("size_bytes") or 0) if str(item.get("size_bytes") or "").strip() else 0,
                }
            )

    artifact_manifest = {
        "primary_artifact_type": artifact_type,
        "primary_artifact_path": artifact.get("path"),
        "artifacts": manifest_artifacts,
    }
    prompt = _build_acceptance_prompt_text(
        stage=stage,
        artifact_type=artifact_type,
        acceptance_prompt=acceptance_prompt,
        acceptance_rules=acceptance_rules,
        stage_output_payload=stage_output_payload,
        artifact_manifest=artifact_manifest,
        repo_root=repo_root,
        run_dir_relative=str(run.get("run_dir_relative") or "").strip(),
        preview_blocked_reason=preview_blocked_reason or "",
        prior_failure=prior_failure,
    )
    return prompt, preview_blocked_reason


def parse_acceptance_result(raw_text: str, *, stage: str, artifact_type: str) -> AcceptanceVerdict:
    text = str(raw_text or "").strip()
    if not text:
        raise AcceptanceValidationError("empty_acceptance_response")
    try:
        payload = json.loads(text)
    except Exception as exc:
        raise AcceptanceValidationError(f"acceptance_result_not_json: {exc}") from exc
    if not isinstance(payload, dict):
        raise AcceptanceValidationError("acceptance_result_must_be_object")

    stage_value = str(payload.get("stage") or "").strip()
    artifact_type_value = str(payload.get("artifact_type") or "").strip()
    verdict = str(payload.get("verdict") or "").strip().lower()
    summary = str(payload.get("summary") or "").strip()
    missing_items = payload.get("missing_items")
    findings = payload.get("findings")
    suggested_fix = str(payload.get("suggested_fix") or "").strip()

    if stage_value != stage:
        raise AcceptanceValidationError(f"acceptance_stage_mismatch: expected {stage}, got {stage_value or '<missing>'}")
    if artifact_type_value != artifact_type:
        raise AcceptanceValidationError(
            f"acceptance_artifact_type_mismatch: expected {artifact_type}, got {artifact_type_value or '<missing>'}"
        )
    if verdict not in {"pass", "fail"}:
        raise AcceptanceValidationError(f"invalid_acceptance_verdict: {verdict or '<missing>'}")
    if not summary:
        raise AcceptanceValidationError("acceptance_summary_required")
    if not isinstance(missing_items, list) or not all(isinstance(item, str) for item in missing_items):
        raise AcceptanceValidationError("acceptance_missing_items_must_be_string_list")
    if not isinstance(findings, list) or not all(isinstance(item, str) for item in findings):
        raise AcceptanceValidationError("acceptance_findings_must_be_string_list")

    return AcceptanceVerdict(
        stage=stage_value,
        artifact_type=artifact_type_value,
        verdict=verdict,
        summary=summary,
        missing_items=[str(item).strip() for item in missing_items],
        findings=[str(item).strip() for item in findings],
        suggested_fix=suggested_fix,
        raw=payload,
    )

def _pick_stage_output_artifact(stage_output: dict[str, Any] | None, artifact_type: str) -> dict[str, Any] | None:
    if not isinstance(stage_output, dict):
        return None
    artifacts = stage_output.get("artifacts") if isinstance(stage_output.get("artifacts"), list) else []
    for item in artifacts:
        if isinstance(item, dict) and str(item.get("artifact_type") or "").strip() == str(artifact_type or "").strip():
            return item
    for item in artifacts:
        if isinstance(item, dict):
            return item
    return None


def _stage_output_validation_payload(*, stage_name: str, artifact_type: str, error: str, stage_output: dict[str, Any] | None) -> dict[str, Any]:
    error_text = str(error or "").strip()
    payload: dict[str, Any] = {
        "error": error_text,
        "error_code": "stage_output_validation_error",
        "error_message": "当前阶段的结构化输出未通过校验。",
        "error_details": {"stage": stage_name, "artifact_type": artifact_type},
    }
    artifact = _pick_stage_output_artifact(stage_output, artifact_type)
    if artifact:
        payload["error_details"]["declared_path"] = artifact.get("path")
        payload["error_details"]["declared_absolute_path"] = artifact.get("absolute_path")
        payload["error_details"]["declared_exists"] = artifact.get("exists")
        payload["error_details"]["declared_is_dir"] = artifact.get("is_dir")
        payload["error_details"]["declared_size_bytes"] = artifact.get("size_bytes")

    if error_text.startswith("missing_stage_output:"):
        missing_stage = error_text.split(":", 1)[1].strip() or stage_name
        payload["error_code"] = "stage_output_not_found"
        payload["error_message"] = f"未找到阶段 {missing_stage} 的 stage output JSON 文件。"
        payload["error_details"]["stage"] = missing_stage
        payload["error_details"]["field"] = "stage_output_file"
        payload["error_details"]["expected"] = f"existing file for stage {missing_stage}"
        payload["error_details"]["received"] = "missing"
        return payload
    if error_text.startswith("invalid_stage_output_schema_version:"):
        received = error_text.split(":", 1)[1].strip()
        payload["error_code"] = "schema_version_invalid"
        payload["error_message"] = "StageOutput 的 schema_version 不合法。"
        payload["error_details"]["field"] = "schema_version"
        payload["error_details"]["expected"] = 1
        payload["error_details"]["received"] = received
        return payload
    if error_text == "stage_output_stage_required":
        payload["error_code"] = "stage_required"
        payload["error_message"] = "StageOutput 缺少必填字段 stage。"
        payload["error_details"]["field"] = "stage"
        payload["error_details"]["expected"] = stage_name
        payload["error_details"]["received"] = ""
        return payload
    if error_text.startswith("stage_output_stage_mismatch:"):
        payload["error_code"] = "stage_mismatch"
        payload["error_message"] = "StageOutput 中的 stage 与当前阶段不一致。"
        payload["error_details"]["field"] = "stage"
        payload["error_details"]["expected"] = stage_name
        payload["error_details"]["received"] = error_text
        return payload
    if error_text == "stage_output_status_required":
        payload["error_code"] = "status_required"
        payload["error_message"] = "StageOutput 缺少必填字段 status。"
        payload["error_details"]["field"] = "status"
        payload["error_details"]["expected"] = "non-empty string"
        payload["error_details"]["received"] = ""
        return payload
    if error_text == "stage_output_summary_required":
        payload["error_code"] = "summary_required"
        payload["error_message"] = "StageOutput 缺少必填字段 summary。"
        payload["error_details"]["field"] = "summary"
        payload["error_details"]["expected"] = "non-empty string"
        payload["error_details"]["received"] = ""
        return payload
    if error_text == "stage_output_artifacts_required":
        payload["error_code"] = "artifacts_required"
        payload["error_message"] = "StageOutput 缺少合法的 artifacts 数组。"
        payload["error_details"]["field"] = "artifacts"
        payload["error_details"]["expected"] = "non-empty array"
        payload["error_details"]["received"] = type(stage_output.get('artifacts')).__name__ if isinstance(stage_output, dict) and 'artifacts' in stage_output else "missing"
        return payload
    if error_text == "stage_output_key_points_must_be_string_list":
        payload["error_code"] = "key_points_invalid"
        payload["error_message"] = "StageOutput 的 key_points 必须是字符串数组。"
        payload["error_details"]["field"] = "key_points"
        payload["error_details"]["expected"] = "string[]"
        payload["error_details"]["received"] = type(stage_output.get('key_points')).__name__ if isinstance(stage_output, dict) and 'key_points' in stage_output else "missing"
        return payload
    if error_text == "stage_output_evidence_must_be_string_list":
        payload["error_code"] = "evidence_invalid"
        payload["error_message"] = "StageOutput 的 evidence 必须是字符串数组。"
        payload["error_details"]["field"] = "evidence"
        payload["error_details"]["expected"] = "string[]"
        payload["error_details"]["received"] = type(stage_output.get('evidence')).__name__ if isinstance(stage_output, dict) and 'evidence' in stage_output else "missing"
        return payload
    if error_text == "stage_output_metadata_must_be_object":
        payload["error_code"] = "metadata_invalid"
        payload["error_message"] = "StageOutput 的 metadata 必须是对象。"
        payload["error_details"]["field"] = "metadata"
        payload["error_details"]["expected"] = "object"
        payload["error_details"]["received"] = type(stage_output.get('metadata')).__name__ if isinstance(stage_output, dict) and 'metadata' in stage_output else "missing"
        return payload
    if error_text == "stage_output_artifact_must_be_object":
        payload["error_code"] = "artifact_object_invalid"
        payload["error_message"] = "artifacts 数组中的每一项都必须是对象。"
        payload["error_details"]["field"] = "artifacts[]"
        payload["error_details"]["expected"] = "object"
        return payload
    artifact_field_errors = {
        "stage_output_artifact_type_required": ("artifact_type_required", "artifact_type"),
        "stage_output_artifact_path_required": ("artifact_path_required", "path"),
        "stage_output_artifact_absolute_path_required": ("artifact_absolute_path_required", "absolute_path"),
        "stage_output_artifact_summary_required": ("artifact_summary_required", "summary"),
        "stage_output_artifact_size_bytes_invalid": ("artifact_size_bytes_invalid", "size_bytes"),
    }
    if error_text in artifact_field_errors:
        code, field = artifact_field_errors[error_text]
        payload["error_code"] = code
        payload["error_message"] = f"artifacts 中的字段 {field} 不符合要求。"
        payload["error_details"]["field"] = f"artifacts[].{field}"
        payload["error_details"]["missing_field"] = field
        return payload
    if error_text.startswith("stage_output_artifact_missing:"):
        failed_artifact = error_text.split(":", 1)[1].strip() or artifact_type
        payload["error_code"] = "artifact_not_found"
        payload["error_message"] = "未在声明的绝对路径下找到该产物文件。"
        payload["error_details"]["artifact_type"] = failed_artifact
        return payload
    if error_text.startswith("stage_output_artifact_empty_dir:"):
        failed_artifact = error_text.split(":", 1)[1].strip() or artifact_type
        payload["error_code"] = "artifact_directory_empty"
        payload["error_message"] = "声明的产物目录下未找到任何文件，未满足非空目录要求。"
        payload["error_details"]["artifact_type"] = failed_artifact
        return payload
    if error_text.startswith("stage_output_artifact_empty:"):
        failed_artifact = error_text.split(":", 1)[1].strip() or artifact_type
        payload["error_code"] = "artifact_empty"
        payload["error_message"] = "未读取到符合要求的非空产物文件。"
        payload["error_details"]["artifact_type"] = failed_artifact
        return payload
    if error_text == "coding_stage_output_changed_files_required":
        payload["error_code"] = "coding_changed_files_required"
        payload["error_message"] = "CODING 阶段的 stage output metadata 缺少 changed_files 列表。"
        payload["error_details"]["field"] = "metadata.changed_files"
        payload["error_details"]["expected"] = "array"
        payload["error_details"]["received"] = "missing_or_invalid"
        return payload
    if error_text.startswith("coding_stage_output_") and error_text.endswith("_required"):
        missing_field = error_text[len("coding_stage_output_") : -len("_required")]
        payload["error_code"] = f"coding_{missing_field}_required"
        payload["error_message"] = f"CODING 阶段的 stage output metadata 缺少必填字段 {missing_field}。"
        payload["error_details"]["missing_field"] = missing_field
        payload["error_details"]["field"] = f"metadata.{missing_field}"
        payload["error_details"]["expected"] = "required"
        payload["error_details"]["received"] = "missing"
        return payload
    return payload


def run_stage_acceptance_verifier(ctx: Any, *, stage: str, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
    from core.acp_agent import AcpAgent

    stage_name = str(stage or "").strip()
    state = load_stage_acceptance_state(stage_name, repo_root=getattr(ctx, "_repo_root", lambda *_: None)())
    artifact_type = stage_acceptance_artifact_type(stage_name)
    meta = metadata if isinstance(metadata, dict) else {}

    if not artifact_type or not state.get("supported"):
        return {"outcome": "pass", "reason": "acceptance_unsupported", "acceptance_result": None}
    if not state.get("enabled"):
        clear_acceptance_result(meta, stage_name)
        clear_acceptance_retry_state(meta, stage_name)
        if hasattr(ctx, "save"):
            ctx.save()
        return {"outcome": "pass", "reason": "acceptance_disabled", "acceptance_result": None}

    repo_root = getattr(ctx, "_repo_root", lambda *_: None)() or ""
    raw_max_retries = state.get("max_retries", 2)
    try:
        configured_max_retries = int(raw_max_retries)
    except (TypeError, ValueError):
        configured_max_retries = 2
    configured_max_retries = max(0, configured_max_retries)
    prior_failure: dict[str, Any] | None = None
    agent = AcpAgent()

    stage_ctx = ctx.prepare_stage_context(stage_name, repo_root=getattr(ctx, "_repo_root", lambda *_: None)())
    try:
        raw_stage_output, validated_stage_output = resolve_stage_output_for_acceptance(stage_ctx=stage_ctx, stage=stage_name)
        prompt = build_acceptance_prompt(
            stage_ctx=stage_ctx,
            stage=stage_name,
            acceptance_prompt=str(state.get("prompt") or "").strip(),
            acceptance_rules=state.get("rules") if isinstance(state.get("rules"), list) else [],
            prior_failure=prior_failure,
        )
    except StageOutputValidationError as exc:
        failed_stage_output = _stage_output_from_run(stage_ctx, stage_name)
        error_payload = _stage_output_validation_payload(
            stage_name=stage_name,
            artifact_type=artifact_type,
            error=str(exc),
            stage_output=failed_stage_output,
        )
        validation_result = {
            "stage": stage_name,
            "artifact_type": artifact_type,
            "verdict": "fail",
            "summary": error_payload["error_message"],
            "missing_items": [],
            "findings": [error_payload["error_message"]],
            "suggested_fix": "修正当前阶段的标准化输出、产物路径和非空约束后重试。",
        }
        record_acceptance_result(meta, stage_name, validation_result)
        clear_acceptance_retry_state(meta, stage_name)
        if hasattr(ctx, "save"):
            ctx.save()
        append_acceptance_trace(
            stage_name,
            "acceptance_stage_output_validation_failed",
            artifact_type=artifact_type,
            summary=error_payload["error_message"],
            error_code=error_payload["error_code"],
        )
        should_retry, retry_count, max_retries = ctx.record_noncompliance(
            stage=stage_name,
            kind="stage_output_validation",
            reason="stage_output_validation_failed",
            details={
                **error_payload,
                "artifact_type": artifact_type,
                "stage_output": failed_stage_output,
            },
            suggestion="修正节点输出 JSON 或产物文件后重试。",
        )
        return {
            "outcome": "fail",
            "reason": "stage_output_validation_failed",
            "acceptance_result": validation_result,
            "stage_output": failed_stage_output,
            "should_retry": should_retry,
            "retry_count": retry_count,
            "max_retries": max_retries,
        }

    append_acceptance_trace(
        stage_name,
        "acceptance_verification_started",
        artifact_type=artifact_type,
        model=str(state.get("model") or ""),
        enabled=bool(state.get("enabled")),
        attempt=1,
        max_retries=configured_max_retries,
        stage_output=validated_stage_output.to_dict(),
    )

    for attempt in range(1, configured_max_retries + 2):
        try:
            result = agent.run_task(prompt_text=prompt, cwd=repo_root, stage=stage_name)
            if hasattr(ctx, "record_acp_session"):
                ctx.record_acp_session(stage_name, result)
            raw_text = _read_acceptance_result_file(
                repo_root=repo_root,
                stage=stage_name,
                run_dir_relative=str(meta.get("run_dir") or "").strip() or None,
            )
            verdict = parse_acceptance_result(raw_text, stage=stage_name, artifact_type=artifact_type)
            record_acceptance_result(meta, stage_name, verdict.to_dict())
            append_acceptance_trace(
                stage_name,
                "acceptance_verification_completed",
                artifact_type=artifact_type,
                verdict=verdict.verdict,
                summary=verdict.summary,
                missing_items=verdict.missing_items,
                findings=verdict.findings,
                suggested_fix=verdict.suggested_fix,
                attempt=attempt,
                max_retries=configured_max_retries,
                stage_output=validated_stage_output.to_dict(),
            )
            if verdict.verdict == "pass":
                clear_acceptance_retry_state(meta, stage_name)
                if hasattr(ctx, "save"):
                    ctx.save()
                if hasattr(ctx, "update_metadata"):
                    ctx.update_metadata("last_error_log", "")
                return {
                    "outcome": "pass",
                    "reason": "acceptance_pass",
                    "acceptance_result": verdict.to_dict(),
                    "stage_output": validated_stage_output.to_dict(),
                }

            prior_failure = _normalize_prior_failure(reason="acceptance_failed", acceptance_result=verdict.to_dict())
            update_acceptance_retry_state(
                meta,
                stage=stage_name,
                attempt=attempt,
                max_retries=configured_max_retries,
                last_failure=prior_failure,
                history_entry={"attempt": attempt, "reason": "acceptance_failed", "summary": verdict.summary, "verdict": verdict.verdict},
            )
            details = {
                "acceptance_result": verdict.to_dict(),
                "artifact_type": artifact_type,
                "stage_output": validated_stage_output.to_dict(),
                "acceptance_retry_state": acceptance_retry_state_from_metadata(meta, stage_name),
            }
            should_retry, retry_count, max_retries = ctx.record_noncompliance(
                stage=stage_name,
                kind="acceptance_verification",
                reason="acceptance_failed",
                details=details,
                suggestion=verdict.suggested_fix or verdict.summary,
            )
            if hasattr(ctx, "save"):
                ctx.save()
            return {
                "outcome": "fail",
                "reason": "acceptance_failed",
                "acceptance_result": verdict.to_dict(),
                "stage_output": validated_stage_output.to_dict(),
                "should_retry": should_retry,
                "retry_count": retry_count,
                "max_retries": max_retries,
                "acceptance_retry_count": attempt,
                "acceptance_max_retries": configured_max_retries,
            }
        except Exception as exc:
            malformed_result = {
                "stage": stage_name,
                "artifact_type": artifact_type,
                "verdict": "fail",
                "summary": str(exc),
                "missing_items": [],
                "findings": [str(exc)],
                "suggested_fix": "修正当前产物后重新生成，并确保准出判定器按约定写出 acceptance JSON 文件。",
            }
            record_acceptance_result(meta, stage_name, malformed_result)
            append_acceptance_trace(
                stage_name,
                "acceptance_verification_completed",
                artifact_type=artifact_type,
                verdict="fail",
                summary=str(exc),
                findings=[str(exc)],
                malformed=True,
                attempt=attempt,
                max_retries=configured_max_retries,
                stage_output=validated_stage_output.to_dict(),
            )
            prior_failure = _normalize_prior_failure(reason="acceptance_verifier_error", acceptance_result=malformed_result)
            update_acceptance_retry_state(
                meta,
                stage=stage_name,
                attempt=attempt,
                max_retries=configured_max_retries,
                last_failure=prior_failure,
                history_entry={"attempt": attempt, "reason": "acceptance_verifier_error", "summary": str(exc), "verdict": "fail"},
            )
            if attempt <= configured_max_retries:
                if hasattr(ctx, "save"):
                    ctx.save()
                continue

            should_retry, retry_count, max_retries = ctx.record_noncompliance(
                stage=stage_name,
                kind="acceptance_verification",
                reason="acceptance_verifier_error",
                details={
                    "error": str(exc),
                    "acceptance_result": malformed_result,
                    "artifact_type": artifact_type,
                    "stage_output": validated_stage_output.to_dict(),
                    "acceptance_retry_state": acceptance_retry_state_from_metadata(meta, stage_name),
                },
                suggestion="修正当前产物或准出规则后重试。",
            )
            if hasattr(ctx, "save"):
                ctx.save()
            return {
                "outcome": "fail",
                "reason": "acceptance_verifier_error",
                "acceptance_result": malformed_result,
                "stage_output": validated_stage_output.to_dict(),
                "should_retry": should_retry,
                "retry_count": retry_count,
                "max_retries": max_retries,
                "acceptance_retry_count": attempt,
                "acceptance_max_retries": configured_max_retries,
            }

    return {"outcome": "fail", "reason": "acceptance_retry_loop_exhausted", "acceptance_result": None}


def append_acceptance_trace(stage: str, event_type: str, **data: Any) -> None:
    append_event(event_type, state=stage, data=data)
