"""Manage the repo-level CLI registration file (.harness/cli_tools.json).

This is the user's curated list of CLIs that Harness is allowed to advertise
to the model. We intentionally do NOT scan $PATH -- users must register CLIs
explicitly. The UI calls this module to list / add / remove entries; the file
format is the same one consumed by `core.tool_catalog._load_cli_entries`.

Entry shape (canonical):
    {
      "name": "lark-cli",               # unique identifier (slug)
      "command": "lark-cli",            # executable or absolute path
      "summary": "Fetch Lark doc",      # short human description
      "risk_level": "medium"            # optional: low | medium | high
    }

Fields we dropped (never write them back, strip on read):
    - "usage": redundant with CLI Allowlist in prompt
"""
from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from typing import Any, Iterable

_CLI_TOOLS_REL = os.path.join(".harness", "cli_tools.json")
_SLUG_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._+\-]{0,63}$")
_VALID_RISK = {"low", "medium", "high"}


@dataclass
class CliRegistryEntry:
    name: str
    command: str
    summary: str
    risk_level: str

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "command": self.command,
            "summary": self.summary,
        }
        if self.risk_level:
            d["risk_level"] = self.risk_level
        return d


def cli_tools_path(repo_root: str) -> str:
    return os.path.join(repo_root, _CLI_TOOLS_REL)


def _read_raw(repo_root: str) -> list[dict[str, Any]]:
    path = cli_tools_path(repo_root)
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(data, list):
        return []
    out: list[dict[str, Any]] = []
    for item in data:
        if isinstance(item, dict) and isinstance(item.get("name"), str):
            item.pop("usage", None)  # legacy field: strip silently
            out.append(item)
    return out


def _write_atomic(repo_root: str, items: list[dict[str, Any]]) -> str:
    path = cli_tools_path(repo_root)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".cli_tools.", suffix=".json.tmp", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
    return path


def list_registered(repo_root: str) -> list[dict[str, Any]]:
    """Return the registered entries with an added `resolved` boolean indicating
    whether the command can be found on PATH right now."""
    items = _read_raw(repo_root)
    out: list[dict[str, Any]] = []
    for it in items:
        cmd = str(it.get("command") or it.get("name") or "").strip()
        if os.path.isabs(cmd):
            resolved = os.path.exists(cmd)
        else:
            resolved = shutil.which(cmd) is not None
        entry = {
            "name": str(it.get("name") or "").strip(),
            "command": cmd,
            "summary": str(it.get("summary") or "").strip(),
            "risk_level": str(it.get("risk_level") or "").strip() or "medium",
            "resolved": bool(resolved),
        }
        out.append(entry)
    return out


class CliRegistryError(ValueError):
    """Raised when the caller provides an invalid registration payload."""


def _validate(payload: dict[str, Any]) -> CliRegistryEntry:
    name = str(payload.get("name") or "").strip()
    if not _SLUG_RE.match(name):
        raise CliRegistryError(
            "invalid_name: must be 1-64 chars of [A-Za-z0-9._+-] and start with an alnum"
        )
    command = str(payload.get("command") or "").strip()
    if not command:
        raise CliRegistryError("invalid_command: required, non-empty")
    # We do NOT shutil.which() here so the user can pre-register a CLI that's
    # not installed yet; the UI surfaces `resolved: false` to warn them.
    summary = str(payload.get("summary") or "").strip()
    if len(summary) > 200:
        raise CliRegistryError("invalid_summary: max 200 chars")
    risk = str(payload.get("risk_level") or "medium").strip().lower()
    if risk not in _VALID_RISK:
        raise CliRegistryError(f"invalid_risk_level: {risk}")
    return CliRegistryEntry(
        name=name, command=command, summary=summary, risk_level=risk
    )


def register_cli(repo_root: str, payload: dict[str, Any], overwrite: bool = False) -> tuple[str, bool]:
    """Add or update one CLI entry. Returns (saved_path, created_new)."""
    entry = _validate(payload)
    items = _read_raw(repo_root)
    found_at: int | None = None
    for idx, it in enumerate(items):
        if str(it.get("name")).strip() == entry.name:
            found_at = idx
            break
    if found_at is not None and not overwrite:
        raise CliRegistryError(f"duplicate_name: {entry.name} already registered (use overwrite=true)")
    if found_at is not None:
        items[found_at] = entry.to_dict()
        created_new = False
    else:
        items.append(entry.to_dict())
        created_new = True
    path = _write_atomic(repo_root, items)
    return path, created_new


def delete_cli(repo_root: str, name: str) -> tuple[str, bool]:
    """Remove one CLI by name. Returns (saved_path, removed)."""
    target = str(name or "").strip()
    if not target:
        raise CliRegistryError("invalid_name")
    items = _read_raw(repo_root)
    new_items = [it for it in items if str(it.get("name")).strip() != target]
    removed = len(new_items) != len(items)
    path = _write_atomic(repo_root, new_items) if removed else cli_tools_path(repo_root)
    return path, removed
