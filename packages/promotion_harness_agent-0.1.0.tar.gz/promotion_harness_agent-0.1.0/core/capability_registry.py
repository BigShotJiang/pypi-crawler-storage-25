from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable
import os
import re
import shlex


_ENV_ASSIGNMENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=.*$")
_SHELL_BINARIES = {"bash", "sh", "zsh"}
_SHELL_OPERATORS = {"&&", "||", ";", "|", "<", ">", ">>"}


@dataclass(frozen=True)
class NormalizedToolCall:
    raw_kind: str | None
    normalized_kind: str
    title: str
    paths: tuple[str, ...] = ()
    command: str | None = None
    args: tuple[str, ...] = ()
    intent_family: str = "generic"
    execution_mode: str | None = None
    original_command: str | None = None
    binary: str | None = None
    uses_shell: bool = False
    is_compound: bool = False
    parse_confidence: str = "high"
    raw_input_summary: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ResolvedCapability:
    capability_name: str | None
    normalized_kind: str
    intent_family: str
    resolution_reason: str
    descriptor: "ToolDescriptor | None" = None
    policy_context: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ToolDescriptor:
    name: str
    summary: str
    kind: str
    parameters_schema: dict[str, Any] = field(default_factory=dict)
    risk_level: str = "low"
    policy_tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExecuteClassification:
    original_command: str | None
    normalized_command: str | None
    normalized_args: tuple[str, ...]
    binary: str | None
    intent_family: str
    execution_mode: str
    uses_shell: bool
    is_compound: bool
    parse_confidence: str
    python_entry: str | None = None


def _to_mapping(candidate: Any) -> dict[str, Any]:
    if isinstance(candidate, dict):
        return candidate
    if hasattr(candidate, "model_dump"):
        try:
            dumped = candidate.model_dump()
            if isinstance(dumped, dict):
                return dumped
        except Exception:
            return {}
    return {}


def _payload_get(mapping: dict[str, Any], *keys: str) -> Any:
    if not isinstance(mapping, dict):
        return None
    lowered = {str(k).lower(): v for k, v in mapping.items()}
    for key in keys:
        value = lowered.get(str(key).lower())
        if value is not None:
            return value
    return None


def _normalize_arg_list(args: Iterable[str] | None) -> tuple[str, ...]:
    return tuple(str(a) for a in (args or ()))


def _infer_kind_from_title(title: str | None) -> str | None:
    text = str(title or "").strip()
    if not text:
        return None
    lowered = text.lower()
    candidates = [lowered]
    first = lowered.split()[0] if lowered.split() else lowered
    candidates.append(first)
    for candidate in candidates:
        if candidate in {"read", "ls"}:
            return "read"
        if candidate in {"grep", "glob", "search"}:
            return "search"
        if candidate in {"write", "edit"}:
            return "edit"
        if candidate in {"move", "rename", "mv"}:
            return "move"
        if candidate in {"delete", "remove", "rm", "unlink"}:
            return "delete"
    return None


def _basename(command: str | None) -> str | None:
    text = str(command or "").strip()
    if not text:
        return None
    base = os.path.basename(text)
    return base.strip() or None


def _looks_like_env_assignment(token: str) -> bool:
    return bool(_ENV_ASSIGNMENT_RE.match(str(token or "")))


def _shell_split(command_text: str) -> tuple[list[str] | None, str | None]:
    try:
        lexer = shlex.shlex(command_text, posix=True, punctuation_chars="|&;<>")
        lexer.whitespace_split = True
        lexer.commenters = ""
        return list(lexer), None
    except ValueError as exc:
        return None, str(exc)


def _extract_env_prefixed_command(tokens: list[str]) -> tuple[tuple[str, ...], str | None, tuple[str, ...]]:
    env_tokens: list[str] = []
    idx = 0
    while idx < len(tokens) and _looks_like_env_assignment(tokens[idx]):
        env_tokens.append(tokens[idx])
        idx += 1
    if idx >= len(tokens):
        return tuple(env_tokens), None, ()
    return tuple(env_tokens), tokens[idx], tuple(tokens[idx + 1 :])


def _contains_shell_operator(tokens: Iterable[str]) -> bool:
    return any(str(token) in _SHELL_OPERATORS for token in tokens)


def _is_shell_binary(binary: str | None) -> bool:
    return str(binary or "").lower() in _SHELL_BINARIES


def _detect_python_entry(args: tuple[str, ...]) -> str | None:
    if not args:
        return None
    first = str(args[0])
    if first.startswith("tools/") or "/tools/" in first:
        return first
    lowered_args = [str(a).lower() for a in args]
    if "-m" in lowered_args:
        idx = lowered_args.index("-m")
        if idx + 1 < len(args):
            mod = str(args[idx + 1])
            if mod.startswith("tools."):
                return mod
    return None


def _direct_execute_classification(
    original_command: str | None,
    command_text: str | None,
    args: tuple[str, ...],
    *,
    parse_confidence: str = "high",
    uses_shell: bool = False,
    is_compound: bool = False,
    execution_mode: str | None = None,
) -> ExecuteClassification:
    normalized_command = str(command_text or "").strip() or None
    binary = _basename(normalized_command)
    python_entry = None
    mode = execution_mode or "direct_cli"
    intent_family = "generic"

    if binary and _is_shell_binary(binary):
        mode = "shell_wrapper"
        intent_family = "shell"
        uses_shell = True
    elif binary and str(binary).lower().startswith("python"):
        python_entry = _detect_python_entry(args)
        if python_entry:
            mode = "repo_python_script"
        intent_family = "python"

    return ExecuteClassification(
        original_command=original_command,
        normalized_command=normalized_command,
        normalized_args=args,
        binary=binary,
        intent_family=intent_family,
        execution_mode=mode if normalized_command else "unknown_execute",
        uses_shell=uses_shell,
        is_compound=is_compound,
        parse_confidence=parse_confidence,
        python_entry=python_entry,
    )


def classify_execute_call(command: str | None, args: Iterable[str] | None = None) -> ExecuteClassification:
    original_command = str(command or "").strip() or None
    normalized_args = _normalize_arg_list(args)

    if not original_command and not normalized_args:
        return ExecuteClassification(
            original_command=None,
            normalized_command=None,
            normalized_args=(),
            binary=None,
            intent_family="generic",
            execution_mode="unknown_execute",
            uses_shell=False,
            is_compound=False,
            parse_confidence="low",
        )

    if normalized_args:
        return _direct_execute_classification(original_command, original_command, normalized_args)

    if not original_command:
        return ExecuteClassification(
            original_command=None,
            normalized_command=None,
            normalized_args=normalized_args,
            binary=None,
            intent_family="generic",
            execution_mode="unknown_execute",
            uses_shell=False,
            is_compound=False,
            parse_confidence="low",
        )

    if not any(ch.isspace() for ch in original_command):
        return _direct_execute_classification(original_command, original_command, ())

    parts, _ = _shell_split(original_command)
    if parts is None:
        return ExecuteClassification(
            original_command=original_command,
            normalized_command=None,
            normalized_args=(),
            binary=None,
            intent_family="generic",
            execution_mode="unknown_execute",
            uses_shell=False,
            is_compound=False,
            parse_confidence="low",
        )

    env_assignments, executable, argv = _extract_env_prefixed_command(parts)
    if executable is None:
        return ExecuteClassification(
            original_command=original_command,
            normalized_command=None,
            normalized_args=(),
            binary=None,
            intent_family="generic",
            execution_mode="unknown_execute",
            uses_shell=False,
            is_compound=False,
            parse_confidence="low",
        )

    if _contains_shell_operator(parts):
        classification = _direct_execute_classification(
            original_command,
            executable,
            argv,
            execution_mode="compound_shell",
            uses_shell=True,
            is_compound=True,
        )
        return classification

    if env_assignments:
        return _direct_execute_classification(original_command, executable, argv)

    return _direct_execute_classification(original_command, executable, argv)


def normalize_terminal_request(command: str | None, args: Iterable[str] | None = None, cwd: str | None = None) -> NormalizedToolCall:
    execute = classify_execute_call(command, args=args)
    paths = tuple([str(cwd)] if cwd else ())
    return NormalizedToolCall(
        raw_kind="execute",
        normalized_kind="execute",
        title=str(command or "<terminal>"),
        paths=paths,
        command=execute.normalized_command,
        args=execute.normalized_args,
        intent_family=execute.intent_family,
        execution_mode=execute.execution_mode,
        original_command=execute.original_command,
        binary=execute.binary,
        uses_shell=execute.uses_shell,
        is_compound=execute.is_compound,
        parse_confidence=execute.parse_confidence,
        raw_input_summary={
            "cwd": cwd,
            "original_command": execute.original_command,
            "command": execute.normalized_command,
            "args": list(execute.normalized_args),
            "python_entry": execute.python_entry,
            "parse_confidence": execute.parse_confidence,
            "parse_mode": execute.execution_mode,
        },
    )


def normalize_tool_call(tool_call: Any, paths: Iterable[str] | None = None) -> NormalizedToolCall:
    raw_kind = getattr(tool_call, "kind", None)
    title = str(getattr(tool_call, "title", None) or getattr(tool_call, "name", None) or "<permission>")
    payload = _to_mapping(getattr(tool_call, "raw_input", None) or getattr(tool_call, "rawInput", None))

    command = _payload_get(payload, "command", "cmd")
    args = _payload_get(payload, "args", "arguments") or []
    if isinstance(args, str):
        args = [args]

    execute = classify_execute_call(str(command) if command is not None else None, args=args)

    normalized_kind = str(raw_kind).lower() if raw_kind else "unknown"
    allowed_kinds = {"read", "search", "edit", "move", "delete", "execute", "mcp", "skill"}
    if normalized_kind not in allowed_kinds:
        normalized_kind = "unknown"
    if command is not None:
        normalized_kind = "execute"
    elif normalized_kind == "unknown":
        inferred_kind = _infer_kind_from_title(title)
        if inferred_kind in allowed_kinds:
            normalized_kind = inferred_kind

    return NormalizedToolCall(
        raw_kind=str(raw_kind).lower() if raw_kind else None,
        normalized_kind=normalized_kind,
        title=title,
        paths=tuple(str(p) for p in (paths or ())),
        command=execute.normalized_command,
        args=execute.normalized_args,
        intent_family=execute.intent_family,
        execution_mode=execute.execution_mode if normalized_kind == "execute" else None,
        original_command=execute.original_command if normalized_kind == "execute" else None,
        binary=execute.binary if normalized_kind == "execute" else None,
        uses_shell=execute.uses_shell if normalized_kind == "execute" else False,
        is_compound=execute.is_compound if normalized_kind == "execute" else False,
        parse_confidence=execute.parse_confidence if normalized_kind == "execute" else "high",
        raw_input_summary={
            **payload,
            "normalized_command": execute.normalized_command,
            "normalized_args": list(execute.normalized_args),
            "parse_mode": execute.execution_mode,
            "parse_confidence": execute.parse_confidence,
            "python_entry": execute.python_entry,
        },
    )


def suggest_tool_name(kind: str | None) -> str:
    if not kind:
        return "unknown"
    k = str(kind).lower()
    if k in {"read", "search"}:
        return "fs.read"
    if k in {"edit", "move", "delete"}:
        return "fs.write"
    if k == "execute":
        return "terminal.cli"
    return "unknown"


def resolve_capability(
    registry: "CapabilityRegistry",
    normalized_call: NormalizedToolCall,
) -> ResolvedCapability:
    cwd = normalized_call.paths[0] if normalized_call.paths else None
    policy_context: dict[str, Any] = {
        "raw_kind": normalized_call.raw_kind,
        "normalized_kind": normalized_call.normalized_kind,
        "intent_family": normalized_call.intent_family,
        "execution_mode": normalized_call.execution_mode,
        "original_command": normalized_call.original_command,
        "command": normalized_call.command,
        "args": list(normalized_call.args),
        "binary": normalized_call.binary,
        "cwd": cwd,
        "uses_shell": normalized_call.uses_shell,
        "is_compound": normalized_call.is_compound,
        "parse_confidence": normalized_call.parse_confidence,
    }
    python_entry = normalized_call.raw_input_summary.get("python_entry")
    if python_entry:
        policy_context["python_entry"] = python_entry

    if normalized_call.normalized_kind in {"read", "search"}:
        name = "fs.read"
        return ResolvedCapability(name, normalized_call.normalized_kind, normalized_call.intent_family, "kind_mapping", registry.get(name), policy_context=policy_context)
    if normalized_call.normalized_kind in {"edit", "move", "delete"}:
        name = "fs.write"
        return ResolvedCapability(name, normalized_call.normalized_kind, normalized_call.intent_family, "kind_mapping", registry.get(name), policy_context=policy_context)
    if normalized_call.normalized_kind == "execute":
        if normalized_call.execution_mode == "repo_python_script":
            name = "tool.py_script"
        elif normalized_call.execution_mode in {"shell_wrapper", "compound_shell"}:
            name = "terminal.bash"
        elif normalized_call.execution_mode == "direct_cli":
            name = "terminal.cli"
        else:
            return ResolvedCapability(None, normalized_call.normalized_kind, normalized_call.intent_family, "unclassified_execute", None, policy_context=policy_context)

        descriptor = registry.get(name)
        if descriptor is not None:
            return ResolvedCapability(name, normalized_call.normalized_kind, normalized_call.intent_family, "execute_family_mapping", descriptor, policy_context=policy_context)
        return ResolvedCapability(None, normalized_call.normalized_kind, normalized_call.intent_family, "unclassified_execute", None, policy_context=policy_context)
    if normalized_call.normalized_kind == "mcp":
        name = "tool.mcp"
        descriptor = registry.get(name)
        policy_context["raw_input"] = dict(normalized_call.raw_input_summary or {})
        if descriptor is not None:
            return ResolvedCapability(name, normalized_call.normalized_kind, normalized_call.intent_family, "kind_mapping", descriptor, policy_context=policy_context)
        return ResolvedCapability(None, normalized_call.normalized_kind, normalized_call.intent_family, "unclassified_mcp", None, policy_context=policy_context)
    if normalized_call.normalized_kind == "skill":
        name = "tool.skill"
        descriptor = registry.get(name)
        policy_context["raw_input"] = dict(normalized_call.raw_input_summary or {})
        if descriptor is not None:
            return ResolvedCapability(name, normalized_call.normalized_kind, normalized_call.intent_family, "kind_mapping", descriptor, policy_context=policy_context)
        return ResolvedCapability(None, normalized_call.normalized_kind, normalized_call.intent_family, "unclassified_skill", None, policy_context=policy_context)
    return ResolvedCapability(None, normalized_call.normalized_kind, normalized_call.intent_family, "unknown_kind", None)


def evaluate_policy(
    descriptor: ToolDescriptor | None,
    stage: str | None,
    kind: str | None,
    paths: list[str],
    workspace_root: str | None,
    *,
    allow_high_risk: bool = False,
) -> tuple[bool, str]:
    if kind in {"execute", "mcp", "skill"} and descriptor is None:
        return False, f"unknown_{kind}_capability"
    if descriptor and descriptor.risk_level == "high" and not allow_high_risk:
        return False, "high_risk_default_deny"
    if descriptor and "workspace_only" in descriptor.policy_tags:
        if not workspace_root:
            return False, "missing_workspace_root"
        from core.sandbox_policy import _is_within as _within
        for p in paths:
            if not _within(p, workspace_root):
                return False, "outside_workspace"
        if not paths and kind in {"edit", "move", "delete"}:
            return False, "missing_paths_for_write"
    return True, "allowed"


class CapabilityRegistry:
    def __init__(self):
        self._tools: dict[str, ToolDescriptor] = {}

    def register(self, descriptor: ToolDescriptor) -> None:
        self._tools[descriptor.name] = descriptor

    def get(self, name: str | None) -> ToolDescriptor | None:
        if not name:
            return None
        return self._tools.get(name)

    def list_all(self) -> list[ToolDescriptor]:
        return list(self._tools.values())

    def list_for_stage(self, stage: str) -> list[ToolDescriptor]:
        del stage
        return sorted(self._tools.values(), key=lambda t: t.name)

    def advertise_for_stage(self, stage: str) -> tuple[str, dict[str, Any]]:
        tools = self.list_for_stage(stage)
        lines = ["## Available Capabilities (this stage)", ""]
        for t in tools:
            lines.append(f"- {t.name} ({t.kind}, risk={t.risk_level}): {t.summary}")
        lines.append("")
        lines.append("Constraints:")
        lines.append("- Repo sandbox applies; do not modify files outside the target repository root")
        lines.append("- Do not output secrets or credentials")
        md = "\n".join(lines).strip() + "\n"
        payload = {
            "stage": stage,
            "tools": [
                {
                    "name": t.name,
                    "kind": t.kind,
                    "risk_level": t.risk_level,
                    "policy_tags": list(t.policy_tags),
                    "summary": t.summary,
                }
                for t in tools
            ],
        }
        return md, payload


def default_registry() -> CapabilityRegistry:
    r = CapabilityRegistry()
    r.register(ToolDescriptor(
        name="fs.read",
        summary="Read a file within the sandboxed workspace (ACP fs.readTextFile).",
        kind="read",
        risk_level="low",
        policy_tags=("workspace_only",),
    ))
    r.register(ToolDescriptor(
        name="fs.write",
        summary="Write a file within the sandboxed workspace (ACP fs.writeTextFile / file edit tools).",
        kind="edit",
        risk_level="medium",
        policy_tags=("workspace_only",),
    ))
    r.register(ToolDescriptor(
        name="terminal.cli",
        summary="Execute a bounded direct CLI command within the sandboxed workspace.",
        kind="execute",
        risk_level="medium",
        policy_tags=("workspace_only",),
    ))
    r.register(ToolDescriptor(
        name="terminal.bash",
        summary="Execute shell-backed commands within the sandboxed workspace (bash/sh/zsh).",
        kind="execute",
        risk_level="high",
        policy_tags=("workspace_only",),
    ))
    r.register(ToolDescriptor(
        name="tool.py_script",
        summary="Run repo-controlled python scripts/modules when a stage explicitly depends on them.",
        kind="execute",
        risk_level="low",
        policy_tags=("workspace_only",),
    ))
    r.register(ToolDescriptor(
        name="tool.mcp",
        summary="Call session-injected MCP tools (governed as a single family).",
        kind="execute",
        risk_level="medium",
    ))
    r.register(ToolDescriptor(
        name="tool.skill",
        summary="Invoke orchestration-layer skills (governed as a single family).",
        kind="execute",
        risk_level="medium",
    ))
    return r
