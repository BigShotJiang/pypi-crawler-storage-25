from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from core.stage_tool_config import (
    _atomic_write_json,
    enabled_tool_ids_for_stage,
    ensure_user_stage_tool_config_seeded,
    load_stage_tool_config,
)
from core.tool_catalog import build_tool_catalog_payload


SCHEMA_VERSION = 2
SUPPORTED_POLICY_STAGES: tuple[str, ...] = (
    "PRD_DRAFTING",
    "TECH_SPEC_DRAFTING",
    "CODING",
    "QUALITY_LOOP",
    "DEPLOYING",
    "REGRESSION_TESTING",
)


_BUILTIN_DEFAULT_POLICIES: dict[str, dict[str, Any]] = {
    "CODING": {
        "rules": [
            {"use_tool_id": "cli:bytedcli", "do": "优先阅读仓库结构、代码库状态和研发工作流上下文，再开始实现。"},
            {"use_tool_id": "skill:bam", "do": "优先阅读上下游接口、协议和相关背景文档，补齐编码实现所需上下文。"},
            {"use_tool_id": "bash:shell", "do": "在开始编码前创建分支，并在完成实现后提交 commit、push 到远程分支。"},
            {"use_tool_id": "skill:codebase-cli", "do": "在代码改动完成后，通过仓库工作流能力创建 MR，并确认 MR 链接可回填到输出中。"},
        ],
        "output_requirements": "输出必须包含：1）本次改动说明；2）changed_files 列表；3）branch_name；4）commit_sha；5）mr_url；6）若任一字段缺失，明确说明原因，不要伪造。",
        "tool_instructions": "进入 CODING 后，要把上下文层与 Agent 执行要求一起落实：先阅读仓库，再阅读上下游接口/协议文档；随后通过 ACP 工具完成代码修改。CODING 阶段不要编写单测。对于大型 Go 仓库，不要主动执行 gofmt、go test、go build 等高耗时命令作为默认步骤，除非用户明确要求或当前任务非跑不可；优先通过最小改动和结构化交付完成本阶段。最终输出中必须明确给出改动说明、分支名、commit 序号和 MR 链接；若外部能力不可用、鉴权失败、创建 MR 失败或链接不可读，必须显式说明，不要假设成功。",
    },
    "QUALITY_LOOP": {
        "rules": [
            {"use_tool_id": "cli:bytedcli", "do": "优先阅读仓库结构、代码库状态和研发工作流上下文，再开始补齐质量闭环。"},
            {"use_tool_id": "skill:bam", "do": "优先阅读上下游接口、协议和相关背景文档，补齐测试设计所需上下文。"},
            {"use_tool_id": "skill:bits-unit-test-gen", "do": "基于当前代码与需求补齐单测，优先生成能够覆盖本次改动的测试。"},
            {"use_tool_id": "skill:remote-ci-ut", "do": "远程执行单测，优先沉淀 MR 关联单测的执行结果、覆盖率和失败信息。"},
            {"use_tool_id": "bash:shell", "do": "在质量闭环补齐完成后提交 commit，并 push 到远程分支。"},
        ],
        "output_requirements": "输出必须包含：1）本次测试相关改动说明；2）changed_files 列表；3）branch_name；4）commit_sha；5）mr_url；6）若任一字段缺失，明确说明原因，不要伪造。",
        "tool_instructions": "进入 QUALITY_LOOP 后，要把上下文层与 Agent 执行要求一起落实。对于大型 Go 仓库，不要主动执行 gofmt、go test、go build 等高耗时本地命令作为默认步骤，除非用户明确要求或当前任务非跑不可；优先基于已有交付、最小修复和结构化质量报告推进闭环。最终输出中必须明确给出改动说明、分支名、commit 序号和 MR 链接；若外部能力不可用、鉴权失败、远程执行失败、覆盖率无法读取、执行状态无法读取或链接不可读，必须显式说明，不要假设成功。",
    },
    "DEPLOYING": {
        "rules": [
            {"use_tool_id": "skill:codebase-cli", "do": "优先读取远程仓库，重点确认当前远程分支状态；若无法直接读取，再退回同类仓库工作流能力继续核对。"},
            {"use_tool_id": "skill:codebase-cli", "do": "优先读取当前产出关联的 MR 信息，补齐部署前所需的提交、分支与合入上下文；若无法直接读取，再退回同类仓库工作流能力继续核对。"},
            {"use_tool_id": "skill:bits-env", "do": "将当前分支部署到 BOE 或 PPE，泳道命名为 分支名_harness_deploy；若无法直接完成，再退回同类研发工作流能力继续处理。"},
        ],
        "output_requirements": "输出必须包含：1）env_name；2）env_url；3）branch_name；4）psm；5）若部署目标为 BOE 或 PPE，明确记录实际目标环境；6）若任一字段缺失、链接不可用或部署失败，明确说明原因，不要伪造。",
        "tool_instructions": "进入 DEPLOYING 后，要把上下文层与 Agent 执行要求一起落实。先读取远程仓库和 MR，再执行部署；部署目标应为 BOE 或 PPE，泳道命名使用 分支名_harness_deploy。若 bits-env 不可用，可退回 bytedcli 或同类仓库工作流能力，但必须显式说明 fallback 路径与失败原因。最终输出中必须明确给出环境名、环境链接、分支名和 psm，不要省略。",
    },
    "REGRESSION_TESTING": {
        "rules": [
            {"use_tool_id": "skill:codebase-cli", "do": "优先读取当前远程分支、MR 和交付上下文，确认回归结果能关联到当前分支与交付。"},
            {"use_tool_id": "skill:bits-env", "do": "优先读取已部署环境信息，确认 env_name / env_url 与 Deploying 阶段沉淀的环境一致，并在该环境上执行回归验证。"},
        ],
        "output_requirements": "输出必须包含：1）env_name；2）env_url；3）branch_name；4）test_cases；5）results 或 endpoint_results；6）final_verdict；7）若任一字段缺失、链接不可读、鉴权失败或回归失败，明确说明原因，不要伪造。",
        "tool_instructions": "进入 REGRESSION_TESTING 后，必须先确认 Deploying 阶段沉淀的环境信息，再针对已部署环境执行接口级回归，不要退化为本地单测。若 bits-env 或其他远端能力不可用，必须显式说明 fallback 路径与失败原因；若发生授权阻塞，按 auth_block 协议写出 auth_block.json。",
    },
}


class StageContextPolicyValidationError(ValueError):
    def __init__(self, errors: list[str]):
        self.errors = [str(error).strip() for error in errors if str(error).strip()]
        super().__init__("; ".join(self.errors) if self.errors else "invalid_stage_context_policy")


@dataclass(frozen=True)
class StageContextPolicyConfig:
    schema_version: int
    policies: dict[str, dict[str, Any]]
    source: str
    sources: dict[str, str]


def repo_policy_config_path(repo_root: str) -> str:
    return os.path.join(repo_root, ".harness", "stage_context_policy.json")


def policy_config_path() -> str:
    return os.path.join(os.path.expanduser("~"), ".harness", "stage_context_policy.json")


def stage_supports_context_policy(stage: str | None) -> bool:
    return str(stage or "").strip() in SUPPORTED_POLICY_STAGES


def _read_json(path: str) -> dict[str, Any] | None:
    if not path or not os.path.exists(path):
        return None
    try:
        import json

        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _normalize_rule(raw: Any) -> dict[str, str]:
    if not isinstance(raw, dict):
        return {"use_tool_id": "", "do": ""}
    return {
        "use_tool_id": str(raw.get("use_tool_id") or "").strip(),
        "do": str(raw.get("do") or "").strip(),
    }


def _empty_policy_entry() -> dict[str, Any]:
    return {
        "rules": [],
        "output_requirements": "",
        "tool_instructions": "",
    }


def _normalize_policy_entry(raw: Any) -> dict[str, Any]:
    if isinstance(raw, list):
        return {
            "rules": [_normalize_rule(item) for item in raw],
            "output_requirements": "",
            "tool_instructions": "",
        }
    if not isinstance(raw, dict):
        return _empty_policy_entry()
    rules = raw.get("rules")
    return {
        "rules": [_normalize_rule(item) for item in rules] if isinstance(rules, list) else [],
        "output_requirements": str(raw.get("output_requirements") or "").strip(),
        "tool_instructions": str(raw.get("tool_instructions") or "").strip(),
    }


def _normalize_policies(raw: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(raw, dict):
        return {}
    out: dict[str, dict[str, Any]] = {}
    for key, value in raw.items():
        stage = str(key or "").strip()
        if not stage:
            continue
        out[stage] = _normalize_policy_entry(value)
    return out


def _merge_stage_policies(repo_policies: dict[str, dict[str, Any]], user_policies: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    merged = dict(repo_policies)
    merged.update(user_policies)
    return merged


def load_stage_context_policy(repo_root: str | None = None) -> StageContextPolicyConfig:
    user_path = policy_config_path()
    repo_path = repo_policy_config_path(repo_root) if repo_root else ""
    repo_data = _read_json(repo_path) or {}
    user_data = _read_json(user_path) or {}
    repo_policies = _normalize_policies(repo_data.get("policies"))
    user_policies = _normalize_policies(user_data.get("policies"))
    return StageContextPolicyConfig(
        schema_version=int(user_data.get("schema_version") or repo_data.get("schema_version") or SCHEMA_VERSION),
        policies=_merge_stage_policies(repo_policies, user_policies),
        source=user_path,
        sources={"repo": repo_path, "user": user_path},
    )


def default_stage_context_policy(repo_root: str, stage: str) -> dict[str, Any]:
    normalized_stage = str(stage or "").strip()
    repo_data = _read_json(repo_policy_config_path(repo_root)) or {}
    repo_policies = _normalize_policies(repo_data.get("policies"))
    repo_entry = repo_policies.get(normalized_stage)
    if isinstance(repo_entry, dict) and any(repo_entry.values()):
        return _normalize_policy_entry(repo_entry)
    builtin_entry = _BUILTIN_DEFAULT_POLICIES.get(normalized_stage)
    if isinstance(builtin_entry, dict):
        return _normalize_policy_entry(builtin_entry)
    return _normalize_policy_entry(repo_entry or {})


def build_default_repo_stage_context_policy_payload() -> dict[str, Any]:
    policies: dict[str, dict[str, Any]] = {}
    for stage in SUPPORTED_POLICY_STAGES:
        builtin_entry = _BUILTIN_DEFAULT_POLICIES.get(stage)
        policies[stage] = _normalize_policy_entry(builtin_entry) if isinstance(builtin_entry, dict) else _empty_policy_entry()
    return {
        "schema_version": SCHEMA_VERSION,
        "policies": policies,
    }


def ensure_user_stage_context_policy_seeded(repo_root: str, stage: str = "CODING") -> tuple[str, bool]:
    normalized_stage = str(stage or "").strip()
    path = policy_config_path()
    raw_user = _read_json(path) or {}
    raw_user_policies = raw_user.get("policies") if isinstance(raw_user.get("policies"), dict) else {}
    if normalized_stage in raw_user_policies:
        return path, False
    default_entry = default_stage_context_policy(repo_root, normalized_stage)
    if not any(default_entry.values()):
        return path, False
    policies = _normalize_policies(raw_user_policies)
    policies[normalized_stage] = default_entry
    _atomic_write_json(path, {"schema_version": SCHEMA_VERSION, "policies": policies})
    return path, True


def reset_stage_context_policy_to_defaults(repo_root: str, stage: str = "CODING") -> StageContextPolicyConfig:
    normalized_stage = str(stage or "").strip()
    raw_user = _read_json(policy_config_path()) or {}
    raw_user_policies = raw_user.get("policies") if isinstance(raw_user.get("policies"), dict) else {}
    policies = _normalize_policies(raw_user_policies)
    default_entry = default_stage_context_policy(repo_root, normalized_stage)
    if not any(default_entry.values()):
        policies.pop(normalized_stage, None)
    else:
        policies[normalized_stage] = default_entry
    _atomic_write_json(policy_config_path(), {"schema_version": SCHEMA_VERSION, "policies": policies})
    return load_stage_context_policy(repo_root)


def get_stage_policy_rules(config: StageContextPolicyConfig, stage: str | None) -> list[dict[str, str]]:
    if not stage:
        return []
    policy = config.policies.get(str(stage), {})
    rules = policy.get("rules") if isinstance(policy, dict) else []
    if not isinstance(rules, list):
        return []
    return [dict(item) for item in rules if isinstance(item, dict)]


def get_stage_output_requirements(config: StageContextPolicyConfig, stage: str | None) -> str:
    if not stage:
        return ""
    policy = config.policies.get(str(stage), {})
    if not isinstance(policy, dict):
        return ""
    return str(policy.get("output_requirements") or "").strip()


def get_stage_tool_instructions(config: StageContextPolicyConfig, stage: str | None) -> str:
    if not stage:
        return ""
    policy = config.policies.get(str(stage), {})
    if not isinstance(policy, dict):
        return ""
    return str(policy.get("tool_instructions") or "").strip()


def _effective_tool_choices(repo_root: str, stage: str) -> tuple[list[dict[str, Any]], set[str]]:
    ensure_user_stage_tool_config_seeded(repo_root)
    tool_payload = build_tool_catalog_payload(stage=stage, workspace_root=repo_root)
    stage_cfg = load_stage_tool_config(repo_root)
    enabled_tool_ids = enabled_tool_ids_for_stage(stage_cfg, stage) or set()

    entries: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in tool_payload.get("entries") or []:
        if not isinstance(entry, dict):
            continue
        tool_id = str(entry.get("tool_id") or "").strip()
        if not tool_id or tool_id in seen or tool_id not in enabled_tool_ids:
            continue
        seen.add(tool_id)
        entries.append(
            {
                "tool_id": tool_id,
                "name": str(entry.get("name") or "").strip(),
                "type": str(entry.get("type") or "").strip(),
                "layer": str(entry.get("layer") or "").strip(),
                "summary": str(entry.get("summary") or "").strip(),
                "risk_level": str(entry.get("risk_level") or "").strip(),
                "source": str(entry.get("source") or "").strip(),
            }
        )
    return entries, enabled_tool_ids


def list_effective_stage_policy_tools(repo_root: str, stage: str) -> list[dict[str, Any]]:
    entries, _ = _effective_tool_choices(repo_root, stage)
    return entries


def validate_stage_policy_rules(repo_root: str, stage: str, rules: Any) -> list[dict[str, str]]:
    normalized_stage = str(stage or "").strip()
    errors: list[str] = []
    if not normalized_stage:
        errors.append("stage is required")
    elif not stage_supports_context_policy(normalized_stage):
        errors.append(f"stage {normalized_stage} does not support context policy in this version")

    if not isinstance(rules, list):
        errors.append("rules must be a list")
        raise StageContextPolicyValidationError(errors)

    normalized_rules = [_normalize_rule(rule) for rule in rules]
    tool_choices, enabled_tool_ids = _effective_tool_choices(repo_root, normalized_stage) if normalized_stage else ([], set())
    allowed_tool_ids = {str(item.get("tool_id") or "").strip() for item in tool_choices if isinstance(item, dict)}

    for idx, rule in enumerate(normalized_rules, start=1):
        tool_id = rule["use_tool_id"]
        do_text = rule["do"]
        if not tool_id:
            errors.append(f"rule {idx}: use_tool_id is required")
        elif tool_id not in allowed_tool_ids:
            if enabled_tool_ids:
                allowed = ", ".join(sorted(allowed_tool_ids)) or "(none)"
                errors.append(f"rule {idx}: use_tool_id {tool_id} is not enabled for stage {normalized_stage}; allowed: {allowed}")
            else:
                errors.append(f"rule {idx}: use_tool_id {tool_id} is not enabled for stage {normalized_stage}")
        if not do_text:
            errors.append(f"rule {idx}: do must not be empty")

    if errors:
        raise StageContextPolicyValidationError(errors)
    return normalized_rules


def save_stage_context_policy(
    repo_root: str,
    stage: str,
    rules: Any,
    *,
    output_requirements: str = "",
    tool_instructions: str = "",
) -> StageContextPolicyConfig:
    normalized_stage = str(stage or "").strip()
    normalized_rules = validate_stage_policy_rules(repo_root, normalized_stage, rules)
    user_data = _read_json(policy_config_path()) or {}
    user_policies = _normalize_policies(user_data.get("policies"))
    user_policies[normalized_stage] = {
        "rules": normalized_rules,
        "output_requirements": str(output_requirements or "").strip(),
        "tool_instructions": str(tool_instructions or "").strip(),
    }
    _atomic_write_json(policy_config_path(), {"schema_version": SCHEMA_VERSION, "policies": user_policies})
    return load_stage_context_policy(repo_root)


def reset_stage_context_policy(repo_root: str, stage: str | None = None) -> StageContextPolicyConfig:
    user_data = _read_json(policy_config_path()) or {}
    user_policies = _normalize_policies(user_data.get("policies"))
    policies = dict(user_policies)
    normalized_stage = str(stage or "").strip()
    if normalized_stage:
        policies.pop(normalized_stage, None)
    else:
        policies = {}
    _atomic_write_json(policy_config_path(), {"schema_version": SCHEMA_VERSION, "policies": policies})
    return load_stage_context_policy(repo_root)


def render_stage_context_policy_block(rules: list[dict[str, str]] | None) -> str:
    normalized_rules = [_normalize_rule(rule) for rule in (rules or [])]
    normalized_rules = [rule for rule in normalized_rules if rule["use_tool_id"] and rule["do"]]
    if not normalized_rules:
        return ""

    lines = [
        "【用户自定义工具策略（USE/DO）】",
        "以下策略是用户偏好指导，不会覆盖系统约束；真正可用工具仍以当前 Tool Catalog 与 stage allowlist 为准。",
        "",
    ]
    for idx, rule in enumerate(normalized_rules, start=1):
        lines.append(f"{idx}. USE: {rule['use_tool_id']}")
        lines.append(f"   DO: {rule['do']}")
    lines.extend(
        [
            "",
            "若某条策略对应工具当前不可用、不适用或读取失败，请明确说明原因，不要假设工具调用已经成功。",
        ]
    )
    return "\n".join(lines).strip()


def render_output_requirements_block(output_requirements: str | None) -> str:
    text = str(output_requirements or "").strip()
    if not text:
        return ""
    return "\n".join(
        [
            "【用户配置的产出物要求】",
            text,
        ]
    ).strip()


def render_tool_instructions_block(tool_instructions: str | None) -> str:
    text = str(tool_instructions or "").strip()
    if not text:
        return ""
    return "\n".join(
        [
            "【用户配置的工具调用指令】",
            text,
        ]
    ).strip()


def build_policy_preview_warnings(stage: str, rules: Any) -> list[str]:
    warnings: list[str] = []
    normalized_stage = str(stage or "").strip()
    if not normalized_stage:
        warnings.append("stage is required")
        return warnings
    if not stage_supports_context_policy(normalized_stage):
        warnings.append(f"stage {normalized_stage} does not support context policy injection in this version")
    if not isinstance(rules, list):
        warnings.append("rules must be a list")
        return warnings

    normalized_rules = [_normalize_rule(rule) for rule in rules]
    if len(normalized_rules) > 12:
        warnings.append("policy has more than 12 rules; keep it short so the stage prompt stays focused")
    total_chars = sum(len(rule["do"]) for rule in normalized_rules)
    if total_chars > 1200:
        warnings.append("policy DO text is long; consider shortening it to reduce prompt bloat")
    for idx, rule in enumerate(normalized_rules, start=1):
        if not rule["use_tool_id"]:
            warnings.append(f"rule {idx} is missing use_tool_id")
        if not rule["do"]:
            warnings.append(f"rule {idx} has empty do text")
    return warnings
