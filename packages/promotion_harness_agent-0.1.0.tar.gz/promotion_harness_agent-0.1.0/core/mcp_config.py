from __future__ import annotations

import json
import logging
import os
import shutil
from dataclasses import dataclass
from typing import Any, Literal

from acp.schema import EnvVariable, HttpHeader, HttpMcpServer, McpServerStdio, SseMcpServer

from core.run_trace import append_event

logger = logging.getLogger(__name__)

McpServer = HttpMcpServer | SseMcpServer | McpServerStdio
SourceKind = Literal["env", "file", "repo", "user"]


@dataclass(frozen=True)
class McpConfigSource:
    kind: SourceKind
    path: str | None = None


@dataclass
class _Merged:
    servers_by_name: dict[str, McpServer]
    source_by_name: dict[str, SourceKind]
    stages: dict[str, list[str]] | None
    sources_loaded: list[McpConfigSource]
    overridden: list[dict[str, Any]]
    skipped: list[dict[str, Any]]
    warnings: list[str]


def _substitute_workspace_vars(val: Any, workspace_folder: str) -> Any:
    if isinstance(val, str):
        return val.replace("${workspaceFolder}", workspace_folder)
    if isinstance(val, list):
        return [_substitute_workspace_vars(v, workspace_folder) for v in val]
    if isinstance(val, dict):
        return {k: _substitute_workspace_vars(v, workspace_folder) for k, v in val.items()}
    return val


def _coerce_headers(value: Any) -> list[HttpHeader]:
    if value is None:
        return []
    if isinstance(value, dict):
        return [HttpHeader(name=str(k), value=str(v)) for k, v in value.items()]
    if isinstance(value, list):
        headers: list[HttpHeader] = []
        for item in value:
            if isinstance(item, HttpHeader):
                headers.append(item)
                continue
            if isinstance(item, dict):
                name = item.get("name")
                val = item.get("value")
                if name is not None and val is not None:
                    headers.append(HttpHeader(name=str(name), value=str(val)))
        return headers
    return []


def _coerce_env(value: Any) -> list[EnvVariable]:
    if value is None:
        return []
    if isinstance(value, dict):
        return [EnvVariable(name=str(k), value=str(v)) for k, v in value.items()]
    if isinstance(value, list):
        envs: list[EnvVariable] = []
        for item in value:
            if isinstance(item, EnvVariable):
                envs.append(item)
                continue
            if isinstance(item, dict):
                name = item.get("name")
                val = item.get("value")
                if name is not None and val is not None:
                    envs.append(EnvVariable(name=str(name), value=str(val)))
        return envs
    return []


def _resolve_stdio_command(command: str) -> str | None:
    candidate = str(command or "").strip()
    if not candidate:
        return None
    if os.path.isabs(candidate):
        return os.path.realpath(candidate)
    resolved = shutil.which(candidate)
    if not resolved:
        return None
    return os.path.realpath(resolved)


def _discover_sources(workspace_folder: str) -> list[McpConfigSource]:
    sources: list[McpConfigSource] = [McpConfigSource(kind="env")]

    explicit = str(os.environ.get("HARNESS_MCP_CONFIG_PATH") or "").strip()
    if explicit:
        path = explicit
        if not os.path.isabs(path):
            path = os.path.join(workspace_folder, path)
        sources.append(McpConfigSource(kind="file", path=os.path.abspath(path)))

    repo_path = os.path.join(workspace_folder, ".harness", "mcp.json")
    sources.append(McpConfigSource(kind="repo", path=os.path.abspath(repo_path)))

    user_path = os.path.expanduser("~/.harness/mcp.json")
    sources.append(McpConfigSource(kind="user", path=os.path.abspath(user_path)))

    return sources


def _read_json_file(path: str) -> Any | None:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None
    except Exception:
        return None


def _parse_env_servers(stage: str | None, workspace_folder: str, merged: _Merged) -> None:
    raw = os.environ.get("HARNESS_MCP_SERVERS_BY_STAGE_JSON")
    if raw:
        try:
            by_stage = json.loads(raw)
        except Exception:
            by_stage = None
        if isinstance(by_stage, dict) and stage and stage in by_stage:
            raw = json.dumps(by_stage.get(stage))
        else:
            raw = None
    if not raw:
        raw = os.environ.get("HARNESS_MCP_SERVERS_JSON")
    if not raw:
        return
    try:
        data = json.loads(raw)
    except Exception:
        merged.sources_loaded.append(McpConfigSource(kind="env"))
        merged.skipped.append({"source": "env", "name": None, "reason": "invalid_json"})
        return
    if not isinstance(data, list):
        merged.sources_loaded.append(McpConfigSource(kind="env"))
        merged.skipped.append({"source": "env", "name": None, "reason": "expected_list"})
        return
    merged.sources_loaded.append(McpConfigSource(kind="env"))
    for item in data:
        if not isinstance(item, dict):
            merged.skipped.append({"source": "env", "name": None, "reason": "invalid_item"})
            continue
        item = _substitute_workspace_vars(item, workspace_folder)
        name = str(item.get("name") or "").strip()
        if not name:
            merged.skipped.append({"source": "env", "name": None, "reason": "missing_name"})
            continue
        server = _normalize_server(name=name, payload=item, workspace_folder=workspace_folder, merged=merged, source="env")
        if server is None:
            continue
        _merge_server(merged, name=name, server=server, source="env")


def _extract_map_config(raw: Any, merged: _Merged, source: str) -> tuple[dict[str, Any] | None, dict[str, list[str]] | None]:
    if isinstance(raw, dict):
        mcp_servers = raw.get("mcpServers")
        stages_raw = raw.get("stages")
        stages: dict[str, list[str]] | None = None
        if isinstance(stages_raw, dict):
            stages = {}
            for k, v in stages_raw.items():
                if isinstance(v, list):
                    stages[str(k)] = [str(x) for x in v if str(x).strip()]
        if isinstance(mcp_servers, dict):
            return mcp_servers, stages
        return None, stages
    if isinstance(raw, list):
        mapped: dict[str, Any] = {}
        for item in raw:
            if not isinstance(item, dict):
                merged.skipped.append({"source": source, "name": None, "reason": "invalid_item"})
                continue
            name = str(item.get("name") or "").strip()
            if not name:
                merged.skipped.append({"source": source, "name": None, "reason": "missing_name"})
                continue
            mapped[name] = item
        return mapped or None, None
    return None, None


def _parse_file_config(path: str, workspace_folder: str, merged: _Merged, kind: SourceKind) -> None:
    raw = _read_json_file(path)
    if raw is None:
        return
    mcp_servers, stages = _extract_map_config(raw, merged=merged, source=kind)
    if mcp_servers is None and stages is None:
        merged.skipped.append({"source": kind, "name": None, "reason": "invalid_schema"})
        merged.sources_loaded.append(McpConfigSource(kind=kind, path=path))
        return

    merged.sources_loaded.append(McpConfigSource(kind=kind, path=path))
    if stages is not None:
        if merged.stages is None:
            merged.stages = {}
        for k, v in stages.items():
            if k not in merged.stages:
                merged.stages[k] = v

    if mcp_servers is None:
        return

    for name, payload in mcp_servers.items():
        if not isinstance(payload, dict):
            merged.skipped.append({"source": kind, "name": str(name), "reason": "invalid_definition"})
            continue
        payload = _substitute_workspace_vars(payload, workspace_folder)
        server = _normalize_server(name=str(name), payload=payload, workspace_folder=workspace_folder, merged=merged, source=kind)
        if server is None:
            continue
        _merge_server(merged, name=str(name), server=server, source=kind)


def _normalize_server(name: str, payload: dict[str, Any], workspace_folder: str, merged: _Merged, source: str) -> McpServer | None:
    t = str(payload.get("type") or "").lower().strip()
    if t == "http":
        url = str(payload.get("url") or "").strip()
        if not url:
            merged.skipped.append({"source": source, "name": name, "reason": "missing_url"})
            return None
        return HttpMcpServer(name=name, url=url, type="http", headers=_coerce_headers(payload.get("headers")))
    if t == "sse":
        url = str(payload.get("url") or "").strip()
        if not url:
            merged.skipped.append({"source": source, "name": name, "reason": "missing_url"})
            return None
        return SseMcpServer(name=name, url=url, type="sse", headers=_coerce_headers(payload.get("headers")))
    if t == "stdio":
        command = str(payload.get("command") or "").strip()
        if not command:
            merged.skipped.append({"source": source, "name": name, "reason": "missing_command"})
            return None
        resolved_command = _resolve_stdio_command(command)
        if not resolved_command:
            merged.skipped.append({"source": source, "name": name, "reason": "stdio_command_not_resolvable"})
            return None
        args = payload.get("args") or []
        if not isinstance(args, list):
            args = []
        return McpServerStdio(
            name=name,
            command=resolved_command,
            args=[str(a) for a in args],
            env=_coerce_env(payload.get("env")),
        )
    merged.skipped.append({"source": source, "name": name, "reason": "unsupported_type"})
    return None


def _endpoint_key(server: McpServer) -> tuple[Any, ...] | None:
    if isinstance(server, HttpMcpServer):
        return ("http", server.url)
    if isinstance(server, SseMcpServer):
        return ("sse", server.url)
    if isinstance(server, McpServerStdio):
        return ("stdio", server.command, tuple(server.args or []))
    return None


def _merge_server(merged: _Merged, name: str, server: McpServer, source: SourceKind) -> None:
    kind = source
    existing = merged.servers_by_name.get(name)
    if existing is not None:
        merged.overridden.append({"name": name, "kept_source": merged.source_by_name.get(name), "dropped_source": kind})
        return
    merged.servers_by_name[name] = server
    merged.source_by_name[name] = kind


def _apply_stage_filter(stage: str | None, merged: _Merged) -> list[McpServer]:
    if merged.stages and stage and stage in merged.stages:
        allow = merged.stages.get(stage) or []
        result: list[McpServer] = []
        for name in allow:
            server = merged.servers_by_name.get(name)
            if server is None:
                merged.warnings.append(f"stage_ref_missing:{stage}:{name}")
                continue
            result.append(server)
        return result
    return list(merged.servers_by_name.values())


def _record_endpoint_warnings(merged: _Merged, servers: list[McpServer]) -> None:
    seen: dict[tuple[Any, ...], str] = {}
    for s in servers:
        key = _endpoint_key(s)
        if key is None:
            continue
        name = getattr(s, "name", "")
        if not name:
            continue
        prev = seen.get(key)
        if prev and prev != name:
            merged.warnings.append(f"endpoint_duplicate:{prev}:{name}")
        else:
            seen[key] = name


def load_effective_mcp_servers(
    stage: str | None,
    workspace_folder: str,
    record_event: bool = True,
) -> list[McpServer] | None:
    merged = _Merged(
        servers_by_name={},
        source_by_name={},
        stages=None,
        sources_loaded=[],
        overridden=[],
        skipped=[],
        warnings=[],
    )

    sources = _discover_sources(workspace_folder)
    for src in sources:
        if src.kind == "env":
            _parse_env_servers(stage=stage, workspace_folder=workspace_folder, merged=merged)
            continue
        if src.kind in {"file", "repo", "user"}:
            if src.path:
                _parse_file_config(path=src.path, workspace_folder=workspace_folder, merged=merged, kind=src.kind)
            continue

    effective = _apply_stage_filter(stage=stage, merged=merged)
    _record_endpoint_warnings(merged, effective)

    if record_event:
        append_event(
            "mcp_config_effective",
            state=None,
            data={
                "stage": stage,
                "sources": [{"kind": s.kind, "path": s.path} for s in merged.sources_loaded],
                "injected": [getattr(s, "name", None) for s in effective if getattr(s, "name", None)],
                "overridden": merged.overridden,
                "skipped": merged.skipped,
                "warnings": merged.warnings,
            },
        )

    return effective or None


def filter_session_mcp_servers_by_enabled_tool_ids(
    servers: list[McpServer] | None,
    enabled_tool_ids: set[str] | None,
) -> tuple[list[McpServer] | None, list[dict[str, str]]]:
    if not servers:
        return None, []
    if enabled_tool_ids is None:
        return servers, []

    effective: list[McpServer] = []
    skipped: list[dict[str, str]] = []
    for server in servers:
        name = str(getattr(server, "name", "") or "")
        transport = str(getattr(server, "type", "") or "stdio")
        tool_id = f"mcp:{name}" if name else ""
        if not tool_id or tool_id not in enabled_tool_ids:
            skipped.append(
                {
                    "name": name,
                    "transport": transport,
                    "tool_id": tool_id,
                    "reason": "tool_not_enabled_for_stage",
                }
            )
            continue
        effective.append(server)
    return effective or None, skipped



def filter_session_mcp_servers_by_capability(
    servers: list[McpServer] | None,
    agent_capabilities: dict[str, Any] | None,
) -> tuple[list[McpServer] | None, list[dict[str, str]]]:
    if not servers:
        return None, []

    capabilities = agent_capabilities or {}
    raw_mcp_caps = capabilities.get("mcp_capabilities") or capabilities.get("mcpCapabilities") or {}
    allow_http = bool(raw_mcp_caps.get("http"))
    allow_sse = bool(raw_mcp_caps.get("sse"))

    effective: list[McpServer] = []
    skipped: list[dict[str, str]] = []
    for server in servers:
        name = str(getattr(server, "name", "") or "")
        if isinstance(server, HttpMcpServer) and not allow_http:
            skipped.append({"name": name, "transport": "http", "reason": "agent_missing_http_capability"})
            continue
        if isinstance(server, SseMcpServer) and not allow_sse:
            skipped.append({"name": name, "transport": "sse", "reason": "agent_missing_sse_capability"})
            continue
        effective.append(server)
    return effective or None, skipped
