from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any

from core.stage_tool_config import (
    _atomic_write_json,
    enabled_tool_ids_for_stage,
    ensure_user_stage_tool_config_seeded,
    load_stage_tool_config,
)
from core.tool_catalog import build_tool_catalog_payload


SCHEMA_VERSION = 1
SUPPORTED_ACCEPTANCE_STAGES: tuple[str, ...] = (
    "PRD_DRAFTING",
    "TECH_SPEC_DRAFTING",
    "CODING",
    "QUALITY_LOOP",
    "DEPLOYING",
    "REGRESSION_TESTING",
)


_DEFAULT_PROMPTS: dict[str, str] = {
    "PRD_DRAFTING": (
        "请判断当前 PRD 是否可以准出。重点检查：是否围绕当前原始需求展开、是否形成完整 PRD、"
        "是否保留 requirement marker、若引用了外部来源是否标出来源与风险。"
        "如果不满足，请明确列出缺失项。"
    ),
    "TECH_SPEC_DRAFTING": (
        "请判断当前 Tech Spec 是否可以准出。重点检查：是否围绕当前原始需求与 PRD 展开、"
        "是否形成完整技术方案、是否保留 requirement marker、是否包含 Manifest/变更清单、"
        "是否给出后续编码所需的关键实现信息。"
        "如果不满足，请明确列出缺失项。"
    ),
    "CODING": (
        "请判断当前 Coding 阶段是否可以准出。不要跳过第一层本地产物校验；先基于标准化 Stage Output 和本地产物确认："
        "代码改动已形成可消费交付，且输出中包含 changed_files、branch_name、commit_sha、mr_url 等关键信息。"
        "然后再执行 Harness Agent 二层判断：1）对照 MR 或本地 commit 与 tech spec / requirement，判断产物是否符合要求；"
        "2）若提供了 MR 链接，验证是否能够通过 MR 链接读取对应 commit 提交记录。"
        "若远端能力、鉴权、链接可达性或提交信息读取失败，请明确记录缺失项与失败原因，不要假设验证成功。"
    ),
    "QUALITY_LOOP": (
        "请判断当前 Quality Loop 是否可以准出。不要绕过第一层本地产物校验；先基于标准化 Stage Output 和本地产物确认："
        "单测相关改动已形成可消费交付，且输出中包含 changed_files、branch_name、commit_sha、mr_url 等关键信息。"
        "然后再执行 Harness Agent 二层判断：1）若提供了 MR 链接，验证是否能够通过 MR 链接读取对应 commit 提交记录；"
        "2）确认 MR 的单测覆盖率或等价覆盖证据是否可读；3）确认 MR 的单测执行情况是否可读，并明确通过、失败、进行中或未知。"
        "若远端能力、鉴权、链接可达性、覆盖率读取或执行状态读取失败，请明确记录缺失项与失败原因，不要假设验证成功。"
    ),
    "DEPLOYING": (
        "请判断当前 Deploying 阶段是否可以准出。重点检查：是否明确部署目标环境、部署结果、"
        "部署证据与后续回归入口。如果不满足，请明确列出缺失项。"
    ),
    "REGRESSION_TESTING": (
        "请判断当前 Regression Testing 阶段是否可以准出。重点检查：是否明确回归环境、测试用例、"
        "接口验证结果与失败项/结论。如果不满足，请明确列出缺失项。"
    ),
}

_DEFAULT_RULES: dict[str, list[dict[str, str]]] = {
    "CODING": [
        {
            "use_tool_id": "cli:bytedcli",
            "do": "优先读取本地仓库状态、分支、commit 信息，以及与当前编码产物相关的研发工作流上下文。",
            "verify": "对照 MR 或本地 commit 与 tech spec / requirement，确认当前代码改动是否符合要求；同时核对 changed_files、branch_name、commit_sha 等关键输出字段是否真实存在且可对应到本地产物。",
        },
        {
            "use_tool_id": "cli:bytedcli",
            "do": "若当前产出提供了 mr_url，优先通过 MR 链接读取对应 MR 与提交记录；若无法直接读取，再继续使用同类仓库工作流能力核对远端提交信息。",
            "verify": "确认是否能够通过 mr_url 读取对应 commit 提交记录；若远端能力、鉴权、链接可达性或提交记录读取失败，必须明确记录失败原因，不要假设验证成功。",
        },
    ],
    "QUALITY_LOOP": [
        {
            "use_tool_id": "skill:codebase-cli",
            "do": "若当前产出提供了 mr_url，优先通过 MR 链接读取对应 MR、commit 提交记录以及可见的测试信息；若无法直接读取，再继续使用同类仓库工作流能力核对远端信息。",
            "verify": "确认是否能够通过 mr_url 读取对应 commit 提交记录；若远端能力、鉴权、链接可达性或提交记录读取失败，必须明确记录失败原因，不要假设验证成功。",
        },
        {
            "use_tool_id": "skill:remote-ci-ut",
            "do": "优先读取 MR 关联单测覆盖率或等价覆盖证据；若没有直接能力，则读取可见的测试报告、流水线结果或质量报告。",
            "verify": "确认 MR 的单测覆盖率或等价覆盖证据是否可读、结论是否明确；若无法读取覆盖率、缺少覆盖证据或鉴权失败，必须明确记录缺失项与失败原因。",
        },
        {
            "use_tool_id": "skill:remote-ci-ut",
            "do": "优先读取 MR 关联单测执行状态、执行结果与失败详情；若没有直接能力，则读取可见的流水线状态、测试报告或质量报告。",
            "verify": "确认 MR 的单测执行情况是否可读，明确通过、失败、进行中或未知；若执行状态不可读、远端查询失败或缺少结果，必须明确记录，不要假设成功。",
        },
    ],
}


class StageAcceptancePolicyValidationError(ValueError):
    def __init__(self, errors: list[str]):
        self.errors = [str(error).strip() for error in errors if str(error).strip()]
        super().__init__("; ".join(self.errors) if self.errors else "invalid_stage_acceptance_policy")


@dataclass(frozen=True)
class StageAcceptancePolicyConfig:
    schema_version: int
    policies: dict[str, dict[str, Any]]
    source: str
    sources: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class StageAcceptancePolicyEntry:
    enabled: bool
    prompt: str
    model: str
    rules: list[dict[str, str]]
    max_retries: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": bool(self.enabled),
            "prompt": str(self.prompt or "").strip(),
            "model": str(self.model or "").strip(),
            "rules": [dict(rule) for rule in self.rules if isinstance(rule, dict)],
            "max_retries": int(self.max_retries),
        }


def repo_acceptance_policy_config_path(repo_root: str) -> str:
    return os.path.join(repo_root, ".harness", "stage_acceptance_policy.json")


def acceptance_policy_config_path() -> str:
    return os.path.join(os.path.expanduser("~"), ".harness", "stage_acceptance_policy.json")


def stage_supports_acceptance_policy(stage: str | None) -> bool:
    return str(stage or "").strip() in SUPPORTED_ACCEPTANCE_STAGES


def _read_json(path: str) -> dict[str, Any] | None:
    if not path or not os.path.exists(path):
        return None
    try:
        import json

        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _normalize_rule(raw: Any) -> dict[str, str]:
    if not isinstance(raw, dict):
        return {"use_tool_id": "", "do": "", "verify": ""}
    return {
        "use_tool_id": str(raw.get("use_tool_id") or "").strip(),
        "do": str(raw.get("do") or "").strip(),
        "verify": str(raw.get("verify") or "").strip(),
    }


def _empty_entry(stage: str) -> dict[str, Any]:
    normalized_stage = str(stage or "").strip()
    return {
        "enabled": stage_supports_acceptance_policy(normalized_stage),
        "prompt": _DEFAULT_PROMPTS.get(normalized_stage, ""),
        "model": "",
        "rules": [dict(rule) for rule in _DEFAULT_RULES.get(normalized_stage, [])],
        "max_retries": 2,
    }


def _normalize_entry(stage: str, raw: Any) -> dict[str, Any]:
    default = _empty_entry(stage)
    if not isinstance(raw, dict):
        return default
    rules = raw.get("rules")
    try:
        max_retries = int(raw.get("max_retries", default["max_retries"]))
    except (TypeError, ValueError):
        max_retries = default["max_retries"]
    if max_retries < 0:
        max_retries = default["max_retries"]
    return {
        "enabled": bool(raw.get("enabled", default["enabled"])),
        "prompt": str(raw.get("prompt") or default["prompt"]).strip(),
        "model": str(raw.get("model") or "").strip(),
        "rules": [_normalize_rule(rule) for rule in rules] if isinstance(rules, list) else [dict(rule) for rule in default["rules"]],
        "max_retries": max_retries,
    }


def _normalize_policies(raw: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(raw, dict):
        return {}
    out: dict[str, dict[str, Any]] = {}
    for key, value in raw.items():
        stage = str(key or "").strip()
        if not stage:
            continue
        out[stage] = _normalize_entry(stage, value)
    return out


def _merge_stage_policies(repo_policies: dict[str, dict[str, Any]], user_policies: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for stage in SUPPORTED_ACCEPTANCE_STAGES:
        merged[stage] = _normalize_entry(stage, repo_policies.get(stage))
    for stage, entry in repo_policies.items():
        if stage not in merged:
            merged[stage] = _normalize_entry(stage, entry)
    for stage, entry in user_policies.items():
        merged[stage] = _normalize_entry(stage, entry)
    return merged


def load_stage_acceptance_policy(repo_root: str | None = None) -> StageAcceptancePolicyConfig:
    repo_path = repo_acceptance_policy_config_path(repo_root) if repo_root else ""
    user_path = acceptance_policy_config_path()
    repo_data = _read_json(repo_path) or {}
    user_data = _read_json(user_path) or {}
    repo_policies = _normalize_policies(repo_data.get("policies"))
    user_policies = _normalize_policies(user_data.get("policies"))
    return StageAcceptancePolicyConfig(
        schema_version=int(user_data.get("schema_version") or repo_data.get("schema_version") or SCHEMA_VERSION),
        policies=_merge_stage_policies(repo_policies, user_policies),
        source=user_path,
        sources={"repo": repo_path, "user": user_path},
    )


def default_stage_acceptance_policy(repo_root: str, stage: str) -> dict[str, Any]:
    repo_data = _read_json(repo_acceptance_policy_config_path(repo_root)) or {}
    repo_policies = _normalize_policies(repo_data.get("policies"))
    return _normalize_entry(stage, repo_policies.get(str(stage or "").strip(), {}))


def build_default_repo_stage_acceptance_policy_payload() -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "policies": {
            stage: _normalize_entry(stage, None)
            for stage in SUPPORTED_ACCEPTANCE_STAGES
        },
    }


def ensure_user_stage_acceptance_policy_seeded(repo_root: str, stage: str = "CODING") -> tuple[str, bool]:
    normalized_stage = str(stage or "").strip()
    path = acceptance_policy_config_path()
    raw_user = _read_json(path) or {}
    raw_user_policies = raw_user.get("policies") if isinstance(raw_user.get("policies"), dict) else {}
    if normalized_stage in raw_user_policies:
        return path, False
    default_entry = default_stage_acceptance_policy(repo_root, normalized_stage)
    if not any([default_entry.get("enabled"), default_entry.get("prompt"), default_entry.get("model"), default_entry.get("rules")]):
        return path, False
    policies = _normalize_policies(raw_user_policies)
    policies[normalized_stage] = default_entry
    _atomic_write_json(path, {"schema_version": SCHEMA_VERSION, "policies": policies})
    return path, True


def reset_stage_acceptance_policy_to_defaults(repo_root: str, stage: str = "CODING") -> StageAcceptancePolicyConfig:
    normalized_stage = str(stage or "").strip()
    raw_user = _read_json(acceptance_policy_config_path()) or {}
    raw_user_policies = raw_user.get("policies") if isinstance(raw_user.get("policies"), dict) else {}
    policies = _normalize_policies(raw_user_policies)
    policies[normalized_stage] = default_stage_acceptance_policy(repo_root, normalized_stage)
    _atomic_write_json(acceptance_policy_config_path(), {"schema_version": SCHEMA_VERSION, "policies": policies})
    return load_stage_acceptance_policy(repo_root)


def get_stage_acceptance_entry(config: StageAcceptancePolicyConfig, stage: str | None) -> StageAcceptancePolicyEntry:
    normalized_stage = str(stage or "").strip()
    entry = config.policies.get(normalized_stage) if normalized_stage else None
    normalized = _normalize_entry(normalized_stage, entry)
    return StageAcceptancePolicyEntry(
        enabled=bool(normalized.get("enabled")),
        prompt=str(normalized.get("prompt") or "").strip(),
        model=str(normalized.get("model") or "").strip(),
        rules=[dict(rule) for rule in (normalized.get("rules") or []) if isinstance(rule, dict)],
        max_retries=int(normalized.get("max_retries", 2)),
    )


def _effective_acceptance_tool_choices(repo_root: str, stage: str) -> tuple[list[dict[str, Any]], set[str]]:
    ensure_user_stage_tool_config_seeded(repo_root)
    tool_payload = build_tool_catalog_payload(stage=stage, workspace_root=repo_root)
    stage_cfg = load_stage_tool_config(repo_root)
    enabled_tool_ids = enabled_tool_ids_for_stage(stage_cfg, stage) or set()

    entries: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry in tool_payload.get("entries") or []:
        if not isinstance(entry, dict):
            continue
        tool_id = str(entry.get("tool_id") or "").strip()
        if not tool_id or tool_id in seen or tool_id not in enabled_tool_ids:
            continue
        seen.add(tool_id)
        entries.append(
            {
                "tool_id": tool_id,
                "name": str(entry.get("name") or "").strip(),
                "type": str(entry.get("type") or "").strip(),
                "layer": str(entry.get("layer") or "").strip(),
                "summary": str(entry.get("summary") or "").strip(),
                "risk_level": str(entry.get("risk_level") or "").strip(),
                "source": str(entry.get("source") or "").strip(),
            }
        )
    return entries, enabled_tool_ids


def list_available_acceptance_policy_tools(repo_root: str, stage: str) -> list[dict[str, Any]]:
    entries, _ = _effective_acceptance_tool_choices(repo_root, stage)
    return entries


def validate_stage_acceptance_rules(repo_root: str, stage: str, rules: Any) -> list[dict[str, str]]:
    normalized_stage = str(stage or "").strip()
    errors: list[str] = []
    if not normalized_stage:
        errors.append("stage is required")
    elif not stage_supports_acceptance_policy(normalized_stage):
        errors.append(f"stage {normalized_stage} does not support acceptance policy in this version")

    if not isinstance(rules, list):
        errors.append("rules must be a list")
        raise StageAcceptancePolicyValidationError(errors)

    normalized_rules = [_normalize_rule(rule) for rule in rules]
    tool_choices, enabled_tool_ids = _effective_acceptance_tool_choices(repo_root, normalized_stage) if normalized_stage else ([], None)
    allowed_tool_ids = {str(item.get("tool_id") or "").strip() for item in tool_choices if isinstance(item, dict)}

    for idx, rule in enumerate(normalized_rules, start=1):
        tool_id = rule["use_tool_id"]
        do_text = rule["do"]
        verify_text = rule["verify"]
        if not tool_id:
            errors.append(f"rule {idx}: use_tool_id is required")
        elif tool_id not in allowed_tool_ids:
            if enabled_tool_ids:
                allowed = ", ".join(sorted(allowed_tool_ids)) or "(none)"
                errors.append(f"rule {idx}: use_tool_id {tool_id} is not enabled for stage {normalized_stage}; allowed: {allowed}")
            else:
                errors.append(f"rule {idx}: use_tool_id {tool_id} is not enabled for stage {normalized_stage}")
        if not do_text:
            errors.append(f"rule {idx}: do must not be empty")
        if not verify_text:
            errors.append(f"rule {idx}: verify must not be empty")

    if errors:
        raise StageAcceptancePolicyValidationError(errors)
    return normalized_rules


def validate_stage_acceptance_entry(repo_root: str, stage: str, payload: Any) -> StageAcceptancePolicyEntry:
    normalized_stage = str(stage or "").strip()
    errors: list[str] = []
    if not normalized_stage:
        errors.append("stage is required")
    elif not stage_supports_acceptance_policy(normalized_stage):
        errors.append(f"stage {normalized_stage} does not support acceptance policy in this version")
    if not isinstance(payload, dict):
        errors.append("policy payload must be an object")
        raise StageAcceptancePolicyValidationError(errors)

    enabled = bool(payload.get("enabled", True))
    prompt = str(payload.get("prompt") or "").strip()
    model = str(payload.get("model") or "").strip()
    rules_raw = payload.get("rules") if "rules" in payload else []

    try:
        max_retries = int(payload.get("max_retries", 2))
    except (TypeError, ValueError):
        errors.append("max_retries must be an integer")
        max_retries = 2

    if enabled and not prompt:
        errors.append("prompt is required when acceptance is enabled")
    if len(prompt) > 6000:
        errors.append("prompt is too long; keep it under 6000 characters")
    if len(model) > 200:
        errors.append("model is too long")
    if max_retries < 0:
        errors.append("max_retries must be greater than or equal to 0")
    if errors:
        raise StageAcceptancePolicyValidationError(errors)

    rules = validate_stage_acceptance_rules(repo_root, normalized_stage, rules_raw)
    return StageAcceptancePolicyEntry(enabled=enabled, prompt=prompt, model=model, rules=rules, max_retries=max_retries)


def save_stage_acceptance_policy(repo_root: str, stage: str, payload: Any) -> StageAcceptancePolicyConfig:
    normalized_stage = str(stage or "").strip()
    entry = validate_stage_acceptance_entry(repo_root, normalized_stage, payload)
    user_data = _read_json(acceptance_policy_config_path()) or {}
    user_policies = _normalize_policies(user_data.get("policies"))
    user_policies[normalized_stage] = entry.to_dict()
    _atomic_write_json(acceptance_policy_config_path(), {"schema_version": SCHEMA_VERSION, "policies": user_policies})
    return load_stage_acceptance_policy(repo_root)


def reset_stage_acceptance_policy(repo_root: str, stage: str | None = None) -> StageAcceptancePolicyConfig:
    user_data = _read_json(acceptance_policy_config_path()) or {}
    user_policies = _normalize_policies(user_data.get("policies"))
    policies = dict(user_policies)
    normalized_stage = str(stage or "").strip()
    if normalized_stage:
        policies.pop(normalized_stage, None)
    else:
        policies = {}
    _atomic_write_json(acceptance_policy_config_path(), {"schema_version": SCHEMA_VERSION, "policies": policies})
    return load_stage_acceptance_policy(repo_root)


def render_acceptance_rules_block(rules: list[dict[str, str]] | None) -> str:
    normalized_rules = [_normalize_rule(rule) for rule in (rules or [])]
    normalized_rules = [
        rule for rule in normalized_rules if rule["use_tool_id"] and rule["do"] and rule["verify"]
    ]
    if not normalized_rules:
        return ""

    lines = [
        "【用户配置的准出规则（USE/DO/VERIFY）】",
        "以下规则是二层准出判断时必须优先参考的用户约束。",
        "",
    ]
    for idx, rule in enumerate(normalized_rules, start=1):
        lines.append(f"{idx}. USE: {rule['use_tool_id']}")
        lines.append(f"   DO: {rule['do']}")
        lines.append(f"   VERIFY: {rule['verify']}")
    lines.extend(
        [
            "",
            "若某条规则依赖的工具当前不可用、不可读或执行失败，必须明确记录原因，不要假设验证已经成功。",
        ]
    )
    return "\n".join(lines).strip()


def build_acceptance_preview_warnings(repo_root: str, stage: str, payload: Any) -> list[str]:
    warnings: list[str] = []
    normalized_stage = str(stage or "").strip()
    if not normalized_stage:
        return ["缺少 stage 参数"]
    if not stage_supports_acceptance_policy(normalized_stage):
        return [f"当前版本不支持 stage {normalized_stage} 的准出规则配置"]
    if not isinstance(payload, dict):
        return ["策略配置必须是字典格式"]

    prompt = str(payload.get("prompt") or "").strip()
    if len(prompt) > 3000:
        warnings.append("补充说明较长，建议精简以保持判断稳定性")

    rules = payload.get("rules")
    if not isinstance(rules, list):
        warnings.append("rules 必须是列表格式")
        return warnings

    normalized_rules = [_normalize_rule(rule) for rule in rules]
    if len(normalized_rules) > 12:
        warnings.append("准出规则超过 12 条，建议精简以保持判断聚焦")
    total_chars = sum(len(rule["do"]) + len(rule["verify"]) for rule in normalized_rules)
    if total_chars > 1600:
        warnings.append("准出规则总文本较长，建议精简以减少 Prompt 冗余")

    tool_choices, _ = _effective_acceptance_tool_choices(repo_root, normalized_stage)
    allowed_tool_ids = {str(item.get("tool_id") or "").strip() for item in tool_choices if isinstance(item, dict)}
    for idx, rule in enumerate(normalized_rules, start=1):
        if not rule["use_tool_id"]:
            warnings.append(f"规则 {idx} 缺失 use_tool_id")
        elif rule["use_tool_id"] not in allowed_tool_ids:
            warnings.append(f"规则 {idx} 引用了当前 Stage 不可用的工具：{rule['use_tool_id']}")
        if not rule["do"]:
            warnings.append(f"规则 {idx} 的 DO 文本为空")
        if not rule["verify"]:
            warnings.append(f"规则 {idx} 的 VERIFY 文本为空")
    return warnings
