import logging
from core.orchestrator import FlowState, Orchestrator

logger = logging.getLogger(__name__)

class VerificationMiddleware:
    def __init__(self, ci_script_path: str | None = None):
        self.ci_script_path = ci_script_path

    def __call__(self, orch: Orchestrator) -> bool:
        current_state = orch.ctx.get_state()
        if current_state in {FlowState.VERIFYING.value, FlowState.QUALITY_LOOP.value}:
            logger.info(f"VerificationMiddleware observing delivery-validation state: {current_state}")
        return True
