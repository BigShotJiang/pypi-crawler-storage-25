import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)


def load_auth_block(path: str) -> dict[str, Any] | None:
    """Return auth_block payload if file exists and looks like an auth_required signal.

    The model writes this file when it encounters an authorization wall (401/403/authorize URL).
    """
    if not path or not os.path.exists(path) or os.path.isdir(path):
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
    except Exception as e:
        logger.warning("Found auth_block.json but failed to parse: %s", e)
        return None
    if not isinstance(data, dict):
        return None
    if str(data.get("type") or "").strip().lower() != "auth_required":
        return None
    return data


def clear_auth_block(path: str) -> None:
    if not path:
        return
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        return

