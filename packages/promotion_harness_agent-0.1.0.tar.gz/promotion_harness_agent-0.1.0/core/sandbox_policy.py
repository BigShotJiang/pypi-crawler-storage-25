import os
import signal
import urllib.parse
from typing import Any, Iterable

from acp.schema import ToolCall, FileEditToolCallContent


DEFAULT_TERMINAL_OUTPUT_BYTE_LIMIT = 32 * 1024
_TERMINAL_ALLOWED_ENV = {
    "CI",
    "HOME",
    "LANG",
    "LC_ALL",
    "LC_CTYPE",
    "PATH",
    "PYTHONPATH",
    "TERM",
    "TMPDIR",
    "VIRTUAL_ENV",
}
_TERMINAL_BLOCKED_ENV_EXACT = {
    "DYLD_INSERT_LIBRARIES",
    "GIT_SSH_COMMAND",
    "LD_PRELOAD",
    "PYTHONSTARTUP",
}
_TERMINAL_BLOCKED_ENV_PREFIXES = ("DYLD_", "LD_")
_TERMINAL_BLOCKED_COMMANDS = {
    "dd",
    "halt",
    "killall",
    "launchctl",
    "mkfs",
    "poweroff",
    "reboot",
    "rm",
    "shutdown",
    "sudo",
}
_TERMINAL_BLOCKED_SNIPPETS = (
    "rm -rf /",
    "shutdown ",
    "reboot ",
    "mkfs",
    "diskutil erase",
    "launchctl unload",
)


def _real(path: str) -> str:
    return os.path.realpath(os.path.abspath(path))


def _is_within(child: str, parent: str) -> bool:
    child_real = _real(child)
    parent_real = _real(parent)
    try:
        common = os.path.commonpath([child_real, parent_real])
    except ValueError:
        return False
    return common == parent_real


def _is_git_protected(path: str, workspace_root: str) -> bool:
    git_root = os.path.join(_real(workspace_root), ".git")
    return _is_within(path, git_root)


def _file_uri_to_path(uri: Any) -> str | None:
    raw = str(uri or "").strip()
    if not raw.startswith("file://"):
        return None
    parsed = urllib.parse.urlparse(raw)
    if parsed.scheme != "file" or not parsed.path:
        return None
    return _real(urllib.parse.unquote(parsed.path))


def extract_paths_from_tool_call(tool_call: ToolCall) -> list[str]:
    paths: list[str] = []

    raw_input = getattr(tool_call, "raw_input", None)
    if raw_input is None:
        raw_input = getattr(tool_call, "rawInput", None)
    if isinstance(raw_input, dict):
        raw_path = raw_input.get("path")
        if isinstance(raw_path, str) and raw_path:
            paths.append(raw_path)

    if getattr(tool_call, "locations", None):
        for loc in tool_call.locations or []:
            if getattr(loc, "path", None):
                paths.append(loc.path)

    if getattr(tool_call, "content", None):
        for item in tool_call.content or []:
            if isinstance(item, FileEditToolCallContent):
                paths.append(item.path)
            elif getattr(item, "type", None) == "diff" and getattr(item, "path", None):
                paths.append(item.path)
            elif getattr(item, "type", None) == "content":
                content = getattr(item, "content", None)
                content_type = getattr(content, "type", None)
                if content_type == "resource_link":
                    resolved = _file_uri_to_path(getattr(content, "uri", None))
                    if resolved:
                        paths.append(resolved)
                elif content_type == "resource":
                    resource = getattr(content, "resource", None)
                    resolved = _file_uri_to_path(getattr(resource, "uri", None))
                    if resolved:
                        paths.append(resolved)

    return [p for p in paths if isinstance(p, str) and p]


def is_write_like_tool_call(tool_call: ToolCall) -> bool:
    kind = getattr(tool_call, "kind", None)
    if kind in {"edit", "delete", "move"}:
        return True
    return False


def is_tool_call_allowed_in_workspace(tool_call: ToolCall, workspace_root: str) -> bool:
    kind = getattr(tool_call, "kind", None)
    if kind not in {"read", "edit", "delete", "move"}:
        return True

    paths = extract_paths_from_tool_call(tool_call)
    title = getattr(tool_call, "title", "") or ""
    if not paths and isinstance(title, str):
        parts = title.split()
        for p in parts:
            if p.startswith("/") or p.startswith("./") or p.startswith("../"):
                paths.append(p)

    if not paths:
        if kind == "read":
            return True
        return False

    for path in paths:
        if not _is_within(path, workspace_root):
            return False
        if kind in {"edit", "delete", "move"} and _is_git_protected(path, workspace_root):
            return False
    return True


def resolve_terminal_cwd(cwd: str | None, workspace_root: str | None) -> str:
    if cwd:
        if not os.path.isabs(cwd):
            return cwd
        return _real(cwd)
    if workspace_root:
        return _real(workspace_root)
    return _real(os.getcwd())


def is_terminal_cwd_allowed(cwd: str | None, workspace_root: str | None) -> bool:
    if not workspace_root:
        return False
    resolved = resolve_terminal_cwd(cwd, workspace_root)
    return _is_within(resolved, workspace_root) and not _is_git_protected(resolved, workspace_root)


def sanitize_terminal_env(env: Iterable[Any] | None) -> dict[str, str]:
    sanitized: dict[str, str] = {}
    if not env:
        return sanitized
    for item in env:
        name = None
        value = None
        if isinstance(item, dict):
            name = item.get("name")
            value = item.get("value")
        else:
            name = getattr(item, "name", None)
            value = getattr(item, "value", None)
        if not name or value is None:
            continue
        name = str(name)
        if name in _TERMINAL_BLOCKED_ENV_EXACT:
            continue
        if any(name.startswith(prefix) for prefix in _TERMINAL_BLOCKED_ENV_PREFIXES):
            continue
        if name in _TERMINAL_ALLOWED_ENV or name.startswith("HARNESS_"):
            sanitized[name] = str(value)
    return sanitized


def is_terminal_command_allowed(command: str | None, args: Iterable[str] | None = None) -> tuple[bool, str]:
    command = str(command or "").strip()
    if not command:
        return False, "missing_command"
    base = os.path.basename(command)
    lowered = base.lower()
    if lowered in _TERMINAL_BLOCKED_COMMANDS:
        return False, "command_blocked"
    arg_text = " ".join(str(a) for a in (args or []))
    payload = f"{command} {arg_text}".lower()
    for snippet in _TERMINAL_BLOCKED_SNIPPETS:
        if snippet in payload:
            return False, "command_blocked"
    return True, "allowed"


def validate_terminal_request(
    command: str | None,
    args: Iterable[str] | None,
    cwd: str | None,
    env: Iterable[Any] | None,
    workspace_root: str | None,
) -> tuple[bool, str, str, dict[str, str]]:
    resolved_cwd = resolve_terminal_cwd(cwd, workspace_root)
    if cwd and not os.path.isabs(cwd):
        return False, "cwd_must_be_absolute", resolved_cwd, {}
    if not is_terminal_cwd_allowed(resolved_cwd, workspace_root):
        return False, "outside_workspace", resolved_cwd, {}
    allowed, reason = is_terminal_command_allowed(command, args)
    if not allowed:
        return False, reason, resolved_cwd, {}
    return True, "allowed", resolved_cwd, sanitize_terminal_env(env)


def normalize_process_exit(returncode: int | None) -> tuple[int | None, str | None]:
    if returncode is None:
        return None, None
    if returncode < 0:
        sig = abs(returncode)
        try:
            return None, signal.Signals(sig).name
        except Exception:
            return None, f"SIG{sig}"
    return int(returncode), None
