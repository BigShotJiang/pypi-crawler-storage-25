from enum import Enum
import logging
import queue
import threading
from typing import Dict, Callable, Any
from core.context_manager import ContextManager
from core.run_trace import append_event
import time
from core.capability_registry import default_registry
from core.harness_gate import default_gate, set_acceptance_runner
from core.stage_acceptance import clear_acceptance_result

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

class FlowState(str, Enum):
    INIT = "INIT"
    PRD_DRAFTING = "PRD_DRAFTING"
    TECH_SPEC_DRAFTING = "TECH_SPEC_DRAFTING"
    CODING = "CODING"
    UNIT_TESTING = "UNIT_TESTING"
    SELF_TESTING = "SELF_TESTING"
    SMOKE_TESTING = "SMOKE_TESTING"
    QA_TESTING = "QA_TESTING"
    DEPLOYING = "DEPLOYING"
    REGRESSION_TESTING = "REGRESSION_TESTING"
    FINISHED = "FINISHED"
    FAILED = "FAILED"
    # Terminal-but-resumable state: the run is paused waiting for the user to grant permissions.
    # UI should offer a "resume" action that continues from the blocked stage without clearing progress/workspace.
    AUTH_BLOCKED = "AUTH_BLOCKED"
    QUALITY_LOOP = "QUALITY_LOOP"
    FIXING = "FIXING"
    VERIFYING = "VERIFYING"
    BUILDING = "BUILDING"
    PLANNING = "PLANNING"


DEFAULT_STAGE_TIMEOUTS_SEC: dict[str, float] = {
    FlowState.PRD_DRAFTING.value: 600.0,
    FlowState.TECH_SPEC_DRAFTING.value: 600.0,
}

class Orchestrator:
    def __init__(self, context_manager: ContextManager):
        self.ctx = context_manager
        self.handlers: Dict[str, Callable] = {}
        self.middlewares: list = []
        self._state_started_at: dict[str, float] = {}
        # Unified Harness gate: pre-gate is enforced at tool boundary; post-gate controls transitions.
        self.gate = default_gate()
        set_acceptance_runner(self._run_acceptance_gate)

    def _get_stage_timeout_sec(self, state: str) -> float | None:
        meta = self.ctx.context.get("metadata", {}) if isinstance(self.ctx.context.get("metadata"), dict) else {}
        timeouts = meta.get("stage_timeouts_sec", {})
        if isinstance(timeouts, dict):
            val = timeouts.get(state)
            if val is not None:
                try:
                    return float(val)
                except (TypeError, ValueError):
                    return None
        return DEFAULT_STAGE_TIMEOUTS_SEC.get(state)

    def register_handler(self, state: FlowState, handler: Callable):
        self.handlers[state.value] = handler

    def _run_acceptance_gate(self, *, stage: str, metadata: dict[str, Any] | None) -> dict[str, Any]:
        from core.stage_acceptance import run_stage_acceptance_verifier

        return run_stage_acceptance_verifier(self.ctx, stage=stage, metadata=metadata)

    def add_middleware(self, middleware: Callable):
        """
        Middlewares can intercept before state execution.
        They take (orchestrator) and return a boolean indicating whether to continue.
        """
        self.middlewares.append(middleware)

    def run(self):
        logger.info("Starting Orchestrator pipeline...")
        while True:
            current_state = self.ctx.get_state()
            if current_state in [FlowState.FINISHED.value, FlowState.FAILED.value, FlowState.AUTH_BLOCKED.value]:
                logger.info(f"Pipeline reached terminal state: {current_state}")
                append_event("run_end", state=current_state, data={})
                break

            # Run middlewares
            continue_execution = True
            for mw in self.middlewares:
                if not mw(self):
                    continue_execution = False
                    break
            
            if not continue_execution:
                break # A middleware halted execution (e.g. forced transition)

            # Re-check state in case middleware changed it
            current_state = self.ctx.get_state()
            if current_state in [FlowState.FINISHED.value, FlowState.FAILED.value, FlowState.AUTH_BLOCKED.value]:
                logger.info(f"Pipeline reached terminal state after middleware: {current_state}")
                break
                
            if current_state not in self.handlers:
                logger.error(f"No handler registered for state: {current_state}")
                append_event("state_error", state=current_state, data={"reason": "missing_handler"})
                self.ctx.set_state(FlowState.FAILED.value)
                break

            logger.info(f"Executing handler for state: {current_state}")
            started_at = time.monotonic()
            self._state_started_at[current_state] = started_at
            append_event("state_enter", state=current_state, data={})
            try:
                # Always emit the capability allowlist for the current stage so the UI can display
                # "what is allowed" alongside the actual tool/capability usage.
                try:
                    _, cap_payload = default_registry().advertise_for_stage(current_state)
                    append_event("capabilities_advertised", state=current_state, data=cap_payload)
                except Exception as e:
                    append_event("state_error", state=current_state, data={"error": f"capability_advertise_failed: {e}"})

                if current_state in {FlowState.PRD_DRAFTING.value, FlowState.TECH_SPEC_DRAFTING.value, FlowState.CODING.value}:
                    clear_acceptance_result(self.ctx.context.get("metadata"), current_state)
                    self.ctx.save()

                stage_ctx = self.ctx.prepare_stage_context(current_state)
                append_event(
                    "stage_context_prepared",
                    state=current_state,
                    data={
                        "ctx_path": self.ctx.context.get("metadata", {}).get("context_snapshots", {}).get(current_state, {}).get("ctx_path"),
                        "fields": sorted(stage_ctx.keys()),
                    },
                )
                timeout_sec = self._get_stage_timeout_sec(current_state)
                if timeout_sec is None or timeout_sec <= 0:
                    next_state = self.handlers[current_state](self.ctx)
                else:
                    q: queue.Queue = queue.Queue(maxsize=1)

                    def runner():
                        try:
                            q.put(("ok", self.handlers[current_state](self.ctx)))
                        except Exception as e:
                            q.put(("err", e))

                    t = threading.Thread(target=runner, daemon=True)
                    t.start()
                    try:
                        kind, payload = q.get(timeout=timeout_sec)
                    except queue.Empty:
                        duration_ms = int((time.monotonic() - started_at) * 1000)
                        msg = f"stage timeout: {current_state} exceeded {timeout_sec:.0f}s"
                        self.ctx.update_metadata("last_error_log", msg)
                        append_event("state_timeout", state=current_state, data={"duration_ms": duration_ms, "timeout_sec": timeout_sec})
                        append_event("state_exit", state=current_state, data={"duration_ms": duration_ms, "next_state": FlowState.FAILED.value})
                        self.ctx.set_state(FlowState.FAILED.value)
                        break
                    if kind == "err":
                        raise payload
                    next_state = payload
                if next_state:
                    # "handler proposes, gate decides": handler return is a suggestion.
                    verdict = self.gate.post_gate(
                        stage=current_state,
                        suggested_next_state=next_state.value,
                        metadata=self.ctx.context.get("metadata", {}) if isinstance(self.ctx.context.get("metadata"), dict) else {},
                    )
                    if verdict.next_state:
                        self.ctx.set_state(verdict.next_state)
                    else:
                        logger.warning(f"Gate verdict had no next_state for {current_state}. Halting.")
                    duration_ms = int((time.monotonic() - started_at) * 1000)
                    append_event(
                        "state_exit",
                        state=current_state,
                        data={
                            "duration_ms": duration_ms,
                            "next_state": verdict.next_state,
                            "suggested_next_state": next_state.value,
                            "gate_outcome": verdict.outcome,
                            "gate_reason": verdict.reason,
                        },
                    )
                else:
                    logger.warning(f"Handler for {current_state} did not return a next state. Halting.")
                    duration_ms = int((time.monotonic() - started_at) * 1000)
                    append_event("state_exit", state=current_state, data={"duration_ms": duration_ms, "next_state": None})
                    break
            except Exception as e:
                logger.error(f"Error in state {current_state}: {e}")
                append_event("state_error", state=current_state, data={"error": str(e)})
                self.ctx.set_state(FlowState.FAILED.value)
                break
