from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime


@dataclass
class StageSummary:
    state: str
    entered_ts: str | None
    exited_ts: str | None
    duration_ms: int | None
    next_state: str | None


def _parse_ts(ts: str) -> datetime | None:
    try:
        if ts.endswith("Z"):
            ts = ts[:-1] + "+00:00"
        return datetime.fromisoformat(ts)
    except Exception:
        return None


def read_ndjson(path: str, max_lines: int = 5000) -> list[dict]:
    if not path or not os.path.exists(path):
        return []
    events: list[dict] = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for i, line in enumerate(f):
            if i >= max_lines:
                break
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return events


def build_stage_summaries(events: list[dict]) -> dict[str, StageSummary]:
    enters: dict[str, str] = {}
    summaries: dict[str, StageSummary] = {}
    for ev in events:
        ev_type = ev.get("type")
        state = ev.get("state")
        ts = ev.get("ts")
        if not state:
            continue
        if ev_type == "state_enter":
            enters[state] = ts
            if state not in summaries:
                summaries[state] = StageSummary(state=state, entered_ts=ts, exited_ts=None, duration_ms=None, next_state=None)
            else:
                summaries[state] = StageSummary(state=state, entered_ts=ts, exited_ts=summaries[state].exited_ts, duration_ms=summaries[state].duration_ms, next_state=summaries[state].next_state)
        if ev_type == "state_exit":
            data = ev.get("data", {}) if isinstance(ev.get("data"), dict) else {}
            duration_ms = data.get("duration_ms")
            next_state = data.get("next_state")
            entered_ts = enters.get(state) or summaries.get(state, StageSummary(state, None, None, None, None)).entered_ts
            summaries[state] = StageSummary(state=state, entered_ts=entered_ts, exited_ts=ts, duration_ms=duration_ms, next_state=next_state)
    return summaries


def build_timeline(events: list[dict]) -> list[StageSummary]:
    timeline: list[StageSummary] = []
    for ev in events:
        if ev.get("type") != "state_exit":
            continue
        state = ev.get("state")
        ts = ev.get("ts")
        data = ev.get("data", {}) if isinstance(ev.get("data"), dict) else {}
        duration_ms = data.get("duration_ms")
        next_state = data.get("next_state")
        entered = None
        for back in reversed(events):
            if back.get("type") == "state_enter" and back.get("state") == state:
                entered = back.get("ts")
                break
        timeline.append(StageSummary(state=state, entered_ts=entered, exited_ts=ts, duration_ms=duration_ms, next_state=next_state))
    return timeline


def summarize_quality_loop_history(progress_metadata: dict) -> list[dict]:
    quality_loop = progress_metadata.get("quality_loop")
    if isinstance(quality_loop, dict):
        history = quality_loop.get("history")
        if isinstance(history, list):
            return history
    return []


def stage_context_snapshot_ref(progress_metadata: dict, stage: str) -> dict | None:
    refs = progress_metadata.get("context_snapshots")
    if not isinstance(refs, dict):
        return None
    item = refs.get(stage)
    return item if isinstance(item, dict) else None


def read_stage_context_snapshot(progress_metadata: dict, stage: str) -> dict | None:
    ref = stage_context_snapshot_ref(progress_metadata, stage)
    if not ref:
        return None
    ctx_path = ref.get("ctx_path")
    if not isinstance(ctx_path, str) or not os.path.exists(ctx_path):
        return None
    try:
        with open(ctx_path, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def read_stage_prompt_snapshot(progress_metadata: dict, stage: str) -> str:
    prompt_path = None

    prompt_refs = progress_metadata.get("prompt_snapshots")
    if isinstance(prompt_refs, dict):
        prompt_ref = prompt_refs.get(stage)
        if isinstance(prompt_ref, dict):
            candidate = prompt_ref.get("prompt_path")
            if isinstance(candidate, str) and os.path.exists(candidate):
                prompt_path = candidate

    if prompt_path is None:
        ref = stage_context_snapshot_ref(progress_metadata, stage)
        if isinstance(ref, dict):
            candidate = ref.get("prompt_path")
            if isinstance(candidate, str) and os.path.exists(candidate):
                prompt_path = candidate

    if not prompt_path:
        return ""
    try:
        with open(prompt_path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def latest_capabilities_for_stage(events: list[dict], stage: str) -> dict | None:
    for ev in reversed(events):
        if ev.get("type") == "capabilities_advertised" and ev.get("state") == stage:
            data = ev.get("data")
            if isinstance(data, dict):
                return data
    return None


def policy_decisions_for_stage(events: list[dict], stage: str) -> list[dict]:
    out: list[dict] = []
    for ev in events:
        if ev.get("type") == "capability_policy_decision" and ev.get("state") == stage:
            data = ev.get("data")
            if isinstance(data, dict):
                out.append(data)
    return out


def capability_usage_for_stage(events: list[dict], stage: str) -> list[dict]:
    """Aggregate capability usage for a stage.

    Uses `capability_policy_decision` events because they carry:
    - resolved_capability (capability id)
    - decision allow/deny
    - normalized_kind / intent_family / reason
    """
    grouped: dict[str, dict] = {}
    for ev in events:
        if ev.get("type") != "capability_policy_decision" or ev.get("state") != stage:
            continue
        data = ev.get("data")
        if not isinstance(data, dict):
            continue
        cap = data.get("resolved_capability") or data.get("tool_name") or "unknown"
        cap = str(cap)
        decision = str(data.get("decision") or "")
        reason = str(data.get("reason") or "")
        kind = str(data.get("kind") or data.get("normalized_kind") or "")
        intent_family = str(data.get("intent_family") or "")
        ts = ev.get("ts")

        item = grouped.get(cap)
        if item is None:
            item = {
                "capability": cap,
                "total": 0,
                "allow": 0,
                "deny": 0,
                "kinds": {},
                "intent_families": {},
                "reasons": {},
                "last_ts": ts,
            }
            grouped[cap] = item

        item["total"] += 1
        if decision == "allow":
            item["allow"] += 1
        elif decision == "deny":
            item["deny"] += 1
        if kind:
            item["kinds"][kind] = int(item["kinds"].get(kind, 0)) + 1
        if intent_family:
            item["intent_families"][intent_family] = int(item["intent_families"].get(intent_family, 0)) + 1
        if reason:
            item["reasons"][reason] = int(item["reasons"].get(reason, 0)) + 1
        if ts:
            item["last_ts"] = ts

    items = list(grouped.values())
    items.sort(key=lambda x: (-int(x.get("total", 0)), str(x.get("capability", ""))))
    return items


def acp_tool_calls_for_stage(events: list[dict], stage: str) -> list[dict]:
    grouped: dict[str, dict] = {}
    order: list[str] = []
    for ev in events:
        if ev.get("state") != stage:
            continue
        t = ev.get("type")
        if t not in {"acp_tool_call", "acp_tool_call_update"}:
            continue
        data = ev.get("data")
        if not isinstance(data, dict):
            continue
        tool_call_id = data.get("tool_call_id")
        if not tool_call_id:
            continue
        if tool_call_id not in grouped:
            display_status = data.get("status_display") or data.get("status")
            grouped[tool_call_id] = {
                "tool_call_id": tool_call_id,
                "title": data.get("title"),
                "kind": data.get("kind"),
                "created_status": display_status if t == "acp_tool_call" else None,
                "latest_status": display_status,
                "locations": data.get("locations"),
                "content_summary": data.get("content_summary"),
                "content_excerpt": data.get("content_excerpt"),
                "raw_input_summary": data.get("raw_input_summary"),
                "raw_output_summary": data.get("raw_output_summary"),
                "updates": [],
            }
            order.append(tool_call_id)
        else:
            display_status = data.get("status_display") or data.get("status")
            grouped[tool_call_id]["latest_status"] = display_status or grouped[tool_call_id].get("latest_status")
            if data.get("content_summary"):
                grouped[tool_call_id]["content_summary"] = data.get("content_summary")
            if data.get("content_excerpt"):
                grouped[tool_call_id]["content_excerpt"] = data.get("content_excerpt")
        grouped[tool_call_id]["updates"].append({"type": t, "ts": ev.get("ts"), "data": data})
    return [grouped[i] for i in order]


def acp_session_info_updates_for_stage(events: list[dict], stage: str) -> list[dict]:
    out: list[dict] = []
    for ev in events:
        if ev.get("state") != stage or ev.get("type") != "acp_session_info_update":
            continue
        data = ev.get("data")
        if not isinstance(data, dict):
            continue
        out.append({
            "ts": ev.get("ts"),
            "session_id": data.get("session_id"),
            "title": data.get("title"),
            "updated_at": data.get("updated_at"),
            "_meta": data.get("_meta"),
        })
    return out


def latest_plan_for_stage(events: list[dict], stage: str) -> dict | None:
    """Return the latest ACP plan update for a stage (if any).

    Plan updates are emitted as `acp_plan_update` trace events by the ACP client.
    """
    for ev in reversed(events):
        if ev.get("type") != "acp_plan_update" or ev.get("state") != stage:
            continue
        data = ev.get("data")
        return data if isinstance(data, dict) else None


def acp_fs_events_for_stage(events: list[dict], stage: str) -> list[dict]:
    out: list[dict] = []
    for ev in events:
        if ev.get("state") != stage:
            continue
        t = ev.get("type")
        if t not in {"acp_fs_read", "acp_fs_write"}:
            continue
        data = ev.get("data")
        if not isinstance(data, dict):
            continue
        out.append({
            "type": t,
            "ts": ev.get("ts"),
            "path": data.get("path"),
            "bytes": data.get("bytes"),
            "line": data.get("line"),
            "limit": data.get("limit"),
            "result": data.get("result"),
            "reason": data.get("reason"),
            "error": data.get("error"),
        })
    return out


def acp_terminal_events_for_stage(events: list[dict], stage: str) -> list[dict]:
    out: list[dict] = []
    terminal_types = {
        "acp_terminal_create",
        "acp_terminal_output",
        "acp_terminal_wait",
        "acp_terminal_kill",
        "acp_terminal_release",
        "acp_terminal_stream_error",
    }
    for ev in events:
        if ev.get("state") != stage:
            continue
        t = ev.get("type")
        if t not in terminal_types:
            continue
        data = ev.get("data")
        if not isinstance(data, dict):
            continue
        out.append({
            "type": t,
            "ts": ev.get("ts"),
            **data,
        })
    return out


def acp_terminal_sessions_for_stage(events: list[dict], stage: str) -> list[dict]:
    grouped: dict[str, dict] = {}
    order: list[str] = []
    for item in acp_terminal_events_for_stage(events, stage):
        terminal_id = item.get("terminal_id") or item.get("terminalId") or "<pending>"
        if terminal_id not in grouped:
            grouped[terminal_id] = {
                "terminal_id": terminal_id,
                "command": item.get("command"),
                "args": item.get("args"),
                "cwd": item.get("cwd"),
                "result": item.get("result"),
                "exit_code": item.get("exit_code"),
                "signal": item.get("signal"),
                "truncated": item.get("truncated"),
                "updates": [],
            }
            order.append(terminal_id)
        session = grouped[terminal_id]
        session["command"] = item.get("command") or session.get("command")
        session["args"] = item.get("args") or session.get("args")
        session["cwd"] = item.get("cwd") or session.get("cwd")
        session["result"] = item.get("result") or session.get("result")
        session["exit_code"] = item.get("exit_code") if item.get("exit_code") is not None else session.get("exit_code")
        session["signal"] = item.get("signal") or session.get("signal")
        session["truncated"] = item.get("truncated") if item.get("truncated") is not None else session.get("truncated")
        session["updates"].append(item)
    return [grouped[i] for i in order]
