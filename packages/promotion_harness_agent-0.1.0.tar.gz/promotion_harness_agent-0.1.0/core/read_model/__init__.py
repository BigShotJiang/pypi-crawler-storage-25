"""Read-model utilities for UI and analysis.

This package MUST NOT import Streamlit. Keep it pure and unit-testable.
"""

