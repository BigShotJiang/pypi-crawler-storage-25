from __future__ import annotations

import json
import os
import tempfile
from dataclasses import asdict, dataclass
from typing import Any


CURRENT_RUN_FILE = "current_run.json"


def _real(path: str) -> str:
    return os.path.realpath(os.path.abspath(path))


def resolve_repo_root(repo_root: str | None = None) -> str:
    explicit = str(repo_root or "").strip()
    if explicit:
        return _real(explicit)
    override = str(os.environ.get("HARNESS_REPO_ROOT") or "").strip()
    if override:
        return _real(override)
    return _real(os.getcwd())


def harness_root(repo_root: str | None = None) -> str:
    return os.path.join(resolve_repo_root(repo_root), ".harness")


def runs_root(repo_root: str | None = None) -> str:
    return os.path.join(harness_root(repo_root), "runs")


def current_run_file(repo_root: str | None = None) -> str:
    return os.path.join(harness_root(repo_root), CURRENT_RUN_FILE)


def _write_json_atomic(path: str, payload: dict[str, Any]) -> None:
    target = _real(path)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".runtime.", suffix=".tmp", dir=os.path.dirname(target))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        os.replace(tmp_path, target)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass


def _read_json(path: str) -> dict[str, Any] | None:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            payload = json.load(fh)
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


@dataclass(frozen=True)
class RuntimePaths:
    repo_root: str
    harness_root: str
    runs_root: str
    current_run_file: str
    run_id: str
    run_root: str
    progress_file: str
    trace_file: str
    docs_root: str
    context_root: str
    stage_outputs_root: str
    acceptance_root: str
    outputs_root: str
    logs_root: str
    auth_block_file: str
    pid_file: str

    @property
    def run_root_relative(self) -> str:
        return os.path.relpath(self.run_root, self.repo_root)

    def current_run_record(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["run_root_relative"] = self.run_root_relative
        return payload


def runtime_paths_for_run(run_id: str, repo_root: str | None = None) -> RuntimePaths:
    resolved_repo_root = resolve_repo_root(repo_root)
    normalized_run_id = str(run_id or "").strip()
    if not normalized_run_id:
        raise ValueError("run_id_required")
    harness_dir = harness_root(resolved_repo_root)
    runs_dir = runs_root(resolved_repo_root)
    run_dir = os.path.join(runs_dir, normalized_run_id)
    return RuntimePaths(
        repo_root=resolved_repo_root,
        harness_root=harness_dir,
        runs_root=runs_dir,
        current_run_file=current_run_file(resolved_repo_root),
        run_id=normalized_run_id,
        run_root=run_dir,
        progress_file=os.path.join(run_dir, "progress.json"),
        trace_file=os.path.join(run_dir, "trace.ndjson"),
        docs_root=os.path.join(run_dir, "docs"),
        context_root=os.path.join(run_dir, "context"),
        stage_outputs_root=os.path.join(run_dir, "stage_outputs"),
        acceptance_root=os.path.join(run_dir, "acceptance"),
        outputs_root=os.path.join(run_dir, "outputs"),
        logs_root=os.path.join(run_dir, "logs"),
        auth_block_file=os.path.join(run_dir, "auth_block.json"),
        pid_file=os.path.join(harness_dir, "run.pid"),
    )


def ensure_repo_initialized(repo_root: str | None = None) -> str:
    resolved = resolve_repo_root(repo_root)
    os.makedirs(harness_root(resolved), exist_ok=True)
    os.makedirs(runs_root(resolved), exist_ok=True)
    return resolved


def validate_repo_init_target(repo_root: str | None = None) -> tuple[bool, str]:
    resolved = resolve_repo_root(repo_root)
    if not os.path.isdir(resolved):
        return False, "repo_root_not_found"
    if not os.path.isdir(os.path.join(resolved, ".git")):
        return False, "git_repository_required"
    return True, "ok"


def write_current_run(paths: RuntimePaths) -> str:
    ensure_repo_initialized(paths.repo_root)
    _write_json_atomic(paths.current_run_file, paths.current_run_record())
    return paths.current_run_file


def clear_current_run(repo_root: str | None = None) -> None:
    path = current_run_file(repo_root)
    try:
        os.remove(path)
    except FileNotFoundError:
        pass


def read_current_run(repo_root: str | None = None) -> dict[str, Any] | None:
    path = current_run_file(repo_root)
    return _read_json(path) if os.path.exists(path) else None


def active_run_paths(repo_root: str | None = None) -> RuntimePaths | None:
    resolved_repo_root = resolve_repo_root(repo_root)
    current = read_current_run(resolved_repo_root)
    if not isinstance(current, dict):
        return None
    run_id = str(current.get("run_id") or "").strip()
    if not run_id:
        return None
    return runtime_paths_for_run(run_id, resolved_repo_root)
