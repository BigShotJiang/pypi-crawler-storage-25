from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, asdict
from typing import Any, Iterable

from core.run_trace import append_event
from core.mcp_config import load_effective_mcp_servers
from core.stage_tool_config import BASH_TOOL_ID


@dataclass(frozen=True)
class ToolEntry:
    name: str
    layer: str  # orchestration | capability
    type: str   # skill | mcp | cli | bash | script
    summary: str
    tool_id: str | None = None
    location: str | None = None
    risk_level: str | None = None
    source: str | None = None


def tool_id_for_entry(entry_type: str, name: str) -> str | None:
    t = str(entry_type or "").strip().lower()
    n = str(name or "").strip()
    if not t or not n:
        return None
    return f"{t}:{n}"


def _read_json(path: str) -> Any | None:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None
    except Exception:
        return None


def _coerce_list(value: Any) -> list[dict[str, Any]]:
    if not value:
        return []
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    return []


def _rel_if_within(path: str, root: str) -> str:
    try:
        common = os.path.commonpath([os.path.realpath(path), os.path.realpath(root)])
    except ValueError:
        return path
    if common == os.path.realpath(root):
        return os.path.relpath(path, root)
    return path


def _parse_skill_frontmatter(path: str) -> dict[str, str]:
    meta: dict[str, str] = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = []
            for _ in range(60):
                line = f.readline()
                if not line:
                    break
                lines.append(line.rstrip("\n"))
    except Exception:
        return meta
    if not lines or lines[0].strip() != "---":
        return meta
    for line in lines[1:]:
        if line.strip() == "---":
            break
        if ":" not in line:
            continue
        key, val = line.split(":", 1)
        key = key.strip().lower()
        val = val.strip().strip("\"")
        if key in {"name", "description", "summary"} and val:
            meta[key] = val
    return meta


def _discover_skill_dirs(workspace_root: str) -> list[str]:
    dirs: list[str] = []
    env_dirs = os.environ.get("HARNESS_SKILL_DIRS")
    if env_dirs:
        for part in env_dirs.split(os.pathsep):
            if part:
                dirs.append(part)
    repo_default = os.path.join(workspace_root, ".trae", "skills")
    user_default = os.path.expanduser("~/.trae/skills")
    for candidate in [repo_default, user_default]:
        if candidate and candidate not in dirs:
            dirs.append(candidate)
    return [d for d in dirs if d and os.path.isdir(d)]


def _load_skill_entries(stage: str | None, workspace_root: str) -> tuple[list[ToolEntry], list[dict[str, str]]]:
    entries: list[ToolEntry] = []
    skipped: list[dict[str, str]] = []

    # Config-driven skills (override/augment discovery)
    sources: list[tuple[str, str | None]] = [
        ("env", os.environ.get("HARNESS_SKILLS_JSON")),
        ("repo", os.path.join(workspace_root, ".harness", "skills.json")),
        ("user", os.path.expanduser("~/.harness/skills.json")),
    ]
    merged: dict[str, dict[str, Any]] = {}
    for kind, payload in sources:
        if kind == "env":
            if not payload:
                continue
            try:
                data = json.loads(payload)
            except Exception:
                skipped.append({"source": "env", "reason": "invalid_json"})
                continue
        else:
            if not payload or not os.path.exists(payload):
                continue
            data = _read_json(payload)
        for item in _coerce_list(data):
            name = str(item.get("name") or "").strip()
            if not name:
                continue
            merged[name] = dict(item)
            merged[name]["_source"] = kind

    for name, item in merged.items():
        path = str(item.get("path") or "").strip()
        summary = str(item.get("summary") or item.get("description") or "Skill entry")
        if path and not os.path.isabs(path):
            path = os.path.join(workspace_root, path)
        location = _rel_if_within(path, workspace_root) if path else None
        entries.append(ToolEntry(
            name=name,
            layer="orchestration",
            type="skill",
            summary=summary,
            tool_id=tool_id_for_entry("skill", name),
            location=location,
            risk_level=str(item.get("risk_level") or "").strip() or None,
            source=str(item.get("_source") or kind),
        ))

    # Directory discovery
    for skill_dir in _discover_skill_dirs(workspace_root):
        try:
            subdirs = [d for d in os.listdir(skill_dir) if not d.startswith(".")]
        except Exception:
            continue
        for entry in sorted(subdirs):
            candidate = os.path.join(skill_dir, entry)
            skill_md = os.path.join(candidate, "SKILL.md")
            if not os.path.isdir(candidate) or not os.path.exists(skill_md):
                continue
            meta = _parse_skill_frontmatter(skill_md)
            name = meta.get("name") or entry
            summary = meta.get("description") or meta.get("summary") or "Skill definition"
            location = _rel_if_within(skill_md, workspace_root)
            entries.append(ToolEntry(
                name=name,
                layer="orchestration",
                type="skill",
                summary=summary,
                tool_id=tool_id_for_entry("skill", name),
                location=location,
                risk_level=None,
                source="skill_dir",
            ))
    return entries, skipped


def _load_cli_entries(stage: str | None, workspace_root: str) -> tuple[list[ToolEntry], list[dict[str, str]]]:
    entries: list[ToolEntry] = []
    skipped: list[dict[str, str]] = []

    sources: list[tuple[str, str | None]] = [
        ("env", os.environ.get("HARNESS_CLI_TOOLS_JSON")),
        ("repo", os.path.join(workspace_root, ".harness", "cli_tools.json")),
        ("user", os.path.expanduser("~/.harness/cli_tools.json")),
    ]

    merged: dict[str, dict[str, Any]] = {}
    for kind, payload in sources:
        if kind == "env":
            if not payload:
                continue
            try:
                data = json.loads(payload)
            except Exception:
                skipped.append({"source": "env", "reason": "invalid_json"})
                continue
        else:
            if not payload or not os.path.exists(payload):
                continue
            data = _read_json(payload)
        for item in _coerce_list(data):
            name = str(item.get("name") or "").strip()
            if not name:
                continue
            merged[name] = dict(item)
            merged[name]["_source"] = kind

    for name, item in merged.items():
        cmd = str(item.get("command") or name).strip()
        summary = str(item.get("summary") or "CLI tool")
        resolved = None
        if os.path.isabs(cmd):
            if os.path.exists(cmd):
                resolved = cmd
        else:
            resolved = shutil.which(cmd)
        if not resolved:
            skipped.append({"source": str(item.get("_source") or "unknown"), "name": name, "reason": "command_not_found"})
            continue
        entries.append(ToolEntry(
            name=name,
            layer="capability",
            type="cli",
            summary=summary,
            tool_id=tool_id_for_entry("cli", name),
            location=_rel_if_within(resolved, workspace_root),
            risk_level=str(item.get("risk_level") or "").strip() or None,
            source=str(item.get("_source") or "unknown"),
        ))
    return entries, skipped


def _load_script_entries(stage: str | None, workspace_root: str) -> tuple[list[ToolEntry], list[dict[str, str]]]:
    entries: list[ToolEntry] = []
    skipped: list[dict[str, str]] = []

    sources: list[tuple[str, str | None]] = [
        ("env", os.environ.get("HARNESS_SCRIPT_TOOLS_JSON")),
        ("repo", os.path.join(workspace_root, ".harness", "script_tools.json")),
        ("user", os.path.expanduser("~/.harness/script_tools.json")),
    ]

    merged: dict[str, dict[str, Any]] = {}
    for kind, payload in sources:
        if kind == "env":
            if not payload:
                continue
            try:
                data = json.loads(payload)
            except Exception:
                skipped.append({"source": "env", "reason": "invalid_json"})
                continue
        else:
            if not payload or not os.path.exists(payload):
                continue
            data = _read_json(payload)
        for item in _coerce_list(data):
            name = str(item.get("name") or "").strip()
            if not name:
                continue
            merged[name] = dict(item)
            merged[name]["_source"] = kind

    for name, item in merged.items():
        path = str(item.get("path") or "").strip()
        if not path:
            continue
        if not os.path.isabs(path):
            path = os.path.join(workspace_root, path)
        if not os.path.exists(path):
            skipped.append({"source": str(item.get("_source") or "unknown"), "name": name, "reason": "script_not_found"})
            continue
        summary = str(item.get("summary") or "Script tool")
        entries.append(ToolEntry(
            name=name,
            layer="capability",
            type="script",
            summary=summary,
            tool_id=tool_id_for_entry("script", name),
            location=_rel_if_within(path, workspace_root),
            risk_level=str(item.get("risk_level") or "").strip() or None,
            source=str(item.get("_source") or "unknown"),
        ))

    # Optional auto-discovery in workspace/scripts and scripts
    auto_discover = str(os.environ.get("HARNESS_SCRIPT_AUTO_DISCOVER", "1")).strip().lower() not in {"0", "false", "no"}
    if auto_discover:
        for folder in [os.path.join(workspace_root, "workspace", "scripts"), os.path.join(workspace_root, "scripts")]:
            if not os.path.isdir(folder):
                continue
            for root, _, filenames in os.walk(folder):
                for filename in sorted(filenames):
                    if filename.startswith("."):
                        continue
                    if not (filename.endswith(".py") or filename.endswith(".sh") or filename.endswith(".bash")):
                        continue
                    path = os.path.join(root, filename)
                    rel = _rel_if_within(path, workspace_root)
                    name = rel
                    entries.append(ToolEntry(
                        name=name,
                        layer="capability",
                        type="script",
                        summary="Local script",
                        tool_id=tool_id_for_entry("script", name),
                        location=rel,
                                risk_level="low",
                        source="auto_discover",
                    ))
    return entries, skipped


def _load_mcp_entries(stage: str | None, workspace_root: str) -> list[ToolEntry]:
    servers = load_effective_mcp_servers(stage=stage, workspace_folder=workspace_root, record_event=False) or []
    entries: list[ToolEntry] = []
    for server in servers:
        name = str(getattr(server, "name", "")) or "mcp"
        transport = getattr(server, "type", None)
        summary = f"MCP server ({transport or 'stdio'})"
        location = None
        if hasattr(server, "url"):
            location = getattr(server, "url", None)
        if hasattr(server, "command"):
            location = getattr(server, "command", None)
        entries.append(ToolEntry(
            name=name,
            layer="capability",
            type="mcp",
            summary=summary,
            tool_id=tool_id_for_entry("mcp", name),
            location=location,
            risk_level="medium",
            source="mcp_config",
        ))
    return entries


def _load_bash_entries(stage: str | None, workspace_root: str) -> list[ToolEntry]:
    return [
        ToolEntry(
            name="shell",
            layer="capability",
            type="bash",
            summary="Enable shell-backed commands (bash/sh/zsh and compound shell syntax) within the repo sandbox.",
            tool_id=BASH_TOOL_ID,
            location=None,
            risk_level="high",
            source="capability_registry",
        )
    ]


def advertise_effective_tool_catalog(
    stage: str,
    *,
    workspace_root: str | None = None,
    enabled_tool_ids: set[str] | None = None,
) -> tuple[str, dict[str, Any]]:
    """Advertise tool catalog for a stage, optionally filtered by stage tool config.

    If enabled_tool_ids is provided, only entries whose `tool_id` is in the set are included.
    This is intended for the "prompt chain" so the model only sees tools that the user enabled.
    """
    root = workspace_root or os.getcwd()
    skill_entries, skill_skipped = _load_skill_entries(stage, root)
    cli_entries, cli_skipped = _load_cli_entries(stage, root)
    script_entries, script_skipped = _load_script_entries(stage, root)
    mcp_entries = _load_mcp_entries(stage, root)
    bash_entries = _load_bash_entries(stage, root)

    orchestration = _dedupe([e for e in skill_entries if e.layer == "orchestration"])
    capability = _dedupe(mcp_entries + cli_entries + bash_entries + script_entries)

    if enabled_tool_ids is not None:
        # User's stage_tools.json is the single source of truth: only tools explicitly
        # enabled by the user are visible to the model.
        # Repo-declared tools (.harness/cli_tools.json etc.) are used as the "capability
        # declaration" and as the seed for first-run defaults (see
        # core/stage_tool_config.default_enabled_tool_ids), but they do NOT auto-enable
        # themselves once the user has a config.
        orchestration = [e for e in orchestration if e.tool_id and e.tool_id in enabled_tool_ids]
        capability = [e for e in capability if e.tool_id and e.tool_id in enabled_tool_ids]

    md_parts = [
        "## Tool Catalog (this stage)",
        "",
        "### Orchestration Layer (Skills)",
        _render_entries(orchestration),
        "",
        "### Capability Layer (MCP / CLI / Bash / Scripts)",
        "#### MCP Servers (session-injected)",
        _render_entries([e for e in capability if e.type == "mcp"]),
        "",
        "#### Direct CLI allowlist (only these CLI tools may be invoked via terminal.execute)",
        _render_entries([e for e in capability if e.type == "cli"]),
        "",
        "#### Shell / Bash",
        _render_entries([e for e in capability if e.type == "bash"]),
        "",
        "#### Local Scripts",
        _render_entries([e for e in capability if e.type == "script"]),
        "",
        "Constraints:",
        "- Use only tools listed above.",
        "- Direct CLI tool_ids are allowlisted per stage. If `bash:shell` is enabled for this stage, direct CLI calls are also allowed by default.",
        "- Shell / bash / compound commands are only allowed when the bash entry is listed for this stage.",
        "- CLI and shell tools must be run via terminal.execute.",
        "- Scripts should be run from the workspace root unless specified otherwise.",
        "",
    ]
    md = "\n".join(md_parts).strip() + "\n"

    payload = {
        "stage": stage,
        "entries": [asdict(e) for e in orchestration + capability],
        "skipped": {
            "skills": skill_skipped,
            "cli": cli_skipped,
            "scripts": script_skipped,
        },
        "stage_tool_config": {
            "enabled_tool_ids_present": enabled_tool_ids is not None,
            "enabled_tool_ids": sorted(list(enabled_tool_ids)) if enabled_tool_ids is not None else None,
        },
    }
    append_event("tool_catalog_advertised", state=stage, data=payload)
    return md, payload


def _render_entries(entries: list[ToolEntry]) -> str:
    if not entries:
        return "(none)"
    lines: list[str] = []
    for entry in entries:
        parts = [f"- `{entry.name}`"]
        if entry.location:
            parts.append(f"({entry.location})")
        if entry.summary:
            parts.append(f"- {entry.summary}")
        lines.append(" ".join(parts))
    return "\n".join(lines)


def _dedupe(entries: list[ToolEntry]) -> list[ToolEntry]:
    seen: set[tuple[str, str, str, str | None]] = set()
    out: list[ToolEntry] = []
    for entry in entries:
        key = (entry.layer, entry.type, entry.name, entry.location)
        if key in seen:
            continue
        seen.add(key)
        out.append(entry)
    return out


def build_tool_catalog_payload(stage: str | None, workspace_root: str | None = None) -> dict[str, Any]:
    """Build the structured tool catalog payload.

    This is a pure function (no trace side effects). The Harness runtime can choose
    to record it in trace separately (see `advertise_tool_catalog`), while UI/other
    callers can consume it safely.
    """
    root = workspace_root or os.getcwd()
    skill_entries, skill_skipped = _load_skill_entries(stage, root)
    cli_entries, cli_skipped = _load_cli_entries(stage, root)
    script_entries, script_skipped = _load_script_entries(stage, root)
    mcp_entries = _load_mcp_entries(stage, root)
    bash_entries = _load_bash_entries(stage, root)

    orchestration = _dedupe([e for e in skill_entries if e.layer == "orchestration"])
    capability = _dedupe(mcp_entries + cli_entries + bash_entries + script_entries)

    return {
        "stage": stage,
        "entries": [asdict(e) for e in orchestration + capability],
        "skipped": {
            "skills": skill_skipped,
            "cli": cli_skipped,
            "scripts": script_skipped,
        },
    }


def advertise_tool_catalog(stage: str, workspace_root: str | None = None) -> tuple[str, dict[str, Any]]:
    root = workspace_root or os.getcwd()
    skill_entries, skill_skipped = _load_skill_entries(stage, root)
    cli_entries, cli_skipped = _load_cli_entries(stage, root)
    script_entries, script_skipped = _load_script_entries(stage, root)
    mcp_entries = _load_mcp_entries(stage, root)
    bash_entries = _load_bash_entries(stage, root)

    orchestration = _dedupe([e for e in skill_entries if e.layer == "orchestration"])
    capability = _dedupe(mcp_entries + cli_entries + bash_entries + script_entries)

    md_parts = [
        "## Tool Catalog (this stage)",
        "",
        "### Orchestration Layer (Skills)",
        _render_entries(orchestration),
        "",
        "### Capability Layer (MCP / CLI / Bash / Scripts)",
        "#### MCP Servers (session-injected)",
        _render_entries(mcp_entries),
        "",
        "#### CLI Allowlist (terminal.execute)",
        _render_entries(cli_entries),
        "",
        "#### Shell / Bash",
        _render_entries(bash_entries),
        "",
        "#### Local Scripts",
        _render_entries(script_entries),
        "",
        "Constraints:",
        "- Use only tools listed above.",
        "- CLI and shell tools must be run via terminal.execute.",
        "- Scripts should be run from the workspace root unless specified otherwise.",
        "",
    ]
    md = "\n".join(md_parts).strip() + "\n"

    payload = {
        "stage": stage,
        "entries": [asdict(e) for e in orchestration + capability],
        "skipped": {
            "skills": skill_skipped,
            "cli": cli_skipped,
            "scripts": script_skipped,
        },
    }
    append_event("tool_catalog_advertised", state=stage, data=payload)
    return md, payload
