import asyncio
import asyncio.subprocess as aio_subprocess
import hashlib
import json
import logging
import os
import queue
import re
import threading
import urllib.parse
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict

from acp import PROTOCOL_VERSION, Client, RequestError, connect_to_agent, text_block
from acp.schema import (
    ClientCapabilities,
    Implementation,
    PermissionOption,
    RequestPermissionResponse,
    AllowedOutcome,
    DeniedOutcome,
    WriteTextFileResponse,
    ReadTextFileResponse,
    CreateTerminalResponse,
    TerminalOutputResponse,
    ReleaseTerminalResponse,
    WaitForTerminalExitResponse,
    KillTerminalResponse,
    ToolCall,
    EnvVariable,
    FileSystemCapabilities,
    HttpHeader,
    HttpMcpServer,
    SseMcpServer,
    McpServerStdio,
)

logger = logging.getLogger(__name__)

DEFAULT_ACP_STDIO_LIMIT_BYTES = 4 * 1024 * 1024

from core.sandbox_policy import is_tool_call_allowed_in_workspace
from core.sandbox_policy import extract_paths_from_tool_call
from core.sandbox_policy import DEFAULT_TERMINAL_OUTPUT_BYTE_LIMIT
from core.sandbox_policy import normalize_process_exit
from core.sandbox_policy import validate_terminal_request
from core.run_trace import append_event
from core.harness_gate import default_gate
from core.stage_tool_config import enabled_tool_ids_for_stage, infer_tool_id_from_policy_context, load_stage_tool_config
from core.context_manager import update_progress_json_atomic
from core.capability_registry import (
    default_registry,
    evaluate_policy,
    normalize_terminal_request,
    normalize_tool_call,
    resolve_capability,
)
from core.mcp_config import (
    filter_session_mcp_servers_by_capability,
    filter_session_mcp_servers_by_enabled_tool_ids,
    load_effective_mcp_servers,
)


def _env_flag(name: str, default: bool) -> bool:
    raw = str(os.environ.get(name) or "").strip().lower()
    if not raw:
        return default
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    return default


def _enforce_exec_allowlist_at_terminal_create() -> bool:
    # Default-on; can be disabled for rollback.
    return _env_flag("HARNESS_ENFORCE_EXEC_ALLOWLIST_AT_TERMINAL_CREATE", True)


def _acp_stdio_limit_bytes() -> int:
    raw = str(os.environ.get("HARNESS_ACP_STDIO_LIMIT_BYTES") or "").strip()
    if not raw:
        return DEFAULT_ACP_STDIO_LIMIT_BYTES
    try:
        value = int(raw)
    except ValueError:
        logger.warning(
            "Invalid HARNESS_ACP_STDIO_LIMIT_BYTES=%r, falling back to default=%s",
            raw,
            DEFAULT_ACP_STDIO_LIMIT_BYTES,
        )
        return DEFAULT_ACP_STDIO_LIMIT_BYTES
    if value <= 0:
        logger.warning(
            "Non-positive HARNESS_ACP_STDIO_LIMIT_BYTES=%s, falling back to default=%s",
            value,
            DEFAULT_ACP_STDIO_LIMIT_BYTES,
        )
        return DEFAULT_ACP_STDIO_LIMIT_BYTES
    return value


def _require_absolute_path(path: str, field_name: str) -> str:
    candidate = str(path or "")
    if not candidate or not os.path.isabs(candidate):
        raise RequestError.invalid_params({field_name: candidate, "reason": f"{field_name}_must_be_absolute"})
    return os.path.realpath(candidate)


def _ensure_workspace_path(path: str, workspace_root: str | None) -> str:
    if not workspace_root:
        return path
    try:
        common = os.path.commonpath([os.path.realpath(path), workspace_root])
    except ValueError:
        common = ""
    if common != workspace_root:
        raise RequestError.invalid_params({"path": path, "reason": "path_must_be_within_workspace"})
    return path


def _build_client_capabilities() -> ClientCapabilities:
    fs_cap = FileSystemCapabilities(write_text_file=True, read_text_file=True)
    return ClientCapabilities(fs=fs_cap, terminal=True, auth=None)


def _validate_initialize_response(init_response: Any) -> dict[str, Any]:
    dumped = init_response.model_dump()
    protocol_version = dumped.get("protocol_version")
    if protocol_version != PROTOCOL_VERSION:
        raise RuntimeError(
            f"ACP protocol version mismatch: client={PROTOCOL_VERSION}, agent={protocol_version}"
        )
    return dumped


def _extract_session_support(agent_capabilities: dict[str, Any] | None) -> tuple[bool, bool]:
    capabilities = agent_capabilities or {}
    session_capabilities = capabilities.get("session_capabilities") or capabilities.get("sessionCapabilities") or {}
    list_capability = session_capabilities.get("list") if isinstance(session_capabilities, dict) else None
    supports_session_list = list_capability is not None
    supports_load_session = bool(capabilities.get("load_session") or capabilities.get("loadSession"))
    return supports_session_list, supports_load_session


def _normalize_stop_reason(stop_reason: Any) -> str | None:
    raw = str(stop_reason or "").strip()
    if not raw:
        return None
    lowered = raw.lower().replace("-", "_")
    aliases = {
        "finished": "end_turn",
        "endturn": "end_turn",
        "maxturnrequests": "max_turn_requests",
        "maxtokens": "max_tokens",
        "canceled": "cancelled",
    }
    normalized = aliases.get(lowered, lowered)
    valid = {"end_turn", "max_tokens", "max_turn_requests", "refusal", "cancelled"}
    return normalized if normalized in valid else raw


def _normalize_prompt_response(prompt_response: Any) -> dict[str, Any]:
    if hasattr(prompt_response, "model_dump"):
        payload = prompt_response.model_dump()
    elif isinstance(prompt_response, dict):
        payload = dict(prompt_response)
    else:
        payload = {"raw": str(prompt_response)}

    stop_reason = payload.get("stop_reason") or payload.get("stopReason")
    normalized = _normalize_stop_reason(stop_reason)
    if normalized is not None:
        payload["stop_reason"] = normalized
    return payload


def _is_cancelled_error(exc: BaseException) -> bool:
    if isinstance(exc, asyncio.CancelledError):
        return True
    msg = str(exc or "").lower()
    return any(token in msg for token in ("cancelled", "canceled", "abort", "aborted", "interrupted"))


def _pick_preferred_permission_option(options: list[PermissionOption]) -> PermissionOption | None:
    best: PermissionOption | None = None
    for option in options:
        if getattr(option, "kind", None) in {"allow_once", "allow_always"}:
            return option
        best = best or option
    return best


def _pick_preferred_reject_option(options: list[PermissionOption]) -> PermissionOption | None:
    """Pick a reject option to represent a denial (policy/user reject).

    ACP schema models denial as selecting a reject_* option (when available),
    while the cancelled outcome is reserved for prompt turn cancellation.
    """
    best: PermissionOption | None = None
    for option in options:
        if getattr(option, "kind", None) in {"reject_once", "reject_always"}:
            return option
        best = best or option
    return None


_RECOVERABLE_NONCOMPLIANCE_REASONS: set[str] = {
    # Config / stage tool allowlist gating
    "tool_not_enabled_for_stage",
    "unknown_tool_identity",
    # Workspace sandbox
    "outside_workspace",
    "missing_workspace_root",
    "missing_paths_for_write",
}


def _extract_prompt_capabilities(agent_capabilities: dict[str, Any] | None) -> dict[str, bool]:
    capabilities = agent_capabilities or {}
    prompt_caps = capabilities.get("prompt_capabilities") or capabilities.get("promptCapabilities") or {}
    return {
        "text": True,
        "resource_link": True,
        "image": bool(prompt_caps.get("image")),
        "audio": bool(prompt_caps.get("audio")),
        "embedded_context": bool(prompt_caps.get("embedded_context") or prompt_caps.get("embeddedContext")),
    }


def _normalize_prompt_blocks(prompt_text: str | None, prompt_blocks: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    if prompt_blocks is not None:
        if not isinstance(prompt_blocks, list) or not prompt_blocks:
            raise ValueError("prompt_blocks must be a non-empty list")
        normalized: list[dict[str, Any]] = []
        for block in prompt_blocks:
            if hasattr(block, "model_dump"):
                normalized.append(block.model_dump())
            elif isinstance(block, dict):
                normalized.append(dict(block))
            else:
                raise ValueError("prompt_blocks entries must be dict-like ACP content blocks")
        return normalized
    default_block = text_block(str(prompt_text or ""))
    if hasattr(default_block, "model_dump"):
        return [{k: v for k, v in default_block.model_dump().items() if v is not None}]
    if isinstance(default_block, dict):
        return [{k: v for k, v in dict(default_block).items() if v is not None}]
    return [{"type": "text", "text": str(prompt_text or "")}]


def _validate_embedded_resource(resource: Any) -> None:
    if not isinstance(resource, dict):
        raise ValueError("resource content block must contain a resource object")
    uri = str(resource.get("uri") or "").strip()
    has_text = isinstance(resource.get("text"), str)
    has_blob = isinstance(resource.get("blob"), str)
    if not uri:
        raise ValueError("embedded resource must include resource.uri")
    if has_text == has_blob:
        raise ValueError("embedded resource must include exactly one of resource.text or resource.blob")


def _validate_prompt_blocks(prompt_blocks: list[dict[str, Any]], prompt_capabilities: dict[str, bool]) -> None:
    if not prompt_blocks:
        raise ValueError("prompt must contain at least one content block")
    for idx, block in enumerate(prompt_blocks):
        if not isinstance(block, dict):
            raise ValueError(f"prompt block #{idx + 1} must be an object")
        block_type = str(block.get("type") or "").strip()
        if block_type == "text":
            if not isinstance(block.get("text"), str):
                raise ValueError(f"text block #{idx + 1} must include text")
            continue
        if block_type == "resource_link":
            if not isinstance(block.get("uri"), str) or not str(block.get("uri") or "").strip():
                raise ValueError(f"resource_link block #{idx + 1} must include uri")
            if not isinstance(block.get("name"), str) or not str(block.get("name") or "").strip():
                raise ValueError(f"resource_link block #{idx + 1} must include name")
            continue
        if block_type == "resource":
            if not prompt_capabilities.get("embedded_context"):
                raise ValueError("agent does not advertise embeddedContext prompt capability")
            _validate_embedded_resource(block.get("resource"))
            continue
        if block_type == "image":
            if not prompt_capabilities.get("image"):
                raise ValueError("agent does not advertise image prompt capability")
            if not isinstance(block.get("data"), str) or not isinstance(block.get("mimeType"), str):
                raise ValueError(f"image block #{idx + 1} must include data and mimeType")
            continue
        if block_type == "audio":
            if not prompt_capabilities.get("audio"):
                raise ValueError("agent does not advertise audio prompt capability")
            if not isinstance(block.get("data"), str) or not isinstance(block.get("mimeType"), str):
                raise ValueError(f"audio block #{idx + 1} must include data and mimeType")
            continue
        raise ValueError(f"unsupported ACP content block type: {block_type or '<missing>'}")


def _truncate_text(value: Any, limit: int = 4000) -> str:
    if value is None:
        return ""
    s = str(value)
    return s if len(s) <= limit else s[:limit]


_PLAN_MAX_ENTRIES = 200
_PLAN_ENTRY_MAX_CONTENT_CHARS = 2000
_RAW_SESSION_UPDATE_MAX_CHARS = 8000


def _coerce_plan_entries(entries: Any) -> list[dict[str, Any]]:
    if not isinstance(entries, list):
        return []
    out: list[dict[str, Any]] = []
    for item in entries:
        if hasattr(item, "model_dump"):
            try:
                item = item.model_dump()
            except Exception:
                item = None
        if not isinstance(item, dict):
            continue
        content = item.get("content")
        priority = item.get("priority")
        status = item.get("status")
        out.append(
            {
                "content": str(content) if content is not None else "",
                "priority": str(priority) if priority is not None else "",
                "status": str(status) if status is not None else "",
            }
        )
    return out


def _bound_plan_entries(entries: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], bool, int]:
    """Return (bounded_entries, truncated, dropped_entries)."""
    truncated = False
    dropped_entries = 0

    bounded_entries: list[dict[str, Any]] = []
    for item in entries[:_PLAN_MAX_ENTRIES]:
        content = str(item.get("content") or "")
        if len(content) > _PLAN_ENTRY_MAX_CONTENT_CHARS:
            truncated = True
            content = content[:_PLAN_ENTRY_MAX_CONTENT_CHARS]
        priority = str(item.get("priority") or "")
        status = str(item.get("status") or "")
        bounded_entries.append({"content": content, "priority": priority, "status": status})

    if len(entries) > _PLAN_MAX_ENTRIES:
        truncated = True
        dropped_entries = len(entries) - _PLAN_MAX_ENTRIES

    return bounded_entries, truncated, dropped_entries


def _plan_fingerprint(entries: list[dict[str, Any]]) -> str:
    """Stable fingerprint for a plan update (future stuck/loop detection)."""
    normalized = [
        {
            "content": str(item.get("content") or "").strip(),
            "priority": str(item.get("priority") or "").strip().lower(),
            "status": str(item.get("status") or "").strip().lower(),
        }
        for item in entries
    ]
    raw = json.dumps(normalized, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _file_uri_to_path(uri: Any) -> str | None:
    raw = str(uri or "").strip()
    if not raw.startswith("file://"):
        return None
    parsed = urllib.parse.urlparse(raw)
    if parsed.scheme != "file" or not parsed.path:
        return None
    return os.path.realpath(urllib.parse.unquote(parsed.path))


def _summarize_content_block(block: Any) -> dict[str, Any] | None:
    if not isinstance(block, dict):
        return None
    block_type = str(block.get("type") or "").strip()
    if not block_type:
        return None
    summary: dict[str, Any] = {"type": block_type}
    if block_type == "text":
        text = str(block.get("text") or "")
        summary["text_preview"] = _truncate_text(text, limit=400)
        summary["text_length"] = len(text)
        return summary
    if block_type in {"image", "audio"}:
        mime_type = block.get("mimeType") or block.get("mime_type")
        if mime_type:
            summary["mimeType"] = mime_type
        if block.get("uri"):
            summary["uri"] = block.get("uri")
        data = block.get("data")
        if isinstance(data, str):
            summary["data_length"] = len(data)
        return summary
    if block_type == "resource_link":
        for key in ("uri", "name", "title", "description", "mimeType", "size"):
            if block.get(key) is not None:
                summary[key] = block.get(key)
        file_path = _file_uri_to_path(block.get("uri"))
        if file_path:
            summary["path"] = file_path
        return summary
    if block_type == "resource":
        resource = block.get("resource") or {}
        if not isinstance(resource, dict):
            summary["resource"] = _truncate_text(resource, limit=200)
            return summary
        for key in ("uri", "mimeType"):
            if resource.get(key) is not None:
                summary[key] = resource.get(key)
        text = resource.get("text")
        blob = resource.get("blob")
        if isinstance(text, str):
            summary["text_preview"] = _truncate_text(text, limit=400)
            summary["text_length"] = len(text)
        if isinstance(blob, str):
            summary["blob_length"] = len(blob)
        file_path = _file_uri_to_path(resource.get("uri"))
        if file_path:
            summary["path"] = file_path
        return summary
    return {"type": block_type, "raw_preview": _truncate_text(json.dumps(block, ensure_ascii=False), limit=400)}


def _summarize_tool_call_content(items: Any) -> tuple[list[dict[str, Any]] | None, str]:
    if not isinstance(items, list):
        return None, ""
    summaries: list[dict[str, Any]] = []
    text_parts: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        item_type = item.get("type")
        if item_type == "content":
            summary = _summarize_content_block(item.get("content"))
            if summary:
                summaries.append(summary)
                if summary.get("text_preview"):
                    text_parts.append(str(summary.get("text_preview")))
            continue
        summary = {"type": item_type or "unknown"}
        path = item.get("path") or item.get("uri")
        if path is not None:
            summary["path"] = path
        if item.get("mimeType") is not None:
            summary["mimeType"] = item.get("mimeType")
        summaries.append(summary)
    excerpt = _truncate_text("\n".join(s for s in text_parts if s).strip(), limit=4000)
    return summaries or None, excerpt



def _extract_named_tool_from_text(text: Any) -> str | None:
    raw = str(text or "").strip()
    if not raw:
        return None
    try:
        parsed = json.loads(raw)
    except Exception:
        parsed = None
    if isinstance(parsed, dict):
        name = str(parsed.get("name") or "").strip()
        return name or None
    match = re.search(r'"name"\s*:\s*"([^"\\]+)"', raw)
    if match:
        name = str(match.group(1) or "").strip()
        return name or None
    return None



def _basename_like(value: Any) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    base = os.path.basename(text)
    return base.strip() or text



def _first_observed_name(
    *,
    raw_kind: str,
    raw_title: str,
    payload: dict[str, Any],
    content_summary: list[dict[str, Any]] | None,
    content_excerpt: str,
) -> str | None:
    if raw_kind == "skill" or raw_title.lower() == "skill":
        skill_name = str(payload.get("skill_name") or payload.get("name") or "").strip()
        if not skill_name or skill_name.lower() == "skill":
            skill_name = _extract_named_tool_from_text(content_excerpt)
        if not skill_name and isinstance(content_summary, list):
            for item in content_summary:
                if not isinstance(item, dict):
                    continue
                skill_name = _extract_named_tool_from_text(item.get("text_preview"))
                if skill_name:
                    break
        return skill_name or None

    if raw_kind == "mcp":
        mcp_name = str(payload.get("mcp_name") or payload.get("name") or raw_title or "").strip()
        if mcp_name and mcp_name.lower() != "mcp":
            return mcp_name

    return None



def _infer_observed_tool_label(
    *,
    capability: str | None,
    tool_id: str | None,
    policy_context: dict[str, Any] | None,
    raw_title: str,
    payload: dict[str, Any],
) -> str | None:
    cap = str(capability or "").strip()
    if not cap:
        return None
    stable_name = str(tool_id or "").split(":", 1)[1].strip() if ":" in str(tool_id or "") else ""
    ctx = policy_context if isinstance(policy_context, dict) else {}

    if cap == "terminal.bash":
        return stable_name or "bash"
    if cap == "terminal.cli":
        return stable_name or _basename_like(ctx.get("binary") or ctx.get("command") or raw_title) or cap
    if cap == "tool.py_script":
        return stable_name or str(ctx.get("python_entry") or "").strip() or cap
    if cap in {"tool.skill", "tool.mcp"}:
        return stable_name or None
    if cap in {"fs.read", "fs.write"}:
        path = (
            payload.get("path")
            or payload.get("Path")
            or payload.get("target_path")
            or payload.get("resolved_path")
            or payload.get("file_path")
        )
        return _basename_like(path) or raw_title or cap
    return raw_title or cap



def _infer_observed_tool_identity(
    *,
    title: Any,
    kind: Any,
    raw_input: Any,
    content_summary: list[dict[str, Any]] | None,
    content_excerpt: str,
) -> tuple[str | None, str | None, str | None, str | None]:
    raw_kind = str(kind or "").strip().lower()
    raw_title = str(title or "").strip()
    payload = dict(raw_input) if isinstance(raw_input, dict) else {}

    observed_name = _first_observed_name(
        raw_kind=raw_kind,
        raw_title=raw_title,
        payload=payload,
        content_summary=content_summary,
        content_excerpt=content_excerpt,
    )
    if raw_kind == "skill" and observed_name:
        payload.setdefault("skill_name", observed_name)
        payload.setdefault("name", observed_name)
    if raw_kind == "mcp" and observed_name:
        payload.setdefault("mcp_name", observed_name)
        payload.setdefault("name", observed_name)

    tool_call = type(
        "ObservedToolCall",
        (),
        {
            "kind": raw_kind or None,
            "title": raw_title or None,
            "raw_input": payload,
            "rawInput": payload,
        },
    )()
    normalized = normalize_tool_call(tool_call)
    resolved = resolve_capability(default_registry(), normalized)
    observed_capability = str(resolved.capability_name or "").strip() or None
    policy_context = dict(resolved.policy_context or {})
    if raw_kind == "skill" and observed_name:
        policy_context.setdefault("skill_name", observed_name)
        policy_context.setdefault("name", observed_name)
    if raw_kind == "mcp" and observed_name:
        policy_context.setdefault("mcp_name", observed_name)
        policy_context.setdefault("name", observed_name)
    observed_tool_id = infer_tool_id_from_policy_context(
        normalized_kind=normalized.normalized_kind,
        resolved_capability=observed_capability,
        policy_context=policy_context,
        title=raw_title or None,
    )
    observed_tool_label = _infer_observed_tool_label(
        capability=observed_capability,
        tool_id=observed_tool_id,
        policy_context=policy_context,
        raw_title=raw_title,
        payload=payload,
    )
    if observed_capability in {"tool.skill", "tool.mcp"} and observed_tool_label and not observed_name:
        observed_name = observed_tool_label
    return observed_name, observed_tool_id, observed_capability, observed_tool_label


def _cancelled_tool_call_meta() -> dict[str, Any]:
    return {
        "harness": {
            "cancelled": True,
            "synthetic": True,
            "reason": "prompt_turn_cancelled",
        }
    }


def _is_cancelled_tool_call_update(payload: dict[str, Any]) -> bool:
    meta = payload.get("_meta")
    if not isinstance(meta, dict):
        return False
    harness_meta = meta.get("harness")
    return bool(isinstance(harness_meta, dict) and harness_meta.get("cancelled"))


def _build_cancelled_tool_call_update(tool_call_id: str, record: dict[str, Any] | None = None) -> dict[str, Any]:
    # Synthetic updates should use ACP schema field names (camelCase) so that
    # downstream consumers do not need schema-specific shims.
    payload: dict[str, Any] = {
        "sessionUpdate": "tool_call_update",
        "toolCallId": tool_call_id,
        "status": "failed",
        "_meta": _cancelled_tool_call_meta(),
        "content": [
            {
                "type": "content",
                "content": {
                    "type": "text",
                    "text": "Tool call cancelled because the current prompt turn was cancelled.",
                },
            }
        ],
    }
    if isinstance(record, dict):
        if record.get("title") is not None:
            payload["title"] = record.get("title")
        if record.get("kind") is not None:
            payload["kind"] = record.get("kind")
    return payload


def _gate_denial_tool_call_meta(reason: str, suggestion: str) -> dict[str, Any]:
    return {
        "harness": {
            "gate_denial": True,
            "synthetic": True,
            "reason": str(reason or ""),
            "suggestion": str(suggestion or ""),
        }
    }


def _build_gate_denial_tool_call_update(
    tool_call_id: str,
    *,
    title: Any,
    kind: Any,
    reason: str,
    suggestion: str,
) -> dict[str, Any]:
    lines = [
        "Tool call denied by Harness gate.",
        f"reason: {str(reason or '')}",
    ]
    if suggestion:
        lines.append(f"suggestion: {suggestion}")
    return {
        "sessionUpdate": "tool_call_update",
        "toolCallId": tool_call_id,
        "title": title,
        "kind": kind,
        "status": "failed",
        "_meta": _gate_denial_tool_call_meta(reason, suggestion),
        "content": [
            {
                "type": "content",
                "content": {
                    "type": "text",
                    "text": "\n".join(lines),
                },
            }
        ],
    }


@dataclass
class _TerminalSession:
    terminal_id: str
    command: str
    args: list[str]
    cwd: str
    env: dict[str, str]
    output_limit: int
    process: asyncio.subprocess.Process
    output_chunks: list[str] = field(default_factory=list)
    output_bytes: int = 0
    truncated: bool = False
    stdout_task: asyncio.Task | None = None
    stderr_task: asyncio.Task | None = None
    exit_code: int | None = None
    signal: str | None = None

    def append_output(self, text: str) -> None:
        if not text:
            return
        encoded = text.encode("utf-8", errors="replace")
        decoded = encoded.decode("utf-8", errors="ignore")
        if not decoded:
            return
        self.output_chunks.append(decoded)
        self.output_bytes += len(decoded.encode("utf-8", errors="replace"))

        while self.output_bytes > self.output_limit and self.output_chunks:
            self.truncated = True
            overflow = self.output_bytes - self.output_limit
            head = self.output_chunks[0]
            head_bytes = head.encode("utf-8", errors="replace")
            if len(head_bytes) <= overflow:
                self.output_chunks.pop(0)
                self.output_bytes -= len(head_bytes)
                continue

            trimmed = head_bytes[overflow:].decode("utf-8", errors="ignore")
            if not trimmed:
                self.output_chunks.pop(0)
                self.output_bytes -= len(head_bytes)
                continue
            removed = len(head_bytes) - len(trimmed.encode("utf-8", errors="replace"))
            self.output_chunks[0] = trimmed
            self.output_bytes -= removed

    def output_text(self) -> str:
        return "".join(self.output_chunks)

def _substitute_workspace_vars(val: Any, workspace_folder: str) -> Any:
    if isinstance(val, str):
        return val.replace("${workspaceFolder}", workspace_folder)
    if isinstance(val, list):
        return [_substitute_workspace_vars(v, workspace_folder) for v in val]
    if isinstance(val, dict):
        return {k: _substitute_workspace_vars(v, workspace_folder) for k, v in val.items()}
    return val

def _coerce_headers(value: Any) -> list[HttpHeader]:
    if value is None:
        return []
    if isinstance(value, dict):
        return [HttpHeader(name=str(k), value=str(v)) for k, v in value.items()]
    if isinstance(value, list):
        headers: list[HttpHeader] = []
        for item in value:
            if isinstance(item, HttpHeader):
                headers.append(item)
                continue
            if isinstance(item, dict):
                name = item.get("name")
                val = item.get("value")
                if name is not None and val is not None:
                    headers.append(HttpHeader(name=str(name), value=str(val)))
        return headers
    return []

def _coerce_env(value: Any) -> list[EnvVariable]:
    if value is None:
        return []
    if isinstance(value, dict):
        return [EnvVariable(name=str(k), value=str(v)) for k, v in value.items()]
    if isinstance(value, list):
        envs: list[EnvVariable] = []
        for item in value:
            if isinstance(item, EnvVariable):
                envs.append(item)
                continue
            if isinstance(item, dict):
                name = item.get("name")
                val = item.get("value")
                if name is not None and val is not None:
                    envs.append(EnvVariable(name=str(name), value=str(val)))
        return envs
    return []


async def _shutdown_subprocess(proc: Any, timeout_sec: float = 2.0) -> None:
    if not proc or getattr(proc, "returncode", None) is not None:
        return
    proc.terminate()
    try:
        await asyncio.wait_for(proc.wait(), timeout=timeout_sec)
        return
    except asyncio.TimeoutError:
        append_event("acp_shutdown_forced", state=None, data={"action": "kill", "reason": "terminate_timeout"})
    except ProcessLookupError:
        return
    try:
        proc.kill()
    except ProcessLookupError:
        return
    try:
        await asyncio.wait_for(proc.wait(), timeout=timeout_sec)
    except asyncio.TimeoutError:
        append_event("acp_shutdown_forced", state=None, data={"action": "give_up", "reason": "kill_timeout"})

class HarnessClientImpl(Client):
    """
    Implementation of the ACP Client protocol.
    Intercepts file system and terminal operations to enforce the sandbox.
    """
    def __init__(self, updates_list: list, workspace_root: str | None = None, repo_root: str | None = None):
        self.updates = updates_list
        self.workspace_root = os.path.realpath(workspace_root) if workspace_root else None
        # repo_root: location of `.harness/*` config; defaults to workspace_root then cwd.
        if repo_root:
            self.repo_root = os.path.realpath(repo_root)
        elif self.workspace_root:
            self.repo_root = self.workspace_root
        else:
            self.repo_root = os.getcwd()
        self.terminals: dict[str, _TerminalSession] = {}
        self.session_infos: dict[str, dict[str, Any]] = {}
        self.pending_tool_calls: dict[str, dict[str, dict[str, Any]]] = {}
        self.pending_terminal_permissions: dict[str, list[dict[str, Any]]] = {}
        # Plan updates are session-scoped and can arrive multiple times per session.
        self._plan_seq: dict[str, int] = {}

    def _current_stage(self) -> str | None:
        try:
            return os.environ.get("HARNESS_STAGE")
        except Exception:
            return None

    def _progress_file(self) -> str | None:
        try:
            path = os.environ.get("HARNESS_PROGRESS_FILE")
        except Exception:
            path = None
        return str(path) if path else None

    def _record_gate_denial_to_progress(
        self,
        *,
        stage: str | None,
        kind: str,
        reason: str,
        details: dict[str, Any],
        suggestion: str,
        session_id: str | None = None,
        tool_call: ToolCall | None = None,
    ) -> None:
        stage_name = str(stage or "UNKNOWN")
        reason_str = str(reason or "")
        detail_map = dict(details or {})

        if session_id and tool_call is not None:
            tool_call_id = getattr(tool_call, "tool_call_id", None) or getattr(tool_call, "toolCallId", None)
            if tool_call_id:
                payload = _build_gate_denial_tool_call_update(
                    str(tool_call_id),
                    title=getattr(tool_call, "title", None) or getattr(tool_call, "name", None),
                    kind=getattr(tool_call, "kind", None),
                    reason=reason_str,
                    suggestion=str(suggestion or ""),
                )
                self.updates.append(payload)

        if reason_str not in _RECOVERABLE_NONCOMPLIANCE_REASONS:
            return

        progress_file = self._progress_file()
        if progress_file:
            def _updater(doc: dict[str, Any]) -> dict[str, Any]:
                meta = doc.setdefault("metadata", {})
                record = {
                    "ts": datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                    "stage": stage_name,
                    "kind": str(kind or "unknown"),
                    "reason": reason_str,
                    "details": detail_map,
                    "suggestion": str(suggestion or ""),
                }
                meta["last_gate_denial"] = record
                hist_map = meta.get("gate_denial_history")
                if not isinstance(hist_map, dict):
                    hist_map = {}
                    meta["gate_denial_history"] = hist_map
                hist = hist_map.get(stage_name)
                if not isinstance(hist, list):
                    hist = []
                hist.append(record)
                hist_map[stage_name] = [x for x in hist if isinstance(x, dict)][-50:]
                return doc

            update_progress_json_atomic(progress_file, _updater)
        append_event("tool_gate_denied", state=stage_name, data={"reason": reason_str, "details": detail_map, "suggestion": suggestion})

    def _append_terminal_event(self, event_type: str, **data: Any) -> None:
        append_event(event_type, state=self._current_stage(), data=data)

    def _record_terminal_policy(
        self,
        command: str | None,
        args: list[str],
        cwd: str,
        decision: str,
        reason: str,
        env_count: int,
        resolved_capability: str | None = None,
        normalized_kind: str | None = None,
        intent_family: str | None = None,
        resolution_reason: str | None = None,
        policy_context: dict[str, Any] | None = None,
    ) -> None:
        append_event("capability_policy_decision", state=self._current_stage(), data={
            "tool_name": resolved_capability or "unknown",
            "kind": normalized_kind or "execute",
            "resolved_capability": resolved_capability,
            "intent_family": intent_family,
            "resolution_reason": resolution_reason,
            "policy_context": policy_context or {},
            "decision": decision,
            "reason": reason,
            "cwd": cwd,
            "command": command,
            "args": args,
            "env_count": env_count,
        })

    def _enqueue_terminal_permission(self, session_id: str, payload: dict[str, Any]) -> None:
        queue = self.pending_terminal_permissions.setdefault(session_id, [])
        queue.append(payload)

    def _dequeue_terminal_permission(self, session_id: str) -> dict[str, Any] | None:
        queue = self.pending_terminal_permissions.get(session_id)
        if not queue:
            return None
        item = queue.pop(0)
        if not queue:
            self.pending_terminal_permissions.pop(session_id, None)
        return item

    def seed_session_info(self, session_id: str, cwd: str) -> None:
        self.session_infos[session_id] = {
            "sessionId": session_id,
            "cwd": cwd,
        }

    def get_session_info(self, session_id: str) -> dict[str, Any] | None:
        session_info = self.session_infos.get(session_id)
        if not isinstance(session_info, dict):
            return None
        return dict(session_info)

    def _track_tool_call(
        self,
        session_id: str,
        tool_call_id: str | None,
        title: Any,
        kind: Any,
        status: Any,
        raw_input: Any = None,
        locations: Any = None,
        observed_name: str | None = None,
        observed_tool_id: str | None = None,
        observed_capability: str | None = None,
        observed_tool_label: str | None = None,
    ) -> None:
        if not tool_call_id:
            return
        per_session = self.pending_tool_calls.setdefault(session_id, {})
        record = dict(per_session.get(tool_call_id) or {})
        if title is not None:
            record["title"] = title
        if kind is not None:
            record["kind"] = kind
        if status is not None:
            record["status"] = status
        if raw_input is not None:
            record["raw_input"] = raw_input
        if locations is not None:
            record["locations"] = locations
        if observed_name:
            record["observed_name"] = observed_name
        if observed_tool_id:
            record["observed_tool_id"] = observed_tool_id
        if observed_capability:
            record["observed_capability"] = observed_capability
        if observed_tool_label:
            record["observed_tool_label"] = observed_tool_label
        terminal_statuses = {"completed", "failed", "cancelled", "canceled"}
        if str(status or "").lower() in terminal_statuses:
            per_session.pop(tool_call_id, None)
            if not per_session:
                self.pending_tool_calls.pop(session_id, None)
            return
        per_session[tool_call_id] = record

    def _merge_tool_call_with_pending(self, session_id: str, tool_call: ToolCall) -> ToolCall:
        tool_call_id = getattr(tool_call, "tool_call_id", None) or getattr(tool_call, "toolCallId", None)
        if not tool_call_id:
            return tool_call
        per_session = self.pending_tool_calls.get(session_id)
        if not isinstance(per_session, dict):
            return tool_call
        cached = per_session.get(str(tool_call_id))
        if not isinstance(cached, dict):
            return tool_call

        merged: dict[str, Any] = {
            "tool_call_id": tool_call_id,
        }
        for field in (
            "title",
            "kind",
            "raw_input",
            "locations",
            "observed_name",
            "observed_tool_id",
            "observed_capability",
            "observed_tool_label",
        ):
            cached_value = cached.get(field)
            if cached_value is not None:
                merged[field] = cached_value
        for field in ("content",):
            value = getattr(tool_call, field, None)
            if value is not None:
                merged[field] = value
        return type("MergedToolCall", (), merged)()

    def cancel_pending_tool_calls(self, session_id: str) -> list[dict[str, Any]]:
        per_session = self.pending_tool_calls.pop(session_id, {})
        if not isinstance(per_session, dict):
            return []
        cancelled_updates: list[dict[str, Any]] = []
        for tool_call_id, record in per_session.items():
            payload = _build_cancelled_tool_call_update(tool_call_id, record if isinstance(record, dict) else None)
            cancelled_updates.append(payload)
            append_event(
                "acp_tool_call_update",
                state=self._current_stage(),
                data={
                    "session_id": session_id,
                    "tool_call_id": tool_call_id,
                    "title": payload.get("title"),
                    "kind": payload.get("kind"),
                    "status": payload.get("status"),
                    "status_display": "cancelled",
                    "cancelled": True,
                    "content_excerpt": "Tool call cancelled because the current prompt turn was cancelled.",
                    "_meta": payload.get("_meta"),
                },
            )
            self.updates.append(payload)
        return cancelled_updates

    def _apply_session_info_update(self, session_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        session_info = dict(self.session_infos.get(session_id) or {"sessionId": session_id})
        if "title" in payload:
            session_info["title"] = payload.get("title")
        if "updatedAt" in payload:
            session_info["updatedAt"] = payload.get("updatedAt")
        elif "updated_at" in payload:
            session_info["updatedAt"] = payload.get("updated_at")
        if "_meta" in payload:
            session_info["_meta"] = payload.get("_meta")
        self.session_infos[session_id] = session_info
        return session_info

    async def _pump_terminal_stream(self, terminal_id: str, stream: asyncio.StreamReader | None) -> None:
        if stream is None:
            return
        try:
            while True:
                chunk = await stream.read(4096)
                if not chunk:
                    return
                session = self.terminals.get(terminal_id)
                if session is None:
                    return
                session.append_output(chunk.decode("utf-8", errors="replace"))
        except asyncio.CancelledError:
            raise
        except Exception as e:
            self._append_terminal_event("acp_terminal_stream_error", terminal_id=terminal_id, error=str(e))

    async def _finalize_terminal_session(self, session: _TerminalSession) -> None:
        if session.process.returncode is None:
            await session.process.wait()
        exit_code, signal_name = normalize_process_exit(session.process.returncode)
        session.exit_code = exit_code
        session.signal = signal_name
        tasks = [t for t in (session.stdout_task, session.stderr_task) if t is not None]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    def _get_terminal_session(self, terminal_id: str) -> _TerminalSession:
        session = self.terminals.get(terminal_id)
        if session is None:
            raise RequestError.invalid_params({"terminalId": terminal_id, "reason": "unknown_terminal"})
        return session

    async def shutdown_terminals(self) -> None:
        for terminal_id in list(self.terminals.keys()):
            try:
                await self.release_terminal(session_id="<shutdown>", terminal_id=terminal_id)
            except Exception:
                continue

    async def request_permission(self, options: list[PermissionOption], session_id: str, tool_call: ToolCall, **kwargs: Any) -> RequestPermissionResponse:
        permission_tool_call = self._merge_tool_call_with_pending(session_id, tool_call)
        title = getattr(permission_tool_call, "title", None) or getattr(tool_call, "title", None) or "<permission>"
        logger.info(f"[Sandbox] Permission requested: {title}")
        paths = extract_paths_from_tool_call(permission_tool_call)
        stage = self._current_stage()
        registry = default_registry()
        normalized_call = normalize_tool_call(permission_tool_call, paths=paths)
        resolved = resolve_capability(registry, normalized_call)
        resolved_capability = resolved.capability_name
        descriptor = resolved.descriptor
        resolution_reason = resolved.resolution_reason
        policy_context = resolved.policy_context

        # Permission-time execute calls may not include a structured command/binary identity.
        # Keep unresolved executes unresolved so malformed or compound commands surface as unknown identity.
        stage_config = load_stage_tool_config(self.repo_root)
        enabled_ids = enabled_tool_ids_for_stage(stage_config, stage)
        tool_id = infer_tool_id_from_policy_context(
            normalized_kind=normalized_call.normalized_kind,
            resolved_capability=resolved_capability,
            policy_context=policy_context,
            title=title,
        )
        if tool_id:
            policy_context = dict(policy_context or {})
            policy_context["tool_id"] = tool_id
            if normalized_call.normalized_kind == "skill" and tool_id.startswith("skill:"):
                policy_context["skill_name"] = tool_id.split(":", 1)[1]
            if normalized_call.normalized_kind == "mcp" and tool_id.startswith("mcp:"):
                policy_context["mcp_name"] = tool_id.split(":", 1)[1]
        # Pre-gate wrapper around existing policy evaluation (behavior-stable).
        allowed, reason = default_gate().evaluate_pre_policy(
            descriptor=descriptor,
            stage=stage,
            kind=normalized_call.normalized_kind,
            paths=list(paths),
            workspace_root=self.workspace_root,
            resolved_capability=resolved_capability,
            policy_context=policy_context,
            tool_id=tool_id,
            enabled_tool_ids=enabled_ids,
        )
        append_event("acp_permission", state=None, data={
            "session_id": session_id,
            "title": title,
            "kind": getattr(tool_call, "kind", None),
            "normalized_kind": normalized_call.normalized_kind,
            "intent_family": normalized_call.intent_family,
            "resolved_capability": resolved_capability,
            "resolution_reason": resolution_reason,
            "policy_context": policy_context,
            "paths": paths,
        })
        append_event("capability_policy_decision", state=stage, data={
            "tool_name": resolved_capability or "unknown",
            "kind": normalized_call.normalized_kind,
            "resolved_capability": resolved_capability,
            "intent_family": normalized_call.intent_family,
            "resolution_reason": resolution_reason,
            "policy_context": policy_context,
            "decision": "allow" if allowed else "deny",
            "reason": reason,
            "paths": paths,
        })
        if not allowed:
            self._record_gate_denial_to_progress(
                stage=stage,
                kind="tool_gate",
                reason=str(reason or ""),
                details={
                    "tool_id": tool_id,
                    "enabled_tool_ids": sorted(list(enabled_ids)) if isinstance(enabled_ids, set) else None,
                    "title": title,
                    "normalized_kind": normalized_call.normalized_kind,
                    "resolved_capability": resolved_capability,
                    "intent_family": normalized_call.intent_family,
                    "resolution_reason": resolution_reason,
                },
                suggestion=(
                    "You were blocked by Harness tool gating. Use only tools enabled for this stage. "
                    "If you need an unavailable tool, either enable it in stage_tools.json or switch to an enabled alternative."
                ),
                session_id=session_id,
                tool_call=tool_call,
            )
            append_event("acp_permission", state=None, data={
                "session_id": session_id,
                "title": title,
                "kind": normalized_call.normalized_kind,
                "paths": paths,
                "decision": "deny",
                "reason": reason,
                "tool_name": resolved_capability or "unknown",
                "resolved_capability": resolved_capability,
                "intent_family": normalized_call.intent_family,
                "resolution_reason": resolution_reason,
            })
            if not options:
                raise RequestError.invalid_params({"reason": "missing_permission_options"})
            reject_opt = _pick_preferred_reject_option(options)
            if reject_opt is None:
                raise RequestError.invalid_params({"reason": "missing_reject_permission_option"})
            return RequestPermissionResponse(
                outcome=AllowedOutcome(option_id=reject_opt.option_id, outcome="selected")
            )
        if self.workspace_root and not is_tool_call_allowed_in_workspace(tool_call, self.workspace_root):
            append_event("acp_permission", state=None, data={
                "session_id": session_id,
                "title": title,
                "kind": normalized_call.normalized_kind,
                "paths": paths,
                "decision": "deny",
                "reason": "outside_workspace",
                "resolved_capability": resolved_capability,
            })
            if not options:
                raise RequestError.invalid_params({"reason": "missing_permission_options"})
            reject_opt = _pick_preferred_reject_option(options)
            if reject_opt is None:
                raise RequestError.invalid_params({"reason": "missing_reject_permission_option"})
            return RequestPermissionResponse(
                outcome=AllowedOutcome(option_id=reject_opt.option_id, outcome="selected")
            )
        if not options:
            append_event("acp_permission", state=None, data={
                "session_id": session_id,
                "title": title,
                "kind": normalized_call.normalized_kind,
                "paths": paths,
                "decision": "deny",
                "reason": "no_options",
                "resolved_capability": resolved.capability_name,
            })
            raise RequestError.invalid_params({"reason": "missing_permission_options"})
        opt = _pick_preferred_permission_option(options)
        if opt is None:
            append_event("acp_permission", state=None, data={
                "session_id": session_id,
                "title": title,
                "kind": normalized_call.normalized_kind,
                "paths": paths,
                "decision": "deny",
                "reason": "no_selectable_option",
                "resolved_capability": resolved.capability_name,
            })
            raise RequestError.invalid_params({"reason": "no_selectable_option"})
        if normalized_call.normalized_kind == "execute":
            self._enqueue_terminal_permission(session_id, {
                "resolved_capability": resolved_capability,
                "normalized_kind": normalized_call.normalized_kind,
                "intent_family": normalized_call.intent_family,
                "resolution_reason": resolution_reason,
                "policy_context": policy_context,
            })
        append_event("acp_permission", state=None, data={
            "session_id": session_id,
            "title": title,
            "kind": normalized_call.normalized_kind,
            "paths": paths,
            "decision": "allow",
            "option_id": getattr(opt, "option_id", None),
            "resolved_capability": resolved_capability,
            "intent_family": normalized_call.intent_family,
            "resolution_reason": resolution_reason,
        })
        return RequestPermissionResponse(outcome=AllowedOutcome(option_id=opt.option_id, outcome="selected"))

    async def write_text_file(self, content: str, path: str, session_id: str, **kwargs: Any) -> WriteTextFileResponse:
        """Intercepts fs.writeTextFile calls."""
        logger.info(f"[Sandbox] Intercepted write_text_file to: {path}")
        stage = self._current_stage()

        try:
            path = _require_absolute_path(path, "path")
        except RequestError:
            append_event("acp_fs_write", state=stage, data={"session_id": session_id, "path": path, "bytes": len(content or ""), "result": "deny", "reason": "path_must_be_absolute"})
            raise
        try:
            path = _ensure_workspace_path(path, self.workspace_root)
        except RequestError:
            append_event("acp_fs_write", state=stage, data={"session_id": session_id, "path": path, "bytes": len(content or ""), "result": "deny", "reason": "outside_workspace"})
            raise

        # Ensure the directory exists
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        # Actually write the file
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info(f"[Sandbox] Successfully wrote to {path}")
            append_event("acp_fs_write", state=stage, data={"session_id": session_id, "path": path, "bytes": len(content or ""), "result": "ok"})
            # Schema expects an object response for fs/write_text_file.
            return WriteTextFileResponse()
        except Exception as e:
            logger.error(f"[Sandbox] Failed to write to {path}: {e}")
            append_event("acp_fs_write", state=stage, data={"session_id": session_id, "path": path, "bytes": len(content or ""), "result": "error", "error": str(e)})
            raise RequestError(code=-32603, message=f"Failed to write file: {e}")

    async def read_text_file(self, path: str, session_id: str, limit: int | None = None, line: int | None = None, **kwargs: Any) -> ReadTextFileResponse:
        logger.info(f"[Sandbox] Intercepted read_text_file to: {path}")
        stage = self._current_stage()
        try:
            path = _require_absolute_path(path, "path")
        except RequestError:
            append_event("acp_fs_read", state=stage, data={"session_id": session_id, "path": path, "result": "deny", "reason": "path_must_be_absolute"})
            raise
        if line is not None and (not isinstance(line, int) or line < 1):
            append_event("acp_fs_read", state=stage, data={"session_id": session_id, "path": path, "result": "deny", "reason": "invalid_line", "line": line, "limit": limit})
            raise RequestError.invalid_params({"line": line, "reason": "line_must_be_positive"})
        if limit is not None and (not isinstance(limit, int) or limit < 0):
            append_event("acp_fs_read", state=stage, data={"session_id": session_id, "path": path, "result": "deny", "reason": "invalid_limit", "line": line, "limit": limit})
            raise RequestError.invalid_params({"limit": limit, "reason": "limit_must_be_non_negative"})
        try:
            path = _ensure_workspace_path(path, self.workspace_root)
        except RequestError:
            append_event("acp_fs_read", state=stage, data={"session_id": session_id, "path": path, "result": "deny", "reason": "outside_workspace", "line": line, "limit": limit})
            raise
        try:
            with open(path, 'r', encoding='utf-8') as f:
                if line is None and limit is None:
                    content = f.read()
                else:
                    lines = f.readlines()
                    start = (line - 1) if line else 0
                    end = None if limit is None else start + limit
                    content = "".join(lines[start:end])
            append_event("acp_fs_read", state=stage, data={"session_id": session_id, "path": path, "bytes": len(content or ""), "result": "ok", "line": line, "limit": limit})
            return ReadTextFileResponse(content=content)
        except Exception as e:
            logger.error(f"[Sandbox] Failed to read {path}: {e}")
            append_event("acp_fs_read", state=stage, data={"session_id": session_id, "path": path, "result": "error", "error": str(e), "line": line, "limit": limit})
            raise RequestError(code=-32603, message=f"Failed to read file: {e}")

    async def create_terminal(self, command: str, session_id: str, args: list[str] | None = None, cwd: str | None = None, env: list[EnvVariable] | None = None, output_byte_limit: int | None = None, **kwargs: Any) -> CreateTerminalResponse:
        args = [str(a) for a in (args or [])]
        normalized_call = normalize_terminal_request(command, args=args, cwd=cwd)
        # Some agents pass a whole command line as `command` (e.g. "lark-cli -h") with args empty.
        # Always prefer the normalized command/args for gating and subprocess execution.
        command = str(normalized_call.command or command)
        args = [str(a) for a in normalized_call.args]
        registry = default_registry()
        resolved = resolve_capability(registry, normalized_call)
        allowed, reason, resolved_cwd, sanitized_env = validate_terminal_request(command, args, cwd, env, self.workspace_root)

        # Enforce stage allowlist for direct CLI execution using terminal/create inputs.
        stage = self._current_stage()
        stage_config = load_stage_tool_config(self.repo_root)
        enabled_ids = enabled_tool_ids_for_stage(stage_config, stage)
        tool_id = infer_tool_id_from_policy_context(
            normalized_kind=normalized_call.normalized_kind,
            resolved_capability=resolved.capability_name,
            policy_context=resolved.policy_context,
            title=normalized_call.title,
        )
        bash_explicitly_enabled = tool_id == "bash:shell" and isinstance(enabled_ids, set) and tool_id in enabled_ids
        if allowed and _enforce_exec_allowlist_at_terminal_create() and enabled_ids is not None and normalized_call.normalized_kind == "execute":
            if not tool_id:
                allowed = False
                reason = "unknown_tool_identity"
            elif tool_id not in enabled_ids:
                allowed = False
                reason = "tool_not_enabled_for_stage"
            else:
                reason = "enabled_by_stage_config"
        if allowed:
            policy_allowed, policy_reason = evaluate_policy(
                resolved.descriptor,
                stage,
                normalized_call.normalized_kind,
                [resolved_cwd] if resolved_cwd else [],
                self.workspace_root,
                allow_high_risk=bash_explicitly_enabled,
            )
            allowed = policy_allowed
            reason = policy_reason

        pending = self._dequeue_terminal_permission(session_id)
        if allowed and pending:
            pending_capability = pending.get("resolved_capability")
            if pending_capability != resolved.capability_name:
                allowed = False
                reason = "resolved_capability_mismatch"

        self._record_terminal_policy(
            command,
            args,
            resolved_cwd,
            "allow" if allowed else "deny",
            reason,
            len(sanitized_env),
            resolved_capability=resolved.capability_name,
            normalized_kind=normalized_call.normalized_kind,
            intent_family=normalized_call.intent_family,
            resolution_reason=resolved.resolution_reason,
            policy_context=resolved.policy_context,
        )
        if not allowed:
            if reason in {"tool_not_enabled_for_stage", "unknown_tool_identity"}:
                self._record_gate_denial_to_progress(
                    stage=stage,
                    kind="tool_gate",
                    reason=str(reason or ""),
                    details={
                        "tool_id": tool_id,
                        "enabled_tool_ids": sorted(list(enabled_ids)) if isinstance(enabled_ids, set) else None,
                        "command": command,
                        "args": list(args),
                        "resolved_capability": resolved.capability_name if tool_id else None,
                        "resolution_reason": resolved.resolution_reason,
                    },
                    suggestion=(
                        "You were blocked by Harness stage tool gating at terminal/create. "
                        "Use only CLI binaries enabled for this stage, or enable the required tool_id in stage_tools.json."
                    ),
                )
            self._append_terminal_event(
                "acp_terminal_create",
                session_id=session_id,
                command=command,
                args=args,
                cwd=resolved_cwd,
                result="deny",
                reason=reason,
                resolved_capability=resolved.capability_name,
                normalized_kind=normalized_call.normalized_kind,
                intent_family=normalized_call.intent_family,
            )
            raise RequestError.invalid_params({"command": command, "cwd": resolved_cwd, "reason": reason})

        effective_limit = output_byte_limit if isinstance(output_byte_limit, int) and output_byte_limit > 0 else DEFAULT_TERMINAL_OUTPUT_BYTE_LIMIT
        proc_env = os.environ.copy()
        proc_env.update(sanitized_env)
        try:
            proc = await asyncio.create_subprocess_exec(
                command,
                *args,
                cwd=resolved_cwd,
                env=proc_env,
                stdout=aio_subprocess.PIPE,
                stderr=aio_subprocess.PIPE,
            )
        except FileNotFoundError as e:
            self._append_terminal_event(
                "acp_terminal_create",
                session_id=session_id,
                command=command,
                args=args,
                cwd=resolved_cwd,
                result="error",
                error=str(e),
                resolved_capability=resolved.capability_name,
                normalized_kind=normalized_call.normalized_kind,
                intent_family=normalized_call.intent_family,
            )
            raise RequestError.invalid_params({"command": command, "reason": "command_not_found"})

        terminal_id = f"term_{uuid.uuid4().hex[:10]}"
        session = _TerminalSession(
            terminal_id=terminal_id,
            command=str(command),
            args=args,
            cwd=resolved_cwd,
            env=sanitized_env,
            output_limit=effective_limit,
            process=proc,
        )
        session.stdout_task = asyncio.create_task(self._pump_terminal_stream(terminal_id, proc.stdout))
        session.stderr_task = asyncio.create_task(self._pump_terminal_stream(terminal_id, proc.stderr))
        self.terminals[terminal_id] = session
        self._append_terminal_event(
            "acp_terminal_create",
            session_id=session_id,
            terminal_id=terminal_id,
            command=command,
            args=args,
            cwd=resolved_cwd,
            result="ok",
            output_byte_limit=effective_limit,
            resolved_capability=resolved.capability_name,
            normalized_kind=normalized_call.normalized_kind,
            intent_family=normalized_call.intent_family,
        )
        return CreateTerminalResponse(terminalId=terminal_id)

    async def terminal_output(self, session_id: str, terminal_id: str, **kwargs: Any) -> TerminalOutputResponse:
        session = self._get_terminal_session(terminal_id)
        exit_status = None
        if session.process.returncode is not None:
            await self._finalize_terminal_session(session)
            exit_status = {"exitCode": session.exit_code, "signal": session.signal}
        output = session.output_text()
        self._append_terminal_event(
            "acp_terminal_output",
            session_id=session_id,
            terminal_id=terminal_id,
            output=output,
            bytes=len(output.encode("utf-8", errors="replace")),
            truncated=session.truncated,
            completed=session.process.returncode is not None,
            exit_code=session.exit_code,
            signal=session.signal,
        )
        return TerminalOutputResponse(output=output, truncated=session.truncated, exitStatus=exit_status)

    async def release_terminal(self, session_id: str, terminal_id: str, **kwargs: Any) -> ReleaseTerminalResponse | None:
        session = self._get_terminal_session(terminal_id)
        was_running = session.process.returncode is None
        if was_running:
            await _shutdown_subprocess(session.process, timeout_sec=0.5)
        await self._finalize_terminal_session(session)
        self.terminals.pop(terminal_id, None)
        self._append_terminal_event(
            "acp_terminal_release",
            session_id=session_id,
            terminal_id=terminal_id,
            exit_code=session.exit_code,
            signal=session.signal,
            killed_running_process=was_running,
        )
        return ReleaseTerminalResponse()

    async def wait_for_terminal_exit(self, session_id: str, terminal_id: str, **kwargs: Any) -> WaitForTerminalExitResponse:
        session = self._get_terminal_session(terminal_id)
        await self._finalize_terminal_session(session)
        self._append_terminal_event("acp_terminal_wait", session_id=session_id, terminal_id=terminal_id, exit_code=session.exit_code, signal=session.signal)
        return WaitForTerminalExitResponse(exitCode=session.exit_code, signal=session.signal)

    async def kill_terminal(self, session_id: str, terminal_id: str, **kwargs: Any) -> KillTerminalResponse | None:
        session = self._get_terminal_session(terminal_id)
        await _shutdown_subprocess(session.process, timeout_sec=0.5)
        await self._finalize_terminal_session(session)
        self._append_terminal_event("acp_terminal_kill", session_id=session_id, terminal_id=terminal_id, exit_code=session.exit_code, signal=session.signal)
        return KillTerminalResponse()

    async def session_update(self, session_id: str, update: Any, **kwargs: Any) -> None:
        """Called by the agent to stream updates (thoughts, messages, etc)"""
        stage = self._current_stage()

        def dump_summary(obj: Any, limit: int = 4000) -> str:
            try:
                return _truncate_text(json.dumps(obj, ensure_ascii=False), limit=limit)
            except Exception:
                return _truncate_text(str(obj), limit=limit)

        def normalize_update(u: Any) -> dict:
            if hasattr(u, "model_dump"):
                try:
                    return u.model_dump()
                except Exception:
                    pass
            if isinstance(u, dict):
                return u
            return {"raw": str(u)}

        payload = normalize_update(update)
        session_update_kind = payload.get("session_update") or payload.get("sessionUpdate")

        if session_update_kind in {"tool_call", "tool_call_update"}:
            tool_call_id = payload.get("tool_call_id") or payload.get("toolCallId")
            title = payload.get("title")
            kind = payload.get("kind")
            status = payload.get("status")
            raw_input = payload.get("raw_input") or payload.get("rawInput")
            raw_output = payload.get("raw_output") or payload.get("rawOutput")
            content = payload.get("content")
            locations = payload.get("locations")
            cached_record = None
            if tool_call_id:
                cached_record = (self.pending_tool_calls.get(session_id) or {}).get(str(tool_call_id))
            effective_title = title if title is not None else (cached_record or {}).get("title")
            effective_kind = kind if kind is not None else (cached_record or {}).get("kind")
            effective_raw_input = raw_input if raw_input is not None else (cached_record or {}).get("raw_input")
            meta = payload.get("_meta")
            is_cancelled = _is_cancelled_tool_call_update(payload)
            content_summary, content_excerpt = _summarize_tool_call_content(content)
            observed_name, observed_tool_id, observed_capability, observed_tool_label = _infer_observed_tool_identity(
                title=effective_title,
                kind=effective_kind,
                raw_input=effective_raw_input,
                content_summary=content_summary,
                content_excerpt=content_excerpt,
            )
            self._track_tool_call(
                session_id,
                tool_call_id,
                title,
                kind,
                status,
                raw_input=raw_input,
                locations=locations,
                observed_name=observed_name,
                observed_tool_id=observed_tool_id,
                observed_capability=observed_capability,
                observed_tool_label=observed_tool_label,
            )

            data = {
                "session_id": session_id,
                "tool_call_id": tool_call_id,
                "title": title,
                "kind": kind,
                "status": status,
                "status_display": "cancelled" if is_cancelled else status,
                "cancelled": is_cancelled,
                "locations": locations if isinstance(locations, list) else None,
            }
            if meta is not None:
                data["_meta"] = meta
            if raw_input is not None:
                data["raw_input_summary"] = dump_summary(raw_input, limit=2000)
            if raw_output is not None:
                data["raw_output_summary"] = dump_summary(raw_output, limit=2000)
            if content_summary:
                data["content_summary"] = content_summary
            if content_excerpt:
                data["content_excerpt"] = content_excerpt
            if observed_name:
                data["observed_name"] = observed_name
            if observed_tool_id:
                data["observed_tool_id"] = observed_tool_id
            if observed_capability:
                data["observed_capability"] = observed_capability
            if observed_tool_label:
                data["observed_tool_label"] = observed_tool_label

            append_event(
                "acp_tool_call" if session_update_kind == "tool_call" else "acp_tool_call_update",
                state=stage,
                data=data,
            )
        elif session_update_kind in {"agent_thought_chunk", "agent_message_chunk", "user_message_chunk"}:
            # Preserve and lightly summarize chunk updates for observability without
            # dumping full content into trace.
            content = payload.get("content")
            summary = _summarize_content_block(content) if isinstance(content, dict) else None
            append_event(
                "acp_content_chunk",
                state=stage,
                data={
                    "session_id": session_id,
                    "kind": session_update_kind,
                    "content_summary": summary,
                },
            )
        elif session_update_kind == "session_info_update":
            merged = self._apply_session_info_update(session_id, payload)
            data = {
                "session_id": session_id,
                "title": merged.get("title"),
                "updated_at": merged.get("updatedAt"),
            }
            if "_meta" in merged:
                data["_meta"] = merged.get("_meta")
            append_event("acp_session_info_update", state=stage, data=data)
        elif session_update_kind == "plan":
            raw_entries = payload.get("entries")
            entries = _coerce_plan_entries(raw_entries)
            bounded_entries, truncated, dropped_entries = _bound_plan_entries(entries)
            seq = int(self._plan_seq.get(session_id, 0)) + 1
            self._plan_seq[session_id] = seq
            fingerprint = _plan_fingerprint(bounded_entries)
            pending = sum(1 for e in bounded_entries if str(e.get("status") or "").lower() == "pending")
            in_progress = sum(1 for e in bounded_entries if str(e.get("status") or "").lower() == "in_progress")
            append_event(
                "acp_plan_update",
                state=stage,
                data={
                    "session_id": session_id,
                    "seq": seq,
                    "fingerprint": fingerprint,
                    "entries": bounded_entries,
                    "counts": {
                        "total": len(bounded_entries),
                        "pending": pending,
                        "in_progress": in_progress,
                    },
                    "truncated": truncated,
                    "dropped_entries": dropped_entries,
                },
            )
        else:
            # Best-effort capture for unknown session updates.
            #
            # This was added to debug "why no plan shows up". Keeping it always-on is too noisy,
            # so the default is OFF. For deep debugging, enable the env flag below to capture
            # all unknown session updates (may be very noisy).
            debug_all = str(os.environ.get("HARNESS_TRACE_RAW_SESSION_UPDATES") or "").strip().lower() in {
                "1",
                "true",
                "yes",
                "on",
            }
            if debug_all:
                try:
                    raw_full = json.dumps(payload, ensure_ascii=False)
                    raw_len = len(raw_full)
                    raw_truncated = raw_len > _RAW_SESSION_UPDATE_MAX_CHARS
                    raw_preview = raw_full[:_RAW_SESSION_UPDATE_MAX_CHARS] if raw_truncated else raw_full
                except Exception:
                    raw_preview = _truncate_text(str(payload), limit=_RAW_SESSION_UPDATE_MAX_CHARS)
                    raw_len = len(str(payload))
                    raw_truncated = raw_len > _RAW_SESSION_UPDATE_MAX_CHARS

                append_event(
                    "acp_session_update_raw",
                    state=stage,
                    data={
                        "session_id": session_id,
                        "session_update_kind": session_update_kind,
                        "payload_json": raw_preview,
                        "payload_len": raw_len,
                        "payload_truncated": raw_truncated,
                        "payload_keys": sorted(list(payload.keys())) if isinstance(payload, dict) else [],
                    },
                )

        try:
            self.updates.append(payload)
        except AttributeError:
            self.updates.append(payload)

    async def ext_method(self, method: str, params: dict) -> dict:
        raise RequestError(code=-32601, message="Method not found")

    async def ext_notification(self, method: str, params: dict) -> None:
        pass


class _AcpSessionManager:
    def __init__(
        self,
        *,
        agent: "AcpAgent",
        cwd: str,
        stage: str | None,
        updates_list: list,
    ):
        self.agent = agent
        self.cwd = os.path.realpath(cwd)
        self.stage = stage
        self.workspace_root = agent._resolve_workspace_root(self.cwd)
        self.updates_list = updates_list
        self.proc = None
        self.client_impl = None
        self.conn = None
        self.prompt_capabilities: dict[str, bool] | None = None
        self.agent_capabilities: dict[str, Any] | None = None
        self.agent_info: dict[str, Any] | None = None
        self.auth_methods: list[Any] | None = None
        self.supports_session_list = False
        self.supports_load_session = False
        self.skipped_mcp_servers: list[dict[str, Any]] = []
        self.last_session_id: str | None = None

    async def __aenter__(self):
        logger.info(f"Spawning ACP agent: {self.agent.command} {' '.join(self.agent.args)}")
        spawn_args = self.agent._spawn_args()
        stdio_limit = _acp_stdio_limit_bytes()
        logger.info(f"ACP spawn args: {' '.join(spawn_args)}")
        self.proc = await asyncio.create_subprocess_exec(
            self.agent.command,
            *spawn_args,
            cwd=self.workspace_root,
            stdin=aio_subprocess.PIPE,
            stdout=aio_subprocess.PIPE,
            limit=stdio_limit,
        )
        if self.proc.stdin is None or self.proc.stdout is None:
            raise RuntimeError("Agent process does not expose stdio pipes")
        self.client_impl = HarnessClientImpl(self.updates_list, workspace_root=self.workspace_root, repo_root=self.cwd)
        self._connection_ctx = connect_to_agent(self.client_impl, self.proc.stdin, self.proc.stdout)
        self.conn = await self._connection_ctx.__aenter__()
        capabilities = _build_client_capabilities()
        init_response = await self.conn.initialize(
            protocol_version=PROTOCOL_VERSION,
            client_capabilities=capabilities,
            client_info=Implementation(name="harness-acp-client", title="Harness Client", version="0.1.0"),
        )
        init_dump = _validate_initialize_response(init_response)
        self.agent_capabilities = init_dump.get("agent_capabilities", {})
        self.agent_info = init_dump.get("agent_info") or init_dump.get("agentInfo") or {}
        self.auth_methods = init_dump.get("auth_methods") or init_dump.get("authMethods") or []
        self.supports_session_list, self.supports_load_session = _extract_session_support(self.agent_capabilities)
        self.prompt_capabilities = _extract_prompt_capabilities(self.agent_capabilities)
        stage_config = load_stage_tool_config(self.cwd)
        enabled_tool_ids = enabled_tool_ids_for_stage(stage_config, self.stage)
        raw_mcp_servers = load_effective_mcp_servers(stage=self.stage, workspace_folder=self.cwd) or []
        stage_filtered_mcp_servers, skipped_stage_mcp_servers = filter_session_mcp_servers_by_enabled_tool_ids(
            raw_mcp_servers,
            enabled_tool_ids,
        )
        capability_filtered_mcp_servers, skipped_capability_mcp_servers = filter_session_mcp_servers_by_capability(
            stage_filtered_mcp_servers,
            self.agent_capabilities,
        )
        self.mcp_servers_for_session = capability_filtered_mcp_servers or []
        self.skipped_mcp_servers = skipped_stage_mcp_servers + skipped_capability_mcp_servers
        if self.skipped_mcp_servers:
            append_event(
                "mcp_config_session_filter",
                state=self.stage,
                data={
                    "enabled_tool_ids_present": enabled_tool_ids is not None,
                    "enabled_tool_ids": sorted(list(enabled_tool_ids)) if enabled_tool_ids is not None else None,
                    "skipped": self.skipped_mcp_servers,
                },
            )
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self.client_impl is not None:
            await self.client_impl.shutdown_terminals()
        if hasattr(self, "_connection_ctx"):
            await self._connection_ctx.__aexit__(exc_type, exc, tb)
        await _shutdown_subprocess(self.proc)
        return False

    async def prompt_once(self, *, prompt_text: str | None = None, prompt_blocks: list[dict[str, Any]] | None = None) -> Dict[str, Any]:
        if self.conn is None or self.client_impl is None or self.prompt_capabilities is None:
            raise RuntimeError("ACP session manager is not initialized")
        normalized_prompt = _normalize_prompt_blocks(prompt_text, prompt_blocks)
        _validate_prompt_blocks(normalized_prompt, self.prompt_capabilities)
        session = await self.conn.new_session(mcp_servers=self.mcp_servers_for_session, cwd=self.workspace_root)
        session_id = session.session_id
        self.last_session_id = session_id
        self.client_impl.seed_session_info(session_id, self.workspace_root)
        prompt_response = await self.conn.prompt(session_id=session_id, prompt=normalized_prompt)
        return {
            "updates": self.updates_list,
            "final_response": _normalize_prompt_response(prompt_response),
            "error": None,
            "protocolVersion": PROTOCOL_VERSION,
            "agentCapabilities": self.agent_capabilities or {},
            "agentInfo": self.agent_info or {},
            "authMethods": list(self.auth_methods or []),
            "supportsSessionList": self.supports_session_list,
            "supportsLoadSession": self.supports_load_session,
            "promptCapabilities": self.prompt_capabilities,
            "sessionId": session_id,
            "sessionInfo": self.client_impl.get_session_info(session_id),
            "mcpServersSkipped": self.skipped_mcp_servers,
        }

    async def run_sequence(self, steps: list[dict[str, Any]]) -> list[Dict[str, Any]]:
        results: list[Dict[str, Any]] = []
        for step in steps:
            result = await self.prompt_once(
                prompt_text=step.get("prompt_text"),
                prompt_blocks=step.get("prompt_blocks"),
            )
            results.append(result)
        return results

    def cancel_last_session(self) -> list[dict[str, Any]]:
        if self.client_impl is None or not self.last_session_id:
            return []
        return self.client_impl.cancel_pending_tool_calls(self.last_session_id)

    def session_info(self, session_id: str | None = None) -> dict[str, Any] | None:
        if self.client_impl is None:
            return None
        target_session_id = str(session_id or self.last_session_id or "").strip()
        if not target_session_id:
            return None
        return self.client_impl.get_session_info(target_session_id)


class AcpAgent:
    """
    A synchronous wrapper around the asynchronous ACP Client.
    Designed to be used within the Harness Orchestrator's synchronous state machine.
    """
    def __init__(self, command: str = "coco", args: list[str] | None = None):
        self.command = command
        self.args = args if args is not None else ["acp", "serve"]

    @staticmethod
    def _coco_global_args_from_env() -> list[str]:
        """Build Coco CLI global args from Harness env configuration.

        Keep this minimal: only model selection is controlled by Harness.
        """
        model_name = str(os.environ.get("HARNESS_COCO_MODEL_NAME") or "").strip()

        extra: list[str] = []
        if model_name:
            extra += ["-c", f"model.name={model_name}"]
        return extra

    def _spawn_args(self) -> list[str]:
        # For coco, global flags should come before subcommands (e.g., `coco --json -c ... acp serve`).
        if os.path.basename(str(self.command)) == "coco":
            return [*self._coco_global_args_from_env(), *self.args]
        return list(self.args)

    @staticmethod
    def _resolve_workspace_root(cwd: str) -> str:
        return os.path.realpath(cwd)

    def run_task(
        self,
        prompt_text: str,
        cwd: str,
        stage: str | None = None,
        prompt_blocks: list[dict[str, Any]] | None = None,
    ) -> Dict[str, Any]:
        """
        Synchronously runs an ACP session, sends the prompt, and waits for completion.
        """
        prev_stage = os.environ.get("HARNESS_STAGE")
        if stage:
            os.environ["HARNESS_STAGE"] = stage
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            result = asyncio.run(self._run_task_async(prompt_text, cwd, prompt_blocks=prompt_blocks))
            if stage:
                if prev_stage is None:
                    os.environ.pop("HARNESS_STAGE", None)
                else:
                    os.environ["HARNESS_STAGE"] = prev_stage
            return result

        q: queue.Queue = queue.Queue(maxsize=1)

        def runner():
            loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(loop)
                q.put(loop.run_until_complete(self._run_task_async(prompt_text, cwd, prompt_blocks=prompt_blocks)))
            except Exception as e:
                q.put(e)
            finally:
                try:
                    loop.run_until_complete(loop.shutdown_asyncgens())
                except Exception:
                    pass
                loop.close()

        t = threading.Thread(target=runner, daemon=True)
        t.start()
        res = q.get()
        if isinstance(res, Exception):
            raise res
        if stage:
            if prev_stage is None:
                os.environ.pop("HARNESS_STAGE", None)
            else:
                os.environ["HARNESS_STAGE"] = prev_stage
        return res

    async def _run_task_async(
        self,
        prompt_text: str,
        cwd: str,
        prompt_blocks: list[dict[str, Any]] | None = None,
    ) -> Dict[str, Any]:
        results = {
            "updates": [],
            "final_response": None,
            "error": None,
        }
        session_root = os.path.realpath(cwd)
        stage = os.environ.get("HARNESS_STAGE")
        last_result: Dict[str, Any] | None = None
        manager: _AcpSessionManager | None = None
        try:
            async with _AcpSessionManager(agent=self, cwd=session_root, stage=stage, updates_list=results["updates"]) as manager:
                logger.info("Sending prompt to agent...")
                last_result = await manager.prompt_once(prompt_text=prompt_text, prompt_blocks=prompt_blocks)
                results.update(last_result)
                return results
        except Exception as e:
            if _is_cancelled_error(e):
                logger.info("ACP prompt turn cancelled: %s", e)
                if manager is not None:
                    manager.cancel_last_session()
                    if manager.last_session_id:
                        results["sessionId"] = manager.last_session_id
                        results["sessionInfo"] = manager.session_info(manager.last_session_id)
                    results["protocolVersion"] = PROTOCOL_VERSION
                    results["agentCapabilities"] = manager.agent_capabilities or {}
                    results["agentInfo"] = manager.agent_info or {}
                    results["authMethods"] = list(manager.auth_methods or [])
                    results["supportsSessionList"] = manager.supports_session_list
                    results["supportsLoadSession"] = manager.supports_load_session
                    results["promptCapabilities"] = manager.prompt_capabilities or {
                        "text": True,
                        "resource_link": True,
                        "image": False,
                        "audio": False,
                        "embedded_context": False,
                    }
                    results["mcpServersSkipped"] = list(manager.skipped_mcp_servers or [])
                elif last_result and last_result.get("sessionId"):
                    results["sessionId"] = last_result.get("sessionId")
                    results["sessionInfo"] = last_result.get("sessionInfo")
                results["final_response"] = {"stop_reason": "cancelled"}
                results["error"] = None
                return results
            logger.error(f"Failed to run ACP process: {e}")
            results["error"] = str(e)
            return results
