from __future__ import annotations

import json
import os
import random
import string
from dataclasses import dataclass
from datetime import datetime, timezone


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def generate_run_id() -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    suffix = "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(6))
    return f"{ts}-{suffix}"


@dataclass(frozen=True)
class TraceContext:
    run_id: str
    run_dir: str
    trace_path: str


_TRACE_CONTEXT: TraceContext | None = None


def init_trace(run_id: str, run_dir: str) -> TraceContext:
    abs_run_dir = os.path.abspath(run_dir)
    os.makedirs(abs_run_dir, exist_ok=True)
    trace_path = os.path.join(abs_run_dir, "trace.ndjson")
    ctx = TraceContext(run_id=run_id, run_dir=abs_run_dir, trace_path=trace_path)
    global _TRACE_CONTEXT
    _TRACE_CONTEXT = ctx
    return ctx


def get_trace() -> TraceContext | None:
    return _TRACE_CONTEXT


def clear_trace() -> None:
    global _TRACE_CONTEXT
    _TRACE_CONTEXT = None


def append_event(event_type: str, state: str | None = None, data: dict | None = None) -> None:
    ctx = _TRACE_CONTEXT
    if not ctx:
        return
    payload = {
        "ts": _utc_now_iso(),
        "run_id": ctx.run_id,
        "type": event_type,
        "data": data or {},
    }
    if state is not None:
        payload["state"] = state
    with open(ctx.trace_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=False) + "\n")
