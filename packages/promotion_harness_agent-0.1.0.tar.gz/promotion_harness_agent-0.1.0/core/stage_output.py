from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from core.stage_validation import dir_has_any_file


def stage_output_relative_path(run_dir_relative: str, stage: str) -> str:
    run_dir = str(run_dir_relative or "").strip().strip("/")
    normalized_stage = str(stage or "").strip()
    if not run_dir:
        raise StageOutputValidationError("stage_output_run_dir_required")
    if not normalized_stage:
        raise StageOutputValidationError("stage_output_stage_required")
    return os.path.join(run_dir, "stage_outputs", f"{normalized_stage}.json")


def stage_output_absolute_path(run_dir: str, stage: str) -> str:
    normalized_run_dir = str(run_dir or "").strip()
    normalized_stage = str(stage or "").strip()
    if not normalized_run_dir:
        raise StageOutputValidationError("stage_output_run_dir_required")
    if not normalized_stage:
        raise StageOutputValidationError("stage_output_stage_required")
    return os.path.join(os.path.abspath(normalized_run_dir), "stage_outputs", f"{normalized_stage}.json")


SCHEMA_VERSION = 1
_SUPPORTED_STAGE_PRIMARY_ARTIFACT = {
    "PRD_DRAFTING": "prd",
    "TECH_SPEC_DRAFTING": "tech_spec",
    "CODING": "code_root",
    "QUALITY_LOOP": "quality_report",
    "DEPLOYING": "deploy_report",
    "REGRESSION_TESTING": "regression_report",
}


class StageOutputValidationError(ValueError):
    pass


@dataclass(frozen=True)
class StageOutputArtifact:
    artifact_type: str
    path: str
    absolute_path: str
    exists: bool
    is_dir: bool
    size_bytes: int
    summary: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "artifact_type": self.artifact_type,
            "path": self.path,
            "absolute_path": self.absolute_path,
            "exists": self.exists,
            "is_dir": self.is_dir,
            "size_bytes": self.size_bytes,
            "summary": self.summary,
        }


@dataclass(frozen=True)
class StageOutput:
    schema_version: int
    stage: str
    status: str
    summary: str
    artifacts: list[StageOutputArtifact]
    key_points: list[str]
    evidence: list[str]
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "stage": self.stage,
            "status": self.status,
            "summary": self.summary,
            "artifacts": [artifact.to_dict() for artifact in self.artifacts],
            "key_points": list(self.key_points),
            "evidence": list(self.evidence),
            "metadata": dict(self.metadata),
        }


def primary_artifact_type_for_stage(stage: str) -> str | None:
    return _SUPPORTED_STAGE_PRIMARY_ARTIFACT.get(str(stage or "").strip())


def build_stage_output_artifact(*, artifact_type: str, path: str, absolute_path: str, summary: str) -> StageOutputArtifact:
    abs_path = os.path.abspath(absolute_path or path)
    exists = os.path.exists(abs_path)
    is_dir = os.path.isdir(abs_path)
    size_bytes = 0
    if exists and not is_dir:
        try:
            size_bytes = int(os.path.getsize(abs_path) or 0)
        except OSError:
            size_bytes = 0
    return StageOutputArtifact(
        artifact_type=str(artifact_type or "").strip(),
        path=str(path or "").strip(),
        absolute_path=abs_path,
        exists=exists,
        is_dir=is_dir,
        size_bytes=size_bytes,
        summary=str(summary or "").strip(),
    )


def build_stage_output(
    *,
    stage: str,
    summary: str,
    artifacts: list[StageOutputArtifact],
    status: str = "completed",
    key_points: list[str] | None = None,
    evidence: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> StageOutput:
    return StageOutput(
        schema_version=SCHEMA_VERSION,
        stage=str(stage or "").strip(),
        status=str(status or "completed").strip() or "completed",
        summary=str(summary or "").strip(),
        artifacts=list(artifacts or []),
        key_points=[str(item).strip() for item in (key_points or []) if str(item).strip()],
        evidence=[str(item).strip() for item in (evidence or []) if str(item).strip()],
        metadata=dict(metadata or {}),
    )


def normalize_stage_output_payload(
    payload: dict[str, Any],
    *,
    fallback_artifacts: list[StageOutputArtifact] | None = None,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise StageOutputValidationError("stage_output_must_be_object")

    def _stringify_item(value: Any) -> str:
        if isinstance(value, str):
            return value.strip()
        if value is None:
            return ""
        return str(value).strip()

    def _stringify_items(values: Any) -> list[str]:
        if isinstance(values, list):
            out: list[str] = []
            for item in values:
                text = _stringify_item(item)
                if text:
                    out.append(text)
            return out
        if values is None:
            return []
        text = _stringify_item(values)
        return [text] if text else []

    normalized = dict(payload)
    schema_version = normalized.get("schema_version")
    if isinstance(schema_version, str):
        stripped = schema_version.strip()
        if stripped:
            try:
                numeric = float(stripped)
            except ValueError:
                pass
            else:
                if numeric.is_integer():
                    normalized["schema_version"] = int(numeric)
    elif isinstance(schema_version, float) and schema_version.is_integer():
        normalized["schema_version"] = int(schema_version)

    fallback_by_type = {
        artifact.artifact_type: artifact.to_dict()
        for artifact in (fallback_artifacts or [])
        if artifact.artifact_type
    }
    artifacts_raw = normalized.get("artifacts")
    if isinstance(artifacts_raw, dict):
        if "artifact_type" in artifacts_raw or "path" in artifacts_raw or "absolute_path" in artifacts_raw:
            normalized["artifacts"] = [artifacts_raw]
        else:
            normalized_artifacts: list[dict[str, Any]] = []
            for artifact_type, raw_value in artifacts_raw.items():
                template = dict(fallback_by_type.get(str(artifact_type).strip(), {}))
                template["artifact_type"] = str(artifact_type or "").strip()
                if isinstance(raw_value, str):
                    value = raw_value.strip()
                    if value:
                        template.setdefault("path", value)
                        template.setdefault("absolute_path", os.path.abspath(value))
                elif isinstance(raw_value, dict):
                    if raw_value.get("path"):
                        template["path"] = str(raw_value.get("path") or "").strip()
                    if raw_value.get("absolute_path"):
                        template["absolute_path"] = str(raw_value.get("absolute_path") or "").strip()
                    template["exists"] = bool(raw_value.get("exists", template.get("exists", False)))
                    template["is_dir"] = bool(raw_value.get("is_dir", template.get("is_dir", False)))
                    try:
                        template["size_bytes"] = int(raw_value.get("size_bytes", template.get("size_bytes", 0)) or 0)
                    except (TypeError, ValueError):
                        template["size_bytes"] = int(template.get("size_bytes", 0) or 0)
                    summary = raw_value.get("summary") or raw_value.get("description") or template.get("summary")
                    if summary:
                        template["summary"] = str(summary).strip()
                normalized_artifacts.append(template)
            normalized["artifacts"] = normalized_artifacts
    elif (artifacts_raw is None or artifacts_raw == []) and fallback_artifacts:
        normalized["artifacts"] = [artifact.to_dict() for artifact in fallback_artifacts]

    normalized["key_points"] = _stringify_items(normalized.get("key_points"))
    normalized["evidence"] = _stringify_items(normalized.get("evidence"))
    if not isinstance(normalized.get("metadata"), dict):
        normalized["metadata"] = {}
    return normalized


def validate_stage_output(payload: dict[str, Any] | StageOutput, *, expected_stage: str | None = None) -> StageOutput:
    if isinstance(payload, StageOutput):
        result = payload
    else:
        if not isinstance(payload, dict):
            raise StageOutputValidationError("stage_output_must_be_object")
        schema_version = payload.get("schema_version")
        if isinstance(schema_version, str):
            stripped = schema_version.strip()
            if stripped:
                try:
                    numeric = float(stripped)
                except ValueError:
                    pass
                else:
                    if numeric.is_integer():
                        schema_version = int(numeric)
        if isinstance(schema_version, float) and schema_version.is_integer():
            schema_version = int(schema_version)
        stage = str(payload.get("stage") or "").strip()
        status = str(payload.get("status") or "").strip()
        summary = str(payload.get("summary") or "").strip()
        artifacts_raw = payload.get("artifacts")
        key_points = payload.get("key_points")
        evidence = payload.get("evidence")
        metadata = payload.get("metadata")

        if schema_version != SCHEMA_VERSION:
            raise StageOutputValidationError(f"invalid_stage_output_schema_version: {schema_version}")
        if not stage:
            raise StageOutputValidationError("stage_output_stage_required")
        if expected_stage and stage != str(expected_stage).strip():
            raise StageOutputValidationError(
                f"stage_output_stage_mismatch: expected {expected_stage}, got {stage}"
            )
        if not status:
            raise StageOutputValidationError("stage_output_status_required")
        if not summary:
            raise StageOutputValidationError("stage_output_summary_required")
        if not isinstance(artifacts_raw, list) or not artifacts_raw:
            raise StageOutputValidationError("stage_output_artifacts_required")
        if not isinstance(key_points, list) or not all(isinstance(item, str) for item in key_points):
            raise StageOutputValidationError("stage_output_key_points_must_be_string_list")
        if not isinstance(evidence, list) or not all(isinstance(item, str) for item in evidence):
            raise StageOutputValidationError("stage_output_evidence_must_be_string_list")
        if not isinstance(metadata, dict):
            raise StageOutputValidationError("stage_output_metadata_must_be_object")

        artifacts: list[StageOutputArtifact] = []
        for item in artifacts_raw:
            if not isinstance(item, dict):
                raise StageOutputValidationError("stage_output_artifact_must_be_object")
            artifact_type = str(item.get("artifact_type") or "").strip()
            path = str(item.get("path") or "").strip()
            absolute_path = str(item.get("absolute_path") or "").strip()
            summary_value = str(item.get("summary") or "").strip()
            exists = bool(item.get("exists"))
            is_dir = bool(item.get("is_dir"))
            try:
                size_bytes = int(item.get("size_bytes") or 0)
            except (TypeError, ValueError) as exc:
                raise StageOutputValidationError("stage_output_artifact_size_bytes_invalid") from exc
            if not artifact_type:
                raise StageOutputValidationError("stage_output_artifact_type_required")
            if not path:
                raise StageOutputValidationError("stage_output_artifact_path_required")
            if not absolute_path:
                raise StageOutputValidationError("stage_output_artifact_absolute_path_required")
            if not summary_value:
                raise StageOutputValidationError("stage_output_artifact_summary_required")
            artifacts.append(
                StageOutputArtifact(
                    artifact_type=artifact_type,
                    path=path,
                    absolute_path=absolute_path,
                    exists=exists,
                    is_dir=is_dir,
                    size_bytes=size_bytes,
                    summary=summary_value,
                )
            )

        result = StageOutput(
            schema_version=SCHEMA_VERSION,
            stage=stage,
            status=status,
            summary=summary,
            artifacts=artifacts,
            key_points=[str(item).strip() for item in key_points],
            evidence=[str(item).strip() for item in evidence],
            metadata=dict(metadata),
        )

    for artifact in result.artifacts:
        if not artifact.exists:
            raise StageOutputValidationError(f"stage_output_artifact_missing: {artifact.artifact_type}")
        if artifact.is_dir:
            if not dir_has_any_file(artifact.absolute_path):
                raise StageOutputValidationError(f"stage_output_artifact_empty_dir: {artifact.artifact_type}")
            continue
        if artifact.size_bytes <= 0:
            raise StageOutputValidationError(f"stage_output_artifact_empty: {artifact.artifact_type}")
    return result
