import json
import os
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from json import JSONDecodeError
from typing import Dict, Any, Callable
from core.context_layer import build_full_context, build_stage_context, render_stage_prompt
from core.runtime_paths import resolve_repo_root
from core.run_trace import append_event
from core.stage_output import stage_output_absolute_path, stage_output_relative_path


_QUALITY_LOOP_HISTORY_LIMIT = 20


DEFAULT_MAX_STAGE_RETRIES = 3
_MAX_NONCOMPLIANCE_HISTORY = 20


def _coerce_non_negative_int(value: Any, default: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return int(default)
    return max(0, parsed)


def normalize_stage_max_retries_map(raw: Any) -> dict[str, int]:
    if not isinstance(raw, dict):
        return {}
    out: dict[str, int] = {}
    for key, value in raw.items():
        stage = str(key or "").strip()
        if not stage:
            continue
        out[stage] = _coerce_non_negative_int(value, DEFAULT_MAX_STAGE_RETRIES)
    return out


def resolve_stage_max_retries(metadata: dict[str, Any] | None, stage: str | None) -> int:
    meta = metadata if isinstance(metadata, dict) else {}
    normalized_stage = str(stage or "").strip()
    if normalized_stage:
        overrides = normalize_stage_max_retries_map(meta.get("stage_max_retries"))
        if normalized_stage in overrides:
            return overrides[normalized_stage]
    return _coerce_non_negative_int(meta.get("max_stage_retries", DEFAULT_MAX_STAGE_RETRIES), DEFAULT_MAX_STAGE_RETRIES)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def read_json_file_safe(path: str, retries: int = 3, sleep_sec: float = 0.05) -> dict | None:
    """Best-effort JSON reader.

    UI may read `progress.json` while another thread/process updates it.
    This helper tolerates transient empty/partial content by retrying briefly.
    """
    if not path:
        return None
    for _ in range(max(1, int(retries))):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                raw = f.read()
            if not raw.strip():
                raise JSONDecodeError("empty file", raw, 0)
            data = json.loads(raw)
            return data if isinstance(data, dict) else None
        except FileNotFoundError:
            return None
        except (JSONDecodeError, OSError):
            time.sleep(max(0.0, float(sleep_sec)))
            continue
    return None


def update_progress_json_atomic(progress_file: str, updater: Callable[[dict[str, Any]], dict[str, Any] | None]) -> dict[str, Any] | None:
    """Atomically update a progress.json file in-place.

    This is used by components that do not have a `ContextManager` instance (e.g., ACP tool boundary)
    but must still persist structured evidence for prompt injection / UI.
    """
    if not progress_file:
        return None
    target = os.path.abspath(progress_file)
    os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
    current = read_json_file_safe(target, retries=3, sleep_sec=0.02) or {}
    if not isinstance(current, dict):
        current = {}
    current.setdefault("metadata", {})
    current.setdefault("artifacts", {})
    updated = updater(current)
    if updated is None:
        return current
    fd, tmp_path = tempfile.mkstemp(prefix=".progress.", suffix=".tmp", dir=os.path.dirname(target) or ".")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(updated, f, indent=2, ensure_ascii=False)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_path, target)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass
    return updated


@dataclass(frozen=True)
class NonComplianceRecord:
    ts: str
    stage: str
    kind: str
    reason: str
    details: dict[str, Any]
    suggestion: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "ts": self.ts,
            "stage": self.stage,
            "kind": self.kind,
            "reason": self.reason,
            "details": self.details,
            "suggestion": self.suggestion,
        }


class ContextManager:
    def __init__(self, progress_file: str, *, repo_root: str | None = None):
        self.progress_file = progress_file
        self._explicit_repo_root = resolve_repo_root(repo_root) if repo_root else None
        self.context: Dict[str, Any] = self._load_or_init()
        self._prepared_full_context: Dict[str, Any] | None = None
        self._prepared_stage_contexts: Dict[str, Dict[str, Any]] = {}

    def _load_or_init(self) -> Dict[str, Any]:
        if os.path.exists(self.progress_file):
            loaded = read_json_file_safe(self.progress_file, retries=3, sleep_sec=0.02)
            if isinstance(loaded, dict) and loaded:
                loaded.setdefault("metadata", {})
                loaded.setdefault("artifacts", {})
                return loaded
        return self._default_context()

    def _default_context(self) -> Dict[str, Any]:
        return {
            "state": "INIT",
            "metadata": {},
            "artifacts": {}
        }

    def _repo_root(self, repo_root: str | None = None) -> str:
        if repo_root:
            return os.path.abspath(repo_root)
        if self._explicit_repo_root:
            return self._explicit_repo_root
        return os.path.abspath(os.path.dirname(self.progress_file) or ".")

    def _atomic_write_text(self, path: str, content: str) -> None:
        target = os.path.abspath(path)
        os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
        dir_name = os.path.dirname(target) or "."
        fd, tmp_path = tempfile.mkstemp(prefix=".ctx.", suffix=".tmp", dir=dir_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(content)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
            os.replace(tmp_path, target)
        finally:
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except OSError:
                pass

    def _atomic_write_json(self, path: str, payload: Dict[str, Any]) -> None:
        self._atomic_write_text(path, json.dumps(payload, indent=2, ensure_ascii=False))

    def _context_snapshot_refs(self) -> Dict[str, Any]:
        metadata = self.context.setdefault("metadata", {})
        refs = metadata.get("context_snapshots")
        if not isinstance(refs, dict):
            refs = {}
            metadata["context_snapshots"] = refs
        return refs

    def _prompt_snapshot_refs(self) -> Dict[str, Any]:
        metadata = self.context.setdefault("metadata", {})
        refs = metadata.get("prompt_snapshots")
        if not isinstance(refs, dict):
            refs = {}
            metadata["prompt_snapshots"] = refs
        return refs

    def stage_output_path(self, stage: str, repo_root: str | None = None) -> str | None:
        metadata = self.context.get("metadata", {}) if isinstance(self.context.get("metadata"), dict) else {}
        run_dir_rel = metadata.get("run_dir")
        if not isinstance(run_dir_rel, str) or not run_dir_rel.strip():
            return None
        return stage_output_relative_path(run_dir_rel, stage)

    def stage_output_abs_path(self, stage: str, repo_root: str | None = None) -> str | None:
        metadata = self.context.get("metadata", {}) if isinstance(self.context.get("metadata"), dict) else {}
        run_dir_rel = metadata.get("run_dir")
        if not isinstance(run_dir_rel, str) or not run_dir_rel.strip():
            return None
        repo_root_value = self._repo_root(repo_root)
        run_dir_abs = os.path.abspath(os.path.join(repo_root_value, run_dir_rel))
        return stage_output_absolute_path(run_dir_abs, stage)

    def save(self):
        # Atomic write to avoid readers observing truncated/partial JSON.
        target = os.path.abspath(self.progress_file)
        os.makedirs(os.path.dirname(target) or ".", exist_ok=True)
        dir_name = os.path.dirname(target) or "."
        fd, tmp_path = tempfile.mkstemp(prefix=".progress.", suffix=".tmp", dir=dir_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self.context, f, indent=2, ensure_ascii=False)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
            os.replace(tmp_path, target)
        finally:
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except OSError:
                pass

    def set_state(self, new_state: str):
        self.context["state"] = new_state
        self.save()

    def reload(self) -> None:
        """Reload progress.json from disk (best-effort).

        Used to observe metadata/evidence written by other components (e.g., ACP tool boundary)
        during a stage execution.
        """
        loaded = read_json_file_safe(self.progress_file, retries=3, sleep_sec=0.02)
        if isinstance(loaded, dict) and loaded:
            loaded.setdefault("metadata", {})
            loaded.setdefault("artifacts", {})
            self.context = loaded
            self._prepared_full_context = None
            self._prepared_stage_contexts = {}

    def get_state(self) -> str:
        return self.context.get("state", "UNKNOWN")

    def update_metadata(self, key: str, value: Any):
        self.context["metadata"][key] = value
        self.save()

    def get_max_stage_retries(self, stage: str | None = None) -> int:
        meta = self.context.get("metadata", {}) if isinstance(self.context.get("metadata"), dict) else {}
        return resolve_stage_max_retries(meta, stage)

    def _stage_retry_count_map(self) -> dict[str, int]:
        meta = self.context.setdefault("metadata", {})
        mapping = meta.get("stage_retry_count")
        if not isinstance(mapping, dict):
            mapping = {}
            meta["stage_retry_count"] = mapping
        # Normalize values to int where possible.
        out: dict[str, int] = {}
        for k, v in mapping.items():
            try:
                out[str(k)] = int(v)
            except (TypeError, ValueError):
                out[str(k)] = 0
        meta["stage_retry_count"] = out
        return out

    def _stage_history_map(self) -> dict[str, list[dict[str, Any]]]:
        meta = self.context.setdefault("metadata", {})
        mapping = meta.get("stage_noncompliance_history")
        if not isinstance(mapping, dict):
            mapping = {}
            meta["stage_noncompliance_history"] = mapping
        # Ensure each stage value is a list.
        for k, v in list(mapping.items()):
            if not isinstance(v, list):
                mapping[str(k)] = []
            else:
                mapping[str(k)] = [item for item in v if isinstance(item, dict)]
        return mapping

    def get_last_noncompliance(self, stage: str) -> dict[str, Any] | None:
        meta = self.context.get("metadata", {}) if isinstance(self.context.get("metadata"), dict) else {}
        last = meta.get("last_noncompliance")
        if not isinstance(last, dict):
            return None
        if str(last.get("stage") or "") != str(stage):
            return None
        return dict(last)

    def record_noncompliance(
        self,
        *,
        stage: str,
        kind: str,
        reason: str,
        details: dict[str, Any] | None = None,
        suggestion: str = "",
    ) -> tuple[bool, int, int]:
        """Record a stage-level non-compliance.

        Returns (should_retry, retry_count, max_stage_retries).
        """
        stage = str(stage or "").strip() or "UNKNOWN"
        kind = str(kind or "").strip() or "unknown"
        reason = str(reason or "").strip() or "unclassified"
        record = NonComplianceRecord(
            ts=_utc_now_iso(),
            stage=stage,
            kind=kind,
            reason=reason,
            details=dict(details or {}),
            suggestion=str(suggestion or ""),
        ).to_dict()

        meta = self.context.setdefault("metadata", {})
        retry_counts = self._stage_retry_count_map()
        retry_count = int(retry_counts.get(stage, 0)) + 1
        retry_counts[stage] = retry_count
        meta["last_noncompliance"] = record

        history_map = self._stage_history_map()
        history = history_map.get(stage)
        if not isinstance(history, list):
            history = []
        history.append(record)
        history_map[stage] = history[-_MAX_NONCOMPLIANCE_HISTORY:]

        max_retries = self.get_max_stage_retries(stage)
        should_retry = retry_count <= max_retries
        loop_guard = ""
        if not should_retry:
            loop_guard = f"\\n\\n[loop_guard] max_stage_retries exceeded: {retry_count} > {max_retries}"
        # Keep last_error_log aligned with the last non-compliance for downstream (UI/FIXING).
        self.context.setdefault("metadata", {})["last_error_log"] = (
            f"NON_COMPLIANT({stage}): {reason}\\n{json.dumps(record.get('details', {}), ensure_ascii=False)}"
            + (f"\nSuggestion: {record.get('suggestion')}" if record.get("suggestion") else "")
            + loop_guard
        )
        self.save()
        append_event("stage_noncompliance", state=stage, data={
            "retry_count": retry_count,
            "max_stage_retries": max_retries,
            "record": record,
            "should_retry": should_retry,
        })
        return should_retry, retry_count, max_retries

    def record_acp_session(self, stage: str, result: Dict[str, Any] | None) -> None:
        if not isinstance(result, dict):
            return
        session_info = result.get("sessionInfo")
        if not isinstance(session_info, dict):
            session_id = result.get("sessionId")
            if not session_id:
                return
            session_info = {"sessionId": session_id}

        session_id = session_info.get("sessionId") or session_info.get("session_id")
        if not session_id:
            return

        metadata = self.context.setdefault("metadata", {})
        sessions = metadata.get("acp_sessions")
        if not isinstance(sessions, dict):
            sessions = {}
            metadata["acp_sessions"] = sessions

        existing = sessions.get(session_id)
        merged = dict(existing) if isinstance(existing, dict) else {}
        for key in ("sessionId", "cwd", "title", "updatedAt", "_meta"):
            if key in session_info:
                merged[key] = session_info.get(key)
        merged["lastStage"] = stage
        merged["supportsSessionList"] = bool(result.get("supportsSessionList"))
        merged["supportsLoadSession"] = bool(result.get("supportsLoadSession"))
        sessions[session_id] = merged
        metadata["last_acp_session_id"] = session_id
        self.save()
        append_event(
            "acp_session_recorded",
            state=stage,
            data={
                "session_id": session_id,
                "title": merged.get("title"),
                "updated_at": merged.get("updatedAt"),
                "supports_session_list": merged.get("supportsSessionList"),
                "supports_load_session": merged.get("supportsLoadSession"),
            },
        )
        
    def add_artifact(self, key: str, path: str):
        self.context["artifacts"][key] = path
        self.save()
        append_event("artifact_update", state=self.get_state(), data={"key": key, "path": path})

    def record_stage_result(self, stage: str, result: Dict[str, Any]) -> None:
        normalized_stage = str(stage or "").strip()
        payload = dict(result or {})
        abs_path = self.stage_output_abs_path(normalized_stage)
        rel_path = self.stage_output_path(normalized_stage)
        if abs_path and rel_path:
            self._atomic_write_json(abs_path, payload)
            metadata = self.context.setdefault("metadata", {})
            refs = metadata.get("stage_output_refs")
            if not isinstance(refs, dict):
                refs = {}
                metadata["stage_output_refs"] = refs
            refs[normalized_stage] = {"path": rel_path, "absolute_path": abs_path}
            metadata["last_stage_output_path"] = rel_path
        metadata = self.context.setdefault("metadata", {})
        stage_results = metadata.get("stage_results")
        if not isinstance(stage_results, dict):
            stage_results = {}
            metadata["stage_results"] = stage_results
        stage_results[normalized_stage] = payload
        metadata["last_stage_result"] = payload
        self.save()
        append_event("stage_result_recorded", state=normalized_stage, data={"stage_result": payload, "stage_output_path": rel_path})

    def update_quality_loop(self, **updates: Any) -> dict[str, Any]:
        metadata = self.context.setdefault("metadata", {})
        quality_loop = metadata.get("quality_loop")
        if not isinstance(quality_loop, dict):
            quality_loop = {}
        merged = dict(quality_loop)
        merged.update({key: value for key, value in updates.items() if value is not None})
        if "history" in merged and not isinstance(merged.get("history"), list):
            merged["history"] = []
        metadata["quality_loop"] = merged
        phase = str(merged.get("phase") or "").strip().lower()
        if phase:
            metadata["quality_loop_phase"] = phase
        self.save()
        return merged

    def append_quality_loop_history(self, entry: Dict[str, Any]) -> dict[str, Any]:
        metadata = self.context.setdefault("metadata", {})
        quality_loop = metadata.get("quality_loop")
        if not isinstance(quality_loop, dict):
            quality_loop = {}
        history = quality_loop.get("history")
        if not isinstance(history, list):
            history = []
        history.append(dict(entry or {}))
        quality_loop["history"] = history[-_QUALITY_LOOP_HISTORY_LIMIT:]
        metadata["quality_loop"] = quality_loop
        phase = str(quality_loop.get("phase") or "").strip().lower()
        if phase:
            metadata["quality_loop_phase"] = phase
        self.save()
        return quality_loop

    def get_stage_result(self, stage: str) -> Dict[str, Any] | None:
        normalized_stage = str(stage or "").strip()
        abs_path = self.stage_output_abs_path(normalized_stage)
        if isinstance(abs_path, str) and abs_path:
            loaded = read_json_file_safe(abs_path, retries=1, sleep_sec=0.0)
            if isinstance(loaded, dict):
                return dict(loaded)
        metadata = self.context.get("metadata", {}) if isinstance(self.context.get("metadata"), dict) else {}
        stage_results = metadata.get("stage_results")
        if not isinstance(stage_results, dict):
            return None
        result = stage_results.get(normalized_stage)
        return dict(result) if isinstance(result, dict) else None

    def build_full_context(self, repo_root: str | None = None) -> Dict[str, Any]:
        full_ctx = build_full_context(self.context, self.progress_file, self._repo_root(repo_root))
        self._prepared_full_context = full_ctx
        return full_ctx

    def build_stage_context(
        self,
        stage: str,
        repo_root: str | None = None,
        policy_rules_override: list[dict[str, str]] | None = None,
        output_requirements_override: str | None = None,
        tool_instructions_override: str | None = None,
        requirement_override: str | None = None,
    ) -> Dict[str, Any]:
        full_ctx = self.build_full_context(repo_root=repo_root)
        stage_ctx = build_stage_context(
            stage,
            full_ctx,
            policy_rules_override=policy_rules_override,
            output_requirements_override=output_requirements_override,
            tool_instructions_override=tool_instructions_override,
            requirement_override=requirement_override,
        )
        self._prepared_stage_contexts[stage] = stage_ctx
        return stage_ctx

    def get_stage_context(self, stage: str) -> Dict[str, Any] | None:
        cached = self._prepared_stage_contexts.get(stage)
        if isinstance(cached, dict):
            return cached
        refs = self._context_snapshot_refs().get(stage)
        if not isinstance(refs, dict):
            return None
        ctx_path = refs.get("ctx_path")
        loaded = read_json_file_safe(ctx_path, retries=1, sleep_sec=0.0) if isinstance(ctx_path, str) else None
        if isinstance(loaded, dict):
            self._prepared_stage_contexts[stage] = loaded
            return loaded
        return None

    def prepare_stage_context(
        self,
        stage: str,
        repo_root: str | None = None,
        policy_rules_override: list[dict[str, str]] | None = None,
        output_requirements_override: str | None = None,
        tool_instructions_override: str | None = None,
        requirement_override: str | None = None,
    ) -> Dict[str, Any]:
        full_ctx = self.build_full_context(repo_root=repo_root)
        stage_ctx = build_stage_context(
            stage,
            full_ctx,
            policy_rules_override=policy_rules_override,
            output_requirements_override=output_requirements_override,
            tool_instructions_override=tool_instructions_override,
            requirement_override=requirement_override,
        )
        context_dir = full_ctx["run"]["context_dir"]
        os.makedirs(context_dir, exist_ok=True)

        full_ctx_path = os.path.join(context_dir, "full_ctx.json")
        stage_ctx_path = os.path.join(context_dir, f"{stage}.ctx.json")
        self._atomic_write_json(full_ctx_path, full_ctx)
        self._atomic_write_json(stage_ctx_path, stage_ctx)

        refs = self._context_snapshot_refs()
        refs["full"] = {"ctx_path": full_ctx_path}
        refs[stage] = {"ctx_path": stage_ctx_path}
        self.context.setdefault("metadata", {})["last_stage_context"] = stage
        self.save()

        self._prepared_full_context = full_ctx
        self._prepared_stage_contexts[stage] = stage_ctx
        append_event("context_snapshot", state=stage, data={"ctx_path": stage_ctx_path, "full_ctx_path": full_ctx_path})
        return stage_ctx

    def render_and_persist_stage_prompt(
        self,
        stage: str,
        repo_root: str | None = None,
        policy_rules_override: list[dict[str, str]] | None = None,
        output_requirements_override: str | None = None,
        tool_instructions_override: str | None = None,
        requirement_override: str | None = None,
    ) -> str:
        # Expose progress location to tool-boundary components (ACP) for evidence recording.
        try:
            os.environ["HARNESS_PROGRESS_FILE"] = os.path.abspath(self.progress_file)
        except Exception:
            pass
        # Always prepare fresh context so that newly recorded non-compliance feedback is injected.
        stage_ctx = self.prepare_stage_context(
            stage,
            repo_root=repo_root,
            policy_rules_override=policy_rules_override,
            output_requirements_override=output_requirements_override,
            tool_instructions_override=tool_instructions_override,
            requirement_override=requirement_override,
        )
        prompt = render_stage_prompt(stage, stage_ctx)
        rendered_meta = stage_ctx.get("metadata") if isinstance(stage_ctx.get("metadata"), dict) else None
        if isinstance(rendered_meta, dict):
            self.context.setdefault("metadata", {}).update(rendered_meta)
        context_dir = stage_ctx["run"]["context_dir"]
        os.makedirs(context_dir, exist_ok=True)
        prompt_path = os.path.join(context_dir, f"{stage}.prompt.md")
        self._atomic_write_text(prompt_path, prompt)
        refs = self._prompt_snapshot_refs()
        refs[stage] = {"prompt_path": prompt_path}
        snapshot_refs = self._context_snapshot_refs()
        if isinstance(snapshot_refs.get(stage), dict):
            snapshot_refs[stage]["prompt_path"] = prompt_path
        self.save()
        append_event("context_prompt_rendered", state=stage, data={"prompt_path": prompt_path})
        return prompt
        
    def clear(self):
        self.context = self._default_context()
        self._prepared_full_context = None
        self._prepared_stage_contexts = {}
        self.save()
