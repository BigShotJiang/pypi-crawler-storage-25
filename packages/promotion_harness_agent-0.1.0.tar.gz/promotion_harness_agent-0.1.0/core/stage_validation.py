import json
import os
from typing import Any


def read_text_file(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def read_nonempty_text_file(path: str, *, empty_message: str | None = None) -> str:
    content = read_text_file(path).strip()
    if not content:
        raise ValueError(empty_message or f"Empty file: {path}")
    return content


def dir_has_any_file(dir_path: str) -> bool:
    for _, _, files in os.walk(dir_path):
        if files:
            return True
    return False


def path_exists_and_nonempty(path: str) -> bool:
    if not os.path.exists(path):
        return False
    if os.path.isdir(path):
        return dir_has_any_file(path)
    try:
        return os.path.getsize(path) > 0
    except OSError:
        return False


def read_nonempty_json_object(path: str, *, empty_message: str | None = None) -> dict[str, Any]:
    raw = read_nonempty_text_file(path, empty_message=empty_message)
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError(f"JSON object required: {path}")
    return data


def validate_deploy_report(path: str) -> dict[str, Any]:
    payload = read_nonempty_json_object(path, empty_message=f"Empty deploy report: {path}")
    missing = [
        field
        for field in ("env_name", "env_url", "branch_name", "psm", "status", "summary")
        if not str(payload.get(field) or "").strip()
    ]
    if missing:
        raise ValueError(f"Deploy report missing required fields: {', '.join(missing)}")
    return payload


def validate_regression_report(path: str) -> dict[str, Any]:
    payload = read_nonempty_json_object(path, empty_message=f"Empty regression report: {path}")
    missing = [
        field
        for field in ("env_name", "env_url", "final_verdict", "summary")
        if not str(payload.get(field) or "").strip()
    ]
    if missing:
        raise ValueError(f"Regression report missing required fields: {', '.join(missing)}")
    test_cases = payload.get("test_cases")
    if not isinstance(test_cases, list) or not any(str(item).strip() for item in test_cases):
        raise ValueError("Regression report requires non-empty test_cases")
    results = payload.get("results")
    endpoint_results = payload.get("endpoint_results")
    if not ((isinstance(results, list) and len(results) > 0) or isinstance(endpoint_results, dict) or (isinstance(endpoint_results, list) and len(endpoint_results) > 0)):
        raise ValueError("Regression report requires results or endpoint_results")
    return payload
