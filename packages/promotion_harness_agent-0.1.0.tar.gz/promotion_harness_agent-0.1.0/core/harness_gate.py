from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal

from core.run_trace import append_event
from core.capability_registry import ToolDescriptor, evaluate_policy

# Keep this module independent from ACP / Orchestrator internals.
# It defines a small "control plane" surface that both sides can call.


GateScope = Literal["pre", "post"]
GateOutcome = Literal["allow", "deny", "force", "abort"]


@dataclass(frozen=True)
class GateVerdict:
    scope: GateScope
    outcome: GateOutcome
    reason: str
    next_state: str | None = None
    evidence: dict[str, Any] = field(default_factory=dict)
    details: dict[str, Any] = field(default_factory=dict)


class HarnessGate:
    """Unified Harness gate interface.

    Contract: stage handlers may propose a next state, but only the gate's post-verdict
    is allowed to drive orchestrator transitions ("handler proposes, gate decides").
    """

    def pre_gate(
        self,
        *,
        stage: str | None,
        normalized_kind: str | None,
        resolved_capability: str | None,
        decision: str,
        reason: str,
        policy_context: dict[str, Any] | None = None,
        paths: list[str] | None = None,
    ) -> GateVerdict:
        raise NotImplementedError

    def post_gate(
        self,
        *,
        stage: str,
        suggested_next_state: str | None,
        metadata: dict[str, Any] | None,
    ) -> GateVerdict:
        raise NotImplementedError


_ACCEPTANCE_RUNNER: Callable[..., dict[str, Any]] | None = None


def set_acceptance_runner(runner: Callable[..., dict[str, Any]] | None) -> None:
    global _ACCEPTANCE_RUNNER
    _ACCEPTANCE_RUNNER = runner


class DefaultHarnessGate(HarnessGate):
    """Default implementation matching current behavior + adding explicit gate verdicts.

    - Pre-gate: does NOT decide policy itself; it records the decision already computed by
      existing policy logic (so behavior remains stable while we refactor call sites).
    - Post-gate: enforces quality-loop/fix loop invariants and emits a gate verdict event. Other
      stages default to "allow suggested transition".
    """

    def pre_gate(
        self,
        *,
        stage: str | None,
        normalized_kind: str | None,
        resolved_capability: str | None,
        decision: str,
        reason: str,
        policy_context: dict[str, Any] | None = None,
        paths: list[str] | None = None,
    ) -> GateVerdict:
        outcome: GateOutcome = "allow" if decision == "allow" else "deny"
        verdict = GateVerdict(
            scope="pre",
            outcome=outcome,
            reason=str(reason or ""),
            next_state=None,
            evidence={},
            details={
                "stage": stage,
                "normalized_kind": normalized_kind,
                "resolved_capability": resolved_capability,
                "paths": list(paths or []),
                "policy_context": policy_context or {},
            },
        )
        append_event(
            "gate_verdict",
            state=stage,
            data={
                "scope": verdict.scope,
                "outcome": verdict.outcome,
                "reason": verdict.reason,
                "next_state": verdict.next_state,
                "details": verdict.details,
                "evidence": verdict.evidence,
            },
        )
        return verdict

    def evaluate_pre_policy(
        self,
        *,
        descriptor: ToolDescriptor | None,
        stage: str | None,
        kind: str | None,
        paths: list[str],
        workspace_root: str | None,
        resolved_capability: str | None,
        policy_context: dict[str, Any] | None = None,
        tool_id: str | None = None,
        enabled_tool_ids: set[str] | None = None,
    ) -> tuple[bool, str]:
        """Pre-gate policy wrapper (behavior-stable).

        This calls the existing policy evaluation, then emits a unified pre-gate verdict event.
        """
        # Stage tool allowlist is an additional constraint. For most tools it only narrows
        # access; for terminal.bash an explicit stage enable also authorizes this high-risk
        # family inside the existing workspace sandbox.
        bash_explicitly_enabled = False
        if enabled_tool_ids is not None:
            bash_explicitly_enabled = "bash:shell" in enabled_tool_ids
            # Only enforce allowlist for tool-like actions; read/write are already sandboxed and
            # generally stage-scoped by capability families.
            if kind in {"mcp", "skill"}:
                if not tool_id:
                    allowed, reason = False, "unknown_tool_identity"
                elif tool_id not in enabled_tool_ids:
                    allowed, reason = False, "tool_not_enabled_for_stage"
                else:
                    allowed, reason = True, "enabled_by_stage_config"
            elif kind == "execute":
                if not tool_id:
                    allowed, reason = False, "unknown_tool_identity"
                elif tool_id in enabled_tool_ids:
                    allowed, reason = True, "enabled_by_stage_config"
                elif resolved_capability == "terminal.cli" and bash_explicitly_enabled:
                    allowed, reason = True, "enabled_by_stage_bash"
                else:
                    allowed, reason = False, "tool_not_enabled_for_stage"
            else:
                allowed, reason = True, "not_applicable"
        else:
            allowed, reason = True, "no_stage_tool_config"

        # Existing policy evaluation remains authoritative and can still deny.
        if allowed:
            allowed, reason = evaluate_policy(
                descriptor,
                stage,
                kind,
                paths,
                workspace_root,
                allow_high_risk=bash_explicitly_enabled,
            )

        # Map raw deny reasons into user-facing categories for UI.
        category = None
        if not allowed:
            category = self._deny_category(reason)
        self.pre_gate(
            stage=stage,
            normalized_kind=kind,
            resolved_capability=resolved_capability,
            decision="allow" if allowed else "deny",
            reason=reason,
            policy_context={
                **(policy_context or {}),
                "tool_id": tool_id,
                "enabled_tool_ids_present": enabled_tool_ids is not None,
                "deny_category": category,
            },
            paths=paths,
        )
        return allowed, reason

    def _deny_category(self, reason: str) -> str:
        r = str(reason or "")
        if r in {"tool_not_enabled_for_stage", "unknown_tool_identity"}:
            return "config"
        if r in {"outside_workspace", "missing_workspace_root", "missing_paths_for_write"}:
            return "sandbox"
        if r in {"high_risk_default_deny"}:
            return "risk"
        if r in {"tool_not_allowed_in_stage"}:
            return "stage"
        if r.startswith("unknown_") or r.startswith("unclassified_"):
            return "discovery"
        return "policy"

    def post_gate(
        self,
        *,
        stage: str,
        suggested_next_state: str | None,
        metadata: dict[str, Any] | None,
    ) -> GateVerdict:
        meta = metadata if isinstance(metadata, dict) else {}
        suggested = str(suggested_next_state) if suggested_next_state is not None else None

        verdict = self._post_gate_verdict(stage=stage, suggested_next_state=suggested, meta=meta)
        append_event(
            "gate_verdict",
            state=stage,
            data={
                "scope": verdict.scope,
                "outcome": verdict.outcome,
                "reason": verdict.reason,
                "suggested_next_state": suggested,
                "next_state": verdict.next_state,
                "details": verdict.details,
                "evidence": verdict.evidence,
            },
        )
        return verdict

    def _post_gate_verdict(self, *, stage: str, suggested_next_state: str | None, meta: dict[str, Any]) -> GateVerdict:
        # Default: allow the handler's suggested transition (compatibility mode).
        if not stage:
            return GateVerdict(scope="post", outcome="deny", reason="missing_stage", next_state="FAILED")

        if stage in {"PRD_DRAFTING", "TECH_SPEC_DRAFTING", "CODING", "DEPLOYING", "REGRESSION_TESTING"}:
            return self._post_gate_acceptance(stage=stage, suggested_next_state=suggested_next_state, meta=meta)
        if stage == "QUALITY_LOOP":
            return self._post_gate_quality_loop(suggested_next_state=suggested_next_state, meta=meta)
        if stage == "VERIFYING":
            return self._post_gate_quality_loop_alias(suggested_next_state=suggested_next_state, meta=meta)
        if stage == "FIXING":
            return self._post_gate_fixing(suggested_next_state=suggested_next_state, meta=meta)
        return GateVerdict(scope="post", outcome="allow", reason="allowed_by_default", next_state=suggested_next_state)

    def _post_gate_acceptance(self, *, stage: str, suggested_next_state: str | None, meta: dict[str, Any]) -> GateVerdict:
        from core.stage_acceptance import acceptance_result_from_metadata, stage_acceptance_pass_next_state

        expected_next_state = stage_acceptance_pass_next_state(stage)
        if suggested_next_state == "FAILED":
            return GateVerdict(scope="post", outcome="allow", reason="handler_failed", next_state="FAILED")
        if suggested_next_state == "AUTH_BLOCKED":
            return GateVerdict(
                scope="post",
                outcome="allow",
                reason="acceptance_stage_auth_blocked",
                next_state="AUTH_BLOCKED",
                details={"stage": stage},
            )
        if suggested_next_state != expected_next_state:
            return GateVerdict(
                scope="post",
                outcome="deny",
                reason="unexpected_transition_from_acceptance_stage",
                next_state="FAILED",
                details={"suggested_next_state": suggested_next_state, "expected_next_state": expected_next_state},
            )

        cached_result = acceptance_result_from_metadata(meta, stage)
        if isinstance(cached_result, dict):
            verdict = str(cached_result.get("verdict") or "").strip().lower()
            if verdict == "pass":
                return GateVerdict(
                    scope="post",
                    outcome="allow",
                    reason="acceptance_pass_allows_transition",
                    next_state=expected_next_state,
                    evidence={"acceptance_result": cached_result},
                )

        if _ACCEPTANCE_RUNNER is None:
            return GateVerdict(
                scope="post",
                outcome="deny",
                reason="acceptance_runner_missing",
                next_state="FAILED",
                details={"stage": stage},
            )

        try:
            result = _ACCEPTANCE_RUNNER(stage=stage, metadata=meta)
        except Exception as exc:
            return GateVerdict(
                scope="post",
                outcome="deny",
                reason="acceptance_runner_error",
                next_state="FAILED",
                details={"stage": stage, "error": str(exc)},
            )

        outcome = str(result.get("outcome") or "").strip().lower()
        verdict_data = result.get("acceptance_result") if isinstance(result.get("acceptance_result"), dict) else None
        if outcome == "pass":
            return GateVerdict(
                scope="post",
                outcome="allow",
                reason="acceptance_pass_allows_transition",
                next_state=expected_next_state,
                evidence={"acceptance_result": verdict_data or {}},
                details={"stage": stage},
            )
        if outcome == "fail":
            reason = str(result.get("reason") or "acceptance_failed").strip() or "acceptance_failed"
            retryable_reasons = {
                "stage_output_validation_failed",
                "acceptance_failed",
                "acceptance_verifier_error",
            }
            if bool(result.get("should_retry")) and reason in retryable_reasons:
                return GateVerdict(
                    scope="post",
                    outcome="force",
                    reason="acceptance_stage_retry",
                    next_state=stage,
                    evidence={"acceptance_result": verdict_data or {}},
                    details={"stage": stage, "acceptance_reason": reason},
                )
            return GateVerdict(
                scope="post",
                outcome="deny",
                reason="acceptance_failed_blocks_transition",
                next_state="FAILED",
                evidence={"acceptance_result": verdict_data or {}},
                details={"stage": stage, "acceptance_reason": reason},
            )
        return GateVerdict(
            scope="post",
            outcome="deny",
            reason="acceptance_runner_invalid_outcome",
            next_state="FAILED",
            details={"stage": stage, "outcome": outcome},
            evidence={"acceptance_result": verdict_data or {}},
        )

    def _post_gate_quality_loop(self, *, suggested_next_state: str | None, meta: dict[str, Any]) -> GateVerdict:
        quality_loop = meta.get("quality_loop") if isinstance(meta.get("quality_loop"), dict) else {}
        phase = str(quality_loop.get("phase") or meta.get("quality_loop_phase") or "verify").strip().lower() or "verify"
        history = quality_loop.get("history") if isinstance(quality_loop.get("history"), list) else []
        last_history = history[-1] if history else None
        last_result = None
        if isinstance(last_history, dict):
            last_result = str(last_history.get("result") or "").strip().lower() or None
        last_error_log = str(meta.get("last_error_log", "") or "")
        try:
            retry_count = int(quality_loop.get("retry_count", 0) or 0)
        except (TypeError, ValueError):
            retry_count = 0
        try:
            max_retries = int(quality_loop.get("max_retries", 5) or 5)
        except (TypeError, ValueError):
            max_retries = 5

        if suggested_next_state == "DEPLOYING":
            if last_result != "pass":
                return GateVerdict(
                    scope="post",
                    outcome="deny",
                    reason="quality_loop_deploy_requires_pass",
                    next_state="FAILED",
                    evidence={"quality_loop_phase": phase, "quality_loop_result": last_result},
                )
            if last_error_log.strip():
                return GateVerdict(
                    scope="post",
                    outcome="deny",
                    reason="quality_loop_deploy_requires_empty_last_error_log",
                    next_state="FAILED",
                    evidence={"last_error_log_size": len(last_error_log)},
                )
            return GateVerdict(scope="post", outcome="allow", reason="quality_loop_pass_allows_deploy", next_state="DEPLOYING")

        if suggested_next_state == "AUTH_BLOCKED":
            return GateVerdict(scope="post", outcome="allow", reason="quality_loop_auth_blocked", next_state="AUTH_BLOCKED")

        if suggested_next_state == "FAILED":
            return GateVerdict(scope="post", outcome="allow", reason="quality_loop_failed", next_state="FAILED")

        if suggested_next_state in {"QUALITY_LOOP", "VERIFYING", "FIXING"}:
            if retry_count > max_retries:
                return GateVerdict(
                    scope="post",
                    outcome="abort",
                    reason="quality_loop_max_retries_exceeded",
                    next_state="FAILED",
                    evidence={"retry_count": retry_count, "max_retries": max_retries},
                )
            if phase == "fix":
                if not last_error_log.strip() and last_result not in {"fixed", "fix_failed", "auth_blocked"}:
                    return GateVerdict(
                        scope="post",
                        outcome="deny",
                        reason="quality_loop_fix_requires_failure_context",
                        next_state="FAILED",
                        evidence={"quality_loop_result": last_result, "last_error_log_size": len(last_error_log)},
                    )
                return GateVerdict(scope="post", outcome="force", reason="quality_loop_continue_fix", next_state="QUALITY_LOOP")
            if last_result in {"fail", "abort"} and not last_error_log.strip():
                return GateVerdict(
                    scope="post",
                    outcome="deny",
                    reason="quality_loop_retry_requires_last_error_log",
                    next_state="FAILED",
                    evidence={"quality_loop_result": last_result, "last_error_log_size": len(last_error_log)},
                )
            return GateVerdict(scope="post", outcome="force", reason="quality_loop_continue_verify", next_state="QUALITY_LOOP")

        return GateVerdict(
            scope="post",
            outcome="deny",
            reason="unexpected_transition_from_quality_loop",
            next_state="FAILED",
            details={"suggested_next_state": suggested_next_state, "quality_loop_phase": phase},
        )

    def _post_gate_quality_loop_alias(self, *, suggested_next_state: str | None, meta: dict[str, Any]) -> GateVerdict:
        # Compatibility shim for legacy VERIFYING entry points.
        last_error_log = str(meta.get("last_error_log", "") or "")
        quality_loop = meta.get("quality_loop") if isinstance(meta.get("quality_loop"), dict) else {}
        quality_loop_history = quality_loop.get("history") if isinstance(quality_loop.get("history"), list) else []
        last_quality_loop = quality_loop_history[-1] if quality_loop_history else None
        last_quality_loop_result = str(last_quality_loop.get("result")) if isinstance(last_quality_loop, dict) and last_quality_loop.get("result") is not None else None

        max_retries = int(quality_loop.get("max_retries", 5) or 5)
        retry_count = int(quality_loop.get("retry_count", 0) or 0)

        if suggested_next_state == "DEPLOYING":
            if last_quality_loop_result != "pass":
                return GateVerdict(
                    scope="post",
                    outcome="deny",
                    reason="quality_loop_deploy_requires_pass",
                    next_state="FAILED",
                    evidence={"quality_loop_result": last_quality_loop_result, "quality_loop_history_len": len(quality_loop_history)},
                )
            if last_error_log.strip():
                return GateVerdict(
                    scope="post",
                    outcome="deny",
                    reason="quality_loop_deploy_requires_empty_last_error_log",
                    next_state="FAILED",
                    evidence={"last_error_log_size": len(last_error_log)},
                )
            return GateVerdict(scope="post", outcome="allow", reason="quality_loop_pass_allows_deploy", next_state="DEPLOYING")

        if suggested_next_state in {"FIXING", "QUALITY_LOOP"}:
            if retry_count > max_retries:
                return GateVerdict(
                    scope="post",
                    outcome="abort",
                    reason="quality_loop_max_retries_exceeded",
                    next_state="FAILED",
                    evidence={"retry_count": retry_count, "max_retries": max_retries},
                )
            if not last_error_log.strip():
                return GateVerdict(
                    scope="post",
                    outcome="deny",
                    reason="quality_loop_retry_requires_last_error_log",
                    next_state="FAILED",
                    evidence={"last_error_log_size": len(last_error_log)},
                )
            if last_quality_loop_result not in {"fail", "abort"}:
                return GateVerdict(
                    scope="post",
                    outcome="deny",
                    reason="quality_loop_fix_requires_failure_context",
                    next_state="FAILED",
                    evidence={"quality_loop_result": last_quality_loop_result, "quality_loop_history_len": len(quality_loop_history)},
                )
            return GateVerdict(scope="post", outcome="force", reason="quality_loop_fail_forces_fixing", next_state="FIXING")

        if suggested_next_state == "FAILED":
            return GateVerdict(scope="post", outcome="allow", reason="handler_failed", next_state="FAILED")

        return GateVerdict(
            scope="post",
            outcome="deny",
            reason="unexpected_transition_from_quality_loop_alias",
            next_state="FAILED",
            details={"suggested_next_state": suggested_next_state},
        )

    def _post_gate_fixing(self, *, suggested_next_state: str | None, meta: dict[str, Any]) -> GateVerdict:
        # Enforce: fixing cannot skip back to deploy/finished; it must return to the delivery-validation loop.
        if suggested_next_state in {"VERIFYING", "QUALITY_LOOP"}:
            return GateVerdict(scope="post", outcome="force", reason="fixing_success_forces_quality_loop", next_state="QUALITY_LOOP")
        if suggested_next_state == "FAILED":
            return GateVerdict(scope="post", outcome="allow", reason="fixing_failed", next_state="FAILED")
        return GateVerdict(
            scope="post",
            outcome="deny",
            reason="fixing_must_transition_to_quality_loop_or_failed",
            next_state="FAILED",
            details={"suggested_next_state": suggested_next_state},
        )


_DEFAULT_GATE: DefaultHarnessGate | None = None


def default_gate() -> DefaultHarnessGate:
    global _DEFAULT_GATE
    if _DEFAULT_GATE is None:
        _DEFAULT_GATE = DefaultHarnessGate()
    return _DEFAULT_GATE
