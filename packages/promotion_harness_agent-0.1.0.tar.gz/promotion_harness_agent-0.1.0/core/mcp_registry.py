"""Manage the repo-level MCP registration file (.harness/mcp.json).

This is the user's curated list of MCP servers that Harness will spin up
(via ACP new_session) for every run. It is symmetric with `core.cli_registry`:
users register entries explicitly through the UI; Harness never auto-discovers
MCP servers.

UI-managed transports: http and stdio.
SSE remains supported at the runtime layer (`core.mcp_config`) for hand-written
config files, but it is not currently editable through this module.

On-disk shape (consumed by core.mcp_config.load_effective_mcp_servers):

    {
      "mcpServers": {
        "<name>": {
          "type": "http",
          "url": "https://...",
          "headers": {"Authorization": "Bearer ..."}
        },
        "<local>": {
          "type": "stdio",
          "command": "coco",
          "args": ["mcp", "serve"],
          "env": {"FOO": "bar"}
        }
      },
      "stages": {...}    # optional, preserved untouched on write
    }

We intentionally:
  - keep the same JSON shape so mcp_config.py keeps working unchanged
  - preserve any unknown top-level keys on write (so hand-edited `stages`
    and non-UI transport entries are not lost on register/delete)
  - never probe the endpoint/command here; the resolved=true hint just means
    the minimal local validation passed
"""
from __future__ import annotations

import json
import os
import re
import tempfile
from dataclasses import dataclass
from typing import Any, Literal

from core.mcp_config import _resolve_stdio_command

_MCP_REL = os.path.join(".harness", "mcp.json")
_SLUG_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._+\-]{0,63}$")


Transport = Literal["http", "stdio"]


@dataclass
class McpRegistryEntry:
    name: str
    transport: Transport
    url: str | None = None
    headers: dict[str, str] | None = None
    command: str | None = None
    args: list[str] | None = None
    env: dict[str, str] | None = None

    def to_dict(self) -> dict[str, Any]:
        if self.transport == "http":
            d: dict[str, Any] = {"type": "http", "url": self.url or ""}
            if self.headers:
                d["headers"] = dict(self.headers)
            return d
        d = {
            "type": "stdio",
            "command": self.command or "",
        }
        if self.args:
            d["args"] = list(self.args)
        if self.env:
            d["env"] = dict(self.env)
        return d


def mcp_path(repo_root: str) -> str:
    return os.path.join(repo_root, _MCP_REL)


def _read_raw(repo_root: str) -> dict[str, Any]:
    """Return the full JSON document (preserving `stages` etc). Empty dict if missing/invalid."""
    path = mcp_path(repo_root)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(data, dict):
        return {}
    return data


def _write_atomic(repo_root: str, doc: dict[str, Any]) -> str:
    path = mcp_path(repo_root)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".mcp.", suffix=".json.tmp", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
    return path


def list_registered(repo_root: str) -> list[dict[str, Any]]:
    """Return normalized UI-visible MCP entries with a `resolved` hint."""
    doc = _read_raw(repo_root)
    servers = doc.get("mcpServers") if isinstance(doc, dict) else None
    if not isinstance(servers, dict):
        return []
    out: list[dict[str, Any]] = []
    for name, payload in servers.items():
        if not isinstance(name, str) or not isinstance(payload, dict):
            continue
        transport = str(payload.get("type") or "").lower().strip()
        if transport == "http":
            url = str(payload.get("url") or "").strip()
            headers_raw = payload.get("headers") or {}
            headers = {str(k): str(v) for k, v in headers_raw.items()} if isinstance(headers_raw, dict) else {}
            out.append(
                {
                    "name": name,
                    "transport": "http",
                    "url": url,
                    "headers": headers,
                    "resolved": bool(url),
                }
            )
            continue
        if transport == "stdio":
            command = str(payload.get("command") or "").strip()
            args_raw = payload.get("args") or []
            env_raw = payload.get("env") or {}
            args = [str(v) for v in args_raw] if isinstance(args_raw, list) else []
            env = {str(k): str(v) for k, v in env_raw.items()} if isinstance(env_raw, dict) else {}
            out.append(
                {
                    "name": name,
                    "transport": "stdio",
                    "command": command,
                    "args": args,
                    "env": env,
                    "resolved": bool(_resolve_stdio_command(command)),
                }
            )
    return out


class McpRegistryError(ValueError):
    """Raised when the caller provides an invalid MCP registration payload."""


def _coerce_headers(value: Any) -> dict[str, str]:
    if value is None or value == "":
        return {}
    if not isinstance(value, dict):
        raise McpRegistryError("invalid_headers: expected object of string→string")
    out: dict[str, str] = {}
    for k, v in value.items():
        ks = str(k).strip()
        if not ks:
            continue
        out[ks] = str(v)
    return out


def _coerce_string_map(value: Any, *, field: str) -> dict[str, str]:
    if value is None or value == "":
        return {}
    if not isinstance(value, dict):
        raise McpRegistryError(f"invalid_{field}: expected object of string→string")
    out: dict[str, str] = {}
    for k, v in value.items():
        ks = str(k).strip()
        if not ks:
            continue
        out[ks] = str(v)
    return out


def _coerce_args(value: Any) -> list[str]:
    if value is None or value == "":
        return []
    if not isinstance(value, list):
        raise McpRegistryError("invalid_args: expected array of strings")
    return [str(v) for v in value]


def _validate(payload: dict[str, Any]) -> McpRegistryEntry:
    name = str(payload.get("name") or "").strip()
    if not _SLUG_RE.match(name):
        raise McpRegistryError(
            "invalid_name: must be 1-64 chars of [A-Za-z0-9._+-] and start with an alnum"
        )
    transport = str(payload.get("transport") or payload.get("type") or "http").lower().strip()
    if transport == "http":
        url = str(payload.get("url") or "").strip()
        if not url:
            raise McpRegistryError("invalid_url: required")
        if not (url.startswith("http://") or url.startswith("https://")):
            raise McpRegistryError("invalid_url: must start with http:// or https://")
        return McpRegistryEntry(
            name=name,
            transport="http",
            url=url,
            headers=_coerce_headers(payload.get("headers")),
        )
    if transport == "stdio":
        command = str(payload.get("command") or "").strip()
        if not command:
            raise McpRegistryError("invalid_command: required")
        return McpRegistryEntry(
            name=name,
            transport="stdio",
            command=command,
            args=_coerce_args(payload.get("args")),
            env=_coerce_string_map(payload.get("env"), field="env"),
        )
    raise McpRegistryError(
        f"unsupported_transport: {transport} (supported: http, stdio)"
    )


def register_mcp(repo_root: str, payload: dict[str, Any], overwrite: bool = False) -> tuple[str, bool]:
    """Add or update one UI-managed MCP server entry. Returns (saved_path, created_new)."""
    entry = _validate(payload)
    doc = _read_raw(repo_root)
    servers_raw = doc.get("mcpServers") if isinstance(doc.get("mcpServers"), dict) else {}
    servers = dict(servers_raw) if isinstance(servers_raw, dict) else {}
    existing = servers.get(entry.name) if isinstance(servers.get(entry.name), dict) else None
    if existing:
        existing_type = str(existing.get("type") or "").lower().strip()
        if existing_type and existing_type not in {"http", "stdio"}:
            raise McpRegistryError(
                f"name_collides_with_{existing_type}: {entry.name} is currently declared as "
                f"{existing_type} in .harness/mcp.json; the UI only manages http/stdio entries"
            )
        if not overwrite:
            raise McpRegistryError(
                f"duplicate_name: {entry.name} already registered (use overwrite=true)"
            )
    servers[entry.name] = entry.to_dict()
    new_doc = dict(doc) if isinstance(doc, dict) else {}
    new_doc["mcpServers"] = servers
    path = _write_atomic(repo_root, new_doc)
    return path, existing is None


def delete_mcp(repo_root: str, name: str) -> tuple[str, bool]:
    """Remove one UI-managed MCP server entry by name. Returns (saved_path, removed).

    Refuses to delete transports that the UI does not manage.
    """
    target = str(name or "").strip()
    if not target:
        raise McpRegistryError("invalid_name")
    doc = _read_raw(repo_root)
    servers = doc.get("mcpServers") if isinstance(doc, dict) else None
    if not isinstance(servers, dict) or target not in servers:
        return mcp_path(repo_root), False
    existing = servers.get(target)
    if isinstance(existing, dict):
        existing_type = str(existing.get("type") or "").lower().strip()
        if existing_type and existing_type not in {"http", "stdio"}:
            raise McpRegistryError(
                f"refuse_delete_non_ui_transport: {target} is {existing_type}; hand-edit .harness/mcp.json"
            )
    new_servers = {k: v for k, v in servers.items() if k != target}
    new_doc: dict[str, Any] = dict(doc)
    new_doc["mcpServers"] = new_servers
    stages = new_doc.get("stages")
    if isinstance(stages, dict):
        pruned_stages: dict[str, list[str]] = {}
        for k, v in stages.items():
            if isinstance(v, list):
                pruned_stages[str(k)] = [str(x) for x in v if str(x) != target]
        new_doc["stages"] = pruned_stages
    path = _write_atomic(repo_root, new_doc)
    return path, True
