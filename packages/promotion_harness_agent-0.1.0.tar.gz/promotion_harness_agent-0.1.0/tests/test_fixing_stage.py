import os

from agents.trae_fixing_agent import trae_fixing_agent
from core.orchestrator import FlowState
from tests.runtime_fixtures import build_runtime_ctx


class _StubAgent:
    def __init__(self, error: str | None = None):
        self.error = error
        self.prompt_text = None
        self.cwd = None

    def run_task(self, prompt_text: str, cwd: str, stage: str | None = None):
        self.prompt_text = prompt_text
        self.cwd = cwd
        return {
            "updates": [],
            "final_response": {"stop_reason": "end_turn"},
            "error": self.error,
            "sessionId": "sess-fixing",
            "supportsSessionList": False,
            "supportsLoadSession": True,
            "sessionInfo": {
                "sessionId": "sess-fixing",
                "cwd": cwd,
                "title": "Fixing session",
            },
        }


def _build_ctx(tmp_path):
    ctx, _ = build_runtime_ctx(tmp_path)
    ctx.update_metadata("last_error_log", "pytest failed: assert 1 == 2")
    return ctx


def test_fixing_stage_builds_prompt_and_returns_quality_loop(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    src_file = tmp_path / "src" / "app.py"
    test_file = tmp_path / "tests" / "test_app.py"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    src_file.parent.mkdir(parents=True, exist_ok=True)
    test_file.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")
    src_file.write_text("def add(a, b):\n    return a-b\n", encoding="utf-8")
    test_file.write_text("def test_add():\n    assert True\n", encoding="utf-8")

    stub = _StubAgent()
    monkeypatch.setattr("agents.trae_fixing_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_fixing_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.QUALITY_LOOP
    assert "pytest failed: assert 1 == 2" in stub.prompt_text
    assert "src/app.py" in stub.prompt_text
    assert "tests/test_app.py" in stub.prompt_text
    assert ctx.context["metadata"]["acp_sessions"]["sess-fixing"]["supportsLoadSession"] is True
    assert ctx.context["metadata"]["acp_sessions"]["sess-fixing"]["title"] == "Fixing session"


def test_fixing_stage_fails_when_agent_errors(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")

    stub = _StubAgent(error="permission denied")
    monkeypatch.setattr("agents.trae_fixing_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_fixing_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["last_error_log"] == "AcpAgent run_task returned error: permission denied"


def test_fixing_stage_fails_without_error_log(tmp_path):
    ctx, _ = build_runtime_ctx(tmp_path)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_fixing_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["last_error_log"] == "Missing delivery-validation evidence for fixing."
