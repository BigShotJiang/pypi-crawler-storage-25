import json
import os

from core.tool_catalog import advertise_effective_tool_catalog, build_tool_catalog_payload
from core.stage_tool_config import (
    BASH_TOOL_ID,
    default_enabled_tool_ids_for_stage,
    default_stage_tool_config,
    ensure_user_stage_tool_config_seeded,
    load_stage_tool_config,
    reset_user_stage_tool_config_to_defaults,
    user_config_path,
)


def _write_cli_tools(repo_root: str, items):
    os.makedirs(os.path.join(repo_root, ".harness"), exist_ok=True)
    with open(os.path.join(repo_root, ".harness", "cli_tools.json"), "w", encoding="utf-8") as f:
        json.dump(items, f)


def test_repo_declared_cli_is_filtered_out_when_user_has_not_enabled_it(tmp_path):
    """User's stage_tools.json is the single source of truth.

    Even if the repo declares a CLI, if the user has not enabled it in their
    config, it MUST NOT appear in the effective catalog.
    """
    repo_root = str(tmp_path)
    _write_cli_tools(
        repo_root,
        [
            {
                "name": "lark-cli",
                "command": "sh",
                "summary": "Fetch Lark doc",
                "risk_level": "medium",
            }
        ],
    )

    # User has a config but no cli:* entries for PRD_DRAFTING.
    enabled_tool_ids: set[str] = {"skill:lark-doc"}
    md, payload = advertise_effective_tool_catalog(
        "PRD_DRAFTING",
        workspace_root=repo_root,
        enabled_tool_ids=enabled_tool_ids,
    )
    tool_ids = [e["tool_id"] for e in payload["entries"] if e.get("tool_id")]
    assert "cli:lark-cli" not in tool_ids, (
        "Repo declaration must NOT silently bypass user stage_tools.json. Got: " + str(tool_ids)
    )


def test_default_enabled_tool_ids_pulls_all_repo_declared_cli(tmp_path):
    """Seed defaults now include repo-declared tools without stage allowlist filtering."""
    repo_root = str(tmp_path)
    _write_cli_tools(
        repo_root,
        [
            {
                "name": "lark-cli",
                "command": "sh",
                "summary": "Fetch Lark doc",
            },
            {
                "name": "bytedcli",
                "command": "sh",
                "summary": "Repo workflow",
            },
        ],
    )
    ids = default_enabled_tool_ids_for_stage(repo_root, "PRD_DRAFTING")
    assert "cli:lark-cli" in ids
    assert "cli:bytedcli" in ids


def test_default_stage_tool_config_covers_seedable_stages(tmp_path):
    repo_root = str(tmp_path)
    _write_cli_tools(
        repo_root,
        [
            {
                "name": "lark-cli",
                "command": "sh",
                "summary": "Fetch Lark doc",
            }
        ],
    )
    defaults = default_stage_tool_config(repo_root)
    assert "PRD_DRAFTING" in defaults
    assert "CODING" in defaults
    assert "DEPLOYING" in defaults
    assert "REGRESSION_TESTING" in defaults
    assert "cli:lark-cli" in defaults["PRD_DRAFTING"]
    assert "cli:lark-cli" in defaults["TECH_SPEC_DRAFTING"]
    assert "cli:lark-cli" in defaults.get("CODING", [])


def test_ensure_seeded_writes_file_on_first_run_only(tmp_path, monkeypatch):
    repo_root = str(tmp_path)
    # Redirect HOME so user config path lives inside tmp_path and doesn't touch real ~/.
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    _write_cli_tools(
        repo_root,
        [
            {
                "name": "lark-cli",
                "command": "sh",
                "summary": "Fetch Lark doc",
            }
        ],
    )

    # First call: seeds.
    path1, seeded1 = ensure_user_stage_tool_config_seeded(repo_root)
    assert seeded1 is True
    assert os.path.exists(path1)

    # Second call: must NOT overwrite.
    with open(path1, "r", encoding="utf-8") as f:
        content_before = f.read()
    # Mutate the user file to verify it is preserved.
    with open(path1, "r", encoding="utf-8") as f:
        data = json.load(f)
    data["stages"]["PRD_DRAFTING"] = []
    with open(path1, "w", encoding="utf-8") as f:
        json.dump(data, f)

    path2, seeded2 = ensure_user_stage_tool_config_seeded(repo_root)
    assert seeded2 is False
    assert path2 == path1
    with open(path2, "r", encoding="utf-8") as f:
        data_after = json.load(f)
    assert data_after["stages"]["PRD_DRAFTING"] == [], "existing user config must be preserved"
    # Sanity: content changed from the freshly-seeded content, proving no re-seed happened.
    assert json.dumps(data_after, sort_keys=True) != content_before


def test_reset_user_config_overwrites_with_defaults(tmp_path, monkeypatch):
    repo_root = str(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    _write_cli_tools(
        repo_root,
        [
            {
                "name": "lark-cli",
                "command": "sh",
                "summary": "Fetch Lark doc",
            }
        ],
    )
    ensure_user_stage_tool_config_seeded(repo_root)
    upath = user_config_path()
    # Mutate user config to drop lark-cli.
    with open(upath, "r", encoding="utf-8") as f:
        data = json.load(f)
    data["stages"]["PRD_DRAFTING"] = []
    with open(upath, "w", encoding="utf-8") as f:
        json.dump(data, f)

    saved = reset_user_stage_tool_config_to_defaults(repo_root)
    assert saved == upath
    cfg = load_stage_tool_config(repo_root)
    assert "cli:lark-cli" in cfg.stages.get("PRD_DRAFTING", []), cfg.stages


def test_tool_catalog_prompt_no_longer_emits_usage(tmp_path, monkeypatch):
    """`usage` has been removed: render must never contain 'usage:' prefix."""
    repo_root = str(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    # Even if the legacy cli_tools.json still carries `usage`, we must strip it
    # from the advertised prompt so the model doesn't latch onto a stale template.
    os.makedirs(os.path.join(repo_root, ".harness"), exist_ok=True)
    with open(os.path.join(repo_root, ".harness", "cli_tools.json"), "w", encoding="utf-8") as f:
        json.dump(
            [
                {
                    "name": "sh-tool",
                    "command": "sh",
                    "summary": "shell",
                    "usage": "sh -c 'hi'",
                }
            ],
            f,
        )
    md, _payload = advertise_effective_tool_catalog(
        "PRD_DRAFTING",
        workspace_root=repo_root,
        enabled_tool_ids={"cli:sh-tool"},
    )
    assert "sh-tool" in md
    assert "usage:" not in md, md


def test_tool_catalog_payload_includes_bash_entry(tmp_path):
    payload = build_tool_catalog_payload(stage="CODING", workspace_root=str(tmp_path))
    entries = payload.get("entries") or []
    bash_entries = [e for e in entries if e.get("type") == "bash"]
    assert bash_entries
    assert bash_entries[0].get("tool_id") == BASH_TOOL_ID


def test_effective_tool_catalog_can_filter_to_enabled_bash(tmp_path, monkeypatch):
    repo_root = str(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    md, payload = advertise_effective_tool_catalog(
        "CODING",
        workspace_root=repo_root,
        enabled_tool_ids={BASH_TOOL_ID},
    )
    tool_ids = [e["tool_id"] for e in payload["entries"] if e.get("tool_id")]
    assert BASH_TOOL_ID in tool_ids
    assert "Shell / Bash" in md


def test_effective_tool_catalog_documents_bash_implies_direct_cli(tmp_path, monkeypatch):
    repo_root = str(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    md, _payload = advertise_effective_tool_catalog(
        "CODING",
        workspace_root=repo_root,
        enabled_tool_ids={BASH_TOOL_ID},
    )
    assert "If `bash:shell` is enabled for this stage, direct CLI calls are also allowed by default." in md
    assert "Shell / bash / compound commands are only allowed when the bash entry is listed for this stage." in md
