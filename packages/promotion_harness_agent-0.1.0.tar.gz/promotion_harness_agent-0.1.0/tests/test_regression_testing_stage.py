import json
import os

from agents.trae_regression_testing_agent import trae_regression_testing_agent
from core.orchestrator import FlowState
from tests.runtime_fixtures import build_runtime_ctx


class _StubRegressionAgent:
    def __init__(self, root: str, error: str | None = None, *, write_stage_output: bool = True, missing_field: str | None = None, empty_cases: bool = False):
        self.root = root
        self.error = error
        self.write_stage_output = write_stage_output
        self.missing_field = missing_field
        self.empty_cases = empty_cases
        self.prompt_text = None
        self.cwd = None

    def run_task(self, prompt_text: str, cwd: str, stage: str | None = None):
        self.prompt_text = prompt_text
        self.cwd = cwd
        if self.error:
            return {"updates": [], "final_response": None, "error": self.error}

        report_path = os.path.join(self.root, ".harness", "runs", "run-test", "outputs", "regression_report.json")
        os.makedirs(os.path.dirname(report_path), exist_ok=True)
        payload = {
            "env_name": "BOE",
            "env_url": "https://example.com/boe",
            "branch_name": "feature/test-run",
            "test_cases": [] if self.empty_cases else ["health", "create_order"],
            "results": [{"name": "health", "status": "pass"}],
            "final_verdict": "pass",
            "summary": "regression ok",
        }
        if self.missing_field:
            payload.pop(self.missing_field, None)
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

        if self.write_stage_output:
            stage_output_path = os.path.join(self.root, ".harness", "runs", "run-test", "stage_outputs", "REGRESSION_TESTING.json")
            os.makedirs(os.path.dirname(stage_output_path), exist_ok=True)
            with open(stage_output_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "schema_version": 1,
                        "stage": "REGRESSION_TESTING",
                        "status": "completed",
                        "summary": "回归已完成。",
                        "artifacts": [
                            {
                                "artifact_type": "regression_report",
                                "path": ".harness/runs/run-test/outputs/regression_report.json",
                                "absolute_path": report_path,
                                "exists": True,
                                "is_dir": False,
                                "size_bytes": os.path.getsize(report_path),
                                "summary": "当前阶段生成的回归测试报告。",
                            }
                        ],
                        "key_points": ["env=BOE"],
                        "evidence": ["regression recorded"],
                        "metadata": {"artifact_key": "regression_report"},
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )

        return {
            "updates": [],
            "final_response": {"stop_reason": "end_turn"},
            "error": None,
            "sessionId": "sess-regression",
            "sessionInfo": {"sessionId": "sess-regression", "cwd": self.root, "title": "Regression session"},
        }


def test_regression_stage_returns_finished_and_records_metadata(tmp_path, monkeypatch):
    ctx, _ = build_runtime_ctx(tmp_path, run_id="run-test", state=FlowState.REGRESSION_TESTING.value)
    stub = _StubRegressionAgent(str(tmp_path))
    monkeypatch.setattr("agents.trae_regression_testing_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_regression_testing_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FINISHED
    assert ctx.context["artifacts"]["regression_report"] == ".harness/runs/run-test/outputs/regression_report.json"
    assert ctx.context["metadata"]["regression_result"] == "pass"
    assert ctx.context["metadata"]["regression_summary"] == "regression ok"
    assert ctx.context["metadata"]["acp_sessions"]["sess-regression"]["title"] == "Regression session"
    assert "regression_report.json" in stub.prompt_text
    assert "REGRESSION_TESTING.json" in stub.prompt_text


def test_regression_stage_fails_when_required_fields_missing(tmp_path, monkeypatch):
    ctx, _ = build_runtime_ctx(tmp_path, run_id="run-test", state=FlowState.REGRESSION_TESTING.value)
    stub = _StubRegressionAgent(str(tmp_path), missing_field="final_verdict")
    monkeypatch.setattr("agents.trae_regression_testing_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_regression_testing_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert "Regression report missing required fields: final_verdict" in ctx.context["metadata"]["last_error_log"]


def test_regression_stage_fails_when_test_cases_empty(tmp_path, monkeypatch):
    ctx, _ = build_runtime_ctx(tmp_path, run_id="run-test", state=FlowState.REGRESSION_TESTING.value)
    stub = _StubRegressionAgent(str(tmp_path), empty_cases=True)
    monkeypatch.setattr("agents.trae_regression_testing_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_regression_testing_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert "Regression report requires non-empty test_cases" in ctx.context["metadata"]["last_error_log"]
