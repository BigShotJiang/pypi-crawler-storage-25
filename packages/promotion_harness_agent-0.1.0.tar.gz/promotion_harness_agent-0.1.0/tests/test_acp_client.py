import pytest
import os
import asyncio
from tools.acp_client_wrapper import run_acp_prompt_test

@pytest.mark.asyncio
async def test_acp_connection_and_prompt():
    """
    Test that we can establish an ACP connection to the Coco agent,
    send a prompt, receive updates, and get a spec-compliant stop reason.
    """
    cwd = os.getcwd()
    prompt_text = "Please calculate 1 + 1 and reply with just the number."
    
    # We use a timeout to prevent hanging if the agent fails to respond
    result = await asyncio.wait_for(
        run_acp_prompt_test(prompt_text, cwd),
        timeout=90.0
    )
    
    # Assert no errors occurred during execution
    assert result["error"] is None, f"Execution failed with error: {result['error']}"
    
    # Assert we received agent capabilities
    assert "agentCapabilities" in result
    assert isinstance(result["agentCapabilities"], dict)
    
    # Assert we received a final response
    assert result["final_response"] is not None
    assert result["final_response"]["stop_reason"] == "end_turn"
    
    # Assert we received at least some updates (like thought or message chunk)
    updates = result["updates"]
    assert len(updates) > 0, "No stream updates were received from the agent"
    
    # Let's inspect what's inside the updates to make sure it's valid
    # Either 'thought' or 'agent_message_chunk' is fine
    # In Pydantic model dump, the type discriminator is usually 'type' or something.
    has_update = any(True for u in updates)
    assert has_update, "No valid updates found"
