from __future__ import annotations

import json

from harness_cli import build_parser, main


def test_harness_init_creates_control_plane(tmp_path, monkeypatch, capsys):
    repo = tmp_path / "repo"
    (repo / ".git").mkdir(parents=True)
    monkeypatch.chdir(repo)

    exit_code = main_args(["init"])

    assert exit_code == 0
    assert (repo / ".harness").is_dir()
    assert (repo / ".harness" / "runs").is_dir()
    config = json.loads((repo / ".harness" / "config.json").read_text(encoding="utf-8"))
    assert config["schema_version"] == 1
    assert config["runs_dir"] == ".harness/runs"
    current = json.loads((repo / ".harness" / "current_run.json").read_text(encoding="utf-8"))
    assert current["run_id"] is None
    context_policy = json.loads((repo / ".harness" / "stage_context_policy.json").read_text(encoding="utf-8"))
    assert context_policy["schema_version"] == 2
    assert "CODING" in context_policy["policies"]
    assert "QUALITY_LOOP" in context_policy["policies"]
    acceptance_policy = json.loads((repo / ".harness" / "stage_acceptance_policy.json").read_text(encoding="utf-8"))
    assert acceptance_policy["schema_version"] == 1
    assert "CODING" in acceptance_policy["policies"]
    assert "QUALITY_LOOP" in acceptance_policy["policies"]
    assert "initialized Promotion Harness Agent repo" in capsys.readouterr().out


def test_harness_init_is_idempotent(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    (repo / ".git").mkdir(parents=True)
    monkeypatch.chdir(repo)

    assert main_args(["init"]) == 0
    original = (repo / ".harness" / "config.json").read_text(encoding="utf-8")
    context_path = repo / ".harness" / "stage_context_policy.json"
    acceptance_path = repo / ".harness" / "stage_acceptance_policy.json"
    context_path.write_text('{"schema_version": 2, "policies": {"CODING": {"rules": [], "output_requirements": "custom", "tool_instructions": ""}}}', encoding="utf-8")
    acceptance_path.write_text('{"schema_version": 1, "policies": {"CODING": {"enabled": true, "prompt": "custom", "model": "", "rules": [], "max_retries": 2}}}', encoding="utf-8")

    assert main_args(["init"]) == 0
    assert (repo / ".harness" / "config.json").read_text(encoding="utf-8") == original
    assert json.loads(context_path.read_text(encoding="utf-8"))["policies"]["CODING"]["output_requirements"] == "custom"
    assert json.loads(acceptance_path.read_text(encoding="utf-8"))["policies"]["CODING"]["prompt"] == "custom"


def test_harness_init_fails_when_not_git_repo(tmp_path, monkeypatch, capsys):
    repo = tmp_path / "repo"
    repo.mkdir(parents=True)
    monkeypatch.chdir(repo)

    exit_code = main_args(["init"])

    assert exit_code == 1
    assert "git_repository_required" in capsys.readouterr().out


def main_args(args: list[str]) -> int:
    parser = build_parser()
    namespace = parser.parse_args(args)
    return int(namespace.func(namespace))
