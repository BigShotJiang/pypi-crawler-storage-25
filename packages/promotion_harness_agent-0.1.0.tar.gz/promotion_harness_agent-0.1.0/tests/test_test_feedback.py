from tools.test_feedback import (
    build_feedback_command,
    build_pytest_args,
    discover_changed_files,
    recommend_test_commands,
)


def test_build_feedback_command_fast_includes_default_exclusions():
    cmd = build_feedback_command("fast")
    assert "uv run pytest -q" in cmd
    assert "not slow and not real_coco" in cmd


def test_build_pytest_args_stage_mode_includes_marker_expression():
    args = build_pytest_args("stage")
    assert args[1:4] == ["-m", "pytest", "-q"]
    assert "-m" in args
    assert "(stage or unit) and not slow and not real_coco" in args


def test_recommend_test_commands_matches_context_layer_paths():
    recs = recommend_test_commands(["core/context_layer.py", "core/context_manager.py"])
    assert recs
    assert recs[0].tests
    assert "tests/test_context_layer.py" in recs[0].tests
    assert "tests/test_context_manager.py" in recs[0].tests


def test_recommend_test_commands_falls_back_to_fast_mode():
    recs = recommend_test_commands(["unknown/path.py"])
    assert len(recs) == 1
    assert recs[0].title == "默认快反馈"
    assert "not slow and not real_coco" in recs[0].command


def test_discover_changed_files_reads_git_outputs(tmp_path, monkeypatch):
    class _Result:
        def __init__(self, stdout: str, returncode: int = 0):
            self.stdout = stdout
            self.returncode = returncode

    calls = []

    def _fake_run(command, cwd, capture_output, text, check):
        calls.append((tuple(command), cwd, capture_output, text, check))
        if command[:2] == ["git", "diff"]:
            return _Result("core/context_layer.py\n")
        return _Result("tests/test_context_layer.py\n")

    monkeypatch.setattr("tools.test_feedback.subprocess.run", _fake_run)

    changed = discover_changed_files(str(tmp_path))

    assert changed == ["core/context_layer.py", "tests/test_context_layer.py"]
    assert len(calls) == 2
