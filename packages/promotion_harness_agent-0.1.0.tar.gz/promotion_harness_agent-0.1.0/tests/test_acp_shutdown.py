import asyncio

import pytest

from core.acp_agent import _shutdown_subprocess


class _Proc:
    def __init__(self):
        self.returncode = None
        self.terminated = False
        self.killed = False
        self.wait_calls = 0

    def terminate(self):
        self.terminated = True

    def kill(self):
        self.killed = True

    async def wait(self):
        self.wait_calls += 1
        await asyncio.sleep(0)
        self.returncode = 0
        return 0


class _HangingProc(_Proc):
    async def wait(self):
        self.wait_calls += 1
        if self.wait_calls == 1:
            await asyncio.sleep(0.05)
            return 0
        await asyncio.sleep(0)
        self.returncode = 0
        return 0


@pytest.mark.asyncio
async def test_shutdown_subprocess_terminates_cleanly():
    p = _Proc()
    await _shutdown_subprocess(p, timeout_sec=0.01)
    assert p.terminated is True
    assert p.killed is False


@pytest.mark.asyncio
async def test_shutdown_subprocess_escalates_to_kill_on_timeout():
    p = _HangingProc()
    await _shutdown_subprocess(p, timeout_sec=0.01)
    assert p.terminated is True
    assert p.killed is True
