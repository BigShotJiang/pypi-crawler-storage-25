import os
import unittest
from core.context_manager import ContextManager
from core.orchestrator import Orchestrator, FlowState


class TestOrchestrator(unittest.TestCase):
    def setUp(self):
        self.test_file = "test_progress_orch.json"
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
        self.cm = ContextManager(self.test_file)
        self.cm.update_metadata("run_id", "run-test")
        self.cm.update_metadata("run_dir", ".harness/runs/run-test")
        self.orch = Orchestrator(self.cm)
        
    def tearDown(self):
        if os.path.exists(self.test_file):
            os.remove(self.test_file)

    def test_successful_pipeline(self):
        # Setup dummy handlers
        def plan_handler(ctx):
            return FlowState.BUILDING
            
        def build_handler(ctx):
            return FlowState.FINISHED
            
        self.orch.register_handler(FlowState.PLANNING, plan_handler)
        self.orch.register_handler(FlowState.BUILDING, build_handler)
        
        self.cm.set_state(FlowState.PLANNING.value)
        self.orch.run()
        
        self.assertEqual(self.cm.get_state(), FlowState.FINISHED.value)
        
    def test_missing_handler_fails(self):
        self.cm.set_state(FlowState.PLANNING.value)
        self.orch.run()
        # Should fail because no handler is registered for PLANNING
        self.assertEqual(self.cm.get_state(), FlowState.FAILED.value)

    def test_auth_blocked_is_terminal(self):
        # AUTH_BLOCKED should behave like a terminal state (but resumable by an external runner).
        self.cm.set_state(FlowState.AUTH_BLOCKED.value)
        self.orch.run()
        self.assertEqual(self.cm.get_state(), FlowState.AUTH_BLOCKED.value)

    def test_middleware_interception(self):
        def plan_handler(ctx):
            return FlowState.BUILDING

        def build_handler(ctx):
            return FlowState.FINISHED
            
        self.orch.register_handler(FlowState.PLANNING, plan_handler)
        self.orch.register_handler(FlowState.BUILDING, build_handler)
        
        # A middleware that intercepts BUILDING and forces it to FINISHED early
        def skip_build_middleware(orch):
            if orch.ctx.get_state() == FlowState.BUILDING.value:
                orch.ctx.set_state(FlowState.FINISHED.value)
                return True # continue with the new state
            return True
            
        self.orch.add_middleware(skip_build_middleware)
        self.cm.set_state(FlowState.PLANNING.value)
        self.orch.run()
        
        # We expect the state to be FINISHED
        self.assertEqual(self.cm.get_state(), FlowState.FINISHED.value)

if __name__ == '__main__':
    unittest.main()
