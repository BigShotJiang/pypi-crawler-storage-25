import json
import os
import re
import shutil
import pytest

from core.orchestrator import FlowState
from agents.trae_coding_agent import trae_coding_agent
from tests.runtime_fixtures import build_runtime_ctx


class _StubAgent:
    def __init__(self, root: str, error: str | None = None, *, create_src: bool = True, create_tests: bool = True, write_stage_output: bool = True):
        self.root = root
        self.error = error
        self.create_src = create_src
        self.create_tests = create_tests
        self.write_stage_output = write_stage_output

    def run_task(self, prompt_text: str, cwd: str, stage: str | None = None):
        if self.error:
            return {"updates": [], "final_response": None, "error": self.error}
        os.makedirs(os.path.join(self.root, "src"), exist_ok=True)
        os.makedirs(os.path.join(self.root, "tests"), exist_ok=True)
        if self.create_src:
            with open(os.path.join(self.root, "src", "app.py"), "w", encoding="utf-8") as f:
                f.write("def add(a, b):\n    return a + b\n")
        if self.create_tests:
            with open(os.path.join(self.root, "tests", "test_app.py"), "w", encoding="utf-8") as f:
                f.write("from src.app import add\n\ndef test_add():\n    assert add(1, 1) == 2\n")
        if self.write_stage_output:
            stage_output_abs_path = os.path.join(self.root, ".harness", "runs", "run-test", "stage_outputs", "CODING.json")
            os.makedirs(os.path.dirname(stage_output_abs_path), exist_ok=True)
            payload = {
                "schema_version": 1,
                "stage": "CODING",
                "status": "pass",
                "summary": "Coding 阶段已生成可供质量校验消费的代码与测试产物。",
                "artifacts": [
                    {
                        "artifact_type": "code_root",
                        "path": "src",
                        "absolute_path": os.path.join(self.root, "src"),
                        "exists": True,
                        "is_dir": True,
                        "size_bytes": 0,
                        "summary": "当前阶段生成的代码目录入口。",
                    },
                    {
                        "artifact_type": "tests_root",
                        "path": "tests",
                        "absolute_path": os.path.join(self.root, "tests"),
                        "exists": True,
                        "is_dir": True,
                        "size_bytes": 0,
                        "summary": "当前阶段生成的测试目录入口。",
                    },
                ],
                "key_points": [
                    f"src_dir={os.path.join(self.root, 'src')}",
                    f"tests_dir={os.path.join(self.root, 'tests')}",
                ],
                "evidence": [
                    "src exists and is non-empty",
                    "tests exists and is non-empty",
                ],
                "metadata": {
                    "artifact_key": "code_root",
                    "changed_files": ["src/app.py", "tests/test_app.py"],
                    "branch_name": "feature/test-run",
                    "commit_sha": "abc123",
                    "mr_url": "https://example.com/mr/1",
                },
            }
            with open(stage_output_abs_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        return {
            "updates": [],
            "final_response": {"stop_reason": "end_turn"},
            "error": None,
            "sessionId": "sess-coding",
            "supportsSessionList": True,
            "supportsLoadSession": False,
            "sessionInfo": {
                "sessionId": "sess-coding",
                "cwd": self.root,
                "title": "Coding session",
            },
        }


def _build_ctx(tmp_path, requirement: str):
    ctx, _ = build_runtime_ctx(tmp_path, requirement=requirement)
    return ctx


def test_coding_stage_requires_tech_spec(tmp_path):
    ctx = _build_ctx(tmp_path, "需求")
    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)
    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["last_error_log"] == "Tech spec file missing."


def test_coding_stage_writes_artifacts_and_returns_next_state(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    ts = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    ts.parent.mkdir(parents=True, exist_ok=True)
    ts.write_text("## Tech Spec\n", encoding="utf-8")

    stub = _StubAgent(str(tmp_path))
    monkeypatch.setattr("agents.trae_coding_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.QUALITY_LOOP
    assert ctx.context["artifacts"]["code_root"] == "src"
    assert ctx.context["artifacts"]["tests_root"] == "tests"
    assert ctx.context["metadata"]["acp_sessions"]["sess-coding"]["title"] == "Coding session"
    assert ctx.context["metadata"]["acp_sessions"]["sess-coding"]["supportsSessionList"] is True
    assert (tmp_path / "src").exists()
    assert (tmp_path / "tests").exists()
    stage_output_file = tmp_path / ".harness" / "runs" / "run-test" / "stage_outputs" / "CODING.json"
    assert stage_output_file.exists()


def test_coding_stage_records_error_when_agent_fails(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    ts = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    ts.parent.mkdir(parents=True, exist_ok=True)
    ts.write_text("## Tech Spec\n", encoding="utf-8")

    stub = _StubAgent(str(tmp_path), error="permission denied")
    monkeypatch.setattr("agents.trae_coding_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["last_error_log"] == "AcpAgent run_task returned error: permission denied"


def test_coding_stage_succeeds_even_when_model_does_not_write_stage_output_json(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    ts = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    ts.parent.mkdir(parents=True, exist_ok=True)
    ts.write_text("## Tech Spec\n", encoding="utf-8")

    stub = _StubAgent(str(tmp_path), write_stage_output=False)
    monkeypatch.setattr("agents.trae_coding_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.QUALITY_LOOP
    assert ctx.context["artifacts"]["code_root"] == "."
    assert ctx.context["artifacts"]["tests_root"] == "."
    assert "last_noncompliance" not in ctx.context["metadata"]


def test_coding_stage_retries_on_tool_gate_denial(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    ctx.update_metadata("max_stage_retries", 2)
    ctx.update_metadata("last_gate_denial", {
        "stage": FlowState.CODING.value,
        "reason": "tool_not_enabled_for_stage",
        "suggestion": "Use cli:lark-cli instead.",
        "details": {
            "tool_id": "bash:shell",
            "resolved_capability": "terminal.bash",
            "enabled_tool_ids": ["fs.read", "fs.write"],
        },
    })
    ts = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    ts.parent.mkdir(parents=True, exist_ok=True)
    ts.write_text("## Tech Spec\n", encoding="utf-8")

    stub = _StubAgent(str(tmp_path), error="Tool call rejected by user")
    monkeypatch.setattr("agents.trae_coding_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.CODING
    last = ctx.context["metadata"]["last_noncompliance"]
    assert last["stage"] == FlowState.CODING.value
    assert last["kind"] == "tool_gate"
    assert last["details"]["tool_id"] == "bash:shell"
    assert last["details"]["resolved_capability"] == "terminal.bash"


def test_coding_stage_fails_when_generated_tests_missing(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    ts = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    ts.parent.mkdir(parents=True, exist_ok=True)
    ts.write_text("## Tech Spec\n", encoding="utf-8")

    stub = _StubAgent(str(tmp_path), create_tests=False)
    monkeypatch.setattr("agents.trae_coding_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert "tests" in ctx.context["metadata"]["last_error_log"]


def test_coding_stage_fails_when_generated_source_missing(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    ts = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    ts.parent.mkdir(parents=True, exist_ok=True)
    ts.write_text("## Tech Spec\n", encoding="utf-8")

    stub = _StubAgent(str(tmp_path), create_src=False)
    monkeypatch.setattr("agents.trae_coding_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["last_error_log"] in {
        "No source artifacts were found under src",
        "stage_output_artifact_empty_dir: code_root",
    }


@pytest.mark.skipif(shutil.which("coco") is None, reason="coco binary not found in PATH")
def test_coding_stage_generates_code_and_tests_via_real_coco(tmp_path):
    ctx = _build_ctx(tmp_path, "实现一个简单的加法函数并提供pytest单测")
    ts = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    ts.parent.mkdir(parents=True, exist_ok=True)
    ts.write_text("## Tech Spec\n", encoding="utf-8")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.QUALITY_LOOP
    code_root = ctx.context["artifacts"]["code_root"]
    tests_root = ctx.context["artifacts"]["tests_root"]
    assert (tmp_path / code_root).exists()
    assert (tmp_path / tests_root).exists()
