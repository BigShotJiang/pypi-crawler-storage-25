import os
import json
import threading
import time
import unittest
from json import JSONDecodeError

from core.context_manager import ContextManager, read_json_file_safe

class TestContextManager(unittest.TestCase):
    def setUp(self):
        self.test_file = "test_progress.json"
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
            
    def tearDown(self):
        if os.path.exists(self.test_file):
            os.remove(self.test_file)

    def test_init_creates_default_state(self):
        cm = ContextManager(self.test_file)
        self.assertEqual(cm.get_state(), "INIT")
        self.assertEqual(cm.context["metadata"], {})
        self.assertEqual(cm.context["artifacts"], {})
        
    def test_save_and_load(self):
        cm = ContextManager(self.test_file)
        cm.set_state("PLANNING")
        cm.update_metadata("req", "test requirement")
        cm.add_artifact("prd", ".harness/runs/run-test/docs/prd.md")
        
        # Load from file again
        cm2 = ContextManager(self.test_file)
        self.assertEqual(cm2.get_state(), "PLANNING")
        self.assertEqual(cm2.context["metadata"]["req"], "test requirement")
        self.assertEqual(cm2.context["artifacts"]["prd"], ".harness/runs/run-test/docs/prd.md")

    def test_clear(self):
        cm = ContextManager(self.test_file)
        cm.set_state("PLANNING")
        cm.clear()
        self.assertEqual(cm.get_state(), "INIT")

    def test_read_json_file_safe_returns_none_for_empty_or_invalid(self):
        # Empty file
        with open(self.test_file, "w", encoding="utf-8") as f:
            f.write("")
        self.assertIsNone(read_json_file_safe(self.test_file, retries=1, sleep_sec=0.0))

        # Invalid JSON
        with open(self.test_file, "w", encoding="utf-8") as f:
            f.write("{not-json")
        self.assertIsNone(read_json_file_safe(self.test_file, retries=1, sleep_sec=0.0))

    def test_save_is_atomic_for_concurrent_readers(self):
        cm = ContextManager(self.test_file)
        cm.set_state("PLANNING")

        stop = threading.Event()
        errors: list[Exception] = []

        def writer():
            try:
                for i in range(200):
                    cm.update_metadata("i", i)
                    time.sleep(0.001)
            finally:
                stop.set()

        def reader():
            # Reader uses strict json.load; it should not observe truncated/partial JSON.
            while not stop.is_set():
                try:
                    with open(self.test_file, "r", encoding="utf-8") as f:
                        json.load(f)
                except (FileNotFoundError, JSONDecodeError) as e:
                    errors.append(e)
                time.sleep(0.0005)

        t1 = threading.Thread(target=writer)
        t2 = threading.Thread(target=reader)
        t1.start()
        t2.start()
        t1.join(timeout=5)
        t2.join(timeout=5)

        # After atomic save, JSONDecodeError should never happen.
        self.assertFalse(any(isinstance(e, JSONDecodeError) for e in errors), f"Observed JSON decode errors: {errors}")

    def test_record_acp_session_merges_runtime_metadata(self):
        cm = ContextManager(self.test_file)

        cm.record_acp_session("CODING", {
            "sessionId": "sess_1",
            "supportsSessionList": True,
            "supportsLoadSession": False,
            "sessionInfo": {
                "sessionId": "sess_1",
                "cwd": "/tmp/repo",
                "title": "First title",
            },
        })

        cm.record_acp_session("FIXING", {
            "sessionId": "sess_1",
            "supportsSessionList": True,
            "supportsLoadSession": True,
            "sessionInfo": {
                "sessionId": "sess_1",
                "updatedAt": "2026-04-12T10:00:00Z",
                "_meta": {"messageCount": 3},
            },
        })

        cm2 = ContextManager(self.test_file)
        session = cm2.context["metadata"]["acp_sessions"]["sess_1"]
        self.assertEqual(session["cwd"], "/tmp/repo")
        self.assertEqual(session["title"], "First title")
        self.assertEqual(session["updatedAt"], "2026-04-12T10:00:00Z")
        self.assertEqual(session["_meta"], {"messageCount": 3})
        self.assertEqual(session["lastStage"], "FIXING")
        self.assertEqual(session["supportsSessionList"], True)
        self.assertEqual(session["supportsLoadSession"], True)
        self.assertEqual(cm2.context["metadata"]["last_acp_session_id"], "sess_1")

if __name__ == '__main__':
    unittest.main()
