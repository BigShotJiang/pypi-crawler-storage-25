import json

import pytest

from core.acp_agent import HarnessClientImpl
from core.run_trace import init_trace


@pytest.mark.asyncio
async def test_fs_read_write_emits_trace_events(tmp_path, monkeypatch):
    run_dir = tmp_path / "workspace" / "runs" / "r1"
    init_trace("r1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "PRD_DRAFTING")

    workspace_root = tmp_path / "workspace"
    workspace_root.mkdir(parents=True, exist_ok=True)

    c = HarnessClientImpl([], workspace_root=str(workspace_root))

    target = workspace_root / "docs" / "prd.md"
    target.parent.mkdir(parents=True, exist_ok=True)

    await c.write_text_file("# PRD\n", str(target), session_id="s1")
    await c.read_text_file(str(target), session_id="s1")

    trace_path = run_dir / "trace.ndjson"
    events = [json.loads(l) for l in trace_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    fs_events = [e for e in events if e.get("type") in {"acp_fs_write", "acp_fs_read"}]
    assert [e["type"] for e in fs_events] == ["acp_fs_write", "acp_fs_read"]
    assert all(e["state"] == "PRD_DRAFTING" for e in fs_events)
    assert fs_events[1]["data"]["line"] is None
    assert fs_events[1]["data"]["limit"] is None
