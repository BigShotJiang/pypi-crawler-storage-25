import json
import os
import shutil
import pytest

from core.context_manager import ContextManager
from core.orchestrator import FlowState
from agents.trae_tech_spec_agent import trae_tech_spec_agent
from tests.runtime_fixtures import build_runtime_ctx


class _StubAgent:
    def __init__(self, root: str, error: str | None = None, *, write_stage_output: bool = True):
        self.root = root
        self.error = error
        self.write_stage_output = write_stage_output
        self.prompt_text = None
        self.cwd = None

    def run_task(self, prompt_text: str, cwd: str, stage: str | None = None):
        self.prompt_text = prompt_text
        self.cwd = cwd
        if self.error:
            return {"updates": [], "final_response": None, "error": self.error}
        marker = next((line for line in prompt_text.splitlines() if "HARNESS_REQUIREMENT:" in line), "")
        tech_spec_path = os.path.join(self.root, ".harness", "runs", "run-test", "docs", "tech_spec.md")
        os.makedirs(os.path.dirname(tech_spec_path), exist_ok=True)
        with open(tech_spec_path, "w", encoding="utf-8") as f:
            f.write(f"## Tech Spec\n\n{marker}\n\n## 变更清单 (Manifest)\n- `src/main.py`\n")
        if self.write_stage_output:
            stage_output_path = os.path.join(self.root, ".harness", "runs", "run-test", "stage_outputs", "TECH_SPEC_DRAFTING.json")
            os.makedirs(os.path.dirname(stage_output_path), exist_ok=True)
            with open(stage_output_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "schema_version": 1,
                        "stage": "TECH_SPEC_DRAFTING",
                        "status": "completed",
                        "summary": "技术方案已生成。",
                        "artifacts": [
                            {
                                "artifact_type": "tech_spec",
                                "path": ".harness/runs/run-test/docs/tech_spec.md",
                                "absolute_path": tech_spec_path,
                                "exists": True,
                                "is_dir": False,
                                "size_bytes": os.path.getsize(tech_spec_path),
                                "summary": "当前阶段生成的技术方案文档。",
                            }
                        ],
                        "key_points": ["artifact_path=.harness/runs/run-test/docs/tech_spec.md"],
                        "evidence": ["file_exists=True"],
                        "metadata": {"artifact_key": "tech_spec"},
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
        return {"updates": [], "final_response": {"stop_reason": "end_turn"}, "error": None}


class _StubAgentEscapedMarker(_StubAgent):
    def run_task(self, prompt_text: str, cwd: str, stage: str | None = None):
        import html

        self.prompt_text = prompt_text
        self.cwd = cwd
        marker = next((line for line in prompt_text.splitlines() if "HARNESS_REQUIREMENT:" in line), "")
        marker = html.escape(marker)
        tech_spec_path = os.path.join(self.root, ".harness", "runs", "run-test", "docs", "tech_spec.md")
        os.makedirs(os.path.dirname(tech_spec_path), exist_ok=True)
        with open(tech_spec_path, "w", encoding="utf-8") as f:
            f.write(f"## Tech Spec\n\n{marker}\n\n## 变更清单 (Manifest)\n- `src/main.py`\n")
        if self.write_stage_output:
            stage_output_path = os.path.join(self.root, ".harness", "runs", "run-test", "stage_outputs", "TECH_SPEC_DRAFTING.json")
            os.makedirs(os.path.dirname(stage_output_path), exist_ok=True)
            with open(stage_output_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "schema_version": 1,
                        "stage": "TECH_SPEC_DRAFTING",
                        "status": "completed",
                        "summary": "技术方案已生成。",
                        "artifacts": [
                            {
                                "artifact_type": "tech_spec",
                                "path": ".harness/runs/run-test/docs/tech_spec.md",
                                "absolute_path": tech_spec_path,
                                "exists": True,
                                "is_dir": False,
                                "size_bytes": os.path.getsize(tech_spec_path),
                                "summary": "当前阶段生成的技术方案文档。",
                            }
                        ],
                        "key_points": ["artifact_path=.harness/runs/run-test/docs/tech_spec.md"],
                        "evidence": ["file_exists=True"],
                        "metadata": {"artifact_key": "tech_spec"},
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
        return {"updates": [], "final_response": {"stop_reason": "end_turn"}, "error": None}


def _build_ctx(tmp_path, requirement: str):
    ctx, _ = build_runtime_ctx(tmp_path, requirement=requirement)
    return ctx


def test_tech_spec_stage_requires_prd(tmp_path):
    ctx = _build_ctx(tmp_path, "需求")
    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_tech_spec_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["last_error_log"] == "PRD file missing."


def test_tech_spec_stage_writes_artifact_and_returns_next_state(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")

    target = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    stub = _StubAgent(str(tmp_path))
    monkeypatch.setattr("agents.trae_tech_spec_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_tech_spec_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.CODING
    assert ctx.context["artifacts"]["tech_spec"] == ".harness/runs/run-test/docs/tech_spec.md"
    assert target.exists()
    content = target.read_text(encoding="utf-8")
    assert "## 变更清单 (Manifest)" in content
    assert "<!-- HARNESS_REQUIREMENT:需求 -->" in content
    assert "需求" in stub.prompt_text
    assert str(target) in stub.prompt_text
    stage_output_file = tmp_path / ".harness" / "runs" / "run-test" / "stage_outputs" / "TECH_SPEC_DRAFTING.json"
    assert stage_output_file.exists()

def test_tech_spec_stage_accepts_html_escaped_requirement_marker(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")

    target = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    stub = _StubAgentEscapedMarker(str(tmp_path))
    monkeypatch.setattr("agents.trae_tech_spec_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_tech_spec_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.CODING
    assert target.exists()
    content = target.read_text(encoding="utf-8")
    assert "&lt;!-- HARNESS_REQUIREMENT:需求 --&gt;" in content


def test_tech_spec_stage_records_error_when_agent_fails(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")

    target = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    stub = _StubAgent(str(tmp_path), error="permission denied")
    monkeypatch.setattr("agents.trae_tech_spec_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_tech_spec_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["last_error_log"] == "AcpAgent run_task returned error: permission denied"
    assert not target.exists()


def test_tech_spec_stage_succeeds_even_when_model_does_not_write_stage_output_json(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "需求")
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")

    stub = _StubAgent(str(tmp_path), write_stage_output=False)
    monkeypatch.setattr("agents.trae_tech_spec_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_tech_spec_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.CODING
    assert ctx.context["artifacts"]["tech_spec"] == ".harness/runs/run-test/docs/tech_spec.md"
    assert "last_noncompliance" not in ctx.context["metadata"]


@pytest.mark.skipif(shutil.which("coco") is None, reason="coco binary not found in PATH")
def test_tech_spec_stage_generates_tech_spec_via_real_coco(tmp_path):
    ctx = _build_ctx(tmp_path, "请为一个在线课程平台生成PRD与TechSpec")
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_tech_spec_agent(ctx)
    finally:
        os.chdir(cwd)

    target = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    assert next_state == FlowState.CODING
    assert ctx.context["artifacts"]["tech_spec"] == ".harness/runs/run-test/docs/tech_spec.md"
    assert target.exists()
    content = target.read_text(encoding="utf-8").strip()
    assert content != ""
    assert "## 变更清单 (Manifest)" in content
    assert "<!-- HARNESS_REQUIREMENT:请为一个在线课程平台生成PRD与TechSpec -->" in content
