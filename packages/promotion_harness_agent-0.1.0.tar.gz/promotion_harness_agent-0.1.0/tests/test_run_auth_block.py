import json
from pathlib import Path

from agents.trae_deploying_agent import trae_deploying_agent
from agents.trae_regression_testing_agent import trae_regression_testing_agent
from core.orchestrator import FlowState
from run import setup_orchestrator
from tests.runtime_fixtures import build_runtime_ctx, seed_active_run



def test_deploying_agent_blocks_on_auth_signal(tmp_path, monkeypatch):
    ctx, _ = build_runtime_ctx(tmp_path, run_id="test-run", state=FlowState.DEPLOYING.value)
    ctx.update_metadata("run_dir", ".harness/runs/test-run")
    monkeypatch.setattr(
        "agents.trae_deploying_agent.AcpAgent.run_task",
        lambda *_args, **_kwargs: {"updates": [], "final_response": {"stop_reason": "end_turn"}, "error": None},
    )
    monkeypatch.setattr(
        "agents.trae_deploying_agent.load_auth_block",
        lambda _path: {
            "type": "auth_required",
            "stage": FlowState.DEPLOYING.value,
            "tool": "bits-env",
            "auth_url": "https://example.com/deploy-auth",
            "message": "authorization required",
            "cli_help": "bits-env login",
        },
    )

    next_state = trae_deploying_agent(ctx)

    assert next_state == FlowState.AUTH_BLOCKED
    meta = ctx.context["metadata"]
    assert meta["run_outcome"] == "auth_blocked"
    assert meta["auth_block_stage"] == FlowState.DEPLOYING.value
    assert meta["auth_block"]["type"] == "auth_required"
    assert meta["last_error_log"].startswith("BLOCKED_AUTH")



def test_setup_orchestrator_registers_real_deploy_and_regression_handlers(tmp_path):
    orch = setup_orchestrator(False, "需求", repo_root=str(tmp_path), run_id="run-test")

    assert orch.handlers[FlowState.DEPLOYING.value] is trae_deploying_agent
    assert orch.handlers[FlowState.REGRESSION_TESTING.value] is trae_regression_testing_agent
    assert orch.ctx.context["metadata"]["stage_timeouts_sec"][FlowState.DEPLOYING.value] == 1200
    assert orch.ctx.context["metadata"]["stage_timeouts_sec"][FlowState.REGRESSION_TESTING.value] == 1200



def test_setup_orchestrator_resume_from_auth_blocked_verifying_clears_stale_file(tmp_path):
    paths = seed_active_run(
        tmp_path,
        run_id="test-run",
        state=FlowState.AUTH_BLOCKED.value,
        metadata={
            "auth_block_stage": FlowState.VERIFYING.value,
            "quality_loop_phase": "verify",
            "quality_loop": {
                "phase": "verify",
                "retry_count": 1,
                "max_retries": 5,
                "history": [],
            },
        },
    )
    auth_path = Path(paths.run_root) / "auth_block.json"
    auth_path.write_text(
        json.dumps(
            {
                "type": "auth_required",
                "stage": FlowState.VERIFYING.value,
                "tool": "bits-env",
                "auth_url": "https://example.com/auth",
                "message": "authorization required",
                "cli_help": "bits-env login",
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    orch = setup_orchestrator(True, "", repo_root=str(tmp_path))

    assert orch.ctx.get_state() == FlowState.QUALITY_LOOP.value
    assert orch.ctx.context["metadata"]["quality_loop_phase"] == "verify"
    assert not auth_path.exists()
