from acp.schema import FileEditToolCallContent, ToolCall, ToolCallLocation

from core.sandbox_policy import extract_paths_from_tool_call, is_tool_call_allowed_in_workspace, sanitize_terminal_env, validate_terminal_request


class _Obj:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


def test_sandbox_denies_read_outside_workspace_when_path_known():
    tool_call = ToolCall(kind="read", title="Read /tmp/foo.txt", tool_call_id="1", raw_input={"path": "/tmp/foo.txt"})
    assert not is_tool_call_allowed_in_workspace(tool_call, "/repo")


def test_sandbox_allows_read_inside_workspace_when_path_known():
    tool_call = ToolCall(kind="read", title="Read notes", tool_call_id="1", raw_input={"path": "/repo/.harness/runs/run-1/docs/notes.txt"})
    assert is_tool_call_allowed_in_workspace(tool_call, "/repo")


def test_sandbox_allows_edit_inside_workspace():
    tool_call = ToolCall(
        kind="edit",
        title="apply_patch",
        tool_call_id="1",
        content=[FileEditToolCallContent(path="/repo/src/a.py", new_text="x=1\n", old_text="", type="diff")],
    )
    assert is_tool_call_allowed_in_workspace(tool_call, "/repo")


def test_sandbox_denies_edit_outside_workspace():
    tool_call = ToolCall(
        kind="edit",
        title="apply_patch",
        tool_call_id="1",
        content=[FileEditToolCallContent(path="/repo/README.md", new_text="x", old_text="", type="diff")],
    )
    assert not is_tool_call_allowed_in_workspace(tool_call, "/repo/src")


def test_sandbox_denies_unknown_write_without_paths():
    tool_call = ToolCall(kind="edit", title="apply_patch", tool_call_id="1")
    assert not is_tool_call_allowed_in_workspace(tool_call, "/repo")


def test_sandbox_uses_locations_when_present():
    tool_call = ToolCall(
        kind="edit",
        title="Edit",
        tool_call_id="1",
        locations=[ToolCallLocation(path="/repo/tests/test_a.py", line=1)],
    )
    assert is_tool_call_allowed_in_workspace(tool_call, "/repo")


def test_extract_paths_from_file_resource_content():
    tool_call = _Obj(
        content=[
            _Obj(
                type="content",
                content=_Obj(type="resource_link", uri="file:///repo/tests/test_a.py", name="test_a.py"),
            )
        ]
    )
    assert extract_paths_from_tool_call(tool_call) == ["/repo/tests/test_a.py"]


def test_extract_paths_from_raw_input_path():
    tool_call = ToolCall(kind="read", title="Read file", tool_call_id="1", raw_input={"path": "/repo/.harness/runs/run-1/docs/prd.md"})
    assert extract_paths_from_tool_call(tool_call) == ["/repo/.harness/runs/run-1/docs/prd.md"]


def test_validate_terminal_request_allows_workspace_command():
    allowed, reason, cwd, env = validate_terminal_request(
        command="python3",
        args=["-c", "print('ok')"],
        cwd="/repo",
        env=[{"name": "PATH", "value": "/bin"}],
        workspace_root="/repo",
    )
    assert allowed is True
    assert reason == "allowed"
    assert cwd == "/repo"
    assert env == {"PATH": "/bin"}


def test_validate_terminal_request_denies_outside_workspace():
    allowed, reason, cwd, env = validate_terminal_request(
        command="python3",
        args=["-c", "print('ok')"],
        cwd="/tmp",
        env=None,
        workspace_root="/repo",
    )
    assert allowed is False
    assert reason == "outside_workspace"
    assert cwd.endswith("/tmp")
    assert env == {}


def test_sanitize_terminal_env_drops_blocked_names():
    env = sanitize_terminal_env([
        {"name": "PATH", "value": "/bin"},
        {"name": "LD_PRELOAD", "value": "hack.so"},
        {"name": "HARNESS_STAGE", "value": "CODING"},
    ])
    assert env == {"PATH": "/bin", "HARNESS_STAGE": "CODING"}
