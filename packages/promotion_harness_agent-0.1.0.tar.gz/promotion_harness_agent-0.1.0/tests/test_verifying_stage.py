import json
import os

from core.orchestrator import FlowState
from agents.trae_verifying_agent import trae_verifying_agent
from tests.runtime_fixtures import build_runtime_ctx


def _build_ctx(tmp_path):
    ctx, _ = build_runtime_ctx(tmp_path, run_id="test-run")
    return ctx


def _seed_coding_stage_result(tmp_path, ctx):
    src = tmp_path / "src"
    tests = tmp_path / "tests"
    src.mkdir(parents=True, exist_ok=True)
    tests.mkdir(parents=True, exist_ok=True)
    (src / "app.py").write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
    (tests / "test_app.py").write_text("def test_add():\n    assert 1 + 1 == 2\n", encoding="utf-8")
    ctx.add_artifact("code_root", "src")
    ctx.add_artifact("tests_root", "tests")
    ctx.record_stage_result(
        FlowState.CODING.value,
        {
            "schema_version": 1,
            "stage": FlowState.CODING.value,
            "status": "pass",
            "summary": "coding done",
            "artifacts": [
                {
                    "artifact_type": "code_root",
                    "path": "src",
                    "absolute_path": str(src),
                    "exists": True,
                    "is_dir": True,
                    "size_bytes": 0,
                    "summary": "src dir",
                },
                {
                    "artifact_type": "tests_root",
                    "path": "tests",
                    "absolute_path": str(tests),
                    "exists": True,
                    "is_dir": True,
                    "size_bytes": 0,
                    "summary": "tests dir",
                },
            ],
            "key_points": ["artifact_count=2"],
            "evidence": ["repo root ready"],
            "metadata": {
                "artifact_key": "code_root",
                "changed_files": ["src/app.py", "tests/test_app.py"],
                "branch_name": "feature/test-run",
                "commit_sha": "abc123",
                "mr_url": "https://example.com/mr/1",
            },
        },
    )


def test_verifying_stage_passes_and_clears_error(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("last_error_log", "old error")
    ctx.update_quality_loop(phase="verify", retry_count=3, max_retries=5, history=[])
    ctx.update_metadata("run_dir", ".harness/runs/test-run")
    _seed_coding_stage_result(tmp_path, ctx)
    monkeypatch.setattr(
        "agents.trae_verifying_agent.run_stage_acceptance_verifier",
        lambda *_args, **_kwargs: {"outcome": "pass", "reason": "acceptance_pass", "acceptance_result": {"summary": "ok"}},
    )

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.DEPLOYING
    assert ctx.context["metadata"]["last_error_log"] == ""
    assert ctx.context["metadata"]["quality_loop"]["retry_count"] == 0
    report = tmp_path / ".harness" / "runs" / "test-run" / "outputs" / "quality_report.json"
    assert report.exists()
    payload = json.loads(report.read_text(encoding="utf-8"))
    assert payload["hard_validation_verdict"] == "pass"
    assert payload["verification_recommendations"]
    stage_output_file = tmp_path / ".harness" / "runs" / "test-run" / "stage_outputs" / "QUALITY_LOOP.json"
    assert stage_output_file.exists()
    stage_output = json.loads(stage_output_file.read_text(encoding="utf-8"))
    assert stage_output["metadata"]["hard_validation_verdict"] == "pass"
    assert stage_output["artifacts"][0]["artifact_type"] == "quality_report"


def test_verifying_stage_fails_and_enters_fixing_when_stage_result_missing(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("run_dir", ".harness/runs/test-run")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FIXING
    assert "missing_stage_result:CODING" in ctx.context["metadata"]["last_error_log"]
    assert ctx.context["metadata"]["quality_loop"]["retry_count"] == 1
    stage_output_file = tmp_path / ".harness" / "runs" / "test-run" / "stage_outputs" / "QUALITY_LOOP.json"
    assert stage_output_file.exists()
    stage_output = json.loads(stage_output_file.read_text(encoding="utf-8"))
    assert stage_output["metadata"]["hard_validation_verdict"] == "fail"


def test_verifying_stage_aborts_after_max_retries(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("run_dir", ".harness/runs/test-run")
    ctx.update_quality_loop(phase="verify", retry_count=5, max_retries=5, history=[])

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert "max_quality_loop_retries" in ctx.context["metadata"]["last_error_log"]
    assert ctx.context["metadata"]["quality_loop"]["retry_count"] == 6


def test_verifying_stage_acceptance_fail_uses_quality_loop_not_stage_retry(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("run_dir", ".harness/runs/test-run")
    ctx.update_metadata("max_stage_retries", 0)
    ctx.update_quality_loop(phase="verify", retry_count=0, max_retries=5, history=[])
    _seed_coding_stage_result(tmp_path, ctx)
    monkeypatch.setattr(
        "agents.trae_verifying_agent.run_stage_acceptance_verifier",
        lambda *_args, **_kwargs: {"outcome": "fail", "reason": "acceptance_failed", "acceptance_result": {"summary": "need more evidence"}},
    )

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FIXING
    assert ctx.context["metadata"]["quality_loop"]["retry_count"] == 1



def test_verifying_stage_retries_on_tool_gate_denial_without_running_checks(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("max_stage_retries", 2)
    ctx.update_quality_loop(phase="verify", retry_count=4, max_retries=5, history=[])
    ctx.update_metadata("last_gate_denial", {
        "stage": FlowState.QUALITY_LOOP.value,
        "reason": "tool_not_enabled_for_stage",
        "suggestion": "Use allowed tools only.",
        "details": {
            "tool_id": "bash:shell",
            "resolved_capability": "terminal.bash",
            "enabled_tool_ids": ["fs.read", "fs.write"],
        },
    })

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.QUALITY_LOOP
    assert ctx.context["metadata"]["quality_loop"]["retry_count"] == 4
    last = ctx.context["metadata"]["last_noncompliance"]
    assert last["stage"] == FlowState.VERIFYING.value
    assert last["kind"] == "tool_gate"
    assert last["details"]["tool_id"] == "bash:shell"


def test_verifying_gate_denial_fails_after_stage_retry_limit(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("max_stage_retries", 0)
    ctx.update_quality_loop(phase="verify", retry_count=1, max_retries=99, history=[])
    ctx.update_metadata("last_gate_denial", {
        "stage": FlowState.QUALITY_LOOP.value,
        "reason": "tool_not_enabled_for_stage",
        "details": {
            "tool_id": "bash:shell",
            "resolved_capability": "terminal.bash",
            "enabled_tool_ids": ["fs.read"],
        },
    })

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["quality_loop"]["retry_count"] == 1
    last = ctx.context["metadata"]["last_noncompliance"]
    assert last["stage"] == FlowState.VERIFYING.value


def test_verifying_stage_blocks_on_auth_signal(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path)
    ctx.set_state(FlowState.QUALITY_LOOP.value)
    ctx.update_metadata("run_dir", ".harness/runs/test-run")
    ctx.update_quality_loop(phase="verify", retry_count=2, max_retries=5, history=[])
    _seed_coding_stage_result(tmp_path, ctx)
    monkeypatch.setattr(
        "agents.trae_verifying_agent.run_stage_acceptance_verifier",
        lambda *_args, **_kwargs: {"outcome": "pass", "reason": "acceptance_pass", "acceptance_result": {"summary": "ok"}},
    )
    monkeypatch.setattr(
        "agents.trae_verifying_agent.load_auth_block",
        lambda _path: {
            "type": "auth_required",
            "stage": FlowState.QUALITY_LOOP.value,
            "tool": "bits-env",
            "auth_url": "https://example.com/auth",
            "message": "authorization required",
            "cli_help": "bits-env login",
        },
    )

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.AUTH_BLOCKED
    meta = ctx.context["metadata"]
    assert meta["run_outcome"] == "auth_blocked"
    assert meta["auth_block_stage"] == FlowState.QUALITY_LOOP.value
    assert meta["auth_block"]["type"] == "auth_required"
    assert meta["last_error_log"].startswith("BLOCKED_AUTH")
    assert meta["quality_loop"]["phase"] == "verify"
    assert meta["quality_loop"]["history"][-1]["result"] == "auth_blocked"
