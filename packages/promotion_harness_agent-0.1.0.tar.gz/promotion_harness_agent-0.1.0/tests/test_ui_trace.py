import json

from ui_trace import acp_fs_events_for_stage, acp_terminal_events_for_stage, acp_terminal_sessions_for_stage, build_timeline, read_ndjson


def test_ui_trace_parses_timeline(tmp_path):
    trace = tmp_path / "trace.ndjson"
    events = [
        {"ts": "2026-04-02T12:00:00.000Z", "run_id": "r1", "type": "state_enter", "state": "CODING", "data": {}},
        {"ts": "2026-04-02T12:00:01.000Z", "run_id": "r1", "type": "state_exit", "state": "CODING", "data": {"duration_ms": 1000, "next_state": "QUALITY_LOOP"}},
        {"ts": "2026-04-02T12:00:01.000Z", "run_id": "r1", "type": "state_enter", "state": "QUALITY_LOOP", "data": {}},
        {"ts": "2026-04-02T12:00:02.500Z", "run_id": "r1", "type": "state_exit", "state": "QUALITY_LOOP", "data": {"duration_ms": 1500, "next_state": "DEPLOYING"}},
    ]
    trace.write_text("\n".join(json.dumps(e) for e in events) + "\n", encoding="utf-8")

    parsed = read_ndjson(str(trace))
    timeline = build_timeline(parsed)
    assert [t.state for t in timeline] == ["CODING", "QUALITY_LOOP"]
    assert timeline[0].duration_ms == 1000
    assert timeline[1].duration_ms == 1500


def test_ui_trace_groups_terminal_sessions():
    events = [
        {"type": "acp_terminal_create", "state": "CODING", "ts": "t1", "data": {"terminal_id": "term_1", "command": "python3", "args": ["-c", "print('ok')"], "cwd": "/repo/workspace", "result": "ok"}},
        {"type": "acp_terminal_output", "state": "CODING", "ts": "t2", "data": {"terminal_id": "term_1", "output": "ok\n", "truncated": False, "completed": True}},
        {"type": "acp_terminal_wait", "state": "CODING", "ts": "t3", "data": {"terminal_id": "term_1", "exit_code": 0}},
    ]
    grouped = acp_terminal_sessions_for_stage(events, "CODING")
    assert len(grouped) == 1
    assert grouped[0]["terminal_id"] == "term_1"
    assert grouped[0]["command"] == "python3"
    assert grouped[0]["exit_code"] == 0
    assert len(grouped[0]["updates"]) == 3


def test_ui_trace_filters_terminal_events_by_stage():
    events = [
        {"type": "acp_terminal_create", "state": "CODING", "ts": "t1", "data": {"terminal_id": "term_1"}},
        {"type": "acp_terminal_release", "state": "FIXING", "ts": "t2", "data": {"terminal_id": "term_2"}},
    ]
    coding = acp_terminal_events_for_stage(events, "CODING")
    fixing = acp_terminal_events_for_stage(events, "FIXING")
    assert coding == [{"type": "acp_terminal_create", "ts": "t1", "terminal_id": "term_1"}]
    assert fixing == [{"type": "acp_terminal_release", "ts": "t2", "terminal_id": "term_2"}]


def test_ui_trace_exposes_fs_window_fields():
    events = [
        {"type": "acp_fs_read", "state": "CODING", "ts": "t1", "data": {"path": "/repo/src/a.py", "bytes": 12, "result": "ok", "line": 10, "limit": 50}},
        {"type": "acp_fs_write", "state": "FIXING", "ts": "t2", "data": {"path": "/repo/tests/b.py", "bytes": 3, "result": "ok"}},
    ]

    coding = acp_fs_events_for_stage(events, "CODING")

    assert coding == [{"type": "acp_fs_read", "ts": "t1", "path": "/repo/src/a.py", "bytes": 12, "line": 10, "limit": 50, "result": "ok", "reason": None, "error": None}]
