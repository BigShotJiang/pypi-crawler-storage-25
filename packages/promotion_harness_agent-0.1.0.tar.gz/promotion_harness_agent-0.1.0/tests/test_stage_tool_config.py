import os
import json

from core.stage_tool_config import BASH_TOOL_ID, infer_tool_id_from_policy_context, load_stage_tool_config, save_stage_tool_config


def test_stage_tool_config_user_overrides_repo(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    repo_root = str(tmp_path / "repo")
    os.makedirs(os.path.join(repo_root, ".harness"), exist_ok=True)
    os.makedirs(os.path.join(tmp_path, ".harness"), exist_ok=True)

    with open(os.path.join(repo_root, ".harness", "stage_tools.json"), "w", encoding="utf-8") as f:
        json.dump({"schema_version": 1, "stages": {"CODING": ["cli:echo"]}}, f)

    with open(os.path.join(tmp_path, ".harness", "stage_tools.json"), "w", encoding="utf-8") as f:
        json.dump({"schema_version": 1, "stages": {"CODING": ["cli:bytedcli"]}}, f)

    cfg = load_stage_tool_config(repo_root)
    assert cfg.stages["CODING"] == ["cli:bytedcli"]


def test_save_stage_tool_config_user_writes_file(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    repo_root = str(tmp_path / "repo")
    os.makedirs(repo_root, exist_ok=True)

    path = save_stage_tool_config(repo_root, {"QUALITY_LOOP": ["cli:echo"]}, scope="user")
    assert path.endswith(os.path.join(".harness", "stage_tools.json"))
    assert os.path.exists(path)


def test_infer_tool_id_for_direct_cli():
    tool_id = infer_tool_id_from_policy_context(
        normalized_kind="execute",
        resolved_capability="terminal.cli",
        policy_context={"binary": "lark-cli"},
    )
    assert tool_id == "cli:lark-cli"


def test_infer_tool_id_for_shell_returns_bash_family():
    tool_id = infer_tool_id_from_policy_context(
        normalized_kind="execute",
        resolved_capability="terminal.bash",
        policy_context={"binary": "bash", "uses_shell": True},
    )
    assert tool_id == BASH_TOOL_ID


def test_infer_tool_id_for_repo_python_script_uses_python_entry():
    tool_id = infer_tool_id_from_policy_context(
        normalized_kind="execute",
        resolved_capability="tool.py_script",
        policy_context={"python_entry": "tools.test_feedback", "args": ["-m", "tools.test_feedback"]},
    )
    assert tool_id == "script:tools.test_feedback"


def test_infer_tool_id_for_skill_uses_structured_skill_name():
    tool_id = infer_tool_id_from_policy_context(
        normalized_kind="skill",
        resolved_capability="tool.skill",
        policy_context={"skill_name": "lark-doc"},
        title="skill",
    )
    assert tool_id == "skill:lark-doc"



def test_infer_tool_id_for_generic_skill_title_returns_none():
    tool_id = infer_tool_id_from_policy_context(
        normalized_kind="skill",
        resolved_capability="tool.skill",
        policy_context={},
        title="skill",
    )
    assert tool_id is None
