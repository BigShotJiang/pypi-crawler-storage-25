import os

from ui_artifacts import load_artifact_preview


def test_load_artifact_preview_file(tmp_path):
    p = tmp_path / "a.md"
    p.write_text("hello", encoding="utf-8")
    out = load_artifact_preview(str(p))
    assert out["type"] == "file"
    assert out["ext"] == ".md"
    assert out["content"] == "hello"


def test_load_artifact_preview_dir(tmp_path):
    d = tmp_path / "workspace" / "src"
    d.mkdir(parents=True)
    (d / "main.py").write_text("x=1\n", encoding="utf-8")
    out = load_artifact_preview(str(d))
    assert out["type"] == "dir"
    assert any(e.endswith("main.py") for e in out["entries"])


def test_load_artifact_preview_missing(tmp_path):
    out = load_artifact_preview(str(tmp_path / "nope.txt"))
    assert out["type"] == "missing"
