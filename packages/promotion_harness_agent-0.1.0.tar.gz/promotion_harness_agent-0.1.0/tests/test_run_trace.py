import json
import os

from core.run_trace import append_event, clear_trace, generate_run_id, init_trace


def test_trace_writer_appends_ndjson(tmp_path):
    run_id = generate_run_id()
    run_dir = tmp_path / "workspace" / "runs" / run_id
    init_trace(run_id=run_id, run_dir=str(run_dir))

    append_event("run_start", state="PLANNING", data={"x": 1})
    append_event("state_enter", state="CODING", data={})

    trace_path = run_dir / "trace.ndjson"
    assert trace_path.exists()
    lines = trace_path.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 2
    first = json.loads(lines[0])
    assert first["run_id"] == run_id
    assert first["type"] == "run_start"
    assert first["state"] == "PLANNING"
    clear_trace()


def test_trace_writer_is_noop_without_init(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    clear_trace()
    append_event("x", state="S", data={})
    assert not os.path.exists(tmp_path / "trace.ndjson")
