import json

import pytest

from core.stage_acceptance_policy import (
    StageAcceptancePolicyValidationError,
    build_default_repo_stage_acceptance_policy_payload,
    ensure_user_stage_acceptance_policy_seeded,
    get_stage_acceptance_entry,
    list_available_acceptance_policy_tools,
    load_stage_acceptance_policy,
    reset_stage_acceptance_policy,
    reset_stage_acceptance_policy_to_defaults,
    save_stage_acceptance_policy,
    validate_stage_acceptance_rules,
)


@pytest.fixture()
def acceptance_repo(tmp_path):
    repo = tmp_path / 'repo'
    (repo / '.harness').mkdir(parents=True, exist_ok=True)
    (repo / '.harness' / 'cli_tools.json').write_text(
        json.dumps(
            [
                {
                    'name': 'lark-cli',
                    'command': 'echo',
                    'summary': 'Read docs',
                    'risk_level': 'low',
                },
                {
                    'name': 'bytedcli',
                    'command': 'echo',
                    'summary': 'Repo workflow CLI',
                    'risk_level': 'medium',
                },
            ],
            indent=2,
        ),
        encoding='utf-8',
    )
    (repo / '.harness' / 'stage_acceptance_policy.json').write_text(
        json.dumps(
            {
                'schema_version': 1,
                'policies': {
                    'PRD_DRAFTING': {
                        'enabled': True,
                        'prompt': '请判断当前 PRD 是否可以准出。重点检查：是否围绕当前原始需求展开、是否形成完整 PRD、是否保留 requirement marker、若引用了外部来源是否标出来源与风险。如果不满足，请明确列出缺失项。',
                        'model': '',
                        'rules': [],
                    },
                    'TECH_SPEC_DRAFTING': {
                        'enabled': True,
                        'prompt': '请判断当前 Tech Spec 是否可以准出。重点检查：是否围绕当前原始需求与 PRD 展开、是否形成完整技术方案、是否保留 requirement marker、是否包含 Manifest/变更清单、是否给出后续编码所需的关键实现信息。如果不满足，请明确列出缺失项。',
                        'model': '',
                        'rules': [],
                    },
                    'CODING': {
                        'enabled': True,
                        'prompt': '请判断当前 Coding 阶段是否可以准出。不要跳过第一层本地产物校验；先基于标准化 Stage Output 和本地产物确认：代码改动已形成可消费交付，且输出中包含 changed_files、branch_name、commit_sha、mr_url 等关键信息。然后再执行 Harness Agent 二层判断：1）对照 MR 或本地 commit 与 tech spec / requirement，判断产物是否符合要求；2）若提供了 MR 链接，验证是否能够通过 MR 链接读取对应 commit 提交记录。若远端能力、鉴权、链接可达性或提交信息读取失败，请明确记录缺失项与失败原因，不要假设验证成功。',
                        'model': '',
                        'rules': [
                            {
                                'use_tool_id': 'cli:bytedcli',
                                'do': '优先读取本地仓库状态、分支、commit 信息，以及与当前编码产物相关的研发工作流上下文。',
                                'verify': '对照 MR 或本地 commit 与 tech spec / requirement，确认当前代码改动是否符合要求；同时核对 changed_files、branch_name、commit_sha 等关键输出字段是否真实存在且可对应到本地产物。',
                            },
                            {
                                'use_tool_id': 'cli:bytedcli',
                                'do': '若当前产出提供了 mr_url，优先通过 MR 链接读取对应 MR 与提交记录；若无法直接读取，再继续使用同类仓库工作流能力核对远端提交信息。',
                                'verify': '确认是否能够通过 mr_url 读取对应 commit 提交记录；若远端能力、鉴权、链接可达性或提交记录读取失败，必须明确记录失败原因，不要假设验证成功。',
                            },
                        ],
                    },
                    'QUALITY_LOOP': {
                        'enabled': True,
                        'prompt': '请判断当前 Quality Loop 是否可以准出。重点检查：上一阶段交付产物是否完整、本地结构校验结论是否清晰、是否保留必要证据、是否足以支持后续部署决策。不要绕过第一层本地结构校验，只评估用户配置的二层准出要求。如果不满足，请明确列出缺失项。',
                        'model': '',
                        'rules': [
                            {
                                'use_tool_id': 'skill:codebase-cli',
                                'do': '若当前产出提供了 mr_url，优先通过 MR 链接读取对应 MR、commit 提交记录以及可见的测试信息；若无法直接读取，再继续使用同类仓库工作流能力核对远端信息。',
                                'verify': '确认是否能够通过 mr_url 读取对应 commit 提交记录；若远端能力、鉴权、链接可达性或提交记录读取失败，必须明确记录失败原因，不要假设验证成功。',
                            },
                            {
                                'use_tool_id': 'skill:remote-ci-ut',
                                'do': '优先读取 MR 关联单测覆盖率或等价覆盖证据；若没有直接能力，则读取可见的测试报告、流水线结果或质量报告。',
                                'verify': '确认 MR 的单测覆盖率或等价覆盖证据是否可读、结论是否明确；若无法读取覆盖率、缺少覆盖证据或鉴权失败，必须明确记录缺失项与失败原因。',
                            },
                            {
                                'use_tool_id': 'skill:remote-ci-ut',
                                'do': '优先读取 MR 关联单测执行状态、执行结果与失败详情；若没有直接能力，则读取可见的流水线状态、测试报告或质量报告。',
                                'verify': '确认 MR 的单测执行情况是否可读，明确通过、失败、进行中或未知；若执行状态不可读、远端查询失败或缺少结果，必须明确记录，不要假设成功。',
                            },
                        ],
                    },
                },
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding='utf-8',
    )
    skill_root = repo / '.trae' / 'skills'
    for skill_name in ['bam', 'bits-unit-test-gen', 'remote-ci-ut', 'codebase-cli']:
        skill_dir = skill_root / skill_name
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / 'SKILL.md').write_text(
            f"---\nname: {skill_name}\ndescription: {skill_name} skill\n---\n",
            encoding='utf-8',
        )
    return repo


def test_stage_acceptance_policy_seed_and_reset_coding_default(tmp_path, monkeypatch, acceptance_repo):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))
    repo_root = str(acceptance_repo)

    path, seeded = ensure_user_stage_acceptance_policy_seeded(repo_root, stage='CODING')
    assert seeded is True
    assert path.endswith('stage_acceptance_policy.json')

    loaded = load_stage_acceptance_policy(repo_root)
    coding = get_stage_acceptance_entry(loaded, 'CODING')
    assert coding.enabled is True
    assert '不要跳过第一层本地产物校验' in coding.prompt
    assert 'mr_url' in coding.prompt
    assert len(coding.rules) == 2
    assert coding.rules[0]['use_tool_id'] == 'cli:bytedcli'
    assert coding.max_retries == 2
    assert '对照 MR 或本地 commit 与 tech spec / requirement' in coding.rules[0]['verify']
    assert '通过 mr_url 读取对应 commit 提交记录' in coding.rules[1]['verify']

    save_stage_acceptance_policy(
        repo_root,
        'CODING',
        {
            'enabled': True,
            'prompt': '自定义 CODING 准出规则，并返回 JSON。',
            'model': 'claude-opus-4-7',
            'max_retries': 5,
            'rules': [
                {
                    'use_tool_id': 'cli:bytedcli',
                    'do': '读取代码变更与仓库状态。',
                    'verify': '核对 changed_files、commit_sha 和 mr_url。',
                }
            ],
        },
    )
    customized = load_stage_acceptance_policy(repo_root)
    customized_entry = get_stage_acceptance_entry(customized, 'CODING')
    assert customized_entry.prompt == '自定义 CODING 准出规则，并返回 JSON。'
    assert customized_entry.max_retries == 5
    assert customized_entry.rules[0]['use_tool_id'] == 'cli:bytedcli'
    assert customized_entry.rules[0]['verify'] == '核对 changed_files、commit_sha 和 mr_url。'

    reset = reset_stage_acceptance_policy_to_defaults(repo_root, stage='CODING')
    reset_entry = get_stage_acceptance_entry(reset, 'CODING')
    assert '不要跳过第一层本地产物校验' in reset_entry.prompt
    assert reset_entry.model == ''
    assert reset_entry.max_retries == 2
    assert len(reset_entry.rules) == 2
    assert reset_entry.rules[0]['use_tool_id'] == 'cli:bytedcli'


def test_stage_acceptance_policy_seed_and_reset_quality_loop_default(tmp_path, monkeypatch, acceptance_repo):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))
    repo_root = str(acceptance_repo)

    path, seeded = ensure_user_stage_acceptance_policy_seeded(repo_root, stage='QUALITY_LOOP')
    assert seeded is True
    assert path.endswith('stage_acceptance_policy.json')

    loaded = load_stage_acceptance_policy(repo_root)
    quality_loop = get_stage_acceptance_entry(loaded, 'QUALITY_LOOP')
    assert quality_loop.enabled is True
    assert quality_loop.max_retries == 2
    assert '不要绕过第一层本地结构校验' in quality_loop.prompt
    assert len(quality_loop.rules) == 3
    assert quality_loop.rules[0]['use_tool_id'] == 'skill:codebase-cli'
    assert '通过 mr_url 读取对应 commit 提交记录' in quality_loop.rules[0]['verify']
    assert quality_loop.rules[1]['use_tool_id'] == 'skill:remote-ci-ut'
    assert '单测覆盖率或等价覆盖证据' in quality_loop.rules[1]['verify']
    assert quality_loop.rules[2]['use_tool_id'] == 'skill:remote-ci-ut'
    assert '单测执行情况是否可读' in quality_loop.rules[2]['verify']

    save_stage_acceptance_policy(
        repo_root,
        'QUALITY_LOOP',
        {
            'enabled': True,
            'prompt': '自定义 QUALITY_LOOP 准出规则，并返回 JSON。',
            'model': 'claude-opus-4-7',
            'max_retries': 4,
            'rules': [
                {
                    'use_tool_id': 'cli:bytedcli',
                    'do': '读取 MR 提交记录。',
                    'verify': '确认 MR 能读取到对应 commit。',
                }
            ],
        },
    )
    customized = load_stage_acceptance_policy(repo_root)
    customized_entry = get_stage_acceptance_entry(customized, 'QUALITY_LOOP')
    assert customized_entry.prompt == '自定义 QUALITY_LOOP 准出规则，并返回 JSON。'
    assert customized_entry.max_retries == 4
    assert customized_entry.rules[0]['verify'] == '确认 MR 能读取到对应 commit。'

    reset = reset_stage_acceptance_policy_to_defaults(repo_root, stage='QUALITY_LOOP')
    reset_entry = get_stage_acceptance_entry(reset, 'QUALITY_LOOP')
    assert '不要绕过第一层本地结构校验' in reset_entry.prompt
    assert reset_entry.max_retries == 2
    assert len(reset_entry.rules) == 3
    assert reset_entry.rules[0]['use_tool_id'] == 'skill:codebase-cli'
    assert reset_entry.rules[1]['use_tool_id'] == 'skill:remote-ci-ut'
    assert reset_entry.rules[2]['use_tool_id'] == 'skill:remote-ci-ut'



def test_stage_acceptance_policy_loads_repo_defaults_for_regression(tmp_path, monkeypatch):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))
    repo_root = '/Users/bytedance/Documents/Project/explore/harness/caijing_harness_agent/my_harness_agent'

    loaded = load_stage_acceptance_policy(repo_root)
    regression = get_stage_acceptance_entry(loaded, 'REGRESSION_TESTING')

    assert regression.enabled is True
    assert regression.max_retries == 2
    assert '不要跳过第一层本地产物校验' in regression.prompt
    assert len(regression.rules) == 2
    assert regression.rules[0]['use_tool_id'] == 'skill:bits-env'
    assert 'env_url' in regression.rules[0]['verify']
    assert regression.rules[1]['use_tool_id'] == 'skill:codebase-cli'
    assert 'branch_name' in regression.rules[1]['verify']


def test_build_default_repo_stage_acceptance_policy_payload_contains_supported_stages():
    payload = build_default_repo_stage_acceptance_policy_payload()

    assert payload['schema_version'] == 1
    assert set(payload['policies']) == {
        'PRD_DRAFTING',
        'TECH_SPEC_DRAFTING',
        'CODING',
        'QUALITY_LOOP',
        'DEPLOYING',
        'REGRESSION_TESTING',
    }
    assert payload['policies']['PRD_DRAFTING']['enabled'] is True
    assert '请判断当前 PRD 是否可以准出' in payload['policies']['PRD_DRAFTING']['prompt']
    assert payload['policies']['PRD_DRAFTING']['rules'] == []
    assert payload['policies']['CODING']['enabled'] is True
    assert len(payload['policies']['CODING']['rules']) == 2
    assert payload['policies']['CODING']['rules'][0]['use_tool_id'] == 'cli:bytedcli'
    assert payload['policies']['QUALITY_LOOP']['rules'][0]['use_tool_id'] == 'skill:codebase-cli'


def test_stage_acceptance_policy_reset_non_coding_still_clears_override(tmp_path, monkeypatch, acceptance_repo):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))
    repo_root = str(acceptance_repo)

    save_stage_acceptance_policy(
        repo_root,
        'PRD_DRAFTING',
        {
            'enabled': True,
            'prompt': '自定义 PRD 规则，并返回 JSON。',
            'model': '',
            'rules': [
                {
                    'use_tool_id': 'cli:lark-cli',
                    'do': '读取 PRD 文档。',
                    'verify': '核对是否包含背景与目标。',
                }
            ],
        },
    )

    reset = reset_stage_acceptance_policy(repo_root, 'PRD_DRAFTING')
    prd = get_stage_acceptance_entry(reset, 'PRD_DRAFTING')
    assert prd.prompt != '自定义 PRD 规则，并返回 JSON。'
    assert '请判断当前 PRD 是否可以准出' in prd.prompt
    assert prd.rules == []



def test_stage_acceptance_policy_validation_rejects_invalid_tool(tmp_path, monkeypatch, acceptance_repo):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))

    with pytest.raises(StageAcceptancePolicyValidationError) as exc:
        validate_stage_acceptance_rules(
            str(acceptance_repo),
            'PRD_DRAFTING',
            [{'use_tool_id': 'cli:missing', 'do': 'read', 'verify': 'check'}],
        )

    assert 'is not enabled for stage PRD_DRAFTING' in str(exc.value)



def test_stage_acceptance_policy_validation_rejects_empty_verify(tmp_path, monkeypatch, acceptance_repo):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))

    with pytest.raises(StageAcceptancePolicyValidationError) as exc:
        validate_stage_acceptance_rules(
            str(acceptance_repo),
            'PRD_DRAFTING',
            [{'use_tool_id': 'cli:lark-cli', 'do': 'read', 'verify': '   '}],
        )

    assert 'verify must not be empty' in str(exc.value)



def test_stage_acceptance_policy_validation_rejects_invalid_max_retries(tmp_path, monkeypatch, acceptance_repo):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))

    with pytest.raises(StageAcceptancePolicyValidationError) as exc:
        save_stage_acceptance_policy(
            str(acceptance_repo),
            'PRD_DRAFTING',
            {
                'enabled': True,
                'prompt': '自定义 PRD 规则，并返回 JSON。',
                'model': '',
                'max_retries': -1,
                'rules': [
                    {
                        'use_tool_id': 'cli:lark-cli',
                        'do': '读取 PRD 文档。',
                        'verify': '核对是否包含背景与目标。',
                    }
                ],
            },
        )

    assert 'max_retries must be greater than or equal to 0' in str(exc.value)



def test_stage_acceptance_policy_tools_return_only_stage_enabled_entries(tmp_path, monkeypatch, acceptance_repo):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))
    (home / '.harness').mkdir(parents=True, exist_ok=True)
    (home / '.harness' / 'stage_tools.json').write_text(
        json.dumps(
            {
                'schema_version': 1,
                'stages': {
                    'PRD_DRAFTING': ['cli:lark-cli'],
                },
            },
            indent=2,
        ),
        encoding='utf-8',
    )

    entries = list_available_acceptance_policy_tools(str(acceptance_repo), 'PRD_DRAFTING')

    tool_ids = [entry['tool_id'] for entry in entries]
    assert tool_ids == ['cli:lark-cli']


def test_stage_acceptance_policy_validation_rejects_tool_not_enabled_for_stage(tmp_path, monkeypatch, acceptance_repo):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))
    (home / '.harness').mkdir(parents=True, exist_ok=True)
    (home / '.harness' / 'stage_tools.json').write_text(
        json.dumps(
            {
                'schema_version': 1,
                'stages': {
                    'PRD_DRAFTING': ['cli:lark-cli'],
                },
            },
            indent=2,
        ),
        encoding='utf-8',
    )

    with pytest.raises(StageAcceptancePolicyValidationError) as exc:
        validate_stage_acceptance_rules(
            str(acceptance_repo),
            'PRD_DRAFTING',
            [{'use_tool_id': 'cli:bytedcli', 'do': 'read', 'verify': 'check'}],
        )

    assert 'cli:bytedcli is not enabled for stage PRD_DRAFTING' in str(exc.value)
