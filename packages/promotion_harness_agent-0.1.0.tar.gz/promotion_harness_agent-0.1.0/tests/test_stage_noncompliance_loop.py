import json
import os

import pytest

from core.context_manager import ContextManager, resolve_stage_max_retries
from core.acp_agent import HarnessClientImpl
from agents.trae_coding_agent import trae_coding_agent
from agents.trae_prd_agent import trae_prd_agent
from agents.trae_tech_spec_agent import trae_tech_spec_agent
from agents.trae_verifying_agent import trae_verifying_agent
from core.orchestrator import FlowState
from core.run_trace import init_trace, clear_trace
from tests.runtime_fixtures import build_runtime_ctx

pytestmark = pytest.mark.legacy_runtime_paths


def test_context_manager_records_noncompliance_with_loop_guard(tmp_path):
    progress = tmp_path / "progress.json"
    ctx = ContextManager(str(progress))
    ctx.update_metadata("max_stage_retries", 2)

    should_retry, retry_count, max_retries = ctx.record_noncompliance(
        stage="TECH_SPEC_DRAFTING",
        kind="artifact_validation",
        reason="missing_manifest",
        details={"x": 1},
        suggestion="add manifest",
    )
    assert should_retry is True
    assert retry_count == 1
    assert max_retries == 2

    should_retry2, retry_count2, _ = ctx.record_noncompliance(
        stage="TECH_SPEC_DRAFTING",
        kind="artifact_validation",
        reason="missing_manifest",
        details={"x": 2},
        suggestion="add manifest",
    )
    assert should_retry2 is True
    assert retry_count2 == 2

    should_retry3, retry_count3, _ = ctx.record_noncompliance(
        stage="TECH_SPEC_DRAFTING",
        kind="artifact_validation",
        reason="missing_manifest",
        details={"x": 3},
        suggestion="add manifest",
    )
    assert should_retry3 is False
    assert retry_count3 == 3
    assert "max_stage_retries exceeded" in str(ctx.context["metadata"].get("last_error_log"))

    history = ctx.context["metadata"].get("stage_noncompliance_history", {}).get("TECH_SPEC_DRAFTING", [])
    assert isinstance(history, list) and len(history) == 3


def test_resolve_stage_max_retries_prefers_stage_override_and_falls_back_to_legacy():
    meta = {
        "max_stage_retries": 4,
        "stage_max_retries": {
            "CODING": 1,
            "QUALITY_LOOP": 7,
        },
    }

    assert resolve_stage_max_retries(meta, "CODING") == 1
    assert resolve_stage_max_retries(meta, "QUALITY_LOOP") == 7
    assert resolve_stage_max_retries(meta, "PRD_DRAFTING") == 4
    assert resolve_stage_max_retries({}, "PRD_DRAFTING") == 3


def test_context_manager_records_noncompliance_uses_stage_specific_retry_limit(tmp_path):
    progress = tmp_path / "progress.json"
    ctx = ContextManager(str(progress))
    ctx.update_metadata("max_stage_retries", 5)
    ctx.update_metadata("stage_max_retries", {"TECH_SPEC_DRAFTING": 1})

    should_retry1, retry_count1, max_retries1 = ctx.record_noncompliance(
        stage="TECH_SPEC_DRAFTING",
        kind="artifact_validation",
        reason="missing_manifest",
        details={"x": 1},
        suggestion="add manifest",
    )
    should_retry2, retry_count2, max_retries2 = ctx.record_noncompliance(
        stage="TECH_SPEC_DRAFTING",
        kind="artifact_validation",
        reason="missing_manifest",
        details={"x": 2},
        suggestion="add manifest",
    )

    assert should_retry1 is True
    assert retry_count1 == 1
    assert max_retries1 == 1
    assert should_retry2 is False
    assert retry_count2 == 2
    assert max_retries2 == 1


@pytest.mark.asyncio
async def test_tool_gate_denial_records_gate_denial_in_progress(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"TECH_SPEC_DRAFTING": []}}),
        encoding="utf-8",
    )

    progress = tmp_path / "progress.json"
    progress.write_text(json.dumps({"state": "TECH_SPEC_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "TECH_SPEC_DRAFTING")

    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path / "workspace"), repo_root=str(tmp_path))

    class _Reject:
        option_id = "opt-reject"
        kind = "reject_once"
        name = "Reject Once"

    class _Tool:
        title = "feishu-mcp"
        kind = "mcp"
        raw_input = {}

    resp = await client.request_permission(options=[_Reject()], session_id="s1", tool_call=_Tool())
    dumped = resp.model_dump()
    assert dumped["outcome"]["option_id"] == "opt-reject"

    doc = json.loads(progress.read_text(encoding="utf-8"))
    meta = doc["metadata"]
    assert meta["last_gate_denial"]["reason"] == "tool_not_enabled_for_stage"
    assert meta["last_gate_denial"]["details"]["tool_id"] == "mcp:feishu-mcp"
    assert meta["last_gate_denial"]["details"]["enabled_tool_ids"] == []
    assert meta["last_gate_denial"]["suggestion"]


@pytest.mark.asyncio
async def test_permission_execute_uppercase_command_is_classified_and_denied_by_allowlist(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"TECH_SPEC_DRAFTING": []}}),
        encoding="utf-8",
    )

    progress = tmp_path / "progress.json"
    progress.write_text(json.dumps({"state": "TECH_SPEC_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "TECH_SPEC_DRAFTING")

    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path / "workspace"), repo_root=str(tmp_path))

    class _Reject:
        option_id = "opt-reject"
        kind = "reject_once"
        name = "Reject Once"

    class _Tool:
        title = "Running command"
        kind = "execute"
        raw_input = {"Command": "lark-cli docs +fetch https://example.com"}

    resp = await client.request_permission(options=[_Reject()], session_id="s1", tool_call=_Tool())
    dumped = resp.model_dump()
    assert dumped["outcome"]["option_id"] == "opt-reject"

    doc = json.loads(progress.read_text(encoding="utf-8"))
    meta = doc["metadata"]
    assert meta["last_gate_denial"]["reason"] == "tool_not_enabled_for_stage"
    assert meta["last_gate_denial"]["details"]["tool_id"] == "cli:lark-cli"
    assert meta["last_gate_denial"]["details"]["resolved_capability"] == "terminal.cli"


@pytest.mark.asyncio
async def test_permission_execute_malformed_command_is_denied_as_unknown_tool_identity(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"TECH_SPEC_DRAFTING": ["cli:lark-cli"]}}),
        encoding="utf-8",
    )

    progress = tmp_path / "progress.json"
    progress.write_text(json.dumps({"state": "TECH_SPEC_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "TECH_SPEC_DRAFTING")

    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path / "workspace"), repo_root=str(tmp_path))

    class _Reject:
        option_id = "opt-reject"
        kind = "reject_once"
        name = "Reject Once"

    class _Tool:
        title = "Running command"
        kind = "execute"
        raw_input = {"command": "bash -lc 'echo hi"}

    resp = await client.request_permission(options=[_Reject()], session_id="s1", tool_call=_Tool())
    dumped = resp.model_dump()
    assert dumped["outcome"]["option_id"] == "opt-reject"

    doc = json.loads(progress.read_text(encoding="utf-8"))
    meta = doc["metadata"]
    assert meta["last_gate_denial"]["reason"] == "unknown_tool_identity"
    assert meta["last_gate_denial"]["details"]["tool_id"] is None
    assert meta["last_gate_denial"]["details"]["resolved_capability"] is None


@pytest.mark.asyncio
async def test_terminal_create_enforces_stage_allowlist_and_records_denial(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"TECH_SPEC_DRAFTING": ["cli:lark-cli"]}}),
        encoding="utf-8",
    )

    progress = tmp_path / "progress.json"
    progress.write_text(json.dumps({"state": "TECH_SPEC_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "TECH_SPEC_DRAFTING")
    monkeypatch.setenv("HARNESS_ENFORCE_EXEC_ALLOWLIST_AT_TERMINAL_CREATE", "1")

    workspace = tmp_path / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    client = HarnessClientImpl(updates_list=[], workspace_root=str(workspace), repo_root=str(tmp_path))

    with pytest.raises(Exception) as excinfo:
        await client.create_terminal(command="curl", session_id="s1", args=["-I", "https://example.com"], cwd=str(workspace))
    assert str(excinfo.value)

    doc = json.loads(progress.read_text(encoding="utf-8"))
    meta = doc["metadata"]
    assert meta["last_gate_denial"]["reason"] == "tool_not_enabled_for_stage"
    assert meta["last_gate_denial"]["details"]["tool_id"] == "cli:curl"
    assert meta["last_gate_denial"]["details"]["enabled_tool_ids"] == ["cli:lark-cli"]
    assert meta["last_gate_denial"]["details"]["command"] == "curl"


@pytest.mark.asyncio
async def test_terminal_create_splits_command_string_for_stage_allowlist(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"TECH_SPEC_DRAFTING": ["cli:lark-cli"]}}),
        encoding="utf-8",
    )

    progress = tmp_path / "progress.json"
    progress.write_text(json.dumps({"state": "TECH_SPEC_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "TECH_SPEC_DRAFTING")
    monkeypatch.setenv("HARNESS_ENFORCE_EXEC_ALLOWLIST_AT_TERMINAL_CREATE", "1")

    workspace = tmp_path / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    client = HarnessClientImpl(updates_list=[], workspace_root=str(workspace), repo_root=str(tmp_path))

    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            import asyncio

            self.returncode = None
            self.stdout = asyncio.StreamReader()
            self.stderr = asyncio.StreamReader()
            self.stdout.feed_eof()
            self.stderr.feed_eof()

        async def wait(self):
            self.returncode = 0
            return 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

    async def _fake_create_subprocess_exec(cmd, *argv, **kwargs):
        captured["cmd"] = cmd
        captured["argv"] = list(argv)
        return _FakeProc()

    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    resp = await client.create_terminal(command="lark-cli -h", session_id="s1", args=None, cwd=str(workspace))
    assert resp.terminalId
    assert captured.get("cmd") == "lark-cli"
    assert captured.get("argv") == ["-h"]


@pytest.mark.asyncio
async def test_terminal_create_compound_command_requires_enabled_bash(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"TECH_SPEC_DRAFTING": ["cli:lark-cli"]}}),
        encoding="utf-8",
    )

    progress = tmp_path / "progress.json"
    progress.write_text(json.dumps({"state": "TECH_SPEC_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "TECH_SPEC_DRAFTING")
    monkeypatch.setenv("HARNESS_ENFORCE_EXEC_ALLOWLIST_AT_TERMINAL_CREATE", "1")

    workspace = tmp_path / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    client = HarnessClientImpl(updates_list=[], workspace_root=str(workspace), repo_root=str(tmp_path))

    with pytest.raises(Exception) as excinfo:
        await client.create_terminal(command="cd workspace && lark-cli -h", session_id="s1", args=None, cwd=str(workspace))
    assert str(excinfo.value)

    doc = json.loads(progress.read_text(encoding="utf-8"))
    meta = doc["metadata"]
    assert meta["last_gate_denial"]["reason"] == "tool_not_enabled_for_stage"
    assert meta["last_gate_denial"]["details"]["tool_id"] == "bash:shell"


@pytest.mark.asyncio
async def test_terminal_create_compound_command_allowed_when_bash_enabled(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"TECH_SPEC_DRAFTING": ["bash:shell"]}}),
        encoding="utf-8",
    )

    progress = tmp_path / "progress.json"
    progress.write_text(json.dumps({"state": "TECH_SPEC_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "TECH_SPEC_DRAFTING")
    monkeypatch.setenv("HARNESS_ENFORCE_EXEC_ALLOWLIST_AT_TERMINAL_CREATE", "1")

    workspace = tmp_path / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    client = HarnessClientImpl(updates_list=[], workspace_root=str(workspace), repo_root=str(tmp_path))

    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            import asyncio

            self.returncode = None
            self.stdout = asyncio.StreamReader()
            self.stderr = asyncio.StreamReader()
            self.stdout.feed_eof()
            self.stderr.feed_eof()

        async def wait(self):
            self.returncode = 0
            return 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

    async def _fake_create_subprocess_exec(cmd, *argv, **kwargs):
        captured["cmd"] = cmd
        captured["argv"] = list(argv)
        return _FakeProc()

    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    resp = await client.create_terminal(command="bash -lc 'echo hi'", session_id="s1", args=None, cwd=str(workspace))
    assert resp.terminalId
    assert captured.get("cmd") == "bash"
    assert captured.get("argv") == ["-lc", "echo hi"]


def test_prd_stage_returns_next_stage_after_basic_artifact_validation(tmp_path, monkeypatch):
    ctx, paths = build_runtime_ctx(tmp_path, requirement="请生成 PRD")

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        out = tmp_path / paths.run_root_relative / "docs" / "prd.md"
        out.write_text("# PRD\n\ncontent\n", encoding="utf-8")
        return {"updates": [], "final_response": {"stop_reason": "end_turn"}, "error": None}

    monkeypatch.setattr("core.acp_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_prd_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.TECH_SPEC_DRAFTING
    assert ctx.context["artifacts"]["prd"] == ".harness/runs/run-test/docs/prd.md"


def test_tech_spec_stage_returns_next_stage_after_basic_artifact_validation(tmp_path, monkeypatch):
    ctx, paths = build_runtime_ctx(tmp_path, requirement="请生成技术方案")
    prd_path = tmp_path / paths.run_root_relative / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("PRD content", encoding="utf-8")
    ctx.update_metadata("max_stage_retries", 2)

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        out = tmp_path / paths.run_root_relative / "docs" / "tech_spec.md"
        out.write_text("# Tech Spec\n\n(placeholder)\n", encoding="utf-8")
        return {"updates": [], "final_response": {"stop_reason": "end_turn"}, "error": None}

    monkeypatch.setattr("core.acp_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_tech_spec_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.CODING
    assert ctx.context["artifacts"]["tech_spec"] == ".harness/runs/run-test/docs/tech_spec.md"


def test_resolve_stage_output_for_acceptance_normalizes_near_miss_payload(tmp_path):
    from core.stage_acceptance import resolve_stage_output_for_acceptance

    prd_path = tmp_path / "workspace" / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("# PRD\n\ncontent\n", encoding="utf-8")
    run_dir = tmp_path / "workspace" / "runs" / "run-test"
    stage_output_path = run_dir / "stage_outputs" / "PRD_DRAFTING.json"
    stage_output_path.parent.mkdir(parents=True, exist_ok=True)
    stage_output_path.write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "stage": "PRD_DRAFTING",
                "status": "completed",
                "summary": "PRD 已生成。",
                "artifacts": {
                    "artifact_type": "prd",
                    "path": "workspace/docs/prd.md",
                    "absolute_path": str(prd_path),
                    "exists": True,
                    "is_dir": False,
                    "size_bytes": 15,
                    "summary": "当前阶段生成的 PRD 文档。",
                },
                "key_points": "artifact_path=workspace/docs/prd.md",
                "evidence": "file_exists=True",
                "metadata": None,
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    stage_ctx = {
        "artifacts": {
            "prd": {
                "path": "workspace/docs/prd.md",
                "absolute_path": str(prd_path),
                "exists": True,
                "is_dir": False,
            }
        },
        "run": {"run_dir": str(run_dir), "repo_root": str(tmp_path)},
    }

    normalized_payload, validated = resolve_stage_output_for_acceptance(stage_ctx=stage_ctx, stage="PRD_DRAFTING")

    assert normalized_payload["schema_version"] == 1
    assert isinstance(normalized_payload["artifacts"], list)
    assert normalized_payload["key_points"] == ["artifact_path=workspace/docs/prd.md"]
    assert normalized_payload["evidence"] == ["file_exists=True"]
    assert normalized_payload["metadata"] == {}
    assert validated.stage == "PRD_DRAFTING"
    assert validated.artifacts[0].artifact_type == "prd"


def test_build_acceptance_prompt_prioritizes_user_rules(tmp_path):
    from core.stage_acceptance import build_acceptance_prompt

    prd_path = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("# PRD\n\ncontent\n", encoding="utf-8")
    stage_output_path = tmp_path / ".harness" / "runs" / "run-test" / "stage_outputs" / "PRD_DRAFTING.json"
    stage_output_path.parent.mkdir(parents=True, exist_ok=True)
    stage_output_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "stage": "PRD_DRAFTING",
                "status": "completed",
                "summary": "PRD 已生成。",
                "artifacts": [
                    {
                        "artifact_type": "prd",
                        "path": ".harness/runs/run-test/docs/prd.md",
                        "absolute_path": str(prd_path),
                        "exists": True,
                        "is_dir": False,
                        "size_bytes": 15,
                        "summary": "当前阶段生成的 PRD 文档。",
                    }
                ],
                "key_points": ["artifact_path=.harness/runs/run-test/docs/prd.md"],
                "evidence": ["file_exists=True"],
                "metadata": {"artifact_key": "prd"},
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    stage_ctx = {
        "request": {"raw_requirement": "请生成 PRD"},
        "prompt_inputs": {
            "requirement": "请生成 PRD",
            "requirement_marker": "<!-- HARNESS_REQUIREMENT:请生成 PRD -->",
        },
        "artifacts": {
            "prd": {
                "path": ".harness/runs/run-test/docs/prd.md",
                "absolute_path": str(prd_path),
                "exists": True,
                "is_dir": False,
                "content": "# PRD\n\ncontent\n",
            }
        },
        "constraints": {"global": [], "stage": []},
        "evidence": {"last_error_log": "", "quality_loop": {}},
        "capabilities": {"tool_catalog_payload": {}, "payload": {}},
        "user_context_policy": {"rules": []},
        "non_compliance": {},
        "run": {
            "run_dir": str(tmp_path / ".harness" / "runs" / "run-test"),
            "run_dir_relative": ".harness/runs/run-test",
            "repo_root": str(tmp_path),
        },
        "metadata": {},
    }

    prompt = build_acceptance_prompt(
        stage_ctx=stage_ctx,
        stage="PRD_DRAFTING",
        acceptance_prompt="只要 PRD 非空且包含需求摘要即可通过",
        acceptance_rules=[
            {
                "use_tool_id": "cli:lark-cli",
                "do": "读取当前 PRD 文档。",
                "verify": "确认 PRD 非空且包含需求摘要。",
            }
        ],
    )

    assert "第一优先级是【用户配置的准出规则】" in prompt
    assert "你默认拿到的是精简输入" in prompt
    assert "如果需要核对细节，按需读取 manifest 中列出的相对路径产物" in prompt
    assert "不要把系统自己的写作偏好、证据偏好、章节偏好、风险提示偏好，当成新的强制准出条件。" in prompt
    assert "只有在用户规则未满足时，才输出 fail" in prompt
    assert "# Role" in prompt
    assert "## Decision priority" in prompt
    assert "## Stage" in prompt
    assert "## System baseline" in prompt
    assert "## User acceptance rules" in prompt
    assert "USE: cli:lark-cli" in prompt
    assert "VERIFY: 确认 PRD 非空且包含需求摘要。" in prompt
    assert "### 用户配置的准出补充说明" in prompt
    assert "## Standardized Stage Output" in prompt
    assert "## Artifact manifest" in prompt
    assert "## Available capabilities" in prompt
    assert "## Capability payload" in prompt
    assert "## Tool catalog" in prompt
    assert "## Output contract" in prompt
    assert '"primary_artifact_path": ".harness/runs/run-test/docs/prd.md"' in prompt
    assert "用户原始需求:" not in prompt
    assert "Requirement marker:" not in prompt
    assert "【Harness 上下文与工具层输入】" not in prompt
    assert "【主产物全文（仅作补充证据，不是唯一判断依据）】" not in prompt
    assert "fs.read" in prompt
    assert "只要 PRD 非空且包含需求摘要即可通过" in prompt


def test_acceptance_verifier_failure_records_stage_noncompliance(tmp_path, monkeypatch):
    from core.stage_acceptance import acceptance_output_path, run_stage_acceptance_verifier

    ctx, paths = build_runtime_ctx(tmp_path, requirement="请生成 PRD")
    ctx.update_metadata("max_stage_retries", 2)
    prd_path = tmp_path / paths.run_root_relative / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("# PRD\n\ncontent\n", encoding="utf-8")
    ctx.record_stage_result(
        "PRD_DRAFTING",
        {
            "schema_version": 1,
            "stage": "PRD_DRAFTING",
            "status": "completed",
            "summary": "PRD 已生成。",
            "artifacts": [
                {
                    "artifact_type": "prd",
                    "path": ".harness/runs/run-test/docs/prd.md",
                    "absolute_path": str(prd_path),
                    "exists": True,
                    "is_dir": False,
                    "size_bytes": 15,
                    "summary": "当前阶段生成的 PRD 文档。",
                }
            ],
            "key_points": ["artifact_path=.harness/runs/run-test/docs/prd.md"],
            "evidence": ["file_exists=True"],
            "metadata": {"artifact_key": "prd"},
        },
    )

    monkeypatch.setattr(
        "core.stage_acceptance.load_stage_acceptance_state",
        lambda stage, repo_root=None: {"supported": True, "enabled": True, "prompt": "judge", "model": "", "max_retries": 0, "schema_version": 1, "source": "x"},
    )

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        assert "## Standardized Stage Output" in prompt_text
        assert "## Artifact manifest" in prompt_text
        assert "## Available capabilities" in prompt_text
        assert "## Capability payload" in prompt_text
        assert "## Tool catalog" in prompt_text
        assert "【Harness 上下文与工具层输入】" not in prompt_text
        assert "【主产物全文（仅作补充证据，不是唯一判断依据）】" not in prompt_text
        expected_output = acceptance_output_path(stage="PRD_DRAFTING", run_dir_relative=paths.run_root_relative)
        assert expected_output in prompt_text
        output_path = tmp_path / expected_output
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(
                {
                    "stage": "PRD_DRAFTING",
                    "artifact_type": "prd",
                    "verdict": "fail",
                    "summary": "缺少风险",
                    "missing_items": ["风险"],
                    "findings": ["缺少风险段落"],
                    "suggested_fix": "补齐风险",
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        return {
            "updates": [],
            "final_response": {"content": [{"type": "text", "text": "WROTE_ACCEPTANCE_JSON"}]},
            "error": None,
            "sessionId": "s1",
            "sessionInfo": {"sessionId": "s1"},
        }

    monkeypatch.setattr("core.acp_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        result = run_stage_acceptance_verifier(ctx, stage="PRD_DRAFTING", metadata=ctx.context.get("metadata"))
    finally:
        os.chdir(cwd)

    assert result["outcome"] == "fail"
    assert result["stage_output"]["stage"] == "PRD_DRAFTING"
    assert result["acceptance_retry_count"] == 1
    retry_state = ctx.context["metadata"].get("acceptance_retry_state", {}).get("PRD_DRAFTING")
    assert isinstance(retry_state, dict)
    assert retry_state["attempt"] == 1
    last = ctx.context["metadata"].get("last_noncompliance")
    assert isinstance(last, dict)
    assert last["reason"] == "acceptance_failed"
    assert last["details"]["acceptance_result"]["summary"] == "缺少风险"
    assert last["details"]["stage_output"]["stage"] == "PRD_DRAFTING"


def test_acceptance_stage_output_validation_fails_before_llm(tmp_path, monkeypatch):
    from core.stage_acceptance import run_stage_acceptance_verifier

    ctx, _ = build_runtime_ctx(tmp_path, requirement="请生成 PRD")
    ctx.update_metadata("max_stage_retries", 2)
    ctx.record_stage_result(
        "PRD_DRAFTING",
        {
            "schema_version": 1,
            "stage": "PRD_DRAFTING",
            "status": "completed",
            "summary": "PRD 已生成。",
            "artifacts": [
                {
                    "artifact_type": "prd",
                    "path": ".harness/runs/run-test/docs/prd.md",
                    "absolute_path": str(tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"),
                    "exists": False,
                    "is_dir": False,
                    "size_bytes": 0,
                    "summary": "当前阶段生成的 PRD 文档。",
                }
            ],
            "key_points": [],
            "evidence": [],
            "metadata": {"artifact_key": "prd"},
        },
    )

    monkeypatch.setattr(
        "core.stage_acceptance.load_stage_acceptance_state",
        lambda stage, repo_root=None: {"supported": True, "enabled": True, "prompt": "judge", "model": "", "max_retries": 0, "schema_version": 1, "source": "x"},
    )

    called = {"count": 0}

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        called["count"] += 1
        return {"updates": [], "error": None}

    monkeypatch.setattr("core.acp_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        result = run_stage_acceptance_verifier(ctx, stage="PRD_DRAFTING", metadata=ctx.context.get("metadata"))
    finally:
        os.chdir(cwd)

    assert called["count"] == 0
    assert result["reason"] == "stage_output_validation_failed"
    last = ctx.context["metadata"].get("last_noncompliance")
    assert isinstance(last, dict)
    assert last["kind"] == "stage_output_validation"
    assert last["reason"] == "stage_output_validation_failed"


def test_acceptance_prompt_includes_prior_failure_block(tmp_path):
    from core.stage_acceptance import build_acceptance_prompt

    prd_path = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("# PRD\n\ncontent\n", encoding="utf-8")
    stage_output_path = tmp_path / ".harness" / "runs" / "run-test" / "stage_outputs" / "PRD_DRAFTING.json"
    stage_output_path.parent.mkdir(parents=True, exist_ok=True)
    stage_output_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "stage": "PRD_DRAFTING",
                "status": "completed",
                "summary": "PRD 已生成。",
                "artifacts": [
                    {
                        "artifact_type": "prd",
                        "path": ".harness/runs/run-test/docs/prd.md",
                        "absolute_path": str(prd_path),
                        "exists": True,
                        "is_dir": False,
                        "size_bytes": 15,
                        "summary": "当前阶段生成的 PRD 文档。",
                    }
                ],
                "key_points": ["artifact_path=.harness/runs/run-test/docs/prd.md"],
                "evidence": ["file_exists=True"],
                "metadata": {"artifact_key": "prd"},
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    stage_ctx = {
        "artifacts": {
            "prd": {
                "path": ".harness/runs/run-test/docs/prd.md",
                "absolute_path": str(prd_path),
                "exists": True,
                "is_dir": False,
            }
        },
        "run": {
            "run_dir": str(tmp_path / ".harness" / "runs" / "run-test"),
            "run_dir_relative": ".harness/runs/run-test",
            "repo_root": str(tmp_path),
        },
    }

    prompt = build_acceptance_prompt(
        stage_ctx=stage_ctx,
        stage="PRD_DRAFTING",
        acceptance_prompt="judge",
        acceptance_rules=[],
        prior_failure={
            "reason": "acceptance_verifier_error",
            "summary": "acceptance_result_missing_file",
            "missing_items": ["acceptance json"],
            "findings": ["verifier did not write result file"],
            "suggested_fix": "write acceptance json",
        },
    )

    assert "## Previous verifier feedback" in prompt
    assert "failure reason: acceptance_verifier_error" in prompt
    assert "acceptance json" in prompt
    assert "verifier did not write result file" in prompt
    assert "write acceptance json" in prompt



def test_acceptance_verifier_reads_result_file(tmp_path, monkeypatch):
    from core.stage_acceptance import acceptance_output_path, run_stage_acceptance_verifier

    ctx, paths = build_runtime_ctx(tmp_path, requirement="请生成 PRD")
    prd_path = tmp_path / paths.run_root_relative / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("# PRD\n\ncontent\n", encoding="utf-8")
    ctx.record_stage_result(
        "PRD_DRAFTING",
        {
            "schema_version": 1,
            "stage": "PRD_DRAFTING",
            "status": "completed",
            "summary": "PRD 已生成。",
            "artifacts": [
                {
                    "artifact_type": "prd",
                    "path": ".harness/runs/run-test/docs/prd.md",
                    "absolute_path": str(prd_path),
                    "exists": True,
                    "is_dir": False,
                    "size_bytes": 15,
                    "summary": "当前阶段生成的 PRD 文档。",
                }
            ],
            "key_points": ["artifact_path=.harness/runs/run-test/docs/prd.md"],
            "evidence": ["file_exists=True"],
            "metadata": {"artifact_key": "prd"},
        },
    )

    monkeypatch.setattr(
        "core.stage_acceptance.load_stage_acceptance_state",
        lambda stage, repo_root=None: {"supported": True, "enabled": True, "prompt": "judge", "model": "", "max_retries": 0, "schema_version": 1, "source": "x"},
    )

    verdict = {
        "stage": "PRD_DRAFTING",
        "artifact_type": "prd",
        "verdict": "pass",
        "summary": "通过",
        "missing_items": [],
        "findings": ["结构完整"],
        "suggested_fix": "",
    }

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        output_path = tmp_path / acceptance_output_path(stage="PRD_DRAFTING", run_dir_relative=paths.run_root_relative)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(verdict, ensure_ascii=False, indent=2), encoding="utf-8")
        return {
            "updates": [],
            "final_response": {"content": [{"type": "text", "text": "WROTE_ACCEPTANCE_JSON"}]},
            "error": None,
        }

    monkeypatch.setattr("core.acp_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        result = run_stage_acceptance_verifier(ctx, stage="PRD_DRAFTING", metadata=ctx.context.get("metadata"))
    finally:
        os.chdir(cwd)

    assert result["outcome"] == "pass"
    assert result["acceptance_result"]["summary"] == "通过"


def test_acceptance_failed_does_not_retry_inside_verifier(tmp_path, monkeypatch):
    from core.stage_acceptance import acceptance_output_path, run_stage_acceptance_verifier

    ctx, paths = build_runtime_ctx(tmp_path, requirement="请生成 PRD")
    ctx.update_metadata("max_stage_retries", 2)
    prd_path = tmp_path / paths.run_root_relative / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("# PRD\n\ncontent\n", encoding="utf-8")
    ctx.record_stage_result(
        "PRD_DRAFTING",
        {
            "schema_version": 1,
            "stage": "PRD_DRAFTING",
            "status": "completed",
            "summary": "PRD 已生成。",
            "artifacts": [
                {
                    "artifact_type": "prd",
                    "path": ".harness/runs/run-test/docs/prd.md",
                    "absolute_path": str(prd_path),
                    "exists": True,
                    "is_dir": False,
                    "size_bytes": 15,
                    "summary": "当前阶段生成的 PRD 文档。",
                }
            ],
            "key_points": ["artifact_path=.harness/runs/run-test/docs/prd.md"],
            "evidence": ["file_exists=True"],
            "metadata": {"artifact_key": "prd"},
        },
    )

    monkeypatch.setattr(
        "core.stage_acceptance.load_stage_acceptance_state",
        lambda stage, repo_root=None: {"supported": True, "enabled": True, "prompt": "judge", "model": "", "max_retries": 2, "schema_version": 1, "source": "x"},
    )

    seen = {"count": 0, "prompts": []}

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        seen["count"] += 1
        seen["prompts"].append(prompt_text)
        output_path = tmp_path / acceptance_output_path(stage="PRD_DRAFTING", run_dir_relative=paths.run_root_relative)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(
                {
                    "stage": "PRD_DRAFTING",
                    "artifact_type": "prd",
                    "verdict": "fail",
                    "summary": "缺少风险",
                    "missing_items": ["风险"],
                    "findings": ["缺少风险段落"],
                    "suggested_fix": "补齐风险",
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        return {"updates": [], "final_response": {"content": [{"type": "text", "text": "WROTE_ACCEPTANCE_JSON"}]}, "error": None}

    monkeypatch.setattr("core.acp_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        result = run_stage_acceptance_verifier(ctx, stage="PRD_DRAFTING", metadata=ctx.context.get("metadata"))
    finally:
        os.chdir(cwd)

    assert result["outcome"] == "fail"
    assert result["reason"] == "acceptance_failed"
    assert result["acceptance_retry_count"] == 1
    assert result["acceptance_max_retries"] == 2
    assert seen["count"] == 1
    retry_state = ctx.context["metadata"].get("acceptance_retry_state", {}).get("PRD_DRAFTING")
    assert isinstance(retry_state, dict)
    assert retry_state["attempt"] == 1
    assert ctx.context["metadata"].get("last_noncompliance", {}).get("reason") == "acceptance_failed"



def test_acceptance_verifier_missing_result_file_retries_then_fails(tmp_path, monkeypatch):
    from core.stage_acceptance import run_stage_acceptance_verifier

    ctx, paths = build_runtime_ctx(tmp_path, requirement="请生成 PRD")
    ctx.update_metadata("max_stage_retries", 2)
    prd_path = tmp_path / paths.run_root_relative / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("# PRD\n\ncontent\n", encoding="utf-8")
    ctx.record_stage_result(
        "PRD_DRAFTING",
        {
            "schema_version": 1,
            "stage": "PRD_DRAFTING",
            "status": "completed",
            "summary": "PRD 已生成。",
            "artifacts": [
                {
                    "artifact_type": "prd",
                    "path": ".harness/runs/run-test/docs/prd.md",
                    "absolute_path": str(prd_path),
                    "exists": True,
                    "is_dir": False,
                    "size_bytes": 15,
                    "summary": "当前阶段生成的 PRD 文档。",
                }
            ],
            "key_points": ["artifact_path=.harness/runs/run-test/docs/prd.md"],
            "evidence": ["file_exists=True"],
            "metadata": {"artifact_key": "prd"},
        },
    )

    monkeypatch.setattr(
        "core.stage_acceptance.load_stage_acceptance_state",
        lambda stage, repo_root=None: {"supported": True, "enabled": True, "prompt": "judge", "model": "", "max_retries": 1, "schema_version": 1, "source": "x"},
    )

    seen = {"count": 0}

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        seen["count"] += 1
        return {
            "updates": [],
            "final_response": {"content": [{"type": "text", "text": "WROTE_ACCEPTANCE_JSON"}]},
            "error": None,
        }

    monkeypatch.setattr("core.acp_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        result = run_stage_acceptance_verifier(ctx, stage="PRD_DRAFTING", metadata=ctx.context.get("metadata"))
    finally:
        os.chdir(cwd)

    assert result["outcome"] == "fail"
    assert result["reason"] == "acceptance_verifier_error"
    assert result["acceptance_result"]["summary"] == "acceptance_result_missing_file: .harness/runs/run-test/acceptance/PRD_DRAFTING.json"
    assert result["acceptance_retry_count"] == 2
    assert result["acceptance_max_retries"] == 1
    assert result["should_retry"] is True
    assert result["retry_count"] == 1
    assert result["max_retries"] == 2
    assert seen["count"] == 2
    retry_state = ctx.context["metadata"].get("acceptance_retry_state", {}).get("PRD_DRAFTING")
    assert isinstance(retry_state, dict)
    assert retry_state["attempt"] == 2


@pytest.mark.parametrize("stage,suggested_next_state", [
    ("PRD_DRAFTING", "TECH_SPEC_DRAFTING"),
    ("TECH_SPEC_DRAFTING", "CODING"),
    ("CODING", "QUALITY_LOOP"),
    ("DEPLOYING", "REGRESSION_TESTING"),
    ("REGRESSION_TESTING", "FINISHED"),
])
def test_acceptance_post_gate_retries_same_stage_for_acceptance_failed(stage, suggested_next_state):
    from core.harness_gate import default_gate, set_acceptance_runner

    gate = default_gate()
    set_acceptance_runner(
        lambda **_: {
            "outcome": "fail",
            "reason": "acceptance_failed",
            "should_retry": True,
            "acceptance_result": {"verdict": "fail", "summary": "missing evidence"},
        }
    )
    try:
        verdict = gate.post_gate(stage=stage, suggested_next_state=suggested_next_state, metadata={})
    finally:
        set_acceptance_runner(None)

    assert verdict.outcome == "force"
    assert verdict.reason == "acceptance_stage_retry"
    assert verdict.next_state == stage
    assert verdict.details["acceptance_reason"] == "acceptance_failed"


@pytest.mark.parametrize("stage,suggested_next_state", [
    ("PRD_DRAFTING", "TECH_SPEC_DRAFTING"),
    ("TECH_SPEC_DRAFTING", "CODING"),
    ("CODING", "QUALITY_LOOP"),
    ("DEPLOYING", "REGRESSION_TESTING"),
    ("REGRESSION_TESTING", "FINISHED"),
])
def test_acceptance_post_gate_retries_same_stage_for_acceptance_verifier_error(stage, suggested_next_state):
    from core.harness_gate import default_gate, set_acceptance_runner

    gate = default_gate()
    set_acceptance_runner(
        lambda **_: {
            "outcome": "fail",
            "reason": "acceptance_verifier_error",
            "should_retry": True,
            "acceptance_result": {"verdict": "fail", "summary": "missing result file"},
        }
    )
    try:
        verdict = gate.post_gate(stage=stage, suggested_next_state=suggested_next_state, metadata={})
    finally:
        set_acceptance_runner(None)

    assert verdict.outcome == "force"
    assert verdict.reason == "acceptance_stage_retry"
    assert verdict.next_state == stage
    assert verdict.details["acceptance_reason"] == "acceptance_verifier_error"


def test_coding_post_gate_stage_output_validation_with_retry_retries_same_stage():
    from core.harness_gate import default_gate, set_acceptance_runner

    gate = default_gate()
    set_acceptance_runner(
        lambda **_: {
            "outcome": "fail",
            "reason": "stage_output_validation_failed",
            "should_retry": True,
            "acceptance_result": {"verdict": "fail", "summary": "missing artifact"},
        }
    )
    try:
        verdict = gate.post_gate(stage="CODING", suggested_next_state="QUALITY_LOOP", metadata={})
    finally:
        set_acceptance_runner(None)

    assert verdict.outcome == "force"
    assert verdict.reason == "acceptance_stage_retry"
    assert verdict.next_state == "CODING"
    assert verdict.details["acceptance_reason"] == "stage_output_validation_failed"


def test_coding_post_gate_acceptance_final_fail_blocks_transition():
    from core.harness_gate import default_gate, set_acceptance_runner

    gate = default_gate()
    set_acceptance_runner(
        lambda **_: {
            "outcome": "fail",
            "reason": "acceptance_failed",
            "should_retry": False,
            "acceptance_result": {"verdict": "fail", "summary": "missing stage output"},
        }
    )
    try:
        verdict = gate.post_gate(stage="CODING", suggested_next_state="QUALITY_LOOP", metadata={})
    finally:
        set_acceptance_runner(None)

    assert verdict.outcome == "deny"
    assert verdict.reason == "acceptance_failed_blocks_transition"
    assert verdict.next_state == "FAILED"


def test_coding_post_gate_acceptance_verifier_error_without_retry_blocks_transition():
    from core.harness_gate import default_gate, set_acceptance_runner

    gate = default_gate()
    set_acceptance_runner(
        lambda **_: {
            "outcome": "fail",
            "reason": "acceptance_verifier_error",
            "should_retry": False,
            "acceptance_result": {"verdict": "fail", "summary": "missing result file"},
        }
    )
    try:
        verdict = gate.post_gate(stage="CODING", suggested_next_state="QUALITY_LOOP", metadata={})
    finally:
        set_acceptance_runner(None)

    assert verdict.outcome == "deny"
    assert verdict.reason == "acceptance_failed_blocks_transition"
    assert verdict.next_state == "FAILED"


def test_acceptance_stage_post_gate_allows_auth_blocked():
    from core.harness_gate import default_gate, set_acceptance_runner

    gate = default_gate()
    set_acceptance_runner(None)
    verdict = gate.post_gate(stage="CODING", suggested_next_state="AUTH_BLOCKED", metadata={})

    assert verdict.outcome == "allow"
    assert verdict.reason == "acceptance_stage_auth_blocked"
    assert verdict.next_state == "AUTH_BLOCKED"



def test_deploying_post_gate_runs_acceptance_and_allows_regression_transition():
    from core.harness_gate import default_gate, set_acceptance_runner

    gate = default_gate()
    set_acceptance_runner(lambda **_: {"outcome": "pass", "acceptance_result": {"verdict": "pass", "summary": "ok"}})
    try:
        verdict = gate.post_gate(stage="DEPLOYING", suggested_next_state="REGRESSION_TESTING", metadata={})
    finally:
        set_acceptance_runner(None)

    assert verdict.outcome == "allow"
    assert verdict.next_state == "REGRESSION_TESTING"
    assert verdict.reason == "acceptance_pass_allows_transition"



def test_regression_post_gate_runs_acceptance_and_allows_finish_transition():
    from core.harness_gate import default_gate, set_acceptance_runner

    gate = default_gate()
    set_acceptance_runner(lambda **_: {"outcome": "pass", "acceptance_result": {"verdict": "pass", "summary": "ok"}})
    try:
        verdict = gate.post_gate(stage="REGRESSION_TESTING", suggested_next_state="FINISHED", metadata={})
    finally:
        set_acceptance_runner(None)

    assert verdict.outcome == "allow"
    assert verdict.next_state == "FINISHED"
    assert verdict.reason == "acceptance_pass_allows_transition"


def test_orchestrator_clears_stale_acceptance_result_before_acceptance_stage_retry(tmp_path):
    from core.orchestrator import Orchestrator

    progress = tmp_path / "progress.json"
    ctx = ContextManager(str(progress))
    ctx.update_metadata("requirement", "请生成 PRD")
    ctx.update_metadata("run_id", "run-test")
    ctx.update_metadata("run_dir", "workspace/runs/run-test")
    ctx.context["metadata"]["acceptance_results"] = {
        "PRD_DRAFTING": {
            "stage": "PRD_DRAFTING",
            "artifact_type": "prd",
            "verdict": "fail",
            "summary": "stale fail",
            "missing_items": [],
            "findings": ["stale fail"],
            "suggested_fix": "retry",
        }
    }
    ctx.context["metadata"]["last_acceptance_result"] = dict(ctx.context["metadata"]["acceptance_results"]["PRD_DRAFTING"])
    ctx.set_state(FlowState.PRD_DRAFTING.value)

    seen: dict[str, object] = {}

    def _prd_handler(_ctx):
        meta = _ctx.context.get("metadata", {})
        seen["acceptance_results"] = dict(meta.get("acceptance_results") or {})
        seen["last_acceptance_result"] = meta.get("last_acceptance_result")
        return FlowState.FAILED

    orch = Orchestrator(ctx)
    orch.register_handler(FlowState.PRD_DRAFTING, _prd_handler)

    orch.run()

    assert seen["acceptance_results"] == {}
    assert seen["last_acceptance_result"] is None


def test_orchestrator_retries_same_acceptance_stage_when_gate_forces_retry(tmp_path):
    from core.harness_gate import set_acceptance_runner
    from core.orchestrator import Orchestrator

    progress = tmp_path / "progress.json"
    ctx = ContextManager(str(progress))
    ctx.update_metadata("requirement", "请生成 PRD")
    ctx.update_metadata("run_id", "run-test")
    ctx.update_metadata("run_dir", "workspace/runs/run-test")
    ctx.set_state(FlowState.PRD_DRAFTING.value)

    calls = {"count": 0}

    def _prd_handler(_ctx):
        calls["count"] += 1
        if calls["count"] == 1:
            return FlowState.TECH_SPEC_DRAFTING
        return FlowState.FAILED

    orch = Orchestrator(ctx)
    orch.register_handler(FlowState.PRD_DRAFTING, _prd_handler)

    set_acceptance_runner(
        lambda **_: {
            "outcome": "fail",
            "reason": "acceptance_failed",
            "should_retry": True,
            "acceptance_result": {"verdict": "fail", "summary": "missing evidence"},
        }
    )
    try:
        orch.run()
    finally:
        set_acceptance_runner(None)

    assert calls["count"] == 2
    assert ctx.get_state() == FlowState.FAILED.value


def test_tech_spec_retry_prompt_includes_flattened_last_gate_denial(tmp_path, monkeypatch):
    ctx, paths = build_runtime_ctx(tmp_path, requirement="请生成技术方案")
    prd_path = tmp_path / paths.run_root_relative / "docs" / "prd.md"
    prd_path.parent.mkdir(parents=True, exist_ok=True)
    prd_path.write_text("PRD content", encoding="utf-8")
    ctx.update_metadata("max_stage_retries", 2)
    ctx.update_metadata("last_gate_denial", {
        "stage": FlowState.TECH_SPEC_DRAFTING.value,
        "kind": "tool_gate",
        "reason": "tool_not_enabled_for_stage",
        "suggestion": "Use cli:lark-cli instead.",
        "details": {
            "tool_id": "cli:git",
            "resolved_capability": "terminal.cli",
            "enabled_tool_ids": ["cli:lark-cli"],
        },
    })

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        return {"updates": [], "final_response": None, "error": "Tool call rejected by user"}

    monkeypatch.setattr("core.acp_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_tech_spec_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.TECH_SPEC_DRAFTING
    last = ctx.context["metadata"].get("last_noncompliance")
    assert isinstance(last, dict)
    assert last["details"]["tool_id"] == "cli:git"
    assert last["details"]["resolved_capability"] == "terminal.cli"
    assert last["details"]["enabled_tool_ids"] == ["cli:lark-cli"]

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=str(tmp_path))
    finally:
        os.chdir(cwd)

    assert "Denied tool_id: cli:git" in prompt
    assert "Resolved capability: terminal.cli" in prompt
    assert "cli:lark-cli" in prompt
    assert "Do not retry unlisted direct CLI or shell commands." in prompt


def test_tech_spec_retry_prompt_includes_factual_stage_output_failure(tmp_path):
    (tmp_path / "workspace" / "docs").mkdir(parents=True, exist_ok=True)
    prd_path = tmp_path / "workspace" / "docs" / "prd.md"
    prd_path.write_text("PRD content", encoding="utf-8")

    ctx = ContextManager(str(tmp_path / "progress.json"))
    ctx.update_metadata("requirement", "请生成技术方案")
    ctx.update_metadata("max_stage_retries", 3)
    ctx.update_metadata("run_id", "run-test")
    ctx.update_metadata("run_dir", "workspace/runs/run-test")
    ctx.update_metadata("last_noncompliance", {
        "ts": "2026-04-30T09:20:14Z",
        "stage": FlowState.TECH_SPEC_DRAFTING.value,
        "kind": "stage_output_validation",
        "reason": "stage_output_validation_failed",
        "details": {
            "error": "stage_output_artifact_empty: tech_spec",
            "error_code": "artifact_empty",
            "error_message": "未读取到符合要求的非空产物文件。",
            "artifact_type": "tech_spec",
            "error_details": {
                "stage": "TECH_SPEC_DRAFTING",
                "artifact_type": "tech_spec",
                "declared_path": "docs/tech_spec.md",
                "declared_absolute_path": str(tmp_path / "workspace" / "docs" / "tech_spec.md"),
                "declared_exists": True,
                "declared_is_dir": False,
                "declared_size_bytes": None,
            },
            "stage_output": {
                "stage": "TECH_SPEC_DRAFTING",
                "artifacts": [
                    {
                        "artifact_type": "tech_spec",
                        "path": "docs/tech_spec.md",
                        "absolute_path": str(tmp_path / "workspace" / "docs" / "tech_spec.md"),
                        "exists": True,
                        "is_dir": False,
                        "size_bytes": None,
                    }
                ],
            },
        },
        "suggestion": "修正节点输出 JSON 或产物文件后重试。",
    })
    ctx.context["metadata"]["stage_retry_count"] = {FlowState.TECH_SPEC_DRAFTING.value: 1}

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=str(tmp_path))
    finally:
        os.chdir(cwd)

    assert "Error code: artifact_empty" in prompt
    assert "Message: 未读取到符合要求的非空产物文件。" in prompt
    assert "Validation error: stage_output_artifact_empty: tech_spec" in prompt
    assert "Affected artifact_type: tech_spec" in prompt
    assert "declared_path: docs/tech_spec.md" in prompt


def test_verifying_loop_guard_is_independent_from_stage_retries(tmp_path):
    run_dir = tmp_path / "workspace" / "runs" / "r1"
    init_trace("r1", str(run_dir))
    ctx = ContextManager(str(tmp_path / "progress.json"))
    ctx.update_metadata("run_dir", "workspace/runs/r1")
    ctx.update_metadata("max_stage_retries", 0)
    ctx.update_quality_loop(phase="verify", retry_count=0, max_retries=2, history=[])

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        nxt = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)
        clear_trace()

    assert nxt == FlowState.FIXING


def test_coding_retry_prompt_includes_flattened_last_gate_denial(tmp_path, monkeypatch):
    ctx, paths = build_runtime_ctx(tmp_path, requirement="请完成编码")
    ts_path = tmp_path / paths.run_root_relative / "docs" / "tech_spec.md"
    ts_path.parent.mkdir(parents=True, exist_ok=True)
    ts_path.write_text("## Tech Spec\n\n## 变更清单 (Manifest)\n- `src/app.py`\n- `tests/test_app.py`\n", encoding="utf-8")
    ctx.update_metadata("max_stage_retries", 2)
    ctx.update_metadata("last_gate_denial", {
        "stage": FlowState.CODING.value,
        "kind": "tool_gate",
        "reason": "tool_not_enabled_for_stage",
        "suggestion": "Use fs.write instead.",
        "details": {
            "tool_id": "bash:shell",
            "resolved_capability": "terminal.bash",
            "enabled_tool_ids": ["fs.read", "fs.write"],
        },
    })

    def _fake_run_task(self, prompt_text: str, cwd: str, stage: str | None = None, prompt_blocks=None):
        return {"updates": [], "final_response": None, "error": "Tool call rejected by user"}

    monkeypatch.setattr("agents.trae_coding_agent.AcpAgent.run_task", _fake_run_task)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_coding_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.CODING

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.CODING.value, repo_root=str(tmp_path))
    finally:
        os.chdir(cwd)

    assert "Denied tool_id: bash:shell" in prompt
    assert "Resolved capability: terminal.bash" in prompt
    assert "fs.read" in prompt
    assert "fs.write" in prompt
    assert "Do not retry unlisted direct CLI or shell commands." in prompt


def test_verifying_gate_denial_uses_stage_retry_limit_not_quality_loop_max_retries(tmp_path):
    run_dir = tmp_path / "workspace" / "runs" / "r2"
    init_trace("r2", str(run_dir))
    ctx = ContextManager(str(tmp_path / "progress.json"))
    ctx.update_metadata("run_dir", "workspace/runs/r2")
    ctx.update_metadata("max_stage_retries", 0)
    ctx.update_quality_loop(phase="verify", retry_count=7, max_retries=99, history=[])
    ctx.update_metadata("last_gate_denial", {
        "stage": FlowState.QUALITY_LOOP.value,
        "kind": "tool_gate",
        "reason": "tool_not_enabled_for_stage",
        "suggestion": "Use allowed tools only.",
        "details": {
            "tool_id": "bash:shell",
            "resolved_capability": "terminal.bash",
            "enabled_tool_ids": ["fs.read", "fs.write"],
        },
    })

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        nxt = trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)
        clear_trace()

    assert nxt == FlowState.FAILED
    assert ctx.context["metadata"]["quality_loop"]["retry_count"] == 7
    last = ctx.context["metadata"]["last_noncompliance"]
    assert last["stage"] == FlowState.VERIFYING.value
    assert last["reason"] == "tool_not_enabled_for_stage"
