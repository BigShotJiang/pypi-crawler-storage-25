import builtins
import os
import signal

from ui_runtime import launch_pipeline_process, stop_previous_run, write_run_pid


class _FakePopen:
    def __init__(self, *args, **kwargs):
        self.kwargs = kwargs
        self.pid = 12345


def test_launch_pipeline_process_closes_log_file(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    opened = {}

    real_open = builtins.open

    def fake_open(*args, **kwargs):
        f = real_open(*args, **kwargs)
        opened["file"] = f
        return f

    monkeypatch.setattr(builtins, "open", fake_open)
    monkeypatch.setattr("subprocess.Popen", _FakePopen)

    pid = launch_pipeline_process(["echo", "ok"], cwd=str(tmp_path), repo_root=str(tmp_path))
    assert pid == 12345
    assert opened["file"].closed is True


def test_stop_previous_run_kills_process_group(tmp_path, monkeypatch):
    pid_file = tmp_path / ".harness" / "run.pid"
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    write_run_pid(111, pid_file=str(pid_file))

    calls = {"killpg": [], "kill": []}

    monkeypatch.setattr(os, "getpgid", lambda pid: pid)

    def fake_killpg(pgid, sig):
        calls["killpg"].append((pgid, sig))

    def fake_kill(pid, sig):
        calls["kill"].append((pid, sig))
        if sig == 0:
            raise ProcessLookupError()

    monkeypatch.setattr(os, "killpg", fake_killpg)
    monkeypatch.setattr(os, "kill", fake_kill)

    stopped = stop_previous_run(pid_file=str(pid_file))
    assert stopped is True
    assert calls["killpg"][0] == (111, signal.SIGTERM)
