import json
import os

import pytest

from core.mcp_registry import (
    McpRegistryError,
    delete_mcp,
    list_registered,
    mcp_path,
    register_mcp,
)


def _read(repo_root: str):
    path = mcp_path(repo_root)
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def test_register_http_creates_file_and_entry(tmp_path):
    repo_root = str(tmp_path)
    saved, created = register_mcp(
        repo_root,
        {
            "name": "feishu-mcp",
            "url": "https://mcp.larkoffice.com/mcp/xxx",
            "headers": {"Authorization": "Bearer xyz"},
        },
    )
    assert created is True
    assert saved == mcp_path(repo_root)
    doc = _read(repo_root)
    assert doc["mcpServers"]["feishu-mcp"]["type"] == "http"
    assert doc["mcpServers"]["feishu-mcp"]["url"] == "https://mcp.larkoffice.com/mcp/xxx"
    assert doc["mcpServers"]["feishu-mcp"]["headers"] == {"Authorization": "Bearer xyz"}


def test_register_http_without_headers_is_allowed(tmp_path):
    repo_root = str(tmp_path)
    register_mcp(repo_root, {"name": "public", "url": "https://example.com/mcp"})
    doc = _read(repo_root)
    assert doc["mcpServers"]["public"] == {"type": "http", "url": "https://example.com/mcp"}


def test_register_accepts_stdio_transport(tmp_path):
    repo_root = str(tmp_path)
    saved, created = register_mcp(
        repo_root,
        {"name": "coco", "transport": "stdio", "command": "python", "args": ["-m", "http.server"], "env": {"FOO": "bar"}},
    )
    assert created is True
    assert saved == mcp_path(repo_root)
    doc = _read(repo_root)
    assert doc["mcpServers"]["coco"] == {
        "type": "stdio",
        "command": "python",
        "args": ["-m", "http.server"],
        "env": {"FOO": "bar"},
    }



def test_register_rejects_unsupported_transport(tmp_path):
    repo_root = str(tmp_path)
    with pytest.raises(McpRegistryError) as exc:
        register_mcp(repo_root, {"name": "coco", "transport": "sse", "url": "https://x"})
    assert "unsupported_transport" in str(exc.value)


def test_register_rejects_missing_or_invalid_url(tmp_path):
    repo_root = str(tmp_path)
    with pytest.raises(McpRegistryError):
        register_mcp(repo_root, {"name": "feishu", "url": ""})
    with pytest.raises(McpRegistryError):
        register_mcp(repo_root, {"name": "feishu", "url": "ftp://x"})


def test_register_rejects_invalid_name(tmp_path):
    with pytest.raises(McpRegistryError):
        register_mcp(str(tmp_path), {"name": "bad name", "url": "https://x"})


def test_register_duplicate_without_overwrite_errors(tmp_path):
    repo_root = str(tmp_path)
    register_mcp(repo_root, {"name": "feishu", "url": "https://a"})
    with pytest.raises(McpRegistryError) as exc:
        register_mcp(repo_root, {"name": "feishu", "url": "https://b"})
    assert "duplicate_name" in str(exc.value)


def test_register_duplicate_with_overwrite_updates(tmp_path):
    repo_root = str(tmp_path)
    register_mcp(repo_root, {"name": "feishu", "url": "https://a"})
    _, created = register_mcp(
        repo_root, {"name": "feishu", "url": "https://b"}, overwrite=True
    )
    assert created is False
    doc = _read(repo_root)
    assert doc["mcpServers"]["feishu"]["url"] == "https://b"


def test_register_allows_overwriting_existing_stdio_with_stdio(tmp_path):
    repo_root = str(tmp_path)
    os.makedirs(os.path.join(repo_root, ".harness"))
    with open(os.path.join(repo_root, ".harness", "mcp.json"), "w", encoding="utf-8") as f:
        json.dump(
            {"mcpServers": {"coco": {"type": "stdio", "command": "coco", "args": ["mcp", "serve"]}}},
            f,
        )
    _, created = register_mcp(repo_root, {"name": "coco", "transport": "stdio", "command": "python"}, overwrite=True)
    assert created is False
    doc = _read(repo_root)
    assert doc["mcpServers"]["coco"] == {"type": "stdio", "command": "python"}


def test_list_registered_includes_stdio_and_http(tmp_path):
    repo_root = str(tmp_path)
    os.makedirs(os.path.join(repo_root, ".harness"))
    with open(os.path.join(repo_root, ".harness", "mcp.json"), "w", encoding="utf-8") as f:
        json.dump(
            {
                "mcpServers": {
                    "coco": {"type": "stdio", "command": "python", "args": ["-m", "http.server"]},
                    "feishu": {"type": "http", "url": "https://x"},
                }
            },
            f,
        )
    entries = list_registered(repo_root)
    by_name = {e["name"]: e for e in entries}
    assert by_name["feishu"]["transport"] == "http"
    assert by_name["coco"]["transport"] == "stdio"
    assert by_name["coco"]["command"] == "python"
    assert by_name["coco"]["args"] == ["-m", "http.server"]


def test_register_preserves_sibling_keys(tmp_path):
    repo_root = str(tmp_path)
    os.makedirs(os.path.join(repo_root, ".harness"))
    with open(os.path.join(repo_root, ".harness", "mcp.json"), "w", encoding="utf-8") as f:
        json.dump(
            {
                "mcpServers": {"coco": {"type": "stdio", "command": "coco"}},
                "stages": {"PRD_DRAFTING": ["coco"]},
                "custom_key": 42,
            },
            f,
        )
    register_mcp(repo_root, {"name": "feishu", "url": "https://x"})
    doc = _read(repo_root)
    # hand-written stdio, `stages`, and unknown keys all preserved
    assert doc["mcpServers"]["coco"] == {"type": "stdio", "command": "coco"}
    assert doc["mcpServers"]["feishu"]["type"] == "http"
    assert doc["stages"] == {"PRD_DRAFTING": ["coco"]}
    assert doc["custom_key"] == 42


def test_delete_mcp_removes_http_and_prunes_stage_refs(tmp_path):
    repo_root = str(tmp_path)
    register_mcp(repo_root, {"name": "feishu", "url": "https://a"})
    register_mcp(repo_root, {"name": "lark", "url": "https://b"})
    path = mcp_path(repo_root)
    with open(path, "r", encoding="utf-8") as f:
        doc = json.load(f)
    doc["stages"] = {"PRD_DRAFTING": ["feishu", "lark"]}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(doc, f)
    saved, removed = delete_mcp(repo_root, "feishu")
    assert removed is True
    assert saved == path
    doc = _read(repo_root)
    assert "feishu" not in doc["mcpServers"]
    assert "lark" in doc["mcpServers"]
    assert doc["stages"] == {"PRD_DRAFTING": ["lark"]}


def test_delete_stdio_is_allowed(tmp_path):
    repo_root = str(tmp_path)
    os.makedirs(os.path.join(repo_root, ".harness"))
    with open(os.path.join(repo_root, ".harness", "mcp.json"), "w", encoding="utf-8") as f:
        json.dump({"mcpServers": {"coco": {"type": "stdio", "command": "coco"}}}, f)
    _, removed = delete_mcp(repo_root, "coco")
    assert removed is True
    doc = _read(repo_root)
    assert doc["mcpServers"] == {}


def test_delete_missing_returns_false(tmp_path):
    repo_root = str(tmp_path)
    register_mcp(repo_root, {"name": "feishu", "url": "https://a"})
    _, removed = delete_mcp(repo_root, "nonexistent")
    assert removed is False


def test_list_registered_reports_resolution(tmp_path):
    repo_root = str(tmp_path)
    register_mcp(repo_root, {"name": "ok-http", "transport": "http", "url": "https://example.com/mcp"})
    register_mcp(repo_root, {"name": "ok-stdio", "transport": "stdio", "command": "python"})
    register_mcp(repo_root, {"name": "bad-stdio", "transport": "stdio", "command": "definitely-not-a-real-binary-for-acp-tests"})
    entries = list_registered(repo_root)
    by_name = {e["name"]: e for e in entries}
    assert by_name["ok-http"]["resolved"] is True
    assert by_name["ok-http"]["transport"] == "http"
    assert by_name["ok-stdio"]["resolved"] is True
    assert by_name["ok-stdio"]["transport"] == "stdio"
    assert by_name["bad-stdio"]["resolved"] is False
