import json
import os

from acp.schema import HttpMcpServer, McpServerStdio, SseMcpServer

from core.mcp_config import (
    filter_session_mcp_servers_by_capability,
    filter_session_mcp_servers_by_enabled_tool_ids,
    load_effective_mcp_servers,
)


def _by_name(servers, name: str):
    for s in servers or []:
        if getattr(s, "name", None) == name:
            return s
    return None


def test_env_overrides_repo_by_name(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)
    monkeypatch.setenv(
        "HARNESS_MCP_SERVERS_JSON",
        json.dumps([{"name": "x", "type": "http", "url": "http://env"}]),
    )

    os.makedirs(tmp_path / ".harness", exist_ok=True)
    with open(tmp_path / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        json.dump({"mcpServers": {"x": {"type": "http", "url": "http://repo"}}}, f)

    servers = load_effective_mcp_servers(stage=None, workspace_folder=str(tmp_path))
    s = _by_name(servers, "x")
    assert isinstance(s, HttpMcpServer)
    assert s.url == "http://env"


def test_stage_allow_list_filters_defaults(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)

    os.makedirs(tmp_path / ".harness", exist_ok=True)
    with open(tmp_path / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "mcpServers": {
                    "a": {"type": "http", "url": "http://a"},
                    "b": {"type": "http", "url": "http://b"},
                },
                "stages": {"CODING": ["b"]},
            },
            f,
        )

    servers = load_effective_mcp_servers(stage="CODING", workspace_folder=str(tmp_path))
    names = [s.name for s in (servers or [])]
    assert names == ["b"]


def test_workspace_folder_substitution(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)

    os.makedirs(tmp_path / ".harness", exist_ok=True)
    with open(tmp_path / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "mcpServers": {
                    "local": {
                        "type": "stdio",
                        "command": "python",
                        "args": ["-m", "m", "--root", "${workspaceFolder}/workspace"],
                    }
                }
            },
            f,
        )

    servers = load_effective_mcp_servers(stage=None, workspace_folder=str(tmp_path))
    s = _by_name(servers, "local")
    assert isinstance(s, McpServerStdio)
    assert os.path.isabs(s.command)
    assert f"{str(tmp_path)}/workspace" in list(s.args or [])


def test_skip_invalid_server_entry(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)

    os.makedirs(tmp_path / ".harness", exist_ok=True)
    with open(tmp_path / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "mcpServers": {
                    "bad": {"type": "http"},
                    "good": {"type": "http", "url": "http://ok"},
                }
            },
            f,
        )

    servers = load_effective_mcp_servers(stage=None, workspace_folder=str(tmp_path))
    assert _by_name(servers, "bad") is None
    assert isinstance(_by_name(servers, "good"), HttpMcpServer)


def test_skip_unresolvable_stdio_server(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)

    os.makedirs(tmp_path / ".harness", exist_ok=True)
    with open(tmp_path / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "mcpServers": {
                    "bad-stdio": {"type": "stdio", "command": "definitely-not-a-real-binary-for-acp-tests"},
                    "good": {"type": "http", "url": "http://ok"},
                }
            },
            f,
        )

    servers = load_effective_mcp_servers(stage=None, workspace_folder=str(tmp_path))
    assert _by_name(servers, "bad-stdio") is None
    assert isinstance(_by_name(servers, "good"), HttpMcpServer)


def test_explicit_config_path_has_highest_file_precedence(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)

    home = tmp_path / "home"
    monkeypatch.setenv("HOME", str(home))
    os.makedirs(home / ".harness", exist_ok=True)
    with open(home / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        json.dump({"mcpServers": {"x": {"type": "http", "url": "http://user"}}}, f)

    os.makedirs(tmp_path / ".harness", exist_ok=True)
    with open(tmp_path / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        json.dump({"mcpServers": {"x": {"type": "http", "url": "http://repo"}}}, f)

    explicit = tmp_path / "explicit.json"
    with open(explicit, "w", encoding="utf-8") as f:
        json.dump({"mcpServers": {"x": {"type": "http", "url": "http://file"}}}, f)
    monkeypatch.setenv("HARNESS_MCP_CONFIG_PATH", str(explicit))

    servers = load_effective_mcp_servers(stage=None, workspace_folder=str(tmp_path))
    s = _by_name(servers, "x")
    assert isinstance(s, HttpMcpServer)
    assert s.url == "http://file"


def test_unreadable_or_invalid_json_file_does_not_fail(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)

    os.makedirs(tmp_path / ".harness", exist_ok=True)
    with open(tmp_path / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        f.write("{")

    servers = load_effective_mcp_servers(stage=None, workspace_folder=str(tmp_path))
    assert servers is None


def test_no_implicit_default_mcp_when_no_config(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_CONFIG_PATH", raising=False)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))

    servers = load_effective_mcp_servers(stage=None, workspace_folder=str(tmp_path))
    assert servers is None



def test_repo_stdio_entry_is_loaded_explicitly(tmp_path, monkeypatch):
    monkeypatch.delenv("HARNESS_MCP_SERVERS_JSON", raising=False)
    monkeypatch.delenv("HARNESS_MCP_SERVERS_BY_STAGE_JSON", raising=False)

    os.makedirs(tmp_path / ".harness", exist_ok=True)
    with open(tmp_path / ".harness" / "mcp.json", "w", encoding="utf-8") as f:
        json.dump(
            {"mcpServers": {"coco": {"type": "stdio", "command": "python", "args": ["-m", "http.server"]}}},
            f,
        )

    servers = load_effective_mcp_servers(stage=None, workspace_folder=str(tmp_path))
    s = _by_name(servers, "coco")
    assert isinstance(s, McpServerStdio)
    assert os.path.isabs(s.command)
    assert list(s.args or []) == ["-m", "http.server"]



def test_filter_session_mcp_servers_by_enabled_tool_ids_respects_stage_allowlist():
    servers = [
        McpServerStdio(name="local", command="/bin/echo", args=["ok"], env=[]),
        HttpMcpServer(name="remote-http", url="https://example.com/mcp", type="http", headers=[]),
    ]

    filtered, skipped = filter_session_mcp_servers_by_enabled_tool_ids(
        servers,
        enabled_tool_ids={"mcp:local"},
    )

    assert [s.name for s in (filtered or [])] == ["local"]
    assert skipped == [
        {
            "name": "remote-http",
            "transport": "http",
            "tool_id": "mcp:remote-http",
            "reason": "tool_not_enabled_for_stage",
        }
    ]



def test_filter_session_mcp_servers_by_enabled_tool_ids_is_noop_without_stage_config():
    servers = [
        McpServerStdio(name="local", command="/bin/echo", args=["ok"], env=[]),
        HttpMcpServer(name="remote-http", url="https://example.com/mcp", type="http", headers=[]),
    ]

    filtered, skipped = filter_session_mcp_servers_by_enabled_tool_ids(
        servers,
        enabled_tool_ids=None,
    )

    assert [s.name for s in (filtered or [])] == ["local", "remote-http"]
    assert skipped == []



def test_filter_session_mcp_servers_by_capability_keeps_stdio_only_when_http_sse_unsupported():
    servers = [
        McpServerStdio(name="local", command="/bin/echo", args=["ok"], env=[]),
        HttpMcpServer(name="remote-http", url="https://example.com/mcp", type="http", headers=[]),
        SseMcpServer(name="remote-sse", url="https://example.com/sse", type="sse", headers=[]),
    ]

    filtered, skipped = filter_session_mcp_servers_by_capability(
        servers,
        agent_capabilities={},
    )

    assert [s.name for s in (filtered or [])] == ["local"]
    assert skipped == [
        {"name": "remote-http", "transport": "http", "reason": "agent_missing_http_capability"},
        {"name": "remote-sse", "transport": "sse", "reason": "agent_missing_sse_capability"},
    ]
