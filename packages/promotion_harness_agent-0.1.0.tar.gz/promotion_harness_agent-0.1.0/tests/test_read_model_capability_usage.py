import json

from core.read_model.trace import capability_usage_for_stage


def test_capability_usage_for_stage_aggregates_allow_deny():
    events = [
        {
            "type": "capability_policy_decision",
            "state": "CODING",
            "ts": "t1",
            "data": {"resolved_capability": "fs.read", "decision": "allow", "kind": "read", "reason": "allowed"},
        },
        {
            "type": "capability_policy_decision",
            "state": "CODING",
            "ts": "t2",
            "data": {"resolved_capability": "fs.read", "decision": "allow", "kind": "read", "reason": "allowed"},
        },
        {
            "type": "capability_policy_decision",
            "state": "CODING",
            "ts": "t3",
            "data": {"resolved_capability": "terminal.cli", "decision": "deny", "kind": "execute", "reason": "outside_workspace"},
        },
        {
            "type": "capability_policy_decision",
            "state": "PRD_DRAFTING",
            "ts": "t4",
            "data": {"resolved_capability": "fs.read", "decision": "allow", "kind": "read", "reason": "allowed"},
        },
    ]

    out = capability_usage_for_stage(events, "CODING")
    assert [x["capability"] for x in out] == ["fs.read", "terminal.cli"]

    fs_read = out[0]
    assert fs_read["total"] == 2
    assert fs_read["allow"] == 2
    assert fs_read["deny"] == 0
    assert fs_read["kinds"]["read"] == 2

    term = out[1]
    assert term["total"] == 1
    assert term["allow"] == 0
    assert term["deny"] == 1
    assert term["reasons"]["outside_workspace"] == 1

