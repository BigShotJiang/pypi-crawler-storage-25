import os

from core.capability_registry import (
    ToolDescriptor,
    default_registry,
    evaluate_policy,
    normalize_terminal_request,
    normalize_tool_call,
    resolve_capability,
)
from core.harness_gate import default_gate


class _Tool:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


def test_policy_denies_high_risk_by_default(tmp_path, monkeypatch):
    d = ToolDescriptor(name="bash.execute", summary="x", kind="execute", risk_level="high")
    allowed, reason = evaluate_policy(d, "CODING", "execute", [], str(tmp_path))
    assert allowed is False
    assert reason == "high_risk_default_deny"


def test_policy_allows_high_risk_when_explicitly_enabled(tmp_path):
    d = ToolDescriptor(name="terminal.bash", summary="x", kind="execute", risk_level="high")
    allowed, reason = evaluate_policy(d, "CODING", "execute", [str(tmp_path / "workspace")], str(tmp_path), allow_high_risk=True)
    assert allowed is True
    assert reason == "allowed"


def test_policy_denies_outside_workspace(tmp_path):
    d = ToolDescriptor(name="fs.write", summary="x", kind="edit", policy_tags=("workspace_only",))
    allowed, reason = evaluate_policy(d, "CODING", "edit", ["/tmp/out.txt"], str(tmp_path))
    assert allowed is False
    assert reason == "outside_workspace"


def test_policy_allows_workspace_write(tmp_path):
    d = ToolDescriptor(name="fs.write", summary="x", kind="edit", policy_tags=("workspace_only",))
    inside = os.path.join(str(tmp_path), "workspace", "a.txt")
    allowed, reason = evaluate_policy(d, "CODING", "edit", [inside], str(tmp_path))
    assert allowed is True
    assert reason == "allowed"


def test_policy_denies_unknown_execute_capability(tmp_path):
    allowed, reason = evaluate_policy(None, "CODING", "execute", [], str(tmp_path))
    assert allowed is False
    assert reason == "unknown_execute_capability"


def test_policy_denies_unknown_mcp_capability(tmp_path):
    allowed, reason = evaluate_policy(None, "CODING", "mcp", [], str(tmp_path))
    assert allowed is False
    assert reason == "unknown_mcp_capability"


def test_policy_allows_terminal_execute_descriptor(tmp_path):
    d = ToolDescriptor(name="terminal.cli", summary="x", kind="execute", policy_tags=("workspace_only",))
    inside = os.path.join(str(tmp_path), "workspace")
    allowed, reason = evaluate_policy(d, "CODING", "execute", [inside], str(tmp_path))
    assert allowed is True
    assert reason == "allowed"


def test_resolve_pytest_terminal_capability(tmp_path):
    normalized = normalize_terminal_request("uv", ["run", "pytest", "-q"], os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name == "terminal.cli"
    assert resolved.intent_family == "generic"
    assert resolved.policy_context.get("binary") == "uv"
    assert resolved.policy_context.get("execution_mode") == "direct_cli"


def test_resolve_absolute_path_direct_cli(tmp_path):
    normalized = normalize_terminal_request("/opt/homebrew/bin/lark-cli", ["-h"], os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name == "terminal.cli"
    assert resolved.policy_context.get("binary") == "lark-cli"
    assert normalized.command == "/opt/homebrew/bin/lark-cli"


def test_resolve_env_prefixed_direct_cli(tmp_path):
    normalized = normalize_terminal_request("FOO=1 lark-cli -h", None, os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name == "terminal.cli"
    assert resolved.policy_context.get("binary") == "lark-cli"
    assert list(normalized.args) == ["-h"]


def test_resolve_shell_terminal_capability(tmp_path):
    normalized = normalize_terminal_request("bash", ["-lc", "echo hi"], os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name == "terminal.bash"
    assert resolved.policy_context.get("uses_shell") is True
    assert resolved.policy_context.get("execution_mode") == "shell_wrapper"


def test_resolve_compound_command_as_terminal_bash(tmp_path):
    normalized = normalize_terminal_request("cd workspace && lark-cli -h", None, os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name == "terminal.bash"
    assert resolved.policy_context.get("uses_shell") is True
    assert resolved.policy_context.get("is_compound") is True
    assert resolved.policy_context.get("execution_mode") == "compound_shell"


def test_resolve_repo_python_script_capability(tmp_path):
    normalized = normalize_terminal_request("python", ["tools/custom_feedback.py"], os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name == "tool.py_script"
    assert resolved.policy_context.get("uses_shell") is False
    assert resolved.policy_context.get("python_entry") == "tools/custom_feedback.py"


def test_resolve_repo_python_module_capability(tmp_path):
    normalized = normalize_terminal_request("python", ["-m", "tools.test_feedback"], os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name == "tool.py_script"
    assert resolved.policy_context.get("python_entry") == "tools.test_feedback"


def test_resolve_execute_without_command_is_unclassified(tmp_path):
    normalized = normalize_terminal_request(None, [], os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name is None
    assert resolved.resolution_reason == "unclassified_execute"
    assert resolved.policy_context.get("execution_mode") == "unknown_execute"


def test_resolve_malformed_command_string_is_unclassified(tmp_path):
    normalized = normalize_terminal_request("bash -lc 'echo hi", None, os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    assert resolved.capability_name is None
    assert resolved.policy_context.get("parse_confidence") == "low"


def test_pre_gate_allows_direct_cli_when_bash_enabled(tmp_path):
    normalized = normalize_terminal_request("git", ["remote", "-v"], os.path.join(str(tmp_path), "workspace"))
    resolved = resolve_capability(default_registry(), normalized)
    allowed, reason = default_gate().evaluate_pre_policy(
        descriptor=resolved.descriptor,
        stage="CODING",
        kind=normalized.normalized_kind,
        paths=[os.path.join(str(tmp_path), "workspace")],
        workspace_root=str(tmp_path),
        resolved_capability=resolved.capability_name,
        policy_context=resolved.policy_context,
        tool_id="cli:git",
        enabled_tool_ids={"bash:shell"},
    )
    assert allowed is True
    assert reason == "allowed"


def test_normalize_tool_call_reads_uppercase_command_field(tmp_path):
    tool = _Tool(kind="execute", raw_input={"Command": "lark-cli --help"}, title="run lark-cli")
    normalized = normalize_tool_call(tool, paths=[os.path.join(str(tmp_path), "workspace")])
    resolved = resolve_capability(default_registry(), normalized)
    assert normalized.command == "lark-cli"
    assert list(normalized.args) == ["--help"]
    assert resolved.capability_name == "terminal.cli"
    assert resolved.policy_context.get("binary") == "lark-cli"


def test_normalize_tool_call_infers_edit_kind_from_title():
    tool = _Tool(title="Write")
    normalized = normalize_tool_call(tool)
    resolved = resolve_capability(default_registry(), normalized)
    assert normalized.normalized_kind == "edit"
    assert resolved.capability_name == "fs.write"


def test_normalize_tool_call_does_not_infer_from_mcp_prefixed_title_only():
    tool = _Tool(title="mcp__coco__Write")
    normalized = normalize_tool_call(tool)
    assert normalized.normalized_kind == "unknown"
