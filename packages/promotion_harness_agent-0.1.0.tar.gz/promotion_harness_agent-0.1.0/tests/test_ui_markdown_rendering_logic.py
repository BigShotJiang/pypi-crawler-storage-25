from ui_artifacts import load_artifact_preview


def test_markdown_artifact_has_md_extension(tmp_path):
    p = tmp_path / "workspace" / "docs" / "prd.md"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("# Title\n\nHello\n", encoding="utf-8")
    preview = load_artifact_preview(str(p))
    assert preview["type"] == "file"
    assert preview["ext"] == ".md"
