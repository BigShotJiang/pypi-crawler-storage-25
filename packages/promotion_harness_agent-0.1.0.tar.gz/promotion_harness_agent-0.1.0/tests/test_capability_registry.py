from core.capability_registry import CapabilityRegistry, ToolDescriptor, default_registry


def test_registry_list_for_stage_returns_all_tools():
    r = CapabilityRegistry()
    r.register(ToolDescriptor(name="a", summary="a", kind="read"))
    r.register(ToolDescriptor(name="b", summary="b", kind="read"))
    assert [t.name for t in r.list_for_stage("X")] == ["a", "b"]
    assert [t.name for t in r.list_for_stage("Y")] == ["a", "b"]


def test_advertise_returns_markdown_and_payload():
    r = default_registry()
    md, payload = r.advertise_for_stage("CODING")
    assert "Available Capabilities" in md
    assert payload["stage"] == "CODING"
    assert any(t["name"] == "fs.write" for t in payload["tools"])
    assert any(t["name"] == "terminal.cli" for t in payload["tools"])


def test_terminal_advertised_for_prd_stage():
    r = default_registry()
    _, payload = r.advertise_for_stage("PRD_DRAFTING")
    assert any(t["name"] == "terminal.cli" for t in payload["tools"])
