import json
import os

import pytest

from core.acp_agent import HarnessClientImpl
from core.run_trace import init_trace
from tests.runtime_fixtures import seed_active_run


class _Update:
    def __init__(self, payload: dict):
        self._payload = payload
        self.session_update = payload.get("session_update")

    def model_dump(self):
        return self._payload


@pytest.mark.asyncio
async def test_session_update_emits_tool_call_events(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r1", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")

    c = HarnessClientImpl([], workspace_root=str(tmp_path), repo_root=str(tmp_path))
    await c.session_update("sess1", _Update({
        "session_update": "tool_call",
        "tool_call_id": "call_1",
        "title": "Read file",
        "kind": "read",
        "status": "pending",
        "raw_input": {"path": ".harness/runs/r1/docs/prd.md"},
    }))
    await c.session_update("sess1", _Update({
        "session_update": "tool_call_update",
        "tool_call_id": "call_1",
        "status": "completed",
        "raw_output": {"ok": True, "text": "x" * 5000},
        "content": [{"type": "content", "content": {"type": "text", "text": "done"}}],
    }))

    trace_path = run_dir / "trace.ndjson"
    lines = trace_path.read_text(encoding="utf-8").splitlines()
    events = [json.loads(l) for l in lines if l.strip()]
    tool_events = [e for e in events if e.get("type") in {"acp_tool_call", "acp_tool_call_update"}]
    assert len(tool_events) == 2
    assert tool_events[0]["state"] == "CODING"
    assert tool_events[0]["data"]["tool_call_id"] == "call_1"
    assert "raw_input_summary" in tool_events[0]["data"]
    assert len(tool_events[1]["data"]["raw_output_summary"]) <= 2000
    assert c.pending_tool_calls == {}


@pytest.mark.asyncio
async def test_session_update_summarizes_non_text_content_blocks(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r1", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")

    c = HarnessClientImpl([], workspace_root=str(tmp_path), repo_root=str(tmp_path))
    await c.session_update("sess1", _Update({
        "session_update": "tool_call_update",
        "tool_call_id": "call_2",
        "status": "completed",
        "content": [
            {
                "type": "content",
                "content": {
                    "type": "resource_link",
                    "uri": "file:///tmp/example.py",
                    "name": "example.py",
                    "mimeType": "text/x-python",
                },
            },
            {
                "type": "content",
                "content": {
                    "type": "resource",
                    "resource": {
                        "uri": "file:///tmp/data.txt",
                        "mimeType": "text/plain",
                        "text": "hello world",
                    },
                },
            },
        ],
    }))

    trace_path = run_dir / "trace.ndjson"
    events = [json.loads(l) for l in trace_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    tool_events = [e for e in events if e.get("type") == "acp_tool_call_update"]
    assert tool_events[-1]["data"]["content_summary"] == [
        {
            "type": "resource_link",
            "uri": "file:///tmp/example.py",
            "name": "example.py",
            "mimeType": "text/x-python",
            "path": os.path.realpath("/tmp/example.py"),
        },
        {
            "type": "resource",
            "uri": "file:///tmp/data.txt",
            "mimeType": "text/plain",
            "text_preview": "hello world",
            "text_length": 11,
            "path": os.path.realpath("/tmp/data.txt"),
        },
    ]


@pytest.mark.asyncio
async def test_session_update_extracts_structured_skill_identity(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r1", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")

    c = HarnessClientImpl([], workspace_root=str(tmp_path), repo_root=str(tmp_path))
    await c.session_update("sess1", _Update({
        "session_update": "tool_call",
        "tool_call_id": "call_skill_1",
        "title": "skill",
        "kind": "skill",
        "status": "in_progress",
    }))
    await c.session_update("sess1", _Update({
        "session_update": "tool_call_update",
        "tool_call_id": "call_skill_1",
        "status": "completed",
        "content": [
            {
                "type": "content",
                "content": {
                    "type": "text",
                    "text": json.dumps({"name": "lark-doc", "path": "/Users/bytedance/.trae/skills/lark-doc"}, ensure_ascii=False),
                },
            }
        ],
    }))

    trace_path = run_dir / "trace.ndjson"
    events = [json.loads(l) for l in trace_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    tool_events = [e for e in events if e.get("type") in {"acp_tool_call", "acp_tool_call_update"}]
    assert tool_events[1]["data"]["observed_name"] == "lark-doc"
    assert tool_events[1]["data"]["observed_tool_id"] == "skill:lark-doc"
    assert tool_events[1]["data"]["observed_capability"] == "tool.skill"
    assert tool_events[1]["data"]["observed_tool_label"] == "lark-doc"


@pytest.mark.asyncio
async def test_cancel_pending_tool_calls_emits_cancelled_update(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r1", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")

    updates: list[dict] = []
    c = HarnessClientImpl(updates, workspace_root=str(tmp_path), repo_root=str(tmp_path))
    await c.session_update("sess1", _Update({
        "session_update": "tool_call",
        "tool_call_id": "call_1",
        "title": "Read file",
        "kind": "read",
        "status": "pending",
    }))

    cancelled = c.cancel_pending_tool_calls("sess1")

    assert cancelled == [{
        "sessionUpdate": "tool_call_update",
        "toolCallId": "call_1",
        "status": "failed",
        "title": "Read file",
        "kind": "read",
        "_meta": {"harness": {"cancelled": True, "synthetic": True, "reason": "prompt_turn_cancelled"}},
        "content": [{"type": "content", "content": {"type": "text", "text": "Tool call cancelled because the current prompt turn was cancelled."}}],
    }]
    assert updates[-1]["status"] == "failed"
    assert updates[-1]["_meta"]["harness"]["cancelled"] is True

    trace_path = run_dir / "trace.ndjson"
    events = [json.loads(l) for l in trace_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    assert events[-1]["type"] == "acp_tool_call_update"
    assert events[-1]["data"]["status"] == "failed"
    assert events[-1]["data"]["status_display"] == "cancelled"
    assert events[-1]["data"]["cancelled"] is True


@pytest.mark.asyncio
async def test_session_update_emits_session_info_update_events(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r1", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")

    c = HarnessClientImpl([], workspace_root=str(tmp_path), repo_root=str(tmp_path))
    c.seed_session_info("sess1", str(tmp_path.resolve()))
    await c.session_update("sess1", _Update({
        "session_update": "session_info_update",
        "title": "Implement session list API",
        "updatedAt": "2026-04-12T10:00:00Z",
        "_meta": {"messageCount": 12},
    }))

    trace_path = run_dir / "trace.ndjson"
    lines = trace_path.read_text(encoding="utf-8").splitlines()
    events = [json.loads(l) for l in lines if l.strip()]
    info_events = [e for e in events if e.get("type") == "acp_session_info_update"]
    assert len(info_events) == 1
    assert info_events[0]["data"]["session_id"] == "sess1"
    assert info_events[0]["data"]["title"] == "Implement session list API"
    assert c.get_session_info("sess1") == {
        "sessionId": "sess1",
        "cwd": str(tmp_path.resolve()),
        "title": "Implement session list API",
        "updatedAt": "2026-04-12T10:00:00Z",
        "_meta": {"messageCount": 12},
    }


@pytest.mark.asyncio
async def test_session_update_agent_thought_chunk_is_traced_and_preserved(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r1", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")

    updates: list[dict] = []
    c = HarnessClientImpl(updates, workspace_root=str(tmp_path), repo_root=str(tmp_path))
    payload = {
        "sessionUpdate": "agent_thought_chunk",
        "content": {"type": "text", "text": "thinking..."},
    }

    await c.session_update("sess1", _Update(payload))

    assert updates[-1]["sessionUpdate"] == "agent_thought_chunk"
    assert updates[-1]["content"]["type"] == "text"

    trace_path = run_dir / "trace.ndjson"
    events = [json.loads(l) for l in trace_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    chunk_events = [e for e in events if e.get("type") == "acp_content_chunk" and e.get("state") == "CODING"]
    assert len(chunk_events) == 1
    data = chunk_events[0].get("data") or {}
    assert data.get("session_id") == "sess1"
    assert data.get("kind") == "agent_thought_chunk"
    assert (data.get("content_summary") or {}).get("type") == "text"
