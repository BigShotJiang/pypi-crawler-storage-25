import json
import os

import pytest

from core.cli_registry import (
    CliRegistryError,
    cli_tools_path,
    delete_cli,
    list_registered,
    register_cli,
)


def _read(repo_root: str):
    path = cli_tools_path(repo_root)
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def test_register_cli_creates_file_and_entry(tmp_path):
    repo_root = str(tmp_path)
    saved, created = register_cli(
        repo_root,
        {"name": "lark-cli", "command": "lark-cli", "summary": "Fetch Lark"},
    )
    assert created is True
    assert saved == cli_tools_path(repo_root)
    items = _read(repo_root)
    assert len(items) == 1
    assert items[0]["name"] == "lark-cli"
    assert "usage" not in items[0], "legacy `usage` field must NOT be written back"


def test_register_strips_legacy_usage_from_existing_file(tmp_path):
    repo_root = str(tmp_path)
    os.makedirs(os.path.join(repo_root, ".harness"))
    with open(os.path.join(repo_root, ".harness", "cli_tools.json"), "w", encoding="utf-8") as f:
        json.dump(
            [{"name": "legacy", "command": "echo", "summary": "old", "usage": "echo hi"}], f
        )
    register_cli(repo_root, {"name": "new-one", "command": "true", "summary": ""})
    items = _read(repo_root)
    by_name = {it["name"]: it for it in items}
    assert "legacy" in by_name and "usage" not in by_name["legacy"]
    assert "new-one" in by_name


def test_register_duplicate_without_overwrite_errors(tmp_path):
    repo_root = str(tmp_path)
    register_cli(repo_root, {"name": "lark-cli", "command": "lark-cli", "summary": ""})
    with pytest.raises(CliRegistryError) as exc:
        register_cli(repo_root, {"name": "lark-cli", "command": "lark-cli2", "summary": ""})
    assert "duplicate_name" in str(exc.value)


def test_register_duplicate_with_overwrite_updates(tmp_path):
    repo_root = str(tmp_path)
    register_cli(repo_root, {"name": "lark-cli", "command": "v1", "summary": "s1"})
    _, created = register_cli(
        repo_root,
        {"name": "lark-cli", "command": "v2", "summary": "s2"},
        overwrite=True,
    )
    assert created is False
    items = _read(repo_root)
    assert len(items) == 1
    assert items[0]["command"] == "v2"
    assert items[0]["summary"] == "s2"


def test_validation_rejects_bad_name(tmp_path):
    with pytest.raises(CliRegistryError):
        register_cli(str(tmp_path), {"name": "bad name with space", "command": "x"})
    with pytest.raises(CliRegistryError):
        register_cli(str(tmp_path), {"name": "", "command": "x"})
    with pytest.raises(CliRegistryError):
        register_cli(str(tmp_path), {"name": "ok", "command": ""})
    with pytest.raises(CliRegistryError):
        register_cli(str(tmp_path), {"name": "ok", "command": "x", "risk_level": "extreme"})


def test_delete_cli_removes_entry(tmp_path):
    repo_root = str(tmp_path)
    register_cli(repo_root, {"name": "a", "command": "a"})
    register_cli(repo_root, {"name": "b", "command": "b"})
    saved, removed = delete_cli(repo_root, "a")
    assert removed is True
    assert saved == cli_tools_path(repo_root)
    items = _read(repo_root)
    assert [it["name"] for it in items] == ["b"]


def test_delete_cli_missing_returns_false(tmp_path):
    repo_root = str(tmp_path)
    register_cli(repo_root, {"name": "a", "command": "a"})
    _, removed = delete_cli(repo_root, "nonexistent")
    assert removed is False


def test_list_registered_reports_resolution(tmp_path):
    repo_root = str(tmp_path)
    # `sh` is essentially always on PATH; use a clearly bogus command for missing.
    register_cli(repo_root, {"name": "sh-tool", "command": "sh", "summary": "shell"})
    register_cli(
        repo_root, {"name": "missing-tool", "command": "definitely-not-a-real-binary-xyz", "summary": ""}
    )
    entries = list_registered(repo_root)
    by_name = {e["name"]: e for e in entries}
    assert by_name["sh-tool"]["resolved"] is True
    assert by_name["missing-tool"]["resolved"] is False
