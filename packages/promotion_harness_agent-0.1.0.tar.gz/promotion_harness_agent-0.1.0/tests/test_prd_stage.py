import json
import os
import shutil
import pytest

from core.context_manager import ContextManager
from core.orchestrator import FlowState
from agents.trae_prd_agent import trae_prd_agent
from core.runtime_paths import runtime_paths_for_run
from tests.runtime_fixtures import build_runtime_ctx
from ui_trace import read_stage_prompt_snapshot, stage_context_snapshot_ref


class _StubAgent:
    def __init__(self, root: str, error: str | None = None, *, write_stage_output: bool = True):
        self.root = root
        self.error = error
        self.write_stage_output = write_stage_output
        self.prompt_text = None
        self.cwd = None

    def run_task(self, prompt_text: str, cwd: str, stage: str | None = None):
        self.prompt_text = prompt_text
        self.cwd = cwd
        if self.error:
            return {"updates": [], "final_response": None, "error": self.error}
        marker = next((line for line in prompt_text.splitlines() if "HARNESS_REQUIREMENT:" in line), "")
        prd_path = os.path.join(self.root, ".harness", "runs", "run-test", "docs", "prd.md")
        os.makedirs(os.path.dirname(prd_path), exist_ok=True)
        with open(prd_path, "w", encoding="utf-8") as f:
            f.write(f"# PRD\n\n{marker}\n\n## 背景\n\n测试内容\n")
        if self.write_stage_output:
            stage_output_path = os.path.join(self.root, ".harness", "runs", "run-test", "stage_outputs", "PRD_DRAFTING.json")
            os.makedirs(os.path.dirname(stage_output_path), exist_ok=True)
            with open(stage_output_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "schema_version": 1,
                        "stage": "PRD_DRAFTING",
                        "status": "completed",
                        "summary": "PRD 已生成。",
                        "artifacts": [
                            {
                                "artifact_type": "prd",
                                "path": ".harness/runs/run-test/docs/prd.md",
                                "absolute_path": prd_path,
                                "exists": True,
                                "is_dir": False,
                                "size_bytes": os.path.getsize(prd_path),
                                "summary": "当前阶段生成的 PRD 文档。",
                            }
                        ],
                        "key_points": ["artifact_path=.harness/runs/run-test/docs/prd.md"],
                        "evidence": ["file_exists=True"],
                        "metadata": {"artifact_key": "prd"},
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
        return {"updates": [], "final_response": {"stop_reason": "end_turn"}, "error": None}


def _build_ctx(tmp_path, requirement: str):
    ctx, _ = build_runtime_ctx(tmp_path, requirement=requirement)
    return ctx


def test_prd_stage_writes_artifact_and_returns_next_state(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "请为一个在线课程平台生成PRD")
    paths = runtime_paths_for_run("run-test", str(tmp_path))
    target = tmp_path / paths.run_root_relative / "docs" / "prd.md"
    stub = _StubAgent(str(tmp_path))

    monkeypatch.setattr("agents.trae_prd_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_prd_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.TECH_SPEC_DRAFTING
    assert ctx.context["artifacts"]["prd"] == ".harness/runs/run-test/docs/prd.md"
    assert target.exists()
    assert "在线课程平台" in stub.prompt_text
    assert "<!-- HARNESS_REQUIREMENT:请为一个在线课程平台生成PRD -->" in target.read_text(encoding="utf-8")
    assert str(target) in stub.prompt_text
    assert stub.cwd == str(tmp_path)
    stage_output_file = tmp_path / paths.run_root_relative / "stage_outputs" / "PRD_DRAFTING.json"
    assert stage_output_file.exists()
    snapshot_ref = stage_context_snapshot_ref(ctx.context["metadata"], FlowState.PRD_DRAFTING.value)
    assert snapshot_ref is not None
    assert snapshot_ref.get("prompt_path")
    prompt_snapshot = read_stage_prompt_snapshot(ctx.context["metadata"], FlowState.PRD_DRAFTING.value)
    assert "请作为产品经理" in prompt_snapshot
    assert "不要改用通用网页抓取工具去追登录页" in prompt_snapshot
    assert "授权阻塞信号（最高优先级" in prompt_snapshot
    assert "auth_block.json" in prompt_snapshot


def test_prd_stage_records_error_when_agent_fails(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "失败场景")
    target = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    stub = _StubAgent(str(tmp_path), error="permission denied")

    monkeypatch.setattr("agents.trae_prd_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_prd_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert ctx.context["metadata"]["last_error_log"] == "AcpAgent run_task returned error: permission denied"
    assert not target.exists()


def test_prd_stage_succeeds_even_when_model_does_not_write_stage_output_json(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "缺少 stage output")
    stub = _StubAgent(str(tmp_path), write_stage_output=False)
    monkeypatch.setattr("agents.trae_prd_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_prd_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.TECH_SPEC_DRAFTING
    assert ctx.context["artifacts"]["prd"] == ".harness/runs/run-test/docs/prd.md"
    assert "last_noncompliance" not in ctx.context["metadata"]


class _AuthBlockingAgent:
    """Stub ACP agent that simulates the model writing auth_block.json and no PRD."""

    def __init__(self, run_dir: str):
        self.run_dir = run_dir
        self.prompt_text = None

    def run_task(self, prompt_text: str, cwd: str, stage: str | None = None):
        self.prompt_text = prompt_text
        os.makedirs(self.run_dir, exist_ok=True)
        import json as _json

        payload = {
            "type": "auth_required",
            "stage": "PRD_DRAFTING",
            "tool": "lark-cli",
            "auth_url": "https://accounts.feishu.cn/open-apis/authen/v1/authorize?x=1",
            "message": "I have no permission to access lark.",
            "cli_help": "lark-cli auth login --scope docs:read",
        }
        with open(os.path.join(self.run_dir, "auth_block.json"), "w", encoding="utf-8") as f:
            _json.dump(payload, f)
        return {"updates": [], "final_response": {"stop_reason": "end_turn"}, "error": None}


def test_prd_stage_blocks_on_auth_signal(tmp_path, monkeypatch):
    ctx = _build_ctx(tmp_path, "请根据下面的飞书链接生成PRD")
    prd_target = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        # Pre-compute the run_dir that build_full_context will use so the stub writes to the right place.
        # Prepare the stage context first to obtain the auth_block_abs_path.
        stage_ctx = ctx.prepare_stage_context(FlowState.PRD_DRAFTING.value, repo_root=str(tmp_path))
        auth_path = stage_ctx["prompt_inputs"]["auth_block_abs_path"]
        stub = _AuthBlockingAgent(os.path.dirname(auth_path))
        monkeypatch.setattr("agents.trae_prd_agent.AcpAgent", lambda: stub)

        next_state = trae_prd_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.AUTH_BLOCKED
    meta = ctx.context["metadata"]
    assert meta.get("run_outcome") == "auth_blocked"
    assert isinstance(meta.get("auth_block"), dict)
    assert meta["auth_block"]["type"] == "auth_required"
    assert "auth_url" in meta["auth_block"]
    assert meta["last_error_log"].startswith("BLOCKED_AUTH")
    assert not prd_target.exists()


@pytest.mark.skipif(shutil.which("coco") is None, reason="coco binary not found in PATH")
def test_prd_stage_generates_prd_via_real_coco(tmp_path):
    ctx = _build_ctx(tmp_path, "请为一个在线课程平台生成PRD")
    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_prd_agent(ctx)
    finally:
        os.chdir(cwd)

    target = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    assert next_state == FlowState.TECH_SPEC_DRAFTING
    assert ctx.context["artifacts"]["prd"] == ".harness/runs/run-test/docs/prd.md"
    assert target.exists()
    content = target.read_text(encoding="utf-8").strip()
    assert content != ""
    assert "<!-- HARNESS_REQUIREMENT:请为一个在线课程平台生成PRD -->" in content
