import json
import os

from core.context_manager import ContextManager
from core.orchestrator import FlowState, Orchestrator
from ui_trace import read_stage_context_snapshot, read_stage_prompt_snapshot, stage_context_snapshot_ref


def _build_ctx(tmp_path):
    ctx = ContextManager(str(tmp_path / ".harness" / "runs" / "run-test" / "progress.json"), repo_root=str(tmp_path))
    ctx.update_metadata("requirement", "实现一个加法功能")
    ctx.update_metadata("run_id", "run-test")
    ctx.update_metadata("run_dir", ".harness/runs/run-test")
    return ctx


def test_prepare_stage_context_persists_full_and_stage_snapshots(tmp_path):
    ctx = _build_ctx(tmp_path)
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")
    ctx.add_artifact("prd", ".harness/runs/run-test/docs/prd.md")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        stage_ctx = ctx.prepare_stage_context(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
        prompt = ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    refs = ctx.context["metadata"]["context_snapshots"][FlowState.TECH_SPEC_DRAFTING.value]
    full_ref = ctx.context["metadata"]["context_snapshots"]["full"]
    assert os.path.exists(refs["ctx_path"])
    assert os.path.exists(full_ref["ctx_path"])
    assert os.path.exists(refs["prompt_path"])
    assert "PRD 内容开始" in prompt
    assert "【授权阻塞信号（最高优先级" in prompt
    assert stage_ctx["artifacts"]["prd"]["content"].startswith("# PRD")

    with open(full_ref["ctx_path"], "r", encoding="utf-8") as f:
        full_ctx = json.load(f)
    assert full_ctx["request"]["raw_requirement"] == "实现一个加法功能"


def test_orchestrator_prepares_stage_context_before_handler(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.set_state(FlowState.PLANNING.value)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")
    ctx.add_artifact("tech_spec", ".harness/runs/run-test/docs/tech_spec.md")

    orch = Orchestrator(ctx)

    def planning_handler(cm):
        prepared = cm.get_stage_context(FlowState.PLANNING.value)
        assert prepared is not None
        assert prepared["stage"] == FlowState.PLANNING.value
        assert prepared["artifacts"]["tech_spec"]["exists"] is True
        return FlowState.FINISHED

    orch.register_handler(FlowState.PLANNING, planning_handler)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        orch.run()
    finally:
        os.chdir(cwd)

    refs = ctx.context["metadata"]["context_snapshots"][FlowState.PLANNING.value]
    assert os.path.exists(refs["ctx_path"])
    assert ctx.get_state() == FlowState.FINISHED.value


def test_ui_trace_can_read_stage_context_and_prompt(tmp_path):
    ctx = _build_ctx(tmp_path)
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")
    ctx.add_artifact("prd", ".harness/runs/run-test/docs/prd.md")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        ctx.prepare_stage_context(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
        ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    metadata = ctx.context["metadata"]
    ref = stage_context_snapshot_ref(metadata, FlowState.TECH_SPEC_DRAFTING.value)
    assert ref is not None

    stage_ctx = read_stage_context_snapshot(metadata, FlowState.TECH_SPEC_DRAFTING.value)
    prompt = read_stage_prompt_snapshot(metadata, FlowState.TECH_SPEC_DRAFTING.value)
    assert stage_ctx is not None
    assert stage_ctx["stage"] == FlowState.TECH_SPEC_DRAFTING.value
    assert "Tech Spec" in prompt


def test_ui_trace_can_read_prompt_from_prompt_snapshots_only(tmp_path):
    ctx = _build_ctx(tmp_path)
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")
    ctx.add_artifact("prd", ".harness/runs/run-test/docs/prd.md")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        ctx.prepare_stage_context(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
        ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    metadata = ctx.context["metadata"]
    metadata["context_snapshots"][FlowState.TECH_SPEC_DRAFTING.value].pop("prompt_path", None)
    prompt = read_stage_prompt_snapshot(metadata, FlowState.TECH_SPEC_DRAFTING.value)
    assert "Tech Spec" in prompt


def test_coding_context_exposes_stage_output_path_and_quality_loop_reads_run_stage_output(tmp_path):
    ctx = _build_ctx(tmp_path)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")
    ctx.add_artifact("tech_spec", ".harness/runs/run-test/docs/tech_spec.md")
    stage_output_dir = tmp_path / ".harness" / "runs" / "run-test" / "stage_outputs"
    stage_output_dir.mkdir(parents=True, exist_ok=True)
    (tmp_path / "src").mkdir(parents=True, exist_ok=True)
    (tmp_path / "tests").mkdir(parents=True, exist_ok=True)
    (tmp_path / "src" / "app.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / "tests" / "test_app.py").write_text("def test_ok():\n    assert True\n", encoding="utf-8")
    (stage_output_dir / "CODING.json").write_text(
        json.dumps(
            {
                "schema_version": 1,
                "stage": "CODING",
                "status": "pass",
                "summary": "coding done",
                "artifacts": [
                    {
                        "artifact_type": "code_root",
                        "path": "src",
                        "absolute_path": str(tmp_path / "src"),
                        "exists": True,
                        "is_dir": True,
                        "size_bytes": 0,
                        "summary": "src dir",
                    },
                    {
                        "artifact_type": "tests_root",
                        "path": "tests",
                        "absolute_path": str(tmp_path / "tests"),
                        "exists": True,
                        "is_dir": True,
                        "size_bytes": 0,
                        "summary": "tests dir",
                    },
                ],
                "key_points": ["artifact_count=2"],
                "evidence": ["workspace ready"],
                "metadata": {
                    "artifact_key": "code_root",
                    "changed_files": ["src/app.py", "tests/test_app.py"],
                    "branch_name": "feature/test-run",
                    "commit_sha": "abc123",
                    "mr_url": "https://example.com/mr/1",
                },
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        coding_ctx = ctx.prepare_stage_context(FlowState.CODING.value, repo_root=os.getcwd())
        quality_ctx = ctx.prepare_stage_context(FlowState.QUALITY_LOOP.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert coding_ctx["prompt_inputs"]["stage_output_abs_path"].endswith(".harness/runs/run-test/stage_outputs/CODING.json")
    assert quality_ctx["prompt_inputs"]["validated_stage_result"]["stage"] == "CODING"
    assert {item["artifact_type"] for item in quality_ctx["prompt_inputs"]["validated_stage_artifacts"]} == {"code_root", "tests_root"}


def test_stage_tool_config_filters_tool_catalog_in_prompt_chain(tmp_path, monkeypatch):
    # Isolate user config so the real ~/.harness/stage_tools.json doesn't leak in.
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    # Arrange: create a discoverable CLI entry and enable it only for CODING stage.
    (tmp_path / ".harness").mkdir(parents=True, exist_ok=True)
    (tmp_path / ".harness" / "cli_tools.json").write_text(
        json.dumps(
            [
                {
                    "name": "echo",
                    "command": "echo",
                    "summary": "Echo CLI (test)",
                    "stages": ["CODING"],
                    "risk_level": "low",
                }
            ],
            indent=2,
        ),
        encoding="utf-8",
    )
    (tmp_path / ".harness" / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"CODING": ["cli:echo", "bash:shell"]}}, indent=2),
        encoding="utf-8",
    )

    ctx = _build_ctx(tmp_path)
    ctx.set_state(FlowState.CODING.value)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")
    ctx.add_artifact("tech_spec", ".harness/runs/run-test/docs/tech_spec.md")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        stage_ctx = ctx.prepare_stage_context(FlowState.CODING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    payload = stage_ctx["capabilities"]["tool_catalog_payload"]
    entries = payload.get("entries") or []
    # Only the enabled tools should be present (filtered by stage_tools.json).
    assert any(e.get("tool_id") == "cli:echo" for e in entries)
    assert any(e.get("tool_id") == "bash:shell" for e in entries)


def test_render_stage_prompt_flattens_nested_last_gate_denial(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("last_noncompliance", {
        "stage": FlowState.PRD_DRAFTING.value,
        "kind": "tool_gate",
        "reason": "tool_not_enabled_for_stage",
        "details": {
            "last_gate_denial": {
                "stage": FlowState.PRD_DRAFTING.value,
                "reason": "tool_not_enabled_for_stage",
                "suggestion": "Use cli:lark-cli instead.",
                "details": {
                    "tool_id": "cli:git",
                    "resolved_capability": "terminal.cli",
                    "enabled_tool_ids": ["cli:lark-cli", "cli:bytedcli"],
                },
            }
        },
        "suggestion": "Fix tool usage.",
    })
    ctx.context["metadata"]["stage_retry_count"] = {FlowState.PRD_DRAFTING.value: 1}
    ctx.context["metadata"]["max_stage_retries"] = 2

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "如果存在本节，表示上一次运行已被 Harness 准出/门禁规则拦截。" in prompt
    assert "Denied tool_id: cli:git" in prompt
    assert "Resolved capability: terminal.cli" in prompt
    assert "Allowed tools for this stage:" in prompt
    assert "cli:lark-cli" in prompt
    assert "Do not retry unlisted direct CLI or shell commands." in prompt
    assert "Suggestion: Use cli:lark-cli instead." in prompt
    assert "【宪法层】" in prompt


def test_render_stage_prompt_injects_full_acceptance_feedback(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("last_noncompliance", {
        "ts": "2026-04-28T10:11:12Z",
        "stage": FlowState.PRD_DRAFTING.value,
        "kind": "acceptance_verification",
        "reason": "acceptance_failed",
        "details": {
            "acceptance_result": {
                "summary": "PRD 有产物，但证据链不完整。",
                "missing_items": ["缺少 lark-cli 证据", "缺少 bytedcli 证据"],
                "findings": ["来源与引用章节已存在", "requirement marker 已保留"],
                "suggested_fix": "补齐证据并补来源风险说明。",
            }
        },
        "suggestion": "补齐证据链。",
    })
    ctx.context["metadata"]["stage_retry_count"] = {FlowState.PRD_DRAFTING.value: 1}
    ctx.context["metadata"]["max_stage_retries"] = 3

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "【上次 Harness 准出拒绝详情（必须逐项修复）】" in prompt
    assert "Summary: PRD 有产物，但证据链不完整。" in prompt
    assert "Missing items:" in prompt
    assert "缺少 lark-cli 证据" in prompt
    assert "缺少 bytedcli 证据" in prompt
    assert "Findings:" in prompt
    assert "来源与引用章节已存在" in prompt
    assert "requirement marker 已保留" in prompt
    assert "Suggested fix: 补齐证据并补来源风险说明。" in prompt

    retry_context = ctx.context["metadata"]["stage_retry_context"][FlowState.PRD_DRAFTING.value]
    assert retry_context["source"] == "last_noncompliance"
    assert retry_context["record_stage"] == FlowState.PRD_DRAFTING.value
    assert retry_context["record_timestamp"] == "2026-04-28T10:11:12Z"
    assert retry_context["retry_count"] == 1
    assert retry_context["injected_fields"] == ["summary", "missing_items", "findings", "suggested_fix"]
    assert retry_context["record_snapshot"]["details"]["acceptance_result"]["summary"] == "PRD 有产物，但证据链不完整。"


def test_render_stage_prompt_injects_factual_stage_output_noncompliance_feedback(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("last_noncompliance", {
        "ts": "2026-04-30T09:20:14Z",
        "stage": FlowState.TECH_SPEC_DRAFTING.value,
        "kind": "stage_output_validation",
        "reason": "stage_output_validation_failed",
        "details": {
            "error": "stage_output_artifact_empty: tech_spec",
            "error_code": "artifact_empty",
            "error_message": "未读取到符合要求的非空产物文件。",
            "artifact_type": "tech_spec",
            "error_details": {
                "stage": "TECH_SPEC_DRAFTING",
                "artifact_type": "tech_spec",
                "declared_path": "docs/tech_spec.md",
                "declared_absolute_path": "/tmp/.harness/runs/run-test/docs/tech_spec.md",
                "declared_exists": True,
                "declared_is_dir": False,
                "declared_size_bytes": None,
            },
            "stage_output": {
                "stage": "TECH_SPEC_DRAFTING",
                "artifacts": [
                    {
                        "artifact_type": "tech_spec",
                        "path": "docs/tech_spec.md",
                        "absolute_path": "/tmp/.harness/runs/run-test/docs/tech_spec.md",
                        "exists": True,
                        "is_dir": False,
                        "size_bytes": None,
                    }
                ],
            },
        },
        "suggestion": "修正节点输出 JSON 或产物文件后重试。",
    })
    ctx.context["metadata"]["stage_retry_count"] = {FlowState.TECH_SPEC_DRAFTING.value: 1}
    ctx.context["metadata"]["max_stage_retries"] = 3

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "如果存在本节，表示上一次运行已被 Harness 准出/门禁规则拦截。" in prompt
    assert "non_compliance_reason: stage_output_validation_failed" in prompt
    assert "【上次 Harness 非合规事实记录（必须先满足）】" in prompt
    assert "Reason: stage_output_validation_failed" in prompt
    assert "Error code: artifact_empty" in prompt
    assert "Message: 未读取到符合要求的非空产物文件。" in prompt
    assert "Validation error: stage_output_artifact_empty: tech_spec" in prompt
    assert "Affected artifact_type: tech_spec" in prompt
    assert "- declared_path: docs/tech_spec.md" in prompt
    assert "- declared_absolute_path: /tmp/.harness/runs/run-test/docs/tech_spec.md" in prompt
    assert "- declared_exists: True" in prompt
    assert "- declared_is_dir: False" in prompt
    assert "- declared_size_bytes: None" in prompt
    assert "Required StageOutput schema:" in prompt
    assert "Observed mismatch:" in prompt
    assert "Referenced artifact paths must already exist on disk and be non-empty" in prompt
    assert "Minimal valid JSON example:" in prompt

    retry_context = ctx.context["metadata"]["stage_retry_context"][FlowState.TECH_SPEC_DRAFTING.value]
    assert retry_context["injected_fields"] == ["non_compliance_reason", "error_code", "error_message", "error", "artifact_type", "error_details"]


def test_render_stage_prompt_includes_initial_stage_output_contract(tmp_path):
    ctx = _build_ctx(tmp_path)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "【StageOutput JSON 写法（首次生成就必须满足）】" in prompt
    assert "`schema_version` must be integer `1`." in prompt
    assert "`artifacts` must be a non-empty array of artifact objects, not a single object." in prompt
    assert "Minimal valid JSON example:" in prompt
    assert '"stage": "PRD_DRAFTING"' in prompt
    assert '"artifact_type": "prd"' in prompt


def test_render_stage_prompt_clears_retry_injection_when_acceptance_feedback_missing(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.context["metadata"]["stage_retry_context"] = {
        FlowState.PRD_DRAFTING.value: {"source": "last_noncompliance", "injected_fields": ["summary"]}
    }
    ctx.update_metadata("last_noncompliance", {
        "stage": FlowState.PRD_DRAFTING.value,
        "kind": "tool_gate",
        "reason": "tool_not_enabled_for_stage",
        "details": {},
    })
    ctx.context["metadata"]["stage_retry_count"] = {FlowState.PRD_DRAFTING.value: 2}

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        ctx.render_and_persist_stage_prompt(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert FlowState.PRD_DRAFTING.value not in ctx.context["metadata"]["stage_retry_context"]


def test_render_stage_prompt_keeps_retry_injection_for_stage_output_validation(tmp_path):
    ctx = _build_ctx(tmp_path)
    ctx.update_metadata("last_noncompliance", {
        "stage": FlowState.TECH_SPEC_DRAFTING.value,
        "kind": "stage_output_validation",
        "reason": "stage_output_validation_failed",
        "details": {
            "error": "stage_output_artifact_empty: tech_spec",
            "error_code": "artifact_empty",
            "error_message": "未读取到符合要求的非空产物文件。",
            "artifact_type": "tech_spec",
            "error_details": {
                "declared_path": "docs/tech_spec.md",
            },
            "stage_output": {
                "artifacts": [
                    {
                        "artifact_type": "tech_spec",
                        "path": "docs/tech_spec.md",
                    }
                ]
            },
        },
    })
    ctx.context["metadata"]["stage_retry_count"] = {FlowState.TECH_SPEC_DRAFTING.value: 1}

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    retry_context = ctx.context["metadata"]["stage_retry_context"][FlowState.TECH_SPEC_DRAFTING.value]
    assert retry_context["injected_fields"] == ["non_compliance_reason", "error_code", "error_message", "error", "artifact_type", "error_details"]


def test_render_stage_prompt_injects_user_context_policy_block(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    (tmp_path / ".harness").mkdir(parents=True, exist_ok=True)
    (tmp_path / ".harness" / "cli_tools.json").write_text(
        json.dumps(
            [
                {
                    "name": "lark-cli",
                    "command": "echo",
                    "summary": "Read Lark docs",
                    "stages": ["PRD_DRAFTING"],
                    "risk_level": "low",
                }
            ],
            indent=2,
        ),
        encoding="utf-8",
    )
    (tmp_path / ".harness" / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"PRD_DRAFTING": ["cli:lark-cli"]}}, indent=2),
        encoding="utf-8",
    )

    ctx = _build_ctx(tmp_path)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(
            FlowState.PRD_DRAFTING.value,
            repo_root=os.getcwd(),
            policy_rules_override=[{"use_tool_id": "cli:lark-cli", "do": "优先读取文档正文并提炼重点"}],
        )
    finally:
        os.chdir(cwd)

    assert "【用户自定义工具策略（USE/DO）】" in prompt
    assert "USE: cli:lark-cli" in prompt
    assert "DO: 优先读取文档正文并提炼重点" in prompt
    assert "【授权阻塞信号（最高优先级，满足条件即唯一产物，写完立刻退出）】" in prompt
    assert "HARNESS_REQUIREMENT" in prompt
    assert "【意图层】" in prompt


def test_prepare_stage_context_records_user_context_policy_rules(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    (tmp_path / ".harness").mkdir(parents=True, exist_ok=True)
    (tmp_path / ".harness" / "cli_tools.json").write_text(
        json.dumps(
            [
                {
                    "name": "lark-cli",
                    "command": "echo",
                    "summary": "Read Lark docs",
                    "stages": ["PRD_DRAFTING"],
                    "risk_level": "low",
                }
            ],
            indent=2,
        ),
        encoding="utf-8",
    )
    (tmp_path / ".harness" / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"PRD_DRAFTING": ["cli:lark-cli"]}}, indent=2),
        encoding="utf-8",
    )

    ctx = _build_ctx(tmp_path)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        stage_ctx = ctx.prepare_stage_context(
            FlowState.PRD_DRAFTING.value,
            repo_root=os.getcwd(),
            policy_rules_override=[{"use_tool_id": "cli:lark-cli", "do": "优先读取文档正文"}],
        )
    finally:
        os.chdir(cwd)

    assert stage_ctx["user_context_policy"]["supported"] is True
    assert stage_ctx["user_context_policy"]["rules"] == [
        {"use_tool_id": "cli:lark-cli", "do": "优先读取文档正文"}
    ]


def test_render_stage_prompt_uses_three_layer_order_and_agents_md(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    (tmp_path / "AGENTS.md").write_text("## Repo Rules\n\n- follow harness\n", encoding="utf-8")
    (tmp_path / ".harness").mkdir(parents=True, exist_ok=True)
    (tmp_path / ".harness" / "cli_tools.json").write_text(
        json.dumps(
            [
                {
                    "name": "lark-cli",
                    "command": "echo",
                    "summary": "Read Lark docs",
                    "stages": ["PRD_DRAFTING"],
                    "risk_level": "low",
                }
            ],
            indent=2,
        ),
        encoding="utf-8",
    )
    (tmp_path / ".harness" / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"PRD_DRAFTING": ["cli:lark-cli"]}}, indent=2),
        encoding="utf-8",
    )
    ctx = _build_ctx(tmp_path)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(
            FlowState.PRD_DRAFTING.value,
            repo_root=os.getcwd(),
            policy_rules_override=[{"use_tool_id": "cli:lark-cli", "do": "先读正文"}],
            output_requirements_override="必须包含目标和范围",
            tool_instructions_override="优先使用 MCP",
            requirement_override="这是预览态需求",
        )
    finally:
        os.chdir(cwd)

    assert prompt.index("【宪法层】") < prompt.index("【规范层】") < prompt.index("【意图层】")
    assert "AGENTS.md 绝对路径：" in prompt
    assert str((tmp_path / "AGENTS.md").resolve()) in prompt
    assert "【用户配置的产出物要求】" in prompt
    assert "必须包含目标和范围" in prompt
    assert "【用户配置的工具调用指令】" in prompt
    assert "优先使用 MCP" in prompt
    assert "用户原始需求：这是预览态需求" in prompt


def test_render_stage_prompt_omits_regulatory_layer_when_empty_and_handles_missing_agents(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    ctx = _build_ctx(tmp_path)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "【规范层】" not in prompt
    assert "AGENTS.md 绝对路径：" not in prompt


def test_render_stage_prompt_omits_empty_agents_md_section(tmp_path):
    (tmp_path / "AGENTS.md").write_text("", encoding="utf-8")
    ctx = _build_ctx(tmp_path)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "AGENTS.md 绝对路径：" in prompt
    assert str((tmp_path / "AGENTS.md").resolve()) in prompt


def test_prd_prompt_omits_input_priority_contract(tmp_path):
    """PRD 阶段是信息采集源头，不应被输入优先级契约约束。"""
    ctx = _build_ctx(tmp_path)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.PRD_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "输入来源优先级" not in prompt
    assert "PRIMARY（权威来源）" not in prompt


def test_tech_spec_prompt_contains_input_priority_contract(tmp_path):
    """TECH_SPEC 阶段必须带有输入优先级契约，优先用 workspace 内容，兜底才查外部链接。"""
    ctx = _build_ctx(tmp_path)
    prd = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "prd.md"
    prd.parent.mkdir(parents=True, exist_ok=True)
    prd.write_text("# PRD\n\n内容\n", encoding="utf-8")
    ctx.add_artifact("prd", ".harness/runs/run-test/docs/prd.md")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.TECH_SPEC_DRAFTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "输入来源优先级" in prompt
    assert "PRIMARY（权威来源）" in prompt
    assert "SECONDARY（兜底来源）" in prompt
    assert "不允许\"为了保险再看一眼\"式的重复拉取" in prompt


def test_coding_prompt_contains_input_priority_contract(tmp_path):
    """CODING 阶段必须带有输入优先级契约。"""
    ctx = _build_ctx(tmp_path)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")
    ctx.add_artifact("tech_spec", ".harness/runs/run-test/docs/tech_spec.md")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.CODING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "输入来源优先级" in prompt
    assert "PRIMARY（权威来源）" in prompt
    assert "不要主动执行 gofmt、go test、go build 等高耗时命令作为默认步骤" in prompt


def test_quality_loop_prompt_contains_input_priority_contract(tmp_path):
    """QUALITY_LOOP 阶段必须带有输入优先级契约。"""
    ctx = _build_ctx(tmp_path)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    quality_report = tmp_path / ".harness" / "runs" / "run-test" / "outputs" / "quality_report.json"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    quality_report.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")
    quality_report.write_text('{"status":"pending"}', encoding="utf-8")
    ctx.add_artifact("tech_spec", ".harness/runs/run-test/docs/tech_spec.md")
    ctx.add_artifact("quality_report", ".harness/runs/run-test/outputs/quality_report.json")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.QUALITY_LOOP.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "输入来源优先级" in prompt
    assert "PRIMARY（权威来源）" in prompt
    assert "不要主动执行 gofmt、go test、go build 等高耗时命令作为默认步骤" in prompt


def test_fixing_prompt_contains_input_priority_contract(tmp_path):
    """FIXING 阶段必须带有输入优先级契约。"""
    ctx = _build_ctx(tmp_path)
    tech_spec = tmp_path / ".harness" / "runs" / "run-test" / "docs" / "tech_spec.md"
    tech_spec.parent.mkdir(parents=True, exist_ok=True)
    tech_spec.write_text("## Tech Spec\n", encoding="utf-8")
    ctx.add_artifact("tech_spec", ".harness/runs/run-test/docs/tech_spec.md")
    ctx.update_metadata("last_error_log", "some error")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.FIXING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "输入来源优先级" in prompt
    assert "PRIMARY（权威来源）" in prompt


def test_deploying_prompt_contains_input_priority_contract_and_auth_block(tmp_path):
    ctx = _build_ctx(tmp_path)
    deploy_report = tmp_path / ".harness" / "runs" / "run-test" / "outputs" / "deploy_report.json"
    deploy_report.parent.mkdir(parents=True, exist_ok=True)
    deploy_report.write_text('{"status":"pending"}', encoding="utf-8")
    ctx.add_artifact("deploy_report", ".harness/runs/run-test/outputs/deploy_report.json")
    ctx.update_metadata("deploy_targets", ["BOE", "PPE"])
    ctx.update_metadata("deploy_status", "blocked")

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.DEPLOYING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "输入来源优先级" in prompt
    assert "BOE、PPE" in prompt
    assert "auth_block.json" in prompt
    assert "DEPLOYING.json" in prompt
    assert "deploy_report 至少要包含：`env_name`, `env_url`, `branch_name`, `psm`, `status`, `summary`" in prompt


def test_regression_prompt_contains_input_priority_contract_and_cases(tmp_path):
    ctx = _build_ctx(tmp_path)
    regression_report = tmp_path / ".harness" / "runs" / "run-test" / "outputs" / "regression_report.json"
    regression_report.parent.mkdir(parents=True, exist_ok=True)
    regression_report.write_text('{"status":"pending"}', encoding="utf-8")
    ctx.add_artifact("regression_report", ".harness/runs/run-test/outputs/regression_report.json")
    ctx.update_metadata("deploy_targets", ["BOE"])
    ctx.update_metadata("regression_test_cases", ["case-a", "case-b"])

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        prompt = ctx.render_and_persist_stage_prompt(FlowState.REGRESSION_TESTING.value, repo_root=os.getcwd())
    finally:
        os.chdir(cwd)

    assert "输入来源优先级" in prompt
    assert "case-a" in prompt
    assert "回归测试代理" in prompt
    assert "REGRESSION_TESTING.json" in prompt
    assert "regression_report 至少要包含：`env_name`, `env_url`, `test_cases`, `results` 或 `endpoint_results`, `final_verdict`, `summary`" in prompt
