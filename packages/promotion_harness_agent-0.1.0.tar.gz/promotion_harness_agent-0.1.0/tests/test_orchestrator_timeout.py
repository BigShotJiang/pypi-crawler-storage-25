import time

from core.orchestrator import FlowState, Orchestrator
from tests.runtime_fixtures import build_runtime_ctx


def test_orchestrator_stage_timeout_fails_run(tmp_path):
    ctx, _ = build_runtime_ctx(tmp_path, state=FlowState.CODING.value)
    ctx.set_state(FlowState.CODING.value)
    ctx.update_metadata("stage_timeouts_sec", {FlowState.CODING.value: 0.01})

    orch = Orchestrator(ctx)

    def slow_handler(_):
        time.sleep(0.2)
        return FlowState.QUALITY_LOOP

    orch.register_handler(FlowState.CODING, slow_handler)
    orch.run()

    assert ctx.get_state() == FlowState.FAILED.value
    assert "stage timeout" in ctx.context["metadata"].get("last_error_log", "")


def test_prd_and_spec_default_timeout_is_10min(tmp_path):
    ctx, _ = build_runtime_ctx(tmp_path)
    orch = Orchestrator(ctx)

    assert orch._get_stage_timeout_sec(FlowState.PRD_DRAFTING.value) == 600.0
    assert orch._get_stage_timeout_sec(FlowState.TECH_SPEC_DRAFTING.value) == 600.0
