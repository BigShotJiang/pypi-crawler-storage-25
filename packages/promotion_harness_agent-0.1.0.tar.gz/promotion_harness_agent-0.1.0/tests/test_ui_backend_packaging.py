from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from ui_backend.app import app
from ui_backend.paths import frontend_static_root, repo_root


def test_repo_root_defaults_to_cwd(monkeypatch, tmp_path):
    monkeypatch.delenv("HARNESS_REPO_ROOT", raising=False)
    monkeypatch.chdir(tmp_path)
    assert repo_root() == str(tmp_path.resolve())


def test_frontend_static_root_prefers_packaged_static(monkeypatch, tmp_path):
    package_dir = tmp_path / "ui_backend"
    packaged_static = package_dir / "static"
    source_dist = tmp_path / "ui_frontend" / "dist"
    packaged_static.mkdir(parents=True)
    source_dist.mkdir(parents=True)
    (packaged_static / "index.html").write_text("packaged", encoding="utf-8")
    (source_dist / "index.html").write_text("source", encoding="utf-8")

    import ui_backend.paths as paths_module

    monkeypatch.setattr(paths_module, "__file__", str(package_dir / "paths.py"))
    assert frontend_static_root() == str(packaged_static)


def test_ui_serves_packaged_static_and_spa_fallback(monkeypatch, tmp_path):
    package_dir = tmp_path / "ui_backend"
    packaged_static = package_dir / "static"
    assets_dir = packaged_static / "assets"
    assets_dir.mkdir(parents=True)
    index_path = packaged_static / "index.html"
    asset_path = assets_dir / "app.js"
    index_path.write_text("<html><body>ui</body></html>", encoding="utf-8")
    asset_path.write_text("console.log('ok')", encoding="utf-8")

    import ui_backend.paths as paths_module

    monkeypatch.setattr(paths_module, "__file__", str(package_dir / "paths.py"))

    client = TestClient(app)

    root = client.get("/")
    assert root.status_code == 200
    assert "<html><body>ui</body></html>" in root.text

    asset = client.get("/assets/app.js")
    assert asset.status_code == 200
    assert "console.log('ok')" in asset.text

    fallback = client.get("/settings")
    assert fallback.status_code == 200
    assert "<html><body>ui</body></html>" in fallback.text

    api_route = client.get("/api")
    assert api_route.status_code == 404
