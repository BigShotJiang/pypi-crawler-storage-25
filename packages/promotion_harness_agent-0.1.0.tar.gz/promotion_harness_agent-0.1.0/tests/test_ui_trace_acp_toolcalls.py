import json

from ui_trace import acp_tool_calls_for_stage


def _safe_string(x):
    return x if isinstance(x, str) else ''


def _parse_raw_input_summary(raw):
    if not raw:
        return {}
    if isinstance(raw, dict):
        return raw
    if not isinstance(raw, str):
        return {}
    try:
        parsed = json.loads(raw)
    except Exception:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _infer_terminal_capability(command):
    trimmed = command.strip()
    lower = trimmed.lower()
    if not trimmed:
        return 'terminal.cli'
    if lower.startswith('bash ') or lower.startswith('sh ') or lower.startswith('zsh '):
        return 'terminal.bash'
    if '&&' in trimmed or '||' in trimmed or ';' in trimmed or '|' in trimmed:
        return 'terminal.bash'
    return 'terminal.cli'


def _first_command_token(command):
    trimmed = command.strip()
    if not trimmed:
        return ''
    parts = trimmed.split()
    return parts[0] if parts else ''


def _basename_like(value):
    trimmed = value.strip()
    if not trimmed:
        return ''
    parts = [p for p in trimmed.split('/') if p]
    return parts[-1] if parts else trimmed


def _extract_named_tool_from_text(text):
    raw = _safe_string(text).strip()
    if not raw:
        return ''
    try:
        parsed = json.loads(raw)
    except Exception:
        parsed = None
    if isinstance(parsed, dict):
        return _safe_string(parsed.get('name')).strip()
    match = __import__('re').search(r'"name"\s*:\s*"([^"\\]+)"', raw)
    return _safe_string(match.group(1) if match else '').strip()


def _infer_observed_tool_label(ev, capability):
    d = ev.get('data') or {}
    if ev.get('type') in {'capability_policy_decision', 'acp_permission'}:
        policy_context = d.get('policy_context') or {}
        command = _safe_string(policy_context.get('command') or policy_context.get('original_command'))
        binary = _safe_string(policy_context.get('binary'))
        if capability in {'terminal.cli', 'terminal.bash'}:
            return _basename_like(binary or _first_command_token(command)) or capability
        if capability in {'fs.read', 'fs.write'}:
            paths = d.get('paths') if isinstance(d.get('paths'), list) else []
            path = _safe_string(paths[0] if paths else '')
            return _basename_like(path) or capability
        if capability == 'tool.skill':
            return _safe_string(policy_context.get('skill_name') or policy_context.get('name') or '').strip() or capability
        if capability == 'tool.mcp':
            return _safe_string(policy_context.get('mcp_name') or policy_context.get('name') or '').strip() or capability
        return capability

    if ev.get('type') in {'acp_fs_read', 'acp_fs_write'}:
        path = _safe_string(d.get('path') or d.get('target_path') or d.get('resolved_path') or '')
        return _basename_like(path) or capability

    raw_input = _parse_raw_input_summary(d.get('raw_input_summary'))
    title = _safe_string(d.get('title')).strip()
    command = _safe_string(raw_input.get('Command') or raw_input.get('command') or raw_input.get('cmd'))
    path = _safe_string(raw_input.get('path') or raw_input.get('Path') or '')
    observed_name = _safe_string(d.get('observed_name')).strip()
    observed_tool_id = _safe_string(d.get('observed_tool_id')).strip()
    observed_tool_label = _safe_string(d.get('observed_tool_label')).strip()
    observed_tool_name = observed_tool_id.split(':', 1)[1] if ':' in observed_tool_id else ''

    if observed_tool_label:
        return observed_tool_label

    if capability in {'terminal.cli', 'terminal.bash'}:
        return _basename_like(_first_command_token(command) or title) or capability
    if capability in {'fs.read', 'fs.write'}:
        return _basename_like(path) or title or capability
    if capability in {'tool.skill', 'tool.mcp'}:
        content_summary = d.get('content_summary') if isinstance(d.get('content_summary'), list) else []
        from_summary = ''
        for item in content_summary:
            if not isinstance(item, dict):
                continue
            from_summary = _extract_named_tool_from_text(item.get('text_preview'))
            if from_summary:
                break
        return observed_name or observed_tool_name or from_summary or _extract_named_tool_from_text(d.get('content_excerpt')) or title or capability
    return title or capability


def _infer_capability_from_observed_tool_call(ev):
    d = ev.get('data') or {}
    observed_capability = _safe_string(d.get('observed_capability')).strip()
    if observed_capability:
        return observed_capability

    kind = _safe_string(d.get('kind')).lower()
    title = _safe_string(d.get('title')).strip().lower()
    first_token = title.split()[0] if title else ''
    raw_input = _parse_raw_input_summary(d.get('raw_input_summary'))
    command = _safe_string(raw_input.get('Command') or raw_input.get('command') or raw_input.get('cmd'))

    if kind in {'read', 'search'}:
        return 'fs.read'
    if kind in {'edit', 'move', 'delete'}:
        return 'fs.write'
    if kind == 'execute':
        return _infer_terminal_capability(command)
    if command:
        return _infer_terminal_capability(command)
    if first_token in {'read', 'ls', 'grep', 'glob'}:
        return 'fs.read'
    if first_token in {'write', 'edit', 'apply_patch', 'applypatch'}:
        return 'fs.write'
    if first_token == 'skill':
        return 'tool.skill'
    return ''


def _create_tool_stats():
    return {'allow': 0, 'deny': 0, 'observed': 0, 'gatedObserved': 0, 'observedOnly': 0, 'unknownObserved': 0, 'lastReason': ''}



def _create_cap_stats(cap):
    return {
        'capability': cap,
        'allow': 0,
        'deny': 0,
        'observed': 0,
        'gatedObserved': 0,
        'observedOnly': 0,
        'unknownObserved': 0,
        'reasons': {},
        'lastReason': '',
        'tools': {},
    }



def _add_observed_evidence(item, tool, provenance):
    item['observed'] += 1
    if provenance == 'gated':
        item['gatedObserved'] += 1
    elif provenance == 'observed_only':
        item['observedOnly'] += 1
    else:
        item['unknownObserved'] += 1
    if not tool:
        return
    tool_item = item['tools'].setdefault(tool, _create_tool_stats())
    tool_item['observed'] += 1
    if provenance == 'gated':
        tool_item['gatedObserved'] += 1
    elif provenance == 'observed_only':
        tool_item['observedOnly'] += 1
    else:
        tool_item['unknownObserved'] += 1



def _aggregate_used_capabilities(stage_events):
    by_cap = {}
    gate_evidence = set()
    unknown_evidence_caps = set()

    def mark_gate_evidence(cap, tool):
        if cap and tool:
            gate_evidence.add(f'{cap}::{tool}')
        elif cap:
            unknown_evidence_caps.add(cap)

    for ev in stage_events:
        d = ev.get('data') or {}
        cap = ''
        decision = ''
        reason = ''
        if ev.get('type') == 'capability_policy_decision':
            cap = str(d.get('resolved_capability') or d.get('tool_name') or 'unknown')
            decision = str(d.get('decision') or '')
            reason = str(d.get('reason') or '')
        elif ev.get('type') == 'acp_fs_read':
            cap = 'fs.read'
            decision = 'deny' if str(d.get('result') or '') == 'deny' else 'allow'
            reason = str(d.get('reason') or d.get('error') or '')
        elif ev.get('type') == 'acp_fs_write':
            cap = 'fs.write'
            decision = 'deny' if str(d.get('result') or '') == 'deny' else 'allow'
            reason = str(d.get('reason') or d.get('error') or '')
        elif ev.get('type') == 'acp_permission':
            cap = str(d.get('resolved_capability') or d.get('tool_name') or 'unknown')
            decision = str(d.get('decision') or '')
            reason = str(d.get('reason') or '')
        else:
            continue
        item = by_cap.setdefault(cap, _create_cap_stats(cap))
        if decision == 'allow':
            item['allow'] += 1
        if decision == 'deny':
            item['deny'] += 1
        tool = _infer_observed_tool_label(ev, cap)
        if tool:
            tool_item = item['tools'].setdefault(tool, _create_tool_stats())
            if decision == 'allow':
                tool_item['allow'] += 1
            if decision == 'deny':
                tool_item['deny'] += 1
            if reason:
                tool_item['lastReason'] = reason
        if reason:
            item['reasons'][reason] = item['reasons'].get(reason, 0) + 1
            item['lastReason'] = reason
        mark_gate_evidence(cap, tool)

    observed_calls = {}
    observed_anonymous = []
    for ev in stage_events:
        if ev.get('type') not in {'acp_tool_call', 'acp_tool_call_update'}:
            continue
        data = ev.get('data') or {}
        tool_call_id = _safe_string(data.get('tool_call_id')).strip()
        if not tool_call_id:
            observed_anonymous.append(ev)
            continue
        prev = observed_calls.get(tool_call_id) or {'type': 'acp_tool_call', 'data': {'tool_call_id': tool_call_id}}
        prev_data = prev.get('data') or {}
        observed_calls[tool_call_id] = {
            'type': 'acp_tool_call',
            'data': {
                **prev_data,
                **data,
                'tool_call_id': tool_call_id,
                'title': data.get('title') if data.get('title') is not None else prev_data.get('title'),
                'kind': data.get('kind') if data.get('kind') is not None else prev_data.get('kind'),
                'raw_input_summary': data.get('raw_input_summary') if data.get('raw_input_summary') is not None else prev_data.get('raw_input_summary'),
                'observed_name': data.get('observed_name') if data.get('observed_name') is not None else prev_data.get('observed_name'),
                'observed_tool_id': data.get('observed_tool_id') if data.get('observed_tool_id') is not None else prev_data.get('observed_tool_id'),
                'observed_capability': data.get('observed_capability') if data.get('observed_capability') is not None else prev_data.get('observed_capability'),
                'observed_tool_label': data.get('observed_tool_label') if data.get('observed_tool_label') is not None else prev_data.get('observed_tool_label'),
                'content_summary': data.get('content_summary') if data.get('content_summary') is not None else prev_data.get('content_summary'),
                'content_excerpt': data.get('content_excerpt') if data.get('content_excerpt') is not None else prev_data.get('content_excerpt'),
            },
        }

    for ev in [*observed_calls.values(), *observed_anonymous]:
        cap = _infer_capability_from_observed_tool_call(ev)
        if not cap:
            continue
        item = by_cap.setdefault(cap, _create_cap_stats(cap))
        tool = _infer_observed_tool_label(ev, cap)
        provenance = 'unknown'
        if tool and f'{cap}::{tool}' in gate_evidence:
            provenance = 'gated'
        elif tool:
            provenance = 'observed_only'
        elif cap in unknown_evidence_caps:
            provenance = 'unknown'
        _add_observed_evidence(item, tool, provenance)

    return sorted(by_cap.values(), key=lambda item: item['allow'] + item['deny'] + item['observed'], reverse=True)


def test_group_acp_tool_calls_by_id():
    events = [
        {"type": "acp_tool_call", "state": "CODING", "ts": "t1", "data": {"tool_call_id": "c1", "title": "read", "kind": "read", "status": "pending"}},
        {"type": "acp_tool_call_update", "state": "CODING", "ts": "t2", "data": {"tool_call_id": "c1", "status": "completed", "content_excerpt": "ok", "content_summary": [{"type": "resource_link", "uri": "file:///repo/src/a.py", "name": "a.py"}]}},
        {"type": "acp_tool_call", "state": "CODING", "ts": "t3", "data": {"tool_call_id": "c2", "title": "write", "kind": "edit", "status": "pending"}},
    ]
    grouped = acp_tool_calls_for_stage(events, "CODING")
    assert [g["tool_call_id"] for g in grouped] == ["c1", "c2"]
    assert grouped[0]["latest_status"] == "completed"
    assert grouped[0]["content_summary"] == [{"type": "resource_link", "uri": "file:///repo/src/a.py", "name": "a.py"}]


def test_group_acp_tool_calls_prefers_display_status():
    events = [
        {
            "type": "acp_tool_call_update",
            "state": "CODING",
            "ts": "t1",
            "data": {
                "tool_call_id": "c1",
                "status": "failed",
                "status_display": "cancelled",
            },
        }
    ]

    grouped = acp_tool_calls_for_stage(events, "CODING")

    assert grouped[0]["latest_status"] == "cancelled"



def test_usage_aggregation_keeps_observed_tool_calls_when_explicit_events_exist():
    events = [
        {
            "type": "capability_policy_decision",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {
                "resolved_capability": "terminal.cli",
                "decision": "allow",
                "reason": "enabled_by_stage_config",
                "policy_context": {"binary": "lark-cli", "command": "lark-cli docs +fetch"},
            },
        },
        {
            "type": "acp_fs_write",
            "state": "PRD_DRAFTING",
            "ts": "t2",
            "data": {"path": "/repo/.harness/runs/run-1/docs/prd.md", "result": "ok"},
        },
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t3",
            "data": {
                "tool_call_id": "c1",
                "title": "bash",
                "raw_input_summary": json.dumps({"Command": "bytedcli -h"}),
            },
        },
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t4",
            "data": {
                "tool_call_id": "c2",
                "title": "bash",
                "raw_input_summary": json.dumps({"Command": "bytedcli codebase repo -h"}),
            },
        },
    ]

    aggregated = _aggregate_used_capabilities(events)
    by_cap = {item['capability']: item for item in aggregated}

    assert 'terminal.cli' in by_cap
    assert 'fs.write' in by_cap
    assert by_cap['terminal.cli']['allow'] == 1
    assert by_cap['terminal.cli']['observed'] == 2
    assert by_cap['terminal.cli']['tools']['lark-cli']['allow'] == 1
    assert by_cap['terminal.cli']['tools']['bytedcli']['observed'] == 2
    assert by_cap['fs.write']['allow'] == 1



def test_usage_aggregation_prefers_structured_skill_name_for_tool_skill():
    events = [
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {
                "tool_call_id": "skill-1",
                "title": "skill",
                "kind": None,
                "status": "in_progress",
            },
        },
        {
            "type": "acp_tool_call_update",
            "state": "PRD_DRAFTING",
            "ts": "t2",
            "data": {
                "tool_call_id": "skill-1",
                "title": None,
                "kind": "skill",
                "status": "completed",
                "observed_name": "lark-doc",
                "observed_tool_id": "skill:lark-doc",
                "content_excerpt": json.dumps({"name": "lark-doc"}),
            },
        }
    ]

    aggregated = _aggregate_used_capabilities(events)
    by_cap = {item['capability']: item for item in aggregated}
    assert by_cap['tool.skill']['observed'] == 1
    assert by_cap['tool.skill']['tools']['lark-doc']['observed'] == 1



def test_usage_aggregation_normalizes_terminal_cli_paths():
    events = [
        {
            "type": "capability_policy_decision",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {
                "resolved_capability": "terminal.cli",
                "decision": "allow",
                "reason": "enabled_by_stage_config",
                "policy_context": {
                    "binary": "/opt/homebrew/bin/lark-cli",
                    "command": "/opt/homebrew/bin/lark-cli docs +fetch",
                },
            },
        },
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t2",
            "data": {
                "tool_call_id": "c1",
                "title": "bash",
                "raw_input_summary": json.dumps({"Command": "/opt/homebrew/bin/lark-cli docs +fetch"}),
            },
        },
    ]

    aggregated = _aggregate_used_capabilities(events)
    by_cap = {item['capability']: item for item in aggregated}
    assert by_cap['terminal.cli']['tools']['lark-cli']['allow'] == 1
    assert by_cap['terminal.cli']['tools']['lark-cli']['observed'] == 1
    assert '/opt/homebrew/bin/lark-cli' not in by_cap['terminal.cli']['tools']


def test_usage_aggregation_prefers_backend_emitted_observed_fields_over_heuristics():
    events = [
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {
                "tool_call_id": "py-1",
                "title": "bash",
                "kind": "execute",
                "status": "completed",
                "raw_input_summary": json.dumps({"Command": "python3 -c 'import os; print(1)'"}),
                "observed_capability": "terminal.cli",
                "observed_tool_label": "python3",
            },
        }
    ]

    aggregated = _aggregate_used_capabilities(events)
    by_cap = {item['capability']: item for item in aggregated}

    assert by_cap['terminal.cli']['observed'] == 1
    assert by_cap['terminal.cli']['tools']['python3']['observed'] == 1
    assert 'terminal.bash' not in by_cap



def test_usage_aggregation_does_not_guess_mcp_from_getdocument_title():
    events = [
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {
                "tool_call_id": "doc-1",
                "title": "GetDocument",
                "kind": None,
                "status": "completed",
                "raw_input_summary": json.dumps({"URL": "https://example.com/docx/abc"}),
            },
        }
    ]

    aggregated = _aggregate_used_capabilities(events)

    assert aggregated == []



def test_usage_aggregation_marks_observed_only_when_gate_evidence_is_missing():
    events = [
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {
                "tool_call_id": "shell-1",
                "title": "bash",
                "kind": "execute",
                "status": "completed",
                "raw_input_summary": json.dumps({"Command": "bytedcli codebase --help && bytedcli codebase repo --help"}),
                "observed_capability": "terminal.bash",
                "observed_tool_label": "shell",
            },
        }
    ]

    aggregated = _aggregate_used_capabilities(events)
    by_cap = {item['capability']: item for item in aggregated}

    assert by_cap['terminal.bash']['observed'] == 1
    assert by_cap['terminal.bash']['observedOnly'] == 1
    assert by_cap['terminal.bash']['gatedObserved'] == 0
    assert by_cap['terminal.bash']['tools']['shell']['observedOnly'] == 1



def test_usage_aggregation_marks_observed_call_gated_when_matching_permission_exists():
    events = [
        {
            "type": "acp_permission",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {
                "resolved_capability": "terminal.cli",
                "decision": "allow",
                "policy_context": {"binary": "lark-cli", "command": "lark-cli docs --help"},
            },
        },
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t2",
            "data": {
                "tool_call_id": "cli-1",
                "title": "bash",
                "kind": "execute",
                "status": "completed",
                "raw_input_summary": json.dumps({"Command": "lark-cli docs --help"}),
                "observed_capability": "terminal.cli",
                "observed_tool_label": "lark-cli",
            },
        },
    ]

    aggregated = _aggregate_used_capabilities(events)
    by_cap = {item['capability']: item for item in aggregated}

    assert by_cap['terminal.cli']['allow'] == 1
    assert by_cap['terminal.cli']['observed'] == 1
    assert by_cap['terminal.cli']['gatedObserved'] == 1
    assert by_cap['terminal.cli']['observedOnly'] == 0
    assert by_cap['terminal.cli']['tools']['lark-cli']['gatedObserved'] == 1



def test_usage_aggregation_supports_mixed_gated_and_observed_only_counts():
    events = [
        {
            "type": "acp_permission",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {
                "resolved_capability": "terminal.cli",
                "decision": "allow",
                "policy_context": {"binary": "lark-cli", "command": "lark-cli docs --help"},
            },
        },
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t2",
            "data": {
                "tool_call_id": "cli-1",
                "title": "bash",
                "kind": "execute",
                "status": "completed",
                "raw_input_summary": json.dumps({"Command": "lark-cli docs --help"}),
                "observed_capability": "terminal.cli",
                "observed_tool_label": "lark-cli",
            },
        },
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t3",
            "data": {
                "tool_call_id": "cli-2",
                "title": "bash",
                "kind": "execute",
                "status": "completed",
                "raw_input_summary": json.dumps({"Command": "othercli --help"}),
                "observed_capability": "terminal.cli",
                "observed_tool_label": "othercli",
            },
        },
    ]

    aggregated = _aggregate_used_capabilities(events)
    by_cap = {item['capability']: item for item in aggregated}

    assert by_cap['terminal.cli']['observed'] == 2
    assert by_cap['terminal.cli']['gatedObserved'] == 1
    assert by_cap['terminal.cli']['observedOnly'] == 1
    assert by_cap['terminal.cli']['tools']['lark-cli']['gatedObserved'] == 1
    assert by_cap['terminal.cli']['tools']['othercli']['observedOnly'] == 1



def test_usage_aggregation_treats_fs_events_as_explicit_gate_evidence():
    events = [
        {
            "type": "acp_fs_write",
            "state": "PRD_DRAFTING",
            "ts": "t1",
            "data": {"path": "/repo/.harness/runs/run-1/docs/prd.md", "result": "ok"},
        },
        {
            "type": "acp_tool_call",
            "state": "PRD_DRAFTING",
            "ts": "t2",
            "data": {
                "tool_call_id": "write-1",
                "title": "write",
                "kind": "edit",
                "status": "completed",
                "raw_input_summary": json.dumps({"path": "/repo/.harness/runs/run-1/docs/prd.md"}),
            },
        },
    ]

    aggregated = _aggregate_used_capabilities(events)
    by_cap = {item['capability']: item for item in aggregated}

    assert by_cap['fs.write']['allow'] == 1
    assert by_cap['fs.write']['observed'] == 1
    assert by_cap['fs.write']['gatedObserved'] == 1
    assert by_cap['fs.write']['observedOnly'] == 0
    assert by_cap['fs.write']['tools']['prd.md']['gatedObserved'] == 1
