from __future__ import annotations

import json

from core.runtime_paths import (
    active_run_paths,
    clear_current_run,
    current_run_file,
    runtime_paths_for_run,
    write_current_run,
)


def test_current_run_round_trip(tmp_path):
    repo = tmp_path / "repo"
    (repo / ".git").mkdir(parents=True)

    paths = runtime_paths_for_run("run-123", str(repo))
    saved = write_current_run(paths)

    assert saved == str(repo / ".harness" / "current_run.json")

    resolved = active_run_paths(str(repo))
    assert resolved is not None
    assert resolved.run_id == "run-123"
    assert resolved.run_root == str(repo / ".harness" / "runs" / "run-123")
    assert resolved.progress_file == str(repo / ".harness" / "runs" / "run-123" / "progress.json")


def test_active_run_paths_requires_current_run_pointer(tmp_path):
    repo = tmp_path / "repo"
    (repo / ".git").mkdir(parents=True)
    (repo / "progress.json").write_text(
        json.dumps({"state": "PRD_DRAFTING", "metadata": {"run_id": "legacy-run"}}),
        encoding="utf-8",
    )

    resolved = active_run_paths(str(repo))
    assert resolved is None


def test_clear_current_run_removes_pointer_file(tmp_path):
    repo = tmp_path / "repo"
    (repo / ".git").mkdir(parents=True)

    paths = runtime_paths_for_run("run-abc", str(repo))
    write_current_run(paths)
    assert current_run_file(str(repo)) == str(repo / ".harness" / "current_run.json")

    clear_current_run(str(repo))
    assert active_run_paths(str(repo)) is None
