import json
import os
import shutil
import pytest
from acp.schema import HttpMcpServer, McpServerStdio

from acp import RequestError

from core.run_trace import init_trace
from acp import PROTOCOL_VERSION

from core.acp_agent import AcpAgent, HarnessClientImpl, _build_client_capabilities
from tools.acp_client_wrapper import HarnessClientImpl as WrapperHarnessClientImpl, run_acp_prompt_test
from tests.runtime_fixtures import seed_active_run


@pytest.mark.skipif(shutil.which("coco") is None, reason="coco binary not found in PATH")
def test_acp_write_file_in_repo_root(tmp_path):
    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        path = os.path.abspath("test-acp.txt")

        agent = AcpAgent(args=["acp", "serve", "-y"])
        prompt = f"请使用工具把字符串 'ok' 原样写到绝对路径 {path}，然后直接结束。"
        res = agent.run_task(prompt_text=prompt, cwd=str(tmp_path))
    finally:
        os.chdir(cwd)

    assert res.get("error") is None, f"run_task error: {res.get('error')}"
    assert os.path.exists(path), "expected file not created by agent tool call"
    with open(path, "r", encoding="utf-8") as f:
        content = f.read().strip()
    assert content != "", "file was created but empty"


class _Dummy:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class _Dumpable:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def model_dump(self):
        return dict(self.__dict__)


@pytest.mark.asyncio
async def test_request_permission_schema_allows_first_option():
    updates = []
    client = HarnessClientImpl(updates_list=updates)

    opt = _Dummy(option_id="opt-1", kind="allow_once", name="Allow Once")
    tool_call = _Dummy(name="apply_patch", title="apply_patch")

    resp = await client.request_permission(options=[opt], session_id="s1", tool_call=tool_call)

    dumped = resp.model_dump()
    assert "outcome" in dumped and isinstance(dumped["outcome"], dict)
    assert dumped["outcome"].get("outcome") == "selected"
    assert dumped["outcome"].get("option_id") == "opt-1"


@pytest.mark.asyncio
async def test_request_permission_prefers_allow_option_over_first_option():
    client = HarnessClientImpl(updates_list=[])

    options = [
        _Dummy(option_id="opt-reject", kind="reject_once", name="Reject"),
        _Dummy(option_id="opt-allow", kind="allow_once", name="Allow Once"),
    ]

    resp = await client.request_permission(options=options, session_id="s1", tool_call=_Dummy(title="apply_patch"))

    dumped = resp.model_dump()
    assert dumped["outcome"].get("outcome") == "selected"
    assert dumped["outcome"].get("option_id") == "opt-allow"


@pytest.mark.asyncio
async def test_request_permission_denies_unknown_execute_capability():
    client = HarnessClientImpl(updates_list=[])
    options = [
        _Dummy(option_id="opt-reject", kind="reject_once", name="Reject Once"),
        _Dummy(option_id="opt-allow", kind="allow_once", name="Allow Once"),
    ]
    tool_call = _Dummy(title="mystery execute", kind="execute", raw_input={"command": ""})

    resp = await client.request_permission(options=options, session_id="s1", tool_call=tool_call)

    dumped = resp.model_dump()
    assert dumped["outcome"].get("outcome") == "selected"
    assert dumped["outcome"].get("option_id") == "opt-reject"


@pytest.mark.asyncio
async def test_request_permission_emits_gate_denial_update_when_tool_call_id_present(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    progress = tmp_path / ".harness" / "runs" / "run-test" / "progress.json"
    progress.parent.mkdir(parents=True, exist_ok=True)
    progress.write_text(json.dumps({"state": "CODING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")

    updates: list[dict] = []
    client = HarnessClientImpl(updates_list=updates, workspace_root=str(tmp_path), repo_root=str(tmp_path))
    options = [_Dummy(option_id="opt-reject", kind="reject_once", name="Reject Once")]
    tool_call = _Dummy(title="mystery execute", kind="execute", raw_input={"command": ""}, tool_call_id="call-1")

    resp = await client.request_permission(options=options, session_id="s1", tool_call=tool_call)

    dumped = resp.model_dump()
    assert dumped["outcome"].get("option_id") == "opt-reject"
    denial_updates = [u for u in updates if u.get("sessionUpdate") == "tool_call_update"]
    assert denial_updates
    denial_update = denial_updates[-1]
    assert denial_update["toolCallId"] == "call-1"
    assert denial_update["status"] == "failed"
    assert denial_update["_meta"]["harness"]["gate_denial"] is True
    denial_text = denial_update["content"][0]["content"]["text"]
    assert "reason: unknown_execute_capability" in denial_text
    assert "suggestion:" in denial_text


@pytest.mark.asyncio
async def test_request_permission_allows_terminal_bash_when_stage_enables_it(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"CODING": ["bash:shell"]}}),
        encoding="utf-8",
    )
    monkeypatch.setenv("HARNESS_STAGE", "CODING")

    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))
    options = [
        _Dummy(option_id="opt-reject", kind="reject_once", name="Reject Once"),
        _Dummy(option_id="opt-allow", kind="allow_once", name="Allow Once"),
    ]
    tool_call = _Dummy(title="shell", kind="execute", raw_input={"command": "bash -lc 'echo hi'"})

    resp = await client.request_permission(options=options, session_id="s1", tool_call=tool_call)
    dumped = resp.model_dump()
    assert dumped["outcome"].get("outcome") == "selected"
    assert dumped["outcome"].get("option_id") == "opt-allow"


@pytest.mark.asyncio
async def test_request_permission_denied_without_reject_option_raises_invalid_params():
    client = HarnessClientImpl(updates_list=[])
    options = [
        _Dummy(option_id="opt-allow", kind="allow_once", name="Allow Once"),
    ]
    tool_call = _Dummy(title="mystery execute", kind="execute", raw_input={"command": ""})

    with pytest.raises(RequestError) as exc:
        await client.request_permission(options=options, session_id="s1", tool_call=tool_call)

    assert exc.value.code == -32602


@pytest.mark.asyncio
async def test_request_permission_execute_allows_and_create_terminal_reuses_resolution(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))
    option = _Dummy(option_id="opt-1", kind="allow_once", name="Allow Once")
    tool_call = _Dummy(title="run pytest", kind="execute", raw_input={"command": "uv", "args": ["run", "pytest", "-q"]})

    resp = await client.request_permission(options=[option], session_id="s1", tool_call=tool_call)
    assert resp.model_dump()["outcome"]["outcome"] == "selected"

    terminal = await client.create_terminal(
        command="uv",
        args=["run", "pytest", "-q", "tests/test_capability_policy.py"],
        cwd=str(repo_root),
        session_id="s1",
    )
    dumped = terminal.model_dump()
    assert dumped.get("terminal_id")


@pytest.mark.asyncio
async def test_request_permission_merges_cached_tool_call_metadata_for_write(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")
    docs = tmp_path / "docs"
    docs.mkdir(parents=True)

    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))
    await client.session_update("s1", _Dumpable(
        session_update="tool_call",
        tool_call_id="call-1",
        title="Write",
        kind=None,
        status="in_progress",
        raw_input={"path": str(docs / "prd.md"), "content": "# PRD\n"},
        locations=[{"path": str(docs / "prd.md")}],
    ))

    option = _Dummy(option_id="opt-1", kind="allow_once", name="Allow Once")
    permission_tool_call = _Dummy(tool_call_id="call-1", title="mcp__coco__Write", kind=None)

    resp = await client.request_permission(options=[option], session_id="s1", tool_call=permission_tool_call)
    assert resp.model_dump()["outcome"]["option_id"] == "opt-1"
    merged = client._merge_tool_call_with_pending("s1", permission_tool_call)
    assert getattr(merged, "title", None) == "Write"
    assert getattr(merged, "raw_input", None) == {"path": str(docs / "prd.md"), "content": "# PRD\n"}


@pytest.mark.asyncio
async def test_create_terminal_and_wait_exit(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    resp = await client.create_terminal(
        command="python3",
        args=["-c", "print('cli-ok')"],
        cwd=str(repo_root),
        session_id="s1",
    )

    term_id = resp.model_dump().get("terminal_id")
    wait = await client.wait_for_terminal_exit(session_id="s1", terminal_id=term_id)
    out = await client.terminal_output(session_id="s1", terminal_id=term_id)
    dumped_wait = wait.model_dump()
    dumped_out = out.model_dump()
    assert dumped_wait.get("exit_code") == 0
    assert "cli-ok" in dumped_out.get("output", "")
    await client.release_terminal(session_id="s1", terminal_id=term_id)
    assert term_id not in client.terminals


@pytest.mark.asyncio
async def test_create_terminal_denies_cli_not_enabled_for_stage(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("HARNESS_ENFORCE_EXEC_ALLOWLIST_AT_TERMINAL_CREATE", "1")
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"PRD_DRAFTING": ["cli:lark-cli"]}}),
        encoding="utf-8",
    )
    progress = tmp_path / ".harness" / "runs" / "run-test" / "progress.json"
    progress.parent.mkdir(parents=True, exist_ok=True)
    progress.write_text(json.dumps({"state": "PRD_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "PRD_DRAFTING")

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root), repo_root=str(tmp_path))

    with pytest.raises(RequestError) as exc:
        await client.create_terminal(
            command="bytedcli",
            args=["-h"],
            cwd=str(repo_root),
            session_id="s1",
        )

    assert exc.value.code == -32602
    doc = json.loads(progress.read_text(encoding="utf-8"))
    denial = doc["metadata"]["last_gate_denial"]
    assert denial["reason"] == "tool_not_enabled_for_stage"
    assert denial["details"]["tool_id"] == "cli:bytedcli"
    assert denial["details"]["enabled_tool_ids"] == ["cli:lark-cli"]


@pytest.mark.asyncio
async def test_create_terminal_allows_enabled_bytedcli_for_stage(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("HARNESS_ENFORCE_EXEC_ALLOWLIST_AT_TERMINAL_CREATE", "1")
    harness_dir = tmp_path / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)
    (harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"PRD_DRAFTING": ["cli:bytedcli"]}}),
        encoding="utf-8",
    )
    progress = tmp_path / ".harness" / "runs" / "run-test" / "progress.json"
    progress.parent.mkdir(parents=True, exist_ok=True)
    progress.write_text(json.dumps({"state": "PRD_DRAFTING", "metadata": {}, "artifacts": {}}), encoding="utf-8")
    monkeypatch.setenv("HARNESS_PROGRESS_FILE", str(progress))
    monkeypatch.setenv("HARNESS_STAGE", "PRD_DRAFTING")

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root), repo_root=str(tmp_path))

    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            import asyncio

            self.returncode = None
            self.stdout = asyncio.StreamReader()
            self.stderr = asyncio.StreamReader()
            self.stdout.feed_eof()
            self.stderr.feed_eof()

        async def wait(self):
            self.returncode = 0
            return 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

    async def _fake_create_subprocess_exec(cmd, *argv, **kwargs):
        captured["cmd"] = cmd
        captured["argv"] = list(argv)
        return _FakeProc()

    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    resp = await client.create_terminal(
        command="bytedcli",
        args=["-h"],
        cwd=str(repo_root),
        session_id="s1",
    )

    assert resp.model_dump().get("terminal_id")
    assert captured.get("cmd") == "bytedcli"
    assert captured.get("argv") == ["-h"]


@pytest.mark.asyncio
async def test_run_task_uses_workspace_as_session_cwd(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            captured["client_capabilities"] = kwargs.get("client_capabilities")
            return _Dumpable(
                protocol_version=PROTOCOL_VERSION,
                agent_capabilities={
                    "terminal": True,
                    "session_capabilities": {"list": {}},
                    "load_session": True,
                    "prompt_capabilities": {"embedded_context": True, "image": True},
                },
            )

        async def new_session(self, **kwargs):
            captured["session_cwd"] = kwargs.get("cwd")
            captured["mcp_servers"] = kwargs.get("mcp_servers")
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            captured["prompt"] = kwargs.get("prompt")
            await captured["client_impl"].session_update(
                kwargs.get("session_id"),
                _Dumpable(
                    session_update="session_info_update",
                    title="Repository session",
                    updatedAt="2026-04-12T10:00:00Z",
                    _meta={"messageCount": 2},
                ),
            )
            captured["prompt_session_id"] = kwargs.get("session_id")
            return _Dumpable(stop_reason="Finished")

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        captured["spawn_command"] = args
        captured["spawn_cwd"] = kwargs.get("cwd")
        captured["spawn_limit"] = kwargs.get("limit")
        return _FakeProc()

    def _fake_connect_to_agent(client_impl, *args, **kwargs):
        captured["client_impl"] = client_impl
        return _FakeConnectionCtx()

    monkeypatch.setenv("HARNESS_DISABLE_DEFAULT_COCO_MCP", "1")
    monkeypatch.setattr("core.acp_agent.connect_to_agent", _fake_connect_to_agent)
    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    repo_root = tmp_path / "repo"
    repo_root.mkdir()

    result = await AcpAgent(args=["acp", "serve", "-y"])._run_task_async(prompt_text="hi", cwd=str(repo_root))

    workspace_root = repo_root
    assert result.get("error") is None
    assert workspace_root.exists()
    assert captured.get("spawn_cwd") == str(workspace_root)
    assert captured.get("spawn_limit") == 4 * 1024 * 1024
    assert captured.get("session_cwd") == str(workspace_root)
    assert captured.get("mcp_servers") == []
    client_capabilities = captured.get("client_capabilities")
    assert client_capabilities is not None
    assert client_capabilities.model_dump().get("terminal") is True
    assert client_capabilities.model_dump(exclude_none=True).get("auth") is None
    assert result.get("supportsSessionList") is True
    assert result.get("supportsLoadSession") is True
    assert result.get("agentInfo") == {}
    assert result.get("authMethods") == []
    assert result.get("promptCapabilities") == {
        "text": True,
        "resource_link": True,
        "image": True,
        "audio": False,
        "embedded_context": True,
    }
    assert result.get("final_response") == {"stop_reason": "end_turn"}
    assert captured.get("prompt") == [{"type": "text", "text": "hi"}]
    assert result.get("sessionInfo") == {
        "sessionId": "s1",
        "cwd": str(workspace_root),
        "title": "Repository session",
        "updatedAt": "2026-04-12T10:00:00Z",
        "_meta": {"messageCount": 2},
    }


@pytest.mark.asyncio
async def test_run_task_honors_custom_stdio_limit(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            return _Dumpable(stop_reason="end_turn")

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        captured["spawn_limit"] = kwargs.get("limit")
        return _FakeProc()

    monkeypatch.setenv("HARNESS_ACP_STDIO_LIMIT_BYTES", "2097152")
    monkeypatch.setattr("core.acp_agent.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx())
    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    repo_root = tmp_path / "repo"
    repo_root.mkdir()

    result = await AcpAgent(args=["acp", "serve", "-y"])._run_task_async(prompt_text="hi", cwd=str(repo_root))

    assert result.get("error") is None
    assert captured.get("spawn_limit") == 2097152


@pytest.mark.asyncio
async def test_run_task_rejects_protocol_version_mismatch(tmp_path, monkeypatch):
    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

        async def wait(self):
            return self.returncode

    class _Dumpable:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def model_dump(self):
            return dict(self.__dict__)

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION + 1, agent_capabilities={})

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    monkeypatch.setattr("core.acp_agent.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx())
    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    repo_root = tmp_path / "repo"
    repo_root.mkdir()

    result = await AcpAgent(args=["acp", "serve", "-y"])._run_task_async(prompt_text="hi", cwd=str(repo_root))

    assert "protocol version mismatch" in (result.get("error") or "").lower()


def test_build_client_capabilities_omits_auth_when_unsupported():
    capabilities = _build_client_capabilities()
    dumped = capabilities.model_dump(exclude_none=True)
    assert dumped.get("terminal") is True
    assert dumped.get("fs", {}).get("read_text_file") is True
    assert dumped.get("auth") is None


@pytest.mark.asyncio
async def test_create_terminal_denies_outside_workspace(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    with pytest.raises(Exception):
        await client.create_terminal(
            command="python3",
            args=["-c", "print('cli-ok')"],
            cwd=str(tmp_path),
            session_id="s1",
        )


@pytest.mark.asyncio
async def test_create_terminal_rejects_relative_cwd(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    with pytest.raises(RequestError):
        await client.create_terminal(
            command="python3",
            args=["-c", "print('cli-ok')"],
            cwd="repo",
            session_id="s1",
        )


@pytest.mark.asyncio
async def test_fs_methods_require_absolute_paths(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    with pytest.raises(RequestError):
        await client.write_text_file("ok", "repo/test.txt", session_id="s1")

    with pytest.raises(RequestError):
        await client.read_text_file("repo/test.txt", session_id="s1")


@pytest.mark.asyncio
async def test_write_text_file_returns_none_on_success(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    result = await client.write_text_file("ok", str(repo_root / "test.txt"), session_id="s1")

    assert result is not None
    assert hasattr(result, "model_dump")


@pytest.mark.asyncio
async def test_read_text_file_honors_line_and_limit(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    target = repo_root / "notes.txt"
    target.write_text("a\nb\nc\nd\n", encoding="utf-8")
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    resp = await client.read_text_file(str(target), session_id="s1", line=2, limit=2)

    assert resp.model_dump().get("content") == "b\nc\n"


@pytest.mark.asyncio
async def test_read_text_file_rejects_invalid_window(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    target = repo_root / "notes.txt"
    target.write_text("a\n", encoding="utf-8")
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    with pytest.raises(RequestError):
        await client.read_text_file(str(target), session_id="s1", line=0)

    with pytest.raises(RequestError):
        await client.read_text_file(str(target), session_id="s1", limit=-1)


@pytest.mark.asyncio
async def test_read_text_file_rejects_outside_workspace(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    outside = tmp_path / "notes.txt"
    outside.write_text("a\n", encoding="utf-8")
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    with pytest.raises(RequestError) as exc:
        await client.read_text_file(str(outside), session_id="s1")

    assert exc.value.code == -32602
    assert exc.value.data == {"path": str(outside.resolve()), "reason": "path_must_be_within_workspace"}


@pytest.mark.asyncio
async def test_read_text_file_validates_window_before_open(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    missing = repo_root / "missing.txt"
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    with pytest.raises(RequestError) as exc:
        await client.read_text_file(str(missing), session_id="s1", line=0)

    assert exc.value.code == -32602
    assert exc.value.data == {"line": 0, "reason": "line_must_be_positive"}


@pytest.mark.asyncio
async def test_run_task_filters_stage_disabled_mcp_servers_before_session_injection(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            captured["mcp_servers"] = kwargs.get("mcp_servers")
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            return _Dumpable(stop_reason="end_turn")

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    monkeypatch.setenv("HARNESS_STAGE", "PRD_DRAFTING")
    user_harness_dir = tmp_path / "home" / ".harness"
    user_harness_dir.mkdir(parents=True, exist_ok=True)
    (user_harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"PRD_DRAFTING": []}}),
        encoding="utf-8",
    )

    monkeypatch.setattr("core.acp_agent.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx())
    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)
    monkeypatch.setattr(
        "core.acp_agent.load_effective_mcp_servers",
        lambda **kwargs: [
            HttpMcpServer(name="remote-http", url="https://example.com/mcp", type="http", headers=[]),
            McpServerStdio(name="coco", command="/bin/echo", args=["ok"], env=[]),
        ],
    )

    repo_root = tmp_path / "repo"
    repo_root.mkdir()

    result = await AcpAgent(args=["acp", "serve", "-y"])._run_task_async(prompt_text="hi", cwd=str(repo_root))

    assert result.get("error") is None
    assert captured.get("mcp_servers") == []
    assert result.get("mcpServersSkipped") == [
        {
            "name": "remote-http",
            "transport": "http",
            "tool_id": "mcp:remote-http",
            "reason": "tool_not_enabled_for_stage",
        },
        {
            "name": "coco",
            "transport": "stdio",
            "tool_id": "mcp:coco",
            "reason": "tool_not_enabled_for_stage",
        },
    ]


@pytest.mark.asyncio
async def test_run_task_filters_unsupported_http_mcp_servers(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            captured["mcp_servers"] = kwargs.get("mcp_servers")
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            return _Dumpable(stop_reason="end_turn")

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    monkeypatch.setenv("HARNESS_STAGE", "PRD_DRAFTING")
    user_harness_dir = tmp_path / "home" / ".harness"
    user_harness_dir.mkdir(parents=True, exist_ok=True)
    (user_harness_dir / "stage_tools.json").write_text(
        json.dumps({"schema_version": 1, "stages": {"PRD_DRAFTING": ["mcp:remote-http", "mcp:local"]}}),
        encoding="utf-8",
    )

    monkeypatch.setattr("core.acp_agent.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx())
    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)
    monkeypatch.setattr(
        "core.acp_agent.load_effective_mcp_servers",
        lambda **kwargs: [
            HttpMcpServer(name="remote-http", url="https://example.com/mcp", type="http", headers=[]),
            McpServerStdio(name="local", command="/bin/echo", args=["ok"], env=[]),
        ],
    )

    repo_root = tmp_path / "repo"
    repo_root.mkdir()

    result = await AcpAgent(args=["acp", "serve", "-y"])._run_task_async(prompt_text="hi", cwd=str(repo_root))

    assert result.get("error") is None
    assert [s.name for s in (captured.get("mcp_servers") or [])] == ["local"]
    assert result.get("mcpServersSkipped") == [
        {"name": "remote-http", "transport": "http", "reason": "agent_missing_http_capability"}
    ]


@pytest.mark.asyncio
async def test_run_task_accepts_resource_link_prompt_blocks(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            captured["prompt"] = kwargs.get("prompt")
            return _Dumpable(stop_reason="end_turn")

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    monkeypatch.setattr("core.acp_agent.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx())
    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    prompt_blocks = [
        {"type": "text", "text": "请阅读附件"},
        {"type": "resource_link", "uri": "file:///tmp/demo.py", "name": "demo.py", "mimeType": "text/x-python"},
    ]

    result = await AcpAgent(args=["acp", "serve", "-y"])._run_task_async(
        prompt_text="ignored",
        cwd=str(repo_root),
        prompt_blocks=prompt_blocks,
    )

    assert result.get("error") is None
    assert captured.get("prompt") == prompt_blocks


@pytest.mark.asyncio
async def test_run_task_rejects_embedded_resource_without_capability(tmp_path, monkeypatch):
    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            return _Dumpable(session_id="s1")

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    monkeypatch.setattr("core.acp_agent.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx())
    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    repo_root = tmp_path / "repo"
    repo_root.mkdir()

    result = await AcpAgent(args=["acp", "serve", "-y"])._run_task_async(
        prompt_text="ignored",
        cwd=str(repo_root),
        prompt_blocks=[
            {
                "type": "resource",
                "resource": {
                    "uri": "file:///tmp/demo.py",
                    "mimeType": "text/x-python",
                    "text": "print('hi')",
                },
            }
        ],
    )

    assert "embeddedcontext" in (result.get("error") or "").lower()


@pytest.mark.asyncio
async def test_run_task_cancellation_marks_pending_tool_calls_cancelled(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        def kill(self):
            self.returncode = -9

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            await captured["client_impl"].session_update(
                kwargs.get("session_id"),
                _Dumpable(
                    session_update="tool_call",
                    tool_call_id="call_1",
                    title="Read file",
                    kind="read",
                    status="pending",
                ),
            )
            raise RuntimeError("request aborted by session/cancel")

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    def _fake_connect_to_agent(client_impl, *args, **kwargs):
        captured["client_impl"] = client_impl
        return _FakeConnectionCtx()

    monkeypatch.setattr("core.acp_agent.connect_to_agent", _fake_connect_to_agent)
    monkeypatch.setattr("core.acp_agent.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    repo_root = tmp_path / "repo"
    repo_root.mkdir()

    result = await AcpAgent(args=["acp", "serve", "-y"])._run_task_async(prompt_text="hi", cwd=str(repo_root))

    assert result.get("error") is None
    assert result.get("final_response") == {"stop_reason": "cancelled"}
    assert result.get("updates")[-1]["sessionUpdate"] == "tool_call_update"
    assert result.get("updates")[-1]["status"] == "failed"
    assert result.get("updates")[-1]["_meta"]["harness"]["cancelled"] is True


@pytest.mark.asyncio
async def test_wrapper_ext_notification_is_noop():
    client = WrapperHarnessClientImpl(updates_list=[])
    await client.ext_notification("unknown/notification", {"ok": True})


@pytest.mark.asyncio
async def test_wrapper_normalizes_session_cwd(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={"prompt_capabilities": {"embedded_context": True}})

        async def new_session(self, **kwargs):
            captured["cwd"] = kwargs.get("cwd")
            captured["mcp_servers"] = kwargs.get("mcp_servers")
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            captured["prompt"] = kwargs.get("prompt")
            return _Dumpable(stop_reason="end_turn")

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    monkeypatch.setattr("tools.acp_client_wrapper.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx())
    monkeypatch.setattr("tools.acp_client_wrapper.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    relative_cwd = os.path.relpath(str(repo_root), start=os.getcwd())

    result = await run_acp_prompt_test("hi", relative_cwd)

    assert result.get("error") is None
    assert captured.get("cwd") == str(repo_root.resolve())
    assert captured.get("mcp_servers") == []
    assert result.get("promptCapabilities") == {
        "text": True,
        "resource_link": True,
        "image": False,
        "audio": False,
        "embedded_context": True,
    }
    assert captured.get("prompt") == [{"type": "text", "text": "hi"}]


@pytest.mark.asyncio
async def test_wrapper_rejects_protocol_version_mismatch(tmp_path, monkeypatch):
    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        async def wait(self):
            return self.returncode

    class _FakeConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION + 1, agent_capabilities={})

    class _FakeConnectionCtx:
        async def __aenter__(self):
            return _FakeConn()

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    monkeypatch.setattr("tools.acp_client_wrapper.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx())
    monkeypatch.setattr("tools.acp_client_wrapper.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    result = await run_acp_prompt_test("hi", str(tmp_path))

    assert "protocol version mismatch" in (result.get("error") or "").lower()


@pytest.mark.asyncio
async def test_wrapper_normalizes_stop_reason_and_cancellation(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        async def wait(self):
            return self.returncode

    class _FinishedConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            return _Dumpable(stop_reason="Finished")

    class _CancelledConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            return _Dumpable(session_id="s2")

        async def prompt(self, **kwargs):
            await captured["client_impl"].session_update(
                kwargs.get("session_id"),
                _Dumpable(
                    session_update="tool_call",
                    tool_call_id="call_1",
                    title="Read file",
                    kind="read",
                    status="pending",
                ),
            )
            raise RuntimeError("request canceled by session/cancel")

    class _FakeConnectionCtx:
        def __init__(self, conn):
            self._conn = conn

        async def __aenter__(self):
            return self._conn

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    def _fake_connect_to_agent_finished(client_impl, *args, **kwargs):
        return _FakeConnectionCtx(_FinishedConn())

    monkeypatch.setattr("tools.acp_client_wrapper.connect_to_agent", _fake_connect_to_agent_finished)
    monkeypatch.setattr("tools.acp_client_wrapper.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)

    finished = await run_acp_prompt_test("hi", str(tmp_path))

    assert finished.get("error") is None
    assert finished.get("final_response") == {"stop_reason": "end_turn"}

    def _fake_connect_to_agent_cancelled(client_impl, *args, **kwargs):
        captured["client_impl"] = client_impl
        return _FakeConnectionCtx(_CancelledConn())

    monkeypatch.setattr("tools.acp_client_wrapper.connect_to_agent", _fake_connect_to_agent_cancelled)

    cancelled = await run_acp_prompt_test("hi", str(tmp_path))

    assert cancelled.get("error") is None
    assert cancelled.get("final_response") == {"stop_reason": "cancelled"}
    assert cancelled.get("updates")[-1]["status"] == "failed"
    assert cancelled.get("updates")[-1]["_meta"]["harness"]["cancelled"] is True


@pytest.mark.asyncio
async def test_wrapper_accepts_resource_link_and_rejects_embedded_resource_without_capability(tmp_path, monkeypatch):
    captured: dict[str, object] = {}

    class _FakeProc:
        def __init__(self):
            self.stdin = object()
            self.stdout = object()
            self.returncode = 0

        def terminate(self):
            self.returncode = 0

        async def wait(self):
            return self.returncode

    class _ResourceLinkConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            return _Dumpable(session_id="s1")

        async def prompt(self, **kwargs):
            captured["prompt"] = kwargs.get("prompt")
            return _Dumpable(stop_reason="end_turn")

    class _NoEmbeddedConn:
        async def initialize(self, **kwargs):
            return _Dumpable(protocol_version=PROTOCOL_VERSION, agent_capabilities={})

        async def new_session(self, **kwargs):
            return _Dumpable(session_id="s2")

    class _FakeConnectionCtx:
        def __init__(self, conn):
            self._conn = conn

        async def __aenter__(self):
            return self._conn

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_create_subprocess_exec(*args, **kwargs):
        return _FakeProc()

    monkeypatch.setattr("tools.acp_client_wrapper.asyncio.create_subprocess_exec", _fake_create_subprocess_exec)
    monkeypatch.setattr("tools.acp_client_wrapper.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx(_ResourceLinkConn()))

    prompt_blocks = [
        {"type": "text", "text": "请参考文件"},
        {"type": "resource_link", "uri": "file:///tmp/demo.py", "name": "demo.py"},
    ]
    ok = await run_acp_prompt_test("ignored", str(tmp_path), prompt_blocks=prompt_blocks)
    assert ok.get("error") is None
    assert captured.get("prompt") == prompt_blocks

    monkeypatch.setattr("tools.acp_client_wrapper.connect_to_agent", lambda *args, **kwargs: _FakeConnectionCtx(_NoEmbeddedConn()))
    bad = await run_acp_prompt_test(
        "ignored",
        str(tmp_path),
        prompt_blocks=[{"type": "resource", "resource": {"uri": "file:///tmp/demo.py", "text": "print('hi')"}}],
    )
    assert "embeddedcontext" in (bad.get("error") or "").lower()


@pytest.mark.asyncio
async def test_terminal_output_truncation(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    resp = await client.create_terminal(
        command="python3",
        args=["-c", "print('x'*200)"],
        cwd=str(repo_root),
        session_id="s1",
        output_byte_limit=32,
    )
    term_id = resp.model_dump().get("terminal_id")
    await client.wait_for_terminal_exit(session_id="s1", terminal_id=term_id)
    out = await client.terminal_output(session_id="s1", terminal_id=term_id)
    dumped = out.model_dump()
    assert dumped.get("truncated") is True
    assert len(dumped.get("output", "").encode("utf-8")) <= 32
    assert dumped.get("output", "").endswith("x\n")
    await client.release_terminal(session_id="s1", terminal_id=term_id)


@pytest.mark.asyncio
async def test_terminal_output_truncation_preserves_utf8_boundary(tmp_path):
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    client = HarnessClientImpl(updates_list=[], workspace_root=str(repo_root))

    resp = await client.create_terminal(
        command="python3",
        args=["-c", "print('你'*40)"],
        cwd=str(repo_root),
        session_id="s1",
        output_byte_limit=31,
    )
    term_id = resp.model_dump().get("terminal_id")
    await client.wait_for_terminal_exit(session_id="s1", terminal_id=term_id)
    out = await client.terminal_output(session_id="s1", terminal_id=term_id)
    dumped = out.model_dump()
    encoded = dumped.get("output", "").encode("utf-8")
    assert dumped.get("truncated") is True
    assert len(encoded) <= 31
    dumped.get("output", "").encode("utf-8").decode("utf-8")
    await client.release_terminal(session_id="s1", terminal_id=term_id)


@pytest.mark.asyncio
async def test_terminal_trace_and_cleanup(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r1", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r1", str(run_dir))
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")
    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))

    resp = await client.create_terminal(
        command="python3",
        args=["-c", "print('trace-ok')"],
        cwd=str(tmp_path),
        session_id="s1",
    )
    term_id = resp.model_dump().get("terminal_id")
    await client.wait_for_terminal_exit(session_id="s1", terminal_id=term_id)
    await client.terminal_output(session_id="s1", terminal_id=term_id)
    await client.release_terminal(session_id="s1", terminal_id=term_id)

    trace_text = (run_dir / "trace.ndjson").read_text(encoding="utf-8")
    assert "acp_terminal_create" in trace_text
    assert "acp_terminal_wait" in trace_text
    assert "acp_terminal_output" in trace_text
    assert "trace-ok" in trace_text
    assert "acp_terminal_release" in trace_text


@pytest.mark.asyncio
async def test_release_terminal_kills_running_process_and_invalidates_terminal(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r2", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r2", str(run_dir))
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")
    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))

    resp = await client.create_terminal(
        command="python3",
        args=["-c", "import time; print('still-running', flush=True); time.sleep(10)"],
        cwd=str(tmp_path),
        session_id="s1",
    )
    term_id = resp.model_dump().get("terminal_id")
    proc = client.terminals[term_id].process

    await client.release_terminal(session_id="s1", terminal_id=term_id)

    assert term_id not in client.terminals
    assert proc.returncode is not None
    with pytest.raises(RequestError):
        await client.terminal_output(session_id="s1", terminal_id=term_id)

    trace_text = (run_dir / "trace.ndjson").read_text(encoding="utf-8")
    assert '"acp_terminal_release"' in trace_text
    assert '"killed_running_process": true' in trace_text


@pytest.mark.asyncio
async def test_session_update_plan_emits_trace_event(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="plan1", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("plan1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")
    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))

    await client.session_update(
        session_id="s1",
        update=_Dumpable(
            session_update="plan",
            entries=[
                {"content": "Analyze", "priority": "high", "status": "pending"},
                {"content": "Implement", "priority": "high", "status": "in_progress"},
            ],
        ),
    )

    trace_text = (run_dir / "trace.ndjson").read_text(encoding="utf-8")
    rows = [json.loads(line) for line in trace_text.splitlines() if line.strip()]
    plan_events = [r for r in rows if r.get("type") == "acp_plan_update" and r.get("state") == "CODING"]
    assert len(plan_events) == 1
    data = plan_events[0].get("data") or {}
    assert data.get("session_id") == "s1"
    assert data.get("seq") == 1
    assert isinstance(data.get("fingerprint"), str) and len(data.get("fingerprint")) == 64
    assert data.get("counts", {}).get("pending") == 1
    assert data.get("counts", {}).get("in_progress") == 1
    assert isinstance(data.get("entries"), list) and len(data.get("entries")) == 2


@pytest.mark.asyncio
async def test_session_update_plan_bounding(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="plan2", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("plan2", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "CODING")
    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))

    entries = [{"content": "x" * 3000, "priority": "high", "status": "pending"} for _ in range(205)]
    await client.session_update(session_id="s1", update=_Dumpable(session_update="plan", entries=entries))

    trace_text = (run_dir / "trace.ndjson").read_text(encoding="utf-8")
    rows = [json.loads(line) for line in trace_text.splitlines() if line.strip()]
    data = next(r.get("data") for r in rows if r.get("type") == "acp_plan_update")
    assert data.get("truncated") is True
    assert data.get("dropped_entries") == 5
    assert len(data.get("entries")) == 200
    assert len(data.get("entries")[0].get("content") or "") == 2000


@pytest.mark.asyncio
async def test_session_update_unknown_emits_raw_event(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="raw1", state="PRD_DRAFTING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("raw1", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "PRD_DRAFTING")
    monkeypatch.setenv("HARNESS_TRACE_RAW_SESSION_UPDATES", "1")
    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))

    await client.session_update(session_id="s1", update=_Dumpable(session_update="foo", x=1, y={"k": "v"}))

    trace_text = (run_dir / "trace.ndjson").read_text(encoding="utf-8")
    rows = [json.loads(line) for line in trace_text.splitlines() if line.strip()]
    raw_events = [r for r in rows if r.get("type") == "acp_session_update_raw" and r.get("state") == "PRD_DRAFTING"]
    assert len(raw_events) == 1
    data = raw_events[0].get("data") or {}
    assert data.get("session_id") == "s1"
    assert data.get("session_update_kind") == "foo"
    assert "payload_json" in data


@pytest.mark.skipif(shutil.which("coco") is None, reason="coco binary not found in PATH")
def test_acp_cli_tool_calling_integration(tmp_path):
    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        path = os.path.abspath("terminal-acp.txt")

        agent = AcpAgent(args=["acp", "serve", "-y"])
        prompt = (
            "请务必使用终端工具，不要使用文件写入工具。"
            f"直接在当前仓库根目录执行一个 python3 命令，把字符串 cli-ok 写入绝对路径 {path}。"
            "完成后直接结束。"
        )
        res = agent.run_task(prompt_text=prompt, cwd=str(tmp_path), stage="CODING")
    finally:
        os.chdir(cwd)

    assert res.get("error") is None, f"run_task error: {res.get('error')}"
    assert os.path.exists(path), "expected file not created by terminal tool call"
    assert any("terminal" in str(u).lower() for u in res.get("updates", [])), "expected terminal-related ACP updates"


@pytest.mark.skipif(shutil.which("coco") is None, reason="coco binary not found in PATH")
def test_acp_cli_terminal_uses_repo_root_default_cwd(tmp_path):
    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        path = os.path.abspath("terminal-default-cwd.txt")

        agent = AcpAgent(args=["acp", "serve", "-y"])
        prompt = (
            "请务必使用终端工具，不要使用文件写入工具。"
            "直接在当前工作目录执行一个 python3 命令，创建文件 terminal-default-cwd.txt 并写入 cli-ok。"
            "不要切换目录，不要使用绝对路径。完成后直接结束。"
        )
        res = agent.run_task(prompt_text=prompt, cwd=str(tmp_path), stage="CODING")
    finally:
        os.chdir(cwd)

    assert res.get("error") is None, f"run_task error: {res.get('error')}"
    assert os.path.exists(path), "expected terminal output file under repo root default cwd"
    with open(path, "r", encoding="utf-8") as f:
        assert "cli-ok" in f.read()
