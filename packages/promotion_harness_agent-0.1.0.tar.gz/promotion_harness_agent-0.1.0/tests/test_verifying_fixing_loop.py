import os

from core.orchestrator import FlowState, Orchestrator
from core.run_trace import clear_trace, init_trace
from agents.trae_verifying_agent import trae_verifying_agent
from tests.runtime_fixtures import build_runtime_ctx


def test_loop_retries_verification_until_fixed(tmp_path, monkeypatch):
    ctx, paths = build_runtime_ctx(tmp_path, state=FlowState.QUALITY_LOOP.value)
    orch = Orchestrator(ctx)
    init_trace("run-test", paths.run_root)

    state = {"attempt": 0}
    src = tmp_path / "src"
    tests = tmp_path / "tests"
    src.mkdir(parents=True, exist_ok=True)
    tests.mkdir(parents=True, exist_ok=True)
    (src / "app.py").write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
    (tests / "test_app.py").write_text("def test_add():\n    assert 1 + 1 == 2\n", encoding="utf-8")
    ctx.add_artifact("code_root", "src")
    ctx.add_artifact("tests_root", "tests")

    def fake_acceptance(local_ctx, *_args, **_kwargs):
        state["attempt"] += 1
        if state["attempt"] == 1:
            local_ctx.update_metadata("last_error_log", "need more evidence")
            return {
                "outcome": "fail",
                "reason": "acceptance_failed",
                "acceptance_result": {"summary": "need more evidence"},
            }
        return {
            "outcome": "pass",
            "reason": "acceptance_pass",
            "acceptance_result": {"summary": "ok"},
        }

    def fake_fixing(local_ctx):
        local_ctx.update_metadata("last_error_log", "need more evidence")
        return FlowState.QUALITY_LOOP

    def fake_deploying(local_ctx):
        meta = local_ctx.context.setdefault("metadata", {})
        acceptance = meta.setdefault("acceptance_results", {})
        acceptance[FlowState.DEPLOYING.value] = {"stage": FlowState.DEPLOYING.value, "verdict": "pass", "summary": "ok"}
        local_ctx.save()
        return FlowState.REGRESSION_TESTING

    def fake_regression(local_ctx):
        meta = local_ctx.context.setdefault("metadata", {})
        acceptance = meta.setdefault("acceptance_results", {})
        acceptance[FlowState.REGRESSION_TESTING.value] = {"stage": FlowState.REGRESSION_TESTING.value, "verdict": "pass", "summary": "ok"}
        local_ctx.save()
        return FlowState.FINISHED

    def fake_verify(local_ctx):
        local_ctx.record_stage_result(
            FlowState.CODING.value,
            {
                "schema_version": 1,
                "stage": FlowState.CODING.value,
                "status": "pass",
                "summary": "coding done",
                "artifacts": [
                    {
                        "artifact_type": "code_root",
                        "path": "src",
                        "absolute_path": str(src),
                        "exists": True,
                        "is_dir": True,
                        "size_bytes": 0,
                        "summary": "src dir",
                    },
                    {
                        "artifact_type": "tests_root",
                        "path": "tests",
                        "absolute_path": str(tests),
                        "exists": True,
                        "is_dir": True,
                        "size_bytes": 0,
                        "summary": "tests dir",
                    },
                ],
                "key_points": ["artifact_count=2"],
                "evidence": ["repo root ready"],
                "metadata": {"artifact_key": "code_root"},
            },
        )
        return trae_verifying_agent(local_ctx)

    monkeypatch.setattr("agents.trae_verifying_agent.run_stage_acceptance_verifier", fake_acceptance)

    orch.register_handler(FlowState.QUALITY_LOOP, fake_verify)
    orch.register_handler(FlowState.FIXING, fake_fixing)
    orch.register_handler(FlowState.DEPLOYING, fake_deploying)
    orch.register_handler(FlowState.REGRESSION_TESTING, fake_regression)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        orch.run()
    finally:
        os.chdir(cwd)
        clear_trace()

    assert ctx.get_state() == FlowState.FINISHED.value
    assert state["attempt"] == 2
    assert ctx.context["metadata"]["quality_loop"]["retry_count"] == 0
