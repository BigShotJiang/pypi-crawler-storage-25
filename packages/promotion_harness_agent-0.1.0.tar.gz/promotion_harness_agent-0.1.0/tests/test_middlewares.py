import os
import unittest

from core.context_manager import ContextManager
from core.orchestrator import Orchestrator, FlowState
from core.middlewares import VerificationMiddleware

class TestVerificationMiddleware(unittest.TestCase):
    def setUp(self):
        self.test_file = "test_progress_mw.json"
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
        self.cm = ContextManager(self.test_file)
        self.orch = Orchestrator(self.cm)
        self.mw = VerificationMiddleware("dummy_script.py")

    def tearDown(self):
        if os.path.exists(self.test_file):
            os.remove(self.test_file)

    def test_quality_loop_state_is_observed(self):
        self.cm.set_state(FlowState.QUALITY_LOOP.value)
        result = self.mw(self.orch)

        self.assertTrue(result)
        self.assertEqual(self.cm.get_state(), FlowState.QUALITY_LOOP.value)
        self.assertIsNone(self.cm.context["metadata"].get("last_error_log"))

    def test_non_verifying_state_is_untouched(self):
        self.cm.set_state(FlowState.CODING.value)
        result = self.mw(self.orch)
        self.assertTrue(result)
        self.assertEqual(self.cm.get_state(), FlowState.CODING.value)

if __name__ == '__main__':
    unittest.main()
