import json
import os
from pathlib import Path

from fastapi.testclient import TestClient

from core.orchestrator import FlowState
from ui_backend.app import app
from tests.runtime_fixtures import seed_active_run


def test_api_health_ok():
    c = TestClient(app)
    r = c.get("/api/health")
    assert r.status_code == 200
    assert r.json()["ok"] is True


def test_api_progress_and_runs_and_trace_and_preview(tmp_path, monkeypatch):
    repo = tmp_path
    paths = seed_active_run(repo, run_id="20260101-000000-abc123", state="PRD_DRAFTING")
    run_dir = repo / paths.run_root_relative

    (run_dir / "trace.ndjson").write_text(
        "\n".join(
            [
                json.dumps({"type": "state_enter", "state": "PRD_DRAFTING"}),
                json.dumps({"type": "verify_result", "state": "QUALITY_LOOP"}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    docs = run_dir / "docs"
    docs.mkdir(parents=True)
    (docs / "prd.md").write_text("# PRD\n", encoding="utf-8")

    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))

    c = TestClient(app)
    pr = c.get("/api/progress")
    assert pr.status_code == 200
    assert pr.json()["data"]["state"] == "PRD_DRAFTING"

    rr = c.get("/api/runs")
    assert rr.status_code == 200
    assert any(x["run_id"] == run_dir.name for x in rr.json()["runs"])

    tr = c.get(f"/api/runs/{run_dir.name}/trace?offset=0&limit=1")
    assert tr.status_code == 200
    assert len(tr.json()["events"]) == 1
    assert tr.json()["next_offset"] == 1

    # tail=1 should tail *matching* events, not tail then filter.
    (run_dir / "trace.ndjson").write_text(
        "\n".join(
            [
                json.dumps({"type": "state_exit", "state": "PRD_DRAFTING", "data": {"duration_ms": 123}}),
                json.dumps({"type": "state_exit", "state": "TECH_SPEC_DRAFTING", "data": {"duration_ms": 456}}),
                json.dumps({"type": "run_end", "state": "FINISHED", "data": {}}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    tr2 = c.get(
        f"/api/runs/{run_dir.name}/trace?tail=1&limit=1&type=state_exit&state=PRD_DRAFTING"
    )
    assert tr2.status_code == 200
    assert len(tr2.json()["events"]) == 1
    assert tr2.json()["events"][0]["state"] == "PRD_DRAFTING"
    assert tr2.json()["events"][0]["data"]["duration_ms"] == 123

    (run_dir / "trace.ndjson").write_text(
        "\n".join(
            [
                json.dumps({"type": "capability_policy_decision", "state": "PRD_DRAFTING", "data": {"resolved_capability": "terminal.cli", "decision": "allow", "reason": "enabled_by_stage_config"}}),
                json.dumps({"type": "acp_fs_write", "state": "PRD_DRAFTING", "data": {"path": str(docs / "prd.md"), "result": "ok"}}),
                json.dumps({"type": "acp_tool_call", "state": "PRD_DRAFTING", "data": {"tool_call_id": "call-1", "title": "bash", "raw_input_summary": json.dumps({"Command": "bytedcli -h"})}}),
                json.dumps({"type": "acp_tool_call_update", "state": "PRD_DRAFTING", "data": {"tool_call_id": "call-skill", "title": "skill", "kind": "skill", "status": "completed", "observed_name": "lark-doc", "observed_tool_id": "skill:lark-doc", "observed_capability": "tool.skill", "observed_tool_label": "lark-doc", "content_excerpt": json.dumps({"name": "lark-doc"})}}),
                json.dumps({"type": "acp_tool_call", "state": "TECH_SPEC_DRAFTING", "data": {"tool_call_id": "call-2", "title": "bash", "raw_input_summary": json.dumps({"Command": "othercli -h"})}}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    tr3 = c.get(f"/api/runs/{run_dir.name}/trace?tail=1&limit=10&state=PRD_DRAFTING")
    assert tr3.status_code == 200
    trace_events = tr3.json()["events"]
    assert len(trace_events) == 4
    assert any(ev["type"] == "capability_policy_decision" for ev in trace_events)
    assert any(ev["type"] == "acp_fs_write" for ev in trace_events)
    assert any(
        ev["type"] == "acp_tool_call"
        and "bytedcli -h" in json.dumps(ev.get("data") or {}, ensure_ascii=False)
        for ev in trace_events
    )
    assert any(
        ev["type"] == "acp_tool_call_update"
        and (ev.get("data") or {}).get("observed_name") == "lark-doc"
        and (ev.get("data") or {}).get("observed_tool_id") == "skill:lark-doc"
        and (ev.get("data") or {}).get("observed_capability") == "tool.skill"
        and (ev.get("data") or {}).get("observed_tool_label") == "lark-doc"
        for ev in trace_events
    )

    pv = c.get(f"/api/fs/preview?path={paths.run_root_relative}/docs/prd.md")
    assert pv.status_code == 200
    assert pv.json()["type"] == "file"

    # Path traversal / escape should be rejected.
    pv2 = c.get("/api/fs/preview?path=../pyproject.toml")
    assert pv2.status_code == 400


def test_api_stop_run_marks_progress_stopped(tmp_path, monkeypatch):
    repo = tmp_path
    paths = seed_active_run(repo, run_id="run-stop", state="TECH_SPEC_DRAFTING")
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))
    monkeypatch.chdir(repo)

    import ui_backend.process_control as process_control

    monkeypatch.setattr(process_control, "stop_previous_run", lambda: True)

    c = TestClient(app)
    resp = c.post("/api/run/stop")
    assert resp.status_code == 200
    assert resp.json()["stopped"] is True

    progress = json.loads((repo / paths.run_root_relative / "progress.json").read_text(encoding="utf-8"))
    assert progress["state"] == "STOPPED"
    assert progress["metadata"]["last_stopped_state"] == "TECH_SPEC_DRAFTING"
    assert isinstance(progress["metadata"]["stopped_at"], str)


def test_api_retry_stage_rewinds_active_run_and_appends_trace(tmp_path, monkeypatch):
    repo = tmp_path
    paths = seed_active_run(
        repo,
        run_id="run-retry-coding",
        state=FlowState.DEPLOYING.value,
        metadata={
            "last_gate_denial": {"stage": FlowState.CODING.value, "reason": "tool_not_enabled_for_stage"},
            "stage_results": {
                FlowState.CODING.value: {"stage": FlowState.CODING.value, "mr_url": "https://example.com/mr/1"}
            },
            "stage_output_refs": {
                FlowState.CODING.value: {"path": "runs/run-retry-coding/stage_outputs/CODING.json"}
            },
        },
    )
    auth_block = Path(paths.run_root) / "auth_block.json"
    auth_block.write_text("{}", encoding="utf-8")
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))
    monkeypatch.chdir(repo)

    import ui_backend.process_control as process_control

    monkeypatch.setattr(process_control, "stop_previous_run", lambda: True)
    monkeypatch.setattr(process_control, "launch_pipeline_process", lambda *args, **kwargs: 4321)

    c = TestClient(app)
    resp = c.post("/api/run/retry-stage?stage=CODING")
    assert resp.status_code == 200
    body = resp.json()
    assert body == {"pid": 4321, "retried_stage": "CODING", "resume_state": "CODING"}

    progress = json.loads((repo / paths.run_root_relative / "progress.json").read_text(encoding="utf-8"))
    assert progress["state"] == FlowState.CODING.value
    assert "last_gate_denial" not in progress["metadata"]
    assert FlowState.CODING.value not in progress["metadata"].get("stage_results", {})
    assert FlowState.CODING.value not in progress["metadata"].get("stage_output_refs", {})
    assert progress["metadata"]["manual_retry"]["stage"] == FlowState.CODING.value
    assert progress["metadata"]["manual_retry"]["requested_from_state"] == FlowState.DEPLOYING.value
    assert progress["metadata"]["manual_retry"]["mapped_resume_state"] == FlowState.CODING.value
    assert not auth_block.exists()

    trace_path = Path(paths.run_root) / "trace.ndjson"
    trace_lines = [json.loads(line) for line in trace_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert trace_lines[-1]["type"] == "manual_stage_retry_requested"
    assert trace_lines[-1]["state"] == FlowState.CODING.value
    assert trace_lines[-1]["data"]["stage"] == FlowState.CODING.value


def test_api_retry_stage_allows_manual_retry_before_failed_and_maps_verifying(tmp_path, monkeypatch):
    repo = tmp_path
    paths = seed_active_run(
        repo,
        run_id="run-retry-verifying",
        state=FlowState.CODING.value,
        metadata={
            "quality_loop_phase": "fix",
            "quality_loop": {"phase": "fix", "retry_count": 1, "max_retries": 5, "history": []},
        },
    )
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))
    monkeypatch.chdir(repo)

    import ui_backend.process_control as process_control

    monkeypatch.setattr(process_control, "stop_previous_run", lambda: True)
    monkeypatch.setattr(process_control, "launch_pipeline_process", lambda *args, **kwargs: 9876)

    c = TestClient(app)
    resp = c.post("/api/run/retry-stage?stage=VERIFYING")
    assert resp.status_code == 200
    body = resp.json()
    assert body == {"pid": 9876, "retried_stage": "VERIFYING", "resume_state": FlowState.QUALITY_LOOP.value}

    progress = json.loads((repo / paths.run_root_relative / "progress.json").read_text(encoding="utf-8"))
    assert progress["state"] == FlowState.QUALITY_LOOP.value
    assert progress["metadata"]["quality_loop_phase"] == "verify"
    assert progress["metadata"]["quality_loop"]["phase"] == "verify"
    assert progress["metadata"]["manual_retry"]["stage"] == FlowState.VERIFYING.value
    assert progress["metadata"]["manual_retry"]["requested_from_state"] == FlowState.CODING.value


def test_api_retry_stage_rejects_invalid_stage_and_missing_active_run(tmp_path, monkeypatch):
    repo = tmp_path
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))
    c = TestClient(app)

    missing = c.post("/api/run/retry-stage?stage=CODING")
    assert missing.status_code == 409
    assert missing.json()["detail"] == "active_run_required"

    seed_active_run(repo, run_id="run-invalid-stage", state=FlowState.CODING.value)
    invalid = c.post("/api/run/retry-stage?stage=FINISHED")
    assert invalid.status_code == 400
    assert invalid.json()["detail"] == "invalid_retry_stage"


def test_api_acceptance_policy_tools_return_only_stage_enabled_entries(tmp_path, monkeypatch):
    repo = tmp_path
    (repo / '.harness').mkdir(parents=True, exist_ok=True)
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))
    monkeypatch.setenv('HARNESS_REPO_ROOT', str(repo))

    (repo / '.harness' / 'cli_tools.json').write_text(
        json.dumps(
            [
                {'name': 'lark-cli', 'command': 'echo', 'summary': 'Read docs', 'risk_level': 'low'},
                {'name': 'bytedcli', 'command': 'echo', 'summary': 'Repo workflow CLI', 'risk_level': 'medium'},
            ]
        ),
        encoding='utf-8',
    )
    (home / '.harness').mkdir(parents=True, exist_ok=True)
    (home / '.harness' / 'stage_tools.json').write_text(
        json.dumps(
            {
                'schema_version': 1,
                'stages': {
                    'PRD_DRAFTING': ['cli:lark-cli'],
                },
            }
        ),
        encoding='utf-8',
    )

    c = TestClient(app)
    r = c.get('/api/acceptance/policy/tools?stage=PRD_DRAFTING')
    assert r.status_code == 200
    body = r.json()
    assert body['stage'] == 'PRD_DRAFTING'
    assert body['supported'] is True
    assert [entry['tool_id'] for entry in body['entries']] == ['cli:lark-cli']



def test_api_acceptance_policy_preview_never_500_on_missing_stage_output(tmp_path, monkeypatch):
    repo = tmp_path
    seed_active_run(repo, run_id="active-run", state="PRD_DRAFTING")
    (repo / ".harness").mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))

    c = TestClient(app)
    r = c.post(
        "/api/acceptance/policy/preview?stage=PRD_DRAFTING",
        json={"enabled": True, "prompt": "Check PRD completeness.", "model": ""},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["stage"] == "PRD_DRAFTING"
    assert body["enabled"] is True
    # Preview should return warnings instead of an internal server error.
    assert isinstance(body.get("warnings"), list)
    assert any("acceptance_preview_blocked" in str(item) for item in body["warnings"])
    assert body.get("max_retries") == 2
    assert "# Role" in body.get("prompt", "")
    assert "## Stage" in body.get("prompt", "")
    assert "## Standardized Stage Output" in body.get("prompt", "")
    assert '"exists": false' in body.get("prompt", "")


def test_api_acceptance_policy_preview_returns_unsupported_without_validation_error(tmp_path, monkeypatch):
    repo = tmp_path
    (repo / ".harness").mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))

    c = TestClient(app)
    r = c.post(
        "/api/acceptance/policy/preview?stage=FIXING",
        json={"enabled": True, "prompt": "", "model": ""},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["stage"] == "FIXING"
    assert body["supported"] is False
    assert body["prompt"] == ""
    assert any("acceptance_preview_unsupported_stage: FIXING" == str(item) for item in body["warnings"])


def test_api_acceptance_policy_endpoints_work_without_active_run(tmp_path, monkeypatch):
    repo = tmp_path
    (repo / ".harness").mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))

    c = TestClient(app)

    get_one = c.get('/api/acceptance/policy?stage=PRD_DRAFTING')
    assert get_one.status_code == 200
    assert get_one.json()['stage'] == 'PRD_DRAFTING'
    assert get_one.json()['supported'] is True
    assert get_one.json()['prompt']

    save = c.put(
        '/api/acceptance/policy',
        json={
            'stage': 'PRD_DRAFTING',
            'enabled': True,
            'prompt': '请判断当前 PRD 是否可以准出。',
            'model': '',
            'max_retries': 2,
            'rules': [],
        },
    )
    assert save.status_code == 200
    assert save.json()['stage'] == 'PRD_DRAFTING'
    assert save.json()['supported'] is True
    assert save.json()['prompt'] == '请判断当前 PRD 是否可以准出。'

    preview = c.post(
        '/api/acceptance/policy/preview?stage=PRD_DRAFTING',
        json={'enabled': True},
    )
    assert preview.status_code == 200
    assert preview.json()['stage'] == 'PRD_DRAFTING'
    assert preview.json()['supported'] is True
    assert preview.json()['enabled'] is True


def test_api_acceptance_policy_preview_uses_stage_ctx_fallback_when_run_output_missing(tmp_path, monkeypatch):
    repo = tmp_path
    paths = seed_active_run(
        repo,
        run_id="active-run",
        state="PRD_DRAFTING",
        artifacts={"prd": ".harness/runs/active-run/docs/prd.md"},
    )
    (repo / paths.run_root_relative / "docs").mkdir(parents=True)
    (repo / ".harness").mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))

    c = TestClient(app)
    r = c.post(
        "/api/acceptance/policy/preview?stage=PRD_DRAFTING",
        json={"enabled": True, "prompt": "Check PRD completeness.", "model": ""},
    )
    assert r.status_code == 200
    body = r.json()
    assert any("missing_stage_output:PRD_DRAFTING" in str(item) for item in body["warnings"])
    assert '"stage": "PRD_DRAFTING"' in body["prompt"]
    assert '"source": "stage_context_fallback"' in body["prompt"]
    assert '"exists": false' in body["prompt"]


def test_api_tools_catalog_schema_and_stage_param(tmp_path, monkeypatch):
    # Create a fake repo root with minimal structure.
    repo = tmp_path
    (repo / ".harness").mkdir(parents=True, exist_ok=True)

    # Make tool discovery deterministic for this test run.
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    monkeypatch.setenv("HARNESS_DISABLE_DEFAULT_COCO_MCP", "1")
    monkeypatch.setenv("HARNESS_SCRIPT_AUTO_DISCOVER", "0")

    c = TestClient(app)
    r = c.get("/api/tools/catalog")
    assert r.status_code == 200
    body = r.json()
    assert body["scope"] == "all"
    assert body["requested_stage"] is None
    assert isinstance(body["entries"], list)
    assert isinstance(body["skipped"], dict)

    r2 = c.get("/api/tools/catalog?stage=CODING")
    assert r2.status_code == 200
    body2 = r2.json()
    assert body2["scope"] == "all"
    assert body2["requested_stage"] == "CODING"
    assert isinstance(body2["entries"], list)


def test_api_tools_mcp_registry_supports_http_and_stdio(tmp_path, monkeypatch):
    repo = tmp_path
    (repo / ".harness").mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))

    c = TestClient(app)

    create_http = c.post(
        "/api/tools/mcp-registry",
        json={"name": "feishu", "transport": "http", "url": "https://example.com/mcp", "headers": {"Authorization": "Bearer x"}},
    )
    assert create_http.status_code == 200
    http_entries = {entry["name"]: entry for entry in create_http.json()["entries"]}
    assert http_entries["feishu"]["transport"] == "http"

    create_stdio = c.post(
        "/api/tools/mcp-registry",
        json={"name": "coco", "transport": "stdio", "command": "python", "args": ["-m", "http.server"], "env": {"FOO": "bar"}},
    )
    assert create_stdio.status_code == 200
    stdio_entries = {entry["name"]: entry for entry in create_stdio.json()["entries"]}
    assert stdio_entries["coco"]["transport"] == "stdio"
    assert stdio_entries["coco"]["command"] == "python"
    assert stdio_entries["coco"]["args"] == ["-m", "http.server"]
    assert stdio_entries["coco"]["env"] == {"FOO": "bar"}

    listed = c.get("/api/tools/mcp-registry")
    assert listed.status_code == 200
    listed_entries = {entry["name"]: entry for entry in listed.json()["entries"]}
    assert set(listed_entries) == {"feishu", "coco"}

    deleted = c.delete("/api/tools/mcp-registry/coco")
    assert deleted.status_code == 200
    deleted_entries = {entry["name"]: entry for entry in deleted.json()["entries"]}
    assert "coco" not in deleted_entries
    assert "feishu" in deleted_entries



def test_api_mcp_status_and_probe_are_redacted_and_cached(tmp_path, monkeypatch):
    from acp.schema import HttpHeader, HttpMcpServer, McpServerStdio, EnvVariable

    # Create a fake repo root.
    repo = tmp_path
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))

    # Inject a deterministic server list for probing.
    http_server = HttpMcpServer(
        name="demo-http",
        type="http",
        url="http://127.0.0.1:9999/mcp",
        headers=[HttpHeader(name="Authorization", value="secret-token")],
    )
    stdio_server = McpServerStdio(
        name="demo-stdio",
        type="stdio",
        command="/bin/echo",
        args=["hello"],
        env=[EnvVariable(name="API_KEY", value="secret-env")],
    )

    import ui_backend.mcp_probe as mp

    monkeypatch.setattr(mp, "list_effective_servers", lambda stage, workspace_root: [http_server, stdio_server])

    async def _ok_probe(_server, *, timeout_sec=8.0):
        return mp.ProbeResult(status="ok", tool_count=2, tools=["t1", "t2"], last_checked_at="2026-01-01T00:00:00Z", last_ok_at="2026-01-01T00:00:00Z")

    monkeypatch.setattr(mp, "deep_probe_server", _ok_probe)

    c = TestClient(app)

    # Status is redacted (no secret header/env values).
    s = c.get("/api/mcp/status?stage=CODING")
    assert s.status_code == 200
    body = s.json()
    assert body["requested_stage"] == "CODING"
    dumped = json.dumps(body)
    assert "secret-token" not in dumped
    assert "secret-env" not in dumped

    # Probe returns tool_count and is cached on a second call.
    p1 = c.post("/api/mcp/probe?stage=CODING")
    assert p1.status_code == 200
    res1 = p1.json()["results"]
    assert any(r["probe"]["tool_count"] == 2 for r in res1)
    assert all(r["cached"] is False for r in res1)

    p2 = c.post("/api/mcp/probe?stage=CODING")
    assert p2.status_code == 200
    res2 = p2.json()["results"]
    assert all(r["cached"] is True for r in res2)


def test_api_acceptance_policy_endpoints(tmp_path, monkeypatch):
    repo = tmp_path
    paths = seed_active_run(
        repo,
        run_id='active-run',
        state='PRD_DRAFTING',
        metadata={
            'acceptance_results': {
                'PRD_DRAFTING': {
                    'stage': 'PRD_DRAFTING',
                    'artifact_type': 'prd',
                    'verdict': 'fail',
                    'summary': '缺少风险说明',
                    'missing_items': ['风险'],
                    'findings': ['结构不完整'],
                    'suggested_fix': '补齐风险',
                }
            },
            'stage_results': {
                'PRD_DRAFTING': {
                    'schema_version': 1,
                    'stage': 'PRD_DRAFTING',
                    'status': 'completed',
                    'summary': 'PRD 已生成。',
                    'artifacts': [
                        {
                            'artifact_type': 'prd',
                            'path': '.harness/runs/active-run/docs/prd.md',
                            'absolute_path': str(repo / '.harness' / 'runs' / 'active-run' / 'docs' / 'prd.md'),
                            'exists': True,
                            'is_dir': False,
                            'size_bytes': 6,
                            'summary': '当前阶段生成的 PRD 文档。',
                        }
                    ],
                    'key_points': ['artifact_path=.harness/runs/active-run/docs/prd.md'],
                    'evidence': ['file_exists=True'],
                    'metadata': {'artifact_key': 'prd'},
                },
                'DEPLOYING': {
                    'schema_version': 1,
                    'stage': 'DEPLOYING',
                    'status': 'completed',
                    'summary': '部署已完成。',
                    'artifacts': [
                        {
                            'artifact_type': 'deploy_report',
                            'path': '.harness/runs/active-run/outputs/deploy_report.json',
                            'absolute_path': str(repo / '.harness' / 'runs' / 'active-run' / 'outputs' / 'deploy_report.json'),
                            'exists': True,
                            'is_dir': False,
                            'size_bytes': 16,
                            'summary': '当前阶段生成的部署报告。',
                        }
                    ],
                    'key_points': ['target_envs=BOE,PPE'],
                    'evidence': ['deploy ok'],
                    'metadata': {'artifact_key': 'deploy_report'},
                },
            },
        },
        artifacts={'prd': '.harness/runs/active-run/docs/prd.md'},
    )
    (repo / paths.run_root_relative / 'docs').mkdir(parents=True, exist_ok=True)
    (repo / paths.run_root_relative / 'docs' / 'prd.md').write_text('# PRD\n', encoding='utf-8')
    (repo / paths.run_root_relative / 'outputs').mkdir(parents=True, exist_ok=True)
    (repo / paths.run_root_relative / 'outputs' / 'deploy_report.json').write_text('{"status":"ok"}\n', encoding='utf-8')
    (repo / paths.run_root_relative / 'stage_outputs').mkdir(parents=True, exist_ok=True)
    (repo / paths.run_root_relative / 'stage_outputs' / 'PRD_DRAFTING.json').write_text(
        json.dumps(
            {
                'schema_version': 1,
                'stage': 'PRD_DRAFTING',
                'status': 'completed',
                'summary': 'PRD 已生成。',
                'artifacts': [
                    {
                        'artifact_type': 'prd',
                        'path': '.harness/runs/active-run/docs/prd.md',
                        'absolute_path': str(repo / '.harness' / 'runs' / 'active-run' / 'docs' / 'prd.md'),
                        'exists': True,
                        'is_dir': False,
                        'size_bytes': 6,
                        'summary': '当前阶段生成的 PRD 文档。',
                    }
                ],
                'key_points': ['artifact_path=.harness/runs/active-run/docs/prd.md'],
                'evidence': ['file_exists=True'],
                'metadata': {'artifact_key': 'prd'},
            }
        ),
        encoding='utf-8',
    )
    (repo / paths.run_root_relative / 'stage_outputs' / 'DEPLOYING.json').write_text(
        json.dumps(
            {
                'schema_version': 1,
                'stage': 'DEPLOYING',
                'status': 'completed',
                'summary': '部署已完成。',
                'artifacts': [
                    {
                        'artifact_type': 'deploy_report',
                        'path': '.harness/runs/active-run/outputs/deploy_report.json',
                        'absolute_path': str(repo / '.harness' / 'runs' / 'active-run' / 'outputs' / 'deploy_report.json'),
                        'exists': True,
                        'is_dir': False,
                        'size_bytes': 16,
                        'summary': '当前阶段生成的部署报告。',
                    }
                ],
                'key_points': ['target_envs=BOE,PPE'],
                'evidence': ['deploy ok'],
                'metadata': {'artifact_key': 'deploy_report'},
            }
        ),
        encoding='utf-8',
    )
    (repo / '.harness' / 'stage_acceptance_policy.json').write_text(
        json.dumps(
            {
                'schema_version': 1,
                'policies': {
                    'DEPLOYING': {
                        'enabled': True,
                        'prompt': '请判断当前 Deploying 阶段是否可以准出。不要跳过第一层本地产物校验；先基于标准化 Stage Output 和本地产物确认：部署相关交付已形成可消费产物，且输出中包含 env_name、env_url、branch_name、psm 等关键信息。然后再执行 Harness Agent 二层判断：1）通过环境链接确认是否能够读取到对应环境；2）确认环境中是否存在该分支对应 psm 的部署工单。若远端能力、鉴权、链接可达性、环境读取或部署工单读取失败，请明确记录缺失项与失败原因，不要假设验证成功。',
                        'model': '',
                        'rules': [
                            {
                                'use_tool_id': 'skill:bits-env',
                                'do': '若当前产出提供了环境链接，优先通过环境链接读取对应环境信息；若无法直接读取，再继续使用同类环境或研发工作流能力核对远端信息。',
                                'verify': '确认是否能够通过 env_url 读取对应环境；若远端能力、鉴权、链接可达性或环境信息读取失败，必须明确记录失败原因，不要假设验证成功。',
                            },
                            {
                                'use_tool_id': 'skill:bits-env',
                                'do': '优先读取目标环境中的部署记录、部署工单或等价发布凭据，定位当前分支对应 psm 的部署信息；若无法直接读取，再继续使用同类环境或研发工作流能力核对。',
                                'verify': '确认目标环境中是否存在该分支对应 psm 的部署工单或等价部署记录；若工单不可读、记录缺失、远端查询失败或结论不明确，必须明确记录缺失项与失败原因，不要假设成功。',
                            },
                        ],
                    }
                },
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding='utf-8',
    )

    monkeypatch.setenv('HARNESS_REPO_ROOT', str(repo))
    monkeypatch.setenv('HOME', str(tmp_path / 'home'))

    c = TestClient(app)

    get_one = c.get('/api/acceptance/policy?stage=PRD_DRAFTING')
    assert get_one.status_code == 200
    assert get_one.json()['supported'] is True
    assert get_one.json()['max_retries'] == 2
    assert get_one.json()['latest_result']['summary'] == '缺少风险说明'
    assert get_one.json()['latest_stage_output']['stage'] == 'PRD_DRAFTING'
    assert get_one.json()['latest_stage_output']['artifacts'][0]['artifact_type'] == 'prd'

    deploy_policy = c.get('/api/acceptance/policy?stage=DEPLOYING')
    assert deploy_policy.status_code == 200
    assert deploy_policy.json()['supported'] is True
    assert deploy_policy.json()['latest_stage_output']['stage'] == 'DEPLOYING'
    assert deploy_policy.json()['latest_stage_output']['artifacts'][0]['artifact_type'] == 'deploy_report'
    assert 'env_name' in deploy_policy.json()['prompt']
    assert len(deploy_policy.json()['rules']) == 2
    assert deploy_policy.json()['rules'][0]['use_tool_id'] == 'skill:bits-env'

    save = c.put(
        '/api/acceptance/policy',
        json={
            'stage': 'PRD_DRAFTING',
            'enabled': True,
            'prompt': '请判断当前 PRD 是否可以准出，并返回 JSON。',
            'model': 'claude-opus-4-7',
            'max_retries': 4,
        },
    )
    assert save.status_code == 200
    assert save.json()['enabled'] is True
    assert save.json()['prompt'] == '请判断当前 PRD 是否可以准出，并返回 JSON。'
    assert save.json()['model'] == 'claude-opus-4-7'
    assert save.json()['max_retries'] == 4

    deploy_save = c.put(
        '/api/acceptance/policy',
        json={
            'stage': 'DEPLOYING',
            'enabled': True,
            'prompt': '请判断部署阶段是否可以准出，并返回 JSON。',
            'model': '',
            'max_retries': 0,
        },
    )
    assert deploy_save.status_code == 200
    assert deploy_save.json()['stage'] == 'DEPLOYING'
    assert deploy_save.json()['enabled'] is True
    assert deploy_save.json()['max_retries'] == 0

    preview = c.post(
        '/api/acceptance/policy/preview?stage=PRD_DRAFTING',
        json={
            'enabled': True,
            'prompt': '请判断当前 PRD 是否可以准出，并返回 JSON。',
            'model': 'claude-opus-4-7',
            'max_retries': 3,
        },
    )
    assert preview.status_code == 200
    body = preview.json()
    assert body['supported'] is True
    assert body['enabled'] is True
    assert body['max_retries'] == 3
    assert '# Role' in body['prompt']
    assert '## Standardized Stage Output' in body['prompt']
    assert '## Artifact manifest' in body['prompt']
    assert '## Available capabilities' in body['prompt']
    assert '## Capability payload' in body['prompt']
    assert '## Tool catalog' in body['prompt']
    assert '【Harness 上下文与工具层输入】' not in body['prompt']
    assert body['latest_result']['summary'] == '缺少风险说明'
    assert body['latest_stage_output']['stage'] == 'PRD_DRAFTING'

    deploy_preview = c.post(
        '/api/acceptance/policy/preview?stage=DEPLOYING',
        json={
            'enabled': True,
            'prompt': '请判断部署阶段是否可以准出，并返回 JSON。',
            'model': '',
            'max_retries': 1,
        },
    )
    assert deploy_preview.status_code == 200
    assert deploy_preview.json()['supported'] is True
    assert deploy_preview.json()['max_retries'] == 1
    assert '## Stage' in deploy_preview.json()['prompt']
    assert 'deploy_report' in deploy_preview.json()['prompt']

    deploy_preview_without_prompt = c.post(
        '/api/acceptance/policy/preview?stage=DEPLOYING',
        json={
            'enabled': True,
        },
    )
    assert deploy_preview_without_prompt.status_code == 200
    assert deploy_preview_without_prompt.json()['supported'] is True
    assert deploy_preview_without_prompt.json()['enabled'] is True
    assert '## Stage' in deploy_preview_without_prompt.json()['prompt']
    assert 'deploy_report' in deploy_preview_without_prompt.json()['prompt']

    bad = c.put(
        '/api/acceptance/policy',
        json={
            'stage': 'PRD_DRAFTING',
            'enabled': True,
            'prompt': '',
        },
    )
    assert bad.status_code == 400
    assert bad.json()['detail']['code'] == 'invalid_acceptance_policy'

    reset = c.post('/api/acceptance/policy/reset', json={'stage': 'PRD_DRAFTING'})
    assert reset.status_code == 200
    assert reset.json()['stage'] == 'PRD_DRAFTING'
    assert reset.json()['max_retries'] == 2


def test_api_context_policy_endpoints(tmp_path, monkeypatch):
    repo = tmp_path
    seed_active_run(repo, run_id='active-run', state='PRD_DRAFTING', metadata={'requirement': '写 PRD'})
    (repo / '.harness').mkdir(parents=True, exist_ok=True)
    (repo / '.harness' / 'cli_tools.json').write_text(
        json.dumps(
            [
                {
                    'name': 'lark-cli',
                    'command': 'echo',
                    'summary': 'Read docs',
                    'risk_level': 'low',
                },
                {
                    'name': 'deploy-cli',
                    'command': 'echo',
                    'summary': 'Deploy app',
                    'risk_level': 'medium',
                }
            ],
            indent=2,
        ),
        encoding='utf-8',
    )
    (repo / '.harness' / 'stage_tools.json').write_text(
        json.dumps({'schema_version': 1, 'stages': {'PRD_DRAFTING': ['cli:lark-cli'], 'DEPLOYING': ['cli:deploy-cli']}}, indent=2),
        encoding='utf-8',
    )
    (repo / '.harness' / 'stage_context_policy.json').write_text(
        json.dumps(
            {
                'schema_version': 2,
                'policies': {
                    'DEPLOYING': {
                        'rules': [
                            {
                                'use_tool_id': 'skill:codebase-cli',
                                'do': '优先读取远程仓库，重点确认当前远程分支状态；若无法直接读取，再退回同类仓库工作流能力继续核对。',
                            },
                            {
                                'use_tool_id': 'skill:codebase-cli',
                                'do': '优先读取当前产出关联的 MR 信息，补齐部署前所需的提交、分支与合入上下文；若无法直接读取，再退回同类仓库工作流能力继续核对。',
                            },
                            {
                                'use_tool_id': 'skill:bits-env',
                                'do': '将当前分支部署到 BOE 或 PPE，泳道命名为 分支名_harness_deploy；若无法直接完成，再退回同类研发工作流能力继续处理。',
                            },
                        ],
                        'output_requirements': '输出必须包含：1）env_name；2）env_url；3）branch_name；4）psm；5）若部署目标为 BOE 或 PPE，明确记录实际目标环境；6）若任一字段缺失、链接不可用或部署失败，明确说明原因，不要伪造。',
                        'tool_instructions': '进入 DEPLOYING 后，要把上下文层与 Agent 执行要求一起落实。先读取远程仓库和 MR，再执行部署；部署目标应为 BOE 或 PPE，泳道命名使用 分支名_harness_deploy。若 bits-env 不可用，可退回 bytedcli 或同类仓库工作流能力，但必须显式说明 fallback 路径与失败原因。最终输出中必须明确给出环境名、环境链接、分支名和 psm，不要省略。',
                    }
                },
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding='utf-8',
    )

    monkeypatch.setenv('HARNESS_REPO_ROOT', str(repo))
    monkeypatch.setenv('HOME', str(tmp_path / 'home'))

    c = TestClient(app)

    tools = c.get('/api/context/policy/tools?stage=PRD_DRAFTING')
    assert tools.status_code == 200
    assert tools.json()['supported'] is True
    assert sorted(entry['tool_id'] for entry in tools.json()['entries']) == ['cli:deploy-cli', 'cli:lark-cli']

    deploy_tools = c.get('/api/context/policy/tools?stage=DEPLOYING')
    assert deploy_tools.status_code == 200
    assert deploy_tools.json()['supported'] is True
    assert sorted(entry['tool_id'] for entry in deploy_tools.json()['entries']) == ['cli:deploy-cli', 'cli:lark-cli']

    save = c.put(
        '/api/context/policy',
        json={
            'stage': 'PRD_DRAFTING',
            'rules': [{'use_tool_id': 'cli:lark-cli', 'do': '优先读取文档正文'}],
            'output_requirements': '必须包含背景和目标',
            'tool_instructions': '优先走 MCP',
        },
    )
    assert save.status_code == 200
    assert save.json()['rules'] == [{'use_tool_id': 'cli:lark-cli', 'do': '优先读取文档正文'}]
    assert save.json()['output_requirements'] == '必须包含背景和目标'
    assert save.json()['tool_instructions'] == '优先走 MCP'

    get_one = c.get('/api/context/policy?stage=PRD_DRAFTING')
    assert get_one.status_code == 200
    assert get_one.json()['rules'][0]['use_tool_id'] == 'cli:lark-cli'
    assert get_one.json()['output_requirements'] == '必须包含背景和目标'
    assert get_one.json()['tool_instructions'] == '优先走 MCP'

    deploy_default = c.get('/api/context/policy?stage=DEPLOYING')
    assert deploy_default.status_code == 200
    assert len(deploy_default.json()['rules']) == 3
    assert deploy_default.json()['rules'][0]['use_tool_id'] == 'skill:codebase-cli'
    assert 'env_name' in deploy_default.json()['output_requirements']
    assert '分支名_harness_deploy' in deploy_default.json()['tool_instructions']

    deploy_save = c.put(
        '/api/context/policy',
        json={
            'stage': 'DEPLOYING',
            'rules': [{'use_tool_id': 'cli:deploy-cli', 'do': '优先读取部署结果并沉淀环境状态'}],
            'output_requirements': '必须包含部署环境与部署结果',
            'tool_instructions': '优先使用部署工具，不要跳过环境记录',
        },
    )
    assert deploy_save.status_code == 200
    assert deploy_save.json()['stage'] == 'DEPLOYING'
    assert deploy_save.json()['rules'][0]['use_tool_id'] == 'cli:deploy-cli'

    preview = c.post(
        '/api/context/policy/preview?stage=PRD_DRAFTING',
        json={
            'rules': [{'use_tool_id': 'cli:lark-cli', 'do': '优先读取文档正文'}],
            'output_requirements': '必须包含背景和目标',
            'tool_instructions': '优先走 MCP',
            'requirement': '使用预览需求覆盖 progress',
        },
    )
    assert preview.status_code == 200
    preview_body = preview.json()
    assert preview_body['output_requirements'] == '必须包含背景和目标'
    assert preview_body['tool_instructions'] == '优先走 MCP'
    assert '【用户自定义工具策略（USE/DO）】' in preview_body['prompt']
    assert 'USE: cli:lark-cli' in preview_body['prompt']
    assert '【用户配置的产出物要求】' in preview_body['prompt']
    assert '【用户配置的工具调用指令】' in preview_body['prompt']
    assert '用户原始需求：使用预览需求覆盖 progress' in preview_body['prompt']

    deploy_preview = c.post(
        '/api/context/policy/preview?stage=DEPLOYING',
        json={
            'rules': [{'use_tool_id': 'cli:deploy-cli', 'do': '优先读取部署结果并沉淀环境状态'}],
            'output_requirements': '必须包含部署环境与部署结果',
            'tool_instructions': '优先使用部署工具，不要跳过环境记录',
            'requirement': '部署到 BOE / PPE',
        },
    )
    assert deploy_preview.status_code == 200
    assert deploy_preview.json()['supported'] is True
    assert '部署执行代理' in deploy_preview.json()['prompt']
    assert 'BOE、PPE' in deploy_preview.json()['prompt']

    bad = c.put(
        '/api/context/policy',
        json={
            'stage': 'PRD_DRAFTING',
            'rules': [{'use_tool_id': 'cli:pytest', 'do': 'run tests'}],
        },
    )
    assert bad.status_code == 400
    assert bad.json()['detail']['code'] == 'invalid_context_policy'

    reset = c.post('/api/context/policy/reset', json={'stage': 'PRD_DRAFTING'})
    assert reset.status_code == 200
    assert reset.json()['rules'] == []
    assert reset.json()['output_requirements'] == ''
    assert reset.json()['tool_instructions'] == ''


def test_api_context_policy_preview_works_without_active_run_for_all_stages(tmp_path, monkeypatch):
    repo = tmp_path
    (repo / '.harness').mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv('HARNESS_REPO_ROOT', str(repo))

    c = TestClient(app)

    prd = c.post(
        '/api/context/policy/preview?stage=PRD_DRAFTING',
        json={'requirement': '预览 PRD 需求'},
    )
    assert prd.status_code == 200
    assert prd.json()['supported'] is True
    assert '用户原始需求：预览 PRD 需求' in prd.json()['prompt']
    assert '.harness/preview-run' in prd.json()['prompt']

    deploy = c.post(
        '/api/context/policy/preview?stage=DEPLOYING',
        json={'requirement': '预览部署需求'},
    )
    assert deploy.status_code == 200
    assert deploy.json()['supported'] is True
    assert '部署执行代理' in deploy.json()['prompt']
    assert 'BOE、PPE' in deploy.json()['prompt']
    assert '.harness/preview-run/stage_outputs/DEPLOYING.json' in deploy.json()['prompt']

    regression = c.post(
        '/api/context/policy/preview?stage=REGRESSION_TESTING',
        json={'requirement': '预览回归需求'},
    )
    assert regression.status_code == 200
    assert regression.json()['supported'] is True
    assert '回归测试代理' in regression.json()['prompt']
    assert '.harness/preview-run/stage_outputs/REGRESSION_TESTING.json' in regression.json()['prompt']



def test_api_settings_merge_and_update(tmp_path, monkeypatch):
    repo = tmp_path
    seed_active_run(
        repo,
        run_id="active-run",
        state="INIT",
        metadata={
            "max_stage_retries": 4,
            "stage_max_retries": {"CODING": 1},
            "stage_timeouts_sec": {"PRD_DRAFTING": 123},
        },
    )
    monkeypatch.setenv("HARNESS_REPO_ROOT", str(repo))

    c = TestClient(app)

    # GET should expose effective stage retries/timeouts and raw overrides.
    r1 = c.get("/api/settings")
    assert r1.status_code == 200
    body1 = r1.json()
    assert body1["max_stage_retries"] == 4
    assert body1["stage_max_retries_overrides"]["CODING"] == 1
    assert body1["stage_max_retries"]["CODING"] == 1
    assert body1["stage_max_retries"]["PRD_DRAFTING"] == 4
    assert body1["max_quality_loop_retries"] == 5
    assert body1["stage_timeouts_overrides_sec"]["PRD_DRAFTING"] == 123
    assert "TECH_SPEC_DRAFTING" in body1["stage_timeouts_sec"]
    assert body1["stage_timeouts_sec"]["PRD_DRAFTING"] == 123

    # PUT supports updating retries and timeout overrides.
    r2 = c.put(
        "/api/settings",
        json={
            "max_stage_retries": 2,
            "stage_max_retries": {"TECH_SPEC_DRAFTING": 3},
            "max_quality_loop_retries": 7,
            "stage_timeouts_sec": {"TECH_SPEC_DRAFTING": 88},
        },
    )
    assert r2.status_code == 200
    body2 = r2.json()["settings"]
    assert body2["max_stage_retries"] == 2
    assert body2["stage_max_retries_overrides"]["CODING"] == 1
    assert body2["stage_max_retries_overrides"]["TECH_SPEC_DRAFTING"] == 3
    assert body2["stage_max_retries"]["TECH_SPEC_DRAFTING"] == 3
    assert body2["max_quality_loop_retries"] == 7
    assert body2["stage_timeouts_overrides_sec"]["PRD_DRAFTING"] == 123
    assert body2["stage_timeouts_overrides_sec"]["TECH_SPEC_DRAFTING"] == 88
    assert body2["stage_timeouts_sec"]["TECH_SPEC_DRAFTING"] == 88

    # PUT with null removes one override key and falls back to legacy/defaults.
    r3 = c.put(
        "/api/settings",
        json={
            "stage_max_retries": {"CODING": None},
            "stage_timeouts_sec": {"PRD_DRAFTING": None},
        },
    )
    assert r3.status_code == 200
    body3 = r3.json()["settings"]
    assert "CODING" not in body3["stage_max_retries_overrides"]
    assert body3["stage_max_retries"]["CODING"] == 2
    assert "PRD_DRAFTING" not in body3["stage_timeouts_overrides_sec"]
    assert "PRD_DRAFTING" in body3["stage_timeouts_sec"]

    # Invalid payload returns 400.
    r4 = c.put("/api/settings", json={"stage_timeouts_sec": "bad"})
    assert r4.status_code == 400
    r5 = c.put("/api/settings", json={"stage_max_retries": {"CODING": -1}})
    assert r5.status_code == 400
