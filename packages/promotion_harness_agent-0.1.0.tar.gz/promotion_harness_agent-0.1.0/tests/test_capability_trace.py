import os
import json

from core.run_trace import init_trace
from core.run_trace import clear_trace
from agents.trae_verifying_agent import trae_verifying_agent
from core.acp_agent import HarnessClientImpl
from core.orchestrator import FlowState
from tests.runtime_fixtures import build_runtime_ctx, seed_active_run


def test_verifying_emits_capability_advertisement(tmp_path, monkeypatch):
    paths = seed_active_run(tmp_path, run_id="r1", state=FlowState.QUALITY_LOOP.value)
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r1", str(run_dir))
    ctx, _ = build_runtime_ctx(tmp_path, run_id="r1")

    src = tmp_path / "src"
    tests = tmp_path / "tests"
    src.mkdir(parents=True, exist_ok=True)
    tests.mkdir(parents=True, exist_ok=True)
    (src / "app.py").write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
    (tests / "test_app.py").write_text("def test_add():\n    assert 1 + 1 == 2\n", encoding="utf-8")
    ctx.record_stage_result(
        FlowState.CODING.value,
        {
            "schema_version": 1,
            "stage": FlowState.CODING.value,
            "status": "pass",
            "summary": "coding done",
            "artifacts": [
                {
                    "artifact_type": "code_root",
                    "path": "src",
                    "absolute_path": str(src),
                    "exists": True,
                    "is_dir": True,
                    "size_bytes": 0,
                    "summary": "src dir",
                },
                {
                    "artifact_type": "tests_root",
                    "path": "tests",
                    "absolute_path": str(tests),
                    "exists": True,
                    "is_dir": True,
                    "size_bytes": 0,
                    "summary": "tests dir",
                },
            ],
            "key_points": ["artifact_count=2"],
            "evidence": ["workspace ready"],
            "metadata": {"artifact_key": "code_root"},
        },
    )
    monkeypatch.setattr(
        "agents.trae_verifying_agent.run_stage_acceptance_verifier",
        lambda *_args, **_kwargs: {"outcome": "pass", "reason": "acceptance_pass", "acceptance_result": {"summary": "ok"}},
    )

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        trae_verifying_agent(ctx)
    finally:
        os.chdir(cwd)

    trace = (run_dir / "trace.ndjson").read_text(encoding="utf-8")
    assert "capabilities_advertised" in trace


def test_trace_records_resolved_capability_for_permission(tmp_path):
    paths = seed_active_run(tmp_path, run_id="r2", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r2", str(run_dir))
    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))

    class _Opt:
        option_id = "opt-1"
        kind = "allow_once"
        name = "Allow Once"

    class _Tool:
        title = "run pytest"
        kind = "execute"
        raw_input = {"command": "uv", "args": ["run", "pytest", "-q"]}

    import asyncio

    try:
        asyncio.run(client.request_permission(options=[_Opt()], session_id="s1", tool_call=_Tool()))
        lines = (run_dir / "trace.ndjson").read_text(encoding="utf-8").splitlines()
        events = [json.loads(line) for line in lines]
        policy_events = [e for e in events if e.get("type") == "capability_policy_decision"]
        assert policy_events
        latest = policy_events[-1]["data"]
        assert latest["resolved_capability"] == "terminal.cli"
        assert latest["intent_family"] == "generic"
        assert "policy_context" in latest
        assert latest["policy_context"].get("binary") == "uv"
        assert latest["policy_context"].get("execution_mode") == "direct_cli"
    finally:
        clear_trace()


def test_trace_records_shell_wrapper_capability_for_permission(tmp_path):
    paths = seed_active_run(tmp_path, run_id="r3", state="CODING")
    run_dir = tmp_path / paths.run_root_relative
    init_trace("r3", str(run_dir))
    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path), repo_root=str(tmp_path))

    class _Reject:
        option_id = "opt-reject"
        kind = "reject_once"
        name = "Reject Once"

    class _Tool:
        title = "run shell"
        kind = "execute"
        raw_input = {"command": "bash -lc 'echo hi'"}

    import asyncio

    try:
        asyncio.run(client.request_permission(options=[_Reject()], session_id="s1", tool_call=_Tool()))
        lines = (run_dir / "trace.ndjson").read_text(encoding="utf-8").splitlines()
        events = [json.loads(line) for line in lines]
        policy_events = [e for e in events if e.get("type") == "capability_policy_decision"]
        assert policy_events
        latest = policy_events[-1]["data"]
        assert latest["resolved_capability"] == "terminal.bash"
        assert latest["reason"] == "high_risk_default_deny"
        assert latest["policy_context"].get("uses_shell") is True
        assert latest["policy_context"].get("execution_mode") == "shell_wrapper"
    finally:
        clear_trace()


def test_trace_records_unclassified_execute_for_malformed_permission(tmp_path):
    run_dir = tmp_path / "workspace" / "runs" / "r4"
    init_trace("r4", str(run_dir))
    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path / "workspace"))

    class _Reject:
        option_id = "opt-reject"
        kind = "reject_once"
        name = "Reject Once"

    class _Tool:
        title = "broken shell"
        kind = "execute"
        raw_input = {"command": "bash -lc 'echo hi"}

    import asyncio

    try:
        asyncio.run(client.request_permission(options=[_Reject()], session_id="s1", tool_call=_Tool()))
        lines = (run_dir / "trace.ndjson").read_text(encoding="utf-8").splitlines()
        events = [json.loads(line) for line in lines]
        policy_events = [e for e in events if e.get("type") == "capability_policy_decision"]
        assert policy_events
        latest = policy_events[-1]["data"]
        assert latest["resolved_capability"] is None
        assert latest["reason"] == "unknown_execute_capability"
        assert latest["policy_context"].get("parse_confidence") == "low"
        assert latest["policy_context"].get("execution_mode") == "unknown_execute"
    finally:
        clear_trace()


def test_trace_permission_uses_cached_tool_call_metadata_for_write(tmp_path, monkeypatch):
    run_dir = tmp_path / "workspace" / "runs" / "r5"
    init_trace("r5", str(run_dir))
    monkeypatch.setenv("HARNESS_STAGE", "PRD_DRAFTING")

    client = HarnessClientImpl(updates_list=[], workspace_root=str(tmp_path / "workspace"), repo_root=str(tmp_path))

    class _Opt:
        option_id = "opt-1"
        kind = "allow_once"
        name = "Allow Once"

    class _ToolCall:
        session_update = "tool_call"
        tool_call_id = "call_1"
        title = "Write"
        kind = None
        status = "in_progress"
        raw_input = {"path": str(tmp_path / "workspace" / "docs" / "prd.md"), "content": "# PRD\n"}
        locations = [type("Loc", (), {"path": str(tmp_path / "workspace" / "docs" / "prd.md")})()]

        def model_dump(self):
            return {
                "session_update": self.session_update,
                "tool_call_id": self.tool_call_id,
                "title": self.title,
                "kind": self.kind,
                "status": self.status,
                "raw_input": self.raw_input,
                "locations": [{"path": str(tmp_path / "workspace" / "docs" / "prd.md")}],
            }

    class _PermissionTool:
        tool_call_id = "call_1"
        title = "mcp__coco__Write"
        kind = None

    import asyncio

    try:
        asyncio.run(client.session_update("s1", _ToolCall()))
        asyncio.run(client.request_permission(options=[_Opt()], session_id="s1", tool_call=_PermissionTool()))
        lines = (run_dir / "trace.ndjson").read_text(encoding="utf-8").splitlines()
        events = [json.loads(line) for line in lines]
        policy_events = [e for e in events if e.get("type") == "capability_policy_decision"]
        assert policy_events
        latest = policy_events[-1]["data"]
        assert latest["kind"] == "edit"
        assert latest["resolved_capability"] == "fs.write"
        assert latest["reason"] == "allowed"
    finally:
        clear_trace()
