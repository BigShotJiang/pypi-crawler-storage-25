import json
import os

from agents.trae_deploying_agent import trae_deploying_agent
from core.orchestrator import FlowState
from tests.runtime_fixtures import build_runtime_ctx


class _StubDeployAgent:
    def __init__(self, root: str, error: str | None = None, *, write_stage_output: bool = True, missing_field: str | None = None):
        self.root = root
        self.error = error
        self.write_stage_output = write_stage_output
        self.missing_field = missing_field
        self.prompt_text = None
        self.cwd = None

    def run_task(self, prompt_text: str, cwd: str, stage: str | None = None):
        self.prompt_text = prompt_text
        self.cwd = cwd
        if self.error:
            return {"updates": [], "final_response": None, "error": self.error}

        deploy_report_path = os.path.join(self.root, ".harness", "runs", "run-test", "outputs", "deploy_report.json")
        os.makedirs(os.path.dirname(deploy_report_path), exist_ok=True)
        payload = {
            "env_name": "BOE",
            "env_url": "https://example.com/boe",
            "branch_name": "feature/test-run",
            "psm": "my.psm",
            "status": "success",
            "summary": "deploy ok",
            "evidence": ["ticket-1"],
        }
        if self.missing_field:
            payload.pop(self.missing_field, None)
        with open(deploy_report_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

        if self.write_stage_output:
            stage_output_path = os.path.join(self.root, ".harness", "runs", "run-test", "stage_outputs", "DEPLOYING.json")
            os.makedirs(os.path.dirname(stage_output_path), exist_ok=True)
            with open(stage_output_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "schema_version": 1,
                        "stage": "DEPLOYING",
                        "status": "completed",
                        "summary": "部署已完成。",
                        "artifacts": [
                            {
                                "artifact_type": "deploy_report",
                                "path": ".harness/runs/run-test/outputs/deploy_report.json",
                                "absolute_path": deploy_report_path,
                                "exists": True,
                                "is_dir": False,
                                "size_bytes": os.path.getsize(deploy_report_path),
                                "summary": "当前阶段生成的部署报告。",
                            }
                        ],
                        "key_points": ["env=BOE"],
                        "evidence": ["deploy recorded"],
                        "metadata": {"artifact_key": "deploy_report"},
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )

        return {
            "updates": [],
            "final_response": {"stop_reason": "end_turn"},
            "error": None,
            "sessionId": "sess-deploy",
            "sessionInfo": {"sessionId": "sess-deploy", "cwd": self.root, "title": "Deploy session"},
        }


def test_deploying_stage_returns_regression_and_records_metadata(tmp_path, monkeypatch):
    ctx, _ = build_runtime_ctx(tmp_path, run_id="run-test", state=FlowState.DEPLOYING.value)
    stub = _StubDeployAgent(str(tmp_path))
    monkeypatch.setattr("agents.trae_deploying_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_deploying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.REGRESSION_TESTING
    assert ctx.context["artifacts"]["deploy_report"] == ".harness/runs/run-test/outputs/deploy_report.json"
    assert ctx.context["metadata"]["deploy_status"] == "success"
    assert ctx.context["metadata"]["deploy_summary"] == "deploy ok"
    assert ctx.context["metadata"]["deploy_targets"] == ["BOE"]
    assert ctx.context["metadata"]["acp_sessions"]["sess-deploy"]["title"] == "Deploy session"
    assert "deploy_report.json" in stub.prompt_text
    assert "DEPLOYING.json" in stub.prompt_text


def test_deploying_stage_fails_when_report_missing_required_fields(tmp_path, monkeypatch):
    ctx, _ = build_runtime_ctx(tmp_path, run_id="run-test", state=FlowState.DEPLOYING.value)
    stub = _StubDeployAgent(str(tmp_path), missing_field="psm")
    monkeypatch.setattr("agents.trae_deploying_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_deploying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.FAILED
    assert "Deploy report missing required fields: psm" in ctx.context["metadata"]["last_error_log"]


def test_deploying_stage_retries_on_tool_gate_denial(tmp_path, monkeypatch):
    ctx, _ = build_runtime_ctx(tmp_path, run_id="run-test", state=FlowState.DEPLOYING.value)
    ctx.update_metadata("max_stage_retries", 2)
    ctx.update_metadata(
        "last_gate_denial",
        {
            "stage": FlowState.DEPLOYING.value,
            "reason": "tool_not_enabled_for_stage",
            "suggestion": "Use bits-env only.",
            "details": {
                "tool_id": "bash:shell",
                "resolved_capability": "terminal.bash",
                "enabled_tool_ids": ["skill:bits-env"],
            },
        },
    )
    stub = _StubDeployAgent(str(tmp_path), error="Tool call rejected by user")
    monkeypatch.setattr("agents.trae_deploying_agent.AcpAgent", lambda: stub)

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        next_state = trae_deploying_agent(ctx)
    finally:
        os.chdir(cwd)

    assert next_state == FlowState.DEPLOYING
    last = ctx.context["metadata"]["last_noncompliance"]
    assert last["stage"] == FlowState.DEPLOYING.value
    assert last["kind"] == "tool_gate"
    assert last["details"]["tool_id"] == "bash:shell"
