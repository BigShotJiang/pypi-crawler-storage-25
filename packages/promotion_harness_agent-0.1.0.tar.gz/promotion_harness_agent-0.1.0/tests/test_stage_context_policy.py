import json
import os

import pytest

from core.stage_context_policy import (
    StageContextPolicyValidationError,
    build_default_repo_stage_context_policy_payload,
    default_stage_context_policy,
    get_stage_output_requirements,
    get_stage_policy_rules,
    get_stage_tool_instructions,
    list_effective_stage_policy_tools,
    load_stage_context_policy,
    render_output_requirements_block,
    render_stage_context_policy_block,
    render_tool_instructions_block,
    reset_stage_context_policy,
    reset_stage_context_policy_to_defaults,
    save_stage_context_policy,
    validate_stage_policy_rules,
)


@pytest.fixture()
def isolated_policy_home(tmp_path, monkeypatch):
    home = tmp_path / 'home'
    monkeypatch.setenv('HOME', str(home))
    return home


def _seed_repo(tmp_path):
    (tmp_path / '.harness').mkdir(parents=True, exist_ok=True)
    (tmp_path / '.harness' / 'cli_tools.json').write_text(
        json.dumps(
            [
                {
                    'name': 'lark-cli',
                    'command': 'echo',
                    'summary': 'Read Lark docs',
                    'risk_level': 'low',
                },
                {
                    'name': 'pytest',
                    'command': 'echo',
                    'summary': 'Run tests',
                    'risk_level': 'low',
                },
            ],
            indent=2,
        ),
        encoding='utf-8',
    )
    (tmp_path / '.harness' / 'stage_tools.json').write_text(
        json.dumps(
            {
                'schema_version': 1,
                'stages': {
                    'PRD_DRAFTING': ['cli:lark-cli'],
                    'CODING': ['cli:pytest'],
                },
            },
            indent=2,
        ),
        encoding='utf-8',
    )


def test_stage_context_policy_save_load_roundtrip(tmp_path, isolated_policy_home):
    _seed_repo(tmp_path)

    saved = save_stage_context_policy(
        str(tmp_path),
        'PRD_DRAFTING',
        [{'use_tool_id': 'cli:lark-cli', 'do': '优先读取飞书文档正文'}],
        output_requirements='必须包含目标与范围',
        tool_instructions='优先走 MCP，失败再退回 CLI',
    )

    assert get_stage_policy_rules(saved, 'PRD_DRAFTING') == [
        {'use_tool_id': 'cli:lark-cli', 'do': '优先读取飞书文档正文'}
    ]
    assert get_stage_output_requirements(saved, 'PRD_DRAFTING') == '必须包含目标与范围'
    assert get_stage_tool_instructions(saved, 'PRD_DRAFTING') == '优先走 MCP，失败再退回 CLI'

    loaded = load_stage_context_policy()
    assert get_stage_policy_rules(loaded, 'PRD_DRAFTING') == [
        {'use_tool_id': 'cli:lark-cli', 'do': '优先读取飞书文档正文'}
    ]
    assert get_stage_output_requirements(loaded, 'PRD_DRAFTING') == '必须包含目标与范围'
    assert get_stage_tool_instructions(loaded, 'PRD_DRAFTING') == '优先走 MCP，失败再退回 CLI'

    saved_file = isolated_policy_home / '.harness' / 'stage_context_policy.json'
    payload = json.loads(saved_file.read_text(encoding='utf-8'))
    assert payload['schema_version'] == 2
    assert payload['policies']['PRD_DRAFTING']['rules'][0]['use_tool_id'] == 'cli:lark-cli'
    assert payload['policies']['PRD_DRAFTING']['output_requirements'] == '必须包含目标与范围'
    assert payload['policies']['PRD_DRAFTING']['tool_instructions'] == '优先走 MCP，失败再退回 CLI'


def test_stage_context_policy_load_v1_data_transparently(tmp_path, isolated_policy_home):
    _seed_repo(tmp_path)
    policy_path = isolated_policy_home / '.harness' / 'stage_context_policy.json'
    policy_path.parent.mkdir(parents=True, exist_ok=True)
    policy_path.write_text(
        json.dumps(
            {
                'schema_version': 1,
                'policies': {
                    'PRD_DRAFTING': [{'use_tool_id': 'cli:lark-cli', 'do': '优先读取飞书文档正文'}],
                },
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding='utf-8',
    )

    loaded = load_stage_context_policy()

    assert loaded.schema_version == 1
    assert get_stage_policy_rules(loaded, 'PRD_DRAFTING') == [
        {'use_tool_id': 'cli:lark-cli', 'do': '优先读取飞书文档正文'}
    ]
    assert get_stage_output_requirements(loaded, 'PRD_DRAFTING') == ''
    assert get_stage_tool_instructions(loaded, 'PRD_DRAFTING') == ''


def test_stage_context_policy_validation_rejects_invalid_tool(tmp_path, isolated_policy_home):
    _seed_repo(tmp_path)

    with pytest.raises(StageContextPolicyValidationError) as exc:
        validate_stage_policy_rules(
            str(tmp_path),
            'PRD_DRAFTING',
            [{'use_tool_id': 'cli:missing', 'do': 'run tests'}],
        )

    assert 'is not enabled for stage PRD_DRAFTING' in str(exc.value)


def test_stage_context_policy_validation_rejects_empty_do(tmp_path, isolated_policy_home):
    _seed_repo(tmp_path)

    with pytest.raises(StageContextPolicyValidationError) as exc:
        validate_stage_policy_rules(
            str(tmp_path),
            'PRD_DRAFTING',
            [{'use_tool_id': 'cli:lark-cli', 'do': '   '}],
        )

    assert 'do must not be empty' in str(exc.value)


def test_stage_context_policy_tools_only_return_enabled_entries(tmp_path, isolated_policy_home):
    _seed_repo(tmp_path)

    entries = list_effective_stage_policy_tools(str(tmp_path), 'PRD_DRAFTING')

    tool_ids = [entry['tool_id'] for entry in entries]
    assert 'cli:lark-cli' in tool_ids
    assert 'cli:pytest' in tool_ids


def test_stage_context_policy_reset_clears_single_stage(tmp_path, isolated_policy_home):
    _seed_repo(tmp_path)
    save_stage_context_policy(
        str(tmp_path),
        'PRD_DRAFTING',
        [{'use_tool_id': 'cli:lark-cli', 'do': '优先读取飞书文档正文'}],
    )

    cfg = reset_stage_context_policy('PRD_DRAFTING')

    assert get_stage_policy_rules(cfg, 'PRD_DRAFTING') == []


def test_render_stage_context_policy_block_preserves_rule_order():
    rendered = render_stage_context_policy_block(
        [
            {'use_tool_id': 'mcp:feishu', 'do': '先读正文'},
            {'use_tool_id': 'cli:lark-cli', 'do': '失败时退回 CLI'},
        ]
    )

    assert '1. USE: mcp:feishu' in rendered
    assert '2. USE: cli:lark-cli' in rendered
    assert rendered.index('mcp:feishu') < rendered.index('cli:lark-cli')


def test_render_output_and_tool_instruction_blocks():
    output_block = render_output_requirements_block('必须包含背景和目标')
    tool_block = render_tool_instructions_block('优先使用 MCP')

    assert '【用户配置的产出物要求】' in output_block
    assert '必须包含背景和目标' in output_block
    assert '【用户配置的工具调用指令】' in tool_block
    assert '优先使用 MCP' in tool_block



def test_stage_context_policy_loads_repo_defaults_for_regression(isolated_policy_home):
    repo_root = '/Users/bytedance/Documents/Project/explore/harness/caijing_harness_agent/my_harness_agent'

    loaded = load_stage_context_policy(repo_root)

    rules = get_stage_policy_rules(loaded, 'REGRESSION_TESTING')
    assert [rule['use_tool_id'] for rule in rules] == ['skill:codebase-cli', 'skill:bits-env']
    assert 'env_name' in get_stage_output_requirements(loaded, 'REGRESSION_TESTING')
    assert '不要退化为本地单测' in get_stage_tool_instructions(loaded, 'REGRESSION_TESTING')


def test_stage_context_policy_falls_back_to_builtin_defaults_when_repo_defaults_missing(tmp_path, isolated_policy_home):
    _seed_repo(tmp_path)

    coding_default = default_stage_context_policy(str(tmp_path), 'CODING')
    assert [rule['use_tool_id'] for rule in coding_default['rules']] == ['cli:bytedcli', 'skill:bam', 'bash:shell', 'skill:codebase-cli']
    assert 'mr_url' in coding_default['output_requirements']

    reset = reset_stage_context_policy_to_defaults(str(tmp_path), stage='CODING')
    assert [rule['use_tool_id'] for rule in get_stage_policy_rules(reset, 'CODING')] == ['cli:bytedcli', 'skill:bam', 'bash:shell', 'skill:codebase-cli']
    assert 'mr_url' in get_stage_output_requirements(reset, 'CODING')

    quality_default = default_stage_context_policy(str(tmp_path), 'QUALITY_LOOP')
    assert [rule['use_tool_id'] for rule in quality_default['rules']] == ['cli:bytedcli', 'skill:bam', 'skill:bits-unit-test-gen', 'skill:remote-ci-ut', 'bash:shell']
    assert '覆盖率' in quality_default['tool_instructions'] or '执行状态' in quality_default['tool_instructions']


def test_build_default_repo_stage_context_policy_payload_contains_supported_stages():
    payload = build_default_repo_stage_context_policy_payload()

    assert payload['schema_version'] == 2
    assert set(payload['policies']) == {
        'PRD_DRAFTING',
        'TECH_SPEC_DRAFTING',
        'CODING',
        'QUALITY_LOOP',
        'DEPLOYING',
        'REGRESSION_TESTING',
    }
    assert payload['policies']['PRD_DRAFTING'] == {
        'rules': [],
        'output_requirements': '',
        'tool_instructions': '',
    }
    assert [rule['use_tool_id'] for rule in payload['policies']['CODING']['rules']] == [
        'cli:bytedcli',
        'skill:bam',
        'bash:shell',
        'skill:codebase-cli',
    ]
    assert 'mr_url' in payload['policies']['CODING']['output_requirements']
    assert '不要退化为本地单测' in payload['policies']['REGRESSION_TESTING']['tool_instructions']
