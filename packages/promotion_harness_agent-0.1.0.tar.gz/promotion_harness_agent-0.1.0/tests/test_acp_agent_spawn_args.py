import os

from core.acp_agent import AcpAgent


def test_acp_agent_builds_coco_spawn_args_from_env(monkeypatch):
    monkeypatch.setenv("HARNESS_COCO_MODEL_NAME", "GPT-5.4")

    agent = AcpAgent(command="coco", args=["acp", "serve", "-y"])
    args = agent._spawn_args()

    # Global flags should appear before the subcommand.
    assert args[:2] == ["-c", "model.name=GPT-5.4"]
    assert args[-3:] == ["acp", "serve", "-y"]
