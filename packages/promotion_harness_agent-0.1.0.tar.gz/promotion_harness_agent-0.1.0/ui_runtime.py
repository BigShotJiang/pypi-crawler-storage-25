import os
import shutil
import signal
import subprocess
import time
from typing import Sequence

from core.runtime_paths import ensure_repo_initialized, harness_root, resolve_repo_root


RUN_PID_FILE = "run.pid"


def ensure_harness_home(repo_root: str | None = None) -> str:
    resolved_repo_root = ensure_repo_initialized(repo_root)
    return harness_root(resolved_repo_root)


def read_run_pid(pid_file: str | None = None, *, repo_root: str | None = None) -> int | None:
    target = pid_file or os.path.join(ensure_harness_home(repo_root), RUN_PID_FILE)
    try:
        with open(target, "r", encoding="utf-8") as f:
            raw = f.read().strip()
        return int(raw) if raw else None
    except (FileNotFoundError, ValueError):
        return None


def write_run_pid(pid: int, pid_file: str | None = None, *, repo_root: str | None = None) -> None:
    target = pid_file or os.path.join(ensure_harness_home(repo_root), RUN_PID_FILE)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "w", encoding="utf-8") as f:
        f.write(str(pid))


def clear_run_pid(pid_file: str | None = None, *, repo_root: str | None = None) -> None:
    target = pid_file or os.path.join(ensure_harness_home(repo_root), RUN_PID_FILE)
    try:
        os.remove(target)
    except FileNotFoundError:
        pass


def stop_previous_run(pid_file: str | None = None, *, repo_root: str | None = None) -> bool:
    target = pid_file or os.path.join(ensure_harness_home(repo_root), RUN_PID_FILE)
    pid = read_run_pid(target, repo_root=repo_root)
    if not pid:
        return False
    try:
        pgid = os.getpgid(pid)
        os.killpg(pgid, signal.SIGTERM)
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
            time.sleep(0.1)
        else:
            os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        clear_run_pid(target, repo_root=repo_root)
        return False
    except PermissionError:
        return False
    except OSError:
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            return False
    clear_run_pid(target, repo_root=repo_root)
    return True


def reset_workspace_outputs(base_dir: str | None = None, *, repo_root: str | None = None) -> None:
    target_base_dir = base_dir or ensure_harness_home(repo_root)
    os.makedirs(target_base_dir, exist_ok=True)
    for name in ["runs", "ui_run.log", "coco_run.log", "current_run.json"]:
        path = os.path.join(target_base_dir, name)
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        elif os.path.exists(path):
            os.remove(path)


def launch_pipeline_process(
    cmd: Sequence[str],
    cwd: str,
    log_path: str | None = None,
    *,
    repo_root: str | None = None,
    env: dict[str, str] | None = None,
) -> int:
    resolved_repo_root = resolve_repo_root(repo_root)
    harness_home = ensure_harness_home(resolved_repo_root)
    target_log_path = log_path or os.path.join(harness_home, "ui_run.log")
    log_fp = open(target_log_path, "w", encoding="utf-8")
    merged_env = dict(os.environ)
    merged_env["HARNESS_REPO_ROOT"] = resolved_repo_root
    if env:
        merged_env.update({str(k): str(v) for k, v in env.items()})
    proc = subprocess.Popen(
        list(cmd),
        cwd=cwd,
        stdout=log_fp,
        stderr=log_fp,
        start_new_session=True,
        env=merged_env,
    )
    log_fp.close()
    write_run_pid(proc.pid, repo_root=resolved_repo_root)
    return proc.pid
