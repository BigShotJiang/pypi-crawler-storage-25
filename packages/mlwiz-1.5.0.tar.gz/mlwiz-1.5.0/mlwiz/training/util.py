"""Training utility helpers.

Includes :func:`~mlwiz.training.util.atomic_torch_save` for safely writing checkpoint dictionaries.
"""

import os

import torch

from mlwiz.static import ATOMIC_SAVE_EXTENSION


def atomic_torch_save(data: dict, filepath: str):
    r"""
    Atomically stores a dictionary that can be serialized by
    :func:`torch.save`, exploiting the atomic :func:`os.replace`.

    Args:
        data (dict): the dictionary to be stored
        filepath (str): the absolute filepath where to store the dictionary
    """
    try:
        tmp_path = str(filepath) + ATOMIC_SAVE_EXTENSION
        torch.save(data, tmp_path)
        os.replace(tmp_path, filepath)
    except Exception as e:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise e
