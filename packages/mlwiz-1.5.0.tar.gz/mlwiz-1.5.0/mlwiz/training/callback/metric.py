"""Metric and loss callbacks for the training engine.

Defines :class:`~mlwiz.training.callback.metric.Metric` and composite helpers such as ``AdditiveLoss`` and ``MultiScore``.
"""

from typing import List, Union, Tuple

import torch
from torch.nn import Module, CrossEntropyLoss, MSELoss, L1Loss

from mlwiz.util import s2c
from mlwiz.static import ARGS, CLASS_NAME
from mlwiz.training.event.handler import EventHandler
from mlwiz.training.event.state import State


class Metric(Module, EventHandler):
    r"""
    Metric is the main event handler for all metrics. Other metrics can easily
    subclass by implementing the :func:`forward` method, though sometimes
    more complex implementations are required.

    Args:
        use_as_loss (bool): whether this metric should act as a loss
            (i.e., it should act when :func:`on_backward` is called).
            **Used by MLWiz, no need to care about this.**
        reduction (str): the type of reduction to apply across samples of
            the mini-batch. Supports ``mean`` and ``sum``. Default is ``mean``.
        accumulate_over_epoch (bool): Whether or not to display the epoch-wise
            metric rather than an average of per-batch metrics.
            If true, it keep a list of predictions and target values across
            the entire epoch. Use it especially with batch-sensitive metrics,
            such as micro AP/F1 scores. Default is ``True``.
        force_cpu (bool): Whether or not to move all predictions to cpu
            before computing the epoch-wise loss/score. Default is ``True``.
        device (bool): The device used. Default is 'cpu'.
        kwargs (dict): additional arguments that may depend on the metric
    """

    def __init__(
        self,
        use_as_loss: bool = False,
        reduction: str = "mean",
        accumulate_over_epoch: bool = True,
        force_cpu: bool = True,
        device: str = "cpu",
        **kwargs: dict,
    ):
        r"""
        Initialize the metric callback.

        Args:
            use_as_loss (bool): If ``True``, this metric is treated as a loss and
                will participate in backpropagation (see :meth:`on_backward`).
            reduction (str): Reduction applied to per-sample values. Expected
                values are ``'mean'`` or ``'sum'`` (passed to underlying torch
                loss implementations where applicable).
            accumulate_over_epoch (bool): If ``True``, accumulate predictions
                and targets across the entire epoch and compute the metric on
                the concatenated tensors. If ``False``, compute a per-batch
                metric and average across batches.
            force_cpu (bool): If ``True`` and ``accumulate_over_epoch`` is
                enabled, detach and move accumulated tensors to CPU to reduce
                GPU memory pressure.
            device (str): Device identifier used by some metrics/losses.
            **kwargs: Additional metric-specific parameters (unused by the base
                class).

        Side effects:
            Initializes internal buffers used to accumulate per-batch and
            per-epoch statistics.
        """
        super().__init__()
        self.batch_metrics = None
        self.use_as_loss = use_as_loss
        self.reduction = reduction
        self.accumulate_over_epoch = accumulate_over_epoch
        self.force_cpu = force_cpu
        self.device = device
        self.y_pred, self.y_true = None, None

        # Keeps track of how many times on_compute_metrics has been called
        # in the same batch.
        # Useful for temporal graph learning, for static graph learning it will
        # be always 1
        self.timesteps_in_batch = None

    @property
    def name(self) -> str:
        """
        The name of the loss to be used in configuration files and displayed
        on Tensorboard. It is the same as the class name.
        """
        return self.__class__.__name__

    def get_main_metric_name(self) -> str:
        """
        Return the metric's main name.
        Useful when a metric is the combination of many.

        Returns:
            the metric's main name
        """
        return self.name

    def get_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""
        Returns predictions and target tensors to be
        accumulated for a given metric

        Args:
            targets (:class:`torch.Tensor`): ground truth
            outputs (List[:class:`torch.Tensor`]): outputs of the model

        Returns:
            A tuple of tensors (predicted_values, target_values)
        """
        raise NotImplementedError(
            "You should subclass Metric and implement this method!"
        )

    def compute_metric(
        self, targets: torch.Tensor, predictions: torch.Tensor
    ) -> torch.tensor:
        r"""
        Computes the metric for a given set of targets and predictions

        Args:
            targets (:class:`torch.Tensor`): tensor of ground truth values
            predictions (:class:`torch.Tensor`):
                tensor of predictions of the model

        Returns:
            A tensor with the metric value
        """
        raise NotImplementedError(
            "You should subclass Metric and implement this method!"
        )

    def on_training_epoch_start(self, state: State):
        """
        Initialize list of batch metrics as well as the list of batch
        predictions and targets for the metric

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        self.batch_metrics = []
        self.y_pred, self.y_true = {self.name: []}, {self.name: []}

    def on_training_batch_start(self, state: State):
        """
        Initializes the number of potential time steps in a batch
        (for temporal learning)

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        self.timesteps_in_batch = 0.0

    def on_training_batch_end(self, state: State):
        """
        If we do not computed aggregated metric values over the entire epoch,
        populate the batch metrics list with the new loss/score.
        Divide by the number of timesteps in the batch
        (default is 1 for static datasets)

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        if self.use_as_loss:
            batch_metric = state.batch_loss
        else:
            batch_metric = state.batch_score

        if not self.accumulate_over_epoch:
            self.batch_metrics.append(
                batch_metric[self.name].item() / self.timesteps_in_batch
            )

        self.timesteps_in_batch = None

    def on_training_epoch_end(self, state: State):
        """
        Computes the mean of batch metrics or an aggregated score over all
        epoch depending on the `accumulate_over_epoch` parameter. Updates
        `epoch_loss` and `epoch_score` fields in the state
        and resets the basic fields used.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        if not self.accumulate_over_epoch:
            epoch_res = {
                self.name: torch.tensor(self.batch_metrics).sum()
                / len(self.batch_metrics)
            }
        else:
            epoch_res = {
                self.name: self.compute_metric(
                    torch.cat(self.y_true[self.name], dim=0),
                    torch.cat(self.y_pred[self.name], dim=0),
                )
            }

        if self.use_as_loss:
            state.update(epoch_loss=epoch_res)
        else:
            state.update(epoch_score=epoch_res)

        self.batch_metrics = None
        self.y_pred, self.y_true = None, None

    def on_eval_epoch_start(self, state: State):
        """
        Initialize list of batch metrics as well as the list of batch
        predictions and targets for the metric

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        self.batch_metrics = []
        self.y_pred, self.y_true = {self.name: []}, {self.name: []}

    def on_eval_batch_start(self, state: State):
        """
        Initializes the number of potential time steps in a batch
        (for temporal learning)

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        self.timesteps_in_batch = 0.0

    def on_eval_batch_end(self, state: State):
        """
        If we do not computed aggregated metric values over the entire epoch,
        populate the batch metrics list with the new loss/score.
        Divide by the number of timesteps in the batch
        (default is 1 for static datasets)

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        if self.use_as_loss:
            batch_metric = state.batch_loss
        else:
            batch_metric = state.batch_score

        if not self.accumulate_over_epoch:
            self.batch_metrics.append(
                batch_metric[self.name].item() / self.timesteps_in_batch
            )

        self.timesteps_in_batch = None

    def on_eval_epoch_end(self, state: State):
        """
        Computes the mean of batch metrics or an aggregated score over all
        epoch depending on the `accumulate_over_epoch` parameter.
        Updates `epoch_loss` and `epoch_score` fields in the state
        and resets the basic fields used.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        if not self.accumulate_over_epoch:
            epoch_res = {
                self.name: torch.tensor(self.batch_metrics).sum()
                / len(self.batch_metrics)
            }
        else:
            epoch_res = {
                self.name: self.compute_metric(
                    torch.cat(self.y_true[self.name], dim=0),
                    torch.cat(self.y_pred[self.name], dim=0),
                )
            }

        if self.use_as_loss:
            state.update(epoch_loss=epoch_res)
        else:
            state.update(epoch_score=epoch_res)

        self.batch_metrics = None
        self.y_pred, self.y_true = None, None

    def accumulate_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> None:
        """
        Used to specify how to accumulate predictions and targets.
        This can be customized by subclasses like
        AdditiveLoss and MultiScore to accumulate predictions and
        targets for different losses/scores.

        Args:
            targets: target tensor
            *outputs: outputs of the model
        """
        y_pred_batch, y_true_batch = self.get_predictions_and_targets(
            targets, *outputs
        )
        metric_name = self.name

        self.y_pred[metric_name].append(
            y_pred_batch.detach().cpu()
            if self.force_cpu
            else y_pred_batch.detach()
        )
        self.y_true[metric_name].append(
            y_true_batch.detach().cpu()
            if self.force_cpu
            else y_true_batch.detach()
        )

    def on_compute_metrics(self, state: State):
        """
        Computes the loss/score depending on the metric, updating the
        `batch_loss` or `batch_score` field in the state.
        In temporal graph learning, this method is computed more than once
        before the batch ends, so we accumulate the loss or scores across
        timesteps of a single batch.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        self.timesteps_in_batch += 1.0

        outputs, targets = state.batch_outputs, state.batch_targets

        # Loss case
        if self.use_as_loss:
            loss = self.forward(targets, *outputs)

            # [temporal graph learning] accumulate, rather than substitute,
            # the losses across multiple snapshots
            # these are reset accordingly by the Training Engine!
            if state.batch_loss is not None:
                old_loss = state.batch_loss
                loss = {k: old_loss[k] + loss[k] for k in loss.keys()}

            # this has to be updated per-batch no matter what
            state.update(batch_loss=loss)

        # Score case
        else:
            if not self.accumulate_over_epoch:
                score = self.forward(targets, *outputs)
                score = {
                    k: (
                        score[k].detach().cpu()
                        if self.force_cpu
                        else score[k].detach()
                    )
                    for k in score.keys()
                }

                # [temporal graph learning] accumulate, rather than substitute,
                # the scores across multiple snapshots
                # these are reset accordingly by the Training Engine!
                if state.batch_score is not None:
                    old_score = state.batch_score
                    score = {k: old_score[k] + score[k] for k in score.keys()}

                # mean of batches
                state.update(batch_score=score)

        if self.accumulate_over_epoch:
            self.accumulate_predictions_and_targets(targets, *outputs)

    def on_backward(self, state: State):
        """
        Calls backward on the loss if the metric is a loss.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        if self.use_as_loss:
            try:
                loss = state.batch_loss[self.name]
                grad_scaler = getattr(state, "grad_scaler", None)
                if grad_scaler is not None:
                    grad_scaler.scale(loss).backward()
                else:
                    loss.backward()
            except Exception as e:
                # Here we catch potential multiprocessing related issues
                # see https://github.com/pytorch/pytorch/wiki/Autograd-and-Fork
                raise (e)

    def forward(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> dict:
        r"""
        Computes the metric value. Optionally, and only for scores used
        as losses, some extra information can be also returned.

        Args:
            targets (:class:`torch.Tensor`): ground truth
            outputs (List[:class:`torch.Tensor`]): outputs of the model
            batch_loss_extra (dict): dictionary of information
                computed by metrics used as losses

        Returns:
            A dictionary containing associations metric_name - value
        """
        y_pred_batch, y_true_batch = self.get_predictions_and_targets(
            targets, *outputs
        )
        return {self.name: self.compute_metric(y_true_batch, y_pred_batch)}


class MultiScore(Metric):
    r"""
    This class is used to keep track of multiple additional metrics
    used as scores, rather than losses.

    Args:
        use_as_loss (bool): whether this metric should act as a loss
            (i.e., it should act when :func:`on_backward` is called).
            **Used by MLWiz, no need to care about this.**
        reduction (str): the type of reduction to apply across samples of the
            mini-batch. Supports ``mean`` and ``sum``. Default is ``mean``.
        accumulate_over_epoch (bool): Whether or not to display the epoch-wise
            metric rather than an average of per-batch metrics.  If true, it
            keeps a list of predictions and target values across the entire
            epoch. Use it especially with batch-sensitive metrics,
            such as micro AP/F1 scores. Default is ``True``.
        force_cpu (bool): Whether or not to move all predictions to cpu
            before computing the epoch-wise loss/score. Default is ``True``.
        device (bool): The device used. Default is 'cpu'.
        main_scorer (:class:`~mlwiz.training.callback.metric.Metric`): the
            score on which final results are computed.
        extra_scorers (dict): dictionary of other metrics to consider.
    """

    def __init__(
        self,
        use_as_loss,
        reduction="mean",
        accumulate_over_epoch: bool = True,
        force_cpu: bool = True,
        device: str = "cpu",
        main_scorer=None,
        **extra_scorers,
    ):
        r"""
        Initialize a multi-score metric wrapper.

        Args:
            use_as_loss (bool): Must be ``False`` for this class.
            reduction (str): Reduction to pass to underlying metrics when
                applicable.
            accumulate_over_epoch (bool): Whether to accumulate predictions and
                targets across the epoch for epoch-level metric computation.
            force_cpu (bool): Whether to move accumulated tensors to CPU.
            device (str): Device identifier.
            main_scorer (str | dict): Main scorer specification. Can be a
                dotted class path string or a dict with ``CLASS_NAME`` and
                ``ARGS``.
            **extra_scorers: Additional scorer specifications (same format as
                ``main_scorer``). Their results are tracked alongside the main
                scorer.

        Raises:
            ValueError: If ``use_as_loss`` is ``True`` or if no
                ``main_scorer`` is provided.

        Side effects:
            Instantiates scorer objects and stores them in ``self.scores``.
        """
        if use_as_loss:
            raise ValueError("MultiScore cannot be used as loss")
        if main_scorer is None:
            raise ValueError("You have to provide a main scorer")
        super().__init__(
            use_as_loss, reduction, accumulate_over_epoch, force_cpu, device
        )
        self.scores = [self._istantiate_scorer(main_scorer)] + [
            self._istantiate_scorer(score) for score in extra_scorers.values()
        ]

    def _istantiate_scorer(self, scorer):
        """
        Instantiate a scorer with its own arguments (if any are given).
        """
        if isinstance(scorer, dict):
            args = scorer[ARGS]
            return s2c(scorer[CLASS_NAME])(use_as_loss=False, **args)
        else:
            return s2c(scorer)(use_as_loss=False)

    def get_main_metric_name(self):
        """
        Returns the name of the first scorer that is passed to this class via
        the `__init__` method.
        """
        return self.scores[0].get_main_metric_name()

    def on_training_epoch_start(self, state: State):
        """
        Compared to superclass version, initializes a dictionary for each score
        to track rather than single lists

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        self.batch_metrics = {s.name: [] for s in self.scores}
        self.y_pred = {s.name: [] for s in self.scores}
        self.y_true = {s.name: [] for s in self.scores}

    def on_training_batch_end(self, state: State):
        """
        For each scorer, computes the average metric in the batch wrt the
        number of timesteps (default is 1 for static datasets) unless
        statistics are accumulated over the entire epoch

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information

        """
        if not self.accumulate_over_epoch:
            for k, v in state.batch_score.items():
                self.batch_metrics[k].append(
                    v.item() / self.timesteps_in_batch
                )

        self.timesteps_in_batch = None

    def on_training_epoch_end(self, state: State):
        """
        For each score, computes the epoch scores using the same
        ogic as the superclass

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_over_epoch:
            epoch_res = {
                s.name: torch.tensor(self.batch_metrics[s.name]).sum()
                / len(self.batch_metrics[s.name])
                for s in self.scores
            }
        else:
            epoch_res = {
                s.name: s.compute_metric(
                    torch.cat(self.y_true[s.name], dim=0),
                    torch.cat(self.y_pred[s.name], dim=0),
                )
                for s in self.scores
            }

        state.update(epoch_score=epoch_res)

        self.batch_metrics = None
        self.y_pred, self.y_true = None, None

    def on_eval_epoch_start(self, state: State):
        """
        Compared to superclass version, initializes a dictionary for each
        score to track rather than single lists

         Args:
             state (:class:`~training.event.state.State`):
                object holding training information
        """
        self.batch_metrics = {s.name: [] for s in self.scores}
        self.y_pred = {s.name: [] for s in self.scores}
        self.y_true = {s.name: [] for s in self.scores}

    def on_eval_batch_end(self, state: State):
        """
        For each scorer, computes the average metric in the batch wrt the
        number of timesteps (default is 1 for static datasets) unless
        statistics are accumulated over the entire epoch

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_over_epoch:
            for k, v in state.batch_score.items():
                self.batch_metrics[k].append(
                    v.item() / self.timesteps_in_batch
                )

        self.timesteps_in_batch = None

    def on_eval_epoch_end(self, state: State):
        """
        For each score, computes the epoch scores using the
        same logic as the superclass

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_over_epoch:
            epoch_res = {
                s.name: torch.tensor(self.batch_metrics[s.name]).sum()
                / len(self.batch_metrics[s.name])
                for s in self.scores
            }
        else:
            epoch_res = {
                s.name: s.compute_metric(
                    torch.cat(self.y_true[s.name], dim=0),
                    torch.cat(self.y_pred[s.name], dim=0),
                )
                for s in self.scores
            }

        state.update(epoch_score=epoch_res)

        self.batch_metrics = None
        self.y_pred, self.y_true = None, None

    def accumulate_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> None:
        """
        Accumulates predictions and targets of the batch into a list for
        each scorer, so as to compute aggregated statistics at the
        end of an epoch.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        for s in self.scores:
            y_pred_batch, y_true_batch = s.get_predictions_and_targets(
                targets, *outputs
            )
            metric_name = s.name

            self.y_pred[metric_name].append(
                y_pred_batch.detach().cpu()
                if self.force_cpu
                else y_pred_batch.detach()
            )
            self.y_true[metric_name].append(
                y_true_batch.detach().cpu()
                if self.force_cpu
                else y_true_batch.detach()
            )

    def forward(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Union[dict, float]:
        """
        For each scorer, it computes a score and returns them into a dictionary

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        res = {}
        for s in self.scores:
            y_pred_batch, y_true_batch = s.get_predictions_and_targets(
                targets, *outputs
            )
            res.update({s.name: s.compute_metric(y_true_batch, y_pred_batch)})
        return res


class AdditiveLoss(Metric):
    r"""
    AdditiveLoss sums an arbitrary number of losses together.

    Args:
        use_as_loss (bool): whether this metric should act as a loss
            (i.e., it should act when :func:`on_backward` is called).
            **Used by MLWiz, no need to care about this.**
        reduction (str): the type of reduction to apply across samples of the
            mini-batch. Supports ``mean`` and ``sum``. Default is ``mean``.
        accumulate_over_epoch (bool): Whether or not to display the epoch-wise
            metric rather than an average of per-batch metrics. If true,
            it keeps a list of predictions and target values across the
            entire epoch. Use it especially with batch-sensitive metrics,
            such as micro AP/F1 scores. Default is ``True``.
        force_cpu (bool): Whether or not to move all predictions to cpu
            before computing the epoch-wise loss/score. Default is ``True``.
        device (bool): The device used. Default is 'cpu'.
        losses_weights: (dict): dictionary of (loss_name, loss_weight) that
            specifies the weight to apply to each loss to be summed.
        losses (dict): dictionary of metrics to add together
    """

    def __init__(
        self,
        use_as_loss,
        reduction="mean",
        accumulate_over_epoch: bool = True,
        force_cpu: bool = True,
        device: str = "cpu",
        losses_weights: dict = None,
        **losses: dict,
    ):
        r"""
        Initialize an additive loss composed of multiple loss terms.

        Args:
            use_as_loss (bool): Must be ``True`` for this class.
            reduction (str): Reduction to pass to underlying losses when
                applicable.
            accumulate_over_epoch (bool): Whether to compute epoch-level losses
                from accumulated predictions/targets.
            force_cpu (bool): Whether to move accumulated tensors to CPU.
            device (str): Device identifier.
            losses_weights (dict, optional): Optional mapping from loss name to
                scalar weight. If omitted, all weights default to ``1.0``.
            **losses: Loss specifications. Each value can be a dotted class
                path string or a dict with ``CLASS_NAME`` and ``ARGS``.

        Raises:
            ValueError: If ``use_as_loss`` is ``False`` or weights are
                missing for any instantiated loss when ``losses_weights`` is
                provided.

        Side effects:
            Instantiates loss objects and stores them in ``self.losses`` and
            stores/normalizes loss weights in ``self.losses_weights``.
        """
        if not use_as_loss:
            raise ValueError("Additive loss can only be used as a loss")
        super().__init__(
            use_as_loss, reduction, accumulate_over_epoch, force_cpu, device
        )

        self.losses_weights = losses_weights
        self.losses = [
            self._instantiate_loss(loss) for loss in losses.values()
        ]

        if self.losses_weights is not None:
            for loss in self.losses:
                # check that a weight exists for each loss
                if loss.name not in self.losses_weights:
                    raise ValueError(
                        "You have to specify a weight for each loss! "
                        f"We could not find the weight for {loss.name} "
                        f"in the dict."
                    )
        else:
            # all losses are simply added together
            self.losses_weights = {loss.name: 1.0 for loss in self.losses}

    def _instantiate_loss(self, loss):
        """
        Instantiate a loss with its own arguments (if any are given).
        """
        if isinstance(loss, dict):
            args = loss[ARGS]
            return s2c(loss[CLASS_NAME])(use_as_loss=True, **args)
        else:
            return s2c(loss)(use_as_loss=True)

    def on_training_epoch_start(self, state: State):
        """
        Instantiates a dictionary with one list per loss (including itself,
        representing the sum of all losses)

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        self.batch_metrics = {loss.name: [] for loss in [self] + self.losses}
        self.y_pred = {loss.name: [] for loss in [self] + self.losses}
        self.y_true = {loss.name: [] for loss in [self] + self.losses}

    def on_training_batch_end(self, state: State):
        """
        For each loss, computes the average metric in the batch wrt the number
        of timesteps (default is 1 for static datasets)
        unless statistics are accumulated over the entire epoch

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_over_epoch:
            for k, v in state.batch_loss.items():
                self.batch_metrics[k].append(
                    v.item() / self.timesteps_in_batch
                )

        self.timesteps_in_batch = None

    def on_training_epoch_end(self, state: State):
        """
        Computes an averaged or aggregated loss across the entire epoch,
        including itself as the main loss. Updates the field `epoch_loss`
        in state.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_over_epoch:
            epoch_res = {
                loss.name: torch.tensor(self.batch_metrics[loss.name]).sum()
                / len(self.batch_metrics[loss.name])
                for loss in [self] + self.losses
            }
        else:
            epoch_res = {
                loss.name: loss.compute_metric(
                    torch.cat(self.y_true[loss.name], dim=0),
                    torch.cat(self.y_pred[loss.name], dim=0),
                )
                * self.losses_weights[loss.name]
                for loss in self.losses
            }
            additive_epoch_loss = 0.0
            for loss in self.losses:
                additive_epoch_loss += epoch_res[loss.name]
            epoch_res[self.name] = additive_epoch_loss

        state.update(epoch_loss=epoch_res)

        self.batch_metrics = None
        self.y_pred, self.y_true = None, None

    def on_eval_epoch_start(self, state: State):
        """
        Instantiates a dictionary with one list per loss (including itself,
        representing the sum of all losses)

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        self.batch_metrics = {loss.name: [] for loss in [self] + self.losses}
        self.y_pred = {loss.name: [] for loss in [self] + self.losses}
        self.y_true = {loss.name: [] for loss in [self] + self.losses}

    def on_eval_epoch_end(self, state: State):
        """
        Computes an averaged or aggregated loss across the entire epoch,
        including itself as the main loss. Updates the field `epoch_loss`
        in state.

        Args:
            state (:class:`~training.event.state.State`):
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_over_epoch:
            epoch_res = {
                loss.name: torch.tensor(self.batch_metrics[loss.name]).sum()
                / len(self.batch_metrics[loss.name])
                for loss in [self] + self.losses
            }
        else:
            epoch_res = {
                loss.name: loss.compute_metric(
                    torch.cat(self.y_true[loss.name], dim=0),
                    torch.cat(self.y_pred[loss.name], dim=0),
                )
                * self.losses_weights[loss.name]
                for loss in self.losses
            }
            additive_epoch_loss = 0.0
            for loss in self.losses:
                additive_epoch_loss += epoch_res[loss.name]
            epoch_res[self.name] = additive_epoch_loss

        state.update(epoch_loss=epoch_res)

        self.batch_metrics = None
        self.y_pred, self.y_true = None, None

    def on_eval_batch_end(self, state: State):
        """
        For each loss, computes the average metric in the batch wrt the number
        of timesteps (default is 1 for static datasets)
        unless statistics are accumulated over the entire epoch

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_over_epoch:
            for k, v in state.batch_loss.items():
                self.batch_metrics[k].append(
                    v.item() / self.timesteps_in_batch
                )

        self.timesteps_in_batch = None

    def compute_metric(
        self, targets: torch.Tensor, predictions: torch.Tensor
    ) -> torch.tensor:
        """
        Sums the value of all different losses into one

        Args:
            targets (:class:`torch.Tensor`): tensor of ground truth values
            predictions (:class:`torch.Tensor`):
                tensor of predictions of the model

        Returns:
            A tensor with the metric value
        """
        loss_sum = 0.0
        for loss in self.losses:
            single_loss = (
                loss.compute_metric(targets, predictions)
                * self.losses_weights[loss.name]
            )
            loss_sum += single_loss
        return loss_sum

    def accumulate_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> None:
        """
        Accumulates predictions and targets of the batch into a list
        for each loss, so as to compute aggregated statistics at the end
        of an epoch.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        for loss in self.losses:
            y_pred_batch, y_true_batch = loss.get_predictions_and_targets(
                targets, *outputs
            )
            metric_name = loss.name

            self.y_pred[metric_name].append(
                y_pred_batch.detach().cpu()
                if self.force_cpu
                else y_pred_batch.detach()
            )
            self.y_true[metric_name].append(
                y_true_batch.detach().cpu()
                if self.force_cpu
                else y_true_batch.detach()
            )

    def forward(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> dict:
        """
        For each scorer, it computes a loss and returns them into a dictionary,
        alongside the sum of all losses.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        res = {}
        loss_sum = 0.0

        for loss in self.losses:
            y_pred_batch, y_true_batch = loss.get_predictions_and_targets(
                targets, *outputs
            )
            single_loss = (
                loss.compute_metric(y_true_batch, y_pred_batch)
                * self.losses_weights[loss.name]
            )

            res[loss.name] = single_loss
            loss_sum += single_loss

        res[self.name] = loss_sum
        return res


class Classification(Metric):
    r"""
    Generic metric for classification tasks. Used to maximize code reuse
    for classical metrics.
    """

    def __init__(
        self,
        use_as_loss=False,
        reduction="mean",
        accumulate_over_epoch: bool = True,
        force_cpu: bool = True,
        device: str = "cpu",
        **kwargs: dict,
    ):
        """
        Initialize the base classification metric wrapper.

        Args:
            use_as_loss (bool): Whether to treat this metric as a loss.
            reduction (str): Reduction to use for underlying loss functions.
            accumulate_over_epoch (bool): Whether to accumulate predictions and
                targets to compute an epoch-level metric.
            force_cpu (bool): Whether to move accumulated tensors to CPU.
            device (str): Device identifier.
            **kwargs: Extra metric-specific parameters forwarded to
                :class:`Metric`.

        Side effects:
            Initializes the metric base class and sets ``self.metric`` to
            ``None``. Subclasses must assign a callable metric/loss.
        """
        super().__init__(
            use_as_loss=use_as_loss,
            reduction=reduction,
            accumulate_over_epoch=accumulate_over_epoch,
            force_cpu=force_cpu,
            device=device,
            **kwargs,
        )
        self.metric = None

    def get_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns output[0] as predictions and dataset targets. Squeezes the
        first dimension of output and targets to get single vector.

        Args:
            targets (:class:`torch.Tensor`): ground truth
            outputs (List[:class:`torch.Tensor`]): outputs of the model

        Returns:
            A tuple of tensors (predicted_values, target_values)
        """
        outputs = outputs[0].squeeze(dim=1)

        if len(targets.shape) == 2:
            targets = targets.squeeze(dim=1)

        return outputs, targets

    def compute_metric(
        self, targets: torch.Tensor, predictions: torch.Tensor
    ) -> torch.tensor:
        """
        Applies a classification metric
        (to be subclassed as it is None in this class)

        Args:
            targets (:class:`torch.Tensor`): tensor of ground truth values
            predictions (:class:`torch.Tensor`):
                tensor of predictions of the model

        Returns:
            A tensor with the metric value
        """
        metric = self.metric(predictions, targets)
        return metric


class Regression(Metric):
    r"""
    Generic metric for regression tasks. Used to maximize code reuse
    for classical metrics.
    """

    def __init__(
        self,
        use_as_loss=False,
        reduction="mean",
        accumulate_over_epoch: bool = True,
        force_cpu: bool = True,
        device: str = "cpu",
        **kwargs: dict,
    ):
        """
        Initialize the base regression metric wrapper.

        Args:
            use_as_loss (bool): Whether to treat this metric as a loss.
            reduction (str): Reduction to use for underlying loss functions.
            accumulate_over_epoch (bool): Whether to accumulate predictions and
                targets to compute an epoch-level metric.
            force_cpu (bool): Whether to move accumulated tensors to CPU.
            device (str): Device identifier.
            **kwargs: Extra metric-specific parameters forwarded to
                :class:`Metric`.

        Side effects:
            Initializes the metric base class and sets ``self.metric`` to
            ``None``. Subclasses must assign a callable metric/loss.
        """
        super().__init__(
            use_as_loss=use_as_loss,
            reduction=reduction,
            accumulate_over_epoch=accumulate_over_epoch,
            force_cpu=force_cpu,
            device=device,
            **kwargs,
        )
        self.metric = None

    def get_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns output[0] as predictions and dataset targets.
        Squeezes the first dimension of output and targets to get
        single vector.

        Args:
            targets (:class:`torch.Tensor`): ground truth
            outputs (List[:class:`torch.Tensor`]): outputs of the model

        Returns:
            A tuple of tensors (predicted_values, target_values)
        """
        outputs = outputs[0].squeeze(dim=1)

        if len(targets.shape) == 2:
            targets = targets.squeeze(dim=1)

        return outputs, targets

    def compute_metric(
        self, targets: torch.Tensor, predictions: torch.Tensor
    ) -> torch.tensor:
        """
        Applies a regression metric
        (to be subclassed as it is None in this class)

        Args:
            targets (:class:`torch.Tensor`): tensor of ground truth values
            predictions (:class:`torch.Tensor`):
                tensor of predictions of the model

        Returns:
            A tensor with the metric value
        """
        metric = self.metric(predictions, targets)
        return metric


class MulticlassClassification(Classification):
    r"""
    Wrapper around :class:`torch.nn.CrossEntropyLoss`
    """

    def __init__(
        self,
        use_as_loss=False,
        reduction="mean",
        accumulate_over_epoch: bool = True,
        force_cpu: bool = True,
        device: str = "cpu",
        **kwargs: dict,
    ):
        """
        Initialize multiclass classification using cross-entropy loss.

        Args:
            use_as_loss (bool): Whether to treat this metric as a loss.
            reduction (str): Reduction passed to :class:`torch.nn.CrossEntropyLoss`.
            accumulate_over_epoch (bool): Whether to compute epoch-level values.
            force_cpu (bool): Whether to move accumulated tensors to CPU.
            device (str): Device identifier.
            **kwargs: Extra parameters forwarded to the base class.

        Side effects:
            Sets ``self.metric`` to a :class:`torch.nn.CrossEntropyLoss`
            instance.
        """
        super().__init__(
            use_as_loss=use_as_loss,
            reduction=reduction,
            accumulate_over_epoch=accumulate_over_epoch,
            force_cpu=force_cpu,
            device=device,
            **kwargs,
        )
        self.metric = CrossEntropyLoss(reduction=reduction)


class MeanSquareError(Regression):
    r"""
    Wrapper around :class:`torch.nn.MSELoss`
    """

    def __init__(
        self,
        use_as_loss=False,
        reduction="mean",
        accumulate_over_epoch: bool = True,
        force_cpu: bool = True,
        device: str = "cpu",
        **kwargs: dict,
    ):
        """
        Initialize mean squared error regression (MSE).

        Args:
            use_as_loss (bool): Whether to treat this metric as a loss.
            reduction (str): Reduction passed to :class:`torch.nn.MSELoss`.
            accumulate_over_epoch (bool): Whether to compute epoch-level values.
            force_cpu (bool): Whether to move accumulated tensors to CPU.
            device (str): Device identifier.
            **kwargs: Extra parameters forwarded to the base class.

        Side effects:
            Sets ``self.metric`` to a :class:`torch.nn.MSELoss` instance.
        """
        super().__init__(
            use_as_loss=use_as_loss,
            reduction=reduction,
            accumulate_over_epoch=accumulate_over_epoch,
            force_cpu=force_cpu,
            device=device,
            **kwargs,
        )
        self.metric = MSELoss(reduction=reduction)


class MeanAbsoluteError(Regression):
    r"""
    Wrapper around :class:`torch.nn.L1Loss`
    """

    def __init__(
        self,
        use_as_loss=False,
        reduction="mean",
        accumulate_over_epoch: bool = True,
        force_cpu: bool = True,
        device: str = "cpu",
        **kwargs: dict,
    ):
        """
        Initialize mean absolute error regression (L1).

        Args:
            use_as_loss (bool): Whether to treat this metric as a loss.
            reduction (str): Reduction passed to :class:`torch.nn.L1Loss`.
            accumulate_over_epoch (bool): Whether to compute epoch-level values.
            force_cpu (bool): Whether to move accumulated tensors to CPU.
            device (str): Device identifier.
            **kwargs: Extra parameters forwarded to the base class.

        Side effects:
            Sets ``self.metric`` to a :class:`torch.nn.L1Loss` instance.
        """
        super().__init__(
            use_as_loss=use_as_loss,
            reduction=reduction,
            accumulate_over_epoch=accumulate_over_epoch,
            force_cpu=force_cpu,
            device=device,
            **kwargs,
        )
        self.metric = L1Loss(reduction=reduction)


class MulticlassAccuracy(Metric):
    """
    Implements multiclass classification accuracy.
    """

    @staticmethod
    def _get_correct(output):
        """
        Returns the argmax of the output alongside dimension 1.
        """
        return torch.argmax(output, dim=1)

    def get_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Takes output[0] as predictions and computes a discrete class
        using argmax. Returns standard dataset targets as well. Squeezes
        the first dimension of output and targets to get single vector.

        Args:
            targets (:class:`torch.Tensor`): ground truth
            outputs (List[:class:`torch.Tensor`]): outputs of the model

        Returns:
            A tuple of tensors (predicted_values, target_values)
        """
        pred = outputs[0]
        correct = self._get_correct(pred)

        if len(targets.shape) == 2:
            targets = targets.squeeze(dim=1)

        return correct, targets

    def compute_metric(
        self, targets: torch.Tensor, predictions: torch.Tensor
    ) -> torch.tensor:
        """
        Takes output[0] as predictions and computes a discrete class using
        argmax. Returns standard dataset targets as well. Squeezes the first
        dimension of output and targets to get single vector.

        Args:
            targets (:class:`torch.Tensor`): tensor of ground truth values
            predictions (:class:`torch.Tensor`):
                tensor of predictions of the model

        Returns:
            A tensor with the metric value
        """
        metric = (
            100.0 * (predictions == targets).sum().float() / targets.size(0)
        )
        return metric


class AllocatedGPUMemory(Metric):
    """Metric that reports current allocated CUDA memory (in MB)."""

    def get_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Query the current allocated GPU memory.

        Args:
            targets (torch.Tensor): Unused.
            *outputs (List[torch.Tensor]): Unused.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: A pair of identical 1D tensors
            containing the allocated GPU memory in megabytes (MB).

        Raises:
            RuntimeError: If CUDA is not available or not initialized.

        Side effects:
            Queries the CUDA runtime via :func:`torch.cuda.memory_allocated`.
        """
        gpu_mem = torch.tensor([torch.cuda.memory_allocated()]).float() / (
            1024 * 1024
        )
        return gpu_mem, gpu_mem

    def compute_metric(
        self, targets: torch.Tensor, predictions: torch.Tensor
    ) -> torch.tensor:
        """
        Compute the metric from predicted values.

        Args:
            targets (torch.Tensor): Unused (kept for API compatibility).
            predictions (torch.Tensor): Tensor containing memory values (MB).

        Returns:
            torch.Tensor: Mean of ``predictions``.
        """
        return predictions.mean()


class ToyMetric(Metric):
    r"""
    Implements a toy metric.
    """

    @staticmethod
    def _get_correct(output):
        """
        Returns the argmax of the output alongside dimension 1.
        """
        return torch.argmax(output, dim=1)

    def get_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns output[0] and dataset targets

        Args:
            targets (:class:`torch.Tensor`): ground truth
            outputs (List[:class:`torch.Tensor`]): outputs of the model

        Returns:
            A tuple of tensors (predicted_values, target_values)
        """
        return outputs[0], targets

    def compute_metric(
        self, targets: torch.Tensor, predictions: torch.Tensor
    ) -> torch.tensor:
        """
        Computes a dummy score

        Args:
            targets (:class:`torch.Tensor`): tensor of ground truth values
            predictions (:class:`torch.Tensor`):
                tensor of predictions of the model

        Returns:
            A tensor with the metric value
        """
        metric = 100.0 * torch.ones(1)
        return metric


class SingleGraphMulticlassClassification(MulticlassClassification):
    r"""
    Wrapper around :class:`torch.nn.CrossEntropyLoss`
    """

    def get_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Extract predictions/targets for single-graph node classification.

        Args:
            targets (torch.Tensor): Full target tensor for all nodes.
            *outputs (List[torch.Tensor]): Model outputs expected to be a tuple
                ``(o, embeddings, idxs)`` where ``idxs`` selects the nodes to
                evaluate (train or eval indices).

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: ``(o, t)`` where ``o`` are the
            selected node logits and ``t`` are the corresponding targets.
        """
        # o and h have alredy been filtered by the model according to
        # required data split indexes
        o, _, idxs = outputs
        t = targets[idxs]
        return o, t


class SingleGraphMulticlassAccuracy(MulticlassAccuracy):
    r"""
    Wrapper around :class:`torch.nn.CrossEntropyLoss`
    """

    def get_predictions_and_targets(
        self, targets: torch.Tensor, *outputs: List[torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Extract predicted classes/targets for single-graph node accuracy.

        Args:
            targets (torch.Tensor): Full target tensor for all nodes.
            *outputs (List[torch.Tensor]): Model outputs expected to be a tuple
                ``(o, embeddings, idxs)`` where ``idxs`` selects the nodes to
                evaluate (train or eval indices).

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: ``(pred, t)`` where ``pred`` are
            the predicted classes and ``t`` are the corresponding targets.
        """
        # o and h have alredy been filtered by the model according to
        # required data split indexes
        o, _, idxs = outputs
        pred = self._get_correct(o)
        if len(targets.shape) == 2:
            targets = targets.squeeze(dim=1)
        t = targets[idxs]

        return pred, t
