"""Optimizer callback wrapper for the training engine.

Instantiates a PyTorch optimizer from a dotted path and exposes lifecycle hooks.
"""

import copy

from mlwiz.util import s2c
from mlwiz.model.interface import ModelInterface
from mlwiz.training.event.handler import EventHandler


class Optimizer(EventHandler):
    """
    Optimizer is the main event handler for optimizers.
    Just pass a PyTorch optimizer together with its arguments in the
    configuration file.

    Args:
        model (:class:`~mlwiz.model.interface.ModelInterface`):
            the model that has to be trained
        optimizer_class_name (str): dotted path to the optimizer class to use
        accumulate_gradients (bool): if ``True``, accumulate mini-batch
            gradients to perform a batch gradient update without
            loading the entire batch in memory
        kwargs (dict): additional parameters for the specific optimizer
    """

    def __init__(
        self,
        model: ModelInterface,
        optimizer_class_name: str,
        accumulate_gradients: bool = False,
        **kwargs: dict,
    ):
        """
        Instantiate the underlying PyTorch optimizer.

        Args:
            model (ModelInterface): Model whose parameters will be optimized.
            optimizer_class_name (str): Dotted path to the optimizer class.
            accumulate_gradients (bool): If ``True``, gradients are accumulated
                across batches and an optimizer step is performed at the end of
                the epoch. If ``False``, step/zero_grad happen per batch.
            **kwargs: Additional keyword arguments forwarded to the optimizer
                constructor.

        Side effects:
            Stores the instantiated optimizer on ``self.optimizer``.
        """
        super().__init__()
        self.optimizer = s2c(optimizer_class_name)(
            model.parameters(), **kwargs
        )
        self.accumulate_gradients = accumulate_gradients

    def load_state_dict(self, state_dict):
        """
        Loads the state_dict of the optimizer from a checkpoint

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        self.optimizer.load_state_dict(state_dict)

    def on_fit_start(self, state):
        """
        If a checkpoint is present, load the state of the optimizer

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if state.optimizer_state is not None:
            self.optimizer.load_state_dict(state.optimizer_state)

    def on_training_epoch_start(self, state):
        """
        At the start of epoch, and if the gradient has been accumulated
        across the entire epoch, zeroes the gradient of the optimizer.

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if self.accumulate_gradients:
            self.optimizer.zero_grad()

    def on_training_batch_start(self, state):
        """
        At the start of a batch, if batch updates are in order,
        zeroes the gradient of the optimizer

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_gradients:
            self.optimizer.zero_grad()

    def on_training_batch_end(self, state):
        """
        At the end of a batch, if batch updates are in order,
        performs a weight update

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if not self.accumulate_gradients:
            grad_scaler = getattr(state, "grad_scaler", None)
            if grad_scaler is not None:
                grad_scaler.step(self.optimizer)
                grad_scaler.update()
            else:
                self.optimizer.step()

    def on_training_epoch_end(self, state):
        """
        At the end of a batch, and if the gradient has been
        accumulated across the entire epoch, performs a weight update

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        if self.accumulate_gradients:
            grad_scaler = getattr(state, "grad_scaler", None)
            if grad_scaler is not None:
                grad_scaler.step(self.optimizer)
                grad_scaler.update()
            else:
                self.optimizer.step()

    def on_epoch_end(self, state):
        """
        Updates the state of the optimizer into the state
        at the end of the epoch

        Args:
            state (:class:`~training.event.state.State`):
                object holding training information
        """
        grad_scaler = getattr(state, "grad_scaler", None)
        scaler_state = (
            copy.deepcopy(grad_scaler.state_dict())
            if grad_scaler is not None
            else None
        )
        state.update(
            optimizer_state=copy.deepcopy(self.optimizer.state_dict()),
            scaler_state=scaler_state,
        )
