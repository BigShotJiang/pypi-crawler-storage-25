"""iFlytek (讯飞) TTS provider adapter — WebSocket-based."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
from openspeechapi.logging_config import logger
import urllib.parse
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import formatdate
from typing import Any

import httpx
import websockets

from openspeechapi.core.base import TTSProvider
from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioChunk, AudioData, TTSOptions
from openspeechapi.core.settings import BaseSettings

@dataclass
class IflytekTTSSettings(BaseSettings):
    app_id: str = ""
    api_key: str = ""
    api_secret: str = ""
    voice: str = "xiaoyan"
    speed: int = 50
    # Audio output encoding requested from iFlytek.
    #   - "lame":  MP3 frames (default; smaller, but caller must decode)
    #   - "raw":   16-bit PCM @ 16 kHz mono, big-endian L16 (drop-in
    #              playable as raw PCM; required by callers that wrap the
    #              bytes in a fixed-format wire envelope and assume PCM,
    #              e.g. wallex's RESP_VOICE which advertises
    #              encoding=raw/bitDepth=16/sampleRate=16000 to the
    #              panel — feeding MP3 bytes through that envelope plays
    #              back as pure noise on the speaker).
    #   - "speex"/"speex-wb-7": Speex narrowband / wideband (low-bitrate,
    #              used by some embedded Wallex panels with constrained
    #              uplink). Requires ``speex_size`` to declare the frame
    #              size iFlytek should produce. Caller must run a Speex
    #              decoder; not auto-handled by browsers.
    # Default stays "lame" for backward-compat; deployments that need
    # PCM (wallex / direct hardware playback) or Speex (embedded panels)
    # override via yaml.
    aue: str = "lame"
    # Output sample rate for raw PCM mode (only meaningful when
    # aue="raw"). 16000 matches what the panel and the iFlytek
    # default both expect; left configurable so an 8 kHz device or
    # a 24 kHz studio path doesn't have to fork the provider.
    auf_rate: int = 16000
    # Volume (0-100). iFlytek default is 50; making it explicit so
    # the parameter parity with Java's TtsConfig is complete.
    volume: int = 50
    # Pitch (0-100). Same rationale as volume.
    pitch: int = 50
    # Speex frame size (only meaningful when aue startswith "speex").
    # iFlytek expects an integer that selects a Speex bitrate / frame
    # mode; ``0`` is "auto-pick by aue tag". Leave 0 unless the client
    # decoder requires a specific frame size. Mirrors Java
    # ``AsrConfig.speex-size`` / ``TtsConfig`` parameter.
    speex_size: int = 0
    # ``ws_host`` / ``ws_path`` — iFlytek TTS WebSocket endpoint.
    # Override in yaml (or via ``OPENSPEECH_IFLYTEK_TTS_HOST`` env var)
    # for region-specific endpoints. Default is the global endpoint.
    ws_host: str = "tts-api.xfyun.cn"
    ws_path: str = "/v2/tts"
    # ``timeout_secs`` — connect / read timeout for the underlying
    # httpx AsyncClient. Java's TtsConfig defaults to 8s; we mirror
    # that for parity. Increase only when the iFlytek endpoint is
    # consistently slow to handshake.
    timeout_secs: int = 8

class IflytekTTS(TTSProvider):
    name = "iflytek-tts"
    provider_type = ProviderType.TTS
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = IflytekTTSSettings
    capabilities = {Capability.BATCH, Capability.STREAMING, Capability.MULTILINGUAL}
    field_options = {
        "voice": [
            "xiaoyan", "aisjiuxu", "aisxping", "aisjinger", "aisbabyxu",
            "x4_lingxiaolu_em", "x4_lingfeizhe_em", "xiaoyu", "xiaoqi",
            "xiaofeng", "xiaomei", "xiaolin", "xiaorong", "xiaoqian",
            "catherine", "john", "laura", "yuka", "xiaoqiukor",
            # English assistant-style voices used by wallex deployments.
            "x4_enuk_ashleigh_assist",
        ],
        "aue": ["lame", "raw", "speex", "speex-wb-7"],
    }

    def __init__(self, settings: IflytekTTSSettings | None = None) -> None:
        self.settings = settings or IflytekTTSSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=float(self.settings.timeout_secs))
            self._owns_client = True

    async def stop(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
        self._client = None

    async def health_check(self) -> bool:
        return bool(self.settings.app_id) and bool(self.settings.api_key) and bool(self.settings.api_secret)

    def _build_auth_url(self) -> str:
        """Build HMAC-SHA256 signed WebSocket URL."""
        now = datetime.now(tz=timezone.utc)
        date = formatdate(timeval=now.timestamp(), localtime=False, usegmt=True)

        host = self.settings.ws_host
        path = self.settings.ws_path
        signature_origin = (
            f"host: {host}\n"
            f"date: {date}\n"
            f"GET {path} HTTP/1.1"
        )
        signature_sha = hmac.new(
            self.settings.api_secret.encode("utf-8"),
            signature_origin.encode("utf-8"),
            hashlib.sha256,
        ).digest()
        signature = base64.b64encode(signature_sha).decode("utf-8")

        authorization_origin = (
            f'api_key="{self.settings.api_key}", '
            f'algorithm="hmac-sha256", '
            f'headers="host date request-line", '
            f'signature="{signature}"'
        )
        authorization = base64.b64encode(
            authorization_origin.encode("utf-8")
        ).decode("utf-8")

        params = urllib.parse.urlencode(
            {"authorization": authorization, "date": date, "host": host}
        )
        return f"wss://{host}{path}?{params}"

    async def synthesize(
        self, text: str, opts: TTSOptions | None = None
    ) -> AudioData:
        """Batch synthesize by collecting all stream chunks."""
        parts: list[bytes] = []
        async for chunk in self.synthesize_stream(text, opts):
            parts.append(chunk.data)
        audio_bytes = b"".join(parts)
        # Format / sample_rate must reflect what iFlytek actually returned —
        # callers downstream may set wire-protocol encoding metadata from
        # this field, and a wrong tag on the bytes plays back as noise on
        # raw-PCM consumers.
        aue = self.settings.aue
        if aue == "raw":
            fmt = "pcm_s16le"
            sr = self.settings.auf_rate
        elif aue.startswith("speex"):
            # Speex narrowband is 8 kHz, wideband ("speex-wb-*") is 16 kHz.
            fmt = "speex"
            sr = 16000 if "wb" in aue else 8000
        else:
            fmt = "mp3"
            sr = 16000
        logger.info(
            "iFlytek TTS: {} chunks, {} bytes total, format={}, sample_rate={}",
            len(parts), len(audio_bytes), fmt, sr,
        )
        return AudioData(
            data=audio_bytes,
            sample_rate=sr,
            channels=1,
            format=fmt,
        )

    # iFlytek voice catalog — vcn → (display name, language, group)
    _VOICES = [
        # 中文
        ("xiaoyan",           "小燕 — 中文女声",         "zh_cn", "中文"),
        ("aisjiuxu",          "许久 — 中文男声",         "zh_cn", "中文"),
        ("aisxping",          "小萍 — 中文女声",         "zh_cn", "中文"),
        ("aisjinger",         "小婧 — 中文女声",         "zh_cn", "中文"),
        ("aisbabyxu",         "许小宝 — 童声",           "zh_cn", "中文"),
        ("x4_lingxiaolu_em",  "凌小路 — 情感男声",       "zh_cn", "中文"),
        ("x4_lingfeizhe_em",  "凌飞哲 — 情感男声",       "zh_cn", "中文"),
        ("xiaoyu",            "小宇 — 中文男声",         "zh_cn", "中文"),
        ("xiaoqi",            "小琪 — 中文女声",         "zh_cn", "中文"),
        ("xiaofeng",          "小峰 — 中文男声",         "zh_cn", "中文"),
        ("xiaomei",           "小梅 — 粤语女声",         "zh_cn", "粤语"),
        ("xiaolin",           "小林 — 台湾女声",         "zh_cn", "中文"),
        ("xiaorong",          "小蓉 — 四川女声",         "zh_cn", "方言"),
        ("xiaoqian",          "小芊 — 东北女声",         "zh_cn", "方言"),
        # English
        ("catherine",         "Catherine — English Female", "en_us", "English"),
        ("john",              "John — English Male",        "en_us", "English"),
        ("laura",             "Laura — English Female",     "en_us", "English"),
        # Japanese
        ("yuka",              "Yuka — Japanese Female",     "ja_jp", "日本語"),
        # Korean
        ("xiaoqiukor",        "小秋 — Korean Female",       "ko_kr", "한국어"),
    ]

    def _build_ws_message(self, text: str, voice: str | None = None, speed: float | None = None) -> dict:
        """Build the WebSocket request message."""
        vcn = voice or self.settings.voice
        spd = int(speed * 50) if speed and speed != 1.0 else self.settings.speed
        text_b64 = base64.b64encode(text.encode("utf-8")).decode("utf-8")
        business: dict[str, Any] = {
            "aue": self.settings.aue,
            "vcn": vcn,
            "speed": spd,
            "volume": self.settings.volume,
            "pitch": self.settings.pitch,
            "tte": "UTF8",
        }
        aue = self.settings.aue
        if aue == "lame":
            # ``sfl=1`` (stream-frame-length) is an MP3-only knob that
            # tells iFlytek to emit per-frame audio rather than waiting
            # for the whole file. It has no meaning for raw PCM (raw is
            # always streamed as 40 ms slices) and iFlytek rejects the
            # combo with a code 10005 "invalid parameter" — so we only
            # send it on the lame path.
            business["sfl"] = 1
        elif aue == "raw":
            # Raw / L16 mode requires ``auf`` to declare the PCM
            # sample-rate iFlytek should produce. Java wallex sends
            # ``audio/L16;rate=16000`` here; we mirror that exactly.
            business["auf"] = f"audio/L16;rate={self.settings.auf_rate}"
        elif aue.startswith("speex"):
            # Speex narrowband / wideband. ``speex_size`` is the iFlytek
            # frame-size selector (0 = engine default; non-zero values
            # match the Java ``TtsConfig.speex-size`` parameter).
            if self.settings.speex_size:
                business["speex_size"] = self.settings.speex_size
        return {
            "common": {"app_id": self.settings.app_id},
            "business": business,
            "data": {
                "status": 2,
                "text": text_b64,
            },
        }

    async def list_voices(self) -> list[dict]:
        """Return available iFlytek voices."""
        return [
            {"name": vcn, "description": desc, "language": lang, "group": group}
            for vcn, desc, lang, group in self._VOICES
        ]

    async def synthesize_stream(
        self, text: str, opts: TTSOptions | None = None
    ) -> AsyncIterator[AudioChunk]:
        """Stream MP3 audio chunks as they arrive from iFlytek WebSocket."""
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        opts = opts or TTSOptions()

        voice = opts.voice or self.settings.voice
        speed = opts.speed if opts.speed != 1.0 else None
        logger.info("iFlytek stream: voice={}, speed={}, text={} chars", voice, speed, len(text))

        url = self._build_auth_url()
        msg = self._build_ws_message(text, voice=voice, speed=speed)
        seq = 0

        async with websockets.connect(url) as ws:
            await ws.send(json.dumps(msg))

            async for message in ws:
                resp = json.loads(message)
                code = resp.get("code", -1)
                if code != 0:
                    raise RuntimeError(
                        f"iFlytek TTS error [{code}]: {resp.get('message', 'unknown')}"
                    )

                data = resp.get("data", {})
                audio_b64 = data.get("audio", "")
                is_final = data.get("status") == 2

                if audio_b64:
                    chunk_bytes = base64.b64decode(audio_b64)
                    yield AudioChunk(data=chunk_bytes, sequence=seq, is_final=is_final)
                    seq += 1

                if is_final:
                    break
