"""iFlytek (讯飞) STT provider adapter — WebSocket-based."""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
from openspeechapi.logging_config import logger
import time
import urllib.parse
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import formatdate
from typing import Any

import httpx
import websockets

from openspeechapi.core.base import STTProvider

from openspeechapi.core.enums import Capability, ExecMode, ProviderType
from openspeechapi.core.models import AudioData, STTOptions, Transcription
from openspeechapi.core.settings import BaseSettings

@dataclass
class IflytekSTTSettings(BaseSettings):
    app_id: str = ""
    api_key: str = ""
    api_secret: str = ""
    # iFlytek-canonical language code. Acceptable values per iFlytek
    # IAT docs: ``zh_cn``, ``en_us``, ``ja_jp``, ``ko_kr``, ``ru-ru``.
    # Common ISO short codes (``en``, ``zh``, ``ja``, ``ko``, ``ru``)
    # are accepted here and mapped on the request hop — see
    # ``_canonical_language``. iFlytek silently falls back to ``zh_cn``
    # when given an unrecognised value, so the alias mapping prevents
    # English audio from being transcribed by the Chinese model
    # (caught 04-28 by an "english only" deployment that had set
    # ``language: en`` and got hanzi back).
    language: str = "zh_cn"
    # ``vad_eos`` — milliseconds of trailing silence iFlytek treats as
    # end-of-sentence before emitting the final result (``status == 2``).
    # iFlytek's documented default is 2000; lower values give faster
    # finalization at the cost of cutting off slow speakers mid-thought.
    # The 04-28 17:00 audit found vad_eos=2000 contributed ~89% of the
    # user-perceived latency budget — the speech itself only used ~3 s
    # but iFlytek waited an additional 2 s of silence before declaring
    # final. Common production values: 800-1000 (responsive),
    # 1500 (conservative), 2000 (default, slow). Below ~500 risks
    # premature finalization on natural pauses. Per-deployment override
    # via ``speech_providers.yaml`` so different sites can pick their
    # own latency-vs-tolerance trade-off.
    vad_eos: int = 2000
    # ``ltc`` — sentence-level timestamp granularity sent in the
    # business block of the IAT request (1 = sentence segments only;
    # 2 = + word boundaries; 3 = + character boundaries). Java's
    # ``AsrConfig.ltc`` defaults to 3; we mirror that so downstream
    # consumers expecting per-character timing offsets keep working.
    # Lower values shave a few bytes per response and slightly reduce
    # post-processing work for callers that don't use the timestamps.
    ltc: int = 3
    # ``ws_host`` / ``ws_path`` — iFlytek IAT WebSocket endpoint. The
    # default ``iat-api.xfyun.cn`` is the global endpoint; multi-region
    # deployments (e.g. directed-domain endpoints such as
    # ``ws-api-dx.xfyun.cn``) override these in yaml or via env var
    # so the WS URL never requires a code change.
    ws_host: str = "iat-api.xfyun.cn"
    ws_path: str = "/v2/iat"
    # ``timeout_secs`` — connect / read timeout for the underlying
    # httpx AsyncClient. Java's AsrConfig defaults to 15s; we mirror
    # that. Lower if the network has aggressive proxies, higher only
    # if the iFlytek endpoint is consistently slow to handshake.
    timeout_secs: int = 15
    # ── Java AsrConfig parity (used as setdefault fallbacks) ────────
    # When a wallex client (panel) supplies ``audio.business``/
    # ``audio.common`` per-frame, those values flow through via
    # ``STTOptions.iflytek_business``/``STTOptions.iflytek_common`` and
    # become the WS first frame body. The settings below act as
    # ``setdefault`` fallbacks for keys the client omits, mirroring
    # Java ``AsrConfig``'s field set so the two implementations
    # produce identical wire frames given the same panel payload.
    #
    # ``domain`` — iFlytek IAT domain. Java default ``iat``; a few
    # vertical models (``medical`` / ``tv``) exist but most
    # deployments stay on the general one.
    domain: str = "iat"
    # ``accent`` — only meaningful when ``language=="zh_cn"`` (selects
    # mandarin vs. cantonese etc.). Java sends ``mandarin`` blindly;
    # we keep the same default so the WS frame matches Java byte-for-
    # byte when the panel omits ``business.accent``. iFlytek treats
    # it as a no-op for non-Chinese language codes.
    accent: str = "mandarin"
    # ``dwa`` — dynamic word adjustment / wpgs (实时纠错). Java's
    # default ``wpgs`` is the realtime-correction mode panels rely on
    # for the partial-result protocol described in
    # ``stt-streaming-spec.md``. Empty disables it.
    dwa: str = "wpgs"
    # ``sample_rate`` — required by the IAT directed-domain endpoint
    # (``ws-api-dx.xfyun.cn``) which expects it in ``business``. Java
    # AsrConfig.sampleRate=16000.
    sample_rate: int = 16000


# iFlytek expects the full locale tag; common ISO short codes need to
# be translated. Keys are casefolded for tolerant matching. Values are
# the iFlytek-canonical strings the WS request will carry.
_LANGUAGE_ALIASES: dict[str, str] = {
    # Canonical pass-through (allow case variation)
    "zh_cn": "zh_cn", "en_us": "en_us", "ja_jp": "ja_jp",
    "ko_kr": "ko_kr", "ru-ru": "ru-ru", "ru_ru": "ru-ru",
    # ISO 639-1 short codes — most config sources use these
    "zh": "zh_cn", "zh-cn": "zh_cn", "zh-hans": "zh_cn",
    "en": "en_us", "en-us": "en_us", "en-gb": "en_us",
    "ja": "ja_jp", "ja-jp": "ja_jp",
    "ko": "ko_kr", "ko-kr": "ko_kr",
    "ru": "ru-ru",
}


def _canonical_language(raw: str | None) -> str:
    """Translate a configured language string to iFlytek's canonical form.

    Returns the iFlytek-canonical code (e.g. ``en_us``). Unknown inputs
    pass through unchanged so iFlytek surfaces a real protocol error
    instead of silently falling back to Chinese.
    """
    if not raw:
        return "zh_cn"
    return _LANGUAGE_ALIASES.get(raw.casefold().strip(), raw)


class IflytekSTT(STTProvider):
    name = "iflytek-stt"
    provider_type = ProviderType.STT
    execution_mode = ExecMode.IN_PROCESS
    settings_cls = IflytekSTTSettings
    capabilities = {Capability.BATCH, Capability.STREAMING, Capability.MULTILINGUAL}
    field_options = {
        "language": ["zh_cn", "en_us", "ja_jp", "ko_kr", "ru-ru"],
    }

    def __init__(self, settings: IflytekSTTSettings | None = None) -> None:
        self.settings = settings or IflytekSTTSettings()
        self._client: httpx.AsyncClient | None = None
        self._owns_client: bool = True

    def set_http_client(self, client) -> None:
        self._client = client
        self._owns_client = False

    async def start(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=float(self.settings.timeout_secs))
            self._owns_client = True
        # Surface the effective language (after alias mapping) and
        # vad_eos at startup so deployments can verify the iFlytek model
        # and silence-finalization threshold that will actually run.
        # The 04-28 audit caught a deployment shipping ``language: en``
        # (invalid) which silently routed every request to the Chinese
        # model; an analogous oversight on vad_eos would silently
        # double the user-perceived latency. Logging both makes
        # mis-config obvious from the first request.
        effective = _canonical_language(self.settings.language)
        if effective != self.settings.language:
            logger.info(
                "{} provider started, language={!r} (canonicalized from {!r}), vad_eos={}ms",
                self.name, effective, self.settings.language, self.settings.vad_eos,
            )
        else:
            logger.info(
                "{} provider started, language={!r}, vad_eos={}ms",
                self.name, effective, self.settings.vad_eos,
            )

    async def stop(self) -> None:
        if self._client and self._owns_client:
            await self._client.aclose()
        self._client = None
        logger.info("{} provider stopped", self.name)

    async def health_check(self) -> bool:
        return bool(self.settings.app_id) and bool(self.settings.api_key) and bool(self.settings.api_secret)

    def _build_auth_url(self) -> str:
        """Build HMAC-SHA256 signed WebSocket URL."""
        now = datetime.now(tz=timezone.utc)
        date = formatdate(timeval=now.timestamp(), localtime=False, usegmt=True)

        host = self.settings.ws_host
        path = self.settings.ws_path
        signature_origin = (
            f"host: {host}\n"
            f"date: {date}\n"
            f"GET {path} HTTP/1.1"
        )
        signature_sha = hmac.new(
            self.settings.api_secret.encode("utf-8"),
            signature_origin.encode("utf-8"),
            hashlib.sha256,
        ).digest()
        signature = base64.b64encode(signature_sha).decode("utf-8")

        authorization_origin = (
            f'api_key="{self.settings.api_key}", '
            f'algorithm="hmac-sha256", '
            f'headers="host date request-line", '
            f'signature="{signature}"'
        )
        authorization = base64.b64encode(
            authorization_origin.encode("utf-8")
        ).decode("utf-8")

        params = urllib.parse.urlencode(
            {"authorization": authorization, "date": date, "host": host}
        )
        return f"wss://{host}{path}?{params}"

    def _build_first_frame_blocks(
        self,
        opts: STTOptions | None,
        *,
        include_dwa: bool,
    ) -> tuple[dict, dict]:
        """Build the ``common`` / ``business`` blocks for the WS first frame.

        Mirrors Java ``AsrServiceImpl.sendToAsr`` semantics: when
        ``opts.iflytek_common``/``opts.iflytek_business`` is provided
        (typically by wallex relaying the panel's per-frame
        ``audio.common`` / ``audio.business``), those dicts are the
        source of truth. We only ``setdefault`` keys the client omitted,
        falling back to ``self.settings`` so a panel that misses a
        single field doesn't get a malformed frame.

        ``include_dwa`` differs between ``transcribe()`` (batch — no
        wpgs because there's no streaming protocol) and
        ``transcribe_stream()`` (always wpgs).
        """
        canon = _canonical_language(self.settings.language)
        eos = (opts.vad_eos
               if opts is not None and opts.vad_eos is not None
               else self.settings.vad_eos)

        # ── business block ─────────────────────────────────────────
        if opts is not None and opts.iflytek_business:
            # Panel-supplied is authoritative; copy then fill missing
            # keys from yaml so we never send a partial frame.
            business = dict(opts.iflytek_business)
        else:
            business = {}

        business.setdefault("language", canon)
        business.setdefault("domain", self.settings.domain)
        business.setdefault("vad_eos", eos)
        business.setdefault("ltc", self.settings.ltc)
        if include_dwa:
            business.setdefault("dwa", self.settings.dwa)
        # ``accent`` is only meaningful for the Chinese model. Java
        # sends ``mandarin`` blindly; we keep that for byte-for-byte
        # parity when the panel omits it AND language is zh_cn. For
        # other languages we leave it out entirely (sending it is a
        # no-op on iFlytek's side but confuses log readers).
        if "accent" not in business and canon == "zh_cn":
            business["accent"] = self.settings.accent

        # ── common block ──────────────────────────────────────────
        if opts is not None and opts.iflytek_common:
            common = dict(opts.iflytek_common)
        else:
            common = {}
        common.setdefault("app_id", self.settings.app_id)

        return common, business

    @staticmethod
    def _build_data_block(
        *, status: int, audio_b64: str, opts: STTOptions | None,
    ) -> dict:
        """Assemble the ``data`` block, merging panel-supplied extras.

        Canonical keys (``status``/``format``/``encoding``/``audio``)
        always win over ``iflytek_data_extras`` because the IAT spec
        requires them in a specific shape; extras like the panel's
        ``data_type`` flow through.
        """
        if opts is not None and opts.iflytek_data_extras:
            data = dict(opts.iflytek_data_extras)
        else:
            data = {}
        data["status"] = status
        data["format"] = "audio/L16;rate=16000"
        data["encoding"] = "raw"
        data["audio"] = audio_b64
        return data

    async def _connect_with_retry(self) -> "websockets.ClientConnection":
        """Connect to iFlytek IAT WS with backoff, mirroring Java parity.

        Java ``AsrServiceImpl.connectWithRetry`` does 4 attempts with
        300/600/1200ms backoff before giving up. The previous Python
        path was one-shot: a single TCP/handshake hiccup surfaced as a
        hard ASR failure. Aligning the retry budget keeps wallex's
        Python and Java front-ends behaviourally interchangeable on
        flaky links.
        """
        backoffs = (0.3, 0.6, 1.2)  # delays AFTER attempts 1, 2, 3
        last_exc: Exception | None = None
        for attempt in range(4):
            try:
                url = self._build_auth_url()
                ws = await websockets.connect(url)
                if attempt > 0:
                    logger.info(
                        "{}: WS connected on attempt {}/4",
                        self.name, attempt + 1,
                    )
                return ws
            except Exception as e:  # noqa: BLE001 — retry boundary
                last_exc = e
                logger.warning(
                    "{}: WS connect failed (attempt {}/4): {}",
                    self.name, attempt + 1, e,
                )
                if attempt < len(backoffs):
                    await asyncio.sleep(backoffs[attempt])
        raise RuntimeError(
            f"iFlytek STT connect failed after 4 attempts: {last_exc}"
        )

    async def transcribe(
        self, audio: AudioData, opts: STTOptions | None = None
    ) -> Transcription:
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")
        logger.info("{}: request received, audio={} bytes", self.name, len(audio.data))
        _t0 = time.perf_counter()

        audio_bytes = audio.data
        # iFlytek recommends ~40ms per frame at 16kHz 16bit mono = 1280 bytes.
        # Use larger frames (8000 bytes = ~250ms) with pacing to avoid server
        # read-timeout when sending pre-recorded audio faster than real-time.
        frame_size = 8000  # bytes per chunk (~250ms of 16kHz 16bit mono)
        # Pacing: small delay between frames to avoid server read-timeout
        # when sending pre-recorded audio faster than real-time.
        # 8000 bytes = 250ms of audio; 10ms interval = ~25x real-time.
        frame_interval = 0.01  # 10ms between frames (~25x real-time)

        result_texts: list[str] = []

        ws = await self._connect_with_retry()
        async with ws:
            # Send audio in chunks with interleaved receive
            total = len(audio_bytes)
            offset = 0
            status = 0  # 0=first frame
            frames_sent = 0

            while offset < total:
                end = min(offset + frame_size, total)
                chunk = audio_bytes[offset:end]

                if end >= total:
                    status = 2  # last frame
                elif offset > 0:
                    status = 1  # continue

                frame_data = base64.b64encode(chunk).decode("utf-8")

                if status == 0:
                    # First frame: panel-supplied common/business win;
                    # batch path doesn't carry wpgs (no streaming
                    # protocol) so include_dwa=False.
                    common, business = self._build_first_frame_blocks(
                        opts, include_dwa=False,
                    )
                    data_block = self._build_data_block(
                        status=0, audio_b64=frame_data, opts=opts,
                    )
                    msg = {
                        "common": common,
                        "business": business,
                        "data": data_block,
                    }
                    # Java parity: log the exact blocks we're about to
                    # ship to iFlytek. Debugging "wrong language /
                    # wrong endpoint" reports needs to see this from
                    # the log alone — Java's AsrServiceImpl prints the
                    # equivalent line at INFO.
                    logger.info(
                        "{}: ASR first frame business={}, common={}",
                        self.name,
                        json.dumps(business, ensure_ascii=False),
                        json.dumps(common, ensure_ascii=False),
                    )
                else:
                    msg = {
                        "data": self._build_data_block(
                            status=status, audio_b64=frame_data, opts=opts,
                        )
                    }

                await ws.send(json.dumps(msg))
                frames_sent += 1
                offset = end

                # Pacing: small delay between frames to avoid server timeout
                if status != 2 and frame_interval > 0:
                    await asyncio.sleep(frame_interval)

            logger.debug("{}: sent {} frames in {:.0f}ms", self.name, frames_sent,
                         (time.perf_counter() - _t0) * 1000)

            # Receive results
            async for message in ws:
                resp = json.loads(message)
                code = resp.get("code", -1)
                if code != 0:
                    raise RuntimeError(
                        f"iFlytek STT error [{code}]: {resp.get('message', 'unknown')}"
                    )

                data = resp.get("data", {})
                result = data.get("result", {})
                ws_items = result.get("ws", [])
                for ws_item in ws_items:
                    cw_list = ws_item.get("cw", [])
                    for cw in cw_list:
                        result_texts.append(cw.get("w", ""))

                if data.get("status") == 2:
                    break

        result = Transcription(text="".join(result_texts))
        logger.info("{}: completed in {:.0f}ms, result={} chars", self.name, (time.perf_counter() - _t0) * 1000, len(result.text))
        return result

    @staticmethod
    def _extract_segment_text(ws_items: list[dict]) -> str:
        """Extract text from a single response's ws array."""
        parts: list[str] = []
        for ws_item in ws_items:
            for cw in ws_item.get("cw", []):
                parts.append(cw.get("w", ""))
        return "".join(parts)

    async def transcribe_stream(
        self, stream: AsyncIterator[bytes], opts: STTOptions | None = None,
    ) -> AsyncIterator[Transcription]:
        """Stream audio chunks to iFlytek via WebSocket and yield transcriptions.

        Each bytes chunk from *stream* is a raw PCM frame (16kHz 16bit mono).
        A ``None`` or empty chunk signals end-of-stream (VAD end).

        The implementation uses two concurrent coroutines:
        - **sender**: reads chunks from *stream* and forwards them to iFlytek
          with natural pacing (frames arrive at ~real-time from the mic).
        - **receiver**: reads iFlytek responses, parses ``dwa=wpgs`` dynamic
          correction fields (``pgs``/``rg``), maintains a segment array, and
          yields partial ``Transcription`` on every response plus a final one
          on ``status == 2``.

        wpgs protocol:
        - ``pgs="apd"``: append — new segment at index ``sn``
        - ``pgs="rpl"``: replace — replace segments ``rg[0]..rg[1]`` with
          new content, effectively a correction of earlier partial results
        - No ``pgs`` field: legacy mode (no dynamic correction) — accumulate
        """
        if self._client is None:
            raise RuntimeError("Provider not started — call start() first")

        results: asyncio.Queue[Transcription | None] = asyncio.Queue()
        _t0 = time.perf_counter()
        _frames_sent = 0

        # Event to signal sender to stop (set by receiver when iFlytek
        # returns status=2 or the connection closes). This handles the case
        # where the user doesn't click stop — iFlytek's VAD triggers a final
        # result, and we need the sender to stop consuming the frame queue.
        _sender_stop = asyncio.Event()

        logger.debug("{}: connecting to iFlytek WebSocket...", self.name)
        ws = await self._connect_with_retry()
        async with ws:
            _t_connected = time.perf_counter()
            logger.info("{}: WS connected in {:.0f}ms", self.name,
                        (_t_connected - _t0) * 1000)

            async def sender() -> None:
                nonlocal _frames_sent
                is_first = True
                try:
                    async for chunk in stream:
                        # Check if receiver signaled us to stop
                        if _sender_stop.is_set():
                            break
                        if chunk is None or len(chunk) == 0:
                            # End-of-stream sentinel — send last frame
                            break
                        frame_data = base64.b64encode(chunk).decode("utf-8")
                        if is_first:
                            # First frame: panel-supplied common/business win;
                            # streaming path always carries wpgs (see
                            # stt-streaming-spec.md realtime-correction
                            # protocol) so include_dwa=True.
                            common, business = self._build_first_frame_blocks(
                                opts, include_dwa=True,
                            )
                            data_block = self._build_data_block(
                                status=0, audio_b64=frame_data, opts=opts,
                            )
                            msg = {
                                "common": common,
                                "business": business,
                                "data": data_block,
                            }
                            # Java parity (AsrServiceImpl line 221): log
                            # the first-frame business + common at INFO so
                            # operators can verify which language/eos/dwa
                            # the panel actually requested without
                            # rebuilding the call from yaml + STTOptions.
                            logger.info(
                                "{}: ASR first frame business={}, common={}",
                                self.name,
                                json.dumps(business, ensure_ascii=False),
                                json.dumps(common, ensure_ascii=False),
                            )
                            is_first = False
                        else:
                            msg = {
                                "data": self._build_data_block(
                                    status=1, audio_b64=frame_data, opts=opts,
                                )
                            }
                        await ws.send(json.dumps(msg))
                        _frames_sent += 1
                        if _frames_sent == 1:
                            logger.debug("{}: first frame sent at {:.0f}ms",
                                         self.name, (time.perf_counter() - _t0) * 1000)

                    # Send empty last frame to signal end (only if WS still open)
                    if not _sender_stop.is_set():
                        last_msg = {
                            "data": self._build_data_block(
                                status=2, audio_b64="", opts=opts,
                            )
                        }
                        await ws.send(json.dumps(last_msg))
                except websockets.exceptions.ConnectionClosed:
                    # iFlytek closed the connection (e.g. server read timeout
                    # or VAD-triggered close). This is expected when the user
                    # doesn't click stop — just exit silently.
                    pass
                finally:
                    logger.debug(
                        "{}: stream sender done, sent {} frames in {:.0f}ms",
                        self.name, _frames_sent, (time.perf_counter() - _t0) * 1000,
                    )

            async def receiver() -> None:
                # Segment array for wpgs dynamic correction.
                # Index = sn (sentence number from iFlytek).
                # Each element is the text for that segment.
                segments: list[str] = []
                _resp_count = 0

                try:
                    async for message in ws:
                        resp = json.loads(message)
                        code = resp.get("code", -1)
                        if code != 0:
                            raise RuntimeError(
                                f"iFlytek STT error [{code}]: {resp.get('message', 'unknown')}"
                            )

                        _resp_count += 1
                        data = resp.get("data", {})
                        resp_status = data.get("status", 0)
                        result = data.get("result", {})
                        ws_items = result.get("ws", [])
                        pgs = result.get("pgs", "")  # "apd" or "rpl"
                        rg = result.get("rg", [])    # [start, end] for rpl
                        sn = result.get("sn", 0)     # segment number

                        seg_text = self._extract_segment_text(ws_items)

                        if _resp_count == 1:
                            logger.debug("{}: first response at {:.0f}ms  sn={}  pgs={}",
                                         self.name, (time.perf_counter() - _t0) * 1000,
                                         sn, pgs or "none")

                        if pgs == "rpl" and len(rg) == 2:
                            # Replace: clear segments rg[0]..rg[1], put new
                            # text at rg[0], remove the rest in range.
                            start, end = rg[0], rg[1]
                            # Ensure segments list is large enough
                            while len(segments) <= end:
                                segments.append("")
                            # Clear the replaced range
                            for i in range(start, end + 1):
                                segments[i] = ""
                            # Put new text at start position
                            segments[start] = seg_text
                        elif pgs == "apd":
                            # Append: add/overwrite segment at index sn
                            while len(segments) <= sn:
                                segments.append("")
                            segments[sn] = seg_text
                        else:
                            # No pgs (legacy / non-wpgs fallback): append
                            while len(segments) <= sn:
                                segments.append("")
                            segments[sn] = seg_text

                        # Build current full text from all segments
                        current_text = "".join(segments).strip()

                        if resp_status == 2:
                            # Final result — stop sender
                            _sender_stop.set()
                            logger.info("{}: final result at {:.0f}ms  responses={}  text='{}'",
                                        self.name, (time.perf_counter() - _t0) * 1000,
                                        _resp_count, current_text[:60])
                            if current_text:
                                await results.put(
                                    Transcription(text=current_text, is_partial=False)
                                )
                            break
                        else:
                            # Partial result — yield for real-time display
                            if current_text:
                                await results.put(
                                    Transcription(text=current_text, is_partial=True)
                                )

                except websockets.exceptions.ConnectionClosed:
                    # Connection closed by server — stop sender, emit whatever we have
                    _sender_stop.set()
                    current_text = "".join(segments).strip()
                    if current_text:
                        await results.put(
                            Transcription(text=current_text, is_partial=False)
                        )
                finally:
                    _sender_stop.set()  # ensure sender stops in all cases
                    await results.put(None)  # sentinel

            send_task = asyncio.create_task(sender())
            recv_task = asyncio.create_task(receiver())

            while True:
                item = await results.get()
                if item is None:
                    break
                yield item

            logger.info(
                "{}: stream completed in {:.0f}ms, frames={}",
                self.name, (time.perf_counter() - _t0) * 1000, _frames_sent,
            )
            # Wait for tasks; suppress sender errors (e.g. ConnectionClosed
            # that slipped past the try/except if timing was tight).
            for task in (send_task, recv_task):
                try:
                    await task
                except websockets.exceptions.ConnectionClosed:
                    pass
