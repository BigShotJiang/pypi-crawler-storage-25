# Agent Security Audit Example / 安全审计示例

This example demonstrates scanning a simple (simulated) Agent project
for security vulnerabilities using the SentriKit Toolkit.

## 1. Setup

```bash
pip install SentriKit-toolkit
```

## 2. Create a Simulated Agent Project

```bash
mkdir demo-agent
cd demo-agent
```

Create a file with known security issues:

```python
# agent.py — 一个故意包含安全漏洞的示例 Agent
import openai

# UXU-PM-001: API Key hardcoded
openai.api_key = "sk-1234567890abcdef"

# UXU-SI-001: Unsafe exec
def run_code(user_input):
    exec(user_input)  # Dangerous!

# UXU-SI-002: Shell injection
def run_command(cmd):
    import subprocess
    subprocess.run(cmd, shell=True)  # Dangerous!

# UXU-IS-001: Prompt injection
def chat(user_input):
    system_prompt = f"You are a helpful assistant. {user_input}"
    return system_prompt
```

## 3. Run Security Audit

```bash
SentriKit-uxu scan . --severity high
```

Expected output:
```
UXU 安全审计报告
=======================================================
目标:    /path/to/demo-agent
文件数:  1
发现:    4 项
评分:    🟢 C (54)

按严重等级:
  🔥 critical: 1
  ⚠️ high: 3
```

## 4. Fix the Issues

```python
# fixed.py — 修复后的版本
import os

# ✅ Use environment variable instead of hardcoded key
openai.api_key = os.environ.get("OPENAI_API_KEY")

# ✅ Use safe alternatives
def run_code(user_input):
    # Don't use exec with user input
    print(f"Analyzing: {user_input[:50]}")

def run_command(cmd):
    import subprocess
    # Use list arguments instead of shell=True
    subprocess.run(cmd.split(), shell=False)  # Better

def chat(user_input):
    # Use placeholder instead of concatenation
    system_prompt = "You are a helpful assistant."
    return {"prompt": system_prompt, "user_input": user_input}
```

## 5. Verify Fix

```bash
SentriKit-uxu scan . --severity high
```

Expected: Score should improve significantly.

## What You Learned / 学到什么

| Finding | Rule | Severity | Fix |
|---------|------|----------|-----|
| Hardcoded API key | UXU-PM-001 | critical | Environment variables |
| Unsafe exec() | UXU-SI-001 | critical | Remove exec, use safe parsing |
| Shell injection | UXU-SI-002 | high | Use list args, no shell=True |
| Prompt injection | UXU-IS-001 | critical | Use placeholders, not concatenation |
