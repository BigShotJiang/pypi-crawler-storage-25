# 创建一个故意包含安全漏洞的示例 Agent 项目

# UXU-PM-001: Hardcoded API Key
openai_api_key = "sk-1234567890abcdef1234567890abcdef"

# UXU-IS-001: Prompt injection via string concatenation
def create_prompt(user_input):
    return f"You are a helpful assistant. User says: {user_input}"

# UXU-SI-001: Unsafe exec
def execute_code(code):
    exec(code)

# UXU-SI-002: Shell injection
import subprocess
def run_shell(cmd):
    subprocess.run(cmd, shell=True)

# UXU-IS-010: Path traversal
def read_file(filename):
    with open(f"/data/{filename}", "r") as f:
        return f.read()

# UXU-PM-005: Internal network access
def check_internal():
    import requests
    requests.get("http://localhost:5432")

# UXU-SI-003: Unrestricted network access
def fetch_url(url):
    import requests
    return requests.get(url).text
