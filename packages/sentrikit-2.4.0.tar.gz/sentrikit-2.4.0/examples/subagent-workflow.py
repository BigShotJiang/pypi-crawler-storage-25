"""
Sub-Agent 派发工作流示例

展示两种模式：
  模式 A — 通过 BrainCore.execute_subagent() 生成参数包，在 Hermes 决策循环中调用
  模式 B — 通过 Dispatcher 构建参数 + 记录结果（纯 pip 包内演示）

使用方法（在 Hermes Agent 的 execute_code 或决策循环中）:

    # === 模式 A：全自动（推荐） ===
    from SentriKit.brain import BrainCore, Dispatcher, AgentRole

    disp = Dispatcher()
    core = BrainCore(dispatcher=disp)

    # 一行生成完整的调用指令包
    cmd = core.execute_subagent(
        role=AgentRole.RESEARCH,
        goal="调研Python 3.13新特性",
        context="关注JIT编译器和性能提升",
    )

    # 然后在 Hermes 决策循环中执行:
    #   delegate_task(**cmd["params"])
    #   disp.record_result(...)

    # === 模式 B：手动构建 ===
    params = disp.build_params(
        role=AgentRole.CODE,
        goal="实现一个密码强度检测函数",
        context="使用纯Python，不需要额外库",
    )
    # Hermes 决策循环中:
    #   delegate_task(**params)

本示例在 pip 包内通过 mock 数据演示结果记录和格式化。
"""

import time
from SentriKit.brain import BrainCore, Dispatcher, AgentRole, DispatchResult


def demo_execute_subagent():
    """展示 execute_subagent() 生成的指令包结构"""
    print("=" * 60)
    print("模式 A: execute_subagent 调用指令包")
    print("=" * 60)

    disp = Dispatcher()
    core = BrainCore(dispatcher=disp)

    # 对4种Agent分别生成指令包
    agents = [
        (AgentRole.RESEARCH, "调研AI Agent安全审计工具", "关注OWASP Top 10 for LLM"),
        (AgentRole.CODE, "实现一个密码强度检测函数", "纯Python，无外部依赖"),
        (AgentRole.EXECUTOR, "清理 /tmp 目录中过期的临时文件", "只删除7天前的文件"),
        (AgentRole.MONITOR, "检查系统磁盘使用情况", "运行 df -h"),
    ]

    for role, goal, ctx in agents:
        print(f"\n▶ [{role.value}] {goal[:50]}")
        cmd = core.execute_subagent(role=role, goal=goal, context=ctx)
        assert cmd["success"]
        print(f"  工具集: {cmd['params']['toolsets']}")
        print(f"  最大迭代: {cmd['params']['max_iterations']}")
        # 展示code模板前3行
        lines = cmd["code"].strip().split("\n")
        for ln in lines[:3]:
            print(f"  {ln}")
        print(f"  ...（共 {len(lines)} 行代码模板）")

    print(f"\n✅ execute_subagent 验证通过（{len(agents)} 个任务）")


def demo_manual_dispatch():
    """展示手动构建参数 + 记录结果的完整流程"""
    print("\n" + "=" * 60)
    print("模式 B: 手动构建 + 记录结果（mock 数据）")
    print("=" * 60)

    disp = Dispatcher()

    # 1. 构建 Research Agent 参数（模拟成功）
    params = disp.build_params(
        role=AgentRole.RESEARCH,
        goal="调研AI Agent安全框架",
        context="关注GuardRail和LangChain安全",
    )
    print(f"\n▶ Research Agent 参数已构建:")
    print(f"  toolsets: {params['toolsets']}")
    print(f"  goal: {params['goal'][:40]}...")

    # 2. 模拟返回结果并记录
    mock_result = [
        {"summary": "调查完成", "result_summary": "发现3个主流框架: GuardRail, Lunar, Garak"}
    ]
    result = disp.record_result(
        role=AgentRole.RESEARCH,
        goal="调研AI Agent安全框架",
        raw_result=mock_result,
        duration=12.5,
    )
    print(f"  结果: {result.brief()}")

    # 3. 模拟失败场景
    result = disp.record_result(
        role=AgentRole.CODE,
        goal="实现复杂算法",
        raw_result=None,
        duration=30.0,
        error="任务超时（>30s无响应）",
    )
    print(f"  失败: {result.brief()}")

    # 4. 查看历史
    print(f"\n  派发历史: {disp.history_count} 条记录")


def demo_integration_flow():
    """完整的集成流：从任务接收到派发指令包"""
    print("\n" + "=" * 60)
    print("集成流: BrainCore 任务接收 → 路由 → Sub-Agent 派发")
    print("=" * 60)

    disp = Dispatcher()
    core = BrainCore(dispatcher=disp)

    # 1. 接收一个需要 Sub-Agent 的任务
    task = core.receive(
        source="user",
        summary="安全审计项目",
        description="对当前项目进行全面的安全审计，包括依赖漏洞、代码注入风险",
    )
    print(f"  1️⃣ 任务接收: [{task.id}] {task.summary}")
    print(f"   目标模块: {task.target_module}")

    # 2. 检查是否需要派发
    if task.target_module in ("research_engine", "research_agent", "code_agent"):
        dispatch_info = core.dispatch_to_agent(task)
        if dispatch_info and dispatch_info["success"]:
            print(f"2️⃣ BrainCore 决策: 派发到 {dispatch_info['agent_role']}")
            print(f"   参数字段: {list(dispatch_info['params'].keys())}")

            # 3. 获取可执行指令包
            import inspect
            role_map = {v.value: v for v in AgentRole}
            role = role_map.get(dispatch_info["agent_role"])
            if role:
                cmd = core.execute_subagent(
                    role=role,
                    goal=task.summary,
                    context=task.description,
                )
                print(f"3️⃣ 指令包已就绪:")
                print(f"   代码模板行数: {len(cmd['code'].split(chr(10)))}")
                print(f"   可执行: delegate_task(**cmd['params'])")

    print(f"\n✅ 集成流验证完成")


if __name__ == "__main__":
    demo_execute_subagent()
    demo_manual_dispatch()
    demo_integration_flow()
    print("\n" + "=" * 60)
    print("所有验证通过 ✅")
    print("=" * 60)
