# SentriKit — Deployment Guide / 私有部署指南

## System Requirements / 系统要求

- Python 3.11+
- Zero external dependencies (pure stdlib) / 纯标准库，零外部依赖
- Linux / macOS / Windows

## Install / 安装

```bash
pip install sentrikit

# 内网 / 离线
pip install sentrikit-*.whl
```

## CLI Commands / 命令速查

| Command | Function / 功能 |
|---------|-----------------|
| `SentriKit-monitor` | Health Check / 健康检查 |
| `SentriKit-safety` | Safety Guard / 安全约束 |
| `SentriKit-judge` | Evolution Judge / 进化评估 |
| `SentriKit-uxu scan` | Security Audit / 安全审计 (30 rules) |
| `SentriKit-dashboard` | Global Dashboard / 全局仪表盘 |
| `SentriKit-audit` | Full Audit / 全量审计 |
| `agent-run research` | Research Agent / 调研 Agent |
| `agent-run code` | Code Agent / 代码 Agent |
| `agent-run exec` | Executor Agent / 执行 Agent |
| `agent-run monitor` | Monitor Agent / 监控 Agent |

## Full Security Pipeline / 完整安全流水线

```bash
# 1. Health check / 健康检查
SentriKit-monitor -d . -o html > report-health.html

# 2. Full security audit / 全量安全审计
SentriKit-uxu scan .

# 3. Global dashboard / 全局仪表盘
SentriKit-dashboard -d . > dashboard.html

# 4. One-command audit / 一键审计
SentriKit-audit -d . > audit-report.html
```

## Data Directory / 数据目录

```
project/
├── .uxurc.yaml           # Project config / 项目配置
├── judge-history.json    # Judge history / 评估历史
└── brain/
    ├── safety-guard.md   # Safety rules / 安全规则
    ├── audit-log.json    # Audit log / 审计日志
    └── working-memory.md # Working memory / 工作记忆
```

## License / 许可

MIT — SentriKit is free and open source for everyone.
SentriKit 完全免费开源，无需任何授权。
