SentriKit Toolkit — 完整 CLI 参考文档 / Complete CLI Reference

## SentriKit-monitor — Health Check / 健康检查
```
Usage: SentriKit-monitor [OPTIONS]

Options:
  -d, --project-dir PATH  Agent project directory (default: .)
  -o, --output FORMAT     Output format: text | json | html (default: text)
  -m, --multi PATHS       Batch check multiple projects

Example:
  SentriKit-monitor                     # Text report
  SentriKit-monitor -o html > report.html  # HTML report
  SentriKit-monitor -m /project/a /project/b  # Batch check
```

## SentriKit-admin — Management Dashboard / 管理后台
```
Usage: SentriKit-admin [OPTIONS]

Options:
  --serve                 Start HTTP server (default: on)
  --port PORT             HTTP port (default: 9901)
  -d, --project-dir PATH  Agent project directory (default: .)

Example:
  SentriKit-admin                          # Start on port 9901
  SentriKit-admin --port 8080              # Custom port
  SentriKit-admin -d /path/to/project      # Custom project dir
```

## SentriKit-selfcheck — Self-Diagnosis / 自检诊断
```
Usage: SentriKit-selfcheck [OPTIONS]

Options:
  --quick                 Quick check (critical modules only)
  --json                  JSON output

Example:
  SentriKit-selfcheck                      # Full check
  SentriKit-selfcheck --quick              # Quick check
  SentriKit-selfcheck --json               # Machine-readable output
```

## SentriKit-config — Configuration Manager / 配置管理
```
Usage: SentriKit-config [OPTIONS]

Options:
  --list                  List all config keys
  --get KEY               Get a config value
  --set KEY=VALUE         Set a config value
  --delete KEY            Delete a config value

Example:
  SentriKit-config --list
  SentriKit-config --get DEEPSEEK_API_KEY
  SentriKit-config --set DEEPSEEK_API_KEY=sk-xxxxx
```
## SentriKit-safety — Safety Guard / 安全约束
```
Usage: SentriKit-safety COMMAND [OPTIONS]

Commands:
  check   Check if an action is safe
  rules   List all safety rules (R1-R6)

Options:
  check:
    -a, --action TEXT     Action type: create | update | delete | config | execute
    -t, --target TEXT     Target file/resource
    -r, --rules FILE      Custom rules JSON file
    -c, --config PATH     .uxurc.yaml project config

  rules:
    -o, --output FORMAT   Output format: text | json

Example:
  SentriKit-safety check -a delete -t config.yaml
  SentriKit-safety rules -o json
```

## SentriKit-judge — Evolution Judge / 进化评估
```
Usage: SentriKit-judge COMMAND [OPTIONS]

Commands:
  evaluate    Evaluate an evolution proposal
  template    Quick evaluate from preset template
  history     View evaluation history
  metrics     View evolution dashboard metrics

Options:
  evaluate:
    --proposal TEXT       Proposal summary (required)
    --id TEXT             Proposal ID
    --type TEXT           Change type: create | update | delete
    --steps INT           Estimated steps
    --tokens INT          Estimated tokens
    --rsi TEXT            RSI direction: yes | no
    --llm                 Use LLM mode (requires DEEPSEEK_API_KEY)
    -o FORMAT             Output: text | json

Example:
  SentriKit-judge evaluate --proposal "优化搜索流程"
  SentriKit-judge history --grade A
  SentriKit-judge metrics -o json
```

## SentriKit-uxu — Security Audit / 安全审计
```
Usage: SentriKit-uxu COMMAND [OPTIONS]

Commands:
  scan    Scan directory/file for security issues
  rules   List all 30 rules (IS + SI + PM)

Options:
  scan:
    PATH                Target path (required)
    --severity LEVEL    Min severity: critical | high | medium | low
    --free-only         Use free rules only
    -f FORMAT           Output: text | json

  rules:
    --pillar PILLAR     Filter by pillar: input_sanitization | sandbox_isolation | privilege_minimization
    --severity LEVEL    Filter by severity
    -f FORMAT           Output: text | json

Example:
  SentriKit-uxu scan .                     # Full scan (30 rules)
  SentriKit-uxu scan . --severity critical  # Critical only
  SentriKit-uxu rules --pillar input_sanitization
```

## SentriKit-dashboard — Global Dashboard / 全局仪表盘
```
Usage: SentriKit-dashboard [OPTIONS]

Options:
  -d, --project-dir PATH  Agent project directory (default: .)
  -o, --output FORMAT     Output: html | json (default: html)
  --free-only             UXU free rules only

Example:
  SentriKit-dashboard -d . > dashboard.html
```

## SentriKit-audit — Full Audit / 全量审计
```
Usage: SentriKit-audit [OPTIONS]

Options:
  -d, --project-dir PATH  Agent project directory (default: .)
  -o, --output FORMAT     Output: html | json (default: html)
  --severity LEVEL        Min severity for UXU findings
  --free-only             UXU free rules only
  --save PATH             Save report to file

Example:
  SentriKit-audit -d . > audit.html
  SentriKit-audit -d . --output json --save report.json
```

## SentriKit-agent — Agent Daemon / Agent 守护进程
```
Usage: SentriKit-agent COMMAND [OPTIONS]

Commands:
  start       Start agent (foreground)
  stop        Stop agent
  status      View agent status
  run-once    Run one evolution cycle

Options:
  start:
    -d, --project-dir PATH    Project directory
    --detach                  Run in background
    --check-interval SECONDS  MetaCogTrigger check interval (default: 60)
    --evolve-interval MINUTES Full evolution interval (default: 360)

  status:
    -o FORMAT                 Output: text | json

  run-once:
    -d, --project-dir PATH    Project directory
    -o FORMAT                 Output: text | json

Example:
  SentriKit-agent start --detach
  SentriKit-agent status -o json
  SentriKit-agent run-once -d /path/to/project
```

## agent-run — Sub-Agent Runner / Agent 执行器
```
Usage: agent-run COMMAND [OPTIONS]

Commands:
  research    Research Agent: investigate topics
  code        Code Agent: analyze source files
  exec        Executor Agent: describe execution tasks
  monitor     Monitor Agent: run health checks

Example:
  agent-run research --topic "AI Agent 安全"
  agent-run code --file src/main.py
  agent-run exec --task "批量处理文件"
  agent-run monitor
```

## SentriKit-brain — BrainCore / 决策引擎
```
Usage: SentriKit-brain COMMAND [OPTIONS]

Commands:
  submit      Submit a task
  process     Process next task in queue
  complete    Mark task as complete
  fail        Mark task as failed
  status      View BrainCore status
  classify    Test task classification

Example:
  SentriKit-brain submit --summary "优化搜索"
  SentriKit-brain process
  SentriKit-brain status
  SentriKit-brain classify --text "实现用户登录功能"
```

## SentriKit-reporter — Reporter / 主动汇报
```
Usage: SentriKit-reporter COMMAND [OPTIONS]

Commands:
  task-done    Standard report (task completed)
  highlight    High-value discovery
  alert        Emergency alert
  summary      Periodic summary
  log          View report history

Example:
  SentriKit-reporter task-done --title "优化搜索" --body "完成"
  SentriKit-reporter highlight --title "发现新模式" --body "..."
  SentriKit-reporter alert --title "异常" --body "连续3次阻止"
  SentriKit-reporter summary --project-dir .
```

## SentriKit-desktop — Desktop Launcher / 桌面版
```
Usage: SentriKit-desktop [OPTIONS]

Options:
  --port PORT             HTTP port (default: 9901)
  -d, --project-dir PATH  Project directory (default: .)
  --no-browser            Do not open browser automatically

Example:
  SentriKit-desktop                         # Start + open browser
  SentriKit-desktop --no-browser            # Server only
  SentriKit-desktop --port 8080             # Custom port
```

## SentriKit-compintel — Competitive Intelligence / 竞品情报
```
Usage: SentriKit-compintel [OPTIONS] COMMAND

Options:
  -d, --project-dir PATH  Project directory (default: .)

Commands:
  list            List all tracked competitors
  sync            Fetch latest intelligence
  report          Generate intelligence report
  add NAME        Add a competitor
  remove ID       Remove a competitor

Report options:
  --format FORMAT  html | markdown | json (default: html)
  --output FILE    Save to file

Example:
  SentriKit-compintel list
  SentriKit-compintel sync
  SentriKit-compintel report
  SentriKit-compintel report --format markdown
  SentriKit-compintel add NewAI --url https://newai.ai
```

## SentriKit-uxu — Security Audit / 安全审计 (扩展用法)
```
Extended options:
  --deep              Deep scan mode (shell injection + web secrets)
  --compliance, -c    Show OWASP LLM Top 10 compliance
  --format, -f        text | json | html
  --output, -o FILE   Save report to file
  --diff, -d FILE     Compare with previous scan result

Example:
  SentriKit-uxu scan . --deep --format html -o report.html
  SentriKit-uxu scan . --compliance
  SentriKit-uxu scan . --diff previous-scan.json
```
