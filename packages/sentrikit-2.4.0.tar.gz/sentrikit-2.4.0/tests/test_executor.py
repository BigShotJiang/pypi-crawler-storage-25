"""tianlong.executor — 测试"""

from __future__ import annotations

from pathlib import Path

import pytest

from tianlong.executor import Executor, ExecutionRequest, ExecutionResult


class TestExecutionRequest:
    def test_defaults(self):
        req = ExecutionRequest()
        assert req.task_type == "query"
        assert req.estimated_steps == 1


class TestExecutionResult:
    def test_defaults(self):
        r = ExecutionResult()
        assert not r.success
        assert r.timestamp

    def test_to_dict(self):
        r = ExecutionResult(success=True, skill_used="web_search",
                            result_summary="完成")
        d = r.to_dict()
        assert d["success"] is True
        assert d["skill_used"] == "web_search"


class TestExecutor:
    def test_resolve_search_skills(self):
        exe = Executor()
        skills = exe.resolve_skills("search")
        assert "online-search" in skills
        assert "web_search" in skills

    def test_resolve_unknown_skills(self):
        exe = Executor()
        assert exe.resolve_skills("nonexistent") == []

    def test_execute_search(self):
        exe = Executor()
        req = ExecutionRequest(task_type="search", goal="搜索AI安全")
        result = exe.execute(req)
        assert result.success
        assert result.skill_used == "online-search"

    def test_execute_with_tools(self):
        """有 tools 时应优先使用 tools 中的技能。"""
        exe = Executor()
        req = ExecutionRequest(task_type="search", goal="搜索",
                                tools=["web_search"])
        result = exe.execute(req)
        assert result.skill_used == "web_search"

    def test_execute_unknown_type(self):
        exe = Executor()
        req = ExecutionRequest(task_type="unknown")
        result = exe.execute(req)
        assert not result.success
        assert "未知" in result.error

    def test_precheck_delete_blocks(self):
        exe = Executor()
        req = ExecutionRequest(task_type="file_write", goal="delete config.yaml",
                                target="config.yaml")
        reason = exe.precheck(req)
        assert reason is not None
        assert "删除" in reason

    def test_precheck_immutable_blocks(self):
        exe = Executor()
        req = ExecutionRequest(task_type="file_write", goal="修改",
                                target="safety-guard.md")
        reason = exe.precheck(req)
        assert reason is not None
        assert "不可修改" in reason

    def test_precheck_immutable_allows_read(self):
        """不可变文件读取不被阻止。"""
        exe = Executor()
        req = ExecutionRequest(task_type="query", goal="读取",
                                target="safety-guard.md")
        reason = exe.precheck(req)
        assert reason is None

    def test_precheck_normal_passes(self):
        exe = Executor()
        req = ExecutionRequest(task_type="search", goal="搜索")
        assert exe.precheck(req) is None

    def test_record_writes_to_working_memory(self, tmp_path):
        (tmp_path / "brain").mkdir(parents=True)
        exe = Executor(project_dir=tmp_path)
        result = ExecutionResult(success=True, skill_used="test_skill",
                                  result_summary="完成")
        exe.record(result)

        wm = tmp_path / "brain" / "working-memory.md"
        assert wm.exists()
        content = wm.read_text()
        assert "test_skill" in content
        assert "完成" in content

    def test_record_no_dir_does_nothing(self, tmp_path):
        """目录不存在时不应报错。"""
        exe = Executor(project_dir=tmp_path / "nonexistent")
        result = ExecutionResult(success=True)
        exe.record(result)  # 不应该抛异常

    def test_code_skill_priority(self):
        exe = Executor()
        skills = exe.resolve_skills("code")
        assert "write" in skills
        assert "exec" in skills
