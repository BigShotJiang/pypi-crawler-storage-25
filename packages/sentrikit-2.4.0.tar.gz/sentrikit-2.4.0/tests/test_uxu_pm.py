"""tianlong.uxu.rules (PM pillar) + tianlong.uxu.score — 测试"""

from __future__ import annotations

from pathlib import Path

import pytest

from tianlong.uxu import Scanner
from tianlong.uxu.score import UxuScore, SEVERITY_WEIGHTS
from tianlong.uxu.rules import UXURule


# ═══════════════════════════════════════════════════════
# UxuScore 测试
# ═══════════════════════════════════════════════════════


class TestUxuScore:
    def test_defaults(self):
        s = UxuScore()
        assert s.total == 100
        assert s.grade == "A"

    def test_calculate_critical_only(self):
        s = UxuScore()
        s.calculate([{"severity": "critical", "rule_id": "UXU-IS-001"}])
        assert s.total <= 100

    def test_calculate_multiple(self):
        s = UxuScore()
        s.calculate([
            {"severity": "critical", "rule_id": "UXU-IS-001"},
            {"severity": "high", "rule_id": "UXU-SI-002"},
            {"severity": "medium", "rule_id": "UXU-PM-003"},
        ])
        assert s.total < 90

    def test_grade_boundaries(self):
        s = UxuScore()
        s.calculate([{"severity": "critical"}])
        assert s.grade in ("A", "B", "C", "D", "F")

    def test_to_dict(self):
        s = UxuScore()
        d = s.to_dict()
        assert "total" in d
        assert "grade" in d

    def test_severity_weights(self):
        assert SEVERITY_WEIGHTS["critical"] >= SEVERITY_WEIGHTS["high"]
        assert SEVERITY_WEIGHTS["high"] >= SEVERITY_WEIGHTS["medium"]


# ═══════════════════════════════════════════════════════
# PM Rule 测试（关键词匹配）
# ═══════════════════════════════════════════════════════


def _write_and_scan(tmp_path, filename: str, content: str, rule_id: str, severity: str = "low"):
    """辅助：写文件、扫描、过滤指定规则的发现。"""
    f = tmp_path / filename
    f.write_text(content)
    scanner = Scanner(min_severity=severity)
    report = scanner.scan(str(f))
    return [x for x in report.findings if x.rule_id == rule_id]


class TestPM001:
    """UXU-PM-001: API Key 硬编码"""

    def test_detect_openai_api_key(self, tmp_path):
        findings = _write_and_scan(tmp_path, "agent.py",
            'openai_api_key="sk-proj-v9xK2m8Q..."', "UXU-PM-001")
        assert len(findings) >= 1

    def test_detect_deepseek_key(self, tmp_path):
        findings = _write_and_scan(tmp_path, "config.py",
            "DEEPSEEK_API_KEY='sk-test123'", "UXU-PM-001")
        assert len(findings) >= 1


class TestPM002:
    """UXU-PM-002: 工具权限过宽"""

    def test_detect_tools_list_long(self, tmp_path):
        content = (
            'from langchain.agents import load_tools\n'
            '\n'
            'tools = load_tools([\n'
            "    'python_repl',\n"
            "    'requests_get',\n"
            "    'bash',\n"
            "    'file_management',\n"
            '])\n'
        )
        findings = _write_and_scan(tmp_path, "agent.py", content, "UXU-PM-002")
        assert len(findings) >= 1

    def test_detect_toolkit_import(self, tmp_path):
        content = (
            'from langchain.tools import tool\n'
            '\n'
            '@tool\n'
            'def execute_shell_command(cmd: str) -> str:\n'
            '    """Execute shell command"""\n'
            '    import subprocess\n'
            '    return subprocess.check_output(cmd, shell=True).decode()\n'
            '\n'
            '@tool\n'
            'def delete_file(path: str) -> str:\n'
            '    """Delete a file"""\n'
            '    import os\n'
            '    os.remove(path)\n'
            "    return f'Deleted {path}'\n"
        )
        findings = _write_and_scan(tmp_path, "agent.py", content, "UXU-PM-002")
        assert len(findings) >= 1

    def test_detect_tools_list_bracket(self, tmp_path):
        content = (
            'from langchain.agents import AgentExecutor\n'
            'from mytoolkit import get_all_tools\n'
            '\n'
            'tools = get_all_tools()\n'
            'agent = AgentExecutor(agent=agent, tools=tools)\n'
        )
        findings = _write_and_scan(tmp_path, "agent.py", content, "UXU-PM-002")
        assert len(findings) >= 1

    def test_detect_tools_bracket_alt(self, tmp_path):
        content = (
            'from langchain.agents import tool\n'
            '\n'
            'tools=[\n'
            '    search_tool,\n'
            '    calculator_tool,\n'
            '    database_tool,\n'
            '    email_tool,\n'
            ']\n'
        )
        findings = _write_and_scan(tmp_path, "agent.py", content, "UXU-PM-002")
        assert len(findings) >= 1


class TestPM003:
    """UXU-PM-003: 数据库权限过宽"""

    def test_detect_sqlite_connection(self, tmp_path):
        content = (
            'from sqlalchemy import create_engine\n'
            'engine = create_engine("sqlite:///prod.db")\n'
        )
        findings = _write_and_scan(tmp_path, "db.py", content, "UXU-PM-003")
        assert len(findings) >= 1

    def test_detect_create_engine(self, tmp_path):
        content = (
            'from sqlalchemy import create_engine\n'
            'create_engine("postgresql://user:pass@host/db")\n'
        )
        findings = _write_and_scan(tmp_path, "db.py", content, "UXU-PM-003")
        assert len(findings) >= 1


class TestPM004:
    """UXU-PM-004: 文件权限过宽"""

    def test_detect_etc_path(self, tmp_path):
        content = (
            'def read_config():\n'
            '    with open("/etc/passwd", "r") as f:\n'
            '        return f.read()\n'
        )
        findings = _write_and_scan(tmp_path, "config.py", content, "UXU-PM-004")
        assert len(findings) >= 1

    def test_detect_sudo_usage(self, tmp_path):
        content = (
            'import subprocess\n'
            'subprocess.run(["sudo", "apt", "install", "package"])\n'
        )
        findings = _write_and_scan(tmp_path, "setup.py", content, "UXU-PM-004")
        assert len(findings) >= 1

    def test_detect_chmod_777(self, tmp_path):
        content = (
            'import os\n'
            'os.system("chmod 777 /var/log/app.log")\n'
        )
        findings = _write_and_scan(tmp_path, "permissions.py", content, "UXU-PM-004")
        assert len(findings) >= 1

    def test_detect_usr_local_path(self, tmp_path):
        content = (
            'INSTALL_DIR = "/usr/local/bin/myagent"\n'
        )
        findings = _write_and_scan(tmp_path, "deploy.py", content, "UXU-PM-004")
        assert len(findings) >= 1

    def test_detect_opt_path(self, tmp_path):
        content = (
            'APP_PATH = "/opt/myapp/config"\n'
        )
        findings = _write_and_scan(tmp_path, "app.py", content, "UXU-PM-004")
        assert len(findings) >= 1

    def test_detect_var_log_path(self, tmp_path):
        content = (
            'LOG_DIR = "/var/log/myagent"\n'
        )
        findings = _write_and_scan(tmp_path, "agent.py", content, "UXU-PM-004")
        assert len(findings) >= 1


class TestPM005:
    """UXU-PM-005: 网络权限过宽"""

    def test_detect_internal_keyword(self, tmp_path):
        content = (
            'allowed_hosts = ["internal", "service.local", "10.0.0.1"]\n'
        )
        findings = _write_and_scan(tmp_path, "config.py", content, "UXU-PM-005")
        assert len(findings) >= 1


class TestPM008:
    """UXU-PM-008: 长期凭证未轮换"""

    def test_detect_token_keyword(self, tmp_path):
        findings = _write_and_scan(tmp_path, "auth.py", "token = get_token()", "UXU-PM-008")
        assert len(findings) >= 1


class TestPM010:
    """UXU-PM-010: 无限 Token 循环"""

    def test_detect_while_true(self, tmp_path):
        content = (
            'while True:\n'
            '    result = llm_call(query)\n'
        )
        findings = _write_and_scan(tmp_path, "agent.py", content, "UXU-PM-010")
        assert len(findings) >= 1

    def test_detect_max_iterations(self, tmp_path):
        findings = _write_and_scan(tmp_path, "config.py",
            "max_iterations = 100", "UXU-PM-010")
        assert len(findings) >= 1

    def test_no_false_positive_plain_loop_var(self, tmp_path):
        """普通变量名包含 for/while 不应触发。"""
        content = (
            'result = for_loop_result\n'
            'data = while_condition\n'
        )
        findings = _write_and_scan(tmp_path, "data.py", content, "UXU-PM-010")
        assert len(findings) == 0, f"期望 0，实际 {len(findings)}:\n" + "\n".join(
            f"  {f.matched_text[:40]}" for f in findings)

    def test_clean_file_no_false_positives(self, tmp_path):
        """没有风险的文件应无发现（或极微量噪音）。"""
        content = (
            'x = 1\n'
            'y = "hello world"\n'
            'result = x + y\n'
        )
        scanner = Scanner()
        f = tmp_path / "safe.py"
        f.write_text(content)
        report = scanner.scan(str(f))
        # 安全文件至少不应该有 critical/high
        for fi in report.findings:
            assert fi.severity not in ("critical", "high"), f"误报: {fi.rule_id}:{fi.matched_text}"
