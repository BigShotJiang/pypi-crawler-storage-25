"""C3: 退化检测实战验证 — MetaCogTrigger 真实退化场景测试

测试覆盖：
1. 正常场景：无退化信号，should_evolve=False
2. 成功率下降：单日成功率<50%，触发CRITICAL
3. 停滞场景：14天无改进，触发MODERATE
4. 重复错误激增：5次以上重复错误，触发CRITICAL
5. 混合信号：多个信号叠加
6. BrainCore.heartbeat() 集成测试（模拟文件）
7. BrainCore.heartbeat() 实际文件集成测试
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from tianlong.metacog import MetaCogTrigger, TriggerLevel
from tianlong.brain import BrainCore, Dispatcher


class TestDegradationScenarios:
    """C3: 真实退化场景测试"""

    def test_normal_operation(self):
        """场景1: 正常运行，无退化"""
        mc = MetaCogTrigger()
        result = mc.evaluate(
            success_rate_7d=0.95,
            success_rate_3d=0.93,
            success_rate_1d=0.98,
            days_since_last_improvement=0,
            repeat_error_count=0,
        )
        assert not result.should_evolve, f"正常场景不应触发进化: {result.summary_line}"
        assert result.overall_score <= 0.15
        assert result.max_level == "mild"

    def test_sudden_success_rate_drop(self):
        """场景2: 单日成功率暴跌到40%（<50%触发CRITICAL）"""
        mc = MetaCogTrigger()
        result = mc.evaluate(
            success_rate_7d=0.88,
            success_rate_3d=0.65,
            success_rate_1d=0.40,  # < 50% → CRITICAL
            days_since_last_improvement=1,
            repeat_error_count=2,
        )
        assert result.should_evolve, f"成功率暴跌应触发进化: {result.summary_line}"
        assert result.max_level == "critical"
        # 验证success_rate信号被触发
        sr_trigger = [t for t in result.triggers if t.signal_name == "success_rate"]
        assert len(sr_trigger) == 1
        assert sr_trigger[0].triggered

    def test_gradual_decline_over_week(self):
        """场景3: 7天持续下降（7天<85%，3天<70%）"""
        mc = MetaCogTrigger()
        result = mc.evaluate(
            success_rate_7d=0.80,
            success_rate_3d=0.65,
            success_rate_1d=0.72,
            days_since_last_improvement=3,
            repeat_error_count=0,
        )
        assert result.should_evolve, f"持续下降应触发进化: {result.summary_line}"
        assert result.max_level in ("moderate", "critical")

    def test_stagnation_two_weeks(self):
        """场景4: 14天无任何改进"""
        mc = MetaCogTrigger()
        result = mc.evaluate(
            success_rate_7d=0.92,
            success_rate_3d=0.90,
            success_rate_1d=0.88,
            days_since_last_improvement=14,
            repeat_error_count=0,
        )
        assert result.should_evolve, f"14天停滞应触发进化: {result.summary_line}"
        # stagnation 信号应被触发
        st_trigger = [t for t in result.triggers if t.signal_name == "stagnation"]
        assert len(st_trigger) == 1
        assert st_trigger[0].triggered

    def test_repeat_error_explosion(self):
        """场景5: 重复错误激增到6次（>=5触发CRITICAL）"""
        mc = MetaCogTrigger()
        result = mc.evaluate(
            success_rate_7d=0.90,
            success_rate_3d=0.88,
            success_rate_1d=0.85,
            days_since_last_improvement=1,
            repeat_error_count=6,
        )
        assert result.should_evolve, f"重复错误激增应触发进化: {result.summary_line}"
        assert result.max_level == "critical"
        rf_trigger = [t for t in result.triggers if t.signal_name == "repeat_failure"]
        assert len(rf_trigger) == 1
        assert rf_trigger[0].triggered

    def test_multi_signal_combined(self):
        """场景6: 多信号叠加 — 成功率下降 + 停滞 + 重复错误"""
        mc = MetaCogTrigger()
        result = mc.evaluate(
            success_rate_7d=0.75,
            success_rate_3d=0.68,
            success_rate_1d=0.55,
            days_since_last_improvement=7,
            repeat_error_count=4,
        )
        assert result.should_evolve, f"多信号叠加应触发进化: {result.summary_line}"
        # 至少3个信号被触发
        triggered_count = sum(1 for t in result.triggers if t.triggered)
        assert triggered_count >= 3, f"期望≥3个信号触发, 实际{triggered_count}"
        assert result.overall_score > 0.3

    def test_history_maintained(self):
        """场景7: 多次评估后历史记录正确"""
        mc = MetaCogTrigger()
        mc.evaluate(success_rate_7d=0.95, success_rate_3d=0.90)
        mc.evaluate(success_rate_7d=0.80, success_rate_3d=0.70, repeat_error_count=3)
        mc.evaluate(success_rate_7d=0.50, success_rate_1d=0.30, repeat_error_count=6)

        history = mc.get_history(limit=10)
        assert len(history) == 3
        assert history[0]["should_evolve"] is False
        assert history[1]["should_evolve"] is True
        assert history[2]["should_evolve"] is True
        assert history[2]["max_level"] == "critical"

    def test_to_dict_serializable(self):
        """场景8: MetaCogReport.to_dict() 可序列化为JSON"""
        mc = MetaCogTrigger()
        result = mc.evaluate(
            success_rate_7d=0.70,
            success_rate_3d=0.60,
            repeat_error_count=3,
        )
        d = result.to_dict()
        # 验证可JSON序列化
        json_str = json.dumps(d, ensure_ascii=False)
        assert json_str
        parsed = json.loads(json_str)
        assert parsed["should_evolve"] == result.should_evolve
        assert parsed["overall_score"] == round(result.overall_score, 3)


class TestBrainCoreHeartbeat:
    """BrainCore.heartbeat() 集成测试"""

    def test_heartbeat_no_files(self, tmp_path):
        """在空目录中执行heartbeat，不应报错"""
        disp = Dispatcher()
        core = BrainCore(dispatcher=disp)
        result = core.heartbeat(project_dir=str(tmp_path))
        assert "timestamp" in result
        assert "status" in result
        assert "metacog" in result
        assert result["status"]["is_idle"] is True
        assert result["status"]["queue_length"] == 0
        # metacog 在没有文件时仍应返回有效结果
        assert "should_evolve" in result["metacog"]
        assert result["metacog"]["should_evolve"] is False

    def test_heartbeat_with_errors(self, tmp_path):
        """有错误日志时，heartbeat应检测到退化"""
        # 创建模拟文件
        brain_dir = tmp_path / "brain"
        brain_dir.mkdir()
        error_log = brain_dir / "error-log.md"
        error_log.write_text(
            "## [待处理] 错误1\n- ID: err1\n错误描述\n"
            "## [待处理] 错误2\n- ID: err2\n错误描述\n"
            "## [待处理] 错误3\n- ID: err3\n错误描述\n"
            "## [待处理] 错误4\n- ID: err4\n错误描述\n"
        )
        # working-memory 7天前修改
        wm_file = brain_dir / "working-memory.md"
        wm_file.write_text("# working-memory\n内容")
        seven_days_ago = datetime.now().timestamp() - 7 * 86400
        os_ts = seven_days_ago
        # 用 touch 类似的机制设置mtime
        import os
        os.utime(str(wm_file), (os_ts, os_ts))

        disp = Dispatcher()
        core = BrainCore(dispatcher=disp)
        result = core.heartbeat(project_dir=str(tmp_path))

        assert result["metacog"]["should_evolve"] is True, (
            f"4个待处理错误+7天停滞应触发进化: {result['metacog']}"
        )

    def test_heartbeat_clean(self, tmp_path):
        """无错误的项目目录，heartbeat应报告健康"""
        brain_dir = tmp_path / "brain"
        brain_dir.mkdir()
        error_log = brain_dir / "error-log.md"
        error_log.write_text("## [已解决] 旧错误\n- ID: old1\n已修复\n")
        wm_file = brain_dir / "working-memory.md"
        wm_file.write_text("# working-memory\n今天更新了内容")

        disp = Dispatcher()
        core = BrainCore(dispatcher=disp)
        result = core.heartbeat(project_dir=str(tmp_path))
        assert result["metacog"]["should_evolve"] is False

    def test_heartbeat_no_dispatcher(self):
        """无dispatcher时heartbeat仍应工作"""
        core = BrainCore()  # 没有注入dispatcher
        # 评估退化检测不需要dispatcher，heartbeat应该正常工作
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            result = core.heartbeat(project_dir=td)
            assert "metacog" in result
            assert "status" in result
            # status可能没有queue_length——不重要，关键是没报错
