"""tests/test_users.py — 多用户/Token认证/API鉴权测试"""

from __future__ import annotations

import json
import os
import shutil
import threading
import time
from http.client import HTTPConnection
from pathlib import Path

import pytest

# 企业版授权（多用户管理需要）
os.environ.setdefault("TIANLONG_ENTERPRISE", "1")
os.environ.setdefault("TIANLONG_API_KEY", "test-enterprise-key")

from tianlong.users import (
    UserManager, get_user_manager, USERS_DIR, SESSIONS_FILE, USERS_FILE,
)


@pytest.fixture(autouse=True)
def _clean_users():
    """每个测试前清理用户数据"""
    if USERS_DIR.exists():
        shutil.rmtree(str(USERS_DIR))
    yield
    if USERS_DIR.exists():
        shutil.rmtree(str(USERS_DIR))


class TestUserManager:
    def test_create_user_success(self):
        um = UserManager()
        user = um.create_user("testuser", "Test123!@#")
        assert user.username == "testuser"
        assert user.role == "user"
        assert user.enabled is True

    def test_create_admin_automatically(self):
        """首次启动自动创建 admin"""
        um = UserManager()
        admin = um.get_user("admin")
        assert admin is not None
        assert admin.role == "admin"

    def test_create_duplicate_username(self):
        um = UserManager()
        um.create_user("dup", "pwd")
        with pytest.raises(ValueError, match="已存在"):
            um.create_user("dup", "pwd2")

    def test_authenticate_correct_password(self):
        um = UserManager()
        token = um.authenticate("admin", "sentrikit")
        assert token is not None
        assert len(token) > 10

    def test_authenticate_wrong_password(self):
        um = UserManager()
        token = um.authenticate("admin", "wrong")
        assert token is None

    def test_authenticate_nonexistent_user(self):
        um = UserManager()
        token = um.authenticate("nonexistent", "pwd")
        assert token is None

    def test_validate_valid_token(self):
        um = UserManager()
        token = um.authenticate("admin", "sentrikit")
        user = um.validate_token(token)
        assert user is not None
        assert user.username == "admin"

    def test_validate_invalid_token(self):
        um = UserManager()
        user = um.validate_token("invalid-token")
        assert user is None

    def test_validate_expired_token(self):
        um = UserManager()
        token = um.authenticate("admin", "sentrikit")
        # 修改 session 过期时间
        sess = um._sessions.get(token)
        import time as t_mod
        sess.expires_at = t_mod.time() - 1  # 设置已过期
        um._save_sessions()
        # 重新加载
        um2 = UserManager()
        user = um2.validate_token(token)
        assert user is None

    def test_list_users(self):
        um = UserManager()
        um.create_user("alice", "pass1", role="user")
        um.create_user("bob", "pass2", role="user")
        users = um.list_users()
        assert len(users) >= 3  # admin + alice + bob
        usernames = [u["username"] for u in users]
        assert "admin" in usernames
        assert "alice" in usernames

    def test_remove_user(self):
        um = UserManager()
        um.create_user("toremove", "pwd")
        ok = um.remove_user("toremove")
        assert ok is True
        assert um.get_user("toremove") is None

    def test_cannot_remove_admin(self):
        um = UserManager()
        with pytest.raises(ValueError, match="不能删除"):
            um.remove_user("admin")

    def test_logout(self):
        um = UserManager()
        token = um.authenticate("admin", "sentrikit")
        assert um.validate_token(token) is not None
        um.logout(token)
        assert um.validate_token(token) is None

    def test_password_hash_not_exposed(self):
        um = UserManager()
        users = um.list_users()
        for u in users:
            assert "password_hash" not in u


class TestConcurrentAccess:
    def test_concurrent_login_same_user(self):
        from concurrent.futures import ThreadPoolExecutor
        um = UserManager()
        um.create_user("concurrent", "pass")

        def login():
            return um.authenticate("concurrent", "pass")

        with ThreadPoolExecutor(max_workers=10) as ex:
            results = list(ex.map(lambda _: login(), range(20)))
        assert all(r is not None for r in results)

    def test_concurrent_validate(self):
        from concurrent.futures import ThreadPoolExecutor
        um = UserManager()
        token = um.authenticate("admin", "sentrikit")

        def validate():
            return um.validate_token(token)

        with ThreadPoolExecutor(max_workers=10) as ex:
            results = list(ex.map(lambda _: validate(), range(20)))
        assert all(r is not None for r in results)


class TestAPIEndpointAuth:
    """管理后台API鉴权测试 — 已迁移"""

    @pytest.fixture
    def server(self):
        pytest.skip("tianlong.admin 模块已移除")
        import socket
        s = socket.socket()
        s.bind(("", 0))
        port = s.getsockname()[1]
        s.close()
        t = threading.Thread(target=start_server, args=(port, "."), daemon=True)
        t.start()
        time.sleep(1.5)
        yield port
        # 清理线程
        import subprocess
        for p in subprocess.check_output(["fuser", str(port) + "/tcp"]).decode().strip().split():
            try:
                os.kill(int(p), 9)
            except Exception:
                pass

    def test_api_without_token_returns_401(self, server):
        conn = HTTPConnection("localhost", server)
        conn.request("GET", "/api/status")
        r = conn.getresponse()
        conn.close()
        assert r.status == 401

    def test_api_with_valid_token_returns_200(self, server):
        um = get_user_manager()
        token = um.authenticate("admin", "sentrikit")
        conn = HTTPConnection("localhost", server)
        conn.request("GET", "/api/status", headers={"X-Auth-Token": token})
        r = conn.getresponse()
        data = json.loads(r.read())
        conn.close()
        assert r.status == 200
        assert "uxu" in data

    def test_api_with_invalid_token_returns_401(self, server):
        conn = HTTPConnection("localhost", server)
        conn.request("GET", "/api/status", headers={"X-Auth-Token": "bad-token"})
        r = conn.getresponse()
        conn.close()
        assert r.status == 401

    def test_login_endpoint_returns_token(self, server):
        conn = HTTPConnection("localhost", server)
        conn.request("POST", "/api/login",
                     json.dumps({"username": "admin", "password": "sentrikit"}).encode(),
                     {"Content-Type": "application/json"})
        r = conn.getresponse()
        data = json.loads(r.read())
        conn.close()
        assert r.status == 200
        assert data["success"] is True
        assert "token" in data

    def test_login_endpoint_wrong_password(self, server):
        conn = HTTPConnection("localhost", server)
        conn.request("POST", "/api/login",
                     json.dumps({"username": "admin", "password": "wrong"}).encode(),
                     {"Content-Type": "application/json"})
        r = conn.getresponse()
        data = json.loads(r.read())
        conn.close()
        assert r.status == 401
        assert data["success"] is False

    def test_page_without_token_still_accessible(self, server):
        conn = HTTPConnection("localhost", server)
        conn.request("GET", "/")
        r = conn.getresponse()
        body = r.read()
        conn.close()
        assert r.status == 200

    def test_dashboard_without_token_accessible(self, server):
        conn = HTTPConnection("localhost", server)
        conn.request("GET", "/dashboard")
        r = conn.getresponse()
        conn.close()
        assert r.status == 200
