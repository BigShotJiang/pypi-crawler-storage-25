"""tianlong.judge.history + metrics — 测试"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tianlong.judge import JudgeHistory, EvolutionDashboard


# ═══════════════════════════════════════════════════════
# JudgeHistory 测试
# ═══════════════════════════════════════════════════════


def _sample_result(proposal_id: str = "p001", grade: str = "A",
                   score: float = 0.75, passed: bool = True) -> dict:
    return {
        "proposal_id": proposal_id,
        "proposal_summary": f"提案{proposal_id}",
        "total_score": score,
        "grade": grade,
        "passed": passed,
        "timestamp": "2026-04-27 12:00:00",
        "dimensions": [
            {"name": "direction", "score": 0.8, "weight": 0.25, "weighted": 0.2},
            {"name": "efficiency", "score": 0.7, "weight": 0.2, "weighted": 0.14},
            {"name": "robustness", "score": 0.6, "weight": 0.2, "weighted": 0.12},
            {"name": "reusability", "score": 0.5, "weight": 0.15, "weighted": 0.075},
            {"name": "cost_risk", "score": 0.8, "weight": 0.2, "weighted": 0.16},
        ],
    }


class TestJudgeHistory:
    def test_init_default_path(self):
        hist = JudgeHistory()
        assert str(hist.path).endswith("judge-history.json")

    def test_init_custom_path(self, tmp_path):
        fp = tmp_path / "my-history.json"
        hist = JudgeHistory(path=str(fp))
        assert hist.path == fp

    def test_record_and_count(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        assert hist.count() == 0

        hist.record(_sample_result("p001"))
        assert hist.count() == 1

        hist.record(_sample_result("p002", grade="B", score=0.5, passed=False))
        assert hist.count() == 2

    def test_recent(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(5):
            hist.record(_sample_result(f"p{i:03d}"))
        recent = hist.recent(3)
        assert len(recent) == 3
        # recent returns last 3 in order: p002, p003, p004
        assert recent[0]["proposal_id"] == "p002"
        assert recent[-1]["proposal_id"] == "p004"

    def test_filter_by_grade(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("p001", grade="A", passed=True))
        hist.record(_sample_result("p002", grade="B", passed=False))
        hist.record(_sample_result("p003", grade="A", passed=True))

        filtered = hist.filter(grade="A")
        assert len(filtered) == 2
        assert all(e["grade"] == "A" for e in filtered)

    def test_filter_by_passed(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("p001", grade="A", passed=True))
        hist.record(_sample_result("p002", grade="D", passed=False))

        passed = hist.filter(passed=True)
        assert len(passed) == 1
        assert passed[0]["proposal_id"] == "p001"

    def test_filter_by_time(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))

        early = _sample_result("p001")
        early["timestamp"] = "2026-04-01 12:00:00"
        late = _sample_result("p002")
        late["timestamp"] = "2026-04-27 12:00:00"
        hist.record(early)
        hist.record(late)

        filtered = hist.filter(since="2026-04-15")
        assert len(filtered) == 1
        assert filtered[0]["proposal_id"] == "p002"

    def test_filter_by_proposal_id(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("my-proposal-001"))

        found = hist.get_by_id("my-proposal-001")
        assert found is not None
        assert found["proposal_id"] == "my-proposal-001"

        not_found = hist.get_by_id("nonexistent")
        assert not_found is None

    def test_statistics(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("p001", score=0.9, grade="S", passed=True))
        hist.record(_sample_result("p002", score=0.8, grade="A", passed=True))
        hist.record(_sample_result("p003", score=0.4, grade="C", passed=False))

        stats = hist.statistics()
        assert stats["total"] == 3
        assert stats["passed"] == 2
        assert stats["failed"] == 1
        assert abs(stats["pass_rate"] - 2/3) < 0.001
        assert abs(stats["avg_score"] - (0.9 + 0.8 + 0.4) / 3) < 0.001

    def test_statistics_empty(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        stats = hist.statistics()
        assert stats["total"] == 0
        assert stats["avg_score"] == 0.0

    def test_record_dicts_batch(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record_dicts([
            _sample_result("p001"),
            _sample_result("p002"),
        ])
        assert hist.count() == 2

    def test_record_dicts_empty(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record_dicts([])
        assert hist.count() == 0

    def test_clear(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("p001"))
        assert hist.count() == 1
        hist.clear()
        assert hist.count() == 0

    def test_persistence_across_instances(self, tmp_path):
        """数据持久化：不同实例读取同一文件应看到相同数据。"""
        fp = tmp_path / "hist.json"
        h1 = JudgeHistory(path=str(fp))
        h1.record(_sample_result("p001"))
        h1.record(_sample_result("p002"))

        h2 = JudgeHistory(path=str(fp))
        assert h2.count() == 2
        assert h2.recent(1)[0]["proposal_id"] == "p002"

    def test_load_corrupted_file(self, tmp_path):
        """损坏的 JSON 文件应被优雅处理。"""
        fp = tmp_path / "hist.json"
        fp.write_text("这不是 JSON", encoding="utf-8")
        hist = JudgeHistory(path=str(fp))
        assert hist.count() == 0


# ═══════════════════════════════════════════════════════
# EvolutionDashboard 测试
# ═══════════════════════════════════════════════════════


class TestEvolutionDashboard:
    def test_empty_history(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["overall_health"] == "unknown"
        assert report["total_proposals"] == 0

    def test_all_passed(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(10):
            hist.record(_sample_result(f"p{i:03d}", grade="A", score=0.8, passed=True))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["total_proposals"] == 10
        assert report["judge"]["indicators"]["pass_rate"]["value"] == 1.0
        assert report["judge"]["indicators"]["direction_consistency"]["value"] == 1.0

    def test_all_failed(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(10):
            hist.record(_sample_result(f"p{i:03d}", grade="D", score=0.2, passed=False))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["total_proposals"] == 10
        assert report["overall_health"] == "critical"
        assert report["judge"]["indicators"]["pass_rate"]["value"] == 0.0

    def test_all_s_grade(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(10):
            hist.record(_sample_result(f"p{i:03d}", grade="S", score=0.95, passed=True))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["judge"]["indicators"]["s_rate"]["value"] == 1.0
        assert report["judge"]["score"] >= 0.8

    def test_mixed(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(7):
            hist.record(_sample_result(f"pass-{i:03d}", grade="A", score=0.8, passed=True))
        for i in range(3):
            hist.record(_sample_result(f"fail-{i:03d}", grade="D", score=0.2, passed=False))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["total_proposals"] == 10
        assert report["judge"]["indicators"]["pass_rate"]["value"] == 0.7

    def test_judge_reject_rate(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(8):
            hist.record(_sample_result(f"p{i:03d}", grade="A", score=0.8, passed=True))
        for i in range(2):
            hist.record(_sample_result(f"p{i:03d}", grade="C", score=0.3, passed=False))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["selflearning"]["indicators"]["judge_reject_rate"]["value"] == 0.2
        # C+D=2/10=0.2, healthy(20%) boundary

    def test_five_categories_present(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("p001", grade="A", score=0.8, passed=True))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        for cat in ["judge", "ralph", "selflearning", "cognition", "skill"]:
            assert cat in report, f"缺少类别: {cat}"
            assert "indicators" in report[cat]
            assert "score" in report[cat]

    def test_overall_score_a(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(10):
            hist.record(_sample_result(f"p{i:03d}", grade="S", score=0.95, passed=True))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["overall_grade"] in ("A", "B")
        # 全部S级，综合分应该很高

    def test_overall_score_d(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(10):
            hist.record(_sample_result(f"p{i:03d}", grade="D", score=0.1, passed=False))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["overall_grade"] == "D"

    def test_report_text_contains_categories(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("p001", grade="S", score=0.9, passed=True))
        hist.record(_sample_result("p002", grade="A", score=0.8, passed=True))

        dash = EvolutionDashboard(history=hist)
        text = dash.report_text()
        assert "天龙1号" in text
        assert "进化状态报告" in text
        assert "Judge评估" in text
        assert "Ralph Loop" in text
        assert "SelfLearning" in text
        assert "认知健康" in text
        assert "技能健康" in text

    def test_report_text_empty(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        dash = EvolutionDashboard(history=hist)
        text = dash.report_text()
        assert "进化状态报告" in text
        assert "总提案: 0" in text

    def test_with_skill_entries(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("p001", grade="S", score=0.9, passed=True))

        skills = [
            {"status": "active", "use_count": 10, "created_at": "2026-04-01"},
            {"status": "active", "use_count": 5, "created_at": "2026-04-10"},
            {"status": "pending", "use_count": 0, "created_at": "2026-03-01"},
        ]

        dash = EvolutionDashboard(history=hist, skill_entries=skills)
        report = dash.compute()
        assert abs(report["skill"]["indicators"]["active_ratio"]["value"] - 2/3) < 0.001
        assert abs(report["skill"]["indicators"]["pending_ratio"]["value"] - 1/3) < 0.001

    def test_with_error_logs(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        hist.record(_sample_result("p001", grade="S", score=0.9, passed=True))

        errors = [
            {"body": "已解决: 网络超时"},
            {"body": "已解决: 文件缺失"},
            {"body": "未解决: 权限不足"},
        ]

        dash = EvolutionDashboard(history=hist, error_log_entries=errors)
        report = dash.compute()
        # 2/3 已解决
        assert abs(report["cognition"]["indicators"]["failure_mining_rate"]["value"] - 2/3) < 0.001

    def test_double_reject_rate(self, tmp_path):
        fp = tmp_path / "hist.json"
        hist = JudgeHistory(path=str(fp))
        for i in range(9):
            hist.record(_sample_result(f"p{i:03d}", grade="A", score=0.8, passed=True))
        # 1 个双重拒绝
        hist.record(_sample_result("rejected", grade="D", score=0.1, passed=False))

        dash = EvolutionDashboard(history=hist)
        report = dash.compute()
        assert report["selflearning"]["indicators"]["double_reject_rate"]["value"] == 0.1


# ═══════════════════════════════════════════════════════
# CLI 集成测试
# ═══════════════════════════════════════════════════════


class TestHistoryCLI:
    def test_history_empty(self, capsys, tmp_path):
        from tianlong.judge.cli import main
        hist_file = tmp_path / "hist.json"
        rc = main(["history", "--file", str(hist_file)])
        captured = capsys.readouterr()
        assert rc == 0
        assert "无记录" in captured.out

    def test_history_json_empty(self, capsys, tmp_path):
        from tianlong.judge.cli import main
        hist_file = tmp_path / "hist.json"
        rc = main(["history", "--file", str(hist_file), "-o", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert data == []

    def test_metrics_empty(self, capsys, tmp_path):
        from tianlong.judge.cli import main
        hist_file = tmp_path / "hist.json"
        rc = main(["metrics", "--file", str(hist_file)])
        captured = capsys.readouterr()
        assert rc == 0
        assert "总提案" in captured.out or "进化状态报告" in captured.out

    def test_metrics_with_data(self, tmp_path):
        from tianlong.judge.cli import main
        hist_file = tmp_path / "hist.json"

        # 先写入一些数据
        hist = JudgeHistory(path=str(hist_file))
        for i in range(5):
            hist.record({
                "proposal_id": f"p{i:03d}",
                "proposal_summary": f"测试{i}",
                "total_score": 0.8,
                "grade": "A",
                "passed": True,
                "timestamp": "2026-04-27 12:00:00",
                "dimensions": [],
            })

        rc = main(["metrics", "--file", str(hist_file), "-o", "json"])
        assert rc == 0

    def test_history_with_data(self, capsys, tmp_path):
        from tianlong.judge.cli import main
        hist_file = tmp_path / "hist.json"

        hist = JudgeHistory(path=str(hist_file))
        hist.record(_sample_result("p001", grade="S", score=0.95, passed=True))
        hist.record(_sample_result("p002", grade="D", score=0.15, passed=False))

        rc = main(["history", "--file", str(hist_file)])
        captured = capsys.readouterr()
        assert rc == 0
        assert "总计: 2" in captured.out
        assert "通过: 1" in captured.out
        assert "失败: 1" in captured.out

    def test_history_filter_grade(self, capsys, tmp_path):
        from tianlong.judge.cli import main
        hist_file = tmp_path / "hist.json"

        hist = JudgeHistory(path=str(hist_file))
        hist.record(_sample_result("p001", grade="A", score=0.8, passed=True))
        hist.record(_sample_result("p002", grade="D", score=0.2, passed=False))

        rc = main(["history", "--file", str(hist_file), "--grade", "D"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "p002" in captured.out
        assert "p001" not in captured.out
