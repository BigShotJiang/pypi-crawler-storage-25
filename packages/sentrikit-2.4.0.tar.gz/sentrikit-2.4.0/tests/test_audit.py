"""tianlong.audit — 测试"""

from __future__ import annotations

import json
from pathlib import Path

import pytest


class TestAuditCLI:
    def test_help(self, capsys):
        from tianlong.audit import main
        with pytest.raises(SystemExit):
            main(["--help"])

    def test_json_output(self, capsys, tmp_path):
        from tianlong.audit import main
        rc = main(["--project-dir", str(tmp_path), "--output", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert "security" in data
        assert "monitor" in data
        assert "judge" in data

    def test_save_to_file(self, tmp_path):
        from tianlong.audit import main
        out = tmp_path / "report.html"
        rc = main(["--project-dir", str(tmp_path), "--save", str(out)])
        assert rc == 0
        assert out.exists()
        content = out.read_text()
        assert "html" in content or "审计" in content or "天龙" in content

    def test_free_only(self, capsys, tmp_path):
        from tianlong.audit import main
        rc = main(["--project-dir", str(tmp_path), "--free-only", "--output", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert data["security"]["total_findings"] >= 0

    def test_severity_filter(self, capsys, tmp_path):
        from tianlong.audit import main
        rc = main(["--project-dir", str(tmp_path), "--severity", "high", "--output", "json"])
        captured = capsys.readouterr()
        assert rc == 0
