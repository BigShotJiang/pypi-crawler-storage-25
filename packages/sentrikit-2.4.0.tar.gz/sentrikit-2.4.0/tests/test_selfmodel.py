"""tianlong.selfmodel + metaevolve + dgmh — 测试"""

from __future__ import annotations

import pytest

from tianlong.selfmodel import SelfModel, SelfGraph, CapabilityScore, DecisionEntry, SnapshotEntry
from tianlong.metaevolve import MetaEVOLVE, ChangeRecord, MetaEvolveReport, StrategySuggestion
from tianlong.dgmh import DGOrchestrator, SafetyShield, ActivationStatus


class TestSelfGraph:
    def test_default_nodes(self):
        g = SelfGraph()
        assert "BrainCore" in g.nodes
        assert "SelfLearning" in g.nodes

    def test_find_bottlenecks_default(self):
        g = SelfGraph()
        bottlenecks = g.find_bottlenecks()
        assert "MemorySystem" in bottlenecks  # load=0.7, health=warning

    def test_update_node(self):
        g = SelfGraph()
        g.update_node("BrainCore", load=0.8, health="warning")
        assert g.nodes["BrainCore"]["load"] == 0.8

    def test_to_dict(self):
        g = SelfGraph()
        d = g.to_dict()
        assert "nodes" in d
        assert "edges" in d


class TestSelfModel:
    def test_default_state(self, tmp_path):
        m = SelfModel(project_dir=str(tmp_path))
        assert m.capabilities() == {}

    def test_update_capability(self, tmp_path):
        m = SelfModel(project_dir=str(tmp_path))
        m.update_capability("coding", CapabilityScore(success_rate=0.85, task_count=10))
        caps = m.capabilities()
        assert "coding" in caps
        assert caps["coding"]["success_rate"] == 0.85

    def test_update_from_history(self, tmp_path):
        m = SelfModel(project_dir=str(tmp_path))
        history = [
            {"task_type": "coding", "status": "done", "timestamp": "2026-04-27"},
            {"task_type": "coding", "status": "failed", "timestamp": "2026-04-26"},
            {"task_type": "research", "status": "done", "timestamp": "2026-04-27"},
        ]
        m.update_capabilities_from_history(history)
        caps = m.capabilities()
        assert caps["coding"]["success_rate"] == 0.5
        assert caps["coding"]["task_count"] == 2
        assert caps["research"]["success_rate"] == 1.0

    def test_record_decision(self, tmp_path):
        m = SelfModel(project_dir=str(tmp_path))
        m.record_decision(DecisionEntry(timestamp="now", decision_type="JUDGE", task="test"))
        assert len(m.get_decisions()) == 1

    def test_take_snapshot(self, tmp_path):
        m = SelfModel(project_dir=str(tmp_path))
        snap = m.take_snapshot()
        assert snap.overall_success_rate >= 0
        assert snap.timestamp

    def test_get_history(self, tmp_path):
        m = SelfModel(project_dir=str(tmp_path))
        h = m.get_history()
        assert "capabilities" in h
        assert "bottlenecks" in h


class TestMetaEVOLVE:
    def test_empty_history(self):
        me = MetaEVOLVE()
        report = me.generate_strategy_advice()
        assert report.total_changes == 0

    def test_analyze_hit_rate_empty(self):
        me = MetaEVOLVE()
        result = me.analyze_hit_rate()
        assert result["hit_rate"] == 0.0

    def test_analyze_hit_rate_mixed(self):
        me = MetaEVOLVE()
        me.add_changes([
            ChangeRecord(proposal_id="p1", verdict="HIT"),
            ChangeRecord(proposal_id="p2", verdict="HIT"),
            ChangeRecord(proposal_id="p3", verdict="MISS"),
            ChangeRecord(proposal_id="p4", verdict="HIT"),
        ])
        result = me.analyze_hit_rate()
        assert result["hit_rate"] == 0.75

    def test_analyze_timing(self):
        me = MetaEVOLVE()
        me.add_changes([
            ChangeRecord(trigger_source="cron", verdict="HIT"),
            ChangeRecord(trigger_source="cron", verdict="MISS"),
            ChangeRecord(trigger_source="ralph_loop", verdict="HIT"),
        ])
        timing = me.analyze_timing()
        assert "cron" in timing
        assert "ralph_loop" in timing
        assert timing["cron"] == 0.5

    def test_calibrate_judge_insufficient(self):
        me = MetaEVOLVE()
        result = me.calibrate_judge()
        assert result["status"] == "insufficient_data"
    def test_calibrate_judge_with_errors(self):
        from tianlong.metaevolve import MetaEVOLVE
        me = MetaEVOLVE()
        # 需要至少 10 条 resolved 记录（超过 MIN_CHANGES_FOR_CALIBRATION=10）
        for i in range(7):
            me.add_change(ChangeRecord(proposal_id=f"h{i}", judge_grade="A", judge_score=0.8, verdict="HIT"))
        me.add_changes([
            ChangeRecord(proposal_id="m1", judge_grade="A", judge_score=0.8, verdict="MISS"),
            ChangeRecord(proposal_id="m2", judge_grade="A", judge_score=0.8, verdict="MISS"),
            ChangeRecord(proposal_id="m3", judge_grade="A", judge_score=0.8, verdict="MISS"),
            ChangeRecord(proposal_id="m4", judge_grade="D", judge_score=0.2, verdict="HIT"),
        ])
        result = me.calibrate_judge()
        assert result["error_rate"] > 0

    def test_generate_strategy_advice_low_hit_rate(self):
        me = MetaEVOLVE()
        me.add_changes([
            ChangeRecord(proposal_id=p, verdict="MISS")
            for p in ["p1", "p2", "p3", "p4", "p5"]
        ])
        report = me.generate_strategy_advice()
        assert report.hit_rate == 0.0
        assert any(s.suggestion_type == "threshold_tune" for s in report.suggestions)

    def test_report_to_dict(self):
        me = MetaEVOLVE()
        report = me.generate_strategy_advice()
        d = report.to_dict()
        assert "hit_rate" in d

    def test_report_summary_line(self):
        report = MetaEvolveReport(hit_rate=0.5, total_changes=10)
        assert "50%" in report.summary_line


class TestSafetyShield:
    def test_m1_blocks_safety_guard(self):
        shield = SafetyShield()
        reason = shield.check("modify", "safety-guard.md")
        assert reason is not None
        assert "M1" in reason

    def test_m5_blocks_new_rules(self):
        shield = SafetyShield(level="M5")
        reason = shield.check("new_rule", "extra_safety")
        assert reason is not None
        assert "M5" in reason

    def test_normal_action_allowed(self):
        shield = SafetyShield()
        reason = shield.check("tune", "JudgeScore阈值")
        assert reason is None

    def test_record_and_rollback(self):
        shield = SafetyShield()
        shield.record_modification("test.txt", "old", "new")
        paths = shield.get_rollback_paths()
        assert len(paths) == 1
        assert paths[0]["path"] == "test.txt"

    def test_rollback_after_three_failures(self):
        shield = SafetyShield()
        shield.record_outcome(False)
        shield.record_outcome(False)
        assert not shield.should_rollback
        shield.record_outcome(False)
        assert shield.should_rollback


class TestActivationStatus:
    def test_phase1_always_ready(self):
        s = ActivationStatus()
        assert s.phase1_ready

    def test_phase2_not_ready(self):
        s = ActivationStatus()
        assert not s.phase2_ready

    def test_phase2_ready_with_judgestored(self):
        s = ActivationStatus(judgestored=True)
        assert s.phase2_ready

    def test_phase3_all_conditions(self):
        s = ActivationStatus(success_trails_ready=True,
                              safetyguard_stable=True, user_authorized=True, judgestored=True)
        assert s.phase3_ready


class TestDGOrchestrator:
    def test_default_state(self):
        dg = DGOrchestrator()
        status = dg.check_activation()
        assert not status.phase3_ready

    def test_set_activation(self):
        dg = DGOrchestrator()
        dg.set_activation(judgestored=True, user_authorized=True,
                          safetyguard_stable=True, success_trails_ready=True)
        status = dg.check_activation()
        assert status.phase3_ready

    def test_run_meta_evolve_blocked(self):
        dg = DGOrchestrator()
        result = dg.run_meta_evolve()
        assert result["status"] == "blocked"

    def test_apply_suggestion_blocked(self):
        dg = DGOrchestrator()
        result = dg.apply_suggestion({"suggestion_type": "modify", "target": "safety-guard.md"})
        assert not result["success"]

    def test_apply_suggestion_allowed(self, monkeypatch):
        dg = DGOrchestrator()
        dg.set_activation(judgestored=True)
        result = dg.apply_suggestion({"suggestion_type": "threshold_tune", "target": "JudgeScore阈值",
                                        "current_value": "0.6", "suggested_value": "0.7"})
        assert result["success"]

    def test_rollback_if_needed(self):
        dg = DGOrchestrator()
        assert dg.rollback_if_needed() is None
