"""tianlong.uxu — IS (Input Sanitization) 规则测试

UXU-IS-001 到 UXU-IS-005 各编写一个 pytest 测试函数，
验证 Scanner 能检测到对应漏洞。
"""

from __future__ import annotations

import pytest

from tianlong.uxu import Scanner


class TestIS001:
    """UXU-IS-001: 用户提示注入 — 未消毒的用户输入直接拼接到系统Prompt"""

    def test_detect_system_message_f_string(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "from langchain.schema import SystemMessage\n"
            'msg = SystemMessage(content=f"你是助理，请回答：{user_input}")\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-001"]
        assert len(findings) >= 1

    def test_detect_format_user_input(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            'system_prompt = "你是助理，请回答：{}".format(user_input)\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-001"]
        assert len(findings) >= 1

    def test_detect_chat_prompt_template(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "from langchain.prompts import ChatPromptTemplate\n"
            "ChatPromptTemplate.from_messages([\n"
            '    ("system", f"你是助理，回答：{user_input}"),\n'
            '    ("human", "{input}"),\n'
            "])\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-001"]
        assert len(findings) >= 1


class TestIS002:
    """UXU-IS-002: 外部内容注入 — 未经消毒的外部读取内容进入决策链"""

    def test_detect_web_search(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "from langchain.tools import tool\n"
            "\n"
            "@tool\n"
            "def search_web(query: str) -> str:\n"
            '    """Search the web"""\n'
            "    result = web_search(query)\n"
            "    return result\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-002"]
        assert len(findings) >= 1

    def test_detect_requests_get(self, tmp_path):
        f = tmp_path / "fetcher.py"
        f.write_text(
            "import requests\n"
            "\n"
            "def fetch_url(url):\n"
            "    resp = requests.get(url)\n"
            "    return resp.text\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-002"]
        assert len(findings) >= 1

    def test_detect_read_file(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "def load_document(path: str) -> str:\n"
            "    content = read_file(path)\n"
            "    return content\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-002"]
        assert len(findings) >= 1


class TestIS003:
    """UXU-IS-003: Prompt模板注入 — 用户可控变量嵌入系统级Prompt"""

    def test_detect_system_message_content(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "from langchain.schema import SystemMessage\n"
            'SystemMessage(content=f"你是{role_name}，请回答")\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-003"]
        assert len(findings) >= 1

    def test_detect_system_prompt_config(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "llm_cfg = {}\n"
            "llm_cfg['system_prompt'] = f'你是{user_name}助手'\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-003"]
        assert len(findings) >= 1

    def test_detect_agent_kwargs_system_message(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "agent_kwargs = {}\n"
            "agent_kwargs['system_message'] = f'你是{name}'\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-003"]
        assert len(findings) >= 1


class TestIS004:
    """UXU-IS-004: 间接注入 — 工具返回值未经消毒返回Agent循环"""

    def test_detect_tool_decorator(self, tmp_path):
        f = tmp_path / "tools.py"
        f.write_text(
            "from langchain.tools import tool\n"
            "\n"
            "@tool\n"
            "def get_user_data(user_id: str) -> str:\n"
            '    """Fetch user data"""\n'
            "    return db_query(user_id)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-004"]
        assert len(findings) >= 1

    def test_detect_structured_tool(self, tmp_path):
        f = tmp_path / "tools.py"
        f.write_text(
            "from langchain.tools import StructuredTool\n"
            "\n"
            "tool = StructuredTool.from_function(\n"
            "    func=my_function\n"
            ")\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-004"]
        assert len(findings) >= 1

    def test_detect_agent_executor(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "from langchain.agents import AgentExecutor\n"
            "executor = AgentExecutor(\n"
            "    agent=agent,\n"
            "    tools=tools,\n"
            ")\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-004"]
        assert len(findings) >= 1


class TestIS005:
    """UXU-IS-005: 多轮注入累积 — 跨轮次注入拼接绕过单轮检测"""

    def test_detect_conversation_buffer_memory(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "from langchain.memory import ConversationBufferMemory\n"
            "memory = ConversationBufferMemory()\n"
            "memory.chat_memory.add_user_message(user_input)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-005"]
        assert len(findings) >= 1

    def test_detect_conversation_summary_memory(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "from langchain.memory import ConversationSummaryMemory\n"
            "memory = ConversationSummaryMemory()\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-005"]
        assert len(findings) >= 1

    def test_detect_message_history(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "from langchain.schema import messages\n"
            "history = MessageHistory()\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-IS-005"]
        assert len(findings) >= 1
