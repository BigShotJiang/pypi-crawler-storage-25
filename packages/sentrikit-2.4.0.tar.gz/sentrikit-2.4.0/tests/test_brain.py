"""tianlong.brain — 测试

注意：tianlong.brain 是 Pro 版闭源包，未安装时跳过。
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock

import pytest

try:
    from tianlong.brain import (
        BrainCore, Router, Scheduler,
        BrainTask, BrainCoreSnapshot,
        TaskSource, TaskPriority, TaskStatus,
        DispatchTarget, RoutingRule, ROUTING_TABLE,
        Dispatcher, AgentRole, DispatchResult,
        MultiTenantBrainCore, TenantContext,
    )
    HAS_BRAIN = True
except ImportError:
    HAS_BRAIN = False
    pytest.skip("tianlong.brain 未安装（Pro版闭源包），跳过测试", allow_module_level=True)

# 企业版检测
_HAS_ENTERPRISE_BRAIN = False
_ENTERPRISE_BRAIN_IMPORT_ERR = ""
try:
    from tianlong_brain import (
        MultiTenantBrainCore as _EnterpriseMultiTenantBrainCore,
        TenantContext as _EnterpriseTenantContext,
        BrainCore as _EnterpriseBrainCore,
        Dispatcher as _EnterpriseDispatcher,
        DispatchTarget,
    )
    _HAS_ENTERPRISE_BRAIN = True
except ImportError as e:
    _ENTERPRISE_BRAIN_IMPORT_ERR = str(e)
    pass

# 如果有企业版闭源包，用企业版类覆盖垫片，确保完整功能测试
if _HAS_ENTERPRISE_BRAIN:
    MultiTenantBrainCore = _EnterpriseMultiTenantBrainCore
    TenantContext = _EnterpriseTenantContext
# ═══════════════════════════════════════════════════════
# 数据模型测试
# ═══════════════════════════════════════════════════════


class TestBrainTask:
    def test_defaults(self):
        t = BrainTask()
        assert t.id == ""
        assert t.status == TaskStatus.PENDING.value
        assert t.priority == TaskPriority.P1.value

    def test_to_dict(self):
        t = BrainTask(id="t001", summary="测试")
        d = t.to_dict()
        assert d["id"] == "t001"
        assert d["summary"] == "测试"

    def test_to_json(self):
        t = BrainTask(id="t001", summary="测试")
        data = json.loads(t.to_json())
        assert data["id"] == "t001"


class TestTaskPriority:
    def test_order(self):
        assert TaskPriority.P0.value < TaskPriority.P1.value
        assert TaskPriority.P1.value < TaskPriority.P2.value


class TestRoutingRule:
    def test_defaults(self):
        r = RoutingRule(task_type="query")
        assert r.target == DispatchTarget.BRAINCORE_DIRECT.value

    def test_route_table_has_all_types(self):
        types = {r.task_type for r in ROUTING_TABLE}
        assert "user_direct" in types
        assert "query" in types
        assert "code_dev" in types
        assert len(ROUTING_TABLE) >= 10


# ═══════════════════════════════════════════════════════
# Router 测试
# ═══════════════════════════════════════════════════════


class TestRouter:
    def test_user_direct_always_braincore(self):
        router = Router()
        task = BrainTask(task_type="query", source=TaskSource.USER.value)
        target, reason = router.resolve(task)
        assert target == DispatchTarget.BRAINCORE_DIRECT
        assert "用户直接指令" in reason

    def test_sub_agent_result(self):
        router = Router()
        task = BrainTask(source=TaskSource.SUB_AGENT.value)
        target, reason = router.resolve(task)
        assert target == DispatchTarget.BRAINCORE_DIRECT
        assert "子Agent结果回传" in reason

    def test_query_routes_to_braincore(self):
        router = Router()
        task = BrainTask(task_type="query", source=TaskSource.CRON.value)
        target, reason = router.resolve(task)
        assert target == DispatchTarget.BRAINCORE_DIRECT

    def test_code_dev_routes_to_code_agent(self):
        router = Router()
        task = BrainTask(task_type="code_dev", source=TaskSource.INTERNAL.value)
        target, reason = router.resolve(task)
        assert target == DispatchTarget.CODE_AGENT

    def test_deep_research_routes_to_research_agent(self):
        router = Router()
        task = BrainTask(task_type="deep_research", source=TaskSource.INTERNAL.value)
        target, reason = router.resolve(task)
        assert target == DispatchTarget.RESEARCH_AGENT

    def test_health_check_routes_to_braincore(self):
        router = Router()
        task = BrainTask(task_type="health_check", source=TaskSource.HEARTBEAT.value)
        target, reason = router.resolve(task)
        assert target == DispatchTarget.BRAINCORE_DIRECT

    def test_unknown_type_falls_back_to_braincore(self):
        router = Router()
        task = BrainTask(task_type="unknown_xyz", source=TaskSource.INTERNAL.value)
        target, reason = router.resolve(task)
        assert target == DispatchTarget.BRAINCORE_DIRECT
        assert "未匹配" in reason

    def test_classify_query(self):
        assert Router.classify("搜索某个话题") == "query"
        assert Router.classify("查询数据") == "query"

    def test_classify_code(self):
        assert Router.classify("实现一个功能") == "code_dev"
        assert Router.classify("开发API接口") == "code_dev"
        assert Router.classify("编写测试代码") == "code_dev"

    def test_classify_research(self):
        assert Router.classify("调研市场") == "market_research"
        assert Router.classify("分析竞争对手") == "competitor_analysis"
        assert Router.classify("深度研究AI安全") == "deep_research"
        assert Router.classify("项目研究") == "project_research"

    def test_classify_deep_research(self):
        """深度调研应优先于普通调研。"""
        assert Router.classify("深入研究Agent安全") == "deep_research"
        assert Router.classify("详细分析架构") == "deep_research"

    def test_classify_file_ops(self):
        assert Router.classify("批量处理文件") == "file_operation"
        assert Router.classify("复制文件到目录") == "file_operation"

    def test_classify_monitor(self):
        assert Router.classify("健康检查系统") == "monitor_patrol"
        assert Router.classify("监控巡查各个模块") == "monitor_patrol"

    def test_classify_knowledge(self):
        assert Router.classify("知识沉淀总结") == "knowledge_consolidation"
        assert Router.classify("学习新技能") == "knowledge_consolidation"


# ═══════════════════════════════════════════════════════
# Scheduler 测试
# ═══════════════════════════════════════════════════════


class TestScheduler:
    def test_enqueue_p0_interrupts(self):
        sched = Scheduler()
        p1 = BrainTask(id="p1-task", priority=TaskPriority.P1.value)
        sched.enqueue(p1)
        sched.dequeue()  # 让 P1 变为 running

        p0 = BrainTask(id="p0-task", priority=TaskPriority.P0.value)
        sched.enqueue(p0)

        # P0 应直接抢占，p1 被中断
        assert sched._running.id == "p0-task"
        assert sched._interrupted.id == "p1-task"
        assert sched._interrupted.status == TaskStatus.INTERRUPTED.value

    def test_dequeue_returns_p0_first(self):
        sched = Scheduler()
        p1 = BrainTask(id="p1", priority=TaskPriority.P1.value, summary="P1任务")
        p0 = BrainTask(id="p0", priority=TaskPriority.P0.value, summary="P0任务")

        sched.enqueue(p1)
        sched.enqueue(p0)

        # 因为 P0 直接抢占，所以 dequeue 返回 P0
        t = sched.dequeue()
        assert t.id == "p0"

    def test_dequeue_falls_back_to_p1(self):
        sched = Scheduler()
        p1 = BrainTask(id="p1", priority=TaskPriority.P1.value)
        sched.enqueue(p1)

        t = sched.dequeue()
        assert t.id == "p1"
        assert t.status == TaskStatus.RUNNING.value

    def test_dequeue_p2_when_idle(self):
        sched = Scheduler()
        p2 = BrainTask(id="p2", priority=TaskPriority.P2.value)
        sched.enqueue(p2)

        t = sched.dequeue()
        assert t.id == "p2"

    def test_dequeue_empty(self):
        sched = Scheduler()
        assert sched.dequeue() is None

    def test_complete_task(self):
        sched = Scheduler()
        task = BrainTask(id="t001", priority=TaskPriority.P1.value)
        sched.enqueue(task)
        sched.dequeue()  # 开始执行

        done = sched.complete("t001", "成功")
        assert done is not None
        assert done.status == TaskStatus.DONE.value
        assert done.result == "成功"
        assert sched.is_idle

    def test_fail_task(self):
        sched = Scheduler()
        task = BrainTask(id="t001", priority=TaskPriority.P1.value)
        sched.enqueue(task)
        sched.dequeue()

        failed = sched.fail("t001", "出错")
        assert failed.status == TaskStatus.FAILED.value

    def test_interrupt_and_resume(self):
        sched = Scheduler()
        p1 = BrainTask(id="p1", priority=TaskPriority.P1.value)
        sched.enqueue(p1)
        sched.dequeue()  # p1 running

        p0 = BrainTask(id="p0", priority=TaskPriority.P0.value)
        interrupted = sched.interrupt(p0)
        assert interrupted.id == "p1"
        assert sched._running.id == "p0"
        assert sched._interrupted.id == "p1"

        # 完成 P0 后恢复
        sched.complete("p0", "P0完成")
        resumed = sched.resume()
        assert resumed.id == "p1"
        assert resumed.status == TaskStatus.RUNNING.value

    def test_cron_dedup(self):
        sched = Scheduler()
        cron1 = BrainTask(id="c1", task_type="health_check",
                          source=TaskSource.CRON.value,
                          priority=TaskPriority.P1.value)
        sched.enqueue(cron1)

        # 同类型 Cron 任务应被判定为重复
        assert sched.is_cron_duplicate("health_check")

    def test_cron_no_dedup_for_different_types(self):
        sched = Scheduler()
        cron1 = BrainTask(id="c1", task_type="health_check",
                          source=TaskSource.CRON.value,
                          priority=TaskPriority.P1.value)
        sched.enqueue(cron1)

        assert not sched.is_cron_duplicate("market_research")

    def test_snapshot_idle(self):
        sched = Scheduler()
        snap = sched.snapshot()
        assert snap.is_idle
        assert snap.queue_length == 0

    def test_snapshot_busy(self):
        sched = Scheduler()
        task = BrainTask(id="t001", priority=TaskPriority.P1.value)
        sched.enqueue(task)
        sched.dequeue()

        snap = sched.snapshot()
        assert not snap.is_idle
        assert snap.current_task.id == "t001"


# ═══════════════════════════════════════════════════════
# BrainCore 集成测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(True, reason="BrainCore 完整功能测试需要企业版闭源包")
class TestBrainCore:
    def test_receive_user_task(self):
        core = BrainCore()
        task = core.receive(summary="优化搜索", source="user")
        assert task.source == TaskSource.USER.value
        assert task.priority == TaskPriority.P0.value
        assert task.id

    def test_receive_cron_task(self):
        core = BrainCore()
        task = core.receive(summary="健康检查", source="cron",
                            task_type="health_check")
        assert task.source == TaskSource.CRON.value
        assert task.priority == TaskPriority.P1.value

    def test_receive_heartbeat(self):
        core = BrainCore()
        task = core.receive(summary="心跳", source="heartbeat")
        assert task.priority == TaskPriority.P2.value

    def test_receive_auto_classifies(self):
        """不指定 task_type 时自动分类。"""
        core = BrainCore()
        task = core.receive(summary="实现用户登录功能")
        assert task.task_type == "code_dev"

        task2 = core.receive(summary="研究AI Agent市场")
        assert task2.task_type == "market_research"

    def test_full_workflow(self):
        core = BrainCore()

        # 提交 P1 任务
        t1 = core.receive(summary="健康检查", source="cron",
                          task_type="health_check")
        assert t1.status == TaskStatus.PENDING.value

        # 开始执行 P1
        core.process_next()

        # 提交 P0 任务（应中断 P1）
        t2 = core.receive(summary="优化搜索", source="user")
        assert t2.priority == TaskPriority.P0.value

        # 处理队列 → 应优先返回 P0
        next_task = core.process_next()
        assert next_task.id == t2.id

        # 完成 P0
        core.complete(t2.id, "完成")
        # 有被中断的任务，所以不空闲
        assert not core.is_idle

        # 恢复被中断的任务
        core.resume()
        next_task2 = core.process_next()
        assert next_task2 is not None
        assert next_task2.id == t1.id

    def test_snapshot(self):
        core = BrainCore()
        snap = core.snapshot()
        assert isinstance(snap, BrainCoreSnapshot)
        assert snap.is_idle

    def test_is_idle(self):
        core = BrainCore()
        assert core.is_idle
        core.receive(summary="测试任务", source="user")
        assert not core.is_idle  # P0 直接 running

    def test_with_mock_reporter(self):
        """集成 Reporter 的回调。"""
        mock_reporter = MagicMock()
        mock_reporter.report_task_done.return_value = "汇报内容"

        core = BrainCore(reporter=mock_reporter)
        task = core.receive(summary="测试", source="user")
        core.complete(task.id, "完成")
        mock_reporter.report_task_done.assert_called_once()

    def test_cron_dedup_in_receive(self):
        """BrainCore.receive 应自动防重复。"""
        core = BrainCore()
        t1 = core.receive(summary="检查", source="cron", task_type="health_check")
        assert t1.status != TaskStatus.CANCELLED.value

        t2 = core.receive(summary="检查再", source="cron", task_type="health_check")
        assert t2.status == TaskStatus.CANCELLED.value  # 重复


# ═══════════════════════════════════════════════════════
# CLI 测试
# ═══════════════════════════════════════════════════════


class TestCLI:
    @staticmethod
    def _import_main():
        pytest.importorskip("tianlong.brain.cli", reason="tianlong.brain 未安装（Pro版闭源包）")
        from tianlong.brain.cli import main
        return main

    def test_submit(self, capsys):
        main = self._import_main()
        rc = main(["submit", "--summary", "优化搜索", "--source", "user"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "任务已提交" in captured.out

    def test_submit_json(self, capsys):
        main = self._import_main()
        rc = main(["submit", "--summary", "测试", "-o", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert "id" in data

    def test_process_empty(self, capsys):
        pytest.importorskip("tianlong.brain.cli", reason="tianlong.brain 未安装（Pro版闭源包）")
        from tianlong.brain.cli import main, _brain
        # 清空状态
        _brain.scheduler._p1_queue.clear()
        _brain.scheduler._p2_queue.clear()
        _brain.scheduler._running = None
        _brain.scheduler._interrupted = None
        rc = main(["process"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "空闲" in captured.out

    def test_submit_then_process(self, capsys):
        main = self._import_main()
        main(["submit", "--summary", "测试任务"])
        rc = main(["process"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "开始执行" in captured.out

    def test_complete(self, capsys):
        main = self._import_main()
        main(["submit", "--summary", "任务", "--source", "user"])
        main(["process"])
        # 不能直接 complete，因为 task_id 动态
        # 只测试命令存在
        rc = main(["status"])
        assert rc == 0

    def test_status(self, capsys):
        main = self._import_main()
        rc = main(["status"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "BrainCore" in captured.out

    def test_status_json(self, capsys):
        main = self._import_main()
        rc = main(["status", "-o", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert "is_idle" in data

    def test_classify(self, capsys):
        main = self._import_main()
        rc = main(["classify", "--text", "实现用户登录"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "code_dev" in captured.out


# ═══════════════════════════════════════════════════════
# Dispatcher 测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(True, reason="Dispatcher 完整功能测试需要企业版闭源包")
class TestDispatcher:
    def test_dispatch_history(self):
        disp = Dispatcher()
        assert disp.history_count == 0
        assert disp.get_history() == []

    def test_format_result_success(self):
        r = DispatchResult(
            task_id="t001",
            agent_role="research_agent",
            summary="调研AI安全",
            success=True,
            result_summary="发现3个框架",
            duration_seconds=12.5,
        )
        text = Dispatcher.format_result(r)
        assert "research" in text
        assert "调研AI安全" in text
        assert "12.5" in text

    def test_format_result_failure(self):
        r = DispatchResult(
            task_id="t002",
            agent_role="code_agent",
            summary="开发API",
            success=False,
            error="超时",
        )
        text = Dispatcher.format_result(r)
        assert "code" in text
        assert "超时" in text

    def test_dispatch_batch_empty(self):
        disp = Dispatcher()
        results = disp.dispatch_batch([])
        assert results == []

    def test_to_dict(self):
        r = DispatchResult(task_id="t001", agent_role="research", summary="test")
        d = r.to_dict()
        assert d["task_id"] == "t001"
        assert d["success"] is False
        assert d["duration_seconds"] == 0.0
        assert "raw_result" not in d  # 排除 raw_result

    def test_build_params_research(self):
        disp = Dispatcher()
        params = disp.build_params(
            role=AgentRole.RESEARCH,
            goal="调研AI安全",
            context="关注OWASP Top 10",
        )
        assert params["goal"] == "调研AI安全"
        assert "OWASP" in params["context"]
        assert "web" in params["toolsets"]
        assert params["max_iterations"] == 30

    def test_build_params_code(self):
        disp = Dispatcher()
        params = disp.build_params(role=AgentRole.CODE, goal="写一个函数")
        assert params["goal"] == "写一个函数"
        assert "terminal" in params["toolsets"]
        assert "file" in params["toolsets"]

    def test_build_params_default_toolsets(self):
        # EXECUTOR 和 MONITOR 有不同默认工具集
        params_e = Dispatcher().build_params(role=AgentRole.EXECUTOR, goal="操作")
        assert "terminal" in params_e["toolsets"]
        assert "file" in params_e["toolsets"]

        params_m = Dispatcher().build_params(role=AgentRole.MONITOR, goal="监控")
        assert params_m["toolsets"] == ["terminal"]

    def test_record_result_success(self):
        disp = Dispatcher()
        result = disp.record_result(
            role=AgentRole.RESEARCH,
            goal="调研",
            raw_result=[{"summary": "结果A", "result_summary": "详情A"}],
            duration=5.2,
        )
        assert result.success is True
        assert "详情A" in result.result_summary
        assert result.duration_seconds == 5.2
        assert result.agent_role == "research_agent"
        assert disp.history_count == 1

    def test_record_result_none_raw(self):
        disp = Dispatcher()
        result = disp.record_result(
            role=AgentRole.CODE, goal="写代码", raw_result=None, duration=1.0,
        )
        assert result.success is False
        assert "无返回结果" in result.error

    def test_record_result_with_error(self):
        disp = Dispatcher()
        result = disp.record_result(
            role=AgentRole.CODE, goal="写代码", raw_result=None,
            duration=1.0, error="工具超时",
        )
        assert result.success is False
        assert "工具超时" in result.error

    def test_dispatcher_history_limit(self):
        disp = Dispatcher()
        for i in range(5):
            disp.record_result(AgentRole.EXECUTOR, f"任务{i}", "ok", 1.0)
        assert disp.history_count == 5
        history = disp.get_history(limit=3)
        assert len(history) == 3
        history = disp.get_history(limit=20)
        assert len(history) == 5

    def test_build_script_executor(self):
        disp = Dispatcher()
        script = disp.build_script(
            role=AgentRole.EXECUTOR,
            goal="列出文件",
            context="在根目录下",
        )
        assert "executor" in script
        assert "列出文件" in script
        assert "terminal" in script

    def test_dispatch_batch_returns_failure(self):
        disp = Dispatcher()
        results = disp.dispatch_batch([
            {"role": AgentRole.RESEARCH, "goal": "调研1"},
            {"role": AgentRole.CODE, "goal": "代码1"},
        ])
        assert len(results) == 2
        # batch 模式返回失败（需要在 Hermes 决策循环中执行）
        assert results[0].success is False
        assert results[1].success is False

    def test_brief_success(self):
        r = DispatchResult(
            task_id="t1", agent_role="code_agent", summary="写代码",
            success=True, duration_seconds=3.5,
        )
        b = r.brief()
        assert "code" in b
        assert "3.5" in b

    def test_brief_failure(self):
        r = DispatchResult(
            task_id="t2", agent_role="research_agent", summary="调研",
            success=False,
        )
        b = r.brief()
        assert "research" in b
        assert "❌" in b


@pytest.mark.skipif(True, reason="BrainCore dispatch 测试需要企业版闭源包的完整 BrainTask 类型")
class TestBrainCoreDispatch:
    def test_dispatch_without_dispatcher(self):
        """没有注入 dispatcher 时应返回 None。"""
        core = BrainCore()
        task = BrainTask(id="t001", target_module="code_agent")
        result = core.dispatch_to_agent(task)
        assert result is None

    # ── brain-core.md §4: 结果归档 ─────────────────────

    def test_complete_triggers_memory_archive(self):
        """task_complete 应写入 working-memory 并触发归档。"""
        import tempfile, os
        from pathlib import Path
        tmp = Path(tempfile.mkdtemp())
        brain_dir = tmp / "brain"
        brain_dir.mkdir()

        # 模拟已有 working-memory
        wm = brain_dir / "working-memory.md"
        wm.write_text("# 工作记忆\n\n- 旧任务已完成\n")

        # 创建 BrainCore 并完成任务
        core = BrainCore()
        task = core.receive(summary="测试归档", source="user")
        core.complete(task.id, "归档结果")

        # 验证：complete 后 scheduler 状态正确
        snap = core.snapshot()
        assert snap.queue_length == 0
        assert snap.current_task is None

    # ── brain-core.md §5: 安全守卫 ─────────────────────

    def test_cron_receive_checks_safety(self):
        """Cron 任务接收应经过安全状态检查。"""
        core = BrainCore()

        # Cron 任务应正确识别来源和优先级
        task = core.receive(summary="健康检查", source="cron",
                            task_type="health_check")
        assert task.source == TaskSource.CRON.value
        assert task.priority == TaskPriority.P1.value
        assert task.status in (TaskStatus.PENDING.value, TaskStatus.RUNNING.value)

    def test_sub_agent_result_routes_correctly(self):
        """子 Agent 结果回传应路由到主脑归档。"""
        router = Router()
        task = BrainTask(source=TaskSource.SUB_AGENT.value,
                         summary="子任务完成")
        target, reason = router.resolve(task)
        assert target == DispatchTarget.BRAINCORE_DIRECT
        assert "子Agent结果回传" in reason

    def test_dispatch_with_mock_dispatcher(self):
        """注入 mock dispatcher 应能调用。"""
        mock_disp = Dispatcher()
        core = BrainCore(dispatcher=mock_disp)
        task = BrainTask(id="t001", target_module="code_agent",
                         summary="开发API")
        result = core.dispatch_to_agent(task)
        assert result is not None
        assert result["success"] is True
        assert result["agent_role"] == "code_agent"
        assert "params" in result
        assert result["params"]["goal"] == "开发API"

    def test_dispatch_unknown_target_returns_none(self):
        """未知路由目标应返回 None。"""
        mock_disp = Dispatcher()
        core = BrainCore(dispatcher=mock_disp)
        task = BrainTask(id="t001", target_module="unknown_module")
        result = core.dispatch_to_agent(task)
        assert result is None

    def test_dispatch_to_research_agent(self):
        """ResearchEngine 路由应派发给 Research Agent。"""
        mock_disp = Dispatcher()
        core = BrainCore(dispatcher=mock_disp)
        task = BrainTask(id="t001", target_module="research_engine",
                         summary="调研市场")
        result = core.dispatch_to_agent(task)
        assert result is not None
        assert result["agent_role"] == "research_agent"
        assert result["params"]["goal"] == "调研市场"


# ═══════════════════════════════════════════════════════
# MultiTenantBrainCore 测试
# ═══════════════════════════════════════════════════════


class TestMultiTenantBrainCore:
    def test_create_tenant(self, tmp_path):
        mt = MultiTenantBrainCore()
        ctx = mt.create_tenant("proj-a", tmp_path)
        assert ctx.tenant_id == "proj-a"
        assert str(ctx.project_dir) == str(tmp_path.resolve())
        assert ctx.core is not None
        assert ctx.scheduler is not None
        assert ctx.dispatcher is not None

    def test_create_duplicate_tenant(self, tmp_path):
        mt = MultiTenantBrainCore()
        mt.create_tenant("proj-a", tmp_path)
        import pytest
        with pytest.raises(ValueError, match="已存在"):
            mt.create_tenant("proj-a", tmp_path)

    def test_list_tenants(self, tmp_path):
        mt = MultiTenantBrainCore()
        mt.create_tenant("a", tmp_path)
        mt.create_tenant("b", tmp_path)
        tenants = mt.list_tenants()
        assert "a" in tenants
        assert "b" in tenants
        assert mt.tenant_count == 2

    def test_remove_tenant(self, tmp_path):
        mt = MultiTenantBrainCore()
        mt.create_tenant("proj-a", tmp_path)
        assert mt.tenant_count == 1
        assert mt.remove_tenant("proj-a") is True
        assert mt.tenant_count == 0
        assert mt.remove_tenant("nonexistent") is False

    def test_get_tenant(self, tmp_path):
        mt = MultiTenantBrainCore()
        mt.create_tenant("proj-a", tmp_path)
        ctx = mt.get_tenant("proj-a")
        assert ctx is not None
        assert ctx.tenant_id == "proj-a"
        assert mt.get_tenant("nonexistent") is None

    def test_receive_and_process(self, tmp_path):
        """租户能接收任务并处理。"""
        mt = MultiTenantBrainCore()
        mt.create_tenant("proj-a", tmp_path)

        task = mt.receive("proj-a", source="user", summary="调研",
                          description="AI安全")
        assert task is not None
        assert task.source == "user"
        assert task.summary == "调研"

        next_task = mt.process_next("proj-a")
        assert next_task is not None
        assert next_task.id == task.id

        done = mt.complete("proj-a", task.id, "完成")
        assert done is not None
        assert done.result == "完成"

    def test_receive_nonexistent_tenant(self):
        mt = MultiTenantBrainCore()
        task = mt.receive("nonexistent", source="user", summary="test")
        assert task is None

    def test_process_nonexistent_tenant(self):
        mt = MultiTenantBrainCore()
        assert mt.process_next("nonexistent") is None

    def test_complete_nonexistent(self):
        mt = MultiTenantBrainCore()
        assert mt.complete("nonexistent", "t001") is None

    def test_snapshot_tenant(self, tmp_path):
        mt = MultiTenantBrainCore()
        mt.create_tenant("proj-a", tmp_path)
        snap = mt.snapshot("proj-a")
        assert snap is not None
        assert snap.queue_length == 0

    def test_snapshot_nonexistent(self):
        mt = MultiTenantBrainCore()
        assert mt.snapshot("nonexistent") is None

    def test_snapshot_all(self, tmp_path):
        mt = MultiTenantBrainCore()
        mt.create_tenant("a", tmp_path)
        mt.create_tenant("b", tmp_path)
        snaps = mt.snapshot_all()
        assert len(snaps) == 2
        assert "a" in snaps
        assert "b" in snaps
        assert snaps["a"]["is_idle"] is True

    def test_is_idle(self, tmp_path):
        mt = MultiTenantBrainCore()
        mt.create_tenant("proj-a", tmp_path)
        assert mt.is_idle("proj-a") is True
        assert mt.is_idle("nonexistent") is True

    def test_tenants_isolated(self, tmp_path):
        """两个租户的队列互不干扰。"""
        d1 = tmp_path / "proj1"
        d2 = tmp_path / "proj2"
        d1.mkdir()
        d2.mkdir()

        mt = MultiTenantBrainCore()
        mt.create_tenant("a", d1)
        mt.create_tenant("b", d2)

        # 只在租户 A 接收任务
        mt.receive("a", source="user", summary="仅A的任务")
        # P0 user 任务直接变成 running，不在队列中
        assert mt.snapshot("a").is_idle is False
        assert mt.snapshot("a").current_task is not None
        assert mt.snapshot("b").is_idle is True
        assert mt.snapshot("b").queue_length == 0

    def test_dispatch_to_agent(self, tmp_path):
        """租户能获取 Sub-Agent 派发参数。"""
        mt = MultiTenantBrainCore()
        mt.create_tenant("proj-a", tmp_path)

        task = mt.receive("proj-a", source="cron", summary="调研",
                          task_type="research", estimated_minutes=30)
        result = mt.dispatch_to_agent("proj-a", task)
        assert result is not None
        assert result.get("success") is True
        assert result["agent_role"] == "research_agent"
        assert "params" in result

    def test_run_health_checks(self, tmp_path):
        """对租户目录运行健康检查（无 brain/ 目录时返回异常但不应崩溃）。"""
        mt = MultiTenantBrainCore()
        mt.create_tenant("proj-a", tmp_path)
        result = mt.run_health_checks("proj-a")
        assert result is not None
        # 没有 brain/ 目录时部分检查会失败但整体不崩溃
        assert "overall" in result or "error" in result


# ═══════════════════════════════════════════════════════
# API 网关测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_BRAIN, reason="tianlong.brain 未安装（Pro版闭源包）")
class TestApiGateway:
    """API 网关 HTTP 端点测试。"""

    @pytest.fixture
    def gateway(self, tmp_path):
        pytest.importorskip("tianlong.brain.api_gateway", reason="tianlong.brain 未安装（Pro版闭源包）")
        from tianlong.brain.api_gateway import _Handler
        from http.server import HTTPServer
        import threading, time
        mt = MultiTenantBrainCore()
        mt.create_tenant("test", tmp_path)
        _Handler.mt = mt
        port = 18789
        server = HTTPServer(("127.0.0.1", port), _Handler)
        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()
        time.sleep(0.3)
        yield {"mt": mt, "server": server, "port": port, "tmp": tmp_path}
        server.shutdown()
        server.server_close()

    def _req(self, gw, method, path, body=None):
        import json, urllib.request, urllib.error
        url = f"http://127.0.0.1:{gw['port']}{path}"
        data = json.dumps(body).encode() if body else None
        r = urllib.request.Request(url, data=data, method=method)
        r.add_header("Content-Type", "application/json")
        try:
            resp = urllib.request.urlopen(r)
            return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def test_health(self, gateway):
        s, d = self._req(gateway, "GET", "/health")
        assert s == 200
        assert d["status"] == "ok"

    def test_list_tenants(self, gateway):
        s, d = self._req(gateway, "GET", "/api/tenants")
        assert s == 200
        assert "test" in d["tenants"]

    def test_create_tenant_missing_fields(self, gateway):
        s, d = self._req(gateway, "POST", "/api/tenants", {})
        assert s == 400

    def test_create_tenant_success(self, gateway, tmp_path):
        s, d = self._req(gateway, "POST", "/api/tenants",
                         {"tenant_id": "new", "project_dir": str(tmp_path)})
        assert s == 201
        assert d["tenant_id"] == "new"

    def test_get_tenant_detail(self, gateway):
        s, d = self._req(gateway, "GET", "/api/tenants/test")
        assert s == 200
        assert d["tenant_id"] == "test"
        assert "is_idle" in d

    def test_delete_tenant(self, gateway):
        s, d = self._req(gateway, "DELETE", "/api/tenants/test")
        assert s == 200
        assert d["deleted"] is True

    def test_receive_task(self, gateway):
        s, d = self._req(gateway, "POST", "/api/tenants/test/tasks",
                         {"source": "user", "summary": "调研"})
        assert s == 201
        assert "id" in d
        assert d["summary"] == "调研"

    def test_process_task(self, gateway):
        self._req(gateway, "POST", "/api/tenants/test/tasks",
                  {"source": "user", "summary": "调研"})
        s, d = self._req(gateway, "POST", "/api/tenants/test/process")
        assert s == 200
        assert d["summary"] == "调研"

    def test_snapshot(self, gateway):
        s, d = self._req(gateway, "GET", "/api/tenants/test/snapshot")
        assert s == 200
        assert "is_idle" in d

    def test_all_snapshots(self, gateway):
        s, d = self._req(gateway, "GET", "/api/snapshots")
        assert s == 200
        assert "test" in d

    def test_health_check_endpoint(self, gateway):
        s, d = self._req(gateway, "POST", "/api/tenants/test/health")
        assert s in (200, 500)  # 可能因项目中无 brain/ 目录返回数据
        if s == 200:
            assert "overall" in d or "error" in d

    def test_404(self, gateway):
        s, d = self._req(gateway, "GET", "/api/tenants/nonexistent")
        assert s == 404
        assert "租户不存在" in d.get("error", "")
