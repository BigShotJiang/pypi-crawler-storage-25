"""tianlong.monitor 测试"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import pytest

from tianlong.monitor.checks import (
    CheckResult,
    HealthReport,
    BaseCheck,
    WorkingMemoryCheck,
    TaskQueueCheck,
    ErrorLogCheck,
    SummaryFileCheck,
    IntegrityCheck,
    PythonVersionCheck,
    DiskSpaceCheck,
    CronStatusCheck,
    UxuSecurityCheck,
    run_all_checks,
    run_multi_project,
    register_check,
    get_registered_checks,
    DEFAULT_CHECKS,
)


# ── 数据模型测试 ──────────────────────────────────────


class TestCheckResult:
    def test_create_ok(self):
        r = CheckResult(name="test", status="ok", message="一切正常")
        assert r.name == "test"
        assert r.status == "ok"
        assert r.to_dict()["name"] == "test"

    def test_create_with_details(self):
        r = CheckResult(name="test", status="warning", message="有警告", details={"lines": 300})
        assert r.details["lines"] == 300


class TestHealthReport:
    def test_summary_all_ok(self):
        checks = [CheckResult("a", "ok", ""), CheckResult("b", "ok", "")]
        hr = HealthReport(timestamp="now", project_dir="/p", overall="healthy", checks=checks)
        assert hr.summary == {"total": 2, "ok": 2, "warning": 0, "error": 0}
        assert hr.exit_code == 0

    def test_summary_with_warning(self):
        checks = [CheckResult("a", "ok", ""), CheckResult("b", "warning", "慢点")]
        hr = HealthReport(timestamp="now", project_dir="/p", overall="warning", checks=checks)
        assert hr.summary == {"total": 2, "ok": 1, "warning": 1, "error": 0}
        assert hr.exit_code == 1

    def test_summary_with_error(self):
        checks = [CheckResult("a", "error", "挂了")]
        hr = HealthReport(timestamp="now", project_dir="/p", overall="error", checks=checks)
        assert hr.summary == {"total": 1, "ok": 0, "warning": 0, "error": 1}
        assert hr.exit_code == 2

    def test_to_json_valid(self):
        checks = [CheckResult("a", "ok", "正常")]
        hr = HealthReport(timestamp="now", project_dir="/p", overall="healthy", checks=checks)
        data = json.loads(hr.to_json())
        assert data["overall"] == "healthy"
        assert len(data["checks"]) == 1


# ── 检查器注册表测试 ──────────────────────────────────


class TestRegistry:
    def test_default_checks_are_registered(self):
        registered = get_registered_checks()
        assert len(registered) >= 8  # 原5个+新增3个
        assert WorkingMemoryCheck in registered
        assert PythonVersionCheck in registered
        assert DiskSpaceCheck in registered

    def test_custom_check_registration(self, monkeypatch):
        monkeypatch.setenv("TIANLONG_ENTERPRISE", "1")
        @register_check
        class CustomCheck(BaseCheck):
            def run(self) -> CheckResult:
                return CheckResult(name="custom", status="ok", message="自定义检查")

        registered = get_registered_checks()
        assert CustomCheck in registered

    def test_run_all_uses_registered_checks(self, tmp_path):
        """run_all_checks 不传 checks 参数时应使用所有已注册的检查器"""
        report = run_all_checks(tmp_path)
        assert len(report.checks) >= 8


# ── 辅助函数 ──────────────────────────────────────────


def _make_project(tmp_path: Path, files: dict[str, str]) -> Path:
    for relpath, content in files.items():
        fp = tmp_path / relpath
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content, encoding="utf-8")
    return tmp_path


# ── WorkingMemoryCheck ────────────────────────────────


class TestWorkingMemoryCheck:
    def test_under_threshold(self, tmp_path):
        project = _make_project(tmp_path, {"brain/working-memory.md": "\n".join(f"line{i}" for i in range(50))})
        result = WorkingMemoryCheck(project).run()
        assert result.status == "ok"
        assert "50行" in result.message

    def test_over_threshold(self, tmp_path):
        project = _make_project(tmp_path, {"brain/working-memory.md": "\n".join(f"line{i}" for i in range(250))})
        result = WorkingMemoryCheck(project).run()
        assert result.status == "warning"
        assert "250行" in result.message

    def test_file_missing(self, tmp_path):
        result = WorkingMemoryCheck(tmp_path).run()
        assert result.status == "warning"
        assert "不存在" in result.message


# ── TaskQueueCheck ────────────────────────────────────


class TestTaskQueueCheck:
    def test_no_pending(self, tmp_path):
        project = _make_project(tmp_path, {"brain/task-queue.md": "## [DONE] 已完成\n- 创建时间: 2026-04-27 13:00"})
        result = TaskQueueCheck(project).run()
        assert result.status == "ok"

    def test_recent_pending(self, tmp_path):
        today = datetime.now().strftime("%Y-%m-%d")
        project = _make_project(tmp_path, {"brain/task-queue.md": f"## [PENDING] 新任务\n- 创建时间: {today} 12:00"})
        result = TaskQueueCheck(project).run()
        assert result.status == "ok"

    def test_stale_pending(self, tmp_path):
        project = _make_project(tmp_path, {"brain/task-queue.md": "## [PENDING] 积压任务\n- 创建时间: 2026-04-20 10:00"})
        result = TaskQueueCheck(project).run()
        assert result.status == "warning"
        assert len(result.details["stale_tasks"]) >= 1

    def test_file_missing(self, tmp_path):
        result = TaskQueueCheck(tmp_path).run()
        assert result.status == "warning"


# ── ErrorLogCheck ─────────────────────────────────────


class TestErrorLogCheck:
    def test_no_error_log(self, tmp_path):
        result = ErrorLogCheck(tmp_path).run()
        assert result.status == "ok"

    def test_all_resolved(self, tmp_path):
        project = _make_project(tmp_path, {
            "brain/error-log.md": "## err-001: 并发写入丢失 ✅已解决\n## err-002: web_search无API Key ✅已解决\n"
        })
        result = ErrorLogCheck(project).run()
        assert result.status == "ok"

    def test_unresolved_errors(self, tmp_path):
        project = _make_project(tmp_path, {
            "brain/error-log.md": "## err-001: 已解决 ✅\n## err-003: 新错误未处理\n## err-004: 另一个未处理\n"
        })
        result = ErrorLogCheck(project).run()
        assert result.status == "warning"
        assert result.details["unresolved"] == 2


# ── SummaryFileCheck ──────────────────────────────────


class TestSummaryFileCheck:
    def test_few_files(self, tmp_path):
        project = _make_project(tmp_path, {"task-summary_2026-04-27.md": "ok"})
        result = SummaryFileCheck(project).run()
        assert result.status == "ok"

    def test_many_files(self, tmp_path):
        files = {f"task-summary_day{i}.md": f"content{i}" for i in range(15)}
        project = _make_project(tmp_path, files)
        result = SummaryFileCheck(project).run()
        assert result.status == "warning"
        assert result.details["count"] == 15


# ── IntegrityCheck ────────────────────────────────────


class TestIntegrityCheck:
    def test_all_present(self, tmp_path):
        files = {
            "AGENTS.md": "", "SOUL.md": "", "USER.md": "", "MEMORY.md": "", "IDENTITY.md": "",
            "brain/brain-core.md": "", "brain/safety-guard.md": "",
            "brain/working-memory.md": "", "brain/task-queue.md": "",
        }
        project = _make_project(tmp_path, files)
        result = IntegrityCheck(project).run()
        assert result.status == "ok"

    def test_some_missing(self, tmp_path):
        files = {"AGENTS.md": "", "SOUL.md": ""}
        project = _make_project(tmp_path, files)
        result = IntegrityCheck(project).run()
        assert result.status == "error"
        assert len(result.details["missing"]) >= 7


# ── PythonVersionCheck ────────────────────────────────


class TestPythonVersionCheck:
    def test_current_version(self):
        """当前 Python 版本应 >= 3.11"""
        result = PythonVersionCheck(Path()).run()
        assert result.status == "ok"
        assert "3." in result.message

    def test_version_parsing(self):
        result = PythonVersionCheck(Path()).run()
        assert result.details is not None
        assert "current" in result.details
        assert "required" in result.details


# ── DiskSpaceCheck ────────────────────────────────────


class TestDiskSpaceCheck:
    def test_returns_result(self, tmp_path):
        """磁盘检查应正常返回"""
        result = DiskSpaceCheck(tmp_path).run()
        assert result.status in ("ok", "warning")
        assert "GB" in result.message or "无法检查" in result.message


# ── CronStatusCheck ───────────────────────────────────


class TestCronStatusCheck:
    def test_no_health_dir(self, tmp_path):
        result = CronStatusCheck(tmp_path).run()
        assert result.status == "warning"
        assert "目录不存在" in result.message

    def test_empty_health_dir(self, tmp_path):
        (tmp_path / "memory" / "health").mkdir(parents=True)
        result = CronStatusCheck(tmp_path).run()
        assert result.status == "warning"
        assert "为空" in result.message

    def test_recent_log(self, tmp_path):
        health_dir = tmp_path / "memory" / "health"
        health_dir.mkdir(parents=True)
        (health_dir / "2026-04-27-1200.json").write_text("{}")
        result = CronStatusCheck(tmp_path).run()
        assert result.status in ("ok", "warning")  # 取决于文件时间


# ── Multi-project 测试 ────────────────────────────────


class TestMultiProject:
    def test_run_multi(self, tmp_path):
        p1 = _make_project(tmp_path / "proj1", {"AGENTS.md": ""})
        p2 = _make_project(tmp_path / "proj2", {"AGENTS.md": "", "SOUL.md": ""})
        reports = run_multi_project([p1, p2])
        assert len(reports) == 2
        for path_str, report in reports.items():
            assert report.summary["total"] >= 8


# ── run_all_checks 集成测试 ────────────────────────────


class TestRunAllChecks:
    def test_on_minimal_project(self, tmp_path):
        files = {
            "brain/working-memory.md": "line1\nline2",
            "brain/task-queue.md": "## [DONE] 旧任务\n- 创建时间: 2026-04-27 10:00",
            "AGENTS.md": "", "SOUL.md": "", "USER.md": "", "MEMORY.md": "", "IDENTITY.md": "",
            "brain/brain-core.md": "", "brain/safety-guard.md": "",
        }
        project = _make_project(tmp_path, files)
        report = run_all_checks(project)
        assert len(report.checks) >= 8
        for c in report.checks:
            assert c.status in ("ok", "warning", "error")

    def test_returns_json(self, tmp_path):
        report = run_all_checks(tmp_path)
        data = json.loads(report.to_json())
        assert "timestamp" in data
        assert "checks" in data
        assert len(data["checks"]) >= 9  # +1 for UxuSecurityCheck


# ── UXU 安全扫描检查器测试 ────────────────────────────


class TestUxuSecurityCheck:
    def test_skip_when_no_target(self, tmp_path):
        """没有扫描目标时返回 ok 不报错。"""
        check = UxuSecurityCheck(tmp_path)
        result = check.run()
        assert result.status in ("ok", "warning")
        assert "跳过" in result.message or "通过" in result.message or "异常" in result.message or "不可用" in result.message

    def test_scan_tianlong_source(self):
        """扫描真实的 tianlong 源码目录。"""
        project = Path("/tmp/test-project")
        check = UxuSecurityCheck(project)
        result = check.run()
        assert result.name == "uxu-security"
        assert result.status in ("ok", "warning", "error")
        # 应该至少扫到一些文件
        if result.details:
            assert "total_findings" in result.details

    def test_registered_in_defaults(self):
        """UxuSecurityCheck 应被注册到默认检查器列表。"""
        assert UxuSecurityCheck in DEFAULT_CHECKS

    def test_included_in_run_all(self, tmp_path):
        """run_all_checks 应包含 uxu-security 检查结果。"""
        report = run_all_checks(tmp_path)
        uxu_results = [c for c in report.checks if c.name == "uxu-security"]
        assert len(uxu_results) == 1


# ── MetaCog 退化检测测试 ─────────────────────────────


class TestMetaCogDegradationCheck:
    def test_ok_when_healthy(self, tmp_path):
        """系统健康时返回 ok。"""
        # 创建必要的文件模拟健康系统
        (tmp_path / "brain").mkdir(parents=True)
        (tmp_path / "brain" / "working-memory.md").write_text("# working-memory\n- 最后更新: today\n")
        (tmp_path / "brain" / "error-log.md").write_text("# 错误日志\n\n（当前无未解决问题）\n")

        from tianlong.monitor.checks import MetaCogDegradationCheck
        check = MetaCogDegradationCheck(tmp_path)
        result = check.run()

        assert result.status in ("ok", "warning")
        assert result.name == "metacog-degradation"
        if result.details:
            assert "overall_score" in result.details

    def test_warning_on_many_errors(self, tmp_path):
        """错误多时应触发警告。"""
        (tmp_path / "brain").mkdir(parents=True)
        (tmp_path / "brain" / "working-memory.md").write_text("# wm\n")
        (tmp_path / "brain" / "error-log.md").write_text(
            "## [待处理] 错误1\n- ID: e001\n"
            "## [待处理] 错误2\n- ID: e002\n"
            "## [待处理] 错误3\n- ID: e003\n"
            "## [待处理] 错误4\n- ID: e004\n"
        )

        from tianlong.monitor.checks import MetaCogDegradationCheck
        check = MetaCogDegradationCheck(tmp_path)
        result = check.run()
        # 重复错误>=3会触发 moderate 信号——ok 或 warning 都可接受
        assert result.name == "metacog-degradation"

    def test_registered_in_defaults(self):
        """MetaCogDegradationCheck 应被注册到默认检查器列表。"""
        from tianlong.monitor.checks import MetaCogDegradationCheck, DEFAULT_CHECKS
        assert MetaCogDegradationCheck in DEFAULT_CHECKS

    def test_included_in_run_all(self, tmp_path):
        """run_all_checks 应包含 metacog-degradation 检查结果。"""
        report = run_all_checks(tmp_path)
        mc_results = [c for c in report.checks if c.name == "metacog-degradation"]
        assert len(mc_results) == 1
