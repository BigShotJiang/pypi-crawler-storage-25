"""tianlong.judge — 测试"""

from __future__ import annotations

import json

import pytest

from tianlong.judge import JudgeEngine, JudgeResult, JudgeGrade, RuleBasedJudge
from tianlong.judge.core import (
    DimensionScore, Proposal, score_to_grade,
    GRADE_THRESHOLDS, DEFAULT_WEIGHTS,
)


# ── 数据模型测试 ──────────────────────────────────────


class TestDimensionScore:
    def test_weighted_score(self):
        d = DimensionScore(name="direction", score=0.8, weight=0.25)
        assert d.weighted == 0.2  # 0.8 * 0.25

    def test_clamp_values(self):
        d = DimensionScore(name="test", score=1.0, weight=0.5)
        assert d.weighted == 0.5


class TestJudgeGrade:
    def test_score_to_grade(self):
        assert score_to_grade(0.90) == JudgeGrade.S
        assert score_to_grade(0.75) == JudgeGrade.A
        assert score_to_grade(0.60) == JudgeGrade.B
        assert score_to_grade(0.40) == JudgeGrade.C
        assert score_to_grade(0.20) == JudgeGrade.D

    def test_grade_values(self):
        assert JudgeGrade.S.value == "S"
        assert JudgeGrade.D.value == "D"


class TestJudgeResult:
    def test_create_result(self):
        dims = [
            DimensionScore("direction", 0.8, 0.25, "方向正确"),
            DimensionScore("efficiency", 0.8, 0.20, "效率高"),
            DimensionScore("robustness", 0.7, 0.20, "鲁棒性好"),
            DimensionScore("reusability", 0.5, 0.15, "可复用性一般"),
            DimensionScore("cost_risk", 0.8, 0.20, "成本可控"),
        ]
        result = JudgeResult(
            proposal_id="p001",
            proposal_summary="优化搜索流程",
            dimensions=dims,
        )
        assert result.passed()
        assert result.total_score >= 0.7

    def test_to_dict(self):
        dims = [DimensionScore("direction", 0.8, 0.25)]
        result = JudgeResult(proposal_id="p001", proposal_summary="test", dimensions=dims)
        d = result.to_dict()
        assert d["proposal_id"] == "p001"
        assert "total_score" in d
        assert "grade" in d

    def test_to_json(self):
        dims = [DimensionScore("direction", 0.8, 0.25)]
        result = JudgeResult(proposal_id="p001", proposal_summary="test", dimensions=dims)
        data = json.loads(result.to_json())
        assert data["proposal_id"] == "p001"

    def test_failed_proposal(self):
        dims = [
            DimensionScore("direction", 0.2, 0.25, "方向错误"),
            DimensionScore("efficiency", 0.1, 0.20, "效率低"),
            DimensionScore("robustness", 0.2, 0.20, "鲁棒性差"),
            DimensionScore("reusability", 0.1, 0.15, "不可复用"),
            DimensionScore("cost_risk", 0.2, 0.20, "成本高"),
        ]
        result = JudgeResult(proposal_id="p002", proposal_summary="删除核心配置", dimensions=dims)
        assert not result.passed()
        assert result.grade in (JudgeGrade.C, JudgeGrade.D)


# ── RuleBasedJudge 测试 ───────────────────────────────


class TestRuleBasedJudge:
    def test_good_proposal(self):
        judge = RuleBasedJudge()
        proposal = Proposal(
            id="p001",
            summary="优化搜索流程，减少步骤",
            change_type="update",
            estimated_steps=3,
            estimated_tokens=1000,
            is_rsi_aligned=True,
        )
        result = judge.evaluate(proposal)
        assert result.passed()
        assert result.total_score >= 0.5

    def test_bad_proposal(self):
        judge = RuleBasedJudge()
        proposal = Proposal(
            id="p002",
            summary="删除核心配置",
            change_type="delete",
            estimated_steps=10,
            estimated_tokens=5000,
            previous_failures=5,
            is_rsi_aligned=False,
        )
        result = judge.evaluate(proposal)
        assert not result.passed()
        assert result.total_score < 0.5

    def test_template_evaluation(self):
        judge = RuleBasedJudge()
        result = judge.evaluate_from_template("create_new_knowledge", "t001")
        assert result.passed()
        assert result.grade in (JudgeGrade.A, JudgeGrade.S)

    def test_template_delete(self):
        judge = RuleBasedJudge()
        result = judge.evaluate_from_template("delete_content", "t002")
        assert not result.passed()
        assert result.grade in (JudgeGrade.C, JudgeGrade.D)

    def test_template_performance(self):
        judge = RuleBasedJudge()
        result = judge.evaluate_from_template("optimize_performance", "t003")
        assert result.passed()
        assert result.total_score >= 0.7

    def test_custom_weights(self):
        """测试自定义权重"""
        class CustomJudge(RuleBasedJudge):
            weights = {
                "direction": 0.5,     # 方向性权重加倍
                "efficiency": 0.1,
                "robustness": 0.1,
                "reusability": 0.1,
                "cost_risk": 0.2,
            }
        judge = CustomJudge()
        proposal = Proposal(id="p003", summary="测试", is_rsi_aligned=True)
        result = judge.evaluate(proposal)
        assert result.total_score > 0

    def test_invalid_template(self):
        judge = RuleBasedJudge()
        with pytest.raises(ValueError):
            judge.evaluate_from_template("nonexistent")


# ── 集成测试 ──────────────────────────────────────────


class TestIntegration:
    def test_full_workflow(self):
        """模拟一次完整的评估流程"""
        judge = RuleBasedJudge()

        # 1. 好的提案 — 通过
        good = Proposal(
            id="p001",
            summary="新增失败挖掘流程",
            change_type="create",
            estimated_steps=4,
            estimated_tokens=1500,
            is_rsi_aligned=True,
        )
        result1 = judge.evaluate(good)
        assert result1.passed()
        assert result1.grade in (JudgeGrade.A, JudgeGrade.S)

        # 2. 差的提案 — 不通过
        bad = Proposal(
            id="p002",
            summary="直接删除错误日志",
            change_type="delete",
            estimated_steps=1,
            previous_failures=3,
            is_rsi_aligned=False,
        )
        result2 = judge.evaluate(bad)
        assert not result2.passed()

        # 3. 结果可序列化
        json1 = result1.to_json()
        data = json.loads(json1)
        assert data["passed"] is True
        assert len(data["dimensions"]) == 5
