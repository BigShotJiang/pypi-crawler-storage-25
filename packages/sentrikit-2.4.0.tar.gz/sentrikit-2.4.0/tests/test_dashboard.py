"""tianlong.license + dashboard — 测试"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tianlong.license import require_pro, module_allowed, LicenseLevel


class TestLicense:
    def test_mit_license(self):
        """全部免费开源，不再有授权检查。"""
        assert require_pro("evolution") is True
        assert require_pro("brain") is True

    def test_module_allowed(self):
        assert module_allowed("evolution") is True
        assert module_allowed("brain") is True
        assert module_allowed("monitor") is True

    def test_license_level(self):
        assert LicenseLevel.COMMUNITY.value == "community"
        assert LicenseLevel.ENTERPRISE.value == "enterprise"


class TestDashboard:
    def test_build_html(self):
        from tianlong.dashboard import build_dashboard
        html = build_dashboard(project_dir="/tmp")
        assert "dashboard" in html.lower() or "仪表盘" in html
        assert "html" in html

    def test_build_html_with_data(self):
        from tianlong.dashboard import build_dashboard
        html = build_dashboard(
            project_dir="/tmp",
            monitor_data={"overall": "healthy", "summary": {"ok": 8, "total": 8}},
            judge_data={"overall_health": "healthy", "total_proposals": 10,
                        "overall_score": 0.8, "overall_grade": "A"},
            uxu_data={"summary": {"grade": "A", "score": 95, "total": 2,
                                   "files_scanned": 10}},
        )
        assert "healthy" in html.lower()
        assert "A" in html

    def test_cli_help(self, capsys):
        from tianlong.dashboard.cli import main
        with pytest.raises(SystemExit):
            main(["--help"])

    def test_cli_html_output(self, capsys, tmp_path):
        from tianlong.dashboard.cli import main
        rc = main(["--project-dir", str(tmp_path), "--output", "html"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "html" in captured.out or "仪表盘" in captured.out

    def test_cli_json_output(self, capsys, tmp_path):
        from tianlong.dashboard.cli import main
        rc = main(["--project-dir", str(tmp_path), "--output", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert "monitor" in data
        assert "uxu" in data

    def test_dashboard_has_rings(self):
        """仪表盘应包含进度环 (conic-gradient)。"""
        from tianlong.dashboard import build_dashboard
        html = build_dashboard(
            project_dir="/tmp",
            monitor_data={"overall": "healthy", "summary": {"ok": 8, "total": 8}},
            judge_data={"overall_health": "healthy", "total_proposals": 10,
                        "overall_score": 0.8, "overall_grade": "A"},
            uxu_data={"summary": {"grade": "A", "score": 95, "total": 2,
                                   "files_scanned": 10}},
        )
        assert "conic-gradient" in html
        assert "ring" in html

    def test_dashboard_with_findings(self):
        """仪表盘包含发现清单表格。"""
        from tianlong.dashboard import build_dashboard
        html = build_dashboard(
            project_dir="/tmp",
            uxu_data={
                "summary": {"grade": "B", "score": 70, "total": 3, "files_scanned": 5},
                "findings": [
                    {"rule_id": "UXU-IS-001", "severity": "high", "title": "注入风险", "file": "test.py"},
                    {"rule_id": "UXU-PM-002", "severity": "medium", "title": "权限过宽", "file": "app.py"},
                ],
            },
        )
        assert "UXU-IS-001" in html
        assert "发现清单" in html or "findings" in html.lower()

    def test_dashboard_metacog_data(self):
        """仪表盘显示退化检测数据。"""
        from tianlong.dashboard import build_dashboard
        html = build_dashboard(
            project_dir="/tmp",
            metacog_data={"should_evolve": True, "overall_score": 0.45, "max_level": "moderate",
                          "message": "触发: repeat_failure"},
        )
        assert "0.45" in html
        assert "repeat_failure" in html or "退化" in html

    def test_dashboard_with_tenants(self):
        """仪表盘显示多租户卡片。"""
        from tianlong.dashboard import build_dashboard
        html = build_dashboard(
            project_dir="/tmp",
            tenant_data={
                "proj-a": {"is_idle": True, "queue_length": 0, "project_dir": "/path/a"},
                "proj-b": {"is_idle": False, "queue_length": 3, "project_dir": "/path/b"},
            },
        )
        assert "proj-a" in html
        assert "proj-b" in html
        assert "多租户" in html
