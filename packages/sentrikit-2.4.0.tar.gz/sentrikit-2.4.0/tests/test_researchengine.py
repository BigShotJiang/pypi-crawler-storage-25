"""tianlong.researchengine + agents.runner — 测试

注意：researchengine 是企业版模块，社区版垫片提供基础功能但测试需适配。
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tianlong.researchengine import ResearchEngine, ResearchType, ResearchResult, ResearchAgent
from tianlong.agents.templates import render_template, get_template_keys

_HAS_ENTERPRISE = False
try:
    from tianlong import enterprise_client
    _HAS_ENTERPRISE = enterprise_client.is_enterprise()
except ImportError:
    pass


class TestResearchResult:
    def test_defaults(self):
        r = ResearchResult()
        assert r.topic == ""
        assert not r.high_value

    def test_to_dict(self):
        r = ResearchResult(topic="test", key_points=["a", "b"])
        d = r.to_dict()
        assert d["topic"] == "test"
        assert "key_points" in d


class TestResearchEngine:
    def test_research_quick(self):
        engine = ResearchEngine()
        result = engine.research("测试主题", ResearchType.QUICK)
        assert result.topic == "测试主题"
        assert result.research_type == "quick_query"
        assert result.duration_seconds >= 0

    def test_research_market(self):
        engine = ResearchEngine()
        result = engine.research("市场调研测试", ResearchType.MARKET)
        assert result.research_type == "market_overview"

    def test_research_technical(self):
        engine = ResearchEngine()
        result = engine.research("技术调研测试", ResearchType.TECHNICAL)
        assert result.research_type == "technical_research"

    def test_high_value_detection_market(self):
        engine = ResearchEngine()
        text = "该市场规模增长 150%，复合年化增长率 35%"
        v = engine._detect_high_value(text)
        assert v["is_high_value"]
        assert "市场规模" in v["reason"]

    def test_high_value_detection_tech(self):
        engine = ResearchEngine()
        text = "这是一项重大技术突破，开源项目已发布 GPT-5 级别模型"
        v = engine._detect_high_value(text)
        assert v["is_high_value"]

    def test_high_value_detection_empty(self):
        engine = ResearchEngine()
        v = engine._detect_high_value("普通日常内容")
        assert not v["is_high_value"]

    def test_history(self):
        engine = ResearchEngine()
        result = engine.research("历史测试", ResearchType.QUICK)
        history = engine.get_history()
        assert len(history) >= 1
        assert history[-1].topic == "历史测试"


class TestResearchAgent:
    def test_search_single(self):
        agent = ResearchAgent()
        results = agent.search("测试查询")
        assert len(results) >= 1
        assert results[0].topic == "测试查询"
        assert results[0].high_value is False

    def test_search_multi(self):
        agent = ResearchAgent()
        results = agent.search("多结果测试", limit=5)
        assert len(results) >= 3

    def test_cache(self):
        agent = ResearchAgent(cache_dir=str(Path.home() / ".tianlong" / "test_cache"))
        results1 = agent.search("缓存测试")
        results2 = agent.search("缓存测试")
        assert len(results1) == len(results2)


class TestRunnerCLI:
    def test_research_cli(self):
        from tianlong.agents.runner import cmd_research
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--topic", default="测试")
        parser.add_argument("--quick", action="store_true")
        parser.add_argument("--json", action="store_true")
        parser.add_argument("--output", default="")
        parser.add_argument("--context", default="")
        args = parser.parse_args(["--topic", "CLI测试", "--quick"])
        code = cmd_research(args)
        assert code == 0

    def test_research_json(self):
        from tianlong.agents.runner import cmd_research
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--topic", default="测试")
        parser.add_argument("--quick", action="store_true")
        parser.add_argument("--json", action="store_true")
        parser.add_argument("--output", default="")
        parser.add_argument("--context", default="")
        args = parser.parse_args(["--topic", "JSON测试", "--quick", "--json"])
        code = cmd_research(args)
        assert code == 0
