"""tianlong.safety 测试"""

from __future__ import annotations

from pathlib import Path

import pytest

from tianlong.safety import SafetyGuard, GuardResult, ChangeType, RiskLevel
from tianlong.safety.rules import (
    Rule, DEFAULT_RULES, make_rules,
)


# ── 基础测试 ──────────────────────────────────────────


class TestChangeType:
    def test_change_type_mapping(self):
        assert ChangeType.CREATE.value == "create"
        assert ChangeType.DELETE.value == "delete"
        assert ChangeType.CONFIG.value == "config"


class TestGuardResult:
    def test_allowed(self):
        r = GuardResult(allowed=True, risk_level=RiskLevel.LOW)
        assert r.allowed
        assert r.risk_level == RiskLevel.LOW
        assert not r.requires_confirmation

    def test_forbidden(self):
        r = GuardResult(allowed=False, risk_level=RiskLevel.FORBIDDEN, reason="测试阻止")
        assert not r.allowed
        assert r.reason == "测试阻止"

    def test_requires_confirmation(self):
        r = GuardResult(allowed=True, risk_level=RiskLevel.HIGH, requires_confirmation=True)
        assert r.requires_confirmation

    def test_to_dict(self):
        r = GuardResult(allowed=True, risk_level=RiskLevel.LOW)
        d = r.to_dict()
        assert d["allowed"] is True
        assert d["risk_level"] == "low"


# ── Rules 测试 ────────────────────────────────────────


class TestDefaultRules:
    def test_five_rules(self):
        assert len(DEFAULT_RULES) == 6
        names = [r.name for r in DEFAULT_RULES]
        assert names == ["R1", "R2", "R3", "R4", "R5", "R6"]

    @pytest.mark.parametrize("action,target,should_block", [
        (ChangeType.DELETE, "file.txt", True),       # R1
        (ChangeType.CREATE, "file.txt", False),       # 创建不触发R1
        (ChangeType.UPDATE, "api_key.txt", True),     # R2
        (ChangeType.UPDATE, "notes.txt", False),      # 正常文件不触发R2
        (ChangeType.EXECUTE, "rm -rf /", True),       # R3
        (ChangeType.EXECUTE, "ls -la", False),        # 安全命令
        (ChangeType.UPDATE, "safety-guard.md", True), # R4
        (ChangeType.UPDATE, "README.md", False),      # 非保护文件
        (ChangeType.EXECUTE, "chmod 777 file", True), # R5
        (ChangeType.EXECUTE, "cat file", False),      # 安全操作
    ])
    def test_rules(self, action, target, should_block):
        """验证5条红线在不同场景下的阻止行为"""
        guard = SafetyGuard()
        guard.load_rules(DEFAULT_RULES)
        result = guard.check(action=action, target=target)
        if should_block:
            assert not result.allowed, f"应该阻止: {action} {target}"
        else:
            assert result.allowed, f"应该放行: {action} {target}"


class TestCustomRule:
    def test_custom_rule_appended(self):
        """自定义规则追加到默认规则之后"""
        custom = Rule("R6", "禁止操作/tmp目录", lambda a, t: "阻止" if "/tmp/" in t else None)
        rules = make_rules([custom])
        assert len(rules) == 7
        # 最后一条是自定义的 R6（追加在默认 R6 之后）
        assert rules[-1].name == "R6"
        # 默认 R6 和自定义 R6 都在
        assert rules[5].name == "R6"  # 默认
        assert rules[6] is custom     # 自定义

    def test_custom_rule_blocks(self):
        guard = SafetyGuard(rules=[
            Rule("custom", "阻止create", lambda a, t: "阻止" if a == ChangeType.CREATE else None),
        ])
        r = guard.check(action=ChangeType.CREATE, target="file.txt")
        assert not r.allowed


# ── SafetyGuard 核心测试 ──────────────────────────────


class TestSafetyGuard:
    def test_empty_guard_allows_create(self):
        guard = SafetyGuard()
        result = guard.check(action=ChangeType.CREATE, target="test.md")
        assert result.allowed
        assert result.risk_level == RiskLevel.LOW

    def test_delete_blocked(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.DELETE, target="config.yaml")
        assert not result.allowed
        assert result.rule_triggered == "R1"

    def test_immutable_file_update_blocked(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.UPDATE, target="/path/to/safety-guard.md")
        assert not result.allowed
        # R4 和 immutable 双重检查，R4 先触发
        assert result.rule_triggered in ("R4", "immutable_files")

    def test_immutable_file_create_allowed(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.CREATE, target="safety-guard.md")
        assert result.allowed  # 创建新文件不受限，只有更新/删除受限

    def test_config_needs_confirmation(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.CONFIG, target="brain-core.md")
        assert result.allowed
        assert result.requires_confirmation

    def test_audit_log_records_check(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        guard.check(action=ChangeType.DELETE, target="test.txt", trigger="测试", summary="删除测试")
        logs = guard.get_audit_log()
        assert len(logs) == 1
        assert logs[0]["trigger"] == "测试"
        assert logs[0]["allowed"] is False

    def test_audit_log_multiple_checks(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        for i in range(5):
            guard.check(action=ChangeType.CREATE, target=f"file{i}.md")
        assert len(guard.get_audit_log()) == 5

    def test_audit_log_limit(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        for i in range(30):
            guard.check(action=ChangeType.CREATE, target=f"file{i}.md")
        logs = guard.get_audit_log(limit=10)
        assert len(logs) == 10


# ── 退化检测测试 ──────────────────────────────────────


class TestDegradation:
    def test_single_degradation(self):
        guard = SafetyGuard()
        result = guard.record_degradation("错误重复率", "同类错误出现3次")
        assert result["warning"] is True
        assert result["count"] == 1
        assert result["paused"] is False

    def test_three_degradations_pause(self):
        guard = SafetyGuard()
        for i in range(3):
            guard.record_degradation("指标X", f"退化{i+1}")
        assert guard.is_paused is True

    def test_reset_degradation(self):
        guard = SafetyGuard()
        for _ in range(3):
            guard.record_degradation("指标X", "退化")
        assert guard.is_paused
        guard.reset_degradation()
        assert guard.is_paused is False
        assert guard._degradation_count == 0

    def test_degradation_logs_audit(self):
        guard = SafetyGuard()
        guard.record_degradation("冷启动成功率", "首次成功<50%")
        logs = guard.get_audit_log()
        # debug
        print("\nDEBUG logs:", logs)
        assert any("冷启动成功率" in str(l) for l in logs)


# ── 集成测试 ──────────────────────────────────────────


class TestIntegration:
    def test_full_workflow(self):
        """模拟一次完整的安全检查流程"""
        guard = SafetyGuard()
        guard.load_rules(DEFAULT_RULES)

        # 1. 创建文件 — 允许
        r1 = guard.check(action=ChangeType.CREATE, target="note.md", trigger="用户")
        assert r1.allowed

        # 2. 删除敏感文件 — 阻止
        r2 = guard.check(action=ChangeType.DELETE, target="config.yaml", trigger="SelfLearning")
        assert not r2.allowed

        # 3. 更新安全规则 — 阻止
        r3 = guard.check(action=ChangeType.UPDATE, target="brain/safety-guard.md", trigger="SelfLearning")
        assert not r3.allowed

        # 4. 修改核心配置 — 允许但需要确认
        r4 = guard.check(action=ChangeType.CONFIG, target="brain/brain-core.md", trigger="用户")
        assert r4.allowed
        assert r4.requires_confirmation

        # 5. 审计日志有4条
        assert len(guard.get_audit_log()) == 4

    def test_save_audit_log(self, tmp_path):
        guard = SafetyGuard()
        guard.check(action=ChangeType.CREATE, target="test.md", trigger="测试")
        log_file = guard.save_audit_log(tmp_path / "audit.json")
        assert log_file.exists()
        content = log_file.read_text()
        assert "test.md" in content


# ═══════════════════════════════════════════════════════
# R6 法律合规测试
# ═══════════════════════════════════════════════════════


class TestR6LegalCompliance:
    def test_six_rules_loaded(self):
        assert len(DEFAULT_RULES) == 6
        assert DEFAULT_RULES[5].name == "R6"

    def test_gdpr_delete_blocked(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        # R1 会先拦截删除操作，R6 的 GDPR 检查用非删除操作测试
        result = guard.check(action=ChangeType.CONFIG, target="gdpr_data_retention.yaml")
        assert not result.allowed
        assert result.rule_triggered in ("R6",)

    def test_ccpa_config_blocked(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.CONFIG, target="ccpa_compliance_config.yaml")
        assert not result.allowed

    def test_hipaa_execute_blocked(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.EXECUTE, target="hipaa_audit_script.sh")
        assert not result.allowed

    def test_chinese_law_blocked(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.DELETE, target="data/个保法相关记录.csv")
        assert not result.allowed

    def test_personal_data_delete_warning(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.DELETE, target="user_data/backup.sql")
        assert not result.allowed

    def test_normal_operation_allowed(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.CREATE, target="new_feature.py")
        assert result.allowed

    def test_normal_read_allowed(self):
        guard = SafetyGuard(rules=DEFAULT_RULES)
        result = guard.check(action=ChangeType.UPDATE, target="README.md")
        assert result.allowed

    def test_r6_in_cli_rules_command(self):
        """CLI rules 命令应显示 R6。"""
        from tianlong.safety.cli import main
        import sys
        rc = main(["rules", "-o", "json"])
        # 这个测试只验证 R6 在规则列表中
        # 实际测试通过 json 输出验证
        assert rc == 0
