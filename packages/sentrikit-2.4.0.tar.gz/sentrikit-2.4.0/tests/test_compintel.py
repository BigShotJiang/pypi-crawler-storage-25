"""tianlong.compintel — 测试"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from tianlong.compintel import (
    CompIntelTracker, CompetitorProfile, IntelEvent,
    IntelReport, DataSource, KNOWN_SOURCES,
)
from tianlong.compintel.sources import get_sources_by_category, get_enabled_sources


class TestDataSources:
    def test_known_sources_count(self):
        assert len(KNOWN_SOURCES) == 18

    def test_get_by_category(self):
        funding = get_sources_by_category("funding")
        assert len(funding) >= 4
        assert all(s.category == "funding" for s in funding)

    def test_get_enabled(self):
        enabled = get_enabled_sources()
        assert len(enabled) <= len(KNOWN_SOURCES)

    def test_source_to_dict(self):
        s = KNOWN_SOURCES[0]
        d = s.to_dict()
        assert d["id"] == s.id
        assert d["name"] == s.name
        assert d["category"] == s.category


class TestCompetitorProfile:
    def test_defaults(self):
        cp = CompetitorProfile(id="test", name="TestCorp")
        assert cp.activity_score == 0.0
        assert cp.risk_score == 0.0

    def test_brief(self):
        cp = CompetitorProfile(id="t1", name="ACME", activity_score=75.0, risk_score=60.0)
        assert "ACME" in cp.brief
        assert "75" in cp.brief


class TestIntelEvent:
    def test_defaults(self):
        ev = IntelEvent(id="e1", title="Test")
        assert ev.impact_score == 0.0

    def test_to_dict(self):
        ev = IntelEvent(id="e1", competitor_id="c1", title="Funding", impact_score=0.8)
        d = ev.to_dict()
        assert d["id"] == "e1"
        assert d["title"] == "Funding"
        assert d["impact_score"] == 0.8


class TestCompIntelTracker:
    def test_init_defaults(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        assert len(tracker.competitors) == 4
        names = [c.name for c in tracker.competitors]
        assert "LangChain" in names
        assert "Hugging Face" in names

    def test_get_competitor(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        c = tracker.get_competitor("comp-langchain")
        assert c is not None
        assert c.name == "LangChain"

    def test_add_competitor(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        cp = tracker.add_competitor("NewCo", url="https://newco.ai")
        assert cp.id == "comp-newco"
        assert cp.name == "NewCo"
        # 验证持久化
        tracker2 = CompIntelTracker(project_dir=str(tmp_path))
        names = [c.name for c in tracker2.competitors]
        assert "NewCo" in names

    def test_remove_competitor(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        ok = tracker.remove_competitor("comp-langchain")
        assert ok
        assert tracker.get_competitor("comp-langchain") is None

    def test_update_competitor(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        c = tracker.update_competitor("comp-langchain", description="Updated desc")
        assert c is not None
        assert c.description == "Updated desc"

    def test_sync(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        new_count = tracker.sync()
        assert new_count >= 0
        assert tracker.summary()["total_events"] >= 0

    def test_sync_real_no_crash(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        new_count = tracker.sync()
        assert new_count >= 0

    def test_summary(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        s = tracker.summary()
        assert s["total_competitors"] == 4
        assert "total_events" in s
        assert "high_risk_count" in s

    def test_to_dict(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        d = tracker.to_dict()
        assert "competitors" in d
        assert "events" in d
        assert "summary" in d


class TestIntelReport:
    def test_markdown(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        report = IntelReport(tracker=tracker)
        md = report.to_markdown()
        assert "竞品情报报告" in md
        assert "LangChain" in md
        assert "CrewAI" in md

    def test_html(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        report = IntelReport(tracker=tracker)
        html = report.to_html()
        assert "竞品情报报告" in html
        assert "<div class=" in html

    def test_save_report(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        report = IntelReport(tracker=tracker)
        fpath = report.save_report(output_dir=str(tmp_path), fmt="html")
        assert Path(fpath).exists()
        content = Path(fpath).read_text()
        assert "竞品情报报告" in content

    def test_save_markdown(self, tmp_path):
        tracker = CompIntelTracker(project_dir=str(tmp_path))
        report = IntelReport(tracker=tracker)
        fpath = report.save_report(output_dir=str(tmp_path), fmt="markdown")
        assert fpath.endswith(".md")
        assert Path(fpath).exists()


class TestCLI:
    def test_list(self, tmp_path, capsys):
        from tianlong.compintel.cli import main
        rc = main(["--project-dir", str(tmp_path), "list"])
        assert rc == 0
        captured = capsys.readouterr()
        assert "LangChain" in captured.out

    def test_add_cli(self, tmp_path, capsys):
        from tianlong.compintel.cli import main
        rc = main(["--project-dir", str(tmp_path), "add", "TestAI"])
        assert rc == 0
        captured = capsys.readouterr()
        assert "TestAI" in captured.out

    def test_sync_cli(self, tmp_path, capsys, monkeypatch):
        monkeypatch.setenv("TIANLONG_ENTERPRISE", "1")
        from tianlong.compintel.cli import main
        rc = main(["--project-dir", str(tmp_path), "sync"])
        assert rc == 0
        captured = capsys.readouterr()
        assert "采集完成" in captured.out

    def test_remove_cli(self, tmp_path, capsys):
        from tianlong.compintel.cli import main
        rc = main(["--project-dir", str(tmp_path), "remove", "comp-crewai"])
        assert rc == 0

    def test_report_cli(self, tmp_path, capsys):
        from tianlong.compintel.cli import main
        rc = main(["--project-dir", str(tmp_path), "report", "--format", "markdown"])
        assert rc == 0
        captured = capsys.readouterr()
        assert "竞品情报报告" in captured.out
