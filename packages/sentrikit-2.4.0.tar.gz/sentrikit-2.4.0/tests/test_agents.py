"""tianlong.agents + metacog + onlinestate — 测试"""

from __future__ import annotations

import pytest

from tianlong.agents import build_goal, get_config, AgentConfig


class TestAgents:
    def test_build_research_goal(self):
        g = build_goal("research_agent", "搜索AI安全")
        assert "Research Agent" in g
        assert "搜索AI安全" in g

    def test_build_code_goal(self):
        g = build_goal("code_agent", "实现API")
        assert "Code Agent" in g
        assert "实现API" in g

    def test_build_goal_with_context(self):
        g = build_goal("research_agent", "调研", "关注中国市场")
        assert "上下文" in g
        assert "中国市场" in g

    def test_build_unknown_role(self):
        g = build_goal("unknown", "任务")
        assert "任务" in g

    def test_get_config(self):
        cfg = get_config("research_agent")
        assert isinstance(cfg, AgentConfig)
        assert cfg.role == "research_agent"

    def test_get_config_fallback(self):
        cfg = get_config("nonexistent")
        assert cfg.role == "research_agent"  # fallback

    def test_research_default_tools(self):
        cfg = get_config("research_agent")
        assert "web" in cfg.default_toolsets
        assert "search" in cfg.default_toolsets

    def test_monitor_config(self):
        cfg = get_config("monitor_agent")
        assert cfg.role == "monitor_agent"
        assert cfg.max_iterations == 15


from tianlong.metacog import MetaCogTrigger, TriggerLevel


class TestMetaCog:
    def test_no_triggers(self):
        mc = MetaCogTrigger()
        report = mc.evaluate(success_rate_7d=0.95, success_rate_3d=0.90,
                              success_rate_1d=1.0, days_since_last_improvement=0)
        assert not report.should_evolve

    def test_critical_success_rate(self):
        mc = MetaCogTrigger()
        report = mc.evaluate(success_rate_7d=0.80, success_rate_3d=0.60,
                              success_rate_1d=0.30)
        assert report.should_evolve
        assert report.max_level == "critical"

    def test_moderate_success_rate(self):
        mc = MetaCogTrigger()
        report = mc.evaluate(success_rate_7d=0.80, success_rate_3d=0.65,
                              success_rate_1d=0.90)
        assert report.should_evolve
        # 3天65%<70% → moderate, 7天80%<85% → mild, 最高=moderate
        assert report.max_level in ("moderate", "mild")

    def test_stagnation_triggers(self):
        mc = MetaCogTrigger()
        report = mc.evaluate(days_since_last_improvement=10)
        assert report.should_evolve

    def test_stagnation_mild(self):
        mc = MetaCogTrigger()
        report = mc.evaluate(days_since_last_improvement=4)
        # 4天停滞轻度，但整体权重较低，should_evolve取决于阈值
        assert report.triggers[1].triggered  # 停滞信号触发
        assert report.triggers[1].level == TriggerLevel.MILD

    def test_repeat_failure_critical(self):
        mc = MetaCogTrigger()
        report = mc.evaluate(repeat_error_count=5)
        assert report.should_evolve
        assert report.max_level == "critical"

    def test_introspection_triggers_at_7_days(self):
        mc = MetaCogTrigger()
        report = mc.evaluate(days_since_last_improvement=7)
        assert report.should_evolve

    def test_summary_line_no_trigger(self):
        mc = MetaCogTrigger()
        report = mc.evaluate()
        assert "无触发" in report.summary_line

    def test_history(self):
        mc = MetaCogTrigger()
        mc.evaluate(success_rate_7d=0.90)
        mc.evaluate(success_rate_7d=0.50)
        history = mc.get_history()
        assert len(history) == 2

    def test_to_dict(self):
        mc = MetaCogTrigger()
        report = mc.evaluate(success_rate_7d=0.50)
        d = report.to_dict()
        assert "should_evolve" in d
        assert "overall_score" in d


from tianlong.onlinestate import OnlineState


class TestOnlineState:
    def test_default_online(self):
        state = OnlineState()
        assert state.is_online

    def test_set_offline(self, tmp_path):
        state = OnlineState(project_dir=tmp_path)
        state.set_offline("维护中")
        assert not state.is_online

    def test_set_online(self, tmp_path):
        state = OnlineState(project_dir=tmp_path)
        state.set_offline("维护")
        state.set_online("恢复")
        assert state.is_online

    def test_read_state(self, tmp_path):
        state = OnlineState(project_dir=tmp_path)
        state.set_online("启动完成")
        snap = state.read()
        assert snap.status == "online"

    def test_read_nonexistent(self, tmp_path):
        state = OnlineState(project_dir=tmp_path)
        snap = state.read()
        assert snap.status == "unknown"

    def test_snapshot(self, tmp_path):
        state = OnlineState(project_dir=tmp_path)
        state.set_online("系统就绪")
        s = state.snapshot()
        assert s["is_online"] is True
        assert s["status"] == "online"
