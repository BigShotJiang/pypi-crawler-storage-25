"""tianlong.evolution — 测试

注意：tianlong.evolution.memory 是企业版闭源包，未安装时跳过相关测试。
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from datetime import date, timedelta

import pytest

try:
    from tianlong.evolution import (
        TaskResult, TaskStatus, LearnContext,
        AnalyzeOutput, EvolveOutput, EvolutionReport,
        EvolutionProposal, SuccessPattern,
        FailureMiningResult, FailureType,
        GEPAResult, GEPAMutationType,
        SkillLifecycleEntry, SkillStatus,
        RalphLoopState, RalphLoopAction,
        ProposalSource,
        Learner, Analyzer, GEPAEngine,
        Evolver, Propagator, RalphLoop,
        MemoryWriter, MemoryAction, MemoryEntry,
    )
    from tianlong.evolution.memory import ExtractionResult, AnalysisResult
    from tianlong.evolution import _HAS_EVOLUTION as _TEMP_EVO
    HAS_EVOLUTION = _TEMP_EVO
except ImportError:
    HAS_EVOLUTION = False
    pytest.skip("tianlong.evolution 未安装（企业版闭源包），跳过测试", allow_module_level=True)


# ═══════════════════════════════════════════════════════
# 类型测试
# ═══════════════════════════════════════════════════════


class TestTaskResult:
    def test_defaults(self):
        r = TaskResult()
        assert r.status == TaskStatus.SUCCESS

    def test_failure(self):
        r = TaskResult(task_id="t001", status=TaskStatus.FAILURE,
                       error_message="出错了")
        assert r.error_message == "出错了"


class TestLearnContext:
    def test_empty(self):
        ctx = LearnContext()
        assert ctx.is_empty

    def test_non_empty(self):
        ctx = LearnContext(semantic_entries=[{"title": "test"}])
        assert not ctx.is_empty


class TestSuccessPattern:
    def test_to_entry(self):
        sp = SuccessPattern(trigger="用户提问", action="搜索", outcome="答案准确")
        entry = sp.to_entry()
        assert entry["trigger"] == "用户提问"
        assert entry["match_count"] == 1


class TestFailureType:
    def test_all_types(self):
        assert len(FailureType) == 4
        assert FailureType.CAPABILITY_GAP.value == "capability_gap"
        assert FailureType.EXECUTION_ERROR.value == "execution_error"

    def test_failure_actions(self):
        from tianlong.evolution.types import FAILURE_ACTIONS
        assert FAILURE_ACTIONS[FailureType.CAPABILITY_GAP] == "生成新流程提案"
        assert FAILURE_ACTIONS[FailureType.EXECUTION_ERROR] == "细化步骤+增加预检"


class TestEvolutionProposal:
    def test_defaults(self):
        p = EvolutionProposal()
        assert p.change_type == "create"
        assert p.safety_allowed is True
        assert not p.executed

    def test_custom(self):
        p = EvolutionProposal(
            id="p001", summary="优化搜索", change_type="update",
            source=ProposalSource.FAILURE_MINING.value,
        )
        assert p.source == "failure_mining"


class TestRalphLoopState:
    def test_defaults(self):
        s = RalphLoopState()
        assert s.iteration == 1
        assert s.max_iterations == 3
        assert s.action == RalphLoopAction.CONTINUE


class TestSkillStatus:
    def test_cycle(self):
        from tianlong.evolution.types import SKILL_STATUS_CYCLE
        assert SKILL_STATUS_CYCLE[SkillStatus.ACTIVE] == SkillStatus.PENDING
        assert SKILL_STATUS_CYCLE[SkillStatus.DEPRECATED] == SkillStatus.ARCHIVED

    def test_reverse(self):
        from tianlong.evolution.types import SKILL_STATUS_REVERSE
        assert SKILL_STATUS_REVERSE[SkillStatus.PENDING] == SkillStatus.ACTIVE


class TestGEPAResult:
    def test_total_score(self):
        r = GEPAResult(
            mutation_type=GEPAMutationType.PARAMETER_TUNE,
            safety_score=1.0, efficiency_score=1.0,
            robustness_score=1.0, practicality_score=1.0,
        )
        assert r.total_score == 1.0  # 1.0*0.3 + 1.0*0.2 + 1.0*0.3 + 1.0*0.2

    def test_total_score_partial(self):
        r = GEPAResult(
            mutation_type=GEPAMutationType.STEP_SPLIT,
            safety_score=0.8, efficiency_score=0.3,
            robustness_score=0.8, practicality_score=0.6,
        )
        # 0.8*0.3 + 0.3*0.2 + 0.8*0.3 + 0.6*0.2
        expected = 0.24 + 0.06 + 0.24 + 0.12
        assert r.total_score == pytest.approx(expected)


class TestEvolutionReport:
    def test_defaults(self):
        r = EvolutionReport()
        assert r.timestamp
        assert not r.completed

    def test_summary_line(self):
        r = EvolutionReport(completed=True)
        assert "完成: True" in r.summary_line

    def test_summary_line_with_evolve(self):
        evolve = EvolveOutput(
            approved_proposals=[EvolutionProposal(id="p1")],
            rejected_proposals=[EvolutionProposal(id="p2")],
            degradation_warnings=["test warning"],
        )
        r = EvolutionReport(evolve_output=evolve, completed=True)
        assert "通过: 1" in r.summary_line
        assert "拒绝: 1" in r.summary_line
        assert "退化警告: 1" in r.summary_line

    def test_to_dict(self):
        r = EvolutionReport(completed=True)
        d = r.to_dict()
        assert d["completed"] is True
        assert "timestamp" in d

    def test_to_json(self):
        r = EvolutionReport(completed=True)
        data = json.loads(r.to_json())
        assert data["completed"] is True


# ═══════════════════════════════════════════════════════
# Learner 测试
# ═══════════════════════════════════════════════════════


def _make_memory_files(tmp_path: Path, files: dict[str, str]) -> Path:
    """在 tmp_path 下创建模拟的记忆文件。"""
    for relpath, content in files.items():
        fp = tmp_path / relpath
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content, encoding="utf-8")
    return tmp_path


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestLearner:
    def test_learn_no_files(self, tmp_path):
        """无文件时返回空上下文。"""
        learner = Learner(project_dir=tmp_path)
        ctx = learner.learn()
        assert ctx.is_empty

    def test_learn_semantic_memory(self, tmp_path):
        _make_memory_files(tmp_path, {
            "brain/semantic-memory.md": "## 知识1\n内容1\n## 知识2\n内容2\n",
        })
        learner = Learner(project_dir=tmp_path)
        ctx = learner.learn()
        assert len(ctx.semantic_entries) == 2
        assert ctx.semantic_entries[0]["title"] == "知识1"
        assert ctx.semantic_entries[1]["body"] == "内容2"

    def test_learn_all_memories(self, tmp_path):
        _make_memory_files(tmp_path, {
            "brain/semantic-memory.md": "## 洞察A\nAAA",
            "brain/procedural-memory.md": "## P1: 搜索流程\n步骤...",
            "brain/error-log.md": "## 2026-04-27\n错误描述",
            "brain/working-memory.md": "## T120: 测试\n- 完成时间: 2026-04-27\n## T121: 另一个\n- 完成时间: 2026-04-27",
            "brain/safety-guard.md": "R1. 删除需确认\nR2. 不泄露数据\n",
        })
        learner = Learner(project_dir=tmp_path)
        ctx = learner.learn()
        assert len(ctx.semantic_entries) == 1
        assert len(ctx.procedural_entries) >= 1
        assert len(ctx.error_log_entries) == 1
        assert len(ctx.safety_rules) == 2
        assert "R1." in ctx.safety_rules[0]

    def test_learn_working_memory_limit(self, tmp_path):
        content = "\n".join([
            f"## T{i}: 任务{i}\n- 完成时间: 2026-04-{i:02d}\n"
            for i in range(20, 30)
        ])
        _make_memory_files(tmp_path, {"brain/working-memory.md": content})
        learner = Learner(project_dir=tmp_path, working_memory_limit=2)
        ctx = learner.learn()
        assert len(ctx.working_memory_entries) == 2

    def test_markdown_parser(self):
        sections = Learner._parse_markdown_sections(
            "## Title1\nbody1\n## Title2\nbody2\nmore\n"
        )
        assert len(sections) == 2
        assert sections[0]["title"] == "Title1"
        assert sections[0]["body"] == "body1"
        assert sections[1]["body"] == "body2\nmore"

    def test_extract_lifecycle_table(self):
        content = """## 生命周期表
| Process | Status | UseCount |
|---------|--------|----------|
| P1 | active | 5 |
| P2 | pending | 0 |
"""
        table = Learner._extract_lifecycle_table(content)
        assert "active" in table
        assert "pending" in table

    def test_extract_no_table(self):
        content = "## 其他内容\n没有表格\n"
        table = Learner._extract_lifecycle_table(content)
        assert table == ""


# ═══════════════════════════════════════════════════════
# Analyzer 测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestAnalyzer:
    def test_analyze_success_task(self):
        """成功任务应产生成功模式和洞察。"""
        analyzer = Analyzer()
        task = TaskResult(task_id="t001", status=TaskStatus.SUCCESS,
                          summary="搜索优化", steps_taken=3)
        ctx = LearnContext()
        output = analyzer.analyze(task, ctx)
        assert len(output.insights) >= 1
        assert len(output.success_patterns) == 1
        assert output.success_patterns[0].trigger == "搜索优化"

    def test_analyze_failure_task(self):
        """失败任务应产生提案。"""
        analyzer = Analyzer()
        task = TaskResult(task_id="t002", status=TaskStatus.FAILURE,
                          error_message="API超时", target="search.py")
        ctx = LearnContext()
        output = analyzer.analyze(task, ctx)
        assert len(output.proposals) >= 1
        assert "API超时" in output.proposals[0].description

    def test_analyze_partial_task(self):
        analyzer = Analyzer()
        task = TaskResult(task_id="t003", status=TaskStatus.PARTIAL)
        ctx = LearnContext()
        output = analyzer.analyze(task, ctx)
        assert "部分成功" in output.insights[0]

    def test_failure_mining_no_errors(self):
        """无错误日志时不应产生挖掘结果。"""
        analyzer = Analyzer()
        task = TaskResult()
        ctx = LearnContext()
        output = analyzer.analyze(task, ctx)
        assert len(output.failure_minings) == 0

    def test_failure_mining_with_errors(self, tmp_path):
        """有错误日志时应进行失败挖掘。"""
        analyzer = Analyzer()
        task = TaskResult()
        ctx = LearnContext(
            error_log_entries=[
                {"title": "API Timeout", "body": "连接超时"},
                {"title": "Module Not Found", "body": "找不到模块"},
            ]
        )
        output = analyzer.analyze(task, ctx)
        assert len(output.failure_minings) >= 1

    def test_failure_classify_capability(self):
        assert Analyzer._classify_failure("ModuleNotFoundError: No module named 'xxx'", "") == FailureType.CAPABILITY_GAP
        assert Analyzer._classify_failure("not found: file.txt", "") == FailureType.CAPABILITY_GAP

    def test_failure_classify_dependency(self):
        assert Analyzer._classify_failure("Connection refused", "") == FailureType.DEPENDENCY_FAILURE
        assert Analyzer._classify_failure("timeout after 30s", "") == FailureType.DEPENDENCY_FAILURE

    def test_failure_classify_execution(self):
        assert Analyzer._classify_failure("Traceback (most recent call last)", "") == FailureType.EXECUTION_ERROR
        assert Analyzer._classify_failure("TypeError: unexpected", "") == FailureType.EXECUTION_ERROR

    def test_failure_classify_scene(self):
        assert Analyzer._classify_failure("Unexpected input format", "") == FailureType.SCENE_MISMATCH
        assert Analyzer._classify_failure("invalid input", "") == FailureType.SCENE_MISMATCH

    def test_causal_analysis_triggers_on_repeated(self):
        analyzer = Analyzer()
        task = TaskResult()
        ctx = LearnContext(error_log_entries=[
            {"title": "Err", "body": "重复错误"},
            {"title": "Err", "body": "重复错误"},
        ])
        output = analyzer.analyze(task, ctx)
        # 应该有重复失败生成的提案
        repeated_proposals = [p for p in output.proposals if "重复" in p.summary]
        assert len(repeated_proposals) >= 0  # 可能没有，取决于具体实现

    def test_analyze_captures_success_pattern(self):
        """成功轨迹捕获应该生成三元组。"""
        analyzer = Analyzer()
        task = TaskResult(task_id="t001", status=TaskStatus.SUCCESS,
                          summary="新增知识库", steps_taken=5)
        ctx = LearnContext()
        output = analyzer.analyze(task, ctx)
        assert len(output.success_patterns) == 1
        sp = output.success_patterns[0]
        assert sp.trigger
        assert sp.action
        assert sp.outcome
        assert sp.match_count == 1


# ═══════════════════════════════════════════════════════
# GEPA 测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestGEPAEngine:
    def test_run_empty(self):
        gepa = GEPAEngine(random_seed=42)
        output = AnalyzeOutput()
        results = gepa.run(output)
        assert len(results) == 0

    def test_run_with_proposals(self):
        gepa = GEPAEngine(random_seed=42)
        output = AnalyzeOutput(
            proposals=[
                EvolutionProposal(summary="修复API超时", description="connection error"),
                EvolutionProposal(summary="新增搜索功能", description="missing tool"),
            ]
        )
        results = gepa.run(output)
        assert len(results) == 2

    def test_mutation_type_selection_dependency(self):
        gepa = GEPAEngine()
        p = EvolutionProposal(summary="网络超时", description="API connection failed")
        mt = gepa._select_mutation(p)
        assert mt == GEPAMutationType.DEGRADE_CHAIN

    def test_mutation_type_selection_execution(self):
        gepa = GEPAEngine()
        p = EvolutionProposal(summary="程序崩溃", description="Traceback exception")
        mt = gepa._select_mutation(p)
        assert mt == GEPAMutationType.STEP_SPLIT

    def test_mutation_type_selection_capability(self):
        gepa = GEPAEngine()
        p = EvolutionProposal(summary="缺少文件", description="not found missing")
        mt = gepa._select_mutation(p)
        assert mt == GEPAMutationType.TOOL_REPLACE

    def test_mutation_type_selection_scene(self):
        gepa = GEPAEngine()
        p = EvolutionProposal(summary="场景不适用", description="invalid input")
        mt = gepa._select_mutation(p)
        assert mt == GEPAMutationType.BOUNDARY_TIGHTEN

    def test_mutation_type_default(self):
        gepa = GEPAEngine()
        p = EvolutionProposal(summary="普通优化", description="常规改进")
        mt = gepa._select_mutation(p)
        assert mt == GEPAMutationType.PARAMETER_TUNE

    def test_gepa_result_passed(self):
        gepa = GEPAEngine(random_seed=42)
        p = EvolutionProposal(summary="测试", description="修正API超时问题")
        result = gepa._mutate(p, GEPAMutationType.DEGRADE_CHAIN)
        assert result.total_score > 0
        if result.passed:
            assert result.proposal is not None
            assert "GEPA" in result.proposal.summary

    def test_gepa_parameter_tune_score(self):
        gepa = GEPAEngine(random_seed=0)
        p = EvolutionProposal(summary="测试")
        result = gepa._mutate(p, GEPAMutationType.PARAMETER_TUNE)
        assert 0 <= result.safety_score <= 1
        assert 0 <= result.total_score <= 1


# ═══════════════════════════════════════════════════════
# Evolver 测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestEvolver:
    def test_evolve_empty(self):
        evolver = Evolver()
        output = AnalyzeOutput()
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 0
        assert len(result.rejected_proposals) == 0

    def test_evolve_with_create_proposal(self):
        evolver = Evolver()
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="新增知识", change_type="create")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 1
        assert result.approved_proposals[0].safety_allowed

    def test_evolve_block_delete(self):
        evolver = Evolver()
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="删除文件", change_type="delete")]
        )
        result = evolver.evolve(output)
        assert len(result.rejected_proposals) == 1

    def test_evolve_block_immutable(self):
        evolver = Evolver()
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(
                summary="修改安全规则", change_type="update",
                target="safety-guard.md",
            )]
        )
        result = evolver.evolve(output)
        assert len(result.rejected_proposals) == 1

    def test_degradation_detection_high_reject(self):
        evolver = Evolver()
        output = AnalyzeOutput(
            proposals=[
                EvolutionProposal(summary="p1", change_type="delete"),
                EvolutionProposal(summary="p2", change_type="delete"),
                EvolutionProposal(summary="p3", change_type="delete"),
            ]
        )
        result = evolver.evolve(output)
        # 全部拒绝，应该触发退化警告
        assert len(result.degradation_warnings) >= 1

    def test_degradation_all_rejected(self):
        evolver = Evolver()
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="删除", change_type="delete")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 0
        assert len(result.rejected_proposals) == 1

    def test_lifecycle_audit_active_to_pending(self):
        evolver = Evolver()
        old_date = (date.today() - timedelta(days=30)).strftime("%Y-%m-%d")
        entries = [
            SkillLifecycleEntry(
                process_id="P1", name="搜索流程",
                status=SkillStatus.ACTIVE, use_count=0,
                fail_count=0, last_used=old_date,
            )
        ]
        changes = evolver.audit_lifecycle(entries)
        assert len(changes) == 1
        assert changes[0][1] == SkillStatus.PENDING
        assert "天未使用" in changes[0][2]

    def test_lifecycle_audit_active_to_pending_by_fails(self):
        evolver = Evolver()
        entries = [
            SkillLifecycleEntry(
                process_id="P2", name="失败流程",
                status=SkillStatus.ACTIVE, use_count=5,
                fail_count=4, last_used=date.today().strftime("%Y-%m-%d"),
            )
        ]
        changes = evolver.audit_lifecycle(entries)
        assert len(changes) == 1
        assert changes[0][1] == SkillStatus.PENDING

    def test_lifecycle_audit_healthy_active(self):
        evolver = Evolver()
        today = date.today().strftime("%Y-%m-%d")
        entries = [
            SkillLifecycleEntry(
                process_id="P3", name="健康流程",
                status=SkillStatus.ACTIVE, use_count=10,
                fail_count=0, last_used=today,
            )
        ]
        changes = evolver.audit_lifecycle(entries)
        assert len(changes) == 0

    def test_lifecycle_audit_pending_to_active(self):
        evolver = Evolver()
        today = date.today().strftime("%Y-%m-%d")
        entries = [
            SkillLifecycleEntry(
                process_id="P4", name="复活流程",
                status=SkillStatus.PENDING, use_count=1,
                fail_count=0, last_used=today,
            )
        ]
        changes = evolver.audit_lifecycle(entries)
        assert len(changes) == 1
        assert changes[0][1] == SkillStatus.ACTIVE

    def test_decay_failures(self):
        evolver = Evolver()
        entries = [
            SkillLifecycleEntry(
                process_id="P1", status=SkillStatus.ACTIVE, fail_count=3,
            ),
            SkillLifecycleEntry(
                process_id="P2", status=SkillStatus.ACTIVE, fail_count=0,
            ),
            SkillLifecycleEntry(
                process_id="P3", status=SkillStatus.PENDING, fail_count=5,
            ),
        ]
        decayed = evolver.decay_failures(entries)
        assert decayed[0].fail_count == 2  # 3-1
        assert decayed[1].fail_count == 0  # 不变
        assert decayed[2].fail_count == 5  # pending 不衰减

    def test_integrated_safety(self):
        """集成 tianlong.safety 的完整流程。"""
        from tianlong.safety import SafetyGuard, ChangeType
        from tianlong.safety.rules import DEFAULT_RULES
        guard = SafetyGuard(rules=list(DEFAULT_RULES))
        evolver = Evolver(safety_guard=guard)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="创建流程", change_type="create")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) >= 1

    def test_integrated_safety_block_delete(self):
        from tianlong.safety import SafetyGuard
        from tianlong.safety.rules import DEFAULT_RULES
        guard = SafetyGuard(rules=list(DEFAULT_RULES))
        evolver = Evolver(safety_guard=guard)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="删除配置", change_type="delete",
                                         target="config.yaml")]
        )
        result = evolver.evolve(output)
        assert len(result.rejected_proposals) >= 1


# ═══════════════════════════════════════════════════════
# 进化授权级别 测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestAuthLevel:
    def test_level0_no_auth(self):
        """Level 0: 所有提案不执行。"""
        evolver = Evolver(auth_level=0)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="新增知识", change_type="create")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 0
        assert len(result.rejected_proposals) >= 1

    def test_level1_auto_create(self):
        """Level 1: 🟢新增自动执行。"""
        evolver = Evolver(auth_level=1)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="新增知识", change_type="create")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 1
        assert "Level 1" in result.approved_proposals[0].safety_reason

    def test_level1_blocks_update(self):
        """Level 1: 🟡修改不自动执行。"""
        evolver = Evolver(auth_level=1)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="修改流程", change_type="update",
                                         grade="A")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 0

    def test_level2_auto_update_grade_a(self):
        """Level 2: 🟡修改自动执行（Judge=A级）。"""
        evolver = Evolver(auth_level=2)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="修改流程", change_type="update",
                                         grade="A", target="procedural-memory.md")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 1
        assert "Level 2" in result.approved_proposals[0].safety_reason

    def test_level2_auto_update_grade_s(self):
        """Level 2: 🟡修改自动执行（Judge=S级）。"""
        evolver = Evolver(auth_level=2)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="优化流程", change_type="update",
                                         grade="S")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 1

    def test_level2_blocks_grade_b(self):
        """Level 2: Judge=B级的修改不执行。"""
        evolver = Evolver(auth_level=2)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="一般修改", change_type="update",
                                         grade="B")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 0

    def test_level2_blocks_immutable(self):
        """Level 2: 不可变文件不执行。"""
        evolver = Evolver(auth_level=2)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="修改安全规则", change_type="update",
                                         grade="S", target="safety-guard.md")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 0

    def test_level2_blocks_evolution_auth(self):
        """Level 2: evolution-authorization 自身不可修改。"""
        evolver = Evolver(auth_level=2)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="修改授权", change_type="update",
                                         grade="A", target="evolution-authorization.md")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 0

    def test_level3_auto_config_s(self):
        """Level 3: 🟠配置修改在Judge=S时执行。"""
        evolver = Evolver(auth_level=3)
        output = AnalyzeOutput(
            proposals=[EvolutionProposal(summary="修改配置", change_type="config",
                                         grade="S")]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 1
        assert "Level 3" in result.approved_proposals[0].safety_reason

    def test_level2_auto_create_and_update(self):
        """Level 2: 同时有新增和修改应都自动执行。"""
        evolver = Evolver(auth_level=2)
        output = AnalyzeOutput(
            proposals=[
                EvolutionProposal(summary="新增知识", change_type="create"),
                EvolutionProposal(summary="修改流程", change_type="update",
                                 grade="A", target="procedural.md"),
            ]
        )
        result = evolver.evolve(output)
        assert len(result.approved_proposals) == 2

    def test_default_auth_level(self):
        """默认 auth_level=1（向后兼容）。"""
        evolver = Evolver()
        assert evolver.auth_level == 1


# ═══════════════════════════════════════════════════════
# Propagator 测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestPropagator:
    def test_identify_no_changes(self):
        propagator = Propagator()
        evolve = EvolveOutput()
        targets = propagator.identify(evolve)
        assert targets == []

    def test_identify_with_proposals(self):
        propagator = Propagator()
        evolve = EvolveOutput(
            approved_proposals=[
                EvolutionProposal(summary="更新流程", target="procedural-memory.md"),
            ]
        )
        targets = propagator.identify(evolve)
        assert "working-memory" in targets
        assert "semantic-memory" in targets

    def test_identify_no_deps(self):
        propagator = Propagator()
        evolve = EvolveOutput(
            approved_proposals=[
                EvolutionProposal(summary="更新日志", target="error-log"),
            ]
        )
        targets = propagator.identify(evolve)
        assert targets == []

    def test_generate_propagate_proposals(self):
        propagator = Propagator()
        evolve = EvolveOutput(
            approved_proposals=[
                EvolutionProposal(summary="P1更新", target="procedural-memory.md"),
            ]
        )
        proposals = propagator.generate_propagate_proposals(evolve)
        assert len(proposals) == 2  # working-memory + semantic-memory

    def test_notification_summary(self):
        propagator = Propagator()
        evolve = EvolveOutput(
            approved_proposals=[EvolutionProposal(id="p1", summary="创建")],
            rejected_proposals=[EvolutionProposal(id="p2", summary="删除",
                                                   safety_reason="禁止删除")],
            degradation_warnings=["退化警告"],
            lifecycle_changes=[("P1", SkillStatus.ACTIVE, SkillStatus.PENDING)],
        )
        summary = propagator.get_notification_summary(evolve)
        assert "1 个提案通过" in summary
        assert "1 个提案被阻止" in summary
        assert "退化警告" in summary
        assert "1 个技能状态变更" in summary


# ═══════════════════════════════════════════════════════
# RalphLoop 测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestRalphLoop:
    def test_run_no_task(self):
        """无任务时也能运行（无错误日志时不会产生提案，会escalate）。"""
        loop = RalphLoop()
        report = loop.run()
        assert report.task_result is not None
        assert report.learn_context is not None
        assert report.analyze_output is not None
        assert report.evolve_output is not None
        assert report.ralph_loop is not None

    def test_run_with_task(self):
        """有成功任务时运行。"""
        loop = RalphLoop()
        task = TaskResult(task_id="t001", status=TaskStatus.SUCCESS,
                          summary="测试优化", steps_taken=3)
        report = loop.run(task)
        assert report.task_result.task_id == "t001"
        assert report.ralph_loop is not None

    def test_run_produces_report(self):
        loop = RalphLoop()
        report = loop.run()
        assert isinstance(report, EvolutionReport)
        assert report.learn_context is not None
        assert report.analyze_output is not None
        assert report.evolve_output is not None
        assert report.ralph_loop is not None

    def test_stophook_continues_on_empty(self):
        loop = RalphLoop()
        state = RalphLoopState(iteration=1)
        report = EvolutionReport(
            evolve_output=EvolveOutput(),
        )
        result = loop._stophook(state, report)
        # 空输出应该有停止原因，但还没到max_iterations，所以continue
        assert result.action == RalphLoopAction.CONTINUE

    def test_stophook_escalates_after_max(self):
        loop = RalphLoop()
        state = RalphLoopState(iteration=3, max_iterations=3)
        report = EvolutionReport(
            evolve_output=EvolveOutput(),
        )
        result = loop._stophook(state, report)
        assert result.action == RalphLoopAction.ESCALATE

    def test_full_loop_with_task(self):
        """完整的 Ralph Loop 执行一次。"""
        loop = RalphLoop()
        task = TaskResult(
            task_id="t001",
            status=TaskStatus.SUCCESS,
            summary="优化搜索流程",
            steps_taken=3,
        )
        report = loop.run(task)
        assert report.task_result.status == TaskStatus.SUCCESS
        assert report.ralph_loop is not None


# ═══════════════════════════════════════════════════════
# 集成测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestIntegration:
    def test_learn_to_evolve_workflow(self, tmp_path):
        """完整的 LEARN → ANALYZE → EVOLVE 集成测试。"""
        # 创建模拟记忆文件
        _make_memory_files(tmp_path, {
            "brain/semantic-memory.md": "## 洞察1\n已有知识",
            "brain/procedural-memory.md": "## P1: 搜索\n步骤1\n## P2: 分析\n步骤2",
            "brain/error-log.md": "## 2026-04-27\n网络超时",
            "brain/working-memory.md": "## T120: 测试\n- 完成时间: 2026-04-27\n",
            "brain/safety-guard.md": "R1. 删除需确认\n",
        })

        # Phase 1
        learner = Learner(project_dir=tmp_path)
        ctx = learner.learn()
        assert not ctx.is_empty
        assert len(ctx.semantic_entries) == 1
        assert len(ctx.safety_rules) == 1

        # Phase 2
        analyzer = Analyzer()
        task = TaskResult(task_id="t100", status=TaskStatus.SUCCESS,
                          summary="集成测试", steps_taken=2)
        analyze_out = analyzer.analyze(task, ctx)
        assert len(analyze_out.success_patterns) >= 1

        # Phase 3
        evolver = Evolver()
        evolve_out = evolver.evolve(analyze_out)

        # 应该有至少1个提案通过
        total = len(evolve_out.approved_proposals) + len(evolve_out.rejected_proposals)
        assert total >= 1

        # Phase 4
        propagator = Propagator()
        targets = propagator.identify(evolve_out)
        assert isinstance(targets, list)

    def test_ralph_loop_with_files(self, tmp_path):
        """带文件的完整 Ralph Loop。"""
        _make_memory_files(tmp_path, {
            "brain/semantic-memory.md": "## 洞察A\nAAA",
            "brain/procedural-memory.md": "## P1: 流程\n步骤",
            "brain/error-log.md": "## 错误\n连接超时",
            "brain/working-memory.md": "## T99: 任务\n- 完成时间: 2026-04-27\n",
            "brain/safety-guard.md": "R1. 删除需确认\n",
        })
        loop = RalphLoop(project_dir=str(tmp_path))
        task = TaskResult(task_id="integ-test", status=TaskStatus.SUCCESS,
                          summary="完整集成")
        report = loop.run(task)
        assert isinstance(report, EvolutionReport)
        assert report.completed


# ═══════════════════════════════════════════════════════
# MemorySystem 测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestMemoryWriter:
    def test_parse_sections(self):
        content = "## T1\n正文1\n## T2\n正文2\n"
        sections = MemoryWriter._parse_sections(content)
        assert len(sections) == 2
        assert sections[0]["title"] == "T1"
        assert sections[1]["body"] == "正文2"

    def test_extract_from_working_memory(self, tmp_path):
        wm = tmp_path / "brain" / "working-memory.md"
        wm.parent.mkdir(parents=True)
        wm.write_text("## T120: 测试任务\n- 完成时间: 2026-04-27\n- 结果: 成功\n")
        writer = MemoryWriter(project_dir=tmp_path)
        extraction = writer.extract_from_working_memory(limit=10)
        assert len(extraction.candidates) == 1
        assert extraction.candidates[0].title == "T120: 测试任务"

    def test_extract_from_text(self):
        writer = MemoryWriter()
        text = "## 知识A\nAAA\n## 知识B\nBBB\n"
        extraction = writer.extract_from_text(text, source="test")
        assert len(extraction.candidates) == 2
        assert extraction.source_file == "test"

    def test_similarity_identical(self):
        sim = MemoryWriter._compute_similarity("优化搜索流程", "优化搜索流程")
        assert sim >= 0.9

    def test_similarity_different(self):
        sim = MemoryWriter._compute_similarity("股票市场分析", "如何做蛋糕")
        assert sim < 0.3

    def test_similarity_partial(self):
        sim = MemoryWriter._compute_similarity("优化搜索流程", "优化算法")
        assert 0 < sim < 1

    def test_classify_add(self):
        writer = MemoryWriter()
        candidate = MemoryEntry(title="全新知识", body="从未出现过的内容")
        existing = [{"title": "已有知识", "body": "旧内容"}]
        decision = writer._classify(candidate, existing)
        assert decision.action == MemoryAction.ADD

    def test_classify_noop(self):
        writer = MemoryWriter()
        candidate = MemoryEntry(title="优化搜索", body="搜索流程优化步骤")
        existing = [{"title": "优化搜索", "body": "搜索流程优化步骤详解"}]
        decision = writer._classify(candidate, existing)
        assert decision.action == MemoryAction.NOOP

    def test_analyze_empty(self):
        writer = MemoryWriter()
        extraction = ExtractionResult(candidates=[])
        result = writer.analyze(extraction)
        assert result.add_count == 0
        assert result.noop_count == 0
        assert result.summary == "ADD 0, UPDATE 0, NOOP 0"

    def test_analyze_mixed(self):
        writer = MemoryWriter(project_dir=Path("/tmp/nonexistent"))
        extraction = ExtractionResult(candidates=[
            MemoryEntry(title="全新知识", body="全新内容"),
            MemoryEntry(title="重复知识", body="重复内容"),
        ])
        # 没有已有知识，两个都应该是 ADD
        result = writer.analyze(extraction)
        assert result.add_count == 2
        assert result.noop_count == 0

    def test_update_adds_new_entries(self, tmp_path):
        semantic = tmp_path / "brain" / "semantic-memory.md"
        semantic.parent.mkdir(parents=True)
        semantic.write_text("## 已有知识\n旧内容\n")

        writer = MemoryWriter(project_dir=tmp_path)
        extraction = ExtractionResult(candidates=[
            MemoryEntry(title="新知识1", body="内容1"),
            MemoryEntry(title="新知识2", body="内容2"),
        ])
        analysis = writer.analyze(extraction)
        result = writer.update(analysis)
        assert result["added"] == 2
        assert result["skipped"] == 0
        content = semantic.read_text()
        assert "新知识1" in content
        assert "新知识2" in content
        assert "已有知识" in content  # 原内容保留

    def test_update_skips_noop(self, tmp_path):
        semantic = tmp_path / "brain" / "semantic-memory.md"
        semantic.parent.mkdir(parents=True)
        semantic.write_text("## 重复标题\n重复内容\n")

        writer = MemoryWriter(project_dir=tmp_path)
        extraction = ExtractionResult(candidates=[
            MemoryEntry(title="重复标题", body="重复内容"),
        ])
        analysis = writer.analyze(extraction)
        result = writer.update(analysis)
        assert result["skipped"] >= 1
        assert result["added"] == 0

    def test_consolidate_no_candidates(self):
        writer = MemoryWriter()
        result = writer.consolidate(text="", source="test")
        assert result["action"] == "noop"

    def test_consolidate_with_text(self, tmp_path):
        semantic = tmp_path / "brain" / "semantic-memory.md"
        semantic.parent.mkdir(parents=True)
        semantic.write_text("## 已有\n旧\n")

        writer = MemoryWriter(project_dir=tmp_path)
        result = writer.consolidate(text="## 新知识\n新内容\n", source="test")
        assert result["action"] == "completed"
        assert result["added"] >= 1

    def test_empty_working_memory_extract(self, tmp_path):
        writer = MemoryWriter(project_dir=tmp_path)
        extraction = writer.extract_from_working_memory()
        assert len(extraction.candidates) == 0

    def test_memory_entry_to_markdown(self):
        entry = MemoryEntry(title="标题", body="正文")
        md = entry.to_markdown()
        assert "## 标题" in md
        assert "正文" in md


# ═══════════════════════════════════════════════════════
# Verify 阶段测试
# ═══════════════════════════════════════════════════════


class TestVerificationResult:
    def test_defaults(self):
        from tianlong.evolution import VerificationResult
        vr = VerificationResult()
        assert vr.verdict == "pending"
        assert vr.to_dict()["proposal_id"] == ""

    def test_hit_miss(self):
        from tianlong.evolution import VerificationResult
        vr = VerificationResult(proposal_id="p1", verdict="hit")
        assert vr.verdict == "hit"
        d = vr.to_dict()
        assert d["proposal_id"] == "p1"


class TestVerifyOutput:
    def test_empty(self):
        from tianlong.evolution import VerifyOutput
        vo = VerifyOutput()
        assert vo.total == 0
        assert "暂无验证" in vo.summary_line()

    def test_with_results(self):
        from tianlong.evolution import VerifyOutput, VerificationResult
        vr1 = VerificationResult(proposal_id="p1", verdict="hit")
        vr2 = VerificationResult(proposal_id="p2", verdict="miss")
        vo = VerifyOutput(verified=[vr1, vr2], hit_count=1, miss_count=1)
        assert vo.total == 2
        assert "50%" in vo.summary_line()


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestVerifyProposals:
    def test_empty(self):
        from tianlong.evolution.verify import verify_proposals
        from tianlong.evolution import EvolveOutput
        evo = EvolveOutput()
        result = verify_proposals(evo.approved_proposals)
        assert result.total == 0
        assert result.hit_count == 0

    def test_with_executed(self, tmp_path):
        from tianlong.evolution.verify import verify_proposals
        from tianlong.evolution import EvolveOutput, EvolutionProposal
        prop = EvolutionProposal(
            id="v1", summary="测试验证", target="__init__.py",
            executed=True,
        )
        evo = EvolveOutput(approved_proposals=[prop])
        result = verify_proposals(evo.approved_proposals, project_dir=str(tmp_path))
        assert result.total == 1
        # 目标文件不存在 -> pending
        assert result.verified[0].verdict in ("pending", "miss")


# ═══════════════════════════════════════════════════════
# Reflect 阶段测试
# ═══════════════════════════════════════════════════════


class TestLesson:
    def test_defaults(self):
        from tianlong.evolution import Lesson
        l = Lesson()
        assert l.confidence == 0.5
        d = l.to_dict()
        assert d["category"] == ""


class TestReflectOutput:
    def test_empty(self):
        from tianlong.evolution import ReflectOutput
        ro = ReflectOutput()
        assert ro.total == 0
        assert "反思0条" in ro.summary_line()

    def test_with_lessons(self):
        from tianlong.evolution import ReflectOutput, Lesson
        l = Lesson(category="judge_calibration", summary="test")
        ro = ReflectOutput(lessons=[l], judge_calibration_error=0.2)
        assert ro.total == 1
        assert "20.0%" in ro.summary_line()


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestReflectOnVerify:
    def test_empty_verify(self):
        from tianlong.evolution.reflect import reflect_on_verify
        from tianlong.evolution import VerifyOutput
        vo = VerifyOutput()
        ro = reflect_on_verify(vo)
        assert ro.total == 0
        assert ro.judge_calibration_error == 0.0

    def test_low_hit_rate(self):
        from tianlong.evolution.reflect import reflect_on_verify
        from tianlong.evolution import VerifyOutput, VerificationResult
        vr1 = VerificationResult(proposal_id="p1", verdict="miss")
        vr2 = VerificationResult(proposal_id="p2", verdict="miss")
        vr3 = VerificationResult(proposal_id="p3", verdict="hit")
        vo = VerifyOutput(verified=[vr1, vr2, vr3], hit_count=1, miss_count=2)
        ro = reflect_on_verify(vo)
        assert ro.judge_calibration_error > 0
        # 应该有 judge_calibration 教训
        cats = [l.category for l in ro.lessons]
        assert "judge_calibration" in cats


# ═══════════════════════════════════════════════════════
# Cleanup 阶段测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestCleanupAction:
    def test_defaults(self):
        from tianlong.evolution.cleanup import CleanupAction
        ca = CleanupAction()
        assert ca.confidence == 0.5


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestScanCleanup:
    def test_empty_dir(self, tmp_path):
        from tianlong.evolution.cleanup import scan_cleanup_candidates
        result = scan_cleanup_candidates(project_dir=str(tmp_path))
        assert result.brain_file_count == 0
        assert len(result.actions) == 0

    def test_with_old_file(self, tmp_path):
        from tianlong.evolution.cleanup import scan_cleanup_candidates
        brain_dir = tmp_path / "brain"
        brain_dir.mkdir()
        fpath = brain_dir / "old_note.md"
        fpath.write_text("# old")
        # 修改 mtime 为 40 天前
        import time
        old_time = time.time() - 40 * 86400
        os.utime(str(fpath), (old_time, old_time))
        result = scan_cleanup_candidates(project_dir=str(tmp_path), max_age_days=30)
        assert len(result.actions) >= 1
        assert any("old_note.md" in a.target for a in result.actions)


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestCleanupOutput:
    def test_total_size(self):
        from tianlong.evolution.cleanup import CleanupOutput, CleanupAction
        ca = CleanupAction(target="f.json", action="archive", size_bytes=1024)
        co = CleanupOutput(actions=[ca], total_size_saved=1024)
        assert co.total_size_saved == 1024
        assert len(co.actions) == 1


# ═══════════════════════════════════════════════════════
# RalphLoop 集成测试（新阶段注入）
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestRalphLoopNewPhases:
    def test_verify_reflect_integration(self):
        """验证 RalphLoop.run() 会正常执行 VERIFY + REFLECT"""
        loop = RalphLoop(config={"require_update": False})
        task = TaskResult(
            task_id="integ-test", status=TaskStatus.SUCCESS,
            summary="集成测试全闭环",
        )
        report = loop.run(task)
        # verify 和 reflect 应该被调用（即使无提案，也不会报错）
        assert report.verify_output is not None
        assert report.reflect_output is not None
        # 即使没有 approved_proposals，verify 也应该返回空结果
        assert report.verify_output.total == 0
        assert report.reflect_output.total == 0

    def test_cleanup_included(self):
        """验证 CLEANUP 阶段也执行"""
        loop = RalphLoop(config={"require_update": False})
        task = TaskResult(task_id="cleanup-test", status=TaskStatus.SUCCESS)
        report = loop.run(task)
        # verify/reflect 不应该报错
        assert report.verify_output is not None
        assert report.reflect_output is not None


# ═══════════════════════════════════════════════════════
# EvolutionReport 扩展测试
# ═══════════════════════════════════════════════════════


@pytest.mark.skipif(not HAS_EVOLUTION, reason="需要企业版进化引擎")
class TestReportNewFields:
    def test_verify_output_in_report(self):
        from tianlong.evolution import VerifyOutput, VerificationResult
        report = EvolutionReport()
        vr = VerificationResult(proposal_id="p1", verdict="hit")
        report.verify_output = VerifyOutput(verified=[vr], hit_count=1)
        assert report.verify_output.total == 1
        assert "验证" in report.summary_line

    def test_reflect_output_in_report(self):
        from tianlong.evolution import ReflectOutput, Lesson
        report = EvolutionReport()
        l = Lesson(category="success_pattern", summary="ok")
        report.reflect_output = ReflectOutput(lessons=[l])
        assert "反思" in report.summary_line

    def test_summary_line_all_phases(self):
        from tianlong.evolution import (
            EvolutionReport, EvolveOutput, EvolutionProposal,
            VerifyOutput, VerificationResult,
            ReflectOutput, Lesson,
        )
        report = EvolutionReport()
        report.evolve_output = EvolveOutput(
            approved_proposals=[EvolutionProposal(id="p1")],
        )
        report.verify_output = VerifyOutput(
            verified=[VerificationResult(proposal_id="p1", verdict="hit")],
            hit_count=1,
        )
        report.reflect_output = ReflectOutput(
            lessons=[Lesson(category="success_pattern", summary="ok")],
        )
        line = report.summary_line
        assert "通过: 1" in line
        assert "验证" in line
        assert "反思" in line
