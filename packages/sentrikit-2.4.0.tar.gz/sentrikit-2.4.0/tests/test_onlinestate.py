"""tianlong.onlinestate — 在线状态管理器测试"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from tianlong.onlinestate import OnlineState, OnlineStateSnapshot


class TestOnlineStateSnapshot:
    def test_default(self):
        s = OnlineStateSnapshot()
        assert s.status == "online"
        assert s.last_online == ""
        assert s.last_offline == ""
        assert s.reason == ""


class TestOnlineState:
    def test_init(self):
        with tempfile.TemporaryDirectory() as tmp:
            os = OnlineState(project_dir=Path(tmp))
            assert os.is_online is True

    def test_set_online(self):
        with tempfile.TemporaryDirectory() as tmp:
            os = OnlineState(project_dir=Path(tmp))
            os.set_offline("测试离线")
            assert os.is_online is False
            os.set_online("重新上线")
            assert os.is_online is True

    def test_set_offline(self):
        with tempfile.TemporaryDirectory() as tmp:
            os = OnlineState(project_dir=Path(tmp))
            os.set_offline("手动离线")
            assert os.is_online is False

    def test_read_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            os = OnlineState(project_dir=Path(tmp))
            os.set_offline("测试离线")
            snap = os.read()
            assert snap.status == "offline"
            assert snap.reason == "测试离线" or "测试" in snap.reason

    def test_read_nonexistent(self):
        with tempfile.TemporaryDirectory() as tmp:
            os = OnlineState(project_dir=Path(tmp))
            snap = os.read()
            # 文件不存在 -> unknown
            assert snap.status == "unknown"

    def test_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            os = OnlineState(project_dir=Path(tmp))
            os.set_online("测试上线")
            snap = os.snapshot()
            assert snap["is_online"] is True
            assert snap["status"] == "online"
            assert "reason" in snap

    def test_set_online_default_reason(self):
        with tempfile.TemporaryDirectory() as tmp:
            os = OnlineState(project_dir=Path(tmp))
            os.set_online()
            assert os.is_online is True
