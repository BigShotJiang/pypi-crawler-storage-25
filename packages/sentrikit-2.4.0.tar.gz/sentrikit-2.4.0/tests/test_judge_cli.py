"""tianlong.judge.cli — 测试"""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from tianlong.judge.cli import main, build_parser, format_text, _score_bar
from tianlong.judge import JudgeGrade, JudgeResult, DimensionScore


# ── CLI 解析测试 ──────────────────────────────────────


class TestCLIParse:
    def test_evaluate_defaults(self):
        """evaluate 子命令的基本参数解析"""
        parser = build_parser()
        args = parser.parse_args(["evaluate", "--proposal", "优化搜索"])
        assert args.command == "evaluate"
        assert args.proposal == "优化搜索"
        assert args.id == "cli"
        assert args.type == "update"
        assert args.steps == 5
        assert args.tokens == 2000
        assert args.rsi == "yes"
        assert args.failures == 0
        assert args.llm is False
        assert args.output == "text"

    def test_evaluate_all_options(self):
        """所有参数指定"""
        parser = build_parser()
        args = parser.parse_args([
            "evaluate",
            "--proposal", "重构记忆模块",
            "--id", "p099",
            "--type", "create",
            "--steps", "3",
            "--tokens", "1500",
            "--target", "brain/memory.md",
            "--description", "完整重构",
            "--rsi", "no",
            "--failures", "2",
            "--llm",
            "--output", "json",
        ])
        assert args.proposal == "重构记忆模块"
        assert args.id == "p099"
        assert args.type == "create"
        assert args.steps == 3
        assert args.tokens == 1500
        assert args.target == "brain/memory.md"
        assert args.description == "完整重构"
        assert args.rsi == "no"
        assert args.failures == 2
        assert args.llm is True
        assert args.output == "json"

    def test_template_subcommand(self):
        """template 子命令"""
        parser = build_parser()
        args = parser.parse_args(["template", "--name", "create_new_knowledge"])
        assert args.command == "template"
        assert args.name == "create_new_knowledge"

    def test_template_output_json(self):
        parser = build_parser()
        args = parser.parse_args(["template", "--name", "delete_content", "-o", "json"])
        assert args.output == "json"

    def test_invalid_template(self):
        parser = build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["template", "--name", "nonexistent"])

    def test_missing_proposal(self):
        """evaluate 需要 --proposal"""
        parser = build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["evaluate"])


# ── 格式工具测试 ──────────────────────────────────────


class TestFormat:
    def test_score_bar_full(self):
        bar = _score_bar(1.0, width=10)
        assert bar == "█" * 10

    def test_score_bar_half(self):
        bar = _score_bar(0.5, width=10)
        assert bar == "█" * 5 + "░" * 5

    def test_score_bar_zero(self):
        bar = _score_bar(0.0, width=10)
        assert bar == "░" * 10

    def test_score_bar_clamp(self):
        bar = _score_bar(1.5, width=10)
        assert bar == "█" * 10

    def test_format_text_contains_key_info(self):
        """格式化输出包含关键信息"""
        dims = [
            DimensionScore("direction", 0.8, 0.25, "RSI方向"),
            DimensionScore("efficiency", 0.7, 0.20, "效率高"),
            DimensionScore("robustness", 0.6, 0.20, "鲁棒性一般"),
            DimensionScore("reusability", 0.5, 0.15, "可复用"),
            DimensionScore("cost_risk", 0.8, 0.20, "成本可控"),
        ]
        result = JudgeResult(proposal_id="p001", proposal_summary="优化流程", dimensions=dims)
        text = format_text(result)
        assert "p001" in text
        assert "优化流程" in text
        assert "direction" in text
        assert "通过" in text

    def test_format_text_failed(self):
        """失败的提案显示不通过"""
        dims = [
            DimensionScore("direction", 0.2, 0.25, "方向错误"),
            DimensionScore("efficiency", 0.1, 0.20, "效率低"),
            DimensionScore("robustness", 0.2, 0.20, "鲁棒性差"),
            DimensionScore("reusability", 0.1, 0.15, "不可复用"),
            DimensionScore("cost_risk", 0.2, 0.20, "成本高"),
        ]
        result = JudgeResult(proposal_id="p002", proposal_summary="删除核心", dimensions=dims)
        text = format_text(result)
        assert "不通过" in text


# ── evaluate 主流程测试 ──────────────────────────────


class TestCmdEvaluate:
    def test_good_proposal_passes(self):
        """好的提案应该通过"""
        rc = main(["evaluate", "--proposal", "优化搜索流程，减少步骤", "--steps", "3"])
        assert rc == 0  # passed

    def test_bad_proposal_fails(self):
        """差的提案应该不通过"""
        rc = main([
            "evaluate", "--proposal", "删除核心配置文件",
            "--type", "delete", "--steps", "1",
            "--rsi", "no", "--failures", "3",
        ])
        assert rc == 1  # not passed

    def test_json_output_parseable(self):
        """JSON 输出可解析"""
        with patch("sys.stdout") as mock_stdout:
            # 创建一个 StringIO 来捕获输出
            pass

        # 直接用 subprocess 风格的完整流程
        rc = main([
            "evaluate", "--proposal", "优化流程",
            "--output", "json",
        ])
        assert rc == 0

    def test_json_output_good(self, capsys):
        main(["evaluate", "--proposal", "优化流程", "--output", "json"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["proposal_id"] == "cli"
        assert data["passed"] is True
        assert data["method"] == "rules"
        assert len(data["dimensions"]) == 5
        assert "total_score" in data
        assert "grade" in data

    def test_json_output_bad(self, capsys):
        main([
            "evaluate", "--proposal", "删库跑路",
            "--type", "delete", "--rsi", "no",
            "--failures", "5", "--output", "json",
        ])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["passed"] is False
        assert data["method"] == "rules"
        assert data["proposal"]["summary"] == "删库跑路"

    def test_custom_proposal_id(self):
        """自定义 ID"""
        rc = main(["evaluate", "--proposal", "测试", "--id", "my-proposal-001"])
        assert rc == 0

    def test_create_type(self):
        """create 类型应该通过"""
        rc = main(["evaluate", "--proposal", "新增知识库", "--type", "create", "--steps", "4"])
        assert rc == 0

    def test_all_fields(self, capsys):
        """所有字段都填满"""
        main([
            "evaluate",
            "--proposal", "重构记忆系统",
            "--id", "p100",
            "--type", "update",
            "--steps", "6",
            "--tokens", "3000",
            "--target", "brain/memory.md",
            "--description", "完整重构记忆系统提升检索效率",
            "--rsi", "yes",
            "--failures", "1",
            "--output", "json",
        ])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["proposal_id"] == "p100"
        assert data["passed"] is True
        assert data["proposal"]["summary"] == "重构记忆系统"
        assert data["proposal"]["change_type"] == "update"
        assert data["proposal"]["estimated_steps"] == 6
        assert data["proposal"]["estimated_tokens"] == 3000

    def test_llm_mode_no_key_fallback(self, capsys):
        """LLM 模式但没有 API Key 应降级到规则引擎"""
        rc = main([
            "evaluate", "--proposal", "优化流程",
            "--llm",
        ])
        captured = capsys.readouterr()
        assert "降级" in captured.err or rc == 0
        assert rc == 0


# ── template 子命令测试 ──────────────────────────────


class TestCmdTemplate:
    def test_template_good(self):
        """好的模板应该通过"""
        rc = main(["template", "--name", "create_new_knowledge"])
        assert rc == 0

    def test_template_bad(self):
        """差的模板应该不通过"""
        rc = main(["template", "--name", "delete_content"])
        assert rc == 1

    def test_template_performance(self):
        """性能优化模板应该高分通过"""
        rc = main(["template", "--name", "optimize_performance"])
        assert rc == 0

    def test_template_json(self, capsys):
        """模板 JSON 输出"""
        main(["template", "--name", "create_new_knowledge", "-o", "json"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["template"] == "create_new_knowledge"
        assert data["passed"] is True

    def test_template_update_process(self):
        """修改流程模板"""
        rc = main(["template", "--name", "update_process"])
        assert rc == 0
