"""tianlong.judge.llm 测试"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tianlong.judge import LLMJudge, LLMConfig, RuleBasedJudge, Proposal, JudgeGrade


# ── LLMConfig 测试 ────────────────────────────────────


class TestLLMConfig:
    def test_default_config(self):
        config = LLMConfig()
        assert config.base_url == "https://api.deepseek.com/v1"
        assert config.model == "deepseek-chat"
        assert config.temperature == 0.3

    def test_not_configured_by_default(self):
        config = LLMConfig()
        assert not config.is_configured

    def test_configured_with_key(self):
        config = LLMConfig(api_key="sk-test")
        assert config.is_configured

    def test_from_env(self, monkeypatch):
        monkeypatch.setenv("DEEPSEEK_API_KEY", "sk-env-test")
        config = LLMConfig.from_env()
        assert config.api_key == "sk-env-test"
        assert config.is_configured


# ── LLMJudge 测试 ─────────────────────────────────────


class TestLLMJudge:
    def test_fallback_when_no_key(self):
        """没有 API Key 时应自动降级到规则引擎"""
        judge = LLMJudge()
        judge.configure(api_key="")  # 清空key
        proposal = Proposal(id="p1", summary="测试", is_rsi_aligned=True)
        result = judge.evaluate(proposal)
        assert result.passed()
        assert result.total_score > 0

    def test_configure_method(self):
        judge = LLMJudge()
        judge.configure(api_key="sk-test", model="deepseek-chat")
        assert judge.config.api_key == "sk-test"
        assert judge.config.model == "deepseek-chat"

    def test_llm_available_flag(self):
        judge = LLMJudge()
        judge.configure(api_key="")
        assert not judge.is_llm_available
        judge.configure(api_key="sk-test")
        assert judge.is_llm_available

    def test_parse_response_valid_json(self):
        """测试解析 LLM 返回的正确 JSON"""
        judge = LLMJudge()
        judge.configure(api_key="sk-test")

        mock_response = json.dumps({
            "dimensions": {
                "direction": {"score": 0.9, "reason": "方向正确，符合RSI"},
                "efficiency": {"score": 0.7, "reason": "步骤适中"},
                "robustness": {"score": 0.8, "reason": "边界覆盖好"},
                "reusability": {"score": 0.6, "reason": "可推广"},
                "cost_risk": {"score": 0.8, "reason": "成本可控"},
            },
            "summary": "推荐执行"
        })

        scores = judge._parse_response(mock_response)
        assert len(scores) == 5
        assert scores["direction"][0] == 0.9
        assert scores["efficiency"][0] == 0.7

    def test_parse_response_markdown_wrapped(self):
        """LLM 返回包在 markdown 代码块里"""
        judge = LLMJudge()
        judge.configure(api_key="sk-test")

        mock_response = """```json
{
  "dimensions": {
    "direction": {"score": 0.8, "reason": "好"},
    "efficiency": {"score": 0.6, "reason": "中"},
    "robustness": {"score": 0.7, "reason": "好"},
    "reusability": {"score": 0.5, "reason": "中"},
    "cost_risk": {"score": 0.8, "reason": "低"}
  }
}
```"""

        scores = judge._parse_response(mock_response)
        assert scores["direction"][0] == 0.8
        assert len(scores) == 5

    def test_parse_response_flat_format(self):
        """有些 LLM 可能直接返回 flat 格式"""
        judge = LLMJudge()
        judge.configure(api_key="sk-test")

        mock_response = json.dumps({
            "direction": 0.85,
            "efficiency": 0.65,
            "robustness": 0.75,
            "reusability": 0.55,
            "cost_risk": 0.80,
        })

        scores = judge._parse_response(mock_response)
        assert scores["direction"][0] == 0.85
        assert scores["cost_risk"][0] == 0.80

    def test_parse_response_invalid_returns_default(self):
        """异常响应应返回默认值 0.5"""
        judge = LLMJudge()
        with pytest.raises(ValueError):
            judge._parse_response("这不是JSON")

    def test_set_custom_fallback(self):
        judge = LLMJudge()
        custom = RuleBasedJudge()
        judge.set_fallback(custom)
        assert judge._fallback is custom

    def test_get_last_response(self):
        judge = LLMJudge()
        assert judge.get_last_response() is None


# ── Mock API 调用测试 ────────────────────────────────


class TestLLMJudgeWithMock:
    """用 mock 模拟真实的 API 调用"""

    @patch("tianlong.judge.llm.urlopen")
    def test_successful_evaluation(self, mock_urlopen):
        """完整的 mock API 调用测试"""
        # 模拟 API 响应
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "choices": [{
                "message": {
                    "content": json.dumps({
                        "dimensions": {
                            "direction": {"score": 0.9, "reason": "RSI方向"},
                            "efficiency": {"score": 0.8, "reason": "效率高"},
                            "robustness": {"score": 0.7, "reason": "鲁棒性好"},
                            "reusability": {"score": 0.6, "reason": "可复用"},
                            "cost_risk": {"score": 0.8, "reason": "成本低"},
                        }
                    })
                }
            }]
        }).encode("utf-8")
        mock_urlopen.return_value.__enter__.return_value = mock_response

        judge = LLMJudge()
        judge.configure(api_key="sk-test")
        proposal = Proposal(id="p1", summary="优化流程", is_rsi_aligned=True)

        result = judge.evaluate(proposal)
        assert result.passed()
        assert result.grade in (JudgeGrade.A, JudgeGrade.S)
        assert result.total_score >= 0.75

    @patch("tianlong.judge.llm.urlopen")
    def test_api_failure_fallback(self, mock_urlopen):
        """API 调用失败时应降级到规则引擎"""
        from urllib.error import URLError
        mock_urlopen.side_effect = URLError("API不可达")

        judge = LLMJudge()
        judge.configure(api_key="sk-test")
        proposal = Proposal(id="p1", summary="测试", is_rsi_aligned=True)

        result = judge.evaluate(proposal)
        assert result.passed()  # 降级后规则引擎应该能返回结果
        assert result.total_score > 0

    @patch("tianlong.judge.llm.urlopen")
    def test_malformed_response_fallback(self, mock_urlopen):
        """LLM 返回乱码时降级"""
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "choices": [{"message": {"content": "我不明白你在说什么"}}]
        }).encode("utf-8")
        mock_urlopen.return_value.__enter__.return_value = mock_response

        judge = LLMJudge()
        judge.configure(api_key="sk-test")
        proposal = Proposal(id="p1", summary="测试", is_rsi_aligned=True)

        result = judge.evaluate(proposal)
        assert result.passed()

    def test_build_prompt(self):
        """验证 prompt 包含提案信息"""
        judge = LLMJudge()
        judge.configure(api_key="sk-test")
        proposal = Proposal(
            id="p001", summary="优化搜索", description="减少搜索步骤",
            change_type="update", target="brain/procedural-memory.md",
            estimated_steps=3, estimated_tokens=1500,
            previous_failures=1, is_rsi_aligned=True,
        )
        prompt = judge._build_prompt(proposal)
        assert "p001" in prompt
        assert "优化搜索" in prompt
        assert "修改" in prompt or "update" in prompt
        assert "3" in prompt or "三" in prompt
