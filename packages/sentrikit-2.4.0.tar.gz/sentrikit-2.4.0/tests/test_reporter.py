"""tianlong.reporter — 测试"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tianlong.reporter import (
    Reporter, ReportTrigger, ReportContent,
    MonitorReportData, SafetyReportData,
    JudgeReportData, EvolutionReportData,
    render_full_report, render_summary,
)


# ═══════════════════════════════════════════════════════
# 数据模型测试
# ═══════════════════════════════════════════════════════


class TestMonitorReportData:
    def test_summary_line(self):
        d = MonitorReportData(overall="healthy", checks_ok=7, checks_total=8)
        assert "HEALTHY" in d.summary_line
        assert "7/8" in d.summary_line

    def test_summary_line_with_warnings(self):
        d = MonitorReportData(overall="warning", checks_ok=6, checks_warning=2,
                              checks_error=0, checks_total=8)
        assert "warning" in d.summary_line.lower()


class TestSafetyReportData:
    def test_summary_line(self):
        d = SafetyReportData(recent_checks=10, recent_blocked=2)
        assert "10" in d.summary_line
        assert "2" in d.summary_line

    def test_summary_line_paused(self):
        d = SafetyReportData(is_paused=True)
        assert "暂停" in d.summary_line


class TestJudgeReportData:
    def test_summary_line(self):
        d = JudgeReportData(overall_grade="B", pass_rate=0.75, avg_score=0.68)
        assert "B" in d.summary_line
        assert "75%" in d.summary_line


class TestEvolutionReportData:
    def test_summary_line(self):
        d = EvolutionReportData(completed=False, approved_count=0, rejected_count=2)
        assert "False" in d.summary_line
        assert "0" in d.summary_line


# ═══════════════════════════════════════════════════════
# 模板测试
# ═══════════════════════════════════════════════════════


class TestTemplates:
    def test_render_standard_task_done(self):
        content = ReportContent(
            trigger="task_done",
            title="优化搜索",
            body="完成，减少3步",
            highlights=["响应时间降低50%"],
            action_items=["部署到生产"],
        )
        text = render_full_report(content)
        assert "优化搜索" in text
        assert "完成" in text
        assert "响应时间降低50%" in text
        assert "部署到生产" in text

    def test_render_highlight(self):
        content = ReportContent(
            trigger="highlight",
            title="发现新模式",
            body="成功轨迹捕获",
            highlights=["可复用率80%"],
            action_items=["写入semantic-memory"],
        )
        text = render_full_report(content)
        assert "发现新模式" in text
        assert "成功轨迹捕获" in text
        assert "写入semantic-memory" in text

    def test_render_alert(self):
        content = ReportContent(
            trigger="alert",
            title="SafetyGate连续阻止",
            body="3次审计阻止",
            highlights=["配置修改被拒"],
            action_items=["手动确认"],
        )
        text = render_full_report(content)
        assert "SafetyGate连续阻止" in text
        assert "手动确认" in text

    def test_render_alert_with_degradation(self):
        evo = EvolutionReportData(
            degradation_warnings=["退化#1: 拒绝率30%", "退化#2: 无提案通过"],
        )
        content = ReportContent(
            trigger="alert", title="退化",
            evolution=evo,
        )
        text = render_full_report(content)
        assert "退化详情" in text
        assert "拒绝率30%" in text

    def test_render_milestone(self):
        judge = JudgeReportData(overall_grade="A", pass_rate=0.85, avg_score=0.82)
        content = ReportContent(
            trigger="milestone",
            title="首次A级闭环",
            body="全部条件满足",
            judge=judge,
        )
        text = render_full_report(content)
        assert "首次A级闭环" in text
        assert "85%" in text or "A" in text

    def test_render_summary(self):
        text = render_summary(
            title="枢御状态摘要",
            monitor_data=MonitorReportData(overall="healthy", checks_ok=7, checks_total=8),
            judge_data=JudgeReportData(overall_grade="B", pass_rate=0.7),
            highlights=["新增知识库条目"],
            action_items=["检查告警"],
        )
        assert "枢御状态摘要" in text
        assert "HEALTHY" in text
        assert "新增知识库条目" in text
        assert "检查告警" in text

    def test_render_summary_with_all_data(self):
        text = render_summary(
            title="完整摘要",
            monitor_data=MonitorReportData(overall="healthy", checks_ok=8, checks_total=8),
            safety_data=SafetyReportData(recent_checks=5),
            judge_data=JudgeReportData(overall_grade="A", pass_rate=0.9, avg_score=0.85),
            evolution_data=EvolutionReportData(completed=True, approved_count=2),
            highlights=["亮点1"],
            action_items=["事项1"],
        )
        assert "健康监控" in text
        assert "安全约束" in text
        assert "进化评估" in text
        assert "进化闭环" in text


# ═══════════════════════════════════════════════════════
# Reporter 引擎测试
# ═══════════════════════════════════════════════════════


class TestReporter:
    def test_report_task_done(self):
        reporter = Reporter()
        text = reporter.report_task_done(title="测试任务", body="完成")
        assert text
        assert "测试任务" in text

    def test_report_highlight(self):
        reporter = Reporter()
        text = reporter.report_highlight(title="发现", body="新知识")
        assert text
        assert "发现" in text

    def test_report_alert(self):
        reporter = Reporter()
        text = reporter.report_alert(title="警告", body="异常")
        assert text
        assert "警告" in text

    def test_report_milestone(self):
        reporter = Reporter()
        text = reporter.report_milestone(title="里程碑", body="完成闭环")
        assert text
        assert "里程碑" in text

    def test_report_summary_no_project(self):
        """无项目目录时返回空摘要。"""
        reporter = Reporter()
        text = reporter.report_summary(title="摘要")
        assert text
        assert "摘要" in text

    def test_task_done_rate_limit(self):
        """同一 task_id 只汇报一次。"""
        reporter = Reporter()
        t1 = reporter.report_task_done(title="任务", task_id="t001")
        assert t1  # 第一次正常输出

        t2 = reporter.report_task_done(title="任务", task_id="t001")
        assert t2 == ""  # 第二次被频率控制拦截

    def test_task_done_different_ids(self):
        """不同 task_id 分别汇报。"""
        reporter = Reporter()
        t1 = reporter.report_task_done(title="任务1", task_id="t001")
        t2 = reporter.report_task_done(title="任务2", task_id="t002")
        assert t1 and t2
        assert "任务1" in t1
        assert "任务2" in t2

    def test_summary_rate_limit(self):
        """摘要最多每3小时1次。"""
        reporter = Reporter()
        s1 = reporter.report_summary(title="摘要1")
        assert s1  # 第一次允许

        s2 = reporter.report_summary(title="摘要2")
        assert s2 == ""  # 第二次被拦截

    def test_report_with_module_data(self):
        """带模块数据的完整汇报。"""
        reporter = Reporter()
        text = reporter.report_task_done(
            title="优化搜索",
            body="完成",
            monitor_data=MonitorReportData(overall="healthy", checks_ok=8, checks_total=8),
            safety_data=SafetyReportData(recent_checks=10),
            judge_data=JudgeReportData(overall_grade="A", pass_rate=0.9),
            evolution_data=EvolutionReportData(completed=True, approved_count=1),
        )
        assert "健康监控" in text
        assert "HEALTHY" in text
        assert "进化评估" in text

    def test_log_entries(self):
        """汇报日志记录。"""
        reporter = Reporter()
        reporter.report_task_done(title="任务1", task_id="t001")
        reporter.report_highlight(title="发现1")
        reporter.report_alert(title="警报1")

        log = reporter.get_log()
        assert len(log) == 3
        assert log[0]["trigger"] == "task_done"
        assert log[1]["trigger"] == "highlight"
        assert log[2]["trigger"] == "alert"


# ═══════════════════════════════════════════════════════
# CLI 测试
# ═══════════════════════════════════════════════════════


class TestCLI:
    def test_task_done(self, capsys):
        from tianlong.reporter.cli import main
        rc = main(["task-done", "--title", "优化", "--body", "完成"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "优化" in captured.out

    def test_highlight(self, capsys):
        from tianlong.reporter.cli import main
        rc = main(["highlight", "--title", "发现", "--body", "新知识"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "发现" in captured.out

    def test_alert(self, capsys):
        from tianlong.reporter.cli import main
        rc = main(["alert", "--title", "警告", "--body", "异常"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "警告" in captured.out

    def test_summary(self, capsys, tmp_path):
        from tianlong.reporter.cli import main
        rc = main(["summary", "--project-dir", str(tmp_path)])
        captured = capsys.readouterr()
        assert rc == 0
        assert "摘要" in captured.out

    def test_summary_json(self, capsys, tmp_path):
        from tianlong.reporter.cli import main
        rc = main(["summary", "--project-dir", str(tmp_path), "-o", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert "project_dir" in data

    def test_log(self, capsys):
        from tianlong.reporter.cli import main
        rc = main(["log", "--limit", "5"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert isinstance(data, list)


# ═══════════════════════════════════════════════════════
# 新功能测试：JSON 输出 + Sub-Agent 汇报 + UXU 汇报
# ═══════════════════════════════════════════════════════


class TestReporterEnhancements:
    def test_report_task_done_json(self):
        """任务完成支持 JSON 格式输出。"""
        reporter = Reporter()
        text = reporter.report_task_done(
            title="测试任务", body="完成",
            task_id="t001",
            output_format="json",
        )
        data = json.loads(text)
        assert data["title"] == "测试任务"
        assert data["trigger"] == "task_done"
        assert data["body"] == "完成"

    def test_report_subagent_result_success(self):
        """Sub-Agent 成功结果汇报。"""
        reporter = Reporter()
        text = reporter.report_subagent_result(
            role="research_agent",
            goal="调研Python安全框架",
            result_summary="发现3个框架",
            duration=15.3,
        )
        assert "Sub-Agent" in text
        assert "research" in text
        assert "15.3" in text
        assert "发现3个框架" in text

    def test_report_subagent_result_failure(self):
        """Sub-Agent 失败结果汇报。"""
        reporter = Reporter()
        text = reporter.report_subagent_result(
            role="code_agent",
            goal="实现复杂算法",
            result_summary="",
            duration=30.0,
            success=False,
            error="任务超时",
        )
        assert "Sub-Agent" in text
        assert "code" in text
        assert "30.0" in text
        assert "任务超时" in text

    def test_report_uxu_scan_clean(self):
        """UXU 扫描无发现。"""
        reporter = Reporter()
        text = reporter.report_uxu_scan(total_findings=0)
        assert "通过" in text
        assert "0" in text

    def test_report_uxu_scan_with_findings(self):
        """UXU 扫描有高危发现。"""
        reporter = Reporter()
        text = reporter.report_uxu_scan(
            total_findings=3,
            by_severity={"critical": 1, "high": 1, "low": 1},
            top_findings=[
                {"severity": "critical", "rule": "UXU-IS-001", "file": "test.py", "line": 42},
                {"severity": "high", "rule": "UXU-SI-005", "file": "app.py", "line": 100},
            ],
        )
        assert "3" in text
        assert "1个严重" in text
        assert "1个高危" in text
        assert "UXU-IS-001" in text

    def test_report_uxu_scan_low_only(self):
        """UXU 扫描仅低风险。"""
        reporter = Reporter()
        text = reporter.report_uxu_scan(
            total_findings=5,
            by_severity={"low": 5},
        )
        assert "5" in text
        assert "低风险" in text
