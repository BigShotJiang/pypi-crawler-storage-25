"""tianlong.dgmh — DGM-H 元认知架构编排器测试"""

from __future__ import annotations

import pytest
from datetime import datetime, timedelta

from tianlong.dgmh import DGOrchestrator, ActivationStatus, SafetyShield


class TestActivationStatus:
    """激活条件状态测试"""

    def test_default_state(self):
        s = ActivationStatus()
        assert s.success_trails_ready is False
        assert s.gepa_verified is True
        assert s.safetyguard_stable is False
        assert s.user_authorized is False
        assert s.judgestored is False

    def test_phase1_ready_always_true(self):
        """Phase 1: 元Agent能力增强 — 始终可用"""
        s = ActivationStatus()
        assert s.phase1_ready is True

    def test_phase2_ready_depends_on_judgestored(self):
        """Phase 2: 需要 Judge 历史"""
        s = ActivationStatus()
        assert s.phase2_ready is False
        s.judgestored = True
        assert s.phase2_ready is True

    def test_phase3_ready_all_conditions(self):
        """Phase 3: 需要所有条件满足"""
        s = ActivationStatus()
        assert s.phase3_ready is False
        s.success_trails_ready = True
        s.gepa_verified = True
        s.safetyguard_stable = True
        s.user_authorized = True
        assert s.phase3_ready is True

    def test_phase3_ready_missing_one(self):
        s = ActivationStatus(
            success_trails_ready=True,
            gepa_verified=True,
            safetyguard_stable=False,
            user_authorized=True,
        )
        assert s.phase3_ready is False

    def test_to_dict(self):
        s = ActivationStatus(success_trails_ready=True)
        d = s.to_dict()
        assert isinstance(d, dict)
        assert d["success_trails_ready"] is True


class TestSafetyShield:
    def test_init(self):
        shield = SafetyShield()
        assert shield is not None
        assert shield.should_rollback is False

    def test_check_blocks_safety_guard(self):
        shield = SafetyShield()
        assert shield.check("modify", "safety_guard.rules") is not None
        assert shield.check("create_safety_rule", "") is not None

    def test_check_allows_normal_action(self):
        shield = SafetyShield()
        assert shield.check("modify", "evolution/threshold.py") is None

    def test_should_not_rollback_by_default(self):
        shield = SafetyShield()
        assert shield.should_rollback is False

    def test_three_failures_triggers_rollback(self):
        shield = SafetyShield()
        shield.record_outcome(False)
        shield.record_outcome(False)
        shield.record_outcome(False)
        assert shield.should_rollback is True

    def test_success_resets_failure_count(self):
        shield = SafetyShield()
        shield.record_outcome(False)
        shield.record_outcome(False)
        shield.record_outcome(True)
        assert shield.should_rollback is False

    def test_record_modification(self):
        shield = SafetyShield()
        shield.record_modification("test.py", "old", "new")
        assert shield.get_rollback_path() is not None
        assert shield.get_rollback_path()["path"] == "test.py"

    def test_get_rollback_paths(self):
        shield = SafetyShield()
        shield.record_modification("a.py", "1", "2")
        shield.record_modification("b.py", "2", "3")
        paths = shield.get_rollback_paths()
        assert len(paths) == 2
        assert paths[0]["path"] == "a.py"

    def test_get_rollback_path_empty(self):
        shield = SafetyShield()
        assert shield.get_rollback_path() is None

    def test_m6_rate_limit(self):
        """M6: 修改频率上限检测"""
        shield = SafetyShield()
        shield.record_modification("test.py", "a", "b")
        # 同秒内再次修改应触发频率限制
        result = shield.check("modify", "another.py")
        if result is not None:
            assert "M6" in result


class TestDGOrchestrator:
    """DGM-H 编排器测试"""

    def test_init(self):
        dg = DGOrchestrator()
        assert dg is not None
        assert dg.shield is not None

    def test_check_activation(self):
        dg = DGOrchestrator()
        result = dg.check_activation()
        assert isinstance(result, ActivationStatus)

    def test_set_activation(self):
        dg = DGOrchestrator()
        dg.set_activation(success_trails_ready=True, user_authorized=True)
        status = dg.check_activation()
        assert status.success_trails_ready is True
        assert status.user_authorized is True

    def test_run_meta_evolve_blocked(self):
        """未满足条件时返回 blocked"""
        dg = DGOrchestrator()
        result = dg.run_meta_evolve()
        assert result["status"] == "blocked"

    def test_apply_suggestion(self):
        dg = DGOrchestrator()
        result = dg.apply_suggestion({"suggestion_type": "threshold_tune", "target": "JudgeScore阈值", "current_value": "0.6", "suggested_value": "0.7"})
        assert result["success"] is True
        assert "已应用" in result["message"]

    def test_apply_suggestion_blocked(self):
        """安全护栏阻止危险操作"""
        dg = DGOrchestrator()
        result = dg.apply_suggestion({"suggestion_type": "modify", "target": "safety_guard.rules"})
        assert result["success"] is False
        assert "M1" in result["reason"] or "M5" in result["reason"]

    def test_rollback_if_needed_no_failures(self):
        dg = DGOrchestrator()
        assert dg.rollback_if_needed() is None

    def test_rollback_if_needed_after_failures(self):
        dg = DGOrchestrator()
        dg.apply_suggestion({"suggestion_type": "threshold_tune", "target": "x.py", "current_value": "a", "suggested_value": "b"})
        dg.shield.record_outcome(False)
        dg.shield.record_outcome(False)
        dg.shield.record_outcome(False)
        rollback = dg.rollback_if_needed()
        assert rollback is not None
        assert "rollback" in rollback["action"]
