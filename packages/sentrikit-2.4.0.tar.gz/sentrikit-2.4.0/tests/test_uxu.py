"""tianlong.uxu — 测试"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tianlong.uxu import Scanner, ScanReport, ScanFinding, UXURule, ALL_RULES, get_rule
from tianlong.uxu.rules import register_custom_rule, load_custom_rules, CUSTOM_RULES


class TestRules:
    def test_base_count(self):
        # 36条内置 + 3条新增(PM-013~PM-015) = 39 + 0条自定义
        base = len([r for r in ALL_RULES if r.rule_id not in [c.rule_id for c in CUSTOM_RULES]])
        assert base == 39

    def test_is_13_rules(self):
        is_rules = [r for r in ALL_RULES if r.pillar == "input_sanitization"]
        assert len(is_rules) == 13  # 原10条 + IS-011 + IS-012 + IS-013

    def test_si_11_rules(self):
        si_rules = [r for r in ALL_RULES if r.pillar == "sandbox_isolation"]
        assert len(si_rules) == 11

    def test_pm_15_rules(self):
        pm_rules = [r for r in ALL_RULES if r.pillar == "privilege_minimization"]
        assert len(pm_rules) == 15  # 原12条 + PM-013 + PM-014 + PM-015

    def test_get_rule_found(self):
        r = get_rule("UXU-IS-001")
        assert r is not None
        assert r.severity == "critical"

    def test_get_rule_not_found(self):
        assert get_rule("UXU-XX-999") is None

    def test_free_tier(self):
        free = [r for r in ALL_RULES if r.tier == "free"]
        assert len(free) == 34  # 32 原有 + IS-013 + SI-011

    def test_paid_tier(self):
        paid = [r for r in ALL_RULES if r.tier == "paid"]
        assert len(paid) == 5  # PM-011 ~ PM-015 为企业版付费规则

    def test_all_have_patterns(self):
        for r in ALL_RULES:
            assert len(r.patterns) > 0, f"{r.rule_id} 无检测模式"

    def test_all_have_suggestions(self):
        for r in ALL_RULES:
            assert r.suggestion, f"{r.rule_id} 无修复建议"


class TestScanner:
    def test_scan_nonexistent(self):
        scanner = Scanner()
        with pytest.raises(FileNotFoundError):
            scanner.scan("/tmp/nonexistent_path_xyz")

    def test_scan_clean_file(self, tmp_path):
        f = tmp_path / "hello.py"
        f.write_text("print('hello world')\nx = 1 + 2\n")
        scanner = Scanner()
        report = scanner.scan(str(f))
        assert report.total_findings == 0
        assert report.score.total == 100

    def test_scan_detects_api_key(self, tmp_path):
        f = tmp_path / "settings.py"
        f.write_text('api_key = "***"\n')
        scanner = Scanner()
        report = scanner.scan(str(f))
        # PM-008 (api key) 应触发，PM-001 也可能触发
        assert report.total_findings >= 1

    def test_scan_detects_exec(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text('exec(user_code)\n')
        scanner = Scanner()
        report = scanner.scan(str(f))
        # SI-001: exec
        exec_findings = [x for x in report.findings if x.rule_id == "UXU-SI-001"]
        assert len(exec_findings) >= 1

    def test_scan_detects_subprocess(self, tmp_path):
        f = tmp_path / "tool.py"
        f.write_text('import subprocess\nsubprocess.run(cmd, shell=True)\n')
        scanner = Scanner()
        report = scanner.scan(str(f))
        si_findings = [x for x in report.findings if x.rule_id == "UXU-SI-002"]
        assert len(si_findings) >= 1

    def test_scan_detects_eval(self, tmp_path):
        f = tmp_path / "danger.py"
        f.write_text('result = eval(user_input)\n')
        scanner = Scanner()
        report = scanner.scan(str(f))
        eval_findings = [x for x in report.findings if x.rule_id == "UXU-SI-001"]
        assert len(eval_findings) >= 1

    def test_scan_free_only(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text('api_key = "sk-test"\n')
        scanner = Scanner(free_only=True)
        report = scanner.scan(str(f))
        # 全部规则免费，free_only 不影响结果
        # 应该检测到 api_key 相关规则

    def test_ignore_comment_single_line(self, tmp_path):
        """# uxu: ignore 注释应跳过当前行。"""
        f = tmp_path / "ignore_test.py"
        f.write_text(
            "result = while_loop\n"
            "safe_line = for_item  # uxu: ignore\n"
            "dangerous = while True\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        lines_found = [x.line_number for x in report.findings]
        assert 2 not in lines_found, "uxu: ignore 应跳过第2行"
        assert 1 in lines_found or 3 in lines_found, "其他行仍应被检测"

    def test_ignore_next_comment(self, tmp_path):
        """# uxu: ignore-next:N 应跳过当前行及后续N行。"""
        f = tmp_path / "ignore_next_test.py"
        f.write_text(
            "normal = while_ok\n"
            "# uxu: ignore-next:2\n"
            "skip1 = for_item\n"
            "skip2 = while_loop\n"
            "danger = while True:\n"
        )
        scanner = Scanner()
        report = scanner.scan(str(f))
        lines_found = [x.line_number for x in report.findings]
        assert 2 not in lines_found, "ignore-next行不应被检测"
        assert 3 not in lines_found, "ignore-next:2 应跳过第3行"
        assert 4 not in lines_found, "ignore-next:2 应跳过第4行"
        assert 5 in lines_found, "第5行 (while True) 应被检测"

    def test_scan_directory(self, tmp_path):
        sub = tmp_path / "src"
        sub.mkdir()
        (sub / "safe.py").write_text("x = 1\n")
        (sub / "danger.py").write_text('exec("danger")\n')
        scanner = Scanner()
        report = scanner.scan(str(tmp_path))
        assert report.files_scanned >= 2
        assert report.total_findings >= 1

    def test_scan_report_to_dict(self, tmp_path):
        f = tmp_path / "test.py"
        f.write_text("x = 1\n")
        scanner = Scanner()
        report = scanner.scan(str(f))
        d = report.to_dict()
        assert "target" in d
        assert "summary" in d
        s = d["summary"]
        assert "score" in s
        assert s["score"]["grade"] in ("A", "B", "C", "D", "F")

    def test_score_100_perfect(self):
        from tianlong.uxu.score import UxuScore
        score = UxuScore()
        assert score.total == 100.0
        assert score.grade == "A"

    def test_score_deductions(self):
        from tianlong.uxu.score import UxuScore
        score = UxuScore()
        score.calculate([
            {"rule_id": "UXU-IS-001", "severity": "critical"},
            {"rule_id": "UXU-SI-001", "severity": "high"},
        ])
        assert score.total < 100.0
        assert score.grade in ("B", "C", "D")


class TestCLI:
    def test_scan_cli(self, capsys, tmp_path):
        from tianlong.uxu.cli import main
        f = tmp_path / "test.py"
        f.write_text("x = 1\n")
        rc = main(["scan", str(f)])
        assert rc == 0

    def test_scan_json(self, capsys, tmp_path):
        from tianlong.uxu.cli import main
        f = tmp_path / "test.py"
        f.write_text("x = 1\n")
        rc = main(["scan", str(f), "--format", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert "target" in data

    def test_rules_cli(self, capsys):
        from tianlong.uxu.cli import main
        rc = main(["rules"])
        captured = capsys.readouterr()
        assert rc == 0
        assert "39" in captured.out
        assert "付费: 5" in captured.out

    def test_rules_json(self, capsys):
        from tianlong.uxu.cli import main
        rc = main(["rules", "--format", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert len(data) == 39


# ═══════════════════════════════════════════════════════
# 自定义规则测试
# ═══════════════════════════════════════════════════════


class TestCustomRules:
    def test_register(self):
        current_custom = len(CUSTOM_RULES)
        rule = UXURule(
            rule_id="TEST-CUSTOM-002", pillar="input_sanitization",
            severity="high", title="Test custom rule",
            description="For testing", patterns=["test_pattern"],
            suggestion="Fix it",
        )
        register_custom_rule(rule)
        assert len(CUSTOM_RULES) == current_custom + 1
        assert any(r.rule_id == "TEST-CUSTOM-002" for r in ALL_RULES)

    def test_duplicate_id_raises(self):
        rule = UXURule(
            rule_id="UXU-IS-001", pillar="input_sanitization",
            severity="high", title="Dup", description="Dup",
            patterns=["x"], suggestion="Fix",
        )
        with pytest.raises(ValueError, match="已存在"):
            register_custom_rule(rule)

    def test_load_from_json(self, tmp_path):
        import json
        f = tmp_path / "custom-rules.json"
        rules_data = [
            {"rule_id": "JSON-RULE-001", "pillar": "sandbox_isolation",
             "severity": "critical", "title": "JSON规则",
             "description": "从JSON加载", "patterns": ["json_kw"],
             "suggestion": "修复"},
        ]
        f.write_text(json.dumps(rules_data), encoding="utf-8")
        count = load_custom_rules(str(f))
        assert count == 1
        assert any(r.rule_id == "JSON-RULE-001" for r in ALL_RULES)

    def test_scan_with_custom_rule(self, tmp_path):
        """验证自定义规则真的能扫描出结果。"""
        from tianlong.uxu import Scanner
        rule = UXURule(
            rule_id="SCAN-TEST-001", pillar="input_sanitization",
            severity="high", title="Scan test",
            description="Test", patterns=["AKIA"],
            suggestion="Fix",
        )
        register_custom_rule(rule)
        f = tmp_path / "test_code.py"
        f.write_text("secret_value = 'AKIA1234567890'\n")
        report = Scanner().scan(str(f))
        custom_findings = [x for x in report.findings if x.rule_id == "SCAN-TEST-001"]
        assert len(custom_findings) >= 1

    def test_load_nonexistent(self):
        with pytest.raises(FileNotFoundError):
            load_custom_rules("/nonexistent/path.json")
