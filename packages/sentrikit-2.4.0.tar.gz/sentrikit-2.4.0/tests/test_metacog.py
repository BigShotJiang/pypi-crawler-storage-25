"""tianlong.metacog — MetaCogTrigger 元认知触发器测试"""

from __future__ import annotations

import pytest

from tianlong.metacog import MetaCogTrigger, TriggerLevel, MetaCogReport


class TestTriggerLevel:
    def test_level_values(self):
        assert TriggerLevel.MILD.value == "mild"
        assert TriggerLevel.MODERATE.value == "moderate"
        assert TriggerLevel.CRITICAL.value == "critical"

    def test_level_order(self):
        """等级应该按 severity 升序"""
        levels = [TriggerLevel.MILD, TriggerLevel.MODERATE, TriggerLevel.CRITICAL]
        assert levels.index(TriggerLevel.MILD) < levels.index(TriggerLevel.MODERATE)


class TestMetaCogReport:
    def test_default_no_triggers(self):
        r = MetaCogReport()
        assert r.should_evolve is False
        assert r.max_level == "mild"
        assert r.overall_score == 0.0
        assert len(r.triggers) == 0

    def test_to_dict(self):
        r = MetaCogReport(timestamp="2026-01-01", should_evolve=True, overall_score=0.5)
        d = r.to_dict()
        assert d["should_evolve"] is True
        assert d["overall_score"] == 0.5

    def test_summary_line_triggered(self):
        from tianlong.metacog.core import TriggerResult
        r = MetaCogReport(
            timestamp="2026-01-01",
            should_evolve=True,
            max_level="critical",
            overall_score=0.9,
            triggers=[
                TriggerResult(signal_name="test_signal", triggered=True, level=TriggerLevel.CRITICAL, score=0.9),
            ],
        )
        summary = r.summary_line
        assert "触发" in summary
        assert "test_signal" in summary

    def test_summary_line_no_trigger(self):
        r = MetaCogReport(overall_score=0.05)
        summary = r.summary_line
        assert "无触发" in summary


class TestMetaCogTrigger:
    def test_init(self):
        trigger = MetaCogTrigger()
        assert trigger is not None

    def test_evaluate_normal(self):
        """正常状态（无退化）"""
        trigger = MetaCogTrigger()
        r = trigger.evaluate(
            success_rate_7d=0.95, success_rate_3d=0.95, success_rate_1d=1.0,
            days_since_last_improvement=0, repeat_error_count=0,
        )
        assert r.should_evolve is False
        assert r.max_level == "mild"

    def test_evaluate_critical_degradation(self):
        """严重退化状态"""
        trigger = MetaCogTrigger()
        r = trigger.evaluate(
            success_rate_7d=0.5, success_rate_3d=0.3, success_rate_1d=0.2,
            days_since_last_improvement=14, repeat_error_count=10,
        )
        assert r.should_evolve is True
        assert r.overall_score > 0.15

    def test_evaluate_moderate_stagnation(self):
        """中等停滞状态"""
        trigger = MetaCogTrigger()
        r = trigger.evaluate(
            success_rate_7d=0.9, success_rate_3d=0.9, success_rate_1d=1.0,
            days_since_last_improvement=14, repeat_error_count=0,
        )
        # stagnation 14天 -> moderate, 但success_rate正常
        assert len(r.triggers) == 5

    def test_evaluate_repeat_failures(self):
        """重复失败"""
        trigger = MetaCogTrigger()
        r = trigger.evaluate(
            success_rate_7d=0.9, success_rate_3d=0.9, success_rate_1d=1.0,
            days_since_last_improvement=0, repeat_error_count=5,
        )
        triggers = r.to_dict()["triggers"]
        repeat = [t for t in triggers if t["signal_name"] == "repeat_failure"]
        assert len(repeat) == 1
        assert repeat[0]["level"] == "critical"

    def test_get_history_no_evaluations(self):
        trigger = MetaCogTrigger()
        assert trigger.get_history() == []

    def test_get_history_after_evaluation(self):
        trigger = MetaCogTrigger()
        trigger.evaluate(
            success_rate_7d=1.0, success_rate_3d=1.0, success_rate_1d=1.0,
            days_since_last_improvement=0, repeat_error_count=0,
        )
        history = trigger.get_history()
        assert len(history) == 1
        assert "overall_score" in history[0]
