"""tianlong.metaevolve — MetaEVOLVE 元修改器测试

注意：完整 MetaEVOLVE 能力需企业版 TIANLONG_API_KEY。
社区版垫片提供基础数据结构和方法签名兼容。
"""
from __future__ import annotations

import pytest

from tianlong.metaevolve import MetaEVOLVE, ChangeRecord, MetaEvolveReport, StrategySuggestion


class TestChangeRecord:
    def test_default(self):
        c = ChangeRecord()
        assert c.verdict == "PENDING"
        assert c.judge_grade == "D"

    def test_to_dict_access(self):
        c = ChangeRecord(proposal_id="p001", verdict="HIT")
        assert c.proposal_id == "p001"
        assert c.verdict == "HIT"


class TestMetaEvolveReport:
    def test_default(self):
        r = MetaEvolveReport()
        assert r.hit_rate == 0.0
        assert r.total_changes == 0
        assert r.suggestions == []

    def test_to_dict(self):
        r = MetaEvolveReport(hit_rate=0.8, total_changes=20)
        d = r.to_dict()
        assert d["hit_rate"] == 0.8
        assert d["total_changes"] == 20

    def test_summary_line(self):
        r = MetaEvolveReport(hit_rate=0.5, total_changes=10)
        assert "50%" in r.summary_line


class TestMetaEVOLVE:
    """注：社区版 MetaEVOLVE 使用内存存储 _changes，兼容测试"""

    def test_init(self):
        m = MetaEVOLVE()
        assert m is not None

    def test_add_change(self):
        m = MetaEVOLVE()
        m.add_change(ChangeRecord(proposal_id="p001", verdict="HIT"))
        assert len(m.get_history()) == 1

    def test_add_changes(self):
        m = MetaEVOLVE()
        m.add_changes([
            ChangeRecord(proposal_id="p001", verdict="HIT"),
            ChangeRecord(proposal_id="p002", verdict="MISS"),
        ])
        assert len(m.get_history()) == 2

    def test_analyze_hit_rate_empty(self):
        m = MetaEVOLVE()
        result = m.analyze_hit_rate()
        assert result["hit_rate"] == 0.0

    def test_analyze_hit_rate_partial(self):
        m = MetaEVOLVE()
        m.add_changes([
            ChangeRecord(proposal_id="p001", verdict="HIT", judge_score=0.8, judge_grade="A"),
            ChangeRecord(proposal_id="p002", verdict="MISS", judge_score=0.6, judge_grade="B"),
            ChangeRecord(proposal_id="p003", verdict="HIT", judge_score=0.9, judge_grade="S"),
        ])
        result = m.analyze_hit_rate()
        assert result["hit_rate"] == pytest.approx(2/3, rel=0.01)

    def test_analyze_timing_empty(self):
        m = MetaEVOLVE()
        result = m.analyze_timing()
        assert isinstance(result, dict)

    def test_analyze_timing_with_data(self):
        m = MetaEVOLVE()
        m.add_changes([
            ChangeRecord(proposal_id="p001", verdict="HIT", trigger_source="cron"),
            ChangeRecord(proposal_id="p002", verdict="MISS", trigger_source="cron"),
            ChangeRecord(proposal_id="p003", verdict="HIT", trigger_source="ralph_loop"),
        ])
        timing = m.analyze_timing()
        assert "cron" in timing
        assert timing["cron"] == 0.5

    def test_calibrate_judge_insufficient(self):
        m = MetaEVOLVE()
        result = m.calibrate_judge()
        assert result["status"] == "insufficient_data"

    def test_calibrate_judge_with_data(self):
        m = MetaEVOLVE()
        for i in range(12):
            m.add_change(ChangeRecord(proposal_id=f"p{i:03d}", verdict="HIT", judge_grade="A", judge_score=0.8))
        result = m.calibrate_judge()
        assert "error_rate" in result
        assert result["error_rate"] == 0.0

    def test_generate_strategy_advice_empty(self):
        m = MetaEVOLVE()
        report = m.generate_strategy_advice()
        assert isinstance(report, MetaEvolveReport)
        assert report.total_changes == 0

    def test_generate_strategy_advice_with_low_hitrate(self):
        m = MetaEVOLVE()
        for i in range(10):
            m.add_change(ChangeRecord(proposal_id=f"p{i:03d}", verdict="MISS", judge_grade="A", trigger_source="cron"))
        report = m.generate_strategy_advice()
        assert report.hit_rate == 0.0
        types = [s.suggestion_type for s in report.suggestions]
        assert "threshold_tune" in types

    def test_get_history(self):
        m = MetaEVOLVE()
        m.add_change(ChangeRecord(proposal_id="p001", verdict="HIT"))
        m.add_change(ChangeRecord(proposal_id="p002", verdict="MISS"))
        history = m.get_history(limit=10)
        assert len(history) == 2
        assert history[0]["proposal_id"] == "p001"
