"""tianlong.agent — 测试"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from tianlong.agent import TianlongAgent, AgentStatus


class TestAgentStatus:
    def test_defaults(self):
        s = AgentStatus()
        assert s.status == "stopped"

    def test_to_dict(self):
        s = AgentStatus(status="running", pid=12345, loops_completed=3)
        d = s.to_dict()
        assert d["status"] == "running"
        assert d["pid"] == 12345

    def test_to_json(self):
        s = AgentStatus()
        data = json.loads(s.to_json())
        assert "status" in data


class TestTianlongAgent:
    def test_init(self):
        agent = TianlongAgent()
        assert agent._status.status == "stopped"
        assert agent._loop_count == 0

    def test_start_stop(self):
        agent = TianlongAgent(schedule={"check_interval": 1})  # 1s 间隔加快测试
        agent.start()
        assert agent._status.status == "running"
        assert agent._thread is not None
        assert agent._thread.is_alive()

        agent.stop()
        # 等待线程终止（1s 睡眠间隔所以很快）
        agent._thread.join(timeout=3)
        assert not agent._thread.is_alive()

    def test_status_method(self):
        agent = TianlongAgent(schedule={"check_interval": 1})
        agent.start()
        s = agent.status()
        assert s.status == "running"
        assert s.loops_completed == 0
        agent.stop()

    def test_run_once(self):
        """run-once CLI 的核心逻辑。"""
        from tianlong.evolution import RalphLoop, TaskResult, TaskStatus
        from datetime import datetime

        loop = RalphLoop()
        task = TaskResult(
            task_id="test-run-once",
            status=TaskStatus.SUCCESS,
            summary="测试单次进化",
        )
        report = loop.run(task)
        assert report.task_result is not None
        assert report.learn_context is not None
        assert report.evolve_output is not None

    def test_double_start(self, capsys):
        agent = TianlongAgent(schedule={"check_interval": 1})
        agent.start()
        agent.start()  # 第二次应该提示已在运行
        captured = capsys.readouterr()
        assert "已在运行" in captured.err
        agent.stop()


class TestCLI:
    def test_start_stop_cli(self):
        from tianlong.agent.daemon import main, _agent as global_agent
        import tianlong.agent.daemon as daemon
        # 手动创建并注入全局 agent
        from tianlong.agent import TianlongAgent
        agent = TianlongAgent(schedule={"check_interval": 1})
        agent.start()
        daemon._agent = agent
        rc = main(["stop"])
        assert rc == 0

    def test_status_cli(self, capsys):
        from tianlong.agent.daemon import main
        main(["status"])
        captured = capsys.readouterr()
        assert "状态" in captured.out

    def test_status_json(self, capsys):
        from tianlong.agent.daemon import main
        rc = main(["status", "-o", "json"])
        captured = capsys.readouterr()
        assert rc == 0
        data = json.loads(captured.out)
        assert "status" in data

    def test_run_once_cli(self, capsys, tmp_path):
        from tianlong.agent.daemon import main
        rc = main(["run-once", "--project-dir", str(tmp_path)])
        captured = capsys.readouterr()
        # 无项目文件时也能运行
        assert rc in (0, 1)

    def test_run_once_json(self, capsys, tmp_path):
        from tianlong.agent.daemon import main
        rc = main(["run-once", "--project-dir", str(tmp_path), "-o", "json"])
        captured = capsys.readouterr()
        assert rc in (0, 1)
