# SentriKit — Quick Start Guide

## Install
```bash
pip install sentrikit
```

## 1. Health Check
```bash
SentriKit-monitor -o html > health.html
```
Opens a clean HTML report showing the health of your Agent project directory.

## 2. Security Audit
```bash
SentriKit-uxu scan . --severity high
```
Scans all Python/YAML files in your project against 30 security rules (IS + SI + PM).

## 3. One-Command Audit
```bash
SentriKit-audit -d . > audit.html
```
Integrates health check + security audit + safety guard + evolution judge into one report.

## 4. Management Dashboard / 管理后台

```bash
SentriKit-admin --serve --port 9901
# Open http://localhost:9901 for an interactive web interface
# Features: health check, security scan, evolution evaluation, command dialog
```

## 5. Self-Diagnosis / 自检诊断

```bash
SentriKit-selfcheck           # Full integrity check (18 modules, 14 CLI commands)
SentriKit-selfcheck --quick   # Quick check (critical modules only)
SentriKit-selfcheck --json    # Machine-readable JSON output
```

## 6. Desktop Launcher / 桌面版

```bash
SentriKit-desktop                    # Start management dashboard + open browser
SentriKit-desktop --no-browser       # Server only (no browser)
# Open http://localhost:9901 in your browser
```

## 7. Competitive Intelligence / 竞品情报

```bash
SentriKit-compintel list                  # List tracked competitors
SentriKit-compintel sync                  # Fetch latest intelligence
SentriKit-compintel report                # Generate HTML report
SentriKit-compintel report --format markdown
SentriKit-compintel add NewCo --url https://newco.ai
```

## 8. CI/CD Integration
Add to `.github/workflows/SentriKit-audit.yml`:
```yaml
steps:
  - uses: actions/checkout@v4
  - uses: actions/setup-python@v5
    with: { python-version: '3.12' }
  - run: pip install sentrikit
  - run: SentriKit-audit -d . -o html > audit.html
```

## 5. Agent Daemon (Self-Learning Loop)
```bash
# Run one evolution cycle
SentriKit-agent run-once

# Start background daemon
SentriKit-agent start --detach
SentriKit-agent status
SentriKit-agent stop
```

## Example: Scan a Project
```python
from SentriKit.uxu import Scanner

scanner = Scanner()
report = scanner.scan(".")

print(f"Score: {report.grade} ({report.score})")
for f in report.findings:
    print(f"  [{f.severity}] {f.rule_id}: {f.title}")
```

## Example: Safety Guard
```python
from SentriKit.safety import SafetyGuard, ChangeType, DEFAULT_RULES

guard = SafetyGuard(rules=DEFAULT_RULES)
result = guard.check(action=ChangeType.DELETE, target="config.yaml")
if not result.allowed:
    print(f"Blocked: {result.reason}")
```

## Example: Evolution Judge
```python
from SentriKit.judge import RuleBasedJudge

judge = RuleBasedJudge()
result = judge.evaluate(proposal_summary="优化搜索流程")
print(f"Grade: {result.grade} (Score: {result.total_score})")
```

## Example: Global Dashboard
```python
from SentriKit.dashboard import build_dashboard

html = build_dashboard(project_dir=".")
with open("dashboard.html", "w") as f:
    f.write(html)
```
