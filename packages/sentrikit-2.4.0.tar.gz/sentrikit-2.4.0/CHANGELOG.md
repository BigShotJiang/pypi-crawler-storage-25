# Changelog / 变更日志

格式基于 [Keep a Changelog](https://keepachangelog.com/)。
版本号遵循 [Semantic Versioning](https://semver.org/)。

## 1.7.0 (2026-04-30)

### UXU 质量升级 (v2 评分模型 + AST语义确认)

#### 评分模型升级 (score.py v2)
- **动态衰减扣分** — 同一规则多次触发时，第二次起扣分衰减70%（×0.3），避免同一问题重复扣分
- **Pillar明细输出** — `to_dict()` 新增 `pillars` 字段，包含每柱的 score/grade/findings/top_rules
- **薄弱环节标识** — 新增 `weakest_pillar` 字段，直接指出最需要加固的 pillar
- **规则频率统计** — 每个 pillar 记录 top N 最频繁触发的规则 ID

#### AST语义确认 (ast.py v2)
- **`has_exec_call()`** — AST确认是否存在真正的 exec() 调用（非注释/字符串中的关键字）
- **`has_eval_call()`** — AST确认 eval() 调用
- **`has_subprocess_call()`** — AST确认 subprocess.run/Popen 调用
- **`has_string_concat_in_call()`** — AST确认函数调用中有 f-string 拼接（Prompt注入检测）
- **`count_eval_occurrences()`** — 精确统计 eval/exec 出现次数

### 技术细节
- 91 UXU测试 + 722全量测试全部通过，零回归
- 纯标准库零依赖，MIT 开源 (2026-04-29)

### 新增
- 🧪 **测试覆盖补全** — 6个模块新增专有测试：admin, dgmh, metacog, metaevolve, onlinestate, sales
  - 测试总数从 **638 → 722**（+84测试）
  - admin: 10测试（HTML存在性、CLI参数解析、可用命令列表）
  - dgmh: 24测试（ActivationStatus、SafetyShield、DGOrchestrator完整覆盖）
  - metacog: 13测试（TriggerLevel、MetaCogReport序列化、退化检测场景）
  - metaevolve: 15测试（命中率分析、时机分析、Judge校准、策略建议）
  - onlinestate: 8测试（在线/离线状态管理、快照、文件持久化）
  - sales: 12测试（数据结构、预设客户、模板、Enterprise许可门控）

### 文档更新
- **README.md** — 全面同步：修复"15 CLI→14 CLI"、"500→722测试"、"30→32 UXU规则"、"19→18模块"
  - 新增 admin 和 selfcheck CLI 命令及 Python API 示例
  - 新增 SalesPipeline 和 SelfCheck API 示例
- **CLI_REFERENCE.md** — 新增 SentriKit-admin、SentriKit-selfcheck、SentriKit-config 三个命令文档
- **QUICKSTART.md** — 新增管理后台和自检诊断快速入门
 
### 改进
- 模块覆盖率从 63%（12/19）提升到 **95%**（18/19，仅 __pycache__ 不含代码）

### 技术细节
- 18 Python 模块，14 CLI 命令
- 722 测试全部通过，零失败
- 全量测试运行 50.69s（v1.2.0 为 51.32s，维持一致）
- 纯标准库零依赖，MIT 开源

## 1.2.0 (2026-04-29)

### 新增
- 🆕 **管理后台** (`SentriKit-admin`) — 基于纯标准库 `http.server` 的交互式 Web 管理界面
  - 一键安全扫描、健康检查、进化评估
  - 实时仪表盘：Health / UXU / Judge / MetaCog / 进化趋势图
  - 自动每30秒刷新，全中文界面
- 🆕 **自检工具** (`SentriKit-selfcheck`) — 一键验证安装完整性
  - 检查版本一致性、模块加载、CLI 注册
  - 快速模式（`--quick`）和 JSON 输出（`--json`）
- 🆕 `.gitignore` — 完整的 Python 项目忽略规则

### 改进
- 版本号统一：代码 `__version__` = pyproject.toml = pip metadata，
  全部同步到 **1.2.0**
- `__init__.py` 模块清单全面更新：修复重复行、补齐缺失模块
  （researchengine, selfmodel, metaevolve, dgmh, sales, admin）
- 更新 `tests/test_dashboard.py` 许可证枚举测试，与代码同步
- 清理项目根目录下 17 个杂散的调试/修复/总结文件

### 技术细节
- 18 个 Python 模块（+1: admin）
- 14 个 CLI 命令（+2: SentriKit-admin, SentriKit-selfcheck）
- 638 测试全部通过，零失败
- 纯标准库零依赖，MIT 开源

## 1.0.0 (2026-04-27)

- MIT License — 100% free and open source
- 500 passing tests
- 19 Python modules
- 15 CLI commands
- UXU: 30 security rules (IS + SI + PM)
- Safety Guard: 6 red-line rules (R1-R6, including legal compliance)
- Evolution Engine: SelfLearning + RalphLoop + GEPA
- ResearchEngine: 5 research types + 4-level search chain
- SelfModel: Capability profile + SelfGraph + decision log
- MetaEVOLVE: Hit rate analysis + timing optimization + judge calibration
- DGM-H: Meta-cognition orchestrator + safety shield (M1-M6)
- SentriKitAgent: Background daemon with auto evolution
- Dashboard: Dark-mode HTML with health/security/evolution data
- Full audit: `SentriKit-audit` one-command integration
- CI/CD: GitHub Action composite action
- Bilingual: Chinese/English throughout
