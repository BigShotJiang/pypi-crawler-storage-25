"""tianlong.metaevolve — MetaEVOLVE 元修改器

v2.0: 社区版通过 enterprise_client + LocalFallback 提供基础进化统计。
企业版激活 SENTRIKIT_API_KEY 后，调用服务端 API 获得命中率分析与策略建议。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from ..enterprise_client import SentriKitEnterprise, is_enterprise
from dataclasses import dataclass, field


_HAS_METAEVOLVE = is_enterprise()
_METAEVOLVE_IMPORT_ERROR = "" if _HAS_METAEVOLVE else "社区版模式：设置 SENTRIKIT_API_KEY 激活企业版"


@dataclass
class ChangeRecord:
    """变更记录"""
    proposal_id: str = ""
    verdict: str = "PENDING"  # HIT / MISS / PENDING
    trigger_source: str = "manual"
    judge_grade: str = "D"
    judge_score: float = 0.3
    timestamp: str = ""


@dataclass
class StrategySuggestion:
    """策略建议"""
    suggestion_type: str = ""
    target: str = ""
    reason: str = ""
    current_value: str = ""
    suggested_value: str = ""
    priority: int = 0


@dataclass
class MetaEvolveReport:
    """元进化报告"""
    hit_rate: float = 0.0
    total_changes: int = 0
    suggestions: list = field(default_factory=list)
    timing: Dict[str, float] = field(default_factory=dict)
    calibrations: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = ""

    @property
    def summary_line(self) -> str:
        """概要行"""
        if self.total_changes == 0:
            return "无变更记录"
        return f"命中率 {self.hit_rate:.0%}（{self.total_changes}次）"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "hit_rate": self.hit_rate,
            "total_changes": self.total_changes,
            "suggestions": [s.__dict__ if hasattr(s, '__dict__') else s for s in self.suggestions],
            "timing": self.timing,
        }


class MetaEVOLVE:
    """MetaEVOLVE 元修改器（社区版 / 企业版自动切换）

    社区版：LocalFallback 提供基础统计（命中率计数）
    企业版：服务端全量分析（命中率趋势、策略建议、瓶颈检测）
    """

    MIN_CHANGES_FOR_CALIBRATION = 10

    def __init__(self, api_key: Optional[str] = None):
        self._enterprise = SentriKitEnterprise(api_key=api_key)
        self._changes: List[ChangeRecord] = []

    def analyze(self, change_records: List[Dict[str, Any]]) -> Dict[str, Any]:
        return self._enterprise.metaevolve_analyze(change_records)

    def add_change(self, record: ChangeRecord) -> None:
        """添加一条变更记录"""
        self._changes.append(record)

    def add_changes(self, records: List[ChangeRecord]) -> None:
        """批量添加变更记录"""
        self._changes.extend(records)

    def analyze_hit_rate(self) -> Dict[str, Any]:
        """分析命中率"""
        if not self._changes:
            return {"hit_rate": 0.0, "total": 0, "mode": "community"}
        hits = sum(1 for c in self._changes if c.verdict == "HIT")
        return {
            "hit_rate": hits / len(self._changes),
            "total": len(self._changes),
            "hits": hits,
            "mode": "community",
        }

    def analyze_timing(self) -> Dict[str, float]:
        """按触发源分析命中率"""
        from collections import defaultdict
        by_source: Dict[str, list] = defaultdict(list)
        for c in self._changes:
            by_source[c.trigger_source].append(c.verdict == "HIT")
        return {
            source: sum(results) / len(results)
            for source, results in by_source.items()
        }

    def calibrate_judge(self) -> Dict[str, Any]:
        """校准 Judge 评分"""
        if len(self._changes) < self.MIN_CHANGES_FOR_CALIBRATION:
            return {"status": "insufficient_data", "required": self.MIN_CHANGES_FOR_CALIBRATION}
        errors = sum(1 for c in self._changes
                     if (c.judge_grade in ("A", "B") and c.verdict == "MISS")
                     or (c.judge_grade in ("D", "F") and c.verdict == "HIT"))
        return {
            "status": "calibrated",
            "error_rate": errors / len(self._changes),
            "mode": "community",
        }

    def generate_strategy_advice(self) -> MetaEvolveReport:
        """生成策略建议"""
        report = MetaEvolveReport(total_changes=len(self._changes))
        if self._changes:
            report.timing = self.analyze_timing()
            if report.hit_rate < 0.3:
                report.suggestions.append(StrategySuggestion(
                    suggestion_type="threshold_tune", target="JudgeScore阈值",
                    reason="命中率低，建议放宽评分阈值",
                    priority=1,
                ))
            if report.hit_rate == 0:
                report.suggestions.append(StrategySuggestion(
                    suggestion_type="review_criteria", target="评判标准",
                    reason="全部变更未被采纳，需要审视评判标准",
                    priority=2,
                ))
        return report

    def get_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取变更历史"""
        records = [{
            "proposal_id": c.proposal_id,
            "verdict": c.verdict,
            "trigger_source": c.trigger_source,
            "judge_grade": c.judge_grade,
            "judge_score": c.judge_score,
            "timestamp": c.timestamp,
        } for c in self._changes[-limit:]]
        return records

    @property
    def is_enterprise(self) -> bool:
        return self._enterprise.is_enterprise


__all__ = [
    "MetaEVOLVE", "MetaEvolveReport",
    "ChangeRecord", "StrategySuggestion",
    "_HAS_METAEVOLVE", "_METAEVOLVE_IMPORT_ERROR",
]
