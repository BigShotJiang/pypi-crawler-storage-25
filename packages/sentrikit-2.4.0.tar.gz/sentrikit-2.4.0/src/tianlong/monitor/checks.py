"""tianlong.monitor.checks — 健康检查核心模块

数据结构定义 + 检查基类 + 内置检查器 + 运行入口。
所有检查为只读操作，不修改任何文件。
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Literal, Optional, Type


# ── 数据模型 ──────────────────────────────────────────


@dataclass
class CheckResult:
    """单次检查的结果"""

    name: str
    status: Literal["ok", "warning", "error"]
    message: str
    details: Optional[Dict] = None

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class HealthReport:
    """完整健康报告"""

    timestamp: str
    project_dir: str
    overall: Literal["healthy", "warning", "error"]
    checks: List[CheckResult]
    summary: Dict = field(default_factory=dict)

    def __post_init__(self):
        ok_count = sum(1 for c in self.checks if c.status == "ok")
        warn_count = sum(1 for c in self.checks if c.status == "warning")
        err_count = sum(1 for c in self.checks if c.status == "error")
        self.summary = {
            "total": len(self.checks),
            "ok": ok_count,
            "warning": warn_count,
            "error": err_count,
        }

    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "project_dir": self.project_dir,
            "overall": self.overall,
            "summary": self.summary,
            "checks": [c.to_dict() for c in self.checks],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)

    @property
    def exit_code(self) -> int:
        if any(c.status == "error" for c in self.checks):
            return 2
        if any(c.status == "warning" for c in self.checks):
            return 1
        return 0


# ── 检查基类 ──────────────────────────────────────────


class BaseCheck(ABC):
    """所有检查器的基类。

    子类只需实现 run() 方法，返回 CheckResult。
    通过 project_dir 访问目标 Agent 项目目录。
    """

    def __init__(self, project_dir: Path):
        self.project_dir = Path(project_dir)

    @abstractmethod
    def run(self) -> CheckResult:
        ...


# ── 检查器注册表 ──────────────────────────────────────

_registry: List[Type[BaseCheck]] = []


def register_check(check_cls: Type[BaseCheck]) -> Type[BaseCheck]:
    """注册自定义检查器到全局注册表。

    用法:
        @register_check
        class MyCheck(BaseCheck):
            def run(self) -> CheckResult:
                ...

    企业版功能：自定义检查项需要企业版授权（TIANLONG_ENTERPRISE=1）。
    开源版包含 8 项内置检查，个人使用足够。
    """
    if not os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes"):
        return check_cls  # 静默跳过，不报错
    if check_cls not in _registry:
        _registry.append(check_cls)
    return check_cls


def get_registered_checks() -> List[Type[BaseCheck]]:
    """获取所有已注册的检查器（内置 + 自定义）"""
    return list(_registry)


# ── 8 项基础检查（开源版） ──────────────────────────────


class WorkingMemoryCheck(BaseCheck):
    """检查1: working-memory 行数是否超过阈值（默认200行）"""

    threshold: int = 200

    def run(self) -> CheckResult:
        fp = self.project_dir / "brain" / "working-memory.md"
        if not fp.exists():
            return CheckResult(
                name="working-memory",
                status="warning",
                message="working-memory.md 文件不存在",
            )

        lines = sum(1 for _ in open(fp, encoding="utf-8"))
        ok = lines <= self.threshold

        return CheckResult(
            name="working-memory",
            status="ok" if ok else "warning",
            message=f"working-memory {lines}行, 阈值{self.threshold}行"
            + (" — ⚠️ 建议归档" if not ok else ""),
            details={"lines": lines, "threshold": self.threshold},
        )


class TaskQueueCheck(BaseCheck):
    """检查2: task-queue 是否有 PENDING 超过24小时的任务"""

    stale_hours: int = 24

    def run(self) -> CheckResult:
        fp = self.project_dir / "brain" / "task-queue.md"
        if not fp.exists():
            return CheckResult(
                name="task-queue",
                status="warning",
                message="task-queue.md 文件不存在",
            )

        content = fp.read_text(encoding="utf-8")
        now = datetime.now()
        stale: List[Dict] = []

        blocks = content.split("## [")
        for block in blocks:
            if "PENDING" not in block:
                continue
            m = re.search(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2})", block)
            if m:
                try:
                    t = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M")
                    hours = (now - t).total_seconds() / 3600
                    if hours > self.stale_hours:
                        stale.append({"age_hours": round(hours, 1), "preview": block.strip()[:100]})
                except ValueError:
                    pass

        return CheckResult(
            name="task-queue",
            status="ok" if not stale else "warning",
            message=f"积压超过24h的任务: {len(stale)}个",
            details={"stale_tasks": stale[:10]},
        )


class ErrorLogCheck(BaseCheck):
    """检查3: error-log 中未处理的错误"""

    def run(self) -> CheckResult:
        fp = self.project_dir / "brain" / "error-log.md"
        if not fp.exists():
            return CheckResult(name="error-log", status="ok", message="无错误日志文件")

        content = fp.read_text(encoding="utf-8")

        # 匹配错误条目：优先 ## [状态] 格式，兼容 ## 标题格式
        # 排除 ## 格式说明、## 状态定义、## 当前记录、## 已归档 等非条目标题
        ERROR_SECTION_HEADERS = {"## 格式说明", "## 状态定义", "## 当前记录",
                                 "## 已归档", "## 优先级规则", "## 队列管理",
                                 "## 失败分类说明"}
        lines = content.split("\n")
        errors = []
        for l in lines:
            stripped = l.strip()
            if stripped.startswith("## [") or (
                stripped.startswith("## ") and stripped not in ERROR_SECTION_HEADERS
                and not stripped.startswith("## 当前") and not stripped.startswith("## 已归档")
            ):
                errors.append(stripped)

        unresolved = [e for e in errors if "已解决" not in e]
        # 检查当前记录区域是否有 [待处理]
        # 如果有 ## 已归档 区域，只考虑当前区域中的错误
        if "## 已归档" in content:
            current_section = content.split("## 已归档")[0]
            has_pending = "[待处理]" in current_section
            if not has_pending:
                unresolved = [e for e in errors if "[待处理]" in e]
        # 没有 ## 已归档 区域时，unresolved 保持最初的计算结果

        return CheckResult(
            name="error-log",
            status="ok" if not unresolved else "warning",
            message=f"错误总数: {len(errors)}, 未处理: {len(unresolved)}",
            details={"total": len(errors), "unresolved": len(unresolved)},
        )


class SummaryFileCheck(BaseCheck):
    """检查4: 根目录 task-summary 文件数量"""

    threshold: int = 10

    def run(self) -> CheckResult:
        files = sorted(self.project_dir.glob("task-summary_*.md"))
        count = len(files)

        return CheckResult(
            name="task-summary",
            status="ok" if count <= self.threshold else "warning",
            message=f"根目录 {count} 个task-summary文件" + (" — ⚠️ 建议归档" if count > self.threshold else ""),
            details={"count": count, "threshold": self.threshold, "files": [f.name for f in files]},
        )


class IntegrityCheck(BaseCheck):
    """检查5: 核心文件完整性"""

    required_files: List[str] = [
        "AGENTS.md", "SOUL.md", "USER.md", "MEMORY.md", "IDENTITY.md",
        "brain/brain-core.md", "brain/safety-guard.md",
        "brain/working-memory.md", "brain/task-queue.md",
    ]

    def run(self) -> CheckResult:
        missing = []
        for f in self.required_files:
            if not (self.project_dir / f).exists():
                missing.append(f)

        return CheckResult(
            name="integrity",
            status="ok" if not missing else "error",
            message=f"核心文件 {len(self.required_files)} 个, 缺失 {len(missing)} 个"
            + (f": {missing}" if missing else ""),
            details={"total": len(self.required_files), "missing": missing},
        )


# ── 新增系统检查器 ────────────────────────────────────


class PythonVersionCheck(BaseCheck):
    """检查6: Python 版本是否满足要求（默认 >= 3.11）"""

    min_version: tuple = (3, 11)

    def run(self) -> CheckResult:
        current = sys.version_info[:2]
        ok = current >= self.min_version

        return CheckResult(
            name="python-version",
            status="ok" if ok else "error",
            message=f"Python {sys.version.split()[0]}, 要求 >= {'.'.join(map(str, self.min_version))}",
            details={
                "current": f"{current[0]}.{current[1]}",
                "required": f"{self.min_version[0]}.{self.min_version[1]}",
            },
        )


class DiskSpaceCheck(BaseCheck):
    """检查7: 磁盘空间是否充足（默认告警阈值 1GB）"""

    warn_gb: int = 1

    def run(self) -> CheckResult:
        try:
            usage = shutil.disk_usage(self.project_dir)
            free_gb = usage.free / (1024 ** 3)
            ok = free_gb >= self.warn_gb

            return CheckResult(
                name="disk-space",
                status="ok" if ok else "warning",
                message=f"剩余磁盘 {free_gb:.1f}GB" + (" — ⚠️ 空间不足" if not ok else ""),
                details={"free_gb": round(free_gb, 1), "total_gb": round(usage.total / (1024 ** 3), 1)},
            )
        except Exception as e:
            return CheckResult(name="disk-space", status="warning", message=f"无法检查磁盘: {e}")


class CronStatusCheck(BaseCheck):
    """检查8: Cron 任务是否正常运行（检查 memory/health 目录最近是否有日志）"""

    max_hours: int = 2

    def run(self) -> CheckResult:
        health_dir = self.project_dir / "memory" / "health"
        if not health_dir.exists():
            return CheckResult(
                name="cron-status",
                status="warning",
                message="memory/health 目录不存在，Cron 可能未运行",
            )

        jsons = sorted(health_dir.glob("*.json"), reverse=True)
        if not jsons:
            return CheckResult(
                name="cron-status",
                status="warning",
                message="memory/health 目录为空，Cron 从未运行",
            )

        latest = jsons[0]
        mtime = datetime.fromtimestamp(latest.stat().st_mtime)
        hours_ago = (datetime.now() - mtime).total_seconds() / 3600
        ok = hours_ago <= self.max_hours

        return CheckResult(
            name="cron-status",
            status="ok" if ok else "warning",
            message=f"最近Cron日志: {latest.name} ({hours_ago:.1f}小时前)"
            + (" — ⚠️ 超过2小时无新日志" if not ok else ""),
            details={"latest_file": latest.name, "hours_ago": round(hours_ago, 1)},
        )


# ── CodeVigil 安全扫描检查器 ────────────────────────────────


class UxuSecurityCheck(BaseCheck):
    """CodeVigil 安全扫描检查器。

    在健康检查时一并运行 CodeVigil 安全扫描，检测代码安全问题。
    轻量运行（只扫最近变更的文件），不阻塞健康检查主流程。
    """

    def __init__(self, project_dir: Path):
        super().__init__(project_dir)
        self.max_findings_warning = 5  # 超过此数标记为 warning
        self.max_findings_error = 20   # 超过此数标记为 error

    def run(self) -> CheckResult:
        project_dir = self.project_dir

        # 确定扫描目标：tianlong-toolkit 源码目录
        scan_target = project_dir / "src" / "tianlong"
        if not scan_target.exists():
            scan_target = project_dir
        if not scan_target.exists():
            return CheckResult(
                name="uxu-security",
                status="ok",
                message="扫描目标不存在，跳过",
            )

        try:
            from tianlong.uxu import Scanner
            scanner = Scanner(min_severity="low")
            report = scanner.scan(str(scan_target))

            findings = report.findings
            total = len(findings)
            by_severity = {}
            for f in findings:
                by_severity[f.severity] = by_severity.get(f.severity, 0) + 1

            critical = by_severity.get("critical", 0)
            high = by_severity.get("high", 0)
            medium = by_severity.get("medium", 0)

            if critical > 0 or high > 0:
                status = "error"
                msg = f"发现 {total} 个安全问题 ({critical}个严重, {high}个高危)"
            elif total >= self.max_findings_error:
                status = "error"
                msg = f"安全问题数量过多: {total}个 (阈值{self.max_findings_error})"
            elif total >= self.max_findings_warning:
                status = "warning"
                msg = f"发现 {total} 个安全问题 (多为低危)"
            else:
                status = "ok"
                msg = f"安全扫描通过 ({total} 个发现)"

            # 记录详细发现（前5条）
            top_findings = []
            for f in findings[:5]:
                top_findings.append({
                    "rule": f.rule_id,
                    "severity": f.severity,
                    "file": f.file_path.split("/")[-1],
                    "line": f.line_number,
                })

            return CheckResult(
                name="uxu-security",
                status=status,
                message=msg,
                details={
                    "total_findings": total,
                    "by_severity": by_severity,
                    "score": report.score.total_score if hasattr(report.score, 'total_score') else None,
                    "grade": report.score.grade if hasattr(report.score, 'grade') else None,
                    "top_findings": top_findings,
                },
            )
        except ImportError:
            return CheckResult(
                name="uxu-security",
                status="ok",
                message="UXU 模块不可用（tianlong.uxu 未安装）",
            )
        except Exception as e:
            return CheckResult(
                name="uxu-security",
                status="warning",
                message=f"CodeVigil 扫描异常: {e}",
                details={"error": str(e)},
            )


# ── MetaCog 退化检测检查器 ────────────────────────────


class MetaCogDegradationCheck(BaseCheck):
    """MetaCog 退化检测检查器。

    在健康检查时运行 MetaCogTrigger 的 5 类触发信号：
    - 成功率波动
    - 停滞（无改进天数）
    - 重复错误
    - 外部信号（health-reports 中 error 级别报告）
    - 自检（长期无快照）
    """

    def run(self) -> CheckResult:
        try:
            from tianlong.metacog import MetaCogTrigger
            trigger = MetaCogTrigger()

            # 从 working-memory 采集数据
            wm_file = self.project_dir / "brain" / "working-memory.md"
            task_queue = self.project_dir / "brain" / "task-queue.md"
            error_log = self.project_dir / "brain" / "error-log.md"
            health_reports_dir = self.project_dir / "health-reports"
            judge_history = self.project_dir / "judge-history.json"

            # 1. 成功率：从 error-log 估算（只计"待处理"未解决错误）
            unresolved_errors = 0
            if error_log.exists():
                content = error_log.read_text(encoding="utf-8", errors="replace")
                unresolved_errors = content.count("## [待处理]")
                # 已解决的错误不纳入成功率计算
                error_count = max(0, content.count("## [") - content.count("## [已解决]"))

            # 近7天错误数（只计未解决）
            total_errors_7d = min(unresolved_errors, 20)
            success_rate_7d = max(0.0, 1.0 - total_errors_7d / 20.0)
            success_rate_3d = max(0.0, 1.0 - min(unresolved_errors, 10) / 15.0)
            success_rate_1d = 1.0 if unresolved_errors == 0 else max(0.0, 1.0 - unresolved_errors / 5.0)

            # 2. 停滞天数：从 working-memory 最后更新时间估算
            days_since_improvement = 0
            if wm_file.exists():
                mtime = datetime.fromtimestamp(wm_file.stat().st_mtime)
                days_since_improvement = (datetime.now() - mtime).days

            # 3. 重复错误计数：只计数当前记录中的未解决错误
            repeat_errors = 0
            if error_log.exists():
                content = error_log.read_text(encoding="utf-8", errors="replace")
                # 只计数当前记录区域中 [待处理] 的 ID 数量
                current_section = content.split("## 已归档")[0] if "## 已归档" in content else content
                repeat_errors = current_section.count("- ID:")

            # 4. 外部信号：health-reports 中最近是否有 error
            external_strength = 0.0
            if health_reports_dir.exists():
                reports = sorted(health_reports_dir.glob("*.json"), reverse=True)
                if reports:
                    try:
                        last = json.loads(reports[0].read_text(encoding="utf-8"))
                        if last.get("overall") == "error":
                            external_strength = 0.8
                        elif last.get("overall") == "warning":
                            external_strength = 0.4
                    except Exception:
                        pass

            # 执行 MetaCogTrigger 评估
            report = trigger.evaluate(
                success_rate_7d=success_rate_7d,
                success_rate_3d=success_rate_3d,
                success_rate_1d=success_rate_1d,
                days_since_last_improvement=days_since_improvement,
                repeat_error_count=repeat_errors,
                external_signal_strength=external_strength,
            )

            # 根据触发结果确定健康状态
            triggered_signals = [t for t in report.triggers if t.triggered]
            if report.should_evolve and report.max_level in ("moderate", "critical"):
                status = "warning"
                msg = f"退化检测: {report.summary_line}"
            elif report.should_evolve:
                status = "ok"
                msg = f"退化检测: {report.summary_line}（轻度）"
            else:
                status = "ok"
                msg = f"退化检测: {report.summary_line}"

            triggered_names = [t.signal_name for t in triggered_signals]

            return CheckResult(
                name="metacog-degradation",
                status=status,
                message=msg,
                details={
                    "should_evolve": report.should_evolve,
                    "overall_score": report.overall_score,
                    "max_level": report.max_level,
                    "triggered_signals": triggered_names,
                    "inputs": {
                        "success_rate_7d": round(success_rate_7d, 2),
                        "days_since_improvement": days_since_improvement,
                        "repeat_errors": repeat_errors,
                        "external_strength": round(external_strength, 2),
                    },
                },
            )
        except ImportError:
            return CheckResult(
                name="metacog-degradation",
                status="ok",
                message="MetaCog 模块不可用（tianlong.metacog 未安装）",
            )
        except Exception as e:
            return CheckResult(
                name="metacog-degradation",
                status="warning",
                message=f"MetaCog 检测异常: {e}",
                details={"error": str(e)},
            )


# ── 内置检查器列表 ─────────────────────────────────────

DEFAULT_CHECKS = [
    WorkingMemoryCheck,
    TaskQueueCheck,
    ErrorLogCheck,
    SummaryFileCheck,
    IntegrityCheck,
    PythonVersionCheck,
    DiskSpaceCheck,
    CronStatusCheck,
    UxuSecurityCheck,
    MetaCogDegradationCheck,
]

# 将内置检查器注册到全局注册表
for _cls in DEFAULT_CHECKS:
    register_check(_cls)


# ── 运行入口 ──────────────────────────────────────────


def run_all_checks(
    project_dir: Path,
    checks: Optional[List[Type[BaseCheck]]] = None,
) -> HealthReport:
    """运行所有检查，返回 HealthReport。

    Args:
        project_dir: 目标 Agent 项目的根目录路径。
        checks: 检查器类列表，默认使用所有已注册的检查器。

    Returns:
        HealthReport 包含所有检查结果。
    """
    check_classes = checks or get_registered_checks()
    results: List[CheckResult] = []

    for CheckCls in check_classes:
        checker = CheckCls(project_dir)
        try:
            result = checker.run()
        except Exception as e:
            result = CheckResult(
                name=CheckCls.__name__,
                status="error",
                message=f"执行异常: {e}",
            )
        results.append(result)

    has_error = any(r.status == "error" for r in results)
    has_warning = any(r.status == "warning" for r in results)
    overall = "error" if has_error else ("warning" if has_warning else "healthy")

    return HealthReport(
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        project_dir=str(project_dir),
        overall=overall,
        checks=results,
    )


def run_multi_project(project_dirs: List[Path]) -> Dict[str, HealthReport]:
    """批量检查多个项目。

    Args:
        project_dirs: 项目目录列表。

    Returns:
        Dict[str, HealthReport] — 项目路径 → HealthReport 映射。
    """
    return {str(d): run_all_checks(d) for d in project_dirs}


# ── 模块加载时注册开源版内置检查 ─────────────────────────

# 10 项内置检查（开源版），个人使用足够
# 8 项基础 + CodeVigil 安全扫描 + MetaCog退化检测
# 自定义检查项需企业版（TIANLONG_ENTERPRISE=1）
_builtin = {c for c in _registry}  # 已注册的（来自 @register_check，如有）
_all_builtin = [
    WorkingMemoryCheck, TaskQueueCheck, ErrorLogCheck,
    SummaryFileCheck, IntegrityCheck, PythonVersionCheck,
    DiskSpaceCheck, CronStatusCheck,
    UxuSecurityCheck, MetaCogDegradationCheck,
]
for cls in _all_builtin:
    if cls not in _builtin:
        _registry.append(cls)
