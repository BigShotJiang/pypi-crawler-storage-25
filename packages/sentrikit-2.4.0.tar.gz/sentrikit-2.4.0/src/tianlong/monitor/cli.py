"""tianlong.monitor.cli — 命令行入口

支持 `tianlong-monitor` 和 `python -m tianlong.monitor` 两种方式。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .checks import run_all_checks, run_multi_project


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tianlong-monitor",
        description="SentriKit — Agent 健康监控。检查目标 Agent 项目的各项健康指标。",
    )
    parser.add_argument(
        "--project-dir", "-d",
        type=str,
        default=".",
        help="目标 Agent 项目的根目录 (默认: 当前目录)",
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        choices=["text", "json", "html"],
        default="text",
        help="输出格式: text, json 或 html (默认: text)",
    )
    parser.add_argument(
        "--multi", "-m",
        type=str,
        nargs="+",
        default=None,
        help="批量检查多个项目目录，用空格分隔",
    )
    parser.add_argument(
        "--save", type=str, default=None,
        help="保存报告到文件路径 (默认: 不保存)",
    )
    return parser


def format_text(report) -> str:
    """格式化为人类可读的文本"""
    lines = []
    lines.append(f"SentriKit · 健康检查报告")
    lines.append(f"时间: {report.timestamp}")
    lines.append(f"项目: {report.project_dir}")
    lines.append(f"状态: {status_icon(report.overall)} {report.overall.upper()}")
    lines.append(f"检查: {report.summary['ok']}/{report.summary['total']} 通过 "
                 f"(warning={report.summary['warning']}, error={report.summary['error']})")
    lines.append("")

    for c in report.checks:
        icon = status_icon(c.status)
        lines.append(f"  {icon} {c.name}: {c.message}")

    lines.append("")
    lines.append(f"退出码: {report.exit_code}")
    return "\n".join(lines)


def format_multi_text(reports: dict) -> str:
    """格式化多项目报告"""
    lines = ["SentriKit · 多项目健康检查报告", f"时间: 见各项目报告", ""]
    for proj_path, report in reports.items():
        lines.append(f"{'='*50}")
        lines.append(f"项目: {proj_path}")
        lines.append(f"状态: {status_icon(report.overall)} {report.overall.upper()}")
        lines.append(f"检查: {report.summary['ok']}/{report.summary['total']} 通过")
        for c in report.checks:
            lines.append(f"  {status_icon(c.status)} {c.name}: {c.message}")
        lines.append("")
    return "\n".join(lines)


def status_icon(status: str) -> str:
    return {"ok": "✅", "warning": "⚠️", "error": "🔴"}.get(status, "❓")


def format_html(report) -> str:
    """格式化为 HTML 报告"""
    status_colors = {"healthy": "#22c55e", "warning": "#f59e0b", "error": "#ef4444"}
    check_colors = {"ok": "#22c55e", "warning": "#f59e0b", "error": "#ef4444"}
    color = status_colors.get(report.overall, "#6b7280")

    checks_html = ""
    for c in report.checks:
        cc = check_colors.get(c.status, "#6b7280")
        checks_html += f"""
        <tr>
            <td style="color:{cc}">{status_icon(c.status)}</td>
            <td>{c.name}</td>
            <td>{c.message}</td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>健康检查报告 - {report.project_dir}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 800px; margin: 40px auto; padding: 0 20px; background: #f8fafc; color: #1e293b; }}
h1 {{ font-size: 24px; margin-bottom: 8px; }}
.summary {{ background: white; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 24px; }}
.status {{ font-size: 32px; font-weight: bold; color: {color}; }}
.meta {{ color: #64748b; font-size: 14px; margin-top: 8px; }}
table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
th {{ background: #f1f5f9; text-align: left; padding: 12px 16px; font-size: 14px; color: #475569; }}
td {{ padding: 12px 16px; border-top: 1px solid #f1f5f9; font-size: 14px; }}
.footer {{ text-align: center; color: #94a3b8; font-size: 12px; margin-top: 24px; }}
</style>
</head>
<body>
    <h1>🔍 健康检查报告</h1>
    <div class="summary">
        <div class="status">{report.overall.upper()}</div>
        <div class="meta">
            项目: {report.project_dir}<br>
            时间: {report.timestamp}<br>
            检查: {report.summary['ok']}/{report.summary['total']} 通过
            (warning={report.summary['warning']}, error={report.summary['error']})
        </div>
    </div>
    <table>
        <tr><th></th><th>检查项</th><th>结果</th></tr>
        {checks_html}
    </table>
    <div class="footer">由 tianlong-toolkit v0.8.0 生成</div>
</body>
</html>"""


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.multi:
        # 批量模式
        projects = [Path(p).resolve() for p in args.multi]
        valid = {}
        for p in projects:
            if not p.exists():
                print(f"❌ 项目目录不存在: {p}", file=sys.stderr)
            else:
                valid[p] = True
        if not valid:
            return 3
        reports = run_multi_project(list(valid.keys()))

        if args.output == "json":
            output = {str(k): v.to_dict() for k, v in reports.items()}
            print(json.dumps(output, ensure_ascii=False, indent=2))
        else:
            print(format_multi_text(reports))

        # 多项目退出码：取最严重的一个
        exit_codes = [r.exit_code for r in reports.values()]
        return max(exit_codes)

    # 单项目模式
    project_dir = Path(args.project_dir).resolve()
    if not project_dir.exists():
        print(f"❌ 项目目录不存在: {project_dir}", file=sys.stderr)
        return 3

    report = run_all_checks(project_dir)

    if args.output == "json":
        output = report.to_json()
        print(output)
    elif args.output == "html":
        output = format_html(report)
        print(output)
    else:
        output = format_text(report)
        print(output)

    # 保存到文件（如果指定了 --save）
    if args.save:
        save_path = Path(args.save)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        save_path.write_text(output, encoding="utf-8")
        print(f"✅ 报告已保存: {save_path}", file=sys.stderr)

    return report.exit_code


if __name__ == "__main__":
    sys.exit(main())
