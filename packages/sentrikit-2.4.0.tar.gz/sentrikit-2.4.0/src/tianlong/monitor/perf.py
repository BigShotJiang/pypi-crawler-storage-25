"""tianlong.monitor.perf — 性能指标采集器

纯标准库，零依赖。提供运行耗时、函数调用统计、缓存命中率等指标采集。
"""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from functools import wraps
from typing import Any, Callable, Dict, List, Optional


# ── 性能指标类型 ────────────────────────────────────────────


@dataclass
class PerfMetric:
    """单条性能指标"""
    name: str                  # 指标名称（如模块名.函数名）
    count: int = 0             # 调用次数
    total_ms: float = 0.0       # 总耗时（毫秒）
    min_ms: float = 0.0         # 最短耗时
    max_ms: float = 0.0         # 最长耗时
    errors: int = 0             # 错误次数
    last_ms: float = 0.0        # 最近一次耗时
    last_ts: str = ""           # 最近一次时间戳

    @property
    def avg_ms(self) -> float:
        return round(self.total_ms / max(self.count, 1), 2)

    def record(self, elapsed_ms: float, error: bool = False) -> None:
        self.count += 1
        self.total_ms += elapsed_ms
        self.min_ms = min(self.min_ms, elapsed_ms) if self.count > 1 else elapsed_ms
        self.max_ms = max(self.max_ms, elapsed_ms)
        self.last_ms = elapsed_ms
        self.last_ts = datetime.now().strftime("%H:%M:%S")
        if error:
            self.errors += 1

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "count": self.count,
            "avg_ms": self.avg_ms,
            "min_ms": round(self.min_ms, 2),
            "max_ms": round(self.max_ms, 2),
            "total_ms": round(self.total_ms, 2),
            "errors": self.errors,
            "last_ms": round(self.last_ms, 2),
        }


# ── 性能采集器 ──────────────────────────────────────────


class PerfCollector:
    """性能数据采集器（全局单例）"""

    def __init__(self):
        self._metrics: Dict[str, PerfMetric] = {}
        self._enabled: bool = True

    @property
    def enabled(self) -> bool:
        return self._enabled

    def set_enabled(self, val: bool) -> None:
        self._enabled = val

    def record(self, name: str, elapsed_ms: float, error: bool = False) -> None:
        if not self._enabled:
            return
        if name not in self._metrics:
            self._metrics[name] = PerfMetric(name=name)
        self._metrics[name].record(elapsed_ms, error)

    def get_metric(self, name: str) -> Optional[PerfMetric]:
        return self._metrics.get(name)

    def get_all(self) -> List[Dict]:
        """获取所有指标摘要"""
        return sorted(
            [m.to_dict() for m in self._metrics.values()],
            key=lambda x: -x["total_ms"],
        )

    def get_summary(self) -> Dict:
        """获取性能摘要"""
        all_metrics = self.get_all()
        if not all_metrics:
            return {"total_calls": 0, "total_time_ms": 0, "metrics": []}
        return {
            "total_calls": sum(m["count"] for m in all_metrics),
            "total_time_ms": round(sum(m["total_ms"] for m in all_metrics), 2),
            "slowest": max(all_metrics, key=lambda x: x["avg_ms"]) if all_metrics else None,
            "metrics": all_metrics,
        }

    def reset(self) -> None:
        self._metrics.clear()


# ── 全局单例 ──────────────────────────────────────────

_collector: PerfCollector = PerfCollector()


def get_collector() -> PerfCollector:
    return _collector


# ── 装饰器 ──────────────────────────────────────────


def timed(name: Optional[str] = None) -> Callable:
    """性能计时装饰器

    用法:
        @timed()
        def my_function():
            ...

        @timed("custom_name")
        def my_function():
            ...
    """
    def decorator(func: Callable) -> Callable:
        metric_name = name or f"{func.__module__}.{func.__qualname__}"

        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                elapsed = (time.perf_counter() - start) * 1000
                _collector.record(metric_name, elapsed)
                return result
            except Exception:
                elapsed = (time.perf_counter() - start) * 1000
                _collector.record(metric_name, elapsed, error=True)
                raise
        return wrapper
    return decorator


def timed_method(name: Optional[str] = None) -> Callable:
    """类方法性能计时装饰器（自动跳过 disabled 状态）"""
    def decorator(func: Callable) -> Callable:
        metric_name = name or f"{func.__module__}.{func.__qualname__}"

        @wraps(func)
        def wrapper(self, *args, **kwargs):
            if not _collector.enabled:
                return func(self, *args, **kwargs)
            start = time.perf_counter()
            try:
                result = func(self, *args, **kwargs)
                elapsed = (time.perf_counter() - start) * 1000
                _collector.record(metric_name, elapsed)
                return result
            except Exception:
                elapsed = (time.perf_counter() - start) * 1000
                _collector.record(metric_name, elapsed, error=True)
                raise
        return wrapper
    return decorator
