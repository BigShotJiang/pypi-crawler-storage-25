"""python -m tianlong.monitor 入口"""

from .cli import main
import sys

sys.exit(main())
