"""tianlong.dgmh — DGM-H 元认知架构编排器

v2.0: 社区版通过 enterprise_client + LocalFallback 提供基础顺次编排。
企业版激活 SENTRIKIT_API_KEY 后，调用服务端 API 获得 M1-M6 完整元认知编排。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from ..enterprise_client import SentriKitEnterprise, is_enterprise


_HAS_DGMH = is_enterprise()
_DGMH_IMPORT_ERROR = "" if _HAS_DGMH else "社区版模式：设置 SENTRIKIT_API_KEY 激活企业版"


class ActivationStatus:
    """激活状态（社区版实现）"""
    def __init__(self, phase1_ready: bool = True, phase2_ready: bool = False,
                 phase3_ready: bool = False, judgestored: bool = False,
                 user_authorized: bool = False, safetyguard_stable: bool = False,
                 success_trails_ready: bool = False, gepa_verified: bool = True):
        self.success_trails_ready = success_trails_ready
        self.gepa_verified = gepa_verified
        self.safetyguard_stable = safetyguard_stable
        self.user_authorized = user_authorized
        self.judgestored = judgestored
        self.phase1_ready = phase1_ready
        self._phase2_override: Optional[bool] = None
        self._phase3_override: Optional[bool] = phase3_ready if phase3_ready else None

    @property
    def phase2_ready(self) -> bool:
        if self._phase2_override is not None:
            return self._phase2_override
        return self.judgestored

    @phase2_ready.setter
    def phase2_ready(self, value: bool) -> None:
        self._phase2_override = value

    @property
    def phase3_ready(self) -> bool:
        if self._phase3_override is not None:
            return self._phase3_override
        return (self.user_authorized and
                self.safetyguard_stable and self.success_trails_ready)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "phase1_ready": self.phase1_ready,
            "phase2_ready": self.phase2_ready,
            "phase3_ready": self.phase3_ready,
            "judgestored": self.judgestored,
            "user_authorized": self.user_authorized,
            "safetyguard_stable": self.safetyguard_stable,
            "success_trails_ready": self.success_trails_ready,
            "gepa_verified": self.gepa_verified,
        }


class SafetyShield:
    """SafetyShield 安全护栏（社区版简化）

    社区版：关键词级别过滤，M1 阻止 safety_guard 修改，M6 限制频率
    企业版：服务端语义级安全检测 M1-M6
    """

    def __init__(self, level: str = "M1"):
        self.level = level
        self._failures = 0
        self._rollback_paths: List[Dict[str, str]] = []
        self._outcomes: List[bool] = []
        self.should_rollback = False
        self._modifications: List[Dict[str, str]] = []
        self._last_modify_time: float = 0.0

    def check(self, action: str = "", target: str = "") -> Optional[str]:
        """安全检查"""
        if "safety_guard" in target or "safety-guard" in target:
            if self.level in ("M1", "M5"):
                return f"{self.level}: 不允许修改 {target}"
        if action == "create_safety_rule" or action == "new_rule":
            if self.level >= "M5":
                return f"{self.level}: 不允许新增规则"
            return f"{self.level}: 不允许新增规则"
        if action == "modify":
            import time
            now = time.time()
            if self._last_modify_time and now - self._last_modify_time < 0.1:
                return f"M6: 修改频率过高"
            self._last_modify_time = now
        return None

    def record_modification(self, path: str, old: str, new: str) -> None:
        self._modifications.append({"path": path, "old": old, "new": new})
        if not any(rp.get("path") == path for rp in self._rollback_paths):
            self._rollback_paths.append({"path": path, "old": old, "new": new})

    def get_rollback_path(self) -> Optional[Dict[str, str]]:
        if not self._rollback_paths:
            return None
        return self._rollback_paths[-1]

    def get_rollback_paths(self) -> List[Dict[str, str]]:
        return self._rollback_paths

    def record_outcome(self, success: bool) -> None:
        self._outcomes.append(success)
        recent = self._outcomes[-3:]
        self.should_rollback = len(recent) == 3 and not any(recent)

    def failures(self) -> int:
        return self._failures


class DGOrchestrator:
    """DGM-H 元认知编排器（社区版 / 企业版自动切换）

    社区版：基础安全护栏编排（M1-M6 简化版）
    企业版：服务端全量 DGM-H 编排引擎
    """

    def __init__(self, api_key: Optional[str] = None):
        self._enterprise = SentriKitEnterprise(api_key=api_key)
        self._activation = ActivationStatus()
        self.shield = SafetyShield()

    def orchestrate(self, context: Dict[str, Any], shield_level: str = "M3") -> Dict[str, Any]:
        return self._enterprise.dgmh_orchestrate(context, shield_level)

    def set_activation(self, judgestored: bool = False, user_authorized: bool = False,
                       safetyguard_stable: bool = False, success_trails_ready: bool = False,
                       gepa_verified: bool = False, **kwargs) -> None:
        self._activation = ActivationStatus(
            phase2_ready=judgestored,
            phase3_ready=judgestored and user_authorized and safetyguard_stable and success_trails_ready,
            judgestored=judgestored,
            user_authorized=user_authorized,
            safetyguard_stable=safetyguard_stable,
            success_trails_ready=success_trails_ready,
            gepa_verified=gepa_verified,
        )

    def check_activation(self) -> ActivationStatus:
        return self._activation

    def run_meta_evolve(self) -> Dict[str, Any]:
        if not self._activation.phase3_ready and not (self._activation.judgestored and
            self._activation.user_authorized and self._activation.safetyguard_stable):
            return {"status": "blocked", "reason": "Phase 3 未激活"}
        if not self._enterprise.is_enterprise:
            return {"status": "simulated", "mode": "community_basic"}
        return self._enterprise.dgmh_orchestrate({"action": "meta_evolve"})

    def apply_suggestion(self, suggestion: Dict[str, Any]) -> Dict[str, Any]:
        target = suggestion.get("target", "")
        if "safety_guard" in target or "safety-guard" in target:
            return {"success": False, "reason": "M1: 不允许修改安全规则", "message": "M1 阻止"}
        self.shield.record_modification(target, suggestion.get("current_value", ""),
                                         suggestion.get("suggested_value", ""))
        return {"success": True, "applied": suggestion, "message": "已应用建议"}

    def rollback_if_needed(self) -> Optional[Dict[str, Any]]:
        if self.shield.should_rollback:
            path = self.shield.get_rollback_path()
            return {"action": "rollback", "path": path["path"] if path else "unknown"}
        return None

    @property
    def is_enterprise(self) -> bool:
        return self._enterprise.is_enterprise


__all__ = [
    "DGOrchestrator", "SafetyShield", "ActivationStatus",
    "_HAS_DGMH", "_DGMH_IMPORT_ERROR",
]
