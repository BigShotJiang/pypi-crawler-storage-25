"""tianlong.agent.daemon — Agent 守护进程 CLI

开源版：单进程守护，单机够用。
企业版：集群管理，集群付费。

用法:
    tianlong-agent start                   # 启动 Agent
    tianlong-agent start --project-dir .   # 指定项目目录
    tianlong-agent stop                    # 停止 Agent
    tianlong-agent status                  # 查看状态
    tianlong-agent run-once                # 运行一次完整进化
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import time
from pathlib import Path

from . import SentriKitAgent, AgentStatus


# 全局 Agent 实例
_agent: SentriKitAgent = None


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tianlong-agent",
        description="SentriKit Agent 守护进程。后台运行 SelfLearning 进化闭环。",
    )
    sub = p.add_subparsers(dest="command", required=True)

    # start
    sp = sub.add_parser("start", help="启动 Agent 后台进程")
    sp.add_argument("--project-dir", "-d", type=str, default=".",
                    help="项目目录 (默认: 当前目录)")
    sp.add_argument("--detach", action="store_true",
                    help="分离为独立进程 (默认: 前台运行)")
    sp.add_argument("--check-interval", type=int, default=60,
                    help="MetaCogTrigger 检查间隔秒数 (默认: 60)")
    sp.add_argument("--evolve-interval", type=int, default=360,
                    help="完整进化间隔分钟数 (默认: 360)")

    # stop
    sub.add_parser("stop", help="停止 Agent")

    # status
    stp = sub.add_parser("status", help="查看 Agent 状态")
    stp.add_argument("--output", "-o", type=str, choices=["text", "json"], default="text")

    # run-once
    rp = sub.add_parser("run-once", help="运行一次完整进化循环")
    rp.add_argument("--project-dir", "-d", type=str, default=".",
                    help="项目目录 (默认: 当前目录)")
    rp.add_argument("--output", "-o", type=str, choices=["text", "json"], default="text")

    return p


def cmd_start(args) -> int:
    global _agent
    project = Path(args.project_dir).resolve()

    _agent = SentriKitAgent(
        project_dir=str(project),
        schedule={
            "check_interval": args.check_interval,
            "full_evolve_interval": args.evolve_interval,
        },
    )
    _agent.start()
    print(f"Agent 已启动 (PID={os.getpid()})", file=sys.stderr)

    if args.detach:
        print(f"后台模式", file=sys.stderr)
        return 0

    # 前台运行
    print(f"项目目录: {project}", file=sys.stderr)
    print(f"检查间隔: {args.check_interval}s", file=sys.stderr)
    print(f"进化间隔: {args.evolve_interval}m", file=sys.stderr)
    print("按 Ctrl+C 停止", file=sys.stderr)
    print(file=sys.stderr)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        _agent.stop()

    return 0


def cmd_stop(args) -> int:
    global _agent
    if _agent is None:
        print("❌ Agent 未运行", file=sys.stderr)
        return 0  # 非错误，只是没有运行中的实例
    _agent.stop()
    return 0


def cmd_status(args) -> int:
    global _agent
    if _agent is None:
        s = AgentStatus(status="not_started")
    else:
        s = _agent.status()

    if args.output == "json":
        print(s.to_json())
        return 0

    status_icon = {"running": "🟢", "stopped": "⚪", "error": "🔴", "not_started": "⚫"}
    icon = status_icon.get(s.status, "❓")
    print(f"\n{icon} SentriKit Agent 状态")
    print(f"{'='*40}")
    print(f"  状态:     {s.status}")
    print(f"  PID:      {s.pid or 'N/A'}")
    print(f"  启动:     {s.started_at or 'N/A'}")
    print(f"  运行时长: {s.uptime_seconds:.0f}s")
    print(f"  进化次数: {s.loops_completed}")
    print(f"  最后汇报: {s.last_report or 'N/A'}")
    print(f"  记忆:     {s.memory_usage or 'N/A'}")
    if s.errors:
        print(f"  最近错误:")
        for e in s.errors[-3:]:
            print(f"    ❌ {e}")
    return 0


def cmd_run_once(args) -> int:
    project = Path(args.project_dir).resolve()
    agent = SentriKitAgent(project_dir=str(project))

    try:
        from tianlong.evolution import RalphLoop, TaskResult, TaskStatus
    except ImportError:
        print("❌ 完整进化需要企业版（tianlong-evolution），社区版未安装", file=sys.stderr)
        return 1
    from datetime import datetime

    task = TaskResult(
        task_id="cli-run-once",
        status=TaskStatus.SUCCESS,
        summary="CLI 单次触发",
    )

    print(f"🔄 运行一次完整进化循环...", file=sys.stderr)
    print(f"项目: {project}", file=sys.stderr)

    loop = RalphLoop(
        project_dir=str(project),
        config={
            "distributed": os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes"),
            "agent_id": f"agent-{os.uname().nodename}",
            "gateway_url": "http://127.0.0.1:8899",
        },
    )
    report = loop.run(task)

    summary = report.summary_line
    if args.output == "json":
        print(report.to_json())
        return 0

    print(f"\n📊 进化报告")
    print(f"{'='*45}")
    print(f"  完成:   {'✅' if report.completed else '❌'}")
    print(f"  摘要:   {summary}")
    if report.evolve_output:
        evo = report.evolve_output
        print(f"  通过:   {len(evo.approved_proposals)}")
        print(f"  拒绝:   {len(evo.rejected_proposals)}")
        for p in evo.approved_proposals:
            print(f"    ✅ {p.summary or '提案通过'}")
        for p in evo.rejected_proposals:
            print(f"    ❌ {p.summary or '提案拒绝'}: {p.safety_reason or ''}")
    if report.ralph_loop:
        rl = report.ralph_loop
        print(f"  迭代:   {rl.iteration} 轮")
        if rl.stop_reasons:
            print(f"  停止原因:")
            for r in rl.stop_reasons:
                print(f"    · {r}")
    return 0 if report.completed else 1


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return {
        "start": cmd_start,
        "stop": cmd_stop,
        "status": cmd_status,
        "run-once": cmd_run_once,
    }[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
