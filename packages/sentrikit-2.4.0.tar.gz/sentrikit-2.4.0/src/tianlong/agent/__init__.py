"""tianlong.agent — SentriKit Agent 主运行时

真正的 Agent 进程。后台运行，持续驱动 SelfLearning 闭环。

开源版：单进程守护，单机够用。
企业版：集群管理，集群付费。

主循环：
1. 空闲检测 → 触发 MetaCogTrigger
2. MetaCogTrigger 判定是否需要进化
3. 需要 → RalphLoop.run() 执行完整闭环
4. SelfModel 记录能力画像
5. Reporter 输出汇报
6. sleep → 回到 1

调度策略：
- 快速检查：每 60s 一次（MetaCogTrigger 轻量）
- 完整进化：每 360m 一次（RalphLoop 重）
- Cron：覆盖原有 Cron 任务
"""

from __future__ import annotations

import json
import os
import signal
import sys
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import Path
from threading import Event, Thread
from typing import Any, Dict, List, Optional


# 默认调度配置
DEFAULT_SCHEDULE = {
    "check_interval": 60,        # MetaCogTrigger 检查间隔（秒）
    "full_evolve_interval": 360, # 完整进化间隔（分钟）
    "summary_interval": 180,    # 摘要汇报间隔（分钟）
    "snapshot_interval": 60,    # SelfModel 快照间隔（分钟）
    "project_dir": ".",          # 项目目录
}


@dataclass
class AgentStatus:
    """Agent 运行时状态"""
    status: str = "stopped"      # running / stopped / error
    pid: int = 0
    started_at: str = ""
    uptime_seconds: float = 0.0
    loops_completed: int = 0
    last_report: str = ""
    memory_usage: str = ""
    errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


class SentriKitAgent:
    """SentriKit Agent 主运行时。

    后台进程模式，持续驱动 SelfLearning 闭环。

    用法:
        agent = SentriKit Agent(project_dir="/path/to/project")
        agent.start()          # 启动后台线程
        agent.stop()           # 停止
        status = agent.status()  # 查看状态
    """

    def __init__(
        self,
        project_dir: str = ".",
        schedule: Optional[Dict] = None,
        auto_start: bool = False,
    ):
        self.project_dir = Path(project_dir).resolve()
        self.schedule = {**DEFAULT_SCHEDULE, **(schedule or {})}
        self._stop_event = Event()
        self._thread: Optional[Thread] = None
        self._status = AgentStatus()
        self._loop_count = 0
        self._last_full_evolve: Optional[datetime] = None
        self._last_summary: Optional[datetime] = None
        self._last_snapshot: Optional[datetime] = None
        self._errors: List[str] = []

        if auto_start:
            self.start()

    # ── 生命周期 ───────────────────────────────────────

    def start(self) -> None:
        """启动 Agent 主循环（后台线程）。"""
        if self._thread and self._thread.is_alive():
            print("⚠️ Agent 已在运行", file=sys.stderr)
            return

        self._stop_event.clear()
        self._thread = Thread(target=self._main_loop, daemon=True)
        self._thread.start()
        self._status.status = "running"
        self._status.started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self._status.pid = os.getpid()
        print(f"✅ SentriKit Agent 已启动 (PID={os.getpid()})", file=sys.stderr)

    def stop(self) -> None:
        """停止 Agent。"""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=3)
        self._status.status = "stopped"
        print("✅ SentriKit Agent 已停止", file=sys.stderr)

    def status(self) -> AgentStatus:
        """获取当前状态。"""
        if self._status.status == "running":
            started = datetime.strptime(self._status.started_at[:19], "%Y-%m-%d %H:%M:%S") if self._status.started_at else datetime.now()
            self._status.uptime_seconds = (datetime.now() - started).total_seconds()
        self._status.loops_completed = self._loop_count
        self._status.errors = self._errors[-5:]
        return self._status

    # ── 主循环 ─────────────────────────────────────────

    def _main_loop(self) -> None:
        """主循环：检查 → 触发 → 进化 → 汇报。"""
        while not self._stop_event.is_set():
            try:
                self._tick()
            except Exception as e:
                self._errors.append(f"[{datetime.now().strftime('%H:%M:%S')}] {e}")
                # 出错不崩溃，继续
            # 使用wait()替代sleep()以保证可中断
            if self._stop_event.wait(timeout=self.schedule["check_interval"]):
                break

    def _tick(self) -> None:
        """一次心跳检查。"""
        now = datetime.now()

        # 1. MetaCogTrigger 轻量检查
        should_evolve = self._check_metacog()

        # 2. 完整进化（定时或触发）
        if should_evolve or self._is_time_for("full_evolve"):
            self._run_full_evolve()
            self._last_full_evolve = now

        # 3. SelfModel 快照
        if self._is_time_for("snapshot"):
            self._take_snapshot()
            self._last_snapshot = now

        # 4. 汇报
        if self._is_time_for("summary"):
            self._send_report()
            self._last_summary = now

    # ── MetaCogTrigger ─────────────────────────────────

    def _check_metacog(self) -> bool:
        """运行 MetaCogTrigger 判断是否需要进化。"""
        try:
            from tianlong.metacog import MetaCogTrigger
            trigger = MetaCogTrigger()

            # 从 SelfModel 获取历史数据
            try:
                from tianlong.selfmodel import SelfModel
                model = SelfModel(project_dir=self.project_dir)
                caps = model.capabilities()
            except Exception:
                caps = {}

            # 计算指标
            rates = [c.get("success_rate", 0) for c in caps.values()] if caps else [1.0]
            sr_7d = sum(rates) / len(rates) if rates else 1.0

            report = trigger.evaluate(
                success_rate_7d=sr_7d,
                days_since_last_improvement=self._days_since_last_improvement(),
            )
            return report.should_evolve
        except Exception as e:
            self._errors.append(f"MetaCogTrigger: {e}")
            return False

    # ── 完整进化 ──────────────────────────────────────

    def _run_full_evolve(self) -> None:
        """执行一次完整 Ralph Loop 进化闭环。"""
        try:
            from tianlong.evolution import RalphLoop, TaskResult, TaskStatus
            from tianlong.reporter import Reporter
            from tianlong.evolution.memory import MemoryWriter

            # 准备任务
            task = TaskResult(
                task_id=f"agent-loop-{self._loop_count}",
                status=TaskStatus.SUCCESS,
                summary="SentriKit Agent 自进化触发",
                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            )

            # Ralph Loop 执行进化
            # 企业版：设置 distributed=True 启用分布式协同进化
            _distributed = os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes")
            loop = RalphLoop(
                project_dir=str(self.project_dir),
                config={
                    "distributed": _distributed,
                    "agent_id": f"agent-{os.uname().nodename}",
                    "gateway_url": "http://127.0.0.1:8899",
                },
            )
            report = loop.run(task)

            # MemoryWriter 增量写入
            try:
                writer = MemoryWriter(project_dir=self.project_dir)
                writer.consolidate()
            except Exception:
                pass

            # 汇报
            reporter = Reporter()
            body_parts = []
            if report.evolve_output:
                approved = len(report.evolve_output.approved_proposals)
                rejected = len(report.evolve_output.rejected_proposals)
                body_parts.append(f"通过{approved} 拒绝{rejected}")
                for p in report.evolve_output.approved_proposals:
                    body_parts.append(f"  ✅ {p.summary}")
            body = "\n".join(body_parts) if body_parts else "无变更"

            reporter.report_task_done(
                title=f"自进化 #{self._loop_count}",
                body=body,
                task_id=task.task_id,
            )

            self._loop_count += 1
            self._status.last_report = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        except Exception as e:
            self._errors.append(f"FullEvolve: {e}")

    # ── SelfModel 快照 ────────────────────────────────

    def _take_snapshot(self) -> None:
        try:
            from tianlong.selfmodel import SelfModel
            model = SelfModel(project_dir=self.project_dir)
            snap = model.take_snapshot()
            self._status.memory_usage = f"semantic={snap.semantic_count} procedural={snap.procedural_active}"
        except Exception:
            pass

    # ── 汇报 ──────────────────────────────────────────

    def _send_report(self) -> None:
        try:
            from tianlong.judge import JudgeHistory, EvolutionDashboard
            from tianlong.reporter import Reporter

            hist = JudgeHistory(path=str(self.project_dir / "judge-history.json"))
            dash = EvolutionDashboard(history=hist)
            judge_report = dash.compute()

            reporter = Reporter()
            highlights = EvolutionDashboard._extract_highlights(judge_report)
            warnings = EvolutionDashboard._extract_warnings(judge_report)

            reporter.report_summary(
                title=f"SentriKit状态摘要 (循环#{self._loop_count})",
                project_dir=str(self.project_dir),
                highlights=highlights,
                action_items=warnings,
            )
        except Exception:
            pass

    # ── 工具方法 ───────────────────────────────────────

    def _is_time_for(self, task: str) -> bool:
        """检查是否到执行时间。"""
        now = datetime.now()
        interval_map = {
            "full_evolve": (self._last_full_evolve, self.schedule["full_evolve_interval"]),
            "snapshot": (self._last_snapshot, self.schedule["snapshot_interval"]),
            "summary": (self._last_summary, self.schedule["summary_interval"]),
        }
        last, interval_minutes = interval_map.get(task, (None, 999))
        if last is None:
            return True
        elapsed = (now - last).total_seconds() / 60
        return elapsed >= interval_minutes

    def _days_since_last_improvement(self) -> int:
        """距离上次改进的天数（简化实现）。"""
        wm = self.project_dir / "brain" / "working-memory.md"
        if not wm.exists():
            return 0
        content = wm.read_text(encoding="utf-8")
        # 倒序搜索最近一次进化事件
        for line in reversed(content.split("\n")):
            if "优化" in line or "改进" in line or "improve" in line.lower():
                return 0  # 有改进
        return 7


# ── 向后兼容 alias ────────────────────────────
TianlongAgent = SentriKitAgent
