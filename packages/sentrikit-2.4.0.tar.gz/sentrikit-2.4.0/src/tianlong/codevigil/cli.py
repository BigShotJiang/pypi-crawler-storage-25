"""SentriKit.codevigil.cli — CodeVigil CLI 入口

用法: sentrikit-codevigil <command> [options]

命令:
    scan <path>     扫描项目代码（同 sentrikit-uxu scan）
    rules           列出所有安全规则
    version         显示版本
"""

from ..uxu.cli import main

if __name__ == "__main__":
    main()
