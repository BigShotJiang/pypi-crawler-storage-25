"""SentriKit.codevigil — CodeVigil AI Agent 代码安全审计

CodeVigil（原 UXU）是一个代码安全审计工具，专为 AI Agent 项目设计。
基于 36+ 条安全规则，覆盖输入消毒（IS）、沙箱隔离（SI）、权限最小化（PM）三支柱。

CodeVigil 是 SentriKit 的内置安全审计引擎。
UXU 规则 ID 保持兼容（UXU-IS-001 等）。

用法:
    from SentriKit.codevigil import Scanner, ScanReport, ScanFinding
    scanner = Scanner()
    report = scanner.scan("/path/to/project")
    print(f"评分: {report.grade} ({report.score})")

CLI:
    sentrikit-codevigil scan .          # CodeViSentriKit
    sentrikit-uxu scan .               # UXU CLI（兼容原 tianlong-uxu）
"""

from ..uxu.scanner import Scanner, ScanReport, ScanFinding
from ..uxu.rules import UXURule, ALL_RULES, FREE_RULES, get_rule
from ..uxu.rules import IS_RULES, SI_RULES, PM_RULES
from ..uxu.rules import register_custom_rule, load_custom_rules
from ..uxu.score import FindingScore, PillarScore, UxuScore
from ..uxu.compliance import OWASP_MAPPING

__all__ = [
    "Scanner", "ScanReport", "ScanFinding",
    "UXURule", "ALL_RULES", "FREE_RULES", "get_rule",
    "IS_RULES", "SI_RULES", "PM_RULES",
    "register_custom_rule", "load_custom_rules",
    "FindingScore", "PillarScore", "UxuScore",
    "OWASP_MAPPING",
]
