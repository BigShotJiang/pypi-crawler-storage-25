"""tianlong.metacog — MetaCogTrigger 元认知触发器

基于 brain/meta-cog-trigger.md 的 5 类触发信号监测器。
"""

from .core import MetaCogTrigger, TriggerLevel, MetaCogReport
