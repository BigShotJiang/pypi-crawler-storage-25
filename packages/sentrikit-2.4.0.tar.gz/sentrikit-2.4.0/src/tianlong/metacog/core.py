"""tianlong.metacog.core — MetaCogTrigger 元认知触发器

基于 brain/meta-cog-trigger.md 的 5 类触发信号监测器。
"""
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Dict, List


class TriggerLevel(Enum):
    MILD = "mild"
    MODERATE = "moderate"
    CRITICAL = "critical"


TRIGGER_WEIGHTS = {"success_rate": 0.30, "stagnation": 0.25, "repeat_failure": 0.25,
                    "external_signal": 0.10, "introspection": 0.10}


@dataclass
class TriggerResult:
    signal_name: str = ""
    level: TriggerLevel = TriggerLevel.MILD
    triggered: bool = False
    score: float = 0.0
    reason: str = ""
    details: Dict = field(default_factory=dict)


@dataclass
class MetaCogReport:
    timestamp: str = ""
    should_evolve: bool = False
    max_level: str = "mild"
    overall_score: float = 0.0
    triggers: List[TriggerResult] = field(default_factory=list)

    def to_dict(self) -> Dict:
        d = {"timestamp": self.timestamp, "should_evolve": self.should_evolve,
             "max_level": self.max_level, "overall_score": round(self.overall_score, 3),
             "triggers": []}
        for t in self.triggers:
            td = asdict(t)
            td["level"] = t.level.value  # TriggerLevel → str
            d["triggers"].append(td)
        return d

    def to_json(self) -> str:
        import json as _json
        return _json.dumps(self.to_dict(), ensure_ascii=False)

    @property
    def summary_line(self) -> str:
        triggered = [t.signal_name for t in self.triggers if t.triggered]
        if triggered:
            return f"触发: {', '.join(triggered)} (等级={self.max_level}, 分={self.overall_score:.2f})"
        return f"无触发 (分={self.overall_score:.2f})"


class MetaCogTrigger:
    def __init__(self):
        self._history: List[MetaCogReport] = []

    def evaluate(self, success_rate_7d=1.0, success_rate_3d=1.0, success_rate_1d=1.0,
                 days_since_last_improvement=0, repeat_error_count=0, external_signal_strength=0.0) -> MetaCogReport:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        triggers = [
            self._check_success_rate(success_rate_7d, success_rate_3d, success_rate_1d),
            self._check_stagnation(days_since_last_improvement),
            self._check_repeat_failure(repeat_error_count),
            self._check_external_signal(external_signal_strength),
            self._check_introspection(days_since_last_improvement),
        ]
        overall = sum(t.score * TRIGGER_WEIGHTS.get(t.signal_name, 0.2) for t in triggers)
        levels = [t for t in triggers if t.triggered]
        max_level = max((l.level for l in levels), key=lambda x: list(TriggerLevel).index(x)).value if levels else TriggerLevel.MILD.value
        report = MetaCogReport(timestamp=now, should_evolve=overall > 0.15, max_level=max_level, overall_score=overall, triggers=triggers)
        self._history.append(report)
        return report

    @staticmethod
    def _check_success_rate(sr7, sr3, sr1) -> TriggerResult:
        score, level, reasons = 0.0, TriggerLevel.MILD, []
        if sr1 < 0.50: score, level = 0.9, TriggerLevel.CRITICAL; reasons.append(f"单日{sr1:.0%}<50%")
        if sr3 < 0.70: score, level = max(score, 0.7), max(level, TriggerLevel.MODERATE, key=lambda x: list(TriggerLevel).index(x)); reasons.append(f"3天{sr3:.0%}<70%")
        if sr7 < 0.85: score = max(score, 0.5); reasons.append(f"7天{sr7:.0%}<85%")
        return TriggerResult(signal_name="success_rate", level=level, triggered=score > 0, score=score, reason="; ".join(reasons) or "正常")

    @staticmethod
    def _check_stagnation(days) -> TriggerResult:
        score, level = min(1.0, days / 14), TriggerLevel.MILD
        if days >= 14: level = TriggerLevel.MODERATE
        return TriggerResult(signal_name="stagnation", level=level, triggered=days >= 3, score=score, reason=f"{days}天无改进" if days > 0 else "正常")

    @staticmethod
    def _check_repeat_failure(count) -> TriggerResult:
        score, level = min(1.0, count / 5), TriggerLevel.MILD
        if count >= 5: level = TriggerLevel.CRITICAL
        elif count >= 3: level = TriggerLevel.MODERATE
        return TriggerResult(signal_name="repeat_failure", level=level, triggered=count > 0, score=score, reason=f"重复失败{count}次" if count > 0 else "正常")

    @staticmethod
    def _check_external_signal(strength) -> TriggerResult:
        return TriggerResult(signal_name="external_signal", triggered=strength > 0.3, score=strength, reason=f"外部信号强度{strength:.2f}" if strength > 0.3 else "正常")

    @staticmethod
    def _check_introspection(days) -> TriggerResult:
        return TriggerResult(signal_name="introspection", triggered=days >= 7, score=min(1.0, days / 10), reason=f"自检: {days}天无改进" if days >= 7 else "正常")

    def get_history(self, limit=10):
        return [r.to_dict() for r in self._history[-limit:]]
