"""tianlong.audit.core — 安全审计核心引擎

整合 SafetyGuard（运行时安全）+ CodeVigil（静态扫描）双引擎。
输出统一的安全评分和安全报告。
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# 安全严重等级权重（用于双引擎综合评分）
SEVERITY_WEIGHTS = {"critical": 10, "high": 6, "medium": 3, "low": 1, "warning": 2, "error": 8}


class SecurityAuditor:
    """安全审计引擎。

    整合 SafetyGuard（行为安全）+ CodeVigil（代码安全）。
    
    用法:
        auditor = SecurityAuditor(project_dir="/path/to/agent")
        report = auditor.run()
        print(f"安全评分: {report['score']}/100")
        print(f"关键发现: {report['critical_count']}")
    """

    def __init__(
        self,
        project_dir: str = ".",
        free_only: bool = False,
        min_severity: str = "low",
    ):
        self.project_dir = Path(project_dir).resolve()
        self.free_only = free_only
        self.min_severity = min_severity

    def run(self) -> Dict:
        """执行双引擎安全审计。"""
        findings: List[Dict] = []
        deductions = 0

        # SafetyGuard：从审计日志读取运行时安全事件
        safety_findings = self._audit_safety()
        findings.extend(safety_findings)
        deductions += sum(SEVERITY_WEIGHTS.get(f.get("severity", "low"), 1) for f in safety_findings)

        # UXU：静态代码扫描
        uxu_findings = self._audit_uxu()
        findings.extend(uxu_findings)
        deductions += sum(SEVERITY_WEIGHTS.get(f.get("severity", "low"), 1) for f in uxu_findings)

        score = max(0, 100 - deductions)

        by_severity: Dict[str, int] = {}
        for f in findings:
            sev = f.get("severity", "low")
            by_severity[sev] = by_severity.get(sev, 0) + 1

        return {
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "target": str(self.project_dir),
            "score": score,
            "grade": self._score_to_grade(score),
            "total_findings": len(findings),
            "critical_count": by_severity.get("critical", 0),
            "high_count": by_severity.get("high", 0),
            "by_severity": by_severity,
            "engines": {
                "safetyguard": {"enabled": True, "findings": len(safety_findings)},
                "uxu": {"enabled": True, "findings": len(uxu_findings)},
            },
            "findings": findings,
        }

    def _audit_safety(self) -> List[Dict]:
        """从 SafetyGuard 审计日志提取运行时安全事件。"""
        log_path = self.project_dir / "brain" / "audit-log.json"
        if not log_path.exists():
            return []

        try:
            logs = json.loads(log_path.read_text(encoding="utf-8"))
        except Exception:
            return []

        if not isinstance(logs, list):
            return []

        findings = []
        for entry in logs[-100:]:  # 最近 100 条
            allowed = entry.get("allowed", True)
            if allowed:
                continue

            risk = entry.get("risk_level", "medium")
            sev_map = {"forbidden": "critical", "high": "high", "medium": "medium", "low": "low"}

            findings.append({
                "engine": "safetyguard",
                "rule_id": f"SG-{entry.get('rule_triggered', 'unknown')}",
                "severity": sev_map.get(risk, "medium"),
                "title": f"[SafetyGuard] {entry.get('reason', '操作被阻止')}",
                "target": entry.get("target", ""),
                "trigger": entry.get("trigger", ""),
                "timestamp": entry.get("timestamp", ""),
                "suggestion": "检查操作是否符合安全策略，如需执行请手动确认",
            })

        return findings

    def _audit_uxu(self) -> List[Dict]:
        """执行 CodeVigil 静态代码扫描。"""
        try:
            from tianlong.uxu import Scanner
            scanner = Scanner(free_only=self.free_only, min_severity=self.min_severity)
            report = scanner.scan(str(self.project_dir))
            uxu_findings = []
            for f in report.findings:
                uxu_findings.append({
                    "engine": "uxu",
                    "rule_id": f.rule_id,
                    "severity": f.severity,
                    "title": f.title,
                    "target": f.file_path,
                    "line": f.line_number,
                    "match": f.matched_text[:80],
                    "suggestion": f.suggestion[:200],
                })
            return uxu_findings
        except Exception as e:
            return [{"engine": "uxu", "severity": "low", "title": f"CodeVigil 扫描异常: {e}"}]

    @staticmethod
    def _score_to_grade(score: int) -> str:
        if score >= 90: return "A"
        elif score >= 70: return "B"
        elif score >= 50: return "C"
        elif score >= 30: return "D"
        return "F"
