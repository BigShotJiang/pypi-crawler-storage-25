"""tianlong.audit — 一键全量安全审计 CLI

整合 SafetyGuard（运行时安全）+ CodeVigil（代码安全）双引擎。
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

from .core import SecurityAuditor


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="sentrikit-audit",
        description="SentriKit — 安全审计。整合 SafetyGuard(运行时)+CodeVigil(代码) 双引擎。",
    )
    p.add_argument("--project-dir", "-d", type=str, default=".",
                   help="目标项目目录 (默认: 当前目录)")
    p.add_argument("--output", "-o", type=str, choices=["html", "json"], default="html",
                   help="输出格式 (默认: html)")
    p.add_argument("--free-only", action="store_true",
                   help="CodeVigil 仅使用免费规则")
    p.add_argument("--severity", "-s", type=str,
                   choices=["critical", "high", "medium", "low"],
                   default="low", help="最低报告等级 (默认: low)")
    p.add_argument("--save", type=str, default=None,
                   help="保存报告到文件路径")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    # 执行双引擎审计
    auditor = SecurityAuditor(
        project_dir=args.project_dir,
        free_only=args.free_only,
        min_severity=args.severity,
    )
    result = auditor.run()

    # 也收集 monitor + judge（用于 dashboard）
    monitor_data = _collect_monitor(Path(args.project_dir).resolve())
    judge_data = _collect_judge(Path(args.project_dir).resolve())

    if args.output == "json":
        output_data = {
            "security": result,
            "monitor": monitor_data,
            "judge": judge_data,
        }
        output = json.dumps(output_data, ensure_ascii=False, indent=2)
    else:
        # 使用 dashboard 渲染
        from tianlong.dashboard import build_dashboard

        # 构建 UXU 数据格式给 dashboard
        uxu_data = {
            "summary": {
                "grade": result["grade"],
                "score": result["score"],
                "total": result["total_findings"],
                "files_scanned": 0,
            },
            "findings": [f for f in result["findings"] if f["engine"] == "uxu"],
        }
        safety_data_for_dash = {
            "recent_checks": result["engines"]["safetyguard"]["findings"],
            "recent_blocked": result["critical_count"],
        }
        output = build_dashboard(
            project_dir=str(auditor.project_dir),
            monitor_data=monitor_data,
            uxu_data=uxu_data,
            judge_data=judge_data,
            safety_data=safety_data_for_dash,
            title="SentriKit · 安全审计报告",
        )

    if args.save:
        Path(args.save).write_text(output, encoding="utf-8")
        print(f"✅ 报告已保存: {args.save}", file=sys.stderr)
    else:
        print(output)

    return 1 if result["critical_count"] > 0 else 0


def _collect_monitor(project: Path) -> dict:
    try:
        from tianlong.monitor import run_all_checks
        report = run_all_checks(project)
        return report.to_dict()
    except Exception as e:
        return {"overall": "error", "error": str(e)}


def _collect_judge(project: Path) -> dict:
    try:
        from tianlong.judge import JudgeHistory, EvolutionDashboard
        hist = JudgeHistory(path=str(project / "judge-history.json"))
        dash = EvolutionDashboard(history=hist)
        return dash.compute()
    except Exception:
        return {"overall_health": "unknown"}


if __name__ == "__main__":
    sys.exit(main())
