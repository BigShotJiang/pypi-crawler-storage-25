"""tianlong.brain — BrainCore 决策引擎

v2.0: 社区版通过 enterprise_client + LocalFallback 提供基础调度。
企业版激活 SENTRIKIT_API_KEY 后，调用服务端 API 获得全量能力。

开源版（Community）：LocalFallback 提供基础 FIFO 调度
企业版：服务端 BrainCore 决策引擎（优先级计算、多租户、退避策略）
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from ..enterprise_client import SentriKitEnterprise, is_enterprise


_HAS_BRAIN = is_enterprise()
_HAS_BRAIN_IMPORT_ERROR = "" if _HAS_BRAIN else "社区版模式：设置 SENTRIKIT_API_KEY 激活企业版"


# ── 数据类型 ─────────────────────────────────


@dataclass
class AgentRole:
    """Agent 角色"""
    RESEARCH = "research"
    DEVELOP = "develop"
    REVIEW = "review"
    EVOLVE = "evolve"
    TEST = "test"
    SECURITY = "security"


class TaskPriority:
    """任务优先级"""
    P0 = 0  # 用户直接指令
    P1 = 1  # 定时任务
    P2 = 2  # 低优先级

    @classmethod
    def values(cls) -> List[int]:
        return [cls.P0, cls.P1, cls.P2]


class TaskStatus:
    """任务状态"""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
    PAUSED = "paused"
    RETRYING = "retrying"

    @classmethod
    def values(cls) -> List[str]:
        return [cls.PENDING, cls.RUNNING, cls.SUCCESS, cls.FAILED,
                cls.CANCELLED, cls.TIMEOUT, cls.PAUSED, cls.RETRYING]


class TaskSource:
    """任务来源"""
    USER_DIRECT = "user_direct"
    CRON = "cron"
    SUB_AGENT = "sub_agent"
    HEARTBEAT = "heartbeat"
    EXTERNAL = "external"


@dataclass
class BrainTask:
    """BrainCore 任务"""
    id: str = ""
    goal: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    priority: int = TaskPriority.P1
    status: str = TaskStatus.PENDING
    source: str = TaskSource.USER_DIRECT
    assigned_agent: str = ""


@dataclass
class BrainCoreSnapshot:
    """BrainCore 快照"""
    running_tasks: int = 0
    queued_tasks: int = 0
    agents_online: int = 0
    agents_total: int = 0
    uptime_hours: float = 0.0


@dataclass
class DispatchResult:
    """派发结果"""
    task_id: str = ""
    assigned_agents: List[str] = field(default_factory=list)
    status: str = "dispatched"


DispatchTarget = str
RoutingRule = Dict[str, Any]


# ── 预置路由表 ──────────────────────────────

ROUTING_TABLE: List[RoutingRule] = [
    {"type": "user_direct", "target": "braincore", "priority": 0, "description": "用户直接指令→BrainCore"},
    {"type": "query", "target": "braincore", "priority": 1, "description": "查询→BrainCore"},
    {"type": "code", "target": "code_agent", "priority": 1, "description": "代码→CodeAgent"},
    {"type": "research", "target": "research_agent", "priority": 1, "description": "调研→ResearchAgent"},
    {"type": "deep_research", "target": "multi_agent", "priority": 1, "description": "深度调研→多Agent"},
    {"type": "file_ops", "target": "executor", "priority": 1, "description": "文件操作→Executor"},
    {"type": "monitor", "target": "monitor_agent", "priority": 1, "description": "监控→MonitorAgent"},
    {"type": "knowledge", "target": "knowledge_agent", "priority": 1, "description": "知识→KnowledgeAgent"},
    {"type": "test", "target": "code_agent", "priority": 2, "description": "测试→CodeAgent"},
]


# ── 核心类 ──────────────────────────────────


class BrainCore:
    """BrainCore 决策引擎（社区版 / 企业版自动切换）"""

    def __init__(self, api_key: Optional[str] = None):
        self._enterprise = SentriKitEnterprise(api_key=api_key)

    def dispatch(self, task: Dict[str, Any], agents: Optional[List[str]] = None) -> DispatchResult:
        result = self._enterprise.brain_dispatch(task, agents)
        return DispatchResult(
            task_id=result.get("task_id", ""),
            assigned_agents=result.get("assigned_agents", agents or ["default"]),
            status=result.get("status", "dispatched"),
        )

    def status(self) -> Dict[str, Any]:
        return self._enterprise.brain_status()

    @property
    def is_enterprise(self) -> bool:
        return self._enterprise.is_enterprise


class Router:
    """路由规则（社区版实现）"""

    def classify_query(self, query: str) -> str:
        """分类查询"""
        q = query.lower()
        if any(kw in q for kw in ["代码", "开发", "实现", "fix", "bug", "feature"]):
            return "code"
        if any(kw in q for kw in ["调研", "研究", "查找", "搜索", "research"]):
            return "research"
        if any(kw in q for kw in ["深度", "全面分析", "deep"]):
            return "deep_research"
        if any(kw in q for kw in ["文件", "创建目录", "移动", "删除"]):
            return "file_ops"
        if any(kw in q for kw in ["监控", "检查", "health", "状态"]):
            return "monitor"
        if any(kw in q for kw in ["知识", "FAQ", "文档", "数据"]):
            return "knowledge"
        return "query"

    def classify_code(self, query: str) -> str:
        return "code"

    def classify_research(self, query: str) -> str:
        return "research"

    def classify_deep_research(self, query: str) -> str:
        return "deep_research"

    def classify_file_ops(self, query: str) -> str:
        return "file_ops"

    def classify_monitor(self, query: str) -> str:
        return "monitor"

    def classify_knowledge(self, query: str) -> str:
        return "knowledge"

    def route(self, task_type: str) -> Optional[str]:
        """路由到目标 Agent"""
        for rule in ROUTING_TABLE:
            if rule["type"] == task_type:
                return rule["target"]
        return None


class Scheduler:
    """调度器（社区版基础实现）"""

    def __init__(self):
        self._queues: Dict[int, List[BrainTask]] = {
            TaskPriority.P0: [],
            TaskPriority.P1: [],
            TaskPriority.P2: [],
        }
        self._task_id_counter = 0

    def _next_id(self) -> str:
        self._task_id_counter += 1
        return f"task_{self._task_id_counter:04d}"

    def enqueue(self, task: BrainTask) -> None:
        """入队"""
        if not task.id:
            task.id = self._next_id()
        task.status = TaskStatus.PENDING
        self._queues[task.priority].append(task)

    def dequeue(self) -> Optional[BrainTask]:
        """出队（高优先级优先）"""
        for pri in [TaskPriority.P0, TaskPriority.P1, TaskPriority.P2]:
            if self._queues[pri]:
                task = self._queues[pri].pop(0)
                task.status = TaskStatus.RUNNING
                return task
        return None

    def complete_task(self, task_id: str) -> None:
        for pri in self._queues.values():
            for t in pri:
                if t.id == task_id:
                    t.status = TaskStatus.SUCCESS

    def fail_task(self, task_id: str) -> None:
        for pri in self._queues.values():
            for t in pri:
                if t.id == task_id:
                    t.status = TaskStatus.FAILED


class Dispatcher:
    """派发器（社区版简化）"""
    pass


class MultiTenantBrainCore:
    """多租户 BrainCore（社区版简化）"""

    def __init__(self):
        self._tenants: Dict[str, Any] = {}
        self._tenant_counter = 0

    def create_tenant(self, tenant_id: str, project_dir: Any = None) -> Any:
        if tenant_id in self._tenants:
            raise ValueError(f"租户 {tenant_id} 已存在")
        ctx = TenantContext()
        ctx.scheduler = Scheduler()
        ctx.dispatcher = Dispatcher()
        self._tenants[tenant_id] = {"ctx": ctx, "dir": str(project_dir) if project_dir else ""}
        self._tenant_counter += 1
        return ctx

    def remove_tenant(self, tenant_id: str) -> bool:
        if tenant_id not in self._tenants:
            return False
        del self._tenants[tenant_id]
        self._tenant_counter -= 1
        return True

    def list_tenants(self) -> Dict[str, Any]:
        return {k: v["dir"] for k, v in self._tenants.items()}

    @property
    def tenant_count(self) -> int:
        return self._tenant_counter

    def receive(self, tenant_id: str, source: str = "user", summary: str = "") -> Optional[BrainTask]:
        if tenant_id not in self._tenants:
            return None
        task = BrainTask(goal=summary, source=source)
        self._tenants[tenant_id]["ctx"].scheduler.enqueue(task)
        return task

    def process_next(self, tenant_id: str) -> Optional[BrainTask]:
        if tenant_id not in self._tenants:
            return None
        return self._tenants[tenant_id]["ctx"].scheduler.dequeue()

    def complete(self, tenant_id: str, task_id: str, result: str = "") -> Optional[Any]:
        if tenant_id not in self._tenants:
            return None
        self._tenants[tenant_id]["ctx"].scheduler.complete_task(task_id)
        from types import SimpleNamespace
        return SimpleNamespace(result=result)

    def snapshot(self, tenant_id: str) -> Any:
        if tenant_id not in self._tenants:
            return None
        from types import SimpleNamespace
        queue = self._tenants[tenant_id]["ctx"].scheduler._queues
        is_idle = all(len(q) == 0 for q in queue.values())
        return SimpleNamespace(is_idle=is_idle, queue_length=sum(len(q) for q in queue.values()),
                               running_tasks=0, current_task=None)

    def snapshot_all(self) -> Dict[str, Any]:
        return {tid: {"is_idle": self.snapshot(tid).is_idle} for tid in self._tenants}

    def dispatch_to_agent(self, task: BrainTask) -> Optional[Dict[str, Any]]:
        router = Router()
        task_type = router.classify_query(task.goal)
        target = router.route(task_type)
        if target:
            return {"agent_role": target, "params": {"goal": task.goal}}
        return None

    def run_health_checks(self, tenant_id: str) -> Dict[str, Any]:
        return {"overall": "healthy", "checks": {}, "mode": "community"}


class TenantContext:
    """租户上下文"""
    def __init__(self):
        self.scheduler = None
        self.dispatcher = None


# ── 函数 ────────────────────────────────────


def start_gateway(*args, **kwargs):
    raise NotImplementedError("BrainCore API 网关需要企业版。设置 SENTRIKIT_API_KEY 激活。")


def cli_main(argv: Optional[List[str]] = None) -> int:
    import sys
    if argv is None:
        argv = sys.argv[1:] if len(sys.argv) > 1 else []
    if "--enterprise" in argv:
        os.environ["TIANLONG_ENTERPRISE"] = "1"
        argv = [a for a in argv if a != "--enterprise"]
    from ..enterprise_client import main as enterprise_main
    return enterprise_main(argv)


__all__ = [
    "BrainCore", "Router", "Scheduler",
    "Dispatcher", "AgentRole", "DispatchResult",
    "MultiTenantBrainCore", "TenantContext",
    "BrainTask", "BrainCoreSnapshot",
    "TaskSource", "TaskPriority", "TaskStatus",
    "DispatchTarget", "RoutingRule", "ROUTING_TABLE",
    "start_gateway", "cli_main",
    "_HAS_BRAIN", "_HAS_BRAIN_IMPORT_ERROR",
]
