"""tianlong.researchengine — Research Engine / 调研引擎

v2.0: 社区版通过 enterprise_client + LocalFallback 提供本地搜索。
企业版激活 SENTRIKIT_API_KEY 后，调用服务端 API 获得 4 级搜索链调研。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from ..enterprise_client import SentriKitEnterprise, is_enterprise


_HAS_RESEARCHENGINE = is_enterprise()
_RESEARCHENGINE_IMPORT_ERROR = "" if _HAS_RESEARCHENGINE else "社区版模式：设置 SENTRIKIT_API_KEY 激活企业版"


class ResearchType:
    """调研类型"""
    QUICK = "quick_query"
    MARKET = "market_overview"
    TECHNICAL = "technical_research"
    COMPETITIVE = "competitive_analysis"
    DEEP = "deep_research"


@dataclass
class ResearchResult:
    """调研结果"""
    topic: str = ""
    research_type: str = "quick_query"
    key_points: List[str] = field(default_factory=list)
    summary: str = ""
    sources: List[str] = field(default_factory=list)
    high_value: bool = False
    confidence: float = 0.0
    duration_seconds: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "topic": self.topic,
            "research_type": self.research_type,
            "key_points": self.key_points,
            "summary": self.summary,
            "sources": self.sources,
            "high_value": self.high_value,
            "confidence": self.confidence,
            "duration_seconds": self.duration_seconds,
        }


class ResearchEngine:
    """Research Engine 调研引擎（社区版 / 企业版自动切换）

    社区版：LocalFallback 提供本地文件搜索 + 基础关键词高价值检测
    企业版：服务端 4 级搜索链（本地→缓存→在线→深度）+ 降级策略
    """

    def __init__(self, api_key: Optional[str] = None):
        self._enterprise = SentriKitEnterprise(api_key=api_key)
        self._history: List[ResearchResult] = []

    def search(
        self,
        query: str,
        chain_depth: int = 2,
        sources: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        return self._enterprise.research_search(query, chain_depth, sources)

    def research(self, topic: str, research_type: str = "quick_query") -> ResearchResult:
        """执行调研"""
        import time
        start = time.time()
        if not self._enterprise.is_enterprise:
            result = ResearchResult(
                topic=topic,
                research_type=research_type,
                key_points=[f"关于 {topic} 的基础信息"],
                summary=f"社区版调研结果：{topic}",
                high_value=self._detect_high_value(topic).get("is_high_value", False),
                duration_seconds=time.time() - start,
            )
            self._history.append(result)
            return result
        # 企业版：调用 API
        api_result = self._enterprise.research_search(topic, 2)
        result = ResearchResult(
            topic=topic,
            research_type=research_type,
            key_points=api_result.get("key_points", []),
            summary=api_result.get("summary", ""),
            high_value=self._detect_high_value(topic).get("is_high_value", False),
            duration_seconds=time.time() - start,
        )
        self._history.append(result)
        return result

    def _detect_high_value(self, text: str) -> Dict[str, Any]:
        """检测高价值内容（社区版使用关键词）"""
        high_value_keywords = [
            "市场规模", "年化增长率", "增长", "突破", "开源",
            "GPT", "发布", "融资", "收购", "里程碑",
        ]
        for kw in high_value_keywords:
            if kw in text:
                return {"is_high_value": True, "reason": f"包含关键词: {kw}"}
        return {"is_high_value": False, "reason": "未检测到高价值信号"}

    def get_history(self) -> List[ResearchResult]:
        """获取调研历史"""
        return self._history

    @property
    def is_enterprise(self) -> bool:
        return self._enterprise.is_enterprise


class ResearchAgent:
    """调研 Agent（社区版实现）"""

    def __init__(self, cache_dir: str = ""):
        self._cache: Dict[str, List[ResearchResult]] = {}
        self._cache_dir = cache_dir

    def search(self, query: str, limit: int = 3) -> List[ResearchResult]:
        """执行搜索"""
        if query in self._cache:
            return self._cache[query]
        # 生成模拟结果
        n_results = min(limit, max(3, len(query) % 5 + 1))
        results = []
        for i in range(n_results):
            results.append(ResearchResult(
                topic=query,
                research_type="quick_query",
                key_points=[f"结果{i+1}: {query} 相关信息"],
                high_value=False,
            ))
        self._cache[query] = results
        return results


SearchResult = Dict[str, Any]


__all__ = [
    "ResearchEngine", "ResearchType", "ResearchResult",
    "ResearchAgent", "SearchResult",
    "_HAS_RESEARCHENGINE", "_RESEARCHENGINE_IMPORT_ERROR",
]
