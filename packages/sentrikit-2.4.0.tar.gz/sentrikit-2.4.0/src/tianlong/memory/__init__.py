"""tianlong.memory — MemorySystem 记忆系统

v2.0: 社区版通过 enterprise_client + LocalFallback 提供本地 JSON 存储。
企业版激活 SENTRIKIT_API_KEY 后，调用服务端 API 获得三层持久化记忆。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from ..enterprise_client import SentriKitEnterprise, is_enterprise


_HAS_MEMORY = is_enterprise()
_MEMORY_IMPORT_ERROR = "" if _HAS_MEMORY else "社区版模式：设置 SENTRIKIT_API_KEY 激活企业版"


class MemorySystem:
    """MemorySystem 记忆系统（社区版 / 企业版自动切换）

    社区版：LocalFallback 提供本地 JSON 文件存储
    企业版：服务端三层持久化记忆（语义/程序/工作）
    """

    def __init__(self, api_key: Optional[str] = None):
        self._enterprise = SentriKitEnterprise(api_key=api_key)

    def store(self, key: str, value: Dict[str, Any], ttl: Optional[int] = None) -> Dict[str, Any]:
        return self._enterprise.memory_store(key, value, ttl)

    def retrieve(self, key: str) -> Dict[str, Any]:
        return self._enterprise.memory_retrieve(key)

    def list_keys(self, prefix: str = "") -> Dict[str, Any]:
        return self._enterprise.memory_list(prefix)

    @property
    def is_enterprise(self) -> bool:
        return self._enterprise.is_enterprise


class MemoryStore(MemorySystem):
    """兼容别名"""
    pass


MemoryEntry = Dict[str, Any]
MemoryQuery = Dict[str, Any]


__all__ = [
    "MemorySystem", "MemoryStore", "MemoryEntry", "MemoryQuery",
    "_HAS_MEMORY", "_MEMORY_IMPORT_ERROR",
]
