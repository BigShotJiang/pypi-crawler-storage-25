# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""tianlong.enterprise_client — SentriKit企业版 API 客户端（统一入口）

用法:
    export SENTRIKIT_API_KEY="sk-xxx"
    tianlong-enterprise status  # CLI 查看状态

或在代码中:
    from tianlong.enterprise_client import SentriKitEnterprise
    client = SentriKitEnterprise(api_key="***")
    result = client.brain_dispatch(task={"goal": "..."})

架构：
- 本模块 = 用户唯一接触的入口，提供高层 API
- enterprise/ = 底层实现（HTTP 客户端 / 本地降级 / 类型 / 缓存）
- 无 API Key → 社区版本地降级（LocalFallback）
- 有 API Key → 调用服务端 API（EnterpriseClient）
"""

from __future__ import annotations

import os
import json
import logging
from typing import Any, Dict, List, Optional
from pathlib import Path


logger = logging.getLogger("tianlong.enterprise")

# ── 企业版配置常量 ─────────────────────────────

ENTERPRISE_API_BASE = "https://api.tianlong.ai/v1"
ENTERPRISE_API_KEY_ENV = "SENTRIKIT_API_KEY"  # 优先，向后兼容 TIANLONG_API_KEY
ENTERPRISE_CONFIG_PATH = Path.home() / ".sentrikit" / "config.json"
_OLD_CONFIG_PATH = Path.home() / ".tianlong" / "config.json"  # 旧路径兼容


def _migrate_old_config() -> None:
    """检测旧 ~/.tianlong/ 目录，若存在则迁移数据到 ~/.sentrikit/"""
    if not _OLD_CONFIG_PATH.exists():
        return
    if ENTERPRISE_CONFIG_PATH.exists():
        return  # 新路径已有配置，不覆盖
    try:
        ENTERPRISE_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        data = json.loads(_OLD_CONFIG_PATH.read_text(encoding="utf-8"))
        ENTERPRISE_CONFIG_PATH.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        logger.info("已迁移配置: ~/.tianlong/ → ~/.sentrikit/")
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("旧配置迁移失败: %s", e)


from .enterprise.fallback import UpgradeHints


# ── API Key 检测 ──────────────────────────────


def detect_api_key() -> Optional[str]:
    """链式查找 API Key: 环境变量 > 配置文件"""
    # 旧路径迁移
    _migrate_old_config()
    key = os.environ.get("SENTRIKIT_API_KEY")
    if key:
        return key
    key = os.environ.get("TIANLONG_API_KEY")
    if key:
        return key
    try:
        if ENTERPRISE_CONFIG_PATH.exists():
            with open(ENTERPRISE_CONFIG_PATH) as f:
                data = json.load(f)
                return data.get("api_key") or data.get("sriKit_api_key")
    except (json.JSONDecodeError, OSError):
        pass
    return None


def is_enterprise() -> bool:
    """快速检查是否为企业版"""
    return bool(detect_api_key())


# ── 统一入口类 ───────────────────────────────


class SentriKitEnterprise:
    """SentriKit企业版客户端

    自动检测 API Key 并切换模式：
    - 无 API Key → 社区版本地降级
    - 有 API Key → 调用服务端 API
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_base: str = ENTERPRISE_API_BASE,
        timeout: int = 30,
        use_cache: bool = True,
    ):
        self.api_key = api_key or detect_api_key()
        self.api_base = api_base
        self.is_enterprise = bool(self.api_key)
        self.use_cache = use_cache

        if self.is_enterprise:
            from .enterprise.client import EnterpriseClient
            self._client = EnterpriseClient(
                api_key=self.api_key,
                api_base=api_base,
                timeout=timeout,
                use_cache=use_cache,
            )
            logger.info("SentriKit企业版已激活 (API Key: %s...)", self.api_key[:8])
        else:
            from .enterprise.fallback import LocalFallback
            self._client = LocalFallback()
            logger.info("SentriKit社区版（本地模式）")

    # ── BrainCore 调度 ─────────────────────────

    def brain_dispatch(
        self,
        task: Dict[str, Any],
        agents: Optional[List[str]] = None,
        priority: int = 0,
    ) -> Dict[str, Any]:
        """BrainCore 多 Agent 调度"""
        if not self.is_enterprise:
            return self._client.brain_dispatch_local(task, agents)
        return self._client.post("/brain/dispatch", json={
            "task": task,
            "agents": agents or ["default"],
            "priority": priority,
        })

    def brain_status(self) -> Dict[str, Any]:
        """BrainCore 状态快照"""
        if not self.is_enterprise:
            return {"mode": "community", "agents_online": 0, "tasks_queued": 0}
        return self._client.get("/brain/status")

    # ── 自进化管道 ────────────────────────────

    def evolution_cycle(
        self,
        proposal: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """执行一次完整的 7 步进化闭环"""
        if not self.is_enterprise:
            return self._client.evolution_cycle_local(proposal, context)
        return self._client.post("/evolution/cycle", json={
            "proposal": proposal,
            "context": context or {},
        })

    def evolution_reflect(self, evolution_id: str) -> Dict[str, Any]:
        """进化后的反射分析"""
        if not self.is_enterprise:
            return {"reflection": "社区版不支持进化反射", "mode": "community"}
        return self._client.get(f"/evolution/{evolution_id}/reflect")

    # ── 调研引擎 ─────────────────────────────

    def research_search(
        self,
        query: str,
        chain_depth: int = 2,
        sources: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """4 级搜索链调研"""
        if not self.is_enterprise:
            return self._client.research_search_local(query)
        return self._client.post("/research/search", json={
            "query": query,
            "chain_depth": chain_depth,
            "sources": sources or ["web", "arxiv", "github"],
        })

    # ── DGM-H 元认知 ──────────────────────────

    def dgmh_orchestrate(
        self,
        context: Dict[str, Any],
        shield_level: str = "M3",
    ) -> Dict[str, Any]:
        """DGM-H 元认知编排 + SafetyShield M1-M6"""
        if not self.is_enterprise:
            return self._client.dgmh_orchestrate_local(context)
        return self._client.post("/dgmh/orchestrate", json={
            "context": context,
            "shield_level": shield_level,
        })

    # ── MetaEVOLVE 元修改器 ────────────────────

    def metaevolve_analyze(
        self,
        change_records: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """MetaEVOLVE 命中率分析 + 策略建议"""
        if not self.is_enterprise:
            return self._client.metaevolve_analyze_local(change_records)
        return self._client.post("/metaevolve/analyze", json={
            "change_records": change_records,
        })

    # ── MemoryStore 记忆系统 ───────────────────

    def memory_store(
        self,
        key: str,
        value: Dict[str, Any],
        ttl: Optional[int] = None,
    ) -> Dict[str, Any]:
        """持久化记忆存储"""
        if not self.is_enterprise:
            return self._client.memory_store_local(key, value)
        return self._client.post("/memory/store", json={
            "key": key,
            "value": value,
            "ttl": ttl,
        })

    def memory_retrieve(self, key: str) -> Dict[str, Any]:
        """检索记忆"""
        if not self.is_enterprise:
            return self._client.memory_retrieve_local(key)
        return self._client.get(f"/memory/{key}")

    def memory_list(self, prefix: str = "") -> Dict[str, Any]:
        """列出记忆"""
        if not self.is_enterprise:
            return self._client.memory_list_local(prefix)
        return self._client.get(f"/memory/list?prefix={prefix}")

    # ── SafetyGuard ───────────────────────────

    def safety_check(
        self,
        content: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """安全检查"""
        if not self.is_enterprise:
            return self._client.safety_check_local(content)
        return self._client.post("/safety/check", json={
            "content": content,
            "context": context or {},
        })

    # ── CodeVigil 安全审计 ─────────────────────────

    def uxu_audit(
        self,
        code: str,
        rules: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """CodeVigil 32 规则安全审计"""
        result = self._run_uxu_local_rules(code, rules)
        if self.is_enterprise:
            semantic = self._client.post("/uxu/semantic-analysis", json={
                "code": code,
                "local_results": result,
            })
            result["semantic_analysis"] = semantic
        return result

    def _run_uxu_local_rules(
        self,
        code: str,
        rules: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """本地 CodeVigil 规则执行"""
        from .uxu.rules import ALL_RULES, MATCH_RULES
        from .uxu.score import calc_score
        findings = []
        to_run = rules or list(ALL_RULES.keys())
        for rule_id in to_run:
            rule = ALL_RULES.get(rule_id)
            if not rule:
                continue
            for pattern_key, pattern in MATCH_RULES.get(rule_id, {}).items():
                if pattern.search(code):
                    findings.append({
                        "rule_id": rule_id,
                        "severity": rule.get("severity", "medium"),
                        "matched": pattern_key,
                        "mode": "local",
                    })
        score, grade = calc_score(findings)
        return {
            "total_findings": len(findings),
            "findings": findings,
            "score": score,
            "grade": grade,
            "mode": "local",
        }

    # ── 联合端点 ─────────────────────────────

    def full_agent_cycle(
        self,
        task: str,
        context: Dict[str, Any],
    ) -> Dict[str, Any]:
        """完整的 Agent 工作周期：调度 → 进化 → 记忆 → 审计"""
        if not self.is_enterprise:
            return {
                "error": "full_agent_cycle 需要企业版 API Key",
                "hint": "请访问 https://tianlong.ai/pricing 获取",
            }
        return self._client.post("/agent/full-cycle", json={
            "task": task,
            "context": context,
        })

    # ── 工具方法 ─────────────────────────────

    def get_usage_stats(self) -> Dict[str, Any]:
        """获取 API 使用统计"""
        if not self.is_enterprise:
            return {"mode": "community", "calls": 0}
        return self._client.get_metrics()

    def check_health(self) -> Dict[str, Any]:
        """检查 API 服务健康状态"""
        if not self.is_enterprise:
            return {"status": "community_mode", "api": False}
        return self._client.health_check()

    def close(self):
        """关闭客户端连接"""
        if self.is_enterprise:
            import asyncio
            try:
                asyncio.get_event_loop().run_until_complete(self._client.close())
            except RuntimeError:
                pass


# ── 向后兼容 alias ────────────────────────────
TianLongEnterprise = SentriKitEnterprise


def main(argv: Optional[List[str]] = None) -> int:
    """CLI 入口：tianlong-enterprise"""
    import sys
    if argv is None:
        argv = sys.argv[1:]

    # 处理 --enterprise flag (从 cli_main 转发)
    if "--enterprise" in argv:
        os.environ["TIANLONG_ENTERPRISE"] = "1"
        argv = [a for a in argv if a != "--enterprise"]

    if not argv:
        print("SentriKit企业版客户端")
        print()
        print("用法:")
        print("  tianlong-enterprise status       查看企业版状态")
        print("  tianlong-enterprise check        健康检查")
        print("  tianlong-enterprise usage        使用统计")
        print()
        print("选项:")
        print("  --enterprise   强制声明为企业版模式")
        return 0

    client = TianLongEnterprise()

    cmd = argv[0]
    if cmd == "status":
        print(f"企业版: {'✅ 已激活' if client.is_enterprise else '❌ 未激活（社区版）'}")
        if client.is_enterprise:
            print(f"API Base: {client.api_base}")
            print(f"API Key:  {client.api_key[:8]}...")
        else:
            print("提示: export SENTRIKIT_API_KEY=sk-xxx 激活企业版（或 export TIANLONG_API_KEY=sk-xxx）")
        print()
        print("社区版可用能力:")
        print("  ✅ CodeVigil 34 规则安全审计（免费: IS+SI+PM 基础规则）")
        print("  ✅ CodeVigil 付费规则 5 条（PM-011~PM-015，需企业版解锁）")
        print("  ✅ Monitor 8 项健康检查（本地）")
        print("  ✅ Safety 6 条红线（本地）")
        print("  ✅ Dashboard 仪表盘（本地）")
        print("  ✅ Selfcheck 自检诊断（本地）")
        print("  ✅ CompIntel 本地竞品采集（本地）")
        print()
        print("企业版额外能力 (API Key 激活):")
        print("  🔒 CodeVigil 完整 39 规则（含 PM-011 供应链锁定 ~ PM-015 越界突破）")
        print("  🔒 CodeVigil 语义级代码审计（企业版）")
        print("  🔒 BrainCore 多 Agent 调度引擎")
        print("  🔒 7 步自进化闭环 (SelfLearning)")
        print("  🔒 DGM-H 元认知编排 (M1-M6)")
        print("  🔒 MetaEVOLVE 命中率分析与策略")
        print("  🔒 4 级搜索链调研引擎")
        print("  🔒 三层持久化记忆系统")
        return 0
    elif cmd == "check":
        health = client.check_health()
        print(f"状态: {health.get('status', 'unknown')}")
        return 0
    elif cmd == "usage":
        stats = client.get_usage_stats()
        print(json.dumps(stats, indent=2, ensure_ascii=False))
        return 0
    else:
        print(f"未知命令: {cmd}")
        return 1
