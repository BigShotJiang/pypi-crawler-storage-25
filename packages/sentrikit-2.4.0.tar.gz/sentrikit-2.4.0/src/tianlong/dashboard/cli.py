"""tianlong.dashboard.cli — 仪表盘 CLI

用法:
    tianlong-dashboard -d . > dashboard.html           # 开源版：静态HTML，免费
    tianlong-dashboard --tenants                        # 企业版：多租户（需 TIANLONG_ENTERPRISE=1）
    tianlong-dashboard --serve                          # 企业版：实时预览（需 TIANLONG_ENTERPRISE=1）
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import build_dashboard


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tianlong-dashboard",
        description="SentriKit — 可视化仪表盘。整合多模块数据生成HTML报告。",
    )
    p.add_argument("--project-dir", "-d", type=str, default=".",
                   help="Agent 项目目录 (默认: 当前目录)")
    p.add_argument("--output", "-o", type=str, choices=["html", "json"], default="html",
                   help="输出格式 (默认: html)")
    p.add_argument("--free-only", action="store_true",
                   help="CodeVigil 仅使用免费规则")
    p.add_argument("--tenants", type=str, nargs="*", default=None,
                   metavar="TENANT_ID",
                   help="从 API 网关拉取多租户数据 (留空=从默认网关拉取，指定ID=只拉取某租户)")
    p.add_argument("--api-host", type=str, default="http://127.0.0.1:8899",
                   help="API 网关地址 (默认: http://127.0.0.1:8899)")
    p.add_argument("--serve", action="store_true",
                   help="启动 HTTP 服务器实时预览 (默认端口 9900)")
    p.add_argument("--port", type=int, default=9900,
                   help="HTTP 服务器端口 (默认: 9900)")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    project = Path(args.project_dir).resolve()

    tenant_data = None

    # 企业版门控：--tenants（多租户）
    if args.tenants is not None:
        enterprise = os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes")
        if not enterprise:
            print("❌ 多租户仪表盘需要企业版授权（TIANLONG_ENTERPRISE=1）", file=sys.stderr)
            return 1
        tenant_ids = args.tenants if args.tenants else []
        tenant_data = _fetch_tenants(args.api_host, tenant_ids)

    if not project.exists():
        print(f"Project directory does not exist: {project}", file=sys.stderr)
        return 1

    # 企业版门控：--serve（实时预览）需先检测，避免耗时数据收集后失败
    if args.serve:
        _enterprise = os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes")
        if not _enterprise:
            print("❌ 实时仪表盘服务需要企业版授权（TIANLONG_ENTERPRISE=1）", file=sys.stderr)
            print("   开源版请使用: tianlong-dashboard -d . > dashboard.html", file=sys.stderr)
            return 1

    monitor_data = _collect_monitor(project)
    uxu_data = _collect_uxu(project, args.free_only)
    judge_data = _collect_judge(project)
    safety_data = _collect_safety(project)
    metacog_data = _collect_metacog(project)
    uxu_score_v2 = _collect_uxu_v2(project)
    dgmh_data = _collect_dgmh(project)

    if args.output == "json":
        data = {
            "monitor": monitor_data,
            "uxu": uxu_data,
            "judge": judge_data,
            "safety": safety_data,
            "metacog": metacog_data,
            "uxu_score_v2": uxu_score_v2,
            "dgmh": dgmh_data,
            "tenants": tenant_data,
        }
        if tenant_data:
            data["tenants"] = tenant_data
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    html = build_dashboard(
        project_dir=str(project),
        monitor_data=monitor_data,
        uxu_data=uxu_data,
        judge_data=judge_data,
        safety_data=safety_data,
        metacog_data=metacog_data,
        tenant_data=tenant_data,
        judge_history_path=str(project / "judge-history.json"),
        title="SentriKit Dashboard",
        uxu_score_v2=uxu_score_v2,
        dgmh_data=dgmh_data,
        enterprise_mode=os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes"),
    )

    if args.serve:
        _serve_html(html, args.port, project)
        return 0

    print(html)
    return 0


def _serve_html(html: str, port: int, project: Path) -> None:
    """Start HTTP server for live dashboard preview."""
    import http.server
    import socketserver

    html_bytes = html.encode("utf-8")

    class DashboardHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            if self.path == "/":
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(html_bytes)))
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                self.wfile.write(html_bytes)
            elif self.path == "/api/config":
                self._handle_config_get()
            elif self.path.startswith("/api/config/"):
                key = self.path[len("/api/config/"):]
                self._handle_config_get(key)
            else:
                self.send_response(404)
                self.end_headers()

        def do_POST(self) -> None:
            if self.path == "/api/config":
                self._handle_config_set()
            else:
                self.send_response(404)
                self.end_headers()

        def do_DELETE(self) -> None:
            if self.path.startswith("/api/config/"):
                key = self.path[len("/api/config/"):]
                self._handle_config_delete(key)
            else:
                self.send_response(404)
                self.end_headers()

        def _read_body(self) -> dict:
            length = int(self.headers.get("Content-Length", 0))
            if length == 0:
                return {}
            body = self.rfile.read(length).decode("utf-8")
            return json.loads(body)

        def _json_response(self, data: dict, status: int = 200) -> None:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def _handle_config_get(self, key: str | None = None) -> None:
            import tianlong.config as cfg
            data = cfg.ensure_config()
            allowed = cfg.ALLOWED_KEYS
            sensitive = cfg.SENSITIVE_KEYS
            if key:
                if key not in allowed:
                    return self._json_response({"error": f"未知配置项: {key}"}, 400)
                masked = "********" if key in sensitive and key in data else data.get(key, "")
                has = key in data
                return self._json_response({"key": key, "set": has, "value": masked, "description": allowed[key]})
            result = {}
            for k, desc in allowed.items():
                if k in data:
                    result[k] = {"set": True, "value": "********" if k in sensitive else data[k], "description": desc}
                else:
                    result[k] = {"set": False, "value": "", "description": desc}
            self._json_response(result)

        def _handle_config_set(self) -> None:
            import tianlong.config as cfg
            body = self._read_body()
            key = body.get("key", "")
            value = body.get("value", "")
            if key not in cfg.ALLOWED_KEYS:
                return self._json_response({"error": f"不允许的配置项: {key}"}, 400)
            data = cfg.ensure_config()
            data[key] = value
            cfg.save_config(data)
            self._json_response({"success": True, "key": key, "message": f"{key} 已保存"})

        def _handle_config_delete(self, key: str) -> None:
            import tianlong.config as cfg
            data = cfg.ensure_config()
            if key not in data:
                return self._json_response({"error": f"{key} 未设置，无需删除"}, 400)
            del data[key]
            cfg.save_config(data)
            self._json_response({"success": True, "key": key, "message": f"{key} 已删除"})

        def log_message(self, fmt, *args) -> None:
            sys.stderr.write(f"[dashboard] {args[0]} {args[1]} {args[2]}\n")

    host = "0.0.0.0"
    with socketserver.TCPServer((host, port), DashboardHandler) as httpd:
        print()
        print("  SentriKit Dashboard Live Preview")
        print("  " + "=" * 40)
        print(f"  URL:   http://localhost:{port}")
        print(f"  Project: {project.name}")
        print(f"  Stop:  Ctrl+C")
        print("  " + "=" * 40)
        print()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n  Server stopped.")
            httpd.server_close()


def _fetch_tenants(api_host: str, tenant_ids: list[str]) -> dict:
    """Fetch tenant data from API gateway."""
    import urllib.request
    import urllib.error

    result = {}

    try:
        resp = urllib.request.urlopen(f"{api_host}/api/tenants", timeout=5)
        all_tenants = json.loads(resp.read()).get("tenants", [])
    except Exception:
        result["_error"] = f"Unable to connect to gateway: {api_host}"
        return result

    targets = tenant_ids if tenant_ids else all_tenants
    for tid in targets:
        try:
            resp = urllib.request.urlopen(f"{api_host}/api/tenants/{tid}/snapshot", timeout=5)
            snap = json.loads(resp.read())
            result[tid] = snap
            try:
                resp2 = urllib.request.urlopen(f"{api_host}/api/tenants/{tid}", timeout=5)
                detail = json.loads(resp2.read())
                result[tid]["project_dir"] = detail.get("project_dir", "")
            except Exception:
                pass
        except urllib.error.HTTPError as e:
            if e.code == 404:
                result[tid] = {"is_idle": True, "queue_length": 0, "error": "not found"}
            else:
                result[tid] = {"error": str(e)}
        except Exception as e:
            result[tid] = {"error": str(e)}

    return result


def _collect_monitor(project: Path) -> dict:
    try:
        from tianlong.monitor import run_all_checks
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            fut = pool.submit(run_all_checks, project)
            report = fut.result(timeout=15)
        return report.to_dict()
    except concurrent.futures.TimeoutError:
        return {"overall": "timeout", "summary": {"total": 0, "ok": 0, "warning": 0, "error": 0}}
    except Exception as e:
        return {"overall": "error", "summary": {}, "error": str(e)}


def _collect_uxu(project: Path, free_only: bool) -> dict:
    try:
        from tianlong.uxu import Scanner
        import concurrent.futures
        scanner = Scanner(free_only=free_only)
        with concurrent.futures.ThreadPoolExecutor() as pool:
            fut = pool.submit(scanner.scan, str(project))
            report = fut.result(timeout=30)
        return report.to_dict()
    except concurrent.futures.TimeoutError:
        return {"summary": {"grade": "TIMEOUT", "score": 0, "total": 0}, "error": "CodeVigil scan timed out (30s)"}
    except Exception as e:
        return {"summary": {"grade": "N/A", "score": 0, "total": 0}, "error": str(e)}


def _collect_judge(project: Path) -> dict:
    try:
        from tianlong.judge import JudgeHistory, EvolutionDashboard
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            fut = pool.submit(
                lambda: EvolutionDashboard(history=JudgeHistory(path=str(project / "judge-history.json"))).compute()
            )
            return fut.result(timeout=10)
    except Exception:
        return {"overall_health": "unknown"}


def _collect_safety(project: Path) -> dict:
    try:
        log_path = project / "brain" / "audit-log.json"
        if log_path.exists():
            logs = json.loads(log_path.read_text(encoding="utf-8"))
            recent = logs[-50:] if isinstance(logs, list) else []
            return {
                "recent_checks": len(recent),
                "recent_blocked": sum(1 for l in recent if not l.get("allowed", True)),
            }
    except Exception:
        pass
    return {"recent_checks": 0, "recent_blocked": 0}


def _collect_metacog(project: Path) -> dict:
    try:
        from tianlong.metacog import MetaCogTrigger
        from datetime import datetime
        wm = project / "brain" / "working-memory.md"
        el = project / "brain" / "error-log.md"
        trigger = MetaCogTrigger()

        err_count = 0
        if el.exists():
            content = el.read_text(encoding="utf-8", errors="replace")
            err_count = content.count("- ID:")
        total_errors = min(err_count, 20)
        sr7 = max(0.0, 1.0 - total_errors / 20.0)
        sr3 = max(0.0, 1.0 - min(err_count, 10) / 15.0)

        days_since = 0
        if wm.exists():
            mtime = datetime.fromtimestamp(wm.stat().st_mtime)
            days_since = (datetime.now() - mtime).days

        result = trigger.evaluate(
            success_rate_7d=sr7, success_rate_3d=sr3, success_rate_1d=1.0,
            days_since_last_improvement=days_since,
            repeat_error_count=min(err_count, 10),
        )
        return {
            "should_evolve": result.should_evolve,
            "overall_score": result.overall_score,
            "max_level": result.max_level,
            "message": result.summary_line,
        }
    except Exception as e:
        return {"error": str(e)}


def _collect_uxu_v2(project: Path) -> dict:
    """收集UXU评分v2（pillar明细+薄弱环节）。"""
    try:
        from tianlong.uxu import Scanner
        scanner = Scanner(min_severity="medium")
        report = scanner.scan(str(project))
        d = report.to_dict()
        s = d.get("summary", {}).get("score", {})
        return {
            "grade": s.get("grade", "?"),
            "total": s.get("total", 100),
            "is_score": s.get("is_score", 100),
            "si_score": s.get("si_score", 100),
            "pm_score": s.get("pm_score", 100),
            "weakest_pillar": s.get("weakest_pillar", ""),
            "pillars": s.get("pillars", {}),
        }
    except Exception as e:
        return {"error": str(e)}


def _collect_dgmh(project: Path) -> dict:
    """收集DGM-H元认知状态。"""
    try:
        from tianlong.dgmh import DGOrchestrator
        dgmh = DGOrchestrator(project_dir=str(project))
        s = dgmh.check_activation()
        return {
            "dgmh_phase1": s.phase1_ready,
            "dgmh_phase2": s.phase2_ready,
            "dgmh_phase3": s.phase3_ready,
        }
    except Exception as e:
        return {"error": str(e)}


if __name__ == "__main__":
    sys.exit(main())
