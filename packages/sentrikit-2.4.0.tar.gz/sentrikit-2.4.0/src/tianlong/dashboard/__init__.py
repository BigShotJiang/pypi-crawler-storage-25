"""tianlong.dashboard — 可视化仪表盘

纯内联 HTML/CSS/JS，零外部依赖。
非技术用户也能看懂：大号颜色卡片、进度条、圆环图。

用法:
    tianlong-dashboard -d . > dashboard.html        # 开源版：静态HTML
    tianlong-dashboard --tenants all                # 企业版：多租户
    tianlong-dashboard --serve                      # 企业版：实时预览
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from tianlong.dgmh import DGOrchestrator
from tianlong.config import ensure_config, ALLOWED_KEYS, SENSITIVE_KEYS

# Sub-Agent 角色标签（原 brain.dispatcher 常量，内联以避免闭源依赖）
AGENT_LABELS = {
    "researcher": "🔬",
    "coder": "💻",
    "tester": "🧪",
    "monitor": "📊",
    "operator": "⚙️",
}


HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; background:#0f172a; color:#e2e8f0; min-height:100vh; }}
.header {{ background:linear-gradient(135deg,#1e293b,#0f172a); padding:24px 32px; border-bottom:1px solid #334155; }}
.header h1 {{ font-size:22px; color:#f8fafc; }}
.header .meta {{ color:#94a3b8; font-size:13px; margin-top:2px; }}

/* 顶部概览卡片 */
.top-row {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:12px; padding:16px 32px; }}
.stat-card {{ background:#1e293b; border-radius:12px; padding:16px; text-align:center; border:1px solid #334155; }}
.stat-card .icon {{ font-size:28px; }}
.stat-card .number {{ font-size:30px; font-weight:700; margin:4px 0; }}
.stat-card .label {{ color:#94a3b8; font-size:12px; }}

/* 进度环（伪元素实现） */
.ring {{ width:80px; height:80px; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; position:relative; margin:8px 0; }}
.ring-inner {{ font-size:20px; font-weight:700; z-index:1; }}

/* 卡片网格 */
.grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(340px,1fr)); gap:16px; padding:0 32px 24px; }}
.card {{ background:#1e293b; border-radius:12px; padding:20px; border:1px solid #334155; }}
.card h2 {{ font-size:14px; color:#94a3b8; margin-bottom:12px; letter-spacing:0.05em; }}

/* 进度条 */
.bar {{ height:8px; border-radius:4px; background:#334155; margin:8px 0; overflow:hidden; }}
.bar-fill {{ height:100%; border-radius:4px; transition:width 0.5s; }}
.bar-fill-green {{ background:linear-gradient(90deg,#22c55e,#4ade80); }}
.bar-fill-yellow {{ background:linear-gradient(90deg,#f59e0b,#fbbf24); }}
.bar-fill-red {{ background:linear-gradient(90deg,#ef4444,#f87171); }}
.bar-fill-blue {{ background:linear-gradient(90deg,#3b82f6,#60a5fa); }}

/* 数据行 */
.row {{ display:flex; justify-content:space-between; padding:6px 0; font-size:13px; border-bottom:1px solid #1e293b; }}
.row:last-child {{ border-bottom:none; }}
.label {{ color:#94a3b8; }}
.val {{ color:#e2e8f0; font-weight:500; }}

/* 标签 */
.badge {{ display:inline-block; padding:1px 8px; border-radius:4px; font-size:11px; }}
.badge-ok {{ background:#166534; color:#22c55e; }}
.badge-warning {{ background:#78350f; color:#f59e0b; }}
.badge-error {{ background:#7f1d1d; color:#ef4444; }}

/* 发现表格（可滚动） */
.findings-wrap {{ overflow-x:auto; }}
table {{ width:100%; border-collapse:collapse; font-size:12px; }}
th {{ text-align:left; padding:8px 10px; color:#94a3b8; border-bottom:1px solid #334155; font-weight:500; }}
td {{ padding:8px 10px; border-bottom:1px solid #1e293b; }}

/* 租户卡片 */
.tenant-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:12px; padding:0 32px 24px; }}
.tenant-card {{ background:#1e293b; border-radius:12px; padding:16px; border:1px solid #334155; }}
.tenant-card h3 {{ font-size:15px; color:#f8fafc; margin-bottom:8px; }}
.tenant-card .row {{ font-size:12px; padding:4px 0; }}

.footer {{ text-align:center; color:#475569; font-size:11px; padding:16px; border-top:1px solid #334155; }}
</style>
</head>
<body>
<div class="header">
    <h1>{title}</h1>
    <div class="meta">{timestamp} | 项目: {project_dir}</div>
</div>

<!-- 顶部概览卡片（4个核心指标） -->
<div class="top-row">
    <div class="stat-card">
        <div class="icon">{health_icon}</div>
        <div class="number" style="color:{health_color}">{health_text}</div>
        <div class="label">系统健康</div>
    </div>
    <div class="stat-card">
        <div class="icon">🛡️</div>
        <div class="number" style="color:{security_color}">{security_grade}</div>
        <div class="label">安全等级</div>
    </div>
    <div class="stat-card">
        <div class="icon">{judge_icon}</div>
        <div class="number" style="color:{judge_color}">{judge_text}</div>
        <div class="label">进化状态</div>
    </div>
    <div class="stat-card">
        <div class="icon">⏱️</div>
        <div class="number" style="color:#60a5fa">{cron_count}</div>
        <div class="label">活跃Cron任务</div>
    </div>
</div>

<!-- 进度环（4个核心指标可视化） -->
<div class="top-row">
    <div class="stat-card">
        <div class="label">健康检查通过率</div>
        <div class="ring" style="background:conic-gradient({health_ring_color} 0deg {health_angle}deg, #334155 {health_angle}deg 360deg);">
            <div class="ring-inner" style="color:{health_color}">{health_pct}</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="label">安全检查分</div>
        <div class="ring" style="background:conic-gradient({security_ring_color} 0deg {security_angle}deg, #334155 {security_angle}deg 360deg);">
            <div class="ring-inner" style="color:{security_color}">{security_pct}</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="label">进化评分</div>
        <div class="ring" style="background:conic-gradient({judge_ring_color} 0deg {judge_angle}deg, #334155 {judge_angle}deg 360deg);">
            <div class="ring-inner" style="color:{judge_color}">{judge_pct}</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="label">退化检测</div>
        <div class="ring" style="background:conic-gradient({degradation_color} 0deg {degradation_angle}deg, #334155 {degradation_angle}deg 360deg);">
            <div class="ring-inner" style="color:{degradation_color}">{degradation_score}</div>
        </div>
    </div>
</div>

<!-- 详情网格 -->
<div class="grid">
    <div class="card">
        <h2>🔍 健康检查</h2>
        <div class="row"><span class="label">通过</span><span class="val">{health_ok}/{health_total}</span></div>
        <div class="bar"><div class="bar-fill bar-fill-green" style="width:{health_ok_pct}%"></div></div>
        <div class="row"><span class="label">警告</span><span class="val" style="color:#f59e0b">{health_warning}</span></div>
        <div class="row"><span class="label">错误</span><span class="val" style="color:#ef4444">{health_error}</span></div>
        <div class="row"><span class="label">MetaCog退化</span><span class="val">{degradation_msg}</span></div>
    </div>
    <div class="card">
        <h2>🛡️ 代码安全 (CodeVigil)</h2>
        <div class="row"><span class="label">安全等级</span><span class="val score-{uxu_grade}" style="font-size:24px;font-weight:700">{uxu_grade}</span></div>
        <div class="row"><span class="label">扫描文件</span><span class="val">{uxu_files}</span></div>
        <div class="row"><span class="label">发现数</span><span class="val">{uxu_findings}</span></div>
        <div class="row"><span class="label">严重</span><span class="val" style="color:#ef4444">{uxu_critical}</span></div>
        <div class="row"><span class="label">高危</span><span class="val" style="color:#f59e0b">{uxu_high}</span></div>
    </div>
    <div class="card">
        <h2>🧠 进化评估</h2>
        <div class="row"><span class="label">综合评分</span><span class="val">{judge_score}</span></div>
        <div class="bar"><div class="bar-fill bar-fill-blue" style="width:{judge_score_pct}%"></div></div>
        <div class="row"><span class="label">总提案数</span><span class="val">{judge_proposals}</span></div>
        <div class="row"><span class="label">通过率</span><span class="val" style="color:#22c55e">{judge_pass_rate}</span></div>
        <div class="row"><span class="label">等级</span><span class="val">{judge_grade}</span></div>
    </div>
    <div class="card">
        <h2>⚡ 安全约束 (SafetyGuard)</h2>
        <div class="row"><span class="label">状态</span><span class="val">{safety_status}</span></div>
        <div class="row"><span class="label">总检查</span><span class="val">{safety_checks}</span></div>
        <div class="row"><span class="label">已阻止</span><span class="val" style="color:#ef4444">{safety_blocked}</span></div>
        <div class="row"><span class="label">红线规则</span><span class="val">6条 (R1-R6)</span></div>
    </div>
    <div class="card">
        <h2>🤖 Sub-Agent</h2>
        <div class="row"><span class="label">派发次数</span><span class="val">{agent_count}</span></div>
        <div class="row"><span class="label">可用角色</span><span class="val">Research / Code / Executor / Monitor</span></div>
        <div class="row"><span class="label">DGM-H元认知</span><span class="val">{dgmh_status}</span></div>
    </div>
    <div class="card">
        <h2>📊 CodeVigil 安全评分 v2</h2>
        <div class="row"><span class="label">综合等级</span><span class="val" style="font-size:20px;font-weight:700">{ux2_grade}</span></div>
        <div class="row"><span class="label">总分</span><span class="val">{ux2_total}</span></div>
        <div class="bar"><div class="bar-fill bar-fill-blue" style="width:{ux2_total}%"></div></div>
        {ux2_pillars_html}
        <div class="row"><span class="label">最弱环节</span><span class="val" style="color:#ef4444">{ux2_weakest}</span></div>
    </div>
    <div class="card">
        <h2>🧠 DGM-H元认知</h2>
        <div class="row"><span class="label">Phase1</span><span class="val">{dg_p1}</span></div>
        <div class="row"><span class="label">Phase2</span><span class="val">{dg_p2}</span></div>
        <div class="row"><span class="label">Phase3</span><span class="val">{dg_p3}</span></div>
        <div class="row"><span class="label">命中率</span><span class="val" style="color:#22c55e">{dg_hit_pct}</span></div>
    </div>
    <div class="card">
        <h2>⏰ Cron 调度</h2>
        <div class="row"><span class="label">活跃任务</span><span class="val">{cron_count}</span></div>
        <div class="row"><span class="label">健康检查</span><span class="val">{cron_health}</span></div>
        <div class="row"><span class="label">市场调研</span><span class="val">每2h</span></div>
        <div class="row"><span class="label">知识沉淀</span><span class="val">每12h</span></div>
        <div class="row"><span class="label">EVOLVE</span><span class="val">每日</span></div>
    </div>
</div>

<!-- 发现清单 -->
{findings_section}

<!-- 历史趋势 -->
{trend_section}

<!-- 多租户 -->
{tenants_section}

<!-- 配置管理 -->
<h2 style="padding:0 32px 8px;font-size:14px;color:#94a3b8;">🔧 配置管理</h2>
<div class="grid">
    <div class="card" id="config-card">
        <h2>🔑 API凭证管理</h2>
        <div id="config-list"></div>
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #334155;">
            <select id="config-key-select" style="background:#1e293b;color:#e2e8f0;border:1px solid #334155;border-radius:6px;padding:6px 10px;font-size:13px;width:100%;margin-bottom:8px;">
                {config_options}
            </select>
            <input id="config-value-input" type="password" placeholder="输入凭证值..." style="background:#1e293b;color:#e2e8f0;border:1px solid #334155;border-radius:6px;padding:6px 10px;font-size:13px;width:100%;margin-bottom:8px;box-sizing:border-box;">
            <div style="display:flex;gap:8px;">
                <button onclick="saveConfig()" style="flex:1;background:#2563eb;color:white;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:13px;">💾 保存</button>
                <button onclick="deleteConfig()" style="flex:1;background:#dc2626;color:white;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:13px;">🗑️ 删除</button>
            </div>
            <div id="config-msg" style="margin-top:8px;font-size:12px;color:#94a3b8;"></div>
        </div>
    </div>
</div>

<script>
async function loadConfig() {{
    try {{
        const r = await fetch('/api/config');
        const data = await r.json();
        const list = document.getElementById('config-list');
        let html = '';
        for (const [key, info] of Object.entries(data)) {{
            const status = info.set ? '✅' : '❌';
            const val = info.set ? info.value : '未设置';
            html += '<div class="row"><span class="label">' + status + ' ' + key + '</span><span class="val">' + val + '</span></div>';
        }}
        list.innerHTML = html;
    }} catch(e) {{
        document.getElementById('config-list').innerHTML = '<div style="color:#ef4444;font-size:12px;">⚠️ 配置服务不可用（仅在 --serve 模式下可用）</div>';
    }}
}}
async function saveConfig() {{
    const key = document.getElementById('config-key-select').value;
    const val = document.getElementById('config-value-input').value;
    if (!val) {{ showMsg('请输入凭证值', '#f59e0b'); return; }}
    try {{
        const r = await fetch('/api/config', {{ method:'POST', headers:{{'Content-Type':'application/json'}}, body:JSON.stringify({{key, value:val}}) }});
        const data = await r.json();
        if (data.success) {{ showMsg('✅ ' + data.message, '#22c55e'); loadConfig(); document.getElementById('config-value-input').value = ''; }}
        else {{ showMsg('❌ ' + (data.error || '失败'), '#ef4444'); }}
    }} catch(e) {{ showMsg('❌ 保存失败: ' + e.message, '#ef4444'); }}
}}
async function deleteConfig() {{
    const key = document.getElementById('config-key-select').value;
    if (!confirm('确定删除 ' + key + ' 吗？')) return;
    try {{
        const r = await fetch('/api/config/' + key, {{ method:'DELETE' }});
        const data = await r.json();
        if (data.success) {{ showMsg('✅ ' + data.message, '#22c55e'); loadConfig(); }}
        else {{ showMsg('❌ ' + (data.error || '失败'), '#ef4444'); }}
    }} catch(e) {{ showMsg('❌ 删除失败: ' + e.message, '#ef4444'); }}
}}
function showMsg(msg, color) {{
    const el = document.getElementById('config-msg');
    el.textContent = msg; el.style.color = color;
    setTimeout(() => {{ el.textContent = ''; }}, 3000);
}}
loadConfig();

{AUTO_REFRESH_JS}
</script>

<div style="text-align:center;font-size:12px;color:#475569;padding:4px 16px 16px;">最后更新: <span id="last-update">生成时</span> | 每30秒自动刷新</div>
<div class="footer">{footer_text}</div>
</body>
</html>"""


def build_dashboard(
    project_dir: str = ".",
    monitor_data: Optional[Dict] = None,
    uxu_data: Optional[Dict] = None,
    judge_data: Optional[Dict] = None,
    safety_data: Optional[Dict] = None,
    cron_data: Optional[Dict] = None,
    metacog_data: Optional[Dict] = None,
    tenant_data: Optional[Dict] = None,
    title: str = "SentriKit · 可视化仪表盘",
    judge_history_path: Optional[str] = None,
    # v2 新增参数
    uxu_score_v2: Optional[Dict] = None,
    dgmh_data: Optional[Dict] = None,
    reporter_data: Optional[Dict] = None,
    enterprise_mode: bool = False,
) -> str:
    """构建可视化 HTML 仪表盘。

    Args:
        enterprise_mode: 企业版模式（启用实时数据、多租户等高级功能）。
    """

    # ── 健康数据 ──
    m = monitor_data or {}
    ms = m.get("summary", {})
    overall = m.get("overall", "unknown")
    health_icon = {"healthy": "✅", "warning": "⚠️", "error": "🔴"}.get(overall, "❓")
    health_color = {"healthy": "#22c55e", "warning": "#f59e0b", "error": "#ef4444"}.get(overall, "#94a3b8")
    health_text = overall.upper()
    health_ok = ms.get("ok", 0)
    health_total = ms.get("total", 1)
    health_warning = ms.get("warning", 0)
    health_error = ms.get("error", 0)
    health_pct = f"{int(health_ok / max(health_total,1) * 100)}%"
    health_angle = int(health_ok / max(health_total, 1) * 360)
    health_ok_pct = int(health_ok / max(health_total, 1) * 100)
    health_ring_color = health_color

    # ── CodeVigil 安全 ──
    u = uxu_data or {}
    us = u.get("summary", {})
    uxu_grade = us.get("grade", "N/A") or "N/A"
    uxu_score = us.get("score", 0) or 0
    uxu_findings = us.get("total", 0) or 0
    uxu_files = us.get("files_scanned", 0) or 0
    uxu_findings_list = u.get("findings", [])
    uxu_critical = sum(1 for f in uxu_findings_list if f.get("severity") == "critical")
    uxu_high = sum(1 for f in uxu_findings_list if f.get("severity") == "high")

    # 安全评分显示
    security_grade = uxu_grade if uxu_grade != "N/A" else "A"
    security_score_raw = int(uxu_score) if isinstance(uxu_score, (int, float)) else 100
    security_pct = f"{min(security_score_raw, 100)}%"
    security_angle = min(int(security_score_raw / 100 * 360), 360)
    if security_score_raw >= 80:
        security_color = "#22c55e"
        security_ring_color = "#22c55e"
    elif security_score_raw >= 50:
        security_color = "#f59e0b"
        security_ring_color = "#f59e0b"
    else:
        security_color = "#ef4444"
        security_ring_color = "#ef4444"

    # ── Judge 进化 ──
    j = judge_data or {}
    judge_health = j.get("overall_health", "unknown")
    judge_icon = {"healthy": "🧬", "warning": "⚠️", "error": "🔴", "unknown": "❓"}.get(judge_health, "❓")
    judge_color = {"healthy": "#22c55e", "warning": "#f59e0b", "error": "#ef4444"}.get(judge_health, "#94a3b8")
    judge_text = judge_health.upper() if judge_health else "UNKNOWN"
    judge_proposals = j.get("total_proposals", 0) or 0
    judge_score_val = j.get("overall_score", 0) or 0
    judge_grade = j.get("overall_grade", "D") or "D"

    ind = j.get("judge", {}).get("indicators", {})
    judge_pass_rate_raw = ind.get("pass_rate", {}).get("value", 0) or 0
    judge_pass_rate = f"{judge_pass_rate_raw:.0%}" if isinstance(judge_pass_rate_raw, float) else f"{judge_pass_rate_raw}%"

    judge_score_pct = int(min(float(judge_score_val) * 100 if float(judge_score_val) <= 1.0 else float(judge_score_val), 100))
    judge_pct = f"{judge_score_pct}%"
    judge_angle = int(judge_score_pct / 100 * 360)
    judge_ring_color = judge_color

    # ── Safety ──
    sf = safety_data or {}
    safety_checks = sf.get("recent_checks", 0) or 0
    safety_blocked = sf.get("recent_blocked", 0) or 0
    safety_status = "✅ 正常" if safety_blocked == 0 else f"⚠️ 已阻止{safety_blocked}次"

    # ── UXU评分v2 ──
    ux2 = uxu_score_v2 or {}
    ux2_grade = ux2.get("grade", uxu_grade)
    ux2_total = ux2.get("total", uxu_score)
    ux2_is = ux2.get("is_score", 0)
    ux2_si = ux2.get("si_score", 0)
    ux2_pm = ux2.get("pm_score", 0)
    ux2_weakest = ux2.get("weakest_pillar", "")
    ux2_pillars_html = ""
    if ux2.get("pillars"):
        for pid, ps in ux2["pillars"].items():
            pscore = ps.get("score", 0)
            pgrade = ps.get("grade", "?")
            pfind = ps.get("findings", 0)
            color = {"IS": "#ef4444", "SI": "#f59e0b", "PM": "#22c55e"}.get(pid, "#94a3b8")
            ux2_pillars_html += (
                f'<div class="row"><span class="label" style="color:{color}">{ps.get("name",pid)}</span>'
                f'<span class="val">{pgrade} ({pscore:.0f}) {pfind}条</span></div>'
            )

    # ── DGM-H 元认知 ──
    dg = dgmh_data or {}
    dg_p1 = "✅" if dg.get("dgmh_phase1") else "❌"
    dg_p2 = "✅" if dg.get("dgmh_phase2") else "❌"
    dg_p3 = "✅" if dg.get("dgmh_phase3") else "❌"
    dg_hit = dg.get("hit_rate", 0)
    dg_miss = dg.get("miss_rate", 0)
    dg_suggestions = dg.get("suggestions", [])
    dg_adjust = dg.get("priority_adjust", "")
    dg_hit_pct = f"{dg_hit:.0%}" if isinstance(dg_hit, float) else f"{dg_hit}%"

    # ── Cron ──
    cr = cron_data or {}
    cron_count = cr.get("active", 5)
    cron_health_raw = cr.get("health_report", "")
    cron_health = cron_health_raw or "每6h检查"

    # ── MetaCog ──
    mc = metacog_data or {}
    degradation_score_raw = mc.get("overall_score", 0) or 0
    degradation_score = f"{degradation_score_raw:.2f}"
    degradation_pct = f"{int(min(degradation_score_raw * 100, 100))}%"
    degradation_angle = int(min(degradation_score_raw * 360, 360))
    degradation_msg = mc.get("message", "无数据")
    degradation_color = "#22c55e"
    if degradation_score_raw > 0.3:
        degradation_color = "#f59e0b"
    if degradation_score_raw > 0.6:
        degradation_color = "#ef4444"

    # ── Sub-Agent ──
    agent_count = len(AGENT_LABELS)
    dgmh_status = _get_dgmh_status()

    # ── Findings 表格 ──
    top20 = uxu_findings_list[:20]
    if top20:
        rows = "\n".join(
            f'<tr><td>{f.get("rule_id","")}</td>'
            f'<td><span class="badge badge-{f.get("severity","low")}">{f.get("severity","")}</span></td>'
            f'<td>{f.get("title","")[:40]}</td>'
            f'<td>{f.get("file","").split("/")[-1] if f.get("file") else ""}</td></tr>'
            for f in top20
        )
        findings_section = (
            '<div class="grid"><div class="card">'
            '<h2>📋 发现清单 (TOP 20)</h2>'
            '<div class="findings-wrap"><table>'
            '<tr><th>规则</th><th>等级</th><th>标题</th><th>文件</th></tr>'
            f'{rows}</table></div></div></div>'
        )
    else:
        findings_section = ""

    # ── Judge历史趋势SVG ──
    trend_section = _build_trend_svg(judge_history_path)

    # ── 多租户 ──
    if tenant_data:
        cards = []
        for tid, td in tenant_data.items():
            idle = td.get("is_idle", True)
            icon = "✅" if idle else "⏳"
            qlen = td.get("queue_length", 0)
            proj = td.get("project_dir", "")
            short_proj = "/".join(proj.split("/")[-2:]) if proj else ""
            cards.append(
                f'<div class="tenant-card">'
                f'<h3>{icon} {tid}</h3>'
                f'<div class="row"><span class="label">目录</span><span class="val">{short_proj}</span></div>'
                f'<div class="row"><span class="label">状态</span><span class="val">{"空闲" if idle else "运行中"}</span></div>'
                f'<div class="row"><span class="label">队列</span><span class="val">{qlen}</span></div>'
                f'</div>'
            )
        tenants_section = (
            '<h2 style="padding:0 32px 8px;font-size:14px;color:#94a3b8;">🏢 多租户概览</h2>'
            f'<div class="tenant-grid">{"".join(cards)}</div>'
        )
    else:
        tenants_section = ""

    # ── 配置选项 ──
    config_opts = "\n".join(
        f'<option value="{k}">{k} — {desc}</option>'
        for k, desc in ALLOWED_KEYS.items()
    )

    # 自动刷新 JS（单独定义，避免内联花括号与 format 冲突）
    auto_refresh_js = """if (window.location.protocol === 'http:') {
    setInterval(function() {
        var lu = document.getElementById('last-update');
        if (lu) lu.textContent = '刷新中...';
        fetch(window.location.href).then(function(r) { return r.text(); }).then(function(html) {
            var parser = new DOMParser();
            var doc = parser.parseFromString(html, 'text/html');
            var cards = doc.querySelectorAll('.card');
            document.querySelectorAll('.card').forEach(function(oldCard, i) {
                if (cards[i]) oldCard.innerHTML = cards[i].innerHTML;
            });
            document.querySelector('.top-row').innerHTML = doc.querySelector('.top-row').innerHTML;
            if (lu) lu.textContent = new Date().toLocaleTimeString();
        }).catch(function() {});
    }, 30000);
}"""

    return HTML_TEMPLATE.format(
        title=title,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        project_dir=project_dir,
        health_icon=health_icon, health_color=health_color, health_text=health_text,
        health_ok=health_ok, health_total=health_total,
        health_warning=health_warning, health_error=health_error,
        health_pct=health_pct, health_angle=health_angle, health_ok_pct=health_ok_pct, health_ring_color=health_ring_color,
        uxu_grade=uxu_grade, uxu_score=uxu_score, uxu_findings=uxu_findings,
        uxu_files=uxu_files, uxu_critical=uxu_critical, uxu_high=uxu_high,
        security_grade=security_grade, security_pct=security_pct, security_angle=security_angle,
        security_color=security_color, security_ring_color=security_ring_color,
        judge_icon=judge_icon, judge_color=judge_color, judge_text=judge_text,
        judge_proposals=judge_proposals, judge_score=judge_score_val,
        judge_grade=judge_grade, judge_pass_rate=judge_pass_rate,
        judge_score_pct=judge_score_pct, judge_pct=judge_pct, judge_angle=judge_angle,
        judge_ring_color=judge_ring_color,
        safety_status=safety_status, safety_checks=safety_checks,
        safety_blocked=safety_blocked,
        cron_count=cron_count, cron_health=cron_health,
        agent_count=agent_count, dgmh_status=dgmh_status,
        degradation_score=degradation_score, degradation_pct=degradation_pct, degradation_angle=degradation_angle,
        degradation_msg=degradation_msg, degradation_color=degradation_color,
        # v2
        ux2_grade=ux2_grade, ux2_total=ux2_total,
        ux2_is=ux2_is, ux2_si=ux2_si, ux2_pm=ux2_pm, ux2_weakest=ux2_weakest, ux2_pillars_html=ux2_pillars_html,
        dg_p1=dg_p1, dg_p2=dg_p2, dg_p3=dg_p3, dg_hit_pct=dg_hit_pct,
        findings_section=findings_section,
        trend_section=trend_section,
        tenants_section=tenants_section,
        config_options=config_opts,
        AUTO_REFRESH_JS=auto_refresh_js,
        footer_text="由 tianlong-toolkit 开源版生成 🐉" if not enterprise_mode else "由 tianlong-toolkit 企业版生成 🔒",
    )


def _build_trend_svg(judge_history_path: Optional[str] = None) -> str:
    """从 judge-history.json 生成进化评分趋势 SVG 迷你图。

    返回一个 <div class="card"> 含内联 SVG 的 HTML 片段，
    无历史数据时返回空字符串。
    """
    if not judge_history_path:
        return ""
    try:
        history_path = Path(judge_history_path)
        if not history_path.exists():
            return ""
        import json as _json
        with open(history_path, "r", encoding="utf-8") as f:
            records = _json.load(f)
        if not isinstance(records, list) or len(records) < 2:
            return ""
    except Exception:
        return ""

    # 提取评分和通过状态
    scores = []
    labels = []
    passes = []
    for r in records:
        ts = r.get("timestamp", "")
        sc = r.get("total_score", 0)
        pa = r.get("passed", False)
        try:
            if isinstance(sc, (int, float)):
                scores.append(min(float(sc), 1.0))
                # 取时间最后5字符 (HH:MM)
                labels.append(ts[-5:] if len(ts) >= 5 else str(len(scores)))
                passes.append(pa)
        except Exception:
            continue

    if len(scores) < 2:
        return ""

    # 只取最近30条
    if len(scores) > 30:
        scores = scores[-30:]
        labels = labels[-30:]
        passes = passes[-30:]

    # SVG 尺寸
    W, H = 600, 120
    PAD = (40, 20, 20, 10)  # left, top, right, bottom
    plot_w = W - PAD[0] - PAD[2]
    plot_h = H - PAD[1] - PAD[3]

    min_s = min(scores)
    max_s = max(scores)
    if max_s == min_s:
        max_s = min_s + 0.1
    s_range = max_s - min_s

    n = len(scores)
    step_x = plot_w / (n - 1) if n > 1 else plot_w

    # 构建折线路径
    points = []
    for i, s in enumerate(scores):
        x = PAD[0] + i * step_x
        y = PAD[1] + plot_h - ((s - min_s) / s_range * plot_h)
        points.append((x, y))

    path_d = "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in points)
    # 填充区域
    fill_d = path_d + f" L {points[-1][0]:.1f},{PAD[1]+plot_h:.1f} L {points[0][0]:.1f},{PAD[1]+plot_h:.1f} Z"

    # 网格线 (4条水平)
    grid_lines = ""
    grid_labels = ""
    for i in range(5):
        y = PAD[1] + plot_h * (1 - i / 4)
        val = min_s + s_range * (i / 4)
        grid_lines += f'<line x1="{PAD[0]}" y1="{y:.1f}" x2="{W-PAD[2]}" y2="{y:.1f}" stroke="#334155" stroke-width="0.5"/>'
        grid_labels += f'<text x="{PAD[0]-4}" y="{y+3:.1f}" text-anchor="end" fill="#64748b" font-size="8">{val:.2f}</text>'

    # 散点 (圆圈)
    circles = ""
    for i, (x, y) in enumerate(points):
        color = "#22c55e" if passes[i] else "#ef4444"
        circles += f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.5" fill="{color}" stroke="#0f172a" stroke-width="1"/>'

    # X轴标签 (只显示首尾+中间)
    xlabels = ""
    for idx in [0, n // 2, n - 1]:
        if idx < len(labels):
            xlabels += f'<text x="{points[idx][0]:.1f}" y="{H-4}" text-anchor="middle" fill="#64748b" font-size="7">{labels[idx]}</text>'

    svg = (
        f'<div class="card">'
        f'<h2>📈 进化评分趋势 (最近{n}条)</h2>'
        f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" style="width:100%;height:auto;max-height:140px;">'
        f'{grid_lines}'
        f'{grid_labels}'
        f'<path d="{fill_d}" fill="url(#trendGrad)" opacity="0.15"/>'
        f'<path d="{path_d}" fill="none" stroke="#60a5fa" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>'
        f'{circles}'
        f'{xlabels}'
        f'<defs>'
        f'<linearGradient id="trendGrad" x1="0" y1="0" x2="0" y2="1">'
        f'<stop offset="0%" stop-color="#60a5fa"/>'
        f'<stop offset="100%" stop-color="#60a5fa" stop-opacity="0"/>'
        f'</linearGradient>'
        f'</defs>'
        f'</svg>'
        f'</div>'
    )

    return svg


def _get_dgmh_status() -> str:
    """安全获取 DGM-H 状态（企业版闭源，可能未安装）。"""
    try:
        from tianlong.dgmh import DGOrchestrator
        if DGOrchestrator is None:
            return "⚙️ DGM-H 未安装（企业版）"
        return "✅ Phase 2+3 已激活" if DGOrchestrator().check_activation().phase2_ready else "⚙️ 待激活"
    except Exception:
        return "⚙️ DGM-H 不可用"
