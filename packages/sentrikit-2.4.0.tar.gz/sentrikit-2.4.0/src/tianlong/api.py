"""tianlong.api — SentriKit HTTP API 服务

为销售宗师等外部系统提供 HTTP API 调用接口。
独立于 CLI 工具箱，纯标准库实现（零外部依赖）。

用法:
    sentrikit-api --port 8899
    # 或
    python -m tianlong.api --port 8899

端点:
    GET  /health                  — 服务健康检查
    GET  /api/status              — SentriKit模块状态
    POST /api/report              — 汇报高亮信息（调用 Reporter）
    POST /api/judge               — 评估进化方向（调用 JudgeEngine）
    GET  /api/selfmodel           — 获取自我模型数据
    GET  /api/evolution           — 获取进化报告

    # 完整进化闭环 API（标准 7 步）
    POST /api/evolve/run          — 触发完整进化闭环（学习→分析→判断→进化→验证→反射→清理）
    GET  /api/evolve/status       — 进化状态（上次时间/结果/耗时）
    POST /api/metacog/evaluate    — 传入指标 → 退化检测结果
    POST /api/judge/evaluate      — 传入提案 → 评分
    GET  /api/selfmodel/snapshot  — 返回自我模型快照
    GET  /api/verify/results      — 返回最近验证结果
    GET  /api/reflect/lessons     — 返回反射教训列表
    GET  /api/evolve/summary    — 进化仪表盘（完整概览）
    GET  /api/cleanup/candidates  — 返回清理候选列表
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import subprocess
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Dict

HERE = Path(__file__).parent
PROJECT_DIR = HERE.parent.parent  # 项目根目录
_SCRIPTS_DIR = PROJECT_DIR / "scripts"
_API_KEY: str = ""


def _load_toolkit_modules():
    """延迟加载 SentriKit 模块（避免 import 影响启动速度）"""
    sys.path.insert(0, str(PROJECT_DIR))
    sys.path.insert(0, str(PROJECT_DIR / "src"))


def _run_evolve_script(timeout: int = 120) -> dict:
    """执行 evolve_loop.py 并返回 JSON 结果"""
    script = _SCRIPTS_DIR / "evolve_loop.py"
    if not script.exists():
        return {"error": f"evolve_loop.py not found at {script}"}
    r = subprocess.run(
        [sys.executable, str(script)],
        capture_output=True, text=True, timeout=timeout,
    )
    if r.stdout:
        return json.loads(r.stdout)
    return {"error": r.stderr[:500] if r.stderr else "no output"}


class APIHandler(BaseHTTPRequestHandler):
    """HTTP API 请求处理器"""

    def log_message(self, format, *args):
        print(f"[API] {self.log_date_time_string()} {args[0]} {args[1]} {args[2]}")

    def _log_request(self, status: int, elapsed: float):
        path = self.path.split("?")[0]
        print(f"[API] {self.log_date_time_string()} {self.command} {path} -> {status} ({elapsed:.2f}s)")

    def _send_json(self, data: dict, status: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._last_status = status
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {}

    def _check_auth(self) -> bool:
        if not _API_KEY:
            return True
        return self.headers.get("X-API-Key", "") == _API_KEY

    # ── 路由分发 ──

    def do_GET(self):
        _start = time.time()
        if not self._check_auth():
            return self._send_json({"error": "unauthorized"}, 401)

        path = self.path.rstrip("/")
        if path == "/health":
            return self._handle_health()
        elif path == "/api/status":
            return self._handle_status()
        elif path == "/api/selfmodel":
            return self._handle_selfmodel()
        elif path == "/api/selfmodel/snapshot":
            return self._handle_selfmodel_snapshot()
        elif path == "/api/evolution":
            return self._handle_evolution()
        elif path == "/api/evolve/status":
            return self._handle_evolve_status()
        elif path == "/api/verify/results":
            return self._handle_verify_results()
        elif path == "/api/reflect/lessons":
            return self._handle_reflect_lessons()
        elif path == "/api/cleanup/candidates":
            return self._handle_cleanup_candidates()
        elif path == "/api/evolve/summary":
            return self._handle_evolve_summary()
        else:
            self._send_json({"error": "not found", "path": self.path}, 404)
        self._log_request(getattr(self, '_last_status', 200), time.time() - _start)

    def do_POST(self):
        _start = time.time()
        if not self._check_auth():
            return self._send_json({"error": "unauthorized"}, 401)

        path = self.path.rstrip("/")
        if path == "/api/report":
            return self._handle_report()
        elif path == "/api/judge":
            return self._handle_judge()
        elif path == "/api/evolve/run":
            return self._handle_evolve()
        elif path == "/api/metacog/evaluate":
            return self._handle_metacog_evaluate()
        elif path == "/api/judge/evaluate":
            return self._handle_judge_evaluate()
        else:
            self._send_json({"error": "not found", "path": self.path}, 404)
        self._log_request(self._last_status, time.time() - _start)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-API-Key")
        self.end_headers()

    # ── 处理器实现 ──

    def _handle_health(self):
        self._send_json({"status": "ok", "service": "sentrikit-api", "version": "1.0.0"})

    def _handle_status(self):
        _load_toolkit_modules()
        try:
            from tianlong import __version__ as ver
            from tianlong.selfmodel import SelfModel
            from tianlong.metacog import MetaCogTrigger
            sm = SelfModel(project_dir=str(PROJECT_DIR))
            mc = MetaCogTrigger()
            report = mc.evaluate()
            self._send_json({
                "version": ver,
                "selfmodel": {"decisions": len(sm.get_decisions()), "snapshots": len(sm.get_snapshots())},
                "metacog": {"should_evolve": report.should_evolve, "score": round(report.overall_score, 3), "level": report.max_level},
                "modules_available": True,
            })
        except Exception as e:
            self._send_json({"error": str(e), "modules_available": False}, 500)

    def _handle_report(self):
        _load_toolkit_modules()
        body = self._read_body()
        title = body.get("title", "报告")
        highlights = body.get("highlights", [])
        action_items = body.get("action_items", [])
        body_text = body.get("body", "")
        try:
            from tianlong.reporter import Reporter
            r = Reporter()
            r.report_highlight(title=title, body=body_text, highlights=highlights, action_items=action_items)
            self._send_json({"status": "ok", "reported": True})
        except Exception as e:
            self._send_json({"status": "error", "error": str(e)}, 500)

    def _handle_judge(self):
        _load_toolkit_modules()
        body = self._read_body()
        summary = body.get("summary", "")
        if not summary:
            return self._send_json({"error": "missing summary"}, 400)
        try:
            from tianlong.judge import RuleBasedJudge, Proposal
            judge = RuleBasedJudge()
            p = Proposal(id=f"api_{int(time.time())}", summary=summary)
            result = judge.evaluate(p)
            self._send_json({
                "grade": result.grade.value,
                "total_score": round(result.total_score, 2),
                "dimensions": [{"name": d.name, "score": d.score, "reason": d.reason} for d in result.dimensions],
            })
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_selfmodel(self):
        _load_toolkit_modules()
        try:
            from tianlong.selfmodel import SelfModel
            sm = SelfModel(project_dir=str(PROJECT_DIR))
            self._send_json({
                "decisions": sm.get_decisions(limit=20),
                "snapshots": sm.get_snapshots(limit=10),
                "capabilities": sm.capabilities(),
            })
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_selfmodel_snapshot(self):
        _load_toolkit_modules()
        try:
            from tianlong.selfmodel import SelfModel
            sm = SelfModel(project_dir=str(PROJECT_DIR))
            sm.take_snapshot()
            self._send_json({
                "status": "ok",
                "latest_snapshot": sm.get_history().get("latest_snapshot", {}),
            })
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_evolution(self):
        _load_toolkit_modules()
        try:
            from tianlong.metaevolve import MetaEVOLVE
            m = MetaEVOLVE()
            history = m.get_history()
            self._send_json({
                "metaevolve_history": history[-10:] if history else [],
            })
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_evolve(self):
        """POST /api/evolve/run — 触发完整进化闭环"""
        try:
            result = _run_evolve_script(timeout=120)
            self._send_json(result)
        except subprocess.TimeoutExpired:
            self._send_json({"error": "timeout", "detail": "进化闭环执行超过 120s"}, 504)
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_evolve_status(self):
        """GET /api/evolve/status — 进化状态"""
        _load_toolkit_modules()
        try:
            from tianlong.selfmodel import SelfModel
            sm = SelfModel(project_dir=str(PROJECT_DIR))
            history = sm.get_history()
            snapshot = history.get("latest_snapshot", {})
            decisions = history.get("recent_decisions", [])

            # 找最近的 EVOLVE 决策
            last_evolve = None
            for d in reversed(decisions):
                if d.get("decision_type") == "EVOLVE":
                    last_evolve = {
                        "timestamp": d.get("timestamp"),
                        "outcome": d.get("outcome"),
                        "task": d.get("task"),
                    }
                    break

            self._send_json({
                "last_evolve": last_evolve,
                "overall_success_rate": snapshot.get("overall_success_rate", 0),
                "judge_avg_score": snapshot.get("judge_avg_score", 0),
                "error_rate_7d": snapshot.get("error_rate_7d", 0),
                "procedural_active": snapshot.get("procedural_active", 0),
                "decision_count": len(decisions),
            })
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_metacog_evaluate(self):
        """POST /api/metacog/evaluate — 传入指标 → 退化检测"""
        _load_toolkit_modules()
        body = self._read_body()
        try:
            from tianlong.metacog import MetaCogTrigger
            t = MetaCogTrigger()
            r = t.evaluate(
                success_rate_7d=body.get("success_rate_7d", 0.85),
                success_rate_3d=body.get("success_rate_3d", 0.80),
                success_rate_1d=body.get("success_rate_1d", 0.75),
                days_since_last_improvement=body.get("days_since_last_improvement", 0),
                repeat_error_count=body.get("repeat_error_count", 0),
            )
            self._send_json({
                "should_evolve": r.should_evolve,
                "score": round(r.overall_score, 3),
                "level": r.max_level,
                "triggers": [
                    {"signal": tr.signal_name, "triggered": tr.triggered, "reason": tr.reason, "level": tr.level.value}
                    for tr in r.triggers
                ],
            })
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_judge_evaluate(self):
        """POST /api/judge/evaluate — 传入提案 → 评分"""
        _load_toolkit_modules()
        body = self._read_body()
        summary = body.get("summary", "")
        if not summary:
            return self._send_json({"error": "missing summary"}, 400)
        try:
            from tianlong.judge import RuleBasedJudge, Proposal
            judge = RuleBasedJudge()
            p = Proposal(id=body.get("id", f"api_{int(time.time())}"), summary=summary)
            result = judge.evaluate(p)
            self._send_json({
                "grade": result.grade.value,
                "total_score": round(result.total_score, 2),
                "dimensions": [{"name": d.name, "score": d.score, "reason": d.reason} for d in result.dimensions],
            })
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_verify_results(self):
        """GET /api/verify/results — 返回最近验证结果"""
        _load_toolkit_modules()
        try:
            verify_state = PROJECT_DIR / "brain" / "verify-state.json"
            if verify_state.exists():
                data = json.loads(verify_state.read_text(encoding="utf-8"))
                self._send_json(data if isinstance(data, dict) else {"results": data})
            else:
                self._send_json({"results": [], "note": "无验证记录"})
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_reflect_lessons(self):
        """GET /api/reflect/lessons — 返回反射教训列表"""
        _load_toolkit_modules()
        try:
            reflect_state = PROJECT_DIR / "brain" / "reflect-state.json"
            if reflect_state.exists():
                data = json.loads(reflect_state.read_text(encoding="utf-8"))
                self._send_json(data if isinstance(data, dict) else {"lessons": data})
            else:
                self._send_json({"lessons": [], "note": "无反省记录"})
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_cleanup_candidates(self):
        """GET /api/cleanup/candidates — 返回清理候选列表"""
        _load_toolkit_modules()
        try:
            cleanup_state = PROJECT_DIR / "brain" / "cleanup-state.json"
            if cleanup_state.exists():
                data = json.loads(cleanup_state.read_text(encoding="utf-8"))
                self._send_json(data if isinstance(data, dict) else {"candidates": data})
            else:
                self._send_json({"candidates": [], "note": "暂无可清理项"})
        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def _handle_evolve_summary(self):
        """GET /api/evolve/summary — 进化仪表盘（完整概览）"""
        _load_toolkit_modules()
        try:
            from tianlong.selfmodel import SelfModel
            from tianlong.metaevolve import MetaEVOLVE
            import json as _json

            sm = SelfModel(project_dir=str(PROJECT_DIR))
            history = sm.get_history()
            me = MetaEVOLVE()
            me_history = me.get_history()

            # 进化审计
            audit_path = PROJECT_DIR / "brain" / "evolution-audit.json"
            audit = []
            if audit_path.exists():
                audit = _json.loads(audit_path.read_text(encoding="utf-8"))

            # metaevolve 报告
            report_path = PROJECT_DIR / "brain" / "metaevolve-report.json"
            report_data = {}
            if report_path.exists():
                report_data = _json.loads(report_path.read_text(encoding="utf-8"))

            self._send_json({
                "selfmodel": {
                    "decisions": len(sm.get_decisions()),
                    "snapshots": len(sm.get_snapshots()),
                    "latest_snapshot": history.get("latest_snapshot", {}),
                },
                "metaevolve": {
                    "changes": len(me_history),
                    "hit_rate": report_data.get("hit_rate", 0),
                    "suggestions": report_data.get("suggestions", []),
                },
                "audit": {
                    "total": len(audit),
                    "recent": audit[-5:] if audit else [],
                },
                "meta_report": report_data,
            })
        except Exception as e:
            self._send_json({"error": str(e)}, 500)


def start_api(host: str = "127.0.0.1", port: int = 8899, api_key: str = ""):
    """启动SentriKit HTTP API 服务"""
    global _API_KEY
    _API_KEY = api_key
    server = HTTPServer((host, port), APIHandler)
    print(f"🚀 SentriKit API 服务启动: http://{host}:{port}")
    print(f"   健康检查:      GET  http://{host}:{port}/health")
    print(f"   状态查询:      GET  http://{host}:{port}/api/status")
    print(f"   报告提交:      POST http://{host}:{port}/api/report")
    print(f"   进化评估:      POST http://{host}:{port}/api/judge")
    print(f"   触发进化闭环:  POST http://{host}:{port}/api/evolve/run")
    print(f"   进化状态:      GET  http://{host}:{port}/api/evolve/status")
    print(f"   退化检测:      POST http://{host}:{port}/api/metacog/evaluate")
    print(f"   提案评分:      POST http://{host}:{port}/api/judge/evaluate")
    print(f"   自我模型:      GET  http://{host}:{port}/api/selfmodel/snapshot")
    print(f"   验证结果:      GET  http://{host}:{port}/api/verify/results")
    print(f"   反射教训:      GET  http://{host}:{port}/api/reflect/lessons")
    print(f"   清理候选:      GET  http://{host}:{port}/api/cleanup/candidates")
    print(f"   进化仪表盘:    GET  http://{host}:{port}/api/evolve/summary")
    if api_key:
        print(f"   认证方式: X-API-Key: {api_key}")
    else:
        print(f"   ⚠️  未设置 API Key，所有请求无需认证")
    print(f"   按 Ctrl+C 停止")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 服务停止")
        server.server_close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="sentrikit-api", description="SentriKit HTTP API 服务")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址 (默认: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8899, help="监听端口 (默认: 8899)")
    parser.add_argument("--api-key", default="", help="API Key 认证 (默认: 无认证)")
    args = parser.parse_args(argv)
    start_api(host=args.host, port=args.port, api_key=args.api_key)
    return 0


if __name__ == "__main__":
    sys.exit(main())
