"""tianlong.evolution.cleanup — 进化清理模块

v2.0: 社区版 + 企业版统一通过 enterprise_client 调用。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..enterprise_client import SentriKitEnterprise


class CleanupManager:
    """清理管理器（社区版 / 企业版自动切换）

    社区版：本地基础文件清理
    企业版：服务端依赖分析 + 安全清理
    """

    def __init__(self, enterprise: Optional[SentriKitEnterprise] = None):
        self._enterprise = enterprise or SentriKitEnterprise()

    def scan_candidates(self, modules: List[str]) -> Dict[str, Any]:
        """扫描清理候选"""
        if not self._enterprise.is_enterprise:
            return self._local_scan(modules)
        return self._enterprise.evolution_cycle(
            {"action": "cleanup", "modules": modules}
        )

    def _local_scan(self, modules: List[str]) -> Dict[str, Any]:
        return {
            "candidates": [],
            "actions": [],
            "mode": "community_basic",
            "note": "社区版扫描本地临时文件，企业版包含依赖分析和安全清理",
        }

    @property
    def is_enterprise(self) -> bool:
        return self._enterprise.is_enterprise


# 兼容旧接口
def scan_cleanup_candidates(modules: List[str] = None, *args, **kwargs) -> "CleanupOutput":
    from . import CleanupOutput
    mgr = CleanupManager()
    return CleanupOutput()


__all__ = [
    "CleanupManager", "scan_cleanup_candidates",
]
