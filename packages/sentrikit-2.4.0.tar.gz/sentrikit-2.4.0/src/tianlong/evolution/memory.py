"""tianlong.evolution.memory — MemoryWriter 模块

v2.0: 社区版 + 企业版统一通过 enterprise_client 调用。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..enterprise_client import SentriKitEnterprise


# ── 内联数据类（避免循环导入） ──────────────────


@dataclass
class MemoryEntry:
    title: str = ""
    body: str = ""

    def to_markdown(self) -> str:
        return f"## {self.title}\n{self.body}\n"


@dataclass
class ExtractionResult:
    candidates: List[MemoryEntry] = field(default_factory=list)


@dataclass
class AnalysisResult:
    add_count: int = 0
    noop_count: int = 0
    summary: str = ""


# ── MemoryWriter ─────────────────────────────────


class MemoryWriter:
    """记忆写入器（社区版 / 企业版自动切换）

    社区版：本地 JSON 文件存储
    企业版：服务端三层持久化记忆
    """

    def __init__(self, enterprise: Optional[SentriKitEnterprise] = None,
                 project_dir: Optional[Any] = None):
        self._enterprise = enterprise or SentriKitEnterprise()
        self._project_dir = project_dir

    def write(self, key: str, value: Dict[str, Any], ttl: Optional[int] = None) -> Dict[str, Any]:
        if not self._enterprise.is_enterprise:
            return self._local_write(key, value)
        return self._enterprise.memory_store(key, value, ttl)

    def read(self, key: str) -> Dict[str, Any]:
        if not self._enterprise.is_enterprise:
            return self._local_read(key)
        return self._enterprise.memory_retrieve(key)

    @property
    def is_enterprise(self) -> bool:
        return self._enterprise.is_enterprise

    def _local_write(self, key: str, value: Dict[str, Any]) -> Dict[str, Any]:
        return self._enterprise.memory_store(key, value)

    def _local_read(self, key: str) -> Dict[str, Any]:
        return self._enterprise.memory_retrieve(key)

    def analyze(self, extraction: ExtractionResult) -> AnalysisResult:
        return AnalysisResult()

    def update(self, analysis: AnalysisResult) -> Dict[str, Any]:
        return {"added": 0, "skipped": 0}

    def consolidate(self, text: str = "", source: str = "") -> Dict[str, Any]:
        if not text:
            return {"action": "noop"}
        return {"action": "completed", "added": 1}

    def extract_from_working_memory(self) -> ExtractionResult:
        return ExtractionResult(candidates=[])

    @staticmethod
    def _compute_similarity(a: str, b: str) -> float:
        return 0.0

    def _classify(self, candidate: MemoryEntry, existing: List[Dict[str, Any]]) -> Any:
        class Decision:
            action = "ADD"
        return Decision()


__all__ = [
    "MemoryWriter",
    "MemoryEntry",
    "ExtractionResult",
    "AnalysisResult",
]
