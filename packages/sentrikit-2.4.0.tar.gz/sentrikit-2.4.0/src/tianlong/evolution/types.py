"""tianlong.evolution.types — 进化模块通用类型

v2.0: 社区版内联常量 + 企业版通过 enterprise_client 调用。
"""

from __future__ import annotations

from typing import Any, Dict, List

# ── 社区版内联常量 ──────────────────────────

FAILURE_ACTIONS: Dict[str, str] = {
    "capability_gap": "生成新流程提案",
    "execution_error": "细化步骤+增加预检",
    "scene_mismatch": "调整使用边界",
    "dependency_failure": "增加降级方案",
}

SKILL_STATUS_CYCLE: Dict[str, str] = {
    "active": "pending",
    "deprecated": "archived",
    "pending": "active",
    "archived": "new",
}

SKILL_STATUS_REVERSE: Dict[str, str] = {
    "pending": "active",
    "deprecated": "active",
    "active": "verified",
    "verified": "testing",
    "testing": "learning",
    "learning": "new",
}


__all__ = [
    "FAILURE_ACTIONS", "SKILL_STATUS_CYCLE", "SKILL_STATUS_REVERSE",
]
