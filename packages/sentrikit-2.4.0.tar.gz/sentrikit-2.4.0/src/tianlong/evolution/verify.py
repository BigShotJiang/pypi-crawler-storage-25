"""tianlong.evolution.verify — 进化提案验证模块

v2.0: 社区版 + 企业版统一通过 enterprise_client 调用。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..enterprise_client import SentriKitEnterprise

from . import VerificationResult, VerifyOutput


class Verifier:
    """进化提案验证器（社区版 / 企业版自动切换）

    社区版：基础格式验证
    企业版：服务端语义验证 + 回归测试
    """

    def __init__(self, enterprise: Optional[SentriKitEnterprise] = None):
        self._enterprise = enterprise or SentriKitEnterprise()

    def verify(self, proposals: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not self._enterprise.is_enterprise:
            return self._local_verify(proposals)
        result = self._enterprise.evolution_cycle(
            {"action": "verify", "proposals": proposals}
        )
        return result.get("verified", [])

    def _local_verify(self, proposals: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """基础格式验证"""
        results = []
        for p in proposals:
            results.append({
                "id": p.get("id", ""),
                "verified": bool(p.get("summary", "")),
                "mode": "community_basic",
            })
        return results


# 兼容旧接口
def verify_proposals(proposals: List[Dict[str, Any]], *args, **kwargs) -> VerifyOutput:
    from . import VerifyOutput, VerificationResult
    if not proposals:
        return VerifyOutput()
    return VerifyOutput(
        verified=[VerificationResult(proposal_id=p.get("id", ""), verdict="pending") for p in proposals],
        hit_count=0,
        miss_count=len(proposals),
    )


__all__ = [
    "Verifier", "verify_proposals",
]
