"""tianlong.evolution — SelfLearning 进化管道

v2.0: 社区版通过 enterprise_client + LocalFallback 提供基础进化评分。
企业版激活 SENTRIKIT_API_KEY 后，调用服务端 API 获得完整 7 步进化闭环。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from ..enterprise_client import SentriKitEnterprise, is_enterprise


_HAS_EVOLUTION = is_enterprise()
_EVOLUTION_IMPORT_ERROR = "" if _HAS_EVOLUTION else "社区版模式：设置 SENTRIKIT_API_KEY 激活企业版"


# ── 枚举 ─────────────────────────────────────────


class TaskStatus(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"


class FailureType(str, Enum):
    CAPABILITY_GAP = "capability_gap"
    EXECUTION_ERROR = "execution_error"
    SCENE_MISMATCH = "scene_mismatch"
    DEPENDENCY_FAILURE = "dependency_failure"


class SkillStatus(str, Enum):
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    PENDING = "pending"
    ARCHIVED = "archived"


class RalphLoopAction(str, Enum):
    CONTINUE = "continue"
    ESCALATE = "escalate"


class ProposalSource(str, Enum):
    FAILURE_MINING = "failure_mining"
    IDLE_REFINE = "idle_refine"
    MANUAL = "manual"


class GEPAMutationType(str, Enum):
    PARAMETER_TUNE = "parameter_tune"
    STEP_SPLIT = "step_split"
    BOUNDARY_TIGHTEN = "boundary_tighten"
    TOOL_REPLACE = "tool_replace"
    DEGRADE_CHAIN = "degrade_chain"


MemoryAction = str
FailureMiningResult = Dict[str, Any]
SkillLifecycleEntry = Dict[str, Any]


# ── 数据类 ───────────────────────────────────────


@dataclass
class TaskResult:
    task_id: str = ""
    status: TaskStatus = TaskStatus.SUCCESS
    summary: str = ""
    error_message: str = ""


@dataclass
class LearnContext:
    is_empty: bool = True
    semantic_entries: List[Dict[str, Any]] = field(default_factory=list)
    procedural_entries: List[Dict[str, Any]] = field(default_factory=list)
    error_log_entries: List[Dict[str, Any]] = field(default_factory=list)
    safety_rules: List[str] = field(default_factory=list)
    working_memory_entries: List[Dict[str, Any]] = field(default_factory=list)

    def __post_init__(self):
        # 如果有任何内容，is_empty 应为 False
        if self.semantic_entries or self.procedural_entries or self.error_log_entries or self.safety_rules or self.working_memory_entries:
            self.is_empty = False


@dataclass
class SuccessPattern:
    trigger: str = ""
    action: str = ""
    outcome: str = ""
    match_count: int = 1

    def to_entry(self) -> Dict[str, Any]:
        return {
            "trigger": self.trigger,
            "action": self.action,
            "outcome": self.outcome,
            "match_count": self.match_count,
        }


@dataclass
class GEPAResult:
    mutation_type: str = "parameter_tune"
    safety_score: float = 0.0
    efficiency_score: float = 0.0
    robustness_score: float = 0.0
    practicality_score: float = 0.0

    @property
    def total_score(self) -> float:
        return (self.safety_score * 0.3 + self.efficiency_score * 0.2 +
                self.robustness_score * 0.3 + self.practicality_score * 0.2)

    passed: bool = True
    proposal: Optional[EvolutionProposal] = None


@dataclass
class EvolutionProposal:
    id: str = ""
    summary: str = ""
    description: str = ""
    change_type: str = "create"
    source: str = ""
    target: str = ""
    safety_allowed: bool = True
    executed: bool = False


@dataclass
class RalphLoopState:
    iteration: int = 1
    max_iterations: int = 3
    action: RalphLoopAction = RalphLoopAction.CONTINUE


@dataclass
class EvolutionReport:
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    completed: bool = False
    evolve_output: Optional[Any] = None
    verify_output: Optional[Any] = None
    reflect_output: Optional[Any] = None

    @property
    def summary_line(self) -> str:
        parts = []
        if self.completed:
            parts.append(f"完成: True")
        if self.evolve_output:
            approved = len(getattr(self.evolve_output, 'approved_proposals', []))
            rejected = len(getattr(self.evolve_output, 'rejected_proposals', []))
            deg = len(getattr(self.evolve_output, 'degradation_warnings', []))
            if approved:
                parts.append(f"通过: {approved}")
            if rejected:
                parts.append(f"拒绝: {rejected}")
            if deg:
                parts.append(f"退化警告: {deg}")
        if self.verify_output:
            parts.append("验证")
        if self.reflect_output:
            parts.append("反思")
        return " · ".join(parts) if parts else f"完成: {self.completed}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "completed": self.completed,
        }

    def to_json(self) -> str:
        import json
        return json.dumps(self.to_dict(), ensure_ascii=False)


@dataclass
class EvolveOutput:
    approved_proposals: List[EvolutionProposal] = field(default_factory=list)
    rejected_proposals: List[EvolutionProposal] = field(default_factory=list)
    degradation_warnings: List[str] = field(default_factory=list)


@dataclass
class AnalyzeOutput:
    insights: List[str] = field(default_factory=list)
    success_patterns: List[SuccessPattern] = field(default_factory=list)
    proposals: List[EvolutionProposal] = field(default_factory=list)
    failure_minings: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class VerificationResult:
    proposal_id: str = ""
    verdict: str = "pending"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "verdict": self.verdict,
        }


@dataclass
class VerifyOutput:
    verified: List[VerificationResult] = field(default_factory=list)
    hit_count: int = 0
    miss_count: int = 0

    @property
    def total(self) -> int:
        return self.hit_count + self.miss_count

    def summary_line(self) -> str:
        if self.total == 0:
            return "暂无验证"
        rate = int(self.hit_count / self.total * 100) if self.total else 0
        return f"命中率{rate}%"


@dataclass
class Lesson:
    category: str = ""
    summary: str = ""
    confidence: float = 0.5

    def to_dict(self) -> Dict[str, Any]:
        return {
            "category": self.category,
            "summary": self.summary,
            "confidence": self.confidence,
        }


@dataclass
class ReflectOutput:
    lessons: List[Lesson] = field(default_factory=list)
    judge_calibration_error: float = 0.0

    @property
    def total(self) -> int:
        return len(self.lessons)

    def summary_line(self) -> str:
        if self.total == 0:
            return "反思0条"
        err_pct = self.judge_calibration_error * 100
        return f"反思{self.total}条 (校准误差{err_pct:.1f}%)"


@dataclass
class CleanupAction:
    target: str = ""
    action: str = ""
    size_bytes: int = 0
    confidence: float = 0.5


@dataclass
class CleanupOutput:
    actions: List[CleanupAction] = field(default_factory=list)
    total_size_saved: int = 0
    brain_file_count: int = 0


# ── 社区版类 ─────────────────────────────────────


class RalphLoop:
    """RalphLoop 进化循环（社区版 / 企业版自动切换）"""

    def __init__(self, api_key: Optional[str] = None, config: Optional[Dict[str, Any]] = None, **kwargs):
        self._enterprise = SentriKitEnterprise(api_key=api_key)
        self._config = config or {}
        self.iteration = 0
        self.stop_reasons: List[str] = []

    def run_cycle(self, proposal: Dict[str, Any], context: Optional[Dict] = None) -> Dict[str, Any]:
        return self._enterprise.evolution_cycle(proposal, context)

    def reflect(self, evolution_id: str) -> Dict[str, Any]:
        return self._enterprise.evolution_reflect(evolution_id)

    def run(self, task: TaskResult) -> EvolutionReport:
        report = EvolutionReport(completed=True)
        report.verify_output = VerifyOutput()
        report.reflect_output = ReflectOutput()
        report.task_result = task
        report.learn_context = LearnContext()
        report.analyze_output = AnalyzeOutput()
        report.evolve_output = EvolveOutput()
        report.ralph_loop = self
        return report

    @property
    def is_enterprise(self) -> bool:
        return self._enterprise.is_enterprise


class Learner:
    def __init__(self, project_dir: Optional[Any] = None, working_memory_limit: int = 10):
        self._project_dir = project_dir
        self._working_memory_limit = working_memory_limit

    def learn(self) -> LearnContext:
        return LearnContext()


class Analyzer:
    def __init__(self):
        pass

    def analyze(self) -> AnalyzeOutput:
        return AnalyzeOutput()

    @staticmethod
    def _classify_failure(error_msg: str, context: str) -> FailureType:
        return FailureType.EXECUTION_ERROR


class GEPAEngine:
    def __init__(self, random_seed: int = 42):
        self._random_seed = random_seed

    def generate_proposals(self, *args, **kwargs) -> AnalyzeOutput:
        return AnalyzeOutput()


class Evolver:
    def evolve(self, *args, **kwargs) -> EvolveOutput:
        return EvolveOutput()


class Propagator:
    pass


class MemoryWriter:
    """记忆写入器桩（社区版，tianlong.evolution.memory 提供完整实现）"""
    pass


# ── 兼容函数 ─────────────────────────────────────


def verify_proposals(proposals, *args, **kwargs):
    """验证提案（社区版简化）"""
    if not proposals:
        return VerifyOutput()
    return VerifyOutput(
        verified=[VerificationResult(proposal_id=p.get("id", ""), verdict="pending") for p in proposals],
        hit_count=0,
        miss_count=len(proposals),
    )


def reflect_on_verify(result, *args, **kwargs):
    """反射分析（社区版简化）"""
    return ReflectOutput()


def scan_cleanup_candidates(*args, **kwargs):
    """扫描清理候选（社区版简化）"""
    return CleanupOutput()


is_enterprise_enabled = is_enterprise
HAS_EVOLUTION = _HAS_EVOLUTION


# ── 延迟导入 memory 子模块的类型 ──────────────

def __getattr__(name: str):
    if name in ("MemoryEntry", "ExtractionResult", "AnalysisResult"):
        from .memory import MemoryEntry, ExtractionResult, AnalysisResult
        globals()[name] = locals()[name]
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "RalphLoop", "Learner", "Analyzer", "GEPAEngine", "Evolver", "Propagator",
    "MemoryWriter", "MemoryAction", "MemoryEntry",
    "TaskResult", "TaskStatus", "LearnContext",
    "AnalyzeOutput", "EvolveOutput", "EvolutionReport",
    "EvolutionProposal", "SuccessPattern",
    "FailureMiningResult", "FailureType",
    "GEPAResult", "GEPAMutationType",
    "SkillLifecycleEntry", "SkillStatus",
    "RalphLoopState", "RalphLoopAction",
    "ProposalSource",
    "VerificationResult", "VerifyOutput",
    "Lesson", "ReflectOutput",
    "verify_proposals", "reflect_on_verify",
    "scan_cleanup_candidates", "CleanupAction", "CleanupOutput",
    "DistributedEvolution", "is_enterprise_enabled",
    "_HAS_EVOLUTION", "_EVOLUTION_IMPORT_ERROR",
]
