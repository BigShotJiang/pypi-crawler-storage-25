"""tianlong.evolution.reflect — 进化反射分析模块

v2.0: 社区版 + 企业版统一通过 enterprise_client 调用。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..enterprise_client import SentriKitEnterprise

from . import Lesson, ReflectOutput


class Reflector:
    """进化反射分析器（社区版 / 企业版自动切换）

    社区版：基础反射（无闭环）
    企业版：服务端完整反射分析
    """

    def __init__(self, enterprise: Optional[SentriKitEnterprise] = None):
        self._enterprise = enterprise or SentriKitEnterprise()

    def reflect(self, evolution_id: str) -> Dict[str, Any]:
        if not self._enterprise.is_enterprise:
            return self._local_reflect(evolution_id)
        return self._enterprise.evolution_reflect(evolution_id)

    def _local_reflect(self, evolution_id: str) -> Dict[str, Any]:
        return {
            "reflection": "社区版不支持进化反射",
            "lessons": [],
            "mode": "community",
        }


# 兼容旧接口
def reflect_on_verify(result: Dict[str, Any], *args, **kwargs) -> ReflectOutput:
    return ReflectOutput()


__all__ = [
    "Reflector", "reflect_on_verify",
]
