# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""tianlong.enterprise — SentriKit企业版 API 客户端模块

企业版通过服务端 API（https://api.tianlong.ai/v1）提供全量能力。
社区版使用本地降级模块（LocalFallback）提供基础功能。

用法:
    from tianlong.enterprise_client import SentriKitEnterprise
    client = SentriKitEnterprise()
"""

from .client import EnterpriseClient
from .fallback import LocalFallback, UpgradeHints
from .types import (
    BrainTask, EvolutionProposal, ResearchQuery,
    DGMHContext, MetaEVOLVERecord, MemoryEntry,
    SafetyCheckResult, AuditResult,
)

__all__ = [
    "EnterpriseClient", "LocalFallback",
    "BrainTask", "EvolutionProposal", "ResearchQuery",
    "DGMHContext", "MetaEVOLVERecord", "MemoryEntry",
    "SafetyCheckResult", "AuditResult",
]
