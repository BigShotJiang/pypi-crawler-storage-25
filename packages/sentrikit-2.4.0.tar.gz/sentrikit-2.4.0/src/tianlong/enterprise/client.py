# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""tianlong.enterprise.client — HTTP 客户端核心

企业版 HTTP 客户端，支持连接池、重试、超时、指标收集。
可选依赖 httpx + tenacity 提供增强功能；未安装时降级到 urllib 标准库。
"""

from __future__ import annotations

import json
import logging
import time
import os
from typing import Any, Dict, List, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

logger = logging.getLogger("tianlong.enterprise.client")


def _percentile(data: List[float], p: float) -> float:
    if not data:
        return 0.0
    sorted_data = sorted(data)
    idx = int(len(sorted_data) * p / 100)
    return sorted_data[min(idx, len(sorted_data) - 1)]


class APIMetrics:
    """API 调用指标收集（本地，不上报）"""

    def __init__(self):
        self.calls_total = 0
        self.calls_by_endpoint: Dict[str, int] = {}
        self.errors_total = 0
        self.latencies: List[float] = []

    def record(self, endpoint: str, status: int, latency_ms: float):
        self.calls_total += 1
        self.calls_by_endpoint[endpoint] = self.calls_by_endpoint.get(endpoint, 0) + 1
        if status >= 400:
            self.errors_total += 1
        self.latencies.append(latency_ms)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "calls_total": self.calls_total,
            "calls_by_endpoint": self.calls_by_endpoint,
            "errors_total": self.errors_total,
            "latency_p50": _percentile(self.latencies, 50),
            "latency_p99": _percentile(self.latencies, 99),
        }


class EnterpriseClient:
    """SentriKit服务端 API 客户端

    零外部依赖核心实现（标准库 urllib）。
    如安装了 httpx，自动使用 httpx 的 async 能力。
    首次连接时执行版本协商，确保客户端-服务端兼容。
    """

    CLIENT_VERSION = "2.0.0"
    MIN_SERVER_VERSION = "2.0.0"

    def __init__(
        self,
        api_key: str,
        api_base: str = "https://api.tianlong.ai/v1",
        timeout: int = 30,
        use_cache: bool = True,
    ):
        self.api_key = api_key
        self.api_base = api_base.rstrip("/")
        self.timeout = timeout
        self.use_cache = use_cache
        self._metrics = APIMetrics()
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._version_checked = False
        self._server_version: Optional[str] = None

        # 检测是否有 httpx
        self._has_httpx = False
        try:
            import httpx  # noqa: F401
            self._has_httpx = True
        except ImportError:
            pass

    def _ensure_version_check(self):
        """首次调用时协商版本"""
        if self._version_checked:
            return
        try:
            health = self.health_check()
            sv = health.get("version", "0.0.0")
            self._server_version = sv
            self._version_checked = True
            if not self._is_compatible(sv):
                logger.warning(
                    "客户端 v%s 与服务端 v%s 可能存在不兼容，建议升级客户端",
                    self.CLIENT_VERSION, sv,
                )
            else:
                logger.info("服务端 v%s (兼容)", sv)
        except Exception as e:
            logger.warning("版本协商失败: %s (继续运行)", e)
            self._version_checked = True

    @staticmethod
    def _is_compatible(server_version: str) -> bool:
        """检查服务端版本与客户端是否兼容（主版本号匹配）"""
        try:
            cv = EnterpriseClient.CLIENT_VERSION.split(".")
            sv = server_version.split(".")
            return cv[0] == sv[0]  # 主版本号匹配
        except (IndexError, ValueError):
            return True

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": "SentriKitToolkit/2.3",
            "Content-Type": "application/json",
        }

    def post(
        self,
        endpoint: str,
        json_data: Dict[str, Any] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """POST 请求"""
        return self._request("POST", endpoint, json_data or kwargs.get("json", {}))

    def get(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        """GET 请求"""
        return self._request("GET", endpoint)

    def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        retries: int = 3,
    ) -> Dict[str, Any]:
        """统一请求处理（含版本协商、缓存、重试、指标）"""
        # 版本协商（首次调用）
        if not self._version_checked:
            self._ensure_version_check()

        cache_key = f"{method}:{endpoint}"

        # 缓存检查（仅 GET）
        if method == "GET" and self.use_cache and cache_key in self._cache:
            return self._cache[cache_key]

        last_error = None
        for attempt in range(retries):
            try:
                start = time.monotonic()
                url = f"{self.api_base}{endpoint}"
                body = json.dumps(data).encode("utf-8") if data else None

                req = Request(url, data=body, headers=self._headers(), method=method)
                with urlopen(req, timeout=self.timeout) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
                    latency_ms = (time.monotonic() - start) * 1000
                    self._metrics.record(endpoint, resp.status, latency_ms)

                    # 缓存 GET 结果
                    if method == "GET" and self.use_cache:
                        self._cache[cache_key] = result

                    return result

            except HTTPError as e:
                latency_ms = (time.monotonic() - start) * 1000
                self._metrics.record(endpoint, e.code, latency_ms)

                if e.code == 429:
                    logger.warning("API 调用频率超限 (attempt %d/%d)", attempt + 1, retries)
                    time.sleep(2 ** attempt)
                    continue
                if e.code == 402:
                    raise QuotaExhaustedError("API 配额已用完")
                if e.code in (401, 403):
                    raise AuthError(f"API Key 验证失败: {e.code}")

                # 500+ 重试
                if e.code >= 500 and attempt < retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                raise ApiError(f"API 错误 {e.code}: {e.reason}")

            except URLError as e:
                latency_ms = (time.monotonic() - start) * 1000
                self._metrics.record(endpoint, 0, latency_ms)
                last_error = e
                if attempt < retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                raise NetworkError(f"网络错误: {e.reason}")

        raise NetworkError(f"请求失败 (重试 {retries} 次): {last_error}")

    def get_metrics(self) -> Dict[str, Any]:
        return self._metrics.to_dict()

    def health_check(self) -> Dict[str, Any]:
        """同步健康检查"""
        try:
            url = f"{self.api_base}/health"
            req = Request(url, headers={"User-Agent": "TianLongToolkit/2.0"})
            with urlopen(req, timeout=5) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            return {"status": "unreachable", "error": str(e)}

    async def close(self):
        """关闭连接（httpx 模式需要清理）"""
        if self._has_httpx:
            import httpx
            async with httpx.AsyncClient() as client:
                await client.aclose()


# ── 异常定义 ────────────────────────────────


class EnterpriseError(Exception):
    """企业版 API 错误基类"""


class ApiError(EnterpriseError):
    """API 响应错误"""


class AuthError(EnterpriseError):
    """认证错误"""


class NetworkError(EnterpriseError):
    """网络错误"""


class RateLimitError(EnterpriseError):
    """频率限制"""


class QuotaExhaustedError(EnterpriseError):
    """配额耗尽"""
