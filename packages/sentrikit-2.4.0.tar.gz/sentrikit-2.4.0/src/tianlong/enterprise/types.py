# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""tianlong.enterprise.types — 请求/响应数据模型

企业版 API 的数据类型定义，用于类型提示和序列化。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ── BrainCore ────────────────────────────────


@dataclass
class BrainTask:
    """BrainCore 任务"""
    goal: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    agents: List[str] = field(default_factory=lambda: ["default"])
    task_id: str = ""


# ── 进化 ────────────────────────────────────


@dataclass
class EvolutionProposal:
    """进化提案"""
    summary: str = ""
    description: str = ""
    has_test: bool = False
    backward_compatible: bool = True
    documentation: str = ""
    risk_level: str = "medium"  # low / medium / high
    source: str = "manual"


# ── 调研 ────────────────────────────────────


@dataclass
class ResearchQuery:
    """调研查询"""
    query: str = ""
    chain_depth: int = 2
    sources: List[str] = field(default_factory=lambda: ["web", "arxiv", "github"])


# ── DGM-H ────────────────────────────────────


@dataclass
class DGMHContext:
    """DGM-H 元认知上下文"""
    task: str = ""
    agent_state: Dict[str, Any] = field(default_factory=dict)
    environment: Dict[str, Any] = field(default_factory=dict)
    shield_level: str = "M3"


# ── MetaEVOLVE ───────────────────────────────


@dataclass
class MetaEVOLVERecord:
    """MetaEVOLVE 变更记录"""
    change_id: str = ""
    timestamp: str = ""
    change_type: str = ""
    accepted: bool = False
    hit: bool = False
    notes: str = ""


# ── 记忆 ─────────────────────────────────────


@dataclass
class MemoryEntry:
    """记忆条目"""
    key: str = ""
    value: Dict[str, Any] = field(default_factory=dict)
    ttl: Optional[int] = None
    created_at: str = ""


# ── 安全 ─────────────────────────────────────


@dataclass
class SafetyCheckResult:
    """安全检查结果"""
    safe: bool = True
    reason: str = ""
    mode: str = "basic_filter"


# ── 审计 ─────────────────────────────────────


@dataclass
class AuditResult:
    """审计结果"""
    total_findings: int = 0
    findings: List[Dict[str, Any]] = field(default_factory=list)
    score: float = 1.0
    grade: str = "S"
    mode: str = "local"
