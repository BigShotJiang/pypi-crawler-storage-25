# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""tianlong.enterprise.cache — 企业版 API 响应缓存

简单的 TTL 缓存，减少重复 API 调用。
"""

from __future__ import annotations

import time
from typing import Any, Dict, Optional, Tuple


class EnterpriseCache:
    """企业版 API 响应缓存（TTL 过期 + LRU 淘汰）"""

    def __init__(self, max_size: int = 128, default_ttl: int = 300):
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._cache: Dict[str, Tuple[float, Any]] = {}  # key -> (expires_at, value)

    def get(self, key: str) -> Optional[Any]:
        if key not in self._cache:
            return None
        expires_at, value = self._cache[key]
        if time.time() > expires_at:
            del self._cache[key]
            return None
        return value

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        if len(self._cache) >= self._max_size:
            self._evict_one()
        expires_at = time.time() + (ttl or self._default_ttl)
        self._cache[key] = (expires_at, value)

    def clear(self) -> None:
        self._cache.clear()

    def _evict_one(self) -> None:
        if not self._cache:
            return
        oldest_key = min(self._cache, key=lambda k: self._cache[k][0])
        del self._cache[oldest_key]

    @property
    def size(self) -> int:
        return len(self._cache)

    def stats(self) -> dict:
        return {
            "size": self.size,
            "max_size": self._max_size,
            "default_ttl": self._default_ttl,
        }
