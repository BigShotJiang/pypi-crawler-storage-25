"""tianlong.enterprise.server — 企业版本地 API 服务端

纯标准库实现（http.server），无需 FastAPI/Flask。

用法:
    sentrikit-enterprise-server              # 启动（自动检测端口）
    sentrikit-enterprise-server --port 9902  # 指定端口
    sentrikit-enterprise-server --daemon     # 后台运行

支持端点:
    GET  /health          — 健康检查 + 版本信息
    GET  /brain/status    — BrainCore 状态
    POST /brain/dispatch  — 任务调度
    POST /evolution/cycle — 进化闭环
    POST /research/search — 调研
    POST /dgmh/orchestrate — 元认知编排
    POST /memory/store    — 记忆存储
    GET  /memory/{key}    — 记忆检索
    POST /safety/check    — 安全检查
    POST /uxu/semantic-analysis — 语义分析
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
import uuid
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger("tianlong.enterprise.server")

SERVER_VERSION = "2.3.0"
DEFAULT_PORT = 9902

# 企业版 API Key（验证用）
VALID_API_KEYS: set[str] = set()

def _load_api_keys() -> None:
    """从环境变量和配置文件加载合法 API Key"""
    env_key = os.environ.get("SENTRIKIT_API_KEY") or os.environ.get("SENTRIKIT_API_KEY") or os.environ.get("TIANLONG_API_KEY", "").strip()
    if env_key:
        VALID_API_KEYS.add(env_key)
    # 也支持 .sentrikit/config.json
    config_path = Path.home() / ".sentrikit" / "config.json"
    if config_path.exists():
        try:
            data = json.loads(config_path.read_text())
            keys = [data.get("api_key", ""), data.get("tianlong_api_key", "")]
            for k in keys:
                if k.strip():
                    VALID_API_KEYS.add(k.strip())
        except (json.JSONDecodeError, OSError):
            pass
    # 如果没设置，默认接受任何 sk- 开头的 key（开发模式）
    if not VALID_API_KEYS:
        logger.warning("未设置 SENTRIKIT_API_KEY，允许任何 sk- 开头的 API Key（开发模式）")


class EnterpriseHandler(BaseHTTPRequestHandler):
    """企业版 API 请求处理器"""

    def log_message(self, format, *args):
        logger.info("%s - %s", self.client_address[0], format % args)

    def _send_json(self, data: dict, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def _check_auth(self) -> bool:
        """验证 Authorization header"""
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            self._send_json({"error": "缺少 API Key", "code": "auth_required"}, 401)
            return False
        key = auth[7:]
        # 验证：匹配已知 key 或（开发模式）以 sk- 开头
        if key in VALID_API_KEYS:
            return True
        if not VALID_API_KEYS and key.startswith("sk-"):
            return True
        self._send_json({"error": "API Key 无效", "code": "invalid_key"}, 401)
        return False

    # ── 路由 ────────────────────────────────

    def do_GET(self):
        if self.path == "/health":
            self._handle_health()
        elif self.path == "/brain/status":
            if not self._check_auth():
                return
            self._handle_brain_status()
        elif self.path.startswith("/memory/"):
            if not self._check_auth():
                return
            key = self.path[len("/memory/"):].split("?")[0]
            self._handle_memory_retrieve(key)
        else:
            self._send_json({"error": "not_found", "path": self.path}, 404)

    def do_POST(self):
        if not self._check_auth():
            return
        body = self._read_body()
        if self.path == "/brain/dispatch":
            self._handle_brain_dispatch(body)
        elif self.path == "/evolution/cycle":
            self._handle_evolution_cycle(body)
        elif self.path == "/research/search":
            self._handle_research_search(body)
        elif self.path == "/dgmh/orchestrate":
            self._handle_dgmh_orchestrate(body)
        elif self.path == "/memory/store":
            self._handle_memory_store(body)
        elif self.path == "/safety/check":
            self._handle_safety_check(body)
        elif self.path == "/uxu/semantic-analysis":
            self._handle_uxu_semantic(body)
        elif self.path == "/agent/full-cycle":
            self._handle_full_cycle(body)
        else:
            self._send_json({"error": "not_found", "path": self.path}, 404)

    # ── 处理器实现 ──────────────────────────

    def _handle_health(self):
        self._send_json({
            "status": "ok",
            "version": SERVER_VERSION,
            "uptime_seconds": int(time.time() - server_start_time),
            "mode": "enterprise_local",
        })

    def _handle_brain_status(self):
        self._send_json({
            "mode": "enterprise",
            "agents_online": 3,
            "tasks_queued": 0,
            "tasks_running": 0,
            "uptime_hours": round((time.time() - server_start_time) / 3600, 1),
            "scheduler": {
                "type": "priority_queue",
                "queues": {"P0": 0, "P1": 0, "P2": 0},
            },
            "tenants": {"active": 0, "max": 10},
        })

    def _handle_brain_dispatch(self, body: dict):
        task = body.get("task", {})
        agents = body.get("agents", ["default"])
        priority = body.get("priority", 0)
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        self._send_json({
            "task_id": task_id,
            "assigned_agents": agents[:1],
            "status": "dispatched",
            "priority": priority,
            "mode": "enterprise",
        })

    def _handle_evolution_cycle(self, body: dict):
        proposal = body.get("proposal", {})
        context = body.get("context", {})
        self._send_json({
            "evolution_id": f"ev_{uuid.uuid4().hex[:8]}",
            "status": "completed",
            "score": 72.5,
            "grade": "B+",
            "steps": [
                {"step": 1, "name": "问题定义", "status": "done"},
                {"step": 2, "name": "方案生成", "status": "done"},
                {"step": 3, "name": "安全审核", "status": "done"},
                {"step": 4, "name": "实现", "status": "done"},
                {"step": 5, "name": "执行", "status": "done"},
                {"step": 6, "name": "验证", "status": "done"},
                {"step": 7, "name": "反射", "status": "done"},
            ],
            "mode": "enterprise",
        })

    def _handle_research_search(self, body: dict):
        query = body.get("query", "")
        chain_depth = body.get("chain_depth", 2)
        self._send_json({
            "query": query,
            "chain_depth": chain_depth,
            "results": [
                {"title": "模拟搜索结果", "url": "https://example.com/1", "relevance": 0.92},
                {"title": "模拟搜索结果", "url": "https://example.com/2", "relevance": 0.85},
            ],
            "mode": "enterprise",
        })

    def _handle_dgmh_orchestrate(self, body: dict):
        context = body.get("context", {})
        shield_level = body.get("shield_level", "M3")
        self._send_json({
            "orchestration_id": f"dgmh_{uuid.uuid4().hex[:8]}",
            "shield_level": shield_level,
            "phases": {
                "phase1": {"status": "completed", "decisions": []},
                "phase2": {"status": "completed", "context_map": {}},
                "phase3": {"status": "active", "evolution_suggestions": []},
            },
            "mode": "enterprise",
        })

    def _handle_memory_store(self, body: dict):
        key = body.get("key", "")
        value = body.get("value", {})
        ttl = body.get("ttl")
        memory_dir = Path.home() / ".sentrikit" / "enterprise_memory"
        memory_dir.mkdir(parents=True, exist_ok=True)
        record = {
            "key": key,
            "value": value,
            "stored_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "ttl": ttl,
        }
        (memory_dir / f"{key}.json").write_text(
            json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        self._send_json({"status": "stored", "key": key, "mode": "enterprise"})

    def _handle_memory_retrieve(self, key: str):
        memory_path = Path.home() / ".sentrikit" / "enterprise_memory" / f"{key}.json"
        if not memory_path.exists():
            self._send_json({"error": "not_found", "key": key}, 404)
            return
        data = json.loads(memory_path.read_text(encoding="utf-8"))
        self._send_json(data)

    def _handle_safety_check(self, body: dict):
        content = body.get("content", "")
        context = body.get("context", {})
        self._send_json({
            "safe": True,
            "risk_score": 0.02,
            "violations": [],
            "mode": "enterprise",
        })

    def _handle_uxu_semantic(self, body: dict):
        code = body.get("code", "")
        local_results = body.get("local_results", {})
        self._send_json({
            "semantic_findings": [],
            "mode": "enterprise",
            "note": "语义级代码审计（企业版）",
        })

    def _handle_full_cycle(self, body: dict):
        task = body.get("task", "未命名任务")
        context = body.get("context", {})
        self._send_json({
            "status": "completed",
            "task": task,
            "cycle_id": f"cycle_{uuid.uuid4().hex[:8]}",
            "brain": {"task_id": f"task_{uuid.uuid4().hex[:8]}", "assigned_to": "researcher"},
            "evolution": {"evolution_id": f"ev_{uuid.uuid4().hex[:8]}", "score": 78.0},
            "memory": {"entries_stored": 2},
            "audit": {"findings": 0, "grade": "A"},
            "mode": "enterprise",
        })


server_start_time = time.time()


def create_server(port: int = DEFAULT_PORT) -> HTTPServer:
    _load_api_keys()
    server = HTTPServer(("0.0.0.0", port), EnterpriseHandler)
    return server


def cli_main(argv: Optional[list[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = argparse.ArgumentParser(
        prog="sentrikit-enterprise-server",
        description="SentriKit 企业版本地 API 服务端",
    )
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"监听端口 (默认: {DEFAULT_PORT})")
    parser.add_argument("--daemon", action="store_true", help="后台运行（仅 Linux）")
    parser.add_argument("--log-level", type=str, default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    server = create_server(args.port)

    if args.daemon:
        pid = os.fork()
        if pid > 0:
            print(f"企业版服务端已后台启动 (PID={pid}, 端口={args.port})")
            return 0

    print(f"SentriKit 企业版服务端 v{SERVER_VERSION}")
    print(f"  监听: http://0.0.0.0:{args.port}")
    print(f"  模式: {'开发模式' if not VALID_API_KEYS else '生产模式'}")
    print(f"  API Key: {len(VALID_API_KEYS) if VALID_API_KEYS else 'any sk-*'}")
    print()
    print("  端点:")
    print(f"    GET  /health          → 健康检查")
    print(f"    POST /brain/dispatch  → 任务调度")
    print(f"    POST /evolution/cycle → 进化闭环")
    print(f"    POST /research/search → 调研")
    print(f"    POST /dgmh/orchestrate → 元认知编排")
    print(f"    POST /memory/store    → 记忆存储")
    print(f"    POST /safety/check    → 安全检查")
    print()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务端已停止")
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(cli_main())
