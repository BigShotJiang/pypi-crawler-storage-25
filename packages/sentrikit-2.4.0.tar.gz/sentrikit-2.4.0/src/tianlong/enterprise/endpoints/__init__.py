# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""tianlong.enterprise.endpoints — API 端点模块

为每个企业版能力提供独立的端点客户端，便于按需导入。
所有端点方法均接受 SentriKitEnterprise 实例作为第一个参数。
"""
