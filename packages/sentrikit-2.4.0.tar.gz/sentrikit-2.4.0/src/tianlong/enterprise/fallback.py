# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""tianlong.enterprise.fallback — 本地降级模块

原闭源包的简化版替代。保留了基础的可用性，但高级功能需要企业版 API Key。
这个模块让社区版用户仍能获得基本能力，而不是什么都不能做。
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional


COMMUNITY_UPGRADE_HINT = (
    "\n\n---\n💡 **需要企业版解锁完整能力？**\n"
    "当前为 MIT 社区版。企业版提供全量 AI 能力：\n"
    "- BrainCore 多 Agent 调度引擎\n"
    "- 7 步自进化闭环 + DGM-H 元认知\n"
    "- MetaEVOLVE 命中率分析与策略建议\n"
    "- 4 级搜索链调研引擎 + 持久化记忆\n"
    "设置 SENTRIKIT_API_KEY 激活：https://tianlong.ai/pricing\n"
)


class UpgradeHints:
    """企业版升级提示 — 统一管理

    每个提示对应一个企业级模块，社区版/企业版降级逻辑共享。
    """

    BRAIN = "社区版支持基础 FIFO 调度。企业版提供优先级计算、多租户公平调度、退避策略等高级调度算法。"
    EVOLUTION = "社区版提供基础评分（0.0-0.5）。企业版包含 7 步完整进化闭环：学习→分析→判断→进化→验证→反射→清理。"
    DGMH = "社区版支持 M1 基础顺次编排。企业版支持 M1-M6 完整元认知编排。"
    RESEARCH = "社区版仅支持本地文件搜索。企业版提供 4 级搜索链（本地→缓存→在线→深度）+ 降级策略。"
    MEMORY = "社区版使用本地 JSON 文件。企业版提供 Redis/PostgreSQL 持久化，支持 TTL 和向量检索。"
    METAEVOLVE = "社区版提供基础统计。企业版提供命中率趋势分析、策略建议、瓶颈检测。"
    SAFETY = "社区版使用基础关键词过滤。企业版提供语义级安全检测。"
    CodeVigil = "社区版提供本地 34 规则扫描。企业版增加语义级代码审计分析。"

    FOOTER = "升级：https://tianlong.ai/pricing | 试用：curl -s https://api.tianlong.ai/v1/trial"


class LocalFallback:
    """社区版本地降级实现

    每个方法返回基础可用结果，并附带升级提示。
    """

    def __init__(self, storage_dir: Optional[Path] = None):
        self.storage_dir = storage_dir or Path.home() / ".sentrikit" / "community"
        self.storage_dir.mkdir(parents=True, exist_ok=True)

    # ── BrainCore 本地：基础的 FIFO 调度 ─────

    def brain_dispatch_local(
        self,
        task: dict,
        agents: Optional[list] = None,
    ) -> dict:
        """基础任务调度（FIFO，单线程）"""
        agents = agents or ["default"]
        return {
            "task_id": hashlib.md5(json.dumps(task, sort_keys=True).encode()).hexdigest()[:12],
            "assigned_agents": agents,
            "schedule_strategy": "fifo",
            "mode": "community",
            "hint": (
                "社区版支持基础 FIFO 调度。"
                "企业版提供优先级计算、多租户公平调度、退避策略等高级调度算法。"
            ),
        }

    # ── 自进化：本地基础评估 ─────────────────

    def evolution_cycle_local(
        self,
        proposal: dict,
        context: Optional[dict] = None,
    ) -> dict:
        """基础进化评估（仅评分，无学习闭环）"""
        context = context or {}
        score = 0.0
        if proposal.get("has_test", False):
            score += 0.2
        if proposal.get("backward_compatible", True):
            score += 0.2
        if proposal.get("documentation", ""):
            score += 0.1
        if proposal.get("risk_level", "high") == "low":
            score += 0.2
        score = min(score, 0.5)  # 社区版上限

        return {
            "evolution_id": hashlib.md5(str(proposal).encode()).hexdigest()[:12],
            "score": score,
            "grade": self._score_to_grade(score),
            "accepted": score >= 0.3,
            "mode": "community_basic",
            "note": (
                "社区版提供基础评分（0.0-0.5）。"
                "企业版包含 7 步完整进化闭环："
                "学习→分析→判断→进化→验证→反射→清理。"
            ),
        }

    # ── 调研：本地基础搜索 ───────────────────

    def research_search_local(self, query: str) -> dict:
        """基础搜索（文件系统搜索，无外网采集）"""
        return {
            "query": query,
            "results": [],
            "chain_depth": 1,
            "mode": "community_local",
            "hint": (
                "社区版仅支持本地文件搜索。"
                "企业版提供 4 级搜索链（本地→缓存→在线→深度）+ 降级策略。"
            ),
        }

    # ── DGM-H：本地基础调度 ─────────────────

    def dgmh_orchestrate_local(self, context: dict) -> dict:
        return {
            "orchestration": "sequential",
            "shield_level": "M1",
            "mode": "community_basic",
            "note": "社区版支持 M1 基础顺次编排。企业版支持 M1-M6 完整元认知编排。",
        }

    # ── MetaEVOLVE：本地基础统计 ─────────────

    def metaevolve_analyze_local(self, change_records: list) -> dict:
        """基础进化统计"""
        if not change_records:
            return {"hit_rate": 0, "total": 0, "mode": "community"}

        accepted = sum(1 for r in change_records if r.get("accepted", False))
        return {
            "hit_rate": accepted / len(change_records) if change_records else 0,
            "total": len(change_records),
            "accepted": accepted,
            "mode": "community_basic",
            "hint": (
                "社区版提供基础统计。"
                "企业版提供命中率趋势分析、策略建议、瓶颈检测。"
            ),
        }

    # ── Memory：本地 JSON 文件 ──────────────

    def memory_store_local(self, key: str, value: dict) -> dict:
        filepath = self.storage_dir / f"memory_{hash(key) % 10000}.json"
        existing = {}
        if filepath.exists():
            existing = json.loads(filepath.read_text())
        existing[key] = value
        filepath.write_text(
            json.dumps(existing, ensure_ascii=False, indent=2)
        )
        return {
            "stored": True,
            "backend": "local_json",
            "mode": "community",
            "hint": "企业版提供 Redis/PostgreSQL 持久化，支持 TTL 和向量检索。",
        }

    def memory_retrieve_local(self, key: str) -> dict:
        for f in self.storage_dir.glob("memory_*.json"):
            try:
                data = json.loads(f.read_text())
                if key in data:
                    return {"key": key, "value": data[key], "backend": "local_json", "mode": "community"}
            except (json.JSONDecodeError, OSError):
                continue
        return {"key": key, "value": None, "found": False, "mode": "community"}

    def memory_list_local(self, prefix: str = "") -> dict:
        """列出所有记忆键"""
        keys = []
        for f in self.storage_dir.glob("memory_*.json"):
            try:
                data = json.loads(f.read_text())
                for k in data:
                    if not prefix or k.startswith(prefix):
                        keys.append(k)
            except (json.JSONDecodeError, OSError):
                continue
        return {"keys": keys, "count": len(keys), "mode": "community"}

    # ── Safety：本地基础过滤 ────────────────

    def safety_check_local(self, content: str) -> dict:
        """基础关键词安全检查"""
        sensitive = ["违法", "行贿", "欺诈", "贿赂", "走私", "洗钱"]
        for word in sensitive:
            if word in content:
                return {"safe": False, "reason": f"包含敏感词: {word}", "mode": "basic_filter"}
        return {"safe": True, "mode": "basic_filter"}

    # ── 工具方法 ────────────────────────────

    @staticmethod
    def _score_to_grade(score: float) -> str:
        if score >= 0.9:
            return "S"
        elif score >= 0.8:
            return "A"
        elif score >= 0.7:
            return "B"
        elif score >= 0.6:
            return "C"
        elif score >= 0.3:
            return "D"
        else:
            return "F"
