"""tianlong.uxu.score — 精准评分模型 v2

三柱加权评分 + 置信度 + 可利用性 + 影响范围 + 动态扣分 + 薄弱环节分析。
基于 UXU-DESIGN-FRAMEWORK.md 的 5.1-5.3 评分模型。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


# 权重定义
SEVERITY_WEIGHTS = {"critical": 25, "high": 10, "medium": 3, "low": 1, "info": 0}
CONFIDENCE_MAP = {"high": 1.0, "medium": 0.7, "low": 0.4}
EXPLOITABILITY_MAP = {"easy": 1.0, "moderate": 0.6, "difficult": 0.3}
IMPACT_MAP = {"complete": 1.0, "partial": 0.5, "minimal": 0.2}

# 三柱权重（来自 UXU 设计文档 §5.3）
PILLAR_WEIGHTS = {
    "IS": 0.40,  # Input Sanitization — 第一道防线
    "SI": 0.35,  # Sandbox Isolation — 纵深防御
    "PM": 0.25,  # Privilege Minimization — 兜底
}

# 规则级别扣分乘数（v2 新增）：同一规则多次触发时衰减
RULE_REPEAT_DECAY = 0.3  # 第二次触发同一规则只扣 30%


@dataclass
class FindingScore:
    """单条发现的评分"""
    severity_weight: int = 0
    confidence: float = 1.0
    exploitability: float = 1.0
    impact: float = 1.0
    raw_score: float = 0.0  # weight × confidence × exploitability × impact

    def calculate(self, severity: str, confidence: str = "high",
                  exploitability: str = "easy", impact: str = "complete") -> None:
        self.severity_weight = SEVERITY_WEIGHTS.get(severity, 1)
        self.confidence = CONFIDENCE_MAP.get(confidence, 0.7)
        self.exploitability = EXPLOITABILITY_MAP.get(exploitability, 0.6)
        self.impact = IMPACT_MAP.get(impact, 0.5)
        self.raw_score = self.severity_weight * self.confidence * self.exploitability * self.impact


@dataclass
class PillarScore:
    """单柱评分 (0-100)"""
    pillar_id: str = ""
    pillar_name: str = ""
    raw_deduction: float = 0.0
    score: float = 100.0
    finding_count: int = 0
    top_rules: Dict[str, int] = field(default_factory=dict)  # v2: 各规则触发次数

    @property
    def grade(self) -> str:
        if self.score >= 90: return "A"
        elif self.score >= 70: return "B"
        elif self.score >= 50: return "C"
        elif self.score >= 30: return "D"
        return "F"

    def to_dict(self) -> Dict:
        return {
            "pillar": self.pillar_id,
            "name": self.pillar_name,
            "score": round(self.score, 1),
            "grade": self.grade,
            "findings": self.finding_count,
            "deduction": round(self.raw_deduction, 1),
            "top_rules": dict(sorted(self.top_rules.items(), key=lambda x: -x[1])[:5]),
        }


@dataclass
class UxuScore:
    """UXU 综合评分 v2"""
    is_score: float = 100.0     # Input Sanitization
    si_score: float = 100.0     # Sandbox Isolation
    pm_score: float = 100.0     # Privilege Minimization
    total: float = 100.0        # 加权总和
    grade: str = "A"
    pillars: Dict[str, PillarScore] = field(default_factory=dict)  # v2: pillar明细
    weakest_pillar: str = ""    # v2: 最薄弱环节

    def calculate(self, findings: List[Dict]) -> None:
        """根据 findings 列表计算三柱评分（v2 动态扣分）。"""
        pillar_findings: Dict[str, List[Dict]] = {"IS": [], "SI": [], "PM": []}
        for f in findings:
            rule_id = f.get("rule_id", "")
            pillar = rule_id.split("-")[1] if "-" in rule_id else "UNKNOWN"
            if pillar in pillar_findings:
                pillar_findings[pillar].append(f)

        scores = {}
        pillar_details = {}
        for pid, pfindings in pillar_findings.items():
            # 统计各规则出现次数（v2: 重复触发的同一规则衰减扣分）
            rule_counts: Dict[str, int] = {}
            deduction = 0.0
            for f in pfindings:
                rid = f.get("rule_id", "unknown")
                rule_counts[rid] = rule_counts.get(rid, 0) + 1
                repeat = rule_counts[rid]

                fs = FindingScore()
                fs.calculate(
                    severity=f.get("severity", "medium"),
                    confidence=f.get("confidence", "high"),
                    exploitability=f.get("exploitability", "easy"),
                    impact=f.get("impact", "complete"),
                )

                # v2: 第二次及以上触发同一规则，扣分衰减
                decay = (RULE_REPEAT_DECAY ** (repeat - 1)) if repeat > 1 else 1.0
                deduction += fs.raw_score * decay

            pillar_score = max(0, 100 - deduction)
            scores[pid] = pillar_score

            pillar_details[pid] = PillarScore(
                pillar_id=pid,
                pillar_name={
                    "IS": "Input Sanitization",
                    "SI": "Sandbox Isolation",
                    "PM": "Privilege Minimization",
                }.get(pid, pid),
                raw_deduction=deduction,
                score=pillar_score,
                finding_count=len(pfindings),
                top_rules=rule_counts,
            )

        self.is_score = scores.get("IS", 100.0)
        self.si_score = scores.get("SI", 100.0)
        self.pm_score = scores.get("PM", 100.0)
        self.pillars = pillar_details

        # 加权总分
        self.total = (
            self.is_score * PILLAR_WEIGHTS["IS"]
            + self.si_score * PILLAR_WEIGHTS["SI"]
            + self.pm_score * PILLAR_WEIGHTS["PM"]
        )

        # v2: 最薄弱环节
        pillar_map = {"IS": self.is_score, "SI": self.si_score, "PM": self.pm_score}
        self.weakest_pillar = min(pillar_map, key=pillar_map.get) if pillar_map else ""

        # 等级
        if self.total >= 90: self.grade = "A"
        elif self.total >= 70: self.grade = "B"
        elif self.total >= 50: self.grade = "C"
        elif self.total >= 30: self.grade = "D"
        else: self.grade = "F"

    def to_dict(self) -> Dict:
        d: Dict = {
            "is_score": round(self.is_score, 1),
            "si_score": round(self.si_score, 1),
            "pm_score": round(self.pm_score, 1),
            "total": round(self.total, 1),
            "grade": self.grade,
            "weakest_pillar": self.weakest_pillar,
        }
        # v2: pillar明细
        if self.pillars:
            d["pillars"] = {
                pid: ps.to_dict()
                for pid, ps in self.pillars.items()
            }
        return d
