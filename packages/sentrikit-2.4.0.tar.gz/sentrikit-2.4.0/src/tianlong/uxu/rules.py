"""tianlong.uxu.rules — UXU 30条安全规则定义

基于 UXU-MVP-SPEC.md 的 30 条规则，分三柱：
- IS (Input Sanitization): 10条 — 输入消毒
- SI (Sandbox Isolation): 10条 — 沙箱隔离
- PM (Privilege Minimization): 10条 — 权限最小化

IS + SI 为免费规则，PM 为付费规则。
每条规则包含 detection patterns、severity、fix suggestion。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional


@dataclass
class UXURule:
    """一条 UXU 安全规则"""
    rule_id: str          # UXU-IS-001
    pillar: str           # input_sanitization / sandbox_isolation / privilege_minimization
    severity: str         # critical / high / medium / low
    title: str
    description: str
    patterns: List[str]   # 检测关键词/模式
    suggestion: str       # 修复建议
    tier: str = "free"    # free / paid


# ── IS: Input Sanitization (10条·免费) ────────────────

IS_RULES: List[UXURule] = [
    UXURule(
        "UXU-IS-001", "input_sanitization", "critical",
        "用户提示注入：未消毒的用户输入直接拼接到系统Prompt",
        "用户输入直接拼接为系统角色设定，攻击者可劫持Agent角色",
        ["SystemMessage(content=f", "system_prompt=f", "system_message=f",
         "ChatPromptTemplate.from_messages", "f\"{user_input}", ".format(user_input"],
        "1. 用户输入只作为 data 字段传入，不拼接 system prompt\n2. 使用 LangChain 的 MessagesPlaceholder",
    ),
    UXURule(
        "UXU-IS-002", "input_sanitization", "high",
        "外部内容注入：未经消毒的外部读取内容进入决策链",
        "网页/文件/数据库读取的内容直接传给 Agent 而不做消毒",
        ["web_search", "load_summary", "get_url_content", "read_file",
         "requests.get", "urlopen", "fetch_url",
         "httpx.", "aiohttp.", "scrape", "crawl", "bs4", "beautifulsoup"],
        "1. 对所有外部读取内容执行与用户输入同等严格的消毒\n2. 使用 bleach.clean() 清洗 HTML",
    ),
    UXURule(
        "UXU-IS-003", "input_sanitization", "high",
        "Prompt模板注入：用户可控变量嵌入系统级Prompt",
        "用户输入被插入系统Prompt而非仅作为数据字段",
        ["SystemMessage(content=", "ChatPromptTemplate.system",
         "agent_kwargs['system_message']", "llm_cfg['system_prompt']",
         "with_system_prompt"],
        "1. 用户变量只通过 data 字段传入\n2. 系统 Prompt 使用固定模板，不动态拼接",
    ),
    UXURule(
        "UXU-IS-004", "input_sanitization", "high",
        "间接注入：工具返回值未经消毒返回Agent循环",
        "工具调用结果直接作为LLM下一轮输入，不经过滤",
        ["@tool", "tool_function", "Tool(", "from langchain",
         "AgentExecutor", "create_tool_calling_agent",
         "StructuredTool", "BaseTool"],
        "1. 工具输出经 sanitizer 后再返回 LLM\n2. 对数值/枚举结果做白名单校验",
    ),
    UXURule(
        "UXU-IS-005", "input_sanitization", "medium",
        "多轮注入累积：跨轮次注入拼接绕过单轮检测",
        "攻击向量跨多轮对话拆分，每轮单独看无问题",
        ["ConversationBufferMemory", "ConversationSummaryMemory",
         "chat_memory", "summary_memory",
         "messages", "MessageHistory"],
        "1. 每轮用户输入独立做注入检测\n2. 对多轮拼接后的文本做二次检测",
    ),
    UXURule(
        "UXU-IS-006", "input_sanitization", "medium",
        "编码绕过检测：Base64/Unicode编码绕过简单关键词匹配",
        "攻击者用编码/混淆绕过关键词黑名单",
        ["base64.b64encode", "base64.b64decode", "base64_encode",
         "base64_decode", "unicode_escape", "string_escape",
         "\\x[0-9a-f]", "chr(ord("],
        "1. 解码后再次扫描\n2. 用语义检测替代关键词黑名单",
    ),
    UXURule(
        "UXU-IS-007", "input_sanitization", "medium",
        "提示泄露：错误信息/调试输出包含系统Prompt",
        "Agent错误详情中包含系统Prompt或内部指令",
        ["print(prompt", "logger.debug", "logging.debug",
         "traceback", "error_detail", "stack_trace"],
        "1. 生产环境关闭详细错误\n2. 用户可见错误信息不包含内部 Prompt",
    ),
    UXURule(
        "UXU-IS-008", "input_sanitization", "low",
        "角色混淆：用户请求Agent假装自己是另一个Agent",
        "用户引导Agent扮演其他角色绕过安全限制",
        ["system_message", "role", "persona", "扮演", "pretend",
         "act as", "you are now"],
        "1. 系统角色设定使用固定模板\n2. 检测并拦截角色扮演类注入",
    ),
    UXURule(
        "UXU-IS-009", "input_sanitization", "medium",
        "Prompt泄露提取：诱导Agent输出完整Prompt",
        "用户通过特定提问手法诱导Agent输出系统Prompt",
        ["ignore previous", "ignore all", "forget",
         "original prompt", "system prompt", "instructions",
         "你被设定为", "你的系统提示"],
        "1. Prompt 中添加'不透露内部指令'的指令\n2. 输出过滤检测系统 Prompt 原文",
    ),
    UXURule(
        "UXU-IS-010", "input_sanitization", "critical",
        "文件路径遍历：工具调用中包含路径遍历攻击",
        "Agent工具调用时传入包含 ../ 或绝对路径的用户输入",
        ["open(request", "open(user", "Path(request", "../../",
         "..\\\\", "read_file(request", "load_file(request",
         "file_path=request", "path=request"],
        "1. 路径参数使用白名单（仅允许指定目录）\n2. 使用 path_validate 禁止 ../ 和绝对路径",
    ),
    UXURule(
        "UXU-IS-011", "input_sanitization", "high",
        "记忆文件注入：Agent记忆存储内容未经消毒直接进入决策链",
        "Agent从记忆文件（brain/memory/*.md）读取的内容直接传给LLM，记忆被投毒后影响所有后续决策",
        ["brain/", "memory/", "semantic-memory", "procedural-memory",
         "working-memory", "online-state", "read_text", "read_memory",
         "memory-system", "MemorySystem"],
        "1. 记忆文件读取后必须经内容消毒再传LLM\n2. 标记可疑的记忆条目（含代码/指令/注入payload）\n3. 记忆写入前做注入扫描",
    ),
    UXURule(
        "UXU-IS-012", "input_sanitization", "critical",
        "自我代码注入：Agent执行自身记忆/配置中的代码",
        "Agent从自身记忆文件或配置中读取代码/指令并执行，攻击者可污染记忆文件实现代码执行",
        ["exec(", "eval(", "compile(", "subprocess.run(",
         "os.system(", "brain/", "semantic-memory",
         "procedural-memory", "read_text", "read_memory",
         "load_config", "config.read", "getattr(obj, "],
        "1. 禁止从记忆文件动态加载代码\n2. 记忆文件中的代码片段只展示不执行\n3. 写入前做exec/eval关键词扫描",
    ),
    UXURule(
        "UXU-IS-013", "input_sanitization", "high",
        "SaaS API Key注入：用户输入包含API Key绕过认证门控",
        "用户输入中携带第三方API Key，可绕过Agent的Key门控策略，实现模型盗窃或越权调用",
        ['api_key="', "SENTRIKIT_API_KEY", "OPENAI_API_KEY",
         "ANTHROPIC_API_KEY", "api-key=", "bearer ",
         "Authorization: Bearer", "x-api-key"],
        "1. API Key 只从安全的环境变量读取\n2. 用户输入中出现的API Key需扫描+拦截\n3. 实现Key泄漏检测和自动轮换",
    ),

]
# ── SI: Sandbox Isolation (10条·免费) ────────────────

SI_RULES: List[UXURule] = [
    UXURule(
        "UXU-SI-001", "sandbox_isolation", "critical",
        "代码执行沙箱逃逸：Python exec/eval 无沙箱保护",
        "Agent使用exec/eval执行用户提供的代码片段，无沙箱隔离",
        ["exec(", "eval(", "compile(", "__import__", "importlib",
         "subprocess.run", "subprocess.Popen", "os.system",
         "marshal.load", "pickle.loads", "ctypes.CDLL", "dlopen"],
        "1. 使用 PyPy sandbox / RestrictedPython\n2. 禁止直接 exec 用户代码",
    ),
    UXURule(
        "UXU-SI-002", "sandbox_isolation", "critical",
        "Shell命令注入：用户输入拼接shell命令",
        "用户输入直接拼接到 shell 命令字符串中",
        ["subprocess.run(", "subprocess.Popen(", "os.system(",
         "os.popen(", "shlex", "bash -c", "shell=True"],
        "1. 使用 shlex.quote() 转义所有参数\n2. 用列表参数替代 shell=True",
    ),
    UXURule(
        "UXU-SI-003", "sandbox_isolation", "high",
        "网络请求无限制：Agent可访问任意外部地址",
        "Agent的 HTTP 请求没有域名/协议白名单",
        ["requests.get", "requests.post", "urlopen", "httpx",
         "aiohttp", "curl", "wget", "fetch",
         "urllib.request", "urllib3", "socket.connect", "websocket"],
        "1. 实现域名白名单\n2. 协议仅允许 http/https\n3. 禁止内网地址",
    ),
    UXURule(
        "UXU-SI-004", "sandbox_isolation", "high",
        "文件系统越权：Agent可读写任意路径",
        "Agent的文件操作没有限定工作目录",
        ["open(", "write_file", "save_file", "upload_file",
         "shutil.copy", "shutil.move", "os.remove"],
        "1. 限定 Agent 只能操作指定工作目录\n2. 使用 chroot/jail 隔离文件系统",
    ),
    UXURule(
        "UXU-SI-005", "sandbox_isolation", "medium",
        "数据库注入：Agent生成并执行SQL无参数化",
        "Agent构造SQL查询时直接拼接参数",
        ["cursor.execute", "session.execute",
         "raw_sql", "sqlalchemy.text", "session.query"],
        "1. Agent只能使用参数化查询\\n2. SQL 模板预定义，不允许动态拼接",
    ),
    UXURule(
        "UXU-SI-006", "sandbox_isolation", "high",
        "环境变量泄露：Agent可读取全部环境变量",
        "Agent能访问包含 API Key 的系统环境变量",
        ["os.environ", "os.getenv", "environ.get",
         "environ['", "load_dotenv", "dotenv"],
        "1. Agent 只应看到最小必需环境变量\n2. 使用 .env 白名单机制",
    ),
    UXURule(
        "UXU-SI-007", "sandbox_isolation", "medium",
        "临时文件未清理：Agent创建临时文件后不删除",
        "Agent操作产生的临时文件未在结束时清理",
        ["tempfile", "TemporaryFile", "mkstemp", "mkdtemp",
         "/tmp/", "/dev/shm/"],
        "1. 使用 with 语句确保临时文件自动清理\n2. 实现 atexit 清理注册",
    ),
    UXURule(
        "UXU-SI-008", "sandbox_isolation", "medium",
        "子进程超时未设置：Agent调用外部命令无超时",
        "Agent启动的子进程可能永久阻塞",
        ["subprocess.run(", "subprocess.Popen(", "os.system(",
         "os.popen(", "run_shell", "exec_command"],
        "1. subprocess.run 设置 timeout 参数\n2. 实现 watchdog 监控子进程",
    ),
    UXURule(
        "UXU-SI-009", "sandbox_isolation", "low",
        "并发资源竞争：多Agent实例操作同一资源",
        "多个 Agent 实例同时操作同一文件/数据库连接无锁",
        ["threading", "multiprocessing", "concurrent",
         "asyncio.gather", "ThreadPoolExecutor"],
        "1. 文件操作使用 filelock\n2. 数据库操作使用事务",
    ),
    UXURule(
        "UXU-SI-010", "sandbox_isolation", "high",
        "容器/VM逃逸：Agent运行在Docker内但挂载了敏感路径",
        "Docker容器挂载了 docker.sock 或宿主机敏感目录",
        ["docker.sock", "/var/run/docker", "--privileged",
         "volume", "bind mount", "hostPath"],
        "1. 不挂载 docker.sock 到 Agent 容器\n2. 使用只读挂载而非读写",
    ),
    UXURule(
        "UXU-SI-011", "sandbox_isolation", "high",
        "Agent间通信未加密：多Agent间数据传输无认证/加密",
        "多个Agent实例间通过共享内存/文件/消息队列通信，无身份认证和传输加密，可被中间人注入恶意指令",
        ["Agent-to-Agent", "inter-agent", "agent_communication", "agent_bus",
         "shared_memory", "message_queue", "agent_router",
         "broadcast", "agent_discovery", "agent_registry"],
        "1. Agent间通信必须使用TLS加密\n2. 实现Agent身份证书认证\n3. 消息队列设置ACL白名单",
    ),

]
# ── PM: Privilege Minimization (10条·付费) ───────────

PM_RULES: List[UXURule] = [
    UXURule(
        "UXU-PM-001", "privilege_minimization", "critical",
        "API Key硬编码：密钥直接写在源码中",
        "API Key、Token等凭证硬编码在Python源码或配置文件中",
        ['="sk-', '="pk-', "api_key=", "apikey=", "token=",
         "secret=", "password=", 'openai.api_key'],
        "1. 使用环境变量或密钥管理服务\n2. 代码中只引用变量名，不写值",
        tier="free",
    ),
    UXURule(
        "UXU-PM-002", "privilege_minimization", "high",
        "工具权限过宽：Agent拥有远超需求的工具集",
        "Agent注册了大量不需要的工具，增加攻击面",
        ["Tool(", "@tool", "tools=[", "toolkit",
         "load_tools", "get_all_tools"],
        "1. 每个 Agent 只注册业务必需工具\n2. 敏感工具需要单独授权",
        tier="free",
    ),
    UXURule(
        "UXU-PM-003", "privilege_minimization", "high",
        "数据库权限过宽：Agent用root/Admin连接数据库",
        "Agent使用的数据库账号拥有远超需求的权限",
        ["postgresql://", "mysql://", "mongodb://",
         "sqlite://", "create_engine", "db_url"],
        "1. Agent 专用DB账号只给 CRUD 权限\n2. 禁止 DDL 权限（CREATE/ALTER/DROP）",
        tier="free",
    ),
    UXURule(
        "UXU-PM-004", "privilege_minimization", "medium",
        "文件权限过宽：Agent可读写敏感系统文件",
        "Agent运行在过高权限用户下，可修改系统文件",
        ["/etc/", "/usr/local", "/opt/", "/var/log",
         "sudo", "chmod 777", "chown"],
        "1. 使用专用低权限用户运行 Agent\n2. Agent 工作目录独立隔离",
        tier="free",
    ),
    UXURule(
        "UXU-PM-005", "privilege_minimization", "high",
        "网络权限过宽：Agent可访问内网敏感服务",
        "Agent可访问数据库/Redis/K8s API等内网服务",
        ["localhost", "127.0.0.1", "10.0.", "172.16.",
         "192.168.", "internal", "inner"],
        "1. Agent 网络隔离，只能访问白名单地址\n2. 使用网络策略限制出站",
        tier="free",
    ),
    UXURule(
        "UXU-PM-006", "privilege_minimization", "medium",
        "无操作审计日志：Agent操作不可追溯",
        "Agent没有操作日志或日志不包含关键上下文",
        ["logger.info", "logging.info",
         "tracer", "span", "opentelemetry"],
        "1. 所有工具调用记录 audit 日志\\n2. 日志包含：操作人、时间、参数、结果",
        tier="free",
    ),
    UXURule(
        "UXU-PM-007", "privilege_minimization", "medium",
        "会话权限继承：Agent会话间共享凭证",
        "Agent在不同会话间共享 Token/Session，无隔离",
        ["session", "token", "cookie", "jwt",
         "shared", "global", "singleton"],
        "1. 每个会话使用独立 Token\n2. 会话结束时清除凭证",
        tier="free",
    ),
    UXURule(
        "UXU-PM-008", "privilege_minimization", "low",
        "长期凭证未轮换：使用的API Key长期不变",
        "Agent使用的 API Key 没有设置过期轮换",
        ["api_key", "access_key", "secret_key",
         "token", "credential"],
        "1. API Key 设置自动轮换周期\n2. 使用临时凭证（如 STS）替代长期 Key",
        tier="free",
    ),
    UXURule(
        "UXU-PM-009", "privilege_minimization", "medium",
        "数据脱敏缺失：Agent日志中包含敏感数据",
        "Agent的 prompt 日志/错误日志包含用户敏感信息",
        ["logger.debug(", "logger.error(", "logging.debug",
         "logging.error", "prompt_log", "message_log",
         "history_log"],
        "1. 日志中自动脱敏（邮箱→u***@***.com）\n2. 使用 PII 检测器过滤日志输出",
        tier="free",
    ),
    UXURule(
        "UXU-PM-010", "privilege_minimization", "high",
        "无限Token消耗：Agent循环调用消耗Token无上限",
        "Agent在循环中无限制调用LLM，导致Token失控",
        ["while", "for", "loop", "recursion", "retry",
         "max_iterations", "AgentExecutor"],
        "1. 设置 max_tokens 硬上限\n2. 实现 budget 控制系统",
        tier="free",
    ),
    UXURule(
        "UXU-PM-011", "privilege_minimization", "high",
        "供应链依赖未锁定（企业版）：Agent使用的第三方依赖版本未锁定",
        "Agent依赖的第三方包未锁定版本号，依赖可被供应链攻击替换为恶意版本",
        ["requirements.txt", "pyproject.toml", "package.json", "go.mod",
         "pip install ", "npm install ", "cargo install ",
         ">=0", "~=0", "^0", "*", "latest"],
        "1. 所有依赖必须锁定精确版本号\\n2. 使用 lockfile（poetry.lock/pipfile.lock）\n3. 定期扫描依赖漏洞（pip-audit/npm audit）",
        tier="paid",
    ),
    UXURule(
        "UXU-PM-012", "privilege_minimization", "critical",
        "跨Agent越权（企业版）：Agent执行了其他Agent角色的特权操作",
        "Agent绕过角色路由直接执行其他Agent的专属操作（如运营Agent执行了代码部署）",
        ["switch_role", "impersonate", "sudo", "run_as",
         "elevate", "privilege_escalation", "bypass_auth",
         "admin_override", "force_execute"],
        "1. 每个Agent的操作必须经过角色路由\n2. 操作前检查当前Agent的角色权限\n3. 跨角色操作需要额外授权签名",
        tier="paid",
    ),
    UXURule(
        "UXU-PM-013", "privilege_minimization", "high",
        "Ast深度注入（企业版）：通过AST模式匹配检测深层代码注入",
        "代码中存在通过AST执行动态代码构造的模式，如exec/eval/setattr/compile等可能被利用的执行路径",
        ["ast.literal_eval", "exec(", "eval(", "compile(", "__import__",
         "setattr(", "getattr(obj, '", "delattr", "globals()", "locals()",
         "type(name, bases, dict)", "importlib.import_module"],
        "1. 使用白名单限制动态执行函数\\n2. 所有 exec/eval 必须经过入参消毒\\n3. 使用 AST 预扫描检测动态构造模式",
        tier="paid",
    ),
    UXURule(
        "UXU-PM-014", "privilege_minimization", "critical",
        "供应链深层劫持（企业版）：依赖包原生安装和post-install脚本风险",
        "setup.py/pyproject.toml/package.json 中包含可执行安装后脚本，恶意包可借此植入后门",
        ["setup.py install", "postinstall", "post_install", "scripts.install",
         "preinstall", "pre_install", "pip install --no-verify",
         "npm postinstall", "--unsafe-perm", "sudo pip",
         "curl.*| sh", "curl.*| bash", "wget.*| sh"],
        "1. 禁止 pip install 绕过签名验证\\n2. 审查所有依赖包的 setup.py 中的 install hooks\\n3. 使用 pip-audit 扫描依赖漏洞",
        tier="paid",
    ),
    UXURule(
        "UXU-PM-015", "privilege_minimization", "critical",
        "Agent权限边界突破（企业版）：检测Agent绕过沙箱权限的操作",
        "Agent尝试写系统敏感路径、修改环境变量、降级自身上下文权限、或访问其他Agent的数据目录",
        ["os.environ['", "os.putenv", "subprocess.run(shell=True",
         "subprocess.Popen(shell=True", "os.chmod('/", "os.chown",
         "/etc/", "/var/run", "/tmp/.agent", "../secrets",
         "rm -rf", "chmod 777", "chmod +s"],
        "1. Agent 文件操作严格限制在 project_dir 范围内\\n2. 禁止修改系统敏感路径和环境变量\\n3. 跨Agent数据访问需经过 Router 授权",
        tier="paid",
    ),

]

ALL_RULES: List[UXURule] = IS_RULES + SI_RULES + PM_RULES
FREE_RULES: List[UXURule] = [r for r in ALL_RULES if r.tier == 'free']
CUSTOM_RULES: List[UXURule] = []


def register_custom_rule(rule: UXURule) -> None:
    """注册一条自定义规则，运行时生效。"""
    if rule.rule_id in [r.rule_id for r in ALL_RULES]:
        raise ValueError(f"规则ID {rule.rule_id} 已存在")
    CUSTOM_RULES.append(rule)
    ALL_RULES.append(rule)
    if rule.tier == "free":
        FREE_RULES.append(rule)


def load_custom_rules(filepath: str) -> int:
    """从 JSON 文件批量加载自定义规则，返回加载数量。"""
    import json
    from pathlib import Path
    fp = Path(filepath)
    if not fp.exists():
        raise FileNotFoundError(f"自定义规则文件不存在: {filepath}")
    data = json.loads(fp.read_text(encoding="utf-8"))
    count = 0
    for item in data:
        rule = UXURule(
            rule_id=item.get("rule_id", ""),
            pillar=item.get("pillar", ""),
            severity=item.get("severity", "medium"),
            title=item.get("title", ""),
            description=item.get("description", ""),
            patterns=item.get("patterns", []),
            suggestion=item.get("suggestion", ""),
            tier=item.get("tier", "free"),
        )
        register_custom_rule(rule)
        count += 1
    return count


def get_rule(rule_id: str) -> Optional[UXURule]:
    """按 rule_id 查找规则。"""
    for r in ALL_RULES:
        if r.rule_id == rule_id:
            return r
    return None


def get_rules_by_pillar(pillar: str) -> List[UXURule]:
    """按 pillar 过滤规则。"""
    return [r for r in ALL_RULES if r.pillar == pillar]


def get_rules_by_severity(severity: str) -> List[UXURule]:
    """按 severity 过滤规则。"""
    return [r for r in ALL_RULES if r.severity == severity]


def get_free_rules() -> List[UXURule]:
    return FREE_RULES


def get_paid_rules() -> List[UXURule]:
    return PM_RULES
