"""tianlong.uxu.dataflow — 数据流追踪引擎

基于变量赋值链 + 函数调用链的轻量级污染分析。
追踪：外部输入(source) → 处理节点(sink) 的传播路径。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


# 外部输入源（taint sources）
TAINT_SOURCES = {
    "user_input", "request", "argv", "sys.argv", "input(",
    "get_input", "receive_message", "listen",
    "http_request", "flask.request", "fastapi.Request",
    "request.json", "request.args", "request.form",
    "body", "params", "query", "data",
    "open(", "file_read", "read_text",
    "subprocess.check_output", "subprocess.Popen",
    "requests.get", "requests.post", "fetch",
}

# 敏感操作（taint sinks）
TAINT_SINKS = {
    "exec(", "eval(", "compile(",
    "subprocess.run", "subprocess.Popen", "os.system", "os.popen",
    "llm.invoke", "llm.predict", "llm.generate",
    "client.chat.completions.create",
    "openai.ChatCompletion.create",
    "Session.run", "chain.run", "agent.run",
    "PromptTemplate.format", "ChatPromptTemplate.from_messages",
    "SystemMessage", "HumanMessage",
    "write_file", "save_file", "open(",
}

# 消毒函数（sanitizers）
SANITIZERS = {
    "sanitize", "validate", "escape", "strip", "clean",
    "filter", "purify", "scrub", "check",
    "bleach.clean", "html.escape",
    "shlex.quote", "path_validate",
    "length_limit", "truncate",
}


@dataclass
class TaintPath:
    """一条污染传播路径"""
    source: str = ""
    sink: str = ""
    line: int = 0
    path: List[str] = field(default_factory=list)
    has_sanitizer: bool = False
    risk_score: float = 0.0


class DataFlowAnalyzer:
    """数据流追踪分析器。

    基于 PythonAST 的输出变量名+函数调用，
    追踪 taint source → taint sink 的传播路径。
    """

    def __init__(self):
        self.paths: List[TaintPath] = []
        self._tainted_vars: Set[str] = set()
        self._sink_hits: List[Tuple[str, int, str]] = []

    def analyze(self, calls: List, assignments: List) -> List[TaintPath]:
        """运行数据流分析。"""
        self.paths.clear()
        self._tainted_vars.clear()
        self._sink_hits.clear()

        # Phase 1: 标记源头
        for call in calls:
            for src in TAINT_SOURCES:
                if src in call.name.lower():
                    self._tainted_vars.add(f"call_result_{call.line}")

        for assign in assignments:
            for src in TAINT_SOURCES:
                if src in assign.value.lower():
                    self._tainted_vars.add(assign.target)

        # Phase 2: 追踪传播
        prev_size = -1
        while len(self._tainted_vars) != prev_size:
            prev_size = len(self._tainted_vars)
            for assign in assignments:
                for tv in list(self._tainted_vars):
                    if tv in assign.value and assign.target not in self._tainted_vars:
                        self._tainted_vars.add(assign.target)

        # Phase 3: 检测 sink
        for call in calls:
            for sink in TAINT_SINKS:
                if sink in call.name.lower():
                    # 检查是否有 tainted 变量作为参数
                    for arg in call.args:
                        if arg in self._tainted_vars:
                            has_san = any(
                                s in str(call) for s in SANITIZERS
                            )
                            score = 0.9 if not has_san else 0.3
                            self._sink_hits.append((call.name, call.line, arg))
                            self.paths.append(TaintPath(
                                source=self._find_source(arg),
                                sink=call.name,
                                line=call.line,
                                path=list(self._tainted_vars),
                                has_sanitizer=has_san,
                                risk_score=score,
                            ))

        return self.paths

    def _find_source(self, var: str) -> str:
        return "external_input"

    def has_critical_flow(self) -> bool:
        return any(p.risk_score >= 0.7 and not p.has_sanitizer for p in self.paths)
