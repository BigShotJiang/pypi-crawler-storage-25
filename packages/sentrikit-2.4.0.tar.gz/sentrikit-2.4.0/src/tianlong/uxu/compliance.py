"""tianlong.uxu.compliance — OWASP LLM Top 10 合规映射

CodeVigil 规则 → OWASP LLM Top 10 映射矩阵。
"""

from __future__ import annotations

from typing import Dict, List

# OWASP LLM Top 10 → CodeVigil 规则映射
OWASP_MAPPING: Dict[str, List[str]] = {
    "LLM01 - Prompt Injection": [
        "UXU-IS-001", "UXU-IS-002", "UXU-IS-003",
        "UXU-IS-005", "UXU-IS-008",
        "UXU-IS-011", "UXU-IS-012",
    ],
    "LLM02 - Insecure Output Handling": [
        "UXU-IS-005", "UXU-PM-010",
        "UXU-SI-011",
    ],
    "LLM03 - Training Data Poisoning": [],  # 超出 UXU 范围
    "LLM04 - Model Denial of Service": [
        "UXU-IS-004", "UXU-SI-004", "UXU-PM-010",
    ],
    "LLM05 - Supply Chain": [
        "UXU-SI-007",
        "UXU-PM-011",
    ],
    "LLM06 - Sensitive Information Disclosure": [
        "UXU-PM-002", "UXU-PM-010", "UXU-SI-006",
        "UXU-IS-006",
    ],
    "LLM07 - Insecure Plugin Design": [
        "UXU-SI-007", "UXU-PM-006",
        "UXU-PM-012",
    ],
    "LLM08 - Excessive Agency": [
        "UXU-PM-005", "UXU-PM-006", "UXU-SI-003",
    ],
    "LLM09 - Overreliance": [],  # 超出 UXU 范围
    "LLM10 - Model Theft": [
        "UXU-IS-013",
    ],
}


def get_compliance_coverage(findings: List[Dict]) -> Dict:
    """计算 OWASP 合规覆盖率。"""
    found_rule_ids = {f.get("rule_id", "") for f in findings}
    result = {}
    covered = 0
    total = sum(1 for v in OWASP_MAPPING.values() if v)  # 排除 N/A 的条目

    for category, rule_ids in OWASP_MAPPING.items():
        if not rule_ids:
            result[category] = {"covered": False, "matched": [], "status": "N/A (超出范围)"}
            continue
        matched = [rid for rid in rule_ids if rid in found_rule_ids]
        is_covered = len(matched) >= len(rule_ids) * 0.5  # 50% 覆盖率算覆盖
        if is_covered:
            covered += 1
        result[category] = {
            "covered": is_covered,
            "matched": matched,
            "missing": [rid for rid in rule_ids if rid not in found_rule_ids],
            "status": "✅ 已覆盖" if is_covered else "⚠️ 部分覆盖",
        }

    return {
        "coverage": f"{covered}/{total}",
        "coverage_rate": round(covered / total, 2) if total > 0 else 0,
        "categories": result,
    }


def get_compliance_report_text(findings: List[Dict]) -> str:
    """生成可读的合规报告文本。"""
    data = get_compliance_coverage(findings)
    lines = ["OWASP LLM Top 10 Coverage:"]
    for cat, info in data["categories"].items():
        icon = info["status"]
        lines.append(f"  {icon}  {cat}")
    lines.append(f"\n覆盖率: {data['coverage']} ({data['coverage_rate']:.0%})")
    return "\n".join(lines)
