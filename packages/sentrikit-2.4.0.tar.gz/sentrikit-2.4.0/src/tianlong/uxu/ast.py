"""tianlong.uxu.ast — Python AST 解析器

基于 ast 标准库的源文件解析，支持：
- 函数定义/调用提取
- 变量赋值追踪
- import 检测
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple


@dataclass
class FuncCall:
    """一次函数调用"""
    name: str
    line: int
    args: List[str] = field(default_factory=list)
    keywords: Dict[str, str] = field(default_factory=dict)


@dataclass
class Assignment:
    """一次变量赋值"""
    target: str
    line: int
    value: str = ""


@dataclass
class ImportInfo:
    """导入信息"""
    module: str
    names: List[str] = field(default_factory=list)
    alias: str = ""


class PythonAST:
    """Python 源文件 AST 解析器。"""

    def __init__(self, content: str):
        self.content = content
        self.tree: Optional[ast.Module] = None
        self.calls: List[FuncCall] = []
        self.assignments: List[Assignment] = []
        self.imports: List[ImportInfo] = []
        self.framework_imports: Set[str] = set()
        self._parsed = False

    def parse(self) -> bool:
        try:
            self.tree = ast.parse(self.content)
            self._walk(self.tree)
            self._parsed = True
            return True
        except SyntaxError:
            return False

    def _walk(self, node: ast.AST) -> None:
        """遍历 AST 节点收集信息。"""
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                self._visit_call(child)
            elif isinstance(child, ast.Assign):
                self._visit_assign(child)
            elif isinstance(child, ast.Import):
                self._visit_import(child)
            elif isinstance(child, ast.ImportFrom):
                self._visit_import_from(child)

    def _visit_call(self, node: ast.Call) -> None:
        name = self._get_call_name(node.func)
        args = [self._ast_to_str(a) for a in node.args]
        keywords = {kw.arg or "": self._ast_to_str(kw.value) for kw in node.keywords if kw.arg}
        self.calls.append(FuncCall(name=name, line=node.lineno, args=args, keywords=keywords))

    def _visit_assign(self, node: ast.Assign) -> None:
        for target in node.targets:
            tname = self._ast_to_str(target)
            val = self._ast_to_str(node.value)
            self.assignments.append(Assignment(target=tname, line=node.lineno, value=val))

    def _visit_import(self, node: ast.Import) -> None:
        for alias in node.names:
            name = alias.name
            self.imports.append(ImportInfo(module=name, alias=alias.asname or ""))
            self._detect_framework(name)

    def _visit_import_from(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        names = [n.name for n in node.names]
        self.imports.append(ImportInfo(module=module, names=names))
        self._detect_framework(module)
        for n in names:
            self._detect_framework(f"{module}.{n}")

    def _detect_framework(self, name: str) -> None:
        frameworks = {
            "langchain": "langchain",
            "openai": "openai-sdk",
            "anthropic": "anthropic-sdk",
            "llama_index": "llamaindex",
            "crewai": "crewai",
            "autogen": "autogen",
            "semantic_kernel": "semantic-kernel",
        }
        for key, val in frameworks.items():
            if key in name.lower():
                self.framework_imports.add(val)

    @staticmethod
    def _get_call_name(node: ast.AST) -> str:
        if isinstance(node, ast.Attribute):
            return f"{PythonAST._get_call_name(node.value)}.{node.attr}"
        elif isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Call):
            return PythonAST._get_call_name(node.func)
        return ""

    @staticmethod
    def _ast_to_str(node: ast.AST) -> str:
        if isinstance(node, ast.Constant):
            return str(node.value) if node.value is not None else "None"
        elif isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return f"{PythonAST._ast_to_str(node.value)}.{node.attr}"
        elif isinstance(node, ast.Call):
            return f"{PythonAST._get_call_name(node)}(...)"
        elif isinstance(node, ast.List):
            return "[...]"
        elif isinstance(node, ast.Dict):
            return "{...}"
        elif isinstance(node, ast.BinOp):
            return f"{PythonAST._ast_to_str(node.left)} op {PythonAST._ast_to_str(node.right)}"
        return "?"

    # ── AST语义确认（v2）──────────────────────────────

    def has_exec_call(self) -> bool:
        """确认是否存在真正的exec()调用（非注释/字符串中的exec）。"""
        if not self.tree:
            return False
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                name = self._get_call_name(node.func)
                if name == "exec":
                    return True
        return False

    def has_eval_call(self) -> bool:
        """确认是否存在真正的eval()调用。"""
        if not self.tree:
            return False
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                name = self._get_call_name(node.func)
                if name == "eval":
                    return True
        return False

    def has_subprocess_call(self) -> bool:
        """确认是否存在真正的 subprocess.run/Popen 调用。"""
        if not self.tree:
            return False
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                name = self._get_call_name(node.func)
                if name in ("subprocess.run", "subprocess.Popen", "subprocess.call", "subprocess.check_call"):
                    return True
        return False

    def has_string_concat_in_call(self, target_func: str) -> bool:
        """确认函数调用中是否含有字符串拼接（IS-001/003 的 f-string 确认）。"""
        if not self.tree:
            return False
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                name = self._get_call_name(node.func)
                if target_func in name:
                    for arg in node.args:
                        if isinstance(arg, ast.JoinedStr):
                            return True  # f"...{var}"
                        if isinstance(arg, ast.BinOp) and isinstance(arg.op, ast.Add):
                            return True  # "..." + var
                    for kw in node.keywords:
                        if isinstance(kw.value, ast.JoinedStr):
                            return True
        return False

    def count_eval_occurrences(self) -> int:
        """统计eval/exec/subprocess调用的精确次数（非注释）。"""
        if not self.tree:
            return 0
        count = 0
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                name = self._get_call_name(node.func)
                if name in ("exec", "eval", "compile"):
                    count += 1
        return count
