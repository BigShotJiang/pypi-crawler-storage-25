"""tianlong.uxu.cli — CodeVigil 安全审计 CLI

用法:
    tianlong-uxu scan <path>
    tianlong-uxu scan <path> --deep --compliance --format html -o report.html
    tianlong-uxu summary <path>
    tianlong-uxu rules
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .scanner import Scanner
from .rules import ALL_RULES, get_rules_by_pillar, get_rules_by_severity
from .score import SEVERITY_WEIGHTS
from .compliance import get_compliance_report_text


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tianlong-uxu",
        description="SentriKit - CodeVigil AI Agent 安全审计",
    )
    sub = p.add_subparsers(dest="command", required=True)

    # scan
    sp = sub.add_parser("scan", help="扫描目录/文件")
    sp.add_argument("path", type=str, help="目标路径")
    sp.add_argument("--free-only", action="store_true", help="仅使用免费规则 (IS+SI)")
    sp.add_argument("--severity", "-s", type=str,
                    choices=["critical", "high", "medium", "low"],
                    default="low", help="最低报告等级 (默认: low)")
    sp.add_argument("--format", "-f", type=str, choices=["text", "json", "html"], default="text")
    sp.add_argument("--output", "-o", type=str, default="", help="输出到文件")
    sp.add_argument("--diff", "-d", type=str, default="",
                    help="对比模式：JSON前次扫描结果路径")
    sp.add_argument("--deep", action="store_true",
                    help="深度扫描：Shell脚本注入 + Web密钥检测")
    sp.add_argument("--self-check", action="store_true", default=False,
                    help="自检模式：扫描框架自身代码（默认跳过）")
    sp.add_argument("--compliance", "-c", action="store_true",
                    help="显示OWASP LLM Top 10合规覆盖率")

    # summary (新)
    ss = sub.add_parser("summary", help="快速扫描摘要")
    ss.add_argument("path", type=str, help="目标路径")
    ss.add_argument("--output", "-o", type=str, default="", help="输出到文件")
    ss.add_argument("--deep", action="store_true", help="深度扫描模式")
    ss.add_argument("--self-check", action="store_true", default=False,
                    help="自检模式：扫描框架自身代码（默认跳过）")

    # rules
    rp = sub.add_parser("rules", help="列出所有规则")
    rp.add_argument("--pillar", "-p", type=str,
                    choices=["input_sanitization", "sandbox_isolation", "privilege_minimization"],
                    help="按支柱过滤")
    rp.add_argument("--severity", "-s", type=str,
                    choices=["critical", "high", "medium", "low"],
                    help="按严重等级过滤")
    rp.add_argument("--format", "-f", type=str, choices=["text", "json"], default="text")

    return p


def _format_text_report(report) -> str:
    grade_colors = {"A": "🟢", "B": "🟢", "C": "🟡", "D": "🔴", "F": "🔴"}
    sev_icons = {"critical": "🔥", "high": "⚠️", "medium": "📌", "low": "ℹ️"}
    lines = []
    lines.append(f"\nCodeVigil 安全审计报告")
    lines.append(f"{'='*55}")
    lines.append(f"目标:    {report.target_path}")
    lines.append(f"文件数:  {report.files_scanned}")
    lines.append(f"发现:    {report.total_findings} 项")
    lines.append(f"评分:    {grade_colors.get(report.score.grade, '?')} {report.score.grade} ({report.score.total:.1f})")
    lines.append(f"三柱:    IS={report.score.is_score:.0f} SI={report.score.si_score:.0f} PM={report.score.pm_score:.0f}")
    if report.frameworks:
        lines.append(f"框架:    {', '.join(report.frameworks)}")
    lines.append("")

    sev_count = {}
    for f in report.findings:
        sev_count[f.severity] = sev_count.get(f.severity, 0) + 1
    if sev_count:
        lines.append("按严重等级:")
        for sev, count in sorted(sev_count.items(),
                                  key=lambda x: SEVERITY_WEIGHTS.get(x[0], 0), reverse=True):
            icon = sev_icons.get(sev, ".")
            lines.append(f"  {icon} {sev}: {count}")
    lines.append("")

    if report.findings:
        lines.append("薄弱环节:")
        if report.score.weakest_pillar:
            lines.append(f"  >> 最弱柱: {report.score.weakest_pillar}")
        lines.append("")
        lines.append("发现清单:")
        lines.append("")
        for f in report.findings:
            icon = sev_icons.get(f.severity, ".")
            lines.append(f"  {icon} [{f.rule_id}] {f.severity.upper()} - {f.title}")
            lines.append(f"      文件: {f.file_path}:{f.line_number}")
            lines.append(f"      匹配: {f.matched_text[:60]}")
            lines.append(f"      建议: {f.suggestion[:80]}")
            lines.append("")
    else:
        lines.append("?? 未发现安全问题")

    return "\n".join(lines)


def _format_html_report(report) -> str:
    sev_colors = {"critical": "#dc3545", "high": "#fd7e14", "medium": "#ffc107", "low": "#6c757d"}
    sev_icons = {"critical": "r", "high": "o", "medium": "y", "low": "g"}
    findings_rows = ""
    for f in report.findings:
        color = sev_colors.get(f.severity, "#6c757d")
        icon = sev_icons.get(f.severity, ".")
        findings_rows += (
            f"<tr><td><span style=\"background:{color};padding:2px 8px;border-radius:4px;color:#fff;font-size:11px\">"
            f"{icon} {f.severity}</span></td>"
            f"<td>{f.rule_id}</td>"
            f"<td>{f.title}</td>"
            f"<td><code>{f.file_path}:{f.line_number}</code></td>"
            f"<td><code>{f.matched_text[:60]}</code></td>"
            f"<td>{f.suggestion[:80]}</td></tr>"
        )
    pillar_bars = ""
    for pid, ps in report.score.pillars.items():
        bc = "#28a745" if ps.score >= 70 else ("#ffc107" if ps.score >= 40 else "#dc3545")
        pillar_bars += (
            f"<div><strong>{ps.pillar_name} ({ps.grade})</strong> "
            f"<div style=\"background:#e9ecef;height:18px;border-radius:9px;overflow:hidden;margin:3px 0\">"
            f"<div style=\"width:{ps.score}%;height:100%;background:{bc}\"></div></div>"
            f"{ps.score:.0f}/100 ({ps.finding_count} findings)</div>"
        )
    gc = {"A": "#28a745", "B": "#28a745", "C": "#ffc107", "D": "#dc3545", "F": "#dc3545"}.get(report.score.grade, "#6c757d")
    html = (
        "<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"UTF-8\">"
        "<title>CodeVigil 安全审计报告</title>"
        "<style>body{font-family:-apple-system,'Segoe UI',sans-serif;max-width:1200px;margin:20px auto;padding:0 20px;background:#f8f9fa}"
        "h1{color:#333;border-bottom:2px solid " + gc + ";padding-bottom:10px}"
        ".grid{display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin:20px 0}"
        ".card{background:#fff;padding:15px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1)}"
        ".card .v{font-size:28px;font-weight:bold;color:" + gc + "}.card .l{color:#666;font-size:13px}"
        "table{width:100%;border-collapse:collapse;margin-top:20px}"
        "th,td{padding:8px 12px;text-align:left;border-bottom:1px solid #dee2e6;font-size:13px}"
        "th{background:#f1f3f5;font-weight:600}code{background:#f1f3f5;padding:1px 4px;border-radius:3px}</style>"
        "</head><body>"
        f"<h1>CodeVigil 安全审计报告</h1>"
        f"<div class=\"grid\">"
        f"<div class=\"card\"><div class=\"v\">{report.score.grade}</div><div class=\"l\">安全等级</div></div>"
        f"<div class=\"card\"><div class=\"v\">{report.score.total:.1f}</div><div class=\"l\">总评分</div></div>"
        f"<div class=\"card\"><div class=\"v\">{report.files_scanned}</div><div class=\"l\">扫描文件数</div></div>"
        f"<div class=\"card\"><div class=\"v\">{report.total_findings}</div><div class=\"l\">安全发现数</div></div>"
        f"</div><h2>三柱评分</h2>{pillar_bars}"
        f"<h2>发现清单 ({report.total_findings})</h2>"
        f"<table><tr><th>等级</th><th>规则</th><th>标题</th><th>文件</th><th>匹配</th><th>建议</th></tr>{findings_rows}</table>"
        f"<p style=\"color:#999;font-size:12px;margin-top:20px\">扫描耗时: {report.duration_ms}ms | CodeVigil Security Audit</p>"
        "</body></html>"
    )
    return html


def cmd_summary(args) -> int:
    try:
        scanner = Scanner(min_severity="low", deep_scan=getattr(args, 'deep', False),
                           self_check=getattr(args, 'self_check', False))
        report = scanner.scan(args.path)
    except FileNotFoundError as e:
        print(f"X {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"X 扫描异常: {e}", file=sys.stderr)
        return 2

    grade_colors = {"A": "g", "B": "g", "C": "y", "D": "r", "F": "r"}
    gicon = grade_colors.get(report.score.grade, "?")
    lines = [
        f"\n{gicon} CodeVigil 安全摘要 - {report.target_path}",
        f"{'='*40}",
        f"  安全等级: {report.score.grade} ({report.score.total:.1f})",
        f"  三柱评分: IS={report.score.is_score:.0f}  SI={report.score.si_score:.0f}  PM={report.score.pm_score:.0f}",
        f"  扫描文件: {report.files_scanned}",
        f"  安全发现: {report.total_findings}",
        f"  文档参考: {len(getattr(report, 'info_findings', []))} 条（不纳入评分）",
    ]
    if report.score.weakest_pillar:
        lines.append(f"  薄弱环节: {report.score.weakest_pillar}")
    if report.frameworks:
        lines.append(f"  检测框架: {', '.join(report.frameworks)}")
    lines.append(f"  耗时: {report.duration_ms}ms\n")

    text = "\n".join(lines)
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print(f"Summary saved to: {args.output}")
    else:
        print(text)
    return 0


def cmd_scan(args) -> int:
    try:
        scanner = Scanner(
            free_only=args.free_only,
            min_severity=args.severity,
            deep_scan=args.deep,
            self_check=args.self_check,
        )
        report = scanner.scan(args.path)
    except FileNotFoundError as e:
        print(f"X {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"X 扫描异常: {e}", file=sys.stderr)
        return 2

    # 对比模式
    diffs = None
    if args.diff:
        diff_path = Path(args.diff)
        if diff_path.exists():
            try:
                prev = json.loads(diff_path.read_text(encoding="utf-8"))
                curr = report.to_dict()
                prev_total = prev.get("summary", {}).get("total", 0)
                curr_total = curr.get("summary", {}).get("total", 0)
                change = curr_total - prev_total
                diffs = {"prev_total": prev_total, "curr_total": curr_total, "change": change, "previous_file": args.diff}
            except Exception:
                diffs = {"error": "无法解析前次扫描结果"}
        else:
            diffs = {"error": f"前次扫描结果文件不存在: {args.diff}"}
        if diffs and "error" not in diffs:
            c_icon = "r" if diffs["change"] > 0 else ("g" if diffs["change"] < 0 else ">")
            print(f"{c_icon} 对比上次: {diffs['prev_total']} -> {diffs['curr_total']} ({diffs['change']:+d})")

    if args.format == "json":
        output_data = json.dumps(report.to_dict(), ensure_ascii=False, indent=2)
    elif args.format == "html":
        output_data = _format_html_report(report)
    else:
        output_data = _format_text_report(report)

    # 合规报告
    if args.compliance and args.format != "html":
        compliance_text = get_compliance_report_text([f.to_dict() for f in report.findings])
        output_data += "\n\n" + compliance_text

    if diffs and args.format == "json":
        full_output = report.to_dict()
        full_output["diff"] = diffs
        output_data = json.dumps(full_output, ensure_ascii=False, indent=2)

    if args.output:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(output_data, encoding="utf-8")
        print(f"Report saved to: {out_path}")
    else:
        print(output_data)
    return 0


def cmd_rules(args) -> int:
    rules = ALL_RULES
    if args.pillar:
        rules = get_rules_by_pillar(args.pillar)
    if args.severity:
        rules = get_rules_by_severity(args.severity)

    if args.format == "json":
        data = [{"rule_id": r.rule_id, "pillar": r.pillar, "severity": r.severity,
                 "title": r.title, "tier": r.tier} for r in rules]
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    free_count = sum(1 for r in rules if r.tier == "free")
    paid_count = sum(1 for r in rules if r.tier == "paid")

    print(f"CodeVigil 规则列表 ({len(rules)} 条)")
    print(f"{'='*45}")
    print(f"免费: {free_count} | 付费: {paid_count}\n")

    for r in rules:
        sev_icon = {"critical": "f", "high": "w", "medium": "p", "low": "i"}.get(r.severity, ".")
        tier_tag = "o" if r.tier == "free" else "x"
        print(f"  {tier_tag}{sev_icon} {r.rule_id} - {r.title}")
        print(f"      {r.description[:70]}\n")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "scan":
        return cmd_scan(args)
    elif args.command == "summary":
        return cmd_summary(args)
    elif args.command == "rules":
        return cmd_rules(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
