"""tianlong.uxu — UXU / CodeVigil AI Agent 安全审计

基于 UXU-MVP-SPEC.md 的 39 条安全规则（IS×13 + SI×11 + PM×15）。
其中 34 条免费 + 5 条企业版（PM-011~PM-015）。
CLI 扫描 Agent 项目代码，输出安全评分和发现清单。

用法:
    from tianlong.uxu import Scanner, ScanReport, ScanFinding
    scanner = Scanner()
    report = scanner.scan("/path/to/project")
    print(f"评分: {report.grade} ({report.score})")

新品牌: CodeVigil — 访问 tianlong.codevigil 模块
"""

from .scanner import Scanner, ScanReport, ScanFinding
from .rules import UXURule, ALL_RULES, FREE_RULES, get_rule
