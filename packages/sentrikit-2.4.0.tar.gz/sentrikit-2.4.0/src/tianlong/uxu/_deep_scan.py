"""tianlong.uxu._deep_scan — 深度扫描辅助函数（Shell/Web密钥检测）"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List

# 内联 ScanFinding 避免循环导入
class _DeepScanFinding:
    def __init__(self, rule_id="", severity="", title="", file_path="",
                 line_number=0, matched_text="", suggestion="",
                 confidence="medium", exploitability="medium", impact="medium"):
        self.rule_id = rule_id
        self.severity = severity
        self.title = title
        self.file_path = file_path
        self.line_number = line_number
        self.matched_text = matched_text
        self.suggestion = suggestion
        self.confidence = confidence
        self.exploitability = exploitability
        self.impact = impact

    def to_dict(self):
        return {
            "rule_id": self.rule_id, "severity": self.severity,
            "title": self.title, "file_path": self.file_path,
            "line_number": self.line_number,
            "matched_text": self.matched_text,
            "suggestion": self.suggestion,
        }


def _deep_scan_shell(file_path: Path, lines: List[str], scanner_cls=None) -> List:
    """深度扫描Shell脚本的命令注入和危险操作。"""
    ScanFinding = scanner_cls or _DeepScanFinding
    findings = []
    dangerous_shell_patterns = [
        ("eval_exec", "eval($", "Shell eval执行动态代码"),
        ("curl_unsafe", "curl ", "curl请求未校验来源"),
        ("wget_download", "wget ", "wget下载未校验"),
        ("rm_rf", "rm -rf", "递归强制删除风险"),
        ("sudo_exec", "sudo ", "提权执行命令"),
        ("chmod_777", "chmod 777", "文件权限全开放"),
        ("inline_exec", "$(", "命令替换执行"),
        ("backtick_exec", "`", "反引号命令执行"),
        ("unsafe_var", "${", "未消毒变量引用"),
        ("ssh_key", "ssh-keygen", "SSH密钥生成操作"),
    ]
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        for pat_id, pat, title in dangerous_shell_patterns:
            if pat in stripped:
                findings.append(ScanFinding(
                    rule_id="UXU-SI-002",
                    severity="high" if pat_id in ("eval_exec", "rm_rf", "sudo_exec", "chmod_777") else "medium",
                    title=f"Shell危险操作: {title}",
                    file_path=str(file_path),
                    line_number=i,
                    matched_text=stripped[:80],
                    suggestion="避免在Shell脚本中使用eval/rm -rf/sudo等危险操作",
                ))
                break
    return findings


def _deep_scan_web_secrets(file_path: Path, lines: List[str], scanner_cls=None) -> List:
    """深度扫描Web文件中的硬编码密钥。"""
    ScanFinding = scanner_cls or _DeepScanFinding
    findings = []
    web_secret_patterns = [
        (r'(sk-[a-zA-Z0-9]{20,})', 'OpenAI API Key', 'critical'),
        (r'(pk-[a-zA-Z0-9]{20,})', 'OpenAI Project Key', 'critical'),
        (r'(ghp_[a-zA-Z0-9]{36})', 'GitHub Personal Access Token', 'critical'),
        (r'(gho_[a-zA-Z0-9]{36})', 'GitHub OAuth Token', 'high'),
        (r'(AKIA[0-9A-Z]{16})', 'AWS Access Key ID', 'critical'),
        (r'(-----BEGIN (RSA |EC )?PRIVATE KEY-----)', 'Private Key', 'critical'),
    ]
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.lstrip().startswith(("//", "#", "<!--", "/*")):
            continue
        for pattern, secret_type, sev in web_secret_patterns:
            m = re.search(pattern, stripped)
            if m:
                if "example" in stripped.lower() or "placeholder" in stripped.lower():
                    continue
                findings.append(ScanFinding(
                    rule_id="UXU-PM-001",
                    severity=sev,
                    title=f"Web文件硬编码密钥: {secret_type}",
                    file_path=str(file_path),
                    line_number=i,
                    matched_text=stripped[:60],
                    suggestion="密钥应放入环境变量或密钥管理服务，禁止硬编码",
                    confidence="high",
                    exploitability="easy",
                    impact="complete",
                ))
                break
    return findings
