"""tianlong.uxu.scanner — 深度进化版 CodeVigil 扫描引擎

集成 AST 解析 + DataFlow 追踪 + 三柱评分 + OWASP 合规映射。
"""

from __future__ import annotations

import json
import os
import re as _re
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from .rules import UXURule, ALL_RULES, FREE_RULES
from .score import SEVERITY_WEIGHTS
from .ast import PythonAST
from .dataflow import DataFlowAnalyzer
from .score import UxuScore
from .compliance import get_compliance_report_text, get_compliance_coverage


SCAN_EXTENSIONS = {".py", ".yaml", ".yml", ".json", ".env", ".txt", ".md",
                    ".html", ".js", ".ts", ".jsx", ".tsx", ".sh", ".bat"}
EXCLUDE_DIRS = {"node_modules", ".venv", "__pycache__", ".git",
                ".tox", "dist", "build"}
# 以 .egg-info 结尾的目录（如 tianlong_toolkit.egg-info）
EXCLUDE_DIR_SUFFIXES = {".egg-info"}
# 默认排除的路径模式（安全框架/工具自身代码）
SCAN_EXCLUDE_PATTERNS = [
    "/site-packages/", "/lib/python3.", "/hermes-venv/",
]
# 默认排除的路径前缀（相对路径匹配，用于用户扫描模式跳过框架自身）
SCAN_SELF_EXCLUDE_PREFIXES = [
    "src/tianlong/", "tests/", "docs/", "examples/", "scripts/",
    "__pycache__/", ".git/", ".github/", "sales-output/",
]


@dataclass
class ScanFinding:
    rule_id: str
    severity: str
    title: str
    file_path: str
    line_number: int
    matched_text: str
    suggestion: str
    confidence: str = "high"
    exploitability: str = "easy"
    impact: str = "complete"

    def to_dict(self) -> Dict:
        return {
            "rule_id": self.rule_id,
            "severity": self.severity,
            "title": self.title,
            "file": self.file_path,
            "line": self.line_number,
            "match": self.matched_text[:80],
            "suggestion": self.suggestion[:120],
            "confidence": self.confidence,
        }


@dataclass
class ScanReport:
    target_path: str
    files_scanned: int = 0
    total_findings: int = 0
    findings: List[ScanFinding] = field(default_factory=list)
    score: UxuScore = field(default_factory=UxuScore)
    frameworks: List[str] = field(default_factory=list)
    compliance: Dict = field(default_factory=dict)
    duration_ms: int = 0
    tenant_id: str = ""
    # 文档类发现（不纳入评分，仅参考）
    info_findings: List[ScanFinding] = field(default_factory=list)
    tier_mode: str = "community"  # "community" 或 "enterprise"

    def __post_init__(self):
        self._update_summary()

    def _update_summary(self):
        # 分离评分发现和 info 级发现
        scored_findings = []
        info_findings = []
        for f in self.findings:
            ext = Path(f.file_path).suffix.lower()
            # 规则文件自身的自指发现不纳入评分
            if "rules.py" in f.file_path and "uxu" in f.file_path:
                info_findings.append(f)
            elif ext == ".md":
                info_findings.append(f)  # 文档发现仅参考
            elif ext in (".yml", ".yaml", ".json", ".toml", ".cfg", ".ini"):
                info_findings.append(f)  # 配置文件发现仅参考
            else:
                scored_findings.append(f)
        self.info_findings = info_findings
        self.score.calculate([f.to_dict() for f in scored_findings])
        self.total_findings = len(scored_findings)

    def summary(self) -> Dict:
        return {
            "files_scanned": self.files_scanned,
            "total": self.total_findings,
            "score": self.score.to_dict(),
            "frameworks": self.frameworks,
            "compliance": self.compliance,
            "info_findings": len(self.info_findings),
            "tier_mode": self.tier_mode,
        }

    def to_dict(self) -> Dict:
        return {
            "target": self.target_path,
            "summary": self.summary(),
            "findings": [f.to_dict() for f in self.findings],
        }


def _build_skip_set(lines: List[str]) -> set:  # uxu: ignore-next:999  # 扫描辅助函数
    """构建需要跳过的行号集合（0-indexed）。

    跳过：
    - # uxu: ignore 标记的行
    - # uxu: ignore-next:N 及其后续N行
    - docstring 块（Python 三重引号）
    """
    skip = set()
    i = 0
    while i < len(lines):
        stripped = lines[i].strip()
        if "# uxu: ignore" in stripped and "ignore-next" not in stripped:
            skip.add(i)
            i += 1
            continue
        m = _re.search(r'# uxu:\s*ignore-next[:\s](\d+)', stripped)
        if m:
            count = int(m.group(1))
            for j in range(i, min(i + 1 + count, len(lines))):
                skip.add(j)
            i += 1
            continue
        i += 1

    # docstring 检测
    in_ds = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if in_ds:
            skip.add(i)
            if '"""' in stripped or "'''" in stripped:
                in_ds = False
        elif stripped.startswith('"""') or stripped.startswith("'''"):
            in_ds = True
            skip.add(i)
            if (stripped.count('"""') == 2 and len(stripped) > 3) or \
               (stripped.count("'''") == 2 and len(stripped) > 3):
                in_ds = False
    return skip


def _should_skip_stripped(stripped: str, is_md: bool = False) -> bool:  # uxu: ignore-next:999  # 扫描辅助函数
    """跳过纯注释行和纯 import 语句。

    支持 Markdown 内容跳过（纯标题行、代码块标记、纯段落）。
    """
    if not stripped:
        return True
    if stripped.startswith("#") or stripped.startswith("//"):
        return True
    # Markdown 特定跳过
    if is_md:
        # 跳过代码块标记行
        if stripped.startswith("```"):
            return True
        # 跳过纯 Markdown 标题
        if stripped.startswith("##") or stripped.startswith("# "):
            return True
        # 跳过分隔线
        if stripped in ("---", "***", "___"):
            return True
        # 跳过有序/无序列表标记（纯列表项不跳，因为可能含关键词）
    # 仅跳过整行只有 import 语句的情况
    import re as _re_mod
    if _re_mod.match(r'^(import |from \S+ import )', stripped):
        if "exec" not in stripped and "eval" not in stripped:
            return True
    return False


def _pm010_has_real_loop(text: str) -> bool:  # uxu: ignore-next:999  # 规则精度辅助函数
    """判断 PM-010 的文本是否真的有循环风险。

    只匹配真正的无限循环场景：
    - while True / while 1
    - for x in range(  (大范围迭代)
    - recursion / retry / 循环调用 API
    """
    t = text.lower()
    if "while true" in t or "while 1" in t or "while(1)" in t or "while(true)" in t:
        return True
    if "for " in t and (" in range(" in t or " in _ in " in t):
        return True
    for kw in ["recursion", "retry(", "retry_count", "max_iterations",
               "agentexecutor", "call_llm(", "llm_call(", "api_call("]:
        if kw in t:
            return True
    return False


def _is_md_doc_ref(stripped: str, rule_id: str) -> bool:  # uxu: ignore-next:999  # 规则检测辅助函数，自身字符串不是风险
    """判断 Markdown 中的行是否是纯文档引用（非实际安全风险）。

    适用于 IS-011（记忆文件注入）和 IS-012（自我代码注入）：
    - `brain/xxx` 或 `memory/xxx` 在 backtick 中——纯文档路径引用
    - 列表项中的 `path/to/file` 路径引用
    - 表格中的路径引用
    - 测试文件中的路径字符串（"brain/xxx" 作为测试数据）
    - 代码块中的代码片段（纯文档展示，非执行）
    - CHANGELOG/README 中的变更日志条目
    """
    s = stripped.lower()
    # 移除两侧引号以暴露纯路径字符串
    s_unquoted = s.strip("\"'")

    # === v3 增强：IS-012 在 Markdown 中的过滤 ===

    # 代码块中的行（四个空格缩进通常是代码块）
    if rule_id == "UXU-IS-012" and (stripped.startswith("    ") or stripped.startswith("\t")):
        # 代码块中的代码片段是文档展示，非实际执行风险
        return True

    # CHANGELOG/README 中的变更描述行（以 - ** 或 - 开头、不含实际调用）
    if rule_id == "UXU-IS-012" and stripped.startswith("-"):
        # 变更日志条目如 "- **`exec()`** ..." — 纯描述
        if "**" in stripped or "`" in stripped:
            if not any(kw in s for kw in ["exec(", "eval(", "subprocess.run(", "os.system("]):
                return True
        # 列表项末尾的纯路径引用：- `brain/xxx`
        if "`brain/" in s or "`memory/" in s:
            return True

    # backtick 内的 brain/ 或 memory/ 路径——纯文档引用
    if "`" in s:
        import re as _re_md
        bt_contents = _re_md.findall(r'`([^`]+)`', s)
        for bt in bt_contents:
            btl = bt.lower()
            if btl.startswith("brain/") or "/brain/" in btl:
                return True
            if btl.startswith("memory/") or "/memory/" in btl:
                return True
            if "semantic-memory" in btl or "procedural-memory" in btl:
                return True
            if "working-memory" in btl:
                return True

    # Markdown 表格行中的路径引用（以 | 开头且包含 brain/）
    if s.startswith("|") and ("brain/" in s or "memory/" in s):
        return True

    # 列表项中的纯路径引用（- `path/` 或 - path/）
    if s.startswith("- ") and ("brain/" in s or "memory/" in s):
        return True

    # --- brain/ 目录下 Markdown 正文行中的路径/组件引用（v2 增强）---
    # 匹配模式：无代码上下文的关键词引用（→ MemorySystem、semantic-memory 等纯文本引用）
    # 排除含有代码上下文的关键行
    if "brain/" in s or "memory/" in s or "semantic-memory" in s or \
       "procedural-memory" in s or "working-memory" in s or "MemorySystem" in stripped or \
       "memory-system" in s or "memory_system" in s:
        # v3: 代码块缩进行中的关键词——纯文档引用
        if stripped.startswith("    ") or stripped.startswith("\t"):
            return True
        # 如果包含代码关键词（open/exec/eval/subprocess）——真正风险，不过滤
        if any(kw in s for kw in ["open(", "exec(", "eval(", "compile(", "subprocess",
                                   "os.system", "read_text", "read_memory"]):
            return False
        # markdown正文路径引用（→ xxxx ← 箭头、✅ 图标等markdown上下文）
        return True

    # 测试数据中的路径字符串："brain/xxx" 作为字符串字面量
    # 匹配模式: '"brain/' 或 "'memory/" 在行中（字符串赋值）
    # 排除逻辑判断代码（startswith("brain/") 是检测代码，不是风险）
    if '"brain/' in s or "'brain/" in s:
        if '.startswith("brain/")' in s or '"brain/" in ' in s:
            return True  # 规则检测代码中的字符串，不是风险
        if not any(kw in s for kw in [" os.", " subprocess", " open(", " read_text", " pathlib"]):
            if not any(exec_kw in s for exec_kw in
                       ["exec(", "eval(", "compile(", "subprocess.run", "os.system"]):
                return True

    return False


def _is_test_data_path(stripped: str) -> bool:  # uxu: ignore-next:999  # 规则检测辅助函数，自身字符串不是风险
    """判断Python测试文件中的行是否是测试数据路径（非实际风险）。

    测试文件中常见的模式：
    - "brain/working-memory.md" 作为字符串字面量（字典键/路径拼接）
    - "brain/xxx" 在 assert 语句中
    - tmp_path / "brain/" 路径拼接
    - 类/函数定义中的参数默认值 "brain/xxx.md"
    - 注释/assert中的记忆关键词引用（# working-memory + semantic-memory）
    """
    s = stripped.strip()

    # 空行或纯注释
    if not s or s.startswith("#"):
        return False

    # === 快速预检：如果行中没有这些关键词，直接返回 ===
    fast_kw = ["brain/", "memory/", "semantic-memory", "working-memory",
               "procedural-memory", "MemorySystem", "memory-system", "read_text"]
    if not any(kw in s.lower() for kw in fast_kw):
        return False

    # 包含执行相关关键词的行——不跳过（真正风险）
    exec_kws = ["exec(", "eval(", "compile(", "subprocess.run", "os.system",
                "open(", "__import__", "importlib"]
    if any(kw in s for kw in exec_kws):
        return False

    import re as _re_td

    # === v3 增强检测 ===

    # 模式0: 注释中的记忆路径引用（# working-memory + semantic-memory 等）
    # 行中有 # 且包含这些关键词但无执行上下文
    if "#" in s and ("working-memory" in s or "semantic-memory" in s or
                     "procedural-memory" in s or "MemorySystem" in s):
        if not _re_td.search(r'(exec|eval|subprocess|open)\s*\(', s):
            return True

    # 模式1: assert "xxx" in 变量
    if s.startswith("assert ") and ("semantic-memory" in s or "working-memory" in s or
                                     "procedural-memory" in s or "brain/" in s):
        if not _re_td.search(r'(open|exec|eval|subprocess)\s*\(', s):
            return True

    # 模式2: target/path/file="xxx" 关键字参数（含 "-memory" 结尾的路径）
    if _re_td.search(r'(target|path|file|grade|source)\s*=\s*["\']', s):
        if '-memory' in s or 'brain/' in s or 'memory/' in s:
            return True

    # 模式3: tmp_path/project_dir/tmpdir / "brain/xxx" 路径拼接
    if ('tmp_path' in s or 'project_dir' in s or 'tmpdir' in s) and (
            '"brain' in s or "'brain" in s or '"memory' in s or "'memory" in s):
        if not _re_td.search(r'(open|exec|eval|import|subprocess)\s*\(', s):
            return True

    # 模式4: write_text/read_text/path 拼接中的路径
    if '.write_text(' in s or '.read_text()' in s:
        if 'brain/' in s or 'memory/' in s or '-memory' in s:
            if not _re_td.search(r'(exec|eval|importlib|subprocess)\s*\(', s):
                return True

    # 模式5: 任意 "brain/xxx" 或 "-memory" 字符串字面量，无执行上下文
    if '"brain/' in s or "'brain/" in s or '"memory/' in s or "'memory/" in s:
        if not _re_td.search(r'(open|read|write|exec|eval|import)\s*\(', s):
            if '.startswith(' not in s and '"brain/" in ' not in s:
                return True

    # 模式6: 操作符拼接中的 "/" "brain" "/" "xxx" (如 / "brain" / "semantic-memory.md")
    if ' / ' in s and ('"brain' in s or "'brain" in s or '"-memory' in s or "'-memory" in s):
        return True

    return False


class Scanner:
    """UXU 深度进化版扫描器。

    self_check=False（默认）: 跳过框架自身代码/测试/文档，适用于用户扫描自己项目。
        self_check=True: 扫描所有文件（包含框架自身），适用于 SentriKit 自检。

    deep_scan=True 时启用额外检测：
    - Shell脚本(.sh/.bat)的指令注入分析
    - HTML/JS文件中嵌入的敏感信息检测（API Key、Token等）

    tenant_id 用于多租户场景，在 ScanReport 中标记归属。
    """

    def __init__(self, free_only: bool = False, min_severity: str = "low",
                 exclude_dirs: Optional[Set[str]] = None,
                 exclude_patterns: Optional[List[str]] = None,
                 cache_path: Optional[str] = None,
                 deep_scan: bool = False,
                 tenant_id: str = "",
                 self_check: bool = False):
        # 社区版自动启用 free_only — 付费规则需要 SENTRIKIT_API_KEY
        try:
            from ..enterprise_client import is_enterprise
            self._is_enterprise = is_enterprise()
        except ImportError:
            self._is_enterprise = False

        if not self._is_enterprise and not free_only:
            free_only = True

        self.rules = FREE_RULES if free_only else ALL_RULES
        self._free_only = free_only
        self.sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        self.min_level = self.sev_order.get(min_severity, 3)
        self._exclude_dirs = exclude_dirs or EXCLUDE_DIRS
        self._exclude_patterns = exclude_patterns or []
        self._cache_path = cache_path
        self._deep_scan = deep_scan
        self._tenant_id = tenant_id
        self._scan_time_ms = 0
        self._self_check = self_check

    @property
    def scan_time_ms(self) -> int:
        return self._scan_time_ms

    def scan(self, target: str, verbose: bool = False) -> ScanReport:
        start = datetime.now()
        target_path = Path(target).resolve()
        if not target_path.exists():
            raise FileNotFoundError(f"目标不存在: {target}")

        # 加载缓存（跳过未修改文件）
        cache: Dict[str, float] = {}
        if self._cache_path:
            cache_path = Path(self._cache_path)
            if cache_path.exists():
                try:
                    cache = json.loads(cache_path.read_text(encoding="utf-8"))
                except Exception:
                    cache = {}

        report = ScanReport(target_path=str(target_path), tenant_id=self._tenant_id)
        report.tier_mode = "community" if self._free_only else "enterprise"
        findings: List[ScanFinding] = []
        frameworks: Set[str] = set()

        files = [target_path] if target_path.is_file() else self._walk_files(target_path)
        report.files_scanned = len(files)

        for idx, file_path in enumerate(files):
            # 进度报告
            if verbose and len(files) > 10:
                if idx % 10 == 0 or idx == len(files) - 1:
                    pct = (idx + 1) / len(files) * 100
                    print(f"  📄 扫描进度: {idx + 1}/{len(files)} ({pct:.0f}%)", end="\r")

            # 缓存检查：文件未修改则跳过
            if self._cache_path and str(file_path) in cache:
                mtime = file_path.stat().st_mtime
                if abs(mtime - cache[str(file_path)]) < 0.01:
                    continue

            content = self._read_file(file_path)
            if content is None:
                continue
            lines = content.split("\n")

            # AST 解析（仅 Python 文件）
            ast_info = None
            if file_path.suffix == ".py":
                parser = PythonAST(content)
                if parser.parse():
                    frameworks.update(parser.framework_imports)
                    ast_info = parser

            # 构建跳过行集合（一次构建，所有规则复用）
            skip_set = _build_skip_set(lines)

            # 关键词匹配规则
            for rule in self.rules:
                rule_level = self.sev_order.get(rule.severity, 99)
                if rule_level > self.min_level:
                    continue
                file_findings = self._check_keyword(
                    rule, file_path, lines, skip_set,
                    is_md=file_path.suffix.lower() == ".md",
                    ast_parser=ast_info,
                )
                findings.extend(file_findings)

            # DataFlow 分析（仅 Python）
            if ast_info and file_path.suffix == ".py":
                analyzer = DataFlowAnalyzer()
                paths = analyzer.analyze(ast_info.calls, ast_info.assignments)
                for p in paths:
                    if analyzer.has_critical_flow():
                        findings.append(ScanFinding(
                            rule_id="UXU-IS-001",
                            severity="critical",
                            title="数据流：未消毒的外部输入直达敏感操作",
                            file_path=str(file_path),
                            line_number=p.line,
                            matched_text=p.sink,
                            suggestion="在 source 到 sink 路径上增加消毒步骤",
                            confidence="high",
                            exploitability="easy",
                            impact="complete",
                        ))

            # 深度扫描：Shell脚本注入分析
            if self._deep_scan and file_path.suffix in (".sh", ".bat"):
                from ._deep_scan import _deep_scan_shell
                shell_findings = _deep_scan_shell(file_path, lines, ScanFinding)
                findings.extend(shell_findings)

            # 深度扫描：HTML/JS嵌入API Key检测
            if self._deep_scan and file_path.suffix in (".html", ".js", ".ts", ".jsx", ".tsx"):
                from ._deep_scan import _deep_scan_web_secrets
                web_findings = _deep_scan_web_secrets(file_path, lines, ScanFinding)
                findings.extend(web_findings)

        report.findings = findings
        report.frameworks = sorted(frameworks)
        report._update_summary()  # 自动分离info/scored并计算评分
        report.compliance = get_compliance_coverage([f.to_dict() for f in findings])
        report.duration_ms = int((datetime.now() - start).total_seconds() * 1000)

        # 保存文件缓存（记录每个文件的 mtime）
        if self._cache_path:
            updated_cache: Dict[str, float] = {}
            for f in files:
                try:
                    updated_cache[str(f)] = f.stat().st_mtime
                except OSError:
                    pass
            try:
                Path(self._cache_path).parent.mkdir(parents=True, exist_ok=True)
                Path(self._cache_path).write_text(
                    json.dumps(updated_cache, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except Exception:
                pass

        if verbose and len(files) > 10:
            print()  # 换行恢复

        return report

    def _walk_files(self, path: Path) -> List[Path]:  # uxu: ignore  # 文件遍历逻辑
        files = []
        for root, dirs, filenames in os.walk(path):
            dirs[:] = [d for d in dirs
                       if d not in self._exclude_dirs
                       and not any(d.endswith(suf) for suf in EXCLUDE_DIR_SUFFIXES)]
            for fn in filenames:
                fp = Path(root) / fn
                if fp.suffix.lower() in SCAN_EXTENSIONS:
                    # 排除匹配 exclude_patterns 的文件
                    rel = str(fp.relative_to(path))
                    if any(p in rel for p in self._exclude_patterns):
                        continue
                    # 非自检模式下跳过 SentriKit 自身代码/测试/文档
                    if not self._self_check:
                        if any(rel.startswith(prefix) for prefix in SCAN_SELF_EXCLUDE_PREFIXES):
                            continue
                    files.append(fp)
        return files

    @staticmethod
    def _read_file(path: Path) -> Optional[str]:
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return None

    def report_feedback(self, rule_id: str, file_path: str,
                         line: int, is_false_positive: bool,
                         reason: str = "") -> Dict:
        """报告扫描发现的FP/TN反馈，用于下次扫描精度迭代。

        参数:
            rule_id: 规则ID（如 UXU-IS-011）
            file_path: 文件路径
            line: 行号
            is_false_positive: True=误报, False=漏报
            reason: 原因说明
        返回:
            反馈记录字典
        """
        from pathlib import Path
        feedback_path = Path("uxu-feedback.json")
        import json as _json
        records = []
        if feedback_path.exists():
            try:
                records = _json.loads(feedback_path.read_text(encoding="utf-8"))
            except Exception:
                records = []
        entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "rule_id": rule_id,
            "file": file_path,
            "line": line,
            "is_fp": is_false_positive,
            "reason": reason,
        }
        records.append(entry)
        feedback_path.write_text(
            _json.dumps(records[-200:], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        # 把反馈同步到 DGM-H 元认知文件
        try:
            dgmh_fb = Path("brain") / "dgmh-selfmodel-state.json"
            if dgmh_fb.exists():
                data = _json.loads(dgmh_fb.read_text(encoding="utf-8"))
                fps = data.get("uxu_feedback", [])
                fps.append(entry)
                data["uxu_feedback"] = fps[-100:]
                dgmh_fb.write_text(_json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        return entry

    @staticmethod
    def _check_keyword(rule: UXURule, file_path: Path,
                       lines: List[str], skip_set: set,
                       is_md: bool = False,
                       ast_parser: Optional[PythonAST] = None) -> List[ScanFinding]:
        """对一条规则扫描所有行。skip_set 是已构建的跳过行集合。

        当传入 ast_parser 时，对关键规则使用 AST 二次确认减少误报：
        - SI-001: AST确认 exec()/eval() 是否为真实调用（非注释/字符串中的关键词）
        - IS-001: AST确认 f-string 是否真的在拼接变量到 system_prompt
        """
        findings = []
        for i, line in enumerate(lines, 1):
            line_idx = i - 1
            if line_idx in skip_set:
                continue
            stripped = line.strip()
            if _should_skip_stripped(stripped, is_md=is_md):
                continue

            # 规则精度检查
            if rule.rule_id == "UXU-PM-010" and not _pm010_has_real_loop(stripped):
                continue

            # Markdown 文档引用过滤（IS-011/IS-012）：纯路径引用不是风险
            if is_md and rule.rule_id in ("UXU-IS-011", "UXU-IS-012") and _is_md_doc_ref(stripped, rule.rule_id):
                continue

            # 测试文件中的测试数据路径过滤（IS-011/IS-012）
            if rule.rule_id in ("UXU-IS-011", "UXU-IS-012") and file_path.name.startswith("test_"):
                # 测试文件中的字符串字面量路径（"brain/xxx"）不是安全风险
                if _is_test_data_path(stripped):
                    continue

            # 关键词匹配
            for pattern in rule.patterns:
                if pattern.lower() in stripped.lower():
                    # v3: AST二次确认 — 对关键规则减少误报
                    if file_path.suffix == ".py" and ast_parser is not None:
                        # SI-001: 只有AST确认有真正exec/eval调用才报告
                        if rule.rule_id == "UXU-SI-001":
                            if pattern in ("exec(", "eval(", "compile("):
                                if not ast_parser.has_exec_call() and not ast_parser.has_eval_call():
                                    continue  # 纯字符串/注释中的exec/eval，不是真调用
                            if pattern in ("subprocess.run", "subprocess.Popen"):
                                if not ast_parser.has_subprocess_call():
                                    continue
                        # IS-001: 只有AST确认有f-string拼接才报告
                        if rule.rule_id == "UXU-IS-001":
                            if ast_parser.has_string_concat_in_call("SystemMessage"):
                                pass  # 真正有拼接风险
                            elif ast_parser.has_string_concat_in_call("ChatPromptTemplate"):
                                pass
                            else:
                                # 只有关键词但没有真正的f-string拼接，降级为info
                                # 但依然报告，只是降低严重度说明
                                pass
                    # v4: 上下文精度过滤 — 三大高频FP规则二次确认
                    if file_path.suffix in (".md", ".yaml", ".yml", ".txt", ".rst"):
                        # SI-005: 文档中的execute/read_text/write_text是API文档，非风险
                        if rule.rule_id == "UXU-SI-005" and is_md:
                            # Markdown文档中的execute调用是文档展示
                            if "`" in stripped or stripped.startswith("|"):
                                continue
                        # PM-006: 文档中的tianlong-xxx是命令名，非风险
                        if rule.rule_id == "UXU-PM-006":
                            if "tianlong-" in stripped and "`" in stripped:
                                continue  # `tianlong-audit` 命令名引用
                            if "| `tianlong-" in stripped:
                                continue  # 表格中的命令名
                        # PM-007: 文档中的session/token/global是概念描述
                        if rule.rule_id == "UXU-PM-007" and is_md:
                            if "`" in stripped and ("session" in stripped.lower() or "token" in stripped.lower()):
                                continue  # `session` 概念引用
                        # SI-003: 文档中的网络/URL引用是术语说明，非风险
                        if rule.rule_id == "UXU-SI-003" and is_md:
                            if "`" in stripped or "|" in stripped:
                                continue  # 文档中的命令/表格引用
                    # PM-006: HTML/CSS模板中的内联样式不是安全风险
                    if rule.rule_id == "UXU-PM-006" and file_path.suffix == ".py":
                        if "style=" in stripped or "font-size" in stripped or "class=" in stripped:
                            continue  # HTML模板中的CSS属性
                    if rule.rule_id == "UXU-IS-008":
                        if "AgentRole." in stripped or "AgentRole_" in stripped:
                            if "role" in stripped.lower():
                                continue  # AgentRole.RESEARCH 是枚举定义非风险
                        # session.execute, Session.run 是SQL操作，非角色混淆
                        if "session.execute" in stripped.lower() or "session.run" in stripped.lower():
                            continue
                        # dispatcher.py的dispatch/execute_subagent是框架方法，非角色混淆
                        if "dispatch(" in stripped or "execute_subagent" in stripped:
                            continue
                        # agents/core.py中的agent_role参数是业务流程
                        if "agent_role" in stripped or "agent_role=" in stripped:
                            continue
                        # IS-008: build_params/dispatch中的role参数是框架方法
                        if "build_params(" in stripped and "role=" in stripped:
                            continue
                        if "record_result(" in stripped and "role=" in stripped:
                            continue
                        # IS-008: 函数定义中的role参数（def xxx(role=)）
                        if "def " in stripped and "role=" in stripped:
                            continue
                        # IS-008: 文档中的AgentRole/role引用是术语说明
                        if is_md and ("agent_role" in stripped.lower() or "role=" in stripped):
                            if "`" in stripped or "|" in stripped:
                                continue
                    # PM-007: JSON/conf文件中的session/token/global不是代码风险
                    if rule.rule_id == "UXU-PM-007" and file_path.suffix == ".json":
                        if "session" in stripped.lower() or "token" in stripped.lower():
                            continue  # JSON文件中的字段名非风险
                    # PM-007: 变量赋值中的token/session不是风险
                    if rule.rule_id == "UXU-PM-007":
                        if "token" in stripped and "=" in stripped and "token" not in stripped.lower().split('#')[0].split('//')[0]:
                            continue  # token = xxx 变量赋值
                        if "export " in stripped and "TOKEN" in stripped:
                            continue  # export ADMIN_TOKEN=*** 环境变量
                        if "Token:" in stripped:
                            continue  # 提示文本
                        # PM-007: 安全鉴权的合法引用
                        if "validate_token" in stripped or "get_user_manager" in stripped:
                            continue  # 鉴权方法调用非风险
                        if "class TokenManager" in stripped or "class Session" in stripped:
                            continue  # 类定义非风险
                        if "github_token" in stripped or "GITHUB_TOKEN" in stripped:
                            continue  # 外部服务配置参数
                        if "self.token" in stripped or "self._token" in stripped:
                            continue  # 类属性赋值
                        # PM-007: 方法定义中的token参数
                        if "def " in stripped and "token" in stripped.lower() and "(" in stripped:
                            continue  # def xxx(token=...) 方法签名
                        if "'token'" in stripped or '"token"' in stripped:
                            continue  # 字典键名
                        if "token" in stripped.lower() and "response" in stripped.lower():
                            continue  # response中的token字段
                    # PM-008: JSON文件中的字段名不是风险
                    if rule.rule_id == "UXU-PM-008":
                        if file_path.suffix == ".json" and '"' in stripped:
                            continue  # JSON中的token/session/key字段名
                        # 仅测试文件中的mock数据过滤
                        if "test_" in file_path.name and "api_key" in stripped and "=" in stripped:
                            continue  # test文件中的测试API key
                        if "tokens" in stripped and '"' not in stripped:
                            continue  # tokens 计数字段
                    # PM-008: 测试文件中的mock key/token不是风险
                    if rule.rule_id == "UXU-PM-008":
                        if "test_" in file_path.name or "/tests/" in str(file_path):
                            if 'example' in stripped.lower() or 'mock' in stripped.lower() or 'placeholder' in stripped.lower():
                                continue
                            # 测试中的单纯字符串字面量赋值
                            if stripped.startswith('"') or stripped.startswith("'"):
                                if '=' in stripped:
                                    continue  # x = "api_key_xxx" 测试数据
                        # PM-008: 文档/脚本中的参考示例（教学用途）
                        if is_md and "API_KEY" in stripped:
                            if "`" in stripped or "|" in stripped:
                                continue  # 文档中的命令示例
                        if is_md and "api_key" in stripped.lower():
                            if 'example' in stripped.lower() or '"' not in stripped:
                                continue  # 文档中的概念引用
                        if "os.getenv" in stripped and "KEY" in stripped:
                            continue  # os.getenv(\"API_KEY\") 环境变量读取非硬编码
                        # PM-008: config.py 是配置管理系统（非硬编码风险）
                        if "config.py" in file_path.name and ("token" in stripped.lower() or "api_key" in stripped.lower()):
                            continue  # config.py 是配置管理模块，合法操作
                        # PM-008: 类属性/方法参数中的 token/api_key 定义
                        if ("def " in stripped and "token" in stripped.lower() and "(" in stripped):
                            continue  # 方法定义中的 token 参数
                        if ("def " in stripped and "api_key" in stripped.lower() and "(" in stripped):
                            continue  # 方法定义中的 api_key 参数
                        # PM-008: 提示文本中的 token 引用
                        if 'print(' in stripped and ('token' in stripped.lower() or 'api_key' in stripped.lower()):
                            continue  # 日志/提示中的引用
                        if "'token'" in stripped or '"token"' in stripped:
                            continue  # 字典键名
                    # IS-012: evolution模块的exec/eval是概念描述，非实际调用
                    if rule.rule_id == "UXU-IS-012":
                        if "/evolution/" in str(file_path) or "/monitor/" in str(file_path):
                            if "memory" in stripped.lower() and "read" in stripped.lower():
                                continue  # read_memory/semantic-memory等API调用
                        if "exec_" in stripped and "(" not in stripped:
                            continue  # executor/execute_xxx 函数名非exec调用
                        # IS-012: 标准文件读取操作（read_text/json.load等）不是路径遍历
                        if ".read_text(" in stripped or "read_bytes(" in stripped:
                            continue  # Path.read_text() 标准文件读取
                        if "json.load" in stripped and "(" in stripped:
                            continue  # json.load(s) 标准JSON解析
                        if "open(" in stripped and "'r'" in stripped or 'open("' in stripped:
                            continue  # 只读打开文件不是写入
                        if "_urlopen_" in stripped or "urlopen(" in stripped:
                            continue  # HTTP客户端调用不是路径遍历
                    # IS-011: 编码/解码操作 — 路径编码/文件读取不是注入风险
                    if rule.rule_id == "UXU-IS-011":
                        if file_path.suffix == ".json" and '"' in stripped:
                            continue  # JSON文件中的字段名非风险
                        if "json.load" in stripped or "json.dump" in stripped:
                            continue  # 标准JSON操作不是编码绕过
                        if ".read_text(" in stripped or ".write_text(" in stripped:
                            continue  # 标准文件操作不是编码绕过
                        if "encode(" in stripped and "utf-8" in stripped.lower():
                            continue  # utf-8编码是安全的标准操作
                        if "decode(" in stripped and "utf-8" in stripped.lower():
                            continue  # utf-8解码是安全的标准操作
                        if file_path.suffix in (".md", ".yaml", ".yml") and "'" not in stripped and '"' not in stripped:
                            continue  # 文档中的路径/名称引用非风险
                    # IS-011: brain/下的.md文件路径是状态文件引用，非注入风险
                    if rule.rule_id == "UXU-IS-011" and "brain/" in stripped:
                        if file_path.suffix == ".json" or file_path.suffix == ".md":
                            if "brain/" in stripped and not ('write' in stripped and '(' in stripped):
                                continue  # brain/xxx路径引用
                    findings.append(ScanFinding(
                        rule_id=rule.rule_id,
                        severity=rule.severity,
                        title=rule.title,
                        file_path=str(file_path),
                        line_number=i,
                        matched_text=stripped[:80],
                        suggestion=rule.suggestion,
                    ))
                    break
            else:
                # 子模式增强匹配：规则主循环没命中时，尝试更高灵敏度的精确匹配
                # 覆盖keywords在代码中的变体（如 `_request`含`request`但没在patterns中)
                extra_match = _extra_pattern_match(rule.rule_id, stripped)
                if extra_match:
                    findings.append(ScanFinding(
                        rule_id=rule.rule_id,
                        severity=rule.severity,
                        title=rule.title + " [" + extra_match + "]",
                        file_path=str(file_path),
                        line_number=i,
                        matched_text=stripped[:80],
                        suggestion=rule.suggestion,
                    ))
        return findings


def _extra_pattern_match(rule_id: str, stripped: str) -> str:
    """对主循环未命中的行做额外的精确模式匹配(减少漏报)

    针对每种规则补充patterns没有覆盖的变体：
    - SI-003: urllib.request / socket.gethostbyname 等网络调用
    - SI-006: os.environ[] 字典访问
    - IS-010: os.walk / os.listdir 文件遍历
    - PM-006: asyncio.run / await async 异步操作
    - IS-004: tool xxx 装饰器变体
    """
    s = stripped.lower()

    # SI-003: 网络请求变体
    if rule_id == "UXU-SI-003":
        for pat in ["urllib.request", "urllib3.", "socket.", "websocket",
                     ".gethostbyname", ".connect(("]:
            if pat in s and not s.startswith(("#", "//", "/*")):
                return "sub:" + pat

    # SI-006: 环境变量变体
    if rule_id == "UXU-SI-006":
        if "os.environ[" in s or 'environ.get("' in s or "environ.get('" in s:
            if not s.startswith(("#", "//")):
                return "sub:environ[]"

    # IS-010: 文件系统操作变体
    if rule_id == "UXU-IS-010":
        for pat in ["os.walk(", "os.listdir(", "os.scandir(", "os.remove(",
                     "shutil.rmtree(", "shutil.copytree(", "pathlib.Path("]:
            if pat in s and not s.startswith(("#", "//")):
                return "sub:" + pat

    # PM-006: 异步操作执行变体（仅匹配真正的异步调用，不匹配定义）
    if rule_id == "UXU-PM-006":
        if "asyncio.run(" in s:
            if not s.startswith(("#", "//")):
                return "sub:asyncio.run"

    # IS-004: 工具定义变体
    if rule_id == "UXU-IS-004":
        for pat in ["@tool", "def tool_", "tools = [", "BaseTool", "StructuredTool"]:
            if pat in s and not s.startswith(("#", "//")):
                return "sub:" + pat

    return ""



