"""tianlong.uxu.scanner — UXU 核心扫描器"""
from __future__ import annotations

from ._helpers import (
    ScanFinding, ScanReport, _build_skip_set,
    _should_skip_stripped, _pm010_has_real_loop,
    _is_md_doc_ref, _is_test_data_path,
    _extra_pattern_match,
)
from ._deep_scan import _deep_scan_shell, _deep_scan_web_secrets
from .rules import ALL_RULES, FREE_RULES, get_rule
from .score import SEVERITY_WEIGHTS
from .ast import PythonAST
from .dataflow import DataFlowAnalyzer
from .compliance import get_compliance_coverage
class Scanner:
    """UXU 深度进化版扫描器。

    deep_scan=True 时启用额外检测：
    - Shell脚本(.sh/.bat)的指令注入分析
    - HTML/JS文件中嵌入的敏感信息检测（API Key、Token等）

    tenant_id 用于多租户场景，在 ScanReport 中标记归属。
    """

    def __init__(self, free_only: bool = False, min_severity: str = "low",
                 exclude_dirs: Optional[Set[str]] = None,
                 exclude_patterns: Optional[List[str]] = None,
                 cache_path: Optional[str] = None,
                 deep_scan: bool = False,
                 tenant_id: str = ""):
        self.rules = FREE_RULES if free_only else ALL_RULES
        self.sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        self.min_level = self.sev_order.get(min_severity, 3)
        self._exclude_dirs = exclude_dirs or EXCLUDE_DIRS
        self._exclude_patterns = exclude_patterns or []
        self._cache_path = cache_path
        self._deep_scan = deep_scan
        self._tenant_id = tenant_id
        self._scan_time_ms = 0

    @property
    def scan_time_ms(self) -> int:
        return self._scan_time_ms

    def scan(self, target: str, verbose: bool = False) -> ScanReport:
        start = datetime.now()
        target_path = Path(target).resolve()
        if not target_path.exists():
            raise FileNotFoundError(f"目标不存在: {target}")

        # 加载缓存（跳过未修改文件）
        cache: Dict[str, float] = {}
        if self._cache_path:
            cache_path = Path(self._cache_path)
            if cache_path.exists():
                try:
                    cache = json.loads(cache_path.read_text(encoding="utf-8"))
                except Exception:
                    cache = {}

        report = ScanReport(target_path=str(target_path), tenant_id=self._tenant_id)
        findings: List[ScanFinding] = []
        frameworks: Set[str] = set()

        files = [target_path] if target_path.is_file() else self._walk_files(target_path)
        report.files_scanned = len(files)

        for idx, file_path in enumerate(files):
            # 进度报告
            if verbose and len(files) > 10:
                if idx % 10 == 0 or idx == len(files) - 1:
                    pct = (idx + 1) / len(files) * 100
                    print(f"  📄 扫描进度: {idx + 1}/{len(files)} ({pct:.0f}%)", end="\r")

            # 缓存检查：文件未修改则跳过
            if self._cache_path and str(file_path) in cache:
                mtime = file_path.stat().st_mtime
                if abs(mtime - cache[str(file_path)]) < 0.01:
                    continue

            content = self._read_file(file_path)
            if content is None:
                continue
            lines = content.split("\n")

            # AST 解析（仅 Python 文件）
            ast_info = None
            if file_path.suffix == ".py":
                parser = PythonAST(content)
                if parser.parse():
                    frameworks.update(parser.framework_imports)
                    ast_info = parser

            # 构建跳过行集合（一次构建，所有规则复用）
            skip_set = _build_skip_set(lines)

            # 关键词匹配规则
            for rule in self.rules:
                rule_level = self.sev_order.get(rule.severity, 99)
                if rule_level > self.min_level:
                    continue
                file_findings = self._check_keyword(
                    rule, file_path, lines, skip_set,
                    is_md=file_path.suffix.lower() == ".md",
                    ast_parser=ast_info,
                )
                findings.extend(file_findings)

            # DataFlow 分析（仅 Python）
            if ast_info and file_path.suffix == ".py":
                analyzer = DataFlowAnalyzer()
                paths = analyzer.analyze(ast_info.calls, ast_info.assignments)
                for p in paths:
                    if analyzer.has_critical_flow():
                        findings.append(ScanFinding(
                            rule_id="UXU-IS-001",
                            severity="critical",
                            title="数据流：未消毒的外部输入直达敏感操作",
                            file_path=str(file_path),
                            line_number=p.line,
                            matched_text=p.sink,
                            suggestion="在 source 到 sink 路径上增加消毒步骤",
                            confidence="high",
                            exploitability="easy",
                            impact="complete",
                        ))

            # 深度扫描：Shell脚本注入分析
            if self._deep_scan and file_path.suffix in (".sh", ".bat"):
                shell_findings = _deep_scan_shell(file_path, lines)
                findings.extend(shell_findings)

            # 深度扫描：HTML/JS嵌入API Key检测
            if self._deep_scan and file_path.suffix in (".html", ".js", ".ts", ".jsx", ".tsx"):
                web_findings = _deep_scan_web_secrets(file_path, lines)
                findings.extend(web_findings)

        report.findings = findings
        report.total_findings = len(findings)
        report.frameworks = sorted(frameworks)
        report.score.calculate([f.to_dict() for f in findings])
        report.compliance = get_compliance_coverage([f.to_dict() for f in findings])
        report.duration_ms = int((datetime.now() - start).total_seconds() * 1000)

        # 保存文件缓存（记录每个文件的 mtime）
        if self._cache_path:
            updated_cache: Dict[str, float] = {}
            for f in files:
                try:
                    updated_cache[str(f)] = f.stat().st_mtime
                except OSError:
                    pass
            try:
                Path(self._cache_path).parent.mkdir(parents=True, exist_ok=True)
                Path(self._cache_path).write_text(
                    json.dumps(updated_cache, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except Exception:
                pass

        if verbose and len(files) > 10:
            print()  # 换行恢复

        return report

    def _walk_files(self, path: Path) -> List[Path]:  # uxu: ignore  # 文件遍历逻辑
        files = []
        for root, dirs, filenames in os.walk(path):
            dirs[:] = [d for d in dirs
                       if d not in self._exclude_dirs
                       and not any(d.endswith(suf) for suf in EXCLUDE_DIR_SUFFIXES)]
            for fn in filenames:
                fp = Path(root) / fn
                if fp.suffix.lower() in SCAN_EXTENSIONS:
                    # 排除匹配 exclude_patterns 的文件
                    rel = str(fp.relative_to(path))
                    if any(p in rel for p in self._exclude_patterns):
                        continue
                    files.append(fp)
        return files

    @staticmethod
    def _read_file(path: Path) -> Optional[str]:
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return None

    def report_feedback(self, rule_id: str, file_path: str,
                         line: int, is_false_positive: bool,
                         reason: str = "") -> Dict:
        """报告扫描发现的FP/TN反馈，用于下次扫描精度迭代。

        参数:
            rule_id: 规则ID（如 UXU-IS-011）
            file_path: 文件路径
            line: 行号
            is_false_positive: True=误报, False=漏报
            reason: 原因说明
        返回:
            反馈记录字典
        """
        from pathlib import Path
        feedback_path = Path("uxu-feedback.json")
        import json as _json
        records = []
        if feedback_path.exists():
            try:
                records = _json.loads(feedback_path.read_text(encoding="utf-8"))
            except Exception:
                records = []
        entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "rule_id": rule_id,
            "file": file_path,
            "line": line,
            "is_fp": is_false_positive,
            "reason": reason,
        }
        records.append(entry)
        feedback_path.write_text(
            _json.dumps(records[-200:], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        # 把反馈同步到 DGM-H 元认知文件
        try:
            dgmh_fb = Path("brain") / "dgmh-selfmodel-state.json"
            if dgmh_fb.exists():
                data = _json.loads(dgmh_fb.read_text(encoding="utf-8"))
                fps = data.get("uxu_feedback", [])
                fps.append(entry)
                data["uxu_feedback"] = fps[-100:]
                dgmh_fb.write_text(_json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        return entry

    @staticmethod
    def _check_keyword(rule: UXURule, file_path: Path,
                       lines: List[str], skip_set: set,
                       is_md: bool = False,
                       ast_parser: Optional[PythonAST] = None) -> List[ScanFinding]:
        """对一条规则扫描所有行。skip_set 是已构建的跳过行集合。

        当传入 ast_parser 时，对关键规则使用 AST 二次确认减少误报：
        - SI-001: AST确认 exec()/eval() 是否为真实调用（非注释/字符串中的关键词）
        - IS-001: AST确认 f-string 是否真的在拼接变量到 system_prompt
        """
        findings = []
        for i, line in enumerate(lines, 1):
            line_idx = i - 1
            if line_idx in skip_set:
                continue
            stripped = line.strip()
            if _should_skip_stripped(stripped, is_md=is_md):
                continue

            # 规则精度检查
            if rule.rule_id == "UXU-PM-010" and not _pm010_has_real_loop(stripped):
                continue

            # Markdown 文档引用过滤（IS-011/IS-012）：纯路径引用不是风险
            if is_md and rule.rule_id in ("UXU-IS-011", "UXU-IS-012") and _is_md_doc_ref(stripped, rule.rule_id):
                continue

            # 测试文件中的测试数据路径过滤（IS-011/IS-012）
            if rule.rule_id in ("UXU-IS-011", "UXU-IS-012") and file_path.name.startswith("test_"):
                # 测试文件中的字符串字面量路径（"brain/xxx"）不是安全风险
                if _is_test_data_path(stripped):
                    continue

            # 关键词匹配
            for pattern in rule.patterns:
                if pattern.lower() in stripped.lower():
                    # v3: AST二次确认 — 对关键规则减少误报
                    if file_path.suffix == ".py" and ast_parser is not None:
                        # SI-001: 只有AST确认有真正exec/eval调用才报告
                        if rule.rule_id == "UXU-SI-001":
                            if pattern in ("exec(", "eval(", "compile("):
                                if not ast_parser.has_exec_call() and not ast_parser.has_eval_call():
                                    continue  # 纯字符串/注释中的exec/eval，不是真调用
                            if pattern in ("subprocess.run", "subprocess.Popen"):
                                if not ast_parser.has_subprocess_call():
                                    continue
                        # IS-001: 只有AST确认有f-string拼接才报告
                        if rule.rule_id == "UXU-IS-001":
                            if ast_parser.has_string_concat_in_call("SystemMessage"):
                                pass  # 真正有拼接风险
                            elif ast_parser.has_string_concat_in_call("ChatPromptTemplate"):
                                pass
                            else:
                                # 只有关键词但没有真正的f-string拼接，降级为info
                                # 但依然报告，只是降低严重度说明
                                pass
                    # v4: 上下文精度过滤 — 三大高频FP规则二次确认
                    if file_path.suffix in (".md", ".yaml", ".yml", ".txt", ".rst"):
                        # SI-005: 文档中的execute/read_text/write_text是API文档，非风险
                        if rule.rule_id == "UXU-SI-005" and is_md:
                            # Markdown文档中的execute调用是文档展示
                            if "`" in stripped or stripped.startswith("|"):
                                continue
                        # PM-006: 文档中的tianlong-xxx是命令名，非风险
                        if rule.rule_id == "UXU-PM-006":
                            if "tianlong-" in stripped and "`" in stripped:
                                continue  # `tianlong-audit` 命令名引用
                            if "| `tianlong-" in stripped:
                                continue  # 表格中的命令名
                        # PM-007: 文档中的session/token/global是概念描述
                        if rule.rule_id == "UXU-PM-007" and is_md:
                            if "`" in stripped and ("session" in stripped.lower() or "token" in stripped.lower()):
                                continue  # `session` 概念引用
                    # IS-008: AgentRole枚举成员不是角色混淆
                    if rule.rule_id == "UXU-IS-008":
                        if "AgentRole." in stripped or "AgentRole_" in stripped:
                            if "role" in stripped.lower():
                                continue  # AgentRole.RESEARCH 是枚举定义非风险
                        # session.execute, Session.run 是SQL操作，非角色混淆
                        if "session.execute" in stripped.lower() or "session.run" in stripped.lower():
                            continue
                    findings.append(ScanFinding(
                        rule_id=rule.rule_id,
                        severity=rule.severity,
                        title=rule.title,
                        file_path=str(file_path),
                        line_number=i,
                        matched_text=stripped[:80],
                        suggestion=rule.suggestion,
                    ))
                    break
            else:
                # 子模式增强匹配：规则主循环没命中时，尝试更高灵敏度的精确匹配
                # 覆盖keywords在代码中的变体（如 `_request`含`request`但没在patterns中)
                extra_match = _extra_pattern_match(rule.rule_id, stripped)
                if extra_match:
                    findings.append(ScanFinding(
                        rule_id=rule.rule_id,
                        severity=rule.severity,
                        title=rule.title + " [" + extra_match + "]",
                        file_path=str(file_path),
                        line_number=i,
                        matched_text=stripped[:80],
                        suggestion=rule.suggestion,
                    ))
        return findings


