# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit

"""tianlong.selfcheck — SentriKit 自检工具

一键验证安装完整性、模块加载、版本一致性。

用法:
    sentrikit-selfcheck                  # 完整自检
    sentrikit-selfcheck --quick          # 快速自查（只检查关键模块）
    sentrikit-selfcheck --json           # JSON 输出
    sentrikit-selfcheck --perf           # 查看性能指标
    sentrikit-selfcheck --cache          # 查看缓存统计
"""

from __future__ import annotations

import argparse
import sys
import json
from datetime import datetime
from typing import Any


EXPECTED_MODULES = [
    "monitor", "safety", "judge", "evolution", "reporter",
    "brain", "executor", "agents", "metacog", "onlinestate",
    "uxu", "dashboard", "researchengine", "selfmodel",
    "metaevolve", "dgmh",
]

EXPECTED_CLI_COMMANDS = [
    "tianlong-monitor", "tianlong-safety", "tianlong-judge",
    "tianlong-reporter", "tianlong-uxu",
    "tianlong-dashboard", "tianlong-audit", "agent-run",
    "tianlong-agent", "tianlong-config",
    "sentrikit-selfcheck",
    "tianlong-compintel", "tianlong-enterprise",
]


def _check_import(module_name: str) -> dict[str, Any]:
    """尝试导入模块并返回状态"""
    result: dict[str, Any] = {"name": module_name, "status": "ok"}
    try:
        __import__(f"tianlong.{module_name}")
        result["imported"] = True
    except ImportError as e:
        result["status"] = "error"
        result["imported"] = False
        result["error"] = str(e)
    return result


def _check_version() -> dict[str, Any]:
    """检查版本一致性（代码 vs metadata）"""
    result: dict[str, Any] = {"status": "ok"}
    try:
        import tianlong
        code_version = tianlong.__version__
        result["code_version"] = code_version
    except Exception as e:
        result["status"] = "error"
        result["code_version"] = "unknown"
        result["error"] = str(e)

    try:
        from importlib.metadata import version as pkg_version
        meta_version = pkg_version("tianlong-toolkit")
        result["metadata_version"] = meta_version
    except Exception as e:
        meta_version = "unknown"
        result["metadata_version"] = meta_version
        result["metadata_error"] = str(e)

    if "code_version" in result and "metadata_version" in result:
        cv = result.get("code_version", "")
        mv = result.get("metadata_version", "")
        if cv and mv and cv != mv:
            result["status"] = "warning"
            result["warning"] = f"版本不一致: __init__={cv}, metadata={mv}"

    return result


def _check_license() -> dict[str, Any]:
    """检查许可文件"""
    result: dict[str, Any] = {"status": "ok"}
    import importlib.resources as res
    try:
        with res.files("tianlong").joinpath("license.py").open("r") as f:
            content = f.read()
        if "MIT" in content:
            result["license"] = "MIT"
        else:
            result["license"] = "OTHER"
            result["status"] = "warning"
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)
    return result


def run_selfcheck(quick: bool = False) -> dict[str, Any]:
    """运行完整自检，返回结果字典"""
    result: dict[str, Any] = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "toolkit": "tianlong-toolkit",
        "checks": [],
        "summary": {"ok": 0, "warning": 0, "error": 0, "total": 0},
    }

    # 1. 版本检查
    version_check = _check_version()
    result["checks"].append({
        "name": "版本一致性",
        "type": "version",
        **version_check,
    })
    _increment_summary(result["summary"], version_check["status"])

    # 2. 许可检查
    license_check = _check_license()
    result["checks"].append({
        "name": "许可文件",
        "type": "license",
        **license_check,
    })
    _increment_summary(result["summary"], license_check["status"])

    # 3. 模块导入检查
    mods_to_check = ["monitor", "judge", "brain", "uxu", "dgmh", "safety"] if quick else EXPECTED_MODULES
    for mod in mods_to_check:
        check = _check_import(mod)
        check["name"] = f"模块: {mod}"
        check["type"] = "module"
        result["checks"].append(check)
        _increment_summary(result["summary"], check["status"])

    # 4. CLI 可用性检查 (非quick模式)
    if not quick:
        _check_cli_commands(result)

    # 5. 种子数据检查（非quick模式）
    if not quick:
        _check_seed_data(result)

    # 6. 文件完整性校验（非quick模式）
    if not quick:
        _check_file_integrity(result)

    # 7. LLM 可用性检查
    if not quick:
        _check_llm(result)

    # 8. Python 环境
    result["environment"] = {
        "python": sys.version.split()[0],
        "platform": sys.platform,
    }

    # 综合判定
    if result["summary"]["error"] > 0:
        result["overall"] = "error"
    elif result["summary"]["warning"] > 0:
        result["overall"] = "degraded"
    else:
        result["overall"] = "healthy"

    return result


def _check_cli_commands(result: dict[str, Any]) -> None:
    """检查CLI命令可用性 — 双策略：entry_points + shutil.which。

    优先使用 entry_points（pip安装后直接可用），
    降级到 shutil.which（跨平台兼容）。
    """
    # 策略1: 通过 importlib.metadata 读取 entry_points
    registered = set()
    try:
        from importlib.metadata import entry_points
        eps = entry_points(group="console_scripts")
        for ep in eps:
            if ep.name.startswith("tianlong-") or ep.name == "agent-run":
                registered.add(ep.name)
    except Exception:
        pass

    # 策略2: shutil.which 降级
    for cmd in EXPECTED_CLI_COMMANDS:
        found = cmd in registered
        if not found:
            try:
                from shutil import which
                found = which(cmd) is not None
            except Exception:
                found = False

        status = "ok" if found else "warning"
        result["checks"].append({
            "name": f"CLI: {cmd}",
            "type": "cli",
            "status": status,
            "found": found,
        })
        _increment_summary(result["summary"], status)


def _check_seed_data(result: dict[str, Any]) -> None:
    """检查并自动生成种子数据（新用户快速体验）。"""
    from pathlib import Path

    # judge-history.json
    judge_path = Path("judge-history.json")
    if not judge_path.exists() or judge_path.stat().st_size < 100:
        try:
            from tianlong.judge import RuleBasedJudge, Proposal, JudgeHistory
            judge = RuleBasedJudge()
            history = JudgeHistory(path=str(judge_path))
            history.clear()
            proposals = [
                ("seed-001", "SafetyGuard门控", 0.90, "S"),
                ("seed-002", "版本号统一", 0.85, "A"),
                ("seed-003", "管理后台HTML", 0.88, "A"),
                ("seed-004", "测试覆盖补全", 0.80, "A"),
                ("seed-005", "UXU评分模型v2", 0.78, "B"),
                ("seed-006", "Cron超时优化", 0.85, "A"),
                ("seed-007", "FP治理优化", 0.83, "A"),
                ("seed-008", "UXU IS-011", 0.79, "B"),
                ("seed-009", "AST语义确认", 0.75, "B"),
                ("seed-010", "搜索API降级链", 0.68, "C"),
                ("seed-011", "批量文件写入约束", 0.70, "B"),
                ("seed-012", "UXU IS-012", 0.81, "A"),
                ("seed-013", "自检工具selfcheck", 0.82, "A"),
                ("seed-014", "取消无用技能", 0.72, "B"),
                ("seed-015", "CLI文档同步", 0.63, "C"),
                ("seed-016", "管理后台指令", 0.77, "B"),
                ("seed-017", "MetaCog集成", 0.86, "A"),
                ("seed-018", "DGM-H门控", 0.84, "A"),
                ("seed-019", "销售Pipeline", 0.65, "C"),
                ("seed-020", "文档架构保护", 0.60, "C"),
            ]
            for pid, summary, score, grade in proposals:
                prop = Proposal(id=pid, summary=summary, description=summary)
                rd = judge.evaluate(prop).to_dict()
                rd["total_score"] = score
                rd["grade"] = grade
                history.record(rd)
            result["checks"].append({
                "name": "种子数据: judge-history.json",
                "type": "seed",
                "status": "ok",
                "records": len(proposals),
            })
        except Exception as e:
            result["checks"].append({
                "name": "种子数据: judge-history.json",
                "type": "seed",
                "status": "warning",
                "warning": str(e),
            })
        _increment_summary(result["summary"], result["checks"][-1].get("status", "warning"))
    else:
        result["checks"].append({
            "name": "种子数据: judge-history.json",
            "type": "seed",
            "status": "ok",
            "records": "已存在",
        })
        _increment_summary(result["summary"], "ok")


def _increment_summary(summary: dict[str, int], status: str) -> None:
    summary["total"] = summary.get("total", 0) + 1
    if status == "ok":
        summary["ok"] = summary.get("ok", 0) + 1
    elif status == "warning":
        summary["warning"] = summary.get("warning", 0) + 1
    elif status == "error":
        summary["error"] = summary.get("error", 0) + 1


def format_text(result: dict[str, Any]) -> str:
    """格式化为可读文本输出"""
    lines = []
    lines.append(f"\n  🔍 SentriKit · 自检报告")
    lines.append(f"  {'='*44}")
    lines.append(f"  时间:     {result['timestamp']}")
    lines.append(f"  版本:     {result.get('checks', [{}])[0].get('code_version', '?')}")
    lines.append(f"  环境:     Python {result['environment']['python']} / {result['environment']['platform']}")
    lines.append(f"  {'='*44}")
    lines.append(f"")

    for check in result.get("checks", []):
        icon = "✅" if check["status"] == "ok" else "⚠️ " if check["status"] == "warning" else "❌"
        label = check.get("name", "?")
        lines.append(f"  {icon}  {label}")

    lines.append(f"")
    s = result["summary"]
    grade = result.get("overall", "unknown")
    gs = {"healthy": "✅ 健康", "degraded": "⚠️  亚健康", "error": "❌ 异常"}
    lines.append(f"  {'='*44}")
    lines.append(f"  结果:   {gs.get(grade, grade)}")
    lines.append(f"  总计:   {s['total']}项  ✅ {s['ok']}  ⚠️  {s['warning']}  ❌ {s['error']}")
    lines.append(f"  {'='*44}")
    lines.append(f"")
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="sentrikit-selfcheck",
        description="🔍 SentriKit · 自检 — 一键验证安装完整性",
    )
    p.add_argument("--quick", action="store_true", help="快速模式")
    p.add_argument("--json", action="store_true", help="JSON 输出")
    p.add_argument("--perf", action="store_true", help="查看性能指标")
    p.add_argument("--cache", action="store_true", help="查看缓存统计")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    # 性能指标查看
    if args.perf:
        try:
            from tianlong.monitor.perf import get_collector
            c = get_collector()
            summary = c.get_summary()
            if not summary["metrics"]:
                print("📊 性能指标: (无数据 — 运行 tianlong 操作后会自动采集)")
                return 0
            print(f"📊 性能指标 — {summary['total_calls']} 次调用, {summary['total_time_ms']}ms 总耗时")
            print(f"{'='*60}")
            for m in summary["metrics"]:
                err = f" ❌{m['errors']}err" if m['errors'] else ""
                print(f"  {m['name']:<40} {m['avg_ms']:>8.1f}ms avg  ({m['count']}次){err}")
            if summary["slowest"]:
                s = summary["slowest"]
                print(f"\n  最慢: {s['name']} ({s['avg_ms']}ms avg)")
            return 0
        except ImportError:
            print("⚠️ 性能分析器未加载 (tianlong.monitor.perf)")
            return 1

    # 缓存统计查看
    if args.cache:
        try:
            from tianlong.cache import all_cache_stats
            stats = all_cache_stats()
            if not stats:
                print("📦 缓存统计: (无缓存活动)")
                return 0
            print(f"📦 缓存统计 — {len(stats)} 个缓存实例")
            print(f"{'='*60}")
            for name, s in stats.items():
                print(f"  {name:<30} size={s['size']}/{s['maxsize']} 命中率={s['hit_rate']}%")
            return 0
        except ImportError:
            print("⚠️ 缓存模块未加载 (tianlong.cache)")
            return 1

    result = run_selfcheck(quick=args.quick)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(format_text(result))

    return 1 if result["summary"]["error"] > 0 else 0


def _check_file_integrity(result: dict) -> None:
    """校验关键文件未被篡改（基于大小和修改时间变化检测）。"""
    import hashlib
    from pathlib import Path

    src_base = Path("src") / "tianlong"
    integrity_path = src_base / ".integrity.json"
    checks: list[dict] = []

    # 关键文件列表（只校验核心模块，不校验所有文件以免过慢）
    critical_files = [
        "selfcheck.py", "config.py",
        "safety/__init__.py",
        "uxu/scanner.py", "uxu/rules.py",
        "evolution/ralph_loop.py",
        "agent/__init__.py",
        "admin/cli.py", "admin/admin_html.py",
        "dgmh/__init__.py",
        "judge/llm.py",
        "sales/master.py", "sales/llm.py",
        "brain/core.py", "brain/dispatcher.py",
        "monitor/cli.py",
        "compintel/tracker.py",
        "dashboard/__init__.py",
    ]

    # 如果没有完整性快照，创建初始快照
    if not integrity_path.exists():
        snapshot = {}
        for cf in critical_files:
            fp = src_base / cf
            if fp.exists():
                content = fp.read_bytes()
                snapshot[cf] = {
                    "size": len(content),
                    "hash": hashlib.sha256(content).hexdigest(),
                    "mtime": fp.stat().st_mtime,
                }
        integrity_path.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
        checks.append({
            "name": "文件完整性",
            "status": "ok",
            "detail": f"已创建{len(snapshot)}个文件的完整性快照",
        })
        result["checks"].append({"name": "文件完整性", "type": "integrity", "status": "ok",
                                  "detail": f"首次校验，已记录{len(snapshot)}个文件"})
        _increment_summary(result["summary"], "ok")
        return

    # 加载快照并校验
    try:
        snapshot = json.loads(integrity_path.read_text(encoding="utf-8"))
    except Exception:
        result["checks"].append({"name": "文件完整性", "type": "integrity", "status": "error",
                                  "error": "无法读取完整性快照"})
        _increment_summary(result["summary"], "error")
        return

    changed = []
    new_files = []
    for cf in critical_files:
        fp = src_base / cf
        if not fp.exists():
            changed.append(f"{cf} (已删除)")
            continue
        content = fp.read_bytes()
        current_hash = hashlib.sha256(content).hexdigest()
        current_size = len(content)

        if cf in snapshot:
            prev = snapshot[cf]
            if prev["hash"] != current_hash:
                changed.append(f"{cf} (哈希变化: 大小{prev['size']}→{current_size})")
        else:
            new_files.append(cf)

    if not changed and not new_files:
        result["checks"].append({"name": "文件完整性", "type": "integrity", "status": "ok",
                                  "detail": f"{len(critical_files)}个核心文件未被篡改"})
        _increment_summary(result["summary"], "ok")
    elif changed:
        detail = "; ".join(changed[:5])
        if len(changed) > 5:
            detail += f" ...等{len(changed)}处"
        result["checks"].append({"name": "文件完整性", "type": "integrity", "status": "warning",
                                  "warning": f"核心文件被修改: {detail}",
                                  "changed": changed})
        _increment_summary(result["summary"], "warning")
    else:
        result["checks"].append({"name": "文件完整性", "type": "integrity", "status": "ok",
                                  "detail": f"核心文件未变，新增{len(new_files)}个文件"})
        _increment_summary(result["summary"], "ok")


def _check_llm(result: dict) -> None:
    """检查 LLM API Key 配置是否正确可用。"""
    status = check_llm_availability()
    name = f"LLM 可用性"
    if status["connectivity"]:
        result["checks"].append({
            "name": name,
            "type": "llm",
            "status": "ok",
            "detail": f"✅ LLM API 可用 ({status['response_time_ms']}ms)",
            "source": status["api_key_source"],
        })
        _increment_summary(result["summary"], "ok")
    elif status["has_api_key"] and not status["connectivity"]:
        result["checks"].append({
            "name": name,
            "type": "llm",
            "status": "warning",
            "warning": f"已配置 API Key 但连接失败: {status['error']}",
        })
        _increment_summary(result["summary"], "warning")
    else:
        result["checks"].append({
            "name": name,
            "type": "llm",
            "status": "ok" if status["has_api_key"] else "warning",
            "warning": status.get("error", "未配置 LLM API Key"),
        })
        _increment_summary(result["summary"], "ok" if status["has_api_key"] else "warning")


def check_llm_availability() -> dict:
    """验证 LLM API Key 配置是否正确且可用。

    返回:
        dict: 包含 has_api_key, api_key_source, connectivity, response_time_ms, error
    """
    import os
    import time

    result = {
        "has_api_key": False,
        "api_key_source": None,
        "connectivity": False,
        "response_time_ms": None,
        "error": None,
    }

    # 1. 检查环境变量 / 配置文件
    api_key = (
        os.getenv("OPENAI_API_KEY") or
        os.getenv("DASHSCOPE_API_KEY") or
        os.getenv("LLM_API_KEY")
    )
    base_url = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")

    # 也检查 tianlong 配置文件
    if not api_key:
        try:
            import tianlong.config as cfg
            data = cfg.ensure_config()
            api_key = data.get("llm_api_key", "") or data.get("openai_api_key", "")
            if api_key:
                base_url = data.get("llm_base_url", base_url)
        except Exception:
            pass

    if not api_key:
        result["error"] = "未找到 LLM API Key，请设置 OPENAI_API_KEY 或 LLM_API_KEY 环境变量，或通过 tianlong-admin 配置"
        return result

    result["has_api_key"] = True
    result["api_key_source"] = "env" if os.getenv("OPENAI_API_KEY") or os.getenv("LLM_API_KEY") else "config"

    # 2. 轻量连接测试（HTTP HEAD 到 base_url，不消耗 token）
    try:
        import urllib.request
        import urllib.error

        start = time.time()
        test_url = base_url.rstrip("/") + "/models"
        req = urllib.request.Request(
            test_url,
            method="HEAD",
            headers={"Authorization": f"Bearer {api_key}"},
        )
        urllib.request.urlopen(req, timeout=5)
        elapsed = int((time.time() - start) * 1000)

        result["connectivity"] = True
        result["response_time_ms"] = elapsed
        result["error"] = None
    except urllib.error.HTTPError as e:
        # HTTP error but connection succeeded (may not have /models permission)
        result["connectivity"] = True
        result["response_time_ms"] = int((time.time() - start) * 1000)
        result["error"] = None
    except Exception as e:
        result["error"] = str(e)
        result["connectivity"] = False

    return result


if __name__ == "__main__":
    sys.exit(main())
