"""tianlong.safety.core — SafetyGuard 核心引擎

提供 SafetyGuard 类，负责安全检查路由、审计日志和退化检测。
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from .rules import Rule, DEFAULT_RULES
from .types import ChangeType, RiskLevel, GuardResult, AuditEntry, CHANGE_RISK_MAP


class SafetyGuard:
    """安全约束引擎。

    负责:
    1. 红线规则检查 — 所有操作前执行
    2. 风险等级判定 — 根据变更类型分配
    3. 审计日志 — 记录所有检查结果
    4. 退化检测 — 监控关键指标

    用法:
        guard = SafetyGuard(project_dir=Path("/path/to/agent"))
        guard.load_rules(DEFAULT_RULES)

        result = guard.check(
            action=ChangeType.DELETE,
            target="brain/config.yaml",
            trigger="SelfLearning",
        )
        if not result.allowed:
            print(f"⛔ {result.reason}")
    """

    def __init__(
        self,
        project_dir: Optional[Path] = None,
        rules: Optional[List[Rule]] = None,
    ):
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.rules: List[Rule] = rules or []
        self.audit_log: List[AuditEntry] = []
        self._degradation_count: int = 0
        self._last_warning: Optional[str] = None

    def load_rules(self, rules: List[Rule]) -> None:
        """加载规则列表"""
        self.rules = list(rules)

    def add_rule(self, rule: Rule) -> None:
        """添加单条规则"""
        self.rules.append(rule)

    # ── 核心检查 ──────────────────────────────────────

    def check(
        self,
        action: ChangeType,
        target: str = "",
        trigger: str = "unknown",
        summary: str = "",
        command: str = "",
    ) -> GuardResult:
        """执行安全检查。

        Args:
            action: 变更类型 (create/update/delete/config/execute)
            target: 目标文件或资源路径
            trigger: 触发者 (SelfLearning/BrainCore/用户)
            summary: 变更摘要描述
            command: 要执行的shell命令或代码（SI/PM运行时拦截）

        Returns:
            GuardResult 包含是否允许、风险等级和原因
        """
        # 0. SI/PM 运行时拦截：shell命令/code执行检查
        if command:
            blocked = self._check_command(command)
            if blocked:
                entry = self._log_audit(
                    trigger=trigger,
                    change_type="execute",
                    target=target or command[:60],
                    summary=summary or f"危险命令被拦截: {command[:60]}",
                    risk_level="forbidden",
                    allowed=False,
                    reason=blocked,
                )
                return GuardResult(
                    allowed=False,
                    risk_level=RiskLevel.FORBIDDEN,
                    reason=blocked,
                    rule_triggered="runtime_command_check",
                )
        # 1. 红线规则检查（最优先）
        for rule in self.rules:
            rule_result = rule.check(action, target)
            if rule_result is not None:
                entry = self._log_audit(
                    trigger=trigger,
                    change_type=action.value,
                    target=target,
                    summary=summary or f"触犯规则: {rule.name}",
                    risk_level="forbidden",
                    allowed=False,
                    reason=rule_result,
                )
                return GuardResult(
                    allowed=False,
                    risk_level=RiskLevel.FORBIDDEN,
                    reason=rule_result,
                    rule_triggered=rule.name,
                )

        # 2. 风险等级判定
        risk = CHANGE_RISK_MAP.get(action, RiskLevel.MEDIUM)

        # 3. 不可变文件检查
        if self._is_immutable(target) and action in (ChangeType.UPDATE, ChangeType.DELETE, ChangeType.CONFIG):
            entry = self._log_audit(
                trigger=trigger,
                change_type=action.value,
                target=target,
                summary=summary,
                risk_level="forbidden",
                allowed=False,
                reason=f"不可变文件: {target}",
            )
            return GuardResult(
                allowed=False,
                risk_level=RiskLevel.FORBIDDEN,
                reason=f"目标文件不可修改: {target}",
                rule_triggered="immutable_files",
            )

        # 4. 通过
        allowed = risk not in (RiskLevel.FORBIDDEN,)
        requires_confirm = risk == RiskLevel.HIGH

        self._log_audit(
            trigger=trigger,
            change_type=action.value,
            target=target,
            summary=summary,
            risk_level=risk.value,
            allowed=allowed,
        )
        return GuardResult(
            allowed=allowed,
            risk_level=risk,
            requires_confirmation=requires_confirm,
            reason=f"风险等级: {risk.value}, {'放行' if allowed else '阻止'}",
        )

    # ── 退化检测 ──────────────────────────────────────

    def record_degradation(self, indicator: str, message: str) -> Dict:
        """记录一次退化事件。

        Args:
            indicator: 退化指标名称
            message: 退化描述

        Returns:
            {"warning": bool, "paused": bool, "count": int}
        """
        self._degradation_count += 1
        self._last_warning = f"[{indicator}] {message}"

        result = {
            "count": self._degradation_count,
            "warning": True,
            "paused": self._degradation_count >= 3,
        }

        self._log_audit(
            trigger="degradation_detector",
            change_type="degradation",
            target=indicator,
            summary=message,
            risk_level="high",
            allowed=not result["paused"],
        )
        return result

    @property
    def is_paused(self) -> bool:
        """是否因退化已暂停"""
        return self._degradation_count >= 3

    def reset_degradation(self) -> None:
        """手动重置退化计数（需要用户确认）"""
        self._degradation_count = 0
        self._last_warning = None

    # ── 审计日志 ──────────────────────────────────────

    def get_audit_log(self, limit: int = 20) -> List[Dict]:
        """获取最近的审计日志"""
        return [asdict(e) for e in self.audit_log[-limit:]]

    def save_audit_log(self, path: Optional[Path] = None) -> Path:
        """保存审计日志到文件"""
        output = path or (self.project_dir / "brain" / "audit-log.json")
        output.parent.mkdir(parents=True, exist_ok=True)
        with open(output, "w", encoding="utf-8") as f:
            json.dump([asdict(e) for e in self.audit_log], f, ensure_ascii=False, indent=2)
        return output

    # ── 私有方法 ──────────────────────────────────────

    IMMUTABLE_FILES = frozenset({
        "safety-guard.md",
        "SOUL.md",
        "IDENTITY.md",
    })

    def _is_immutable(self, target: str) -> bool:
        target_name = Path(target).name
        return target_name in self.IMMUTABLE_FILES

    def _log_audit(
        self,
        trigger: str,
        change_type: str,
        target: str,
        summary: str,
        risk_level: str,
        allowed: bool,
        reason: str = "",
    ) -> AuditEntry:
        entry = AuditEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            trigger=trigger,
            change_type=change_type,
            target=target,
            summary=summary,
            risk_level=risk_level,
            allowed=allowed,
            reason=reason,
        )
        self.audit_log.append(entry)
        return entry
