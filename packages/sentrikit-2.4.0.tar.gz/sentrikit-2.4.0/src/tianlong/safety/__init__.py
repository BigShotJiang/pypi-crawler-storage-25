"""tianlong.safety — Agent 安全约束引擎

基于 Misevolution 论文 (arXiv:2509.26354) 设计的双重门控安全系统。
核心功能：5条红线规则 + 进化门控 + 退化检测。
"""

from .core import SafetyGuard
from .rules import Rule, DEFAULT_RULES, make_rules
from .types import GuardResult, ChangeType, RiskLevel, AuditEntry
