"""tianlong.safety.config — .uxurc.yaml 项目配置加载

项目级配置文件，控制规则开关、阈值、路径排除。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional


# 默认配置
DEFAULT_UXURC: Dict[str, Any] = {
    "version": "1",
    "project": {
        "name": "",
        "agent_framework": "auto",  # auto/langchain/openai/custom
    },
    "rules": {
        "enabled": True,
        "severity_threshold": "low",  # low/medium/high/critical
        "custom_rules_file": "",
    },
    "paths": {
        "scan": ["."],
        "exclude": [
            "node_modules/**",
            ".venv/**",
            "__pycache__/**",
            "*.pyc",
            ".git/**",
        ],
    },
    "monitor": {
        "health_threshold_warning": 0.6,
        "health_threshold_error": 0.3,
        "max_log_age_days": 30,
    },
    "safety": {
        "immutable_files": [
            "safety-guard.md",
            "SOUL.md",
            "IDENTITY.md",
            "evolution-authorization.md",
        ],
        "auto_confirm_threshold": "medium",  # low/medium/high
    },
}


def load_uxurc(path: Optional[str] = None) -> Dict[str, Any]:
    """加载 .uxurc.yaml 配置文件。

    如果文件不存在或无法解析，返回默认配置。
    """
    if path:
        fp = Path(path)
    else:
        fp = Path.cwd() / ".uxurc.yaml"

    if not fp.exists():
        return dict(DEFAULT_UXURC)

    try:
        import yaml
        data = yaml.safe_load(fp.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return _merge_config(dict(DEFAULT_UXURC), data)
        return dict(DEFAULT_UXURC)
    except ImportError:
        # yaml 不是标准库，用简单 key-value 解析作为 fallback
        return _parse_simple_config(fp)
    except Exception:
        return dict(DEFAULT_UXURC)


def _merge_config(base: Dict, override: Dict) -> Dict:
    """深度合并两个配置字典。"""
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _merge_config(result[k], v)
        else:
            result[k] = v
    return result


def _parse_simple_config(fp: Path) -> Dict[str, Any]:
    """无需 PyYAML 的简易解析器。"""
    config = dict(DEFAULT_UXURC)
    try:
        lines = fp.read_text(encoding="utf-8").split("\n")
        current_key = ""
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line and not line.startswith("-"):
                key, _, val = line.partition(":")
                key = key.strip()
                val = val.strip()
                if val == "":
                    current_key = key
                elif current_key:
                    if current_key not in config:
                        config[current_key] = {}
                    config[current_key][key] = val
                else:
                    config[key] = val
    except Exception:
        pass
    return config
