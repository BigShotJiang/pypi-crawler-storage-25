"""tianlong.safety.rules — 安全规则定义

包含 Rule 类和 5条红线规则的默认实现 (R1-R5)。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional

from .types import ChangeType


# 规则检查函数的类型签名
RuleCheckFn = Callable[[ChangeType, str], Optional[str]]


@dataclass
class Rule:
    """一条安全规则。

    name: 规则名称 (如 "R1")
    description: 规则描述
    check_fn: 检查函数，接收 (action, target) 返回 None=通过 或 str=阻止原因
    """

    name: str
    description: str
    check_fn: RuleCheckFn

    def check(self, action: ChangeType, target: str) -> Optional[str]:
        """执行规则检查。返回 None 表示通过，非空字符串表示阻止原因。"""
        return self.check_fn(action, target)


# ── 内置规则工厂 ──────────────────────────────────────


def _make_r1_no_delete() -> Rule:
    """R1: 任何删除操作必须由用户手动确认。"""
    def check(action: ChangeType, target: str) -> Optional[str]:
        if action == ChangeType.DELETE:
            return "[R1] 删除操作需主人手动确认，已阻止"
        return None
    return Rule("R1", "删除需主人手动确认", check)


def _make_r2_no_leak() -> Rule:
    """R2: 不泄露私人数据。"""
    sensitive_patterns = [
        "api_key", "api-key", "apikey", "token", "secret",
        "password", "credential", ".env", "private_key",
    ]
    def check(action: ChangeType, target: str) -> Optional[str]:
        target_lower = target.lower()
        for pattern in sensitive_patterns:
            if pattern in target_lower:
                return f"[R2] 目标含敏感数据关键词 '{pattern}'，已阻止泄露"
        return None
    return Rule("R2", "不泄露私人数据", check)


def _make_r3_no_destructive() -> Rule:
    """R3: 不执行违法/破坏性操作"""
    destructive_patterns = [
        "rm -rf", "format", "dd if=", "> /dev/sd",
        "shutdown", "reboot", "chmod 777 /",
        "DROP TABLE", "DELETE FROM",
    ]
    def check(action: ChangeType, target: str) -> Optional[str]:
        target_lower = target.lower()
        for pattern in destructive_patterns:
            if pattern.lower() in target_lower:
                return f"[R3] 目标含破坏性操作 '{pattern}'，已阻止"
        return None
    return Rule("R3", "不执行违法/破坏性操作", check)


def _make_r4_no_self_modify() -> Rule:
    """R4: 不修改自身安全规则。"""
    protected_files = [
        "safety-guard.md", "safety-guard.yaml", "safety-guard.json",
        "SOUL.md", "IDENTITY.md",
    ]
    def check(action: ChangeType, target: str) -> Optional[str]:
        target_name = Path(target).name
        if target_name in protected_files and action in (ChangeType.UPDATE, ChangeType.DELETE, ChangeType.CONFIG):
            return f"[R4] 禁止修改安全规则文件: {target_name}"
        return None
    return Rule("R4", "不修改自身安全规则", check)


def _make_r5_no_auto_auth() -> Rule:
    """R5: 不自主授权 — 不自行扩大权限范围。"""
    auth_patterns = [
        "chmod", "sudo", "su ", "usermod", "chown",
        "adduser", "groupadd", "authorization",
        "allowlist", "whitelist",
    ]
    def check(action: ChangeType, target: str) -> Optional[str]:
        target_lower = target.lower()
        for pattern in auth_patterns:
            if pattern.lower() in target_lower:
                return f"[R5] 目标含权限变更操作 '{pattern}'，已阻止自主授权"
        return None
    return Rule("R5", "不自主授权", check)


def _make_r6_legal_compliance() -> Rule:
    """R6: 遵守适用法律法规 — 自动适配当地法律约束。

    检查操作是否可能违反数据保护、内容合规等法律要求。
    基于目标关键词和国家/地区相关模式匹配。
    """
    # 各国/地区法律敏感关键词
    legal_patterns = [
        # GDPR (欧盟)
        "gdpr", "general data protection", "data subject", "right to erasure",
        "right to be forgotten", "personal data", "pii",
        # 中国
        "个人信息保护法", "pipL", "数据安全法", "网络安全法",
        "个保法", "数安法", "网安法", "中国法律",
        # 美国
        "ccpa", "cpra", "hipaa", "sox", "fcra", "coppa",
        "california consumer privacy", "health insurance portability",
        # 通用
        "export control", "sanction", "embargo", "dual-use",
        "intellectual property", "copyright", "trade secret",
        "classified", "confidential", "legal hold",
        # 内容合规
        "defamation", "hate speech", "illegal content",
        "child protection", "age verification",
    ]

    # 高风险操作类型
    high_risk_actions = {
        ChangeType.DELETE: "删除操作可能违反数据保留法律要求",
        ChangeType.CONFIG: "配置变更可能影响法律合规状态",
        ChangeType.EXECUTE: "执行操作可能触发法律约束检查",
    }

    def check(action: ChangeType, target: str) -> Optional[str]:
        target_lower = target.lower()

        # 检查关键词匹配
        for pattern in legal_patterns:
            if pattern.lower() in target_lower:
                risk_msg = high_risk_actions.get(action, "")
                if risk_msg:
                    return f"[R6] 目标涉及法律敏感词 '{pattern}'，{risk_msg}，已阻止"
                return f"[R6] 目标涉及法律敏感词 '{pattern}'，需合规审查"

        # 删除个人数据（名字、邮箱、身份证等模式）需要额外审查
        if action == ChangeType.DELETE:
            personal_patterns = ["user_data", "customer", "personal",
                                 "user_profile", "account", "log"]
            if any(p in target_lower for p in personal_patterns):
                return "[R6] 删除可能涉及个人数据，需确认符合数据保护法要求"

        return None
    return Rule("R6", "遵守适用法律法规", check)


# ── 默认规则集 ────────────────────────────────────────

DEFAULT_RULES: List[Rule] = [
    _make_r1_no_delete(),
    _make_r2_no_leak(),
    _make_r3_no_destructive(),
    _make_r4_no_self_modify(),
    _make_r5_no_auto_auth(),
    _make_r6_legal_compliance(),
]


def make_rules(custom_rules: Optional[List[Rule]] = None) -> List[Rule]:
    """创建规则列表。如果提供了自定义规则，追加到默认规则之后。"""
    rules = list(DEFAULT_RULES)
    if custom_rules:
        rules.extend(custom_rules)
    return rules
