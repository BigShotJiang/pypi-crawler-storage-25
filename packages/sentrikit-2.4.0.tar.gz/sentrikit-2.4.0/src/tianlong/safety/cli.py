"""tianlong.safety.cli — SafetyGuard 命令行接口

支持 `tianlong-safety` 和 `python -m tianlong.safety` 两种方式。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .core import SafetyGuard
from .rules import DEFAULT_RULES, make_rules
from .types import ChangeType
from .config import load_uxurc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tianlong-safety",
        description="SentriKit — SafetyGuard 安全约束引擎。检查操作是否安全。",
    )
    parser.add_argument(
        "--config", "-c",
        type=str,
        default=None,
        help=".uxurc.yaml 项目配置文件路径",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # check 子命令
    check_p = sub.add_parser("check", help="执行安全检查")
    check_p.add_argument("--action", "-a", required=True,
                         choices=["create", "update", "delete", "config", "execute"],
                         help="操作类型")
    check_p.add_argument("--target", "-t", required=True,
                         help="操作目标文件或命令")
    check_p.add_argument("--trigger", default="CLI",
                         help="触发者标识 (默认: CLI)")
    check_p.add_argument("--summary", default="",
                         help="操作摘要描述")
    check_p.add_argument("--rules", type=str, default=None,
                         help="自定义规则 JSON 文件路径")
    check_p.add_argument("--output", "-o", choices=["text", "json"], default="text",
                         help="输出格式 (默认: text)")

    # rules 子命令
    rules_p = sub.add_parser("rules", help="查看或加载规则")
    rules_p.add_argument("--file", "-f", type=str, default=None,
                         help="加载自定义规则 JSON 文件并显示")
    rules_p.add_argument("--output", "-o", choices=["text", "json"], default="text",
                         help="输出格式 (默认: text)")

    # audit 子命令
    audit_p = sub.add_parser("audit", help="查看审计日志")
    audit_p.add_argument("--limit", type=int, default=20,
                         help="显示最近 N 条 (默认: 20)")
    audit_p.add_argument("--file", type=str, default=None,
                         help="从文件加载审计日志")
    audit_p.add_argument("--output", "-o", choices=["text", "json"], default="text",
                         help="输出格式 (默认: text)")

    return parser


def _get_rules(rules_path: str | None):
    """获取规则列表：如果给了 JSON 文件则从文件加载，否则用默认规则。"""
    if rules_path:
        fp = Path(rules_path)
        if not fp.exists():
            print(f"❌ 规则文件不存在: {fp}", file=sys.stderr)
            sys.exit(3)
        data = json.loads(fp.read_text(encoding="utf-8"))
        return make_rules_from_dict(data)
    return list(DEFAULT_RULES)


def _load_project_config(config_path: str | None) -> dict:
    """加载项目配置，支持 .uxurc.yaml。"""
    cfg = load_uxurc(config_path)
    if cfg.get("project", {}).get("name"):
        framework = cfg["project"].get("agent_framework", "auto")
        print(f"📋 项目: {cfg['project']['name']} ({framework})", file=sys.stderr)
    return cfg


def make_rules_from_dict(data: dict) -> list:
    """从字典创建自定义规则列表。"""
    from .rules import Rule, make_rules

    custom_rules = []
    for item in data.get("rules", []):
        name = item.get("name", "custom")
        desc = item.get("description", "")
        patterns = item.get("patterns", [])
        block_actions = item.get("block_actions", ["delete", "config"])
        risk_override = item.get("risk", None)

        def _make_fn(pats, acts):
            def fn(action, target):
                from .types import ChangeType
                if action.value in acts:
                    for pat in pats:
                        if pat.lower() in target.lower():
                            return f"[{name}] 触犯规则: {pat}"
                return None
            return fn

        custom_rules.append(Rule(name, desc, _make_fn(patterns, block_actions)))

    return make_rules(custom_rules)


def cmd_check(args) -> int:
    rules = _get_rules(args.rules)
    guard = SafetyGuard(rules=rules)

    # 加载项目配置
    uxurc = _load_project_config(args.config)

    action_map = {
        "create": ChangeType.CREATE,
        "update": ChangeType.UPDATE,
        "delete": ChangeType.DELETE,
        "config": ChangeType.CONFIG,
        "execute": ChangeType.EXECUTE,
    }
    action = action_map[args.action]

    result = guard.check(
        action=action,
        target=args.target,
        trigger=args.trigger,
        summary=args.summary,
    )

    if args.output == "json":
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
        return 0 if result.allowed else 1

    icon = "✅" if result.allowed else "⛔"
    level = result.risk_level.value
    print(f"SafetyGuard · 安全检查结果")
    print(f"{'='*40}")
    print(f"操作:    {args.action}")
    print(f"目标:    {args.target}")
    print(f"允许:    {icon} {'是' if result.allowed else '否'}")
    print(f"风险等级: {level}")
    print(f"原因:    {result.reason}")
    if result.rule_triggered:
        print(f"触犯规则: {result.rule_triggered}")
    if result.requires_confirmation:
        print(f"⚠️ 需要用户确认")
    return 0 if result.allowed else 1


def cmd_rules(args) -> int:
    rules = _get_rules(args.file) if args.file else list(DEFAULT_RULES)

    if args.output == "json":
        data = [{"name": r.name, "description": r.description} for r in rules]
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    print(f"SafetyGuard · 规则列表 ({len(rules)} 条)")
    print(f"{'='*40}")
    for r in rules:
        print(f"  {r.name}: {r.description}")
    return 0


def cmd_audit(args) -> int:
    guard = SafetyGuard()

    if args.file:
        fp = Path(args.file)
        if not fp.exists():
            print(f"❌ 文件不存在: {fp}", file=sys.stderr)
            return 3
        data = json.loads(fp.read_text(encoding="utf-8"))
        logs = data[-args.limit:] if isinstance(data, list) else []
    else:
        logs = guard.get_audit_log(limit=args.limit)

    if args.output == "json":
        print(json.dumps(logs, ensure_ascii=False, indent=2))
        return 0

    print(f"SafetyGuard · 审计日志 (最近 {len(logs)} 条)")
    print(f"{'='*40}")
    for entry in logs:
        icon = "✅" if entry.get("allowed", False) else "⛔"
        print(f"  {icon} [{entry.get('change_type','?')}] {entry.get('target','?')}")
        print(f"     触发: {entry.get('trigger','?')} | 等级: {entry.get('risk_level','?')}")
        if entry.get("reason"):
            print(f"     原因: {entry['reason']}")
        print()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "check":
        return cmd_check(args)
    elif args.command == "rules":
        return cmd_rules(args)
    elif args.command == "audit":
        return cmd_audit(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
