"""tianlong.safety.types — 类型定义（无循环依赖）"""

from __future__ import annotations

from dataclasses import dataclass, field as dataclass_field, asdict
from enum import Enum
from typing import Dict, List, Optional


class ChangeType(Enum):
    """变更类型，对应风险等级"""
    CREATE = "create"       # 🟢 新增内容 — 低风险
    UPDATE = "update"       # 🟡 修改内容 — 中风险
    CONFIG = "config"       # 🟠 修改核心配置 — 高风险
    DELETE = "delete"       # 🔴 删除内容 — 禁止
    EXECUTE = "execute"     # 执行操作


class RiskLevel(Enum):
    LOW = "low"         # 🟢 自动放行
    MEDIUM = "medium"   # 🟡 审计通过后放行
    HIGH = "high"       # 🟠 需用户确认
    FORBIDDEN = "forbidden"  # 🔴 阻止


# 变更类型 → 默认风险等级映射
CHANGE_RISK_MAP: Dict[ChangeType, RiskLevel] = {
    ChangeType.CREATE: RiskLevel.LOW,
    ChangeType.UPDATE: RiskLevel.MEDIUM,
    ChangeType.CONFIG: RiskLevel.HIGH,
    ChangeType.DELETE: RiskLevel.FORBIDDEN,
}


@dataclass
class GuardResult:
    """安全检查结果"""
    allowed: bool
    risk_level: RiskLevel
    reason: str = ""
    rule_triggered: Optional[str] = None
    requires_confirmation: bool = False

    def to_dict(self) -> Dict:
        return {
            "allowed": self.allowed,
            "risk_level": self.risk_level.value,
            "reason": self.reason,
            "rule_triggered": self.rule_triggered,
            "requires_confirmation": self.requires_confirmation,
        }


@dataclass
class AuditEntry:
    """审计日志条目"""
    timestamp: str
    trigger: str
    change_type: str
    target: str
    summary: str
    risk_level: str
    allowed: bool
    reason: str = ""
