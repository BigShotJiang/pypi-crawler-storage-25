# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""tianlong.license — SentriKit 许可管理

v2.0: 从闭源包导入检测改为 API Key 运行时检测。

门控逻辑：
- 基础模块（monitor/safety/judge/uxu/dashboard/admin 等）：始终可用
- 企业模块（BrainCore/Evolution/DGM-H/MetaEVOLVE/Research/Memory）：需 API Key

检测顺序：
1. 环境变量 SENTRIKIT_API_KEY 或 TIANLONG_ENTERPRISE
2. 文件 ~/.sentrikit/config.json 中的 api_key

Usage:
    from tianlong.license import require_enterprise, LicenseLevel
    if not require_enterprise("brain"):
        print("BrainCore 需要企业版 API Key")
"""

from __future__ import annotations

import os
import json
from enum import Enum
from pathlib import Path
from typing import Optional

from .enterprise_client import detect_api_key


# ── 授权级别 ─────────────────────────────────────

class LicenseLevel(Enum):
    COMMUNITY = "community"     # MIT 开源版
    ENTERPRISE = "enterprise"   # 企业版 API Key 激活


# ── 企业模块列表 ────────────────────────────────

# 这些模块需要企业版 API Key
ENTERPRISE_MODULES = {
    "brain",        # BrainCore 决策引擎
    "evolution",    # SelfLearning 进化管道
    "dgmh",         # DGM-H 元认知编排
    "metaevolve",   # MetaEVOLVE 元修改器
    "researchengine", # 调研引擎
    "memory",       # 记忆系统
}

# 环境变量覆盖
ENV_LICENSE_KEY = "TIANLONG_LICENSE_KEY"
ENV_ENTERPRISE_ENABLED = "TIANLONG_ENTERPRISE"


# ── 授权检查 ─────────────────────────────────────

def get_license_level() -> LicenseLevel:
    """获取当前授权级别。

    检测顺序：
    1. 环境变量 TIANLONG_ENTERPRISE=1
    2. 环境变量 TIANLONG_LICENSE_KEY 或 SENTRIKIT_API_KEY
    3. 文件 ~/.sentrikit/config.json 中的 api_key
    4. 默认为 COMMUNITY
    """
    # 环境变量开关
    if os.environ.get(ENV_ENTERPRISE_ENABLED, "").lower() in ("1", "true", "yes"):
        return LicenseLevel.ENTERPRISE

    # API Key 检测（统一入口）
    api_key = detect_api_key()
    if api_key:
        return LicenseLevel.ENTERPRISE

    # 旧版 License Key 兼容
    license_key = os.environ.get(ENV_LICENSE_KEY, "")
    if license_key and _verify_key(license_key):
        return LicenseLevel.ENTERPRISE

    # 文件检测（旧版）
    key_file = Path.home() / ".sentrikit" / "license.key"
    if key_file.exists():
        try:
            if _verify_key(key_file.read_text().strip()):
                return LicenseLevel.ENTERPRISE
        except Exception:
            pass

    return LicenseLevel.COMMUNITY


def require_enterprise(module_name: str = "") -> bool:
    """检查是否可以使用企业版模块。

    Args:
        module_name: 模块名称

    Returns:
        True 如果已激活企业版或模块不属于企业模块
        False 如果模块需要企业版但未激活
    """
    # 非企业模块始终可用
    if module_name not in ENTERPRISE_MODULES:
        return True

    level = get_license_level()
    return level == LicenseLevel.ENTERPRISE


def module_allowed(module_name: str) -> bool:
    """兼容接口：检查模块是否允许使用。"""
    return require_enterprise(module_name)


def get_license_display() -> str:
    """获取可读的许可状态文本。"""
    level = get_license_level()
    if level == LicenseLevel.ENTERPRISE:
        return "🔒 Enterprise License — API Key 已激活"
    return "🆓 MIT License — 开源社区版（设置 SENTRIKIT_API_KEY 激活企业版）"


def _verify_key(key: str) -> bool:
    """验证 License Key 格式（兼容旧版）。"""
    parts = key.split("-")
    if len(parts) == 4 and parts[0] == "TIANLONG":
        return True
    # 也接受 API Key 格式 (sk-xxx)
    if key.startswith("sk-") and len(key) > 10:
        return True
    return False


# ── 兼容接口 ─────────────────────────────────────

def get_license() -> str:
    return get_license_display()


def require_pro(module_name: str) -> bool:
    """保留兼容接口。"""
    return require_enterprise(module_name)
