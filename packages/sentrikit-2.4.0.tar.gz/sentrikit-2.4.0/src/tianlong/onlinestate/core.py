"""tianlong.onlinestate.core — 在线状态管理器"""
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

ONLINE_STATE_FILE = "brain/online-state.md"


@dataclass
class OnlineStateSnapshot:
    status: str = "online"
    last_online: str = ""
    last_offline: str = ""
    reason: str = ""


class OnlineState:
    def __init__(self, project_dir: Optional[Path] = None):
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self._status: str = "online"

    @property
    def is_online(self) -> bool:
        return self._status == "online"

    def set_online(self, reason: str = "") -> None:
        self._status = "online"
        self._write_state("online", reason)

    def set_offline(self, reason: str = "手动离线") -> None:
        self._status = "offline"
        self._write_state("offline", reason)

    def _write_state(self, status: str, reason: str) -> None:
        fp = self.project_dir / ONLINE_STATE_FILE
        fp.parent.mkdir(parents=True, exist_ok=True)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        fp.write_text(f"# 在线状态\n\n状态: {status}\n时间: {now}\n原因: {reason or '无'}\n", encoding="utf-8")

    def read(self) -> OnlineStateSnapshot:
        fp = self.project_dir / ONLINE_STATE_FILE
        if not fp.exists():
            return OnlineStateSnapshot(status="unknown")
        snap = OnlineStateSnapshot()
        for line in fp.read_text(encoding="utf-8").strip().split("\n"):
            line = line.strip()
            if line.startswith("状态:"): snap.status = line[3:].strip()
            elif line.startswith("时间:"):
                if snap.status == "online": snap.last_online = line[3:].strip()
                else: snap.last_offline = line[3:].strip()
            elif line.startswith("原因:"): snap.reason = line[3:].strip()
        return snap

    def snapshot(self) -> Dict:
        s = self.read()
        return {"status": s.status, "is_online": s.status == "online",
                "last_online": s.last_online, "last_offline": s.last_offline, "reason": s.reason}
