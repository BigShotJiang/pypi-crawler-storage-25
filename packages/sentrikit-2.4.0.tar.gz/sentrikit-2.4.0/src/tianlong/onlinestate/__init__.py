"""tianlong.onlinestate — 在线状态管理器

基于 brain/online-state.md 的状态管理。
开源版：基础功能（在线/离线状态切换 + 持久化）。
"""

from .core import OnlineState, OnlineStateSnapshot
