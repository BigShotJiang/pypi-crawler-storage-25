"""tianlong.compintel.sources — 数据源定义

预设竞品数据源（Crunchbase/GitHub/新闻/招聘/社交媒体/技术社区）。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class DataSource:
    """一个情报数据源"""
    id: str = ""
    name: str = ""
    url: str = ""
    category: str = ""       # github / funding / news / hiring / social / tech
    enabled: bool = True
    weight: float = 1.0      # 该源在评分中的权重
    last_fetch: str = ""
    fetch_interval: str = "24h"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "url": self.url,
            "category": self.category,
            "enabled": self.enabled,
            "weight": self.weight,
            "last_fetch": self.last_fetch,
        }


# 预设数据源（行业通用竞品情报数据源）
KNOWN_SOURCES: List[DataSource] = [
    # ── 融资情报 ──
    DataSource("fin-001", "CrunchBase", "https://www.crunchbase.com", "funding", weight=1.5),
    DataSource("fin-002", "PitchBook", "https://pitchbook.com", "funding", weight=1.5),
    DataSource("fin-003", "IT桔子", "https://www.itjuzi.com", "funding", weight=1.2),
    DataSource("fin-004", "36氪 融资日报", "https://36kr.com/investment", "funding", weight=1.0),
    # ── GitHub ──
    DataSource("gh-001", "GitHub Trending", "https://github.com/trending", "github", weight=0.8),
    DataSource("gh-002", "GitHub 竞品仓库", "", "github", weight=1.2),
    # ── 新闻 ──
    DataSource("news-001", "TechCrunch", "https://techcrunch.com", "news", weight=1.0),
    DataSource("news-002", "Hacker News", "https://news.ycombinator.com", "news", weight=0.8),
    DataSource("news-003", "36氪 快讯", "https://36kr.com/news", "news", weight=0.8),
    DataSource("news-004", "机器之心", "https://jiqizhixin.com", "news", weight=0.8),
    # ── 招聘 ──
    DataSource("hire-001", "Boss直聘 竞品招聘", "https://zhipin.com", "hiring", weight=0.6),
    DataSource("hire-002", "LinkedIn Hiring", "https://linkedin.com/jobs", "hiring", weight=0.6),
    # ── 社交媒体 ──
    DataSource("soc-001", "Twitter/X AI社区", "https://x.com", "social", weight=0.5),
    DataSource("soc-002", "知乎 AI话题", "https://zhihu.com/topic/ai", "social", weight=0.5),
    DataSource("soc-003", "Reddit r/MachineLearning", "https://reddit.com/r/MachineLearning", "social", weight=0.4),
    # ── 技术社区 ──
    DataSource("tech-001", "Kaggle", "https://kaggle.com", "tech", weight=0.6),
    DataSource("tech-002", "Hugging Face", "https://huggingface.co", "tech", weight=0.8),
    DataSource("tech-003", "Papers With Code", "https://paperswithcode.com", "tech", weight=0.7),
]


def get_sources_by_category(category: str) -> List[DataSource]:
    """按分类获取数据源。"""
    return [s for s in KNOWN_SOURCES if s.category == category]


def get_enabled_sources() -> List[DataSource]:
    return [s for s in KNOWN_SOURCES if s.enabled]
