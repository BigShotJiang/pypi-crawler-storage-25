"""tianlong.compintel.cli — 竞品情报 CLI

用法:
    tianlong-compintel list           # 列出竞品
    tianlong-compintel sync            # 企业版：自动采集
    tianlong-compintel report          # 生成报告（默认HTML）
    tianlong-compintel report --format markdown
    tianlong-compintel add <name>      # 手动添加竞品
    tianlong-compintel remove <id>     # 删除竞品
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .tracker import CompIntelTracker
from .report import IntelReport


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tianlong-compintel",
        description="🕵️ SentriKit · 竞品情报 — SaaS级竞品追踪与分析",
    )
    p.add_argument("--project-dir", "-d", type=str, default=".", help="项目目录")

    sub = p.add_subparsers(dest="command", required=True)

    # list
    sub.add_parser("list", help="列出所有竞品")

    # sync
    sub.add_parser("sync", help="采集最新情报")

    # report
    rp = sub.add_parser("report", help="生成情报报告")
    rp.add_argument("--format", "-f", type=str, choices=["html", "markdown", "json"],
                    default="html", help="报告格式")
    rp.add_argument("--output", "-o", type=str, default="", help="输出到文件")

    # add
    ap = sub.add_parser("add", help="添加竞品")
    ap.add_argument("name", type=str, help="竞品名称")
    ap.add_argument("--url", type=str, default="", help="官网URL")
    ap.add_argument("--category", type=str, choices=["direct", "indirect", "potential"],
                    default="indirect", help="竞品分类")

    # remove
    rmp = sub.add_parser("remove", help="删除竞品")
    rmp.add_argument("comp_id", type=str, help="竞品ID")

    return p


def cmd_list(args) -> int:
    tracker = CompIntelTracker(project_dir=args.project_dir)
    comps = tracker.competitors
    if not comps:
        print("暂无竞品")
        return 0
    print(f"\n{'='*55}")
    print(f"  竞品情报 — {len(comps)} 家追踪中")
    print(f"{'='*55}\n")
    for c in comps:
        print(f"  🏢 {c.name}")
        print(f"     ID: {c.id} | 分类: {c.category}")
        print(f"     活跃度: {c.activity_score:.1f}/100 | 威胁: {c.risk_score:.1f}/100")
        if c.products:
            print(f"     产品: {', '.join(c.products[:3])}")
        print()
    return 0


def cmd_sync(args) -> int:
    """企业版功能：自动采集竞品情报（需 TIANLONG_ENTERPRISE=1）。"""
    enterprise = os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes")
    if not enterprise:
        print("❌ 自动采集需要企业版授权（TIANLONG_ENTERPRISE=1）", file=sys.stderr)
        print("   开源版请手动添加竞品: tianlong-compintel add <名称>", file=sys.stderr)
        return 1
    tracker = CompIntelTracker(project_dir=args.project_dir)
    print("正在采集竞品情报...")
    new_count = tracker.sync()
    print(f"\n✅ 采集完成，新增 {new_count} 条情报事件")
    summary = tracker.summary()
    print(f"   追踪竞品: {summary['total_competitors']} 家")
    print(f"   累计事件: {summary['total_events']} 条")
    print(f"   高威胁: {summary['high_risk_count']} 家")
    return 0


def cmd_add(args) -> int:
    tracker = CompIntelTracker(project_dir=args.project_dir)
    cp = tracker.add_competitor(
        name=args.name,
        url=args.url,
        category=args.category,
    )
    print(f"\n✅ 已添加竞品: {cp.name} (ID: {cp.id})")
    return 0


def cmd_remove(args) -> int:
    tracker = CompIntelTracker(project_dir=args.project_dir)
    ok = tracker.remove_competitor(args.comp_id)
    if ok:
        print(f"\n✅ 已删除竞品: {args.comp_id}")
    else:
        print(f"\n❌ 竞品不存在: {args.comp_id}")
        return 1
    return 0


def cmd_report(args) -> int:
    tracker = CompIntelTracker(project_dir=args.project_dir)
    report = IntelReport(tracker=tracker)

    if args.format == "json":
        output = json.dumps(report.to_dict(), ensure_ascii=False, indent=2)
    elif args.format == "markdown":
        output = report.to_markdown()
    else:
        output = report.to_html()

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(f"💾 报告已保存到: {args.output}")
    else:
        print(output)
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "list":
        return cmd_list(args)
    elif args.command == "sync":
        return cmd_sync(args)
    elif args.command == "add":
        return cmd_add(args)
    elif args.command == "remove":
        return cmd_remove(args)
    elif args.command == "report":
        return cmd_report(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
