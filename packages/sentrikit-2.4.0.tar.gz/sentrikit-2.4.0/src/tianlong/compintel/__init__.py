"""tianlong.compintel — 竞品情报模块

开源版：手动竞品管理（添加/列表/报告），个人够用。
企业版：自动采集+推送，走独立 SaaS 服务（非 pip 安装），数据生意。
"""

from __future__ import annotations

from .tracker import CompIntelTracker, CompetitorProfile, IntelEvent
from .report import IntelReport
from .sources import DataSource, KNOWN_SOURCES

__all__ = [
    "CompIntelTracker", "CompetitorProfile", "IntelEvent",
    "IntelReport", "DataSource", "KNOWN_SOURCES",
]
