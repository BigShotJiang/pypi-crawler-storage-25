"""tianlong.compintel.tracker — 竞品追踪器

核心引擎：竞品Profile管理、情报采集、变化检测、活动评分。
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .sources import DataSource, KNOWN_SOURCES

# ── 持久化路径 ──
INTEL_STATE_FILE = "brain/compintel-state.json"


@dataclass
class IntelEvent:
    """一条情报事件"""
    id: str = ""
    competitor_id: str = ""
    source_id: str = ""
    category: str = ""          # funding / product / hiring / partnership / security
    title: str = ""
    summary: str = ""
    url: str = ""
    timestamp: str = ""
    impact_score: float = 0.0   # 0-1 影响评分
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v}


@dataclass
class CompetitorProfile:
    """一个竞品画像"""
    id: str = ""
    name: str = ""
    url: str = ""
    category: str = ""           # direct / indirect / potential
    description: str = ""
    founded: str = ""
    funding_total: str = ""
    funding_round: str = ""
    employees: str = ""
    headquarters: str = ""
    products: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    sources: List[str] = field(default_factory=list)  # 监控的数据源ID列表

    # 动态指标
    github_stars: int = 0
    github_forks: int = 0
    last_commit_days: int = 0
    hiring_count: int = 0
    news_mention_7d: int = 0
    activity_score: float = 0.0        # 0-100 综合活跃度
    risk_score: float = 0.0            # 0-100 竞争威胁评分

    # 元数据
    created_at: str = ""
    updated_at: str = ""
    notes: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def brief(self) -> str:
        """一行摘要"""
        return f"{self.name} [{self.category}] 活跃度{self.activity_score:.0f} 威胁{self.risk_score:.0f}"


class CompIntelTracker:
    """竞品情报追踪器

    用法:
        tracker = CompIntelTracker()
        tracker.add_competitor("LangChain", url="https://langchain.com")
        tracker.sync()  # 采集情报
        report = tracker.generate_report()
    """

    def __init__(self, project_dir: str = "."):
        self.project_dir = Path(project_dir).resolve()
        self._state_path = self.project_dir / INTEL_STATE_FILE
        self._competitors: List[CompetitorProfile] = []
        self._events: List[IntelEvent] = []
        self._sources: List[DataSource] = KNOWN_SOURCES
        self._load()

    # ── 持久化 ──

    def _load(self) -> None:
        if self._state_path.exists():
            try:
                data = json.loads(self._state_path.read_text(encoding="utf-8"))
                self._competitors = [CompetitorProfile(**c) for c in data.get("competitors", [])]
                self._events = [IntelEvent(**e) for e in data.get("events", [])]
            except Exception:
                self._init_defaults()
        else:
            self._init_defaults()

    def _save(self) -> None:
        data = {
            "competitors": [c.to_dict() for c in self._competitors],
            "events": [e.to_dict() for e in self._events[-500:]],
            "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        self._state_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _init_defaults(self) -> None:
        self._competitors = [
            CompetitorProfile(
                id="comp-langchain", name="LangChain", category="direct",
                url="https://langchain.com", description="LLM应用框架",
                products=["LangChain", "LangSmith", "LangServe"],
                tags=["LLM", "framework", "agent"],
                sources=["fin-001", "news-001", "gh-001"],
            ),
            CompetitorProfile(
                id="comp-crewai", name="CrewAI", category="direct",
                url="https://crewai.com", description="多Agent协作框架",
                products=["CrewAI"], tags=["agent", "multi-agent"],
                sources=["news-001", "gh-001", "tech-002"],
            ),
            CompetitorProfile(
                id="comp-autogpt", name="AutoGPT", category="direct",
                url="https://agpt.co", description="自主Agent框架",
                products=["AutoGPT"], tags=["agent", "autonomous"],
                sources=["gh-001", "news-002", "tech-001"],
            ),
            CompetitorProfile(
                id="comp-hf", name="Hugging Face", category="indirect",
                url="https://huggingface.co", description="ML模型Hub+Agent框架",
                products=["Transformers", "smolagents", "Hugging Face Hub"],
                tags=["ML", "hub", "open-source"],
                sources=["fin-001", "news-001", "tech-002", "tech-003"],
            ),
        ]
        self._save()

    # ── 竞品管理 ──

    @property
    def competitors(self) -> List[CompetitorProfile]:
        return self._competitors

    def get_competitor(self, comp_id: str) -> Optional[CompetitorProfile]:
        for c in self._competitors:
            if c.id == comp_id:
                return c
        return None

    def add_competitor(self, name: str, url: str = "",
                       category: str = "indirect",
                       description: str = "",
                       products: Optional[List[str]] = None) -> CompetitorProfile:
        comp_id = "comp-" + (re.sub(r'[^a-z0-9]', '', name.lower())[:20] or "unknown")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cp = CompetitorProfile(
            id=comp_id, name=name, url=url, category=category,
            description=description, products=products or [],
            created_at=now, updated_at=now,
        )
        self._competitors.append(cp)
        self._save()
        return cp

    def remove_competitor(self, comp_id: str) -> bool:
        before = len(self._competitors)
        self._competitors = [c for c in self._competitors if c.id != comp_id]
        if len(self._competitors) < before:
            self._save()
            return True
        return False

    def update_competitor(self, comp_id: str, **kwargs) -> Optional[CompetitorProfile]:
        for c in self._competitors:
            if c.id == comp_id:
                for k, v in kwargs.items():
                    if hasattr(c, k):
                        setattr(c, k, v)
                c.updated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self._save()
                return c
        return None

    # ── 情报采集 ──

    def sync(self) -> int:
        """执行一次情报采集，返回新事件数。"""
        new_count = 0
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        for comp in self._competitors:
            # 计算活跃度（模拟采集）
            score = self._calc_activity(comp)
            comp.activity_score = score
            comp.updated_at = now

            # 竞争威胁评分
            comp.risk_score = self._calc_risk(comp)

            # 生成情报事件
            events = self._generate_events(comp)
            for ev in events:
                if not self._is_duplicate_event(ev):
                    self._events.append(ev)
                    new_count += 1

        self._save()
        return new_count

    def _calc_activity(self, comp: CompetitorProfile) -> float:
        """计算竞品活跃度 (0-100)

        基于: GitHub活动/新闻提及/招聘/产品更新
        模拟评分，未来对接真实数据源后转为加权计算。
        """
        base = {
            "LangChain": 85.0, "CrewAI": 72.0,
            "AutoGPT": 58.0, "Hugging Face": 92.0,
        }.get(comp.name, 50.0)

        # 添加随机波动
        import random
        delta = random.uniform(-5, 5)
        return max(0, min(100, base + delta))

    def _calc_risk(self, comp: CompetitorProfile) -> float:
        """计算竞争威胁评分 (0-100)

        基于: 活跃度/融资/产品重叠度/市场影响力
        """
        risk_map = {
            "LangChain": 80.0, "CrewAI": 65.0,
            "AutoGPT": 50.0, "Hugging Face": 75.0,
        }
        base = risk_map.get(comp.name, 40.0)
        import random
        delta = random.uniform(-3, 3)
        return max(0, min(100, base + delta))

    def _generate_events(self, comp: CompetitorProfile) -> List[IntelEvent]:
        """模拟生成情报事件。"""
        import random
        events = []
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # GitHub Star事件
        if random.random() < 0.4:
            events.append(IntelEvent(
                id=f"evt-{int(time.time()*1000000)%100000}",
                competitor_id=comp.id,
                source_id="gh-001",
                category="product",
                title=f"{comp.name} GitHub Stars增长",
                summary=f"{comp.name} 在GitHub上获得了新关注",
                timestamp=now,
                impact_score=round(random.uniform(0.3, 0.7), 2),
                tags=["github", "growth"],
            ))

        return events

    def _is_duplicate_event(self, event: IntelEvent) -> bool:
        for e in self._events:
            if e.title == event.title and e.competitor_id == event.competitor_id:
                if abs((datetime.now() - datetime.strptime(e.timestamp[:10], "%Y-%m-%d")).days) < 1:
                    return True
        return False

    # ── 情报查询 ──

    def get_recent_events(self, limit: int = 50) -> List[dict]:
        return [e.to_dict() for e in self._events[-limit:]]

    def get_events_by_competitor(self, comp_id: str, limit: int = 20) -> List[dict]:
        return [e.to_dict() for e in self._events if e.competitor_id == comp_id][-limit:]

    def get_high_impact_events(self, min_score: float = 0.6) -> List[dict]:
        return [e.to_dict() for e in self._events if e.impact_score >= min_score]

    # ── 摘要 ──

    def summary(self) -> dict:
        high_risk = [c for c in self._competitors if c.risk_score >= 60]
        high_activity = sorted(self._competitors, key=lambda c: -c.activity_score)[:3]
        return {
            "total_competitors": len(self._competitors),
            "total_events": len(self._events),
            "high_risk_count": len(high_risk),
            "high_risk_names": [c.name for c in high_risk],
            "top_active": [c.name for c in high_activity],
            "sources_monitored": len(self._sources),
        }

    def to_dict(self) -> dict:
        return {
            "competitors": [c.to_dict() for c in self._competitors],
            "events": [e.to_dict() for e in self._events[-100:]],
            "summary": self.summary(),
        }
