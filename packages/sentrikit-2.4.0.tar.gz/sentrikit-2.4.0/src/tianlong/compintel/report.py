"""tianlong.compintel.report — 竞品情报报告生成

生成Markdown/HTML格式的竞品情报报告。
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Dict, List, Optional

from .tracker import CompIntelTracker, CompetitorProfile, IntelEvent


def _impact_icon(score: float) -> str:
    if score >= 0.8:
        return "\U0001f534"
    elif score >= 0.6:
        return "\U0001f7e0"
    elif score >= 0.4:
        return "\U0001f7e1"
    return "\U0001f7e2"


class IntelReport:
    """竞品情报报告生成器"""

    def __init__(self, tracker: Optional[CompIntelTracker] = None, project_dir: str = "."):
        self.tracker = tracker or CompIntelTracker(project_dir=project_dir)

    def to_dict(self) -> dict:
        """结构化数据"""
        return self.tracker.to_dict()

    def to_markdown(self) -> str:
        """Markdown报告"""
        lines = []
        lines.append("# \U0001f575 竞品情报报告\n")
        lines.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

        summary = self.tracker.summary()
        lines.append("## \U0001f4ca 概览\n")
        lines.append(f"- **追踪竞品**: {summary['total_competitors']} 家")
        lines.append(f"- **情报事件**: {summary['total_events']} 条")
        lines.append(f"- **高威胁竞品**: {summary['high_risk_count']} 家 ({', '.join(summary['high_risk_names'])})")
        lines.append(f"- **最活跃**: {', '.join(summary['top_active'])}")
        lines.append(f"- **数据源**: {summary['sources_monitored']} 个\n")

        lines.append("---\n")
        lines.append("## \U0001f3e2 竞品画像\n")
        for comp in self.tracker.competitors:
            lines.append(f"### {comp.name}")
            lines.append(f"- **分类**: {comp.category}")
            lines.append(f"- **产品**: {', '.join(comp.products) if comp.products else '-'}")
            lines.append(f"- **活跃度**: {comp.activity_score:.1f}/100")
            lines.append(f"- **威胁评分**: {comp.risk_score:.1f}/100")
            if comp.description:
                lines.append(f"- **描述**: {comp.description}")
            lines.append("")

        lines.append("---\n")
        lines.append("## \U0001f4f0 最新情报\n")
        events = self.tracker.get_recent_events(30)
        if events:
            for ev in reversed(events):
                icon = _impact_icon(ev.get("impact_score", 0))
                lines.append(f"- {icon} **{ev.get('title', '?')}** ({ev.get('timestamp', '')[:10]})")
                if ev.get("summary"):
                    lines.append(f"  > {ev['summary']}")
            lines.append("")
        else:
            lines.append("暂无情报事件\n")

        return "\n".join(lines)

    def to_html(self) -> str:
        """HTML报告"""
        cards = ""
        for comp in self.tracker.competitors:
            ac = "stat-good" if comp.activity_score >= 70 else ("stat-warn" if comp.activity_score >= 50 else "stat-bad")
            rc = "stat-bad" if comp.risk_score >= 70 else ("stat-warn" if comp.risk_score >= 50 else "stat-good")
            products = ", ".join(comp.products[:3]) if comp.products else "-"
            cards += f"""
            <div class="card">
                <h3>{comp.name} <span class="badge">{comp.category}</span></h3>
                <div class="row"><span class="label">活跃度</span><span class="{ac}">{comp.activity_score:.0f}/100</span></div>
                <div class="row"><span class="label">威胁评分</span><span class="{rc}">{comp.risk_score:.0f}/100</span></div>
                <div class="row"><span class="label">产品</span><span>{products}</span></div>
                <div class="row"><span class="label">描述</span><span>{comp.description or '-'}</span></div>
            </div>"""

        events_html = ""
        for ev in self.tracker.get_recent_events(20):
            icon = _impact_icon(ev.get("impact_score", 0))
            events_html += f"""
            <div class="evt">
                <span class="evt-icon">{icon}</span>
                <span class="evt-title">{ev.get('title', '?')}</span>
                <span class="evt-time">{ev.get('timestamp', '')[:10]}</span>
            </div>"""

        return self._build_html(cards, events_html)

    def _build_html(self, cards: str, events_html: str) -> str:
        """组装完整HTML"""
        summary = self.tracker.summary()
        events_count = len(self.tracker.get_recent_events(20))

        html = """<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><title>竞品情报报告</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,'Segoe UI',sans-serif;background:#0d1117;color:#c9d1d9;max-width:1200px;margin:20px auto;padding:0 20px}
h1,h2{color:#f0f6fc;border-bottom:1px solid #30363d;padding-bottom:10px;margin:20px 0 15px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin:15px 0}
.stat-card{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:15px}
.stat-card .v{font-size:24px;font-weight:700}
.stat-card .l{font-size:12px;color:#8b949e}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:15px}
.card{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:15px}
.card h3{font-size:15px;margin-bottom:10px;color:#f0f6fc}
.badge{display:inline-block;font-size:10px;padding:1px 6px;border-radius:3px;background:#21262d;color:#8b949e;vertical-align:middle}
.row{display:flex;justify-content:space-between;padding:4px 0;font-size:13px;border-bottom:1px solid #21262d}
.row .label{color:#8b949e}
.stat-good{color:#3fb950}
.stat-warn{color:#d29922}
.stat-bad{color:#f85149}
.evt{display:flex;align-items:center;gap:8px;padding:8px 12px;background:#161b22;border:1px solid #30363d;border-radius:6px;margin-bottom:4px;font-size:13px}
.evt-icon{font-size:16px}
.evt-title{flex:1;color:#f0f6fc}
.evt-time{color:#8b949e;font-size:11px}
.footer{text-align:center;padding:20px;color:#8b949e;font-size:12px}
</style></head>
<body>
    <h1>竞品情报报告</h1>
    <p style="color:#8b949e;margin-bottom:20px">时间: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """</p>
    <div class="stats">
        <div class="stat-card"><div class="v">""" + str(summary['total_competitors']) + """</div><div class="l">追踪竞品</div></div>
        <div class="stat-card"><div class="v" style="color:#58a6ff">""" + str(summary['total_events']) + """</div><div class="l">情报事件</div></div>
        <div class="stat-card"><div class="v" style="color:#f85149">""" + str(summary['high_risk_count']) + """</div><div class="l">高威胁竞品</div></div>
        <div class="stat-card"><div class="v">""" + str(summary['sources_monitored']) + """</div><div class="l">数据源</div></div>
    </div>
    <h2>竞品画像</h2>
    <div class="grid">""" + cards + """</div>
    <h2>最新情报 (""" + str(events_count) + """)</h2>
    """ + (events_html if events_html else '<p style="color:#8b949e">暂无情报事件</p>') + """
    <div class="footer">SentriKit 竞品情报模块</div>
</body></html>"""
        return html

    def save_report(self, output_dir: str = ".", fmt: str = "html") -> str:
        """保存报告到文件，返回文件路径。"""
        from pathlib import Path
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if fmt == "html":
            content = self.to_html()
            fname = f"compintel-report-{timestamp}.html"
        else:
            content = self.to_markdown()
            fname = f"compintel-report-{timestamp}.md"

        fpath = out / fname
        fpath.write_text(content, encoding="utf-8")
        return str(fpath)
