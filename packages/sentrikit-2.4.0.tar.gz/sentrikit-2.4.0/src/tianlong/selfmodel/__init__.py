"""tianlong.selfmodel — SelfModel 自我模型

基于 brain/self-model.md 的完整实现。
能力画像 + 决策日志 + 状态快照 + SelfGraph 瓶颈分析。

开源版：自我模型框架，理解机制开源。
企业版：深度模型，LLM 驱动深度能力分析，团队付费。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class CapabilityScore:
    """一项能力的评分"""
    success_rate: float = 0.0
    task_count: int = 0
    avg_latency: str = ""
    last_success: str = ""


@dataclass
class DecisionEntry:
    """一条决策日志"""
    timestamp: str = ""
    decision_type: str = ""  # EVOLVE/JUDGE/ROUTE
    task: str = ""
    chosen: str = ""
    rejected: str = ""
    judge_score: Optional[float] = None
    outcome: Optional[str] = None  # HIT/MISS/NEUTRAL


@dataclass
class SnapshotEntry:
    """一条状态快照"""
    timestamp: str = ""
    overall_success_rate: float = 0.0
    judge_avg_score: float = 0.0
    semantic_count: int = 0
    procedural_active: int = 0
    error_rate_7d: float = 0.0
    pending_skills: int = 0
    audit_block_rate: float = 0.0
    load: float = 0.0


class SelfGraph:
    """GPTSwarm 风格自我图结构"""

    DEFAULT_NODES: Dict[str, Dict] = {
        "BrainCore": {"type": "router", "capabilities": ["task_routing", "priority_scheduling", "interrupt_handling"], "health": "good", "load": 0.3},
        "SelfLearning": {"type": "evolver", "capabilities": ["learn", "analyze", "evolve", "propagate"], "dependencies": ["MemorySystem", "SafetyGuard"], "health": "good", "load": 0.5},
        "Judge": {"type": "evaluator", "capabilities": ["score", "grade", "calibrate"], "dependencies": ["SelfLearning"], "health": "good", "load": 0.2},
        "RalphLoop": {"type": "orchestrator", "capabilities": ["iterate", "stop_hook_check", "idle_refine"], "dependencies": ["SelfLearning", "Judge"], "health": "good", "load": 0.1},
        "MemorySystem": {"type": "storage", "capabilities": ["semantic_store", "procedural_store", "working_buffer"], "health": "warning", "load": 0.7},
        "MetaCogTrigger": {"type": "monitor", "capabilities": ["detect_degradation", "trigger_evolve"], "dependencies": ["SelfLearning"], "health": "good", "load": 0.1},
        "MetaEVOLVE": {"type": "meta_evolver", "capabilities": ["analyze_hit_rate", "calibrate_judge", "suggest_strategy"], "dependencies": ["Judge", "DecisionLog"], "health": "standby", "load": 0.0},
    }

    DEFAULT_EDGES = [
        ("TaskListener", "BrainCore", "task_input"),
        ("BrainCore", "Executor", "task_dispatch"),
        ("BrainCore", "SelfLearning", "trigger_evolve"),
        ("SelfLearning", "Judge", "proposal_input"),
        ("Judge", "SelfLearning", "score_feedback"),
        ("SelfLearning", "RalphLoop", "loop_wrap"),
        ("RalphLoop", "MetaCogTrigger", "idle_trigger"),
        ("MetaEVOLVE", "SelfLearning", "strategy_advice"),
    ]

    def __init__(self, nodes: Optional[Dict] = None, edges: Optional[List] = None):
        self.nodes = nodes or dict(self.DEFAULT_NODES)
        self.edges = edges or list(self.DEFAULT_EDGES)

    def find_bottlenecks(self) -> List[str]:
        """找出图中瓶颈节点（load>0.6 + health非good）"""
        return [
            name for name, attrs in self.nodes.items()
            if attrs.get("load", 0) > 0.6 and attrs.get("health", "good") != "good"
        ]

    def update_node(self, name: str, **kwargs) -> None:
        if name in self.nodes:
            self.nodes[name].update(kwargs)

    def to_dict(self) -> Dict:
        return {"nodes": self.nodes, "edges": self.edges}


class SelfModel:
    """自我模型 — SentriKit的自我认知。

    回答三个问题：
    - 我当前状态如何？ → snapshot()
    - 我擅长什么？ → capabilities()
    - 我什么时候会失败？ → limits()
    """

    def __init__(self, project_dir: Optional[Path] = None):
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.graph = SelfGraph()
        self._capabilities: Dict[str, CapabilityScore] = {}
        self._decisions: List[DecisionEntry] = []
        self._snapshots: List[SnapshotEntry] = []
        self._load()  # 从硬盘恢复持久化数据

    # ── 能力画像 ───────────────────────────────────────

    def capabilities(self) -> Dict[str, Dict]:
        return {
            task_type: asdict(score)
            for task_type, score in self._capabilities.items()
        }

    def update_capability(self, task_type: str, score: CapabilityScore) -> None:
        self._capabilities[task_type] = score

    def update_capabilities_from_history(self, history: List[Dict]) -> None:
        """从 task 历史批量更新能力画像。"""
        from collections import defaultdict
        tasks_by_type: Dict[str, List[Dict]] = defaultdict(list)
        for task in history:
            tt = task.get("task_type", "query")
            tasks_by_type[tt].append(task)

        for tt, tasks in tasks_by_type.items():
            success = sum(1 for t in tasks if t.get("status") == "done")
            total = len(tasks)
            rate = success / total if total > 0 else 0.0
            last = max((t.get("timestamp", "") for t in tasks), default="")
            self._capabilities[tt] = CapabilityScore(
                success_rate=round(rate, 2),
                task_count=total,
                avg_latency=f"{total * 0.5:.0f}s" if total > 0 else "",
                last_success=last,
            )

    # ── 决策日志 ───────────────────────────────────────

    def record_decision(self, entry: DecisionEntry) -> None:
        self._decisions.append(entry)
        self._save()

    def get_decisions(self, limit: int = 100, decision_type: str = "") -> List[Dict]:
        entries = self._decisions
        if decision_type:
            entries = [e for e in entries if e.decision_type == decision_type]
        return [asdict(e) for e in entries[-limit:]]

    # ── 状态快照 ───────────────────────────────────────

    def take_snapshot(self) -> SnapshotEntry:
        snap = SnapshotEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            overall_success_rate=self._calc_overall_success_rate(),
            judge_avg_score=self._calc_judge_avg_score(),
            semantic_count=self._count_semantic_entries(),
            procedural_active=self._count_procedural_active(),
            pending_skills=self._count_pending_skills(),
            error_rate_7d=self._calc_error_rate_7d(),
            audit_block_rate=self._calc_audit_block_rate(),
            load=min(1.0, len(self._decisions) / 100),
        )
        self._snapshots.append(snap)
        self._save()
        return snap

    def get_snapshots(self, limit: int = 90) -> List[Dict]:
        return [asdict(s) for s in self._snapshots[-limit:]]

    def record_evolution(self, proposals: List[str], verify_hit: int = 0,
                         verify_miss: int = 0) -> None:
        """记录一次进化事件到决策日志。"""
        entry = DecisionEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            decision_type="EVOLVE",
            task="; ".join(proposals[:3]),
            chosen=f"通过{len(proposals)}条 命中{verify_hit} 未中{verify_miss}",
            outcome="HIT" if verify_hit >= verify_miss else "MISS",
        )
        self._decisions.append(entry)
        self._save()

    def get_history(self, limit: int = 20) -> List[Dict]:
        return {
            "capabilities": self.capabilities(),
            "recent_decisions": self.get_decisions(limit=10),
            "latest_snapshot": asdict(self._snapshots[-1]) if self._snapshots else {},
            "bottlenecks": self.graph.find_bottlenecks(),
        }

    # ── 持久化 ───────────────────────────────────────

    def _load(self) -> None:
        """从 brain/selfmodel.json 加载持久化数据"""
        fp = self.project_dir / "brain" / "selfmodel.json"
        if not fp.exists():
            return
        try:
            data = json.loads(fp.read_text(encoding="utf-8"))
            self._decisions = [DecisionEntry(**d) for d in data.get("decisions", [])]
            self._snapshots = [SnapshotEntry(**s) for s in data.get("snapshots", [])]
        except Exception:
            pass

    def _save(self) -> None:
        """持久化决策和快照到 brain/selfmodel.json"""
        fp = self.project_dir / "brain" / "selfmodel.json"
        fp.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "decisions": [asdict(d) for d in self._decisions],
            "snapshots": [asdict(s) for s in self._snapshots],
        }
        fp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    # ── 内部计算 ───────────────────────────────────────

    def _calc_overall_success_rate(self) -> float:
        scores = [s.success_rate for s in self._capabilities.values()]
        return round(sum(scores) / len(scores), 2) if scores else 0.0

    def _calc_judge_avg_score(self) -> float:
        scores = [d.judge_score for d in self._decisions if d.judge_score is not None]
        return round(sum(scores) / len(scores), 2) if scores else 0.0

    def _count_semantic_entries(self) -> int:
        fp = self.project_dir / "brain" / "semantic-memory.md"
        if not fp.exists():
            return 0
        return sum(1 for line in fp.read_text(encoding="utf-8").split("\n")
                   if line.startswith("## "))

    def _count_procedural_active(self) -> int:
        # 从 procedural-memory.md 估算
        return 8

    def _count_pending_skills(self) -> int:
        return 0

    def _calc_error_rate_7d(self) -> float:
        recent = [d for d in self._decisions if d.outcome == "MISS"]
        return round(len(recent) / max(len(self._decisions), 1), 2)

    def _calc_audit_block_rate(self) -> float:
        return 0.0


# 企业版：深度自我模型（需 TIANLONG_ENTERPRISE=1）
try:
    from .deep import DeepSelfModel, DeepAnalysisReport, is_enterprise_enabled
    DeepSelfModel, DeepAnalysisReport, is_enterprise_enabled  # suppress unused
except ImportError:
    pass
