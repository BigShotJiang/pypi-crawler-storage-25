"""tianlong.selfmodel.deep — DeepSelfModel 深度自我模型

企业版功能：通过 TIANLONG_ENTERPRISE=1 激活。
基于 LLM 的深度能力分析引擎，在开源版 SelfModel 框架之上提供：

1. 深度能力洞察 — LLM 分析能力画像，生成自然语言洞察（优势/劣势/趋势）
2. 能力衰退预测 — 基于历史快照预测各项能力的衰退趋势
3. 进化方向建议 — 根据瓶颈+能力趋势推荐进化优先级

用法:
    from tianlong.selfmodel.deep import DeepSelfModel

    deep = DeepSelfModel()
    insights = deep.analyze_capabilities(self_model)
    prediction = deep.predict_decline(self_model)
    suggestions = deep.suggest_evolution(self_model)
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.request import Request, urlopen
from urllib.error import URLError

from . import SelfModel, CapabilityScore, SnapshotEntry


# ── 企业版门控 ─────────────────────────────────────────

def is_enterprise_enabled() -> bool:
    return os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes")


def require_enterprise() -> None:
    if not is_enterprise_enabled():
        raise RuntimeError("深度自我模型需要企业版授权（TIANLONG_ENTERPRISE=1）")


# ── LLM 调用器 ────────────────────────────────────────

_DEFAULT_MODEL = "deepseek-chat"
_DEFAULT_BASE_URL = "https://api.deepseek.com/v1"


def _get_llm_config() -> dict:
    """获取 LLM 配置（环境变量优先）。"""
    return {
        "api_key": (os.environ.get("DEEPSEEK_API_KEY", "")
                    or os.environ.get("OPENAI_API_KEY", "")),
        "base_url": os.environ.get("LLM_BASE_URL", _DEFAULT_BASE_URL),
        "model": os.environ.get("LLM_MODEL", _DEFAULT_MODEL),
    }


def _call_llm(system_prompt: str, user_prompt: str, timeout: int = 30) -> Optional[str]:
    """调用 LLM API（零依赖 urllib 实现）。"""
    cfg = _get_llm_config()
    if not cfg["api_key"]:
        return None

    payload = json.dumps({
        "model": cfg["model"],
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.3,
        "max_tokens": 2048,
    }).encode("utf-8")

    try:
        req = Request(
            f"{cfg['base_url']}/chat/completions",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {cfg['api_key']}",
            },
            method="POST",
        )
        resp = urlopen(req, timeout=timeout)
        result = json.loads(resp.read().decode("utf-8"))
        return result.get("choices", [{}])[0].get("message", {}).get("content", "")
    except Exception:
        return None


def _extract_json(text: Optional[str]) -> Optional[Dict]:
    """从 LLM 返回中提取 JSON。"""
    if not text:
        return None
    text = text.strip()
    text = re.sub(r"^```json\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{[\s\S]*\}", text)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                return None
        return None


# ── 输出数据类型 ──────────────────────────────────────


@dataclass
class CapabilityInsight:
    """一项能力的深度洞察"""
    task_type: str = ""
    strength: str = ""               # 优势描述
    weakness: str = ""               # 劣势描述
    trend: str = "stable"            # rising / stable / declining
    confidence: float = 0.0          # 洞察置信度 0-1
    suggestion: str = ""             # 改进建议

    def to_dict(self) -> Dict:
        return {
            "task_type": self.task_type,
            "strength": self.strength,
            "weakness": self.weakness,
            "trend": self.trend,
            "confidence": self.confidence,
            "suggestion": self.suggestion,
        }


@dataclass
class DeclinePrediction:
    """一项能力的衰退预测"""
    task_type: str = ""
    days_to_decline: int = 0         # 预计多少天后衰退
    risk_level: str = "low"          # low / medium / high
    reason: str = ""                 # 预测依据
    recommended_action: str = ""     # 建议行动

    def to_dict(self) -> Dict:
        return {
            "task_type": self.task_type,
            "days_to_decline": self.days_to_decline,
            "risk_level": self.risk_level,
            "reason": self.reason,
            "recommended_action": self.recommended_action,
        }


@dataclass
class EvolutionSuggestion:
    """一条进化方向建议"""
    priority: int = 0
    category: str = ""               # capability / safety / efficiency
    suggestion: str = ""
    expected_impact: str = ""
    effort: str = "medium"           # low / medium / high
    source: str = ""                 # 建议来源（瓶颈/衰退/趋势）

    def to_dict(self) -> Dict:
        return {
            "priority": self.priority,
            "category": self.category,
            "suggestion": self.suggestion,
            "expected_impact": self.expected_impact,
            "effort": self.effort,
            "source": self.source,
        }


@dataclass
class DeepAnalysisReport:
    """一次深度分析的完整报告"""
    timestamp: str = ""
    capabilities_insights: List[CapabilityInsight] = field(default_factory=list)
    decline_predictions: List[DeclinePrediction] = field(default_factory=list)
    evolution_suggestions: List[EvolutionSuggestion] = field(default_factory=list)
    llm_available: bool = False
    errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "capabilities_insights": [i.to_dict() for i in self.capabilities_insights],
            "decline_predictions": [p.to_dict() for p in self.decline_predictions],
            "evolution_suggestions": [s.to_dict() for s in self.evolution_suggestions],
            "llm_available": self.llm_available,
            "errors": self.errors,
        }

    def summary_line(self) -> str:
        parts = [
            f"深度洞察{len(self.capabilities_insights)}项",
            f"衰退预测{len(self.decline_predictions)}项",
            f"进化建议{len(self.evolution_suggestions)}条",
        ]
        if self.errors:
            parts.append(f"错误:{len(self.errors)}")
        return " | ".join(parts)


# ── 深度模型引擎 ──────────────────────────────────────


class DeepSelfModel:
    """深度自我模型引擎。

    企业版功能：本类所有公共方法都需要 TIANLONG_ENTERPRISE=1。
    在开源版 SelfModel 框架之上提供 LLM 驱动的深度分析。
    """

    def __init__(self):
        require_enterprise()
        self._llm_available = bool(_get_llm_config()["api_key"])

    # ── 1. 深度能力洞察 ─────────────────────────────────

    def analyze_capabilities(self, model: SelfModel) -> List[CapabilityInsight]:
        """LLM 驱动：分析能力画像，生成自然语言洞察。

        Args:
            model: 开源版 SelfModel 实例（提供能力数据）

        Returns:
            每个能力的深度洞察列表
        """
        if not self._llm_available:
            return self._fallback_insights(model)

        caps = model.capabilities()
        if not caps:
            return []

        prompt = self._build_insight_prompt(caps)
        result = _call_llm(
            "你是一位 AI Agent 能力分析师。分析以下能力数据，输出 JSON。",
            prompt,
        )
        parsed = _extract_json(result)
        if parsed and "insights" in parsed:
            return [
                CapabilityInsight(**i) for i in parsed["insights"]
                if isinstance(i, dict)
            ]

        return self._fallback_insights(model)

    def _build_insight_prompt(self, capabilities: Dict) -> str:
        lines = ["分析以下 Agent 的能力画像数据，输出 JSON 格式的分析结果。", ""]
        for tt, data in capabilities.items():
            lines.append(f"- {tt}: 成功率{data.get('success_rate', 0)*100:.0f}% "
                         f"任务{data.get('task_count', 0)}次 "
                         f"最后成功{data.get('last_success', '未知')}")

        lines.extend([
            "",
            "输出格式:",
            '{"insights": [',
            '  {"task_type": "...", "strength": "优势描述", "weakness": "劣势描述",',
            '   "trend": "rising/stable/declining", "confidence": 0.0-1.0,',
            '   "suggestion": "改进建议"}',
            "]}",
        ])
        return "\n".join(lines)

    def _fallback_insights(self, model: SelfModel) -> List[CapabilityInsight]:
        """LLM 不可用时的规则降级。"""
        caps = model.capabilities()
        insights = []
        for tt, data in caps.items():
            sr = data.get("success_rate", 0)
            tc = data.get("task_count", 0)
            trend = "stable"

            if tc >= 5:
                if sr >= 0.8:
                    trend = "rising"
                    strength = f"{tt}任务成功率高达{sr*100:.0f}%，表现稳健"
                    weakness = f"数据量偏少（{tc}次），统计意义有限"
                elif sr >= 0.5:
                    trend = "stable"
                    strength = f"{tt}任务中等水平（{sr*100:.0f}%）"
                    weakness = "有改进空间"
                else:
                    trend = "declining"
                    strength = ""
                    weakness = f"{tt}任务成功率仅{sr*100:.0f}%，需关注"

                insights.append(CapabilityInsight(
                    task_type=tt,
                    strength=strength,
                    weakness=weakness,
                    trend=trend,
                    confidence=min(0.5, tc / 20),
                    suggestion=f"建议增加{tt}类型任务的执行频率以积累数据",
                ))
        return insights

    # ── 2. 能力衰退预测 ─────────────────────────────────

    def predict_decline(self, model: SelfModel) -> List[DeclinePrediction]:
        """LLM 驱动：基于历史快照预测能力衰退。

        Args:
            model: 开源版 SelfModel 实例（提供快照历史）

        Returns:
            每个高风险能力的衰退预测
        """
        snapshots = model.get_snapshots()
        if not snapshots:
            return []

        predictions: List[DeclinePrediction] = []

        # 2a. LLM 分析趋势
        if self._llm_available and len(snapshots) >= 3:
            prompt = self._build_decline_prompt(snapshots)
            result = _call_llm(
                "你是一位 AI Agent 能力衰退分析师。分析以下快照趋势，输出 JSON。",
                prompt,
            )
            parsed = _extract_json(result)
            if parsed and "predictions" in parsed:
                return [
                    DeclinePrediction(**p) for p in parsed["predictions"]
                    if isinstance(p, dict)
                ]

        # 2b. 规则降级
        if len(snapshots) >= 2:
            latest = snapshots[-1]
            prev = snapshots[-2]

            if latest.get("overall_success_rate", 1) < prev.get("overall_success_rate", 1):
                predictions.append(DeclinePrediction(
                    task_type="综合能力",
                    days_to_decline=14,
                    risk_level="medium",
                    reason=f"整体成功率从{prev.get('overall_success_rate',0)*100:.0f}% "
                           f"下降到{latest.get('overall_success_rate',0)*100:.0f}%",
                    recommended_action="检查最近变更、增加回归测试",
                ))
            if latest.get("error_rate_7d", 0) > 0.3:
                predictions.append(DeclinePrediction(
                    task_type="执行稳定性",
                    days_to_decline=7,
                    risk_level="high",
                    reason=f"近7天错误率{latest.get('error_rate_7d',0)*100:.0f}%",
                    recommended_action="立即审查 error-log 中的待处理错误",
                ))

        return predictions

    def _build_decline_prompt(self, snapshots: List[Dict]) -> str:
        lines = ["分析以下 Agent 快照趋势，预测哪些能力可能衰退。", ""]
        for s in snapshots[-5:]:  # 最近 5 条
            lines.append(
                f"- {s.get('timestamp','')[:16]}: "
                f"成功率{s.get('overall_success_rate',0)*100:.0f}% "
                f"Judge均分{s.get('judge_avg_score',0):.2f} "
                f"错误率{s.get('error_rate_7d',0)*100:.0f}%"
            )
        lines.extend([
            "",
            "输出 JSON:",
            '{"predictions": [',
            '  {"task_type": "能力名称", "days_to_decline": 7,',
            '   "risk_level": "high/medium/low", "reason": "依据",',
            '   "recommended_action": "建议"}',
            "]}",
        ])
        return "\n".join(lines)

    # ── 3. 进化方向建议 ─────────────────────────────────

    def suggest_evolution(self, model: SelfModel) -> List[EvolutionSuggestion]:
        """LLM 驱动：根据瓶颈+能力趋势推荐进化优先级。

        Args:
            model: 开源版 SelfModel 实例

        Returns:
            按优先级排序的进化建议列表
        """
        suggestions: List[EvolutionSuggestion] = []

        # 3a. 从瓶颈分析生成建议
        bottlenecks = model.graph.find_bottlenecks()
        for i, bn in enumerate(bottlenecks):
            suggestions.append(EvolutionSuggestion(
                priority=i + 1,
                category="efficiency",
                suggestion=f"优化 {bn} 节点性能（当前负载 > 0.6）",
                expected_impact="降低系统瓶颈，提升整体响应速度",
                effort="medium",
                source="bottleneck_analysis",
            ))

        # 3b. 从能力画像生成建议
        caps = model.capabilities()
        low_performers = [
            (tt, d) for tt, d in caps.items()
            if d.get("success_rate", 1) < 0.6
        ]
        for i, (tt, data) in enumerate(low_performers):
            suggestions.append(EvolutionSuggestion(
                priority=len(bottlenecks) + i + 1,
                category="capability",
                suggestion=f"提升 {tt} 能力（成功率仅{data.get('success_rate',0)*100:.0f}%）",
                expected_impact=f"{tt}任务成功率提升至80%以上",
                effort="medium",
                source="capability_weakness",
            ))

        # 3c. LLM 补充建议
        if self._llm_available and suggestions:
            prompt = self._build_suggest_prompt(bottlenecks, caps)
            result = _call_llm(
                "你是一位 AI Agent 进化策略师。基于以下分析，补充进化建议。",
                prompt,
            )
            parsed = _extract_json(result)
            if parsed and "suggestions" in parsed:
                for s in parsed["suggestions"]:
                    if isinstance(s, dict):
                        suggestions.append(EvolutionSuggestion(**s))

        # 按优先级排序
        suggestions.sort(key=lambda s: s.priority)
        return suggestions

    def _build_suggest_prompt(self, bottlenecks: List[str], caps: Dict) -> str:
        lines = ["基于以下数据，补充 2-3 条进化建议。", ""]
        if bottlenecks:
            lines.append(f"瓶颈节点: {', '.join(bottlenecks)}")
        for tt, data in caps.items():
            sr = data.get("success_rate", 0)
            tc = data.get("task_count", 0)
            lines.append(f"- {tt}: 成功率{sr*100:.0f}% 任务{tc}次")
        lines.extend([
            "",
            '输出 JSON: {"suggestions": [',
            '  {"priority": 3, "category": "safety/efficiency/capability",',
            '   "suggestion": "建议内容", "expected_impact": "预期效果",',
            '   "effort": "low/medium/high", "source": "llm_analysis"}',
            "]}",
        ])
        return "\n".join(lines)

    # ── 入口 ───────────────────────────────────────────

    def run_deep_analysis(self, model: SelfModel) -> DeepAnalysisReport:
        """执行一次完整的深度分析。

        三步一体：洞察 + 预测 + 建议。

        Args:
            model: 开源版 SelfModel 实例

        Returns:
            深度分析报告
        """
        report = DeepAnalysisReport(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            llm_available=self._llm_available,
        )

        try:
            report.capabilities_insights = self.analyze_capabilities(model)
        except Exception as e:
            report.errors.append(f"洞察分析失败: {e}")

        try:
            report.decline_predictions = self.predict_decline(model)
        except Exception as e:
            report.errors.append(f"衰退预测失败: {e}")

        try:
            report.evolution_suggestions = self.suggest_evolution(model)
        except Exception as e:
            report.errors.append(f"进化建议失败: {e}")

        return report
