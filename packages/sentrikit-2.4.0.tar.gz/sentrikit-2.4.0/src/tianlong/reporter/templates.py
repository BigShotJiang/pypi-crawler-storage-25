"""tianlong.reporter.templates — 4种汇报模板

对应 brain/reporter.md 的4个模板：
1. 标准汇报（任务完成）
2. 高价值发现（立即推送）
3. 紧急预警
4. 定时摘要

+ 集成仪表盘格式的全景汇报
"""

from __future__ import annotations

from typing import Dict, List, Optional

from .types import (
    ReportContent, ReportTrigger,
    MonitorReportData, SafetyReportData,
    JudgeReportData, EvolutionReportData,
    UxuScoreReportData, DGMHReportData,
)


def render_standard(content: ReportContent) -> str:
    """标准汇报 — 任务完成。"""
    lines = [f"📌 {content.title} - 完成"]
    if content.body:
        lines.append(f"- 结果：{content.body}")
    if content.highlights:
        lines.append("- 关键发现：")
        for h in content.highlights[:3]:
            lines.append(f"  · {h}")
    if content.action_items:
        lines.append("→ 下一步：")
        for a in content.action_items[:2]:
            lines.append(f"  · {a}")
    # 附加各模块数据
    extra = _module_summary_lines(content)
    if extra:
        lines.append("")
        lines.extend(extra)
    return "\n".join(lines)


def render_highlight(content: ReportContent) -> str:
    """高价值发现 — 立即推送。"""
    lines = [f"🔥 高价值发现：{content.title}"]
    if content.body:
        lines.append(f"- 发现：{content.body}")
    if content.highlights:
        lines.append("- 价值：")
        for h in content.highlights[:2]:
            lines.append(f"  · {h}")
    if content.action_items:
        lines.append("→ 建议：")
        for a in content.action_items[:2]:
            lines.append(f"  · {a}")
    return "\n".join(lines)


def render_alert(content: ReportContent) -> str:
    """紧急预警。"""
    lines = [f"⚠️ 紧急：{content.title}"]
    lines.append(f"- 现状：{content.body or '需关注'}")
    if content.highlights:
        lines.append("- 影响：")
        for h in content.highlights[:2]:
            lines.append(f"  · {h}")
    if content.action_items:
        lines.append("→ 需要立即：")
        for a in content.action_items[:2]:
            lines.append(f"  · {a}")
    # 退化信息
    if content.evolution and content.evolution.degradation_warnings:
        lines.append("")
        lines.append("退化详情：")
        for w in content.evolution.degradation_warnings[:3]:
            lines.append(f"  ⚠️ {w}")
    return "\n".join(lines)


def render_milestone(content: ReportContent) -> str:
    """进化里程碑。"""
    lines = ["🧬 进化里程碑"]
    lines.append(f"{'='*40}")
    lines.append(f"事件：{content.title}")
    if content.body:
        lines.append(f"详情：{content.body}")
    if content.judge:
        lines.append(f"")
        lines.append(f"【进化指标】{content.judge.summary_line}")
        if content.judge.highlights:
            lines.append("亮点：")
            for h in content.judge.highlights[:2]:
                lines.append(f"  ✅ {h}")
    return "\n".join(lines)


def render_summary(
    title: str,
    monitor_data: Optional[MonitorReportData] = None,
    safety_data: Optional[SafetyReportData] = None,
    judge_data: Optional[JudgeReportData] = None,
    evolution_data: Optional[EvolutionReportData] = None,
    highlights: Optional[List[str]] = None,
    action_items: Optional[List[str]] = None,
) -> str:
    """定时摘要 — 3小时周期汇报。"""
    lines = [f"📊 {title}"]
    lines.append(f"{'='*45}")

    # Monitor
    if monitor_data:
        icon = {"healthy": "✅", "warning": "⚠️", "error": "🔴"}.get(monitor_data.overall, "❓")
        lines.append(f"健康监控：{icon} {monitor_data.summary_line}")

    # Safety
    if safety_data:
        lines.append(f"安全约束：{safety_data.summary_line}")

    # Judge / Evolution
    if judge_data:
        lines.append(f"进化评估：{judge_data.summary_line}")
    if evolution_data:
        lines.append(f"进化闭环：{evolution_data.summary_line}")

    # Highlights
    if highlights:
        lines.append("")
        lines.append("最近亮点：")
        for h in highlights[:2]:
            lines.append(f"  ✅ {h}")

    # Action items
    if action_items:
        lines.append("")
        lines.append("待关注：")
        for a in action_items[:3]:
            lines.append(f"  📌 {a}")

    return "\n".join(lines)


# ── 多模块聚合 ─────────────────────────────────────────


def render_full_report(content: ReportContent) -> str:
    """根据触发类型选择合适的模板渲染。"""
    trigger_map = {
        ReportTrigger.TASK_DONE.value: render_standard,
        ReportTrigger.HIGHLIGHT.value: render_highlight,
        ReportTrigger.ALERT.value: render_alert,
        ReportTrigger.MILESTONE.value: render_milestone,
        ReportTrigger.SUMMARY.value: _render_summary_from_content,
    }
    renderer = trigger_map.get(content.trigger, render_standard)
    text = renderer(content)

    # 开源版添加品牌水印，企业版不添加
    _remove_branding = __import__("os").environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes")
    if not _remove_branding:
        text += "\n\n---\n*由 🐉 SentriKit 开源版生成*"

    return text


def _render_summary_from_content(content: ReportContent) -> str:
    return render_summary(
        title=content.title or "枢御状态摘要",
        monitor_data=content.monitor,
        safety_data=content.safety,
        judge_data=content.judge,
        evolution_data=content.evolution,
        highlights=content.highlights,
        action_items=content.action_items,
    )


# ── 内部工具 ───────────────────────────────────────────


def _module_summary_lines(content: ReportContent) -> List[str]:
    """从各模块数据生成附加摘要行。"""
    lines: List[str] = []
    if content.monitor:
        lines.append(f"健康监控：{content.monitor.summary_line}")
    if content.safety:
        lines.append(f"安全约束：{content.safety.summary_line}")
    if content.judge:
        lines.append(f"进化评估：{content.judge.summary_line}")
    if content.evolution:
        lines.append(f"进化闭环：{content.evolution.summary_line}")
    if content.uxu_score:
        lines.append(f"安全扫描：{content.uxu_score.summary_line}")
    if content.dgmh:
        lines.append(f"元认知：{content.dgmh.summary_line}")
    return lines


# ── CodeVigil 扫描渲染 ────────────────────────────────────


def render_uxu_scan(data: UxuScoreReportData) -> str:
    """CodeVigil 安全扫描 v2 报告。"""
    lines = [
        "| 指标 | 值 |",
        "|------|-----|",
        f"| 综合等级 | {data.grade} |",
        f"| 总分 | {data.total:.1f}/100 |",
        f"| IS (输入消毒) | {data.is_score:.1f} |",
        f"| SI (沙箱隔离) | {data.si_score:.1f} |",
        f"| PM (权限最小化) | {data.pm_score:.1f} |",
        f"| 最弱环节 | {data.weakest_pillar} |",
        f"| 发现总数 | {data.total_findings} |",
    ]
    if data.findings_by_severity:
        sev = data.findings_by_severity
        lines.append(f"| 严重: {sev.get('critical',0)} 高: {sev.get('high',0)} 中: {sev.get('medium',0)} 低: {sev.get('low',0)} |")
    return "\n".join(lines)


# ── DGM-H 元认知渲染 ────────────────────────────────


def render_dgmh_report(data: DGMHReportData) -> str:
    """DGM-H 元认知状态报告。"""
    lines = [
        "| 维度 | 状态 |",
        "|------|------|",
        f"| Phase 1 (MetaCog) | {'✅' if data.phase1_active else '❌'} |",
        f"| Phase 2 (MetaEVOLVE) | {'✅' if data.phase2_active else '❌'} |",
        f"| Phase 3 (完整元认知) | {'✅' if data.phase3_active else '❌'} |",
        f"| 命中率 | {data.hit_rate:.1%} |",
        f"| MISS率 | {data.miss_rate:.1%} |",
        f"| 总修改 | {data.total_changes}次 |",
        f"| 策略建议 | {data.suggestions_count}条 |",
        f"| 护栏阻止 | {data.shielded_count}条 |",
        f"| 决策记录 | {data.decision_count}条 |",
        f"| 能力画像 | {data.capability_count}个 |",
    ]
    if data.weakest_pillar:
        lines.append(f"| 最弱Pillar | {data.weakest_pillar} |")
    return "\n".join(lines)


# ── 每日仪表盘 ──────────────────────────────────────


def render_daily_dashboard(
    monitor_data: Optional[MonitorReportData] = None,
    judge_data: Optional[JudgeReportData] = None,
    uxu_data: Optional[UxuScoreReportData] = None,
    dgmh_data: Optional[DGMHReportData] = None,
    highlights: Optional[List[str]] = None,
    action_items: Optional[List[str]] = None,
) -> str:
    """📋 每日聚合仪表盘 — 所有模块状态一行。"""
    lines = [
        "## 📊 综合状态面板",
        "",
        "### 健康监控",
        f"{'✅' if monitor_data and monitor_data.overall in ('healthy','ok') else '⚠️'} {monitor_data.summary_line if monitor_data else '无数据'}",
        "",
    ]
    if judge_data:
        lines.append("### 进化评估")
        lines.append(f"{judge_data.summary_line}")
        lines.append("")
    if uxu_data:
        lines.append("### 安全扫描")
        lines.append(f"| 等级 | 总分 | IS | SI | PM | 最弱 | 发现 |")
        lines.append(f"|------|------|----|----|----|------|------|")
        lines.append(f"| {uxu_data.grade} | {uxu_data.total:.0f} | {uxu_data.is_score:.0f} | {uxu_data.si_score:.0f} | {uxu_data.pm_score:.0f} | {uxu_data.weakest_pillar} | {uxu_data.total_findings} |")
        lines.append("")
    if dgmh_data:
        lines.append("### 元认知")
        lines.append(f"Phase{'✅' if dgmh_data.phase3_active else '❌'} | 命中率{dgmh_data.hit_rate:.0%} | 建议{dgmh_data.suggestions_count}条 | 修改{dgmh_data.total_changes}次")
        lines.append("")
    if highlights:
        lines.append("### 今日亮点")
        for h in highlights:
            lines.append(f"- ✅ {h}")
        lines.append("")
    if action_items:
        lines.append("### 待办")
        for a in action_items:
            lines.append(f"- [ ] {a}")
    return "\n".join(lines)
