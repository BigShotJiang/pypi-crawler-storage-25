"""tianlong.reporter.__main__ — `python -m tianlong.reporter` 入口"""
from .cli import main
import sys
sys.exit(main())
