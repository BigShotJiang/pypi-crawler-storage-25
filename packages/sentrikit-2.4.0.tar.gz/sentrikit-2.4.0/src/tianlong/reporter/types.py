"""tianlong.reporter.types — 汇报数据模型

4种触发类型 + 各模块数据收集的结构化定义。
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class ReportTrigger(Enum):
    """汇报触发类型"""
    HIGHLIGHT = "highlight"      # 🔥 高价值发现
    TASK_DONE = "task_done"      # ✅ 任务完成
    ALERT = "alert"              # ⚠️ 异常/风险
    MILESTONE = "milestone"      # 🧬 进化里程碑
    SUMMARY = "summary"          # ⏰ 定时摘要


@dataclass
class UxuScoreReportData:
    """从 uxu.score 模块收集的 v2 评分数据"""
    grade: str = "A"
    total: float = 100.0
    is_score: float = 100.0
    si_score: float = 100.0
    pm_score: float = 100.0
    weakest_pillar: str = ""
    total_findings: int = 0
    findings_by_severity: Dict[str, int] = field(default_factory=dict)

    @property
    def summary_line(self) -> str:
        return (f"等级{self.grade} 总分{self.total:.1f} "
                f"IS={self.is_score:.1f} SI={self.si_score:.1f} PM={self.pm_score:.1f} "
                f"发现{self.total_findings}条")


@dataclass
class DGMHReportData:
    """从 DGM-H / SelfModel / MetaEVOLVE 收集的元认知数据"""
    phase1_active: bool = True
    phase2_active: bool = False
    phase3_active: bool = False
    hit_rate: float = 0.0
    miss_rate: float = 0.0
    total_changes: int = 0
    suggestions_count: int = 0
    shielded_count: int = 0
    weakest_pillar: str = ""
    decision_count: int = 0
    capability_count: int = 0

    @property
    def summary_line(self) -> str:
        return (f"Phase1{'✅' if self.phase1_active else '❌'} "
                f"Phase2{'✅' if self.phase2_active else '❌'} "
                f"Phase3{'✅' if self.phase3_active else '❌'} "
                f"命中率{self.hit_rate:.0%} 建议{self.suggestions_count}条")


class ReportChannel(Enum):
    """汇报路由通道"""
    SESSION = "session"          # 当前 session 直接回复
    MESSAGE = "message"          # message 工具推送
    HEARTBEAT = "heartbeat"      # 静默状态回复
    DASHBOARD = "dashboard"      # 管理后台 API
    FILE = "file"                # 写入文件
    ALL = "all"                  # 全部通道


@dataclass
class MonitorReportData:
    """从 monitor 模块收集的数据"""
    overall: str = "unknown"
    checks_ok: int = 0
    checks_warning: int = 0
    checks_error: int = 0
    checks_total: int = 0

    @property
    def summary_line(self) -> str:
        return f"{self.overall.upper()} ({self.checks_ok}/{self.checks_total} 通过, warning={self.checks_warning}, error={self.checks_error})"


@dataclass
class SafetyReportData:
    """从 safety 模块收集的数据"""
    recent_checks: int = 0
    recent_blocked: int = 0
    degradation_count: int = 0
    is_paused: bool = False

    @property
    def summary_line(self) -> str:
        parts = [f"检查 {self.recent_checks} 次"]
        if self.recent_blocked:
            parts.append(f"阻止 {self.recent_blocked}")
        if self.is_paused:
            parts.append("已暂停 ⛔")
        return " | ".join(parts)


@dataclass
class JudgeReportData:
    """从 judge 模块收集的数据"""
    total_proposals: int = 0
    pass_rate: float = 0.0
    avg_score: float = 0.0
    overall_grade: str = "D"
    overall_health: str = "unknown"
    highlights: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    @property
    def summary_line(self) -> str:
        return f"等级{self.overall_grade} 通过率{self.pass_rate:.0%} 均分{self.avg_score:.2f}"


@dataclass
class EvolutionReportData:
    """从 evolution 模块收集的数据"""
    completed: bool = False
    approved_count: int = 0
    rejected_count: int = 0
    iteration: int = 1
    degradation_warnings: List[str] = field(default_factory=list)

    @property
    def summary_line(self) -> str:
        return f"完成:{self.completed} 通过:{self.approved_count} 拒绝:{self.rejected_count}"


@dataclass
class ReportContent:
    """一次汇报的完整内容"""
    trigger: str = "summary"
    title: str = ""
    body: str = ""
    highlights: List[str] = field(default_factory=list)
    action_items: List[str] = field(default_factory=list)

    # 各模块数据（可选）
    monitor: Optional[MonitorReportData] = None
    safety: Optional[SafetyReportData] = None
    judge: Optional[JudgeReportData] = None
    evolution: Optional[EvolutionReportData] = None
    uxu_score: Optional[UxuScoreReportData] = None       # UXU评分v2
    dgmh: Optional[DGMHReportData] = None                # DGM-H元认知
    channels: List[str] = field(default_factory=lambda: [ReportChannel.SESSION.value])

    def to_dict(self) -> Dict:
        d = asdict(self)
        return d

    def render(self) -> str:
        """渲染为最终文本。等价于调用模板 render。"""
        # 简单直出 body，复杂渲染由 templates.py 完成
        return self.body


@dataclass
class ReportLogEntry:
    """汇报日志条目"""
    timestamp: str = ""
    trigger: str = ""
    title: str = ""
    channel: str = "session"
    sent: bool = False


class RateLimitState:
    """频率控制状态"""

    def __init__(self):
        self._last_summary: Optional[str] = None
        self._reported_tasks: set[str] = set()

    def can_send_summary(self, now: Optional[str] = None) -> bool:
        """检查是否可以发送定时摘要（最多每3小时1次）。"""
        if self._last_summary is None:
            return True
        now = now or datetime.now().strftime("%Y-%m-%d %H:%M")
        try:
            last = datetime.strptime(self._last_summary[:16], "%Y-%m-%d %H:%M")
            current = datetime.strptime(now[:16], "%Y-%m-%d %H:%M")
            return (current - last).total_seconds() >= 10800  # 3h
        except ValueError:
            return True

    def mark_summary_sent(self, now: Optional[str] = None) -> None:
        self._last_summary = now or datetime.now().strftime("%Y-%m-%d %H:%M")

    def is_task_reported(self, task_id: str) -> bool:
        return task_id in self._reported_tasks

    def mark_task_reported(self, task_id: str) -> None:
        self._reported_tasks.add(task_id)
