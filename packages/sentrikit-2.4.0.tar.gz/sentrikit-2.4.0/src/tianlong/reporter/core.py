"""tianlong.reporter.core — Reporter 引擎

负责：
1. 收集各模块数据（monitor/safety/judge/evolution）
2. 选择合适的模板渲染
3. 频率控制（同一任务只汇报一次，摘要每3小时）
4. 日志记录

所有数据收集都是只读操作，不修改任何文件。
"""

from __future__ import annotations

from datetime import datetime
import os
from pathlib import Path
from typing import Dict, List, Optional

from .types import (
    ReportContent, ReportTrigger, ReportLogEntry, RateLimitState, ReportChannel,
    MonitorReportData, SafetyReportData,
    JudgeReportData, EvolutionReportData,
)
from .templates import render_full_report


class Reporter:
    """Reporter 引擎。

    从其他模块收集数据 -> 选择模板 -> 渲染文本。

    用法:
        reporter = Reporter()

        # 标准汇报
        text = reporter.report_task_done(
            title="优化搜索流程",
            body="完成，减少3步操作",
            highlights=["响应时间降低50%"],
        )

        # 高价值发现
        text = reporter.report_highlight(
            title="发现新模式",
            body="...",
        )

        # 紧急预警
        text = reporter.report_alert(
            title="SafetyGate连续阻止",
            body="3次审计阻止",
            evolution_data=evolve_data,
        )

        # 定时摘要（自动从各模块收集数据）
        text = reporter.report_summary(
            project_dir="/path/to/agent",
        )
    """

    def __init__(self, log_path: Optional[str] = None, remove_branding: Optional[bool] = None):
        self._log: List[ReportLogEntry] = []
        self._rate_limit = RateLimitState()
        self._log_path = Path(log_path) if log_path else None
        self._callbacks: Dict[str, List[callable]] = {}
        # 品牌水印控制：None=自动检测环境变量，True=去水印，False=保留
        self._remove_branding = remove_branding if remove_branding is not None else (
            os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes")
        )

    # ── 回调注册 ─────────────────────────────────────────

    def on(self, trigger: str, callback: callable) -> None:
        """注册回调，当指定 trigger 事件发生时自动调用。

        callback 签名: callback(content: ReportContent) -> None

        可用 trigger: task_done, highlight, alert, milestone, summary, *
        """
        if trigger not in self._callbacks:
            self._callbacks[trigger] = []
        self._callbacks[trigger].append(callback)

    def off(self, trigger: str, callback: Optional[callable] = None) -> None:
        """移除回调。不指定 callback 时移除该 trigger 全部。"""
        if trigger not in self._callbacks:
            return
        if callback is None:
            self._callbacks[trigger].clear()
        else:
            self._callbacks[trigger] = [cb for cb in self._callbacks[trigger] if cb != callback]

    def _trigger_callbacks(self, content: ReportContent) -> None:
        """触发所有匹配的回调。"""
        triggered = set()
        for cb in self._callbacks.get("*", []):
            try:
                cb(content)
            except Exception:
                pass
            triggered.add(id(cb))
        for cb in self._callbacks.get(content.trigger, []):
            if id(cb) not in triggered:
                try:
                    cb(content)
                except Exception:
                    pass

    # ── 多通道分发 ───────────────────────────────────

    @staticmethod
    def _dispatch(content: ReportContent, text: str) -> None:
        """根据 content.channels 分发到各通道。"""
        channels = content.channels or [ReportChannel.SESSION.value]
        for ch in channels:
            if ch == ReportChannel.FILE.value:
                _write_to_daily_report(content)
            # SESSION / HEARTBEAT / DASHBOARD 由调用者处理
            # 这里只做文件写入；其他通道在调用 report_* 时返回 text

    # ── 4种汇报接口 ────────────────────────────────────

    def report_task_done(
        self,
        title: str = "",
        body: str = "",
        highlights: Optional[List[str]] = None,
        action_items: Optional[List[str]] = None,
        task_id: str = "",
        monitor_data: Optional[MonitorReportData] = None,
        safety_data: Optional[SafetyReportData] = None,
        judge_data: Optional[JudgeReportData] = None,
        evolution_data: Optional[EvolutionReportData] = None,
        output_format: str = "text",
    ) -> str:
        """✅ 任务完成 — 标准汇报。"""
        # 频率控制：同一任务只汇报一次
        if task_id and self._rate_limit.is_task_reported(task_id):
            return ""

        content = ReportContent(
            trigger=ReportTrigger.TASK_DONE.value,
            title=title,
            body=body,
            highlights=highlights or [],
            action_items=action_items or [],
            monitor=monitor_data,
            safety=safety_data,
            judge=judge_data,
            evolution=evolution_data,
        )
        if output_format == "json":
            import json
            text = json.dumps(content.to_dict(), ensure_ascii=False, indent=2)
        else:
            text = render_full_report(content)

        if task_id:
            self._rate_limit.mark_task_reported(task_id)

        self._log_entry(ReportTrigger.TASK_DONE, title)
        self._trigger_callbacks(content)
        return text

    def report_highlight(
        self,
        title: str = "",
        body: str = "",
        highlights: Optional[List[str]] = None,
        action_items: Optional[List[str]] = None,
    ) -> str:
        """🔥 高价值发现 — 立即推送。"""
        content = ReportContent(
            trigger=ReportTrigger.HIGHLIGHT.value,
            title=title, body=body,
            highlights=highlights or [],
            action_items=action_items or [],
        )
        text = render_full_report(content)
        self._log_entry(ReportTrigger.HIGHLIGHT, title)
        self._trigger_callbacks(content)
        return text

    def report_alert(
        self,
        title: str = "",
        body: str = "",
        highlights: Optional[List[str]] = None,
        action_items: Optional[List[str]] = None,
        evolution_data: Optional[EvolutionReportData] = None,
    ) -> str:
        """⚠️ 紧急预警。"""
        content = ReportContent(
            trigger=ReportTrigger.ALERT.value,
            title=title, body=body,
            highlights=highlights or [],
            action_items=action_items or [],
            evolution=evolution_data,
        )
        text = render_full_report(content)
        self._log_entry(ReportTrigger.ALERT, title)
        self._trigger_callbacks(content)
        return text

    def report_milestone(
        self,
        title: str = "",
        body: str = "",
        judge_data: Optional[JudgeReportData] = None,
    ) -> str:
        """🧬 进化里程碑。"""
        content = ReportContent(
            trigger=ReportTrigger.MILESTONE.value,
            title=title, body=body,
            judge=judge_data,
        )
        text = render_full_report(content)
        self._log_entry(ReportTrigger.MILESTONE, title)
        self._trigger_callbacks(content)
        return text

    def report_summary(
        self,
        title: str = "枢御状态摘要",
        project_dir: Optional[str] = None,
        monitor_data: Optional[MonitorReportData] = None,
        safety_data: Optional[SafetyReportData] = None,
        judge_data: Optional[JudgeReportData] = None,
        evolution_data: Optional[EvolutionReportData] = None,
        highlights: Optional[List[str]] = None,
        action_items: Optional[List[str]] = None,
    ) -> str:
        """⏰ 定时摘要 — 每3小时一次，自动收集数据。"""
        if not self._rate_limit.can_send_summary():
            return ""

        # 从项目目录自动收集数据
        m_data = monitor_data or self._collect_monitor(project_dir)
        s_data = safety_data or SafetyReportData()
        j_data = judge_data or self._collect_judge(project_dir)
        e_data = evolution_data or EvolutionReportData()

        from .templates import render_summary
        text = render_summary(
            title=title,
            monitor_data=m_data,
            safety_data=s_data,
            judge_data=j_data,
            evolution_data=e_data,
            highlights=highlights,
            action_items=action_items,
        )

        self._rate_limit.mark_summary_sent()
        self._log_entry(ReportTrigger.SUMMARY, title)
        # Summary 触发回调
        content = ReportContent(
            trigger=ReportTrigger.SUMMARY.value,
            title=title,
            highlights=highlights or [],
            action_items=action_items or [],
            monitor=m_data,
            safety=s_data,
            judge=j_data,
            evolution=e_data,
        )
        self._trigger_callbacks(content)
        return text

    # ── 子 Agent 结果汇报 ──────────────────────────────

    def report_subagent_result(
        self,
        role: str,
        goal: str,
        result_summary: str,
        duration: float,
        success: bool = True,
        error: str = "",
    ) -> str:
        """📬 Sub-Agent 执行结果汇报。

        由 BrainCore 在 Sub-Agent 任务完成后调用。
        """
        icon = "✅" if success else "❌"
        role_name = role.replace("_agent", "")
        lines = [
            f"{icon} [Sub-Agent] {role_name} — {goal[:60]}",
            f"  耗时: {duration:.1f}s",
        ]
        if success and result_summary:
            lines.append(f"  结果: {result_summary[:200]}")
        if error:
            lines.append(f"  错误: {error}")
        text = "\n".join(lines)

        self._log_entry(ReportTrigger.TASK_DONE, f"Sub-Agent[{role}]: {goal[:40]}")
        return text

    # ── CodeVigil 安全扫描汇报 ───────────────────────────────

    def report_uxu_scan(
        self,
        total_findings: int,
        by_severity: Optional[Dict[str, int]] = None,
        top_findings: Optional[List[Dict]] = None,
        report_path: str = "",
    ) -> str:
        """🔒 CodeVigil 安全扫描结果汇报。

        由 UxuSecurityCheck 在健康检查后调用。
        """
        by_sev = by_severity or {}
        critical = by_sev.get("critical", 0)
        high = by_sev.get("high", 0)

        if total_findings == 0:
            text = f"🔒 CodeVigil 安全扫描通过: 0 个发现"
        elif critical > 0 or high > 0:
            text = (f"🔒 CodeVigil 安全扫描: {total_findings} 个发现 "
                    f"({critical}个严重, {high}个高危)")
            if top_findings:
                for f in top_findings[:3]:
                    text += f"\n  ⚠️ [{f.get('severity','?')}] {f.get('rule','?')} | {f.get('file','?')}:{f.get('line','?')}"
        else:
            text = f"🔒 CodeVigil 安全扫描: {total_findings} 个低风险发现"

        if report_path:
            text += f"\n  报告: {report_path}"

        self._log_entry(ReportTrigger.ALERT if (critical > 0 or high > 0) else ReportTrigger.TASK_DONE,
                        f"CodeVigil 安全扫描: {total_findings}个发现")
        return text

    # ── 销售结果汇报 ───────────────────────────────

    def report_sales_cycle(
        self,
        leads_count: int = 0,
        proposals_count: int = 0,
        leads_table: str = "",
        proposals_list: str = "",
        summary: str = "",
        next_steps: str = "等待主人授权后执行下一步销售动作",
        output_format: str = "text",
    ) -> str:
        """💼 销售周期汇报 — 向主人报告销售Pipeline执行结果。"""
        from datetime import datetime
        from .templates import render_full_report

        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        report = (
            f"## 💼 SentriKit 销售周期报告\n\n"
            f"### 周期: {ts}\n\n"
            f"### 摘要\n{summary}\n\n"
            f"### 本次发现的潜在客户 ({leads_count}个)\n"
            f"| 公司 | 优先级 | 状态 |\n"
            f"|------|--------|------|\n{leads_table}\n\n"
            f"### 已生成提案 ({proposals_count}个)\n{proposals_list}\n\n"
            f"### 下一步\n{next_steps}"
        )

        content = ReportContent(
            trigger="sales_cycle",
            title=f"💼 销售周期报告 — {leads_count}个客户, {proposals_count}个提案",
            body=report,
            highlights=[
                f"发现 {leads_count} 个潜在客户",
                f"生成 {proposals_count} 个销售提案",
            ],
            action_items=[
                "查看 sales-output/ 目录下的调研报告和提案",
                "审阅 brain/leads.md 客户列表",
                "授权发送提案或进一步调研",
            ],
        )

        text = render_full_report(content)
        self._log.append(ReportLogEntry(
            timestamp=ts, trigger="sales_cycle",
            title=content.title,
        ))
        return text

    # ── 数据收集 ───────────────────────────────────────

    @staticmethod
    def _collect_monitor(project_dir: Optional[str]) -> Optional[MonitorReportData]:
        """从 monitor 模块收集健康数据。"""
        if not project_dir:
            return None
        try:
            from tianlong.monitor import run_all_checks
            report = run_all_checks(Path(project_dir))
            return MonitorReportData(
                overall=report.overall,
                checks_ok=report.summary.get("ok", 0),
                checks_warning=report.summary.get("warning", 0),
                checks_error=report.summary.get("error", 0),
                checks_total=report.summary.get("total", 0),
            )
        except Exception:
            return None

    @staticmethod
    def _collect_judge(project_dir: Optional[str]) -> Optional[JudgeReportData]:
        """从 judge 模块收集进化评估数据。"""
        if not project_dir:
            return None
        try:
            from tianlong.judge import JudgeHistory, EvolutionDashboard
            hist = JudgeHistory(path=str(Path(project_dir) / "judge-history.json"))
            dash = EvolutionDashboard(history=hist)
            report = dash.compute()
            j = report.get("judge", {})
            ind = j.get("indicators", {})
            return JudgeReportData(
                total_proposals=report.get("total_proposals", 0),
                pass_rate=ind.get("pass_rate", {}).get("value", 0),
                avg_score=ind.get("avg_score", {}).get("value", 0),
                overall_grade=report.get("overall_grade", "D"),
                overall_health=report.get("overall_health", "unknown"),
                highlights=EvolutionDashboard._extract_highlights(report),
                warnings=EvolutionDashboard._extract_warnings(report),
            )
        except Exception:
            return None

    # ── 日志 ───────────────────────────────────────────

    def _log_entry(self, trigger: ReportTrigger, title: str) -> None:
        entry = ReportLogEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            trigger=trigger.value,
            title=title,
            channel="session",
            sent=True,
        )
        self._log.append(entry)

    def get_log(self, limit: int = 20) -> List[Dict]:
        """获取最近汇报日志。"""
        return [{
            "timestamp": e.timestamp,
            "trigger": e.trigger,
            "title": e.title,
            "channel": e.channel,
            "sent": e.sent,
        } for e in self._log[-limit:]]

    def save_log(self, path: Optional[str] = None) -> None:
        """保存日志到 JSON 文件。"""
        import json
        fp = Path(path) if path else self._log_path
        if fp:
            fp.parent.mkdir(parents=True, exist_ok=True)
            fp.write_text(
                json.dumps(self.get_log(limit=1000), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    # ── CodeVigil 安全扫描汇报（v2评分）────────────────────────

    def report_uxu_scan_v2(
        self,
        uxu_data: Optional[UxuScoreReportData] = None,
        title: str = "安全扫描报告",
        channels: Optional[List[str]] = None,
    ) -> str:
        """🔒 CodeVigil 安全扫描v2汇报 — 包含pillar明细和薄弱环节。"""
        from .templates import render_uxu_scan

        if uxu_data is None:
            return ""

        content = ReportContent(
            trigger=ReportTrigger.TASK_DONE.value,
            title=title,
            body=render_uxu_scan(uxu_data),
            channels=channels or [ReportChannel.SESSION.value],
        )
        text = render_full_report(content)
        self._log_entry(ReportTrigger.TASK_DONE, f"CodeVigil 扫描: 等级{uxu_data.grade}")
        self._dispatch(content, text)
        self._trigger_callbacks(content)
        return text

    # ── DGM-H 元认知汇报 ────────────────────────────────

    def report_dgmh(
        self,
        dgmh_data: Optional[DGMHReportData] = None,
        title: str = "元认知状态报告",
        channels: Optional[List[str]] = None,
    ) -> str:
        """🧠 DGM-H 元认知状态汇报 — Phase状态+命中率+策略建议。"""
        from .templates import render_dgmh_report

        if dgmh_data is None:
            return ""

        content = ReportContent(
            trigger=ReportTrigger.SUMMARY.value,
            title=title,
            body=render_dgmh_report(dgmh_data),
            dgmh=dgmh_data,
            channels=channels or [ReportChannel.SESSION.value],
        )
        text = render_full_report(content)
        self._log_entry(ReportTrigger.SUMMARY, f"元认知: Phase{'✅' if dgmh_data.phase3_active else '⏳'}")
        self._dispatch(content, text)
        self._trigger_callbacks(content)
        return text

    # ── 每日聚合报告 ──────────────────────────────────

    def report_daily(
        self,
        monitor_data: Optional[MonitorReportData] = None,
        judge_data: Optional[JudgeReportData] = None,
        uxu_data: Optional[UxuScoreReportData] = None,
        dgmh_data: Optional[DGMHReportData] = None,
        highlights: Optional[List[str]] = None,
        action_items: Optional[List[str]] = None,
        channels: Optional[List[str]] = None,
    ) -> str:
        """📋 每日聚合报告 — 一次汇报采集所有模块数据。"""
        from .templates import render_daily_dashboard

        text = render_daily_dashboard(
            monitor_data=monitor_data,
            judge_data=judge_data,
            uxu_data=uxu_data,
            dgmh_data=dgmh_data,
            highlights=highlights,
            action_items=action_items,
        )
        # 品牌水印（开源版保留，企业版可去除）
        if not self._remove_branding:
            text += "\n\n---\n*由 🌐 SentriKit 开源版生成 🐉*"

        content = ReportContent(
            trigger="daily",
            title=f"每日报告 — {datetime.now().strftime('%Y-%m-%d')}",
            body=text,
            monitor=monitor_data,
            judge=judge_data,
            uxu_score=uxu_data,
            dgmh=dgmh_data,
            highlights=highlights,
            action_items=action_items,
            channels=channels or [ReportChannel.SESSION.value, ReportChannel.FILE.value],
        )
        self._log_entry(ReportTrigger.SUMMARY, content.title)
        self._dispatch(content, text)
        self._trigger_callbacks(content)
        return text


# ── 模块级辅助函数 ──────────────────────────────────


def _write_to_daily_report(content: ReportContent) -> None:
    """将汇报内容写入 reports/YYYY-MM-DD.md。"""
    from pathlib import Path
    from datetime import date

    output_path = Path("reports")
    output_path.mkdir(parents=True, exist_ok=True)
    today = date.today().strftime("%Y-%m-%d")
    filepath = output_path / f"{today}.md"

    trigger_icons = {
        "task_done": "✅", "highlight": "🔥", "alert": "⚠️",
        "milestone": "🧬", "summary": "📊", "daily": "📋",
    }
    icon = trigger_icons.get(content.trigger, "📌")
    now = datetime.now().strftime("%H:%M:%S")
    lines = [
        f"### {icon} {content.title}",
        f"**时间**: {now}",
    ]
    if content.body:
        lines.append(f"\n{content.body}")
    if content.highlights:
        lines.append("\n**关键发现**:")
        for h in content.highlights:
            lines.append(f"- {h}")
    if content.action_items:
        lines.append("\n**下一步**:")
        for a in content.action_items:
            lines.append(f"- [ ] {a}")
    lines.append("\n---\n")

    entry = "\n".join(lines)
    if filepath.exists():
        with open(filepath, "a", encoding="utf-8") as f:
            f.write(entry)
    else:
        filepath.write_text(entry, encoding="utf-8")

    def report_to_file(
        self,
        title: str = "",
        body: str = "",
        highlights: Optional[List[str]] = None,
        action_items: Optional[List[str]] = None,
        trigger: str = "task_done",
        output_dir: str = "reports",
        filename: Optional[str] = None,
        append: bool = True,
    ) -> str:
        """将汇报写入 Markdown 文件。

        - 默认追加到 reports/YYYY-MM-DD.md (每日报告)
        - 可指定 filename 写入固定文件
        - 返回完整文件路径
        """
        import json
        from datetime import date

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        if filename:
            filepath = output_path / filename
        else:
            today = date.today().strftime("%Y-%m-%d")
            filepath = output_path / f"{today}.md"

        # 构建 markdown 条目
        trigger_icons = {
            "task_done": "✅",
            "highlight": "🔥",
            "alert": "⚠️",
            "milestone": "🧬",
            "summary": "📊",
        }
        icon = trigger_icons.get(trigger, "📌")
        now = datetime.now().strftime("%H:%M:%S")

        lines = [
            f"### {icon} {title}",
            f"**时间**: {now}  **类型**: {trigger}",
        ]
        if body:
            lines.append(f"\n{body}")
        if highlights:
            lines.append("\n**关键发现**:")
            for h in highlights:
                lines.append(f"- {h}")
        if action_items:
            lines.append("\n**下一步**:")
            for a in action_items:
                lines.append(f"- [ ] {a}")
        lines.append("\n---\n")

        entry = "\n".join(lines)

        if append and filepath.exists():
            with open(filepath, "a", encoding="utf-8") as f:
                f.write(entry)
        else:
            with open(filepath, "w", encoding="utf-8") as f:
                header = f"# 汇报报告 — {date.today().strftime('%Y-%m-%d')}\n\n"
                f.write(header + entry)

        self._log_entry(ReportTrigger(trigger) if trigger in [t.value for t in ReportTrigger] else ReportTrigger.TASK_DONE, title)
        return str(filepath)
