"""tianlong.reporter — 主动汇报系统

从 monitor/safety/judge/evolution 收集数据，按4种模板生成结构化汇报。

开源版：4种基础模板，免费。
企业版：自定义模板 + 去水印，企业去品牌。
"""

from .core import Reporter
from .types import (
    ReportTrigger, ReportContent, ReportChannel,
    MonitorReportData, SafetyReportData,
    JudgeReportData, EvolutionReportData,
    UxuScoreReportData, DGMHReportData,
)
from .templates import render_full_report, render_summary
