"""tianlong.reporter.cli — 命令行接口

支持 `tianlong-reporter` 和 `python -m tianlong.reporter`。

用法:
    # 标准汇报（任务完成）
    tianlong-reporter task-done --title "优化搜索" --body "完成"

    # 高价值发现
    tianlong-reporter highlight --title "发现新模式" --body "..."

    # 紧急预警
    tianlong-reporter alert --title "审计阻止" --body "连续3次"

    # 定时摘要（从项目目录自动收集数据）
    tianlong-reporter summary --project-dir /path/to/agent

    # 查看汇报日志
    tianlong-reporter log --limit 10
"""

from __future__ import annotations

import argparse
import json
import sys

from .core import Reporter
from .types import ReportTrigger


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tianlong-reporter",
        description="SentriKit — 主动汇报系统。从 monitor/safety/judge/evolution 收集数据生成结构化汇报。",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # task-done
    td = sub.add_parser("task-done", help="✅ 标准汇报（任务完成）")
    td.add_argument("--title", "-t", type=str, default="任务完成", help="任务名称")
    td.add_argument("--body", "-b", type=str, default="", help="结果描述")
    td.add_argument("--highlight", "-hl", type=str, action="append", default=None, help="关键发现（可多次）")
    td.add_argument("--action", "-a", type=str, action="append", default=None, help="下一步建议")

    # highlight
    hl = sub.add_parser("highlight", help="🔥 高价值发现")
    hl.add_argument("--title", "-t", type=str, required=True, help="发现标题")
    hl.add_argument("--body", "-b", type=str, default="", help="发现描述")
    hl.add_argument("--value", "-v", type=str, action="append", default=None, help="价值说明")
    hl.add_argument("--action", "-a", type=str, action="append", default=None, help="建议行动")

    # alert
    al = sub.add_parser("alert", help="⚠️ 紧急预警")
    al.add_argument("--title", "-t", type=str, required=True, help="预警标题")
    al.add_argument("--body", "-b", type=str, default="", help="现状描述")
    al.add_argument("--impact", "-i", type=str, action="append", default=None, help="影响说明")
    al.add_argument("--action", "-a", type=str, action="append", default=None, help="需要立即执行的操作")

    # summary
    sm = sub.add_parser("summary", help="⏰ 定时摘要（从项目目录自动收集数据）")
    sm.add_argument("--project-dir", "-d", type=str, default=".", help="Agent 项目目录")
    sm.add_argument("--title", "-t", type=str, default="枢御状态摘要", help="摘要标题")
    sm.add_argument("--output", "-o", type=str, choices=["text", "json"], default="text")

    # log
    lg = sub.add_parser("log", help="查看汇报日志")
    lg.add_argument("--limit", "-n", type=int, default=10, help="显示最近 N 条")

    return parser


def cmd_task_done(args) -> int:
    reporter = Reporter()
    text = reporter.report_task_done(
        title=args.title,
        body=args.body,
        highlights=args.highlight or [],
        action_items=args.action or [],
    )
    print(text)
    return 0


def cmd_highlight(args) -> int:
    reporter = Reporter()
    text = reporter.report_highlight(
        title=args.title,
        body=args.body,
        highlights=args.value or [],
        action_items=args.action or [],
    )
    print(text)
    return 0


def cmd_alert(args) -> int:
    reporter = Reporter()
    text = reporter.report_alert(
        title=args.title,
        body=args.body,
        highlights=args.impact or [],
        action_items=args.action or [],
    )
    print(text)
    return 0


def cmd_summary(args) -> int:
    reporter = Reporter()

    if args.output == "json":
        # JSON 模式：输出各模块原始数据
        from tianlong.monitor import run_all_checks
        from pathlib import Path
        proj = Path(args.project_dir).resolve()
        data = {"project_dir": str(proj)}
        if proj.exists():
            try:
                report = run_all_checks(proj)
                data["monitor"] = report.to_dict()
            except Exception as e:
                data["monitor"] = {"error": str(e)}
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    text = reporter.report_summary(
        title=args.title,
        project_dir=args.project_dir,
    )
    if not text:
        print("(频率控制: 摘要每3小时1次，尚未到下次发送时间)")
        return 0
    print(text)
    return 0


def cmd_log(args) -> int:
    # 创建一个临时 reporter 查看日志（仅当前 session）
    reporter = Reporter()
    # 演示场景：写入一条"查看日志"条目
    import json as _json
    entries = reporter.get_log(limit=args.limit)
    print(_json.dumps(entries, ensure_ascii=False, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return {
        "task-done": cmd_task_done,
        "highlight": cmd_highlight,
        "alert": cmd_alert,
        "summary": cmd_summary,
        "log": cmd_log,
    }[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
