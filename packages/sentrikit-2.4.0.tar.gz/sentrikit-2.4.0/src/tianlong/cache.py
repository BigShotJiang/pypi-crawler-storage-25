"""tianlong.cache — 轻量级缓存工具

纯标准库，零依赖。提供 LRU 缓存和函数结果缓存装饰器。
"""

from __future__ import annotations

import time
from collections import OrderedDict
from functools import wraps
from typing import Any, Callable, Dict, Optional


class LRUCache:
    """LRU 缓存（最近最少使用淘汰）

    用法:
        cache = LRUCache(maxsize=128, ttl=60)
        cache.set("key", "value")
        value = cache.get("key")  # 返回 None 如果过期或不存在
    """

    def __init__(self, maxsize: int = 128, ttl: Optional[float] = None):
        self._maxsize = maxsize
        self._ttl = ttl  # 秒数，None 表示永不过期
        self._cache: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._hits = 0
        self._misses = 0

    @property
    def hits(self) -> int:
        return self._hits

    @property
    def misses(self) -> int:
        return self._misses

    @property
    def hit_rate(self) -> float:
        total = self._hits + self._misses
        return round(self._hits / max(total, 1) * 100, 1)

    @property
    def size(self) -> int:
        return len(self._cache)

    def get(self, key: str) -> Any:
        """获取缓存值，不存在或过期返回 None"""
        if key not in self._cache:
            self._misses += 1
            return None
        value, expires = self._cache[key]
        if expires is not None and time.time() > expires:
            del self._cache[key]
            self._misses += 1
            return None
        self._cache.move_to_end(key)
        self._hits += 1
        return value

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """设置缓存值"""
        if key in self._cache:
            self._cache.move_to_end(key)
        expires = None
        effective_ttl = ttl if ttl is not None else self._ttl
        if effective_ttl is not None:
            expires = time.time() + effective_ttl
        self._cache[key] = (value, expires)
        if len(self._cache) > self._maxsize:
            self._cache.popitem(last=False)

    def delete(self, key: str) -> bool:
        """删除缓存项"""
        if key in self._cache:
            del self._cache[key]
            return True
        return False

    def clear(self) -> None:
        self._cache.clear()
        self._hits = 0
        self._misses = 0

    def stats(self) -> Dict:
        return {
            "size": self.size,
            "maxsize": self._maxsize,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": self.hit_rate,
            "ttl": self._ttl,
        }


def cached(maxsize: int = 128, ttl: float = 60.0) -> Callable:
    """函数结果缓存装饰器

    用法:
        @cached(ttl=30)
        def expensive_function(arg1, arg2):
            ...
            return result
    """
    caches: Dict[str, LRUCache] = {}

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            key = f"{func.__module__}.{func.__qualname__}:{args}:{kwargs}"
            if key not in caches:
                caches[key] = LRUCache(maxsize=maxsize, ttl=ttl)
            cache = caches[key]
            result = cache.get(key)
            if result is not None:
                return result
            result = func(*args, **kwargs)
            cache.set(key, result)
            return result
        return wrapper
    return decorator


# ── 缓存管理器（用于跟踪多个缓存实例） ──────────────────


_cache_registry: Dict[str, LRUCache] = {}


def register_cache(name: str, maxsize: int = 128, ttl: float = 60.0) -> LRUCache:
    """注册并获取命名缓存"""
    if name not in _cache_registry:
        _cache_registry[name] = LRUCache(maxsize=maxsize, ttl=ttl)
    return _cache_registry[name]


def get_cache(name: str) -> Optional[LRUCache]:
    return _cache_registry.get(name)


def clear_all_caches() -> None:
    for cache in _cache_registry.values():
        cache.clear()


def all_cache_stats() -> Dict[str, Dict]:
    return {name: cache.stats() for name, cache in _cache_registry.items()}
