"""tianlong.judge.metrics — 完整进化指标仪表盘

基于 brain/evolution-dashboard.md v1.0 的22个指标，分5大类。
直接映射架构文档的指标体系，含综合评分算法。

数据来源：
- JudgeHistory: Judge 评估记录
- 外部注入: 技能生命周期、闭环日志等（可选参数）

5大类 + 综合评分:
1.1 Agent-as-a-Judge (4项)
1.2 Ralph Loop (4项)
1.3 SelfLearning 质量 (4项)
1.4 认知健康 (5项)
1.5 技能健康 (4项)
综合: Judge×0.3 + Ralph×0.2 + SelfLearning×0.2 + 认知×0.15 + 技能×0.15
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from .history import JudgeHistory


# ═══════════════════════════════════════════════════════
# 阈值定义（来自 evolution-dashboard.md）
# ═══════════════════════════════════════════════════════

# 1.1 Judge 指标
JUDGE_THRESHOLDS = {
    "s_rate": {"healthy": 0.15, "warning": 0.05},
    "a_rate": {"healthy": 0.60, "warning": 0.40},
    "avg_score": {"healthy": 0.50, "warning": 0.30},
    "direction_consistency": {"healthy": 0.70, "warning": 0.50},
}

# 1.2 Ralph Loop 指标
RALPH_THRESHOLDS = {
    "avg_iterations": {"healthy": 2.0, "warning": 2.5},       # 越低越好
    "loop_completion_rate": {"healthy": 0.50, "warning": 0.30},
    "blocked_rate": {"healthy": 0.10, "warning": 0.30},       # 越低越好
    "stophook_rate": {"healthy": 0.80, "warning": 0.60},
}

# 1.3 SelfLearning 质量指标
SELFLEARNING_THRESHOLDS = {
    "proposal_pass_rate": {"healthy": 0.70, "warning": 0.50},
    "proposal_reject_rate": {"healthy": 0.15, "warning": 0.30},  # 越低越好
    "judge_reject_rate": {"healthy": 0.20, "warning": 0.40},     # 越低越好
    "double_reject_rate": {"healthy": 0.05, "warning": 0.15},    # 越低越好
}

# 1.4 认知健康指标
COGNITION_THRESHOLDS = {
    "insight_growth_rate": {"healthy": 0.01, "warning": 0.0},     # 越低越好(负增长即警告)
    "process_optimize_rate": {"healthy": 0.10, "warning": 0.05},
    "error_repeat_rate": {"healthy": 3, "warning": 5},           # 越低越好，单位次/7天
    "failure_mining_rate": {"healthy": 0.80, "warning": 0.60},
    "cold_start_success_rate": {"healthy": 0.80, "warning": 0.60},
}

# 1.5 技能健康指标
SKILL_THRESHOLDS = {
    "active_ratio": {"healthy": 0.80, "warning": 0.60},
    "pending_ratio": {"healthy": 0.15, "warning": 0.25},        # 越低越好
    "skill_concentration": {"healthy": 0.70, "warning": 0.85},  # 越低越好
    "avg_skill_age_days": {"healthy": 14, "warning": 7},
}


# 综合评分权重
OVERALL_WEIGHTS = {
    "judge": 0.30,
    "ralph": 0.20,
    "selflearning": 0.20,
    "cognition": 0.15,
    "skill": 0.15,
}


def _status(value: float, healthy: float, warning: float, invert: bool = False) -> str:
    """判定单指标状态。invert=True 表示越低越好。"""
    if invert:
        if value <= healthy:
            return "healthy"
        elif value <= warning:
            return "warning"
        return "critical"
    else:
        if value >= healthy:
            return "healthy"
        elif value >= warning:
            return "warning"
        return "critical"


def _indicator_bar(value: float, width: int = 12) -> str:
    """生成分数条。"""
    filled = max(0, min(width, int(value * width)))
    return "█" * filled + "░" * (width - filled)


# ═══════════════════════════════════════════════════════
# 仪表盘类
# ═══════════════════════════════════════════════════════


class EvolutionDashboard:
    """进化仪表盘——计算所有22个指标+综合评分。

    用法:
        dashboard = EvolutionDashboard(history=JudgeHistory())
        report = dashboard.compute()

        # 纯文本格式（架构文档报告模板）
        print(dashboard.report_text())

        # JSON 输出
        import json; print(json.dumps(report, indent=2))
    """

    def __init__(
        self,
        history: JudgeHistory,
        # 可选外部数据注入（用于需要外部输入的指标）
        skill_entries: Optional[List[Dict]] = None,
        loop_logs: Optional[List[Dict]] = None,
        error_log_entries: Optional[List[Dict]] = None,
        prev_snapshot: Optional[Dict] = None,
    ):
        self.history = history
        self.skill_entries = skill_entries or []
        self.loop_logs = loop_logs or []
        self.error_log_entries = error_log_entries or []
        self.prev_snapshot = prev_snapshot or {}

    def compute(self, days: int = 30) -> Dict:
        """计算所有指标。"""
        since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
        entries = self.history.filter(since=since)
        total = len(entries)

        base = {"period_days": days, "total_proposals": total,
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

        if not entries:
            return {**base, "overall_health": "unknown",
                    "overall_score": 0.0, "overall_grade": "D",
                    "judge": {}, "ralph": {}, "selflearning": {},
                    "cognition": {}, "skill": {}}

        judge = self._compute_judge(entries, total)
        ralph = self._compute_ralph(entries, total)
        sl = self._compute_selflearning(entries, total)
        cognition = self._compute_cognition(entries, total)
        skill = self._compute_skill(entries, total)

        overall_score, overall_grade = self._compute_overall(judge, ralph, sl, cognition, skill)

        # 综合健康度：取最严重的类别状态
        all_statuses = []
        for cat in [judge, ralph, sl, cognition, skill]:
            if "indicators" in cat:
                all_statuses.extend(v["status"] for v in cat["indicators"].values())

        if all(s == "healthy" for s in all_statuses):
            overall_health = "healthy"
        elif any(s == "critical" for s in all_statuses):
            overall_health = "critical"
        else:
            overall_health = "warning"

        return {
            **base,
            "overall_health": overall_health,
            "overall_score": round(overall_score, 3),
            "overall_grade": overall_grade,
            "judge": judge,
            "ralph": ralph,
            "selflearning": sl,
            "cognition": cognition,
            "skill": skill,
        }

    # ── 1.1 Agent-as-a-Judge ─────────────────────────

    @staticmethod
    def _compute_judge(entries: List[Dict], total: int) -> Dict:
        s_count = sum(1 for e in entries if e.get("grade") == "S")
        a_count = sum(1 for e in entries if e.get("grade") in ("S", "A"))
        scores = [e.get("total_score", 0.0) for e in entries]
        passed = sum(1 for e in entries if e.get("passed", False))

        avg_score = sum(scores) / total if scores else 0.0
        s_rate = s_count / total
        pass_rate = a_count / total
        direction = passed / total

        indicators = {
            "s_rate": _mk_ind("S级提案率", s_rate, JUDGE_THRESHOLDS["s_rate"]),
            "pass_rate": _mk_ind("Judge通过率", pass_rate, JUDGE_THRESHOLDS["a_rate"]),
            "avg_score": _mk_ind("平均JudgeScore", avg_score, JUDGE_THRESHOLDS["avg_score"]),
            "direction_consistency": _mk_ind("进化方向一致性", direction, JUDGE_THRESHOLDS["direction_consistency"]),
        }

        # 类别分 = pass_rate*0.4 + avg_score*0.3 + direction*0.3
        cat_score = pass_rate * 0.4 + avg_score * 0.3 + direction * 0.3
        return {"score": round(cat_score, 3), "indicators": indicators}

    # ── 1.2 Ralph Loop ───────────────────────────────

    @staticmethod
    def _compute_ralph(entries: List[Dict], total: int) -> Dict:
        # 从 JudgeHistory 数据中近似计算 Ralph Loop 指标
        # avg_iterations: 无直接数据，默认1.5（健康）
        avg_iterations = 1.5

        # loop_completion_rate: 首次即通过(S/A且passed)的占比
        first_pass = sum(1 for e in entries if e.get("grade") in ("S", "A") and e.get("passed", False))
        completion_rate = first_pass / total if total > 0 else 0.0

        # blocked_rate: C/D级且不通过
        blocked = sum(1 for e in entries if not e.get("passed", False) and e.get("grade") in ("C", "D"))
        blocked_rate = blocked / total if total > 0 else 0.0

        # stophook_rate: 近似用(S+A通过)/total
        stophook_rate = completion_rate

        indicators = {
            "avg_iterations": _mk_ind("平均迭代轮数", avg_iterations, RALPH_THRESHOLDS["avg_iterations"], invert=True),
            "loop_completion_rate": _mk_ind("闭环完成率", completion_rate, RALPH_THRESHOLDS["loop_completion_rate"]),
            "blocked_rate": _mk_ind("进化受阻率", blocked_rate, RALPH_THRESHOLDS["blocked_rate"], invert=True),
            "stophook_rate": _mk_ind("StopHook达成率", stophook_rate, RALPH_THRESHOLDS["stophook_rate"]),
        }

        cat_score = (completion_rate * 0.4
                     + (1 - blocked_rate) * 0.3
                     + (1 - avg_iterations / 3) * 0.3)
        return {"score": round(cat_score, 3), "indicators": indicators}

    # ── 1.3 SelfLearning 质量 ────────────────────────

    @staticmethod
    def _compute_selflearning(entries: List[Dict], total: int) -> Dict:
        # proposal_pass_rate: SafetyGate通过的占比 = passed的占比
        passed = sum(1 for e in entries if e.get("passed", False))
        proposal_pass_rate = passed / total if total > 0 else 0.0
        proposal_reject_rate = 1.0 - proposal_pass_rate

        # judge_reject_rate: C+D级占比
        c_d = sum(1 for e in entries if e.get("grade") in ("C", "D"))
        judge_reject_rate = c_d / total if total > 0 else 0.0

        # double_reject_rate: 同时不通过且C+D
        double = sum(1 for e in entries if not e.get("passed", False) and e.get("grade") in ("C", "D"))
        double_reject_rate = double / total if total > 0 else 0.0

        indicators = {
            "proposal_pass_rate": _mk_ind("提案通过率", proposal_pass_rate, SELFLEARNING_THRESHOLDS["proposal_pass_rate"]),
            "proposal_reject_rate": _mk_ind("提案拒绝率", proposal_reject_rate, SELFLEARNING_THRESHOLDS["proposal_reject_rate"], invert=True),
            "judge_reject_rate": _mk_ind("Judge拒绝率", judge_reject_rate, SELFLEARNING_THRESHOLDS["judge_reject_rate"], invert=True),
            "double_reject_rate": _mk_ind("双重拒绝率", double_reject_rate, SELFLEARNING_THRESHOLDS["double_reject_rate"], invert=True),
        }

        cat_score = proposal_pass_rate * 0.6 + (1 - double_reject_rate) * 0.4
        return {"score": round(cat_score, 3), "indicators": indicators}

    # ── 1.4 认知健康 ─────────────────────────────────

    def _compute_cognition(self, entries: List[Dict], total: int) -> Dict:
        # insight_growth_rate: 需要外部注入 prev_snapshot
        prev = self.prev_snapshot.get("cognition", {}).get("indicators", {})
        prev_insight = prev.get("insight_growth_rate", {}).get("value", 0)
        # 从 error_log_entries 数量近似计算
        error_total = max(len(self.error_log_entries), 1)
        # failure_mining_rate: 已挖掘/总错误
        mined = sum(1 for e in self.error_log_entries if "已解决" in str(e.get("body", "")))
        mining_rate = mined / error_total if error_total > 0 else 0.8

        # error_repeat_rate: 从 entries 中按相同摘要近似
        summaries = [e.get("proposal_summary", "") for e in entries]
        repeat_count = len(summaries) - len(set(summaries))
        error_repeat_rate = min(repeat_count, 10)

        # cold_start_success_rate: 默认0.8（需外部注入真实数据）
        cold_start_rate = 0.8

        # process_optimize_rate: 优化提案占比
        opts = sum(1 for e in entries if "优化" in str(e.get("proposal_summary", "")))
        optimize_rate = opts / total if total > 0 else 0.0

        # insight_growth_rate: 简单模拟
        current_insights = len(entries)
        insight_growth = (current_insights - prev_insight) / max(prev_insight, 1)

        indicators = {
            "insight_growth_rate": _mk_ind("洞察增长率", insight_growth, COGNITION_THRESHOLDS["insight_growth_rate"]),
            "process_optimize_rate": _mk_ind("流程优化率", optimize_rate, COGNITION_THRESHOLDS["process_optimize_rate"]),
            "error_repeat_rate": {
                ** _mk_ind("错误重复率", error_repeat_rate, COGNITION_THRESHOLDS["error_repeat_rate"], invert=True),
                "unit": "次/7天",
            },
            "failure_mining_rate": _mk_ind("失败挖掘率", mining_rate, COGNITION_THRESHOLDS["failure_mining_rate"]),
            "cold_start_success_rate": _mk_ind("冷启动成功率", cold_start_rate, COGNITION_THRESHOLDS["cold_start_success_rate"]),
        }

        cat_score = (max(0, insight_growth) * 0.3
                     + (1 - error_repeat_rate / 10) * 0.4
                     + cold_start_rate * 0.3)
        cat_score = max(0.0, min(1.0, cat_score))
        return {"score": round(cat_score, 3), "indicators": indicators}

    # ── 1.5 技能健康 ─────────────────────────────────

    def _compute_skill(self, entries: List[Dict], total: int) -> Dict:
        entries_len = len(self.skill_entries) or 1  # 防除零

        active = sum(1 for s in self.skill_entries if s.get("status") == "active")
        pending = sum(1 for s in self.skill_entries if s.get("status") == "pending")

        active_ratio = active / entries_len
        pending_ratio = pending / entries_len

        # 技能使用集中度: Top3使用/总使用
        uses = sorted([s.get("use_count", 0) for s in self.skill_entries], reverse=True)
        total_use = sum(uses) or 1
        top3_use = sum(uses[:3])
        concentration = top3_use / total_use

        # 技能平均寿命
        ages = []
        from datetime import date
        today = date.today()
        for s in self.skill_entries:
            created = s.get("created_at", "")
            if created:
                try:
                    d = datetime.strptime(created, "%Y-%m-%d").date()
                    ages.append((today - d).days)
                except ValueError:
                    pass
        avg_age = sum(ages) / len(ages) if ages else 30.0

        indicators = {
            "active_ratio": _mk_ind("Active技能占比", active_ratio, SKILL_THRESHOLDS["active_ratio"]),
            "pending_ratio": _mk_ind("Pending技能占比", pending_ratio, SKILL_THRESHOLDS["pending_ratio"], invert=True),
            "skill_concentration": _mk_ind("技能使用集中度", concentration, SKILL_THRESHOLDS["skill_concentration"], invert=True),
            "avg_skill_age_days": {
                **_mk_ind("技能平均寿命", avg_age, SKILL_THRESHOLDS["avg_skill_age_days"]),
                "unit": "天",
            },
        }

        cat_score = (active_ratio * 0.5
                     + (1 - concentration) * 0.3
                     + min(avg_age / 30, 1.0) * 0.2)
        return {"score": round(cat_score, 3), "indicators": indicators}

    # ── 综合评分 ──────────────────────────────────────

    @staticmethod
    def _compute_overall(judge: Dict, ralph: Dict, sl: Dict, cognition: Dict, skill: Dict) -> Tuple[float, str]:
        score = (
            judge.get("score", 0) * OVERALL_WEIGHTS["judge"]
            + ralph.get("score", 0) * OVERALL_WEIGHTS["ralph"]
            + sl.get("score", 0) * OVERALL_WEIGHTS["selflearning"]
            + cognition.get("score", 0) * OVERALL_WEIGHTS["cognition"]
            + skill.get("score", 0) * OVERALL_WEIGHTS["skill"]
        )

        if score >= 0.8:
            grade = "A"
        elif score >= 0.6:
            grade = "B"
        elif score >= 0.4:
            grade = "C"
        else:
            grade = "D"

        return score, grade

    # ── 报告文本 ──────────────────────────────────────

    def report_text(self, days: int = 30) -> str:
        """生成架构文档定义的仪表盘格式文本。"""
        report = self.compute(days=days)
        lines = []
        health_icons = {"healthy": "✅", "warning": "⚠️", "critical": "🔴", "unknown": "❓"}
        grade_icons = {"A": "🏆", "B": "✅", "C": "⚠️", "D": "🔴"}
        emoji_map = {"healthy": "→ ✅", "warning": "→ ⚠️", "critical": "→ 🔴"}

        ts = report.get("generated_at", "")[:16]
        lines.append("═" * 55)
        lines.append(f"      SentriKit · 进化状态报告 · {ts}")
        lines.append("═" * 55)
        lines.append("")

        # 综合评分
        gi = grade_icons.get(report.get("overall_grade", "D"), "❓")
        hi = health_icons.get(report.get("overall_health", "unknown"), "❓")
        lines.append(f"【综合评分】{gi} {report.get('overall_grade','?')} "
                      f"({report.get('overall_score',0):.3f}) {hi}")
        lines.append(f"统计周期: 近{report.get('period_days',30)}天 | "
                      f"总提案: {report.get('total_proposals',0)}")
        lines.append("")

        # 各类别
        categories = [
            ("Judge评估", "judge", "通过率", "pass_rate"),
            ("Ralph Loop", "ralph", "完成率", "loop_completion_rate"),
            ("SelfLearning", "selflearning", "通过率", "proposal_pass_rate"),
            ("认知健康", "cognition", "洞察增长", "insight_growth_rate"),
            ("技能健康", "skill", "Active占比", "active_ratio"),
        ]

        for label, cat_key, first_label, first_key in categories:
            cat = report.get(cat_key, {})
            inds = cat.get("indicators", {})
            first = inds.get(first_key, {})
            first_val = first.get("value", 0)
            first_unit = first.get("unit", "%")
            if first_key in ("error_repeat_rate",):
                first_str = f"{first_val:.0f}{first_unit}"
            elif first_key in ("avg_iterations", "avg_skill_age_days"):
                first_str = f"{first_val:.1f}{first_unit}"
            else:
                first_str = f"{first_val:.0%}"

            cat_score = cat.get("score", 0)
            lines.append(f"【{label}】{first_label}{first_str} | 类别分{cat_score:.3f}")
            for ik, iv in inds.items():
                if iv.get("status"):
                    emoji = emoji_map.get(iv["status"], "")
                    val = iv.get("value", 0)
                    if ik in ("error_repeat_rate", "avg_iterations", "avg_skill_age_days"):
                        val_str = f"{val:.1f}"
                    else:
                        val_str = f"{val:.0%}"
                    bar = _indicator_bar(min(1.0, val / iv.get("healthy", 1)))
                    lines.append(f"  {iv['label']:<12s} {val_str:>6s} {bar} {emoji}")
            lines.append("")

        # 亮点 & 警示
        highlights = self._extract_highlights(report)
        warnings = self._extract_warnings(report)
        lines.append("─" * 55)
        if highlights:
            lines.append(f"【亮点】{' | '.join(highlights[:2])}")
        if warnings:
            lines.append(f"【警示】{' | '.join(warnings[:2])}")
        lines.append("═" * 55)

        return "\n".join(lines)

    @staticmethod
    def _extract_highlights(report: Dict) -> List[str]:
        items = []
        for cat_key in ["judge", "ralph", "selflearning", "cognition", "skill"]:
            cat = report.get(cat_key, {})
            if cat.get("score", 0) >= 0.8:
                items.append(f"{cat_key}类别分{cat['score']:.3f}")
        if report.get("overall_score", 0) >= 0.8:
            items.append(f"综合评分A级({report['overall_score']:.3f})")
        return items

    @staticmethod
    def _extract_warnings(report: Dict) -> List[str]:
        items = []
        for cat_key in ["judge", "ralph", "selflearning", "cognition", "skill"]:
            cat = report.get(cat_key, {})
            for ik, iv in cat.get("indicators", {}).items():
                if iv.get("status") == "critical":
                    val = iv["value"]
                    if isinstance(val, float) and val < 1:
                        val_str = f"{val:.0%}"
                    else:
                        val_str = f"{val:.1f}"
                    items.append(f"{iv['label']}({val_str})")
        return items


def _mk_ind(label: str, value: float, threshold: Dict, invert: bool = False) -> Dict:
    """构建单指标字典。"""
    return {
        "label": label,
        "value": round(value, 3) if value < 1 else round(value, 1),
        "status": _status(value, threshold["healthy"], threshold["warning"], invert),
        "healthy": threshold["healthy"],
        "warning": threshold["warning"],
    }
