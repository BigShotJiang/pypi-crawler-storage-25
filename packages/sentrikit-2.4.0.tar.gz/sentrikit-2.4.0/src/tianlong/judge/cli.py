"""tianlong.judge.cli — 命令行接口

支持 `tianlong-judge` 和 `python -m tianlong.judge` 两种方式。

用法:
    # 评估一个提案
    tianlong-judge evaluate --proposal "优化搜索流程，减少用户操作步骤"

    # 指定提案详情
    tianlong-judge evaluate \\
        --proposal "重构记忆检索模块" \\
        --id p001 \\
        --type update \\
        --steps 5 \\
        --tokens 3000 \\
        --target "brain/memory-system.md"

    # 使用 LLM 模式（需要 API Key）
    DEEPSEEK_API_KEY=sk-xxx tianlong-judge evaluate --proposal "..." --llm

    # JSON 输出
    tianlong-judge evaluate --proposal "..." -o json

    # 从模板评估
    tianlong-judge template --name create_new_knowledge
"""

from __future__ import annotations

import argparse
import json
import sys
import os

from .core import Proposal, JudgeEngine, JudgeGrade, PROPOSAL_SCORE
from .rules import RuleBasedJudge
from .history import JudgeHistory
from .metrics import EvolutionDashboard, _indicator_bar


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tianlong-judge",
        description="SentriKit — Agent-as-a-Judge 进化方向评估引擎。"
                    "对 Agent 变更提案进行 5 维评分，判断变更质量与方向。",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # evaluate 子命令
    eval_p = sub.add_parser("evaluate", help="评估一个变更提案")
    eval_p.add_argument(
        "--proposal", "-p",
        type=str,
        required=True,
        help="提案摘要描述（如：'优化搜索流程，减少用户操作步骤'）",
    )
    eval_p.add_argument(
        "--id",
        type=str,
        default="cli",
        help="提案 ID (默认: cli)",
    )
    eval_p.add_argument(
        "--type", "-t",
        type=str,
        choices=["create", "update", "delete", "config", "execute"],
        default="update",
        help="变更类型 (默认: update)",
    )
    eval_p.add_argument(
        "--steps", "-s",
        type=int,
        default=5,
        help="预估步骤数 (默认: 5)",
    )
    eval_p.add_argument(
        "--tokens",
        type=int,
        default=2000,
        help="预估 Token 消耗 (默认: 2000)",
    )
    eval_p.add_argument(
        "--target",
        type=str,
        default="",
        help="操作目标文件或模块",
    )
    eval_p.add_argument(
        "--description", "-d",
        type=str,
        default="",
        help="详细描述（可选，默认使用 --proposal 的值）",
    )
    eval_p.add_argument(
        "--rsi",
        type=str,
        choices=["yes", "no"],
        default="yes",
        help="是否朝 RSI 方向 (默认: yes)",
    )
    eval_p.add_argument(
        "--failures",
        type=int,
        default=0,
        help="同类提案历史失败次数 (默认: 0)",
    )
    eval_p.add_argument(
        "--llm",
        action="store_true",
        help="使用 LLM API 评估（需要设置 DEEPSEEK_API_KEY 环境变量）",
    )
    eval_p.add_argument(
        "--output", "-o",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式: text 或 json (默认: text)",
    )

    # template 子命令
    tmpl_p = sub.add_parser("template", help="从预设模板快速评估")
    tmpl_p.add_argument(
        "--name", "-n",
        type=str,
        required=True,
        choices=list(PROPOSAL_SCORE.keys()),
        help=f"模板名称，可选: {', '.join(PROPOSAL_SCORE.keys())}",
    )
    tmpl_p.add_argument(
        "--output", "-o",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式: text 或 json (默认: text)",
    )

    # history 子命令
    hist_p = sub.add_parser("history", help="查看评估历史记录")
    hist_p.add_argument(
        "--limit", "-n",
        type=int,
        default=10,
        help="显示最近 N 条 (默认: 10)",
    )
    hist_p.add_argument(
        "--grade", "-g",
        type=str,
        choices=["S", "A", "B", "C", "D"],
        default=None,
        help="按等级筛选",
    )
    hist_p.add_argument(
        "--passed",
        type=str,
        choices=["yes", "no"],
        default=None,
        help="按是否通过筛选",
    )
    hist_p.add_argument(
        "--file", "-f",
        type=str,
        default=None,
        help="历史文件路径 (默认: ./judge-history.json)",
    )
    hist_p.add_argument(
        "--output", "-o",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式: text 或 json (默认: text)",
    )

    # metrics 子命令
    met_p = sub.add_parser("metrics", help="查看进化指标")
    met_p.add_argument(
        "--days", "-d",
        type=int,
        default=30,
        help="统计最近 N 天 (默认: 30)",
    )
    met_p.add_argument(
        "--file", "-f",
        type=str,
        default=None,
        help="历史文件路径 (默认: ./judge-history.json)",
    )
    met_p.add_argument(
        "--output", "-o",
        type=str,
        choices=["text", "json"],
        default="text",
        help="输出格式: text 或 json (默认: text)",
    )

    return parser


def format_text(result) -> str:
    """格式化为人类可读的文本报告"""
    dim_icons = {
        "direction": "🧭", "efficiency": "⚡",
        "robustness": "🛡️", "reusability": "♻️", "cost_risk": "💰",
    }
    grade_icons = {
        JudgeGrade.S: "🏆", JudgeGrade.A: "✅",
        JudgeGrade.B: "⚠️", JudgeGrade.C: "🔴", JudgeGrade.D: "⛔",
    }

    lines = []
    lines.append(f"SentriKit · Judge 评估报告")
    lines.append(f"{'='*50}")
    lines.append(f"提案ID:    {result.proposal_id}")
    lines.append(f"摘要:      {result.proposal_summary}")
    lines.append(f"时间:      {result.timestamp}")
    lines.append("")

    lines.append("五维评分:")
    for d in result.dimensions:
        icon = dim_icons.get(d.name, "📊")
        bar = _score_bar(d.score)
        lines.append(
            f"  {icon} {d.name:<12s} "
            f"{d.score:.2f} {bar} "
            f"(权重 {d.weight:.2f}, 加权 {d.weighted:.3f})"
        )
        if d.reason:
            lines.append(f"     理由: {d.reason}")

    lines.append("")
    grade_icon = grade_icons.get(result.grade, "❓")
    passed_str = "✅ 通过" if result.passed() else "⛔ 不通过"
    lines.append(
        f"综合评分: {result.total_score:.3f}"
        f"  |  等级: {grade_icon} {result.grade.value}"
        f"  |  判定: {passed_str}"
    )
    lines.append(f"{'='*50}")
    return "\n".join(lines)


def _score_bar(score: float, width: int = 20) -> str:
    """生成一个简单的分数条"""
    filled = max(0, min(width, int(score * width)))
    empty = width - filled
    return "█" * filled + "░" * empty


def cmd_evaluate(args) -> int:
    """处理 evaluate 子命令"""
    # 构建提案
    proposal = Proposal(
        id=args.id,
        summary=args.proposal,
        description=args.description or args.proposal,
        change_type=args.type,
        target=args.target,
        estimated_steps=args.steps,
        estimated_tokens=args.tokens,
        previous_failures=args.failures,
        is_rsi_aligned=(args.rsi == "yes"),
    )

    # 选择引擎
    if args.llm:
        # LLM 模式
        from .llm import LLMJudge
        judge = LLMJudge()
        judge.configure(
            api_key=os.environ.get("DEEPSEEK_API_KEY", ""),
        )
        if not judge.is_llm_available:
            print("⚠️  未配置 DEEPSEEK_API_KEY 环境变量，降级到规则引擎模式")
            judge = RuleBasedJudge()
    else:
        judge = RuleBasedJudge()

    # 执行评估
    result = judge.evaluate(proposal)

    if args.output == "json":
        output = result.to_dict()
        # 额外字段
        output["method"] = "llm" if args.llm else "rules"
        output["proposal"] = {
            "summary": args.proposal,
            "change_type": args.type,
            "estimated_steps": args.steps,
            "estimated_tokens": args.tokens,
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(format_text(result))

    return 0 if result.passed() else 1


def cmd_template(args) -> int:
    """处理 template 子命令"""
    judge = RuleBasedJudge()
    result = judge.evaluate_from_template(args.name, f"tmpl-{args.name}")

    if args.output == "json":
        output = result.to_dict()
        output["template"] = args.name
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(f"使用模板: {args.name} ({PROPOSAL_SCORE[args.name]['description']})")
        print()
        print(format_text(result))

    return 0 if result.passed() else 1


def cmd_history(args) -> int:
    """处理 history 子命令"""
    hist = JudgeHistory(path=args.file)

    if args.grade or args.passed is not None:
        entries = hist.filter(
            grade=args.grade,
            passed={"yes": True, "no": False}.get(args.passed) if args.passed else None,
        )
    else:
        entries = hist.recent(limit=args.limit)

    if args.output == "json":
        print(json.dumps(entries, ensure_ascii=False, indent=2))
        return 0

    if not entries:
        print("SentriKit · Judge 评估历史")
        print(f"{'='*50}")
        print("(无记录)")
        return 0

    stats = hist.statistics()
    grade_icons = {"S": "🏆", "A": "✅", "B": "⚠️", "C": "🔴", "D": "⛔"}

    print(f"SentriKit · Judge 评估历史")
    print(f"{'='*50}")
    print(f"总计: {stats['total']} 条 | 通过: {stats['passed']} | 失败: {stats['failed']}")
    print(f"通过率: {stats['pass_rate']:.1%} | 平均分: {stats['avg_score']:.3f}")
    print()

    for e in entries:
        icon = grade_icons.get(e.get("grade", ""), "❓")
        passed = "✅" if e.get("passed", False) else "⛔"
        ts = e.get("timestamp", "")[:16]
        summary = (e.get("proposal_summary", "") or "")[:50]
        print(f"  {passed} [{ts}] {icon} {e.get('grade','?')} "
              f"({e.get('total_score',0):.2f}) {summary}")

    return 0


def cmd_metrics(args) -> int:
    """处理 metrics 子命令"""
    hist = JudgeHistory(path=args.file)
    dashboard = EvolutionDashboard(history=hist)

    if args.output == "json":
        report = dashboard.compute(days=args.days)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    print(dashboard.report_text(days=args.days))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "evaluate":
        return cmd_evaluate(args)
    elif args.command == "template":
        return cmd_template(args)
    elif args.command == "history":
        return cmd_history(args)
    elif args.command == "metrics":
        return cmd_metrics(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
