"""tianlong.judge.history — 评估历史持久化

将每次 Judge 评估结果存储为 JSON 日志文件。
支持按时间范围/等级/结果查询，自动管理日志文件大小。

用法:
    history = JudgeHistory(path="judge-history.json")
    history.record(result)        # 记录一次评估
    recent = history.recent(10)   # 最近10条
    by_grade = history.filter(grade="A")
    stats = history.statistics()  # 基础统计
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class JudgeHistory:
    """评估历史持久化存储。

    以 JSON 格式存储每次评估记录。
    线程安全：每次写入都是全量覆写（文件小，单条<1KB）。
    """

    def __init__(self, path: Optional[str] = None):
        self.path = Path(path) if path else Path.cwd() / "judge-history.json"

    # ── 写入 ───────────────────────────────────────────

    def record(self, result_dict: Dict) -> None:
        """记录一次评估结果到历史文件。

        Args:
            result_dict: JudgeResult.to_dict() 的输出，或是兼容的 dict
        """
        entries = self._load_all()
        entry = {
            "timestamp": result_dict.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            "proposal_id": result_dict.get("proposal_id", ""),
            "proposal_summary": result_dict.get("proposal_summary", ""),
            "total_score": result_dict.get("total_score", 0.0),
            "grade": result_dict.get("grade", "D"),
            "passed": result_dict.get("passed", False),
            "dimensions": result_dict.get("dimensions", []),
        }
        entries.append(entry)
        self._save_all(entries)

    def record_dicts(self, result_dicts: List[Dict]) -> None:
        """批量记录多条评估结果。"""
        if not result_dicts:
            return
        entries = self._load_all()
        for rd in result_dicts:
            entries.append({
                "timestamp": rd.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                "proposal_id": rd.get("proposal_id", ""),
                "proposal_summary": rd.get("proposal_summary", ""),
                "total_score": rd.get("total_score", 0.0),
                "grade": rd.get("grade", "D"),
                "passed": rd.get("passed", False),
                "dimensions": rd.get("dimensions", []),
            })
        self._save_all(entries)

    # ── 查询 ───────────────────────────────────────────

    def recent(self, limit: int = 10) -> List[Dict]:
        """获取最近 N 条评估记录。"""
        entries = self._load_all()
        return entries[-limit:]

    def filter(
        self,
        grade: Optional[str] = None,
        passed: Optional[bool] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        proposal_id: Optional[str] = None,
    ) -> List[Dict]:
        """按条件筛选评估记录。

        Args:
            grade: 等级过滤，如 "S", "A", "B", "C", "D"
            passed: 是否通过
            since: 起始时间 "YYYY-MM-DD"
            until: 截止时间 "YYYY-MM-DD"
            proposal_id: 提案 ID 精确匹配

        Returns:
            匹配的记录列表（按时间倒序）
        """
        entries = self._load_all()
        result = []

        for e in entries:
            if grade and e.get("grade") != grade:
                continue
            if passed is not None and e.get("passed") != passed:
                continue
            if since and e.get("timestamp", "")[:10] < since:
                continue
            if until and e.get("timestamp", "")[:10] > until:
                continue
            if proposal_id and e.get("proposal_id") != proposal_id:
                continue
            result.append(e)

        # 按时间倒序
        result.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
        return result

    def get_by_id(self, proposal_id: str) -> Optional[Dict]:
        """按提案 ID 精确查找。"""
        entries = self._load_all()
        for e in reversed(entries):
            if e.get("proposal_id") == proposal_id:
                return e
        return None

    def count(self) -> int:
        """总记录数。"""
        return len(self._load_all())

    def clear(self) -> None:
        """清空历史记录（测试用）。"""
        self._save_all([])

    # ── 统计 ───────────────────────────────────────────

    def statistics(self) -> Dict:
        """基础统计。"""
        entries = self._load_all()
        if not entries:
            return {
                "total": 0, "passed": 0, "failed": 0,
                "avg_score": 0.0,
            }

        total = len(entries)
        passed = sum(1 for e in entries if e.get("passed", False))
        failed = total - passed
        scores = [e.get("total_score", 0.0) for e in entries]
        avg_score = sum(scores) / total if scores else 0.0

        return {
            "total": total,
            "passed": passed,
            "failed": failed,
            "pass_rate": round(passed / total, 3) if total > 0 else 0.0,
            "avg_score": round(avg_score, 3),
        }

    # ── 文件操作 ───────────────────────────────────────

    def _load_all(self) -> List[Dict]:
        """从 JSON 文件加载所有记录。"""
        if not self.path.exists():
            return []
        try:
            raw = self.path.read_text(encoding="utf-8")
            data = json.loads(raw)
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            return []

    def _save_all(self, entries: List[Dict]) -> None:
        """将所有记录写入 JSON 文件。"""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(entries, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
