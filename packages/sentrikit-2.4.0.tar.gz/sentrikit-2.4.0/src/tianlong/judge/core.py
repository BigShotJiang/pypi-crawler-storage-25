"""tianlong.judge.core — 评估引擎核心

包含 JudgeResult、JudgeGrade 数据模型和 JudgeEngine 基类。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Tuple


class JudgeGrade(Enum):
    """评分等级"""
    S = "S"   # 优秀 — 优先执行
    A = "A"   # 良好 — 正常执行
    B = "B"   # 一般 — 需二次评估
    C = "C"   # 较差 — 阻止执行
    D = "D"   # 很差 — 阻止执行


# 综合分 → 等级映射
GRADE_THRESHOLDS: List[Tuple[float, JudgeGrade]] = [
    (0.85, JudgeGrade.S),
    (0.70, JudgeGrade.A),
    (0.50, JudgeGrade.B),
    (0.30, JudgeGrade.C),
]


def score_to_grade(score: float) -> JudgeGrade:
    """将综合分转为等级"""
    for threshold, grade in GRADE_THRESHOLDS:
        if score >= threshold:
            return grade
    return JudgeGrade.D


# 五维评分权重
DEFAULT_WEIGHTS = {
    "direction": 0.25,    # 方向性
    "efficiency": 0.20,   # 效率
    "robustness": 0.20,   # 鲁棒性
    "reusability": 0.15,  # 可复用性
    "cost_risk": 0.20,    # 成本风险
}


@dataclass
class DimensionScore:
    """单个维度的评分"""
    name: str
    score: float        # 0-1
    weight: float       # 权重
    reason: str = ""    # 评分理由

    @property
    def weighted(self) -> float:
        return self.score * self.weight


@dataclass
class JudgeResult:
    """一次评估的完整结果"""
    proposal_id: str
    proposal_summary: str
    dimensions: List[DimensionScore]
    total_score: float = 0.0
    grade: JudgeGrade = JudgeGrade.B
    timestamp: str = ""
    details: Optional[Dict] = None

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.total_score = sum(d.weighted for d in self.dimensions)
        self.grade = score_to_grade(self.total_score)

    def passed(self) -> bool:
        """是否通过评估（B级及以上通过）"""
        return self.grade in (JudgeGrade.S, JudgeGrade.A, JudgeGrade.B)

    def to_dict(self) -> Dict:
        return {
            "proposal_id": self.proposal_id,
            "proposal_summary": self.proposal_summary,
            "total_score": round(self.total_score, 3),
            "grade": self.grade.value,
            "passed": self.passed(),
            "timestamp": self.timestamp,
            "dimensions": [
                {"name": d.name, "score": d.score, "weight": d.weight,
                 "weighted": round(d.weighted, 3), "reason": d.reason}
                for d in self.dimensions
            ],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)


# 提案数据模型
@dataclass
class Proposal:
    """一个变更提案"""
    id: str
    summary: str                       # 变更摘要
    description: str = ""              # 详细描述
    change_type: str = "update"        # create/update/delete/config
    target: str = ""                   # 目标文件
    estimated_steps: int = 5           # 预估步骤数
    estimated_tokens: int = 2000       # 预估 Token 消耗
    previous_failures: int = 0         # 同类提案历史失败次数
    is_rsi_aligned: bool = True        # 是否朝 RSI 方向


# 预设提案模板（用于测试和标准场景）
PROPOSAL_SCORE = {
    "create_new_knowledge": {
        "description": "新增知识/洞察",
        "direction": 0.8, "efficiency": 0.7,
        "robustness": 0.6, "reusability": 0.8, "cost_risk": 0.9,
    },
    "update_process": {
        "description": "修改已有流程",
        "direction": 0.7, "efficiency": 0.6,
        "robustness": 0.7, "reusability": 0.6, "cost_risk": 0.7,
    },
    "delete_content": {
        "description": "删除内容",
        "direction": 0.3, "efficiency": 0.5,
        "robustness": 0.3, "reusability": 0.2, "cost_risk": 0.2,
    },
    "optimize_performance": {
        "description": "性能优化",
        "direction": 0.9, "efficiency": 0.9,
        "robustness": 0.7, "reusability": 0.6, "cost_risk": 0.8,
    },
}


class JudgeEngine:
    """评估引擎基类。

    子类实现 evaluate() 方法。
    RulesJudge 使用规则引擎（不需要 LLM API）。
    LLMJudge 使用大模型评估（需要 API Key）。
    """

    weights: Dict[str, float] = DEFAULT_WEIGHTS

    def evaluate(self, proposal: Proposal) -> JudgeResult:
        """评估提案，返回完整评分结果。子类必须实现。"""
        raise NotImplementedError

    def _build_result(self, proposal: Proposal, scores: Dict[str, Tuple[float, str]]) -> JudgeResult:
        """从维度分数构建 JudgeResult。"""
        dimensions = []
        for dim_name, (score, reason) in scores.items():
            weight = self.weights.get(dim_name, 0.2)
            dimensions.append(DimensionScore(
                name=dim_name,
                score=max(0.0, min(1.0, score)),
                weight=weight,
                reason=reason,
            ))
        return JudgeResult(
            proposal_id=proposal.id,
            proposal_summary=proposal.summary,
            dimensions=dimensions,
        )
