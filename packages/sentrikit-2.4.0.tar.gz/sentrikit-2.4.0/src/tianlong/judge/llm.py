"""tianlong.judge.llm — LLM 驱动的 Judge 实现

LLMJudge 调用大模型 API 进行深度评估。
支持 DeepSeek 和其他兼容 OpenAI 格式的 API。
当 LLM 不可用时自动降级到规则引擎。
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Dict, Optional, Tuple
from urllib.request import Request, urlopen
from urllib.error import URLError

from .core import JudgeEngine, JudgeResult, Proposal, DimensionScore
from .rules import RuleBasedJudge


@dataclass
class LLMConfig:
    """LLM API 配置"""
    api_key: str = ""
    base_url: str = "https://api.deepseek.com/v1"
    model: str = "deepseek-chat"
    temperature: float = 0.3       # 低温度保证评分稳定性
    max_tokens: int = 1024
    timeout: int = 30

    @classmethod
    def from_env(cls) -> "LLMConfig":
        """从环境变量加载配置"""
        return cls(
            api_key=os.environ.get("DEEPSEEK_API_KEY", ""),
            base_url=os.environ.get("LLM_BASE_URL", "https://api.deepseek.com/v1"),
            model=os.environ.get("LLM_MODEL", "deepseek-chat"),
        )

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key)


# 评估用的 System Prompt
JUDGE_SYSTEM_PROMPT = """你是一位严谨的 Agent 进化评估专家。请对以下变更提案进行 5 维评分。

评分维度及权重：
1. direction (权重0.25) — 方向性：变更是否朝 Agent 自我改进方向前进？是否新增有价值的能力？
2. efficiency (权重0.20) — 效率：步骤/Token/时间是否更优？是否比现有方案更精简？
3. robustness (权重0.20) — 鲁棒性：边界覆盖和容错是否增强？失败处理是否完善？
4. reusability (权重0.15) — 可复用性：方案能否推广到其他场景？是通用能力还是特例？
5. cost_risk (权重0.20) — 成本风险：失败代价多大？资源消耗合理吗？

请严格按照以下 JSON 格式输出，不要包含其他文字：
{
  "dimensions": {
    "direction": {"score": 0-1, "reason": "评分理由"},
    "efficiency": {"score": 0-1, "reason": "评分理由"},
    "robustness": {"score": 0-1, "reason": "评分理由"},
    "reusability": {"score": 0-1, "reason": "评分理由"},
    "cost_risk": {"score": 0-1, "reason": "评分理由"}
  },
  "summary": "整体评估结论"
}

评分标准：
- 0.85-1.00: 优秀(S级)，强烈推荐执行
- 0.70-0.84: 良好(A级)，推荐执行
- 0.50-0.69: 一般(B级)，需二次评估
- 0.30-0.49: 较差(C级)，不建议执行
- 0.00-0.29: 很差(D级)，阻止执行"""


class LLMJudge(JudgeEngine):
    """LLM 驱动的 Judge 引擎。

    调用 DeepSeek/OpenAI 兼容 API 进行 5 维评分。
    当 LLM 不可用时自动降级到 RuleBasedJudge。

    用法:
        judge = LLMJudge()
        judge.configure(api_key="sk-xxx")  # 或从环境变量加载
        result = judge.evaluate(proposal)
    """

    def __init__(self):
        self.config = LLMConfig.from_env()
        self._fallback = RuleBasedJudge()
        self._last_raw_response: Optional[str] = None

    def configure(self, **kwargs) -> "LLMJudge":
        """动态配置 LLM 参数。支持: api_key, base_url, model, temperature"""
        for k, v in kwargs.items():
            if hasattr(self.config, k):
                setattr(self.config, k, v)
        return self

    @property
    def is_llm_available(self) -> bool:
        return self.config.is_configured

    def evaluate(self, proposal: Proposal) -> JudgeResult:
        if not self.config.is_configured:
            return self._fallback.evaluate(proposal)

        try:
            return self._evaluate_by_llm(proposal)
        except Exception as e:
            print(f"[LLMJudge] LLM 评估失败: {e}，降级到规则引擎")
            return self._fallback.evaluate(proposal)

    def _evaluate_by_llm(self, proposal: Proposal) -> JudgeResult:
        prompt = self._build_prompt(proposal)
        response = self._call_api(prompt)
        scores = self._parse_response(response)
        return self._build_result(proposal, scores)

    def _build_prompt(self, proposal: Proposal) -> str:
        change_type_map = {
            "create": "新增",
            "update": "修改",
            "delete": "删除",
            "config": "配置变更",
            "execute": "执行操作",
        }
        return f"""## 变更提案

提案ID: {proposal.id}
摘要: {proposal.summary}
描述: {proposal.description or proposal.summary}
变更类型: {change_type_map.get(proposal.change_type, proposal.change_type)}
目标: {proposal.target or '无'}
预估步骤数: {proposal.estimated_steps}
预估Token消耗: {proposal.estimated_tokens}
历史失败次数: {proposal.previous_failures}
是否RSI方向: {'是' if proposal.is_rsi_aligned else '否'}"""

    def _call_api(self, prompt: str) -> str:
        payload = json.dumps({
            "model": self.config.model,
            "messages": [
                {"role": "system", "content": JUDGE_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }).encode("utf-8")

        req = Request(
            f"{self.config.base_url}/chat/completions",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.config.api_key}",
            },
            method="POST",
        )

        resp = urlopen(req, timeout=self.config.timeout)
        result = json.loads(resp.read().decode("utf-8"))
        content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
        self._last_raw_response = content
        return content

    def _parse_response(self, content: str) -> Dict[str, Tuple[float, str]]:
        """从 LLM 返回的 JSON 中提取 5 维评分"""
        # 提取 JSON（可能被 markdown 包裹）
        json_str = content.strip()
        json_str = re.sub(r"^```json\s*", "", json_str)
        json_str = re.sub(r"\s*```$", "", json_str)

        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            # 尝试在文本中找 JSON 块
            match = re.search(r"\{[\s\S]*\}", json_str)
            if match:
                try:
                    data = json.loads(match.group())
                except json.JSONDecodeError:
                    raise ValueError(f"LLM 返回非 JSON: {content[:200]}")
            else:
                raise ValueError(f"LLM 返回无 JSON: {content[:200]}")

        dims = data.get("dimensions", data)
        scores: Dict[str, Tuple[float, str]] = {}

        for dim_name in self.weights:
            dim_data = dims.get(dim_name, {})
            if isinstance(dim_data, dict):
                score = float(dim_data.get("score", 0.5))
                reason = str(dim_data.get("reason", ""))
            elif isinstance(dim_data, (int, float)):
                score = float(dim_data)
                reason = "LLM 评分"
            else:
                score = 0.5
                reason = "解析失败"
            scores[dim_name] = (max(0.0, min(1.0, score)), reason)

        return scores

    def get_last_response(self) -> Optional[str]:
        """获取最后一次 LLM 的原始返回（用于调试）"""
        return self._last_raw_response

    def set_fallback(self, fallback: JudgeEngine) -> "LLMJudge":
        """设置自定义降级引擎"""
        self._fallback = fallback
        return self
