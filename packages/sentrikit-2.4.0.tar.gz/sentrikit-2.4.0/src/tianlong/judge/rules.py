"""tianlong.judge.rules — 基于规则引擎的 Judge 实现

RuleBasedJudge 不使用 LLM API，纯本地规则引擎评估。
适合低资源环境、高频评估、或隐私敏感场景。
"""

from __future__ import annotations

from typing import Dict, Tuple

from .core import JudgeEngine, JudgeResult, Proposal, PROPOSAL_SCORE


class RuleBasedJudge(JudgeEngine):
    """基于规则的 Judge 引擎。

    使用预设分数模板 + 启发式规则进行评分。
    5 个维度各按规则判断，最终加权求和得到综合分。
    """

    def evaluate(self, proposal: Proposal) -> JudgeResult:
        scores: Dict[str, Tuple[float, str]] = {}

        # 1. 方向性: 是否朝 RSI 方向
        dir_score = 0.8 if proposal.is_rsi_aligned else 0.3
        if "delete" in proposal.change_type:
            dir_score *= 0.5
        scores["direction"] = (dir_score, self._direction_reason(proposal))

        # 2. 效率: 步骤越少越高分，但删除操作效率扣分
        eff_score = max(0.1, 1.0 - proposal.estimated_steps * 0.1)
        if "delete" in proposal.change_type:
            eff_score *= 0.5
        scores["efficiency"] = (eff_score, f"预估 {proposal.estimated_steps} 步")

        # 3. 鲁棒性: 历史失败次数影响
        rob_score = max(0.2, 1.0 - proposal.previous_failures * 0.2)
        scores["robustness"] = (rob_score, f"历史失败 {proposal.previous_failures} 次")

        # 4. 可复用性: 创建/优化类提案可复用性强
        if proposal.change_type in ("create",):
            reuse_score = 0.8
        elif proposal.change_type in ("update",):
            reuse_score = 0.6
        else:
            reuse_score = 0.3
        scores["reusability"] = (reuse_score, f"变更类型: {proposal.change_type}")

        # 5. 成本风险: Token 消耗越低越高分
        cost_score = max(0.1, 1.0 - proposal.estimated_tokens / 10000)
        scores["cost_risk"] = (cost_score, f"预估 {proposal.estimated_tokens} tokens")

        return self._build_result(proposal, scores)

    @staticmethod
    def _direction_reason(proposal: Proposal) -> str:
        if not proposal.is_rsi_aligned:
            return "非 RSI 方向"
        if "delete" in proposal.change_type:
            return "RSI 方向但涉及删除操作"
        return f"RSI 方向: {proposal.summary[:60]}"

    def evaluate_from_template(self, template_name: str, proposal_id: str = "auto") -> JudgeResult:
        """从预设模板快速评估。"""
        if template_name not in PROPOSAL_SCORE:
            raise ValueError(f"未知模板: {template_name}, 可选: {list(PROPOSAL_SCORE.keys())}")

        tmpl = PROPOSAL_SCORE[template_name]
        scores = {
            "direction": (tmpl["direction"], tmpl["description"]),
            "efficiency": (tmpl["efficiency"], "模板预设"),
            "robustness": (tmpl["robustness"], "模板预设"),
            "reusability": (tmpl["reusability"], "模板预设"),
            "cost_risk": (tmpl["cost_risk"], "模板预设"),
        }

        return self._build_result(
            Proposal(id=proposal_id, summary=tmpl["description"], change_type="update"),
            scores,
        )
