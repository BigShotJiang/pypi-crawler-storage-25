"""tianlong.judge — Agent-as-a-Judge 进化方向评估引擎

对 Agent 的变更提案做 5 维评分，判断变更的质量和方向。
支持双模式：规则引擎（离线/本地）和 LLM API（在线/深度评估）。

用法:
    # 规则引擎模式（零依赖）
    from tianlong.judge import RuleBasedJudge, Proposal
    judge = RuleBasedJudge()
    result = judge.evaluate(Proposal(id="p1", summary="优化流程"))
    print(result.to_json())

    # LLM 模式（需要 API Key）
    from tianlong.judge import LLMJudge
    judge = LLMJudge()
    judge.configure(api_key="sk-xxx")
    result = judge.evaluate(Proposal(id="p1", summary="优化流程"))
"""

from .core import JudgeEngine, JudgeResult, JudgeGrade, Proposal, DimensionScore, PROPOSAL_SCORE
from .rules import RuleBasedJudge
from .llm import LLMJudge, LLMConfig
from .history import JudgeHistory
from .metrics import EvolutionDashboard
