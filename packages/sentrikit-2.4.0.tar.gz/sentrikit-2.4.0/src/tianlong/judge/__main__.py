"""tianlong.judge.__main__ — `python -m tianlong.judge` 入口"""
from .cli import main
import sys

sys.exit(main())
