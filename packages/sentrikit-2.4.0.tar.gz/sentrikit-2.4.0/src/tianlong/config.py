"""tianlong.config — SentriKit 配置管理

存储用户凭证和配置到 ~/.sentrikit/config.json。
不上传到Git，不写入代码。

用法:
    sentrikit-config set pypi_token <token>
    sentrikit-config get pypi_token
    sentrikit-config list
    sentrikit-config delete pypi_token
"""

from __future__ import annotations

import base64
import json
import os
import sys
from pathlib import Path

CONFIG_DIR = Path.home() / ".sentrikit"
CONFIG_FILE = CONFIG_DIR / "config.json"

# 简单混淆密钥（不加密，只是防明文浏览）
_OBSF_KEY = "tl2026"

ALLOWED_KEYS = {
    "pypi_token": "PyPI API Token（用于 twine upload）",
    "github_token": "GitHub Personal Access Token",
    "openai_key": "OpenAI API Key",
    "deepseek_key": "DeepSeek API Key",
    "api_key": "SentriKit企业版 API Key",
}

SENSITIVE_KEYS = {"pypi_token", "github_token", "openai_key", "deepseek_key", "api_key"}


def _obfuscate(value: str) -> str:
    """XOR + base64 简单混淆敏感值。"""
    encoded = bytes([ord(c) ^ ord(_OBSF_KEY[i % len(_OBSF_KEY)]) for i, c in enumerate(value)])
    return base64.b64encode(encoded).decode()


def _deobfuscate(obfuscated: str) -> str:
    """还原混淆值。"""
    decoded = base64.b64decode(obfuscated.encode())
    return "".join(chr(b ^ ord(_OBSF_KEY[i % len(_OBSF_KEY)])) for i, b in enumerate(decoded))


def ensure_config() -> dict:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        try:
            raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            # 解混淆敏感值
            for k in SENSITIVE_KEYS:
                if k in raw and isinstance(raw[k], str) and not raw[k].startswith("sk-"):
                    try:
                        raw[k] = _deobfuscate(raw[k])
                    except Exception:
                        pass
            return raw
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(data: dict) -> None:
    # 混淆敏感值
    out = dict(data)
    for k in SENSITIVE_KEYS:
        if k in out and out[k]:
            out[k] = _obfuscate(out[k])
    CONFIG_FILE.write_text(
        json.dumps(out, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    # 确保只有owner可读写
    CONFIG_FILE.chmod(0o600)


def cmd_set(key: str, value: str) -> int:
    if key not in ALLOWED_KEYS:
        print(f"❌ 不允许的配置项: {key}")
        print(f"   允许的: {', '.join(ALLOWED_KEYS.keys())}")
        return 1
    data = ensure_config()
    data[key] = value
    save_config(data)
    print(f"✅ 已设置 {key}")
    return 0


def cmd_get(key: str) -> int:
    data = ensure_config()
    if key not in data:
        print(f"❌ {key} 未设置")
        return 1
    val = data[key]
    if key in SENSITIVE_KEYS:
        print(f"{key}: {'*' * min(len(val), 16)} (已隐藏)")
    else:
        print(f"{key}: {val}")
    return 0


def cmd_list() -> int:
    data = ensure_config()
    if not data:
        print("配置为空 (~/.sentrikit/config.json)")
        return 0
    print(f"配置 (~/.sentrikit/config.json):")
    for key, desc in ALLOWED_KEYS.items():
        if key in data:
            val = data[key]
            masked = f"{'*' * min(len(val), 16)}" if key in SENSITIVE_KEYS else val
            print(f"  ✅ {key} = {masked}")
        else:
            print(f"  ❌ {key} — {desc}（未设置）")
    return 0


def cmd_delete(key: str) -> int:
    data = ensure_config()
    if key not in data:
        print(f"❌ {key} 未设置，无需删除")
        return 1
    del data[key]
    save_config(data)
    print(f"✅ 已删除 {key}")
    return 0


def cmd_upload() -> int:
    """用配置中的 pypi_token 上传 dist/ 目录下的包。"""
    data = ensure_config()
    token = data.get("pypi_token")
    if not token:
        print("❌ 未设置 pypi_token，请先运行: sentrikit-config set pypi_token <token>")
        return 1
    import subprocess
    env = os.environ.copy()
    env["TWINE_USERNAME"] = "__token__"
    env["TWINE_PASSWORD"] = token
    result = subprocess.run(
        ["twine", "upload", "dist/*"],
        env=env,
        capture_output=True,
        text=True,
    )
    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr)
        return result.returncode
    print("✅ 上传成功")
    return 0


def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    if not argv:
        print("用法:")
        print("  sentrikit-config set <key> <value>   设置配置项")
        print("  sentrikit-config get <key>           查看配置项")
        print("  sentrikit-config list                列出所有配置")
        print("  sentrikit-config delete <key>        删除配置项")
        print("  sentrikit-config upload              用保存的 PyPI token 上传包")
        print()
        print("可用配置项:")
        for key, desc in ALLOWED_KEYS.items():
            print(f"  {key}: {desc}")
        return 0

    cmd = argv[0]

    if cmd == "set":
        if len(argv) < 3:
            print("用法: sentrikit-config set <key> <value>")
            return 1
        return cmd_set(argv[1], argv[2])
    elif cmd == "get":
        if len(argv) < 2:
            print("用法: sentrikit-config get <key>")
            return 1
        return cmd_get(argv[1])
    elif cmd == "list":
        return cmd_list()
    elif cmd == "delete":
        if len(argv) < 2:
            print("用法: sentrikit-config delete <key>")
            return 1
        return cmd_delete(argv[1])
    elif cmd == "upload":
        return cmd_upload()
    else:
        print(f"❌ 未知命令: {cmd}")
        print("可用: set | get | list | delete | upload")
        return 1


if __name__ == "__main__":
    sys.exit(main())
