"""tianlong.agents.templates — 4 种 Agent 可执行模板

每个模板是一个完整的执行脚本，通过 agent-run 命令调用。
"""

from typing import Dict, List, Optional

# Research Agent 调研模板
RESEARCH_TEMPLATE = """## 调研报告: {topic}

### 1. 核心发现
{findings}

### 2. 高价值机会
{opportunities}

### 3. 风险提示
{risks}

### 4. 建议行动
{actions}
"""


# Code Agent 代码审查模板
CODE_REVIEW_TEMPLATE = """## 代码审查: {file}

### 问题
{issues}

### 建议
{suggestions}

### 评分: {score}/10
"""


# Executor Agent 执行报告模板
EXECUTOR_REPORT_TEMPLATE = """## 执行报告: {task_name}

### 状态: {status}
### 操作
{operations}

### 结果
{result}
"""


# Monitor Agent 监控报告模板
MONITOR_REPORT_TEMPLATE = """## 监控报告

### 时间: {timestamp}
### 健康状态: {health}
### 检查项
{checks}

### 异常
{alerts}
"""


# Sales Agent 销售提案模板
SALES_PROPOSAL_TEMPLATE = """## 销售提案: {company_name}

### 1. 客户概况
{company_profile}

### 2. 需求分析
{needs_analysis}

### 3. SentriKit 价值主张
{value_proposition}

### 4. 推荐方案
{recommended_solution}

### 5. 联系策略
{contact_strategy}

### 6. 跟进计划
{follow_up_plan}

---

*由SentriKit Sales Agent 自动生成 | {generated_at}*
"""

# Sales Agent 客户调研模板
SALES_RESEARCH_TEMPLATE = """## 客户调研报告: {company_name}

### 基础信息
{basic_info}

### AI Agent 成熟度评估
{ai_maturity}

### 安全与合规需求
{security_needs}

### 商业机会评估
{opportunity_assessment}

### 建议切入点
{entry_point}
"""


def render_template(name: str, **kwargs) -> str:
    """渲染指定模板。"""
    templates = {
        "research": RESEARCH_TEMPLATE,
        "code_review": CODE_REVIEW_TEMPLATE,
        "executor": EXECUTOR_REPORT_TEMPLATE,
        "monitor": MONITOR_REPORT_TEMPLATE,
        "sales_proposal": SALES_PROPOSAL_TEMPLATE,
        "sales_research": SALES_RESEARCH_TEMPLATE,
    }
    tpl = templates.get(name, RESEARCH_TEMPLATE)
    return tpl.format(**kwargs)


def get_template_keys(name: str) -> List[str]:
    """获取模板所需的参数名。"""
    keys_map = {
        "research": ["topic", "findings", "opportunities", "risks", "actions"],
        "code_review": ["file", "issues", "suggestions", "score"],
        "executor": ["task_name", "status", "operations", "result"],
        "monitor": ["timestamp", "health", "checks", "alerts"],
        "sales_proposal": ["company_name", "company_profile", "needs_analysis",
                          "value_proposition", "recommended_solution",
                          "contact_strategy", "follow_up_plan", "generated_at"],
        "sales_research": ["company_name", "basic_info", "ai_maturity",
                          "security_needs", "opportunity_assessment", "entry_point"],
    }
    return keys_map.get(name, [])
