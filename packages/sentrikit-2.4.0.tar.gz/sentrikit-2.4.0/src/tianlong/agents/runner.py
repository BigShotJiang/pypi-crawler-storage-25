"""tianlong.agents.runner — Agent 执行器 CLI

用法:
    # Research Agent
    agent-run research --topic "AI Agent 安全" --quick

    # Code Agent
    agent-run code --file /path/to/code.py --action review

    # Executor Agent
    agent-run exec --task "批量处理文件" --action run

    # Monitor Agent
    agent-run monitor --action check
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

from .templates import render_template


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="agent-run",
        description="Sub-Agent 执行器。运行 research/code/executor/monitor/sales Agent。",
    )
    sub = p.add_subparsers(dest="agent", required=True)

    # research
    rp = sub.add_parser("research", help="调研 Agent")
    rp.add_argument("--topic", "-t", type=str, required=True, help="调研主题")
    rp.add_argument("--quick", action="store_true", help="快速查询（单源）")
    rp.add_argument("--context", "-c", type=str, default="", help="上下文")
    rp.add_argument("--output", "-o", type=str, choices=["text", "json"], default="text")

    # code
    cp = sub.add_parser("code", help="代码 Agent")
    cp.add_argument("--file", "-f", type=str, required=True, help="目标文件")
    cp.add_argument("--action", "-a", type=str, choices=["review", "analyze"], default="review",
                    help="操作类型")
    cp.add_argument("--output", "-o", type=str, choices=["text", "json"], default="text")

    # exec
    ep = sub.add_parser("exec", help="执行 Agent")
    ep.add_argument("--task", "-t", type=str, required=True, help="任务描述")
    ep.add_argument("--action", "-a", type=str, default="run", help="操作")
    ep.add_argument("--output", "-o", type=str, choices=["text", "json"], default="text")

    # monitor
    mp = sub.add_parser("monitor", help="监控 Agent")
    mp.add_argument("--action", "-a", type=str, choices=["check", "status"], default="check")
    mp.add_argument("--project-dir", "-d", type=str, default=".", help="项目目录")
    mp.add_argument("--output", "-o", type=str, choices=["text", "json"], default="text")

    # sales
    sp = sub.add_parser("sales", help="销售 Agent")
    sp.add_argument("--company", "-c", type=str, required=True, help="目标公司名称")
    sp.add_argument("--action", "-a", type=str,
                    choices=["research", "proposal", "full"], default="research",
                    help="操作: research=调研, proposal=提案, full=调研+提案")
    sp.add_argument("--context", "-k", type=str, default="", help="额外上下文/已知信息")
    sp.add_argument("--output", "-o", type=str, choices=["text", "json"], default="text")

    return p


def cmd_research(args) -> int:
    try:
        from tianlong.researchengine import ResearchEngine, ResearchType
    except ImportError:
        print("❌ 调研引擎需要企业版（tianlong-researchengine），社区版未安装", file=sys.stderr)
        return 1
    engine = ResearchEngine()
    rtype = ResearchType.QUICK if args.quick else ResearchType.MARKET
    context = getattr(args, 'context', '')
    if context:
        result = engine.research(args.topic, rtype, context)
    else:
        result = engine.research(args.topic, rtype)

    if args.output == "json":
        print(result.to_json())
        return 0

    # 格式化输出
    print(f"\n🔬 调研报告: {result.topic}")
    print(f"{'='*50}")
    print(f"类型: {result.research_type}")
    print(f"耗时: {result.duration_seconds}s")
    print(f"来源: {len(result.sources)}")
    if result.high_value:
        print(f"🔥 高价值发现: {result.high_value_reason}")
    print()
    if result.summary:
        print(result.summary[:500])
    if result.key_points:
        print("\n要点:")
        for i, p in enumerate(result.key_points, 1):
            print(f"  {i}. {p[:100]}")
    return 0


def cmd_code(args) -> int:
    fp = Path(args.file)
    if not fp.exists():
        print(f"❌ 文件不存在: {fp}", file=sys.stderr)
        return 1

    content = fp.read_text(encoding="utf-8", errors="replace")
    lines = content.split("\n")
    issues = []
    suggestions = []

    # 简单静态分析
    if "exec(" in content:
        issues.append("发现 exec() 调用，可能的安全风险")
        suggestions.append("替换为安全替代方案")
    if len(lines) > 500:
        issues.append(f"文件过长 ({len(lines)} 行)")
        suggestions.append("考虑模块化拆分")
    if not content.strip():
        issues.append("空文件")
        suggestions.append("添加实现")

    score = max(0, 10 - len(issues) * 2)

    if args.output == "json":
        print(json.dumps({"file": args.file, "issues": issues, "score": score,
                           "suggestions": suggestions}, ensure_ascii=False, indent=2))
        return 0

    print(render_template("code_review", file=args.file,
                           issues="\n".join(f"- {i}" for i in issues) or "- 无",
                           suggestions="\n".join(f"- {s}" for s in suggestions) or "- 无",
                           score=score))
    return 0


def cmd_exec(args) -> int:
    if args.output == "json":
        print(json.dumps({"task": args.task, "status": "pending", "action": args.action},
                          ensure_ascii=False, indent=2))
        return 0

    print(render_template("executor", task_name=args.task,
                           status="待执行", operations=f"- {args.action}",
                           result="任务已接收"))
    return 0


def cmd_monitor(args) -> int:
    try:
        from tianlong.monitor import run_all_checks
        report = run_all_checks(Path(args.project_dir).resolve())
    except Exception as e:
        report = None
        err = str(e)

    if args.output == "json":
        data = report.to_dict() if report else {"error": err}
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    if report:
        health = report.overall.upper()
        checks_text = "\n".join(f"  {'✅' if c.status=='ok' else '⚠️'} {c.name}: {c.message}"
                                 for c in report.checks)
        alerts = [f"  🔴 {c.message}" for c in report.checks if c.status == "error"]
        print(render_template("monitor", timestamp=report.timestamp,
                               health=health, checks=checks_text,
                               alerts="\n".join(alerts) or "  无"))
    else:
        print(f"❌ 监控检查失败: {err}")
    return 0


def cmd_sales(args) -> int:
    """Sales Agent：客户调研 + 销售提案生成"""
    from datetime import datetime

    company = args.company
    context = args.context or ""
    action = args.action

    if args.output == "json":
        print(json.dumps({
            "company": company, "action": action,
            "status": "dispatched", "message": "Sales Agent 已接收任务（销售宗师已独立为 tianlong-salesmaster）",
        }, ensure_ascii=False, indent=2))
        return 0

    print(f"\n💼 Sales Agent — {company} (已独立为 tianlong-salesmaster)")
    print(f"{'='*50}")
    print("销售能力已迁移至独立项目: pip install tianlong-salesmaster")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return {
        "research": cmd_research,
        "code": cmd_code,
        "exec": cmd_exec,
        "monitor": cmd_monitor,
        "sales": cmd_sales,
    }[args.agent](args)


if __name__ == "__main__":
    sys.exit(main())
