"""tianlong.agents — Sub-Agent SDK

开源版：Sub-Agent SDK（4 种 Agent 配置 + goal 模板 + CLI），开源建生态。
企业版：企业级 Agent（完整执行 + 协同 + 管控），付费。
"""

from .core import build_goal, get_config, AgentConfig
