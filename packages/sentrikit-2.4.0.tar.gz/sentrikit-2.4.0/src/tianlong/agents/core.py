"""tianlong.agents.core — Sub-Agent 配置与 goal 模板
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class AgentConfig:
    role: str = ""
    label: str = ""
    description: str = ""
    default_toolsets: List[str] = field(default_factory=lambda: ["terminal", "file", "search", "web"])
    max_iterations: int = 30


RESEARCH_CONFIG = AgentConfig(
    role="research_agent", label="research-agent",
    description="市场/技术调研、竞品分析、深度研究",
    default_toolsets=["web", "search"], max_iterations=30,
)
CODE_CONFIG = AgentConfig(
    role="code_agent", label="code-agent",
    description="代码开发、重构、审查",
    default_toolsets=["terminal", "file"], max_iterations=40,
)
EXECUTOR_CONFIG = AgentConfig(
    role="executor_agent", label="executor-agent",
    description="文件操作、命令执行、批量处理",
    default_toolsets=["terminal", "file"], max_iterations=20,
)
MONITOR_CONFIG = AgentConfig(
    role="monitor_agent", label="monitor-agent",
    description="系统健康检查、监控巡查",
    default_toolsets=["terminal", "file"], max_iterations=15,
)
SALES_CONFIG = AgentConfig(
    role="sales_agent", label="sales-agent",
    description="销售业务——潜在客户调研、需求分析、销售提案生成、跟进策略",
    default_toolsets=["web", "search"], max_iterations=40,
)


def build_goal(role: str, task: str, context: str = "") -> str:
    role_prefixes = {
        "research_agent": f"作为 Research Agent，请调研以下主题并返回结构化结果。\n\n任务: {task}",
        "code_agent": f"作为 Code Agent，请完成以下开发任务。\n\n任务: {task}",
        "executor_agent": f"作为 Executor Agent，请执行以下操作。\n\n任务: {task}",
        "monitor_agent": f"作为 Monitor Agent，请执行以下检查。\n\n任务: {task}",
        "sales_agent": f"作为 Sales Agent（SentriKit销售大师），你拥有SentriKit的完整销售权限。\n你的任务是：\n1. 研究目标公司/行业\n2. 分析其AI Agent安全、监控、进化方面的需求\n3. 生成定制化销售提案\n4. 提供跟进策略\n\n任务: {task}",
    }
    prefix = role_prefixes.get(role, f"任务: {task}")
    return f"{prefix}\n\n上下文: {context}" if context else prefix


def get_config(role: str) -> AgentConfig:
    return {
        "research_agent": RESEARCH_CONFIG, "code_agent": CODE_CONFIG,
        "executor_agent": EXECUTOR_CONFIG, "monitor_agent": MONITOR_CONFIG,
        "sales_agent": SALES_CONFIG,
    }.get(role, RESEARCH_CONFIG)
