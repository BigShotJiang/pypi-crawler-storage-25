"""tianlong.executor.core — 执行引擎

基于 brain/executor.md 定义的任务执行引擎。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional


SKILL_PRIORITY: Dict[str, List[str]] = {
    "search": ["online-search", "multi-search-engine", "web_search"],
    "file_write": ["write-file", "write"],
    "env_setup": ["env-setup", "exec"],
    "cron": ["cron-scheduler", "cron"],
    "code": ["write", "edit", "exec"],
    "self_check": ["session_status", "exec"],
}


@dataclass
class ExecutionRequest:
    task_type: str = "query"
    goal: str = ""
    tools: List[str] = field(default_factory=list)
    target: str = ""
    estimated_steps: int = 1


@dataclass
class ExecutionResult:
    success: bool = False
    skill_used: str = ""
    result_summary: str = ""
    error: str = ""
    steps_taken: int = 0
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def to_dict(self) -> Dict:
        return asdict(self)


class Executor:
    def __init__(self, project_dir: Optional[Path] = None):
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()

    def resolve_skills(self, task_type: str) -> List[str]:
        return SKILL_PRIORITY.get(task_type, [])

    def precheck(self, request: ExecutionRequest) -> Optional[str]:
        if "delete" in request.goal.lower() or "remove" in request.goal.lower():
            if "backup" not in request.goal.lower():
                return "删除/破坏性操作需用户确认"
        if "send" in request.goal.lower() or "message" in request.goal.lower():
            return "外部发送操作需检查授权"
        immutable = ["safety-guard.md", "SOUL.md", "IDENTITY.md",
                      "evolution-authorization.md"]
        if any(p in request.target.lower() for p in immutable):
            if "write" in request.task_type or "update" in request.task_type:
                return f"目标文件不可修改: {request.target}"
        return None

    def execute(self, request: ExecutionRequest) -> ExecutionResult:
        block_reason = self.precheck(request)
        if block_reason:
            return ExecutionResult(success=False, error=block_reason)

        skills = self.resolve_skills(request.task_type)
        if not skills:
            return ExecutionResult(success=False, error=f"未知任务类型: {request.task_type}")

        skill_used = skills[0]
        if request.tools:
            for s in skills:
                if s in request.tools:
                    skill_used = s
                    break

        return ExecutionResult(
            success=True,
            skill_used=skill_used,
            result_summary=f"使用 {skill_used} 执行: {request.goal[:60]}",
            steps_taken=request.estimated_steps,
        )

    def record(self, result: ExecutionResult) -> None:
        wm_path = self.project_dir / "brain" / "working-memory.md"
        if not wm_path.parent.exists():
            return
        entry = (
            f"\n## Executor {result.timestamp[:16]}\n"
            f"- 状态: {'✅ 成功' if result.success else '❌ 失败'}\n"
            f"- 技能: {result.skill_used or '无'}\n"
            f"- 结果: {result.result_summary or result.error}\n"
        )
        content = wm_path.read_text(encoding="utf-8") if wm_path.exists() else "# 工作记忆\n"
        content += entry
        wm_path.write_text(content, encoding="utf-8")
