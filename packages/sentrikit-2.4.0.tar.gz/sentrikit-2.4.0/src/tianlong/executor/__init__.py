"""tianlong.executor — 执行层

基于 brain/executor.md 的任务执行引擎。
"""

from .core import Executor, ExecutionRequest, ExecutionResult
