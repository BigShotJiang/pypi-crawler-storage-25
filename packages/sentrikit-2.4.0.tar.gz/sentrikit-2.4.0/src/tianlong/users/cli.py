"""tianlong.users.cli — 用户管理 CLI

用法:
    tianlong-users login          # 登录（开源版：单用户 admin）
    tianlong-users list            # 列出用户
    tianlong-users create <name>   # 企业版：创建多用户
    tianlong-users remove <name>   # 企业版：删除用户
"""

from __future__ import annotations

import argparse
import getpass
import json
import sys
from pathlib import Path

from . import get_user_manager


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tianlong-users",
        description="SentriKit · 用户管理 — 登录/创建/列表",
    )
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("login", help="登录获取 Token")
    sub.add_parser("list", help="列出所有用户")

    cp = sub.add_parser("create", help="创建新用户")
    cp.add_argument("username", type=str, help="用户名")
    cp.add_argument("--role", type=str, default="user",
                    choices=["admin", "user", "readonly"], help="角色")
    cp.add_argument("--project-dir", type=str, default="", help="工作目录")

    rp = sub.add_parser("remove", help="删除用户")
    rp.add_argument("username", type=str, help="用户名")

    cpw = sub.add_parser("change-password", help="修改用户密码")
    cpw.add_argument("username", type=str, nargs="?", default=None,
                     help="用户名（默认当前登录用户）")

    return p


def cmd_change_password(args) -> int:
    um = get_user_manager()
    username = args.username or "admin"
    user = um.get_user(username)
    if not user:
        print(f"❌ 用户不存在: {username}")
        return 1
    password = getpass.getpass("新密码: ")
    confirm = getpass.getpass("确认新密码: ")
    if password != confirm:
        print("❌ 两次密码不一致")
        return 1
    if len(password) < 6:
        print("❌ 密码长度至少6位")
        return 1
    try:
        from ..users import _hash_password
        um._users[username].password_hash = um._hash_password(password)
        um._save_users()
        print(f"✅ 密码已修改: {username}")
        return 0
    except Exception as e:
        print(f"❌ 修改失败: {e}")
        return 1


def cmd_login(args) -> int:
    um = get_user_manager()
    username = input("用户名: ").strip()
    if not username:
        print("用户名不能为空")
        return 1
    password = getpass.getpass("密码: ")
    token = um.authenticate(username, password)
    if token:
        print(f"\n✅ 登录成功")
        print(f"Token: {token}")
        print()
        print(f"保存到环境变量:")
        print(f"  export ADMIN_TOKEN={token}")
        print()
        print(f"或直接使用:")
        print(f"  curl -H 'X-Auth-Token: {token}' http://localhost:9901/api/status")
        return 0
    else:
        print("\n❌ 用户名或密码错误")
        return 1


def cmd_list(args) -> int:
    um = get_user_manager()
    users = um.list_users()
    if not users:
        print("暂无用户")
        return 0
    print(f"\n{'='*50}")
    print(f"  用户列表 ({len(users)} 个)")
    print(f"{'='*50}\n")
    for u in users:
        print(f"  👤 {u['username']:12} 角色: {u['role']:10} 启用: {u['enabled']}")
        print(f"     目录: {u.get('project_dir', '-')}")
        print(f"     创建: {u.get('created_at', '-')}")
        print()
    return 0


def cmd_create(args) -> int:
    """创建用户（企业版功能）。"""
    um = get_user_manager()
    password = getpass.getpass("密码: ")
    confirm = getpass.getpass("确认密码: ")
    if password != confirm:
        print("❌ 两次密码不一致")
        return 1
    try:
        user = um.create_user(
            username=args.username,
            password=password,
            role=args.role,
            project_dir=args.project_dir,
        )
        print(f"\n✅ 用户创建成功: {user.username} (角色: {user.role})")
        return 0
    except ValueError as e:
        print(f"❌ {e}")
        return 1


def cmd_remove(args) -> int:
    """删除用户（企业版功能）。"""
    um = get_user_manager()
    try:
        ok = um.remove_user(args.username)
        if ok:
            print(f"✅ 已删除用户: {args.username}")
            return 0
        else:
            print(f"❌ 用户不存在: {args.username}")
            return 1
    except ValueError as e:
        print(f"❌ {e}")
        return 1


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.command == "login":
        return cmd_login(args)
    elif args.command == "list":
        return cmd_list(args)
    elif args.command == "create":
        return cmd_create(args)
    elif args.command == "remove":
        return cmd_remove(args)
    elif args.command == "change-password":
        return cmd_change_password(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
