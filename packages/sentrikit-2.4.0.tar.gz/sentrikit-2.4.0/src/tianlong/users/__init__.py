"""tianlong.users — 用户管理

开源版：单用户（admin），个人够用。
企业版：多用户 + SSO + RBAC，团队管理是核心付费点。
"""

from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional


# ── 存储路径 ──

USERS_DIR = Path.home() / ".sentrikit" / "users"
USERS_FILE = USERS_DIR / "users.json"
SESSIONS_FILE = USERS_DIR / "sessions.json"
TOKEN_EXPIRE_SECONDS = 86400 * 7  # 7天
_DEFAULT_PASSWORD = "sentrikit"   # 首次安装默认密码，请立即修改
_MAX_FREE_USERS = 2  # 社区版最多2个用户（admin + 1个）


# ── 数据模型 ──


@dataclass
class User:
    """一个用户"""
    id: str = ""
    username: str = ""
    password_hash: str = ""
    role: str = "user"           # admin / user / readonly
    project_dir: str = ""        # 用户独立工作目录
    created_at: str = ""
    enabled: bool = True

    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("password_hash", None)  # 不暴露hash
        return d


@dataclass
class Session:
    """登录会话"""
    token: str = ""
    user_id: str = ""
    username: str = ""
    created_at: float = 0.0
    expires_at: float = 0.0

    @property
    def expired(self) -> bool:
        return time.time() > self.expires_at

    def to_dict(self) -> dict:
        return asdict(self)


# ── 用户管理器 ──


class UserManager:
    """多用户管理器"""

    def __init__(self):
        self._users: Dict[str, User] = {}       # username -> User
        self._sessions: Dict[str, Session] = {}  # token -> Session
        self._load()

    # ── 持久化 ──

    def _load(self) -> None:
        USERS_DIR.mkdir(parents=True, exist_ok=True)
        if USERS_FILE.exists():
            try:
                data = json.loads(USERS_FILE.read_text(encoding="utf-8"))
                for u in data.get("users", []):
                    user = User(**u)
                    self._users[user.username] = user
            except Exception:
                pass
        if SESSIONS_FILE.exists():
            try:
                data = json.loads(SESSIONS_FILE.read_text(encoding="utf-8"))
                for s in data.get("sessions", []):
                    sess = Session(**s)
                    if not sess.expired:
                        self._sessions[sess.token] = sess
            except Exception:
                pass

        # 默认创建 admin 用户
        if "admin" not in self._users:
            self._create_default_admin()
            import warnings
            warnings.warn(
                f"默认管理员已创建（admin/{_DEFAULT_PASSWORD}）。"
                "请立即修改密码！使用 `sentrikit-users change-password admin <新密码>`"
            )

    def _save_users(self) -> None:
        USERS_DIR.mkdir(parents=True, exist_ok=True)
        data = {"users": [u.to_dict() for u in self._users.values()]}
        USERS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _save_sessions(self) -> None:
        USERS_DIR.mkdir(parents=True, exist_ok=True)
        data = {"sessions": [s.to_dict() for s in self._sessions.values()]}
        SESSIONS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _create_default_admin(self) -> None:
        """首次启动创建默认管理员"""
        if "admin" in self._users:
            return
        import hashlib
        admin = User(
            id=str(uuid.uuid4())[:8],
            username="admin",
            password_hash=hashlib.sha256(_DEFAULT_PASSWORD.encode()).hexdigest(),
            role="admin",
            project_dir=str(Path.cwd()),
            created_at=time.strftime("%Y-%m-%d %H:%M:%S"),
        )
        self._users["admin"] = admin
        self._save_users()

    @staticmethod
    def _hash_password(password: str) -> str:
        return hashlib.sha256(password.encode()).hexdigest()

    @staticmethod
    def _is_enterprise() -> bool:
        """检查企业版是否激活。"""
        try:
            from ..enterprise_client import is_enterprise
            return is_enterprise()
        except ImportError:
            return os.environ.get("TIANLONG_ENTERPRISE", "").lower() in ("1", "true", "yes")

    # ── 用户管理 ──

    def create_user(self, username: str, password: str,
                    role: str = "user", project_dir: str = "") -> User:
        """创建用户（社区版限2用户，企业版无限制）。"""
        # 社区版：限制用户数
        if not self._is_enterprise() and len(self._users) >= _MAX_FREE_USERS:
            raise ValueError(f"社区版最多创建 {_MAX_FREE_USERS} 个用户。企业版无限制（设置 SENTRIKIT_API_KEY）")
        # 企业版：完整多用户管理
        if self._is_enterprise() and len(self._users) >= 100:
            raise ValueError("用户数已达上限（100）")
        if not username or not password:
            raise ValueError("用户名和密码不能为空")
        if username in self._users:
            raise ValueError(f"用户已存在: {username}")
        user = User(
            id=str(uuid.uuid4())[:8],
            username=username,
            password_hash=self._hash_password(password),
            role=role if role in ("admin", "user", "readonly") else "user",
            project_dir=project_dir or str(Path.cwd()),
            created_at=time.strftime("%Y-%m-%d %H:%M:%S"),
        )
        self._users[username] = user
        self._save_users()
        return user

    def get_user(self, username: str) -> Optional[User]:
        return self._users.get(username)

    def list_users(self) -> List[dict]:
        return [u.to_dict() for u in self._users.values()]

    def remove_user(self, username: str) -> bool:
        """删除用户（企业版功能）。"""
        if not self._is_enterprise():
            raise ValueError("多用户管理需要企业版授权（TIANLONG_ENTERPRISE=1）")
        if username == "admin":
            raise ValueError("不能删除 admin 用户")
        if username in self._users:
            del self._users[username]
            # 同时清除该用户的所有session
            to_remove = [t for t, s in self._sessions.items() if s.user_id == username]
            for t in to_remove:
                del self._sessions[t]
            self._save_users()
            self._save_sessions()
            return True
        return False

    # ── 鉴权 ──

    def authenticate(self, username: str, password: str) -> Optional[str]:
        """登录：验证密码，返回 token"""
        user = self._users.get(username)
        if not user or not user.enabled:
            return None
        if user.password_hash != self._hash_password(password):
            return None
        return self._create_session(user)

    def _create_session(self, user: User) -> str:
        now = time.time()
        token = str(uuid.uuid4()) + str(int(now))
        session = Session(
            token=token,
            user_id=user.id,
            username=user.username,
            created_at=now,
            expires_at=now + TOKEN_EXPIRE_SECONDS,
        )
        self._sessions[token] = session
        self._save_sessions()
        return token

    def validate_token(self, token: str) -> Optional[User]:
        """验证 token，返回 User 或 None"""
        session = self._sessions.get(token)
        if not session or session.expired:
            if session:
                del self._sessions[token]
                self._save_sessions()
            return None
        return self._users.get(session.username)

    def logout(self, token: str) -> None:
        if token in self._sessions:
            del self._sessions[token]
            self._save_sessions()


# ── 全局实例 ──

_global_user_manager: Optional[UserManager] = None


def get_user_manager() -> UserManager:
    """获取全局用户管理器实例。

    支持单用户/文件持久化。
    """
    global _global_user_manager
    if _global_user_manager is None:
        _global_user_manager = UserManager()
    return _global_user_manager
