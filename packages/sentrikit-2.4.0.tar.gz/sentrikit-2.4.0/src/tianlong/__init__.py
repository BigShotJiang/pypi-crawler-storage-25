# SPDX-License-Identifier: MIT
# Copyright (c) 2026 SentriKit
"""SentriKit — SentriKit AI Agent Framework

v2.0: 单一 MIT 包 + 服务端 API Key 激活企业版。
安装: pip install sentrikit
激活: export SENTRIKIT_API_KEY="sk-xxx"

模块：
    monitor    — Agent 健康监控（8项内置检查 + 自定义注册 + CLI + 多项目批量）
    safety     — SafetyGuard 安全约束引擎（5条红线 + CLI + 规则热加载 + 退化检测 + 审计日志）
    judge      — Agent-as-a-Judge 进化方向评估引擎（5维评分 + 规则引擎 + LLM API双模式 + CLI）
    evolution  — SelfLearning 进化管道（社区版：基础评分 / 企业版：7步闭环 + API Key）
    reporter   — 主动汇报系统（4种模板 + 多模块数据聚合 + CLI）
    brain      — BrainCore 决策引擎（社区版：FIFO调度 / 企业版：优先级+多租户 + API Key）
    executor   — 执行层（技能优先级 + 执行前检查 + 执行记录）
    agent      — SentriKit Agent 守护进程（开源版：单进程 / 企业版：集群管理）
    agents     — Sub-Agent SDK（4种 Agent 配置 + goal 模板）
    metacog    — MetaCogTrigger 元认知触发器（5类信号监测）
    memory     — MemorySystem 记忆系统（社区版：JSON本地 / 企业版：三层持久化 + API Key）
    onlinestate — 在线状态管理器
    uxu        — UXU AI Agent 安全审计（32条规则 + AST，本地始终可用）
    dashboard  — 全局仪表盘（HTML 报告）
    compintel  — 竞品情报模块（本地采集 + SaaS推送）
    users      — 用户管理
    researhengine — 调研引擎（社区版：本地搜索 / 企业版：4级搜索链 + API Key）
    selfmodel  — SelfModel 自我模型（能力画像 + SelfGraph）
    metaevolve — MetaEVOLVE 元修改器（社区版：基础统计 / 企业版：命中率分析 + API Key）
    dgmh       — DGM-H 元认知架构编排器（社区版：M1基础 / 企业版：M1-M6 + API Key）
    enterprise — 企业版 API 客户端模块
    enterprise_client — 统一企业版 API 入口
"""

from . import monitor, safety, judge, evolution, reporter, brain, executor, agent, agents, metacog, memory, onlinestate, uxu, dashboard, compintel, users, researchengine, selfmodel, metaevolve, dgmh, license, enterprise, enterprise_client

__version__ = "2.3.0"
