# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from tilus.backends.emitter import BaseInstEmitter, register_emitter
from tilus.hidet.ir.primitives.cuda.tcgen05 import (
    Tcgen05CtaGroupKind,
    tcgen05_commit,
)
from tilus.ir.instructions.cuda.tcgen05 import (
    Tcgen05CommitInst,
)
from tilus.target import nvgpu_sm100


@register_emitter(Tcgen05CommitInst, target=nvgpu_sm100)
class TMemoryCommitEmitter(BaseInstEmitter):
    def emit(self, inst: Tcgen05CommitInst) -> None:
        self.assert_is_warp_aligned(inst, "tcgen05 commit is a warp-cooperative instruction")
        self.append(
            tcgen05_commit(
                mbarrier=inst.mbarrier,
                cta_mask=inst.multicast_mask,
                cta_group=Tcgen05CtaGroupKind.from_int(inst.cta_group),
                predicate=self.contexts.leader_lane_ctx.leader_lane,
            )
        )
