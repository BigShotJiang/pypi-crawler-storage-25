# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from tilus.backends.emitter import BaseInstEmitter, register_emitter
from tilus.hidet.ir import logical_or
from tilus.hidet.ir.dtypes import int32, uint32
from tilus.hidet.ir.expr import cast
from tilus.hidet.ir.primitives.cuda.cvta import cvta_generic_to_shared
from tilus.hidet.ir.primitives.cuda.tcgen05 import (
    Tcgen05CtaGroupKind,
    tcgen05_alloc,
    tcgen05_dealloc,
    tcgen05_relinquish_alloc_permit,
)
from tilus.ir.instructions.cuda.tcgen05 import (
    Tcgen05AllocInst,
    Tcgen05DeallocInst,
    Tcgen05RelinquishAllocPermitInst,
    Tcgen05ViewInst,
)
from tilus.ir.tensor import TMemoryTensor
from tilus.target import nvgpu_sm100
from tilus.utils import prod, same_list


class Tcgen05AllocDeallocEmitter(BaseInstEmitter):
    def get_num_columns(self, tmem_tensor: TMemoryTensor) -> int:
        shape = tmem_tensor.shape
        if shape[-2] != 128:
            raise NotImplementedError(f"The emitter currently only supports shape[-2] == 128, but got {shape[-2]}")
        if shape[-1] * tmem_tensor.dtype.nbits % 32 != 0:
            raise ValueError(
                f"shape[-1] * dtype.nbits must be divisible by 32, but got {shape[-1]} * {tmem_tensor.dtype.nbits} = {shape[-1] * tmem_tensor.dtype.nbits}"
            )
        num_columns = prod(shape[:-2]) * shape[-1] * tmem_tensor.dtype.nbits // 32

        # the number of columns must be a power-of-two and in the range [32, 512]
        # normalize it to be at least 32 and be a power of two
        if num_columns < 32:
            num_columns = 32
        elif not (num_columns & (num_columns - 1) == 0):  # not a power of two
            # round up to the next power of two
            num_columns = 1 << (num_columns - 1).bit_length()
        if num_columns > 512:
            raise ValueError(
                f"The number of 32-bit columns requested: {num_columns}, it must be in the range [32, 512]."
            )
        return num_columns


@register_emitter(Tcgen05AllocInst, target=nvgpu_sm100)
class Tcgen05AllocEmitter(Tcgen05AllocDeallocEmitter):
    def emit(self, inst: Tcgen05AllocInst) -> None:
        if self.current_num_threads < 32:
            raise ValueError("tcgen05_alloc requires at least 32 threads in the current thread group")

        tmem_tensor = inst.tmemory_output
        num_columns = self.get_num_columns(tmem_tensor)

        # set the cta group in the tcgen05 context
        tcgen05_ctx = self.contexts.tcgen05_ctx
        tcgen05_ctx.set_cta_group(inst.cta_group)

        # allocate a workspace in shared memory to hold the tensor memory handle
        smem_ctx = self.contexts.smem_alloc_ctx
        smem_ptr = smem_ctx.request_shared_workspace(nbytes=4)

        # call tcgen05_alloc
        with self.if_then(logical_or(self.current_num_threads == 32, self.current_thread // 32 == 0)):
            smem_addr = self.declare_var("smem_addr", tp=uint32, init=cvta_generic_to_shared(smem_ptr))
            self.append(
                tcgen05_alloc(
                    dst=smem_addr,
                    num_columns=uint32(num_columns),
                    cta_group=Tcgen05CtaGroupKind.from_int(inst.cta_group),
                )
            )

        # let other warps in the thread group wait until the first warp finishes
        with self.if_then(self.current_num_threads > 32):
            self.sync()

        # load the tensor memory handle from shared memory and store it to the register variable
        tmem_var = self.get_or_allocate_var(tmem_tensor)
        self.assign(tmem_var, cast(smem_ptr, ~int32)[0])
        self.sync()

        # mark the tensor as allocated in the tcgen05 context to track allocations
        tcgen05_ctx.mark_tmemory_tensor_allocate(tmem_tensor)


@register_emitter(Tcgen05DeallocInst, target=nvgpu_sm100)
class Tcgen05DeallocEmitter(Tcgen05AllocDeallocEmitter):
    def emit(self, inst: Tcgen05DeallocInst) -> None:
        tmem_tensor = inst.inputs[0].as_tmemory_tensor()
        tmem_var = self.get_or_allocate_var(tmem_tensor)
        num_columns = self.get_num_columns(tmem_tensor)
        tcgen05_ctx = self.contexts.tcgen05_ctx

        if self.current_num_threads < 32:
            raise ValueError("tcgen05_dealloc requires at least 32 threads in the current thread group")
        with self.if_then(logical_or(self.current_num_threads == 32, self.current_thread // 32 == 0)):
            self.append(
                tcgen05_dealloc(
                    taddr=tmem_var,
                    num_columns=uint32(num_columns),
                    cta_group=Tcgen05CtaGroupKind.from_int(tcgen05_ctx.get_cta_group()),
                )
            )

        # mark the tensor as deallocated in the tcgen05 context to track allocations
        tcgen05_ctx.mark_tmemory_tensor_deallocate(tmem_tensor)


@register_emitter(Tcgen05RelinquishAllocPermitInst, target=nvgpu_sm100)
class Tcgen05RelinquishAllocPermitEmitter(BaseInstEmitter):
    def emit(self, inst: Tcgen05RelinquishAllocPermitInst) -> None:
        self.append(tcgen05_relinquish_alloc_permit(Tcgen05CtaGroupKind.from_int(inst.cta_group)))


@register_emitter(Tcgen05ViewInst, target=nvgpu_sm100)
class TMemoryViewEmitter(BaseInstEmitter):
    def emit(self, inst: Tcgen05ViewInst) -> None:
        tmem_tensor = inst.inputs[0].as_tmemory_tensor()
        output_tmem_tensor = inst.tmemory_output

        if (
            tmem_tensor.dtype.nbits * tmem_tensor.shape[-1]
            != output_tmem_tensor.dtype.nbits * output_tmem_tensor.shape[-1]
        ):
            raise ValueError("The total number of bits must be the same as the original tensor.")

        if not same_list(tmem_tensor.layout.column_strides[:-2], output_tmem_tensor.layout.column_strides[:-2]):
            raise ValueError(
                "The column strides of the leading dimensions (all dimensions except the last two ones) must be the same as the original tensor."
            )

        tmem_addr = self.get_or_allocate_var(tmem_tensor)
        view_addr = self.get_or_allocate_var(output_tmem_tensor, name="tmem_view")
        self.assign(view_addr, tmem_addr)
