# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from tilus.hidet.ir.func import Function
from tilus.hidet.ir.primitives import register_primitive_function


def register_primitive_function_decorator(fn: Function) -> Function:
    if not isinstance(fn, Function):
        raise TypeError(f"Expected a Function, but got {type(fn)}")
    register_primitive_function(fn.name, func_or_type=fn)
    return fn
