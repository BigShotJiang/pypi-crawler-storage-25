# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from tilus.ir.instructions import (
    AllocateRegisterInst,
    AllocateSharedInst,
    AllocBarrierInst,
    CopyAsyncGenericInst,
    CopyAsyncInst,
    FormatPrintInst,
    FreeSharedInst,
    Instruction,
    LoadGlobalGenericInst,
    LoadGlobalInst,
    LoadSharedInst,
    PermuteSharedInst,
    PrintTensorInst,
    ReshapeSharedInst,
    SliceAssignInst,
    SliceRegisterInst,
    SliceSharedInst,
    StoreGlobalGenericInst,
    StoreGlobalInst,
    StoreSharedInst,
)
from tilus.ir.instructions.cuda.clc import ClusterLaunchControlQueryResponseInst, ClusterLaunchControlTryCancelInst
from tilus.ir.instructions.cuda.cp_async_bulk import (
    CopyAsyncBulkGlobalToClusterSharedInst,
    CopyAsyncBulkGlobalToSharedInst,
    CopyAsyncBulkSharedToClusterSharedInst,
    CopyAsyncBulkSharedToGlobalInst,
)
from tilus.ir.instructions.cuda.cp_async_tensor import (
    CopyAsyncTensorGlobalToSharedInst,
    CopyAsyncTensorSharedToGlobalInst,
)
from tilus.ir.instructions.cuda.mapa import MapSharedAddrInst
from tilus.ir.instructions.cuda.tcgen05 import Tcgen05CopyInst, Tcgen05LoadInst, Tcgen05MmaSSInst, Tcgen05StoreInst
from tilus.ir.instructions.cuda.wgmma import WgmmaMmaRSInst, WgmmaMmaSSInst
from tilus.ir.layout.inference.rule import LayoutValidationRule, register_rule


@register_rule(WgmmaMmaSSInst)  # todo: should have its own rule
@register_rule(WgmmaMmaRSInst)  # todo: should have its own rule
@register_rule(Tcgen05LoadInst)  # todo: should have its own rule
@register_rule(Tcgen05StoreInst)  # todo: should have its own rule
@register_rule(Tcgen05CopyInst)  # todo: should have its own rule
@register_rule(Tcgen05MmaSSInst)  # todo: should have its own rule
@register_rule(CopyAsyncTensorGlobalToSharedInst)  # todo: should have its own rule
@register_rule(CopyAsyncTensorSharedToGlobalInst)  # todo: should have its own rule
@register_rule(CopyAsyncBulkSharedToClusterSharedInst)  # todo: should have its own rule
@register_rule(CopyAsyncBulkGlobalToClusterSharedInst)  # todo: should have its own rule
@register_rule(CopyAsyncBulkGlobalToSharedInst)  # todo: should have its own rule
@register_rule(CopyAsyncBulkSharedToGlobalInst)  # todo: should have its own rule
@register_rule(CopyAsyncGenericInst)  # todo: should have its own rule
@register_rule(CopyAsyncInst)  # todo: should have its own rule
@register_rule(SliceRegisterInst)  # todo: should have its own rule
@register_rule(SliceAssignInst)  # todo: should have its own rule
@register_rule(StoreGlobalGenericInst)  # todo: should have its own rule
@register_rule(AllocBarrierInst)  # todo: should have its own rule
@register_rule(MapSharedAddrInst)
@register_rule(ClusterLaunchControlTryCancelInst)
@register_rule(ClusterLaunchControlQueryResponseInst)
@register_rule(StoreSharedInst)
@register_rule(PrintTensorInst)
@register_rule(FormatPrintInst)
@register_rule(LoadGlobalInst)
@register_rule(LoadGlobalGenericInst)
@register_rule(StoreGlobalInst)
@register_rule(SliceSharedInst)
@register_rule(PermuteSharedInst)
@register_rule(ReshapeSharedInst)
@register_rule(LoadSharedInst)
@register_rule(FreeSharedInst)
@register_rule(AllocateRegisterInst)
@register_rule(AllocateSharedInst)
class AlwaysOkayRule(LayoutValidationRule):
    @staticmethod
    def validate(inst: Instruction) -> bool:
        return True


# todo: the following instructions should have dedicated validation rules
class TemporaryAlwaysOkRule(LayoutValidationRule):
    @staticmethod
    def validate(inst: Instruction) -> bool:
        return True
