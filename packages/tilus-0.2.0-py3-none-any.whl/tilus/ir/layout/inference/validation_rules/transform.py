# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from tilus.ir.instructions import SqueezeInst, UnsqueezeInst
from tilus.ir.layout import ops
from tilus.ir.layout.inference.rule import LayoutValidationRule, register_rule
from tilus.ir.tensor import RegisterTensor


@register_rule(SqueezeInst)
class TransposeRule(LayoutValidationRule):
    @staticmethod
    def validate(inst: SqueezeInst) -> bool:
        x: RegisterTensor = inst.register_input
        y: RegisterTensor = inst.register_output

        return y.layout == ops.squeeze(x.layout, dims=inst.dims)


@register_rule(UnsqueezeInst)
class UnsqueezeRule(LayoutValidationRule):
    @staticmethod
    def validate(inst: UnsqueezeInst) -> bool:
        x: RegisterTensor = inst.register_input
        y: RegisterTensor = inst.register_output

        return y.layout == ops.unsqueeze(x.layout, dims=inst.dims)
