"""Tessera authentication."""
