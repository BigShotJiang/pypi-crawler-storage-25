from __future__ import annotations

import contextvars
import functools
import traceback
import uuid
from datetime import datetime, timezone

from .database import _SessionLocal
from .models import WorkflowRun, WorkflowStatus

# Holds the mutable node-collection context for the currently-executing workflow.
# Shape: {"nodes": list[dict]}  — None when not inside a workflow.
_active_run_ctx: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "_active_run_ctx", default=None
)


def _run_summary(run: WorkflowRun) -> dict:
    """Serialise a WorkflowRun to the camelCase summary shape expected by the frontend."""
    return {
        "id": str(run.id),
        "name": run.name,
        "status": run.status.value,
        "triggeredBy": run.triggered_by,
        "startedAt": run.started_at.isoformat() if run.started_at else None,
        "finishedAt": run.finished_at.isoformat() if run.finished_at else None,
        "createdAt": run.created_at.isoformat(),
        "children": [],
    }


def _run_detail(run: WorkflowRun) -> dict:
    """Serialise a WorkflowRun to the full camelCase detail shape (includes nodes)."""
    nodes = [
        {
            "id": n.get("id", str(run.id)),
            "name": n.get("name", run.name),
            "status": n.get("status", run.status.value),
            "inputs": n.get("inputs", {}),
            "outputs": n.get("outputs", {}),
            "durationMs": n.get("duration_ms", 0),
            "logs": n.get("logs"),
        }
        for n in (run.nodes or [])
    ]
    return {**_run_summary(run), "nodes": nodes}


def make_node_wrapper(fn):
    """Wrap *fn* so each call is recorded as a node in the active workflow run.

    If called outside a workflow (no active run context), the function runs
    transparently with no tracking overhead.
    """

    @functools.wraps(fn)
    async def wrapper(inputs: dict):
        ctx = _active_run_ctx.get()
        if ctx is None:
            return await fn(inputs)

        node_id = str(uuid.uuid4())
        node_start = datetime.now(timezone.utc)

        try:
            result = await fn(inputs)
            duration_ms = int((datetime.now(timezone.utc) - node_start).total_seconds() * 1000)
            ctx["nodes"].append({
                "id": node_id,
                "name": fn.__name__,
                "status": "success",
                "inputs": inputs,
                "outputs": result if isinstance(result, dict) else {},
                "duration_ms": duration_ms,
            })
            return result
        except Exception:
            duration_ms = int((datetime.now(timezone.utc) - node_start).total_seconds() * 1000)
            ctx["nodes"].append({
                "id": node_id,
                "name": fn.__name__,
                "status": "failed",
                "inputs": inputs,
                "outputs": {},
                "duration_ms": duration_ms,
                "logs": traceback.format_exc(),
            })
            raise

    wrapper._gtm_fn = fn
    return wrapper


def make_workflow_wrapper(fn):
    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, _trigger_type: str = "manual"):
        if _SessionLocal is None:
            return await fn(inputs)

        from .broadcast import manager

        async with _SessionLocal() as session:
            run = WorkflowRun(
                name=fn.__name__,
                status=WorkflowStatus.running,
                triggered_by=_trigger_type,
                started_at=datetime.now(timezone.utc),
            )
            session.add(run)
            await session.commit()
            await session.refresh(run)

            await manager.broadcast("workflow_list", {"type": "run_created", "data": _run_summary(run)})

            ctx: dict = {"nodes": []}
            token = _active_run_ctx.set(ctx)
            try:
                result = await fn(inputs)
                run.status = WorkflowStatus.success
                if ctx["nodes"]:
                    run.nodes = ctx["nodes"]
                else:
                    run.nodes = [
                        {
                            "id": str(run.id),
                            "name": fn.__name__,
                            "status": "success",
                            "inputs": inputs,
                            "outputs": result if isinstance(result, dict) else {},
                            "duration_ms": int(
                                (datetime.now(timezone.utc) - run.started_at).total_seconds() * 1000
                            ),
                        }
                    ]
            except Exception:
                run.status = WorkflowStatus.failed
                if ctx["nodes"]:
                    run.nodes = ctx["nodes"]
                else:
                    run.nodes = [
                        {
                            "id": str(run.id),
                            "name": fn.__name__,
                            "status": "failed",
                            "inputs": inputs,
                            "outputs": {},
                            "duration_ms": int(
                                (datetime.now(timezone.utc) - run.started_at).total_seconds() * 1000
                            ),
                            "logs": traceback.format_exc(),
                        }
                    ]
                result = None
            finally:
                _active_run_ctx.reset(token)

            run.finished_at = datetime.now(timezone.utc)
            session.add(run)
            await session.commit()

            await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run)})
            await manager.broadcast(f"workflow_detail:{run.id}", {"type": "run_updated", "data": _run_detail(run)})

        return result

    wrapper._gtm_fn = fn
    return wrapper
