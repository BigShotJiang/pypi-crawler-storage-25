"""Seed demo data.

When ``auto_seed`` (GTM_SEED env var) is enabled, always truncates all
tables and re-inserts fresh demo data on every startup.
"""

from __future__ import annotations

import json
import math
from datetime import datetime, timedelta, timezone
from uuid import uuid4


NOW = datetime.now(timezone.utc)

_WORKFLOW_NAMES = [
    "enrich_leads",
    "daily_report",
    "sync_catalog",
    "renewal_check",
    "churn_scoring",
]


def _seeded(n: int) -> float:
    x = math.sin(n + 1) * 10000
    return x - math.floor(x)


def _make_historical_runs() -> list[dict]:
    """~120 runs spread over the last 30 days — used to populate the activity chart."""
    runs: list[dict] = []
    base = NOW - timedelta(days=30)
    hour_ms = 3_600_000
    t = int(base.timestamp() * 1000)
    end = int(NOW.timestamp() * 1000)
    slot = 0
    while t <= end:
        d = datetime.fromtimestamp(t / 1000, tz=timezone.utc)
        is_biz = 8 <= d.hour <= 18 and d.weekday() < 5
        count = int(_seeded(slot) * (12 if is_biz else 3))
        for i in range(count):
            failed = _seeded(slot * 100 + i + 77) < 0.13
            started = datetime.fromtimestamp(t / 1000, tz=timezone.utc)
            finished = started + timedelta(seconds=int(_seeded(slot + i) * 120) + 5)
            wf = _WORKFLOW_NAMES[int(_seeded(slot + i + 3) * len(_WORKFLOW_NAMES))]
            runs.append({
                "id": uuid4(),
                "name": wf,
                "status": "failed" if failed else "success",
                "triggered_by": "scheduler",
                "started_at": started,
                "finished_at": finished,
                "created_at": started,
                "nodes": [],
            })
        t += hour_ms
        slot += 1
    return runs


_DETAILED_RUNS = [
    {
        "id": uuid4(), "name": "enrich_leads", "status": "success",
        "triggered_by": "scheduler",
        "started_at": NOW - timedelta(hours=2),
        "finished_at": NOW - timedelta(hours=2) + timedelta(seconds=38),
        "created_at": NOW - timedelta(hours=2),
        "nodes": [
            {"id": "n1", "name": "Fetch Contacts", "status": "success",
             "inputs": {"limit": 10}, "outputs": {"count": 10}, "duration_ms": 320},
            {"id": "n2", "name": "Enrich via Clearbit", "status": "success",
             "inputs": {"emails": 10}, "outputs": {"enriched": 10}, "duration_ms": 12_000},
        ],
    },
    {
        "id": uuid4(), "name": "daily_report", "status": "failed",
        "triggered_by": "scheduler",
        "started_at": NOW - timedelta(hours=5),
        "finished_at": NOW - timedelta(hours=5) + timedelta(seconds=72),
        "created_at": NOW - timedelta(hours=5),
        "nodes": [
            {"id": "n1", "name": "Aggregate Sales Data", "status": "success",
             "inputs": {"region": "EU"}, "outputs": {"total": 48200}, "duration_ms": 520},
            {"id": "n2", "name": "Generate PDF", "status": "failed",
             "inputs": {"template": "daily_v2"}, "outputs": {"error": "missing field `growth_rate`"},
             "duration_ms": 92,
             "logs": "[07:00:00.595] WARN  Variable 'growth_rate' not found\n[07:00:00.610] ERROR TemplateRenderError"},
        ],
    },
    {
        "id": uuid4(), "name": "sync_catalog", "status": "success",
        "triggered_by": "webhook",
        "started_at": NOW - timedelta(hours=14),
        "finished_at": NOW - timedelta(hours=14) + timedelta(minutes=4),
        "created_at": NOW - timedelta(hours=14),
        "nodes": [
            {"id": "n1", "name": "Fetch from ERP", "status": "success",
             "inputs": {}, "outputs": {"products": 50}, "duration_ms": 1230},
            {"id": "n2", "name": "Push to Shopify", "status": "success",
             "inputs": {"batch_size": 25}, "outputs": {"synced": 50, "errors": 0}, "duration_ms": 2520},
        ],
    },
    {
        "id": uuid4(), "name": "renewal_check", "status": "success",
        "triggered_by": "scheduler",
        "started_at": NOW - timedelta(hours=26),
        "finished_at": NOW - timedelta(hours=26) + timedelta(minutes=2),
        "created_at": NOW - timedelta(hours=26),
        "nodes": [
            {"id": "n1", "name": "Query Expiring", "status": "success",
             "inputs": {"days": 7}, "outputs": {"count": 14}, "duration_ms": 380},
            {"id": "n2", "name": "Send Reminders", "status": "success",
             "inputs": {}, "outputs": {"sent": 14}, "duration_ms": 1920},
        ],
    },
    {
        "id": uuid4(), "name": "churn_scoring", "status": "success",
        "triggered_by": "scheduler",
        "started_at": NOW - timedelta(hours=30),
        "finished_at": NOW - timedelta(hours=30) + timedelta(minutes=5),
        "created_at": NOW - timedelta(hours=30),
        "nodes": [
            {"id": "n1", "name": "Load Activity", "status": "success",
             "inputs": {"lookback_days": 30}, "outputs": {"users": 822}, "duration_ms": 1100},
            {"id": "n2", "name": "Run ML Model", "status": "success",
             "inputs": {"threshold": 0.75}, "outputs": {"high_risk": 38}, "duration_ms": 2840},
            {"id": "n3", "name": "Write Scores", "status": "success",
             "inputs": {}, "outputs": {"rows": 822}, "duration_ms": 560},
        ],
    },
]

_CONFIGS = [
    {"key": "app.name", "value": "GTM Admin", "type": "string", "folder": "System",
     "description": "Application display name"},
    {"key": "max.retries", "value": "3", "type": "number", "folder": "System",
     "description": "Maximum retry attempts for failed workflows"},
    {"key": "maintenance.date", "value": "2026-05-01", "type": "date", "folder": "Infrastructure",
     "description": "Next scheduled maintenance window"},
    {"key": "digest.send.time", "value": "08:00", "type": "time", "folder": "Notifications",
     "description": "Daily digest delivery time"},
    {"key": "default.region", "value": "EU", "type": "select",
     "select_options": ["EU", "US", "APAC"], "folder": "Infrastructure",
     "description": "Default region for data processing"},
    {"key": "feature.flags",
     "value": json.dumps({"darkMode": True, "betaWorkflows": False, "analyticsV2": True}, indent=2),
     "type": "json", "folder": "System", "description": "Feature toggle flags"},
]

_TABLES = [
    {
        "name": "Customers",
        "description": "All registered customers",
        "columns": [
            {"id": "col-1", "name": "id", "type": "number"},
            {"id": "col-2", "name": "name", "type": "text"},
            {"id": "col-3", "name": "email", "type": "text"},
            {"id": "col-4", "name": "plan", "type": "select", "selectOptions": ["free", "pro", "enterprise"]},
            {"id": "col-5", "name": "mrr", "type": "number"},
            {"id": "col-6", "name": "active", "type": "boolean"},
        ],
        "rows": [
            {"id": "row-1", "col-1": 1, "col-2": "Alice Martin", "col-3": "alice@example.com", "col-4": "pro", "col-5": 149, "col-6": True},
            {"id": "row-2", "col-1": 2, "col-2": "Bob Strauss", "col-3": "bob@techcorp.de", "col-4": "enterprise", "col-5": 599, "col-6": True},
            {"id": "row-3", "col-1": 3, "col-2": "Clara Ng", "col-3": "clara@startup.io", "col-4": "free", "col-5": 0, "col-6": False},
        ],
    },
]


async def seed_demo_data() -> None:
    """Clear all demo tables and re-insert fresh seed data.

    Always runs a full replace so the DB state is predictable after every call.
    """
    from sqlalchemy import text

    from .auth import hash_password
    from .database import get_session
    from .models import ConfigRecord, DbTable, User, WorkflowRun

    async for session in get_session():
        # Clear in dependency order (workflow_runs self-references via parent_id)
        await session.exec(text("DELETE FROM workflow_runs"))
        await session.exec(text("DELETE FROM config_records"))
        await session.exec(text("DELETE FROM db_tables"))
        await session.exec(text("DELETE FROM users"))

        session.add(User(username="admin", hashed_password=hash_password("password")))
        print("gtm-admin: seeded admin user (admin / password)")

        historical = _make_historical_runs()
        for row in historical:
            session.add(WorkflowRun(**row))
        for row in _DETAILED_RUNS:
            session.add(WorkflowRun(**row))
        print(f"gtm-admin: seeded {len(historical) + len(_DETAILED_RUNS)} demo workflow runs")

        for cfg in _CONFIGS:
            session.add(ConfigRecord(**cfg))
        print(f"gtm-admin: seeded {len(_CONFIGS)} config records")

        for tbl in _TABLES:
            session.add(DbTable(**tbl))
        print(f"gtm-admin: seeded {len(_TABLES)} demo db tables")

        await session.commit()
        print("gtm-admin: seed complete.")
        break  # get_session is a generator; one iteration is all we need


