## llm generated tool func, created Mon May 11 20:34:01 2026
# version: 1.0.1

"""
项目知识库构建与查询工具 — toolkit_explr

在任意项目目录中构建以下索引（存入 .tea_agent_run/）：
  symbol_index.json  — 符号 → 文件:行号 (基于 ctags)
  call_graph.json    — 函数调用图 (基于 AST)
  ctags.json         — 原始 ctags 输出
  call_flow.dot/svg  — 调用流程图 (需 graphviz)
  kb.md              — 人类可读知识库

查询接口: symbol(符号定位), callers(谁调此函数), callees(此函数调谁), module(模块概览)
"""
import ast
import json
import os
import subprocess
import shutil
import time
from collections import defaultdict

# NOTE: 2026-05-15 gen by tea_agent, toolkit logging
import logging
logger = logging.getLogger("toolkit")

_RUN_DIR = ".tea_agent_run"

def _log(msg):
    print(f"[explr] {msg}")


def _build_ctags(directory, run_dir):
    """生成 ctags JSON 索引"""
    ctags_bin = shutil.which("ctags") or shutil.which("ctags-universal")
    if not ctags_bin:
        _log("⚠ ctags 未安装，跳过 ctags 索引")
        return None, {}

    src_dirs = []
    for entry in sorted(os.listdir(directory)):
        epath = os.path.join(directory, entry)
        if os.path.isdir(epath) and not entry.startswith('.') and entry not in ('build', '__pycache__', 'tmp', 'dist'):
            for root, dirs, files in os.walk(epath):
                if any(f.endswith('.py') for f in files):
                    src_dirs.append(epath)
                    break

    if not src_dirs:
        _log("⚠ 未找到 Python 源码目录")
        return None, {}

    _log(f"ctags 扫描: {', '.join(src_dirs)}")
    try:
        result = subprocess.run(
            [ctags_bin, '-R', '--fields=+nKzS', '--python-kinds=+cfmv', '--output-format=json'] + src_dirs,
            capture_output=True, text=True, timeout=60, cwd=directory
        )
    except Exception as e:
        _log(f"⚠ ctags 执行失败: {e}")
        return None, {}

    lines = [l for l in result.stdout.strip().split('\n') if l.strip()]
    _log(f"ctags: {len(lines)} 条目")

    ctags_path = os.path.join(run_dir, "ctags.json")
    with open(ctags_path, 'w', encoding='utf-8') as f:
        f.write(result.stdout)

    index = {}
    for line in lines:
        try:
            entry = json.loads(line)
            name = entry.get('name', '')
            path = entry.get('path', '')
            line_num = entry.get('line', '')
            kind = entry.get('kind', '')
            if name:
                if name not in index:
                    index[name] = []
                index[name].append({
                    'kind': kind,
                    'path': os.path.relpath(path, directory) if os.path.isabs(path) else path,
                    'line': line_num,
                })
        except json.JSONDecodeError:
            pass

    return ctags_path, index


def _build_call_graph(directory):
    """用 AST 分析函数调用图"""
    calls = {}
    defs = {}
    classes = {}

    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in ('__pycache__', 'build', 'dist', '.git', '.tea_agent_run', 'tmp')]
        for fname in files:
            if not fname.endswith('.py'):
                continue
            fpath = os.path.join(root, fname)
            relpath = os.path.relpath(fpath, directory)
            try:
                with open(fpath, 'r', encoding='utf-8') as fh:
                    source = fh.read()
                tree = ast.parse(source, filename=relpath)
            except (SyntaxError, UnicodeDecodeError) as e:
                _log(f"⚠ 语法错误: {relpath}: {e}")
                continue

            class CallVisitor(ast.NodeVisitor):
                def visit_FunctionDef(self, node):
                    defs[node.name] = {'file': relpath, 'line': node.lineno}
                    called = set()
                    for child in ast.walk(node):
                        if isinstance(child, ast.Call):
                            if isinstance(child.func, ast.Name):
                                called.add(child.func.id)
                            elif isinstance(child.func, ast.Attribute):
                                called.add(child.func.attr)
                    if called:
                        calls[node.name] = sorted(called)
                    self.generic_visit(node)

                def visit_AsyncFunctionDef(self, node):
                    self.visit_FunctionDef(node)

                def visit_ClassDef(self, node):
                    classes[node.name] = {'file': relpath, 'line': node.lineno}
                    self.generic_visit(node)

            CallVisitor().visit(tree)

    _log(f"AST: {len(defs)} 函数, {len(classes)} 类, {sum(len(v) for v in calls.values())} 调用边")
    return calls, defs, classes


def _build_dot_flow(calls, defs, run_dir):
    """生成关键调用流程 DOT 图"""
    dot_bin = shutil.which("dot")
    if not dot_bin:
        return

    callers = defaultdict(list)
    for caller, callees in calls.items():
        for callee in callees:
            callers[callee].append(caller)

    top = sorted(callers.items(), key=lambda x: -len(x[1]))[:30]
    top_names = {n for n, _ in top}

    dot = ['digraph G {', '  rankdir=TB;', '  node [shape=box, style=filled, fillcolor=lightyellow, fontsize=10];']
    for i, (name, clrs) in enumerate(top):
        count = len(clrs)
        color = 'lightsalmon' if count > 20 else 'lightyellow'
        short_name = name[:25] + ('..' if len(name) > 25 else '')
        dot.append(f'  n{i} [label="{short_name}\\n({count} callers)" fillcolor={color}];')

    name_to_id = {n: f"n{i}" for i, (n, _) in enumerate(top)}
    for caller, callees in calls.items():
        if caller not in name_to_id:
            continue
        for callee in callees:
            if callee in name_to_id:
                dot.append(f'  {name_to_id[caller]} -> {name_to_id[callee]};')

    dot.append('}')
    dot_path = os.path.join(run_dir, "call_flow.dot")
    with open(dot_path, 'w') as f:
        f.write('\n'.join(dot))

    svg_path = os.path.join(run_dir, "call_flow.svg")
    subprocess.run([dot_bin, '-Tsvg', dot_path, '-o', svg_path],
                   capture_output=True, timeout=15)
    _log(f"DOT: {dot_path}, {svg_path}")


def _build_kb_md(directory, index, calls, defs, classes, run_dir):
    """生成人类可读知识库 Markdown"""
    now = time.strftime("%Y-%m-%d %H:%M")
    project_name = os.path.basename(os.path.abspath(directory))

    modules = {}
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in ('__pycache__', 'build', 'dist', '.git', '.tea_agent_run', 'tmp')]
        for fname in files:
            if not fname.endswith('.py'):
                continue
            fpath = os.path.join(root, fname)
            relpath = os.path.relpath(fpath, directory)
            try:
                with open(fpath, 'r', encoding='utf-8') as fh:
                    lines = fh.readlines()
            except Exception:
                continue

            mod_classes = []
            mod_funcs = []
            lines_count = len(lines)
            for line in lines:
                s = line.strip()
                if s.startswith('class '):
                    name = s.split('(')[0].replace('class ', '').strip().rstrip(':')
                    mod_classes.append(name)
                elif s.startswith('def ') and not s.startswith((' ', '\t')):
                    name = s.split('(')[0].replace('def ', '').strip()
                    if not name.startswith('_'):
                        mod_funcs.append(name)

            modules[relpath] = {'classes': mod_classes, 'funcs': mod_funcs, 'lines': lines_count}

    kind_counts = defaultdict(int)
    for entries in index.values():
        for e in entries:
            kind_counts[e['kind']] += 1

    md = f"""# {project_name} 项目知识库

> 自动生成: {now}
> 工具: ctags + AST + graphviz
>
> 符号: {len(index)} 唯一 · 函数: {len(defs)} · 类: {len(classes)} · 调用边: {sum(len(v) for v in calls.values())}

## 符号种类分布

| 种类 | 数量 |
|------|------|
"""
    for kind, count in sorted(kind_counts.items(), key=lambda x: -x[1]):
        md += f"| {kind} | {count} |\n"

    md += f"""
## 模块索引 ({len(modules)} 文件)

| 模块 | 行数 | 类 | 公开函数 |
|------|------|-----|----------|
"""
    for path in sorted(modules.keys()):
        info = modules[path]
        cls_str = ', '.join(info['classes'][:3]) or '—'
        fn_str = ', '.join(info['funcs'][:3]) or '—'
        md += f"| {path} | {info['lines']} | {cls_str} | {fn_str} |\n"

    md += f"""
## Top 20 被调用函数

| 函数 | 文件:行号 | 调用者数 |
|------|-----------|----------|
"""
    callers = defaultdict(list)
    for caller, callees in calls.items():
        for callee in callees:
            callers[callee].append(caller)
    for name, clrs in sorted(callers.items(), key=lambda x: -len(x[1]))[:20]:
        loc = defs.get(name, {})
        fp = loc.get('file', '?')
        ln = loc.get('line', '?')
        md += f"| `{name}` | {fp}:{ln} | {len(clrs)} |\n"

    md += f"""
## 生成文件

| 文件 | 说明 |
|------|------|
| symbol_index.json | 符号→位置索引 |
| call_graph.json | AST 调用图 |
| ctags.json | 原始 ctags 输出 |
| call_flow.dot | Graphviz 调用流程图 |
| call_flow.svg | 调用流程图 SVG |
| kb.md | 本文档 |
"""
    kb_path = os.path.join(run_dir, "kb.md")
    with open(kb_path, 'w', encoding='utf-8') as f:
        f.write(md)
    _log(f"KB: {kb_path} ({len(md):,} chars)")


def _action_build(directory, force):
    directory = os.path.abspath(directory)
    if not os.path.isdir(directory):
        return f"❌ 目录不存在: {directory}"

    run_dir = os.path.join(directory, _RUN_DIR)
    os.makedirs(run_dir, exist_ok=True)

    kb_path = os.path.join(run_dir, "kb.md")
    sym_path = os.path.join(run_dir, "symbol_index.json")
    if not force and os.path.exists(kb_path) and os.path.exists(sym_path):
        age = time.time() - os.path.getmtime(kb_path)
        if age < 3600:
            return f"✅ 知识库已存在 (更新于 {age/60:.0f} 分钟前)，使用 force=true 强制重建"

    _log(f"🏗 构建项目知识库: {directory}")
    t0 = time.time()

    _, index = _build_ctags(directory, run_dir)
    calls, defs, classes = _build_call_graph(directory)

    cg_path = os.path.join(run_dir, "call_graph.json")
    with open(cg_path, 'w', encoding='utf-8') as f:
        json.dump({'functions': defs, 'classes': classes, 'calls': calls}, f, indent=2, ensure_ascii=False)

    idx_path = os.path.join(run_dir, "symbol_index.json")
    with open(idx_path, 'w', encoding='utf-8') as f:
        json.dump(index, f, indent=2, ensure_ascii=False)

    _build_dot_flow(calls, defs, run_dir)
    _build_kb_md(directory, index, calls, defs, classes, run_dir)

    elapsed = time.time() - t0
    summary = (
        f"✅ 知识库构建完成 ({elapsed:.1f}s)\n"
        f"  📁 {run_dir}/\n"
        f"  🏷  {len(index)} 符号 · {len(defs)} 函数 · {len(classes)} 类\n"
        f"  🔗 {sum(len(v) for v in calls.values())} 调用边\n"
        f"  📄 kb.md / symbol_index.json / call_graph.json"
    )
    return summary


def _action_query(directory, symbol, query_type):
    directory = os.path.abspath(directory)
    run_dir = os.path.join(directory, _RUN_DIR)

    idx_path = os.path.join(run_dir, "symbol_index.json")
    cg_path = os.path.join(run_dir, "call_graph.json")

    if query_type == 'module':
        kb_path = os.path.join(run_dir, "kb.md")
        if os.path.exists(kb_path):
            with open(kb_path, 'r', encoding='utf-8') as f:
                content = f.read()
            in_table = False
            lines = []
            for line in content.split('\n'):
                if '## 模块索引' in line:
                    in_table = True
                    continue
                if in_table and line.startswith('## '):
                    break
                if in_table:
                    lines.append(line)
            return '\n'.join(lines[:50])
        return "❌ 无知识库，请先 build"

    if not symbol:
        return "❌ query 需要 symbol 参数"

    if query_type == 'symbol':
        if not os.path.exists(idx_path):
            return "❌ 无索引，请先 build"
        with open(idx_path, 'r', encoding='utf-8') as f:
            index = json.load(f)

        if symbol in index:
            entries = index[symbol]
            parts = [f"## `{symbol}` ({len(entries)} 处定义)"]
            for e in entries[:10]:
                parts.append(f"- [{e['kind']}] `{e['path']}:{e['line']}`")
            return '\n'.join(parts)
        else:
            matches = [k for k in index if symbol.lower() in k.lower()]
            if matches:
                if len(matches) == 1:
                    return _action_query(directory, matches[0], 'symbol')
                return f"未找到 `{symbol}`，相关: {', '.join(f'`{m}`' for m in matches[:15])}"
            return f"❌ 未找到 `{symbol}`"

    if not os.path.exists(cg_path):
        return "❌ 无调用图，请先 build"
    with open(cg_path, 'r', encoding='utf-8') as f:
        cg = json.load(f)

    calls = cg.get('calls', {})
    defs = cg.get('functions', {})

    if query_type == 'callers':
        callers = defaultdict(list)
        for caller, callees in calls.items():
            for callee in callees:
                callers[callee].append(caller)
        if symbol in callers:
            parts = [f"## `{symbol}` 被 {len(callers[symbol])} 个函数调用:"]
            for c in sorted(callers[symbol]):
                loc = defs.get(c, {}).get('file', '?')
                ln = defs.get(c, {}).get('line', '?')
                parts.append(f"- `{c}` ({loc}:{ln})")
            return '\n'.join(parts[:30])
        return f"❌ `{symbol}` 无调用者记录"

    if query_type == 'callees':
        if symbol in calls:
            parts = [f"## `{symbol}` 调用 {len(calls[symbol])} 个函数:"]
            for c in sorted(calls[symbol]):
                loc = defs.get(c, {}).get('file', '?')
                ln = defs.get(c, {}).get('line', '?')
                parts.append(f"- `{c}` ({loc}:{ln})")
            return '\n'.join(parts[:30])
        return f"❌ `{symbol}` 无被调用记录"

    return "❌ 未知 query_type"


def _action_status(directory):
    directory = os.path.abspath(directory)
    run_dir = os.path.join(directory, _RUN_DIR)
    if not os.path.isdir(run_dir):
        return f"❌ {_RUN_DIR}/ 不存在，请先 build"

    files = sorted(os.listdir(run_dir))
    lines = [f"📁 {run_dir}/ ({len(files)} 文件)"]
    total = 0
    for fname in files:
        fpath = os.path.join(run_dir, fname)
        size = os.path.getsize(fpath)
        total += size
        mtime = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(fpath)))
        lines.append(f"  {fname:25s} {size:>10,} bytes  [{mtime}]")

    idx_path = os.path.join(run_dir, "symbol_index.json")
    cg_path = os.path.join(run_dir, "call_graph.json")
    if os.path.exists(idx_path):
        with open(idx_path, 'r', encoding='utf-8') as f:
            index = json.load(f)
        lines.append(f"\n🏷 {len(index)} 符号")
    if os.path.exists(cg_path):
        with open(cg_path, 'r', encoding='utf-8') as f:
            cg = json.load(f)
        lines.append(f"🔗 {len(cg.get('calls', {}))} 函数有调用关系, {sum(len(v) for v in cg.get('calls', {}).values())} 调用边")

    lines.append(f"\n💾 总计 {total:,} bytes")
    return '\n'.join(lines)


def toolkit_explr(action="build", directory=".", symbol=None, query_type="symbol", force="false"):
    logger.info(f"toolkit_explr called: action={action!r}, directory={repr(directory)[:80]}, symbol={symbol!r}, query_type={query_type!r}, force={force!r}")
    force_bool = force in ("true", "True", "1")
    if action == "build":
        return _action_build(directory, force_bool)
    elif action == "query":
        return _action_query(directory, symbol, query_type)
    elif action == "status":
        return _action_status(directory)
    else:
        return f"❌ 未知 action: {action}"


def meta_toolkit_explr() -> dict:
    return {"type": "function", "function": {"name": "toolkit_explr", "description": "项目知识库构建与查询。action=build 构建符号索引+AST调用图+流程图+kb.md；action=query 查询符号位置/调用者/被调用者；action=status 查看知识库状态。默认存储于当前目录 .tea_agent_run/。", "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["build", "query", "status"], "description": "build=构建项目知识库, query=查询符号/调用关系, status=查看知识库状态"}, "directory": {"type": "string", "description": "项目目录，默认当前目录", "default": "."}, "symbol": {"type": "string", "description": "[query] 要查询的符号名"}, "query_type": {"type": "string", "enum": ["symbol", "callers", "callees", "module"], "description": "[query] 查询类型：symbol=符号定位, callers=谁调此函数, callees=此函数调谁, module=模块概览", "default": "symbol"}, "force": {"type": "string", "enum": ["true", "false"], "description": "[build] true=强制重建，忽略已有索引", "default": "false"}}, "required": ["action"]}}}
