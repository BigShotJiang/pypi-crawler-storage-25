# Probiotic

Probiotic is a lightweight runtime for repository-native autonomous agents.

It provides:

- a DNA runtime that installs as a Python package
- repo-local cells under `symbiont/cells/`
- a nightly scheduler
- optional hive reporting and prompt improvement distribution

## Status

This project is currently alpha.

The v2 loop implemented in this repo includes:

- prompt hashing based on shareable prompt text
- passive approval metrics from local run history
- hive prompt snapshot storage
- analyzer-generated prompt patches
- nightly `apply_updates()` before cell execution

## Install

Until the package is published to PyPI, install it from GitHub or from a built wheel:

```bash
pip install git+https://github.com/penthoy/probiotic.git
```

or

```bash
pip install probiotic-0.1.0-py3-none-any.whl
```

## CLI

```bash
probiotic init
probiotic spawn janitor --template janitor
probiotic run-nightly
probiotic connect-hive http://<host>:8000 --api-key <key>
probiotic update-check
```

## Development

```bash
uv sync --extra dev --extra hive-server
uv run pytest
uv build
```