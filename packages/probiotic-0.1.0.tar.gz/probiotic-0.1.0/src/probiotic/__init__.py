"""Probiotic: autonomous symbiont runtime for code repositories."""

from __future__ import annotations

__version__ = "0.1.0"

