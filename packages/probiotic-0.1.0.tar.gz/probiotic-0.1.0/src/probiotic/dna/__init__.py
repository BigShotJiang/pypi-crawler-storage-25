"""DNA layer: reusable runtime machinery for Probiotic cells."""

from __future__ import annotations

