from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from datetime import datetime
from datetime import timedelta
from pathlib import Path


RUN_HISTORY_FILENAME = "run_history.jsonl"


@dataclass(frozen=True)
class RunHistoryEntry:
    timestamp: datetime
    prompt_hash: str
    status: str
    summary: str


def run_log_timestamp() -> str:
    return datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")


def append_run_log(run_log: Path, summary: str) -> None:
    run_log.parent.mkdir(parents=True, exist_ok=True)
    with run_log.open("a", encoding="utf-8") as fh:
        fh.write(f"{run_log_timestamp()} - {summary}\n")


def append_run_history(
    cell_dir: Path,
    *,
    timestamp: datetime,
    prompt_hash: str,
    status: str,
    summary: str,
) -> None:
    path = cell_dir / RUN_HISTORY_FILENAME
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp": timestamp.isoformat(timespec="seconds"),
        "prompt_hash": prompt_hash,
        "status": status,
        "summary": summary,
    }
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload, sort_keys=True) + "\n")


def load_run_history(cell_dir: Path) -> list[RunHistoryEntry]:
    path = cell_dir / RUN_HISTORY_FILENAME
    if not path.exists():
        return []

    entries: list[RunHistoryEntry] = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not line.strip():
            continue
        try:
            payload = json.loads(line)
            timestamp = datetime.fromisoformat(str(payload["timestamp"]))
            prompt_hash = str(payload["prompt_hash"])
            status = str(payload.get("status", "completed"))
            summary = str(payload.get("summary", ""))
        except (KeyError, TypeError, ValueError, json.JSONDecodeError):
            continue
        entries.append(RunHistoryEntry(timestamp=timestamp, prompt_hash=prompt_hash, status=status, summary=summary))
    return sorted(entries, key=lambda entry: entry.timestamp)


def _git_commit_timestamps(project_root: Path, *, since: datetime) -> list[datetime] | None:
    try:
        completed = subprocess.run(
            ["git", "-C", str(project_root), "log", f"--since={since.isoformat()}", "--format=%cI"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return None

    if completed.returncode != 0:
        return None

    timestamps: list[datetime] = []
    for line in completed.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            timestamps.append(datetime.fromisoformat(line))
        except ValueError:
            continue
    return sorted(timestamps)


def _approval_windows(
    entries: list[RunHistoryEntry],
    commit_timestamps: list[datetime],
    *,
    now: datetime,
) -> list[tuple[RunHistoryEntry, bool]]:
    approvals: list[tuple[RunHistoryEntry, bool]] = []
    for index, entry in enumerate(entries):
        window_end = entries[index + 1].timestamp if index + 1 < len(entries) else now
        approved = any(entry.timestamp <= commit_timestamp < window_end for commit_timestamp in commit_timestamps)
        approvals.append((entry, approved))
    return approvals


def _approval_rate(entries: list[tuple[RunHistoryEntry, bool]], prompt_hash: str | None) -> float | None:
    if not prompt_hash:
        return None
    matching = [approved for entry, approved in entries if entry.prompt_hash == prompt_hash]
    if len(matching) < 3:
        return None
    approved_count = sum(1 for approved in matching if approved)
    return approved_count / len(matching)


def _previous_prompt_hash(entries: list[RunHistoryEntry], current_prompt_hash: str) -> str | None:
    for entry in reversed(entries):
        if entry.prompt_hash != current_prompt_hash:
            return entry.prompt_hash
    return None


def compute_approval_metrics(
    cell_dir: Path,
    project_root: Path,
    *,
    current_prompt_hash: str,
    days: int = 30,
    now: datetime | None = None,
) -> tuple[float | None, float | None]:
    timestamp = now or datetime.now().astimezone()
    cutoff = timestamp - timedelta(days=days)
    history = [
        entry
        for entry in load_run_history(cell_dir)
        if entry.timestamp >= cutoff and entry.status not in {"dry-run", "skipped"}
    ]
    if len(history) < 3:
        return None, None

    commit_timestamps = _git_commit_timestamps(project_root, since=cutoff)
    if commit_timestamps is None:
        return None, None

    approvals = _approval_windows(history, commit_timestamps, now=timestamp)
    current_rate = _approval_rate(approvals, current_prompt_hash)
    previous_rate = _approval_rate(approvals, _previous_prompt_hash(history, current_prompt_hash))
    return current_rate, previous_rate


def tail_lines(path: Path, count: int = 10) -> list[str]:
    if not path.exists():
        return []
    return path.read_text(encoding="utf-8", errors="replace").splitlines()[-count:]


def ran_today(run_log: Path, *, now: datetime | None = None) -> bool:
    if not run_log.exists():
        return False
    today = (now or datetime.now().astimezone()).date().isoformat()
    return any(line.startswith(today) for line in tail_lines(run_log, 20))


def write_daily_journal(cell_dir: Path, title: str, body: str, *, now: datetime | None = None) -> Path:
    timestamp = now or datetime.now().astimezone()
    journal_dir = cell_dir / "journal"
    journal_dir.mkdir(parents=True, exist_ok=True)
    path = journal_dir / f"{timestamp.date().isoformat()}.md"
    path.write_text(f"# {title} - {timestamp.isoformat(timespec='seconds')}\n\n{body.strip()}\n", encoding="utf-8")
    return path
