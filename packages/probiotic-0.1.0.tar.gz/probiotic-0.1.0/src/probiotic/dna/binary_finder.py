from __future__ import annotations

import os
import shlex
import shutil
from pathlib import Path


def _env_override(name: str) -> Path | None:
    override = os.environ.get(name)
    if not override:
        return None
    candidate = Path(override).expanduser()
    if candidate.is_file():
        return candidate
    raise FileNotFoundError(f"{name} points to a missing file: {candidate}")


def find_codex_binary() -> Path:
    override = _env_override("CODEX_BIN")
    if override:
        return override

    path_hit = shutil.which("codex")
    if path_hit:
        return Path(path_hit)

    candidates: list[Path] = []
    for root in [
        Path.home() / ".vscode-server" / "extensions",
        Path.home() / ".vscode" / "extensions",
    ]:
        if root.is_dir():
            candidates.extend(root.glob("openai.chatgpt-*/bin/*/codex"))

    if candidates:
        return max(candidates, key=lambda path: path.stat().st_mtime_ns)
    raise FileNotFoundError("Could not find a Codex binary in PATH or VS Code extensions")


def find_claude_binary() -> Path:
    override = _env_override("CLAUDE_BIN")
    if override:
        return override

    path_hit = shutil.which("claude")
    if path_hit:
        return Path(path_hit)

    for candidate in [
        Path.home() / ".local" / "bin" / "claude",
        Path("/usr/local/bin/claude"),
        Path("/usr/bin/claude"),
    ]:
        if candidate.is_file():
            return candidate

    nvm_dir = Path.home() / ".nvm" / "versions" / "node"
    if nvm_dir.is_dir():
        hits = sorted(nvm_dir.glob("*/bin/claude"), reverse=True)
        if hits:
            return hits[0]

    raise FileNotFoundError("Could not find claude binary in PATH or common locations")


def find_binary(backend: str, *, binary_command: str | None = None) -> Path:
    if backend == "codex":
        return find_codex_binary()
    if backend == "claude":
        return find_claude_binary()
    if backend == "custom":
        if not binary_command:
            raise ValueError("custom backend requires cell.binary_command")
        command = shlex.split(binary_command)
        if not command:
            raise ValueError("custom backend has an empty binary_command")
        candidate = Path(command[0]).expanduser()
        if candidate.is_file():
            return candidate
        path_hit = shutil.which(command[0])
        if path_hit:
            return Path(path_hit)
        raise FileNotFoundError(f"Could not find custom binary: {command[0]}")
    raise ValueError(f"Unsupported binary backend: {backend}")


def build_env(binary: Path, backend: str) -> dict[str, str]:
    env = os.environ.copy()
    default_path = [
        str(binary.parent),
        str(Path.home() / ".local" / "bin"),
        "/usr/local/sbin",
        "/usr/local/bin",
        "/usr/sbin",
        "/usr/bin",
        "/sbin",
        "/bin",
    ]
    existing_path = env.get("PATH", "")
    if existing_path:
        default_path.append(existing_path)

    env["HOME"] = str(Path.home())
    if backend == "codex":
        env["CODEX_HOME"] = str(Path.home() / ".codex")
    env["PATH"] = ":".join(dict.fromkeys(part for part in default_path if part))
    env.setdefault("TERM", "dumb")
    return env


def build_command(backend: str, binary: Path, workdir: Path, *, prompt: str, binary_command: str | None = None) -> tuple[list[str], str | None]:
    if backend == "codex":
        return (
            [
                str(binary),
                "--dangerously-bypass-approvals-and-sandbox",
                "exec",
                "--skip-git-repo-check",
                "--cd",
                str(workdir),
                "-",
            ],
            prompt,
        )
    if backend == "claude":
        return (
            [
                str(binary),
                "-p",
                prompt,
                "--dangerously-skip-permissions",
                "--output-format",
                "json",
            ],
            None,
        )
    if backend == "custom":
        if not binary_command:
            raise ValueError("custom backend requires cell.binary_command")
        command = shlex.split(binary_command)
        if Path(command[0]).name == binary.name:
            command[0] = str(binary)
        return command, prompt
    raise ValueError(f"Unsupported binary backend: {backend}")

