from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from .config import DEFAULT_RUN_ORDER, nested_get, read_toml
from .journal import append_run_log, ran_today
from .runtime import RunResult, RuntimePaths, apply_updates, load_cell_config, resolve_cell_dir, run_cell
from .tools.usage import usage_snapshot


@dataclass(frozen=True)
class BudgetHeadroom:
    available: bool
    reason: str = "available"
    codex_5h_tokens: int | None = None
    claude_5h_tokens: int | None = None


class SchedulerSignal(Protocol):
    def available_budget(self) -> BudgetHeadroom:
        ...

    def should_run(self, cell_name: str, cost_estimate: float) -> bool:
        ...


class AlwaysRunSignal:
    def available_budget(self) -> BudgetHeadroom:
        return BudgetHeadroom(True)

    def should_run(self, cell_name: str, cost_estimate: float) -> bool:
        return True


class LocalUsageSignal:
    def __init__(self, *, max_codex_5h_tokens: int = 5_000_000, max_claude_5h_tokens: int = 2_000_000) -> None:
        self.max_codex_5h_tokens = max_codex_5h_tokens
        self.max_claude_5h_tokens = max_claude_5h_tokens

    def available_budget(self) -> BudgetHeadroom:
        snapshot = usage_snapshot()
        codex = snapshot["codex"]
        claude = snapshot["claude"]
        codex_5h = codex.get("5h_tokens") if "error" not in codex else None
        claude_5h = claude.get("5h_tokens") if "error" not in claude else None
        if codex_5h is not None and codex_5h > self.max_codex_5h_tokens:
            return BudgetHeadroom(False, "codex 5h usage is above soft ceiling", codex_5h, claude_5h)
        if claude_5h is not None and claude_5h > self.max_claude_5h_tokens:
            return BudgetHeadroom(False, "claude 5h usage is above soft ceiling", codex_5h, claude_5h)
        return BudgetHeadroom(True, "available", codex_5h, claude_5h)

    def should_run(self, cell_name: str, cost_estimate: float) -> bool:
        return self.available_budget().available


def signal_from_config(instance_config: dict, *, force: SchedulerSignal | None = None) -> SchedulerSignal:
    if force is not None:
        return force
    if not bool(nested_get(instance_config, ("symbiont", "budget", "enabled"), True)):
        return AlwaysRunSignal()
    source = str(nested_get(instance_config, ("symbiont", "budget", "signal_source"), "local"))
    if source == "local":
        return LocalUsageSignal()
    if source == "none":
        return AlwaysRunSignal()
    raise ValueError(f"Unsupported scheduler signal source: {source}")


def discover_cells(paths: RuntimePaths) -> list[Path]:
    root = paths.cells_root if paths.cells_root.exists() else paths.symbiont_root
    return sorted(
        path
        for path in root.iterdir()
        if path.is_dir() and (path / "cell.toml").exists() and not path.name.startswith(".")
    )


def ordered_cells(paths: RuntimePaths, instance_config: dict) -> list[str]:
    configured = list(nested_get(instance_config, ("symbiont", "schedule", "run_order"), DEFAULT_RUN_ORDER))
    seen: set[str] = set()
    cells_by_name: dict[str, tuple[int, str]] = {}
    for cell_dir in discover_cells(paths):
        config = load_cell_config(cell_dir)
        name = str(nested_get(config, ("cell", "name"), cell_dir.name))
        if not bool(nested_get(config, ("cell", "enabled"), True)):
            continue
        order = int(nested_get(config, ("cell", "schedule_order"), 100))
        cells_by_name[name] = (order, name)

    ordered: list[str] = []
    for name in configured:
        if name in cells_by_name and name not in seen:
            ordered.append(name)
            seen.add(name)
    for _, name in sorted(cells_by_name.values()):
        if name not in seen:
            ordered.append(name)
            seen.add(name)
    return ordered


def run_nightly(
    *,
    project_root: Path | str = ".",
    symbiont_dir: Path | str = "symbiont",
    dry_run: bool = False,
    signal: SchedulerSignal | None = None,
    skip_ran_today: bool = True,
    verbose: bool = False,
    skip_updates: bool = False,
) -> list[RunResult]:
    paths = RuntimePaths.create(Path(project_root), symbiont_dir)
    instance_config = read_toml(paths.symbiont_root / "config.toml")
    if not skip_updates:
        try:
            update_actions = apply_updates(paths, instance_config, dry_run=dry_run)
            if verbose:
                for action in update_actions:
                    print(f"update: {action}", flush=True)
            if not dry_run:
                if update_actions:
                    for action in update_actions:
                        append_run_log(paths.symbiont_root / "nightly.log", action)
                else:
                    append_run_log(paths.symbiont_root / "nightly.log", "hive updates checked: no applicable improvements")
        except RuntimeError as exc:
            if not dry_run:
                append_run_log(paths.symbiont_root / "nightly.log", f"hive update check failed: {exc}")

    scheduler_signal = signal_from_config(instance_config, force=signal)
    results: list[RunResult] = []
    for cell_name in ordered_cells(paths, instance_config):
        cell_dir = resolve_cell_dir(paths, cell_name)
        cell_config = load_cell_config(cell_dir)
        if skip_ran_today and ran_today(cell_dir / "run.log"):
            summary = f"skipped: {cell_name} already ran today"
            if not dry_run:
                append_run_log(cell_dir / "run.log", summary)
            results.append(RunResult(cell_name, 0, "skipped", summary, dry_run=dry_run))
            continue
        budget_soft = float(nested_get(cell_config, ("cell", "budget_soft"), 0.0) or 0.0)
        if not scheduler_signal.should_run(cell_name, budget_soft):
            headroom = scheduler_signal.available_budget()
            summary = f"skipped: budget unavailable ({headroom.reason})"
            if not dry_run:
                append_run_log(cell_dir / "run.log", summary)
            results.append(RunResult(cell_name, 0, "skipped", summary, dry_run=dry_run))
            continue
        results.append(
            run_cell(
                cell_name,
                project_root=paths.project_root,
                symbiont_dir=paths.symbiont_root,
                dry_run=dry_run,
                verbose=verbose,
            )
        )
    if not dry_run:
        append_run_log(paths.symbiont_root / "nightly.log", f"run-nightly finished: {len(results)} cells considered")
    return results
