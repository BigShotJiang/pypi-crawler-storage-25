from __future__ import annotations

import argparse
import datetime as dt
import json
import pathlib
import sqlite3
import sys
from typing import Any


HOME = pathlib.Path.home()
CODEX_STATE_DB = HOME / ".codex" / "state_5.sqlite"
CLAUDE_PROJECTS_DIR = HOME / ".claude" / "projects"


def codex_usage(now_ts: float, state_db: pathlib.Path = CODEX_STATE_DB) -> dict[str, Any]:
    if not state_db.exists():
        return {"error": f"Codex state DB not found: {state_db}"}

    five_h_ago = now_ts - 5 * 3600
    week_ago = now_ts - 7 * 24 * 3600
    try:
        con = sqlite3.connect(str(state_db))
        r5 = con.execute(
            "SELECT COALESCE(SUM(tokens_used),0), COUNT(*) FROM threads WHERE created_at > ?",
            (int(five_h_ago),),
        ).fetchone()
        r7 = con.execute(
            "SELECT COALESCE(SUM(tokens_used),0), COUNT(*) FROM threads WHERE created_at > ?",
            (int(week_ago),),
        ).fetchone()
        con.close()
    except Exception as exc:  # pragma: no cover - sqlite schema is external state
        return {"error": str(exc)}

    return {
        "5h_tokens": int(r5[0]),
        "5h_sessions": int(r5[1]),
        "7d_tokens": int(r7[0]),
        "7d_sessions": int(r7[1]),
    }


def claude_usage(now_ts: float, projects_dir: pathlib.Path = CLAUDE_PROJECTS_DIR) -> dict[str, Any]:
    if not projects_dir.exists():
        return {"error": f"Claude projects dir not found: {projects_dir}"}

    five_h_ago = now_ts - 5 * 3600
    week_ago = now_ts - 7 * 24 * 3600

    def empty() -> dict[str, int]:
        return {"input": 0, "output": 0, "cache_creation": 0, "cache_read": 0, "sessions": 0}

    stats_5h = empty()
    stats_7d = empty()

    for jsonl_file in projects_dir.rglob("*.jsonl"):
        try:
            if jsonl_file.stat().st_mtime < week_ago:
                continue
        except OSError:
            continue

        seen_5h = False
        seen_7d = False
        try:
            with jsonl_file.open(errors="replace") as fh:
                for raw in fh:
                    raw = raw.strip()
                    if not raw:
                        continue
                    try:
                        entry = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    if entry.get("type") != "assistant":
                        continue
                    usage = entry.get("message", {}).get("usage")
                    if not usage:
                        continue

                    ts_str = entry.get("timestamp", "")
                    try:
                        ts = (
                            dt.datetime.fromisoformat(ts_str.replace("Z", "+00:00")).timestamp()
                            if ts_str
                            else jsonl_file.stat().st_mtime
                        )
                    except ValueError:
                        ts = jsonl_file.stat().st_mtime

                    inp = int(usage.get("input_tokens", 0) or 0)
                    out = int(usage.get("output_tokens", 0) or 0)
                    cc = int(usage.get("cache_creation_input_tokens", 0) or 0)
                    cr = int(usage.get("cache_read_input_tokens", 0) or 0)

                    if ts > five_h_ago:
                        stats_5h["input"] += inp
                        stats_5h["output"] += out
                        stats_5h["cache_creation"] += cc
                        stats_5h["cache_read"] += cr
                        if not seen_5h:
                            stats_5h["sessions"] += 1
                            seen_5h = True
                    if ts > week_ago:
                        stats_7d["input"] += inp
                        stats_7d["output"] += out
                        stats_7d["cache_creation"] += cc
                        stats_7d["cache_read"] += cr
                        if not seen_7d:
                            stats_7d["sessions"] += 1
                            seen_7d = True
        except OSError:
            continue

    def total(stats: dict[str, int]) -> int:
        return stats["input"] + stats["output"] + stats["cache_creation"] + stats["cache_read"]

    return {
        "5h_tokens": total(stats_5h),
        "5h_input": stats_5h["input"],
        "5h_output": stats_5h["output"],
        "5h_cache_creation": stats_5h["cache_creation"],
        "5h_cache_read": stats_5h["cache_read"],
        "5h_sessions": stats_5h["sessions"],
        "7d_tokens": total(stats_7d),
        "7d_input": stats_7d["input"],
        "7d_output": stats_7d["output"],
        "7d_cache_creation": stats_7d["cache_creation"],
        "7d_cache_read": stats_7d["cache_read"],
        "7d_sessions": stats_7d["sessions"],
    }


def usage_snapshot(now: dt.datetime | None = None) -> dict[str, Any]:
    current = now or dt.datetime.now().astimezone()
    return {
        "timestamp": current.isoformat(),
        "codex": codex_usage(current.timestamp()),
        "claude": claude_usage(current.timestamp()),
    }


def _fmt_num(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.0f}K"
    return str(n)


def render_usage_text(snapshot: dict[str, Any]) -> str:
    timestamp = dt.datetime.fromisoformat(snapshot["timestamp"])
    codex = snapshot["codex"]
    claude = snapshot["claude"]
    lines = [
        f"## Live usage snapshot - {timestamp.strftime('%Y-%m-%d %H:%M %Z')}",
        "",
        "### Codex  (source: ~/.codex/state_5.sqlite -> threads.tokens_used)",
    ]
    if "error" in codex:
        lines.append(f"  ERROR: {codex['error']}")
    else:
        lines.extend(
            [
                f"  Last 5h:  {_fmt_num(codex['5h_tokens'])} tokens  ({codex['5h_sessions']} sessions)",
                f"  Last 7d:  {_fmt_num(codex['7d_tokens'])} tokens  ({codex['7d_sessions']} sessions)",
            ]
        )

    lines.extend(["", "### Claude Code  (source: ~/.claude/projects/**/*.jsonl -> message.usage)"])
    if "error" in claude:
        lines.append(f"  ERROR: {claude['error']}")
    else:
        lines.extend(
            [
                f"  Last 5h:  {_fmt_num(claude['5h_tokens'])} tokens  ({claude['5h_sessions']} sessions)",
                f"  Last 7d:  {_fmt_num(claude['7d_tokens'])} tokens  ({claude['7d_sessions']} sessions)",
            ]
        )
    lines.extend(
        [
            "",
            "NOTE: Plan limit denominators are not stored locally.",
            "Use these counts as a local velocity signal, not as exact percentage caps.",
        ]
    )
    return "\n".join(lines)


def cmd_usage(as_json: bool) -> int:
    snapshot = usage_snapshot()
    if as_json:
        print(json.dumps(snapshot, indent=2))
    else:
        print(render_usage_text(snapshot))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Probiotic helper tools")
    sub = parser.add_subparsers(dest="command", required=True)
    usage_parser = sub.add_parser("usage", help="Print local Codex and Claude token usage")
    usage_parser.add_argument("--json", action="store_true", help="Output machine-readable JSON")
    args = parser.parse_args(argv)
    if args.command == "usage":
        return cmd_usage(as_json=args.json)
    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())

