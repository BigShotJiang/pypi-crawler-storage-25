from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass(frozen=True)
class TemplateContext:
    project_root: Path
    symbiont_root: Path
    cell_dir: Path
    cell_name: str
    timestamp: datetime

    @classmethod
    def create(cls, project_root: Path, symbiont_root: Path, cell_dir: Path, cell_name: str) -> "TemplateContext":
        return cls(
            project_root=project_root.resolve(),
            symbiont_root=symbiont_root.resolve(),
            cell_dir=cell_dir.resolve(),
            cell_name=cell_name,
            timestamp=datetime.now().astimezone(),
        )


def template_variables(context: TemplateContext) -> dict[str, str]:
    timestamp = context.timestamp.isoformat(timespec="seconds")
    date = context.timestamp.date().isoformat()
    return {
        "PROJECT_ROOT": str(context.project_root),
        "SYMBIONT_ROOT": str(context.symbiont_root),
        "SYMBIONTS_ROOT": str(context.symbiont_root),
        "CRONIONS_ROOT": str(context.symbiont_root),
        "CRON_ROOT": str(context.symbiont_root),
        "CELL_DIR": str(context.cell_dir),
        "CELL_NAME": context.cell_name,
        "DATE": date,
        "TIMESTAMP": timestamp,
    }


def render_text(text: str, context: TemplateContext) -> str:
    rendered = text
    for key, value in template_variables(context).items():
        rendered = rendered.replace("{{" + key + "}}", value)
    return rendered


def normalize_prompt_text(text: str, context: TemplateContext) -> str:
    replacements = [
        (str(context.cell_dir), "{{CELL_DIR}}"),
        (str(context.symbiont_root), "{{SYMBIONT_ROOT}}"),
        (str(context.project_root), "{{PROJECT_ROOT}}"),
    ]
    normalized = text
    for value, placeholder in sorted(replacements, key=lambda item: len(item[0]), reverse=True):
        normalized = normalized.replace(value, placeholder)
    return normalized


def find_prompt_file(cell_dir: Path, cell_name: str) -> Path:
    preferred = cell_dir / "agent.md"
    if preferred.exists():
        return preferred

    legacy_names = [
        f"{cell_name}.md",
        "manager.md",
        "janitor.md",
        "researcher.md",
        "documentation.md",
        "commit.md",
        "tracker.md",
    ]
    for name in legacy_names:
        candidate = cell_dir / name
        if candidate.exists():
            return candidate

    md_files = sorted(path for path in cell_dir.glob("*.md") if path.name != "SOUL.md")
    if md_files:
        return md_files[0]
    raise FileNotFoundError(f"No agent prompt found in {cell_dir}")


def memory_section(cell_dir: Path) -> str:
    memory_path = cell_dir / "memory.md"
    if not memory_path.exists():
        return ""
    memory_text = memory_path.read_text(encoding="utf-8").strip()
    if not memory_text:
        return ""
    return "## Persistent memory\n" + memory_text


def manager_context_section(symbiont_root: Path, cell_dir: Path) -> str:
    sections: list[str] = []
    todos_path = symbiont_root / "todos.md"
    if todos_path.exists():
        todos_text = todos_path.read_text(encoding="utf-8").strip()
        sections.append("## todos.md\n" + (todos_text or "(empty)"))

    usage_log = cell_dir / "usage.log"
    if usage_log.exists():
        recent = usage_log.read_text(encoding="utf-8").strip().splitlines()[-50:]
        if recent:
            sections.append("## Recent usage log\n```\n" + "\n".join(recent) + "\n```")

    cells_root = symbiont_root / "cells"
    if not cells_root.exists():
        cells_root = symbiont_root
    blocks: list[str] = []
    for job_dir in sorted(path for path in cells_root.iterdir() if path.is_dir() and not path.name.startswith(".")):
        if job_dir.name in {"cells", "__pycache__"}:
            continue
        run_log = job_dir / "run.log"
        lines = [f"### {job_dir.name}"]
        if run_log.exists():
            tail = run_log.read_text(encoding="utf-8").strip().splitlines()[-10:]
            lines.append("```")
            lines.extend(tail or ["(empty)"])
            lines.append("```")
        else:
            lines.append("run.log: not found")
        backup_files = sorted(job_dir.glob("*.md.bak"))
        if backup_files:
            lines.append("pending backups: " + ", ".join(str(path) for path in backup_files))
        blocks.append("\n".join(lines))
    if blocks:
        sections.append("## Cell state\n" + "\n\n".join(blocks))

    if not sections:
        return ""
    return "## Context injected by Probiotic\nCurrent time: " + datetime.now().astimezone().isoformat(timespec="seconds") + "\n\n" + "\n\n".join(sections)


def load_cell_prompt(
    cell_dir: Path,
    context: TemplateContext,
    *,
    include_memory: bool = True,
    include_manager_context: bool = True,
) -> str:
    prompt_file = find_prompt_file(cell_dir, context.cell_name)
    parts = [prompt_file.read_text(encoding="utf-8").strip()]
    if include_memory:
        memory = memory_section(cell_dir)
        if memory:
            parts.append(memory)
    if include_manager_context and context.cell_name == "manager":
        injected = manager_context_section(context.symbiont_root, cell_dir)
        if injected:
            parts.append(injected)
    prompt = render_text("\n\n".join(parts), context)
    if not prompt.strip():
        raise ValueError(f"Assembled prompt is empty: {prompt_file}")
    return prompt


def load_shareable_prompt(cell_dir: Path, context: TemplateContext) -> str:
    prompt_file = find_prompt_file(cell_dir, context.cell_name)
    prompt = prompt_file.read_text(encoding="utf-8").strip()
    if not prompt:
        raise ValueError(f"Stored prompt is empty: {prompt_file}")
    return normalize_prompt_text(prompt, context)

