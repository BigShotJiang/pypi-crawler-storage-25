from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class HiveConfig:
    enabled: bool = False
    url: str = ""
    api_key: str = ""

    @classmethod
    def from_instance_config(cls, config: dict[str, Any]) -> "HiveConfig":
        hive = config.get("symbiont", {}).get("hive", {})
        return cls(
            enabled=bool(hive.get("enabled", False)),
            url=str(hive.get("url", "")).rstrip("/"),
            api_key=str(hive.get("api_key", "")),
        )


@dataclass(frozen=True)
class RunReport:
    instance_id: str
    repo_name: str
    agent: str
    run_date: str
    outcome: str
    prompt_hash: str
    approval_rate_30d: float | None = None
    prompt_text: str | None = None
    metrics: dict[str, Any] = field(default_factory=dict)


def _headers(config: HiveConfig) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if config.api_key:
        headers["Authorization"] = f"Bearer {config.api_key}"
    return headers


def _request_json(
    method: str,
    url: str,
    *,
    payload: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    timeout: float = 10.0,
) -> dict[str, Any]:
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=body, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        message = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Hive request failed: HTTP {exc.code}: {message}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Hive request failed: {exc}") from exc
    return json.loads(raw) if raw else {}


def report_run(config: HiveConfig, report: RunReport, *, timeout: float = 10.0) -> dict[str, Any]:
    if not config.enabled or not config.url:
        return {"skipped": "hive disabled"}
    return _request_json(
        "POST",
        f"{config.url}/report",
        payload=asdict(report),
        headers=_headers(config),
        timeout=timeout,
    )


def check_updates(
    config: HiveConfig,
    *,
    instance_id: str,
    since: str | None = None,
    timeout: float = 10.0,
) -> dict[str, Any]:
    if not config.enabled or not config.url:
        return {"improvements": [], "new_templates": []}
    query = {"instance_id": instance_id}
    if since:
        query["since"] = since
    url = f"{config.url}/updates?{urllib.parse.urlencode(query)}"
    return _request_json("GET", url, headers=_headers(config), timeout=timeout)


def default_run_report(
    *,
    instance_id: str,
    repo_name: str,
    agent: str,
    outcome: str,
    prompt_hash: str,
    approval_rate_30d: float | None = None,
    prompt_text: str | None = None,
    metrics: dict[str, Any] | None = None,
) -> RunReport:
    return RunReport(
        instance_id=instance_id,
        repo_name=repo_name,
        agent=agent,
        run_date=datetime.now().astimezone().date().isoformat(),
        outcome=outcome,
        prompt_hash=prompt_hash,
        approval_rate_30d=approval_rate_30d,
        prompt_text=prompt_text,
        metrics=metrics or {},
    )

