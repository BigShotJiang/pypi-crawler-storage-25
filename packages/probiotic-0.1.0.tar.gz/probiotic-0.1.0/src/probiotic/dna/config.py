from __future__ import annotations

import socket
import tomllib
import uuid
from pathlib import Path
from typing import Any


DEFAULT_RUN_ORDER = [
    "manager",
    "researcher",
    "documentation",
    "janitor",
    "commit",
    "progress_tracker",
]


def read_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("rb") as fh:
        return tomllib.load(fh)


def nested_get(data: dict[str, Any], keys: tuple[str, ...], default: Any = None) -> Any:
    cursor: Any = data
    for key in keys:
        if not isinstance(cursor, dict) or key not in cursor:
            return default
        cursor = cursor[key]
    return cursor


def detect_project_type(project_root: Path) -> str:
    markers = [
        ("pyproject.toml", "python"),
        ("package.json", "node"),
        ("go.mod", "go"),
        ("Cargo.toml", "rust"),
    ]
    for filename, project_type in markers:
        if (project_root / filename).exists():
            return project_type
    return "generic"


def default_instance_config_text(
    project_root: Path,
    *,
    default_binary: str = "codex",
    timezone: str = "America/Vancouver",
) -> str:
    repo_name = project_root.resolve().name or socket.gethostname()
    run_order = ", ".join(f'"{name}"' for name in DEFAULT_RUN_ORDER)
    return f"""[symbiont]
instance_id = "{uuid.uuid4()}"
repo_name = "{repo_name}"
project_type = "{detect_project_type(project_root)}"
timezone = "{timezone}"
default_binary = "{default_binary}"

[symbiont.budget]
enabled = true
signal_source = "local"
max_5h_pct = 50
human_reserve_pct = 50

[symbiont.hive]
enabled = false
url = ""
api_key = ""
share_prompts = true
share_approval_rates = true
share_journals = false

[symbiont.schedule]
run_order = [{run_order}]
"""


def default_cell_config_text(
    name: str,
    *,
    binary: str = "codex",
    schedule_order: int = 100,
    template: str = "_base",
    template_hash: str = "",
    budget_soft: float = 0.50,
) -> str:
    return f"""[cell]
name = "{name}"
binary = "{binary}"
enabled = true
schedule_order = {schedule_order}
budget_soft = {budget_soft:.2f}
template = "{template}"
spawned_from_template_hash = "{template_hash}"
allow_self_edit = true
backup_before_edit = true
hive_report = true
hive_accept_improvements = true
"""


def write_if_missing(path: Path, content: str) -> bool:
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True

