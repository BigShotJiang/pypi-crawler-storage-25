from __future__ import annotations

import hashlib
import json
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from .binary_finder import build_command, build_env, find_binary
from .config import nested_get, read_toml
from .hive_client import HiveConfig, check_updates, default_run_report, report_run
from .journal import append_run_history, append_run_log, compute_approval_metrics
from .lock import CellLock
from .prompts import TemplateContext, find_prompt_file, load_cell_prompt, load_shareable_prompt


@dataclass(frozen=True)
class RuntimePaths:
    project_root: Path
    symbiont_root: Path
    cells_root: Path

    @classmethod
    def create(cls, project_root: Path, symbiont_dir: Path | str = "symbiont") -> "RuntimePaths":
        root = project_root.resolve()
        symbiont_root = (root / symbiont_dir).resolve() if not Path(symbiont_dir).is_absolute() else Path(symbiont_dir).resolve()
        cells_root = symbiont_root / "cells"
        return cls(project_root=root, symbiont_root=symbiont_root, cells_root=cells_root)


@dataclass
class RunResult:
    cell_name: str
    returncode: int
    status: str
    summary: str
    dry_run: bool = False
    prompt_hash: str = ""
    metrics: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.returncode == 0


def resolve_cell_dir(paths: RuntimePaths, cell_name: str) -> Path:
    candidate = paths.cells_root / cell_name
    if candidate.exists():
        return candidate
    legacy = paths.symbiont_root / cell_name
    if legacy.exists():
        return legacy
    raise FileNotFoundError(f"Cell not found: {cell_name} under {paths.cells_root}")


def load_cell_config(cell_dir: Path) -> dict[str, Any]:
    return read_toml(cell_dir / "cell.toml")


def _cell_setting(cell_config: dict[str, Any], key: str, default: Any) -> Any:
    return nested_get(cell_config, ("cell", key), default)


def _parse_claude_summary(stdout: str) -> tuple[str, float | None]:
    summary = "completed"
    cost_usd: float | None = None
    for line in reversed(stdout.strip().splitlines()):
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        cost_usd = data.get("total_cost_usd")
        result_text = data.get("result", "")
        first_line = next((item for item in result_text.splitlines() if item.strip()), "")
        if first_line:
            summary = first_line[:120]
        break
    return summary, cost_usd


def _instance_identity(instance_config: dict[str, Any], paths: RuntimePaths) -> tuple[str, str]:
    instance_id = str(nested_get(instance_config, ("symbiont", "instance_id"), "local"))
    repo_name = str(nested_get(instance_config, ("symbiont", "repo_name"), paths.project_root.name))
    return instance_id, repo_name


def apply_updates(
    paths: RuntimePaths,
    instance_config: dict[str, Any],
    *,
    min_confidence: float | None = None,
    dry_run: bool = False,
) -> list[str]:
    hive = HiveConfig.from_instance_config(instance_config)
    if not hive.enabled or not hive.url:
        return []

    threshold = float(min_confidence if min_confidence is not None else nested_get(instance_config, ("symbiont", "hive", "min_confidence"), 0.85))
    instance_id, _ = _instance_identity(instance_config, paths)
    updates = check_updates(hive, instance_id=instance_id)
    actions: list[str] = []

    for improvement in updates.get("improvements", []):
        confidence = float(improvement.get("confidence", 0.0) or 0.0)
        if confidence < threshold:
            continue
        if str(improvement.get("change_type", "")) != "prompt_patch":
            continue

        agent_name = str(improvement.get("agent_template", "")).strip()
        patch_content = str(improvement.get("patch", ""))
        description = str(improvement.get("description", "hive prompt update"))
        target_hash = str(improvement.get("prompt_hash", ""))
        if not agent_name or not patch_content:
            continue

        try:
            cell_dir = resolve_cell_dir(paths, agent_name)
        except FileNotFoundError:
            actions.append(f"skip {agent_name}: cell not found")
            continue

        cell_config = load_cell_config(cell_dir)
        if not bool(_cell_setting(cell_config, "hive_accept_improvements", True)):
            actions.append(f"skip {agent_name}: hive improvements disabled")
            continue

        context = TemplateContext.create(paths.project_root, paths.symbiont_root, cell_dir, agent_name)
        current_prompt = load_shareable_prompt(cell_dir, context)
        current_hash = "sha256:" + hashlib.sha256(current_prompt.encode("utf-8")).hexdigest()
        if current_prompt == patch_content or (target_hash and current_hash == target_hash):
            continue

        prompt_file = find_prompt_file(cell_dir, agent_name)
        existing_text = prompt_file.read_text(encoding="utf-8")
        if dry_run:
            actions.append(f"dry-run: would patch {agent_name}/agent.md ({description})")
            continue

        backup_path = prompt_file.with_suffix(prompt_file.suffix + ".pre-hive")
        backup_path.write_text(existing_text, encoding="utf-8")
        prompt_file.write_text(patch_content, encoding="utf-8")
        append_run_log(cell_dir / "run.log", f"hive update applied: {description} (confidence {confidence:.2f})")
        actions.append(f"applied {agent_name}: {description} (confidence {confidence:.2f})")

    return actions


def run_cell(
    cell_name: str,
    *,
    project_root: Path | str = ".",
    symbiont_dir: Path | str = "symbiont",
    dry_run: bool = False,
    verbose: bool = False,
) -> RunResult:
    paths = RuntimePaths.create(Path(project_root), symbiont_dir)
    cell_dir = resolve_cell_dir(paths, cell_name)
    instance_config = read_toml(paths.symbiont_root / "config.toml")
    cell_config = load_cell_config(cell_dir)
    effective_name = str(_cell_setting(cell_config, "name", cell_name))
    backend = str(_cell_setting(cell_config, "binary", nested_get(instance_config, ("symbiont", "default_binary"), "codex")))
    binary_command = _cell_setting(cell_config, "binary_command", None)
    run_log = cell_dir / "run.log"
    lock_path = cell_dir / f".{effective_name}.lock"

    context = TemplateContext.create(paths.project_root, paths.symbiont_root, cell_dir, effective_name)
    prompt = load_cell_prompt(cell_dir, context)
    shareable_prompt = load_shareable_prompt(cell_dir, context)
    prompt_hash = "sha256:" + hashlib.sha256(shareable_prompt.encode("utf-8")).hexdigest()

    with CellLock(lock_path) as lock:
        if not lock.acquired:
            summary = f"skipped: another {effective_name} run is already active"
            append_run_log(run_log, summary)
            return RunResult(effective_name, 0, "skipped", summary, dry_run=dry_run, prompt_hash=prompt_hash)

        if dry_run:
            summary = f"dry-run: would run {effective_name} with {backend}"
            return RunResult(effective_name, 0, "dry-run", summary, dry_run=True, prompt_hash=prompt_hash)

        started = datetime.now().astimezone()
        try:
            binary = find_binary(backend, binary_command=binary_command)
            command, stdin = build_command(backend, binary, paths.project_root, prompt=prompt, binary_command=binary_command)
            env = build_env(binary, backend)
            if verbose:
                print(f"Using {backend} binary: {binary}", flush=True)
                print(f"Running {effective_name} in {paths.project_root}", flush=True)
            completed = subprocess.run(
                command,
                cwd=paths.project_root,
                env=env,
                input=stdin,
                stdout=subprocess.PIPE if backend == "claude" else None,
                stderr=None,
                text=True,
                check=False,
            )
            finished = datetime.now().astimezone()
            elapsed = (finished - started).total_seconds()
            status = "completed" if completed.returncode == 0 else "failed"
            summary = f"{status}: nightly {effective_name} run"
            metrics: dict[str, Any] = {"duration_seconds": elapsed, "backend": backend}
            if backend == "claude" and completed.stdout:
                claude_summary, cost_usd = _parse_claude_summary(completed.stdout)
                summary = f"{status}: {claude_summary}"
                if cost_usd is not None:
                    metrics["cost_usd"] = cost_usd
            append_run_log(run_log, summary)
            approval_rate_30d, previous_approval_rate_30d = compute_approval_metrics(
                cell_dir,
                paths.project_root,
                current_prompt_hash=prompt_hash,
                now=finished,
            )
            append_run_history(
                cell_dir,
                timestamp=finished,
                prompt_hash=prompt_hash,
                status=status,
                summary=summary,
            )
            if approval_rate_30d is not None:
                metrics["approval_rate_30d"] = approval_rate_30d
            if previous_approval_rate_30d is not None:
                metrics["previous_approval_rate_30d"] = previous_approval_rate_30d

            hive = HiveConfig.from_instance_config(instance_config)
            if hive.enabled and bool(_cell_setting(cell_config, "hive_report", True)):
                instance_id, repo_name = _instance_identity(instance_config, paths)
                share_prompts = bool(nested_get(instance_config, ("symbiont", "hive", "share_prompts"), True))
                try:
                    report_run(
                        hive,
                        default_run_report(
                            instance_id=instance_id,
                            repo_name=repo_name,
                            agent=effective_name,
                            outcome=status,
                            prompt_hash=prompt_hash,
                            approval_rate_30d=approval_rate_30d,
                            prompt_text=shareable_prompt if share_prompts else None,
                            metrics=metrics,
                        ),
                    )
                except RuntimeError as exc:
                    append_run_log(run_log, f"hive report failed: {exc}")
            return RunResult(effective_name, completed.returncode, status, summary, prompt_hash=prompt_hash, metrics=metrics)
        except Exception as exc:
            finished = datetime.now().astimezone()
            summary = f"failed: {exc}"
            append_run_log(run_log, summary)
            append_run_history(
                cell_dir,
                timestamp=finished,
                prompt_hash=prompt_hash,
                status="failed",
                summary=summary,
            )
            return RunResult(effective_name, 1, "failed", summary, prompt_hash=prompt_hash)
