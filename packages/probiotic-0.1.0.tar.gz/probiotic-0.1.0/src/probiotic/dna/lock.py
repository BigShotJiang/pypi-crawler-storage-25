from __future__ import annotations

import fcntl
import os
from pathlib import Path
from types import TracebackType


class CellLock:
    """Small fcntl-backed nonblocking lock for a single cell run."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._fh = None
        self.acquired = False

    def acquire(self) -> bool:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = self.path.open("w", encoding="utf-8")
        try:
            fcntl.flock(self._fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self._fh.close()
            self._fh = None
            self.acquired = False
            return False

        self._fh.write(f"{os.getpid()}\n")
        self._fh.flush()
        self.acquired = True
        return True

    def release(self) -> None:
        if self._fh is None:
            return
        try:
            fcntl.flock(self._fh.fileno(), fcntl.LOCK_UN)
        finally:
            self._fh.close()
            self._fh = None
            self.acquired = False

    def __enter__(self) -> "CellLock":
        self.acquire()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.release()

