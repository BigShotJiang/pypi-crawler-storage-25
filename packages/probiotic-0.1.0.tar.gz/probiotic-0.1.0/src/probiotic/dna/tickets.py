from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass(frozen=True)
class Ticket:
    path: Path
    sender: str
    receiver: str
    subject: str
    body: str


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug or "ticket"


def resolve_cell_dir(symbiont_root: Path, receiver: str) -> Path:
    cells_candidate = symbiont_root / "cells" / receiver
    if cells_candidate.exists() or (symbiont_root / "cells").exists():
        return cells_candidate
    return symbiont_root / receiver


def create_ticket(symbiont_root: Path, *, sender: str, receiver: str, subject: str, body: str) -> Path:
    ticket_dir = resolve_cell_dir(symbiont_root, receiver) / "tickets"
    ticket_dir.mkdir(parents=True, exist_ok=True)
    date = datetime.now().astimezone().date().isoformat()
    path = ticket_dir / f"{date}-from-{slugify(sender)}-{slugify(subject)}.md"
    text = f"""# Ticket: {subject}

From: {sender}
To: {receiver}
Created: {datetime.now().astimezone().isoformat(timespec="seconds")}

{body.strip()}
"""
    path.write_text(text, encoding="utf-8")
    return path


def list_tickets(cell_dir: Path) -> list[Path]:
    ticket_dir = cell_dir / "tickets"
    if not ticket_dir.exists():
        return []
    return sorted(ticket_dir.glob("*.md"))


def read_ticket(path: Path, receiver: str = "") -> Ticket:
    text = path.read_text(encoding="utf-8")
    sender = ""
    subject = path.stem
    for line in text.splitlines():
        if line.startswith("# Ticket:"):
            subject = line.removeprefix("# Ticket:").strip()
        elif line.startswith("From:"):
            sender = line.removeprefix("From:").strip()
        elif line.startswith("To:") and not receiver:
            receiver = line.removeprefix("To:").strip()
    return Ticket(path=path, sender=sender, receiver=receiver, subject=subject, body=text)


def consume_ticket(path: Path) -> Ticket:
    ticket = read_ticket(path)
    path.unlink()
    return ticket

