"""Packaged cell templates for Probiotic."""

