from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import sys
from importlib import resources
from pathlib import Path

from . import __version__
from .dna.config import (
    DEFAULT_RUN_ORDER,
    default_cell_config_text,
    default_instance_config_text,
    nested_get,
    read_toml,
    write_if_missing,
)
from .dna.hive_client import HiveConfig, check_updates
from .dna.prompts import TemplateContext, render_text
from .dna.runtime import RuntimePaths, run_cell
from .dna.scheduler import ordered_cells, run_nightly
from .dna.tools.usage import cmd_usage


ROOT_FILES = {
    "todos.md": "# Todos\n\n## Open\n\n## Finished\n",
    "proposals.md": "# Proposals queue\n\n## Pending\n\n*(none)*\n",
    "progressSummary.md": "# Progress summary\n\nNo runs yet.\n",
    "Changelog.md": "# Changelog\n\n## [Unreleased]\n",
    "TICKET_FORMAT.md": "# Ticket format\n\nOne request per Markdown file in a receiver's `tickets/` directory.\n",
    ".gitignore": "cells/*/__pycache__/\ncells/*/*.lock\ncells/*/*.log\nnightly.log\n",
}

LEGACY_CELL_MAP = {
    "manager": ("manager", "manager.md", "claude"),
    "researcher": ("researcher", "researcher.md", "codex"),
    "documentation": ("documentation", "documentation.md", "codex"),
    "Janitor": ("janitor", "janitor.md", "codex"),
    "commit": ("commit", "commit.md", "codex"),
    "progressTracker": ("progress_tracker", "tracker.md", "codex"),
}


def _templates_root():
    return resources.files("probiotic.templates")


def available_templates() -> list[str]:
    root = _templates_root()
    return sorted(
        child.name
        for child in root.iterdir()
        if child.is_dir() and child.name != "__pycache__" and not child.name.startswith(".")
    )


def _template_file(template_name: str, filename: str):
    return _templates_root().joinpath(template_name, filename)


def _read_template_text(template_name: str, filename: str) -> str | None:
    resource = _template_file(template_name, filename)
    if resource.is_file():
        return resource.read_text(encoding="utf-8")
    return None


def _extra_render(text: str, values: dict[str, str]) -> str:
    rendered = text
    for key, value in values.items():
        rendered = rendered.replace("{{" + key + "}}", value)
    return rendered


def _template_hash(template_name: str) -> str:
    digest = hashlib.sha256()
    for filename in ("agent.md.j2", "SOUL.md", "SOUL.md.j2", "cell.toml.default"):
        text = _read_template_text(template_name, filename)
        if text:
            digest.update(filename.encode("utf-8"))
            digest.update(text.encode("utf-8"))
    return "sha256:" + digest.hexdigest()


def _schedule_order(name: str) -> int:
    try:
        return DEFAULT_RUN_ORDER.index(name) + 1
    except ValueError:
        return 100


def spawn_cell(
    name: str,
    *,
    project_root: Path,
    symbiont_dir: Path | str = "symbiont",
    template: str | None = None,
    binary: str | None = None,
    dry_run: bool = False,
) -> Path:
    paths = RuntimePaths.create(project_root, symbiont_dir)
    template_name = template or name
    if template_name not in available_templates():
        template_name = "_base"
    cell_dir = paths.cells_root / name
    if cell_dir.exists() and not dry_run:
        raise FileExistsError(f"Cell already exists: {cell_dir}")

    instance_config = read_toml(paths.symbiont_root / "config.toml")
    default_binary = str(nested_get(instance_config, ("symbiont", "default_binary"), "codex"))
    cell_binary = binary or default_binary
    template_hash = _template_hash(template_name)
    context = TemplateContext.create(project_root, paths.symbiont_root, cell_dir, name)
    extra = {
        "CELL_NAME": name,
        "BINARY": cell_binary,
        "SCHEDULE_ORDER": str(_schedule_order(name)),
        "TEMPLATE_NAME": template_name,
        "TEMPLATE_HASH": template_hash,
    }

    if dry_run:
        return cell_dir

    cell_dir.mkdir(parents=True, exist_ok=False)
    (cell_dir / "journal").mkdir()
    (cell_dir / "tickets").mkdir()
    (cell_dir / "proposals").mkdir()
    (cell_dir / "run.log").touch()
    (cell_dir / "memory.md").write_text("# Memory\n\n", encoding="utf-8")

    prompt_text = _read_template_text(template_name, "agent.md.j2") or _read_template_text("_base", "agent.md.j2")
    if prompt_text is None:
        raise FileNotFoundError(f"Template {template_name} does not include agent.md.j2")
    rendered_prompt = _extra_render(prompt_text, extra)
    (cell_dir / "agent.md").write_text(rendered_prompt, encoding="utf-8")

    soul_text = _read_template_text(template_name, "SOUL.md") or _read_template_text(template_name, "SOUL.md.j2")
    if soul_text is None:
        soul_text = _read_template_text("_base", "SOUL.md.j2")
    if soul_text is None:
        raise FileNotFoundError("Base template is missing SOUL.md.j2")
    (cell_dir / "SOUL.md").write_text(_extra_render(soul_text, extra), encoding="utf-8")

    cell_toml = _read_template_text(template_name, "cell.toml.default")
    if cell_toml is None:
        cell_toml = default_cell_config_text(
            name,
            binary=cell_binary,
            schedule_order=_schedule_order(name),
            template=template_name,
            template_hash=template_hash,
        )
    else:
        cell_toml = _extra_render(cell_toml, extra)
    (cell_dir / "cell.toml").write_text(cell_toml, encoding="utf-8")
    return cell_dir


def init_symbiont(
    *,
    project_root: Path,
    symbiont_dir: Path | str = "symbiont",
    default_binary: str = "codex",
    dry_run: bool = False,
) -> Path:
    paths = RuntimePaths.create(project_root, symbiont_dir)
    if dry_run:
        return paths.symbiont_root

    paths.symbiont_root.mkdir(parents=True, exist_ok=True)
    paths.cells_root.mkdir(exist_ok=True)
    write_if_missing(paths.symbiont_root / "config.toml", default_instance_config_text(project_root, default_binary=default_binary))
    for filename, content in ROOT_FILES.items():
        write_if_missing(paths.symbiont_root / filename, content)
    manager_dir = paths.cells_root / "manager"
    if not manager_dir.exists():
        spawn_cell("manager", project_root=project_root, symbiont_dir=paths.symbiont_root, template="manager", binary=default_binary)
    return paths.symbiont_root


def migrate_legacy_symbiont(
    *,
    project_root: Path,
    symbiont_dir: Path | str = "symbiont",
    dry_run: bool = False,
) -> list[str]:
    paths = RuntimePaths.create(project_root, symbiont_dir)
    actions: list[str] = []
    if not paths.symbiont_root.exists():
        raise FileNotFoundError(f"Symbiont directory not found: {paths.symbiont_root}")
    if not dry_run:
        paths.cells_root.mkdir(parents=True, exist_ok=True)
        write_if_missing(paths.symbiont_root / "config.toml", default_instance_config_text(project_root))

    for legacy_name, (cell_name, prompt_name, binary) in LEGACY_CELL_MAP.items():
        source = paths.symbiont_root / legacy_name
        if not source.exists():
            continue
        destination = paths.cells_root / cell_name
        if destination.exists():
            actions.append(f"skip {legacy_name}: {destination} already exists")
            continue
        actions.append(f"copy {legacy_name}/ -> cells/{cell_name}/")
        if dry_run:
            continue
        shutil.copytree(source, destination)
        legacy_prompt = destination / prompt_name
        agent_prompt = destination / "agent.md"
        if legacy_prompt.exists() and not agent_prompt.exists():
            shutil.copy2(legacy_prompt, agent_prompt)
        (destination / "journal").mkdir(exist_ok=True)
        (destination / "tickets").mkdir(exist_ok=True)
        (destination / "run.log").touch(exist_ok=True)
        if not (destination / "memory.md").exists():
            (destination / "memory.md").write_text("# Memory\n\n", encoding="utf-8")
        write_if_missing(
            destination / "cell.toml",
            default_cell_config_text(
                cell_name,
                binary=binary,
                schedule_order=_schedule_order(cell_name),
                template=cell_name,
            ),
        )
    if not actions:
        actions.append("no legacy cells found")
    return actions


def _replace_toml_value(text: str, section: str, key: str, value: str) -> str:
    pattern = rf"(\[{re.escape(section)}\][\s\S]*?)(?=\n\[|\Z)"
    match = re.search(pattern, text)
    line = f'{key} = "{value}"'
    if key == "enabled":
        line = f"{key} = {value.lower()}"
    if not match:
        return text.rstrip() + f"\n\n[{section}]\n{line}\n"
    block = match.group(1)
    key_pattern = rf"^{re.escape(key)}\s*=.*$"
    if re.search(key_pattern, block, flags=re.MULTILINE):
        block = re.sub(key_pattern, line, block, flags=re.MULTILINE)
    else:
        block = block.rstrip() + "\n" + line
    return text[: match.start(1)] + block + text[match.end(1) :]


def update_hive_config(symbiont_root: Path, *, enabled: bool, url: str = "", api_key: str = "") -> None:
    config_path = symbiont_root / "config.toml"
    text = config_path.read_text(encoding="utf-8")
    text = _replace_toml_value(text, "symbiont.hive", "enabled", "true" if enabled else "false")
    if url:
        text = _replace_toml_value(text, "symbiont.hive", "url", url.rstrip("/"))
    if api_key:
        text = _replace_toml_value(text, "symbiont.hive", "api_key", api_key)
    config_path.write_text(text, encoding="utf-8")


def print_status(project_root: Path, symbiont_dir: Path | str) -> int:
    paths = RuntimePaths.create(project_root, symbiont_dir)
    instance_config = read_toml(paths.symbiont_root / "config.toml")
    print(f"Symbiont: {paths.symbiont_root}")
    print(f"Repo: {nested_get(instance_config, ('symbiont', 'repo_name'), project_root.name)}")
    for cell_name in ordered_cells(paths, instance_config):
        cell_dir = paths.cells_root / cell_name
        if not cell_dir.exists():
            cell_dir = paths.symbiont_root / cell_name
        run_log = cell_dir / "run.log"
        last = run_log.read_text(encoding="utf-8").splitlines()[-1] if run_log.exists() and run_log.stat().st_size else "never"
        print(f"- {cell_name}: {last}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="probiotic", description="Autonomous symbiont framework for code repositories")
    parser.add_argument("--symbiont-dir", default="symbiont", help="Override symbiont directory")
    parser.add_argument("--dry-run", action="store_true", help="Show what would happen without executing")
    parser.add_argument("--verbose", action="store_true", help="Verbose logging")
    parser.add_argument("--version", action="version", version=f"probiotic {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    init_parser = sub.add_parser("init", help="Initialize a symbiont in the current repository")
    init_parser.add_argument("--default-binary", default="codex", choices=["codex", "claude", "custom"])
    init_parser.add_argument("--dry-run", action="store_true", default=argparse.SUPPRESS)

    spawn_parser = sub.add_parser("spawn", help="Create a new cell from a template")
    spawn_parser.add_argument("name")
    spawn_parser.add_argument("--template")
    spawn_parser.add_argument("--binary", choices=["codex", "claude", "custom"])
    spawn_parser.add_argument("--dry-run", action="store_true", default=argparse.SUPPRESS)

    run_parser = sub.add_parser("run", help="Run a specific cell")
    run_parser.add_argument("cell")
    run_parser.add_argument("--dry-run", action="store_true", default=argparse.SUPPRESS)

    nightly_parser = sub.add_parser("run-nightly", help="Run all scheduled cells in order")
    nightly_parser.add_argument("--dry-run", action="store_true", default=argparse.SUPPRESS)
    nightly_parser.add_argument("--skip-updates", action="store_true", help="Skip pulling hive improvements before running cells")
    sub.add_parser("status", help="Show cell status")
    sub.add_parser("list-templates", help="Show available templates")
    migrate_parser = sub.add_parser("migrate-legacy", help="Copy old top-level symbiont agents into cells/")
    migrate_parser.add_argument("--dry-run", action="store_true", default=argparse.SUPPRESS)

    connect = sub.add_parser("connect-hive", help="Connect this symbiont to a hive server")
    connect.add_argument("url")
    connect.add_argument("--api-key", default="")

    sub.add_parser("disconnect-hive", help="Disconnect from hive")
    sub.add_parser("update-check", help="Check hive for available updates")

    usage = sub.add_parser("usage", help="Print token usage summary")
    usage.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    project_root = Path.cwd()
    symbiont_dir = args.symbiont_dir

    try:
        if args.command == "init":
            path = init_symbiont(project_root=project_root, symbiont_dir=symbiont_dir, default_binary=args.default_binary, dry_run=args.dry_run)
            print(f"Symbiont initialized at {path}")
            print("Next: edit symbiont/todos.md, then run `probiotic run manager`.")
            return 0
        if args.command == "spawn":
            path = spawn_cell(args.name, project_root=project_root, symbiont_dir=symbiont_dir, template=args.template, binary=args.binary, dry_run=args.dry_run)
            print(f"Cell `{args.name}` created at {path}")
            return 0
        if args.command == "run":
            result = run_cell(args.cell, project_root=project_root, symbiont_dir=symbiont_dir, dry_run=args.dry_run, verbose=args.verbose)
            print(result.summary)
            return result.returncode
        if args.command == "run-nightly":
            results = run_nightly(
                project_root=project_root,
                symbiont_dir=symbiont_dir,
                dry_run=args.dry_run,
                verbose=args.verbose,
                skip_updates=args.skip_updates,
            )
            for result in results:
                print(f"{result.cell_name}: {result.summary}")
            return 0 if all(result.ok for result in results) else 1
        if args.command == "status":
            return print_status(project_root, symbiont_dir)
        if args.command == "list-templates":
            for name in available_templates():
                if name != "_base":
                    print(name)
            return 0
        if args.command == "migrate-legacy":
            actions = migrate_legacy_symbiont(project_root=project_root, symbiont_dir=symbiont_dir, dry_run=args.dry_run)
            for action in actions:
                print(action)
            return 0
        if args.command == "connect-hive":
            paths = RuntimePaths.create(project_root, symbiont_dir)
            update_hive_config(paths.symbiont_root, enabled=True, url=args.url, api_key=args.api_key)
            print(f"Connected hive: {args.url.rstrip('/')}")
            return 0
        if args.command == "disconnect-hive":
            paths = RuntimePaths.create(project_root, symbiont_dir)
            update_hive_config(paths.symbiont_root, enabled=False)
            print("Hive disconnected")
            return 0
        if args.command == "update-check":
            paths = RuntimePaths.create(project_root, symbiont_dir)
            config = read_toml(paths.symbiont_root / "config.toml")
            hive = HiveConfig.from_instance_config(config)
            instance_id = str(nested_get(config, ("symbiont", "instance_id"), "local"))
            updates = check_updates(hive, instance_id=instance_id)
            print(f"{len(updates.get('improvements', []))} improvements, {len(updates.get('new_templates', []))} new templates")
            return 0
        if args.command == "usage":
            return cmd_usage(as_json=args.json)
    except Exception as exc:
        print(f"probiotic: {exc}", file=sys.stderr)
        return 1

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
