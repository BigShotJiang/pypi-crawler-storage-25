from __future__ import annotations

from collections.abc import Callable
from collections import defaultdict

from .models import HiveStore, RunRecord, VerifiedImprovement


def _confidence(delta: float, repo_count: int) -> float:
    return min(0.99, max(0.0, 0.65 + delta + repo_count * 0.05))


def find_verified_improvements(
    records: list[RunRecord],
    *,
    prompt_lookup: Callable[[str, str], str | None] | None = None,
    min_repos: int = 3,
    min_delta: float = 0.10,
    min_confidence: float = 0.80,
) -> list[VerifiedImprovement]:
    by_hash: dict[str, list[RunRecord]] = defaultdict(list)
    for record in records:
        if record.approval_rate_30d is not None:
            by_hash[record.prompt_hash].append(record)

    improvements: list[VerifiedImprovement] = []
    for prompt_hash, grouped in by_hash.items():
        repos = {record.instance_id for record in grouped}
        if len(repos) < min_repos:
            continue
        previous_rates = [
            float(record.metrics["previous_approval_rate_30d"])
            for record in grouped
            if "previous_approval_rate_30d" in record.metrics
        ]
        if not previous_rates:
            continue
        previous = sum(previous_rates) / len(previous_rates)
        current = sum(float(record.approval_rate_30d or 0.0) for record in grouped) / len(grouped)
        delta = current - previous
        confidence = _confidence(delta, len(repos))
        if delta >= min_delta and confidence >= min_confidence:
            sample = grouped[0]
            patch = prompt_lookup(prompt_hash, sample.agent) if prompt_lookup is not None else ""
            if prompt_lookup is not None and not patch:
                continue
            improvements.append(
                VerifiedImprovement(
                    agent_template=sample.agent,
                    prompt_hash=prompt_hash,
                    change_type="prompt_patch",
                    description=f"{sample.agent} prompt correlated with {delta:.0%} approval-rate lift across {len(repos)} repos",
                    patch=patch,
                    confidence=confidence,
                    verified_repos=len(repos),
                )
            )
    return improvements


def analyze_and_store(
    store: HiveStore,
    *,
    min_repos: int = 3,
    min_delta: float = 0.10,
    min_confidence: float = 0.80,
) -> list[VerifiedImprovement]:
    improvements = find_verified_improvements(
        store.reports(),
        prompt_lookup=lambda prompt_hash, agent: store.get_prompt_by_hash(prompt_hash, agent=agent),
        min_repos=min_repos,
        min_delta=min_delta,
        min_confidence=min_confidence,
    )
    for improvement in improvements:
        store.save_improvement(improvement)
    return improvements

