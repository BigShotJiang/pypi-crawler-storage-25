from __future__ import annotations

from dataclasses import asdict

from .models import HiveStore


def updates_for_instance(store: HiveStore, *, instance_id: str) -> dict:
    return {
        "improvements": [asdict(improvement) for improvement in store.improvements()],
        "new_templates": [],
        "instance_id": instance_id,
    }

