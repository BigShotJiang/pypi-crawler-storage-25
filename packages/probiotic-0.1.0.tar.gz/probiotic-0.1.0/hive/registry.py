from __future__ import annotations

from .models import HiveStore, RunRecord


class Registry:
    def __init__(self, store: HiveStore) -> None:
        self.store = store

    def record_report(self, report: RunRecord, *, prompt_text: str | None = None) -> dict[str, str]:
        self.store.save_report(report)
        if prompt_text and prompt_text.strip():
            self.store.save_prompt_snapshot(prompt_hash=report.prompt_hash, agent=report.agent, content=prompt_text)
        return {"status": "ok"}

