from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class HiveServerConfig:
    database_path: Path = Path("hive.sqlite3")
    api_key: str = ""
    min_repos: int = 2
    min_delta: float = 0.10
    min_confidence: float = 0.80

    @classmethod
    def from_env(cls) -> "HiveServerConfig":
        return cls(
            database_path=Path(os.environ.get("PROBIOTIC_HIVE_DB", "hive.sqlite3")),
            api_key=os.environ.get("PROBIOTIC_HIVE_API_KEY", ""),
            min_repos=int(os.environ.get("PROBIOTIC_HIVE_MIN_REPOS", "2")),
            min_delta=float(os.environ.get("PROBIOTIC_HIVE_MIN_DELTA", "0.10")),
            min_confidence=float(os.environ.get("PROBIOTIC_HIVE_MIN_CONFIDENCE", "0.80")),
        )

