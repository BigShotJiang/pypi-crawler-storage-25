from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .analyzer import analyze_and_store
from .config import HiveServerConfig
from .distributor import updates_for_instance
from .models import HiveStore, RunRecord
from .registry import Registry

try:  # pragma: no cover - exercised only when optional dependency is installed
    from fastapi import Depends, FastAPI, Header, HTTPException
except ImportError:  # pragma: no cover
    Depends = FastAPI = Header = HTTPException = None  # type: ignore[assignment]


config = HiveServerConfig.from_env()
store = HiveStore(config.database_path)
registry = Registry(store)


def _require_fastapi() -> None:
    if FastAPI is None:
        raise RuntimeError("Install probiotic[hive-server] to run the hive server")


def _auth(authorization: str | None = None) -> None:
    if not config.api_key:
        return
    expected = f"Bearer {config.api_key}"
    if authorization != expected:
        raise HTTPException(status_code=401, detail="invalid hive API key")


def create_app():
    _require_fastapi()
    app = FastAPI(title="Probiotic Hive")

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.post("/report")
    def report(payload: dict[str, Any], authorization: str | None = Header(default=None)) -> dict[str, str]:
        _auth(authorization)
        record = RunRecord(
            instance_id=str(payload["instance_id"]),
            repo_name=str(payload["repo_name"]),
            agent=str(payload["agent"]),
            run_date=str(payload["run_date"]),
            outcome=str(payload["outcome"]),
            prompt_hash=str(payload["prompt_hash"]),
            approval_rate_30d=payload.get("approval_rate_30d"),
            metrics=dict(payload.get("metrics", {})),
        )
        result = registry.record_report(record, prompt_text=payload.get("prompt_text"))
        analyze_and_store(
            store,
            min_repos=config.min_repos,
            min_delta=config.min_delta,
            min_confidence=config.min_confidence,
        )
        return result

    @app.get("/updates")
    def updates(instance_id: str, since: str | None = None, authorization: str | None = Header(default=None)) -> dict:
        _auth(authorization)
        return updates_for_instance(store, instance_id=instance_id)

    @app.post("/analyze")
    def analyze(authorization: str | None = Header(default=None)) -> dict:
        _auth(authorization)
        improvements = analyze_and_store(
            store,
            min_repos=config.min_repos,
            min_delta=config.min_delta,
            min_confidence=config.min_confidence,
        )
        return {"improvements": [asdict(item) for item in improvements]}

    return app


app = create_app() if FastAPI is not None else None

