from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Instance:
    instance_id: str
    repo_name: str
    last_seen: str


@dataclass(frozen=True)
class RunRecord:
    instance_id: str
    repo_name: str
    agent: str
    run_date: str
    outcome: str
    prompt_hash: str
    approval_rate_30d: float | None = None
    metrics: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class VerifiedImprovement:
    agent_template: str
    prompt_hash: str
    change_type: str
    description: str
    patch: str
    confidence: float
    verified_repos: int


@dataclass(frozen=True)
class PromptSnapshot:
    prompt_hash: str
    agent: str
    content: str
    first_seen: str


class HiveStore:
    def __init__(self, path: Path | str = "hive.sqlite3") -> None:
        self.path = Path(path)
        self.init_db()

    def connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(str(self.path))
        con.row_factory = sqlite3.Row
        return con

    def init_db(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS instances (
                    instance_id TEXT PRIMARY KEY,
                    repo_name TEXT NOT NULL,
                    last_seen TEXT NOT NULL
                )
                """
            )
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS run_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    instance_id TEXT NOT NULL,
                    repo_name TEXT NOT NULL,
                    agent TEXT NOT NULL,
                    run_date TEXT NOT NULL,
                    outcome TEXT NOT NULL,
                    prompt_hash TEXT NOT NULL,
                    approval_rate_30d REAL,
                    metrics_json TEXT NOT NULL
                )
                """
            )
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS verified_improvements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_template TEXT NOT NULL,
                    prompt_hash TEXT NOT NULL UNIQUE,
                    change_type TEXT NOT NULL,
                    description TEXT NOT NULL,
                    patch TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    verified_repos INTEGER NOT NULL
                )
                """
            )
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS prompt_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    prompt_hash TEXT NOT NULL,
                    agent TEXT NOT NULL,
                    content TEXT NOT NULL,
                    first_seen TEXT NOT NULL,
                    UNIQUE(prompt_hash, agent)
                )
                """
            )

    def save_report(self, report: RunRecord) -> None:
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        with self.connect() as con:
            con.execute(
                """
                INSERT INTO instances(instance_id, repo_name, last_seen)
                VALUES (?, ?, ?)
                ON CONFLICT(instance_id) DO UPDATE SET repo_name=excluded.repo_name, last_seen=excluded.last_seen
                """,
                (report.instance_id, report.repo_name, now),
            )
            con.execute(
                """
                INSERT INTO run_records(
                    instance_id, repo_name, agent, run_date, outcome,
                    prompt_hash, approval_rate_30d, metrics_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    report.instance_id,
                    report.repo_name,
                    report.agent,
                    report.run_date,
                    report.outcome,
                    report.prompt_hash,
                    report.approval_rate_30d,
                    json.dumps(report.metrics),
                ),
            )

    def reports(self) -> list[RunRecord]:
        with self.connect() as con:
            rows = con.execute("SELECT * FROM run_records ORDER BY id").fetchall()
        return [
            RunRecord(
                instance_id=row["instance_id"],
                repo_name=row["repo_name"],
                agent=row["agent"],
                run_date=row["run_date"],
                outcome=row["outcome"],
                prompt_hash=row["prompt_hash"],
                approval_rate_30d=row["approval_rate_30d"],
                metrics=json.loads(row["metrics_json"]),
            )
            for row in rows
        ]

    def save_prompt_snapshot(self, *, prompt_hash: str, agent: str, content: str) -> None:
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        with self.connect() as con:
            con.execute(
                """
                INSERT INTO prompt_snapshots(prompt_hash, agent, content, first_seen)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(prompt_hash, agent) DO NOTHING
                """,
                (prompt_hash, agent, content, now),
            )

    def get_prompt_by_hash(self, prompt_hash: str, *, agent: str | None = None) -> str | None:
        query = "SELECT content FROM prompt_snapshots WHERE prompt_hash = ?"
        params: list[Any] = [prompt_hash]
        if agent is not None:
            query += " AND agent = ?"
            params.append(agent)
        query += " ORDER BY first_seen LIMIT 1"
        with self.connect() as con:
            row = con.execute(query, params).fetchone()
        if row is None:
            return None
        return str(row["content"])

    def save_improvement(self, improvement: VerifiedImprovement) -> None:
        with self.connect() as con:
            con.execute(
                """
                INSERT INTO verified_improvements(
                    agent_template, prompt_hash, change_type, description,
                    patch, confidence, verified_repos
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(prompt_hash) DO UPDATE SET
                    agent_template=excluded.agent_template,
                    change_type=excluded.change_type,
                    description=excluded.description,
                    patch=excluded.patch,
                    confidence=excluded.confidence,
                    verified_repos=excluded.verified_repos
                """,
                (
                    improvement.agent_template,
                    improvement.prompt_hash,
                    improvement.change_type,
                    improvement.description,
                    improvement.patch,
                    improvement.confidence,
                    improvement.verified_repos,
                ),
            )

    def improvements(self) -> list[VerifiedImprovement]:
        with self.connect() as con:
            rows = con.execute("SELECT * FROM verified_improvements ORDER BY id").fetchall()
        return [
            VerifiedImprovement(
                agent_template=row["agent_template"],
                prompt_hash=row["prompt_hash"],
                change_type=row["change_type"],
                description=row["description"],
                patch=row["patch"],
                confidence=row["confidence"],
                verified_repos=row["verified_repos"],
            )
            for row in rows
        ]

