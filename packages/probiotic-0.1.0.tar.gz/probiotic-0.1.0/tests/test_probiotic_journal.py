from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import subprocess

from probiotic.dna.journal import append_run_history, compute_approval_metrics


def _commit(repo: Path, filename: str, content: str, when: datetime) -> None:
    path = repo / filename
    path.write_text(content, encoding="utf-8")
    env = {
        **subprocess.os.environ,
        "GIT_AUTHOR_DATE": when.isoformat(),
        "GIT_COMMITTER_DATE": when.isoformat(),
    }
    subprocess.run(["git", "-C", str(repo), "add", filename], check=True, env=env)
    subprocess.run(["git", "-C", str(repo), "commit", "-m", f"commit {filename}"], check=True, env=env, capture_output=True)


def test_compute_approval_metrics_returns_current_and_previous_rates(tmp_path: Path) -> None:
    subprocess.run(["git", "-C", str(tmp_path), "init"], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "tester@example.com"], check=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Tester"], check=True)

    cell_dir = tmp_path / "symbiont" / "cells" / "janitor"
    cell_dir.mkdir(parents=True)
    base = datetime(2026, 4, 1, 10, 0, tzinfo=timezone.utc)
    events = [
        (base + timedelta(days=0), "sha256:old", True),
        (base + timedelta(days=1), "sha256:old", True),
        (base + timedelta(days=2), "sha256:old", False),
        (base + timedelta(days=3), "sha256:new", True),
        (base + timedelta(days=4), "sha256:new", True),
        (base + timedelta(days=5), "sha256:new", True),
    ]

    for index, (timestamp, prompt_hash, approved) in enumerate(events):
        append_run_history(
            cell_dir,
            timestamp=timestamp,
            prompt_hash=prompt_hash,
            status="completed",
            summary=f"run {index}",
        )
        if approved:
            _commit(tmp_path, f"file_{index}.txt", f"{index}\n", timestamp + timedelta(minutes=5))

    current_rate, previous_rate = compute_approval_metrics(
        cell_dir,
        tmp_path,
        current_prompt_hash="sha256:new",
        now=base + timedelta(days=6),
    )

    assert current_rate == 1.0
    assert previous_rate == 2 / 3