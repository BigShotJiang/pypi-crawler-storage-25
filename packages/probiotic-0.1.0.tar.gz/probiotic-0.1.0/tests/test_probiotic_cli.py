from __future__ import annotations

from pathlib import Path

from probiotic.cli import main


def test_cli_init_and_spawn_create_symbiont_cells(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)

    assert main(["init", "--default-binary", "custom"]) == 0
    assert (tmp_path / "symbiont" / "config.toml").exists()
    assert (tmp_path / "symbiont" / "cells" / "manager" / "agent.md").exists()

    assert main(["spawn", "janitor", "--binary", "custom"]) == 0
    janitor = tmp_path / "symbiont" / "cells" / "janitor"
    assert (janitor / "SOUL.md").exists()
    assert 'name = "janitor"' in (janitor / "cell.toml").read_text(encoding="utf-8")


def test_cli_list_templates_prints_builtins(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.chdir(tmp_path)

    assert main(["list-templates"]) == 0
    out = capsys.readouterr().out

    assert "manager" in out
    assert "janitor" in out
    assert "_base" not in out


def test_cli_accepts_dry_run_after_run_subcommand(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.chdir(tmp_path)
    assert main(["init", "--default-binary", "custom"]) == 0

    assert main(["run", "manager", "--dry-run"]) == 0

    out = capsys.readouterr().out
    assert "dry-run: would run manager with custom" in out


def test_cli_run_nightly_accepts_skip_updates(tmp_path: Path, monkeypatch, capsys) -> None:
    monkeypatch.chdir(tmp_path)
    assert main(["init", "--default-binary", "custom"]) == 0

    assert main(["run-nightly", "--dry-run", "--skip-updates"]) == 0

    out = capsys.readouterr().out
    assert "manager: dry-run: would run manager with custom" in out


def test_cli_migrate_legacy_copies_old_cell_layout(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    legacy = tmp_path / "symbiont" / "Janitor"
    legacy.mkdir(parents=True)
    (legacy / "janitor.md").write_text("legacy prompt", encoding="utf-8")
    (legacy / "SOUL.md").write_text("soul", encoding="utf-8")

    assert main(["migrate-legacy"]) == 0

    migrated = tmp_path / "symbiont" / "cells" / "janitor"
    assert (migrated / "agent.md").read_text(encoding="utf-8") == "legacy prompt"
    assert 'name = "janitor"' in (migrated / "cell.toml").read_text(encoding="utf-8")
