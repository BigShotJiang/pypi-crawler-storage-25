from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

from probiotic.dna.hive_client import HiveConfig, RunReport, check_updates, report_run


class HiveHandler(BaseHTTPRequestHandler):
    reports: list[dict] = []

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        HiveHandler.reports.append(json.loads(self.rfile.read(length).decode("utf-8")))
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'{"status":"ok"}')

    def do_GET(self) -> None:
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'{"improvements":[],"new_templates":[]}')

    def log_message(self, format: str, *args) -> None:
        return


def test_hive_client_reports_and_checks_updates() -> None:
    HiveHandler.reports = []
    server = HTTPServer(("127.0.0.1", 0), HiveHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    config = HiveConfig(enabled=True, url=f"http://127.0.0.1:{server.server_port}", api_key="secret")

    try:
        response = report_run(
            config,
            RunReport(
                instance_id="i1",
                repo_name="repo",
                agent="janitor",
                run_date="2026-04-10",
                outcome="clean",
                prompt_hash="sha256:test",
                approval_rate_30d=0.75,
                prompt_text="# Janitor\n\nKeep it clean.",
            ),
        )
        updates = check_updates(config, instance_id="i1")
    finally:
        server.shutdown()
        thread.join(timeout=2)

    assert response == {"status": "ok"}
    assert HiveHandler.reports[0]["agent"] == "janitor"
    assert HiveHandler.reports[0]["approval_rate_30d"] == 0.75
    assert HiveHandler.reports[0]["prompt_text"] == "# Janitor\n\nKeep it clean."
    assert updates == {"improvements": [], "new_templates": []}

