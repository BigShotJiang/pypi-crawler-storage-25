from __future__ import annotations

from pathlib import Path

from probiotic.cli import init_symbiont, spawn_cell
from probiotic.dna.scheduler import AlwaysRunSignal, ordered_cells, run_nightly
from probiotic.dna.runtime import RuntimePaths
from probiotic.dna.config import read_toml


def test_ordered_cells_uses_config_order_then_cell_order(tmp_path: Path) -> None:
    init_symbiont(project_root=tmp_path, default_binary="custom")
    spawn_cell("janitor", project_root=tmp_path, template="janitor", binary="custom")
    paths = RuntimePaths.create(tmp_path)
    config = read_toml(paths.symbiont_root / "config.toml")

    assert ordered_cells(paths, config)[:2] == ["manager", "janitor"]


def test_run_nightly_dry_run_considers_scheduled_cells(tmp_path: Path) -> None:
    init_symbiont(project_root=tmp_path, default_binary="custom")
    spawn_cell("janitor", project_root=tmp_path, template="janitor", binary="custom")

    results = run_nightly(project_root=tmp_path, dry_run=True, signal=AlwaysRunSignal())

    assert [result.cell_name for result in results] == ["manager", "janitor"]
    assert all(result.status == "dry-run" for result in results)


def test_run_nightly_skip_updates_bypasses_hive_pull(tmp_path: Path, monkeypatch) -> None:
    init_symbiont(project_root=tmp_path, default_binary="custom")

    def fail_apply_updates(*args, **kwargs):
        raise AssertionError("apply_updates should not be called")

    monkeypatch.setattr("probiotic.dna.scheduler.apply_updates", fail_apply_updates)

    results = run_nightly(project_root=tmp_path, dry_run=True, signal=AlwaysRunSignal(), skip_updates=True)

    assert [result.cell_name for result in results] == ["manager"]

