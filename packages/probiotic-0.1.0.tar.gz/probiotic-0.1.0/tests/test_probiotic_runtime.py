from __future__ import annotations

from pathlib import Path

from probiotic.cli import init_symbiont, spawn_cell
from probiotic.dna.runtime import RuntimePaths, apply_updates, run_cell
from probiotic.dna.config import read_toml


def test_run_cell_executes_custom_binary_and_logs(tmp_path: Path) -> None:
    init_symbiont(project_root=tmp_path, default_binary="custom")
    cell_dir = spawn_cell("janitor", project_root=tmp_path, template="janitor", binary="custom")
    cell_toml = cell_dir / "cell.toml"
    cell_toml.write_text(
        cell_toml.read_text(encoding="utf-8") + 'binary_command = "/bin/sh -c true"\n',
        encoding="utf-8",
    )

    result = run_cell("janitor", project_root=tmp_path)

    assert result.returncode == 0
    assert result.status == "completed"
    assert "completed" in (cell_dir / "run.log").read_text(encoding="utf-8")


def test_run_cell_dry_run_does_not_require_binary_command(tmp_path: Path) -> None:
    init_symbiont(project_root=tmp_path, default_binary="custom")

    result = run_cell("manager", project_root=tmp_path, dry_run=True)

    assert result.returncode == 0
    assert result.status == "dry-run"
    assert (tmp_path / "symbiont" / "cells" / "manager" / "run.log").read_text(encoding="utf-8") == ""


def test_run_cell_prompt_hash_ignores_memory_changes(tmp_path: Path) -> None:
    init_symbiont(project_root=tmp_path, default_binary="custom")
    cell_dir = spawn_cell("janitor", project_root=tmp_path, template="janitor", binary="custom")
    cell_toml = cell_dir / "cell.toml"
    cell_toml.write_text(
        cell_toml.read_text(encoding="utf-8") + 'binary_command = "/bin/sh -c true"\n',
        encoding="utf-8",
    )
    (cell_dir / "memory.md").write_text("# Memory\n\nfirst", encoding="utf-8")

    first = run_cell("janitor", project_root=tmp_path)
    (cell_dir / "memory.md").write_text("# Memory\n\nsecond", encoding="utf-8")
    second = run_cell("janitor", project_root=tmp_path)

    assert first.prompt_hash == second.prompt_hash
    history = (cell_dir / "run_history.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(history) == 2


def test_apply_updates_replaces_prompt_and_writes_backup(tmp_path: Path, monkeypatch) -> None:
    init_symbiont(project_root=tmp_path, default_binary="custom")
    cell_dir = spawn_cell("janitor", project_root=tmp_path, template="janitor", binary="custom")
    config_path = tmp_path / "symbiont" / "config.toml"
    config_path.write_text(
        config_path.read_text(encoding="utf-8")
        .replace('enabled = false', 'enabled = true')
        .replace('url = ""', 'url = "http://hive.local"')
        .replace('api_key = ""', 'api_key = "secret"'),
        encoding="utf-8",
    )
    instance_config = read_toml(config_path)
    paths = RuntimePaths.create(tmp_path)
    replacement = "# Janitor\n\nUse {{PROJECT_ROOT}} carefully."

    monkeypatch.setattr(
        "probiotic.dna.runtime.check_updates",
        lambda *args, **kwargs: {
            "improvements": [
                {
                    "agent_template": "janitor",
                    "change_type": "prompt_patch",
                    "description": "verified janitor prompt",
                    "patch": replacement,
                    "confidence": 0.9,
                    "prompt_hash": "sha256:new",
                }
            ],
            "new_templates": [],
        },
    )

    actions = apply_updates(paths, instance_config)

    assert actions == ["applied janitor: verified janitor prompt (confidence 0.90)"]
    assert (cell_dir / "agent.md").read_text(encoding="utf-8") == replacement
    assert (cell_dir / "agent.md.pre-hive").exists()
