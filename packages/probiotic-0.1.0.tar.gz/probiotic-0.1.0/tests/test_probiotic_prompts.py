from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from probiotic.dna.prompts import TemplateContext, load_cell_prompt, load_shareable_prompt, render_text


def test_render_text_substitutes_runtime_variables(tmp_path: Path) -> None:
    symbiont_root = tmp_path / "symbiont"
    cell_dir = symbiont_root / "cells" / "janitor"
    context = TemplateContext(
        project_root=tmp_path,
        symbiont_root=symbiont_root,
        cell_dir=cell_dir,
        cell_name="janitor",
        timestamp=datetime(2026, 4, 10, 5, 0, tzinfo=timezone.utc),
    )

    rendered = render_text("{{PROJECT_ROOT}} {{CELL_NAME}} {{DATE}} {{TIMESTAMP}}", context)

    assert str(tmp_path) in rendered
    assert "janitor" in rendered
    assert "2026-04-10" in rendered


def test_load_cell_prompt_injects_memory(tmp_path: Path) -> None:
    symbiont_root = tmp_path / "symbiont"
    cell_dir = symbiont_root / "cells" / "janitor"
    cell_dir.mkdir(parents=True)
    (cell_dir / "agent.md").write_text("Work in {{PROJECT_ROOT}}.", encoding="utf-8")
    (cell_dir / "memory.md").write_text("Remember the guardrail.", encoding="utf-8")
    context = TemplateContext.create(tmp_path, symbiont_root, cell_dir, "janitor")

    prompt = load_cell_prompt(cell_dir, context)

    assert f"Work in {tmp_path.resolve()}." in prompt
    assert "## Persistent memory" in prompt
    assert "Remember the guardrail." in prompt


def test_load_shareable_prompt_normalizes_runtime_paths(tmp_path: Path) -> None:
    symbiont_root = tmp_path / "symbiont"
    cell_dir = symbiont_root / "cells" / "janitor"
    cell_dir.mkdir(parents=True)
    (cell_dir / "agent.md").write_text(f"Work in {tmp_path.resolve()} from {cell_dir.resolve()}.", encoding="utf-8")
    context = TemplateContext.create(tmp_path, symbiont_root, cell_dir, "janitor")

    prompt = load_shareable_prompt(cell_dir, context)

    assert "{{PROJECT_ROOT}}" in prompt
    assert "{{CELL_DIR}}" in prompt

