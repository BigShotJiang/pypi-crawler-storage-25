from __future__ import annotations

from pathlib import Path

from probiotic.dna.tickets import consume_ticket, create_ticket, list_tickets, read_ticket


def test_ticket_create_read_and_consume(tmp_path: Path) -> None:
    symbiont_root = tmp_path / "symbiont"
    receiver_dir = symbiont_root / "cells" / "janitor"
    receiver_dir.mkdir(parents=True)

    path = create_ticket(
        symbiont_root,
        sender="manager",
        receiver="janitor",
        subject="Clean stale cache",
        body="Please inspect the cache directory.",
    )

    assert path in list_tickets(receiver_dir)
    ticket = read_ticket(path)
    assert ticket.sender == "manager"
    assert ticket.receiver == "janitor"
    assert ticket.subject == "Clean stale cache"

    consumed = consume_ticket(path)
    assert consumed.subject == "Clean stale cache"
    assert not path.exists()

