from __future__ import annotations

from hive.analyzer import analyze_and_store, find_verified_improvements
from hive.models import HiveStore, RunRecord


def test_hive_analyzer_requires_cross_repo_improvement_signal() -> None:
    records = [
        RunRecord(
            instance_id=f"repo-{index}",
            repo_name=f"repo-{index}",
            agent="janitor",
            run_date="2026-04-10",
            outcome="clean",
            prompt_hash="sha256:better",
            approval_rate_30d=0.90,
            metrics={"previous_approval_rate_30d": 0.70},
        )
        for index in range(3)
    ]

    improvements = find_verified_improvements(records)

    assert len(improvements) == 1
    assert improvements[0].verified_repos == 3
    assert improvements[0].agent_template == "janitor"


def test_hive_analyzer_populates_patch_from_prompt_snapshot(tmp_path) -> None:
    store = HiveStore(tmp_path / "hive.sqlite3")
    store.save_prompt_snapshot(prompt_hash="sha256:better", agent="janitor", content="# Janitor\n\nKeep it tidy.")
    for index in range(3):
        store.save_report(
            RunRecord(
                instance_id=f"repo-{index}",
                repo_name=f"repo-{index}",
                agent="janitor",
                run_date="2026-04-10",
                outcome="clean",
                prompt_hash="sha256:better",
                approval_rate_30d=0.90,
                metrics={"previous_approval_rate_30d": 0.70},
            )
        )

    improvements = analyze_and_store(store, min_repos=2)

    assert len(improvements) == 1
    assert improvements[0].patch == "# Janitor\n\nKeep it tidy."

