import asyncio
import json
import signal
import ssl
import sys
import time
import tempfile
import os
from typing import Dict, Callable, Optional, List, Union
from websockets.server import serve
from websockets.exceptions import ConnectionClosed
from .components import Page, Widget, WidgetType, NavItem


class RateLimiter:
    """Token bucket rate limiter per WebSocket connection.

    Limits the number of messages a single client can send per second.
    When the limit is exceeded, messages are silently dropped and the
    client is notified after the window resets.
    """

    def __init__(self, rate: float = 50.0, burst: int = 100):
        """
        Args:
            rate: Tokens added per second (steady-state throughput).
            burst: Maximum bucket size (burst allowance).
        """
        self.rate = rate
        self.burst = burst
        self._buckets: Dict[object, Dict[str, float]] = {}
        self._limited: set = set()  # track connections currently throttled

    def _get_bucket(self, key: object) -> Dict[str, float]:
        if key not in self._buckets:
            self._buckets[key] = {"tokens": self.burst, "last": time.monotonic()}
        return self._buckets[key]

    def allow(self, key: object) -> bool:
        """Return True if the request is allowed under the rate limit."""
        # If already throttled, deny until bucket refills
        if key in self._limited:
            bucket = self._get_bucket(key)
            now = time.monotonic()
            elapsed = now - bucket["last"]
            bucket["last"] = now
            bucket["tokens"] = min(self.burst, bucket["tokens"] + elapsed * self.rate)
            if bucket["tokens"] >= 1:
                self._limited.discard(key)
                bucket["tokens"] -= 1
                return True
            return False

        bucket = self._get_bucket(key)
        now = time.monotonic()
        elapsed = now - bucket["last"]
        bucket["last"] = now
        bucket["tokens"] = min(self.burst, bucket["tokens"] + elapsed * self.rate)
        if bucket["tokens"] >= 1:
            bucket["tokens"] -= 1
            return True

        self._limited.add(key)
        return False

    def remove(self, key: object) -> None:
        self._buckets.pop(key, None)
        self._limited.discard(key)


def _generate_self_signed_cert() -> tuple:
    """Generate a self-signed certificate for development use.

    Returns (cert_file, key_file) paths. The files are written to a temp
    directory and persist for the lifetime of the process.
    """
    try:
        import ipaddress
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from datetime import datetime, timedelta

        # Generate private key
        key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )

        # Build certificate
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "Localhost"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "TermStream"),
            x509.NameAttribute(NameOID.COMMON_NAME, "localhost"),
        ])

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.utcnow())
            .not_valid_after(datetime.utcnow() + timedelta(days=365))
            .add_extension(
                x509.SubjectAlternativeName([
                    x509.DNSName("localhost"),
                    x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
                ]),
                critical=False,
            )
            .sign(key, hashes.SHA256())
        )

        # Write to temp files
        tmp_dir = tempfile.mkdtemp(prefix="termstream_ssl_")
        cert_path = os.path.join(tmp_dir, "cert.pem")
        key_path = os.path.join(tmp_dir, "key.pem")

        with open(cert_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        with open(key_path, "wb") as f:
            f.write(
                key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption(),
                )
            )

        return cert_path, key_path

    except ImportError:
        raise ImportError(
            "HTTPS requires the 'cryptography' package. "
            "Install it with: pip install cryptography"
        )


class TermStreamServer:
    def __init__(
        self,
        host: str = "localhost",
        port: int = 8765,
        allowed_origins: Optional[List[str]] = None,
        ssl_certfile: Optional[str] = None,
        ssl_keyfile: Optional[str] = None,
    ):
        self.host = host
        self.port = port
        # Routes can store either Page objects or callables that return Page objects
        self.routes: Dict[str, Union[Page, Callable[[], Page]]] = {}
        self.input_handlers: Dict[str, Callable] = {}
        self._running = False
        # allowed_origins: None -> allow all (legacy). List -> enforce check.
        self.allowed_origins = allowed_origins
        self._rate_limiter = RateLimiter()

        # SSL / HTTPS support
        self.ssl_certfile = ssl_certfile
        self.ssl_keyfile = ssl_keyfile
        self._ssl_context: Optional[ssl.SSLContext] = None
        self._auto_cert = False  # track if we generated a self-signed cert

    def _ensure_ssl_context(self) -> Optional[ssl.SSLContext]:
        """Build and cache an SSL context if HTTPS is requested."""
        if self._ssl_context is not None:
            return self._ssl_context

        needs_ssl = self.ssl_certfile is not None or self.ssl_keyfile is not None
        if not needs_ssl:
            return None

        # If only one of cert/key is given, auto-generate the missing one
        if self.ssl_certfile and not self.ssl_keyfile:
            _, self.ssl_keyfile = _generate_self_signed_cert()
            self._auto_cert = True
        elif self.ssl_keyfile and not self.ssl_certfile:
            self.ssl_certfile, _ = _generate_self_signed_cert()
            self._auto_cert = True
        elif not self.ssl_certfile and not self.ssl_keyfile:
            # Both None -> generate self-signed pair
            self.ssl_certfile, self.ssl_keyfile = _generate_self_signed_cert()
            self._auto_cert = True

        ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        ctx.load_cert_chain(certfile=self.ssl_certfile, keyfile=self.ssl_keyfile)
        # Allow TLS 1.2+
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        self._ssl_context = ctx
        return ctx

    @property
    def scheme(self) -> str:
        """Return 'wss' if SSL is configured, 'ws' otherwise."""
        return "wss" if (self.ssl_certfile or self.ssl_keyfile) else "ws"

    def _resolve_route_target(self, path: str) -> Page:
        """Resolve a route path to a Page, calling callables if needed.

        When a route stores a callable (e.g., from @app.route decorator on a
        function), it is called once and the resulting Page is cached.
        """
        target = self.routes.get(path)
        if target is None:
            return self._get_404()
        if callable(target):
            page = target()
            # Cache the result so subsequent hits don't re-call
            self.routes[path] = page
            return page
        return target

    def _resolve_nav(self, current_path: str) -> list:
        """Auto-resolve navigation items based on the route tree.

        For the current path, find all direct child routes and create nav items.
        If there are no children, return an end-of-node indicator.
        """
        # Normalize: ensure current_path starts with /
        base = current_path.rstrip('/')
        if not base:
            base = '/'

        children = []
        for route_path in self.routes:
            rp = route_path.rstrip('/')
            if rp == '/':
                continue
            # Check if route_path is a direct child of current_path
            if base == '/':
                # Root: direct children are routes with exactly one more segment
                parts = rp.lstrip('/').split('/')
                if len(parts) == 1:
                    children.append((parts[0], '/' + parts[0]))
            else:
                # Non-root: children are routes that start with base/
                if rp.startswith(base + '/'):
                    remainder = rp[len(base) + 1:]
                    parts = remainder.split('/')
                    if len(parts) == 1:
                        children.append((parts[0], base + '/' + parts[0]))

        if not children:
            # End of node - no children
            return [NavItem("__end__", "(end of node)", "")]

        # Build nav items - label is the segment name, target is the full path
        nav_items = []
        for label, target in children:
            # Skip items with empty labels to prevent blank nav entries
            if not label:
                continue
            nav_items.append(NavItem(label, label.capitalize(), target))
        return nav_items if nav_items else [NavItem("__end__", "(end of node)", "")]

    def route(self, path: str):
        def decorator(func_or_page):
            self.routes[path] = func_or_page
            return func_or_page
        return decorator

    def on_input(self, widget_id: str):
        def decorator(handler: Callable):
            self.input_handlers[widget_id] = handler
            return handler
        return decorator

    async def _stream_page(self, ws, page: Page, current_path: str):
        # Auto-resolve nav from route tree
        nav_items = self._resolve_nav(current_path)
        init_frame = {
            "op": "init",
            "title": page.title,
            "nav": [n.to_dict() for n in nav_items],
        }
        await ws.send(json.dumps(init_frame))
        for w in page.widgets:
            await ws.send(json.dumps(w.to_frame()))
        await ws.send(json.dumps({"op": "end"}))

    async def _handle_client(self, ws):
        current_path = list(self.routes.keys())[0] if self.routes else "/404"
        page = self._resolve_route_target(current_path)
        await self._stream_page(ws, page, current_path)

        try:
            async for msg in ws:
                # Rate limiting: reject messages that exceed the allowed rate
                if not self._rate_limiter.allow(ws):
                    await ws.send(json.dumps({
                        "op": "error",
                        "text": "Rate limit exceeded. Slow down."
                    }))
                    continue

                try:
                    data = json.loads(msg)
                except (json.JSONDecodeError, TypeError):
                    await ws.send(json.dumps({
                        "op": "error",
                        "text": "Invalid JSON message."
                    }))
                    continue

                if not isinstance(data, dict):
                    await ws.send(json.dumps({
                        "op": "error",
                        "text": "Message must be a JSON object."
                    }))
                    continue

                if data.get("type") == "navigate":
                    target = data.get("target", current_path)
                    # Ignore empty target (end-of-node indicator)
                    if not target:
                        continue
                    current_path = target
                    page = self._resolve_route_target(target)
                    await self._stream_page(ws, page, target)
                elif data.get("type") == "input":
                    wid, value = data.get("id"), data.get("value", "")
                    handler = self.input_handlers.get(wid)
                    if handler:
                        res = handler(wid, value)
                        if asyncio.iscoroutine(res): await res
                    await ws.send(json.dumps({"op": "update", "id": wid, "text": f"OK: {value}", "style": {"bold": True}}))
        except ConnectionClosed:
            pass
        finally:
            # Clean up rate limiter bucket when connection closes
            self._rate_limiter.remove(ws)

    def _get_404(self) -> Page:
        return Page(
            title="404 Not Found",
            nav=[NavItem("home", "home", "/")],
            widgets=[
                Widget("h1", WidgetType.HEADING, (0, 0), "404 - Page Not Found", bold=True),
                Widget("p1", WidgetType.TEXT, (2, 0), "Route not registered."),
                Widget("btn", WidgetType.BUTTON, (4, 0), "Go Home", action={"type": "navigate", "target": "/"})
            ]
        )

    async def _check_origin(self, path, request_headers):
        """Process-request callback to enforce origin checking."""
        if self.allowed_origins is None:
            # No origin restriction configured — allow all (legacy behavior)
            return

        origin = request_headers.get("Origin", "")
        if not origin:
            return

        # Normalize allowed origins for comparison
        allowed = [o.rstrip("/") for o in self.allowed_origins]
        normalized_origin = origin.rstrip("/")

        if normalized_origin not in allowed:
            # Reject with HTTP 403
            return (403, "Forbidden", b"Origin not allowed: " + origin.encode())

    async def start(self):
        self._running = True
        main_future = None

        def _signal_handler() -> None:
            """Cancel the main future to trigger graceful shutdown."""
            nonlocal main_future
            if main_future is not None:
                main_future.cancel()

        # Signal handlers only work on Unix (not Windows)
        if sys.platform != "win32":
            loop = asyncio.get_running_loop()
            for sig in (signal.SIGINT, signal.SIGTERM):
                loop.add_signal_handler(sig, _signal_handler)

        kwargs = {}
        if self.allowed_origins is not None:
            kwargs["process_request"] = self._check_origin

        # SSL context
        ssl_ctx = self._ensure_ssl_context()
        if ssl_ctx:
            kwargs["ssl"] = ssl_ctx

        async with serve(self._handle_client, self.host, self.port, **kwargs):
            scheme = self.scheme
            print(f"TermStream server on {scheme}://{self.host}:{self.port}")
            if self.allowed_origins:
                print(f"Allowed origins: {self.allowed_origins}")
            print(f"Routes: {list(self.routes.keys())}")
            if ssl_ctx:
                if self._auto_cert:
                    print("WARNING: Using auto-generated self-signed certificate.")
                    print("        For production, provide your own cert with --ssl-cert and --ssl-key.")
                else:
                    print(f"SSL cert: {self.ssl_certfile}")
                    print(f"SSL key:  {self.ssl_keyfile}")
            main_future = asyncio.Future()
            try:
                await main_future
            except asyncio.CancelledError:
                await self.stop()

    async def stop(self):
        self._running = False
        print("\nShutting down...")