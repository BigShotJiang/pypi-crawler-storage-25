from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Tuple
from enum import Enum

class WidgetType(Enum):
    TEXT = "text"
    HEADING = "heading"
    BUTTON = "button"
    INPUT = "input"

@dataclass
class NavItem:
    id: str
    label: str
    target: str
    def to_dict(self) -> dict:
        return {"id": self.id, "label": self.label, "target": self.target}

@dataclass
class Widget:
    id: str
    type: WidgetType
    pos: Tuple[int, int]
    text: str
    bold: bool = False
    action: Optional[Dict[str, Any]] = None

    def to_frame(self) -> dict:
        frame = {
            "op": "widget",
            "id": self.id,
            "type": self.type.value,
            "pos": list(self.pos),
            "text": self.text,
            "style": {"bold": self.bold} if self.bold else {},
        }
        if self.action:
            frame["action"] = self.action
        return frame

    def _to_dict(self) -> dict:
        """Convert widget to a dictionary suitable for YAML serialization."""
        d = {
            "id": self.id,
            "type": self.type.value,
            "pos": list(self.pos),
            "text": self.text,
        }
        if self.bold:
            d["style"] = {"bold": True}
        if self.action:
            d["action"] = self.action
        return d

@dataclass
class Page:
    title: str
    nav: List[NavItem] = field(default_factory=list)
    widgets: List[Widget] = field(default_factory=list)

    def to_init_frame(self) -> dict:
        return {
            "op": "init",
            "title": self.title,
            "nav": [n.to_dict() for n in self.nav],
        }