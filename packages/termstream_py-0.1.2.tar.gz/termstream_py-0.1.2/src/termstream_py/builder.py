"""Builder functions for programmatically constructing TermStream applications.

Provides a PageNode-based API for building terminal UI applications hierarchically.
PageNodes can be created empty, have widgets added, be nested with parent-child
relationships, and be loaded from or exported to YAML files or directory formats.

Example usage:
    # Build programmatically
    app = PageNode("app")
    home = PageNode("home", path="/")
    home.add_heading("Welcome")
    home.add_text("Hello, TermStream!")
    home.add_button("-> Docs", action={"type": "navigate", "target": "/docs"})
    app.add_child(home)

    docs = PageNode("docs", path="/docs")
    docs.add_heading("Documentation")
    docs.add_input("Search...")
    app.add_child(docs)

    # Export to YAML
    app.to_yaml("config.yaml")

    # Export to directory format
    app.to_directory("output/")

    # Load from YAML
    loaded = PageNode.from_yaml("config.yaml")

    # Load from directory
    loaded = PageNode.from_directory("my_app/")

    # Convert to server and start
    server = app.to_server(host="localhost", port=8765)
    await server.start()
"""

import uuid
import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List

from .components import Page, Widget, WidgetType, NavItem
from .server import TermStreamServer


class PageNode:
    """A hierarchical node that represents a page in a TermStream application.

    Each node has a name, an optional path, a list of child nodes,
    and a collection of widgets that define its page content.

    Attributes:
        name: Human-readable name for the node.
        path: URL path for this node (e.g., "/", "/docs"). If None, it will
             be auto-derived from the parent path and the node name.
        parent: Reference to the parent node, or None for root nodes.
        children: List of child nodes.
        widgets: List of Widget instances defining the page content.
        title: Page title shown in the terminal header.
    """

    def __init__(self, name: str, path: Optional[str] = None, title: Optional[str] = None):
        self.name = name
        self.path = path
        self.title = title or name.capitalize()
        self.parent: Optional["PageNode"] = None
        self.children: List["PageNode"] = []
        self.widgets: List[Widget] = []

    # ------------------------------------------------------------------ #
    # Builder methods for adding widgets
    # ------------------------------------------------------------------ #

    def add_widget(self, widget: Widget) -> "PageNode":
        """Add an existing Widget to this node.

        Returns self for method chaining.
        """
        self.widgets.append(widget)
        return self

    def add_text(self, text: str, pos: Optional[tuple] = None, bold: bool = False) -> "PageNode":
        """Add a TEXT widget.

        Returns self for method chaining.
        """
        if pos is None:
            pos = (len(self.widgets), 0)
        widget = Widget(
            id=f"txt_{uuid.uuid4().hex[:8]}",
            type=WidgetType.TEXT,
            pos=pos,
            text=text,
            bold=bold,
        )
        self.widgets.append(widget)
        return self

    def add_heading(self, text: str, pos: Optional[tuple] = None) -> "PageNode":
        """Add a HEADING widget (bold by default).

        Returns self for method chaining.
        """
        if pos is None:
            pos = (len(self.widgets), 0)
        widget = Widget(
            id=f"hdg_{uuid.uuid4().hex[:8]}",
            type=WidgetType.HEADING,
            pos=pos,
            text=text,
            bold=True,
        )
        self.widgets.append(widget)
        return self

    def add_button(self, text: str, pos: Optional[tuple] = None,
                   action: Optional[Dict[str, Any]] = None) -> "PageNode":
        """Add a BUTTON widget.

        Args:
            text: Label shown on the button.
            pos: (row, col) position. Auto-calculated if None.
            action: Optional action dict, e.g. {"type": "navigate", "target": "/path"}.

        Returns self for method chaining.
        """
        if pos is None:
            pos = (len(self.widgets), 0)
        widget = Widget(
            id=f"btn_{uuid.uuid4().hex[:8]}",
            type=WidgetType.BUTTON,
            pos=pos,
            text=text,
            action=action,
        )
        self.widgets.append(widget)
        return self

    def add_input(self, text: str = "", pos: Optional[tuple] = None) -> "PageNode":
        """Add an INPUT widget.

        Args:
            text: Placeholder text for the input field.
            pos: (row, col) position. Auto-calculated if None.

        Returns self for method chaining.
        """
        if pos is None:
            pos = (len(self.widgets), 0)
        widget = Widget(
            id=f"inp_{uuid.uuid4().hex[:8]}",
            type=WidgetType.INPUT,
            pos=pos,
            text=text,
        )
        self.widgets.append(widget)
        return self

    # ------------------------------------------------------------------ #
    # Parent-child relationship methods
    # ------------------------------------------------------------------ #

    def add_child(self, child: "PageNode") -> "PageNode":
        """Add a child node. Sets the child's parent reference to self.

        Returns the child node for method chaining on it.
        """
        child.parent = self
        self.children.append(child)
        return child

    def remove_child(self, child: "PageNode") -> None:
        """Remove a child node and clear its parent reference."""
        if child in self.children:
            self.children.remove(child)
            child.parent = None

    def find(self, name: str) -> Optional["PageNode"]:
        """Find a descendant node by name (depth-first search).

        Returns None if not found.
        """
        if self.name == name:
            return self
        for child in self.children:
            result = child.find(name)
            if result is not None:
                return result
        return None

    def find_by_path(self, path: str) -> Optional["PageNode"]:
        """Find a node by its resolved path.

        Returns None if not found.
        """
        resolved = self.resolved_path()
        if resolved == path:
            return self
        for child in self.children:
            result = child.find_by_path(path)
            if result is not None:
                return result
        return None

    # ------------------------------------------------------------------ #
    # Path resolution
    # ------------------------------------------------------------------ #

    def resolved_path(self) -> str:
        """Get the fully resolved path for this node.

        If self.path is set, return it. Otherwise, derive it from the parent
        path and the node name (slugified).
        """
        if self.path is not None:
            return self.path

        if self.parent is None:
            return "/"

        parent_path = self.parent.resolved_path()
        slug = _slugify(self.name)
        if parent_path == "/":
            return f"/{slug}"
        return f"{parent_path}/{slug}"

    # ------------------------------------------------------------------ #
    # Conversion to Page / Server
    # ------------------------------------------------------------------ #

    def to_page(self) -> Page:
        """Convert this node into a Page instance."""
        return Page(
            title=self.title,
            widgets=list(self.widgets),
        )

    def to_server(self, host: str = "localhost", port: int = 8765) -> TermStreamServer:
        """Convert this node tree into a TermStreamServer with all routes registered.

        Args:
            host: Server host address.
            port: Server port number.

        Returns:
            A fully configured TermStreamServer instance.
        """
        server = TermStreamServer(host=host, port=port)

        def _register(node: "PageNode") -> None:
            path = node.resolved_path()
            server.routes[path] = node.to_page()
            for child in node.children:
                _register(child)

        _register(self)
        return server

    # ------------------------------------------------------------------ #
    # YAML export
    # ------------------------------------------------------------------ #

    def to_yaml_dict(self) -> Dict[str, Any]:
        """Convert this node tree into a YAML-compatible dictionary.

        Returns a dictionary that can be serialized with yaml.dump() or
        written using to_yaml().
        """
        pages = []

        def _collect(node: "PageNode") -> None:
            path = node.resolved_path()
            page_data = {
                "path": path,
                "title": node.title,
                "widgets": [w._to_dict() for w in node.widgets],
            }
            pages.append(page_data)
            for child in node.children:
                _collect(child)

        _collect(self)

        # Extract host/port from server if available, else defaults
        result = {
            "host": "localhost",
            "port": 8765,
            "pages": pages,
        }
        return result

    def to_yaml(self, path: str, host: str = "localhost", port: int = 8765) -> None:
        """Export this node tree to a YAML file.

        Args:
            path: File path to write the YAML configuration.
            host: Server host address.
            port: Server port number.
        """
        data = self.to_yaml_dict()
        data["host"] = host
        data["port"] = port

        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    # ------------------------------------------------------------------ #
    # YAML loading
    # ------------------------------------------------------------------ #

    @classmethod
    def from_yaml(cls, path: str) -> "PageNode":
        """Load a node tree from a YAML configuration file.

        Args:
            path: Path to the YAML file.

        Returns:
            A PageNode instance representing the root of the loaded tree.
        """
        with open(path, "r") as f:
            config = yaml.safe_load(f)

        root = cls("root", path="/")
        pages = config.get("pages", [])

        # Group pages by path depth to reconstruct hierarchy
        page_map: Dict[str, "PageNode"] = {}

        for page_data in pages:
            p = page_data["path"]
            title = page_data.get("title", "Untitled")
            node = cls(name=p.split("/")[-1] or "root", path=p, title=title)

            for w_data in page_data.get("widgets", []):
                widget = _parse_widget(w_data)
                node.widgets.append(widget)

            page_map[p] = node

        # Build hierarchy from paths
        for p, node in page_map.items():
            if p == "/":
                # Merge root into our root node
                root.widgets = node.widgets
                root.title = node.title
                continue

            # Find parent path
            parts = p.rstrip("/").split("/")
            if len(parts) <= 2:
                # Direct child of root
                root.add_child(node)
            else:
                parent_path = "/".join(parts[:-1])
                if not parent_path.startswith("/"):
                    parent_path = "/" + parent_path
                parent_node = page_map.get(parent_path)
                if parent_node:
                    parent_node.add_child(node)
                else:
                    # Parent not in map, attach to root
                    root.add_child(node)

        return root

    # ------------------------------------------------------------------ #
    # Directory export
    # ------------------------------------------------------------------ #

    def to_directory(self, base_path: str) -> None:
        """Export this node tree to a directory structure with content.md files.

        Each node becomes a directory containing a content.md file with the
        widget content rendered in a simple markdown format.

        Args:
            base_path: Root directory path to write the structure.
        """
        base = Path(base_path)
        base.mkdir(parents=True, exist_ok=True)

        def _write_node(node: "PageNode", dir_path: Path) -> None:
            dir_path.mkdir(parents=True, exist_ok=True)
            content_file = dir_path / "content.md"

            lines = []
            for w in node.widgets:
                if w.type == WidgetType.HEADING:
                    lines.append(f"# {w.text}")
                elif w.type == WidgetType.BUTTON:
                    action_target = ""
                    if w.action and w.action.get("type") == "navigate":
                        action_target = f" -> {w.action.get('target', '')}"
                    lines.append(f"> {w.text}{action_target}")
                elif w.type == WidgetType.INPUT:
                    lines.append(f"$ {w.text}")
                else:
                    lines.append(w.text)
                lines.append("")  # blank line after each widget

            content_file.write_text("\n".join(lines))

            # Recurse into children
            for child in node.children:
                child_dir = dir_path / _slugify(child.name)
                _write_node(child, child_dir)

        _write_node(self, base)

    # ------------------------------------------------------------------ #
    # Directory loading
    # ------------------------------------------------------------------ #

    @classmethod
    def from_directory(cls, directory: str) -> "PageNode":
        """Load a node tree from a directory structure.

        Each directory containing a content.md file becomes a node.
        Subdirectories become child nodes.

        Args:
            directory: Path to the root directory.

        Returns:
            A PageNode instance representing the root of the loaded tree.
        """
        root_path = Path(directory).resolve()
        root = cls("root", path="/")

        def _build(dir_path: Path, parent_node: "PageNode") -> None:
            content_file = dir_path / "content.md"

            if content_file.exists():
                widgets = _parse_content_md(str(content_file))
                # Determine node name and title
                if parent_node is root and dir_path == root_path:
                    name = "root"
                    path = "/"
                else:
                    name = dir_path.name
                    # Derive path from parent
                    path = f"{parent_node.resolved_path()}/{_slugify(name)}" if parent_node.resolved_path() != "/" else f"/{_slugify(name)}"

                # Extract title from first heading widget
                title = "Untitled"
                for w in widgets:
                    if w.type == WidgetType.HEADING:
                        title = w.text
                        break

                node = cls(name=name, path=path, title=title)
                node.widgets = widgets
                parent_node.add_child(node)
                current_node = node
            else:
                current_node = parent_node

            # Recurse into subdirectories
            for entry in sorted(dir_path.iterdir()):
                if entry.is_dir() and not entry.name.startswith((".", "_")):
                    _build(entry, current_node)

        _build(root_path, root)
        return root

    # ------------------------------------------------------------------ #
    # Utility
    # ------------------------------------------------------------------ #

    def all_nodes(self) -> List["PageNode"]:
        """Return a flat list of all nodes in the tree (depth-first)."""
        result = [self]
        for child in self.children:
            result.extend(child.all_nodes())
        return result

    def visualise(self) -> str:
        """Display the current navigation tree defined for this PageNode.

        Returns a string representation of the tree showing node names,
        resolved paths, and widget counts for each node in the hierarchy.

        Example output:
            root (/) [3 widgets]
            ├── home (/home) [2 widgets]
            │   ├── dashboard (/home/dashboard) [4 widgets]
            │   └── settings (/home/settings) [1 widget]
            └── docs (/docs) [5 widgets]
        """
        lines = []
        self._visualise_tree("", True, lines, is_root=True)
        return "\n".join(lines)

    def _visualise_tree(
        self, prefix: str, is_last: bool, lines: List[str], is_root: bool = False
    ) -> None:
        """Recursively build the tree visualization."""
        path = self.resolved_path()
        widget_count = len(self.widgets)
        widget_label = f"{widget_count} widget{'s' if widget_count != 1 else ''}"

        # Root node has no connector
        if is_root:
            connector = ""
        else:
            connector = prefix + ("└── " if is_last else "├── ")

        lines.append(f"{connector}{self.name} ({path}) [{widget_label}]")

        # Extend prefix for children
        if is_root:
            new_prefix = ""
        else:
            new_prefix = prefix + ("    " if is_last else "│   ")

        children = self.children
        for i, child in enumerate(children):
            is_last_child = i == len(children) - 1
            child._visualise_tree(new_prefix, is_last_child, lines, is_root=False)

    def __repr__(self) -> str:
        path = self.resolved_path()
        return f"PageNode(name={self.name!r}, path={path!r}, children={len(self.children)}, widgets={len(self.widgets)})"


# ------------------------------------------------------------------ #
# Helper functions
# ------------------------------------------------------------------ #

def _slugify(name: str) -> str:
    """Convert a name to a URL-friendly slug."""
    import re
    slug = name.lower().strip()
    slug = re.sub(r'[^a-z0-9]+', '-', slug)
    slug = slug.strip('-')
    return slug or name.lower()


def _parse_widget_type(type_str: str) -> WidgetType:
    """Convert a string widget type to WidgetType enum."""
    mapping = {
        "text": WidgetType.TEXT,
        "heading": WidgetType.HEADING,
        "button": WidgetType.BUTTON,
        "input": WidgetType.INPUT,
    }
    wt = mapping.get(type_str.lower())
    if wt is None:
        raise ValueError(f"Unknown widget type: {type_str!r}. Must be one of {list(mapping.keys())}")
    return wt


def _parse_widget(data: Dict[str, Any]) -> Widget:
    """Parse a widget dict (from YAML) into a Widget instance."""
    if not isinstance(data, dict):
        raise ValueError(f"Expected dict for widget, got {type(data).__name__}")

    type_str = data.get("type")
    if type_str is None:
        raise ValueError("Widget missing required 'type' field")

    pos = data.get("pos", [0, 0])
    if isinstance(pos, (list, tuple)):
        pos = (int(pos[0]), int(pos[1]))

    style = data.get("style", {})
    bold = style.get("bold", False) if isinstance(style, dict) else False

    widget_id = data.get("id") or f"w_{uuid.uuid4().hex[:8]}"

    return Widget(
        id=widget_id,
        type=_parse_widget_type(type_str),
        pos=pos,
        text=data.get("text", ""),
        bold=bold,
        action=data.get("action"),
    )


def _parse_content_md(file_path: str) -> List[Widget]:
    """Parse a content.md file into a list of Widgets."""
    widgets = []
    row = 0
    title_found = False

    with open(file_path, "r") as f:
        for line in f:
            # FIX: proper line ending handling for all platforms
            line = line.rstrip("\r\n")
            stripped = line.strip()

            if not stripped:
                row += 1
                continue

            # First heading becomes title heading widget
            if not title_found and stripped.startswith("#"):
                title_text = stripped.lstrip("#").strip()
                widgets.append(Widget(
                    id=f"title_{uuid.uuid4().hex[:6]}",
                    type=WidgetType.HEADING,
                    pos=(row, 0),
                    text=title_text,
                    bold=True,
                ))
                title_found = True
                row += 1
                continue

            # Button: line starting with >
            if stripped.startswith(">"):
                btn_text = stripped[1:].strip()
                # Check for navigation target in format "-> /path"
                action = None
                if " -> " in btn_text:
                    parts = btn_text.split(" -> ", 1)
                    btn_text = parts[0].strip()
                    target = parts[1].strip()
                    action = {"type": "navigate", "target": target}
                widgets.append(Widget(
                    id=f"btn_{uuid.uuid4().hex[:6]}",
                    type=WidgetType.BUTTON,
                    pos=(row, 0),
                    text=btn_text,
                    action=action,
                ))
                row += 1
                continue

            # Input: line starting with $
            if stripped.startswith("$"):
                placeholder = stripped[1:].strip()
                widgets.append(Widget(
                    id=f"inp_{uuid.uuid4().hex[:6]}",
                    type=WidgetType.INPUT,
                    pos=(row, 0),
                    text=placeholder,
                ))
                row += 1
                continue

            # Regular text
            widgets.append(Widget(
                id=f"txt_{uuid.uuid4().hex[:6]}",
                type=WidgetType.TEXT,
                pos=(row, 0),
                text=stripped,
            ))
            row += 1

    return widgets


# ------------------------------------------------------------------ #
# Convenience factory functions
# ------------------------------------------------------------------ #

def create_page_node(name: str, path: Optional[str] = None, title: Optional[str] = None) -> PageNode:
    """Create a new empty PageNode.

    Args:
        name: Human-readable name for the node.
        path: Optional URL path. Auto-derived if None.
        title: Optional page title. Defaults to capitalized name.

    Returns:
        A new PageNode instance.
    """
    return PageNode(name, path=path, title=title)


def create_server_from_nodes(root: PageNode, host: str = "localhost", port: int = 8765) -> TermStreamServer:
    """Create a TermStreamServer from a root PageNode tree.

    Args:
        root: Root node of the application tree.
        host: Server host address.
        port: Server port number.

    Returns:
        A fully configured TermStreamServer instance.
    """
    return root.to_server(host=host, port=port)