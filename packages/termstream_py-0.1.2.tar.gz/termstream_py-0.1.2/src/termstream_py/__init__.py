"""TermStream - Unified streaming terminal UI framework (client + server)."""

__version__ = "0.1.0"

from .components import Page, Widget, WidgetType, NavItem
from .server import TermStreamServer
from .browser import TermStreamBrowser
from .mcp import init_mcp_server
from .builder import (
    PageNode,
    create_page_node,
    create_server_from_nodes,
)

# Convenience functions documented in README
def visualise(node: PageNode) -> str:
    """Display the route tree structure for a PageNode."""
    return node.visualise()


def to_yaml(node: PageNode, path: str) -> None:
    """Export a PageNode tree to a YAML file."""
    node.to_yaml(path)


def from_yaml(path: str) -> PageNode:
    """Load a PageNode tree from a YAML file."""
    return PageNode.from_yaml(path)


def to_directory(node: PageNode, dir_path: str) -> None:
    """Export a PageNode tree to a directory with content.md files."""
    node.to_directory(dir_path)


def from_directory(dir_path: str) -> PageNode:
    """Load a PageNode tree from a directory structure."""
    return PageNode.from_directory(dir_path)


__all__ = [
    "__version__",
    "TermStreamServer",
    "TermStreamBrowser",
    "init_mcp_server",
    "Page",
    "Widget",
    "WidgetType",
    "NavItem",
    "PageNode",
    "create_page_node",
    "create_server_from_nodes",
    "visualise",
    "to_yaml",
    "from_yaml",
    "to_directory",
    "from_directory",
]
