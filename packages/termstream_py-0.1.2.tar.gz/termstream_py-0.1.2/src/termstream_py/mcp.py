import asyncio
from typing import Dict, Any, List, Optional
from mcp.server.fastmcp import FastMCP
from .components import Page, Widget, WidgetType, NavItem
from .server import TermStreamServer

mcp = FastMCP("TermStream-Agent")

class AgentSession:
    """Manages agent navigation state & data extraction.

    All mutating operations are protected by an internal asyncio.Lock to
    prevent race conditions when concurrent MCP tool invocations modify
    history, current_path, or current_page.
    """

    def __init__(self, server: TermStreamServer):
        self.server = server
        self.routes = server.routes
        self.current_path = list(self.routes.keys())[0] if self.routes else "/404"
        self.history = [self.current_path]
        self.history_idx = 0
        self.current_page: Optional[Page] = None
        self._lock = asyncio.Lock()
        self._load_current_page()

    def _load_current_page(self):
        self.current_page = self.routes.get(self.current_path, self.server._get_404())

    def _extract_text(self, widget: Widget) -> str:
        """Normalize widget text for LLM consumption"""
        return " ".join(widget.text.split())

    def _to_structured(self, page: Page) -> Dict[str, Any]:
        """Convert page to agent-friendly JSON"""
        return {
            "path": self.current_path,
            "title": page.title,
            "nav_links": [{"id": n.id, "label": n.label, "target": n.target} for n in page.nav],
            "content_blocks": [
                {"id": w.id, "type": w.type.value, "text": self._extract_text(w)}
                for w in page.widgets if w.type in (WidgetType.TEXT, WidgetType.HEADING)
            ],
            "interactive_elements": [
                {"id": w.id, "type": w.type.value, "action": w.action, "label": self._extract_text(w)}
                for w in page.widgets if w.type in (WidgetType.BUTTON, WidgetType.INPUT)
            ]
        }

    async def navigate_to(self, path: str) -> Dict[str, Any]:
        """Navigate to a path under lock. Returns structured page data."""
        async with self._lock:
            if path not in self.routes:
                return {"error": f"Route '{path}' not found",
                        "available_routes": list(self.routes.keys())}

            if self.history_idx < len(self.history) - 1:
                self.history = self.history[:self.history_idx + 1]
            self.history.append(path)
            self.history_idx += 1
            self.current_path = path
            self._load_current_page()
            return self._to_structured(self.current_page)

    async def go_back(self) -> Dict[str, Any]:
        """Navigate back under lock. Returns structured page data."""
        async with self._lock:
            if self.history_idx > 0:
                self.history_idx -= 1
                self.current_path = self.history[self.history_idx]
                self._load_current_page()
                return self._to_structured(self.current_page)
            return {"status": "at_start", "message": "Already at first page in history"}

    async def get_page(self) -> Dict[str, Any]:
        """Return current page snapshot under lock."""
        async with self._lock:
            return self._to_structured(self.current_page)


# Global session (initialized on MCP startup)
_session: Optional[AgentSession] = None


@mcp.tool()
async def navigate(path: str) -> Dict[str, Any]:
    """Navigate to a specific route. Returns page structure & content."""
    global _session
    return await _session.navigate_to(path)


@mcp.tool()
async def back() -> Dict[str, Any]:
    """Navigate back to the previous page in history."""
    global _session
    return await _session.go_back()


@mcp.tool()
async def get_current_page() -> Dict[str, Any]:
    """Return the current page's structure, content, and interactive elements."""
    global _session
    return await _session.get_page()


def _resolve_click_target(session: AgentSession, element_id: str) -> Optional[str]:
    """Resolve a target path for clicking an element without mutating session state."""
    page = session.current_page
    # Check widgets
    for w in page.widgets:
        if w.id == element_id and w.action:
            target = w.action.get("target")
            if target:
                return target
    # Check nav links
    for n in page.nav:
        if n.id == element_id:
            return n.target
    return None


@mcp.tool()
async def click_element(element_id: str) -> Dict[str, Any]:
    """Click a button or nav element by ID. Triggers navigation or action."""
    global _session
    # Resolve target under lock to avoid race with concurrent navigate_to
    async with _session._lock:
        target = _resolve_click_target(_session, element_id)
    if target:
        return await _session.navigate_to(target)
    return {"error": f"Interactive element '{element_id}' not found"}+++++++ REPLACE


@mcp.tool()
async def fill_and_submit(widget_id: str, value: str) -> Dict[str, Any]:
    """Fill an input field and submit it. Triggers server-side handler if registered."""
    global _session
    handler = _session.server.input_handlers.get(widget_id)
    if handler:
        res = handler(widget_id, value)
        if asyncio.iscoroutine(res):
            await res
        return {"status": "submitted", "widget_id": widget_id, "value": value}
    return {"status": "filled", "widget_id": widget_id, "value": value,
            "note": "No server handler registered"}


@mcp.tool()
async def get_nav_tree() -> Dict[str, Any]:
    """Return all registered routes and their titles for route discovery."""
    global _session
    return {
        "routes": [
            {"path": path, "title": page.title}
            for path, page in _session.routes.items()
        ]
    }


def init_mcp_server(server: TermStreamServer) -> FastMCP:
    """Initialize MCP server with shared route registry"""
    global _session
    _session = AgentSession(server)
    return mcp