from termstream_py import TermStreamServer, Page, Widget, WidgetType, NavItem

app = TermStreamServer(host="localhost", port=8765)

@app.route("/home")
def home():
    return Page(
        title="Home",
        nav=[NavItem("home","home","/home"), NavItem("docs","docs","/docs")],
        widgets=[
            Widget("h1", WidgetType.HEADING, (0,0), "Welcome", bold=True),
            Widget("p1", WidgetType.TEXT, (2,0), "Streaming terminal UI."),
            Widget("btn", WidgetType.BUTTON, (4,0), "→ Docs", action={"type":"navigate","target":"/docs"}),
        ]
    )

@app.route("/docs")
def docs():
    return Page(
        title="Docs",
        nav=[NavItem("home","home","/home"), NavItem("docs","docs","/docs")],
        widgets=[
            Widget("h1", WidgetType.HEADING, (0,0), "Documentation", bold=True),
            Widget("inp", WidgetType.INPUT, (2,0), "Search..."),
            Widget("btn", WidgetType.BUTTON, (4,0), "← Home", action={"type":"navigate","target":"/home"}),
        ]
    )

@app.on_input("inp")
async def on_search(wid, val):
    print(f"{val}")