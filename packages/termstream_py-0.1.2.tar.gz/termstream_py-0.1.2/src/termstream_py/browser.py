import curses
import asyncio
import json
import time
import threading
import queue
import websockets

# ---------------------------------------------------------------------------
# Key constants
# ---------------------------------------------------------------------------
# Raw ASCII control characters (platform-independent, no curses dependency)
ESC_KEY = 27           # Escape
CTRL_Q_KEY = 17        # Ctrl+Q  (ASCII 0x11)

# Backspace key codes that terminals may send
_backspace_raw = {
    getattr(curses, 'KEY_BACKSPACE', None),
    127,  # DEL
    8,    # BS
}
_backspace_raw.discard(None)
BACKSPACE_KEYS = frozenset(_backspace_raw)
del _backspace_raw


class TermStreamBrowser:
    def __init__(self, url: str = "ws://localhost:8765"):
        self.url = url
        self.nav = []
        self.content = []
        self.current_path = "/"
        self._title = "/"
        self.load_time = 0.0
        self._load_start = 0.0
        self.stdscr = None
        self.frame_queue = queue.Queue()
        self.cmd_queue = queue.Queue()
        self.running = True
        self.content_scroll = 0
        self.input_values = {}
        self.history = ["/"]
        self.history_idx = 0
        # Separate focus for nav and content panes
        self.pane = "nav"  # "nav" or "content"
        self.nav_focus = 0
        self.content_focus = 0
        # Search mode
        self.searching = False
        self.search_query = ""
        self.search_error = ""

    def start(self):
        threading.Thread(target=self._ws_loop, daemon=True).start()
        try:
            curses.wrapper(self._curses_loop)
        finally:
            self.running = False

    def _ws_loop(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self._async_ws_loop())

    async def _async_ws_loop(self):
        try:
            async with websockets.connect(self.url) as ws:
                while self.running:
                    # FIX #11: Use get_nowait in a loop instead of empty()/get()
                    # to avoid TOCTOU race on the queue.
                    while True:
                        try:
                            cmd = self.cmd_queue.get_nowait()
                            await ws.send(json.dumps(cmd))
                        except queue.Empty:
                            break
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=0.1)
                        self.frame_queue.put(json.loads(msg))
                    except asyncio.TimeoutError:
                        pass
                    except websockets.exceptions.ConnectionClosed:
                        break
        except Exception:
            pass
        finally:
            self.running = False

    def _curses_loop(self, stdscr):
        self.stdscr = stdscr
        stdscr.nodelay(True)
        stdscr.keypad(True)
        curses.noecho()
        curses.curs_set(0)
        curses.start_color()
        curses.init_pair(1, curses.COLOR_CYAN, curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_WHITE, curses.COLOR_BLUE)

        while self.running:
            while not self.frame_queue.empty():
                self._handle_frame(self.frame_queue.get())
            self._handle_key(stdscr.getch())
            self._render()
            stdscr.refresh()

    def _handle_frame(self, msg):
        op = msg.get("op")
        if op == "init":
            self._title = msg.get("title", self.current_path)
            self.nav = msg.get("nav", [])
            self.content = []
            self.pane = "nav"
            self.nav_focus = 0
            self.content_focus = 0
            self.content_scroll = 0
            self.input_values.clear()
            self.searching = False
            self.search_query = ""
            self.search_error = ""
            self._load_start = time.perf_counter()
        elif op == "widget":
            self.content.append(msg)
        elif op == "end":
            self.load_time = time.perf_counter() - self._load_start
        elif op == "update":
            for w in self.content:
                if w.get("id") == msg.get("id"):
                    if "text" in msg:
                        w["text"] = msg["text"]
                    if "style" in msg:
                        w["style"] = msg["style"]

    def _navigate(self, path: str):
        if path == self.current_path:
            return
        if self.history_idx < len(self.history) - 1:
            self.history = self.history[:self.history_idx + 1]
        self.history.append(path)
        self.history_idx += 1
        self.current_path = path
        self.cmd_queue.put({"type": "navigate", "target": path})

    def _navigate_back(self):
        """Navigate back in history. Returns True if there is a previous page."""
        if self.history_idx > 0:
            self.history_idx -= 1
            self.current_path = self.history[self.history_idx]
            self.cmd_queue.put({"type": "navigate", "target": self.current_path})
            return True
        return False

    def _is_backspace(self, key) -> bool:
        """Check if a key is a backspace variant."""
        return key in BACKSPACE_KEYS

    def _handle_key(self, key):
        focused_w = self._get_focused_widget()
        in_input = focused_w and focused_w.get("type") == "input"

        # Quit on 'q' key
        if key == ord('q'):
            self.running = False
            return

        # ESC: cancel search, or navigate back in history
        if key == ESC_KEY:
            if self.searching:
                self.searching = False
                self.search_query = ""
                self.search_error = ""
                return
            # Navigate back if there is history
            if self._navigate_back():
                return
            return

        # FIX #8: Backspace: use proper set-based check
        if self._is_backspace(key):
            if self.searching:
                self.search_query = self.search_query[:-1]
                self.search_error = ""
                if self.search_query:
                    if self.pane == "nav":
                        self._find_nav_match()
                    else:
                        self._find_content_match()
                return
            # Navigate back if there is history
            if self._navigate_back():
                return
            return

        # Pane switching: RIGHT moves nav->content, LEFT moves content->nav
        if key == curses.KEY_RIGHT and self.pane == "nav":
            self.pane = "content"
            return
        if key == curses.KEY_LEFT and self.pane == "content":
            self.pane = "nav"
            return

        if self.pane == "nav":
            self._handle_nav_key(key)
        else:
            self._handle_content_key(key)

    def _handle_nav_key(self, key):
        """Handle keys while nav pane is focused."""
        # Search mode
        if self.searching:
            self._handle_search_key(key)
            return

        # '/' enters search mode
        if key == ord('/'):
            self.searching = True
            self.search_query = ""
            self.search_error = ""
            return

        # 1-9 jumps to nav items
        if 49 <= self._safe_key(key) <= 57:
            idx = self._safe_key(key) - 49
            if idx < len(self.nav):
                self.nav_focus = idx
            return
        # Up/down within nav
        if self.nav:
            if self._key_name(key) == curses.KEY_DOWN:
                self.nav_focus = (self.nav_focus + 1) % len(self.nav)
            elif self._key_name(key) == curses.KEY_UP:
                self.nav_focus = (self.nav_focus - 1) % len(self.nav)
        # Enter activates nav item (ignore end-of-node with empty target)
        if key in (curses.KEY_ENTER, 10, 13):
            if self.nav_focus < len(self.nav):
                target = self.nav[self.nav_focus]["target"]
                if target:
                    self._navigate(target)

    def _handle_search_key(self, key):
        """Handle keys while in search mode."""
        # Enter confirms search: nav pane navigates, content pane just exits
        if key in (curses.KEY_ENTER, 10, 13):
            if not self.search_error:
                self.searching = False
                self.search_query = ""
                if self.pane == "nav" and self.nav_focus < len(self.nav):
                    self._navigate(self.nav[self.nav_focus]["target"])
            else:
                self.search_error = ""
            return

        # FIX #8: Backspace deletes a character (use proper check)
        if self._is_backspace(key):
            self.search_query = self.search_query[:-1]
            self.search_error = ""
            if self.search_query:
                if self.pane == "nav":
                    self._find_nav_match()
                else:
                    self._find_content_match()
            return

        # Type a character into the search query
        if 32 <= self._safe_key(key) <= 126:
            self.search_query += chr(self._safe_key(key))
            self.search_error = ""
            if self.pane == "nav":
                exact = self._find_nav_match()
                # If exact match found, navigate immediately
                if exact:
                    self.searching = False
                    if self.nav_focus < len(self.nav):
                        self._navigate(self.nav[self.nav_focus]["target"])
                    return
            else:
                self._find_content_match()
            return

        # Tab: autocomplete search query from nav labels
        if key == 9:  # TAB
            if self.pane == "nav":
                completed = self._tab_complete_nav()
                if completed:
                    self.search_query = completed
                    self.search_error = ""
                    # Check if completion resulted in an exact match -> auto-navigate
                    exact = self._find_nav_match()
                    if exact:
                        self.searching = False
                        if self.nav_focus < len(self.nav):
                            self._navigate(self.nav[self.nav_focus]["target"])
                        return
            return

    def _find_nav_match(self):
        """Find nav item matching search query (nav pane search).

        Searches from the current cursor position downward, then cycles back to the top.
        Uses exact match (case-insensitive) on the nav item label.
        Returns True when an exact match is found, False otherwise.
        """
        if not self.nav or not self.search_query:
            return False
        query = self.search_query.lower()
        n = len(self.nav)
        for offset in range(n):
            idx = (self.nav_focus + offset) % n
            if self.nav[idx].get("label", "").lower() == query:
                self.nav_focus = idx
                return True
        self.search_error = f"Not found: '{self.search_query}'"
        self.nav_focus = -1
        return False

    def _tab_complete_nav(self):
        """Tab-complete the search query from nav item labels.

        Finds all nav items whose label starts with the current query (case-insensitive),
        then completes to the longest common prefix. Returns the completed label if
        there's a single exact match, or the common prefix otherwise.
        """
        if not self.nav or not self.search_query:
            return None
        query = self.search_query.lower()
        matches = [n for n in self.nav if n.get("label", "").lower().startswith(query)]
        if not matches:
            return None
        # Single match -> return the full label (triggers auto-navigate)
        if len(matches) == 1:
            return matches[0]["label"]
        # Multiple matches -> complete to longest common prefix
        first = matches[0]["label"]
        common = []
        for i, c in enumerate(first):
            if all(m.get("label", "")[i] == c for m in matches if i < len(m.get("label", ""))):
                common.append(c)
            else:
                break
        result = "".join(common)
        if result and result != self.search_query:
            return result
        return None

    def _find_content_match(self):
        """Find content widget matching search query (content pane search)."""
        if not self.content or not self.search_query:
            return
        query = self.search_query.lower()
        n = len(self.content)
        for offset in range(n):
            idx = (self.content_focus + 1 + offset) % n
            if query in self.content[idx].get("text", "").lower():
                self.content_focus = idx
                return
        self.search_error = f"Not found: '{self.search_query}'"
        self.content_focus = -1

    def _handle_content_key(self, key):
        """Handle keys while content pane is focused."""
        # Search mode
        if self.searching:
            self._handle_search_key(key)
            return

        focused_w = self._get_focused_widget()
        in_input = focused_w and focused_w.get("type") == "input"

        # FIX: PgDn/PgUp fallback keys (space, 'b') must NOT conflict with input typing.
        # Only apply scroll shortcuts when NOT focused on an input widget.
        if not in_input:
            pgdn = getattr(curses, 'KEY_PAGEDOWN', None) or getattr(curses, 'KEY_NPAGE', None)
            pgup = getattr(curses, 'KEY_PAGEUP', None) or getattr(curses, 'KEY_PPAGE', None)

            # Scrolling via dedicated page keys
            if pgdn is not None and key == pgdn:
                self.content_scroll = min(self.content_scroll + 3, self._max_scroll())
                return
            if pgup is not None and key == pgup:
                self.content_scroll = max(self.content_scroll - 3, 0)
                return

            # Fallback: space and 'b' only when curses page keys unavailable
            if pgdn is None and key == ord(' '):
                self.content_scroll = min(self.content_scroll + 3, self._max_scroll())
                return
            if pgup is None and key == ord('b'):
                self.content_scroll = max(self.content_scroll - 3, 0)
                return

        # Up/down within content
        if self.content:
            if self._key_name(key) == curses.KEY_DOWN:
                self.content_focus = (self.content_focus + 1) % len(self.content)
                return
            if self._key_name(key) == curses.KEY_UP:
                self.content_focus = (self.content_focus - 1) % len(self.content)
                return

        # Enter activates content widget
        if key in (curses.KEY_ENTER, 10, 13):
            self._activate_focused()
            return

        # Typing into input widget
        if in_input and 32 <= self._safe_key(key) <= 126:
            wid = focused_w["id"]
            self.input_values[wid] = self.input_values.get(wid, "") + chr(self._safe_key(key))

    def _safe_key(self, key):
        """Return the key as an integer for comparison.

        FIX: Handle non-standard input types gracefully to avoid crashes.
        """
        if isinstance(key, int):
            return key
        if isinstance(key, str) and len(key) == 1:
            return ord(key)
        # Fallback: return 0 for unrecognized types (treated as no-op)
        return 0

    def _key_name(self, key):
        """Return the curses key name constant."""
        return key

    def _activate_focused(self):
        w = self._get_focused_widget()
        if w:
            if w.get("type") == "input":
                self.cmd_queue.put({"type": "input", "id": w["id"], "value": self.input_values.get(w["id"], "")})
                self.input_values[w["id"]] = ""
            elif w.get("action"):
                self._navigate(w["action"]["target"])

    def _max_scroll(self):
        total = sum(len(w.get("text", "").split('\n')) for w in self.content)
        start = len(self.nav) + 2
        footer = max(self.stdscr.getmaxyx()[0] - 2, start + 2) if self.stdscr else 22
        return max(0, total - (footer - start - 1))

    def _get_focused_widget(self):
        if 0 <= self.content_focus < len(self.content):
            return self.content[self.content_focus]
        return None

    def _render(self):
        if not self.stdscr:
            return
        self.stdscr.clear()
        rows, cols = self.stdscr.getmaxyx()
        start = len(self.nav) + 2
        footer = max(rows - 2, start + 2)

        # Render page title at row 0 (nav items start at row 1)
        title_text = self._title
        try:
            self.stdscr.addstr(0, 1, title_text[:cols-1], curses.color_pair(1) | curses.A_BOLD)
        except Exception:
            pass

        y = 1
        for i, n in enumerate(self.nav):
            # Skip nav items with empty labels (e.g. end-of-node placeholders)
            if not n.get("label"):
                continue
            nav_focused = (self.pane == "nav" and i == self.nav_focus)
            pref = "* " if nav_focused else "  "
            attr = curses.color_pair(1) | curses.A_BOLD if nav_focused else curses.A_NORMAL
            try:
                self.stdscr.addstr(y, 1, f"{pref}{n['label']:<15}", attr)
            except Exception:
                pass
            y += 1
        # Use actual rendered nav height for separator position
        nav_height = y - 1
        try:
            self.stdscr.addstr(start - 1, 0, "-" * cols)
        except Exception:
            pass

        cur_y = start
        for idx, w in enumerate(self.content):
            is_foc = (self.pane == "content" and idx == self.content_focus)
            is_inp = w.get("type") == "input"
            for line in w.get("text", "").split('\n'):
                dy = cur_y - self.content_scroll
                if dy < start:
                    cur_y += 1
                    continue
                # FIX #7: use `break` instead of `return` so footer/status
                # bar and cursor visibility are still updated.
                if dy >= footer:
                    break
                attr = curses.A_BOLD if (w.get("style") or {}).get("bold", False) else curses.A_NORMAL
                if is_foc:
                    attr |= curses.color_pair(2) if is_inp else curses.color_pair(1)
                disp = self.input_values.get(w["id"], line) if is_inp else line
                try:
                    self.stdscr.addstr(dy, 1, disp[:cols-1], attr)
                except Exception:
                    pass
                cur_y += 1

        try:
            self.stdscr.addstr(footer, 0, "-" * cols)
        except Exception:
            pass

        # Build status line
        if self.searching:
            status = f"/{self.search_query}"
            if self.search_error:
                status += f" | ERROR: {self.search_error}"
        else:
            pane_label = "NAV" if self.pane == "nav" else "CONTENT"
            status = f"load: {self.load_time:.3f}s | path: {self.current_path} | [{pane_label}] LEFT/RIGHT Switch Pane | UP/DOWN Focus | / Search | Space/b Scroll | 1-9 Nav | ESC/BACKSPACE Back | q Quit"

        try:
            self.stdscr.addstr(footer+1, 1, status)
        except Exception:
            pass
        foc = self._get_focused_widget()
        curses.curs_set(1 if (foc and foc.get("type") == "input") else 0)