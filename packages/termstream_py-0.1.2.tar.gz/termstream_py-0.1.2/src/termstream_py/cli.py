import argparse
import os
import sys
import importlib.util
import asyncio
from .server import TermStreamServer
from .browser import TermStreamBrowser
from .mcp import init_mcp_server
from .yaml_config import load_from_yaml, load_from_directory


# Environment variable to disable --app loading entirely.
# Set TERMSTREAM_DISABLE_APP=1 (or any truthy value) to block dynamic app loading.
_DISABLE_APP_ENV = "TERMSTREAM_DISABLE_APP"


def _app_disabled() -> bool:
    """Return True if the --app feature is disabled via environment variable."""
    return os.environ.get(_DISABLE_APP_ENV, "").lower() in ("1", "true", "yes", "on")


def load_app(app_path: str) -> TermStreamServer:
    """Load user app module from file path.

    WARNING: This function dynamically executes an arbitrary Python file.
    Only use with files you trust. The --app feature can be disabled by
    setting the TERMSTREAM_DISABLE_APP environment variable.
    """
    if _app_disabled():
        print(
            f"ERROR: The --app option is disabled by the {_DISABLE_APP_ENV} "
            f"environment variable.\n"
            f"  Dynamic code execution is blocked for security reasons.\n"
            f"  Use --config (YAML) or --directory instead.\n"
            f"  To re-enable, unset {_DISABLE_APP_ENV} or set it to 0/false.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Resolve to absolute path and validate it exists
    resolved = os.path.abspath(app_path)
    if not os.path.isfile(resolved):
        print(f"ERROR: App file not found: {resolved}", file=sys.stderr)
        sys.exit(1)

    # Confirmation prompt with warning
    print()
    print("=" * 60)
    print("  WARNING: Dynamic App Loading")
    print("=" * 60)
    print()
    print(
        "  You are about to dynamically load and execute a Python file.\n"
        "  The file will be executed with full privileges of this process.\n"
        "  ONLY load files you trust and understand.\n"
        f"  File: {resolved}"
    )
    print()
    print("  This behavior can be disabled by setting:")
    print(f"    {_DISABLE_APP_ENV}=1")
    print()

    try:
        answer = input("  Continue? [y/N]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()  # newline after interrupt
        sys.exit(1)

    if answer not in ("y", "yes"):
        print("\nAborted.")
        sys.exit(0)

    print()  # blank line after confirmation

    spec = importlib.util.spec_from_file_location("user_app", resolved)
    if spec is None or spec.loader is None:
        print(f"ERROR: Unable to load module from: {resolved}", file=sys.stderr)
        sys.exit(1)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.app  # Expects `app = TermStreamServer(...)`


def main():
    parser = argparse.ArgumentParser(
        prog="termstream",
        description="Streaming terminal UI framework",
    )
    sub = parser.add_subparsers(dest="command", help="Available commands")

    # Server command
    srv = sub.add_parser("server", help="Run WebSocket terminal server")
    srv.add_argument("-u", "--url", default="ws://localhost:8765",
                     help="Server WebSocket URL")
    srv.add_argument("-a", "--app",
                     help="Path to app module (e.g., myapp.py). "
                          "WARNING: executes arbitrary Python code.")
    srv.add_argument("-c", "--config",
                     help="Path to YAML configuration file")
    srv.add_argument("-d", "--directory",
                     help="Path to directory tree for building routes "
                          "from content.md files")
    srv.add_argument("--allowed-origins", nargs="*", default=None,
                     help="List of allowed WebSocket origins for CORS-like "
                          "protection. If omitted, all origins are accepted.")
    # SSL / HTTPS flags
    srv.add_argument("--ssl", action="store_true", default=False,
                     help="Enable HTTPS/WSS (auto-generates self-signed cert)")
    srv.add_argument("--ssl-cert", default=None,
                     help="Path to SSL certificate file (.pem)")
    srv.add_argument("--ssl-key", default=None,
                     help="Path to SSL private key file (.pem)")

    # Browser command
    brw = sub.add_parser("browser", help="Run terminal browser client")
    brw.add_argument("-u", "--url", default="ws://localhost:8765",
                     help="Server WebSocket URL")

    # MCP command
    mcp_p = sub.add_parser("mcp", help="Run MCP server for AI agents")
    mcp_p.add_argument("-a", "--app", help="Path to app module")
    mcp_p.add_argument("-c", "--config", help="Path to YAML configuration file")
    mcp_p.add_argument("-p", "--port", type=int, default=3000,
                       help="MCP HTTP port")
    mcp_p.add_argument("--transport", choices=["stdio", "http"], default="stdio",
                       help="MCP transport")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "server":
        # Determine SSL settings
        use_ssl = args.ssl or args.ssl_cert or args.ssl_key
        ssl_cert = args.ssl_cert
        ssl_key = args.ssl_key

        if args.directory:
            app = load_from_directory(args.directory)
        elif args.config:
            app = load_from_yaml(args.config)
        elif args.app:
            app = load_app(args.app)
        else:
            parser.print_help()
            sys.exit(1)

        # Apply SSL settings
        if use_ssl:
            app.ssl_certfile = ssl_cert
            app.ssl_keyfile = ssl_key

        # Apply origin restrictions if provided
        if args.allowed_origins is not None:
            app.allowed_origins = args.allowed_origins

        asyncio.run(app.start())

    elif args.command == "browser":
        TermStreamBrowser(url=args.url).start()

    elif args.command == "mcp":
        if args.config:
            app = load_from_yaml(args.config)
        elif args.app:
            app = load_app(args.app)
        else:
            parser.print_help()
            sys.exit(1)
        mcp_server = init_mcp_server(app)
        print(f"MCP Agent server starting on {args.transport}...")
        if args.transport == "stdio":
            mcp_server.run(transport="stdio")
        else:
            mcp_server.run(transport="http", host="0.0.0.0", port=args.port)