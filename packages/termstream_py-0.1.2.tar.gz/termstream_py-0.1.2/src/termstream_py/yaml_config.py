"""YAML-based configuration loader for TermStream servers.

Allows defining pages, navigation, and widgets in a YAML file instead of code.
Also supports building pages from a directory tree where each directory contains
a content.md file defining its content, and subdirectories become navigation nodes.

Example YAML:
    host: localhost
    port: 8765
    ssl: true                       # enable HTTPS/WSS
    ssl_cert: /path/to/cert.pem     # optional custom cert
    ssl_key: /path/to/key.pem       # optional custom key
    pages:
      - path: /home
        title: Home
        widgets:
          - type: heading
            pos: [0, 0]
            text: Welcome
            style:
              bold: true
          - type: button
            pos: [4, 0]
            text: "-> Docs"
            action:
              type: navigate
              target: /docs
"""

import yaml
import uuid
import os
import re
import warnings
from pathlib import Path
from typing import Dict, Any, Optional, List
from .server import TermStreamServer
from .components import Page, Widget, WidgetType, NavItem


def _parse_widget_type(type_str: str) -> WidgetType:
    """Convert a string widget type to WidgetType enum."""
    mapping = {
        "text": WidgetType.TEXT,
        "heading": WidgetType.HEADING,
        "button": WidgetType.BUTTON,
        "input": WidgetType.INPUT,
    }
    wt = mapping.get(type_str.lower())
    if wt is None:
        raise ValueError(f"Unknown widget type: {type_str!r}. Must be one of {list(mapping.keys())}")
    return wt


def _parse_widget(data: Dict[str, Any]) -> Widget:
    """Parse a widget dict from YAML into a Widget instance."""
    if not isinstance(data, dict):
        raise ValueError(f"Expected dict for widget, got {type(data).__name__}")

    type_str = data.get("type")
    if type_str is None:
        raise ValueError("Widget missing required 'type' field")

    pos = data.get("pos", [0, 0])
    if isinstance(pos, (list, tuple)):
        pos = (int(pos[0]), int(pos[1]))

    style = data.get("style", {})
    bold = style.get("bold", False) if isinstance(style, dict) else False

    # Auto-generate id if not provided
    widget_id = data.get("id") or f"w_{uuid.uuid4().hex[:8]}"

    return Widget(
        id=widget_id,
        type=_parse_widget_type(type_str),
        pos=pos,
        text=data.get("text", ""),
        bold=bold,
        action=data.get("action"),
    )


def _parse_page(data: Dict[str, Any]) -> Page:
    """Parse a page dict from YAML into a Page instance."""
    if not isinstance(data, dict):
        raise ValueError(f"Expected dict for page, got {type(data).__name__}")

    title = data.get("title")
    if title is None:
        raise ValueError("Page missing required 'title' field")

    nav_items = []
    for n in data.get("nav", []):
        nav_items.append(NavItem(
            n.get("id", ""),
            n.get("label", ""),
            n.get("target", "")
        ))

    widgets = []
    for w in data.get("widgets", []):
        widgets.append(_parse_widget(w))

    return Page(title=title, nav=nav_items, widgets=widgets)


def load_from_yaml(path: str) -> TermStreamServer:
    """Load a TermStreamServer configuration from a YAML file.

    Args:
        path: Path to the YAML configuration file.

    Returns:
        A fully configured TermStreamServer instance.

    YAML SSL options:
        ssl: true/false            # enable HTTPS
        ssl_cert: /path/to/cert    # optional custom cert
        ssl_key: /path/to/key      # optional custom key
    """
    with open(path, "r") as f:
        config = yaml.safe_load(f)

    host = config.get("host", "localhost")
    port = config.get("port", 8765)

    # SSL settings
    ssl_enabled = config.get("ssl", False)
    ssl_cert = config.get("ssl_cert") if ssl_enabled else None
    ssl_key = config.get("ssl_key") if ssl_enabled else None

    server = TermStreamServer(host=host, port=port,
                              ssl_certfile=ssl_cert, ssl_keyfile=ssl_key)

    for page_data in config.get("pages", []):
        page = _parse_page(page_data)
        server.routes[page_data["path"]] = page

    return server


def _parse_content_md(file_path: str) -> List[Widget]:
    """Parse a content.md file into a list of Widgets.

    Format:
    - First line starting with # is the title (HEADING, bold)
    - Subsequent non-empty lines are TEXT widgets
    - Lines starting with > are treated as BUTTON widgets with navigate action
    - Lines starting with $ are treated as INPUT widgets
    """
    widgets = []
    row = 0
    title_found = False

    with open(file_path, "r") as f:
        for line in f:
            # FIX: proper line ending handling for all platforms
            line = line.rstrip("\r\n")
            stripped = line.strip()

            # Skip empty lines
            if not stripped:
                row += 1
                continue

            # First heading becomes title heading widget
            if not title_found and stripped.startswith("#"):
                title_text = stripped.lstrip("#").strip()
                widgets.append(Widget(
                    id=f"title_{uuid.uuid4().hex[:6]}",
                    type=WidgetType.HEADING,
                    pos=(row, 0),
                    text=title_text,
                    bold=True,
                ))
                title_found = True
                row += 1
                continue

            # Button: line starting with >
            if stripped.startswith(">"):
                btn_text = stripped[1:].strip()
                # Check for navigation target in format "-> /path"
                action = None
                if " -> " in btn_text:
                    parts = btn_text.split(" -> ", 1)
                    btn_text = parts[0].strip()
                    target = parts[1].strip()
                    action = {"type": "navigate", "target": target}
                widgets.append(Widget(
                    id=f"btn_{uuid.uuid4().hex[:6]}",
                    type=WidgetType.BUTTON,
                    pos=(row, 0),
                    text=btn_text,
                    action=action,
                ))
                row += 1
                continue

            # Input: line starting with $
            if stripped.startswith("$"):
                placeholder = stripped[1:].strip()
                widgets.append(Widget(
                    id=f"inp_{uuid.uuid4().hex[:6]}",
                    type=WidgetType.INPUT,
                    pos=(row, 0),
                    text=placeholder,
                ))
                row += 1
                continue

            # Regular text
            widgets.append(Widget(
                id=f"txt_{uuid.uuid4().hex[:6]}",
                type=WidgetType.TEXT,
                pos=(row, 0),
                text=stripped,
            ))
            row += 1

    return widgets


def _slugify(name: str) -> str:
    """Convert a directory name to a URL-friendly slug."""
    # Lowercase, replace spaces/special chars with hyphens, remove duplicates
    slug = name.lower().strip()
    slug = re.sub(r'[^a-z0-9]+', '-', slug)
    slug = slug.strip('-')
    return slug or name.lower()


def _extract_title(content: List[Widget]) -> str:
    """Extract the title from a list of widgets (first HEADING widget text)."""
    for w in content:
        if w.type == WidgetType.HEADING:
            return w.text
    return "Untitled"


def load_from_directory(directory: str, host: str = "localhost", port: int = 8765) -> TermStreamServer:
    """Load a TermStreamServer by building routes from a directory tree.

    Each directory is expected to contain a content.md file defining its page
    content. Subdirectories become child navigation nodes.

    Args:
        directory: Path to the root directory.
        host: Server host (default: localhost).
        port: Server port (default: 8765).

    Returns:
        A fully configured TermStreamServer instance.
    """
    server = TermStreamServer(host=host, port=port)
    root_path = Path(directory).resolve()

    def _build_routes(dir_path: Path, current_route: str) -> None:
        """Recursively build routes from directory structure."""
        content_file = dir_path / "content.md"

        if content_file.exists():
            widgets = _parse_content_md(str(content_file))
            title = _extract_title(widgets)
            server.routes[current_route] = Page(title=title, widgets=widgets)
        else:
            # Default blank page with warning
            warnings.warn(
                f"Directory '{dir_path}' does not contain a content.md file. "
                f"Creating blank page at route '{current_route}'."
            )
            server.routes[current_route] = Page(
                title=dir_path.name.capitalize(),
                widgets=[Widget(
                    id=f"blank_{uuid.uuid4().hex[:6]}",
                    type=WidgetType.TEXT,
                    pos=(0, 0),
                    text=f"(blank page — {dir_path.name})",
                )],
            )

        # Recurse into subdirectories
        for entry in sorted(dir_path.iterdir()):
            if entry.is_dir() and not entry.name.startswith(('.', '_')):
                child_route = f"{current_route}/{_slugify(entry.name)}" if current_route != "/" else f"/{_slugify(entry.name)}"
                _build_routes(entry, child_route)

    _build_routes(root_path, "/")
    return server