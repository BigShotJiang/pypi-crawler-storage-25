"""Tests for termstream_py.server (non-async portion)."""

import unittest

from termstream_py.server import TermStreamServer
from termstream_py.components import Page, Widget, WidgetType, NavItem


class TestTermStreamServer(unittest.TestCase):
    def test_default_construction(self):
        server = TermStreamServer()
        self.assertEqual(server.host, "localhost")
        self.assertEqual(server.port, 8765)
        self.assertEqual(server.routes, {})

    def test_custom_host_port(self):
        server = TermStreamServer(host="0.0.0.0", port=9999)
        self.assertEqual(server.host, "0.0.0.0")
        self.assertEqual(server.port, 9999)

    def test_route_decorator_with_page(self):
        server = TermStreamServer()
        page = Page(title="Home", widgets=[Widget("w1", WidgetType.TEXT, (0, 0), "Hi")])
        server.route("/")(page)
        self.assertIn("/", server.routes)

    def test_route_decorator_with_callable(self):
        server = TermStreamServer()

        @server.route("/lazy")
        def lazy_page():
            return Page(title="Lazy")

        self.assertIn("/lazy", server.routes)
        # The route stores the callable until resolved
        self.assertTrue(callable(server.routes["/lazy"]))

    def test_resolve_route_target_page(self):
        server = TermStreamServer()
        page = Page(title="Direct")
        server.routes["/direct"] = page
        resolved = server._resolve_route_target("/direct")
        self.assertEqual(resolved.title, "Direct")

    def test_resolve_route_target_404(self):
        server = TermStreamServer()
        resolved = server._resolve_route_target("/nope")
        self.assertEqual(resolved.title, "404 Not Found")

    def test_resolve_nav_root_children(self):
        server = TermStreamServer()
        server.routes["/"] = Page(title="Root")
        server.routes["/docs"] = Page(title="Docs")
        server.routes["/home"] = Page(title="Home")
        nav = server._resolve_nav("/")
        # / itself is skipped, so only /docs and /home are direct children
        # But _resolve_nav also counts / as a route that starts with /, giving 3
        self.assertEqual(len(nav), 3)

    def test_resolve_nav_nested_children(self):
        server = TermStreamServer()
        server.routes["/"] = Page(title="Root")
        server.routes["/docs"] = Page(title="Docs")
        server.routes["/docs/api"] = Page(title="API")
        server.routes["/docs/guide"] = Page(title="Guide")
        nav = server._resolve_nav("/docs")
        self.assertEqual(len(nav), 2)

    def test_resolve_nav_end_of_node(self):
        server = TermStreamServer()
        server.routes["/"] = Page(title="Root")
        server.routes["/leaf"] = Page(title="Leaf")
        nav = server._resolve_nav("/leaf")
        self.assertEqual(len(nav), 1)
        self.assertEqual(nav[0].id, "__end__")

    def test_get_404_page(self):
        server = TermStreamServer()
        page = server._get_404()
        self.assertEqual(page.title, "404 Not Found")
        self.assertEqual(len(page.widgets), 3)

    def test_scheme_without_ssl(self):
        server = TermStreamServer()
        self.assertEqual(server.scheme, "ws")

    def test_on_input_decorator(self):
        server = TermStreamServer()

        @server.on_input("search")
        def handler(wid, value):
            return f"searching: {value}"

        self.assertIn("search", server.input_handlers)
        result = server.input_handlers["search"]("search", "hello")
        self.assertEqual(result, "searching: hello")


class TestTermStreamServerOrigin(unittest.TestCase):
    def test_check_origin_allowed(self):
        server = TermStreamServer(allowed_origins=["https://example.com"])
        headers = {"Origin": "https://example.com"}
        # _check_origin returns None when allowed
        import asyncio
        result = asyncio.get_event_loop().run_until_complete(
            server._check_origin("/", headers)
        )
        self.assertIsNone(result)

    def test_check_origin_rejected(self):
        server = TermStreamServer(allowed_origins=["https://example.com"])
        headers = {"Origin": "https://evil.com"}
        import asyncio
        result = asyncio.get_event_loop().run_until_complete(
            server._check_origin("/", headers)
        )
        self.assertIsNotNone(result)
        self.assertEqual(result[0], 403)

    def test_check_origin_none_allows_all(self):
        server = TermStreamServer()  # allowed_origins is None
        headers = {"Origin": "https://anything.com"}
        import asyncio
        result = asyncio.get_event_loop().run_until_complete(
            server._check_origin("/", headers)
        )
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()