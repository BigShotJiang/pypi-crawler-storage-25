"""Tests for termstream_py.server.RateLimiter."""

import time
import unittest

from termstream_py.server import RateLimiter


class TestRateLimiter(unittest.TestCase):
    def test_initial_allows_requests(self):
        limiter = RateLimiter(rate=10.0, burst=5)
        key = object()
        # First 5 requests should be allowed (burst = 5)
        for _ in range(5):
            self.assertTrue(limiter.allow(key))

    def test_exceeds_burst_denies(self):
        limiter = RateLimiter(rate=10.0, burst=3)
        key = object()
        for _ in range(3):
            self.assertTrue(limiter.allow(key))
        # 4th request should be denied
        self.assertFalse(limiter.allow(key))

    def test_refill_after_wait(self):
        limiter = RateLimiter(rate=100.0, burst=2)
        key = object()
        # Exhaust burst
        self.assertTrue(limiter.allow(key))
        self.assertTrue(limiter.allow(key))
        self.assertFalse(limiter.allow(key))
        # Wait for refill
        time.sleep(0.05)  # 100 tokens/s * 0.05s = 5 tokens
        self.assertTrue(limiter.allow(key))

    def test_remove_cleans_state(self):
        limiter = RateLimiter(rate=10.0, burst=2)
        key = object()
        limiter.allow(key)
        limiter.remove(key)
        # After removal, key gets a fresh bucket
        self.assertTrue(limiter.allow(key))

    def test_multiple_keys_independent(self):
        limiter = RateLimiter(rate=10.0, burst=2)
        key_a = object()
        key_b = object()
        # Exhaust key_a
        self.assertTrue(limiter.allow(key_a))
        self.assertTrue(limiter.allow(key_a))
        self.assertFalse(limiter.allow(key_a))
        # key_b should still have full bucket
        self.assertTrue(limiter.allow(key_b))
        self.assertTrue(limiter.allow(key_b))

    def test_throttled_key_recovered(self):
        limiter = RateLimiter(rate=100.0, burst=1)
        key = object()
        self.assertTrue(limiter.allow(key))
        self.assertFalse(limiter.allow(key))  # throttled
        time.sleep(0.05)  # enough time to refill
        self.assertTrue(limiter.allow(key))  # recovered


if __name__ == "__main__":
    unittest.main()