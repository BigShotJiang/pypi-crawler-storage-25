"""Tests for termstream_py.components."""

import unittest
from termstream_py.components import Page, Widget, WidgetType, NavItem


class TestWidgetType(unittest.TestCase):
    def test_widget_type_values(self):
        self.assertEqual(WidgetType.TEXT.value, "text")
        self.assertEqual(WidgetType.HEADING.value, "heading")
        self.assertEqual(WidgetType.BUTTON.value, "button")
        self.assertEqual(WidgetType.INPUT.value, "input")

    def test_widget_type_equality(self):
        self.assertEqual(WidgetType.TEXT, WidgetType.TEXT)
        self.assertNotEqual(WidgetType.TEXT, WidgetType.HEADING)


class TestNavItem(unittest.TestCase):
    def test_create_nav_item(self):
        item = NavItem(id="home", label="Home", target="/home")
        self.assertEqual(item.id, "home")
        self.assertEqual(item.label, "Home")
        self.assertEqual(item.target, "/home")

    def test_to_dict(self):
        item = NavItem(id="docs", label="Docs", target="/docs")
        d = item.to_dict()
        self.assertEqual(d, {"id": "docs", "label": "Docs", "target": "/docs"})


class TestWidget(unittest.TestCase):
    def test_create_basic_widget(self):
        w = Widget(id="w1", type=WidgetType.TEXT, pos=(0, 0), text="Hello")
        self.assertEqual(w.id, "w1")
        self.assertEqual(w.type, WidgetType.TEXT)
        self.assertEqual(w.pos, (0, 0))
        self.assertEqual(w.text, "Hello")
        self.assertFalse(w.bold)
        self.assertIsNone(w.action)

    def test_create_bold_widget(self):
        w = Widget(id="w2", type=WidgetType.HEADING, pos=(1, 0), text="Title", bold=True)
        self.assertTrue(w.bold)

    def test_create_button_with_action(self):
        action = {"type": "navigate", "target": "/docs"}
        w = Widget(id="w3", type=WidgetType.BUTTON, pos=(2, 0), text="Go", action=action)
        self.assertEqual(w.action, action)

    def test_to_frame_basic(self):
        w = Widget(id="w1", type=WidgetType.TEXT, pos=(3, 2), text="Hi")
        frame = w.to_frame()
        self.assertEqual(frame["op"], "widget")
        self.assertEqual(frame["id"], "w1")
        self.assertEqual(frame["type"], "text")
        self.assertEqual(frame["pos"], [3, 2])
        self.assertEqual(frame["text"], "Hi")

    def test_to_frame_bold_includes_style(self):
        w = Widget(id="w2", type=WidgetType.HEADING, pos=(0, 0), text="Title", bold=True)
        frame = w.to_frame()
        self.assertEqual(frame["style"], {"bold": True})

    def test_to_frame_not_bold_omits_style(self):
        w = Widget(id="w3", type=WidgetType.TEXT, pos=(0, 0), text="Plain", bold=False)
        frame = w.to_frame()
        self.assertEqual(frame.get("style", {}), {})

    def test_to_frame_with_action(self):
        action = {"type": "navigate", "target": "/home"}
        w = Widget(id="w4", type=WidgetType.BUTTON, pos=(0, 0), text="Btn", action=action)
        frame = w.to_frame()
        self.assertEqual(frame["action"], action)

    def test_to_frame_without_action(self):
        w = Widget(id="w5", type=WidgetType.TEXT, pos=(0, 0), text="No action")
        frame = w.to_frame()
        self.assertNotIn("action", frame)

    def test_to_dict(self):
        w = Widget(id="w6", type=WidgetType.INPUT, pos=(5, 0), text="Enter name")
        d = w._to_dict()
        self.assertEqual(d["id"], "w6")
        self.assertEqual(d["type"], "input")
        self.assertEqual(d["pos"], [5, 0])
        self.assertEqual(d["text"], "Enter name")

    def test_to_dict_with_bold(self):
        w = Widget(id="w7", type=WidgetType.TEXT, pos=(0, 0), text="Bold", bold=True)
        d = w._to_dict()
        self.assertEqual(d["style"], {"bold": True})

    def test_to_dict_without_bold(self):
        w = Widget(id="w8", type=WidgetType.TEXT, pos=(0, 0), text="Normal", bold=False)
        d = w._to_dict()
        self.assertNotIn("style", d)


class TestPage(unittest.TestCase):
    def test_create_empty_page(self):
        page = Page(title="Empty")
        self.assertEqual(page.title, "Empty")
        self.assertEqual(page.nav, [])
        self.assertEqual(page.widgets, [])

    def test_create_page_with_nav_and_widgets(self):
        nav = [NavItem("home", "Home", "/")]
        widgets = [Widget("w1", WidgetType.TEXT, (0, 0), "Hello")]
        page = Page(title="Main", nav=nav, widgets=widgets)
        self.assertEqual(page.title, "Main")
        self.assertEqual(len(page.nav), 1)
        self.assertEqual(len(page.widgets), 1)

    def test_to_init_frame(self):
        nav = [NavItem("docs", "Docs", "/docs")]
        page = Page(title="Home", nav=nav)
        frame = page.to_init_frame()
        self.assertEqual(frame["op"], "init")
        self.assertEqual(frame["title"], "Home")
        self.assertEqual(len(frame["nav"]), 1)
        self.assertEqual(frame["nav"][0]["label"], "Docs")

    def test_to_init_frame_empty_nav(self):
        page = Page(title="Solo")
        frame = page.to_init_frame()
        self.assertEqual(frame["nav"], [])


if __name__ == "__main__":
    unittest.main()