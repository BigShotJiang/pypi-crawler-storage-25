"""Tests for termstream_py.yaml_config."""

import os
import tempfile
import unittest

from termstream_py.yaml_config import (
    load_from_yaml,
    _parse_widget,
    _parse_widget_type,
    _parse_page,
    _parse_content_md,
    _slugify,
    _extract_title,
)
from termstream_py.components import Widget, WidgetType


class TestParseWidgetType(unittest.TestCase):
    def test_all_types(self):
        self.assertEqual(_parse_widget_type("text"), WidgetType.TEXT)
        self.assertEqual(_parse_widget_type("heading"), WidgetType.HEADING)
        self.assertEqual(_parse_widget_type("button"), WidgetType.BUTTON)
        self.assertEqual(_parse_widget_type("input"), WidgetType.INPUT)

    def test_invalid_raises(self):
        with self.assertRaises(ValueError):
            _parse_widget_type("video")


class TestParseWidget(unittest.TestCase):
    def test_minimal_widget(self):
        w = _parse_widget({"type": "text", "text": "Hi"})
        self.assertEqual(w.type, WidgetType.TEXT)
        self.assertEqual(w.text, "Hi")

    def test_widget_with_all_fields(self):
        data = {
            "id": "my_id",
            "type": "button",
            "pos": [2, 3],
            "text": "Click",
            "style": {"bold": True},
            "action": {"type": "navigate", "target": "/x"},
        }
        w = _parse_widget(data)
        self.assertEqual(w.id, "my_id")
        self.assertEqual(w.pos, (2, 3))
        self.assertTrue(w.bold)


class TestParsePage(unittest.TestCase):
    def test_page_with_widgets(self):
        data = {
            "title": "Test",
            "widgets": [{"type": "text", "text": "Hello"}],
        }
        page = _parse_page(data)
        self.assertEqual(page.title, "Test")
        self.assertEqual(len(page.widgets), 1)


class TestSlugify(unittest.TestCase):
    def test_normal(self):
        self.assertEqual(_slugify("my_page"), "my-page")

    def test_uppercase(self):
        self.assertEqual(_slugify("Hello"), "hello")

    def test_special(self):
        self.assertEqual(_slugify("a!b@c"), "a-b-c")


class TestExtractTitle(unittest.TestCase):
    def test_finds_heading(self):
        widgets = [
            Widget("w1", WidgetType.TEXT, (0, 0), "intro"),
            Widget("w2", WidgetType.HEADING, (1, 0), "My Title"),
        ]
        self.assertEqual(_extract_title(widgets), "My Title")

    def test_no_heading_returns_untitled(self):
        widgets = [Widget("w1", WidgetType.TEXT, (0, 0), "just text")]
        self.assertEqual(_extract_title(widgets), "Untitled")


class TestLoadFromYaml(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_load_basic_yaml(self):
        yaml_path = os.path.join(self.tmpdir, "config.yaml")
        with open(yaml_path, "w") as f:
            f.write(
                "host: localhost\n"
                "port: 8765\n"
                "pages:\n"
                "  - path: /\n"
                "    title: Home\n"
                "    widgets:\n"
                "      - type: heading\n"
                "        pos: [0, 0]\n"
                "        text: Welcome\n"
                "      - type: text\n"
                "        pos: [1, 0]\n"
                "        text: Hello World\n"
            )
        server = load_from_yaml(yaml_path)
        self.assertEqual(server.host, "localhost")
        self.assertEqual(server.port, 8765)
        self.assertIn("/", server.routes)
        page = server.routes["/"]
        self.assertEqual(page.title, "Home")
        self.assertEqual(len(page.widgets), 2)

    def test_load_yaml_with_multiple_pages(self):
        yaml_path = os.path.join(self.tmpdir, "multi.yaml")
        with open(yaml_path, "w") as f:
            f.write(
                "host: 0.0.0.0\n"
                "port: 9000\n"
                "pages:\n"
                "  - path: /\n"
                "    title: Root\n"
                "    widgets:\n"
                "      - type: text\n"
                "        text: root\n"
                "  - path: /docs\n"
                "    title: Docs\n"
                "    widgets:\n"
                "      - type: heading\n"
                "        text: Docs\n"
            )
        server = load_from_yaml(yaml_path)
        self.assertEqual(server.host, "0.0.0.0")
        self.assertEqual(server.port, 9000)
        self.assertIn("/", server.routes)
        self.assertIn("/docs", server.routes)


class TestParseContentMd(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_heading_and_text(self):
        fpath = os.path.join(self.tmpdir, "content.md")
        with open(fpath, "w") as f:
            f.write("# Title\n\nSome paragraph\n")
        widgets = _parse_content_md(fpath)
        self.assertEqual(len(widgets), 2)
        self.assertEqual(widgets[0].type, WidgetType.HEADING)
        self.assertEqual(widgets[1].type, WidgetType.TEXT)

    def test_button_with_navigation(self):
        fpath = os.path.join(self.tmpdir, "content.md")
        with open(fpath, "w") as f:
            f.write("# Home\n> Go -> /docs\n")
        widgets = _parse_content_md(fpath)
        self.assertEqual(widgets[1].type, WidgetType.BUTTON)
        self.assertIsNotNone(widgets[1].action)
        self.assertEqual(widgets[1].action["target"], "/docs")

    def test_input_widget(self):
        fpath = os.path.join(self.tmpdir, "content.md")
        with open(fpath, "w") as f:
            f.write("# Home\n$ Search query\n")
        widgets = _parse_content_md(fpath)
        self.assertEqual(widgets[1].type, WidgetType.INPUT)
        self.assertEqual(widgets[1].text, "Search query")

    def test_empty_lines_skipped(self):
        fpath = os.path.join(self.tmpdir, "content.md")
        with open(fpath, "w") as f:
            f.write("# Title\n\n\n\nText\n")
        widgets = _parse_content_md(fpath)
        self.assertEqual(len(widgets), 2)


if __name__ == "__main__":
    unittest.main()