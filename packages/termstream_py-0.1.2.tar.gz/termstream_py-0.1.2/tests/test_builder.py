"""Tests for termstream_py.builder."""

import os
import tempfile
import unittest
from pathlib import Path

from termstream_py.builder import (
    PageNode,
    _slugify,
    _parse_widget_type,
    _parse_widget,
    _parse_content_md,
    create_page_node,
    create_server_from_nodes,
)
from termstream_py.components import WidgetType


class TestSlugify(unittest.TestCase):
    def test_simple_name(self):
        self.assertEqual(_slugify("home"), "home")

    def test_uppercase_converted(self):
        self.assertEqual(_slugify("Home"), "home")

    def test_spaces_replaced(self):
        self.assertEqual(_slugify("my page"), "my-page")

    def test_special_chars_replaced(self):
        self.assertEqual(_slugify("hello!world"), "hello-world")

    def test_multiple_spaces_become_single_hyphen(self):
        self.assertEqual(_slugify("a  b"), "a-b")

    def test_leading_trailing_spaces_stripped(self):
        self.assertEqual(_slugify("  hello  "), "hello")

    def test_all_hyphens_returns_hyphens(self):
        # _slugify replaces non-alphanumeric with hyphens but does not collapse them
        self.assertEqual(_slugify("---"), "---")


class TestParseWidgetType(unittest.TestCase):
    def test_valid_types(self):
        self.assertEqual(_parse_widget_type("text"), WidgetType.TEXT)
        self.assertEqual(_parse_widget_type("heading"), WidgetType.HEADING)
        self.assertEqual(_parse_widget_type("button"), WidgetType.BUTTON)
        self.assertEqual(_parse_widget_type("input"), WidgetType.INPUT)

    def test_case_insensitive(self):
        self.assertEqual(_parse_widget_type("Text"), WidgetType.TEXT)
        self.assertEqual(_parse_widget_type("HEADING"), WidgetType.HEADING)

    def test_invalid_type_raises(self):
        with self.assertRaises(ValueError):
            _parse_widget_type("invalid")


class TestParseWidget(unittest.TestCase):
    def test_basic_text_widget(self):
        data = {"type": "text", "pos": [0, 0], "text": "Hello"}
        w = _parse_widget(data)
        self.assertEqual(w.type, WidgetType.TEXT)
        self.assertEqual(w.text, "Hello")
        self.assertEqual(w.pos, (0, 0))

    def test_widget_with_id(self):
        data = {"id": "custom_id", "type": "heading", "pos": [1, 0], "text": "Title"}
        w = _parse_widget(data)
        self.assertEqual(w.id, "custom_id")

    def test_widget_with_bold_style(self):
        data = {"type": "text", "pos": [0, 0], "text": "Bold", "style": {"bold": True}}
        w = _parse_widget(data)
        self.assertTrue(w.bold)

    def test_widget_with_action(self):
        data = {
            "type": "button",
            "pos": [0, 0],
            "text": "Go",
            "action": {"type": "navigate", "target": "/docs"},
        }
        w = _parse_widget(data)
        self.assertEqual(w.action["target"], "/docs")

    def test_missing_type_raises(self):
        with self.assertRaises(ValueError):
            _parse_widget({"text": "no type"})

    def test_invalid_data_raises(self):
        with self.assertRaises(ValueError):
            _parse_widget("not a dict")


class TestPageNode(unittest.TestCase):
    def test_create_node(self):
        node = PageNode("home", path="/")
        self.assertEqual(node.name, "home")
        self.assertEqual(node.path, "/")
        self.assertEqual(node.title, "Home")
        self.assertEqual(node.children, [])
        self.assertEqual(node.widgets, [])

    def test_default_title(self):
        node = PageNode("my_page")
        self.assertEqual(node.title, "My_page")

    def test_custom_title(self):
        node = PageNode("my_page", title="Custom Title")
        self.assertEqual(node.title, "Custom Title")

    def test_add_text(self):
        node = PageNode("home")
        node.add_text("Hello")
        self.assertEqual(len(node.widgets), 1)
        self.assertEqual(node.widgets[0].type, WidgetType.TEXT)

    def test_add_heading(self):
        node = PageNode("home")
        node.add_heading("Title")
        self.assertEqual(len(node.widgets), 1)
        self.assertEqual(node.widgets[0].type, WidgetType.HEADING)
        self.assertTrue(node.widgets[0].bold)

    def test_add_button(self):
        node = PageNode("home")
        node.add_button("Go", action={"type": "navigate", "target": "/docs"})
        self.assertEqual(len(node.widgets), 1)
        self.assertEqual(node.widgets[0].type, WidgetType.BUTTON)

    def test_add_input(self):
        node = PageNode("home")
        node.add_input("Search...")
        self.assertEqual(len(node.widgets), 1)
        self.assertEqual(node.widgets[0].type, WidgetType.INPUT)

    def test_add_widget(self):
        node = PageNode("home")
        from termstream_py.components import Widget
        w = Widget("w1", WidgetType.TEXT, (0, 0), "Manual")
        node.add_widget(w)
        self.assertEqual(len(node.widgets), 1)

    def test_add_child(self):
        parent = PageNode("root", path="/")
        child = PageNode("docs", path="/docs")
        parent.add_child(child)
        self.assertEqual(len(parent.children), 1)
        self.assertEqual(parent.children[0], child)

    def test_remove_child(self):
        parent = PageNode("root", path="/")
        child = PageNode("docs", path="/docs")
        parent.add_child(child)
        parent.remove_child(child)
        self.assertEqual(len(parent.children), 0)

    def test_find_by_name(self):
        root = PageNode("root", path="/")
        docs = PageNode("docs", path="/docs")
        api = PageNode("api", path="/docs/api")
        docs.add_child(api)
        root.add_child(docs)
        self.assertIsNotNone(root.find("api"))
        self.assertIsNone(root.find("nonexistent"))

    def test_find_by_path(self):
        root = PageNode("root", path="/")
        docs = PageNode("docs", path="/docs")
        root.add_child(docs)
        self.assertIsNotNone(root.find_by_path("/docs"))
        self.assertIsNone(root.find_by_path("/nope"))

    def test_resolved_path_explicit(self):
        node = PageNode("home", path="/custom")
        self.assertEqual(node.resolved_path(), "/custom")

    def test_resolved_path_root(self):
        node = PageNode("root")
        self.assertEqual(node.resolved_path(), "/")

    def test_to_page(self):
        node = PageNode("home", path="/", title="Home Page")
        node.add_text("Hello")
        page = node.to_page()
        self.assertEqual(page.title, "Home Page")
        self.assertEqual(len(page.widgets), 1)

    def test_to_server(self):
        root = PageNode("root", path="/")
        root.add_heading("Home")
        docs = PageNode("docs", path="/docs")
        docs.add_heading("Docs")
        root.add_child(docs)
        server = root.to_server()
        self.assertIn("/", server.routes)
        self.assertIn("/docs", server.routes)

    def test_all_nodes(self):
        root = PageNode("root", path="/")
        a = PageNode("a", path="/a")
        b = PageNode("b", path="/b")
        root.add_child(a)
        root.add_child(b)
        nodes = root.all_nodes()
        self.assertEqual(len(nodes), 3)

    def test_visualise(self):
        root = PageNode("root", path="/")
        root.add_heading("Home")
        child = PageNode("docs", path="/docs")
        child.add_text("Docs content")
        root.add_child(child)
        output = root.visualise()
        self.assertIn("root", output)
        self.assertIn("docs", output)
        self.assertIn("/", output)

    def test_repr(self):
        node = PageNode("home", path="/home")
        node.add_text("Hi")
        r = repr(node)
        self.assertIn("home", r)
        self.assertIn("/home", r)


class TestPageNodeYAML(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_to_yaml_and_from_yaml_roundtrip(self):
        root = PageNode("root", path="/")
        root.add_heading("Home")
        root.add_text("Welcome")
        docs = PageNode("docs", path="/docs")
        docs.add_heading("Documentation")
        root.add_child(docs)

        yaml_path = os.path.join(self.tmpdir, "test_config.yaml")
        root.to_yaml(yaml_path)
        self.assertTrue(os.path.exists(yaml_path))

        loaded = PageNode.from_yaml(yaml_path)
        self.assertEqual(len(loaded.all_nodes()), 2)

    def test_to_yaml_dict(self):
        root = PageNode("root", path="/")
        root.add_heading("Home")
        d = root.to_yaml_dict()
        self.assertIn("pages", d)
        self.assertEqual(d["host"], "localhost")
        self.assertEqual(d["port"], 8765)


class TestPageNodeDirectory(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_to_directory_creates_files(self):
        root = PageNode("root", path="/")
        root.add_heading("Home")
        root.add_text("Welcome")
        docs = PageNode("docs", path="/docs")
        docs.add_heading("Docs")
        root.add_child(docs)

        out_dir = os.path.join(self.tmpdir, "output")
        root.to_directory(out_dir)
        self.assertTrue(os.path.exists(os.path.join(out_dir, "content.md")))
        self.assertTrue(os.path.exists(os.path.join(out_dir, "docs", "content.md")))

    def test_from_directory(self):
        # Create a test directory structure
        base = Path(self.tmpdir) / "myapp"
        base.mkdir()
        (base / "content.md").write_text("# Home\nWelcome\n")
        docs_dir = base / "docs"
        docs_dir.mkdir()
        (docs_dir / "content.md").write_text("# Docs\nAPI reference\n")

        root = PageNode.from_directory(str(base))
        self.assertEqual(len(root.all_nodes()), 3)  # root + home + docs


class TestFactoryFunctions(unittest.TestCase):
    def test_create_page_node(self):
        node = create_page_node("test", path="/test", title="Test Page")
        self.assertEqual(node.name, "test")
        self.assertEqual(node.path, "/test")
        self.assertEqual(node.title, "Test Page")

    def test_create_server_from_nodes(self):
        root = PageNode("root", path="/")
        root.add_heading("Home")
        server = create_server_from_nodes(root, host="0.0.0.0", port=9999)
        self.assertEqual(server.host, "0.0.0.0")
        self.assertEqual(server.port, 9999)


class TestParseContentMd(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_parse_heading_and_text(self):
        fpath = os.path.join(self.tmpdir, "content.md")
        with open(fpath, "w") as f:
            f.write("# My Title\n\nSome text\n")
        widgets = _parse_content_md(fpath)
        self.assertEqual(len(widgets), 2)
        self.assertEqual(widgets[0].type, WidgetType.HEADING)
        self.assertEqual(widgets[1].type, WidgetType.TEXT)

    def test_parse_button(self):
        fpath = os.path.join(self.tmpdir, "content.md")
        with open(fpath, "w") as f:
            f.write("# Title\n> Click me -> /docs\n")
        widgets = _parse_content_md(fpath)
        self.assertEqual(widgets[1].type, WidgetType.BUTTON)
        self.assertEqual(widgets[1].action["target"], "/docs")

    def test_parse_input(self):
        fpath = os.path.join(self.tmpdir, "content.md")
        with open(fpath, "w") as f:
            f.write("# Title\n$ Enter name\n")
        widgets = _parse_content_md(fpath)
        self.assertEqual(widgets[1].type, WidgetType.INPUT)
        self.assertEqual(widgets[1].text, "Enter name")


if __name__ == "__main__":
    unittest.main()