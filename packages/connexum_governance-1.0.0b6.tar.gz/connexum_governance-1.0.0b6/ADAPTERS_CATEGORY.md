# Python SDK Adapter Categories

> 2026-05-02 -- F-NEW-LOW-3

`packages/python-sdk/connexum_governance/integrations/` mixes three
distinct categories of adapter in a single flat namespace. This file
is the authoritative classification index. If you add or rename an
integration, update this file in the same PR.

The TypeScript side already separates the three categories at the
filesystem level (`src/llm-adapters/`, `src/orchestrators/`, and
`src/ide-adapters/`). The Python SDK keeps everything flat for
single-namespace import ergonomics; this document compensates.

## Category 1: LLM provider integrations

These wrap a vendor's LLM client SDK (model.generate_content,
client.chat.completions.create, etc.) and inject pre-call governance
checks plus post-call output classification. They are **not** IDE
adapters even when the vendor also ships an IDE plugin (e.g. Gemini
LLM != Gemini Code Assist; OpenAI LLM != GitHub Copilot).

| File                            | Vendor / Model                  | TS counterpart              |
|---------------------------------|----------------------------------|-----------------------------|
| `anthropic.py`                  | Anthropic Claude (messages API)  | `src/llm-adapters/anthropic.ts` |
| `openai.py`                     | OpenAI (chat.completions)        | `src/llm-adapters/openai.ts`    |
| `gemini.py`                     | Google Gemini GenerativeModel    | `src/llm-adapters/gemini.ts`    |
| `azure_openai.py`               | Azure OpenAI                     | `src/llm-adapters/azure-openai.ts` |
| `bedrock.py`                    | AWS Bedrock                      | `src/llm-adapters/bedrock.ts`   |
| `ollama.py`                     | Ollama (local LLM)               | `src/llm-adapters/ollama.ts`    |

## Category 2: Framework / orchestrator adapters

These wrap an agent framework's task / tool / callback surface
(LangChain BaseCallbackHandler, CrewAI Task callback, AutoGen
FunctionTool, etc.) so the framework's own concept of "tool call"
goes through the governance check.

| File                                       | Framework                         | TS counterpart |
|--------------------------------------------|------------------------------------|----------------|
| `langchain.py` + `langchain_integration.py` | LangChain (callbacks + agent)      | `src/orchestrators/langchain.ts` |
| `langgraph.py`                             | LangGraph                          | `src/orchestrators/langgraph.ts` |
| `crewai.py` + `crewai_integration.py`      | CrewAI                             | `src/orchestrators/crewai.ts` |
| `autogen.py` + `autogen_integration.py`    | AutoGen                            | `src/orchestrators/autogen.ts` |
| `llamaindex.py` + `llama_index_integration.py` | LlamaIndex                     | `src/orchestrators/llama-index.ts` |
| `haystack.py` + `haystack_integration.py`  | Haystack v2                        | `src/orchestrators/haystack.ts` |
| `claude_agent_sdk.py`                      | Anthropic Claude Agent SDK         | `src/orchestrators/claude-agent.ts` |
| `google_adk.py`                            | Google Agent Development Kit       | `src/orchestrators/google-adk.ts` |
| `bedrock_agentcore.py`                     | AWS Bedrock AgentCore              | `src/orchestrators/bedrock-agentcore.ts` |
| `openai_agents_integration.py`             | OpenAI Agents SDK                  | `src/orchestrators/openai-agents.ts` |
| `deepagents.py`                            | DeepAgents                         | `src/orchestrators/deepagents.ts` |

## Category 3: IDE / coding-assistant adapters

These wrap an IDE's coding-assistant surface (Copilot, Cursor,
Gemini Code Assist, etc.) so completions, edits, and chat replies
in the IDE go through the governance check. Gemini Code Assist
(the IDE plugin) belongs HERE; Gemini LLM (the model API) belongs
in Category 1.

| File                            | IDE / coding-assistant            | TS counterpart |
|---------------------------------|------------------------------------|----------------|
| `claude_code.py`                | Anthropic Claude Code              | `src/ide-adapters/claude-code.ts` |
| `github_copilot.py`             | GitHub Copilot                     | `src/ide-adapters/github-copilot.ts` |
| `cursor.py`                     | Cursor                             | `src/ide-adapters/cursor.ts` |
| `jetbrains_ai.py`               | JetBrains AI Assistant             | `src/ide-adapters/jetbrains-ai.ts` |
| `amazon_q_developer.py`         | Amazon Q Developer                 | `src/ide-adapters/amazon-q-developer.ts` |
| `copilot_workspace.py`          | GitHub Copilot Workspace           | `src/ide-adapters/copilot-workspace.ts` |
| `continue_dev.py`               | Continue.dev                       | `src/ide-adapters/continue-dev.ts` |
| Pending: gemini-code-assist Python wrapper | Google Gemini Code Assist | `src/ide-adapters/gemini-code-assist.ts` |

## How to verify the classification

A short scan that confirms `gemini.py` is an LLM-provider integration
and not an IDE adapter:

```
$ head -30 packages/python-sdk/connexum_governance/integrations/gemini.py
```

The docstring imports `google.generativeai` (the model API), wraps
`GenerativeModel.generate_content`, and sets `provider == "gemini"`
in registration. None of the IDE-adapter surfaces (resolveUserIdentity,
intercept completion, intercept edit) are present.

If a future audit re-flags this categorization, point at this file.
