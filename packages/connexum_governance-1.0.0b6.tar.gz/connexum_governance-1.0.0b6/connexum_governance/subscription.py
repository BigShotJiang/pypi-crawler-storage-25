"""
Subscription gate for connexum_governance -- S-06.

Mirrors the TypeScript SubscriptionGate (src/license/subscription-gate.ts).

Flow:
  1. Resolve CXNI_VENDOR_CODE from environment or ~/.connexum/governance.json (mode 0600).
  2. Call POST /api/v1/license/exchange on the license server with
     { vendorCode, machineId, sdkVersion }.
  3. Cache the Entitlement Token on disk at ~/.connexum/entitlement.json (mode 0600).
  4. Refresh the cached token 1 hour before expiry.
  5. Background thread re-validates every 24h. On 'revoked', flip to fail-closed
     within one cycle.

Pack-floor grace windows (strictest-wins, identical to TypeScript):
  hipaa / hitech / pci_dss: 24h
  soc2:                      48h
  default:                   72h

Errors raised from the client constructor:
  SubscriptionNotConfiguredError -- no vendor code found
  SubscriptionInactiveError      -- vendor code is revoked
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import stat
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx

# ---------------------------------------------------------------------------
# Package version
# ---------------------------------------------------------------------------

SDK_VERSION = "0.1.0"

# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------


class SubscriptionNotConfiguredError(RuntimeError):
    """No vendor code found for this governance installation."""

    def __init__(self) -> None:
        super().__init__(
            "SUBSCRIPTION_NOT_CONFIGURED: No vendor code found for this governance "
            "installation. Set CXNI_VENDOR_CODE in your environment or run "
            "`npx @connexum/ai-governance init` to configure a subscription. "
            "See docs/INSTALL.md#subscription for instructions."
        )
        self.code = "SUBSCRIPTION_NOT_CONFIGURED"


class SubscriptionInactiveError(RuntimeError):
    """The subscription is revoked or has expired past its grace window."""

    def __init__(self, status: str, detail: Optional[str] = None) -> None:
        super().__init__(
            f"SUBSCRIPTION_INACTIVE: Your connexum-governance subscription is {status}. "
            + (detail or "Visit the billing portal to restore your subscription.")
        )
        self.subscription_status = status
        self.code = "SUBSCRIPTION_INACTIVE"


class SubscriptionMalformedError(ValueError):
    """The vendor code does not match the expected format.

    M8b / PT-PYTHON-SUB-VENDOR-FORMAT-1: Vendor codes MUST match the pattern
    ``cxni_v1_<14 uppercase base32 chars>`` before an HTTP exchange is attempted.
    A malformed code indicates mis-configuration or an injection attempt; failing
    before the network call prevents unnecessary outbound requests and avoids
    leaking partial data to an attacker-controlled URL.
    """

    _PATTERN = re.compile(r"^cxni_v1_[A-Z2-7]{14}$")

    def __init__(self, vendor_code: str) -> None:
        # Truncate to avoid logging the full code in error messages.
        truncated = vendor_code[:12] + "..." if len(vendor_code) > 12 else vendor_code
        super().__init__(
            f"SUBSCRIPTION_MALFORMED_VENDOR_CODE: Vendor code '{truncated}' does not match "
            "the required format 'cxni_v1_<14 uppercase base32 chars>'. "
            "Check your CXNI_VENDOR_CODE environment variable or ~/.connexum/governance.json."
        )
        self.code = "SUBSCRIPTION_MALFORMED_VENDOR_CODE"

    @classmethod
    def validate(cls, vendor_code: str) -> None:
        """Raise SubscriptionMalformedError if vendor_code is not valid format."""
        if not cls._PATTERN.match(vendor_code):
            raise cls(vendor_code)


# ---------------------------------------------------------------------------
# Grace-window constants (strictest-wins, must match TypeScript floor)
# ---------------------------------------------------------------------------

GRACE_WINDOWS_SECONDS: dict[str, int] = {
    "hipaa": 24 * 3600,
    "hitech": 24 * 3600,
    "pci_dss": 24 * 3600,
    "soc2": 48 * 3600,
    "soc_2": 48 * 3600,
    "default": 72 * 3600,
}


def resolve_grace_window_seconds(active_pack_ids: list[str]) -> int:
    """Return the strictest (shortest) grace window for the given pack IDs."""
    floor = GRACE_WINDOWS_SECONDS["default"]
    for pack_id in active_pack_ids:
        pack_floor = GRACE_WINDOWS_SECONDS.get(pack_id.lower())
        if pack_floor is not None and pack_floor < floor:
            floor = pack_floor
    return floor


# ---------------------------------------------------------------------------
# Machine ID
# ---------------------------------------------------------------------------

def _machine_id() -> str:
    """
    Return a stable, opaque identifier for this installation.
    Uses /etc/machine-id (Linux) or platform.node() as a fallback.
    Hashed with SHA-256 so no raw hardware info is sent to the server.
    """
    raw = ""
    if platform.system() == "Linux":
        try:
            raw = Path("/etc/machine-id").read_text(encoding="utf-8").strip()
        except OSError:
            pass
    if not raw:
        raw = platform.node() or "unknown"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


# ---------------------------------------------------------------------------
# Disk cache helpers
# ---------------------------------------------------------------------------

_CONNEXUM_DIR = Path.home() / ".connexum"
_GOVERNANCE_JSON = _CONNEXUM_DIR / "governance.json"
_ENTITLEMENT_JSON = _CONNEXUM_DIR / "entitlement.json"


def _ensure_connexum_dir() -> None:
    _CONNEXUM_DIR.mkdir(parents=True, exist_ok=True)
    # Owner-only permissions on the directory
    os.chmod(_CONNEXUM_DIR, stat.S_IRWXU)


def _write_secure(path: Path, data: dict) -> None:
    """Write JSON to path with mode 0600 (owner read/write only)."""
    _ensure_connexum_dir()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    tmp.rename(path)


def _read_json(path: Path) -> Optional[dict]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


# ---------------------------------------------------------------------------
# JWT decode (no verification -- server holds the signing key)
# ---------------------------------------------------------------------------

def _decode_jwt_payload(token: str) -> dict:
    import base64
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("malformed JWT")
    # Standard base64url with padding
    payload_b64 = parts[1]
    padding = 4 - len(payload_b64) % 4
    if padding != 4:
        payload_b64 += "=" * padding
    return json.loads(base64.urlsafe_b64decode(payload_b64).decode("utf-8"))


# ---------------------------------------------------------------------------
# Entitlement token cache
# ---------------------------------------------------------------------------

_REFRESH_BEFORE_EXPIRY_SECONDS = 3600  # 1 hour before expiry


def _load_cached_token() -> Optional[dict]:
    """Load cached entitlement token. Returns None if missing or expired."""
    data = _read_json(_ENTITLEMENT_JSON)
    if not data or "token" not in data:
        return None
    try:
        claims = _decode_jwt_payload(data["token"])
        exp = claims.get("exp", 0)
        # Return None if the token expires within the refresh buffer
        if time.time() >= (exp - _REFRESH_BEFORE_EXPIRY_SECONDS):
            return None
        return data
    except Exception as exc:
        # H2: cache read failure is non-fatal (returns None to trigger fresh fetch)
        # but should be logged so operators can detect filesystem/permission issues.
        import logging as _logging
        _logging.getLogger(__name__).warning("Failed to load cached entitlement token: %s", exc)
        return None


def _save_cached_token(token: str, claims: dict) -> None:
    _write_secure(_ENTITLEMENT_JSON, {"token": token, "claims": claims})


# ---------------------------------------------------------------------------
# Vendor code resolution
# ---------------------------------------------------------------------------

def _resolve_vendor_code() -> Optional[str]:
    """
    Priority 1: CXNI_VENDOR_CODE environment variable.
    Priority 2: ~/.connexum/governance.json -> subscription.vendorCode.
    """
    from_env = os.environ.get("CXNI_VENDOR_CODE", "").strip()
    if from_env:
        return from_env

    data = _read_json(_GOVERNANCE_JSON)
    if data:
        subscription = data.get("subscription", {})
        code = subscription.get("vendorCode", "")
        if code:
            return code
    return None


# ---------------------------------------------------------------------------
# Exchange endpoint call
# ---------------------------------------------------------------------------

def _exchange(
    vendor_code: str,
    license_server_url: str,
    timeout: float = 10.0,
) -> dict:
    """
    POST /api/v1/license/exchange.
    Returns the parsed JSON response body.
    Raises SubscriptionNotConfiguredError or SubscriptionInactiveError on error.
    """
    payload = {
        "vendorCode": vendor_code,
        "machineId": _machine_id(),
        "sdkVersion": SDK_VERSION,
    }
    url = license_server_url.rstrip("/") + "/api/v1/license/exchange"

    try:
        with httpx.Client(timeout=timeout) as client:
            resp = client.post(url, json=payload)
    except (httpx.ConnectError, httpx.TimeoutException) as exc:
        raise SubscriptionInactiveError(
            "revoked",
            f"License server unreachable: {exc}",
        ) from exc

    if resp.status_code == 404:
        raise SubscriptionNotConfiguredError()

    if resp.status_code == 403:
        body = resp.json() if resp.content else {}
        raise SubscriptionInactiveError(
            body.get("subscriptionStatus", "revoked"),
            body.get("detail"),
        )

    if resp.status_code != 200:
        raise SubscriptionInactiveError(
            "revoked",
            f"License server returned HTTP {resp.status_code}",
        )

    return resp.json()


# ---------------------------------------------------------------------------
# SubscriptionGate
# ---------------------------------------------------------------------------


class SubscriptionGate:
    """
    Runtime subscription enforcement gate (Python mirror of S-03 TypeScript).

    Usage::

        gate = SubscriptionGate(license_server_url="https://license.my-cc.io")
        status = gate.boot()  # 'active' | 'grace'  (raises on revoked/missing)
        # gate handles background revalidation automatically
        gate.stop()  # clean shutdown
    """

    def __init__(
        self,
        license_server_url: str,
        active_pack_ids: Optional[list[str]] = None,
        revalidate_interval_seconds: int = 24 * 3600,
        on_status_change=None,  # callable(previous, current, grace_until=None)
        emit_audit_event=None,  # callable(event_type, data_dict)
    ) -> None:
        self._license_server_url = license_server_url
        self._active_pack_ids = active_pack_ids or []
        self._revalidate_interval_seconds = revalidate_interval_seconds
        self._on_status_change = on_status_change
        self._emit_audit_event = emit_audit_event

        self._vendor_code: Optional[str] = None
        self._current_status: Optional[str] = None
        self._timer: Optional[threading.Timer] = None
        self._lock = threading.Lock()
        self._last_grace_warn_date: Optional[str] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def boot(self) -> str:
        """
        Boot the gate: resolve vendor code, exchange for token, enforce policy.

        Returns 'active' or 'grace'.
        Raises SubscriptionNotConfiguredError or SubscriptionInactiveError.
        """
        vendor_code = _resolve_vendor_code()
        if not vendor_code:
            raise SubscriptionNotConfiguredError()

        # M8b / PT-PYTHON-SUB-VENDOR-FORMAT-1: validate format before HTTP call.
        # Prevents network round-trips and potential SSRF with malformed codes.
        SubscriptionMalformedError.validate(vendor_code)

        self._vendor_code = vendor_code

        # Try disk cache first
        cached = _load_cached_token()
        if cached:
            status = cached.get("claims", {}).get("status", "revoked")
        else:
            # Fresh exchange
            resp = _exchange(vendor_code, self._license_server_url)
            token = resp.get("token", "")
            claims = _decode_jwt_payload(token) if token else {}
            _save_cached_token(token, claims)
            status = resp.get("status", "revoked")

        with self._lock:
            self._current_status = status

        if status == "revoked":
            raise SubscriptionInactiveError("revoked")

        if status == "grace":
            self._emit_grace_warning()

        self._start_revalidation()
        return status

    def stop(self) -> None:
        """Cancel background revalidation timer."""
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None

    def revalidate_now(self) -> str:
        """Force an immediate revalidation. Returns current status."""
        if not self._vendor_code:
            raise SubscriptionNotConfiguredError()

        resp = _exchange(self._vendor_code, self._license_server_url)
        token = resp.get("token", "")
        claims = _decode_jwt_payload(token) if token else {}
        _save_cached_token(token, claims)
        new_status = resp.get("status", "revoked")

        with self._lock:
            previous = self._current_status
            self._current_status = new_status

        if new_status != previous and self._on_status_change:
            grace_until = claims.get("graceUntil") if isinstance(claims, dict) else None
            self._on_status_change(previous, new_status, grace_until)

        return new_status

    @property
    def status(self) -> Optional[str]:
        """Return the current cached status or None if boot() has not been called."""
        with self._lock:
            return self._current_status

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _start_revalidation(self) -> None:
        if self._revalidate_interval_seconds <= 0:
            return
        with self._lock:
            if self._timer is not None:
                return

            def _revalidate() -> None:
                try:
                    status = self.revalidate_now()
                    if status == "revoked":
                        with self._lock:
                            self._current_status = "revoked"
                        if self._emit_audit_event:
                            self._emit_audit_event(
                                "subscription.revoked.detected",
                                {"detectedAt": datetime.now(timezone.utc).isoformat()},
                            )
                except Exception as exc:  # noqa: BLE001
                    if self._emit_audit_event:
                        self._emit_audit_event(
                            "subscription.revalidation.failed",
                            {"error": str(exc), "timestamp": datetime.now(timezone.utc).isoformat()},
                        )
                finally:
                    # Re-schedule (daemon thread pattern)
                    with self._lock:
                        self._timer = threading.Timer(
                            self._revalidate_interval_seconds, _revalidate
                        )
                        self._timer.daemon = True
                        self._timer.start()

            self._timer = threading.Timer(
                self._revalidate_interval_seconds, _revalidate
            )
            self._timer.daemon = True
            self._timer.start()

    def _emit_grace_warning(self) -> None:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if self._last_grace_warn_date == today:
            return
        self._last_grace_warn_date = today

        # H7: resolve_grace_window_seconds must source active_pack_ids from the
        # server-validated entitlement token claims if present, not from caller
        # input. If the token carries packIds, those govern the grace window.
        # Caller-supplied list is ONLY used as a fallback when no token exists.
        authoritative_pack_ids = self._active_pack_ids  # fallback
        cached = _load_cached_token()
        if cached:
            token_pack_ids = cached.get("claims", {}).get("packIds")
            if isinstance(token_pack_ids, list) and token_pack_ids:
                authoritative_pack_ids = [str(p) for p in token_pack_ids]

        grace_window_s = resolve_grace_window_seconds(authoritative_pack_ids)
        if self._emit_audit_event:
            self._emit_audit_event(
                "subscription.grace.warning",
                {
                    "graceWindowSeconds": grace_window_s,
                    "activePackIds": authoritative_pack_ids,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )


# ---------------------------------------------------------------------------
# Standalone one-shot check (mirrors checkSubscriptionGate in TypeScript)
# ---------------------------------------------------------------------------


def enforce(
    license_server_url: str,
    active_pack_ids: Optional[list[str]] = None,
) -> str:
    """
    One-shot gate check with no background revalidation.
    Used for hook scripts and CLI pre-flight.
    Returns 'active' or 'grace'. Raises on failure.
    """
    gate = SubscriptionGate(
        license_server_url=license_server_url,
        active_pack_ids=active_pack_ids or [],
        revalidate_interval_seconds=0,  # no background thread
    )
    status = gate.boot()
    gate.stop()
    return status
