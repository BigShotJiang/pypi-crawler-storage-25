"""
connexum_governance.testing -- TEST-ONLY helpers.

Import from this subpath in test files ONLY. Production code MUST
NOT import from ``connexum_governance.testing``. The directory layout
makes this boundary structural rather than merely documentary; CI
linters can ban any import that matches ``connexum_governance\\.testing``
outside of ``tests/`` directories.

Mirrors the TS SDK's ``@connexum/typescript-sdk/testing`` subpath
introduced in F-NEW-CRIT-39e-2-TEST-PATH-SEPARATION (PR #285).

Exported symbols:
  * ``SoftwareKeyAttestor`` -- in-memory Ed25519 attestor (TEST-ONLY)
  * ``generate_software_key()`` -- generate an in-memory Ed25519 key
    pair (TEST-ONLY)
  * ``build_attestation_token()`` -- low-level token builder for
    advanced callers / cross-SDK contract tests
  * ``compute_request_hash()`` -- canonical request hash matching the
    server-side helper

Re-exported types from ``connexum_governance.attestor`` for caller
convenience:
  * ``EndUserAttestor`` (Protocol)
  * ``AttestationContext``
  * ``SignedAttestation``
  * ``AttestorError``

If the process env ``CONNEXUM_PROD`` is truthy at import time, a
``DeprecationWarning`` is raised.

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 1
"""

from __future__ import annotations

from connexum_governance.attestor import (
    AttestationContext,
    AttestorError,
    EndUserAttestor,
    SignedAttestation,
)
from connexum_governance.testing._warning import emit_production_import_warning
from connexum_governance.testing.software_key_attestor import (
    SoftwareKeyAttestor,
    build_attestation_token,
    compute_request_hash,
    generate_software_key,
)

# Emit production-import DeprecationWarning at module load time when
# CONNEXUM_PROD=1 (or true/yes). Done last so that import side-effects
# in software_key_attestor (which may import cryptography) surface
# any ImportError before the warning fires.
emit_production_import_warning()

__all__ = [
    "AttestationContext",
    "AttestorError",
    "EndUserAttestor",
    "SignedAttestation",
    "SoftwareKeyAttestor",
    "build_attestation_token",
    "compute_request_hash",
    "generate_software_key",
]
