"""
SoftwareKeyAttestor -- TEST-ONLY reference implementation of the
``EndUserAttestor`` protocol for the Python SDK.

Mirrors ``packages/typescript-sdk/src/testing/attestation-helpers.ts``.

WIRE FORMAT (mirrors
``packages/governance-server/src/end-user-attestation.ts``):

::

    v4att.<base64url-payload>.<base64url-signature>

where:

  * payload   = base64url(UTF-8(JSON.stringify(claims)))
                (Python: ``base64.urlsafe_b64encode(payload_bytes)``,
                 padding stripped, with ``json.dumps(..., separators=(",",":"))``
                 to match Node ``JSON.stringify`` byte-for-byte.)
  * signature = base64url(Ed25519.sign(payload_bytes))
                (raw 64-byte signature; **no PASETO PAE**.)

The dict insertion order in ``_build_claims_dict()`` exactly matches
the TS field order in ``attestation-helpers.ts:130-141``:
``sub, iat, exp, jti, aud, tenantId, nonce, action, requestHash``
followed by an optional ``keyId``. Python's ``dict`` preserves
insertion order in 3.7+, and ``json.dumps`` uses that order, so the
serialized payload bytes are identical to Node's ``JSON.stringify``
output for the same claims.

@deprecated TEST-ONLY. DO NOT USE IN PRODUCTION.

This class stores the Ed25519 private key in process memory with no
hardware isolation, no biometric or physical confirmation, and no
protection against process memory dumps. Any attacker with read
access to the process heap can extract the key and forge attestation
tokens indefinitely.

The governance guarantee sold to enterprise customers ("signed
end-user attestation") collapses to an in-process key that is
trivially forgeable. A hospital or bank using ``SoftwareKeyAttestor``
in production means their entire attestation audit trail can be
forged by any attacker with process access.

Production deployments MUST use a hardware-backed attestor:

  * WebAuthn / FIDO2 passkey (slice 3, pending)
  * YubiKey + PKCS#11 via the WebAuthn stack
  * AWS KMS / Azure Key Vault / GCP KMS (slice 5+, pending)

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 1
"""

from __future__ import annotations

import base64
import json
import secrets
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from typing import Any, Dict, Optional, Tuple

# ``cryptography`` is intentionally an OPTIONAL dependency declared in
# ``pyproject.toml`` under ``[project.optional-dependencies] testing``.
# The import is at module load time, so importing
# ``connexum_governance.testing`` without the ``testing`` extra raises a
# clear ImportError pointing the caller to the install command.
try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
except ImportError as exc:  # pragma: no cover -- tested via separate import test
    raise ImportError(
        "connexum_governance.testing requires the 'cryptography' library "
        "(>=42). Install via:\n"
        "    pip install 'connexum-governance[testing]'\n"
        "or\n"
        "    pip install 'cryptography>=42'\n"
        "Production deployments must NOT use SoftwareKeyAttestor; the "
        "testing extra is intentionally separate."
    ) from exc

from connexum_governance.attestor._types import (
    AttestationContext,
    AttestorError,
    SignedAttestation,
)

__all__ = [
    "DEFAULT_TTL_SECONDS",
    "SoftwareKeyAttestor",
    "build_attestation_token",
    "compute_request_hash",
    "generate_software_key",
]

# ---------------------------------------------------------------------------
# Wire format constants -- mirror packages/governance-server/src/end-user-attestation.ts
# and packages/typescript-sdk/src/attestation.ts
# ---------------------------------------------------------------------------

TOKEN_PREFIX = "v4att."

DEFAULT_TTL_SECONDS = 90
"""Default token TTL. Mirrors the TS SDK and server defaults."""


# ---------------------------------------------------------------------------
# Internal: claims builder -- order MUST match TS attestation-helpers.ts:130
# ---------------------------------------------------------------------------


def _b64url_no_pad(raw: bytes) -> str:
    """``base64url`` per RFC 4648 with padding stripped, ASCII string.

    Equivalent to Node ``Buffer.from(raw).toString('base64url')``.
    """

    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _build_claims_dict(
    *,
    sub: str,
    aud: str,
    iat_iso: str,
    exp_iso: str,
    jti: str,
    nonce: Optional[str],
    action: Optional[str],
    request_hash: Optional[str],
    key_id: Optional[str],
) -> Dict[str, Any]:
    """Build the claims dict in TS-equivalent insertion order.

    Order from ``packages/typescript-sdk/src/testing/attestation-helpers.ts:130-141``:

    1.  ``sub``
    2.  ``iat``
    3.  ``exp``
    4.  ``jti``
    5.  ``aud``
    6.  ``tenantId`` (always populated as a copy of ``aud``)
    7.  ``nonce``        (optional, included only if not ``None``)
    8.  ``action``       (optional, truncated to 200 chars)
    9.  ``requestHash``  (optional)
    10. ``keyId``        (optional)

    The TS spread ``...(keyId !== undefined ? { keyId } : {})`` only
    emits ``keyId`` when it is set; everything else is always emitted
    (the TS code passes ``nonce: context.nonce``, ``action:
    context.action.slice(0, 200)``, ``requestHash:
    context.requestHash`` unconditionally, so we do the same).

    ``json.dumps(..., separators=(",", ":"))`` then matches Node's
    ``JSON.stringify`` byte-for-byte for these field types.
    """

    claims: Dict[str, Any] = {
        "sub": sub,
        "iat": iat_iso,
        "exp": exp_iso,
        "jti": jti,
        "aud": aud,
        "tenantId": aud,
    }

    # The TS reference passes nonce/action/requestHash unconditionally
    # (they are always present on AttestationContext, never undefined).
    # We mirror by emitting the keys with whatever value the caller
    # supplied. If the caller passes None for any of these, JS would
    # see ``undefined`` and skip them via JSON.stringify -- so we skip
    # them in Python too for correctness.
    if nonce is not None:
        claims["nonce"] = nonce
    if action is not None:
        # Slice to 200 chars per server constraint
        # (end-user-attestation.ts:69 + attestation-helpers.ts:138)
        claims["action"] = action[:200]
    if request_hash is not None:
        claims["requestHash"] = request_hash

    if key_id is not None:
        claims["keyId"] = key_id

    return claims


# ---------------------------------------------------------------------------
# build_attestation_token -- low-level helper for advanced callers
# ---------------------------------------------------------------------------


def build_attestation_token(
    claims: Dict[str, Any],
    private_key: Ed25519PrivateKey,
) -> str:
    """Build and sign a v4att token from a pre-built claims dict.

    Mirrors ``buildAttestationToken()`` in
    ``packages/typescript-sdk/src/attestation.ts:183-199`` and
    ``packages/governance-server/src/end-user-attestation.ts:132-145``.

    The caller is responsible for the claims dict's insertion order;
    use ``_build_claims_dict()`` (or ``SoftwareKeyAttestor.sign()``)
    if you want canonical TS-equivalent ordering.

    :param claims: payload dict (will be JSON-encoded UTF-8 with
        ``separators=(",", ":")`` to match Node ``JSON.stringify``).
    :param private_key: Ed25519 private key. The signature is the raw
        64-byte Ed25519 signature over the payload bytes -- **no
        PASETO PAE**. Server expects raw payload signing per
        ``end-user-attestation.ts:296`` (``crypto.verify(null, payloadBytes, ...)``).
    :returns: ``v4att.<b64url-payload>.<b64url-signature>`` token string.
    """

    payload_json = json.dumps(claims, separators=(",", ":"))
    payload_bytes = payload_json.encode("utf-8")
    payload_b64 = _b64url_no_pad(payload_bytes)

    # Raw payload signing -- no PAE preamble. Mirrors the TS
    # crypto.sign(null, payloadBytes, privateKey) at attestation.ts:195.
    signature = private_key.sign(payload_bytes)
    sig_b64 = _b64url_no_pad(signature)

    return f"{TOKEN_PREFIX}{payload_b64}.{sig_b64}"


# ---------------------------------------------------------------------------
# compute_request_hash -- canonical request hash, server-side equivalent
# ---------------------------------------------------------------------------


def compute_request_hash(
    tool_name: str,
    input_json: str,
    agent_name: str,
) -> str:
    """Compute the canonical request hash used to bind a token to a
    specific request.

    Mirrors the server-side ``computeRequestHash()`` in
    ``packages/governance-server/src/end-user-attestation.ts:415-422``.

    canonical = ``toolName + ":" + inputJson + ":" + agentName``

    :returns: SHA-256 hex string.
    """

    canonical = f"{tool_name}:{input_json}:{agent_name}"
    return sha256(canonical.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# generate_software_key -- TEST-ONLY key pair generator
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SoftwareKeyPair:
    """Output of ``generate_software_key()``.

    The PEM string is what the host application registers with the
    server-side ``AttestationKeyStore`` (POST
    ``/api/v1/admin/attestation/keys/register``). The
    ``Ed25519PrivateKey`` object is what ``SoftwareKeyAttestor``
    holds in memory.
    """

    private_key: Ed25519PrivateKey
    public_key_pem: str


def generate_software_key() -> SoftwareKeyPair:
    """Generate an in-memory Ed25519 key pair. **TEST-ONLY.**

    Companion to ``SoftwareKeyAttestor``. The private key is held in
    process memory and can be extracted by any attacker with heap
    read access -- DO NOT USE IN PRODUCTION.

    Returns:
        ``SoftwareKeyPair(private_key, public_key_pem)`` where
        ``public_key_pem`` is SPKI-encoded PEM, suitable for the
        server-side ``AttestationKeyStore.registerKey()`` call.
    """

    private_key = Ed25519PrivateKey.generate()
    public_key: Ed25519PublicKey = private_key.public_key()
    public_key_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("ascii")
    return SoftwareKeyPair(private_key=private_key, public_key_pem=public_key_pem)


# ---------------------------------------------------------------------------
# SoftwareKeyAttestor -- the EndUserAttestor implementation
# ---------------------------------------------------------------------------


class SoftwareKeyAttestor:
    """TEST-ONLY in-memory ``EndUserAttestor`` implementation.

    Mirrors the TS ``SoftwareKeyAttestor`` in
    ``packages/typescript-sdk/src/testing/attestation-helpers.ts:98-160``.

    :param private_key: Ed25519 private key (from
        ``generate_software_key()`` or
        ``Ed25519PrivateKey.generate()``).
    :param sub_claim: opaque end-user identifier. Becomes the ``sub``
        claim in the token and must match the userId registered in
        the server-side ``AttestationKeyStore``.
    :param ttl_seconds: token TTL in seconds. Default: 90.
    :param key_id: optional key identifier for targeted revocation.
    """

    __slots__ = ("_private_key", "_sub_claim", "_ttl_seconds", "_key_id")

    def __init__(
        self,
        private_key: Ed25519PrivateKey,
        sub_claim: str,
        *,
        ttl_seconds: int = DEFAULT_TTL_SECONDS,
        key_id: Optional[str] = None,
    ) -> None:
        self._private_key = private_key
        self._sub_claim = sub_claim
        self._ttl_seconds = ttl_seconds
        self._key_id = key_id

    async def sign(self, context: AttestationContext) -> SignedAttestation:
        """Sign a v4att token for the given context.

        :raises AttestorError: with ``code='sign-failed'`` if the
            Ed25519 signing primitive raises (very rare with stdlib
            keys; the TS reference also wraps this).
        """

        now = datetime.now(timezone.utc)
        exp = now + timedelta(seconds=self._ttl_seconds)
        jti = str(uuid.uuid4())

        # ISO 8601 with millisecond precision and trailing Z, matching
        # Node's Date.toISOString() output -- e.g.
        # ``2026-05-04T16:30:00.123Z``. Python's default isoformat()
        # yields ``...+00:00``; we trim and append ``Z`` so the
        # token's iat/exp claims are byte-identical to TS-issued
        # tokens.
        iat_iso = _iso8601_z(now)
        exp_iso = _iso8601_z(exp)

        claims = _build_claims_dict(
            sub=self._sub_claim,
            aud=context.tenant_id,
            iat_iso=iat_iso,
            exp_iso=exp_iso,
            jti=jti,
            nonce=context.nonce,
            action=context.action,
            request_hash=context.request_hash,
            key_id=self._key_id,
        )

        try:
            token = build_attestation_token(claims, self._private_key)
        except Exception as err:  # pragma: no cover -- stdlib failure path
            raise AttestorError(
                "sign-failed",
                f"Ed25519 signing failed: {err}",
            ) from err

        return SignedAttestation(
            token=token,
            sub=self._sub_claim,
            jti=jti,
            exp=int(exp.timestamp() * 1000),
        )


def _iso8601_z(dt: datetime) -> str:
    """Render a UTC datetime in ISO-8601 with millisecond precision
    and a trailing ``Z``, matching Node ``Date.toISOString()``.

    Node example:  ``2026-05-04T16:30:00.123Z``
    Python default ``isoformat()``: ``2026-05-04T16:30:00.123456+00:00``
    """

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    # Truncate to milliseconds (3 digits of fractional seconds), drop
    # the timezone offset, append Z.
    iso = dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    millis = dt.microsecond // 1000
    return f"{iso}.{millis:03d}Z"
