"""
Production-import guard for ``connexum_governance.testing``.

Mirrors the TS SDK's structural prod/test boundary in
``packages/typescript-sdk/src/testing/index.ts``. When this module is
imported and ``CONNEXUM_PROD=1`` (or ``true`` / ``yes``) is set in the
process environment, a ``DeprecationWarning`` is emitted.

This is informational, not blocking. CI rules can ban any
``import connexum_governance.testing`` outside of test directories to
turn this into a structural enforcement mechanism.

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 1
"""

from __future__ import annotations

import os
import warnings

_PROD_ENV_TRUTHY = frozenset({"1", "true", "yes"})


def emit_production_import_warning() -> None:
    """Emit a ``DeprecationWarning`` if the host environment claims
    production via ``CONNEXUM_PROD``.

    Called once at module import time from
    ``connexum_governance.testing.__init__``.
    """

    raw = os.environ.get("CONNEXUM_PROD", "").strip().lower()
    if raw in _PROD_ENV_TRUTHY:
        warnings.warn(
            "connexum_governance.testing was imported in a production "
            "environment (CONNEXUM_PROD=1). The helpers under this "
            "namespace (e.g. SoftwareKeyAttestor) keep Ed25519 private "
            "keys in process memory with no hardware isolation. "
            "Production deployments MUST use a hardware-backed attestor "
            "(WebAuthn / FIDO2, YubiKey, AWS KMS, Azure Key Vault, GCP "
            "KMS). See F-NEW-CRIT-39e-2-PY slice 3+.",
            category=DeprecationWarning,
            stacklevel=3,
        )
