"""
GovernedLlamaIndex -- governance enforcement for LlamaIndex (Python).

This is a FRAMEWORK ADAPTER, not an LLM provider shim. It intercepts at the
framework orchestration layer, sitting between customer code and LlamaIndex's
query engines, chat engines, and agent workers.

=== ARCHITECTURAL CONTRAST: LlamaIndex vs LangChain vs OpenAI Agents SDK ===

LangChain's callback system is OBSERVABILITY-first. Whether a raise from
on_agent_action or on_tool_start actually blocks execution is NOT guaranteed
by the LangChain callback contract (see langchain_integration.py). The only
guaranteed LangChain blocking primitive is GovernedTool._run().

OpenAI Agents SDK provides FIRST-CLASS blocking via input/output guardrails --
a contract-guaranteed gate in the SDK's public API.

LlamaIndex falls between these two:

  FunctionTool.__call__ / acall:
    LlamaIndex FunctionTool exposes __call__ for sync execution and acall for
    async execution. These are the tool dispatch points in agent workers (e.g.
    FunctionCallingAgentWorker, ReActAgent). Subclassing FunctionTool and
    overriding __call__ / acall is the GUARANTEED BLOCKING PRIMITIVE -- it
    runs inside the tool invocation path regardless of which agent worker or
    query engine triggers the call.

  CallbackManager / BaseCallbackHandler:
    LlamaIndex's callback system (on_event_start / on_event_end) fires for
    LLM calls, agent steps, retrievals, etc. This is an OBSERVABILITY system,
    not a blocking gate. Whether a raise from on_event_start propagates to the
    caller depends on the LlamaIndex version and the component firing the event.
    Versions < 0.11 fire callbacks inside try/except in some code paths.
    CONCLUSION: Use GovernanceLlamaIndexCallback for audit coverage and
    defense-in-depth. Do NOT rely on it as the sole enforcement gate.

  QueryEngine.query() / ChatEngine.chat():
    These are top-level entry points where governance can be applied to the
    QUERY STRING before any retrieval happens. Wrapping these entry points
    gives a clean pre-retrieval gate. This is the right place to enforce
    input-level policies (who is allowed to query, what topics are permitted).

BLOCKING STORY (ranked best to worst):
  1. GovernedFunctionTool.__call__ / acall     -- GUARANTEED (tool dispatch)
  2. wrap_query_engine / wrap_chat_engine       -- GUARANTEED at entry point
                                                   (before any retrieval)
  3. GovernanceLlamaIndexCallback               -- BEST-EFFORT (observability)
                                                   not guaranteed to block in
                                                   all LlamaIndex versions

ARCHITECTURE NOTE for customers:
  - Use GovernedFunctionTool (or governed_function_tool() factory) for all
    tools registered with FunctionCallingAgentWorker / ReActAgent.
  - Use wrap_query_engine() / wrap_chat_engine() for top-level query gates.
  - Register GovernanceLlamaIndexCallback via CallbackManager for full audit
    coverage of LLM calls, agent steps, and retrievals.
  - For defense-in-depth, use all three layers together.

Action name namespace (for pack rule targeting):
  framework.llamaindex.query           -- query engine input check
  framework.llamaindex.tool_call       -- GovernedFunctionTool dispatch check
  framework.llamaindex.agent_step      -- callback on_event_start (AGENT_STEP)
  framework.llamaindex.chat_message    -- chat engine message check

Supported LlamaIndex version range (tested against mock primitives):
  llama-index-core >= 0.10.0
  llama-index >= 0.10.0

Architectural difference vs LangChain:
  LangChain tools implement _run() / _arun(). LlamaIndex FunctionTool exposes
  __call__() for sync and acall() for async. This module subclasses FunctionTool
  to override those dispatch points, mirroring the GovernedTool._run() pattern.

  LlamaIndex CallbackManager receives CBEventType enum values (FUNCTION_CALL,
  LLM, AGENT_STEP, RETRIEVE, etc.) rather than LangChain's named hook methods.
  This module uses on_event_start(event_type, payload) for the primary hook.

Optional peer dependencies:
  llama-index-core >= 0.10.0
  llama-index >= 0.10.0

@connexum/python-sdk -- Framework Adapter Layer (Sprint 5, WS-09)
"""

from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass
from typing import Any, Callable, Optional

from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations._wire_shape import build_check_action_body

# ---------------------------------------------------------------------------
# Type alias for check function injection (test isolation)
#
# Signature: async (governance_server_url: str, body: dict) -> dict
# Returns: {decision: ALLOW|DENY|REQUIRE_APPROVAL, reason, approvalId, auditId}
# ---------------------------------------------------------------------------

CheckFnType = Callable[[str, dict], Any]


# ---------------------------------------------------------------------------
# LlamaIndex type contracts (minimal interfaces, no hard import)
#
# These classes capture the shape of LlamaIndex primitives we interact with.
# They are intentionally minimal -- only the fields and methods our adapter
# uses. This avoids requiring llama-index as a hard dependency in the test
# environment and in SDK consumers that don't use LlamaIndex.
#
# When the real package is installed, these stubs are never used -- the real
# classes satisfy the duck-typing checks.
# ---------------------------------------------------------------------------

class _LlamaIndexFunctionToolBase:
    """
    Minimal protocol for LlamaIndex FunctionTool.

    The real FunctionTool (llama_index.core.tools.FunctionTool) exposes:
      - .metadata.name  (ToolMetadata.name)
      - .metadata.description
      - __call__(input: Any) -> ToolOutput
      - acall(input: Any) -> Awaitable[ToolOutput]
    """

    def __init__(self, fn: Callable, metadata: Any):
        self._fn = fn
        self.metadata = metadata

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._fn(*args, **kwargs)

    async def acall(self, *args: Any, **kwargs: Any) -> Any:
        if asyncio.iscoroutinefunction(self._fn):
            return await self._fn(*args, **kwargs)
        return self._fn(*args, **kwargs)


# ---------------------------------------------------------------------------
# HTTP check helpers (same pattern as langchain_integration.py)
# ---------------------------------------------------------------------------

def _do_check_sync(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """Run a synchronous governance check."""
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            try:
                asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(
                        lambda: asyncio.run(check_fn(governance_server_url, body))
                    )
                    return future.result()
            except RuntimeError:
                return asyncio.run(check_fn(governance_server_url, body))
        else:
            return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        with _httpx.Client(timeout=5.0) as client:
            resp = client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


async def _do_check_async(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """Run an asynchronous governance check."""
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            return await check_fn(governance_server_url, body)
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        async with _httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


# ---------------------------------------------------------------------------
# Decision enforcement helper
# ---------------------------------------------------------------------------

def _enforce_decision(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
) -> None:
    """
    Inspect a governance check result and raise on DENY / REQUIRE_APPROVAL.

    Args:
        result: Raw check result dict (decision, reason, approvalId, auditId).
        context_label: Human-readable label for error messages.
        raise_on_deny: Whether to raise exceptions. If False, log to stderr only.

    Raises:
        GovernanceViolation: decision is DENY (and raise_on_deny=True).
        GovernancePendingApproval: decision is REQUIRE_APPROVAL (and raise_on_deny=True).
    """
    decision = result.get("decision", "ALLOW")

    if decision == "DENY":
        reason = result.get("reason") or "policy"
        sys.stderr.write(
            f"[GovernanceLlamaIndexCallback] DENIED for '{context_label}'. reason={reason}\n"
        )
        if raise_on_deny:
            raise GovernanceViolation(
                decision="DENY",
                reason=reason,
                audit_id=result.get("auditId"),
            )
        return

    if decision == "REQUIRE_APPROVAL":
        approval_id = result.get("approvalId")
        audit_id = result.get("auditId")
        if not approval_id:
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                    audit_id=audit_id,
                )
            return
        sys.stderr.write(
            f"[GovernanceLlamaIndexCallback] PENDING for '{context_label}'. "
            f"approvalId={approval_id}\n"
        )
        if raise_on_deny:
            raise GovernancePendingApproval(
                approval_id=approval_id,
                audit_id=audit_id,
            )

    # ALLOW -- fall through


# ---------------------------------------------------------------------------
# GovernanceLlamaIndexCallback
#
# Registers with CallbackManager for observability + defense-in-depth.
#
# BLOCKING CONTRACT: Best-effort. LlamaIndex may catch exceptions from
# on_event_start in some code paths (depends on version and component).
# This is an OBSERVABILITY hook with secondary blocking. Use
# GovernedFunctionTool for guaranteed blocking at tool dispatch.
# ---------------------------------------------------------------------------

class GovernanceLlamaIndexCallback:
    """
    LlamaIndex CallbackManager handler that enforces governance policy.

    Implements the LlamaIndex BaseCallbackHandler duck-type interface.
    Can be passed to CallbackManager.add_handler() or used in
    Settings.callback_manager.

    BLOCKING CONTRACT:
      Raises GovernanceViolation on DENY (when raise_on_deny=True).
      Whether LlamaIndex respects these raises depends on the component
      firing the event and the LlamaIndex version. This is OBSERVABILITY
      and defense-in-depth, NOT the primary guaranteed blocking gate.
      Use GovernedFunctionTool for guaranteed blocking.

    Usage:
        from connexum_governance.integrations.llama_index_integration import (
            GovernanceLlamaIndexCallback,
        )
        from llama_index.core.callbacks import CallbackManager

        callback = GovernanceLlamaIndexCallback(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )
        callback_manager = CallbackManager([callback])
    """

    event_starts_to_amend: list = []
    event_ends_to_amend: list = []

    def __init__(
        self,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        """
        Args:
            governance_server_url: URL of the governance server.
            license_key: License / JWT key for the governance server.
            pack_ids: Compliance pack IDs to evaluate against.
            raise_on_deny: When True (default), DENY raises GovernanceViolation.
                When False, violations are logged to stderr but not raised.
                IMPORTANT: Even with raise_on_deny=True, LlamaIndex may swallow
                exceptions in some code paths. Use GovernedFunctionTool for
                guaranteed blocking. See BLOCKING CONTRACT in module header.
            _check_fn: Test injection hook. Not part of public API.
        """
        if not governance_server_url:
            raise ValueError(
                "[GovernanceLlamaIndexCallback] governance_server_url is required"
            )
        if not license_key:
            raise ValueError(
                "[GovernanceLlamaIndexCallback] license_key is required"
            )

        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._check_fn = _check_fn

    def _check_sync(self, body: dict) -> dict:
        return _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=body,
            check_fn=self._check_fn,
        )

    def on_event_start(
        self,
        event_type: Any,
        payload: Optional[dict] = None,
        event_id: str = "",
        parent_id: str = "",
        **kwargs: Any,
    ) -> str:
        """
        Fires before a LlamaIndex event (LLM call, agent step, tool call, retrieval).

        Runs governance check with action namespace based on event_type.
        On DENY, raises GovernanceViolation (if raise_on_deny=True).
        On PENDING, raises GovernancePendingApproval (if raise_on_deny=True).

        BLOCKING CONTRACT: Best-effort. Some LlamaIndex code paths wrap
        on_event_start calls in try/except. Use GovernedFunctionTool for
        guaranteed tool-level blocking.

        Args:
            event_type: LlamaIndex CBEventType (FUNCTION_CALL, LLM, AGENT_STEP,
                RETRIEVE, etc.) or string equivalent.
            payload: Dict with event-specific data (function name, query, etc.).
            event_id: Event ID assigned by the CallbackManager.
            parent_id: Parent event ID for nested events.
        """
        event_type_str = str(event_type)
        payload = payload or {}

        # Map LlamaIndex event types to governance action namespaces
        if "FUNCTION_CALL" in event_type_str or "function_call" in event_type_str.lower():
            action = "framework.llamaindex.tool_call"
            tool_name = payload.get("function_call", payload.get("name", "unknown"))
        elif "AGENT_STEP" in event_type_str or "agent_step" in event_type_str.lower():
            action = "framework.llamaindex.agent_step"
            tool_name = payload.get("step_type", "agent_step")
        elif "RETRIEVE" in event_type_str or "retrieve" in event_type_str.lower():
            action = "framework.llamaindex.query"
            tool_name = payload.get("query_str", "retrieve")
        else:
            # LLM, CHUNKING, NODE_PARSING, etc. -- default to agent_step namespace
            action = "framework.llamaindex.agent_step"
            tool_name = event_type_str

        message_preview = str(payload.get("query_str") or payload.get("input") or "")[:200]

        result = self._check_sync(build_check_action_body(
            tool_name=str(tool_name)[:100] or "unknown",
            agent_name="llamaindex-callback-handler",
            framework_action=action,
            message_preview=message_preview,
            pack_ids=self._pack_ids,
            extra_metadata={
                "eventType": event_type_str,
                "eventId": event_id,
            },
            source="on_event_start",
        ))

        _enforce_decision(result, str(tool_name), self._raise_on_deny)
        return event_id

    def on_event_end(
        self,
        event_type: Any,
        payload: Optional[dict] = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        """
        Fires after a LlamaIndex event completes. Logs to audit chain; does NOT raise.

        This is an observability hook. Governance violations at event-end are
        reported to stderr but the event output is not blocked (already completed).
        """
        event_type_str = str(event_type)
        sys.stderr.write(
            f"[GovernanceLlamaIndexCallback] event_end. "
            f"event_type={event_type_str} event_id={event_id}\n"
        )

    def start_trace(self, trace_id: Optional[str] = None) -> None:
        """Called when a trace starts. Passthrough for compat."""
        pass

    def end_trace(
        self,
        trace_id: Optional[str] = None,
        trace_map: Optional[dict] = None,
    ) -> None:
        """Called when a trace ends. Passthrough for compat."""
        pass


# ---------------------------------------------------------------------------
# GovernedFunctionTool -- GUARANTEED BLOCKING PRIMITIVE
#
# Subclasses LlamaIndex FunctionTool to override __call__ and acall.
# This runs governance check INSIDE the tool dispatch path, regardless of
# which agent worker (FunctionCallingAgentWorker, ReActAgent) or runner
# triggers the tool call.
# ---------------------------------------------------------------------------

class GovernedFunctionTool:
    """
    LlamaIndex FunctionTool wrapper that intercepts __call__ and acall with
    governance checks BEFORE delegating to the underlying function.

    This is the GUARANTEED BLOCKING PRIMITIVE for LlamaIndex tool calls.
    Unlike the CallbackManager (which LlamaIndex may swallow), wrapping
    __call__ / acall ensures governance runs regardless of which agent worker
    or executor is in use.

    The returned object exposes:
      - .metadata.name       -- tool name (from underlying tool)
      - .metadata.description -- tool description
      - __call__(*args)       -- governed sync dispatch
      - acall(*args)          -- governed async dispatch

    Usage:
        from connexum_governance.integrations.llama_index_integration import (
            governed_function_tool,
        )

        raw_tool = FunctionTool.from_defaults(fn=my_fn, name="search")
        safe_tool = governed_function_tool(
            tool=raw_tool,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
        )
        agent = ReActAgent.from_tools([safe_tool], ...)
    """

    def __init__(
        self,
        tool: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        if tool is None:
            raise ValueError("[GovernedFunctionTool] tool is required")

        # Extract tool name from metadata (LlamaIndex FunctionTool pattern)
        metadata = getattr(tool, "metadata", None)
        if metadata is not None:
            tool_name = getattr(metadata, "name", None) or getattr(metadata, "fn_name", None)
            tool_description = getattr(metadata, "description", "") or ""
        else:
            # Fallback: tool may expose .name directly (duck-typing)
            tool_name = getattr(tool, "name", None)
            tool_description = getattr(tool, "description", "") or ""

        if not tool_name:
            raise ValueError(
                "[GovernedFunctionTool] tool.metadata.name (or tool.name) is required"
            )
        if not governance_server_url:
            raise ValueError("[GovernedFunctionTool] governance_server_url is required")
        if not license_key:
            raise ValueError("[GovernedFunctionTool] license_key is required")

        self._underlying = tool
        self.metadata = _ToolMetadataProxy(name=tool_name, description=tool_description)
        self.name = tool_name
        self.description = tool_description
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._check_fn = _check_fn

    def _build_check_body(self, input_str: str, source: str = "GovernedFunctionTool.__call__") -> dict:
        return build_check_action_body(
            tool_name=self.name,
            agent_name=f"llamaindex-tool:{self.name}",
            framework_action="framework.llamaindex.tool_call",
            input_dict={"input": input_str},
            message_preview=input_str[:200],
            pack_ids=self._pack_ids,
            extra_metadata={"toolName": self.name, "inputPreview": input_str[:200]},
            source=source,
        )

    def _normalize_input(self, args: tuple, kwargs: dict) -> str:
        """Normalize args/kwargs to a string for governance check."""
        if args:
            return str(args[0]) if not isinstance(args[0], str) else args[0]
        if kwargs:
            import json as _json
            return _json.dumps(kwargs)
        return ""

    def _apply_decision(self, result: dict, input_str: str) -> Optional[str]:
        """
        Apply governance decision. Raises on DENY/PENDING (raise_on_deny=True).
        Returns a denial string on DENY (raise_on_deny=False).
        Returns None on ALLOW (caller proceeds to delegate).

        Returns:
            None on ALLOW (proceed to delegate).
            A '[GOVERNANCE DENIED]' or '[GOVERNANCE PENDING]' string when
            raise_on_deny=False and decision is DENY or PENDING_NO_ID.
            Raises on DENY/PENDING when raise_on_deny=True.
        """
        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "Tool call denied by governance policy"
            sys.stderr.write(
                f"[GovernedFunctionTool:{self.name}] __call__ DENIED. reason={reason}\n"
            )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return f"[GOVERNANCE DENIED] {reason}"

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
                return "[GOVERNANCE PENDING] Approval required but no approvalId returned"
            sys.stderr.write(
                f"[GovernedFunctionTool:{self.name}] __call__ PENDING. "
                f"approvalId={approval_id}\n"
            )
            if self._raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )
            return f"[GOVERNANCE PENDING] approvalId={approval_id}"

        # ALLOW -- return None (caller proceeds to delegate)
        return None

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """
        Governed sync dispatch. Runs governance check before calling underlying tool.

        DENY -> raises GovernanceViolation (guaranteed blocking).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying tool.__call__().

        This is the GUARANTEED BLOCKING PRIMITIVE for sync tool invocations.
        """
        input_str = self._normalize_input(args, kwargs)
        result = _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=self._build_check_body(input_str),
            check_fn=self._check_fn,
        )

        denial_result = self._apply_decision(result, input_str)
        if denial_result is not None:
            return denial_result

        # ALLOW -- delegate to underlying tool
        underlying_call = getattr(self._underlying, "__call__", None)
        if underlying_call is not None:
            return underlying_call(*args, **kwargs)
        raise AttributeError(
            f"[GovernedFunctionTool] Underlying tool '{self.name}' has no __call__ method"
        )

    async def acall(self, *args: Any, **kwargs: Any) -> Any:
        """
        Governed async dispatch. Runs governance check before calling underlying tool.

        DENY -> raises GovernanceViolation (guaranteed blocking).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying tool.acall() or __call__().

        This is the GUARANTEED BLOCKING PRIMITIVE for async tool invocations.
        """
        input_str = self._normalize_input(args, kwargs)
        result = await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=self._build_check_body(input_str, source="GovernedFunctionTool.acall"),
            check_fn=self._check_fn,
        )

        denial_result = self._apply_decision(result, input_str)
        if denial_result is not None:
            return denial_result

        # ALLOW -- delegate to underlying tool
        underlying_acall = getattr(self._underlying, "acall", None)
        if underlying_acall is not None:
            if asyncio.iscoroutinefunction(underlying_acall):
                return await underlying_acall(*args, **kwargs)
            return underlying_acall(*args, **kwargs)

        underlying_call = getattr(self._underlying, "__call__", None)
        if underlying_call is not None:
            if asyncio.iscoroutinefunction(underlying_call):
                return await underlying_call(*args, **kwargs)
            return underlying_call(*args, **kwargs)

        raise AttributeError(
            f"[GovernedFunctionTool] Underlying tool '{self.name}' has no acall() or __call__"
        )


@dataclass
class _ToolMetadataProxy:
    """Minimal proxy for LlamaIndex ToolMetadata."""
    name: str
    description: str = ""


# ---------------------------------------------------------------------------
# governed_function_tool -- convenience factory
# ---------------------------------------------------------------------------

def governed_function_tool(
    tool: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedFunctionTool:
    """
    Factory function to create a GovernedFunctionTool wrapping any LlamaIndex tool.

    The returned GovernedFunctionTool intercepts __call__ and acall with
    governance checks before delegating to the underlying function. This is the
    GUARANTEED BLOCKING PRIMITIVE for LlamaIndex tool calls.

    Args:
        tool: Any LlamaIndex tool with .metadata.name and .__call__().
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedFunctionTool wrapping the provided tool.
    """
    return GovernedFunctionTool(
        tool=tool,
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )


# ---------------------------------------------------------------------------
# wrap_query_engine -- query-level governance gate
# ---------------------------------------------------------------------------

def wrap_query_engine(
    engine: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wrap a LlamaIndex QueryEngine so that query() runs a governance check on
    the input query string BEFORE any retrieval or LLM call.

    Returns a GovernedQueryEngineProxy wrapping the original engine. The proxy
    exposes .query() and .aquery() with governance checks.

    BLOCKING CONTRACT: GUARANTEED at query entry point. Governance check runs
    before any retrieval, chunking, or LLM call. On DENY, the query is blocked
    before any data is accessed.

    Usage:
        from connexum_governance.integrations.llama_index_integration import (
            wrap_query_engine,
        )

        engine = index.as_query_engine()
        governed_engine = wrap_query_engine(
            engine,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
        )
        response = governed_engine.query("What are the HIPAA requirements?")

    Args:
        engine: LlamaIndex QueryEngine (or any object with .query() method).
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedQueryEngineProxy wrapping the original engine.
    """
    return GovernedQueryEngineProxy(
        engine=engine,
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )


class GovernedQueryEngineProxy:
    """
    Proxy wrapping a LlamaIndex QueryEngine with pre-query governance checks.

    Exposes .query() and .aquery() with governance enforcement.
    BLOCKING CONTRACT: GUARANTEED at query entry point.
    """

    def __init__(
        self,
        engine: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        if engine is None:
            raise ValueError("[GovernedQueryEngineProxy] engine is required")
        if not governance_server_url:
            raise ValueError("[GovernedQueryEngineProxy] governance_server_url is required")
        if not license_key:
            raise ValueError("[GovernedQueryEngineProxy] license_key is required")

        self._engine = engine
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._check_fn = _check_fn

    def query(self, query_str: str, **kwargs: Any) -> Any:
        """
        Run governance check on query_str, then delegate to engine.query().

        DENY -> raises GovernanceViolation before any retrieval.
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying engine.query().
        """
        result = _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name="query_engine",
                agent_name="llamaindex-query-engine",
                framework_action="framework.llamaindex.query",
                input_dict={"query": str(query_str)},
                message_preview=str(query_str)[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"queryPreview": str(query_str)[:200]},
                source="wrap_query_engine",
            ),
            check_fn=self._check_fn,
        )

        _enforce_decision(result, "query_engine", self._raise_on_deny)

        # ALLOW -- delegate to underlying engine
        return self._engine.query(query_str, **kwargs)

    async def aquery(self, query_str: str, **kwargs: Any) -> Any:
        """Async version of query(). Same governance gate, then async delegation."""
        result = await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name="query_engine",
                agent_name="llamaindex-query-engine",
                framework_action="framework.llamaindex.query",
                input_dict={"query": str(query_str)},
                message_preview=str(query_str)[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"queryPreview": str(query_str)[:200]},
                source="wrap_query_engine.aquery",
            ),
            check_fn=self._check_fn,
        )

        _enforce_decision(result, "query_engine", self._raise_on_deny)

        # ALLOW -- delegate to underlying engine
        aquery = getattr(self._engine, "aquery", None)
        if aquery is not None:
            return await aquery(query_str, **kwargs)
        return self._engine.query(query_str, **kwargs)


# ---------------------------------------------------------------------------
# wrap_chat_engine -- chat message governance gate
# ---------------------------------------------------------------------------

def wrap_chat_engine(
    engine: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wrap a LlamaIndex ChatEngine so that chat() runs a governance check on
    each message BEFORE any retrieval or LLM call.

    Returns a GovernedChatEngineProxy wrapping the original engine.

    BLOCKING CONTRACT: GUARANTEED at chat message entry point.

    Args:
        engine: LlamaIndex ChatEngine (or any object with .chat() method).
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedChatEngineProxy wrapping the original engine.
    """
    return GovernedChatEngineProxy(
        engine=engine,
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )


class GovernedChatEngineProxy:
    """
    Proxy wrapping a LlamaIndex ChatEngine with pre-message governance checks.

    Exposes .chat() and .achat() with governance enforcement.
    BLOCKING CONTRACT: GUARANTEED at message entry point.
    """

    def __init__(
        self,
        engine: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        if engine is None:
            raise ValueError("[GovernedChatEngineProxy] engine is required")
        if not governance_server_url:
            raise ValueError("[GovernedChatEngineProxy] governance_server_url is required")
        if not license_key:
            raise ValueError("[GovernedChatEngineProxy] license_key is required")

        self._engine = engine
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._check_fn = _check_fn

    def chat(self, message: str, **kwargs: Any) -> Any:
        """
        Run governance check on message, then delegate to engine.chat().

        DENY -> raises GovernanceViolation before any retrieval.
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying engine.chat().
        """
        result = _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name="chat_engine",
                agent_name="llamaindex-chat-engine",
                framework_action="framework.llamaindex.chat_message",
                input_dict={"message": str(message)},
                message_preview=str(message)[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"messagePreview": str(message)[:200]},
                source="wrap_chat_engine",
            ),
            check_fn=self._check_fn,
        )

        _enforce_decision(result, "chat_engine", self._raise_on_deny)

        return self._engine.chat(message, **kwargs)

    async def achat(self, message: str, **kwargs: Any) -> Any:
        """Async version of chat(). Same governance gate, then async delegation."""
        result = await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name="chat_engine",
                agent_name="llamaindex-chat-engine",
                framework_action="framework.llamaindex.chat_message",
                input_dict={"message": str(message)},
                message_preview=str(message)[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"messagePreview": str(message)[:200]},
                source="wrap_chat_engine.achat",
            ),
            check_fn=self._check_fn,
        )

        _enforce_decision(result, "chat_engine", self._raise_on_deny)

        achat = getattr(self._engine, "achat", None)
        if achat is not None:
            return await achat(message, **kwargs)
        return self._engine.chat(message, **kwargs)


# ---------------------------------------------------------------------------
# wrap_agent_worker -- agent worker governance gate
# ---------------------------------------------------------------------------

def wrap_agent_worker(
    worker: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Inject governance into a LlamaIndex agent worker by:
      1. Attaching a GovernanceLlamaIndexCallback to the worker's callback manager.
      2. Wrapping all tools registered on the worker with GovernedFunctionTool.

    Returns the same worker with governance wired.

    BLOCKING CONTRACT: Per-tool blocking via GovernedFunctionTool (GUARANTEED).
    Callback injection provides defense-in-depth.

    Args:
        worker: LlamaIndex agent worker (FunctionCallingAgentWorker, ReActAgent, etc.)
            with .tools attribute and optional .callback_manager attribute.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same worker with GovernedFunctionTool wrapping on all tools.
    """
    callback = GovernanceLlamaIndexCallback(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )

    # Inject callback into worker's callback_manager if it has one
    callback_manager = getattr(worker, "callback_manager", None)
    if callback_manager is not None:
        handlers = getattr(callback_manager, "handlers", None)
        if handlers is not None:
            already_injected = any(
                isinstance(h, GovernanceLlamaIndexCallback) for h in handlers
            )
            if not already_injected:
                handlers.append(callback)
        elif hasattr(callback_manager, "add_handler"):
            callback_manager.add_handler(callback)

    # Wrap all tools on the worker with GovernedFunctionTool
    tools = getattr(worker, "tools", None)
    if tools is not None:
        governed_tools = []
        for tool in tools:
            # Skip tools already wrapped
            if isinstance(tool, GovernedFunctionTool):
                governed_tools.append(tool)
            else:
                try:
                    governed_tools.append(
                        GovernedFunctionTool(
                            tool=tool,
                            governance_server_url=governance_server_url,
                            license_key=license_key,
                            pack_ids=pack_ids,
                            raise_on_deny=raise_on_deny,
                            _check_fn=_check_fn,
                        )
                    )
                except (ValueError, AttributeError):
                    # Tool missing required attributes -- keep unwrapped, log warning
                    sys.stderr.write(
                        f"[wrap_agent_worker] Could not wrap tool {tool!r} "
                        f"-- missing metadata.name. Keeping unwrapped.\n"
                    )
                    governed_tools.append(tool)

        worker.tools = governed_tools

    return worker


# ---------------------------------------------------------------------------
# create_governed_llama_index -- primary public factory namespace
# ---------------------------------------------------------------------------

@dataclass
class GovernedLlamaIndexInstance:
    """
    Governed LlamaIndex object returned by create_governed_llama_index.

    Exposes all integration helpers for the LlamaIndex framework adapter.
    """

    callback: "GovernanceLlamaIndexCallback"
    """
    Drop-in GovernanceLlamaIndexCallback for CallbackManager registration.
    Provides observability + best-effort blocking.
    See BLOCKING CONTRACT in module header.
    """

    _governance_server_url: str
    _license_key: str
    _pack_ids: list
    _raise_on_deny: bool
    _check_fn: Optional[CheckFnType]

    def governed_tool(self, tool: Any) -> GovernedFunctionTool:
        """
        Wrap a single LlamaIndex tool with governance on __call__ / acall.
        GUARANTEED BLOCKING: governance check runs before tool execution.
        """
        return GovernedFunctionTool(
            tool=tool,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_query_engine(self, engine: Any) -> GovernedQueryEngineProxy:
        """
        Wrap a QueryEngine with pre-query governance gate.
        GUARANTEED BLOCKING before any retrieval.
        """
        return wrap_query_engine(
            engine=engine,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_chat_engine(self, engine: Any) -> GovernedChatEngineProxy:
        """
        Wrap a ChatEngine with per-message governance gate.
        GUARANTEED BLOCKING before any retrieval.
        """
        return wrap_chat_engine(
            engine=engine,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_agent_worker(self, worker: Any) -> Any:
        """
        Inject governance into an agent worker.
        Wraps all tools + injects callback for defense-in-depth.
        """
        return wrap_agent_worker(
            worker=worker,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )


def create_governed_llama_index(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedLlamaIndexInstance:
    """
    Primary factory for the LlamaIndex governance adapter.

    Returns a GovernedLlamaIndexInstance exposing all integration helpers.

    Usage:
        gov = create_governed_llama_index(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        # Option 1 (guaranteed blocking): wrap individual tools
        safe_tool = gov.governed_tool(my_tool)
        agent = ReActAgent.from_tools([safe_tool], ...)

        # Option 2 (query-level gate): wrap the query engine
        governed_engine = gov.wrap_query_engine(index.as_query_engine())
        response = governed_engine.query("What are the retention requirements?")

        # Option 3 (chat-level gate): wrap the chat engine
        governed_chat = gov.wrap_chat_engine(index.as_chat_engine())
        response = governed_chat.chat("Summarize the HIPAA policy.")

        # Option 4 (defense-in-depth): register callback for audit coverage
        callback_manager = CallbackManager([gov.callback])

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedLlamaIndexInstance with all integration helpers.
    """
    callback = GovernanceLlamaIndexCallback(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )

    return GovernedLlamaIndexInstance(
        callback=callback,
        _governance_server_url=governance_server_url,
        _license_key=license_key,
        _pack_ids=pack_ids or [],
        _raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )
