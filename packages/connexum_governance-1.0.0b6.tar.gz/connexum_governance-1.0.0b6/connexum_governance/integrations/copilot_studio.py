"""Microsoft Copilot Studio governance integration.

Microsoft Copilot Studio is a low-code agent builder inside Microsoft's Power
Platform ecosystem. It is DISTINCT from GitHub Copilot (autocomplete) and M365
Copilot (productivity assistant). Copilot Studio lets business analysts, IT
admins, and citizen developers build organization-specific copilots and agents
using natural-language descriptions, topic graphs, Power Automate flows, custom
connectors, MCP servers, and knowledge sources.

Target users: non-developers with elevated organizational trust. A Copilot
Studio agent can be published to Microsoft Teams, M365 Copilot, the public web,
or custom channels -- giving it organizational-grade reach from a low-code
interface.

Architecture:
  The primary adapter is TypeScript-native (src/ide-adapters/copilot-studio.ts).
  This Python shim lets a Python-hosted governance policy server participate
  in the Copilot Studio decision loop via HTTP.

  Eight distinct governable surfaces (parity with TS adapter):
    intercept_agent_build(request)              -- agent description + owner gate
    intercept_topic_creation(request)           -- new topic gate (audited)
    intercept_action_definition(request)        -- action body egress scan
    intercept_connector_add(request)            -- connector allowlist enforcement
    intercept_knowledge_source_add(request)     -- knowledge source type gate
    intercept_publish(request)                  -- channel publish gate
    intercept_governance_center_policy(request) -- admin-only policy gate
    intercept_chat_test(request)                -- test chat secret scan

  Deployment modes:
    copilot-studio-cloud       -- standard commercial cloud (default)
    copilot-studio-government  -- GCC / GCC-High / DoD; strict data residency;
                                  public-web channel and public-website knowledge
                                  sources denied unconditionally; connectors
                                  restricted to Microsoft-internal allow-list.
    copilot-studio-sovereign   -- regulated-industry sovereign cloud; all
                                  government restrictions PLUS Governance Center
                                  policy changes require admin approval.

  Government / sovereign safeguards (the differentiators):
    - intercept_publish: government/sovereign mode blocks 'public-web' channel.
    - intercept_connector_add: government mode blocks non-Microsoft connectors
      unless allowlisted.
    - intercept_knowledge_source_add: government/sovereign mode blocks
      'public-website' source.
    - intercept_action_definition: government mode blocks action bodies
      referencing URLs outside allowed_connector_prefixes.
    - intercept_governance_center_policy: sovereign mode requires admin approval.

  Agent build gate:
    REQUIRES non-empty agent_description AND agent_owner. Denied with reason
    codes copilot-studio-agent-description-required /
    copilot-studio-agent-owner-required otherwise.

  Publish gate:
    Government/sovereign: 'public-web' ALWAYS denied
    (copilot-studio-public-channel-not-permitted-government).
    Sovereign: non-public-web channels also require
    require_governance_center_approval=True
    (copilot-studio-publish-requires-governance-approval).

  Governance Center policy gate:
    Requires user_role='admin' AND (require_governance_center_approval=True
    OR sovereign mode MUST have it set).
    Non-admin denied with copilot-studio-admin-only.
    Sovereign without flag denied with
    copilot-studio-governance-center-approval-required.

  Knowledge source gate:
    Government/sovereign: 'public-website' unconditionally denied.
    If allowed_knowledge_sources configured: only listed types allowed.

  Connector add gate:
    Government/sovereign: connectors outside allowed_connector_prefixes
    (default: Microsoft-only) denied.
    Connectors with public-internet egress prefixes denied unless allowlisted.

  Action definition gate:
    Government/sovereign: embedded URLs with non-Microsoft / non-allowlisted
    hosts denied (copilot-studio-action-egress-not-permitted).

  Pen-test IDs (mirrored from TS adapter):
    PT-ADAPT-COPILOTSTUDIO-1: empty pack_binding denied (pack-binding primacy)
    PT-ADAPT-COPILOTSTUDIO-2: tenant secrets / connection strings never appear
                               in audit entries or decision reason text
    PT-ADAPT-COPILOTSTUDIO-3: invalid deployment_mode raises ValueError;
                               conflicting tenant_tier vs deployment_mode raises ValueError
    PT-ADAPT-COPILOTSTUDIO-4: government/sovereign mode publish to public-web ALWAYS
                               denied with copilot-studio-public-channel-not-permitted-government
    PT-ADAPT-COPILOTSTUDIO-5: sovereign mode without admin approval ALWAYS denied
                               for governance-center policy changes
    PT-ADAPT-COPILOTSTUDIO-6: action definition egress URL outside allowlist in
                               government mode denied with
                               copilot-studio-action-egress-not-permitted

BAA-eligible deployment modes:
  copilot-studio-government (GCC-High / DoD BAA path)
  copilot-studio-sovereign  (regulated-industry sovereign cloud BAA)

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.copilot_studio import CopilotStudioGovernedClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = CopilotStudioGovernedClient(
        client=gov,
        agent_name="copilot-studio-01",
        pack_binding=["hipaa"],
        deployment_mode="copilot-studio-government",
        tenant_tier="gcc-high",
        data_residency_region="us-gov",
    )

    # Gate an agent build (description + owner required):
    decision = adapter.intercept_agent_build({
        "agentDescription": "HR onboarding assistant for new hires",
        "agentOwner": "hr-team@agency.gov",
        "packBinding": ["hipaa"],
    })

    # Gate a publish (public-web blocked in government mode):
    decision = adapter.intercept_publish({
        "channel": "teams",
        "packBinding": ["hipaa"],
    })

    # Gate a governance-center policy change (admin + approval required):
    decision = adapter.intercept_governance_center_policy({
        "policyName": "DataRetentionPolicy",
        "userRole": "admin",
        "packBinding": ["hipaa"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional
from urllib.parse import urlparse

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Deployment modes
# ---------------------------------------------------------------------------

COPILOT_STUDIO_VALID_DEPLOYMENT_MODES: tuple[str, ...] = (
    "copilot-studio-cloud",
    "copilot-studio-government",
    "copilot-studio-sovereign",
)

COPILOT_STUDIO_BAA_ELIGIBLE_MODES: tuple[str, ...] = (
    "copilot-studio-government",
    "copilot-studio-sovereign",
)

# ---------------------------------------------------------------------------
# Tenant tiers
# ---------------------------------------------------------------------------

COPILOT_STUDIO_VALID_TENANT_TIERS: tuple[str, ...] = (
    "commercial",
    "government",
    "gcc",
    "gcc-high",
    "dod",
    "sovereign",
)

COPILOT_STUDIO_GOVERNMENT_TENANT_TIERS: tuple[str, ...] = (
    "government",
    "gcc",
    "gcc-high",
    "dod",
)

# ---------------------------------------------------------------------------
# Channel types
# ---------------------------------------------------------------------------

COPILOT_STUDIO_VALID_CHANNELS: tuple[str, ...] = (
    "teams",
    "m365-copilot",
    "public-web",
    "custom",
)

# ---------------------------------------------------------------------------
# Knowledge source types
# ---------------------------------------------------------------------------

COPILOT_STUDIO_VALID_KNOWLEDGE_SOURCE_TYPES: tuple[str, ...] = (
    "sharepoint",
    "dataverse",
    "public-website",
    "uploaded-file",
)

# ---------------------------------------------------------------------------
# Default connector allow-list for government / sovereign mode
# ---------------------------------------------------------------------------

COPILOT_STUDIO_GOVERNMENT_DEFAULT_CONNECTOR_PREFIXES: tuple[str, ...] = (
    "shared_sharepointonline",
    "shared_teams",
    "shared_office365",
    "shared_office365outlook",
    "shared_office365users",
    "shared_onedriveforbusiness",
    "shared_commondataserviceforapps",
    "shared_dynamicscrmonline",
    "shared_microsoftforms",
    "shared_planner",
    "shared_visualstudioteamservices",
    "shared_powerplatformforadmins",
)

# Connectors that imply public internet egress.
_INTERNET_EGRESS_CONNECTOR_PREFIXES: tuple[str, ...] = (
    "shared_twitter",
    "shared_facebook",
    "shared_instagram",
    "shared_linkedin",
    "shared_slack",
    "shared_github",
    "shared_googledrive",
    "shared_gmail",
    "shared_dropbox",
    "shared_box",
    "shared_servicenow",
    "shared_zendesk",
    "shared_salesforce",
    "shared_hubspot",
    "shared_stripe",
    "shared_twilio",
    "shared_sendgrid",
    "shared_mailchimp",
    "shared_airtable",
    "shared_notion",
    "shared_jira",
    "shared_confluence",
    "shared_googledocs",
    "shared_googletasks",
    "shared_googlemaps",
)

# ---------------------------------------------------------------------------
# Microsoft-managed domain suffixes
# ---------------------------------------------------------------------------

_MICROSOFT_MANAGED_SUFFIXES: tuple[str, ...] = (
    ".microsoft.com",
    ".azure.com",
    ".microsoftonline.com",
    ".sharepoint.com",
    ".office.com",
    ".teams.microsoft.com",
    ".dynamics.com",
    ".crm.dynamics.com",
    ".powerplatform.microsoft.com",
)


def _is_microsoft_managed_host(hostname: str) -> bool:
    """Return True if hostname is a Microsoft-managed domain."""
    h = hostname.lower()
    for suffix in _MICROSOFT_MANAGED_SUFFIXES:
        bare = suffix.lstrip(".")
        if h == bare or h.endswith(suffix):
            return True
    return False


# ---------------------------------------------------------------------------
# URL extraction helper (for action-body egress scan)
# ---------------------------------------------------------------------------

_URL_RE = re.compile(r"https?://([A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=%]+)", re.IGNORECASE)


def _extract_url_hosts(text: str) -> list[str]:
    """Extract unique lowercased hostnames from all http/https URLs in text."""
    if not text:
        return []
    hosts: set[str] = set()
    for match in _URL_RE.finditer(text):
        try:
            parsed = urlparse(f"https://{match.group(1)}")
            if parsed.hostname:
                hosts.add(parsed.hostname.lower())
        except Exception:
            pass
    return list(hosts)


# ---------------------------------------------------------------------------
# Secret patterns (PT-ADAPT-COPILOTSTUDIO-2)
# ---------------------------------------------------------------------------

_COPILOT_STUDIO_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("Azure connection string",   re.compile(r"AccountKey=[A-Za-z0-9+/=]{20,}")),
    ("Azure SAS token",           re.compile(r"sv=\d{4}-\d{2}-\d{2}&")),
    ("Azure AD client secret",    re.compile(r'clientSecret["\s]*[:=]["\s]*[A-Za-z0-9\-._~]{8,}')),
    ("Azure storage account",     re.compile(r"DefaultEndpointsProtocol=https;AccountName=")),
    ("Power Platform API key",    re.compile(r"powerplatform[_\-]?(key|secret|token)\s*[:=]\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("AWS access key",            re.compile(r"AKIA[0-9A-Z]{16}")),
    ("Generic API key env var",   re.compile(r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY)\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Bearer token",              re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
    ("Database URL with creds",   re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
]


def _scan_for_secrets(text: str) -> Optional[str]:
    """Return the pattern name of the first matched secret, or None."""
    if not text:
        return None
    for name, pattern in _COPILOT_STUDIO_SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


# ---------------------------------------------------------------------------
# Valid event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
    "policyViolation",
    "auditLog",
})


# ---------------------------------------------------------------------------
# CopilotStudioGovernedClient
# ---------------------------------------------------------------------------

class CopilotStudioGovernedClient(BaseGovernanceIntegration):
    """Python parity for CopilotStudioAdapter (TypeScript).

    Provides eight intercept_* methods matching the TS adapter's wrap methods:
      intercept_agent_build(request)
      intercept_topic_creation(request)
      intercept_action_definition(request)
      intercept_connector_add(request)
      intercept_knowledge_source_add(request)
      intercept_publish(request)
      intercept_governance_center_policy(request)
      intercept_chat_test(request)

    Each method checks pack_binding primacy (PT-ADAPT-COPILOTSTUDIO-1), then
    applies deployment-mode-specific enforcement logic before delegating to the
    governance REST API.

    Args:
        client: GovernanceClient instance (REST API connection).
        agent_name: Logical name of this adapter instance.
        pack_binding: Default pack bindings for this adapter.
        deployment_mode: One of COPILOT_STUDIO_VALID_DEPLOYMENT_MODES.
        tenant_tier: Optional tenant tier (must be compatible with deployment_mode).
        data_residency_region: Optional data residency region identifier.
        allowed_channels: Optional list of permitted publish channels.
        allowed_connector_prefixes: Optional connector id prefix allowlist.
        allowed_knowledge_sources: Optional knowledge source type allowlist.
        require_governance_center_approval: If True, Governance Center policy
            operations are permitted for admin users. Required True in
            sovereign mode.
    """

    _VALID_EVENT_TYPES = _VALID_EVENT_TYPES
    _FRAMEWORK_NAME = "copilot-studio"
    _LAYER_NAME = "copilot-studio-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        pack_binding: list[str],
        deployment_mode: str = "copilot-studio-cloud",
        tenant_tier: Optional[str] = None,
        data_residency_region: Optional[str] = None,
        allowed_channels: Optional[list[str]] = None,
        allowed_connector_prefixes: Optional[list[str]] = None,
        allowed_knowledge_sources: Optional[list[str]] = None,
        require_governance_center_approval: bool = False,
    ) -> None:
        super().__init__(client)
        self.agent_name = agent_name
        self.pack_binding = pack_binding
        self.data_residency_region = data_residency_region
        self.allowed_channels = allowed_channels
        self.allowed_connector_prefixes = allowed_connector_prefixes
        self.allowed_knowledge_sources = allowed_knowledge_sources
        self.require_governance_center_approval = require_governance_center_approval

        # Validate deployment_mode.
        if deployment_mode not in COPILOT_STUDIO_VALID_DEPLOYMENT_MODES:
            raise ValueError(
                f"CopilotStudioGovernedClient: invalid deployment_mode "
                f"'{deployment_mode}'. Must be one of: "
                f"{', '.join(COPILOT_STUDIO_VALID_DEPLOYMENT_MODES)}."
            )
        self.deployment_mode = deployment_mode

        # Validate tenant_tier if provided and check compatibility.
        if tenant_tier is not None:
            if tenant_tier not in COPILOT_STUDIO_VALID_TENANT_TIERS:
                raise ValueError(
                    f"CopilotStudioGovernedClient: invalid tenant_tier "
                    f"'{tenant_tier}'. Must be one of: "
                    f"{', '.join(COPILOT_STUDIO_VALID_TENANT_TIERS)}."
                )
            # PT-ADAPT-COPILOTSTUDIO-3: tenantTier must be compatible with deploymentMode.
            is_gov_tier = tenant_tier in COPILOT_STUDIO_GOVERNMENT_TENANT_TIERS
            is_sov_tier = tenant_tier == "sovereign"
            is_comm_tier = tenant_tier == "commercial"

            if is_gov_tier and deployment_mode != "copilot-studio-government":
                raise ValueError(
                    f"CopilotStudioGovernedClient: conflicting configuration -- "
                    f"tenant_tier '{tenant_tier}' is a government tier and requires "
                    f"deployment_mode 'copilot-studio-government'. "
                    f"Received deployment_mode: '{deployment_mode}'."
                )
            if is_sov_tier and deployment_mode != "copilot-studio-sovereign":
                raise ValueError(
                    f"CopilotStudioGovernedClient: conflicting configuration -- "
                    f"tenant_tier 'sovereign' requires deployment_mode "
                    f"'copilot-studio-sovereign'. "
                    f"Received deployment_mode: '{deployment_mode}'."
                )
            if is_comm_tier and deployment_mode != "copilot-studio-cloud":
                raise ValueError(
                    f"CopilotStudioGovernedClient: conflicting configuration -- "
                    f"tenant_tier 'commercial' requires deployment_mode "
                    f"'copilot-studio-cloud'. "
                    f"Received deployment_mode: '{deployment_mode}'."
                )
        self.tenant_tier = tenant_tier

    # ------------------------------------------------------------------
    # intercept_agent_build
    # ------------------------------------------------------------------

    def intercept_agent_build(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an agent build request.

        REQUIRES non-empty agent_description AND agent_owner. Both fields must
        be present for governance to evaluate and record the agent's intended
        purpose and organizational identity.

        Args:
            request: Agent build request dict with keys:
                     agentDescription, agentOwner, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-COPILOTSTUDIO-1: pack-binding primacy.
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Studio agent build request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        agent_description = str(
            request.get("agentDescription", request.get("description", ""))
        ).strip()
        agent_owner = str(
            request.get("agentOwner", request.get("owner", ""))
        ).strip()

        if not agent_description:
            return self._deny(
                agent_id,
                "Copilot Studio agent build denied: agentDescription is required for "
                "governance audit. Every agent must carry a non-empty description so "
                "the compliance system can evaluate and record the intended purpose. "
                "Reason code: copilot-studio-agent-description-required.",
                pack_binding=pack_binding,
                reason_code="copilot-studio-agent-description-required",
            )

        if not agent_owner:
            return self._deny(
                agent_id,
                "Copilot Studio agent build denied: agentOwner is required for "
                "governance audit. Tenant identity must be recorded for every "
                "agent build operation. "
                "Reason code: copilot-studio-agent-owner-required.",
                pack_binding=pack_binding,
                reason_code="copilot-studio-agent-owner-required",
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "copilot-studio:agent-build-requested",
            "args": {
                "agentDescription": agent_description[:200],
                "agentOwner": agent_owner,
                "deploymentMode": self.deployment_mode,
                "tenantTier": self.tenant_tier,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_topic_creation
    # ------------------------------------------------------------------

    def intercept_topic_creation(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a new conversational topic creation.

        Audited; no specific deny conditions beyond pack-binding primacy.

        Args:
            request: Topic creation request dict with keys:
                     topicName, topicDescription, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-COPILOTSTUDIO-1: pack-binding primacy.
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Studio topic creation request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        topic_name = str(request.get("topicName", request.get("name", ""))).strip()

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "copilot-studio:topic-creation-requested",
            "args": {
                "topicName": topic_name[:120],
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_action_definition (PT-ADAPT-COPILOTSTUDIO-6)
    # ------------------------------------------------------------------

    def intercept_action_definition(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an action/tool definition.

        In copilot-studio-government / copilot-studio-sovereign mode:
        scan action body for embedded URLs. Any URL host outside the
        allowed_connector_prefixes (default: Microsoft-managed) is denied.

        Args:
            request: Action definition request dict with keys:
                     actionName, actionBody, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-COPILOTSTUDIO-1: pack-binding primacy.
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Studio action definition request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        action_name = str(request.get("actionName", request.get("name", ""))).strip()
        action_body = str(request.get("actionBody", request.get("body", "")))
        is_restricted_mode = self.deployment_mode in (
            "copilot-studio-government", "copilot-studio-sovereign"
        )

        if is_restricted_mode and action_body:
            url_hosts = _extract_url_hosts(action_body)
            if url_hosts:
                effective_prefixes = self._effective_connector_prefixes()
                offending_hosts = [
                    h for h in url_hosts
                    if not _is_microsoft_managed_host(h)
                    and not any(
                        h == p or h.endswith(f".{p}") or p.endswith(h)
                        for p in effective_prefixes
                    )
                ]
                if offending_hosts:
                    return self._deny(
                        agent_id,
                        f"Copilot Studio action definition denied: action body contains "
                        f"URLs with hosts outside the allowed connector prefix list. "
                        f"Offending hosts: [{', '.join(offending_hosts[:5])}]. "
                        f"In {self.deployment_mode} mode, action bodies may not reference "
                        f"external internet hosts unless explicitly allowlisted via "
                        f"allowed_connector_prefixes. "
                        f"Reason code: copilot-studio-action-egress-not-permitted.",
                        pack_binding=pack_binding,
                        reason_code="copilot-studio-action-egress-not-permitted",
                    )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "copilot-studio:action-definition-requested",
            "args": {
                "actionName": action_name[:120],
                "deploymentMode": self.deployment_mode,
                "egressScanPerformed": is_restricted_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_connector_add
    # ------------------------------------------------------------------

    def intercept_connector_add(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a connector add operation.

        In copilot-studio-government / copilot-studio-sovereign mode:
        connectors NOT in the effective connector prefix allow-list are denied.
        Connectors with known public-internet egress prefixes are denied unless
        explicitly in allowed_connector_prefixes.

        Args:
            request: Connector add request dict with keys:
                     connectorId, connectorType, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-COPILOTSTUDIO-1: pack-binding primacy.
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Studio connector add request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        connector_id = str(request.get("connectorId", request.get("id", ""))).strip()
        connector_type = str(request.get("connectorType", request.get("type", ""))).strip()
        is_restricted_mode = self.deployment_mode in (
            "copilot-studio-government", "copilot-studio-sovereign"
        )

        if is_restricted_mode and connector_id:
            effective_prefixes = self._effective_connector_prefixes()
            is_allowed = any(connector_id.startswith(p) for p in effective_prefixes)

            if not is_allowed:
                is_egress_connector = any(
                    connector_id.startswith(p) for p in _INTERNET_EGRESS_CONNECTOR_PREFIXES
                )
                detail = (
                    f"connector '{connector_id}' implies public internet egress and is "
                    f"not in allowed_connector_prefixes"
                    if is_egress_connector
                    else f"connector '{connector_id}' is not in the allowed_connector_prefixes list"
                )
                return self._deny(
                    agent_id,
                    f"Copilot Studio connector add denied: {detail}. "
                    f"In {self.deployment_mode} mode, only connectors matching the "
                    f"allowed_connector_prefixes list are permitted. "
                    f"Reason code: copilot-studio-connector-not-permitted-government.",
                    pack_binding=pack_binding,
                    reason_code="copilot-studio-connector-not-permitted-government",
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "copilot-studio:connector-add-requested",
            "args": {
                "connectorId": connector_id,
                "connectorType": connector_type,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_knowledge_source_add
    # ------------------------------------------------------------------

    def intercept_knowledge_source_add(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a knowledge source add operation.

        Government/sovereign mode: 'public-website' source type is unconditionally
        denied (data residency requirement).
        If allowed_knowledge_sources configured: only listed source types allowed.

        Args:
            request: Knowledge source add request dict with keys:
                     sourceType, sourceUri, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-COPILOTSTUDIO-1: pack-binding primacy.
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Studio knowledge source add request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        source_type = str(request.get("sourceType", request.get("type", ""))).strip()
        is_restricted_mode = self.deployment_mode in (
            "copilot-studio-government", "copilot-studio-sovereign"
        )

        # Government/sovereign: public-website unconditionally denied.
        if is_restricted_mode and source_type == "public-website":
            return self._deny(
                agent_id,
                f"Copilot Studio knowledge source denied: 'public-website' source type "
                f"is not permitted in {self.deployment_mode} mode. "
                f"Public website knowledge sources would cause data to be fetched from the "
                f"public internet, violating data residency requirements. "
                f"Use SharePoint, Dataverse, or uploaded-file sources instead. "
                f"Reason code: copilot-studio-knowledge-source-public-website-not-permitted-government.",
                pack_binding=pack_binding,
                reason_code="copilot-studio-knowledge-source-public-website-not-permitted-government",
            )

        # allowed_knowledge_sources enforcement.
        if self.allowed_knowledge_sources and len(self.allowed_knowledge_sources) > 0:
            if source_type not in self.allowed_knowledge_sources:
                return self._deny(
                    agent_id,
                    f"Copilot Studio knowledge source denied: source type '{source_type}' "
                    f"is not in allowed_knowledge_sources "
                    f"[{', '.join(self.allowed_knowledge_sources)}]. "
                    f"Reason code: copilot-studio-knowledge-source-not-permitted.",
                    pack_binding=pack_binding,
                    reason_code="copilot-studio-knowledge-source-not-permitted",
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "copilot-studio:knowledge-source-add-requested",
            "args": {
                "sourceType": source_type,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_publish (PT-ADAPT-COPILOTSTUDIO-4)
    # ------------------------------------------------------------------

    def intercept_publish(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an agent publish operation.

        Government/sovereign mode: 'public-web' channel is ALWAYS denied.
        Sovereign mode: any publish requires require_governance_center_approval=True.
        If allowed_channels configured: only listed channels allowed.

        Args:
            request: Publish request dict with keys:
                     channel, version, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-COPILOTSTUDIO-1: pack-binding primacy.
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Studio publish request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        channel = str(request.get("channel", request.get("target", ""))).strip()
        is_government_mode = self.deployment_mode == "copilot-studio-government"
        is_sovereign_mode = self.deployment_mode == "copilot-studio-sovereign"

        # PT-ADAPT-COPILOTSTUDIO-4: government/sovereign -- public-web ALWAYS denied.
        if (is_government_mode or is_sovereign_mode) and channel == "public-web":
            return self._deny(
                agent_id,
                f"Copilot Studio publish denied: publishing to 'public-web' channel is "
                f"not permitted in {self.deployment_mode} mode. "
                f"Government and sovereign deployments may not expose agents to the public "
                f"internet via the web channel. This is an unconditional governance rule. "
                f"Reason code: copilot-studio-public-channel-not-permitted-government.",
                pack_binding=pack_binding,
                reason_code="copilot-studio-public-channel-not-permitted-government",
            )

        # Sovereign mode: any publish requires governance-center approval flag.
        if is_sovereign_mode and not self.require_governance_center_approval:
            return self._deny(
                agent_id,
                f"Copilot Studio publish denied: sovereign mode requires "
                f"require_governance_center_approval=True in adapter configuration. "
                f"Set require_governance_center_approval=True and obtain admin approval "
                f"before publishing in sovereign cloud environments. "
                f"Reason code: copilot-studio-publish-requires-governance-approval.",
                pack_binding=pack_binding,
                reason_code="copilot-studio-publish-requires-governance-approval",
            )

        # allowed_channels enforcement.
        if self.allowed_channels and len(self.allowed_channels) > 0:
            if channel not in self.allowed_channels:
                return self._deny(
                    agent_id,
                    f"Copilot Studio publish denied: channel '{channel}' is not in "
                    f"allowed_channels [{', '.join(self.allowed_channels)}]. "
                    f"Reason code: copilot-studio-channel-not-permitted.",
                    pack_binding=pack_binding,
                    reason_code="copilot-studio-channel-not-permitted",
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "copilot-studio:publish-requested",
            "args": {
                "channel": channel,
                "deploymentMode": self.deployment_mode,
                "tenantTier": self.tenant_tier,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_governance_center_policy (PT-ADAPT-COPILOTSTUDIO-5)
    # ------------------------------------------------------------------

    def intercept_governance_center_policy(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a Governance Center policy definition or update.

        Requires:
          1. user_role == 'admin' in request (non-admin always denied).
          2. require_governance_center_approval=True in config (or sovereign mode).

        Args:
            request: Policy request dict with keys:
                     policyName, policyBody, userRole, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-COPILOTSTUDIO-1: pack-binding primacy.
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Studio governance-center policy request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        policy_name = str(request.get("policyName", request.get("name", ""))).strip()
        user_role = str(request.get("userRole", request.get("role", ""))).strip()
        is_sovereign_mode = self.deployment_mode == "copilot-studio-sovereign"

        # PT-ADAPT-COPILOTSTUDIO-5: admin-only gate.
        if user_role != "admin":
            return self._deny(
                agent_id,
                f"Copilot Studio Governance Center policy operation denied: requires admin role. "
                f"Current role: '{user_role or 'not-set'}'. "
                f"Only tenant administrators may define or update Governance Center policies. "
                f"Reason code: copilot-studio-admin-only.",
                pack_binding=pack_binding,
                reason_code="copilot-studio-admin-only",
            )

        # PT-ADAPT-COPILOTSTUDIO-5: sovereign requires require_governance_center_approval.
        if is_sovereign_mode and not self.require_governance_center_approval:
            return self._deny(
                agent_id,
                f"Copilot Studio Governance Center policy operation denied: sovereign mode "
                f"requires require_governance_center_approval=True in adapter configuration. "
                f"Set require_governance_center_approval=True to permit admin governance-center "
                f"operations in sovereign cloud environments. "
                f"Reason code: copilot-studio-governance-center-approval-required.",
                pack_binding=pack_binding,
                reason_code="copilot-studio-governance-center-approval-required",
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "copilot-studio:governance-center-policy-requested",
            "args": {
                "policyName": policy_name[:120],
                "userRole": "admin",
                "deploymentMode": self.deployment_mode,
                "requireGovernanceCenterApproval": self.require_governance_center_approval,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_chat_test
    # ------------------------------------------------------------------

    def intercept_chat_test(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a design-canvas test conversation.

        Scans prompt text for secrets. PT-ADAPT-COPILOTSTUDIO-2: secret
        VALUES must never appear in audit entries or denial reasons.

        Args:
            request: Chat test request dict with keys:
                     promptText, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-COPILOTSTUDIO-1: pack-binding primacy.
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Studio chat test request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        prompt_text = str(request.get("promptText", request.get("prompt", "")))

        # Secret scan (PT-ADAPT-COPILOTSTUDIO-2: only pattern name in reason, not raw value).
        secret_match = _scan_for_secrets(prompt_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Copilot Studio chat test denied: secret pattern '{secret_match}' detected "
                f"in prompt. Test prompts must not contain credentials, connection strings, "
                f"or API keys. "
                f"Reason code: copilot-studio-chat-test-secret-detected.",
                pack_binding=pack_binding,
                reason_code="copilot-studio-chat-test-secret-detected",
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "copilot-studio:chat-test-requested",
            "args": {
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown CopilotStudioGovernedClient event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier: scan tool results for secrets.
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] CopilotStudioGovernedClient output classifier: possible "
                    f"secret in tool result \"{payload.get('toolName', 'unknown')}\" "
                    f"(agent: {agent_id}).",
                    file=sys.stderr,
                )

        # Inject deployment mode metadata.
        enriched = {
            "deploymentMode": self.deployment_mode,
            "tenantTier": self.tenant_tier,
            **payload,
        }
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # Convenience hook methods (canonical event surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _effective_connector_prefixes(self) -> tuple[str, ...]:
        """Resolve effective connector prefix allow-list.

        Government/sovereign: use configured list or default Microsoft-only list.
        Cloud: empty tuple (no connector restriction).
        """
        if self.allowed_connector_prefixes and len(self.allowed_connector_prefixes) > 0:
            return tuple(self.allowed_connector_prefixes)
        if self.deployment_mode in ("copilot-studio-government", "copilot-studio-sovereign"):
            return COPILOT_STUDIO_GOVERNMENT_DEFAULT_CONNECTOR_PREFIXES
        return ()

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
        reason_code: Optional[str] = None,
        require_approval: bool = False,
        extra: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Build a DENY (or REQUIRE_APPROVAL) GovernanceDecision."""
        from connexum_governance.models import GovernanceDecision, DecisionType
        decision_type = DecisionType.REQUIRE_APPROVAL if require_approval else DecisionType.DENY
        d = GovernanceDecision(
            decision=decision_type,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce and not require_approval:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# CopilotStudioPolicyBridge
# ---------------------------------------------------------------------------

class CopilotStudioPolicyBridge:
    """Bridge for Python-hosted policy participation in the Copilot Studio governance loop."""

    def __init__(
        self,
        adapter: CopilotStudioGovernedClient,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:
                import logging as _logging
                _logging.getLogger(__name__).warning(
                    "Governance audit operation failed: %s", exc
                )

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
