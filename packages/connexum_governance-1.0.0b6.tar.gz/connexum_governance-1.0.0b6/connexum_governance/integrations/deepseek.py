"""DeepSeek governance integration for Connexum governance.

Wraps DeepSeek API calls (OpenAI-compatible chat.completions endpoint
at api.deepseek.com) with pre-call governance checks.

BAA status: DeepSeek does NOT offer a BAA. Several Connexum compliance
packs (DORA, EU MDR/IVDR, US FDA 21 CFR 56, UK AI Framework, Illinois
AIVIA) explicitly block the 'deepseek' provider for jurisdictional /
PRC National Intelligence Law reasons. The gov-server enforces those
blocks via blockedProviders pack policy independently of this wrapper.

Closes F-NEW-CRIT-4 -- the README listed DeepSeek as a supported
platform but no Python wrapper existed.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.deepseek import DeepSeekGovernance

    gov = GovernanceClient(api_url="...", license_key="...")
    dg = DeepSeekGovernance(client=gov, agent_name="ds-agent")

    decision = dg.intercept_request({
        "model": "deepseek-chat",
        "messages": [{"role": "user", "content": "Hello"}],
    })
"""

from __future__ import annotations

from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
)

_PROVIDER_ID = "deepseek"
_BAA_AVAILABLE = False
_BAA_SCOPE = None
_BAA_NOTES = (
    "DeepSeek does not offer a BAA. Several Connexum compliance packs "
    "(DORA, EU MDR/IVDR, US FDA 21 CFR 56, UK AI Framework, Illinois AIVIA) "
    "block the 'deepseek' provider per blockedProviders pack policy."
)


class DeepSeekGovernance:
    """Governance wrapper for DeepSeek chat.completions.

    Does NOT depend on a deepseek SDK at import time. The DeepSeek API
    is OpenAI-compatible, so the request/response shape mirrors
    OpenAIGovernance.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)
        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        messages = request.get("messages", [])
        system_digest = ""
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "system":
                content = msg.get("content", "")
                if isinstance(content, str):
                    system_digest = content[:500]
                break
        tools = request.get("tools", [])
        tool_names = [
            t.get("function", {}).get("name", "")
            for t in tools
            if isinstance(t, dict)
        ]
        all_tool_names = list(filter(None, tool_names))

        gov_input: dict[str, Any] = {
            "provider": _PROVIDER_ID,
            "model": request.get("model", "unknown"),
            "maxTokens": request.get("max_tokens"),
            "systemPromptDigest": system_digest,
            "messageCount": len(messages),
            "toolCount": len(all_tool_names),
            "toolNames": all_tool_names,
        }
        return self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )

    def intercept_response(
        self,
        response: dict[str, Any],
        audit_id: str,
    ) -> ClassifiedResponse:
        return self.client.classify_output(
            audit_id=audit_id,
            output=response,
            agent=self.agent,
        )
