"""Haystack (deepset) integration for Connexum governance.

Hooks into the Haystack Pipeline lifecycle with six canonical governance
hook surfaces. Python-native: integrates with haystack-ai's Pipeline
component event system.

Haystack's framework is pipeline-based: agents are Nodes/Components
connected by Edges. The adapter hooks at the Pipeline execution boundary.

Hook surfaces (parity with src/orchestrator-adapters/haystack.ts):
  agentStart   -> pipelineStart: gate at pipeline start
  toolCall     -> nodeStart: pre-node governance check
  toolResult   -> nodeEnd: post-node G-series classification
  llmCall      -> promptNodeCall: pre-LLM backend governance check
  llmResult    -> promptNodeResult: post-LLM output classification
  agentEnd     -> pipelineEnd: terminal audit event sealing

Haystack-specific considerations:
  - Multiple backends per pipeline: each backend invocation is a distinct
    canonical event so provider-compliance checks fire per-backend.
  - Eval mode: eval-mode events write to a SEPARATE eval audit path.
    The evalStep() method surfaces eval metadata in dedicated audit events.
  - GDPR default: European deployment default -- GDPR pack is bound unless
    explicitly disabled.
  - Document retrieval: Retriever node results are classified for PHI
    at the ingress surface.

Lazy import: haystack-ai is NOT hard-required at import time.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.haystack import HaystackGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = HaystackGovernance(
        client=gov,
        approved_backends=["openai", "anthropic"],
        eval_audit_path="eval",
    )

    adapter.pipeline_start("pipeline-001", "rag_pipeline", pack_binding=["gdpr", "hipaa"])
    adapter.node_start("pipeline-001", "retriever", "Retriever", inputs={"query": "..."})
    adapter.node_end("pipeline-001", "retriever", "Retriever", outputs={"documents": [...]})
    adapter.prompt_node_call("pipeline-001", "generator", "openai", "gpt-4o", prompt="...")
    adapter.prompt_node_result("pipeline-001", "generator", "openai", result="Response...")
    adapter.pipeline_end("pipeline-001", success=True)
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


def _extract_text(obj: Any) -> str:
    """Recursively extract text content from Haystack result structures."""
    if isinstance(obj, str):
        return obj
    if isinstance(obj, dict):
        return " ".join(_extract_text(v) for v in obj.values())
    if isinstance(obj, list):
        return " ".join(_extract_text(item) for item in obj)
    return str(obj)


# ---------------------------------------------------------------------------
# HaystackGovernance
# ---------------------------------------------------------------------------

class HaystackGovernance:
    """Governance adapter for Haystack Pipelines (deepset).

    Hooks at the Pipeline execution boundary. Covers all six canonical
    governance event surfaces including the eval-mode audit path.

    Does NOT hard-depend on the haystack-ai package. All hook methods
    accept plain Python dicts so they can be called from any Haystack
    version or from tests without the SDK installed.
    """

    def __init__(
        self,
        client: GovernanceClient,
        approved_backends: Optional[list[str]] = None,
        sensitive_nodes: Optional[list[str]] = None,
        eval_audit_path: str = "eval",
        agent_name: str = "haystack-pipeline",
        default_pack_binding: Optional[list[str]] = None,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            approved_backends: LLM backend IDs allowed in PromptNode calls.
                               None means all backends permitted.
            sensitive_nodes: Node IDs requiring reviewer approval.
            eval_audit_path: Audit path tag for eval-mode events (distinct from
                             production chain per Haystack eval isolation).
            agent_name: Default agent identity name for audit events.
            default_pack_binding: Default pack binding when pipeline_start does
                                  not specify one. GDPR is recommended for EU.
        """
        self.client = client
        self.approved_backends = approved_backends
        self.sensitive_nodes = sensitive_nodes or []
        self.eval_audit_path = eval_audit_path
        self.agent_name = agent_name
        self.default_pack_binding = default_pack_binding or ["gdpr"]

        # pipeline_id -> state
        self._pipelines: dict[str, dict[str, Any]] = {}
        self._pending_audits: dict[str, str] = {}

    # ------------------------------------------------------------------
    # pipelineStart (agentStart)
    # ------------------------------------------------------------------

    def pipeline_start(
        self,
        pipeline_id: str,
        pipeline_name: str,
        pack_binding: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
        eval_mode: bool = False,
    ) -> GovernanceDecision:
        """Gate at pipeline start.

        Records the pipeline state and sends a governance check_action.
        eval_mode pipelines use the eval audit path.

        Raises:
            GovernanceViolation: governance server denies.
        """
        pack = pack_binding or self.default_pack_binding
        agent = AgentIdentity(name=self.agent_name)

        decision = self.client.check_action(
            tool="agent.start",
            input={
                "pipelineId": pipeline_id,
                "pipelineName": pipeline_name,
                "packBinding": pack,
                "evalMode": eval_mode,
                "auditPath": self.eval_audit_path if eval_mode else "production",
                "metadata": metadata or {},
                "framework": "haystack",
            },
            agent=agent,
        )

        self._pipelines[pipeline_id] = {
            "name": pipeline_name,
            "pack_binding": pack,
            "eval_mode": eval_mode,
        }
        if decision.audit_id:
            self._pending_audits[f"pipeline:{pipeline_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # nodeStart (toolCall)
    # ------------------------------------------------------------------

    def node_start(
        self,
        pipeline_id: str,
        node_id: str,
        node_type: str,
        inputs: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Pre-node governance check.

        Sensitive nodes route to REQUIRE_APPROVAL. Retriever node inputs
        are scanned for PHI at ingress.

        Raises:
            GovernanceViolation: governance server denies.
        """
        pipeline = self._pipelines.get(pipeline_id, {})
        pack = pipeline.get("pack_binding", self.default_pack_binding)
        agent = AgentIdentity(name=self.agent_name)

        # PHI ingress scan for Retriever nodes
        phi_in_inputs = False
        if node_type in ("Retriever", "BM25Retriever", "EmbeddingRetriever", "DensePassageRetriever"):
            input_text = _extract_text(inputs or {})
            phi_in_inputs = _contains_phi(input_text)

        decision = self.client.check_action(
            tool=f"node.{node_type}",
            input={
                "pipelineId": pipeline_id,
                "nodeId": node_id,
                "nodeType": node_type,
                "inputDigest": _extract_text(inputs or {})[:500],
                "phiInInputs": phi_in_inputs,
                "packBinding": pack,
                "sensitive": node_id in self.sensitive_nodes,
                "framework": "haystack",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"node:{pipeline_id}:{node_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # nodeEnd (toolResult)
    # ------------------------------------------------------------------

    def node_end(
        self,
        pipeline_id: str,
        node_id: str,
        node_type: str,
        outputs: Optional[Any] = None,
        duration_ms: Optional[int] = None,
    ) -> None:
        """Post-node G-series classification and audit chain close."""
        audit_id = self._pending_audits.pop(f"node:{pipeline_id}:{node_id}", None)
        output_text = _extract_text(outputs or {})
        phi_found = _contains_phi(output_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output classifier: possible PHI in Haystack node "
                f'output "{node_id}" (type: {node_type}, pipeline: {pipeline_id}). '
                f"Audit ID: {audit_id}",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=not phi_found,
                    summary=output_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Output classifier: PHI in node output",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # promptNodeCall (llmCall)
    # ------------------------------------------------------------------

    def prompt_node_call(
        self,
        pipeline_id: str,
        node_id: str,
        backend_id: str,
        model: str,
        prompt: str,
        tools: Optional[list[dict[str, Any]]] = None,
    ) -> GovernanceDecision:
        """Pre-LLM backend governance check.

        Each PromptNode backend invocation is a distinct canonical event.
        Backend IDs are checked against the approved_backends list.

        Raises:
            GovernanceViolation: unapproved backend or governance server denies.
        """
        pipeline = self._pipelines.get(pipeline_id, {})
        pack = pipeline.get("pack_binding", self.default_pack_binding)
        agent = AgentIdentity(name=self.agent_name)

        # Backend allowlist check
        if self.approved_backends is not None and backend_id not in self.approved_backends:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'LLM backend "{backend_id}" is not in the approved backends list. '
                f"Approved: {', '.join(self.approved_backends)}. "
                "HIPAA pack requires BAA-covered backend."
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        decision = self.client.check_action(
            tool="llm.call",
            input={
                "pipelineId": pipeline_id,
                "nodeId": node_id,
                "backendId": backend_id,
                "model": model,
                "promptDigest": prompt[:500],
                "toolCount": len(tools or []),
                "packBinding": pack,
                "framework": "haystack",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"llm:{pipeline_id}:{node_id}:{backend_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # promptNodeResult (llmResult)
    # ------------------------------------------------------------------

    def prompt_node_result(
        self,
        pipeline_id: str,
        node_id: str,
        backend_id: str,
        result: Any,
        duration_ms: Optional[int] = None,
    ) -> None:
        """Post-LLM output classification and audit chain close."""
        audit_id = self._pending_audits.pop(f"llm:{pipeline_id}:{node_id}:{backend_id}", None)
        result_text = _extract_text(result)
        phi_found = _contains_phi(result_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output exfiltration scanner: possible PHI in "
                f"Haystack PromptNode result (node: {node_id}, backend: {backend_id}, "
                f"pipeline: {pipeline_id}). Flagged for compliance review.",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=not phi_found,
                    summary=result_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Output exfiltration scanner: PHI in LLM result",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # evalStep -- eval-mode audit (distinct from production chain)
    # ------------------------------------------------------------------

    def eval_step(
        self,
        pipeline_id: str,
        eval_set_id: str,
        metric_name: str,
        result: float,
        metadata: Optional[dict[str, Any]] = None,
    ) -> None:
        """Record an evaluation step to the eval audit path.

        Eval-mode events write to the separate eval audit path, not the
        production chain. This prevents eval noise from polluting the
        production compliance audit trail.
        """
        pipeline = self._pipelines.get(pipeline_id, {})
        pack = pipeline.get("pack_binding", self.default_pack_binding)
        agent = AgentIdentity(name=self.agent_name)

        try:
            self.client.check_action(
                tool="eval.step",
                input={
                    "pipelineId": pipeline_id,
                    "evalSetId": eval_set_id,
                    "metricName": metric_name,
                    "result": result,
                    "auditPath": self.eval_audit_path,
                    "packBinding": pack,
                    "metadata": metadata or {},
                    "framework": "haystack",
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # pipelineEnd (agentEnd)
    # ------------------------------------------------------------------

    def pipeline_end(
        self,
        pipeline_id: str,
        success: bool,
        summary: Optional[str] = None,
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
    ) -> None:
        """Terminal audit event sealing and pipeline cleanup."""
        pipeline = self._pipelines.pop(pipeline_id, {})
        audit_id = self._pending_audits.pop(f"pipeline:{pipeline_id}", None)
        agent = AgentIdentity(name=self.agent_name)

        try:
            self.client.check_action(
                tool="agent.end",
                input={
                    "pipelineId": pipeline_id,
                    "pipelineName": pipeline.get("name", "unknown"),
                    "success": success,
                    "summary": summary or ("Pipeline complete" if success else "Pipeline failed"),
                    "durationMs": duration_ms,
                    "error": error,
                    "packBinding": pipeline.get("pack_binding", []),
                    "evalMode": pipeline.get("eval_mode", False),
                    "framework": "haystack",
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success,
                    summary=summary or "",
                    duration_ms=duration_ms,
                    error=error,
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)
