"""Amazon Q Developer governance integration.

Amazon Q Developer (formerly CodeWhisperer) ships with every AWS Bedrock
shop. This adapter pairs with the Bedrock AgentCore orchestrator adapter:
the same BAA region list applies directly.

Architecture:
  The primary adapter is TypeScript-native (`src/ide-adapters/amazon-q-developer.ts`).
  This Python shim lets a Python-hosted governance policy server participate
  in the Amazon Q decision loop via HTTP.

  Two principal surfaces:
    intercept_chat(request)   -- pre/post-chat gate + ingress scan
    intercept_aws_op(request) -- gate AWS resource operations (PT-ADAPT-AMAZONQ-3)

  Amazon Q-specific surfaces:
    intercept_iam_policy(request)   -- IAM policy safety classifier (PT-ADAPT-AMAZONQ-2)
    intercept_code_transform(request) -- code transform audit gate

  BAA region enforcement:
    Under HIPAA or PCI binding, requests from non-BAA-eligible AWS regions
    are denied (PT-ADAPT-AMAZONQ-1).

Pen-test IDs mirrored from TS adapter:
  PT-ADAPT-AMAZONQ-1: non-BAA region denied under HIPAA/PCI
  PT-ADAPT-AMAZONQ-2: IAM wildcard patterns require T3_SECURITY review
  PT-ADAPT-AMAZONQ-3: destructive AWS operations require explicit approval

BAA-eligible regions (Bedrock HIPAA-eligible):
  us-east-1, us-east-2, us-west-2, eu-west-1, eu-west-2,
  eu-central-1, ap-southeast-2

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.amazon_q_developer import AmazonQDeveloperGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = AmazonQDeveloperGovernance(
        client=gov,
        agent_name="amazon-q-agent",
        pack_binding=["hipaa"],
        aws_region="us-east-1",
    )

    # Gate a chat request:
    decision = adapter.intercept_chat({
        "promptText": "Explain this Lambda function",
        "packBinding": ["hipaa"],
    })

    # Gate an AWS resource operation:
    decision = adapter.intercept_aws_op({
        "resourceType": "S3Bucket",
        "operation": "DeleteBucket",
        "resourceArn": "arn:aws:s3:::my-bucket",
        "packBinding": ["hipaa"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Bedrock BAA regions (PT-ADAPT-AMAZONQ-1)
# These regions have data-processing commitments suitable for HIPAA BAA
# coverage when an AWS BAA is in place.
# ---------------------------------------------------------------------------

AMAZON_Q_BAA_REGIONS: tuple[str, ...] = (
    "us-east-1",
    "us-east-2",
    "us-west-2",
    "eu-west-1",
    "eu-west-2",
    "eu-central-1",
    "ap-southeast-2",
)

# ---------------------------------------------------------------------------
# Destructive AWS operations (PT-ADAPT-AMAZONQ-3)
# These operations require explicit approval (T3_SECURITY tier).
# ---------------------------------------------------------------------------

_DESTRUCTIVE_AWS_OPERATIONS = frozenset({
    "DeleteBucket",
    "DeleteObject",
    "DeleteFunction",
    "DeleteRole",
    "DetachRolePolicy",
    "DeleteSecurityGroup",
    "TerminateInstances",
    "DeleteCluster",
    "DeleteTable",         # DynamoDB
    "DeleteDatabase",      # RDS
    "DeleteStack",         # CloudFormation
    "PurgeQueue",          # SQS
    "DeleteTopic",         # SNS
    "DeleteSecret",        # Secrets Manager
    "DisableKey",          # KMS
    "ScheduleKeyDeletion", # KMS
})

# ---------------------------------------------------------------------------
# IAM policy safety patterns (PT-ADAPT-AMAZONQ-2)
# ---------------------------------------------------------------------------

_IAM_UNSAFE_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("wildcard-action",      re.compile(r'"Action"\s*:\s*"\*"')),
    ("wildcard-resource",    re.compile(r'"Resource"\s*:\s*"\*"')),
    ("all-actions-on-iam",   re.compile(r'"Action"\s*:\s*"iam:\*"')),
    ("all-actions-on-s3",    re.compile(r'"Action"\s*:\s*"s3:\*"')),
    ("allow-all-principals", re.compile(r'"Principal"\s*:\s*"\*"')),
    ("no-mfa-condition",     re.compile(r'"Effect"\s*:\s*"Allow"[\s\S]{0,200}"iam:')),
]

# ---------------------------------------------------------------------------
# Secret patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",          re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",              re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",       re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",          re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",      re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",  re.compile(r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Bearer token",            re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
    ("Database URL with creds", re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_for_phi(text: str) -> Optional[str]:
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _classify_iam_policy(policy_document: str) -> list[str]:
    """Return list of safety finding names for an IAM policy document."""
    findings = []
    for name, pattern in _IAM_UNSAFE_PATTERNS:
        if pattern.search(policy_document):
            findings.append(name)
    return findings


def _is_hipaa_or_pci_binding(pack_binding: list[str]) -> bool:
    return any(
        p.lower() in ("hipaa", "hitech", "pci-dss", "pci", "pci_dss")
        for p in pack_binding
    )


# ---------------------------------------------------------------------------
# AmazonQDeveloperGovernance
# ---------------------------------------------------------------------------

class AmazonQDeveloperGovernance(BaseGovernanceIntegration):
    """REST-client shim for Amazon Q Developer governance.

    Amazon Q Developer is TypeScript-native. This Python shim participates in
    the decision loop by:
      1. Gating chat requests (intercept_chat)
      2. Gating AWS resource operations (intercept_aws_op)
      3. Gating IAM policy generation (intercept_iam_policy)
      4. Gating code transform requests (intercept_code_transform)
      5. Enforcing BAA region compliance (PT-ADAPT-AMAZONQ-1)
      6. Providing policy_bridge() for Python policy participation

    Provider: AWS Bedrock.
    BAA regions: enforced under HIPAA or PCI binding (PT-ADAPT-AMAZONQ-1).
    """

    _FRAMEWORK_NAME = "amazon-q-developer"
    _LAYER_NAME = "amazon-q-developer-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        aws_region: str = "us-east-1",
        iam_reviewer_tier: str = "T3_SECURITY",
        destructive_op_reviewer_tier: str = "T3_SECURITY",
        hipaa_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            aws_region: AWS region where Amazon Q Developer is running.
            iam_reviewer_tier: Reviewer tier for IAM policy review.
            destructive_op_reviewer_tier: Reviewer tier for destructive AWS operations.
            hipaa_reviewer_tier: Reviewer tier for HIPAA/PHI completions.
        """
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.aws_region = aws_region
        self.iam_reviewer_tier = iam_reviewer_tier
        self.destructive_op_reviewer_tier = destructive_op_reviewer_tier
        self.hipaa_reviewer_tier = hipaa_reviewer_tier

    # ------------------------------------------------------------------
    # intercept_chat -- pre/post-chat gate
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate an Amazon Q Developer chat request.

        Handles both pre-chat and post-chat directions.

        Guards applied for 'pre' direction:
          1. Pack-binding primacy
          2. BAA region check under HIPAA/PCI (PT-ADAPT-AMAZONQ-1)
          3. Secret scan on prompt
          4. PHI proximity check under HIPAA

        Args:
            request: Chat request dict with keys:
                     promptText, responseText (post), direction, packBinding, region, etc.

        Returns:
            GovernanceDecision.
        """
        direction = str(request.get("direction", "pre"))
        prompt_text = str(request.get("promptText", request.get("prompt", "")))
        response_text = str(request.get("responseText", request.get("response", "")))
        region = str(request.get("region", self.aws_region))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Amazon Q Developer chat request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        if direction == "post":
            secret_match = _scan_for_secrets(response_text)
            if secret_match:
                return self._deny(
                    agent_id,
                    f"Chat response blocked: secret pattern '{secret_match}' in response.",
                    pack_binding=pack_binding,
                )
            return self.emit_event("llmResult", {
                "agentId": agent_id,
                "model": "amazon-q",
                "responseText": response_text[:100],
                "packBinding": pack_binding,
            })

        # 'pre' direction

        # BAA region check (PT-ADAPT-AMAZONQ-1)
        if _is_hipaa_or_pci_binding(pack_binding) and region not in AMAZON_Q_BAA_REGIONS:
            return self._deny(
                agent_id,
                f"Amazon Q Developer request blocked: region '{region}' is not on the "
                f"BAA-eligible list for pack binding {pack_binding}. "
                f"Permitted BAA regions: {', '.join(AMAZON_Q_BAA_REGIONS)}.",
                pack_binding=pack_binding,
            )

        # Secret scan
        secret_match = _scan_for_secrets(prompt_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Chat request blocked: secret pattern '{secret_match}' in prompt.",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_or_pci_binding(pack_binding):
            phi_indicator = _scan_for_phi(prompt_text)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "amazon-q",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Chat request routed for review: PHI indicator "
                        f"'{phi_indicator}' found in prompt. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "amazon-q",
            "messageCount": 1,
            "packBinding": pack_binding,
            "region": region,
            "chatRequest": True,
        })

    # ------------------------------------------------------------------
    # intercept_aws_op -- gate AWS resource operations (PT-ADAPT-AMAZONQ-3)
    # ------------------------------------------------------------------

    def intercept_aws_op(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate an Amazon Q Developer AWS resource operation request (PT-ADAPT-AMAZONQ-3).

        Amazon Q Developer's "agent for AWS" can create/modify/delete AWS resources.
        Destructive operations require explicit T3_SECURITY approval.

        Guards applied:
          1. Pack-binding primacy
          2. BAA region check under HIPAA/PCI (PT-ADAPT-AMAZONQ-1)
          3. Destructive operation gate (T3_SECURITY approval required)

        Args:
            request: AWS operation request dict with keys:
                     resourceType, operation, resourceArn, region, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        resource_type = str(request.get("resourceType", "unknown"))
        operation = str(request.get("operation", ""))
        resource_arn = str(request.get("resourceArn", ""))
        region = str(request.get("region", self.aws_region))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Amazon Q Developer AWS op request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # BAA region check
        if _is_hipaa_or_pci_binding(pack_binding) and region not in AMAZON_Q_BAA_REGIONS:
            return self._deny(
                agent_id,
                f"AWS resource operation blocked: region '{region}' is not on the "
                f"BAA-eligible list for pack binding {pack_binding}. "
                f"Permitted regions: {', '.join(AMAZON_Q_BAA_REGIONS)}.",
                pack_binding=pack_binding,
            )

        # Destructive operation gate (PT-ADAPT-AMAZONQ-3)
        if operation in _DESTRUCTIVE_AWS_OPERATIONS:
            return self._deny(
                agent_id,
                f"AWS destructive operation '{operation}' on '{resource_type}' "
                f"({resource_arn or 'ARN unknown'}) requires explicit T3_SECURITY approval. "
                "This operation cannot be reversed without a recovery procedure. "
                f"Reviewer tier: {self.destructive_op_reviewer_tier}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aq:aws-resource-operation",
            "args": {
                "resourceType": resource_type,
                "operation": operation,
                "resourceArn": resource_arn,
                "region": region,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_iam_policy -- IAM policy safety classifier (PT-ADAPT-AMAZONQ-2)
    # ------------------------------------------------------------------

    def intercept_iam_policy(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate an Amazon Q Developer IAM policy generation request (PT-ADAPT-AMAZONQ-2).

        Runs the policy-safety classifier on the generated IAM policy document.
        Under PCI or HIPAA binding, unsafe patterns require T3_SECURITY review.

        Args:
            request: IAM policy request dict with keys:
                     roleName, intent, policyDocument (optional), packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        role_name = str(request.get("roleName", request.get("role", "unknown-role")))
        intent = str(request.get("intent", ""))
        policy_document = str(request.get("policyDocument", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        if not pack_binding:
            return self._deny(
                agent_id,
                "Amazon Q Developer IAM policy request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        if policy_document:
            findings = _classify_iam_policy(policy_document)
            if findings:
                if _is_hipaa_or_pci_binding(pack_binding):
                    # Under PCI/HIPAA: require T3_SECURITY review
                    return self._deny(
                        agent_id,
                        f"IAM policy generation for role '{role_name}' flagged under "
                        f"{pack_binding} binding. "
                        f"Policy safety findings: [{', '.join(findings)}]. "
                        "Overly-broad IAM policies are a PCI DSS Requirement 7 and "
                        "HIPAA access-control violation. "
                        f"Reviewer tier: {self.iam_reviewer_tier}.",
                        pack_binding=pack_binding,
                    )
                else:
                    # Non-regulated: warn via stderr but allow
                    print(
                        f"[GOVERNANCE] AmazonQ IAM policy for role '{role_name}' has "
                        f"safety findings [{', '.join(findings)}] "
                        "but no regulated pack binding. Allowed with WARN.",
                        file=sys.stderr,
                    )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aq:iam-policy-generation",
            "args": {
                "roleName": role_name,
                "intent": intent,
                "dataClass": "infrastructure-change",
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_code_transform -- code transform audit gate
    # ------------------------------------------------------------------

    def intercept_code_transform(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate an Amazon Q Developer Code Transform request.

        Carries project-level provenance (projectName + targetVersion) in
        the audit chain.

        Args:
            request: Code transform request dict with keys:
                     projectName, targetVersion, language, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        project_name = str(request.get("projectName", "unknown-project"))
        target_version = str(request.get("targetVersion", ""))
        language = str(request.get("language", "java"))
        region = str(request.get("region", self.aws_region))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        if not pack_binding:
            return self._deny(
                agent_id,
                "Amazon Q Developer code transform request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # BAA region check for bulk operations under regulated packs
        if _is_hipaa_or_pci_binding(pack_binding) and region not in AMAZON_Q_BAA_REGIONS:
            return self._deny(
                agent_id,
                f"Code Transform blocked: region '{region}' is not BAA-eligible for "
                f"{pack_binding} pack binding. "
                "Code Transform is a bulk operation that processes all source files.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aq:code-transform-requested",
            "args": {
                "projectName": project_name,
                "targetVersion": target_version,
                "language": language,
                "region": region,
                "dataClass": "bulk-code-transform",
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown AmazonQDeveloper event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] AmazonQDeveloper output classifier: possible secret in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] AmazonQDeveloper output exfiltration scanner: possible "
                    f'secret/PHI in LLM response (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Inject AWS region metadata and delegate to base (M2)
        enriched = {"awsRegion": self.aws_region, **payload}
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload and forward it as a canonical governance event."""
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError(
                "AmazonQDeveloper webhook payload missing required field: 'eventType'"
            )
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError(
                "AmazonQDeveloper webhook payload missing required field: 'agentId'"
            )
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "AmazonQDeveloperPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return AmazonQDeveloperPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# AmazonQDeveloperPolicyBridge
# ---------------------------------------------------------------------------

class AmazonQDeveloperPolicyBridge:
    """Bridge for Python-hosted policy participation in the Amazon Q loop."""

    def __init__(
        self,
        adapter: AmazonQDeveloperGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
