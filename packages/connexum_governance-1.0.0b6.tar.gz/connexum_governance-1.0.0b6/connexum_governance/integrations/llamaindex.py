"""LlamaIndex integration for Connexum governance.

Hooks into the LlamaIndex agent lifecycle with six canonical governance hook
surfaces. Python-native: integrates with llama-index's callback system
(llama_index.core.callbacks).

Hook surfaces (parity with src/orchestrator-adapters/llamaindex.ts):
  agentStart        -> gate at agent spawn
  toolCall          -> pre-tool gate (FunctionAgent / ReActAgent tool use)
  toolResult        -> post-tool G-series classification
  llmCall           -> pre-LLM gate
  documentRetrieval -> post-retrieval ingress classification (PHI in docs)
  responseSynthesis -> post-synthesis ingress classification (PHI in answer)
  agentEnd          -> terminal audit event sealing

LlamaIndex-specific considerations:
  - DocumentStore and VectorStore retrieval is a first-class ingress surface.
    Every retrieved chunk is classified for PHI before the agent sees it.
    Healthcare document classes: MedicalRecord, LabReport, ClinicalNote, etc.
  - ReAct trace format (Thought -> Action -> Observation) is surfaced in
    canonical audit events as a structured react_trace field.
  - Response synthesis stage (assembling final answer from retrieved chunks)
    is a post-retrieval ingress classification surface.
  - Primary runtime is Python; this is a fully Python-native adapter.

Lazy import: llama-index / llama-index-core are NOT hard-required at import time.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.llamaindex import LlamaIndexGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = LlamaIndexGovernance(
        client=gov,
        approved_models=["gpt-4o", "claude-haiku-4-5"],
        agent_name="medical-rag-agent",
    )

    adapter.agent_start("sess-001", agent_type="ReActAgent", pack_binding=["hipaa"])
    adapter.tool_call("sess-001", "search_tool", {"query": "patient treatment"})
    adapter.tool_result("sess-001", "search_tool", "Treatment guidelines...", success=True)
    adapter.llm_call("sess-001", "gpt-4o", messages=[...])
    adapter.document_retrieval("sess-001", chunks=[...])
    adapter.response_synthesis("sess-001", synthesized_text="...", source_chunk_ids=[...])
    adapter.agent_end("sess-001", success=True)
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation


# ---------------------------------------------------------------------------
# Healthcare document classes (PHI ingress classification)
# ---------------------------------------------------------------------------

HEALTHCARE_DOCUMENT_CLASSES = frozenset({
    "MedicalRecord",
    "LabReport",
    "ClinicalNote",
    "PatientChart",
    "PathologyReport",
    "RadiologyReport",
    "PrescriptionRecord",
    "InsuranceClaim",
})


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


def _extract_text_from_chunks(chunks: list[Any]) -> str:
    """Extract text from LlamaIndex NodeWithScore / dict chunk objects."""
    parts: list[str] = []
    for chunk in chunks:
        if isinstance(chunk, str):
            parts.append(chunk)
        elif isinstance(chunk, dict):
            parts.append(
                chunk.get("text", "")
                or chunk.get("content", "")
                or str(chunk)
            )
        elif hasattr(chunk, "text"):
            parts.append(str(chunk.text))
        elif hasattr(chunk, "get_text"):
            parts.append(str(chunk.get_text()))
        else:
            parts.append(str(chunk))
    return " ".join(parts)


# ---------------------------------------------------------------------------
# LlamaIndexGovernance
# ---------------------------------------------------------------------------

class LlamaIndexGovernance:
    """Governance adapter for LlamaIndex Agents.

    Exposes six lifecycle hooks (plus document_retrieval and response_synthesis
    as first-class LlamaIndex-specific surfaces) that map to the canonical
    governance event surfaces.

    Does NOT hard-depend on the llama-index or llama-index-core packages.
    All hook methods accept plain Python dicts / lists so they can be called
    from any LlamaIndex version or from tests without the SDK installed.
    """

    def __init__(
        self,
        client: GovernanceClient,
        approved_models: Optional[list[str]] = None,
        sensitive_tools: Optional[list[str]] = None,
        agent_name: str = "llamaindex-agent",
        classify_healthcare_chunks: bool = True,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            approved_models: LLM model IDs approved for use.
            sensitive_tools: Tool names requiring reviewer approval.
            agent_name: Default agent identity name for audit events.
            classify_healthcare_chunks: When True, retrieved chunks are
                                        scanned for PHI at ingress.
        """
        self.client = client
        self.approved_models = approved_models or []
        self.sensitive_tools = sensitive_tools or []
        self.agent_name = agent_name
        self.classify_healthcare_chunks = classify_healthcare_chunks

        # session_id -> state
        self._sessions: dict[str, dict[str, Any]] = {}
        self._pending_audits: dict[str, str] = {}

    # ------------------------------------------------------------------
    # agentStart
    # ------------------------------------------------------------------

    def agent_start(
        self,
        session_id: str,
        agent_type: str = "FunctionAgent",
        pack_binding: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Gate at agent spawn.

        Raises:
            GovernanceViolation: governance server denies.
        """
        pack = pack_binding or []
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        decision = self.client.check_action(
            tool="agent.start",
            input={
                "sessionId": session_id,
                "agentType": agent_type,
                "packBinding": pack,
                "metadata": metadata or {},
                "framework": "llamaindex",
            },
            agent=agent,
        )

        self._sessions[session_id] = {
            "agent_type": agent_type,
            "pack_binding": pack,
        }
        if decision.audit_id:
            self._pending_audits[f"start:{session_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolCall
    # ------------------------------------------------------------------

    def tool_call(
        self,
        session_id: str,
        tool_name: str,
        args: dict[str, Any],
        react_trace: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Pre-tool governance check.

        ReAct trace (Thought -> Action -> Observation) is forwarded in the
        governance input as a structured react_trace field.

        Raises:
            GovernanceViolation: governance server denies.
        """
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        decision = self.client.check_action(
            tool=f"tool.{tool_name}",
            input={
                "sessionId": session_id,
                "toolName": tool_name,
                "argsDigest": str(args)[:500],
                "reactTrace": react_trace or {},
                "packBinding": pack,
                "sensitive": tool_name in self.sensitive_tools,
                "framework": "llamaindex",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"tool:{session_id}:{tool_name}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolResult
    # ------------------------------------------------------------------

    def tool_result(
        self,
        session_id: str,
        tool_name: str,
        result: Any,
        success: bool = True,
        duration_ms: Optional[int] = None,
    ) -> None:
        """Post-tool G-series classification and audit chain close."""
        audit_id = self._pending_audits.pop(f"tool:{session_id}:{tool_name}", None)
        result_text = str(result) if not isinstance(result, str) else result
        phi_found = _contains_phi(result_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output classifier: possible PHI in LlamaIndex tool "
                f'result "{tool_name}" (session: {session_id}). '
                f"Audit ID: {audit_id}",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success and not phi_found,
                    summary=result_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Output classifier: PHI in tool result",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # llmCall
    # ------------------------------------------------------------------

    def llm_call(
        self,
        session_id: str,
        model: str,
        messages: list[dict[str, Any]],
        tools: Optional[list[dict[str, Any]]] = None,
    ) -> GovernanceDecision:
        """Pre-LLM governance check.

        Raises:
            GovernanceViolation: unapproved model or governance server denies.
        """
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        # Approved model check
        if self.approved_models and model not in self.approved_models:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'LLM model "{model}" is not on the approved provider list. '
                f"Approved: {', '.join(self.approved_models)}"
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        decision = self.client.check_action(
            tool="llm.call",
            input={
                "sessionId": session_id,
                "model": model,
                "messageCount": len(messages),
                "toolCount": len(tools or []),
                "packBinding": pack,
                "framework": "llamaindex",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"llm:{session_id}:{model}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # documentRetrieval -- LlamaIndex-specific ingress surface
    # ------------------------------------------------------------------

    def document_retrieval(
        self,
        session_id: str,
        chunks: list[Any],
        document_class: Optional[str] = None,
        query: Optional[str] = None,
    ) -> GovernanceDecision:
        """Post-retrieval ingress classification.

        Classifies retrieved document chunks for PHI before the agent sees
        them. Healthcare document classes (MedicalRecord, LabReport, etc.)
        trigger additional HIPAA compliance checks.

        This is a LlamaIndex-specific hook surface not present in the core
        six but needed for RAG pipeline governance.

        Raises:
            GovernanceViolation: PHI detected under non-HIPAA pack, or
                                 governance server denies.
        """
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        chunk_text = _extract_text_from_chunks(chunks)
        phi_found = self.classify_healthcare_chunks and _contains_phi(chunk_text)

        is_healthcare_class = document_class in HEALTHCARE_DOCUMENT_CLASSES if document_class else False

        if phi_found:
            print(
                f"[GOVERNANCE] Document retrieval ingress: PHI detected in retrieved chunks "
                f"(session: {session_id}, document_class: {document_class}, "
                f"chunk_count: {len(chunks)}). Governance check required.",
                file=sys.stderr,
            )

        decision = self.client.check_action(
            tool="document.retrieval",
            input={
                "sessionId": session_id,
                "chunkCount": len(chunks),
                "documentClass": document_class,
                "isHealthcareClass": is_healthcare_class,
                "phiDetected": phi_found,
                "queryDigest": str(query or "")[:200],
                "packBinding": pack,
                "framework": "llamaindex",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"retrieval:{session_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # responseSynthesis -- LlamaIndex-specific post-retrieval surface
    # ------------------------------------------------------------------

    def response_synthesis(
        self,
        session_id: str,
        synthesized_text: str,
        source_chunk_ids: Optional[list[str]] = None,
        duration_ms: Optional[int] = None,
    ) -> None:
        """Post-synthesis ingress classification.

        Classifies the synthesized response for PHI that may have been
        distilled from retrieved chunks. The synthesised response is
        classified before return to the caller.
        """
        audit_id = self._pending_audits.pop(f"retrieval:{session_id}", None)
        phi_found = _contains_phi(synthesized_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Response synthesis: PHI detected in synthesized "
                f"response (session: {session_id}). Distilled PHI check required. "
                f"Source chunks: {source_chunk_ids}.",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=not phi_found,
                    summary=synthesized_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Response synthesis: distilled PHI detected",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # agentEnd
    # ------------------------------------------------------------------

    def agent_end(
        self,
        session_id: str,
        success: bool,
        summary: Optional[str] = None,
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
    ) -> None:
        """Terminal audit event sealing and session cleanup."""
        session = self._sessions.pop(session_id, {})
        audit_id = self._pending_audits.pop(f"start:{session_id}", None)
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        try:
            self.client.check_action(
                tool="agent.end",
                input={
                    "sessionId": session_id,
                    "agentType": session.get("agent_type", "unknown"),
                    "success": success,
                    "summary": summary or ("Run complete" if success else "Run failed"),
                    "durationMs": duration_ms,
                    "error": error,
                    "packBinding": session.get("pack_binding", []),
                    "framework": "llamaindex",
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success,
                    summary=summary or "",
                    duration_ms=duration_ms,
                    error=error,
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)
