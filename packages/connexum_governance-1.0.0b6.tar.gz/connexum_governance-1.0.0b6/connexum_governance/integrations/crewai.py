"""CrewAI integration for Connexum governance.

Provides a GovernanceCallback that hooks into CrewAI's task lifecycle
for pre-task and post-task governance enforcement.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations import GovernanceCallback

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    callback = GovernanceCallback(client=gov, agent_name="analyst")

    # Pass to CrewAI crew
    crew = Crew(
        agents=[analyst],
        tasks=[task],
        callbacks=[callback],
    )
"""

from __future__ import annotations

from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, TaskContext


class GovernanceCallback:
    """CrewAI-compatible callback with governance enforcement.

    Implements the callback interface CrewAI expects:
    - on_task_start(task) -> called before task execution
    - on_task_end(task, output) -> called after task completes
    - on_tool_start(tool_name, input) -> called before tool use
    - on_tool_end(tool_name, output) -> called after tool use

    When a task or tool is denied, raises GovernanceViolation
    (if enforce=True on the client) or returns a denial marker.

    pack_binding: List of active compliance pack IDs governing this agent.
    Required for TaskContext construction (C2: pack-binding primacy).
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)
        self.pack_binding: list[str] = pack_binding or []
        self._pending_audits: dict[str, str] = {}
        # C1 fix: track tool-level audit IDs so on_tool_end can classify output
        self._tool_audits: dict[str, str] = {}

    def on_task_start(self, task: Any) -> Optional[str]:
        """Check governance before a CrewAI task starts.

        Args:
            task: CrewAI Task object (has .description, .agent, etc.)

        Returns:
            None if allowed, denial reason string if denied (enforce=False)

        Raises:
            GovernanceViolation if denied and enforce=True
        """
        task_id = getattr(task, "id", None) or id(task)
        task_type = getattr(task, "task_type", "crewai_task")
        description = getattr(task, "description", str(task))

        # C2: pack_binding required. Use callback's binding or task-level binding.
        task_pack_binding = getattr(task, "pack_binding", None) or self.pack_binding
        if not task_pack_binding:
            task_pack_binding = ["default"]  # fail-open with minimal binding for compat

        ctx = TaskContext(
            task_id=str(task_id),
            task_type=str(task_type),
            description=description[:500],
            agent=self.agent,
            pack_binding=task_pack_binding,
        )

        decision = self.client.check_task(ctx)

        if decision.audit_id:
            self._pending_audits[str(task_id)] = decision.audit_id

        if decision.denied:
            return f"[GOVERNANCE DENIED] {decision.reason}"

        if decision.requires_approval:
            return (
                f"[GOVERNANCE PENDING] Task requires approval. "
                f"Audit ID: {decision.audit_id}"
            )

        return None

    def on_task_end(self, task: Any, output: Any) -> None:
        """Report task completion to governance."""
        task_id = str(getattr(task, "id", None) or id(task))
        audit_id = self._pending_audits.pop(task_id, None)

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=True,
                    summary=str(output)[:200],
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    def on_tool_start(self, tool_name: str, tool_input: Any) -> Optional[str]:
        """Check governance before a tool call within a CrewAI task."""
        input_dict = (
            tool_input if isinstance(tool_input, dict)
            else {"input": str(tool_input)}
        )

        decision = self.client.check_action(
            tool=f"tool.{tool_name}",
            input=input_dict,
            agent=self.agent,
        )

        # C1 fix: store audit_id so on_tool_end can run G-series classify
        if decision.audit_id:
            self._tool_audits[tool_name] = decision.audit_id

        if decision.denied:
            return f"[GOVERNANCE DENIED] {decision.reason}"

        if decision.requires_approval:
            return (
                f"[GOVERNANCE PENDING] Tool requires approval. "
                f"Audit ID: {decision.audit_id}"
            )

        return None

    def on_tool_end(self, tool_name: str, output: Any) -> None:
        """Run G-series classification on tool output (C1 fix).

        Previously a no-op. Now calls client.classify_output() to run the
        full nine-guard G-series on the tool output before it is used by
        the CrewAI agent. A classification failure is logged to stderr but
        does not raise (the audit chain is still closed via report_result).
        """
        import sys
        audit_id = self._tool_audits.pop(tool_name, None)
        if not audit_id:
            return

        output_text = str(output)
        try:
            classified = self.client.classify_output(
                audit_id=audit_id,
                output={"toolOutput": output_text, "toolName": tool_name},
                agent=self.agent,
            )
            if not classified.allowed:
                print(
                    f"[GOVERNANCE] G-series server classification: CrewAI tool output flagged "
                    f"(tool={tool_name}, audit={audit_id}). "
                    f"Guards triggered: {classified.guards_triggered}. "
                    "(C1: postActionClassify)",
                    file=sys.stderr,
                )
            # Close the audit chain entry
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=classified.allowed,
                    summary=output_text[:200],
                    error=(
                        f"Guards triggered: {classified.guards_triggered}"
                        if not classified.allowed else None
                    ),
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)
        except Exception as exc:
            print(
                f"[GOVERNANCE] on_tool_end classify_output failed for tool={tool_name}: {exc}",
                file=sys.stderr,
            )
