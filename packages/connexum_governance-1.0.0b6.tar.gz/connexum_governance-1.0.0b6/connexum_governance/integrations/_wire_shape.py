"""
Shared wire-shape helper for framework adapters.

Every framework adapter (langchain, langgraph, crewai, llama_index, autogen,
openai_agents, haystack, pydantic_ai) sends governance check-action requests to
the My-CC governance server. The server schema (gov-server check-action,
src/index.ts:1037-1102) requires:

    {
      "toolName": str,                # required, 1..200 chars
      "agent":    {                   # required object
        "name":   str,                # required
        "role":   str (optional)
      },
      "input":    object (optional),
      "sessionInfo": object (optional)
    }

Historically, every framework adapter constructed an HTTP body of shape
{action, tools, messagePreview, packIds, metadata}. The server rejected those
with 400 "Validation failed" because it required {toolName, agent, ...} and
the customer's call effectively no-op'd.

This helper normalizes every framework adapter's outgoing body to the
server-schema shape while preserving the framework-specific routing/audit
metadata that pack rules and the audit chain rely on.

F-NEW-CRIT-1 (2026-05-02): unified wire-shape fix.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

# F-NEW-LOW-1 (2026-05-02): the helper silently truncates tool_name at 200
# chars to satisfy the gov-server schema's 1..200 char limit. Without a
# warning, callers who passed a longer name (e.g. a fully-qualified
# function path used as the tool identifier) lost the suffix without
# knowing. The truncation now warns once per truncated value at WARNING
# level so the loss is visible in logs / observability tools.
_log = logging.getLogger("connexum_governance.wire_shape")
TOOL_NAME_MAX_CHARS = 200


def _truncate_tool_name(tool_name: str) -> str:
    """Truncate tool_name to TOOL_NAME_MAX_CHARS and warn if truncation occurred."""
    if len(tool_name) <= TOOL_NAME_MAX_CHARS:
        return tool_name
    # Visible warning so the loss isn't silent. Includes both lengths so a
    # log scraper can see how much was dropped.
    _log.warning(
        "tool_name truncated to %d chars (was %d). "
        "Original ends with: %r. "
        "Pass a shorter tool_name or update the gov-server schema limit.",
        TOOL_NAME_MAX_CHARS,
        len(tool_name),
        tool_name[max(0, len(tool_name) - 40):],
    )
    return tool_name[:TOOL_NAME_MAX_CHARS]


def build_check_action_body(
    *,
    tool_name: str,
    agent_name: str,
    agent_role: Optional[str] = None,
    framework_action: Optional[str] = None,
    input_dict: Optional[dict[str, Any]] = None,
    message_preview: Optional[str] = None,
    pack_ids: Optional[list[str]] = None,
    extra_metadata: Optional[dict[str, Any]] = None,
    source: Optional[str] = None,
    tools: Optional[list[str]] = None,
    # F-NEW-CRIT-39f-followup: regulator-grade audit fields. Each
    # framework adapter (langchain, crewai, autogen, etc.) sources
    # these from the framework's per-agent context and forwards them
    # so the gov-server CRIT-39e chain entry records non-"unknown"
    # values.
    user_id: Optional[str] = None,
    llm_model: Optional[str] = None,
) -> dict[str, Any]:
    """
    Build a server-schema-compliant check-action body.

    Args:
        tool_name: The tool name being invoked. This is the field server pack
            rules match against (e.g. 'fake_lc_tool', 'web_search', 'agent_step').
            REQUIRED. Must be 1..200 chars.
        agent_name: The agent identifier (e.g. 'GovernedAnthropic',
            'crewai-tool:web_search'). REQUIRED.
        agent_role: Optional agent role.
        framework_action: The framework-level action namespace
            (e.g. 'framework.langchain.tool_invoke'). Recorded in metadata for
            audit-chain visibility and pack rules that target framework actions
            via metadata. NOT placed at the top level (server schema rejects).
        input_dict: Tool input dict. Optional. Recorded under 'input'.
        message_preview: Optional truncated string preview of the input.
            Recorded under metadata.messagePreview to preserve pre-fix observability.
        pack_ids: List of compliance pack IDs active for this call.
            Recorded under metadata.packIds.
        extra_metadata: Caller-supplied additional metadata fields. Merged into
            metadata last (does not override standard fields).
        source: Origin of the call (e.g. 'GovernedTool._run').
            Recorded under metadata.source.

    Returns:
        A dict matching the gov-server check-action schema:
        {toolName, agent: {name, role?}, input, sessionInfo: {metadata: {...}}}.
    """
    if not tool_name:
        raise ValueError("[wire_shape] tool_name is required")
    if not agent_name:
        raise ValueError("[wire_shape] agent_name is required")

    agent_obj: dict[str, Any] = {"name": agent_name}
    if agent_role is not None:
        agent_obj["role"] = agent_role

    metadata: dict[str, Any] = {}
    if framework_action:
        metadata["frameworkAction"] = framework_action
    if message_preview is not None:
        metadata["messagePreview"] = message_preview
    if pack_ids:
        metadata["packIds"] = list(pack_ids)
    # extra_metadata wins over `source` so callers that pass an explicit
    # metadata["source"] (legacy convention -- the source-node name for
    # langgraph routing, callback name for callbacks) get their value back.
    if extra_metadata:
        for k, v in extra_metadata.items():
            metadata[k] = v
    if source and "source" not in metadata:
        metadata["source"] = source

    body: dict[str, Any] = {
        "toolName": _truncate_tool_name(tool_name),
        "agent": agent_obj,
    }
    if input_dict is not None:
        body["input"] = input_dict
    if metadata:
        body["sessionInfo"] = {"metadata": metadata}
    # F-NEW-CRIT-39f-followup: forward regulator-grade fields when present.
    if user_id is not None:
        body["userId"] = user_id
    if llm_model is not None:
        body["llmModel"] = llm_model

    # Backward-compat passthroughs. The gov-server check-action validator only
    # checks for declared fields and ignores extras, so attaching legacy
    # observability fields at the top level is safe and lets existing unit
    # tests / external audit consumers that inspect body["action"] etc keep
    # working unchanged.
    if framework_action:
        body["action"] = framework_action
    if message_preview is not None:
        body["messagePreview"] = message_preview
    if pack_ids:
        body["packIds"] = list(pack_ids)
    # tools[] mirrors metadata["toolName"] when caller passes it explicitly;
    # supply the canonical tool_name as a single-element list for legacy tests
    # unless caller provided an explicit list (e.g. multi-tool dispatchers).
    body["tools"] = list(tools) if tools else [tool_name]
    if metadata:
        # Some legacy tests inspect body["metadata"] directly. Preserve that
        # surface in addition to sessionInfo.metadata.
        body["metadata"] = metadata
    return body
