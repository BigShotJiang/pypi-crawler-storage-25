"""Claude Agent SDK integration for Connexum governance.

Hooks into the Anthropic Claude Agent SDK lifecycle events with six
canonical governance hook surfaces. Python-native: delegates to the
claude-agent-sdk package when installed.

Hook surfaces (parity with src/orchestrator-adapters/claude-agent-sdk.ts):
  agentStart   -> gate at agent spawn (subscription + pack-binding + provider compliance)
  toolCall     -> pre-tool gate (phantom check + exfiltration scan + sensitive tools)
  toolResult   -> post-tool G-series output classification
  llmCall      -> pre-LLM gate (approved model list)
  llmResult    -> post-LLM output exfiltration scan
  agentEnd     -> terminal audit event sealing

Error classes (parity):
  UnboundDataError     -- agent acted without pack binding
  PhantomAgentError    -- unregistered agent attempted to act
  SubscriptionGateError -- subscription gate denied spawn

Lazy import: claude-agent-sdk is NOT hard-required. This module is always
importable. The hook methods work without the SDK installed; you only need
it if you are using the SDK's native classes directly.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.claude_agent_sdk import (
        ClaudeAgentGovernance,
        UnboundDataError,
        PhantomAgentError,
    )

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = ClaudeAgentGovernance(
        client=gov,
        registered_agents=["my-agent"],
        approved_models=["claude-sonnet-4-6", "claude-haiku-4-5-20251001"],
        sensitive_tools=["bash", "file_write"],
    )

    # At agent spawn:
    adapter.agent_start("my-agent", pack_binding=["hipaa"], model="claude-haiku-4-5-20251001")

    # Before a tool call:
    adapter.tool_call("my-agent", "web_search", {"query": "AI governance"})

    # After tool result:
    adapter.tool_result("my-agent", "web_search", "AI governance overview...", success=True)

    # Before LLM call:
    adapter.llm_call("my-agent", "claude-haiku-4-5-20251001", messages=[...])

    # After LLM response:
    adapter.llm_result("my-agent", "claude-haiku-4-5-20251001", response_text="...")

    # When agent ends:
    adapter.agent_end("my-agent", success=True, summary="Task complete")
"""

from __future__ import annotations

import re
import sys
import time
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation


# ---------------------------------------------------------------------------
# Error classes (parity with TS adapter)
# ---------------------------------------------------------------------------

class UnboundDataError(RuntimeError):
    """Raised when an agent attempts to act without a pack binding."""

    def __init__(self, agent_id: str, stage: str):
        super().__init__(
            f'Agent "{agent_id}" attempted {stage} without a pack binding. '
            "Every agent MUST carry packBinding before any action fires. "
            "Fail closed per pack-binding primacy rule."
        )
        self.agent_id = agent_id
        self.stage = stage


class PhantomAgentError(RuntimeError):
    """Raised when an unregistered agent attempts to act."""

    def __init__(self, agent_id: str, registered: list[str]):
        super().__init__(
            f'Phantom-agent detection: agent "{agent_id}" is not registered. '
            f"Registered agents: [{', '.join(registered)}]. "
            "Refuse-closed per DA-MED-NEW-1 agent-registration integrity rule."
        )
        self.agent_id = agent_id
        self.registered = registered


class SubscriptionGateError(RuntimeError):
    """Raised when the subscription gate denies agent spawn."""

    def __init__(self, agent_id: str, reason: str):
        super().__init__(
            f'Subscription gate denied spawn for agent "{agent_id}": {reason}'
        )
        self.agent_id = agent_id
        self.reason = reason


# ---------------------------------------------------------------------------
# PHI / secret helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


# ---------------------------------------------------------------------------
# ClaudeAgentGovernance
# ---------------------------------------------------------------------------

class ClaudeAgentGovernance:
    """Governance adapter for the Claude Agent SDK.

    Exposes six lifecycle hooks that map to the canonical governance event
    surfaces. Each hook calls the governance API and enforces the configured
    policy (pack-binding primacy, subscription gate, phantom-agent detection,
    exfiltration scanning, approved-model list).

    Does NOT hard-depend on the claude-agent-sdk package. All hook methods
    accept plain Python dicts / strings so they can be called from any
    Claude-SDK version or from tests without the SDK installed.
    """

    def __init__(
        self,
        client: GovernanceClient,
        registered_agents: list[str],
        approved_models: list[str],
        sensitive_tools: Optional[list[str]] = None,
        sensitive_arg_keys: Optional[list[str]] = None,
        max_tool_calls_per_run: Optional[int] = None,
        enforce_pack_binding: bool = True,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            registered_agents: Agent IDs permitted to spawn. Empty list causes
                               all spawns to be denied (fail-closed).
            approved_models: LLM model IDs approved for use. Unapproved models
                             trigger denial at llm_call.
            sensitive_tools: Tool names that require reviewer approval.
            sensitive_arg_keys: Argument keys to scan for PHI / exfiltration.
            max_tool_calls_per_run: Cap on tool calls per agent run.
            enforce_pack_binding: If True (default), agents must carry non-empty
                                  packBinding at spawn and tool calls.
        """
        self.client = client
        self.registered_agents = registered_agents
        self.approved_models = approved_models
        self.sensitive_tools = sensitive_tools or []
        self.sensitive_arg_keys = sensitive_arg_keys or ["query", "body", "content", "message"]
        self.max_tool_calls_per_run = max_tool_calls_per_run
        self.enforce_pack_binding = enforce_pack_binding

        # Per-agent state
        self._active_agents: dict[str, dict[str, Any]] = {}
        self._tool_counters: dict[str, int] = {}
        self._pending_audits: dict[str, str] = {}

    # ------------------------------------------------------------------
    # agentStart
    # ------------------------------------------------------------------

    def agent_start(
        self,
        agent_id: str,
        pack_binding: list[str],
        model: str,
        metadata: Optional[dict[str, Any]] = None,
        parent_agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> GovernanceDecision:
        """Gate at agent spawn.

        Checks:
          1. Phantom-agent detection (DA-MED-NEW-1)
          2. Pack-binding primacy (UnboundDataError if empty)
          3. Provider compliance (approved_models list)
          4. Subscription gate via governance check_action

        Raises:
            PhantomAgentError: Agent not in registered_agents.
            UnboundDataError: pack_binding is empty and enforce_pack_binding=True.
            SubscriptionGateError: Governance server returns DENY with subscription
                                   language.
            GovernanceViolation: Governance server denies for any other reason.
        """
        # Phantom-agent detection
        if agent_id not in self.registered_agents:
            raise PhantomAgentError(agent_id, self.registered_agents)

        # Pack-binding primacy
        if self.enforce_pack_binding and not pack_binding:
            raise UnboundDataError(agent_id, "agent_start")

        # Provider compliance (approved model list)
        if model not in self.approved_models:
            decision_data = {
                "decision": "DENY",
                "reason": (
                    f'LLM model "{model}" is not on the approved provider list. '
                    f"Approved: {', '.join(self.approved_models)}"
                ),
                "auditId": str(uuid.uuid4()),
            }
            from connexum_governance.models import GovernanceDecision, DecisionType
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=decision_data["reason"],
                audit_id=decision_data["auditId"],
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        agent = AgentIdentity(name=agent_id)
        decision = self.client.check_action(
            tool="agent.start",
            input={
                "agentId": agent_id,
                "packBinding": pack_binding,
                "model": model,
                "parentAgentId": parent_agent_id,
                "sessionId": session_id,
                "metadata": metadata or {},
            },
            agent=agent,
        )

        if decision.denied and "subscription" in decision.reason.lower():
            raise SubscriptionGateError(agent_id, decision.reason)
        if decision.denied and self.client.enforce:
            raise GovernanceViolation(decision)

        # Register active agent
        self._active_agents[agent_id] = {
            "pack_binding": pack_binding,
            "model": model,
        }
        self._tool_counters[agent_id] = 0

        return decision

    # ------------------------------------------------------------------
    # toolCall
    # ------------------------------------------------------------------

    def tool_call(
        self,
        agent_id: str,
        tool_name: str,
        args: dict[str, Any],
    ) -> GovernanceDecision:
        """Pre-tool gate.

        Checks:
          1. Phantom check (agent must have called agent_start first)
          2. Pack-binding presence
          3. Runaway counter
          4. Sensitive-tool REQUIRE_APPROVAL routing
          5. Exfiltration scan on sensitive arg keys (G5/G7)

        Raises:
            PhantomAgentError: tool_call without prior agent_start.
            UnboundDataError: pack_binding missing on active agent.
            GovernanceViolation: Governance server denies.
        """
        if agent_id not in self._active_agents:
            raise PhantomAgentError(agent_id, list(self._active_agents.keys()))

        snapshot = self._active_agents[agent_id]
        if self.enforce_pack_binding and not snapshot.get("pack_binding"):
            raise UnboundDataError(agent_id, f"tool_call({tool_name})")

        # Runaway counter
        count = self._tool_counters.get(agent_id, 0) + 1
        self._tool_counters[agent_id] = count
        if self.max_tool_calls_per_run is not None and count > self.max_tool_calls_per_run:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Agent "{agent_id}" exceeded max_tool_calls_per_run '
                f"({self.max_tool_calls_per_run}). Runaway agent suppressed."
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        # Exfiltration scan
        exfil_key = self._scan_args(args)
        if exfil_key:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Possible data exfiltration in args for tool "{tool_name}" '
                f'(key: "{exfil_key}"). Blocked at G5/G7 egress guard.'
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        agent = AgentIdentity(name=agent_id)
        decision = self.client.check_action(
            tool=f"tool.{tool_name}",
            input={
                "agentId": agent_id,
                "toolName": tool_name,
                "argsDigest": str(args)[:500],
                "callCount": count,
                "packBinding": snapshot.get("pack_binding", []),
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"{agent_id}:{tool_name}:{count}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolResult
    # ------------------------------------------------------------------

    def tool_result(
        self,
        agent_id: str,
        tool_name: str,
        result: Any,
        success: bool = True,
        duration_ms: Optional[int] = None,
    ) -> None:
        """Post-tool G-series classification and audit chain close."""
        count = self._tool_counters.get(agent_id, 1)
        audit_key = f"{agent_id}:{tool_name}:{count}"
        audit_id = self._pending_audits.pop(audit_key, None)

        result_text = str(result) if not isinstance(result, str) else result
        phi_found = _contains_phi(result_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output classifier: possible PHI in tool result "
                f'for "{tool_name}" (agent: {agent_id}). '
                f"Audit ID: {audit_id}",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success and not phi_found,
                    summary=result_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Output classifier: PHI detected in tool result",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # llmCall
    # ------------------------------------------------------------------

    def llm_call(
        self,
        agent_id: str,
        model: str,
        messages: list[dict[str, Any]],
        tools: Optional[list[dict[str, Any]]] = None,
    ) -> GovernanceDecision:
        """Pre-LLM gate.

        Checks:
          1. Phantom check
          2. Pack-binding presence
          3. Approved model list

        Raises:
            PhantomAgentError, UnboundDataError, GovernanceViolation.
        """
        if agent_id not in self._active_agents:
            raise PhantomAgentError(agent_id, list(self._active_agents.keys()))

        snapshot = self._active_agents[agent_id]
        if self.enforce_pack_binding and not snapshot.get("pack_binding"):
            raise UnboundDataError(agent_id, f"llm_call({model})")

        if model not in self.approved_models:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'LLM destination "{model}" is not on the approved provider list '
                f"for the active pack ({', '.join(snapshot.get('pack_binding', []))})."
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        agent = AgentIdentity(name=agent_id)
        decision = self.client.check_action(
            tool="llm.call",
            input={
                "agentId": agent_id,
                "model": model,
                "messageCount": len(messages),
                "toolCount": len(tools or []),
                "packBinding": snapshot.get("pack_binding", []),
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"{agent_id}:llm:{model}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # llmResult
    # ------------------------------------------------------------------

    def llm_result(
        self,
        agent_id: str,
        model: str,
        response_text: str,
        usage: Optional[dict[str, int]] = None,
    ) -> None:
        """Post-LLM output exfiltration scan and audit chain close."""
        audit_id = self._pending_audits.pop(f"{agent_id}:llm:{model}", None)

        phi_found = _contains_phi(response_text)
        if phi_found:
            print(
                f"[GOVERNANCE] Output exfiltration scanner: possible PHI in "
                f'LLM response (model: {model}, agent: {agent_id}). '
                f"Flagged for compliance review.",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=not phi_found,
                    summary=response_text[:200],
                    error=None if not phi_found else "Output exfiltration scanner: PHI in LLM response",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # agentEnd
    # ------------------------------------------------------------------

    def agent_end(
        self,
        agent_id: str,
        success: bool,
        summary: Optional[str] = None,
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
    ) -> None:
        """Terminal audit event sealing and active-agent cleanup."""
        snapshot = self._active_agents.pop(agent_id, {})
        tool_count = self._tool_counters.pop(agent_id, 0)

        agent = AgentIdentity(name=agent_id)
        try:
            self.client.check_action(
                tool="agent.end",
                input={
                    "agentId": agent_id,
                    "success": success,
                    "summary": summary or ("Run complete" if success else "Run failed"),
                    "durationMs": duration_ms,
                    "error": error,
                    "toolCallCount": tool_count,
                    "packBinding": snapshot.get("pack_binding", []),
                    "model": snapshot.get("model"),
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _scan_args(self, args: dict[str, Any]) -> Optional[str]:
        """Scan tool arguments for PHI patterns on sensitive keys."""
        for key in self.sensitive_arg_keys:
            value = args.get(key)
            if isinstance(value, str) and _contains_phi(value):
                return key
        return None
