"""Replicate governance integration for Connexum governance.

Wraps replicate.run() and replicate.predictions.create() calls,
typically used for Llama-family models hosted on Replicate.

BAA status: Replicate does NOT offer a BAA. PHI / regulated data
should NOT flow through Replicate without explicit data processing
agreement.

Closes F-NEW-CRIT-4 -- the README listed Llama (typically run via
Replicate) as a supported platform but no Python wrapper existed.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.replicate import ReplicateGovernance

    gov = GovernanceClient(api_url="...", license_key="...")
    rg = ReplicateGovernance(client=gov, agent_name="replicate-agent")

    decision = rg.intercept_request({
        "model": "meta/llama-3-70b-instruct",
        "input": {"prompt": "Hello", "max_tokens": 256},
    })
"""

from __future__ import annotations

from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
)

_PROVIDER_ID = "replicate"
_BAA_AVAILABLE = False
_BAA_SCOPE = None
_BAA_NOTES = (
    "Replicate does not offer a BAA. PHI / regulated data should NOT "
    "flow through Replicate without an explicit data processing "
    "agreement covering the deployment."
)


class ReplicateGovernance:
    """Governance wrapper for Replicate prediction calls.

    Does NOT depend on the replicate package at import time. Supports
    both replicate.run(model, input=...) and predictions.create() request
    shapes.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)
        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        # request shape: { model: "owner/name", input: {prompt, ...} }
        # OR              { version: "<sha>", input: {prompt, ...} }
        model_id = request.get("model") or request.get("version") or "unknown"
        inp = request.get("input", {}) or {}
        prompt = inp.get("prompt") or inp.get("text") or ""
        if not isinstance(prompt, str):
            prompt = str(prompt)

        gov_input: dict[str, Any] = {
            "provider": _PROVIDER_ID,
            "model": model_id,
            "maxTokens": inp.get("max_tokens") or inp.get("max_new_tokens"),
            "systemPromptDigest": prompt[:500],
            "messageCount": 1,
        }
        return self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )

    def intercept_response(
        self,
        response: Any,
        audit_id: str,
    ) -> ClassifiedResponse:
        # Replicate streaming yields list[str]; dict-only path is the safe normalizer
        if isinstance(response, str):
            payload: dict[str, Any] = {"output": response}
        elif isinstance(response, list):
            payload = {"output": "".join(str(p) for p in response)}
        elif isinstance(response, dict):
            payload = response
        else:
            payload = {"raw": str(response)}
        return self.client.classify_output(
            audit_id=audit_id,
            output=payload,
            agent=self.agent,
        )
