"""
GovernedCrewAI -- governance enforcement for CrewAI (Python).

This is a FRAMEWORK ADAPTER operating at the CrewAI SDK layer. It intercepts
between customer code and CrewAI's Crew orchestration layer, enforcing
governance policy at tool dispatch, agent steps, and task completion.

=== ARCHITECTURAL CONTRAST: CrewAI vs LangChain vs OpenAI Agents SDK vs LlamaIndex ===

LangChain's callback system is OBSERVABILITY-first. GovernedTool._run() is the
only guaranteed blocking path (see langchain_integration.py).

OpenAI Agents SDK provides FIRST-CLASS blocking via input/output guardrails --
a contract-guaranteed gate in the SDK's public API.

LlamaIndex falls between: GovernedFunctionTool.__call__ is the guaranteed gate;
CallbackManager provides observability.

CrewAI's blocking model aligns more closely with LangChain:

  BaseTool._run(tool_input):
    The dispatch point for all CrewAI tool executions. Subclassing BaseTool
    and overriding _run() (and the async _arun() where available) is the
    GUARANTEED BLOCKING PRIMITIVE. This runs inside CrewAI's tool invocation
    path regardless of which agent or crew triggers the tool.

  task_callback / step_callback on Crew:
    CrewAI Crew accepts task_callback and step_callback callables at
    construction time. These fire after each task and each agent step
    respectively. They are OBSERVABILITY hooks -- they fire after execution,
    meaning they can audit but cannot block the initiating action.
    EXCEPTION: if a step_callback raises, CrewAI may halt the step depending
    on version, but this is NOT part of the public API contract.
    CONCLUSION: Use these for audit coverage and post-hoc checks, not as
    your primary blocking gate.

  Crew-level tool wrapping:
    wrap_crew() replaces all tools on all agents in the crew with
    GovernanceCrewAITool instances. This provides defense-in-depth from the
    outside in: even if a new agent is added later, all tool registrations
    on the crew are governed at Crew construction time.

BLOCKING STORY (ranked best to worst):
  1. GovernanceCrewAITool._run()          -- GUARANTEED (tool dispatch point)
  2. wrap_crew() tool replacement          -- GUARANTEED for all crew tools
  3. step_callback / task_callback         -- OBSERVABILITY / best-effort
                                             fires AFTER action, not before
                                             (cannot reliably block initiating call)

ARCHITECTURE NOTE for customers:
  - Use GovernanceCrewAITool (or governed_crewai_tool() factory) for all tools
    registered with CrewAI agents. This is the guaranteed blocking path.
  - Use wrap_crew() to govern all tools in an existing Crew at once.
  - Register step_callback / task_callback via wrap_crew() for audit coverage
    of agent steps and task outputs.
  - For defense-in-depth, combine GovernanceCrewAITool + wrap_crew().

Action name namespace (for pack rule targeting):
  framework.crewai.tool_run        -- GovernanceCrewAITool._run() check
  framework.crewai.agent_step      -- step_callback check
  framework.crewai.task_complete   -- task_callback check
  framework.crewai.crew_kickoff    -- pre-kickoff check on Crew.kickoff()

Supported CrewAI version range (tested against mock primitives):
  crewai >= 0.30.0

Architectural difference vs LangChain:
  LangChain tools implement _run() / _arun(). CrewAI's BaseTool also uses
  _run() as the dispatch point, making the wrapping pattern similar. However,
  CrewAI's BaseTool has slightly different constructor requirements (name,
  description, args_schema are class attributes, not constructor args in most
  versions). This module adapts by setting attributes directly.

  CrewAI does not have a built-in async tool interface as of crewai 0.30.x.
  This module provides async support via GovernanceCrewAITool._arun() for
  future compatibility.

Optional peer dependencies:
  crewai >= 0.30.0

@connexum/python-sdk -- Framework Adapter Layer (Sprint 5, WS-09)
"""

from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass
from typing import Any, Callable, Optional

from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations._wire_shape import build_check_action_body

# ---------------------------------------------------------------------------
# Type alias for check function injection (test isolation)
#
# Signature: async (governance_server_url: str, body: dict) -> dict
# Returns: {decision: ALLOW|DENY|REQUIRE_APPROVAL, reason, approvalId, auditId}
# ---------------------------------------------------------------------------

CheckFnType = Callable[[str, dict], Any]


# ---------------------------------------------------------------------------
# HTTP check helpers (same pattern as langchain_integration.py and
# llama_index_integration.py for consistency)
# ---------------------------------------------------------------------------

def _do_check_sync(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """Run a synchronous governance check."""
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            try:
                asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(
                        lambda: asyncio.run(check_fn(governance_server_url, body))
                    )
                    return future.result()
            except RuntimeError:
                return asyncio.run(check_fn(governance_server_url, body))
        else:
            return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        with _httpx.Client(timeout=5.0) as client:
            resp = client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


async def _do_check_async(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """Run an asynchronous governance check."""
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            return await check_fn(governance_server_url, body)
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        async with _httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


# ---------------------------------------------------------------------------
# Decision enforcement helper
# ---------------------------------------------------------------------------

def _enforce_decision(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
) -> None:
    """
    Inspect a governance check result and raise on DENY / REQUIRE_APPROVAL.

    Args:
        result: Raw check result dict (decision, reason, approvalId, auditId).
        context_label: Human-readable label for error messages.
        raise_on_deny: Whether to raise exceptions. If False, log to stderr only.

    Raises:
        GovernanceViolation: decision is DENY (and raise_on_deny=True).
        GovernancePendingApproval: decision is REQUIRE_APPROVAL (and raise_on_deny=True).
    """
    decision = result.get("decision", "ALLOW")

    if decision == "DENY":
        reason = result.get("reason") or "policy"
        sys.stderr.write(
            f"[GovernanceCrewAITool] DENIED for '{context_label}'. reason={reason}\n"
        )
        if raise_on_deny:
            raise GovernanceViolation(
                decision="DENY",
                reason=reason,
                audit_id=result.get("auditId"),
            )
        return

    if decision == "REQUIRE_APPROVAL":
        approval_id = result.get("approvalId")
        audit_id = result.get("auditId")
        if not approval_id:
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                    audit_id=audit_id,
                )
            return
        sys.stderr.write(
            f"[GovernanceCrewAITool] PENDING for '{context_label}'. "
            f"approvalId={approval_id}\n"
        )
        if raise_on_deny:
            raise GovernancePendingApproval(
                approval_id=approval_id,
                audit_id=audit_id,
            )

    # ALLOW -- fall through


# ---------------------------------------------------------------------------
# GovernanceCrewAITool -- GUARANTEED BLOCKING PRIMITIVE
#
# Wraps a CrewAI BaseTool by overriding _run() (and _arun()) with governance
# checks BEFORE delegating to the underlying tool implementation.
#
# This is the CrewAI equivalent of GovernedTool._run() in LangChain.
# ---------------------------------------------------------------------------

class GovernanceCrewAITool:
    """
    CrewAI BaseTool wrapper that intercepts _run() with a governance check
    BEFORE delegating to the underlying tool implementation.

    This is the GUARANTEED BLOCKING PRIMITIVE for CrewAI tool calls.
    Unlike step_callback / task_callback (which fire after execution),
    overriding _run() ensures governance runs BEFORE the tool executes.

    The returned object exposes:
      - .name            -- tool name (from underlying tool)
      - .description     -- tool description
      - ._run(input)     -- governed sync dispatch
      - ._arun(input)    -- governed async dispatch
      - .run(input)      -- public run() wrapper

    Usage:
        from connexum_governance.integrations.crewai_integration import (
            governed_crewai_tool,
        )

        raw_tool = SearchTool()  # any CrewAI BaseTool
        safe_tool = governed_crewai_tool(
            tool=raw_tool,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
        )
        agent = Agent(role="researcher", tools=[safe_tool], ...)
    """

    def __init__(
        self,
        tool: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        if tool is None:
            raise ValueError("[GovernanceCrewAITool] tool is required")

        # Extract tool name -- CrewAI tools expose .name as a class or instance attribute
        tool_name = getattr(tool, "name", None)
        if not tool_name:
            raise ValueError(
                "[GovernanceCrewAITool] tool.name is required (BaseTool subclass must "
                "set name as a class attribute or instance attribute)"
            )
        if not governance_server_url:
            raise ValueError("[GovernanceCrewAITool] governance_server_url is required")
        if not license_key:
            raise ValueError("[GovernanceCrewAITool] license_key is required")

        self._underlying = tool
        self.name: str = tool_name
        self.description: str = getattr(tool, "description", "") or ""
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._check_fn = _check_fn

    def _normalize_input(self, tool_input: Any) -> str:
        """Normalize tool_input to a string for governance check."""
        if tool_input is None:
            return ""
        if isinstance(tool_input, str):
            return tool_input
        import json as _json
        try:
            return _json.dumps(tool_input)
        except (TypeError, ValueError):
            return str(tool_input)

    def _build_check_body(self, input_str: str, source: str = "GovernanceCrewAITool._run") -> dict:
        return build_check_action_body(
            tool_name=self.name,
            agent_name=f"crewai-tool:{self.name}",
            framework_action="framework.crewai.tool_run",
            input_dict={"input": input_str},
            message_preview=input_str[:200],
            pack_ids=self._pack_ids,
            extra_metadata={"toolName": self.name, "inputPreview": input_str[:200]},
            source=source,
        )

    def _run(self, tool_input: Any = "", **kwargs: Any) -> Any:
        """
        Governed _run(). Runs governance check before executing the underlying tool.

        DENY -> raises GovernanceViolation (guaranteed blocking).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying tool._run().

        This is the GUARANTEED BLOCKING PRIMITIVE for sync tool invocations.

        Args:
            tool_input: The input to the tool (str, dict, or other serializable type).
        """
        input_str = self._normalize_input(tool_input)
        result = _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=self._build_check_body(input_str),
            check_fn=self._check_fn,
        )

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "Tool call denied by governance policy"
            sys.stderr.write(
                f"[GovernanceCrewAITool:{self.name}] _run DENIED. reason={reason}\n"
            )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return f"[GOVERNANCE DENIED] {reason}"

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
                return "[GOVERNANCE PENDING] Approval required but no approvalId returned"
            sys.stderr.write(
                f"[GovernanceCrewAITool:{self.name}] _run PENDING. approvalId={approval_id}\n"
            )
            if self._raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )
            return f"[GOVERNANCE PENDING] approvalId={approval_id}"

        # ALLOW -- delegate to underlying tool
        underlying_run = getattr(self._underlying, "_run", None)
        if underlying_run is not None:
            return underlying_run(tool_input, **kwargs)

        # Fallback to run() if _run not available
        underlying_run_pub = getattr(self._underlying, "run", None)
        if underlying_run_pub is not None:
            return underlying_run_pub(tool_input, **kwargs)

        raise AttributeError(
            f"[GovernanceCrewAITool] Underlying tool '{self.name}' has no _run() or run() method"
        )

    async def _arun(self, tool_input: Any = "", **kwargs: Any) -> Any:
        """
        Governed async _arun(). Async version of _run().

        DENY -> raises GovernanceViolation (guaranteed blocking).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying tool._arun() or _run().

        This is the GUARANTEED BLOCKING PRIMITIVE for async tool invocations.
        """
        input_str = self._normalize_input(tool_input)
        result = await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=self._build_check_body(input_str, source="GovernanceCrewAITool._arun"),
            check_fn=self._check_fn,
        )

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "Tool call denied by governance policy"
            sys.stderr.write(
                f"[GovernanceCrewAITool:{self.name}] _arun DENIED. reason={reason}\n"
            )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return f"[GOVERNANCE DENIED] {reason}"

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
                return "[GOVERNANCE PENDING] Approval required but no approvalId returned"
            sys.stderr.write(
                f"[GovernanceCrewAITool:{self.name}] _arun PENDING. approvalId={approval_id}\n"
            )
            if self._raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )
            return f"[GOVERNANCE PENDING] approvalId={approval_id}"

        # ALLOW -- delegate
        underlying_arun = getattr(self._underlying, "_arun", None)
        if underlying_arun is not None:
            if asyncio.iscoroutinefunction(underlying_arun):
                return await underlying_arun(tool_input, **kwargs)
            return underlying_arun(tool_input, **kwargs)

        underlying_run = getattr(self._underlying, "_run", None)
        if underlying_run is not None:
            return underlying_run(tool_input, **kwargs)

        raise AttributeError(
            f"[GovernanceCrewAITool] Underlying tool '{self.name}' has no _arun() or _run()"
        )

    def run(self, tool_input: Any = "", **kwargs: Any) -> Any:
        """Public run() shim -- delegates to _run()."""
        return self._run(tool_input, **kwargs)


# ---------------------------------------------------------------------------
# governed_crewai_tool -- convenience factory
# ---------------------------------------------------------------------------

def governed_crewai_tool(
    tool: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernanceCrewAITool:
    """
    Factory function to create a GovernanceCrewAITool wrapping any CrewAI tool.

    The returned GovernanceCrewAITool intercepts _run() with governance checks
    before delegating to the underlying tool. This is the GUARANTEED BLOCKING
    PRIMITIVE for CrewAI tool calls.

    Args:
        tool: Any CrewAI BaseTool with a .name attribute and ._run() method.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernanceCrewAITool wrapping the provided tool.
    """
    return GovernanceCrewAITool(
        tool=tool,
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )


# ---------------------------------------------------------------------------
# governance_step_callback -- agent step audit hook
#
# OBSERVABILITY ONLY. Fires after each agent step. Can check step outputs
# for policy violations, but cannot block the step that triggered it.
# ---------------------------------------------------------------------------

def make_governance_step_callback(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = False,
    _check_fn: Optional[CheckFnType] = None,
) -> Callable:
    """
    Create a step_callback function for CrewAI Crew.

    The returned callback runs a governance check on each agent step's output.
    This is OBSERVABILITY-focused: it fires after each step, so it cannot
    block the action that produced the step output. However, it can:
      1. Detect policy violations in step outputs (audit trail).
      2. Raise GovernanceViolation to halt the crew run after a violation
         (raise_on_deny=True -- USE WITH CAUTION: this stops the entire crew).

    BLOCKING CONTRACT: OBSERVABILITY (fires after step, not before).
    Raising from step_callback will halt the crew run in most CrewAI versions,
    but this is not part of the public API contract.

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY (default False for step_callback
            since it fires post-step; True would halt the crew run).
        _check_fn: Test injection hook (not public API).

    Returns:
        A callable suitable for use as CrewAI Crew(step_callback=...).
    """

    def governance_step_callback(step_output: Any) -> None:
        """
        CrewAI step_callback: runs governance check on agent step output.

        OBSERVABILITY: fires after step completes. Cannot block the step.
        When raise_on_deny=True, a DENY halts the crew run.

        Args:
            step_output: The output of the agent step. May be a string, dict,
                CrewAI AgentFinish, AgentAction, or other step result type.
        """
        # Normalize step_output to string for governance check
        if step_output is None:
            step_str = ""
        elif isinstance(step_output, str):
            step_str = step_output
        elif hasattr(step_output, "output"):
            step_str = str(step_output.output)
        elif hasattr(step_output, "return_values"):
            step_str = str(step_output.return_values)
        else:
            import json as _json
            try:
                step_str = _json.dumps(step_output if isinstance(step_output, dict) else str(step_output))
            except (TypeError, ValueError):
                step_str = str(step_output)

        result = _do_check_sync(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name="agent_step",
                agent_name="crewai-step-callback",
                framework_action="framework.crewai.agent_step",
                input_dict={"step": step_str},
                message_preview=step_str[:200],
                pack_ids=pack_ids,
                extra_metadata={"stepPreview": step_str[:200]},
                source="step_callback",
            ),
            check_fn=_check_fn,
        )

        _enforce_decision(result, "agent_step", raise_on_deny)

    return governance_step_callback


# ---------------------------------------------------------------------------
# governance_task_callback -- task completion audit hook
#
# OBSERVABILITY ONLY. Fires after a task completes. Checks task output for
# policy violations. Cannot block the task that produced the output.
# ---------------------------------------------------------------------------

def make_governance_task_callback(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = False,
    _check_fn: Optional[CheckFnType] = None,
) -> Callable:
    """
    Create a task_callback function for CrewAI Crew.

    The returned callback runs a governance check on each completed task's output.
    This is OBSERVABILITY-focused: fires after task completion, cannot block the task.

    BLOCKING CONTRACT: OBSERVABILITY (fires after task, not before).

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY (default False for task_callback).
        _check_fn: Test injection hook (not public API).

    Returns:
        A callable suitable for use as CrewAI Crew(task_callback=...).
    """

    def governance_task_callback(task_output: Any) -> None:
        """
        CrewAI task_callback: runs governance check on completed task output.

        OBSERVABILITY: fires after task completes. Cannot block the task.

        Args:
            task_output: The output of the completed task. May be a string,
                dict, or CrewAI TaskOutput object.
        """
        if task_output is None:
            output_str = ""
        elif isinstance(task_output, str):
            output_str = task_output
        elif hasattr(task_output, "raw"):
            output_str = str(task_output.raw)
        elif hasattr(task_output, "result"):
            output_str = str(task_output.result)
        elif hasattr(task_output, "output"):
            output_str = str(task_output.output)
        else:
            import json as _json
            try:
                output_str = _json.dumps(task_output if isinstance(task_output, dict) else str(task_output))
            except (TypeError, ValueError):
                output_str = str(task_output)

        result = _do_check_sync(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name="task_complete",
                agent_name="crewai-task-callback",
                framework_action="framework.crewai.task_complete",
                input_dict={"output": output_str},
                message_preview=output_str[:200],
                pack_ids=pack_ids,
                extra_metadata={"outputPreview": output_str[:200]},
                source="task_callback",
            ),
            check_fn=_check_fn,
        )

        _enforce_decision(result, "task_complete", raise_on_deny)

    return governance_task_callback


# ---------------------------------------------------------------------------
# wrap_agent -- wrap all tools on a single CrewAI Agent
# ---------------------------------------------------------------------------

def wrap_agent(
    agent: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wrap all tools on a CrewAI Agent with governance enforcement.

    Replaces each tool in agent.tools with a GovernanceCrewAITool wrapper.
    Returns the same agent with governed tools.

    BLOCKING CONTRACT: GUARANTEED per tool (via GovernanceCrewAITool._run()).

    Args:
        agent: A CrewAI Agent with a .tools attribute (list of BaseTool instances).
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same agent with all tools replaced by GovernanceCrewAITool wrappers.
    """
    tools = getattr(agent, "tools", None)
    if tools is None:
        return agent

    governed_tools = []
    for tool in tools:
        if isinstance(tool, GovernanceCrewAITool):
            governed_tools.append(tool)
        else:
            try:
                governed_tools.append(
                    GovernanceCrewAITool(
                        tool=tool,
                        governance_server_url=governance_server_url,
                        license_key=license_key,
                        pack_ids=pack_ids,
                        raise_on_deny=raise_on_deny,
                        _check_fn=_check_fn,
                    )
                )
            except (ValueError, AttributeError):
                sys.stderr.write(
                    f"[wrap_agent] Could not wrap tool {tool!r} -- "
                    f"missing .name attribute. Keeping unwrapped.\n"
                )
                governed_tools.append(tool)

    agent.tools = governed_tools
    return agent


# ---------------------------------------------------------------------------
# wrap_crew -- wrap all agents + inject callbacks into a Crew
# ---------------------------------------------------------------------------

def wrap_crew(
    crew: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    step_callback_raise_on_deny: bool = False,
    task_callback_raise_on_deny: bool = False,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wrap all agents in a CrewAI Crew with governance enforcement + inject callbacks.

    Steps performed:
      1. For each agent in crew.agents, wrap all tools with GovernanceCrewAITool.
      2. Inject governance_step_callback into crew.step_callback.
      3. Inject governance_task_callback into crew.task_callback.
      4. Wrap crew.kickoff() / crew.kickoff_async() to run a pre-kickoff
         governance check (framework.crewai.crew_kickoff).

    Returns the same crew with governance wired.

    BLOCKING CONTRACT:
      - Per-tool blocking via GovernanceCrewAITool._run() (GUARANTEED).
      - Pre-kickoff blocking via kickoff() wrap (GUARANTEED at crew start).
      - step_callback / task_callback (OBSERVABILITY -- fires after action).

    Args:
        crew: A CrewAI Crew with .agents, optional .step_callback, .task_callback.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY for tool-level and kickoff checks.
        step_callback_raise_on_deny: Whether step_callback raises on DENY
            (default False: observe-only for steps).
        task_callback_raise_on_deny: Whether task_callback raises on DENY
            (default False: observe-only for tasks).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same crew with governance wired across all layers.
    """
    # 1. Wrap all agent tools
    agents = getattr(crew, "agents", None) or []
    for agent in agents:
        wrap_agent(
            agent=agent,
            governance_server_url=governance_server_url,
            license_key=license_key,
            pack_ids=pack_ids,
            raise_on_deny=raise_on_deny,
            _check_fn=_check_fn,
        )

    # 2. Inject step_callback
    step_cb = make_governance_step_callback(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=step_callback_raise_on_deny,
        _check_fn=_check_fn,
    )
    existing_step_cb = getattr(crew, "step_callback", None)
    if existing_step_cb is None:
        crew.step_callback = step_cb
    else:
        # Chain: run existing callback first, then governance
        original_step_cb = existing_step_cb

        def chained_step_cb(step_output: Any) -> None:
            original_step_cb(step_output)
            step_cb(step_output)

        crew.step_callback = chained_step_cb

    # 3. Inject task_callback
    task_cb = make_governance_task_callback(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=task_callback_raise_on_deny,
        _check_fn=_check_fn,
    )
    existing_task_cb = getattr(crew, "task_callback", None)
    if existing_task_cb is None:
        crew.task_callback = task_cb
    else:
        original_task_cb = existing_task_cb

        def chained_task_cb(task_output: Any) -> None:
            original_task_cb(task_output)
            task_cb(task_output)

        crew.task_callback = chained_task_cb

    # 4. Wrap kickoff() with pre-kickoff governance check
    original_kickoff = getattr(crew, "kickoff", None)
    if original_kickoff is not None:
        def governed_kickoff(*args: Any, **kwargs: Any) -> Any:
            """Run pre-kickoff governance check, then delegate to original kickoff."""
            result = _do_check_sync(
                governance_server_url=governance_server_url,
                license_key=license_key,
                body=build_check_action_body(
                    tool_name="crew_kickoff",
                    agent_name="crewai-crew",
                    framework_action="framework.crewai.crew_kickoff",
                    pack_ids=pack_ids,
                    extra_metadata={"agentCount": len(agents)},
                    source="wrap_crew.kickoff",
                ),
                check_fn=_check_fn,
            )
            _enforce_decision(result, "crew_kickoff", raise_on_deny)
            return original_kickoff(*args, **kwargs)

        crew.kickoff = governed_kickoff

    # Wrap async kickoff if present
    original_kickoff_async = getattr(crew, "kickoff_async", None)
    if original_kickoff_async is not None:
        async def governed_kickoff_async(*args: Any, **kwargs: Any) -> Any:
            """Async pre-kickoff governance check, then delegate."""
            result = await _do_check_async(
                governance_server_url=governance_server_url,
                license_key=license_key,
                body=build_check_action_body(
                    tool_name="crew_kickoff",
                    agent_name="crewai-crew",
                    framework_action="framework.crewai.crew_kickoff",
                    pack_ids=pack_ids,
                    extra_metadata={"agentCount": len(agents)},
                    source="wrap_crew.kickoff_async",
                ),
                check_fn=_check_fn,
            )
            _enforce_decision(result, "crew_kickoff", raise_on_deny)
            return await original_kickoff_async(*args, **kwargs)

        crew.kickoff_async = governed_kickoff_async

    return crew


# ---------------------------------------------------------------------------
# create_governed_crewai -- primary public factory namespace
# ---------------------------------------------------------------------------

@dataclass
class GovernedCrewAIInstance:
    """
    Governed CrewAI object returned by create_governed_crewai.

    Exposes all integration helpers for the CrewAI framework adapter.
    """

    _governance_server_url: str
    _license_key: str
    _pack_ids: list
    _raise_on_deny: bool
    _check_fn: Optional[CheckFnType]

    def governed_tool(self, tool: Any) -> GovernanceCrewAITool:
        """
        Wrap a single CrewAI tool with governance on _run().
        GUARANTEED BLOCKING: governance check runs before tool execution.
        """
        return GovernanceCrewAITool(
            tool=tool,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_agent(self, agent: Any) -> Any:
        """
        Wrap all tools on a CrewAI Agent.
        GUARANTEED BLOCKING per tool via GovernanceCrewAITool._run().
        """
        return wrap_agent(
            agent=agent,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_crew(
        self,
        crew: Any,
        step_callback_raise_on_deny: bool = False,
        task_callback_raise_on_deny: bool = False,
    ) -> Any:
        """
        Wrap all agents in a Crew + inject governance callbacks.
        Full defense-in-depth: tools (guaranteed) + kickoff + callbacks.
        """
        return wrap_crew(
            crew=crew,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            step_callback_raise_on_deny=step_callback_raise_on_deny,
            task_callback_raise_on_deny=task_callback_raise_on_deny,
            _check_fn=self._check_fn,
        )

    def make_step_callback(self, raise_on_deny: bool = False) -> Callable:
        """Create a step_callback for manual Crew construction."""
        return make_governance_step_callback(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=raise_on_deny,
            _check_fn=self._check_fn,
        )

    def make_task_callback(self, raise_on_deny: bool = False) -> Callable:
        """Create a task_callback for manual Crew construction."""
        return make_governance_task_callback(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=raise_on_deny,
            _check_fn=self._check_fn,
        )


def create_governed_crewai(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedCrewAIInstance:
    """
    Primary factory for the CrewAI governance adapter.

    Returns a GovernedCrewAIInstance exposing all integration helpers.

    Usage:
        gov = create_governed_crewai(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        # Option 1 (guaranteed blocking): wrap individual tools
        safe_tool = gov.governed_tool(raw_tool)
        agent = Agent(role="researcher", tools=[safe_tool], ...)

        # Option 2 (agent-level): wrap all tools on an agent at once
        agent = gov.wrap_agent(agent)

        # Option 3 (crew-level, full defense-in-depth):
        crew = gov.wrap_crew(crew)
        crew.kickoff()  # pre-kickoff governance check runs automatically

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedCrewAIInstance with all integration helpers.
    """
    if not governance_server_url:
        raise ValueError("[create_governed_crewai] governance_server_url is required")
    if not license_key:
        raise ValueError("[create_governed_crewai] license_key is required")

    return GovernedCrewAIInstance(
        _governance_server_url=governance_server_url,
        _license_key=license_key,
        _pack_ids=pack_ids or [],
        _raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )
