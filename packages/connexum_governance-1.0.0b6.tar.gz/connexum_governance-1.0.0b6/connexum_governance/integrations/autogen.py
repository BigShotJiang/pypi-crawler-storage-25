"""AutoGen integration for Connexum governance.

Provides a GovernanceGuardrail that wraps AutoGen's function calling
with governance enforcement. Works with pyautogen's ConversableAgent.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations import GovernanceGuardrail

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    guardrail = GovernanceGuardrail(client=gov, agent_name="coder")

    # Wrap a function before registering with AutoGen
    @guardrail.protect("execute_code")
    def execute_code(code: str) -> str:
        return exec_in_sandbox(code)

    # Or use as a message filter
    agent = ConversableAgent(
        name="coder",
        function_map={"execute_code": guardrail.protect("execute_code")(execute_code)},
    )
"""

from __future__ import annotations

import functools
import time
from typing import Any, Callable, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceViolation


class GovernanceGuardrail:
    """AutoGen-compatible guardrail with governance enforcement.

    Wraps functions registered in AutoGen's function_map so every
    call goes through governance check_action before execution.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)

    def protect(self, tool_name: str) -> Callable:
        """Decorator that wraps a function with governance enforcement.

        Args:
            tool_name: The governance tool name for this function

        Returns:
            Decorator that wraps the function
        """
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                # Build input dict from function arguments
                input_dict = dict(kwargs)
                if args:
                    input_dict["_positional_args"] = [str(a) for a in args]

                decision = self.client.check_action(
                    tool=f"tool.{tool_name}",
                    input=input_dict,
                    agent=self.agent,
                )

                if decision.denied:
                    if self.client.enforce:
                        raise GovernanceViolation(decision)
                    return f"[GOVERNANCE DENIED] {decision.reason}"

                if decision.requires_approval:
                    return (
                        f"[GOVERNANCE PENDING] Action requires approval. "
                        f"Audit ID: {decision.audit_id}"
                    )

                start = time.monotonic()
                error_msg = None
                result = None
                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as exc:
                    error_msg = str(exc)
                    raise
                finally:
                    elapsed_ms = int((time.monotonic() - start) * 1000)
                    if decision.audit_id:
                        try:
                            self.client.report_result(
                                audit_id=decision.audit_id,
                                success=error_msg is None,
                                summary=str(result)[:200] if result else "",
                                duration_ms=elapsed_ms,
                                error=error_msg,
                            )
                        except Exception as exc:  # H2: never swallow -- always log
                            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

            return wrapper
        return decorator

    def check_message(
        self,
        sender: str,
        message: str,
        recipient: Optional[str] = None,
    ) -> Optional[str]:
        """Check if an agent-to-agent message is allowed.

        Useful as a pre-filter on AutoGen's message flow.

        Args:
            sender: Name of the sending agent
            message: Message content
            recipient: Name of the receiving agent

        Returns:
            None if allowed, denial reason if denied
        """
        decision = self.client.check_action(
            tool="agent_message",
            input={
                "sender": sender,
                "message": message[:500],
                "recipient": recipient or "unknown",
            },
            agent=AgentIdentity(name=sender),
        )

        if decision.denied:
            return f"[GOVERNANCE DENIED] {decision.reason}"

        return None
