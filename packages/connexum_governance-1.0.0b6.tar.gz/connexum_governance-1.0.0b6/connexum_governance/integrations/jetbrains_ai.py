"""JetBrains AI Assistant governance integration.

Covers JetBrains AI Assistant across IntelliJ IDEA, PyCharm, WebStorm,
GoLand, Rider, DataGrip, and the full JetBrains IDE family.

Architecture:
  The primary adapter is TypeScript-native (`src/ide-adapters/jetbrains-ai.ts`).
  This Python shim lets a Python-hosted governance policy server participate
  in the JetBrains AI decision loop via HTTP.

  Two principal surfaces:
    intercept_chat(request)   -- pre/post-chat gate + ingress scan
    intercept_inline(request) -- pre/post-completion gate + ingress scan

  JetBrains-specific surfaces:
    intercept_refactor(request)        -- AI refactor gate (PT-ADAPT-JBAI-1)
    intercept_commit_message(request)  -- AI commit message gate (PT-ADAPT-JBAI-2)
    intercept_datagrip_result(request) -- DataGrip PHI column gate (PT-ADAPT-JBAI-3)

JetBrains AI backends:
  'jetbrains-cloud' -- default; JetBrains must have BAA in place for HIPAA.
  'ollama'          -- self-hosted; customer controls data. BAA-eligible.
  'openai'          -- customer holds OpenAI BAA.
  'anthropic'       -- customer holds Anthropic BAA.
  'azure-openai'    -- customer holds Microsoft BAA.

  'jetbrains-cloud' is NOT on the BAA-eligible list in this adapter.
  Customers using it under HIPAA must switch to a BAA-eligible backend.

DataGrip strict mode (PT-ADAPT-JBAI-3):
  When ide_variant='datagrip', column names in query result sets are scanned
  for PHI and PCI indicators. Matching columns under HIPAA binding require
  HITL approval before AI analysis proceeds.

Pen-test IDs mirrored from TS adapter:
  PT-ADAPT-JBAI-1: pre-refactor PHI check
  PT-ADAPT-JBAI-2: pre-commit-message secret scan
  PT-ADAPT-JBAI-3: DataGrip PHI column gate under HIPAA

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.jetbrains_ai import JetBrainsAIGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = JetBrainsAIGovernance(
        client=gov,
        agent_name="jb-ai-agent",
        pack_binding=["hipaa"],
        ai_backend="anthropic",
        ide_variant="datagrip",
    )

    decision = adapter.intercept_chat({
        "promptText": "Explain this query",
        "packBinding": ["hipaa"],
    })

    decision = adapter.intercept_datagrip_result({
        "columns": ["patient_id", "diagnosis", "order_date"],
        "query": "SELECT * FROM patients",
        "packBinding": ["hipaa"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Literal, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# JetBrains AI backend types
# ---------------------------------------------------------------------------

JetBrainsAiBackend = Literal[
    "jetbrains-cloud", "ollama", "openai", "anthropic", "azure-openai"
]

JetBrainsIdeVariant = Literal[
    "intellij-idea", "pycharm", "webstorm", "goland", "rider",
    "datagrip", "rubymine", "clion", "phpstorm", "unknown"
]

# Backends that carry a BAA-eligible data-processing agreement.
# 'jetbrains-cloud' is NOT included -- JetBrains must provide a BAA explicitly.
JETBRAINS_BAA_ELIGIBLE_BACKENDS = frozenset({
    "ollama",        # self-hosted, customer controls data
    "openai",        # customer holds OpenAI BAA
    "anthropic",     # customer holds Anthropic BAA
    "azure-openai",  # customer holds Microsoft BAA
})

# ---------------------------------------------------------------------------
# DataGrip PHI column name patterns (PT-ADAPT-JBAI-3)
# ---------------------------------------------------------------------------

_DATAGRIP_PHI_COLUMN_PATTERNS: list[re.Pattern] = [
    re.compile(r"\bpatient[_]?(id|name|ssn|dob|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bsocial[_]?security\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_]?of[_]?birth\b", re.IGNORECASE),
    re.compile(r"\bdob\b"),
    re.compile(r"\bdiagnos[ie]", re.IGNORECASE),
    re.compile(r"\btreatment\b", re.IGNORECASE),
    re.compile(r"\bmedical[_]?record\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
    re.compile(r"\bcard[_]?number\b", re.IGNORECASE),  # PCI
    re.compile(r"\bpan\b"),                             # Primary Account Number
    re.compile(r"\bcvv\b", re.IGNORECASE),
]

# ---------------------------------------------------------------------------
# Secret patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",          re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",              re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",       re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",          re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",      re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",  re.compile(r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Bearer token",            re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
    ("Database URL with creds", re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bsocial[_\s]?security\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_diff_for_secrets(diff: str) -> Optional[dict[str, Any]]:
    """Scan unified diff for secrets on added lines. Returns first finding or None."""
    for line_num, line in enumerate(diff.splitlines(), start=1):
        if not line.startswith("+") or line.startswith("+++"):
            continue
        content = line[1:]
        for name, pattern in _SECRET_PATTERNS:
            if pattern.search(content):
                return {"line": line_num, "pattern": name}
    return None


def _scan_for_phi(text: str) -> Optional[str]:
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _check_datagrip_phi_columns(columns: list[str]) -> list[str]:
    """Return list of column names matching DataGrip PHI patterns."""
    phi_columns = []
    for col in columns:
        for pattern in _DATAGRIP_PHI_COLUMN_PATTERNS:
            if pattern.search(col):
                phi_columns.append(col)
                break
    return phi_columns


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(p.lower() in ("hipaa", "hitech") for p in pack_binding)


# ---------------------------------------------------------------------------
# JetBrainsAIGovernance
# ---------------------------------------------------------------------------

class JetBrainsAIGovernance(BaseGovernanceIntegration):
    """REST-client shim for JetBrains AI Assistant governance.

    JetBrains AI is TypeScript-native. This Python shim participates in
    the decision loop by:
      1. Gating chat requests (intercept_chat)
      2. Gating inline completion requests (intercept_inline)
      3. Gating AI refactor requests (intercept_refactor, PT-ADAPT-JBAI-1)
      4. Gating AI commit message generation (intercept_commit_message, PT-ADAPT-JBAI-2)
      5. Gating DataGrip result-set analysis (intercept_datagrip_result, PT-ADAPT-JBAI-3)
      6. Providing policy_bridge() for Python policy participation

    Backend compliance:
      Under HIPAA binding, 'jetbrains-cloud' backend is blocked.
      BAA-eligible backends: ollama, openai, anthropic, azure-openai.

    DataGrip strict mode:
      When ide_variant='datagrip', column names are scanned for PHI/PCI
      indicators. Matching columns under HIPAA require HITL approval.
    """

    _FRAMEWORK_NAME = "jetbrains-ai"
    _LAYER_NAME = "jetbrains-ai-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        ai_backend: JetBrainsAiBackend = "jetbrains-cloud",
        ide_variant: JetBrainsIdeVariant = "unknown",
        hipaa_reviewer_tier: str = "T2_LEAD",
        refactor_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            ai_backend: JetBrains AI backend in use.
            ide_variant: JetBrains IDE variant (use 'datagrip' for DataGrip strict mode).
            hipaa_reviewer_tier: Reviewer tier for HIPAA-bound PHI violations.
            refactor_reviewer_tier: Reviewer tier for refactor/commit-message operations.
        """
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.ai_backend: JetBrainsAiBackend = ai_backend
        self.ide_variant: JetBrainsIdeVariant = ide_variant
        self.hipaa_reviewer_tier = hipaa_reviewer_tier
        self.refactor_reviewer_tier = refactor_reviewer_tier

    # ------------------------------------------------------------------
    # intercept_chat -- pre/post-chat gate
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a JetBrains AI chat request.

        Handles both pre-chat and post-chat directions based on request['direction']:
          'pre'  -- gate outbound chat request (default)
          'post' -- scan incoming chat response for secrets

        Guards applied for 'pre' direction:
          1. Pack-binding primacy
          2. Secret scan on prompt text
          3. PHI proximity check under HIPAA
          4. Backend compliance (jetbrains-cloud blocked under HIPAA)

        Args:
            request: Chat request dict with keys:
                     promptText, responseText (post), direction, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        direction = str(request.get("direction", "pre"))
        prompt_text = str(request.get("promptText", request.get("prompt", "")))
        response_text = str(request.get("responseText", request.get("response", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        backend = str(request.get("backend", self.ai_backend))

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "JetBrains AI chat request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        if direction == "post":
            secret_match = _scan_for_secrets(response_text)
            if secret_match:
                return self._deny(
                    agent_id,
                    f"Chat response blocked: secret pattern '{secret_match}' "
                    "found in response.",
                    pack_binding=pack_binding,
                )
            return self.emit_event("llmResult", {
                "agentId": agent_id,
                "model": backend,
                "responseText": response_text[:100],
                "packBinding": pack_binding,
            })

        # 'pre' direction

        # Secret scan
        secret_match = _scan_for_secrets(prompt_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Chat request blocked: secret pattern '{secret_match}' in prompt.",
                pack_binding=pack_binding,
            )

        # PHI proximity check under HIPAA
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(prompt_text)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": backend,
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Chat request routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' found in prompt. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

            # Backend compliance under HIPAA
            if backend not in JETBRAINS_BAA_ELIGIBLE_BACKENDS:
                return self._deny(
                    agent_id,
                    f"JetBrains AI backend '{backend}' is not BAA-eligible under HIPAA binding. "
                    "Switch to ollama (self-hosted), openai, anthropic, or azure-openai, "
                    "and ensure a BAA is in place with the provider.",
                    pack_binding=pack_binding,
                )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": backend,
            "messageCount": 1,
            "packBinding": pack_binding,
            "chatRequest": True,
            "ideVariant": self.ide_variant,
        })

    # ------------------------------------------------------------------
    # intercept_inline -- pre/post-completion gate
    # ------------------------------------------------------------------

    def intercept_inline(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a JetBrains AI inline completion request.

        Handles both pre-completion and post-completion directions.

        Guards applied for 'pre':
          1. Pack-binding primacy
          2. Secret scan on surrounding context
          3. PHI proximity check under HIPAA
          4. Backend compliance

        Args:
            request: Completion request dict with keys:
                     surroundingContext, completionText (post), filePath,
                     direction, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        direction = str(request.get("direction", "pre"))
        surrounding_context = str(request.get("surroundingContext", request.get("context", "")))
        completion_text = str(request.get("completionText", request.get("completion", "")))
        file_path = str(request.get("filePath", request.get("file_path", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        backend = str(request.get("backend", self.ai_backend))

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "JetBrains AI inline completion request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        if direction == "post":
            secret_match = _scan_for_secrets(completion_text)
            if secret_match:
                return self._deny(
                    agent_id,
                    f"Completion response blocked: secret pattern '{secret_match}' "
                    "in returned code.",
                    pack_binding=pack_binding,
                )
            return self.emit_event("toolResult", {
                "agentId": agent_id,
                "toolName": "jb:completion-received",
                "result": completion_text[:100],
                "packBinding": pack_binding,
            })

        # 'pre' direction

        secret_match = _scan_for_secrets(surrounding_context)
        if secret_match:
            return self._deny(
                agent_id,
                f"Completion blocked: secret pattern '{secret_match}' "
                f"in surrounding context ({file_path}).",
                pack_binding=pack_binding,
            )

        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(surrounding_context)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": backend,
                    "messageCount": 0,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Completion routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' in context ({file_path}). "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                    "filePath": file_path,
                })

            if backend not in JETBRAINS_BAA_ELIGIBLE_BACKENDS:
                return self._deny(
                    agent_id,
                    f"JetBrains AI backend '{backend}' is not BAA-eligible under HIPAA binding.",
                    pack_binding=pack_binding,
                )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": backend,
            "messageCount": 0,
            "packBinding": pack_binding,
            "filePath": file_path,
            "completionRequest": True,
            "ideVariant": self.ide_variant,
        })

    # ------------------------------------------------------------------
    # intercept_refactor -- AI refactor gate (PT-ADAPT-JBAI-1)
    # ------------------------------------------------------------------

    def intercept_refactor(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a JetBrains AI Refactor-with-AI request (PT-ADAPT-JBAI-1).

        Checks the target symbol context for PHI or secrets BEFORE the refactor
        AI prompt is sent to the backend.

        Guards applied:
          1. Pack-binding primacy
          2. Secret scan on target symbol + intent + surrounding context
          3. PHI proximity check under HIPAA

        Args:
            request: Refactor request dict with keys:
                     targetSymbol, intent, surroundingContext, filePath,
                     packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        target_symbol = str(request.get("targetSymbol", request.get("symbol", "")))
        intent = str(request.get("intent", ""))
        surrounding_context = str(request.get("surroundingContext", ""))
        file_path = str(request.get("filePath", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        backend = str(request.get("backend", self.ai_backend))

        if not pack_binding:
            return self._deny(
                agent_id,
                "JetBrains AI refactor request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        combined = f"{target_symbol} {intent} {surrounding_context}"

        # Secret scan
        secret_match = _scan_for_secrets(combined)
        if secret_match:
            return self._deny(
                agent_id,
                f"Refactor request blocked: secret pattern '{secret_match}' found in target "
                f"symbol context ({file_path or 'unknown file'}). "
                "Remove the secret before requesting AI refactoring.",
                pack_binding=pack_binding,
            )

        # PHI proximity check under HIPAA (PT-ADAPT-JBAI-1)
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(combined)
            if phi_indicator:
                return self._deny(
                    agent_id,
                    f"Refactor request blocked under HIPAA binding: PHI indicator "
                    f"'{phi_indicator}' found in target symbol '{target_symbol}' context. "
                    f"Reviewer tier: {self.refactor_reviewer_tier}. "
                    "Ensure the refactoring plan is reviewed before the AI prompt is sent.",
                    pack_binding=pack_binding,
                )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": backend,
            "messageCount": 1,
            "packBinding": pack_binding,
            "targetSymbol": target_symbol,
            "refactorRequest": True,
            "ideVariant": self.ide_variant,
        })

    # ------------------------------------------------------------------
    # intercept_commit_message -- AI commit message gate (PT-ADAPT-JBAI-2)
    # ------------------------------------------------------------------

    def intercept_commit_message(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a JetBrains AI commit message generation request (PT-ADAPT-JBAI-2).

        Classifies the diff for secret leaks BEFORE the message generation
        prompt is sent to the backend. Only added lines (starting with '+')
        are scanned.

        Args:
            request: Commit message request dict with keys:
                     diff, branchName, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        diff = str(request.get("diff", ""))
        branch_name = str(request.get("branchName", request.get("branch", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        backend = str(request.get("backend", self.ai_backend))

        if not pack_binding:
            return self._deny(
                agent_id,
                "JetBrains AI commit message request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        finding = _scan_diff_for_secrets(diff)
        if finding:
            return self._deny(
                agent_id,
                f"Commit message generation blocked: secret pattern '{finding['pattern']}' "
                f"detected in diff at line {finding['line']}. "
                "Remove the secret from the staged changes before generating a commit message. "
                f"Branch: {branch_name or 'unknown'}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": backend,
            "messageCount": 1,
            "packBinding": pack_binding,
            "branchName": branch_name,
            "commitMessageRequest": True,
            "ideVariant": self.ide_variant,
        })

    # ------------------------------------------------------------------
    # intercept_datagrip_result -- DataGrip PHI column gate (PT-ADAPT-JBAI-3)
    # ------------------------------------------------------------------

    def intercept_datagrip_result(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a DataGrip query result-set AI analysis request (PT-ADAPT-JBAI-3).

        Scans column names for PHI and PCI indicators. Under HIPAA binding,
        matching columns require HITL approval before AI analysis proceeds.

        Without HIPAA binding, matching columns produce a warning but are allowed.

        Args:
            request: DataGrip result-set request dict with keys:
                     columns, query, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        columns: list[str] = list(request.get("columns", []))
        query = str(request.get("query", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        backend = str(request.get("backend", self.ai_backend))

        if not pack_binding:
            return self._deny(
                agent_id,
                "JetBrains AI DataGrip result request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        phi_columns = _check_datagrip_phi_columns(columns)

        if phi_columns:
            if _is_hipaa_binding(pack_binding):
                # Under HIPAA: require HITL approval (deny until reviewed)
                return self._deny(
                    agent_id,
                    f"DataGrip result-set analysis blocked under HIPAA binding: "
                    f"columns [{', '.join(phi_columns)}] indicate PHI data. "
                    f"Reviewer tier: {self.hipaa_reviewer_tier}. "
                    f"Tag the data class before allowing AI analysis. "
                    f"IDE: {self.ide_variant}.",
                    pack_binding=pack_binding,
                )
            else:
                # Non-HIPAA: warn via stderr but allow
                print(
                    f"[GOVERNANCE] JetBrains AI DataGrip: PHI-indicator columns "
                    f"[{', '.join(phi_columns)}] present but no HIPAA pack binding active. "
                    "Allowed with WARN. Consider adding HIPAA pack binding.",
                    file=sys.stderr,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "jb:datagrip-result-requested",
            "args": {
                "columnCount": len(columns),
                "phiColumnCount": len(phi_columns),
                "query": query[:100] if query else "",
            },
            "packBinding": pack_binding,
            "ideVariant": self.ide_variant,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown JetBrainsAI event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] JetBrainsAI output classifier: possible secret in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] JetBrainsAI output exfiltration scanner: possible "
                    f'secret/PHI in LLM response (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Inject backend/IDE metadata and delegate to base (M2)
        enriched = {"aiBackend": self.ai_backend, "ideVariant": self.ide_variant, **payload}
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload and forward it as a canonical governance event."""
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError(
                "JetBrainsAI webhook payload missing required field: 'eventType'"
            )
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError(
                "JetBrainsAI webhook payload missing required field: 'agentId'"
            )
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "JetBrainsAIPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return JetBrainsAIPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# JetBrainsAIPolicyBridge
# ---------------------------------------------------------------------------

class JetBrainsAIPolicyBridge:
    """Bridge for Python-hosted policy participation in the JetBrains AI loop."""

    def __init__(
        self,
        adapter: JetBrainsAIGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
