"""
GovernedLangGraph -- governance enforcement for LangGraph standalone (Python).

This is a DEDICATED LangGraph adapter for customers using LangGraph as a
standalone package (without other LangChain primitives, or as the primary
orchestration layer). It provides richer interception than the lightweight
wrap_state_graph() in the LangChain adapter.

IMPORTANT: The LangChain adapter (langchain_integration.py) includes a
wrap_state_graph() function that works for LangChain users who use LangGraph.
That function now re-exports from this module so existing customers are not
broken. New customers using LangGraph standalone should use this module directly.

=== ARCHITECTURAL CONTRAST: LangGraph vs other frameworks ===

OpenAI Agents SDK: FIRST-CLASS blocking via guardrails (SDK contract).
LangChain: GovernedTool._run() is GUARANTEED; callbacks are OBSERVABILITY-FIRST.
LlamaIndex: GovernedFunctionTool.__call__ is GUARANTEED.
CrewAI: GovernanceCrewAITool._run() is GUARANTEED.

LangGraph's blocking story is more layered:

  StateGraph / MessageGraph:
    LangGraph builds a Pregel execution graph. The graph is compiled via
    compile() into a Pregel runnable with invoke() / ainvoke() / stream().
    There is no single dispatch point equivalent to LangChain's Tool._run().
    Nodes are arbitrary callables. The correct interception strategy is:

    1. COMPILE-LEVEL wrap (GUARANTEED per-invocation):
       Wrap compile() so the returned Pregel's invoke/ainvoke runs a
       governance check on the input state before ANY node executes. This
       is the most conservative gate: one check per graph run, catches
       policy violations at the outermost boundary.

    2. PER-NODE wrap (GUARANTEED per-node, requires add_node interception):
       Wrap add_node() so every registered node function is wrapped with
       a governance check. This catches violations at individual node
       boundaries (especially ToolNode). Multiple checks per run (one per
       node). This is defense-in-depth but may increase latency.

    3. CONDITIONAL EDGE wrap (OBSERVABILITY / routing check):
       Wrap add_conditional_edges() so the routing function is governance-
       checked before a routing decision is made. This catches policy
       violations in conditional state transitions (e.g., "go to human
       review" vs "continue autonomously").

    4. CHANNEL / STATE observability:
       LangGraph state is managed via channels (TypedDict or dataclass).
       State changes are auditable but not a blocking point in the current
       adapter -- channels don't have a single interception hook.

BLOCKING STORY (ranked):
  1. compile()-level invoke/ainvoke wrap (GovernedStateGraph)
       GUARANTEED: one check fires before any node executes per graph run.
  2. Per-node wrap via add_node interception (GovernedStateGraph)
       GUARANTEED: fires before each wrapped node. Defense-in-depth.
       Slightly higher latency (one check per node turn).
  3. Conditional edge routing function wrap
       BEST-EFFORT routing check: fires before routing decision.
       Useful for catching "should this go to a human?" policy questions.
  4. wrap_pregel() on already-compiled graph
       GUARANTEED per-invocation (same as compile-level wrap).
       Use when you cannot intercept at StateGraph construction time.

ARCHITECTURE NOTE for customers:
  - GovernedStateGraph is the recommended entry point for new graphs.
  - wrap_state_graph() is the convenience function for existing StateGraph instances.
  - wrap_pregel() is for already-compiled graphs (post-compile interception).
  - For per-tool blocking inside ToolNode, wrap the tools with GovernedTool
    (from langchain_integration) before passing them to ToolNode. This module
    handles the graph-level gate; tool-level blocking requires GovernedTool.

Action name namespace (for pack rule targeting):
  framework.langgraph.invoke        -- compile()-level invoke/ainvoke gate
  framework.langgraph.node_execute  -- per-node governance check
  framework.langgraph.edge_transition -- conditional edge routing check
  framework.langgraph.tool_node     -- ToolNode-specific node check

Supported LangGraph version range (tested against mock primitives):
  langgraph >= 0.0.30, < 0.4.0

Architectural difference vs LangChain adapter:
  The LangChain adapter's wrap_state_graph() only wraps add_node(). This
  dedicated adapter adds:
  - compile()-level invoke/ainvoke governance (new)
  - add_conditional_edges() routing function governance (new)
  - wrap_pregel() for post-compile interception (new)
  - GovernedStateGraph proxy class with full construction API (new)

Optional peer dependencies:
  langgraph >= 0.0.30

@connexum/python-sdk -- Framework Adapter Layer (Sprint 5, WS-10)
"""

from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations._wire_shape import build_check_action_body

# ---------------------------------------------------------------------------
# Type alias for check function injection (test isolation)
# ---------------------------------------------------------------------------

CheckFnType = Callable[[str, dict], Any]


# ---------------------------------------------------------------------------
# HTTP check helpers (same pattern as other adapters)
# ---------------------------------------------------------------------------

async def _do_check_async(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """Run an asynchronous governance check."""
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            return await check_fn(governance_server_url, body)
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        async with _httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


def _do_check_sync(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """Run a synchronous governance check."""
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            try:
                loop = asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(
                        lambda: asyncio.run(check_fn(governance_server_url, body))
                    )
                    return future.result()
            except RuntimeError:
                return asyncio.run(check_fn(governance_server_url, body))
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        with _httpx.Client(timeout=5.0) as client:
            resp = client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


# ---------------------------------------------------------------------------
# Decision enforcement helpers
# ---------------------------------------------------------------------------

def _enforce_decision_sync(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
) -> None:
    """Raise on DENY / PENDING when raise_on_deny=True (sync path)."""
    decision = result.get("decision", "ALLOW")

    if decision == "DENY":
        reason = result.get("reason") or "policy"
        sys.stderr.write(
            f"[GovernedLangGraph] DENIED for '{context_label}'. reason={reason}\n"
        )
        if raise_on_deny:
            raise GovernanceViolation(
                decision="DENY",
                reason=reason,
                audit_id=result.get("auditId"),
            )
        return

    if decision == "REQUIRE_APPROVAL":
        approval_id = result.get("approvalId")
        audit_id = result.get("auditId")
        if not approval_id:
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                    audit_id=audit_id,
                )
            return
        sys.stderr.write(
            f"[GovernedLangGraph] PENDING for '{context_label}'. "
            f"approvalId={approval_id}\n"
        )
        if raise_on_deny:
            raise GovernancePendingApproval(
                approval_id=approval_id,
                audit_id=audit_id,
            )


async def _enforce_decision_async(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
) -> None:
    """Raise on DENY / PENDING when raise_on_deny=True (async path)."""
    _enforce_decision_sync(result, context_label, raise_on_deny)


# ---------------------------------------------------------------------------
# Node wrapping helper -- wraps any node fn with a governance check
# ---------------------------------------------------------------------------

def _make_governed_node(
    node_name: str,
    original_node: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: list,
    raise_on_deny: bool,
    check_fn: Optional[CheckFnType],
    action: str = "framework.langgraph.node_execute",
) -> Any:
    """
    Return a governance-wrapped node callable.

    For ToolNode-named nodes, uses action 'framework.langgraph.tool_node'
    to allow pack rules to target ToolNode specifically.
    """
    # Use tool_node action for nodes named "tools" or "tool_node" (convention)
    effective_action = action
    if node_name.lower() in ("tools", "tool_node", "tool-node") or "toolnode" in node_name.lower():
        effective_action = "framework.langgraph.tool_node"

    def governed_node_sync(*args: Any, **kwargs: Any) -> Any:
        result = _do_check_sync(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name=node_name,
                agent_name=f"langgraph-node:{node_name}",
                framework_action=effective_action,
                pack_ids=pack_ids,
                extra_metadata={"nodeName": node_name},
                source="GovernedStateGraph.add_node",
            ),
            check_fn=check_fn,
        )

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "policy"
            sys.stderr.write(
                f"[GovernedStateGraph] node '{node_name}' DENIED. reason={reason}\n"
            )
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return {"governance": "DENIED", "reason": reason}

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            if approval_id and raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=result.get("auditId"),
                )
            if not approval_id and raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                )
            return {"governance": "PENDING", "approvalId": approval_id}

        # ALLOW -- invoke original node
        if callable(original_node):
            return original_node(*args, **kwargs)
        return original_node

    async def governed_node_async(*args: Any, **kwargs: Any) -> Any:
        result = await _do_check_async(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name=node_name,
                agent_name=f"langgraph-node:{node_name}",
                framework_action=effective_action,
                pack_ids=pack_ids,
                extra_metadata={"nodeName": node_name},
                source="GovernedStateGraph.add_node",
            ),
            check_fn=check_fn,
        )

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "policy"
            sys.stderr.write(
                f"[GovernedStateGraph] node '{node_name}' DENIED. reason={reason}\n"
            )
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return {"governance": "DENIED", "reason": reason}

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            if approval_id and raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=result.get("auditId"),
                )
            if not approval_id and raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                )
            return {"governance": "PENDING", "approvalId": approval_id}

        # ALLOW -- invoke original node
        if callable(original_node):
            if asyncio.iscoroutinefunction(original_node):
                return await original_node(*args, **kwargs)
            return original_node(*args, **kwargs)
        return original_node

    if asyncio.iscoroutinefunction(original_node):
        governed_node_async._connexum_governed_node = True
        return governed_node_async
    governed_node_sync._connexum_governed_node = True
    return governed_node_sync


# ---------------------------------------------------------------------------
# GovernedStateGraph -- primary proxy wrapper for StateGraph / MessageGraph
# ---------------------------------------------------------------------------


class GovernedStateGraph:
    """
    Governance proxy for LangGraph StateGraph (and MessageGraph).

    Wraps an existing StateGraph, intercepting:
      - add_node(): wraps each node function with a governance pre-check
      - add_conditional_edges(): wraps the routing function with governance
      - compile(): returns a governed Pregel runnable (invoke/ainvoke checked)

    Other StateGraph methods (add_edge, set_entry_point, etc.) are delegated
    transparently to the underlying graph.

    BLOCKING CONTRACT:
      - Per-node governance fires BEFORE each node executes (strongest per-node).
      - Compile-level governance fires BEFORE any node in a graph run.
      - Conditional edge routing governance fires BEFORE routing decisions.

    Usage:
        from connexum_governance.integrations.langgraph_integration import (
            GovernedStateGraph,
        )

        # Wrap at construction time
        from langgraph.graph import StateGraph
        raw_graph = StateGraph(MyState)
        gov_graph = GovernedStateGraph(
            graph=raw_graph,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )
        gov_graph.add_node("agent", agent_fn)
        gov_graph.add_node("tools", tool_node)
        gov_graph.add_edge("agent", "tools")
        gov_graph.add_conditional_edges("tools", routing_fn)
        app = gov_graph.compile()
        result = app.invoke({"messages": [...]})

    Architecture:
      GovernedStateGraph is a thin proxy. All method calls that are not
      intercepted (add_edge, set_entry_point, set_finish_point, etc.) are
      forwarded directly to the underlying StateGraph.
    """

    def __init__(
        self,
        graph: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        """
        Args:
            graph: A LangGraph StateGraph (or MessageGraph, or duck-type equivalent
                with add_node, add_edge, add_conditional_edges, compile).
            governance_server_url: URL of the governance server.
            license_key: License / JWT key for the governance server.
            pack_ids: Compliance pack IDs to evaluate against.
            raise_on_deny: Whether to raise on DENY / PENDING (default True).
            _check_fn: Test injection hook. Not part of the public API.
        """
        if graph is None:
            raise ValueError("[GovernedStateGraph] graph is required")
        if not governance_server_url:
            raise ValueError(
                "[GovernedStateGraph] governance_server_url is required"
            )
        if not license_key:
            raise ValueError("[GovernedStateGraph] license_key is required")

        self._graph = graph
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._check_fn = _check_fn

    def add_node(self, name: str, fn: Any, *args: Any, **kwargs: Any) -> Any:
        """
        Add a node to the graph with governance pre-check wrapping.

        The node function is wrapped so governance fires before the node executes
        on every graph run. This is the per-node GUARANTEED BLOCKING path.

        For ToolNode (nodes named 'tools', 'tool_node', or containing 'toolnode'),
        the action namespace is 'framework.langgraph.tool_node'.

        Args:
            name: The node name.
            fn: The node callable (sync or async). Will be wrapped with governance.
        """
        governed_fn = _make_governed_node(
            node_name=name,
            original_node=fn,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            check_fn=self._check_fn,
        )
        return self._graph.add_node(name, governed_fn, *args, **kwargs)

    def add_conditional_edges(
        self,
        source: str,
        path: Any,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Add conditional edges with governance-wrapped routing function.

        The routing function (path) is wrapped so governance fires before the
        routing decision is made. This catches policy violations in conditional
        state transitions.

        BLOCKING CONTRACT: BEST-EFFORT routing check. If the routing function
        itself is async and the governance check denies, a GovernanceViolation
        is raised before the edge is selected.

        Args:
            source: The source node name.
            path: The routing callable (sync or async). Will be wrapped.
        """
        source_name = source

        def governed_path_sync(state: Any, *inner_args: Any, **inner_kwargs: Any) -> Any:
            result = _do_check_sync(
                governance_server_url=self._governance_server_url,
                license_key=self._license_key,
                body=build_check_action_body(
                    tool_name=f"edge:{source_name}",
                    agent_name=f"langgraph-router:{source_name}",
                    framework_action="framework.langgraph.edge_transition",
                    pack_ids=self._pack_ids,
                    extra_metadata={
                        "source": source_name,
                        "routingFn": getattr(path, "__name__", "unknown"),
                        "triggerSource": "add_conditional_edges",
                    },
                    source="GovernedStateGraph.add_conditional_edges",
                ),
                check_fn=self._check_fn,
            )
            _enforce_decision_sync(
                result, f"edge:{source_name}", self._raise_on_deny
            )
            # ALLOW -- invoke original routing function
            if callable(path):
                return path(state, *inner_args, **inner_kwargs)
            return path

        async def governed_path_async(
            state: Any, *inner_args: Any, **inner_kwargs: Any
        ) -> Any:
            result = await _do_check_async(
                governance_server_url=self._governance_server_url,
                license_key=self._license_key,
                body=build_check_action_body(
                    tool_name=f"edge:{source_name}",
                    agent_name=f"langgraph-router:{source_name}",
                    framework_action="framework.langgraph.edge_transition",
                    pack_ids=self._pack_ids,
                    extra_metadata={
                        "source": source_name,
                        "routingFn": getattr(path, "__name__", "unknown"),
                        "triggerSource": "add_conditional_edges",
                    },
                    source="GovernedStateGraph.add_conditional_edges_async",
                ),
                check_fn=self._check_fn,
            )
            _enforce_decision_sync(
                result, f"edge:{source_name}", self._raise_on_deny
            )
            if callable(path):
                if asyncio.iscoroutinefunction(path):
                    return await path(state, *inner_args, **inner_kwargs)
                return path(state, *inner_args, **inner_kwargs)
            return path

        governed_path = (
            governed_path_async
            if asyncio.iscoroutinefunction(path)
            else governed_path_sync
        )
        return self._graph.add_conditional_edges(source, governed_path, *args, **kwargs)

    def compile(self, *args: Any, **kwargs: Any) -> Any:
        """
        Compile the StateGraph and return a governed Pregel runnable.

        The returned Pregel's invoke() and ainvoke() are wrapped to run a
        governance check on the input state BEFORE any node executes. This
        is the outermost GUARANTEED gate: one check per graph invocation.

        Returns:
            A governed Pregel runnable with governed invoke() and ainvoke().
        """
        pregel = self._graph.compile(*args, **kwargs)
        return wrap_pregel(
            runnable=pregel,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def __getattr__(self, name: str) -> Any:
        """
        Transparently forward all other StateGraph methods to the underlying graph.

        This covers: add_edge, set_entry_point, set_finish_point, set_conditional_entry_point,
        and any other StateGraph methods not intercepted above.
        """
        return getattr(self._graph, name)


# ---------------------------------------------------------------------------
# wrap_pregel -- wrap an already-compiled Pregel runnable
# ---------------------------------------------------------------------------


def wrap_pregel(
    runnable: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wrap an already-compiled LangGraph Pregel runnable with governance.

    Use this when you cannot intercept at StateGraph construction time
    (e.g., when the graph is compiled by library code you don't control).

    Wraps invoke() and ainvoke() to run a governance check on the input
    state before any node in the graph executes.

    BLOCKING CONTRACT: GUARANTEED per-invocation. One check per graph run.

    Args:
        runnable: A compiled LangGraph Pregel instance (has invoke() / ainvoke()).
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same runnable with invoke() and ainvoke() wrapped.
    """
    if getattr(runnable, "_connexum_governed", False):
        return runnable

    original_invoke = getattr(runnable, "invoke", None)
    original_ainvoke = getattr(runnable, "ainvoke", None)

    def _build_state_preview(state: Any) -> str:
        if isinstance(state, str):
            return state[:200]
        if isinstance(state, dict):
            # Try to extract a meaningful preview from common state keys
            for key in ("messages", "input", "query", "content"):
                val = state.get(key)
                if val is not None:
                    if isinstance(val, list) and val:
                        first = val[0]
                        if hasattr(first, "content"):
                            return str(first.content)[:200]
                        return str(first)[:200]
                    return str(val)[:200]
            import json as _json
            try:
                return _json.dumps(state)[:200]
            except Exception:
                return str(state)[:200]
        return str(state)[:200] if state is not None else ""

    if original_invoke is not None:
        def governed_invoke(state: Any = None, config: Any = None, **kwargs: Any) -> Any:
            state_preview = _build_state_preview(state)
            result = _do_check_sync(
                governance_server_url=governance_server_url,
                license_key=license_key,
                body=build_check_action_body(
                    tool_name="pregel.invoke",
                    agent_name="langgraph-pregel",
                    framework_action="framework.langgraph.invoke",
                    input_dict=state if isinstance(state, dict) else {"state": state_preview},
                    message_preview=state_preview,
                    pack_ids=pack_ids,
                    extra_metadata={"statePreview": state_preview},
                    source="wrap_pregel.invoke",
                ),
                check_fn=_check_fn,
            )
            _enforce_decision_sync(result, "graph.invoke", raise_on_deny)
            # ALLOW
            if config is not None:
                return original_invoke(state, config, **kwargs)
            if state is not None:
                return original_invoke(state, **kwargs)
            return original_invoke(**kwargs)

        runnable.invoke = governed_invoke

    if original_ainvoke is not None:
        async def governed_ainvoke(
            state: Any = None, config: Any = None, **kwargs: Any
        ) -> Any:
            state_preview = _build_state_preview(state)
            result = await _do_check_async(
                governance_server_url=governance_server_url,
                license_key=license_key,
                body=build_check_action_body(
                    tool_name="pregel.ainvoke",
                    agent_name="langgraph-pregel",
                    framework_action="framework.langgraph.invoke",
                    input_dict=state if isinstance(state, dict) else {"state": state_preview},
                    message_preview=state_preview,
                    pack_ids=pack_ids,
                    extra_metadata={"statePreview": state_preview},
                    source="wrap_pregel.ainvoke",
                ),
                check_fn=_check_fn,
            )
            _enforce_decision_sync(result, "graph.ainvoke", raise_on_deny)
            # ALLOW
            if config is not None:
                return await original_ainvoke(state, config, **kwargs)
            if state is not None:
                return await original_ainvoke(state, **kwargs)
            return await original_ainvoke(**kwargs)

        runnable.ainvoke = governed_ainvoke

    runnable._connexum_governed = True
    return runnable


# ---------------------------------------------------------------------------
# wrap_state_graph -- canonical implementation (LangChain adapter re-exports this)
# ---------------------------------------------------------------------------


def wrap_state_graph(
    graph: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Injects governance into a LangGraph StateGraph by wrapping all node
    registrations and the compile() step.

    This is the CANONICAL implementation of wrap_state_graph.
    The LangChain adapter (langchain_integration.py) re-exports this function.

    Mutates the StateGraph's add_node() method to intercept ToolNode and other
    node registrations. Also wraps compile() to return a governed Pregel.

    BLOCKING CONTRACT:
      - Per-node: governance fires before each wrapped node (GUARANTEED).
      - Compile-level: governance fires before each graph invocation (GUARANTEED).

    Use this for existing StateGraph instances you don't want to replace with
    GovernedStateGraph. For new graphs, GovernedStateGraph provides a cleaner
    proxy interface with additional edge transition governance.

    Args:
        graph: LangGraph StateGraph with add_node() and compile() methods.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same StateGraph with add_node() wrapped for governance interception.
    """
    if getattr(graph, "_connexum_governed", False):
        return graph

    # Wrap add_node
    original_add_node = graph.add_node

    def governed_add_node(name: str, node: Any, *args: Any, **kwargs: Any) -> Any:
        if getattr(node, "_connexum_governed_node", False):
            return original_add_node(name, node, *args, **kwargs)
        wrapped = _make_governed_node(
            node_name=name,
            original_node=node,
            governance_server_url=governance_server_url,
            license_key=license_key,
            pack_ids=pack_ids or [],
            raise_on_deny=raise_on_deny,
            check_fn=_check_fn,
        )
        return original_add_node(name, wrapped, *args, **kwargs)

    graph.add_node = governed_add_node

    # Wrap compile to return a governed Pregel
    original_compile = getattr(graph, "compile", None)
    if original_compile is not None:
        def governed_compile(*args: Any, **kwargs: Any) -> Any:
            pregel = original_compile(*args, **kwargs)
            return wrap_pregel(
                runnable=pregel,
                governance_server_url=governance_server_url,
                license_key=license_key,
                pack_ids=pack_ids,
                raise_on_deny=raise_on_deny,
                _check_fn=_check_fn,
            )
        graph.compile = governed_compile

    graph._connexum_governed = True
    return graph


# ---------------------------------------------------------------------------
# GovernedLangGraphInstance -- namespace returned by factory
# ---------------------------------------------------------------------------


@dataclass
class GovernedLangGraphInstance:
    """
    Governed LangGraph object returned by create_governed_langgraph().

    Exposes all integration helpers for the standalone LangGraph adapter.
    """

    _governance_server_url: str = field(repr=False)
    _license_key: str = field(repr=False)
    _pack_ids: list = field(default_factory=list, repr=False)
    _raise_on_deny: bool = field(default=True, repr=False)
    _check_fn: Optional[CheckFnType] = field(default=None, repr=False)

    def governed_state_graph(self, graph: Any) -> GovernedStateGraph:
        """
        Return a GovernedStateGraph proxy wrapping the provided StateGraph.

        Use this for new graph construction workflows. All add_node(),
        add_conditional_edges(), and compile() calls are governed.
        """
        return GovernedStateGraph(
            graph=graph,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_graph(self, graph: Any) -> Any:
        """
        Wrap an existing StateGraph in-place (wrap_state_graph convenience).

        Mutates add_node() and compile(). For new graphs, prefer governed_state_graph().
        """
        return wrap_state_graph(
            graph=graph,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_pregel(self, runnable: Any) -> Any:
        """
        Wrap an already-compiled Pregel runnable with governance.

        Use when you cannot intercept at graph construction time.
        """
        return wrap_pregel(
            runnable=runnable,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )


def create_governed_langgraph(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedLangGraphInstance:
    """
    Primary factory for the standalone LangGraph governance adapter.

    Returns a GovernedLangGraphInstance exposing all integration helpers.

    ARCHITECTURAL NOTE: This dedicated adapter provides richer governance than
    the lightweight wrap_state_graph() in the LangChain adapter. Key additions:
      - Per-node governance (guaranteed, one check per node turn)
      - Conditional edge transition governance
      - Compile-level Pregel invoke/ainvoke governance
      - GovernedStateGraph proxy class for clean construction workflows

    Enforcement layers (strongest to weakest):
      1. GovernedStateGraph.add_node (per-node, GUARANTEED)
      2. GovernedStateGraph.compile -> wrap_pregel (per-invocation, GUARANTEED)
      3. GovernedStateGraph.add_conditional_edges (routing, BEST-EFFORT)
      4. wrap_pregel() direct (per-invocation, GUARANTEED)

    Usage:
        gov = create_governed_langgraph(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        # Option 1 (recommended for new graphs):
        from langgraph.graph import StateGraph
        raw_graph = StateGraph(MyState)
        g = gov.governed_state_graph(raw_graph)
        g.add_node("agent", agent_fn)
        g.add_node("tools", tool_node)
        app = g.compile()
        result = app.invoke({"messages": [...]})

        # Option 2 (existing graph):
        raw_graph = StateGraph(MyState)
        raw_graph.add_node("agent", agent_fn)
        gov.wrap_graph(raw_graph)
        app = raw_graph.compile()

        # Option 3 (post-compile):
        app = raw_graph.compile()
        app = gov.wrap_pregel(app)

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedLangGraphInstance with all integration helpers.
    """
    if not governance_server_url:
        raise ValueError(
            "[create_governed_langgraph] governance_server_url is required"
        )
    if not license_key:
        raise ValueError(
            "[create_governed_langgraph] license_key is required"
        )

    return GovernedLangGraphInstance(
        _governance_server_url=governance_server_url,
        _license_key=license_key,
        _pack_ids=pack_ids or [],
        _raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )
