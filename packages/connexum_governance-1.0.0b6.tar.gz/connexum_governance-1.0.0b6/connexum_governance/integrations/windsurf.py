"""Windsurf (Codeium) governance integration.

Windsurf is an agentic IDE built by Codeium. Its core feature is Cascade, a
multi-step agentic system that plans and executes multi-tool workflows
autonomously. Windsurf competes directly with Cursor and has a fast adoption
curve among professional developers. Its agentic depth makes it the
highest-governance-exposure IDE in the Connexum catalogue.

Architecture:
  The primary adapter is TypeScript-native (src/ide-adapters/windsurf.ts).
  This Python shim lets a Python-hosted governance policy server participate
  in the Windsurf decision loop via HTTP.

  Seven distinct governable surfaces (parity with TS adapter):
    intercept_cascade_flow(request)         -- Cascade agentic flow gate (REQUIRES description)
    intercept_chat(request)                 -- chat request gate
    intercept_inline_completion(request)    -- inline completion gate
    intercept_command(request)              -- slash command gate
    intercept_terminal_command(request)     -- terminal execution gate (STRICT)
    intercept_web_search(request)           -- web search gate
    intercept_multi_file_edit(request)      -- multi-file edit gate (blast-radius cap)

  Deployment modes:
    windsurf-cloud      -- Codeium-managed SaaS (default)
    windsurf-enterprise -- Customer-operated VPC or air-gapped deployment
    windsurf-individual -- Individual subscription; no enterprise controls

  Air-gapped sub-mode (windsurf-enterprise only):
    Set air_gapped=True to activate classified-network policy:
      - Web search is UNCONDITIONALLY DENIED.
      - Terminal commands require BOTH allow_terminal_execution=True AND
        the command must start with one of the allowed_terminal_prefixes strings.
    This enables governance of fully-offline enterprise Windsurf deployments.

  Cascade flow gate:
    REQUIRES a non-empty flow_description. Empty/missing description = DENIED.
    Reason code: windsurf-cascade-flow-description-required.

  Terminal command gate:
    Default: DENIED (allow_terminal_execution=False).
    Non-air-gapped with allow_terminal_execution=True: ALLOWED with audit.
    air_gapped=True with allow_terminal_execution=True AND prefix match: ALLOWED.
    air_gapped=True without prefix match: DENIED.

  Multi-file edit blast-radius cap:
    files[] count > multi_file_edit_cap (default 10) = DENIED.

  Pen-test IDs mirrored from TS adapter:
    PT-ADAPT-WINDSURF-1: empty pack_binding denied (pack-binding primacy)
    PT-ADAPT-WINDSURF-2: auth tokens never appear in audit entries
    PT-ADAPT-WINDSURF-3: invalid deployment_mode raises ValueError at init;
                         negative multi_file_edit_cap raises ValueError;
                         air_gapped=True on non-enterprise raises ValueError
    PT-ADAPT-WINDSURF-4: terminal command denials produce audit entries with
                         explicit reason codes
    PT-ADAPT-WINDSURF-5: cascade flow without description produces denial with
                         reason code windsurf-cascade-flow-description-required

BAA-eligible deployment modes:
  windsurf-enterprise (customer controls data residency)

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.windsurf import WindsurfGovernedClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = WindsurfGovernedClient(
        client=gov,
        agent_name="windsurf-agent",
        pack_binding=["hipaa"],
        deployment_mode="windsurf-enterprise",
        air_gapped=True,
        allow_terminal_execution=True,
        allowed_terminal_prefixes=["git ", "npm ", "python "],
    )

    # Gate a Cascade flow (description required):
    decision = adapter.intercept_cascade_flow({
        "flowDescription": "Refactor auth module to use JWT",
        "tools": ["read_file", "edit_file"],
        "packBinding": ["hipaa"],
    })

    # Gate a terminal command in air-gapped mode:
    decision = adapter.intercept_terminal_command({
        "command": "git status",
        "packBinding": ["hipaa"],
    })

    # Gate a web search (denied in air-gapped mode):
    decision = adapter.intercept_web_search({
        "query": "python jwt tutorial",
        "packBinding": ["soc2"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Deployment modes
# ---------------------------------------------------------------------------

WINDSURF_VALID_DEPLOYMENT_MODES: tuple[str, ...] = (
    "windsurf-cloud",
    "windsurf-enterprise",
    "windsurf-individual",
)

WINDSURF_BAA_ELIGIBLE_MODES: tuple[str, ...] = (
    "windsurf-enterprise",  # customer controls data residency
)

# Modes that support air-gapped operation.
WINDSURF_AIR_GAPPED_CAPABLE_MODES: tuple[str, ...] = (
    "windsurf-enterprise",
)

# ---------------------------------------------------------------------------
# Secret patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",            re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",                re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",         re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",            re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",        re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",    re.compile(
        r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
    ("Bearer token",              re.compile(
        r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}",
        re.IGNORECASE,
    )),
    ("Database URL with creds",   re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("Windsurf auth token",       re.compile(
        r"windsurf[_\-]?(auth|token|key|secret)\s*[:=]\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
    ("Codeium auth token",        re.compile(
        r"codeium[_\-]?(auth|token|key|secret)\s*[:=]\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    """Return the name of the first matched secret pattern, or None."""
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_for_phi(text: str) -> Optional[str]:
    """Return the pattern string of the first matched PHI indicator, or None."""
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(
        p.lower() in ("hipaa", "hitech", "hipaa-hitech")
        for p in pack_binding
    )


def _is_sensitive_path(file_path: str) -> bool:
    """Return True if the file path matches a sensitive path pattern."""
    sensitive_patterns = [
        re.compile(r"^/etc/"),
        re.compile(r"^/root/"),
        re.compile(r"(^|/)\.env$"),
        re.compile(r"\.env\."),
        re.compile(r"^/proc/"),
        re.compile(r"^/sys/"),
        re.compile(r"secrets?/", re.IGNORECASE),
        re.compile(r"private_?key", re.IGNORECASE),
        re.compile(r"\.pem$", re.IGNORECASE),
        re.compile(r"\.key$", re.IGNORECASE),
    ]
    return any(p.search(file_path) for p in sensitive_patterns)


# ---------------------------------------------------------------------------
# WindsurfGovernedClient
# ---------------------------------------------------------------------------

class WindsurfGovernedClient(BaseGovernanceIntegration):
    """REST-client shim for Windsurf governance.

    Windsurf is TypeScript-native. This Python shim participates in the
    decision loop by governing all seven Windsurf hook surfaces:
      1. Cascade flow (intercept_cascade_flow) -- REQUIRES description
      2. Chat (intercept_chat)
      3. Inline completion (intercept_inline_completion)
      4. Command (intercept_command)
      5. Terminal command (intercept_terminal_command) -- STRICT
      6. Web search (intercept_web_search) -- STRICT in air-gapped mode
      7. Multi-file edit (intercept_multi_file_edit) -- blast-radius cap

    Deployment modes: windsurf-cloud, windsurf-enterprise, windsurf-individual.
    BAA-eligible modes: windsurf-enterprise.
    Air-gapped sub-mode: windsurf-enterprise only (air_gapped=True).

    Pen-tests:
      PT-ADAPT-WINDSURF-1: empty pack_binding => denied (pack-binding primacy)
      PT-ADAPT-WINDSURF-2: auth tokens never appear in audit entries
      PT-ADAPT-WINDSURF-3: invalid deployment_mode raises ValueError at init;
                           negative multi_file_edit_cap raises ValueError;
                           air_gapped=True on non-enterprise raises ValueError
      PT-ADAPT-WINDSURF-4: terminal command denials produce audit with reason codes
      PT-ADAPT-WINDSURF-5: cascade flow without description produces denial with
                           reason code windsurf-cascade-flow-description-required
    """

    _FRAMEWORK_NAME = "windsurf"
    _LAYER_NAME = "windsurf-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        deployment_mode: str = "windsurf-cloud",
        air_gapped: bool = False,
        allow_terminal_execution: bool = False,
        allowed_terminal_prefixes: Optional[list[str]] = None,
        multi_file_edit_cap: int = 10,
        hipaa_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            deployment_mode: Windsurf deployment mode.
                             One of: windsurf-cloud, windsurf-enterprise,
                             windsurf-individual.
            air_gapped: Activate air-gapped policy. Only valid in
                        'windsurf-enterprise' mode. Default: False.
            allow_terminal_execution: Explicit opt-in for terminal commands.
                                      Default: False (governance default-deny).
            allowed_terminal_prefixes: Allowed command prefixes for air-gapped
                                       terminal execution. Only used when
                                       air_gapped=True.
            multi_file_edit_cap: Maximum files in a single multi-file edit.
                                 Default: 10. Must be a positive integer.
            hipaa_reviewer_tier: Reviewer tier for HIPAA/PHI requests.

        Raises:
            ValueError: If deployment_mode is not a valid Windsurf deployment mode
                        (PT-ADAPT-WINDSURF-3).
            ValueError: If air_gapped=True and deployment_mode is not
                        'windsurf-enterprise' (PT-ADAPT-WINDSURF-3).
            ValueError: If multi_file_edit_cap is not a positive integer
                        (PT-ADAPT-WINDSURF-3).
        """
        # PT-ADAPT-WINDSURF-3: validate deployment_mode at construction time.
        if deployment_mode not in WINDSURF_VALID_DEPLOYMENT_MODES:
            raise ValueError(
                f"WindsurfGovernedClient: invalid deployment_mode '{deployment_mode}'. "
                f"Must be one of: {', '.join(WINDSURF_VALID_DEPLOYMENT_MODES)}. "
                "Deployment mode is required to enforce terminal-execution, "
                "web-search, and air-gapped policies."
            )

        # PT-ADAPT-WINDSURF-3: air_gapped only valid in windsurf-enterprise.
        if air_gapped and deployment_mode not in WINDSURF_AIR_GAPPED_CAPABLE_MODES:
            raise ValueError(
                f"WindsurfGovernedClient: air_gapped=True is only valid in "
                f"'windsurf-enterprise' mode. Current deployment_mode: "
                f"'{deployment_mode}'. Air-gapped operation requires enterprise deployment."
            )

        # PT-ADAPT-WINDSURF-3: multi_file_edit_cap must be a positive integer.
        if not isinstance(multi_file_edit_cap, int) or multi_file_edit_cap < 1:
            raise ValueError(
                f"WindsurfGovernedClient: multi_file_edit_cap must be a positive integer. "
                f"Received: {multi_file_edit_cap}."
            )

        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.deployment_mode = deployment_mode
        self.air_gapped = air_gapped
        self.allow_terminal_execution = allow_terminal_execution
        self.allowed_terminal_prefixes = allowed_terminal_prefixes or []
        self.multi_file_edit_cap = multi_file_edit_cap
        self.hipaa_reviewer_tier = hipaa_reviewer_tier

    # ------------------------------------------------------------------
    # intercept_cascade_flow -- Cascade agentic flow gate (PT-ADAPT-WINDSURF-5)
    # ------------------------------------------------------------------

    def intercept_cascade_flow(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Windsurf Cascade agentic flow (PT-ADAPT-WINDSURF-5).

        Cascade can plan and execute dozens of tool calls autonomously.
        REQUIRES a non-empty flow_description for governance auditability.
        An unlabeled flow cannot be audited or approved -- default deny.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-WINDSURF-1)
          2. flow_description required gate (PT-ADAPT-WINDSURF-5)

        Args:
            request: Cascade flow request dict with keys:
                     flowDescription, tools, estimatedSteps,
                     packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        flow_description = str(
            request.get("flowDescription", request.get("description", ""))
        ).strip()
        tools = request.get("tools")
        estimated_steps = request.get("estimatedSteps")
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-WINDSURF-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Windsurf Cascade flow request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # PT-ADAPT-WINDSURF-5: flowDescription required.
        if not flow_description:
            return self._deny(
                agent_id,
                "Windsurf Cascade flow denied: flow_description is required for governance "
                "audit. Every Cascade flow must carry a non-empty flow_description so the "
                "compliance system can evaluate and record what the flow is intended to do. "
                "Reason code: windsurf-cascade-flow-description-required.",
                pack_binding=pack_binding,
                reason_code="windsurf-cascade-flow-description-required",
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "windsurf:cascade-flow-requested",
            "args": {
                "flowDescription": flow_description[:200],
                "tools": tools,
                "estimatedSteps": estimated_steps,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_chat -- chat gate
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Windsurf chat request.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-WINDSURF-1)
          2. Secret scan on prompt
          3. PHI proximity check under HIPAA binding

        Args:
            request: Chat request dict with keys:
                     promptText, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        prompt_text = str(request.get("promptText", request.get("prompt", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-WINDSURF-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Windsurf chat request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Secret scan
        secret_match = _scan_for_secrets(prompt_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Chat request blocked: secret pattern '{secret_match}' in prompt.",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(prompt_text)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "windsurf",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Chat request routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' found in prompt. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "windsurf",
            "messageCount": 1,
            "packBinding": pack_binding,
            "deploymentMode": self.deployment_mode,
        })

    # ------------------------------------------------------------------
    # intercept_inline_completion -- inline completion gate
    # ------------------------------------------------------------------

    def intercept_inline_completion(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Windsurf inline completion request.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-WINDSURF-1)
          2. Secret scan on surrounding context
          3. PHI proximity check under HIPAA binding

        Args:
            request: Inline completion request dict with keys:
                     surroundingContext, filePath, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        surrounding_context = str(
            request.get("surroundingContext", request.get("context", ""))
        )
        file_path = str(request.get("filePath", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-WINDSURF-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Windsurf inline completion request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Secret scan
        secret_match = _scan_for_secrets(surrounding_context)
        if secret_match:
            return self._deny(
                agent_id,
                f"Inline completion blocked: secret pattern '{secret_match}' in "
                f"surrounding context ({file_path or 'unknown file'}).",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(surrounding_context)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "windsurf",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Inline completion routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' in context. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "windsurf",
            "messageCount": 1,
            "packBinding": pack_binding,
            "filePath": file_path,
            "deploymentMode": self.deployment_mode,
        })

    # ------------------------------------------------------------------
    # intercept_command -- slash command gate
    # ------------------------------------------------------------------

    def intercept_command(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Windsurf slash command (file edits, refactors).

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-WINDSURF-1)
          2. Sensitive path check on target_file

        Args:
            request: Command request dict with keys:
                     command, targetFile, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        command = str(request.get("command", ""))
        target_file = str(request.get("targetFile", request.get("target_file", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-WINDSURF-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Windsurf command request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Sensitive path check
        if target_file and _is_sensitive_path(target_file):
            return self._deny(
                agent_id,
                f"Windsurf command blocked: target file '{target_file}' matches sensitive "
                f"path pattern. Command: {command[:80]}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "windsurf:command-requested",
            "args": {
                "command": command[:80],
                "targetFile": target_file,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_terminal_command -- terminal execution gate (PT-ADAPT-WINDSURF-4)
    # ------------------------------------------------------------------

    def intercept_terminal_command(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Windsurf terminal command execution (PT-ADAPT-WINDSURF-4).

        CRITICAL governance surface. Cascade can run terminal commands autonomously.
        Strict-mode enforcement:

          Default (allow_terminal_execution=False):
            ALWAYS DENIED. Reason code: windsurf-terminal-execution-not-permitted.

          Non-air-gapped, allow_terminal_execution=True:
            ALLOWED with audit.

          air_gapped=True, allow_terminal_execution=False:
            DENIED. Reason code: windsurf-terminal-denied-air-gapped-no-opt-in.

          air_gapped=True, allow_terminal_execution=True, no prefix list:
            DENIED. Reason code: windsurf-terminal-denied-air-gapped-no-prefix-list.

          air_gapped=True, allow_terminal_execution=True, prefix match:
            ALLOWED with audit.

          air_gapped=True, allow_terminal_execution=True, no prefix match:
            DENIED. Reason code: windsurf-terminal-denied-air-gapped-prefix-mismatch.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-WINDSURF-1)
          2. Terminal execution opt-in check
          3. Air-gapped prefix match check (if applicable)

        Args:
            request: Terminal command request dict with keys:
                     command, workingDirectory, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        command = str(request.get("command", "")).strip()
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-WINDSURF-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Windsurf terminal command request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Default deny: terminal execution not opted in.
        if not self.allow_terminal_execution:
            reason_code = (
                "windsurf-terminal-denied-air-gapped-no-opt-in"
                if self.air_gapped
                else "windsurf-terminal-execution-not-permitted"
            )
            return self._deny(
                agent_id,
                f"Windsurf terminal command blocked: allow_terminal_execution is not "
                f"enabled. Set allow_terminal_execution=True in WindsurfGovernedClient "
                f"to permit terminal execution. deployment_mode: {self.deployment_mode}. "
                f"air_gapped: {self.air_gapped}. Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Terminal opt-in confirmed. In air-gapped mode, require prefix match.
        if self.air_gapped:
            if not self.allowed_terminal_prefixes:
                reason_code = "windsurf-terminal-denied-air-gapped-no-prefix-list"
                return self._deny(
                    agent_id,
                    "Windsurf terminal command blocked: air-gapped mode requires "
                    "allowed_terminal_prefixes[] to be configured with at least one entry. "
                    "Empty prefix list in air-gapped mode means ALL terminal commands are "
                    "denied (safe default). Configure allowed_terminal_prefixes in "
                    f"WindsurfGovernedClient. Reason code: {reason_code}.",
                    pack_binding=pack_binding,
                    reason_code=reason_code,
                )

            matched_prefix = next(
                (prefix for prefix in self.allowed_terminal_prefixes
                 if command.startswith(prefix)),
                None,
            )
            if not matched_prefix:
                reason_code = "windsurf-terminal-denied-air-gapped-prefix-mismatch"
                prefix_sample = self.allowed_terminal_prefixes[:5]
                return self._deny(
                    agent_id,
                    f"Windsurf terminal command blocked: air-gapped mode is active and "
                    f"the command '{command[:60]}' does not start with any entry in "
                    f"allowed_terminal_prefixes {prefix_sample}. "
                    "Air-gapped deployments restrict terminal access to a pre-approved "
                    f"command set. Reason code: {reason_code}.",
                    pack_binding=pack_binding,
                    reason_code=reason_code,
                )

            # Air-gapped, opt-in confirmed, prefix matched.
            return self.emit_event("toolCall", {
                "agentId": agent_id,
                "toolName": "windsurf:terminal-command-requested",
                "args": {
                    "command": command[:80],
                    "matchedPrefix": matched_prefix,
                    "deploymentMode": self.deployment_mode,
                    "airGapped": True,
                },
                "packBinding": pack_binding,
            })

        # Non-air-gapped, opt-in confirmed.
        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "windsurf:terminal-command-requested",
            "args": {
                "command": command[:80],
                "deploymentMode": self.deployment_mode,
                "airGapped": False,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_web_search -- web search gate
    # ------------------------------------------------------------------

    def intercept_web_search(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Windsurf web search (Cascade browse).

        In air-gapped mode: UNCONDITIONALLY DENIED. Air-gapped deployments
        cannot permit outbound web requests.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-WINDSURF-1)
          2. Air-gapped unconditional denial

        Args:
            request: Web search request dict with keys:
                     query, url, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        query = str(request.get("query", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-WINDSURF-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Windsurf web search request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Air-gapped: unconditional denial.
        if self.air_gapped:
            reason_code = "windsurf-web-search-denied-air-gapped"
            return self._deny(
                agent_id,
                f"Windsurf web search blocked: air-gapped mode is active. "
                "Web search is unconditionally denied in air-gapped deployments to prevent "
                "data exfiltration and ensure network isolation. "
                f"deployment_mode: {self.deployment_mode}. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Non-air-gapped: allowed with audit.
        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "windsurf:web-search-requested",
            "args": {
                "query": query[:80],
                "deploymentMode": self.deployment_mode,
                "airGapped": False,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_multi_file_edit -- multi-file edit blast-radius cap
    # ------------------------------------------------------------------

    def intercept_multi_file_edit(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Windsurf multi-file edit operation.

        Blast-radius cap: file count > multi_file_edit_cap => DENIED.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-WINDSURF-1)
          2. Blast-radius file count check

        Args:
            request: Multi-file edit request dict with keys:
                     files, description, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        files: list[str] = request.get("files", [])
        description = str(request.get("description", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-WINDSURF-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Windsurf multi-file edit request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Blast-radius cap check
        if len(files) > self.multi_file_edit_cap:
            reason_code = "windsurf-multi-file-edit-blast-radius-exceeded"
            return self._deny(
                agent_id,
                f"Windsurf multi-file edit blocked: {len(files)} files exceeds the "
                f"blast-radius cap of {self.multi_file_edit_cap}. Reduce the number of "
                "files in a single edit operation or increase multi_file_edit_cap in "
                f"WindsurfGovernedClient. Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "windsurf:multi-file-edit-requested",
            "args": {
                "fileCount": len(files),
                "cap": self.multi_file_edit_cap,
                "description": description[:120],
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown WindsurfGovernedClient event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] WindsurfGovernedClient output classifier: possible secret "
                    f'in tool result "{payload.get("toolName", "unknown")}" '
                    f"(agent: {agent_id}).",
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] WindsurfGovernedClient output exfiltration scanner: "
                    f"possible secret/PHI in LLM response (agent: {agent_id}).",
                    file=sys.stderr,
                )

        # Inject deployment mode metadata and delegate to base
        enriched = {
            "deploymentMode": self.deployment_mode,
            "airGapped": self.air_gapped,
            **payload,
        }
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload and forward it as a canonical governance event."""
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError(
                "WindsurfGovernedClient webhook payload missing required field: 'eventType'"
            )
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError(
                "WindsurfGovernedClient webhook payload missing required field: 'agentId'"
            )
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "WindsurfPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return WindsurfPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (canonical event surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
        reason_code: Optional[str] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# WindsurfPolicyBridge
# ---------------------------------------------------------------------------

class WindsurfPolicyBridge:
    """Bridge for Python-hosted policy participation in the Windsurf governance loop."""

    def __init__(
        self,
        adapter: WindsurfGovernedClient,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:
                import logging as _logging
                _logging.getLogger(__name__).warning(
                    "Governance audit operation failed: %s", exc
                )

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
