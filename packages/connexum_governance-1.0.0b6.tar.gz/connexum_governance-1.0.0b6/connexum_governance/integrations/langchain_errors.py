"""
Governance error types for the LangChain framework adapter.

These errors are raised when governance decisions block or pend tool/agent actions.
They mirror the TypeScript SDK's errors.ts pattern:
  GovernanceViolation      -- raised on DENY
  GovernancePendingApproval -- raised on REQUIRE_APPROVAL

These are distinct from the models.GovernanceViolation used by the older
GovernanceClient-based integrations, to maintain clean separation between
the new framework adapter layer (langchain_integration.py) and the original
HTTP client layer (anthropic.py, langchain.py, etc.).

Both error types are re-exported from connexum_governance top-level __init__.py
under the names GovernanceViolation and GovernancePendingApproval for consumers
who use the new framework adapter.
"""

from __future__ import annotations

from typing import Optional


class GovernanceViolation(Exception):
    """
    Raised when a governance check returns DENY.

    This is the primary signal that a tool call, agent action, or LLM call
    has been blocked by governance policy.

    Attributes:
        decision: The decision string (always 'DENY').
        reason: Human-readable reason for the denial.
        audit_id: Audit trail ID from the governance server (may be None).

    Mirrors TypeScript SDK's GovernanceViolation in errors.ts.
    """

    def __init__(
        self,
        decision: str = "DENY",
        reason: Optional[str] = None,
        audit_id: Optional[str] = None,
    ):
        self.decision = decision
        self.reason = reason
        self.audit_id = audit_id

        message = reason or "Action denied by governance policy"
        super().__init__(message)

    @property
    def name(self) -> str:
        return "GovernanceViolation"

    def __repr__(self) -> str:
        return (
            f"GovernanceViolation(decision={self.decision!r}, "
            f"reason={self.reason!r}, audit_id={self.audit_id!r})"
        )


class GovernancePendingApproval(Exception):
    """
    Raised when a governance check returns REQUIRE_APPROVAL.

    This signals that a tool call or agent action cannot proceed without
    explicit human approval via the governance server's approval workflow.

    Attributes:
        approval_id: The approval workflow ID to poll / present to the approver.
        audit_id: Audit trail ID from the governance server (may be None).

    Mirrors TypeScript SDK's GovernancePendingApproval in errors.ts.
    """

    def __init__(
        self,
        approval_id: str,
        audit_id: Optional[str] = None,
    ):
        self.approval_id = approval_id
        self.audit_id = audit_id

        super().__init__(
            f"Action requires approval. approvalId={approval_id}"
            + (f", auditId={audit_id}" if audit_id else "")
        )

    @property
    def name(self) -> str:
        return "GovernancePendingApproval"

    def __repr__(self) -> str:
        return (
            f"GovernancePendingApproval(approval_id={self.approval_id!r}, "
            f"audit_id={self.audit_id!r})"
        )
