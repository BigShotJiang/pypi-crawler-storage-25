"""Notebook AI governance integration.

Unified adapter for AI-assisted notebook surfaces across four platforms:

  jupyter-ai   -- JupyterLab built-in AI (self-hosted or on-prem);
                 requires instance_url; multi-tenant capable.
  hex-ai       -- Hex AI (cloud SaaS, team-based); high data-egress
                 sensitivity (Snowflake/BigQuery sample rows).
  deepnote-ai  -- Deepnote AI (cloud SaaS, team workspaces); integrates
                 cloud DBs and cloud storage.
  colab-ai     -- Google Colab AI (cloud SaaS by Google); all notebook
                 content is sent to Google by design.

Why unified vs four separate adapters:
  All four platforms expose the same governable surface: cells, kernel,
  datasets, and exports. The platform-specific differences are deployment
  shape and data-residency concerns, not method shape. A unified adapter
  with a `platform` discriminator keeps the contract simple and lets
  healthcare-research customers standardize across multiple platforms.

Nine governed surfaces (parity with TS adapter):
  intercept_cell_generation(request)       -- AI generates a new cell
  intercept_cell_edit(request)             -- AI edits an existing cell
  intercept_cell_explain(request)          -- AI explains a cell (read-only)
  intercept_kernel_execution(request)      -- AI triggers kernel execution (HIGH RISK)
  intercept_dataset_introspection(request) -- AI reads dataset schema/samples (PHI-critical)
  intercept_chart_generation(request)      -- AI generates a chart from data
  intercept_notebook_export(request)       -- AI helps export notebook
  intercept_chat(request)                  -- assistant panel chat
  intercept_slash_command(request)         -- /explain, /fix, /optimize, etc.

Platform-specific config validation:
  jupyter-ai:           instance_url required; rejected for cloud platforms.
  hex-ai/deepnote-ai/colab-ai: instance_url rejected (managed by vendor).

Deployment modes:
  notebook-ai-multi-tenant-cloud -- Hex, Deepnote, Colab default.
  notebook-ai-self-hosted        -- Jupyter on-prem.
  notebook-ai-air-gapped         -- Jupyter offline / sovereign deployment.
  notebook-ai-education          -- Any platform with minor/student users.

Strict-mode enforcement (the differentiators):
  - Air-gapped + kernel execution: denied if cell contains egress patterns.
  - Air-gapped + dataset introspection: non-local source denied.
  - Air-gapped + notebook export: upload / non-local target denied.
  - Cloud + dataset allowlist: source NOT in list denied.
  - PHI scan: SSN, MRN, ICD-10 patterns in sample rows trigger audit redaction.
  - Minor / student + kernel execution: ALWAYS denied (non-negotiable).
  - Cell generation / edit: secret scan on content.
  - Multi-cell edit cap: batch edits beyond cap denied.
  - Education mode + export: default-deny unless allow_export=True.

Pen-test IDs (mirrored from TS adapter):
  PT-ADAPT-NOTEBOOK-1: empty pack_binding denied (pack-binding primacy)
  PT-ADAPT-NOTEBOOK-2: API keys / connection strings never in audit entries
  PT-ADAPT-NOTEBOOK-3: malformed config raises ValueError at construction
  PT-ADAPT-NOTEBOOK-4: minor + kernel execution ALWAYS denied
  PT-ADAPT-NOTEBOOK-5: air-gapped + network-egress code ALWAYS denied
  PT-ADAPT-NOTEBOOK-6: dataset introspection PHI pattern triggers redaction
  PT-ADAPT-NOTEBOOK-7: cell generation with secret content denied

Healthcare-research footprint:
  This adapter's PHI-aware dataset introspection, kernel-execution safeguards,
  and air-gapped deployment mode are specifically designed for regulated
  healthcare-research environments (hospital data science teams, clinical
  trial analytics, public-health research notebooks).

Spec: P3-SUB-IDE-10

Usage::

    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.notebook_ai import NotebookAIGovernedClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    client = NotebookAIGovernedClient(
        client=gov,
        agent_name="research-notebook-01",
        pack_binding=["hipaa"],
        platform="jupyter-ai",
        deployment_mode="notebook-ai-self-hosted",
        instance_url="https://jupyter.hospital.internal",
        allowed_dataset_sources=["file:///data/research"],
        allow_kernel_execution=True,
        allowed_kernel_languages=["python", "r"],
    )

    decision = client.intercept_kernel_execution({
        "cellId": "cell-42",
        "cellContent": "import pandas as pd; df = pd.read_csv('/data/research/cohort.csv')",
        "language": "python",
        "packBinding": ["hipaa"],
    })
"""

from __future__ import annotations

import re
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import GovernanceDecision, GovernanceViolation, DecisionType
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Valid platforms and deployment modes
# ---------------------------------------------------------------------------

NOTEBOOK_AI_VALID_PLATFORMS: tuple[str, ...] = (
    "jupyter-ai",
    "hex-ai",
    "deepnote-ai",
    "colab-ai",
)

NOTEBOOK_AI_CLOUD_PLATFORMS: tuple[str, ...] = (
    "hex-ai",
    "deepnote-ai",
    "colab-ai",
)

NOTEBOOK_AI_VALID_DEPLOYMENT_MODES: tuple[str, ...] = (
    "notebook-ai-multi-tenant-cloud",
    "notebook-ai-self-hosted",
    "notebook-ai-air-gapped",
    "notebook-ai-education",
)

NOTEBOOK_AI_VALID_USER_TIERS: tuple[str, ...] = (
    "professional",
    "student",
    "researcher",
    "admin",
)

# ---------------------------------------------------------------------------
# Network egress patterns (air-gapped kernel execution guard)
# ---------------------------------------------------------------------------

_KERNEL_EGRESS_PATTERNS: list[re.Pattern] = [
    re.compile(r"\brequests\.get\s*\("),
    re.compile(r"\brequests\.post\s*\("),
    re.compile(r"\brequests\.put\s*\("),
    re.compile(r"\burllib\.request\b"),
    re.compile(r"\burllib\.urlopen\s*\("),
    re.compile(r"\burllib3\b"),
    re.compile(r"\bsocket\.connect\s*\("),
    re.compile(r"\bsocket\.create_connection\s*\("),
    re.compile(r"\bhttplib2\b"),
    re.compile(r"\bhttpx\b"),
    re.compile(r"\baiohttp\b"),
    re.compile(r"\bfetch\s*\("),
    re.compile(r"\baxios\s*\."),
    re.compile(r"\bhttp\.get\s*\("),
    re.compile(r"\bhttp\.request\s*\("),
    re.compile(r"\bhttps\.get\s*\("),
    re.compile(r"\bhttps\.request\s*\("),
]


def _detect_kernel_egress(code: str) -> Optional[str]:
    """Return the pattern string of the first matched egress pattern, or None."""
    if not code:
        return None
    for pattern in _KERNEL_EGRESS_PATTERNS:
        if pattern.search(code):
            return pattern.pattern
    return None


# ---------------------------------------------------------------------------
# Secret scan patterns (cell content guard)
# PT-ADAPT-NOTEBOOK-2: connection strings must never appear in audit entries.
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",          re.compile(r"AKIA[0-9A-Z]{16}")),
    ("AWS secret key",          re.compile(r"aws_secret_access_key\s*=\s*\S{20,}", re.IGNORECASE)),
    ("GitHub PAT",              re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",       re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",          re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",      re.compile(r"-----BEGIN (RSA|EC|OPENSSH|DSA|ED25519) PRIVATE KEY-----")),
    ("Generic secret env var",  re.compile(
        r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY|ACCESS_TOKEN)\w*\s*=\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
    ("Bearer token",            re.compile(
        r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}",
        re.IGNORECASE,
    )),
    ("Database URL with creds", re.compile(
        r"(postgres|mysql|mongodb|redis|snowflake|bigquery)://[^:]+:[^@]+@",
        re.IGNORECASE,
    )),
    ("Snowflake account key",   re.compile(
        r"snowflake[_\-]?(account|key|password|token)\s*[:=]\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
    ("Connection string",       re.compile(
        r"Server\s*=\s*[^;]{4,};.*Password\s*=\s*[^;]{4,}",
        re.IGNORECASE,
    )),
]


def _scan_cell_for_secrets(content: str) -> Optional[str]:
    """Return the name of the first matched secret pattern, or None."""
    if not content:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(content):
            return name
    return None


# ---------------------------------------------------------------------------
# PHI scan patterns (dataset introspection guard)
# PT-ADAPT-NOTEBOOK-6: PHI patterns in sample rows trigger audit redaction.
# ---------------------------------------------------------------------------

_PHI_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("SSN pattern",        re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("MRN-like pattern",   re.compile(
        r"\b(mrn|medical[_\s]?record[_\s]?(number|no|#?))\s*[:=]?\s*[A-Z0-9\-]{4,}",
        re.IGNORECASE,
    )),
    ("ICD-10 code",        re.compile(r"\b[A-Z]\d{2}(\.\d{1,4})?\b")),
    ("Patient name field", re.compile(r"\b(patient|pt)[_\s]?(name|first|last)\b", re.IGNORECASE)),
    ("Date of birth",      re.compile(r"\b(dob|date[_\s]?of[_\s]?birth)\b", re.IGNORECASE)),
    ("Diagnosis field",    re.compile(r"\bdiagnos(is|es|tic)\b", re.IGNORECASE)),
    ("PHI marker",         re.compile(r"\bphi\b", re.IGNORECASE)),
    ("HIPAA indicator",    re.compile(r"\bhipaa\b", re.IGNORECASE)),
]


def _scan_for_phi(text: str) -> Optional[str]:
    """Return the name of the first matched PHI pattern, or None."""
    if not text:
        return None
    for name, pattern in _PHI_PATTERNS:
        if pattern.search(text):
            return name
    return None


# ---------------------------------------------------------------------------
# Dataset source allowlist check
# ---------------------------------------------------------------------------

def _is_dataset_source_allowed(
    source: str,
    allowed_sources: list[str],
    deployment_mode: str,
) -> tuple[bool, Optional[str]]:
    """Check whether a dataset source is permitted.

    Returns:
        (allowed: bool, reason: Optional[str])
    """
    # Air-gapped: only local sources
    if deployment_mode == "notebook-ai-air-gapped":
        is_local = (
            source.startswith("file://")
            or source.startswith("/")
            or source.startswith("./")
        )
        if not is_local:
            return (
                False,
                f"notebook-ai-dataset-source-not-local-in-air-gapped: source '{source}' is not "
                "a local path. Air-gapped mode only permits file:// or local-path sources.",
            )
        return (True, None)

    # Cloud modes with an explicit allowlist
    if allowed_sources:
        matched = any(
            source == allowed or source in allowed or allowed in source
            for allowed in allowed_sources
        )
        if not matched:
            return (
                False,
                f"notebook-ai-dataset-source-not-in-allowlist: source '{source}' is not in "
                f"allowed_dataset_sources. Permitted sources: {', '.join(allowed_sources)}.",
            )

    return (True, None)


# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# NotebookAIGovernedClient
# ---------------------------------------------------------------------------

class NotebookAIGovernedClient(BaseGovernanceIntegration):
    """REST-client shim for Notebook AI governance.

    Unified adapter for Jupyter AI, Hex AI, Deepnote AI, and Google Colab AI.
    Nine governed surfaces with PHI-aware dataset introspection, kernel-execution
    safeguards, air-gapped enforcement, and minor/student safeguards.

    Healthcare-research teams use this adapter to standardize governance across
    multiple notebook platforms without duplicating policy configuration.

    Nine distinct governable surfaces (parity with TS adapter):
      1. Cell generation (intercept_cell_generation) -- secret scan
      2. Cell edit (intercept_cell_edit)             -- secret scan + cap
      3. Cell explain (intercept_cell_explain)        -- read-only
      4. Kernel execution (intercept_kernel_execution) -- HIGH RISK; minor blocked
      5. Dataset introspection (intercept_dataset_introspection) -- PHI scan
      6. Chart generation (intercept_chart_generation) -- source allowlist
      7. Notebook export (intercept_notebook_export)   -- air-gapped + edu gates
      8. Chat (intercept_chat)                         -- secret scan
      9. Slash command (intercept_slash_command)       -- allow passthrough
    """

    _VALID_EVENT_TYPES = _VALID_EVENT_TYPES
    _FRAMEWORK_NAME = "notebook-ai"
    _LAYER_NAME = "notebook-ai-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        pack_binding: list[str],
        platform: str,
        deployment_mode: Optional[str] = None,
        user_tier: str = "professional",
        user_is_minor: bool = False,
        instance_url: Optional[str] = None,
        allowed_dataset_sources: Optional[list[str]] = None,
        allow_kernel_execution: bool = False,
        allowed_kernel_languages: Optional[list[str]] = None,
        allow_export: Optional[bool] = None,
        cell_execution_time_ms: int = 30000,
        multi_cell_edit_cap: int = 25,
        instructor_override: bool = False,
    ) -> None:
        """Create a NotebookAIGovernedClient.

        Args:
            client: GovernanceClient REST connection.
            agent_name: Agent identifier for audit attribution.
            pack_binding: Compliance packs that govern this agent.
            platform: REQUIRED. One of 'jupyter-ai', 'hex-ai', 'deepnote-ai',
                      'colab-ai'. The platform discriminator.
            deployment_mode: Deployment mode. Defaults to 'notebook-ai-self-hosted'
                             for jupyter-ai, 'notebook-ai-multi-tenant-cloud' for others.
            user_tier: 'professional', 'student', 'researcher', or 'admin'.
            user_is_minor: True activates minor safeguards. Kernel execution ALWAYS
                           denied regardless of allow_kernel_execution.
            instance_url: Required for jupyter-ai. Rejected for cloud platforms.
            allowed_dataset_sources: FQDN/URI allowlist for permitted dataset sources.
            allow_kernel_execution: Allow AI-triggered kernel execution. Default: False.
            allowed_kernel_languages: Restrict kernel execution to these languages.
            allow_export: Allow notebook export. Defaults to False in education/student.
            cell_execution_time_ms: Advisory execution time cap. Default: 30000.
            multi_cell_edit_cap: Maximum cells per batch edit. Default: 25.
            instructor_override: Admin-level override for student kernel gate. Default: False.

        Raises:
            ValueError: If platform is invalid, deployment_mode is invalid,
                        jupyter-ai without instance_url, cloud platform with instance_url,
                        user_tier is invalid, or multi_cell_edit_cap < 1.
        """
        super().__init__(client)

        # PT-ADAPT-NOTEBOOK-3: validate platform
        if not platform:
            raise ValueError(
                "NotebookAIGovernedClient: platform is required. "
                f"Must be one of: {', '.join(NOTEBOOK_AI_VALID_PLATFORMS)}."
            )
        if platform not in NOTEBOOK_AI_VALID_PLATFORMS:
            raise ValueError(
                f"NotebookAIGovernedClient: invalid platform '{platform}'. "
                f"Must be one of: {', '.join(NOTEBOOK_AI_VALID_PLATFORMS)}."
            )

        # PT-ADAPT-NOTEBOOK-3: jupyter-ai requires instance_url; cloud platforms reject it.
        is_cloud_platform = platform in NOTEBOOK_AI_CLOUD_PLATFORMS
        if platform == "jupyter-ai" and not instance_url:
            raise ValueError(
                "NotebookAIGovernedClient: instance_url is required for platform 'jupyter-ai'. "
                "Jupyter AI is a self-hosted platform -- provide the base URL of your "
                "JupyterLab instance (e.g. 'https://jupyter.acme.com')."
            )
        if is_cloud_platform and instance_url:
            raise ValueError(
                f"NotebookAIGovernedClient: instance_url is not permitted for platform '{platform}'. "
                "Cloud-managed platforms (hex-ai, deepnote-ai, colab-ai) are operated by the "
                "vendor -- there is no customer-controlled instance URL. "
                "Remove instance_url from your config for this platform."
            )

        # Derive default deployment mode from platform
        if deployment_mode is None:
            deployment_mode = (
                "notebook-ai-self-hosted" if platform == "jupyter-ai"
                else "notebook-ai-multi-tenant-cloud"
            )

        # PT-ADAPT-NOTEBOOK-3: validate deployment_mode
        if deployment_mode not in NOTEBOOK_AI_VALID_DEPLOYMENT_MODES:
            raise ValueError(
                f"NotebookAIGovernedClient: invalid deployment_mode '{deployment_mode}'. "
                f"Must be one of: {', '.join(NOTEBOOK_AI_VALID_DEPLOYMENT_MODES)}."
            )

        # Validate user_tier
        if user_tier not in NOTEBOOK_AI_VALID_USER_TIERS:
            raise ValueError(
                f"NotebookAIGovernedClient: invalid user_tier '{user_tier}'. "
                f"Must be one of: {', '.join(NOTEBOOK_AI_VALID_USER_TIERS)}."
            )

        # PT-ADAPT-NOTEBOOK-3: validate multi_cell_edit_cap
        if multi_cell_edit_cap < 1:
            raise ValueError(
                f"NotebookAIGovernedClient: multi_cell_edit_cap must be >= 1. "
                f"Received: {multi_cell_edit_cap}."
            )

        if cell_execution_time_ms < 0:
            raise ValueError(
                f"NotebookAIGovernedClient: cell_execution_time_ms must be >= 0. "
                f"Received: {cell_execution_time_ms}."
            )

        # Resolve allow_export default: False in education mode or student tier
        is_education = (deployment_mode == "notebook-ai-education" or user_tier == "student")
        if allow_export is None:
            allow_export = not is_education

        self.agent_name = agent_name
        self.pack_binding = pack_binding
        self.platform = platform
        self.deployment_mode = deployment_mode
        self.user_tier = user_tier
        self.user_is_minor = user_is_minor
        self.instance_url = instance_url
        self.allowed_dataset_sources: list[str] = allowed_dataset_sources or []
        self.allow_kernel_execution = allow_kernel_execution
        self.allowed_kernel_languages: Optional[list[str]] = (
            allowed_kernel_languages if allowed_kernel_languages else None
        )
        self.allow_export = allow_export
        self.cell_execution_time_ms = cell_execution_time_ms
        self.multi_cell_edit_cap = multi_cell_edit_cap
        self.instructor_override = instructor_override

    # ------------------------------------------------------------------
    # Guard helpers
    # ------------------------------------------------------------------

    def _check_pack_binding(self, pack_binding: list[str], agent_id: str) -> Optional[GovernanceDecision]:
        """Return a DENY decision if pack_binding is empty (PT-ADAPT-NOTEBOOK-1)."""
        if not pack_binding:
            return self._deny(
                agent_id,
                "Notebook AI request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )
        return None

    def _check_minor_kernel_execution(self, agent_id: str, pack_binding: list[str]) -> Optional[GovernanceDecision]:
        """Return a DENY decision for minor/student kernel execution (PT-ADAPT-NOTEBOOK-4)."""
        is_minor_or_student = self.user_is_minor or self.user_tier == "student"
        if not is_minor_or_student:
            return None

        # instructor_override + user_tier='admin' can override student gate, but NOT minor (COPPA)
        if self.instructor_override and self.user_tier == "admin" and not self.user_is_minor:
            return None

        reason_code = (
            "notebook-ai-kernel-execution-not-permitted-minor"
            if self.user_is_minor
            else "notebook-ai-kernel-execution-not-permitted-student"
        )
        user_label = "minor" if self.user_is_minor else "student"
        return self._deny(
            agent_id,
            f"Notebook AI: kernel execution denied for {user_label} user. "
            "Kernel execution (running code in a live kernel) is not permitted for minor or student "
            "users regardless of allow_kernel_execution configuration. This safeguard is non-negotiable. "
            f"Reason code: {reason_code}.",
            pack_binding=pack_binding,
            reason_code=reason_code,
        )

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
        reason_code: Optional[str] = None,
    ) -> GovernanceDecision:
        """Return a denied GovernanceDecision."""
        metadata: dict[str, Any] = {
            "agentId": agent_id,
            "packBinding": pack_binding or self.pack_binding,
            "platform": self.platform,
            "deploymentMode": self.deployment_mode,
        }
        if reason_code:
            metadata["reasonCode"] = reason_code
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
            metadata=metadata,
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d

    # ------------------------------------------------------------------
    # intercept_cell_generation -- AI generates a new cell
    # ------------------------------------------------------------------

    def intercept_cell_generation(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate AI cell generation.

        Scans the prompt/content for secrets before the cell is placed.
        LLMs sometimes echo provided API keys back into generated cells.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)
          2. Secret scan on prompt (PT-ADAPT-NOTEBOOK-7)

        Args:
            request: Dict with keys: prompt, language, packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        prompt = str(request.get("prompt", ""))
        language = request.get("language", "unspecified")
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        # PT-ADAPT-NOTEBOOK-7: secret scan
        secret_name = _scan_cell_for_secrets(prompt)
        if secret_name:
            reason_code = "notebook-ai-cell-generation-secret-detected"
            return self._deny(
                agent_id,
                f"Notebook AI: cell generation denied -- secret pattern detected in generated content "
                f"('{secret_name}'). AI models sometimes echo API keys or connection strings from context "
                "into generated cells. The content has been blocked to prevent credential exposure in notebooks. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "notebook-ai:cell-generation-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                "language": language,
                "promptLength": len(prompt),
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_cell_edit -- AI rewrites / refactors an existing cell
    # ------------------------------------------------------------------

    def intercept_cell_edit(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate AI cell editing.

        Applies secret scan and multi-cell edit cap.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)
          2. Multi-cell edit cap
          3. Secret scan on original content

        Args:
            request: Dict with keys: cellId, originalContent, instruction,
                     cellCount, packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        cell_id = str(request.get("cellId", ""))
        original_content = str(request.get("originalContent", ""))
        instruction = str(request.get("instruction", ""))
        cell_count: int = int(request.get("cellCount", 1))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        # Multi-cell edit cap
        if cell_count > self.multi_cell_edit_cap:
            reason_code = "notebook-ai-multi-cell-edit-cap-exceeded"
            return self._deny(
                agent_id,
                f"Notebook AI: batch cell edit denied -- {cell_count} cells exceeds the "
                f"multi-cell edit cap of {self.multi_cell_edit_cap}. Reduce the batch size or "
                "increase multi_cell_edit_cap in config. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Secret scan on cell content
        secret_name = _scan_cell_for_secrets(original_content)
        if secret_name:
            reason_code = "notebook-ai-cell-edit-secret-detected"
            return self._deny(
                agent_id,
                f"Notebook AI: cell edit denied -- secret pattern detected in cell content "
                f"('{secret_name}'). Sending cell content containing secrets to the AI service "
                "would risk credential exposure. Remove the secret before editing. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "notebook-ai:cell-edit-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                "cellId": cell_id,
                "cellCount": cell_count,
                "cap": self.multi_cell_edit_cap,
                "instructionLength": len(instruction),
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_cell_explain -- AI explains a cell (read-only)
    # ------------------------------------------------------------------

    def intercept_cell_explain(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate AI cell explanation (read-only surface).

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)

        Args:
            request: Dict with keys: cellId, cellContent, packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        cell_id = str(request.get("cellId", ""))
        cell_content = str(request.get("cellContent", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "notebook-ai:cell-explain-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                "cellId": cell_id,
                "contentLength": len(cell_content),
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_kernel_execution -- AI triggers kernel execution (HIGH RISK)
    # ------------------------------------------------------------------

    def intercept_kernel_execution(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate AI-triggered kernel execution.

        HIGH RISK: runs arbitrary code in the notebook kernel.

        Guards applied (in order):
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)
          2. Minor / student safeguard (PT-ADAPT-NOTEBOOK-4, non-negotiable)
          3. allow_kernel_execution gate
          4. Language allowlist
          5. Air-gapped egress scan (PT-ADAPT-NOTEBOOK-5)

        Args:
            request: Dict with keys: cellId, cellContent, language,
                     packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        cell_id = str(request.get("cellId", ""))
        cell_content = str(request.get("cellContent", ""))
        language = str(request.get("language", "unknown"))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        # PT-ADAPT-NOTEBOOK-4: minor / student safeguard is non-negotiable
        minor_deny = self._check_minor_kernel_execution(agent_id, pack_binding)
        if minor_deny:
            return minor_deny

        # allow_kernel_execution gate
        if not self.allow_kernel_execution:
            reason_code = "notebook-ai-kernel-execution-not-permitted"
            return self._deny(
                agent_id,
                "Notebook AI: kernel execution denied -- allow_kernel_execution is False. "
                "AI-triggered kernel execution is high-risk (runs arbitrary code in the notebook "
                "kernel). Set allow_kernel_execution=True in NotebookAIGovernedClient to enable. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Language allowlist
        if self.allowed_kernel_languages and language != "unknown":
            if language.lower() not in self.allowed_kernel_languages:
                reason_code = "notebook-ai-kernel-language-not-permitted"
                return self._deny(
                    agent_id,
                    f"Notebook AI: kernel execution denied -- language '{language}' is not in "
                    f"allowed_kernel_languages ({', '.join(self.allowed_kernel_languages)}). "
                    f"Reason code: {reason_code}.",
                    pack_binding=pack_binding,
                    reason_code=reason_code,
                )

        # PT-ADAPT-NOTEBOOK-5: air-gapped mode -- deny network egress code
        if self.deployment_mode == "notebook-ai-air-gapped":
            egress_pattern = _detect_kernel_egress(cell_content)
            if egress_pattern:
                reason_code = "notebook-ai-kernel-egress-denied-air-gapped"
                return self._deny(
                    agent_id,
                    f"Notebook AI: kernel execution denied in air-gapped mode -- network egress "
                    f"pattern detected in cell content (pattern: {egress_pattern}). "
                    "Air-gapped deployments must not make outbound network requests from notebook kernels. "
                    f"Reason code: {reason_code}.",
                    pack_binding=pack_binding,
                    reason_code=reason_code,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "notebook-ai:kernel-execution-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                "cellId": cell_id,
                "language": language,
                "advisoryCap": self.cell_execution_time_ms,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_dataset_introspection -- AI reads dataset schema / samples
    # ------------------------------------------------------------------

    def intercept_dataset_introspection(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate AI dataset introspection.

        PRIVACY-CRITICAL: sample rows may contain PHI, PII, or financial data.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)
          2. Dataset source allowlist / air-gapped check
          3. PHI scan on sample rows (PT-ADAPT-NOTEBOOK-6)

        Args:
            request: Dict with keys: source, sampleRows, packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        source = str(request.get("source", ""))
        sample_rows = request.get("sampleRows")
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        # Dataset source allowlist / air-gapped check
        allowed, reason = _is_dataset_source_allowed(
            source,
            self.allowed_dataset_sources,
            self.deployment_mode,
        )
        if not allowed:
            reason_code = (
                "notebook-ai-dataset-source-not-local-in-air-gapped"
                if self.deployment_mode == "notebook-ai-air-gapped"
                else "notebook-ai-dataset-source-not-in-allowlist"
            )
            return self._deny(
                agent_id,
                f"Notebook AI: dataset introspection denied. {reason or ''}",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # PT-ADAPT-NOTEBOOK-6: PHI scan on sample rows
        phi_detected = False
        phi_type = ""
        if sample_rows is not None:
            sample_text = str(sample_rows)
            phi_type_found = _scan_for_phi(sample_text)
            if phi_type_found:
                phi_detected = True
                phi_type = phi_type_found
                # Emit audit event with sample rows REDACTED
                # (This is handled by emit_event metadata, no raw rows logged)

        decision = self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "notebook-ai:dataset-introspection-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                # PT-ADAPT-NOTEBOOK-2: source redacted from audit to prevent credential leakage
                "sourceProvided": len(source) > 0,
                "sampleRowsProvided": sample_rows is not None,
                "phiDetected": phi_detected,
                "phiType": phi_type if phi_detected else None,
                "sampleRowsRedacted": phi_detected,
            },
            "packBinding": pack_binding,
        })
        # Attach PHI and source metadata to the returned decision so callers
        # can act on the redaction signal without re-inspecting the request.
        enriched_metadata: dict[str, Any] = dict(decision.metadata or {})
        enriched_metadata["phiDetected"] = phi_detected
        enriched_metadata["phiType"] = phi_type if phi_detected else None
        enriched_metadata["sampleRowsRedacted"] = phi_detected
        enriched_metadata["sourceProvided"] = len(source) > 0
        from dataclasses import replace as _dc_replace
        return _dc_replace(decision, metadata=enriched_metadata)

    # ------------------------------------------------------------------
    # intercept_chart_generation -- AI generates a chart from a dataset
    # ------------------------------------------------------------------

    def intercept_chart_generation(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate AI chart generation.

        Applies the same dataset-source allowlist as introspection.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)
          2. Dataset source allowlist / air-gapped check

        Args:
            request: Dict with keys: source, chartType, packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        source = str(request.get("source", ""))
        chart_type = request.get("chartType", "unspecified")
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        # Dataset source allowlist / air-gapped check
        allowed, reason = _is_dataset_source_allowed(
            source,
            self.allowed_dataset_sources,
            self.deployment_mode,
        )
        if not allowed:
            reason_code = (
                "notebook-ai-dataset-source-not-local-in-air-gapped"
                if self.deployment_mode == "notebook-ai-air-gapped"
                else "notebook-ai-dataset-source-not-in-allowlist"
            )
            return self._deny(
                agent_id,
                f"Notebook AI: chart generation denied. {reason or ''}",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "notebook-ai:chart-generation-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                "chartType": chart_type,
                "sourceProvided": len(source) > 0,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_notebook_export -- AI helps export the notebook
    # ------------------------------------------------------------------

    def intercept_notebook_export(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate AI notebook export.

        Exports may include sensitive output (PHI in cells, data previews, etc.).

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)
          2. Education / student mode: default-deny unless allow_export=True
          3. Air-gapped: only local file targets allowed

        Args:
            request: Dict with keys: format, exportTarget, packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        fmt = str(request.get("format", ""))
        export_target = request.get("exportTarget")
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        # Education / student mode: default-deny
        if (self.deployment_mode == "notebook-ai-education" or self.user_tier == "student") and not self.allow_export:
            reason_code = "notebook-ai-export-denied-education-mode"
            return self._deny(
                agent_id,
                "Notebook AI: notebook export denied in education mode. "
                "Export is default-denied for student/education sessions. "
                "Set allow_export=True in NotebookAIGovernedClient to enable. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        if not self.allow_export:
            reason_code = "notebook-ai-export-not-permitted"
            return self._deny(
                agent_id,
                "Notebook AI: notebook export denied -- allow_export is False. "
                "Set allow_export=True in NotebookAIGovernedClient to enable. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Air-gapped mode: only local file targets
        if self.deployment_mode == "notebook-ai-air-gapped" and export_target:
            target_str = str(export_target)
            is_local = (
                target_str.startswith("file://")
                or target_str.startswith("/")
                or target_str.startswith("./")
                or target_str.startswith("../")
            )
            if not is_local:
                reason_code = "notebook-ai-export-target-not-local-air-gapped"
                return self._deny(
                    agent_id,
                    f"Notebook AI: notebook export denied in air-gapped mode -- export target "
                    f"'{target_str}' is not a local path. Air-gapped deployments may only export "
                    "to local file paths (file://, /, ./, ../). Upload targets are not permitted. "
                    f"Reason code: {reason_code}.",
                    pack_binding=pack_binding,
                    reason_code=reason_code,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "notebook-ai:notebook-export-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                "format": fmt,
                "exportTargetProvided": export_target is not None,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_chat -- assistant panel chat
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Notebook AI assistant panel chat.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)
          2. Secret scan on prompt

        Args:
            request: Dict with keys: prompt, packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        prompt = str(request.get("prompt", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        # Secret scan on prompt
        secret_name = _scan_cell_for_secrets(prompt)
        if secret_name:
            reason_code = "notebook-ai-chat-secret-detected"
            return self._deny(
                agent_id,
                f"Notebook AI: chat request denied -- secret pattern detected in prompt "
                f"('{secret_name}'). The chat prompt appears to contain a credential or "
                "connection string. Remove the secret before sending. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "notebook-ai:chat-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                "promptLength": len(prompt),
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_slash_command -- /explain, /fix, /optimize, etc.
    # ------------------------------------------------------------------

    def intercept_slash_command(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Notebook AI slash commands.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-NOTEBOOK-1)

        Args:
            request: Dict with keys: command, args, packBinding, agentId.

        Returns:
            GovernanceDecision.
        """
        command = str(request.get("command", ""))
        args = str(request.get("args", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        deny = self._check_pack_binding(pack_binding, agent_id)
        if deny:
            return deny

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": f"notebook-ai:slash-command-requested",
            "args": {
                "platform": self.platform,
                "deploymentMode": self.deployment_mode,
                "command": command,
                "argsLength": len(args),
            },
            "packBinding": pack_binding,
        })


# ---------------------------------------------------------------------------
# NotebookAIPolicyBridge (mirror of other PolicyBridge shims)
# ---------------------------------------------------------------------------

class NotebookAIPolicyBridge:
    """Policy bridge for Notebook AI adapter.

    Thin wrapper that lets the governance policy server participate in
    Notebook AI decision loops by delegating to NotebookAIGovernedClient.

    Usage::

        bridge = NotebookAIPolicyBridge(
            client=gov,
            agent_name="notebook-bridge",
            pack_binding=["hipaa"],
            platform="hex-ai",
        )
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        pack_binding: list[str],
        platform: str,
        **kwargs: Any,
    ) -> None:
        self._inner = NotebookAIGovernedClient(
            client=client,
            agent_name=agent_name,
            pack_binding=pack_binding,
            platform=platform,
            **kwargs,
        )

    @property
    def inner(self) -> NotebookAIGovernedClient:
        return self._inner
