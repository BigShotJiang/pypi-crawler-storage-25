"""Semantic Kernel integration for Connexum governance.

Hooks into Microsoft Semantic Kernel's filter system with six canonical
governance hook surfaces. Python-native: integrates with the
semantic-kernel package when installed.

Hook surfaces (parity with src/orchestrator-adapters/semantic-kernel.ts):
  agentStart         -> gate at kernel workflow start
  toolCall           -> maps to SKFunctionInvocationContext (pre-invoke filter)
  toolResult         -> post-invoke audit hook
  llmCall            -> pre-LLM gate (prompt rendering filter)
  llmResult          -> post-LLM output classification
  agentEnd           -> terminal audit event sealing

Semantic Kernel-specific considerations:
  - Hooks into kernel.FunctionInvocationFilter (function_invocation_filter).
    Both InvokeFunctionAsync (standard) and InvokePromptAsync (prompt synthesis)
    paths are intercepted. Older SK versions bypass function filters on the
    InvokePromptAsync path; this adapter handles both explicitly.
  - Memory reads through SK's memory plugins are gated as a separate class of
    operation. memory_plugin_names configures which plugins are treated as
    memory plugins.
  - Skill-to-skill delegation (function A invoking function B) maps onto the
    DelegationDecision contract via check_skill_delegation().
  - MCP plugin invocations are detected via plugin name prefix "mcp_" and
    routed through the same approval surface as sensitive functions.
  - SK Python 1.x has FunctionInvocationFilter and PromptRenderingFilter
    abstract classes. Both are wrapped.

Lazy import: semantic-kernel is NOT hard-required. This module is always
importable. Hook methods work without the SDK installed.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.semantic_kernel import SemanticKernelGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = SemanticKernelGovernance(
        client=gov,
        allowed_plugins=["MathPlugin", "TextPlugin", "WebSearchPlugin"],
        sensitive_functions=["WebSearchPlugin.search", "DataPlugin.query"],
        memory_plugin_names=["MemoryPlugin", "SemanticMemory"],
        approved_models=["gpt-4o", "gpt-4o-mini"],
    )

    # At kernel workflow start:
    adapter.agent_start("workflow-001", pack_binding=["hipaa"], model="gpt-4o")

    # Before function invocation (SK filter surface):
    adapter.tool_call("workflow-001", "MathPlugin.add",
                      {"a": 1, "b": 2},
                      is_prompt_invocation=False, is_memory_read=False)

    # After function invocation:
    adapter.tool_result("workflow-001", "MathPlugin.add", "3", success=True)

    # Before an LLM call (prompt rendering filter):
    adapter.llm_call("workflow-001", "gpt-4o", messages=[...])

    # After LLM response:
    adapter.llm_result("workflow-001", "gpt-4o", response_text="...")

    # At workflow end:
    adapter.agent_end("workflow-001", success=True)

    # For skill-to-skill delegation:
    adapter.check_skill_delegation(
        session_id="workflow-001",
        caller_plugin="PlannerPlugin", caller_function="execute",
        target_plugin="DataPlugin", target_function="query",
    )
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation


# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------

class SKFunctionNotFoundError(RuntimeError):
    """Raised when a Semantic Kernel function is not found in the allowed list."""

    def __init__(self, plugin_name: str, function_name: str):
        super().__init__(
            f'SK function "{plugin_name}.{function_name}" is not in the allowed plugin list.'
        )
        self.plugin_name = plugin_name
        self.function_name = function_name


class SKMemoryAccessDeniedError(RuntimeError):
    """Raised when a memory read is denied due to missing reviewer queue."""

    def __init__(self, fully_qualified_name: str):
        super().__init__(
            f'Memory read via "{fully_qualified_name}" requires security-reviewer tier '
            "but no queue binding exists. Fail closed."
        )
        self.fully_qualified_name = fully_qualified_name


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)

_MCP_PLUGIN_PREFIX = "mcp_"


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


# ---------------------------------------------------------------------------
# SemanticKernelGovernance
# ---------------------------------------------------------------------------

class SemanticKernelGovernance:
    """Governance adapter for Microsoft Semantic Kernel.

    Exposes six lifecycle hooks mapped to SK's filter surfaces:
      - FunctionInvocationFilter (pre/post function invoke)
      - PromptRenderingFilter (pre LLM call)

    Register the governance hooks with your SK Kernel:

        # In SK Python 1.x:
        kernel.add_function_invocation_filter(adapter.to_function_invocation_filter())

    Does NOT hard-depend on the semantic-kernel package. All hook methods
    accept plain Python dicts / strings so they work from tests without
    the SDK installed.
    """

    def __init__(
        self,
        client: GovernanceClient,
        allowed_plugins: list[str],
        sensitive_functions: Optional[list[str]] = None,
        memory_plugin_names: Optional[list[str]] = None,
        approved_models: Optional[list[str]] = None,
        max_plan_steps: Optional[int] = None,
        sensitive_arg_keys: Optional[list[str]] = None,
        enforce_pack_binding: bool = True,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            allowed_plugins: Plugin names allowed to be invoked under governance.
                             Empty list causes all invocations to be denied (fail closed).
            sensitive_functions: Fully-qualified function names ("Plugin.Function") that
                                 require reviewer approval.
            memory_plugin_names: Plugin names treated as memory plugins.
                                 Memory reads trigger additional gating.
            approved_models: LLM model IDs approved for use.
            max_plan_steps: Maximum steps in a governed SK plan.
            sensitive_arg_keys: Argument keys to scan for PHI.
            enforce_pack_binding: If True (default), pack-binding required at spawn.
        """
        self.client = client
        self.allowed_plugins = allowed_plugins
        self.sensitive_functions = sensitive_functions or []
        self.memory_plugin_names = memory_plugin_names or []
        self.approved_models = approved_models or []
        self.max_plan_steps = max_plan_steps
        self.sensitive_arg_keys = sensitive_arg_keys or ["query", "input", "content", "message"]
        self.enforce_pack_binding = enforce_pack_binding

        # session_id -> state
        self._sessions: dict[str, dict[str, Any]] = {}
        self._pending_audits: dict[str, str] = {}

    # ------------------------------------------------------------------
    # agentStart -- gate at SK kernel workflow start
    # ------------------------------------------------------------------

    def agent_start(
        self,
        session_id: str,
        pack_binding: Optional[list[str]] = None,
        model: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Gate at Semantic Kernel workflow start.

        Checks pack-binding primacy and provider compliance.
        """
        pack = pack_binding or []

        if self.enforce_pack_binding and not pack:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'SK session "{session_id}" attempted agent_start without a pack binding. '
                "Every session MUST carry packBinding before any function fires."
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        if model and self.approved_models and model not in self.approved_models:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'LLM model "{model}" is not on the approved provider list. '
                f"Approved: {', '.join(self.approved_models)}"
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        agent = AgentIdentity(name="sk-kernel", session_id=session_id)
        decision = self.client.check_action(
            tool="agent.start",
            input={
                "sessionId": session_id,
                "packBinding": pack,
                "model": model,
                "metadata": metadata or {},
                "framework": "semantic-kernel",
            },
            agent=agent,
        )

        self._sessions[session_id] = {
            "pack_binding": pack,
            "model": model,
        }
        if decision.audit_id:
            self._pending_audits[f"start:{session_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolCall -- pre-function-invocation filter (SK FunctionInvocationFilter)
    # ------------------------------------------------------------------

    def tool_call(
        self,
        session_id: str,
        fully_qualified_name: str,
        args: dict[str, Any],
        is_prompt_invocation: bool = False,
        is_memory_read: bool = False,
        invocation_id: Optional[str] = None,
    ) -> GovernanceDecision:
        """Pre-function-invocation governance check.

        Intercepts both paths:
          1. InvokeFunctionAsync (standard, all SK versions)
          2. InvokePromptAsync (prompt synthesis, older SK versions bypass filters)

        Memory reads are gated as a separate operation class.
        MCP plugins (prefixed "mcp_") are treated as sensitive functions.
        Sensitive functions (by fullyQualifiedName) are routed to approval tier.

        Args:
            fully_qualified_name: "PluginName.FunctionName" format.
            is_prompt_invocation: True if triggered via InvokePromptAsync path.
            is_memory_read: True if this is a memory plugin read operation.
        """
        plugin_name = fully_qualified_name.split(".")[0] if "." in fully_qualified_name else fully_qualified_name
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])
        effective_id = invocation_id or str(uuid.uuid4())

        # Plugin allowlist check (fail closed on empty allowed_plugins).
        # Memory plugins, MCP plugins, and explicitly sensitive functions bypass
        # the allowlist -- they have their own specialised approval path below
        # and must not be denied here.
        is_memory_plugin_pre = plugin_name in self.memory_plugin_names
        is_mcp_pre = plugin_name.lower().startswith(_MCP_PLUGIN_PREFIX)
        is_sensitive_pre = (
            fully_qualified_name in self.sensitive_functions
            or any(sf.startswith(plugin_name + ".") for sf in self.sensitive_functions)
        )
        if (
            not is_memory_plugin_pre
            and not is_mcp_pre
            and not is_sensitive_pre
            and (not self.allowed_plugins or plugin_name not in self.allowed_plugins)
        ):
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = f'SK plugin "{plugin_name}" is not in the allowed plugin list'
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=effective_id,
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        # Memory plugin governance (security-reviewer tier)
        is_memory_plugin = plugin_name in self.memory_plugin_names
        if is_memory_read or is_memory_plugin:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Memory read via "{fully_qualified_name}" routed to security-reviewer approval. '
                "Memory access requires elevated review under active pack binding."
            )
            d = GovernanceDecision(
                decision=DecisionType.REQUIRE_APPROVAL,
                reason=reason,
                audit_id=effective_id,
            )
            return d

        # MCP plugin detection
        is_mcp = plugin_name.lower().startswith(_MCP_PLUGIN_PREFIX)

        # Sensitive function check (includes MCP plugins)
        is_sensitive = (
            fully_qualified_name in self.sensitive_functions
            or is_mcp
        )
        if is_sensitive:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'SK function "{fully_qualified_name}" requires human-reviewer approval '
                f'({"MCP plugin" if is_mcp else "sensitive function"}).'
            )
            d = GovernanceDecision(
                decision=DecisionType.REQUIRE_APPROVAL,
                reason=reason,
                audit_id=effective_id,
            )
            return d

        # Exfiltration scan
        exfil_key = self._scan_args(args)
        if exfil_key:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Possible data exfiltration in args for SK function "{fully_qualified_name}" '
                f'(key: "{exfil_key}"). Blocked at G5/G7 egress guard.'
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=effective_id,
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        agent = AgentIdentity(name="sk-kernel", session_id=session_id)
        decision = self.client.check_action(
            tool=f"sk.function.{fully_qualified_name}",
            input={
                "sessionId": session_id,
                "invocationId": effective_id,
                "fullyQualifiedName": fully_qualified_name,
                "pluginName": plugin_name,
                "isPromptInvocation": is_prompt_invocation,
                "isMemoryRead": is_memory_read,
                "argsDigest": str(args)[:500],
                "packBinding": pack,
                "framework": "semantic-kernel",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"fn:{session_id}:{fully_qualified_name}:{effective_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolResult -- post-function-invocation audit
    # ------------------------------------------------------------------

    def tool_result(
        self,
        session_id: str,
        fully_qualified_name: str,
        result: Any,
        success: bool = True,
        duration_ms: Optional[int] = None,
        invocation_id: Optional[str] = None,
    ) -> None:
        """Post-function-invocation G-series classification and audit chain close."""
        audit_key_prefix = f"fn:{session_id}:{fully_qualified_name}:"
        audit_id = None
        if invocation_id:
            audit_id = self._pending_audits.pop(f"{audit_key_prefix}{invocation_id}", None)
        if audit_id is None:
            # pop any pending audit for this function
            for k in list(self._pending_audits):
                if k.startswith(audit_key_prefix):
                    audit_id = self._pending_audits.pop(k)
                    break

        result_text = str(result) if not isinstance(result, str) else result
        phi_found = _contains_phi(result_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output classifier: possible PHI in SK function "
                f'result "{fully_qualified_name}" (session: {session_id}). '
                f"Audit ID: {audit_id}",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success and not phi_found,
                    summary=result_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Output classifier: PHI in SK function result",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # llmCall -- prompt rendering filter (PromptRenderingFilter)
    # ------------------------------------------------------------------

    def llm_call(
        self,
        session_id: str,
        model: str,
        messages: list[dict[str, Any]],
        prompt: Optional[str] = None,
        tools: Optional[list[dict[str, Any]]] = None,
    ) -> GovernanceDecision:
        """Pre-LLM governance check via SK PromptRenderingFilter.

        Checks:
          1. Pack-binding presence
          2. Approved model list
        """
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])

        if self.approved_models and model not in self.approved_models:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'SK LLM model "{model}" is not on the approved provider list. '
                f"Approved: {', '.join(self.approved_models)}"
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        agent = AgentIdentity(name="sk-kernel", session_id=session_id)
        decision = self.client.check_action(
            tool="llm.call",
            input={
                "sessionId": session_id,
                "model": model,
                "messageCount": len(messages),
                "toolCount": len(tools or []),
                "promptDigest": (prompt or "")[:300],
                "packBinding": pack,
                "framework": "semantic-kernel",
                "filter": "prompt-rendering",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"llm:{session_id}:{model}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # llmResult -- post-LLM output classification
    # ------------------------------------------------------------------

    def llm_result(
        self,
        session_id: str,
        model: str,
        response_text: str,
        usage: Optional[dict[str, int]] = None,
    ) -> None:
        """Post-LLM output exfiltration scan and audit chain close."""
        audit_id = self._pending_audits.pop(f"llm:{session_id}:{model}", None)

        phi_found = _contains_phi(response_text)
        if phi_found:
            print(
                f"[GOVERNANCE] Output exfiltration scanner: possible PHI in "
                f'SK LLM response (model: {model}, session: {session_id}). '
                "Flagged for compliance review.",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=not phi_found,
                    summary=response_text[:200],
                    error=None if not phi_found else "Output exfiltration scanner: PHI in SK LLM response",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # agentEnd -- terminal audit event sealing
    # ------------------------------------------------------------------

    def agent_end(
        self,
        session_id: str,
        success: bool,
        summary: Optional[str] = None,
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
    ) -> None:
        """Terminal audit event sealing and session cleanup."""
        session = self._sessions.pop(session_id, {})
        start_audit_id = self._pending_audits.pop(f"start:{session_id}", None)
        agent = AgentIdentity(name="sk-kernel", session_id=session_id)

        try:
            self.client.check_action(
                tool="agent.end",
                input={
                    "sessionId": session_id,
                    "success": success,
                    "summary": summary or ("SK workflow complete" if success else "SK workflow failed"),
                    "durationMs": duration_ms,
                    "error": error,
                    "packBinding": session.get("pack_binding", []),
                    "model": session.get("model"),
                    "framework": "semantic-kernel",
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        if start_audit_id:
            try:
                self.client.report_result(
                    audit_id=start_audit_id,
                    success=success,
                    summary=summary or "",
                    duration_ms=duration_ms,
                    error=error,
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # check_skill_delegation -- SK skill-to-skill delegation governance
    # ------------------------------------------------------------------

    def check_skill_delegation(
        self,
        session_id: str,
        caller_plugin: str,
        caller_function: str,
        target_plugin: str,
        target_function: str,
        args: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Govern a skill-to-skill delegation (function A invoking function B).

        SK's function invocation chaining maps onto the DelegationDecision
        contract. When a SK function invokes another function, this constitutes
        a delegation event and fires the delegation governance check.

        Sensitive target functions require human-reviewer approval.
        """
        target_fqn = f"{target_plugin}.{target_function}"
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])

        # Sensitive target check
        if target_fqn in self.sensitive_functions:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Skill delegation to sensitive function "{target_fqn}" requires '
                "human-reviewer approval."
            )
            d = GovernanceDecision(
                decision=DecisionType.REQUIRE_APPROVAL,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            return d

        caller_fqn = f"{caller_plugin}.{caller_function}"
        agent = AgentIdentity(name=caller_fqn, session_id=session_id)
        decision = self.client.check_action(
            tool="sk.delegation",
            input={
                "sessionId": session_id,
                "callerPlugin": caller_plugin,
                "callerFunction": caller_function,
                "targetPlugin": target_plugin,
                "targetFunction": target_function,
                "targetFqn": target_fqn,
                "packBinding": pack,
                "framework": "semantic-kernel",
            },
            agent=agent,
        )

        return decision

    # ------------------------------------------------------------------
    # to_function_invocation_filter -- factory for SK filter integration
    # ------------------------------------------------------------------

    def to_function_invocation_filter(self) -> "SKGovernanceFilterShim":
        """Return a shim object suitable for registration as an SK filter.

        In SK Python 1.x:
            kernel.add_function_invocation_filter(adapter.to_function_invocation_filter())

        The returned object calls back into this adapter's hook methods.
        """
        return SKGovernanceFilterShim(self)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _scan_args(self, args: dict[str, Any]) -> Optional[str]:
        """Scan function arguments for PHI patterns on sensitive keys."""
        for key in self.sensitive_arg_keys:
            value = args.get(key)
            if isinstance(value, str) and _contains_phi(value):
                return key
        return None


# ---------------------------------------------------------------------------
# SKGovernanceFilterShim
# ---------------------------------------------------------------------------

class SKGovernanceFilterShim:
    """Shim that wraps SemanticKernelGovernance for SK filter registration.

    Mirrors the IFunctionInvocationFilter interface. The exact Python binding
    method signatures depend on the SK version installed; this shim exposes
    the canonical names documented in SK Python 1.x.

    DEFERRED-SK-PY-BINDING: Confirm method name and signature against the
    shipped SK Python 1.x API before production use.
    """

    def __init__(self, adapter: SemanticKernelGovernance):
        self._adapter = adapter

    async def on_function_invoking(
        self,
        context: Any,
        session_id: str = "default",
    ) -> GovernanceDecision:
        """Called before function invocation (OnFunctionInvokingAsync equivalent)."""
        plugin_name = getattr(context, "plugin_name", "unknown")
        function_name = getattr(context, "function_name", "unknown")
        fqn = f"{plugin_name}.{function_name}"
        args = getattr(context, "arguments", {})
        is_prompt = getattr(context, "is_prompt_invocation", False)
        is_memory = getattr(context, "is_memory_read", False)
        invocation_id = getattr(context, "invocation_id", None)

        return self._adapter.tool_call(
            session_id=session_id,
            fully_qualified_name=fqn,
            args=dict(args) if hasattr(args, "__iter__") else {},
            is_prompt_invocation=bool(is_prompt),
            is_memory_read=bool(is_memory),
            invocation_id=invocation_id,
        )

    async def on_function_invoked(
        self,
        context: Any,
        result: Any,
        session_id: str = "default",
    ) -> None:
        """Called after function invocation (OnFunctionInvokedAsync equivalent)."""
        plugin_name = getattr(context, "plugin_name", "unknown")
        function_name = getattr(context, "function_name", "unknown")
        fqn = f"{plugin_name}.{function_name}"
        invocation_id = getattr(context, "invocation_id", None)
        duration_ms = getattr(result, "duration_ms", None)
        success = getattr(result, "success", True)
        value = getattr(result, "value", result)

        self._adapter.tool_result(
            session_id=session_id,
            fully_qualified_name=fqn,
            result=value,
            success=success,
            duration_ms=duration_ms,
            invocation_id=invocation_id,
        )
