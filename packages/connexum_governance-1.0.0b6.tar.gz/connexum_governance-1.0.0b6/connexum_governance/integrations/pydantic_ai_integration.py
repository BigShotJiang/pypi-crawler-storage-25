"""
GovernedPydanticAI -- governance enforcement for Pydantic AI (Python).

This is a FRAMEWORK ADAPTER operating at the Pydantic AI SDK layer. It intercepts
between customer code and Pydantic AI's Agent, tool, and result validation surfaces,
enforcing governance policy at tool invocation, agent run, and result output boundaries.

=== ARCHITECTURAL CONTRAST: Pydantic AI vs Prior Adapters ===

LangChain's callback system is OBSERVABILITY-first. GovernedTool._run() is the
only guaranteed blocking path (see langchain_integration.py).

OpenAI Agents SDK provides FIRST-CLASS blocking via input/output guardrails --
a contract-guaranteed gate in the SDK's public API.

Pydantic AI's blocking model:

  @agent.tool / @agent.tool_plain decorators:
    These are the CANONICAL registration points for tools in Pydantic AI.
    The decorated function becomes the invocable tool body. Wrapping the
    decorated function BEFORE registration (or intercepting the decorator
    itself) ensures governance runs before every tool call, regardless of
    which agent or run triggers the tool.

    Pydantic AI does NOT provide a callback or hook system for tool dispatch.
    The @agent.tool decorator is the ONLY registration path. This means:
    - Wrapping the decorator (governed_tool_decorator) is the GUARANTEED path.
    - There is no observability-only secondary gate in Pydantic AI's API.

  agent.run() / run_sync() / run_stream():
    Entry points for agent execution. Monkeypatching these runs a governance
    check on the input prompt BEFORE the agent processes it. This catches
    prompt injection at the agent boundary.

  result_type (Pydantic model validation):
    Pydantic AI uses Pydantic models to validate agent output. The
    GovernedAgentResult wrapper scans string fields in the result for PII/PHI
    using the built-in sensitive data classifier. This is OUTPUT-SIDE enforcement.

BLOCKING STORY (ranked best to worst):
  1. governed_tool_decorator() / governed_tool_plain_decorator()  -- GUARANTEED
        Runs governance inside the tool function body before any computation.
        Fires every time a tool is invoked, regardless of run method or context.
  2. wrap_agent_run() (run/run_sync/run_stream wraps)             -- GUARANTEED
        Blocks at the agent entry point before any LLM call or tool dispatch.
  3. GovernedAgentResult (output-side classification)             -- OBSERVABILITY
        Scans result fields for PII/PHI; raises GovernanceViolation if found.
        Run AFTER the agent produces output (cannot block LLM computation).

CRITICAL NOTE on tool registration:
  Pydantic AI's @agent.tool decorator registers functions at AGENT CONSTRUCTION
  time. governed_tool_decorator() replaces agent.tool so that any function
  decorated with it is wrapped with a governance pre-check before Pydantic AI
  sees it. This means governance is baked into the tool function itself -- the
  Pydantic AI runtime calls the wrapped function and governance runs first.

  Contrast with LangChain: GovernedTool wraps an EXISTING tool object post-hoc.
  With Pydantic AI: governed_tool_decorator replaces the DECORATOR so the tool
  function carries governance from the point of registration.

Action name namespace (for pack rule targeting):
  framework.pydantic_ai.tool_invoke     -- governed tool execution (GUARANTEED)
  framework.pydantic_ai.agent_run       -- agent.run() / run_sync() entry guard
  framework.pydantic_ai.result_validate -- GovernedAgentResult output scan
  framework.pydantic_ai.stream_chunk    -- run_stream() per-chunk scan

Supported pydantic-ai version range (tested against mock primitives):
  pydantic-ai >= 0.0.13

Architectural difference vs LangChain / OpenAI Agents SDK:
  Pydantic AI is type-safe throughout. Tools are typed Python functions.
  There is no callback system, no guardrail protocol, no hook interface.
  The adapter must work entirely through function wrapping (decorator
  interception and monkeypatching).

  Because Pydantic AI agents are designed to be immutable after construction,
  wrap_agent() patches run/run_sync/run_stream on the existing Agent instance
  and replaces the agent.tool and agent.tool_plain attributes with governed
  decorator variants for future tool registrations.

Optional peer dependencies:
  pydantic-ai >= 0.0.13

@connexum/python-sdk -- Framework Adapter Layer (Sprint 5, WS-13)
"""

from __future__ import annotations

import asyncio
import json
import re
import sys
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Callable, Optional, Union

from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations._wire_shape import build_check_action_body

# Lazy import of GovernanceClient (optional: do not create a hard circular dep)
try:
    from connexum_governance.client import GovernanceClient as _GovernanceClient
except ImportError:
    _GovernanceClient = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

CheckFnType = Callable[[str, dict], Any]


# ---------------------------------------------------------------------------
# _resolve_governance_params
#
# Resolves governance connection parameters from either a GovernanceClient
# instance or standalone URL + key (deprecated). Enables the adapter to
# accept GovernanceClient uniformly like every other Python adapter.
# ---------------------------------------------------------------------------

def _resolve_governance_params(
    governance_client: Optional[Any] = None,
    governance_server_url: Optional[str] = None,
    license_key: Optional[str] = None,
) -> tuple[str, str]:
    """
    Resolve (governance_server_url, license_key) from either:
      - governance_client: a GovernanceClient instance (preferred)
      - governance_server_url + license_key: standalone params (deprecated)

    Returns:
        Tuple of (governance_server_url, license_key).

    Raises:
        ValueError: If neither a GovernanceClient nor standalone params are supplied.
    """
    if governance_client is not None:
        # GovernanceClient instance: extract URL and license key
        url = getattr(governance_client, "api_url", None)
        key = getattr(governance_client, "license_key", None)
        if not url or not key:
            raise ValueError(
                "[PydanticAI governance] GovernanceClient must have api_url and "
                "license_key attributes."
            )
        return url, key

    if governance_server_url and license_key:
        import warnings
        warnings.warn(
            "Passing governance_server_url and license_key as standalone parameters "
            "to the PydanticAI governance adapter is deprecated. Pass a GovernanceClient "
            "instance via governance_client= instead. "
            "Standalone params will be removed in a future release.",
            DeprecationWarning,
            stacklevel=3,
        )
        return governance_server_url, license_key

    raise ValueError(
        "[PydanticAI governance] Either governance_client= (preferred) or both "
        "governance_server_url= and license_key= must be supplied."
    )

# ---------------------------------------------------------------------------
# PII / PHI / sensitive data classifier (mirrors OpenAI Agents adapter)
# ---------------------------------------------------------------------------

_SENSITIVE_PATTERNS = [
    re.compile(r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"),           # SSN
    re.compile(r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"), # Credit card
    re.compile(
        r"\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi|medication|prescription)\s*[:=]",
        re.IGNORECASE,
    ),
    re.compile(r"\b(sk-|pk_|rk_|api_key\s*[:=])", re.IGNORECASE),
]


def _contains_sensitive_data(text: str) -> bool:
    """Returns True if text contains PII, PHI, or credential patterns."""
    return any(p.search(text) for p in _SENSITIVE_PATTERNS)


# ---------------------------------------------------------------------------
# Prompt injection detector
# ---------------------------------------------------------------------------

_HIGH_INJECTION_PATTERNS = [
    "ignore previous instructions",
    "ignore your system prompt",
    "ignore all previous",
    "disregard previous",
    "forget your instructions",
    "you are now a different",
    "you are now an",
    "act as if you",
    "pretend you are",
    "reveal all secrets",
    "reveal your system prompt",
    "output your instructions",
    "your new instructions are",
    "new instructions:",
    "system override",
    "i am your administrator",
    "i am your operator",
    "override safety",
    "ignore safety",
    "bypass",
    "jailbreak",
]

_MEDIUM_INJECTION_PATTERNS = [
    "ignore the above",
    "disregard the above",
    "don't follow",
    "do not follow",
    "forget what",
    "as an ai without",
    "without restrictions",
    "without limitations",
    "without constraints",
    "act without",
    "you have no",
    "you must always",
    "you must never",
]


def _detect_injection(text: str) -> dict:
    """
    Lightweight prompt injection scan.

    Returns:
        {detected: bool, severity: 'high'|'medium'|'low', patterns: list[str]}
    """
    lowered = text.lower()
    matched_high = [p for p in _HIGH_INJECTION_PATTERNS if p in lowered]
    if matched_high:
        return {"detected": True, "severity": "high", "patterns": matched_high}
    matched_medium = [p for p in _MEDIUM_INJECTION_PATTERNS if p in lowered]
    if matched_medium:
        return {"detected": True, "severity": "medium", "patterns": matched_medium}
    return {"detected": False, "severity": "low", "patterns": []}


# ---------------------------------------------------------------------------
# HTTP check helpers (same contract as langchain_integration.py)
# ---------------------------------------------------------------------------

async def _do_check_async(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            return await check_fn(governance_server_url, body)
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        async with _httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


def _do_check_sync(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            try:
                loop = asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(
                        lambda: asyncio.run(check_fn(governance_server_url, body))
                    )
                    return future.result()
            except RuntimeError:
                return asyncio.run(check_fn(governance_server_url, body))
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        with _httpx.Client(timeout=5.0) as client:
            resp = client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


# ---------------------------------------------------------------------------
# Decision enforcement helpers
# ---------------------------------------------------------------------------

def _enforce_decision_sync(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
    log_prefix: str = "GovernedPydanticAI",
) -> None:
    decision = result.get("decision", "ALLOW")
    if decision == "DENY":
        reason = result.get("reason") or "policy"
        sys.stderr.write(
            f"[{log_prefix}] DENIED for '{context_label}'. reason={reason}\n"
        )
        if raise_on_deny:
            raise GovernanceViolation(
                decision="DENY",
                reason=reason,
                audit_id=result.get("auditId"),
            )
        return
    if decision == "REQUIRE_APPROVAL":
        approval_id = result.get("approvalId")
        audit_id = result.get("auditId")
        if not approval_id:
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                    audit_id=audit_id,
                )
            return
        sys.stderr.write(
            f"[{log_prefix}] PENDING for '{context_label}'. approvalId={approval_id}\n"
        )
        if raise_on_deny:
            raise GovernancePendingApproval(
                approval_id=approval_id,
                audit_id=audit_id,
            )


async def _enforce_decision_async(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
    log_prefix: str = "GovernedPydanticAI",
) -> None:
    """Async-compatible version -- same logic, no blocking I/O."""
    _enforce_decision_sync(result, context_label, raise_on_deny, log_prefix)


# ---------------------------------------------------------------------------
# governed_tool_decorator
#
# PRIMARY BLOCKING PRIMITIVE (input side).
#
# Replaces agent.tool so that any function registered with @agent.tool is
# wrapped with a governance pre-check. The wrapped function runs governance
# BEFORE Pydantic AI's tool execution pipeline begins.
#
# Usage:
#   original_tool_decorator = agent.tool
#   agent.tool = governed_tool_decorator(agent, governance_client)
#   # Now @agent.tool wraps functions with governance.
# ---------------------------------------------------------------------------


def governed_tool_decorator(
    agent: Any,
    governance_server_url: Optional[str] = None,
    license_key: Optional[str] = None,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
    governance_client: Optional[Any] = None,
) -> Callable:
    """
    Returns a replacement for agent.tool that wraps each registered tool
    function with a governance pre-check.

    The returned decorator mimics the @agent.tool signature: it accepts a
    function, wraps it with governance, and delegates to the original
    agent.tool for Pydantic AI's registration bookkeeping.

    This is the PRIMARY BLOCKING PRIMITIVE for Pydantic AI tool invocations.

    GUARANTEED BLOCKING: governance runs inside the tool function body before
    any computation. Fires regardless of which run method (run/run_sync/run_stream)
    triggers the tool.

    Args:
        agent: The Pydantic AI Agent instance with a .tool attribute.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        A decorator that wraps tool functions with governance before
        registering them with the original agent.tool mechanism.
    """
    # Resolve governance connection params (GovernanceClient preferred).
    # stacklevel=3 to point deprecation warning at the caller of this function.
    _resolved_url, _resolved_key = _resolve_governance_params(
        governance_client=governance_client,
        governance_server_url=governance_server_url,
        license_key=license_key,
    )
    governance_server_url = _resolved_url
    license_key = _resolved_key

    original_tool = getattr(agent, "tool", None)
    if original_tool is None:
        raise ValueError(
            "[governed_tool_decorator] agent.tool attribute is required"
        )

    def governing_decorator(fn: Callable) -> Callable:
        tool_name = getattr(fn, "__name__", "unknown_tool")

        if asyncio.iscoroutinefunction(fn):
            @wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                try:
                    input_preview = json.dumps(kwargs or dict(enumerate(args)))[:200]
                except Exception:
                    input_preview = str(args)[:200]

                result = await _do_check_async(
                    governance_server_url=governance_server_url,
                    license_key=license_key,
                    body=build_check_action_body(
                        tool_name=f"tool.{tool_name}",
                        agent_name=f"pydantic-ai-tool:{tool_name}",
                        framework_action="framework.pydantic_ai.tool_invoke",
                        input_dict={"input": input_preview},
                        message_preview=input_preview,
                        pack_ids=pack_ids,
                        extra_metadata={"toolName": tool_name, "inputPreview": input_preview, "tool": f"tool.{tool_name}"},
                        source="governed_tool_decorator",
                        tools=[tool_name],
                    ),
                    check_fn=_check_fn,
                )
                _enforce_decision_sync(result, tool_name, raise_on_deny)
                return await fn(*args, **kwargs)

            async_wrapper._governed = True
            async_wrapper._governed_tool_name = tool_name
            # Delegate registration to original agent.tool
            return original_tool(async_wrapper)

        else:
            @wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                try:
                    input_preview = json.dumps(kwargs or dict(enumerate(args)))[:200]
                except Exception:
                    input_preview = str(args)[:200]

                result = _do_check_sync(
                    governance_server_url=governance_server_url,
                    license_key=license_key,
                    body=build_check_action_body(
                        tool_name=f"tool.{tool_name}",
                        agent_name=f"pydantic-ai-tool:{tool_name}",
                        framework_action="framework.pydantic_ai.tool_invoke",
                        input_dict={"input": input_preview},
                        message_preview=input_preview,
                        pack_ids=pack_ids,
                        extra_metadata={"toolName": tool_name, "inputPreview": input_preview, "tool": f"tool.{tool_name}"},
                        source="governed_tool_decorator",
                        tools=[tool_name],
                    ),
                    check_fn=_check_fn,
                )
                _enforce_decision_sync(result, tool_name, raise_on_deny)
                return fn(*args, **kwargs)

            sync_wrapper._governed = True
            sync_wrapper._governed_tool_name = tool_name
            return original_tool(sync_wrapper)

    return governing_decorator


def governed_tool_plain_decorator(
    agent: Any,
    governance_server_url: Optional[str] = None,
    license_key: Optional[str] = None,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
    governance_client: Optional[Any] = None,
) -> Callable:
    """
    Returns a replacement for agent.tool_plain that wraps each registered
    tool function with a governance pre-check.

    Same as governed_tool_decorator but targets the tool_plain variant.
    tool_plain is used for tools that do not receive RunContext (plain
    functions that only take typed arguments). The governance pre-check
    runs identically to governed_tool_decorator.

    GUARANTEED BLOCKING: same contract as governed_tool_decorator.

    Args:
        agent: The Pydantic AI Agent instance with a .tool_plain attribute.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        A decorator that wraps tool_plain functions with governance before
        registering them with the original agent.tool_plain mechanism.
    """
    # Resolve governance connection params (GovernanceClient preferred).
    _resolved_url, _resolved_key = _resolve_governance_params(
        governance_client=governance_client,
        governance_server_url=governance_server_url,
        license_key=license_key,
    )
    governance_server_url = _resolved_url
    license_key = _resolved_key

    original_tool_plain = getattr(agent, "tool_plain", None)
    if original_tool_plain is None:
        raise ValueError(
            "[governed_tool_plain_decorator] agent.tool_plain attribute is required"
        )

    def governing_decorator(fn: Callable) -> Callable:
        tool_name = getattr(fn, "__name__", "unknown_tool")

        if asyncio.iscoroutinefunction(fn):
            @wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                try:
                    input_preview = json.dumps(kwargs or dict(enumerate(args)))[:200]
                except Exception:
                    input_preview = str(args)[:200]

                result = await _do_check_async(
                    governance_server_url=governance_server_url,
                    license_key=license_key,
                    body=build_check_action_body(
                        tool_name=f"tool.{tool_name}",
                        agent_name=f"pydantic-ai-tool:{tool_name}",
                        framework_action="framework.pydantic_ai.tool_invoke",
                        input_dict={"input": input_preview},
                        message_preview=input_preview,
                        pack_ids=pack_ids,
                        extra_metadata={"toolName": tool_name, "inputPreview": input_preview, "tool": f"tool.{tool_name}"},
                        source="governed_tool_plain_decorator",
                        tools=[tool_name],
                    ),
                    check_fn=_check_fn,
                )
                _enforce_decision_sync(result, tool_name, raise_on_deny)
                return await fn(*args, **kwargs)

            async_wrapper._governed = True
            async_wrapper._governed_tool_name = tool_name
            return original_tool_plain(async_wrapper)

        else:
            @wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                try:
                    input_preview = json.dumps(kwargs or dict(enumerate(args)))[:200]
                except Exception:
                    input_preview = str(args)[:200]

                result = _do_check_sync(
                    governance_server_url=governance_server_url,
                    license_key=license_key,
                    body=build_check_action_body(
                        tool_name=f"tool.{tool_name}",
                        agent_name=f"pydantic-ai-tool:{tool_name}",
                        framework_action="framework.pydantic_ai.tool_invoke",
                        input_dict={"input": input_preview},
                        message_preview=input_preview,
                        pack_ids=pack_ids,
                        extra_metadata={"toolName": tool_name, "inputPreview": input_preview, "tool": f"tool.{tool_name}"},
                        source="governed_tool_plain_decorator",
                        tools=[tool_name],
                    ),
                    check_fn=_check_fn,
                )
                _enforce_decision_sync(result, tool_name, raise_on_deny)
                return fn(*args, **kwargs)

            sync_wrapper._governed = True
            sync_wrapper._governed_tool_name = tool_name
            return original_tool_plain(sync_wrapper)

    return governing_decorator


# ---------------------------------------------------------------------------
# wrap_agent_run
#
# AGENT-ENTRY blocking gate. Monkeypatches agent.run / run_sync / run_stream
# to run a governance check on the prompt before any LLM call.
# ---------------------------------------------------------------------------


def wrap_agent_run(
    agent: Any,
    governance_server_url: Optional[str] = None,
    license_key: Optional[str] = None,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    injection_deny_threshold: str = "high",
    _check_fn: Optional[CheckFnType] = None,
    governance_client: Optional[Any] = None,
) -> Any:
    """
    Monkeypatches agent.run, agent.run_sync, and agent.run_stream so that each
    invocation runs a governance check on the input prompt before any LLM call.

    This intercepts prompt injection at the agent entry boundary. It does NOT
    intercept individual tool calls -- use governed_tool_decorator for that.

    BLOCKING CONTRACT:
      DENY -> raises GovernanceViolation before the LLM call begins.
      PENDING -> raises GovernancePendingApproval.
      ALLOW -> delegates to the original run/run_sync/run_stream.

    Idempotent: calling wrap_agent_run twice will not double-wrap (checked via
    _connexum_governed marker on wrapped methods).

    Args:
        agent: The Pydantic AI Agent instance.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        injection_deny_threshold: 'high' or 'medium' injection scan threshold.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        The same agent instance with run/run_sync/run_stream wrapped.
    """
    # Resolve governance connection params (GovernanceClient preferred).
    _resolved_url, _resolved_key = _resolve_governance_params(
        governance_client=governance_client,
        governance_server_url=governance_server_url,
        license_key=license_key,
    )
    governance_server_url = _resolved_url
    license_key = _resolved_key

    # Idempotency check
    if getattr(agent, "_connexum_run_governed", False):
        return agent

    def _build_run_body(prompt: Any, source: str) -> dict:
        if isinstance(prompt, list):
            prompt_text = " ".join(
                m.get("content", "") if isinstance(m, dict) else str(m)
                for m in prompt
            )
        else:
            prompt_text = str(prompt) if prompt is not None else ""

        # Prompt injection scan
        detection = _detect_injection(prompt_text)
        if detection["detected"]:
            severity = detection["severity"]
            should_block = severity == "high" or (
                injection_deny_threshold == "medium" and severity == "medium"
            )
            sys.stderr.write(
                f"[wrap_agent_run] prompt-injection:{severity} detected on {source}. "
                f"patterns={detection['patterns']}\n"
            )
            if should_block and raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=(
                        f"Prompt injection detected (severity={severity}, "
                        f"patterns={detection['patterns']}). "
                        "Blocked by connexum-governance (Onyx #5 / OWASP LLM01)."
                    ),
                )

        # Tool-name slot derives from the run-method (run / run_sync / run_stream)
        # so pack rules can target each entry-point distinctly.
        run_slot = source.split(".")[-1] if "." in source else source
        return build_check_action_body(
            tool_name=run_slot or "agent_run",
            agent_name=f"pydantic-ai-agent:{run_slot}",
            framework_action="framework.pydantic_ai.agent_run",
            input_dict={"prompt": prompt_text[:2000]},
            message_preview=prompt_text[:200],
            pack_ids=pack_ids,
            extra_metadata={"promptPreview": prompt_text[:200]},
            source=source,
        )

    # Wrap async run()
    original_run = getattr(agent, "run", None)
    if original_run is not None and not getattr(original_run, "_connexum_governed", False):
        @wraps(original_run)
        async def governed_run(prompt: Any, *args: Any, **kwargs: Any) -> Any:
            body = _build_run_body(prompt, "agent.run")
            result = await _do_check_async(
                governance_server_url=governance_server_url,
                license_key=license_key,
                body=body,
                check_fn=_check_fn,
            )
            _enforce_decision_sync(result, "agent.run", raise_on_deny, "wrap_agent_run")
            return await original_run(prompt, *args, **kwargs)

        governed_run._connexum_governed = True
        agent.run = governed_run

    # Wrap sync run_sync()
    original_run_sync = getattr(agent, "run_sync", None)
    if original_run_sync is not None and not getattr(original_run_sync, "_connexum_governed", False):
        @wraps(original_run_sync)
        def governed_run_sync(prompt: Any, *args: Any, **kwargs: Any) -> Any:
            body = _build_run_body(prompt, "agent.run_sync")
            result = _do_check_sync(
                governance_server_url=governance_server_url,
                license_key=license_key,
                body=body,
                check_fn=_check_fn,
            )
            _enforce_decision_sync(
                result, "agent.run_sync", raise_on_deny, "wrap_agent_run"
            )
            return original_run_sync(prompt, *args, **kwargs)

        governed_run_sync._connexum_governed = True
        agent.run_sync = governed_run_sync

    # Wrap async generator run_stream()
    original_run_stream = getattr(agent, "run_stream", None)
    if original_run_stream is not None and not getattr(original_run_stream, "_connexum_governed", False):
        @wraps(original_run_stream)
        async def governed_run_stream(prompt: Any, *args: Any, **kwargs: Any):
            body = _build_run_body(prompt, "agent.run_stream")
            result = await _do_check_async(
                governance_server_url=governance_server_url,
                license_key=license_key,
                body=body,
                check_fn=_check_fn,
            )
            _enforce_decision_sync(
                result, "agent.run_stream", raise_on_deny, "wrap_agent_run"
            )
            async for chunk in original_run_stream(prompt, *args, **kwargs):
                # Per-chunk output scan (optional, lightweight)
                chunk_text = str(chunk) if not isinstance(chunk, str) else chunk
                if _contains_sensitive_data(chunk_text):
                    sys.stderr.write(
                        "[wrap_agent_run] sensitive data detected in stream chunk. "
                        "Consider output classification.\n"
                    )
                    # Log but yield -- halting a stream mid-flight is disruptive.
                    # Customers who need hard blocking on stream output should use
                    # GovernedAgentResult on the accumulated result.
                yield chunk

                # Emit a lightweight chunk audit event (best-effort, non-blocking)
                try:
                    await _do_check_async(
                        governance_server_url=governance_server_url,
                        license_key=license_key,
                        body=build_check_action_body(
                            tool_name="stream_chunk",
                            agent_name="pydantic-ai-stream",
                            framework_action="framework.pydantic_ai.stream_chunk",
                            input_dict={"chunk": chunk_text[:200]},
                            message_preview=chunk_text[:200],
                            pack_ids=pack_ids,
                            source="run_stream_chunk",
                        ),
                        check_fn=_check_fn,
                    )
                except Exception as _chunk_exc:
                    sys.stderr.write(
                        f"[wrap_agent_run] stream_chunk audit event failed: {_chunk_exc}\n"
                    )

        governed_run_stream._connexum_governed = True
        agent.run_stream = governed_run_stream

    agent._connexum_run_governed = True
    return agent


# ---------------------------------------------------------------------------
# GovernedAgentResult
#
# OUTPUT-SIDE enforcement. Wraps an agent result and scans Pydantic model
# fields for PII / PHI before returning to the caller.
# ---------------------------------------------------------------------------


class GovernedAgentResult:
    """
    Wraps a Pydantic AI agent result and runs output-side governance checks.

    Scans string fields in the result object for PII / PHI / credential
    patterns. If sensitive data is found, raises GovernanceViolation before
    the result is returned to the caller.

    This is OUTPUT-SIDE enforcement. The agent has already produced the result;
    this prevents it from being returned. For earlier blocking, use
    wrap_agent_run() (agent entry) and governed_tool_decorator() (tool dispatch).

    Usage:
        raw_result = await agent.run("Summarize patient records")
        safe_result = GovernedAgentResult(
            result=raw_result,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
        ).validate()

    Alternatively, use the factory:
        gov = create_governed_pydantic_ai(...)
        safe_result = gov.validate_result(raw_result)
    """

    def __init__(
        self,
        result: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        scan_for_sensitive_data: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        if not governance_server_url:
            raise ValueError(
                "[GovernedAgentResult] governance_server_url is required"
            )
        if not license_key:
            raise ValueError(
                "[GovernedAgentResult] license_key is required"
            )

        self._result = result
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._scan_for_sensitive_data = scan_for_sensitive_data
        self._check_fn = _check_fn

    def _extract_text(self) -> str:
        """Extract string representation of the result for scanning."""
        result = self._result
        if isinstance(result, str):
            return result
        if hasattr(result, "model_dump"):
            try:
                return json.dumps(result.model_dump())
            except Exception as exc:
                sys.stderr.write(
                    f"[GovernedAgentResult] model_dump serialization failed: {exc}\n"
                )
        if hasattr(result, "data"):
            data = result.data
            if isinstance(data, str):
                return data
            if hasattr(data, "model_dump"):
                try:
                    return json.dumps(data.model_dump())
                except Exception as exc:
                    sys.stderr.write(
                        f"[GovernedAgentResult] data.model_dump serialization failed: {exc}\n"
                    )
            return str(data)
        if isinstance(result, dict):
            try:
                return json.dumps(result)
            except Exception as exc:
                sys.stderr.write(
                    f"[GovernedAgentResult] dict serialization failed: {exc}\n"
                )
        return str(result)

    def validate(self) -> Any:
        """
        Synchronous validation. Scans result for sensitive data.

        Returns:
            The original result if validation passes.

        Raises:
            GovernanceViolation: If sensitive data is detected or governance
                server returns DENY.
        """
        result_text = self._extract_text()

        # PII / PHI scan
        if self._scan_for_sensitive_data and _contains_sensitive_data(result_text):
            reason = (
                "Agent result contains PII / PHI / credential patterns. "
                "Blocked by connexum-governance output classifier (G2/G3)."
            )
            sys.stderr.write(
                "[GovernedAgentResult] sensitive data detected in result. "
                "Raising GovernanceViolation.\n"
            )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                )
            return self._result

        # Governance server check
        check_result = _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name="result_validate",
                agent_name="pydantic-ai-result",
                framework_action="framework.pydantic_ai.result_validate",
                input_dict={"result": result_text[:2000]},
                message_preview=result_text[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"resultPreview": result_text[:200]},
                source="GovernedAgentResult.validate",
            ),
            check_fn=self._check_fn,
        )
        _enforce_decision_sync(
            check_result, "result_validate", self._raise_on_deny, "GovernedAgentResult"
        )
        return self._result

    async def validate_async(self) -> Any:
        """
        Async validation. Scans result for sensitive data.

        Returns:
            The original result if validation passes.

        Raises:
            GovernanceViolation: If sensitive data is detected or governance
                server returns DENY.
        """
        result_text = self._extract_text()

        if self._scan_for_sensitive_data and _contains_sensitive_data(result_text):
            reason = (
                "Agent result contains PII / PHI / credential patterns. "
                "Blocked by connexum-governance output classifier (G2/G3)."
            )
            sys.stderr.write(
                "[GovernedAgentResult] sensitive data detected in result. "
                "Raising GovernanceViolation.\n"
            )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                )
            return self._result

        check_result = await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name="result_validate",
                agent_name="pydantic-ai-result",
                framework_action="framework.pydantic_ai.result_validate",
                input_dict={"result": result_text[:2000]},
                message_preview=result_text[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"resultPreview": result_text[:200]},
                source="GovernedAgentResult.validate_async",
            ),
            check_fn=self._check_fn,
        )
        _enforce_decision_sync(
            check_result, "result_validate", self._raise_on_deny, "GovernedAgentResult"
        )
        return self._result


# ---------------------------------------------------------------------------
# wrap_agent
#
# Convenience helper combining wrap_agent_run + tool decorator replacement.
# ---------------------------------------------------------------------------


def wrap_agent(
    agent: Any,
    governance_server_url: Optional[str] = None,
    license_key: Optional[str] = None,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    injection_deny_threshold: str = "high",
    _check_fn: Optional[CheckFnType] = None,
    governance_client: Optional[Any] = None,
) -> Any:
    """
    Convenience helper that wraps a Pydantic AI Agent with governance.

    Applies three layers of governance to the agent:
    1. wrap_agent_run(): wraps run/run_sync/run_stream entry points.
    2. governed_tool_decorator(): replaces agent.tool for future tool registrations.
    3. governed_tool_plain_decorator(): replaces agent.tool_plain for plain tools.

    Idempotent: calling wrap_agent twice on the same agent is a no-op for the
    run methods (checked via _connexum_run_governed marker). Tool decorators
    are replaced each call -- call wrap_agent BEFORE registering tools.

    Args:
        agent: The Pydantic AI Agent instance to wrap.
        governance_client: GovernanceClient instance (preferred). Takes precedence
            over governance_server_url + license_key when supplied.
        governance_server_url: URL of the governance server (deprecated: use
            governance_client= instead).
        license_key: License / JWT key (deprecated: use governance_client= instead).
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        injection_deny_threshold: 'high' or 'medium' injection scan threshold.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        The same agent instance with governance applied.
    """
    # Resolve governance connection params once; pass resolved URL/key downstream.
    _resolved_url, _resolved_key = _resolve_governance_params(
        governance_client=governance_client,
        governance_server_url=governance_server_url,
        license_key=license_key,
    )

    common_kwargs = dict(
        governance_server_url=_resolved_url,
        license_key=_resolved_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )

    # Wrap run methods
    wrap_agent_run(
        agent=agent,
        injection_deny_threshold=injection_deny_threshold,
        **common_kwargs,
    )

    # Replace tool decorator if present
    if hasattr(agent, "tool"):
        agent.tool = governed_tool_decorator(agent=agent, **common_kwargs)

    # Replace tool_plain decorator if present
    if hasattr(agent, "tool_plain"):
        agent.tool_plain = governed_tool_plain_decorator(agent=agent, **common_kwargs)

    agent._connexum_governed = True
    return agent


# ---------------------------------------------------------------------------
# GovernedPydanticAIInstance -- namespace returned by factory
# ---------------------------------------------------------------------------


@dataclass
class GovernedPydanticAIInstance:
    """
    Governed Pydantic AI object returned by create_governed_pydantic_ai().

    Exposes all integration helpers for the Pydantic AI framework adapter.
    """

    _governance_server_url: str = field(repr=False)
    _license_key: str = field(repr=False)
    _pack_ids: list = field(default_factory=list, repr=False)
    _raise_on_deny: bool = field(default=True, repr=False)
    _injection_deny_threshold: str = field(default="high", repr=False)
    _check_fn: Optional[CheckFnType] = field(default=None, repr=False)

    def wrap_agent(self, agent: Any) -> Any:
        """
        Apply full governance to a Pydantic AI Agent.

        Wraps run/run_sync/run_stream and replaces tool/tool_plain decorators.
        Returns the same agent with governance applied (idempotent for runs).

        IMPORTANT: Call this BEFORE registering tools with @agent.tool so the
        tool decorator replacement is in effect before any tool registration.
        """
        return wrap_agent(
            agent=agent,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            injection_deny_threshold=self._injection_deny_threshold,
            _check_fn=self._check_fn,
        )

    def wrap_runs(self, agent: Any) -> Any:
        """
        Wrap only agent.run / run_sync / run_stream with governance.
        Does not replace tool decorators. Use wrap_agent() for full coverage.
        """
        return wrap_agent_run(
            agent=agent,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            injection_deny_threshold=self._injection_deny_threshold,
            _check_fn=self._check_fn,
        )

    def tool_decorator(self, agent: Any) -> Callable:
        """
        Return a governed replacement for agent.tool.

        Usage:
            agent.tool = gov.tool_decorator(agent)

            @agent.tool
            async def my_tool(ctx, query: str) -> str:
                ...
            # Governance runs before my_tool executes.
        """
        return governed_tool_decorator(
            agent=agent,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def tool_plain_decorator(self, agent: Any) -> Callable:
        """
        Return a governed replacement for agent.tool_plain.

        Usage:
            agent.tool_plain = gov.tool_plain_decorator(agent)

            @agent.tool_plain
            def calculate(x: int, y: int) -> int:
                return x + y
        """
        return governed_tool_plain_decorator(
            agent=agent,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def validate_result(self, result: Any, scan_for_sensitive_data: bool = True) -> Any:
        """
        Validate an agent result for PII/PHI and governance policy compliance.

        Runs the output-side classification synchronously. Raises
        GovernanceViolation if sensitive data or a DENY decision is found.

        Args:
            result: The raw agent result to validate.
            scan_for_sensitive_data: If True (default), scan for PII/PHI patterns.

        Returns:
            The original result if validation passes.
        """
        return GovernedAgentResult(
            result=result,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            scan_for_sensitive_data=scan_for_sensitive_data,
            _check_fn=self._check_fn,
        ).validate()

    async def validate_result_async(
        self, result: Any, scan_for_sensitive_data: bool = True
    ) -> Any:
        """
        Async variant of validate_result().
        """
        return await GovernedAgentResult(
            result=result,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            scan_for_sensitive_data=scan_for_sensitive_data,
            _check_fn=self._check_fn,
        ).validate_async()


# ---------------------------------------------------------------------------
# create_governed_pydantic_ai -- primary public factory
# ---------------------------------------------------------------------------


def create_governed_pydantic_ai(
    governance_server_url: Optional[str] = None,
    license_key: Optional[str] = None,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    injection_deny_threshold: str = "high",
    _check_fn: Optional[CheckFnType] = None,
    governance_client: Optional[Any] = None,
) -> GovernedPydanticAIInstance:
    """
    Primary factory for the Pydantic AI governance adapter.

    Returns a GovernedPydanticAIInstance exposing all integration helpers.

    Pydantic AI is a type-safe agent SDK with Pydantic validation throughout.
    Unlike LangChain (callback system) or OpenAI Agents SDK (guardrail protocol),
    Pydantic AI has no built-in observability or blocking hooks. This adapter
    works entirely through function wrapping:

    1. governed_tool_decorator: replaces @agent.tool so registered tools carry
       governance pre-checks from the point of definition.
    2. governed_tool_plain_decorator: same for @agent.tool_plain.
    3. wrap_agent_run: monkeypatches run/run_sync/run_stream for prompt injection
       scanning and governance check at the agent entry boundary.
    4. GovernedAgentResult: output-side PII/PHI classification.

    RECOMMENDED USAGE ORDER (with GovernanceClient, preferred):
        from connexum_governance import GovernanceClient
        from connexum_governance.integrations.pydantic_ai_integration import (
            create_governed_pydantic_ai,
        )

        client = GovernanceClient(api_url="http://localhost:3200", license_key=...)
        gov = create_governed_pydantic_ai(governance_client=client, pack_ids=["hipaa"])
        gov.wrap_agent(agent)          # wraps runs + replaces decorators
        @agent.tool                    # now governed (decorator replaced)
        async def my_tool(...):
            ...
        result = await agent.run(...)
        safe_result = gov.validate_result(result)

    DEPRECATED (standalone URL/key, backward compat preserved):
        gov = create_governed_pydantic_ai(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
        )

    Args:
        governance_client: GovernanceClient instance (preferred). Takes precedence
            over governance_server_url + license_key when supplied.
        governance_server_url: URL of the governance server (deprecated: use
            governance_client= instead). Will emit DeprecationWarning.
        license_key: License / JWT key (deprecated: use governance_client= instead).
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        injection_deny_threshold: 'high' (default) or 'medium' injection threshold.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        GovernedPydanticAIInstance with all integration helpers.

    CANONICAL TOOL-NAME WIRE FORM (IMPORTANT FOR PACK AUTHORS):
        Pydantic AI tools are sent to gov-server with
        toolName='tool.<name>' to preserve the framework's tool-namespace
        convention. Pack rules targeting bare tool names will not match;
        use prefix matching or include the 'tool.' prefix in your rule.

        Example: a tool registered as @agent.tool async def lookup_patient(...)
        is sent as toolName='tool.lookup_patient'. A pack rule that targets
        'lookup_patient' alone will NOT match. Target 'tool.lookup_patient'
        (exact) or use a 'tool.*' / 'tool.lookup_*' prefix matcher.

        This is a deliberate divergence from CrewAI / AutoGen / LangGraph
        post WS-05 ITEM 5 (DIVERGENCE-005 RESOLVED), which now also use the
        'tool.' prefix. The Pydantic AI adapter ALSO sends the action key
        as 'framework.pydantic_ai.tool_invoke' (DIVERGENCE-007 RESOLVED),
        so pack rules can target either surface.
    """
    resolved_url, resolved_key = _resolve_governance_params(
        governance_client=governance_client,
        governance_server_url=governance_server_url,
        license_key=license_key,
    )

    return GovernedPydanticAIInstance(
        _governance_server_url=resolved_url,
        _license_key=resolved_key,
        _pack_ids=pack_ids or [],
        _raise_on_deny=raise_on_deny,
        _injection_deny_threshold=injection_deny_threshold,
        _check_fn=_check_fn,
    )
