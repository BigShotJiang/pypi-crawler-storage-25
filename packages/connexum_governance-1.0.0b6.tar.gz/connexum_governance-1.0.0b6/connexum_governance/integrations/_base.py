"""Base classes for Connexum governance integrations.

Provides two base classes:

  GovernanceIntegrationBase -- postActionClassify() mixin for orchestrators.
    Used by CrewAI, LangChain, Google ADK, etc.

  BaseGovernanceIntegration -- emit_event() base for IDE/shell integrations.
    Extracted from the 10 IDE integrations (M2) to eliminate duplication.
    Provides: pack-binding primacy, agentEnd exemption, REST API dispatch,
    and pending-audit tracking. All 10 IDE integrations call super().emit_event().

C1 fix: G-series (nine-guard) classification was missing from orchestrator
tool outputs. GovernanceIntegrationBase wires the full classify_output() path
from GovernanceClient into every integration via a single shared method.

M2 fix: emit_event() duplicated 10 times with inconsistent agentEnd exemption.
BaseGovernanceIntegration now holds the canonical implementation.

Usage (IDE integration):
    class MyIdeGovernance(BaseGovernanceIntegration):
        _VALID_EVENT_TYPES = frozenset({...})
        _FRAMEWORK_NAME = "my-ide"
        _LAYER_NAME = "my-ide-rest-shim"

        def __init__(self, client, ...):
            super().__init__(client)
            ...

        def emit_event(self, event_type, payload):
            # Do integration-specific guard checks here
            ...
            # Then delegate pack-binding + REST dispatch to base
            return super().emit_event(event_type, payload)
"""

from __future__ import annotations

import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation


# ---------------------------------------------------------------------------
# GovernanceIntegrationBase (original -- orchestrator postActionClassify mixin)
# ---------------------------------------------------------------------------

class GovernanceIntegrationBase:
    """Mixin providing postActionClassify() for orchestrator integrations.

    Concrete integrations should call postActionClassify() at the end of
    every on_tool_end / postAction hook to ensure G-series classification
    (G1-G9 guards: unsafe content, secrets, PHI, exfiltration, etc.) runs
    on all tool outputs before they are returned to callers.

    C1 fix: without this call, a tool could return secrets, PHI, or
    policy-violating content that bypassed the nine-guard output classifier.
    """

    def __init__(self, client: GovernanceClient) -> None:
        self.client = client

    def postActionClassify(
        self,
        audit_id: str,
        output: dict[str, Any],
        agent_name: str,
        pack_binding: Optional[list[str]] = None,
    ) -> bool:
        """Run G-series classification on a tool output.

        Calls GovernanceClient.classify_output() to screen the output through
        the nine guards (G1-G9). Logs a warning to stderr if the output is
        flagged. Always returns a boolean indicating whether the output was
        classified as clean (True) or flagged (False).

        Non-fatal: classification failure (e.g. governance server unreachable)
        falls back to the client's on_failure setting (open or closed). This
        method never raises.

        Args:
            audit_id: The audit ID from the preceding check_action decision.
            output: The tool output payload to classify. Should be a dict;
                    string outputs should be wrapped: {"output": text}.
            agent_name: Name of the agent / tool for logging context.
            pack_binding: Optional pack binding context for classification.

        Returns:
            True if the output is classified as safe, False if guards triggered.
        """
        agent = AgentIdentity(name=agent_name)
        try:
            classified = self.client.classify_output(
                audit_id=audit_id,
                output=output,
                agent=agent,
            )
            if not classified.allowed:
                print(
                    f"[GOVERNANCE] G-series classification: tool output flagged "
                    f"(agent={agent_name}, audit={audit_id}). "
                    f"Guards triggered: {classified.guards_triggered}. "
                    "(C1: postActionClassify)",
                    file=sys.stderr,
                )
            return classified.allowed
        except Exception as exc:
            print(
                f"[GOVERNANCE] postActionClassify failed for agent={agent_name}, "
                f"audit={audit_id}: {exc}. Treating as clean per on_failure=open.",
                file=sys.stderr,
            )
            return True


# ---------------------------------------------------------------------------
# BaseGovernanceIntegration (M2 -- IDE/shell emit_event() base class)
# ---------------------------------------------------------------------------

class BaseGovernanceIntegration:
    """Base class for IDE and shell governance integrations.

    Extracted from the 10 duplicated emit_event() implementations (M2).
    Provides the canonical shared behavior:

      1. Pack-binding primacy: deny events with no packBinding unless the
         event type is in _EXEMPT_EVENT_TYPES (agentEnd is always exempt).
      2. REST API dispatch: calls client.check_action() with the tool name
         constructed as "{_FRAMEWORK_NAME}.{event_type}".
      3. Pending-audit tracking: correlates toolCall/llmCall audit IDs with
         their corresponding toolResult/llmResult for report_result().

    Subclasses MUST define:
      _VALID_EVENT_TYPES: frozenset[str]  -- set of accepted event type strings.
      _FRAMEWORK_NAME: str               -- used as tool name prefix in REST calls.
      _LAYER_NAME: str                   -- layer label in event payload metadata.

    Subclasses SHOULD override emit_event() to run integration-specific guard
    checks (PHI scan, provider compliance, destructive command guard, etc.)
    and then call super().emit_event(event_type, payload) to dispatch.

    The base emit_event() does NOT re-validate event_type -- subclasses should
    validate before calling super(). Subclasses may extend _EXEMPT_EVENT_TYPES
    to add integration-specific exempt events (e.g. "memoryRead" for openclaw).
    """

    # Subclasses must override these.
    _VALID_EVENT_TYPES: frozenset[str] = frozenset({
        "agentStart",
        "toolCall",
        "toolResult",
        "llmCall",
        "llmResult",
        "agentEnd",
    })
    _FRAMEWORK_NAME: str = "governance"
    _LAYER_NAME: str = "governance-rest-shim"

    # agentEnd is always exempt from pack-binding primacy (lifecycle close event).
    # Subclasses may extend this set for additional integration-specific exemptions.
    _EXEMPT_EVENT_TYPES: frozenset[str] = frozenset({"agentEnd"})

    def __init__(self, client: GovernanceClient) -> None:
        self.client = client
        # Correlates toolCall/llmCall audit IDs with subsequent result events.
        self._pending_audits: dict[str, str] = {}

    def _is_exempt_event(self, event_type: str) -> bool:
        """Return True if event_type is exempt from pack-binding primacy.

        agentEnd is always exempt -- it is a lifecycle close event that fires
        after the agent's compliance context may already be torn down.
        Subclasses may override or extend _EXEMPT_EVENT_TYPES.
        """
        return event_type in self._EXEMPT_EVENT_TYPES

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API.

        Shared base behavior (M2):
          1. Pack-binding primacy check (exempt: agentEnd + _EXEMPT_EVENT_TYPES).
          2. Dispatch to client.check_action() with tool={framework}.{event_type}.
          3. Track pending audit IDs for toolCall/llmCall -> result correlation.
          4. Call report_result() on toolResult/llmResult.

        Subclasses run integration-specific guards BEFORE calling super(). The
        base does not re-validate event_type -- subclasses must validate first.

        Args:
            event_type: Canonical event type (already validated by caller).
            payload: Event-specific payload. Must include "agentId".

        Returns:
            GovernanceDecision from the governance API.
        """
        agent_id = payload.get("agentId", "unknown")
        pack_binding: list[str] = payload.get("packBinding", [])

        # Pack-binding primacy: deny unless exempt event (agentEnd etc.)
        if not pack_binding and not self._is_exempt_event(event_type):
            from connexum_governance.models import DecisionType
            reason = (
                f'{self._FRAMEWORK_NAME} event "{event_type}" for agent '
                f'"{agent_id}" carries no pack binding. '
                "Pack-binding primacy: every event MUST carry packBinding."
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        # Dispatch to governance REST API
        agent = AgentIdentity(name=agent_id)
        decision = self.client.check_action(
            tool=f"{self._FRAMEWORK_NAME}.{event_type}",
            input={
                "eventType": event_type,
                "framework": self._FRAMEWORK_NAME,
                "layer": self._LAYER_NAME,
                **payload,
            },
            agent=agent,
        )

        # Track pending audit IDs for toolCall/llmCall -> result correlation
        if event_type in ("toolCall", "llmCall") and decision.audit_id:
            self._pending_audits[f"{event_type}:{agent_id}"] = decision.audit_id

        # Correlate result event to preceding call for report_result()
        if event_type in ("toolResult", "llmResult"):
            audit_key = (
                f"{'toolCall' if event_type == 'toolResult' else 'llmCall'}:{agent_id}"
            )
            audit_id = self._pending_audits.pop(audit_key, None)
            if audit_id:
                try:
                    self.client.report_result(
                        audit_id=audit_id,
                        success=payload.get("success", True),
                        summary=str(
                            payload.get("result", payload.get("responseText", ""))
                        )[:200],
                    )
                except Exception as exc:  # H2: never swallow -- always log
                    import logging as _logging
                    _logging.getLogger(__name__).warning(
                        "Governance audit operation failed: %s", exc
                    )

        return decision
