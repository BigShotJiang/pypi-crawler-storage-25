"""Claude Code IDE governance integration.

Claude Code is shell-invoked -- it has no Python SDK. This integration is a
REST-client shim that a Python-hosted governance policy can use from a Claude
Code hook script. The hook script shells out to a Python process (or calls this
module directly), receives a `{continue: bool, reason: str}` response, and
exits 0 (allow) or 2 (deny) accordingly.

Architecture:
  Claude Code fires PreToolUse / PostToolUse hooks as JSON payloads written to
  stdin (or via environment). The Python shim:
    1. Accepts the raw hook payload via intercept_hook()
    2. Runs local guard checks (destructive commands, sensitive paths, PHI scan)
    3. Forwards a canonical event to the governance REST API
    4. Returns `{continue: bool, reason: str}` in the format Claude Code expects

Canonical event shape:
  agentStart -> {"eventType": "agentStart",  "agentId": ..., "packBinding": [...]}
  toolCall   -> {"eventType": "toolCall",    "agentId": ..., "toolName": ..., ...}
  toolResult -> {"eventType": "toolResult",  "agentId": ..., "toolName": ..., ...}
  llmCall    -> {"eventType": "llmCall",     "agentId": ..., "model": ..., ...}
  llmResult  -> {"eventType": "llmResult",   "agentId": ..., "model": ..., ...}
  agentEnd   -> {"eventType": "agentEnd",    "agentId": ..., "success": ..., ...}

Provider compliance note:
  Claude Code uses Anthropic as its LLM backend. The approved_models list
  should reference Claude model IDs (e.g. "claude-haiku-4-5", "claude-sonnet-4-6").

Usage (from a Claude Code hook script):
    import json, sys
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.claude_code import ClaudeCodeGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = ClaudeCodeGovernance(
        client=gov,
        agent_name="my-claude-agent",
        pack_binding=["hipaa"],
        approved_models=["claude-haiku-4-5", "claude-sonnet-4-6"],
    )

    hook_payload = json.loads(sys.stdin.read())
    result = adapter.intercept_hook("PreToolUse", hook_payload)
    if not result["continue"]:
        sys.exit(2)   # Claude Code interprets exit 2 as a block
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Dict, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Destructive command patterns (G4 guard equivalent)
# ---------------------------------------------------------------------------

_DESTRUCTIVE_COMMAND_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("rm-rf",           re.compile(r"\brm\s+(-[rR]f?|--recursive)\b")),
    ("git-push-force",  re.compile(r"\bgit\s+push\s+--force\b")),
    ("git-reset-hard",  re.compile(r"\bgit\s+reset\s+--hard\b")),
    ("git-clean-f",     re.compile(r"\bgit\s+clean\s+-f")),
    ("drop-table",      re.compile(r"\bdrop\s+(table|database)\b", re.IGNORECASE)),
    ("truncate-table",  re.compile(r"\btruncate\s+table\b", re.IGNORECASE)),
    ("npm-publish",     re.compile(r"\bnpm\s+publish\b")),
    ("curl-pipe-shell", re.compile(r"\bcurl\b.*\|\s*(bash|sh)\b")),
    ("dd-if",           re.compile(r"\bdd\s+if=")),
    ("chmod-777",       re.compile(r"\bchmod\s+777\b")),
    ("sudo-rm",         re.compile(r"\bsudo\s+rm\b")),
]

# ---------------------------------------------------------------------------
# Sensitive path patterns (G5 guard equivalent)
# ---------------------------------------------------------------------------

_SENSITIVE_PATH_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("etc-dir",      re.compile(r"^/etc/")),
    ("root-dir",     re.compile(r"^/root/")),
    ("dotenv",       re.compile(r"^/?\.env$")),
    ("dotenv-ext",   re.compile(r"\.env\.")),
    ("proc-dir",     re.compile(r"^/proc/")),
    ("sys-dir",      re.compile(r"^/sys/")),
    ("secrets-dir",  re.compile(r"secrets?/", re.IGNORECASE)),
    ("private-key",  re.compile(r"private_?key", re.IGNORECASE)),
    ("pem-file",     re.compile(r"\.pem$", re.IGNORECASE)),
    ("key-file",     re.compile(r"\.key$", re.IGNORECASE)),
]

# ---------------------------------------------------------------------------
# PHI detection
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


# ---------------------------------------------------------------------------
# Canonical event type set
# ---------------------------------------------------------------------------

_VALID_HOOK_NAMES = frozenset({
    "PreToolUse",
    "PostToolUse",
    "PreLlmCall",
    "PostLlmCall",
    "Stop",
    "SubagentStop",
})

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})

# Tools that receive Bash / terminal payloads
_BASH_TOOLS = frozenset({"Bash", "run_terminal", "run_command", "execute", "bash", "shell"})
# Tools that receive file paths
_FILE_TOOLS = frozenset({"Edit", "Write", "Read", "Glob"})


# ---------------------------------------------------------------------------
# ClaudeCodeGovernance
# ---------------------------------------------------------------------------

class ClaudeCodeGovernance(BaseGovernanceIntegration):
    """REST-client shim for Claude Code governance.

    Claude Code uses a hook script (PreToolUse / PostToolUse / etc.) that this
    Python module bridges to the governance REST API. Returns
    `{continue: bool, reason: str}` for hook scripts to act on.

    Provider: Anthropic (Claude models only). The approved_models list must
    contain Claude model IDs.
    """

    PROVIDER = "anthropic"
    _FRAMEWORK_NAME = "claude-code"
    _LAYER_NAME = "claude-code-hook-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        approved_models: Optional[list[str]] = None,
        sensitive_tools: Optional[list[str]] = None,
        sensitive_arg_keys: Optional[list[str]] = None,
        allow_destructive_commands: bool = False,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: The Claude Code agent name (shown in audit logs).
            agent_role: Optional role for richer attribution.
            pack_binding: Compliance packs governing this agent.
            approved_models: Claude model IDs approved for use.
            sensitive_tools: Tool names that require explicit approval.
            sensitive_arg_keys: Argument keys to scan for PHI.
            allow_destructive_commands: Set True to disable destructive-command
                                        denial (NOT recommended for production).
        """
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.approved_models = approved_models or []
        self.sensitive_tools = sensitive_tools or []
        self.sensitive_arg_keys = sensitive_arg_keys or [
            "command", "content", "body", "message", "query",
        ]
        self.allow_destructive_commands = allow_destructive_commands

    # ------------------------------------------------------------------
    # intercept_hook -- primary entry point from a Claude Code hook script
    # ------------------------------------------------------------------

    def intercept_hook(
        self,
        hook_name: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Process a Claude Code hook payload and return a hook response.

        Claude Code hook scripts:
          - Exit 0: permit the action
          - Exit 2: block the action (Claude Code reads the reason from stdout)

        This method returns `{"continue": bool, "reason": str}`.
        The caller uses `result["continue"]` to decide which exit code to use.

        Hook name to canonical event mapping:
          PreToolUse  -> toolCall (guard before the tool fires)
          PostToolUse -> toolResult (classify the output)
          PreLlmCall  -> llmCall
          PostLlmCall -> llmResult
          Stop        -> agentEnd
          SubagentStop-> agentEnd

        Args:
            hook_name: Claude Code hook name ("PreToolUse", "PostToolUse", etc.)
            payload: Parsed JSON payload from Claude Code hook stdin.

        Returns:
            dict with keys "continue" (bool) and "reason" (str).
        """
        if hook_name not in _VALID_HOOK_NAMES:
            return {
                "continue": False,
                "reason": (
                    f'ClaudeCodeGovernance: unknown hook name "{hook_name}". '
                    f"Valid hooks: {sorted(_VALID_HOOK_NAMES)}"
                ),
            }

        tool_name = payload.get("tool_name", payload.get("toolName", ""))
        tool_input = payload.get("tool_input", payload.get("input", {}))
        model = payload.get("model", "")

        if hook_name == "PreToolUse":
            decision = self._pre_tool_use(tool_name, tool_input)
        elif hook_name == "PostToolUse":
            decision = self._post_tool_use(tool_name, payload)
        elif hook_name == "PreLlmCall":
            decision = self._llm_call(model, payload)
        elif hook_name == "PostLlmCall":
            decision = self._llm_result(model, payload)
        elif hook_name in ("Stop", "SubagentStop"):
            decision = self.emit_event("agentEnd", {
                "agentId": self.agent_name,
                "success": payload.get("success", True),
                "packBinding": self.pack_binding,
            })
        else:
            decision = self.emit_event("agentStart", {
                "agentId": self.agent_name,
                "packBinding": self.pack_binding,
            })

        return {
            "continue": decision.allowed,
            "reason": decision.reason,
        }

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API.

        Args:
            event_type: Canonical event type (agentStart, toolCall, etc.)
            payload: Event payload. Must include "agentId".

        Returns:
            GovernanceDecision from the governance API.
        """
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown ClaudeCode event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)
        pack_binding: list[str] = payload.get("packBinding", self.pack_binding)
        # Normalise: ensure payload carries the resolved pack_binding for super()
        payload = {**payload, "agentId": agent_id, "packBinding": pack_binding}

        # Provider compliance: Claude Code uses Anthropic exclusively
        if event_type == "llmCall":
            model = payload.get("model", "")
            if self.approved_models and model and model not in self.approved_models:
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f'ClaudeCode LLM model "{model}" is not on the approved model list. '
                    f"Approved: {', '.join(self.approved_models)}. "
                    "Claude Code uses Anthropic models exclusively."
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # PHI scan on tool call args (G5/G7 egress guard)
        if event_type == "toolCall":
            args = payload.get("args", {})
            for key in self.sensitive_arg_keys:
                value = args.get(key)
                if isinstance(value, str) and _contains_phi(value):
                    from connexum_governance.models import GovernanceDecision, DecisionType
                    tool_name_str = payload.get("toolName", "unknown")
                    reason = (
                        f'Possible PHI detected in tool "{tool_name_str}" argument "{key}". '
                        "Blocked at ClaudeCode pre-tool ingress guard."
                    )
                    d = GovernanceDecision(
                        decision=DecisionType.DENY,
                        reason=reason,
                        audit_id=str(uuid.uuid4()),
                    )
                    if self.client.enforce:
                        raise GovernanceViolation(d)
                    return d

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _contains_phi(result_text):
                print(
                    f"[GOVERNANCE] ClaudeCode output classifier: possible PHI in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _contains_phi(response_text):
                print(
                    f"[GOVERNANCE] ClaudeCode output exfiltration scanner: possible PHI in "
                    f'LLM response (model: {payload.get("model", "unknown")}, agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Inject provider metadata before base class REST dispatch
        enriched = {**payload, "provider": self.PROVIDER}
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # wrap_webhook -- accept JSON from a server-side webhook handler
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a governance event JSON payload and forward it.

        Useful when Claude Code hooks are forwarded to a Python server via HTTP.

        Args:
            request_body: Parsed JSON body with "eventType" and "agentId".

        Returns:
            GovernanceDecision.
        """
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError("ClaudeCode webhook payload missing required field: 'eventType'")
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError("ClaudeCode webhook payload missing required field: 'agentId'")
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "ClaudeCodePolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return ClaudeCodePolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private: PreToolUse guard
    # ------------------------------------------------------------------

    def _pre_tool_use(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a PreToolUse hook: destructive commands, sensitive paths, PHI."""
        # 1. Destructive command guard (G4)
        if not self.allow_destructive_commands and tool_name in _BASH_TOOLS:
            command = str(tool_input.get("command", ""))
            for pattern_name, pattern in _DESTRUCTIVE_COMMAND_PATTERNS:
                if pattern.search(command):
                    from connexum_governance.models import GovernanceDecision, DecisionType
                    reason = (
                        f'Destructive command blocked by ClaudeCodeGovernance (pattern: {pattern_name}). '
                        "This command cannot be reversed without a recovery procedure. "
                        "Remove it from the tool call or set allow_destructive_commands=True."
                    )
                    d = GovernanceDecision(
                        decision=DecisionType.DENY,
                        reason=reason,
                        audit_id=str(uuid.uuid4()),
                    )
                    if self.client.enforce:
                        raise GovernanceViolation(d)
                    return d

        # 2. Sensitive path guard (G5)
        if tool_name in _FILE_TOOLS:
            file_path = str(
                tool_input.get("file_path", tool_input.get("path", ""))
            )
            if file_path:
                for pattern_name, pattern in _SENSITIVE_PATH_PATTERNS:
                    if pattern.search(file_path):
                        from connexum_governance.models import GovernanceDecision, DecisionType
                        reason = (
                            f'Sensitive path blocked by ClaudeCodeGovernance '
                            f'(pattern: {pattern_name}): {file_path}'
                        )
                        d = GovernanceDecision(
                            decision=DecisionType.DENY,
                            reason=reason,
                            audit_id=str(uuid.uuid4()),
                        )
                        if self.client.enforce:
                            raise GovernanceViolation(d)
                        return d

        # 3. PHI scan on sensitive arg keys
        for key in self.sensitive_arg_keys:
            value = tool_input.get(key)
            if isinstance(value, str) and _contains_phi(value):
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f'Possible PHI detected in tool "{tool_name}" argument "{key}". '
                    "Blocked at ClaudeCode pre-tool ingress guard."
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        return self.emit_event("toolCall", {
            "agentId": self.agent_name,
            "toolName": tool_name,
            "args": tool_input,
            "packBinding": self.pack_binding,
        })

    def _post_tool_use(
        self,
        tool_name: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a PostToolUse hook: output classifier."""
        result_text = str(payload.get("tool_response", payload.get("result", "")))
        if _contains_phi(result_text):
            print(
                f"[GOVERNANCE] ClaudeCode output classifier: possible PHI in "
                f'tool result "{tool_name}" (agent: {self.agent_name}).',
                file=sys.stderr,
            )
        return self.emit_event("toolResult", {
            "agentId": self.agent_name,
            "toolName": tool_name,
            "result": result_text,
            "success": payload.get("success", True),
            "packBinding": self.pack_binding,
        })

    def _llm_call(
        self, model: str, payload: dict[str, Any]
    ) -> GovernanceDecision:
        return self.emit_event("llmCall", {
            "agentId": self.agent_name,
            "model": model,
            "messageCount": payload.get("message_count", 0),
            "packBinding": self.pack_binding,
        })

    def _llm_result(
        self, model: str, payload: dict[str, Any]
    ) -> GovernanceDecision:
        response_text = str(payload.get("response", payload.get("responseText", "")))
        if _contains_phi(response_text):
            print(
                f"[GOVERNANCE] ClaudeCode output exfiltration scanner: possible PHI in "
                f'LLM response (model: {model}, agent: {self.agent_name}).',
                file=sys.stderr,
            )
        return self.emit_event("llmResult", {
            "agentId": self.agent_name,
            "model": model,
            "responseText": response_text,
            "packBinding": self.pack_binding,
        })


# ---------------------------------------------------------------------------
# ClaudeCodePolicyBridge
# ---------------------------------------------------------------------------

class ClaudeCodePolicyBridge:
    """Bridge for Python-hosted policy participation in the Claude Code hook loop."""

    def __init__(
        self,
        adapter: ClaudeCodeGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
