"""Replit Agent governance integration.

Replit is a browser-based IDE with full sandbox execution. The Replit Agent
operates INSIDE the Repl environment: it can plan and execute tasks, run code,
manipulate files, install packages, deploy to Replit Deployments, access Replit
Secrets, and query databases -- all autonomously.

Replit's user base is the most diverse in the Connexum catalogue: students,
hobbyists, indie developers, small teams, and early-stage startups. This
diversity creates governance challenges unique to Replit:
  - Minor / student users require extra protection (COPPA, FERPA concerns).
  - High-volume signup means credentials are frequently mishandled.
  - Supply-chain risk is elevated: students copy-paste package installs.
  - Replit Deployments push directly to production without a separate CI/CD
    layer -- the governance gate IS the last line of defense.

Architecture:
  The primary adapter is TypeScript-native (src/ide-adapters/replit-agent.ts).
  This Python shim lets a Python-hosted governance policy server participate
  in the Replit decision loop via HTTP.

  Eight distinct governable surfaces (parity with TS adapter):
    intercept_agent_task(request)              -- high-level task gate (REQUIRES description)
    intercept_sandbox_code_execution(request)  -- code execution gate (egress scan)
    intercept_file_system_mutation(request)    -- file mutation gate (blast-radius cap)
    intercept_package_install(request)         -- package install gate (supply-chain)
    intercept_deployment(request)              -- deployment gate (CRITICAL)
    intercept_secret_access(request)           -- secrets manager gate (HIGH SENSITIVITY)
    intercept_database_query(request)          -- database query gate (destructive SQL)
    intercept_chat(request)                    -- chat request gate (secret + PHI scan)

  Deployment modes:
    replit-cloud        -- Replit-managed SaaS (default). Individual Repls.
    replit-teams        -- Replit Teams (Education or business org). Multi-user.
    replit-deployments  -- Replit Deployments (production-facing). The only mode
                          where deployment is permitted by default.

  Minor / student safeguards (the Replit-distinct differentiators):
    user_is_minor=True OR user_tier='student' triggers strict defaults:
      - deployment: ALWAYS DENIED for minor; DENIED for student
      - secret access: ALWAYS DENIED for minor; default-deny for non-minor
      - package install: DENIED when user_is_minor=True AND user_tier='student'

  Task gate:
    REQUIRES a non-empty task_description. Denied with reason code
    replit-agent-task-description-required otherwise.

  Deployment gate:
    Minor: ALWAYS DENIED (replit-deployment-not-permitted-minor).
    Student tier: ALWAYS DENIED (replit-deployment-not-permitted-student).
    Non-deployments mode without allow_deployment=True: DENIED.

  Secret access gate:
    Minor: ALWAYS DENIED (replit-secret-access-not-permitted).
    allow_secret_access not set: DENIED (governance default-deny).

  Package install gate:
    minor + student: DENIED (replit-package-install-not-permitted-minor-student).
    package_install_allow_list configured: only listed packages allowed.
    Typosquat heuristics: long names or suspicious punctuation flagged.

  File system mutation blast-radius cap:
    files[] count > multi_file_edit_cap (default 25) = DENIED.

  Pen-test IDs (mirrored from TS adapter):
    PT-ADAPT-REPLIT-1: empty pack_binding denied (pack-binding primacy)
    PT-ADAPT-REPLIT-2: Replit auth token never appears in audit entries
    PT-ADAPT-REPLIT-3: invalid deployment_mode raises ValueError at init;
                       negative multi_file_edit_cap raises ValueError;
                       user_is_minor=True + user_tier='admin' raises ValueError
    PT-ADAPT-REPLIT-4: minor + deployment attempt always denied with
                       replit-deployment-not-permitted-minor
    PT-ADAPT-REPLIT-5: minor + secret access always denied with
                       replit-secret-access-not-permitted
    PT-ADAPT-REPLIT-6: package install allowList enforcement audit entry
                       contains the offending package name (sanitized)

BAA-eligible deployment modes:
  replit-teams (enterprise Teams for Education BAA)
  replit-deployments (Replit business account BAA)

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.replit_agent import ReplitAgentGovernedClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = ReplitAgentGovernedClient(
        client=gov,
        agent_name="replit-agent-01",
        pack_binding=["soc2"],
        deployment_mode="replit-deployments",
        user_tier="team-member",
        allow_secret_access=True,
    )

    # Gate a high-level agent task (description required):
    decision = adapter.intercept_agent_task({
        "taskDescription": "Build a Flask REST API with auth",
        "packBinding": ["soc2"],
    })

    # Gate a deployment (only allowed in replit-deployments mode for non-minor):
    decision = adapter.intercept_deployment({
        "target": "production",
        "branch": "main",
        "packBinding": ["soc2"],
    })

    # Gate secret access (default-deny, minor always blocked):
    decision = adapter.intercept_secret_access({
        "secretName": "DATABASE_URL",
        "packBinding": ["hipaa"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Deployment modes
# ---------------------------------------------------------------------------

REPLIT_VALID_DEPLOYMENT_MODES: tuple[str, ...] = (
    "replit-cloud",
    "replit-teams",
    "replit-deployments",
)

REPLIT_BAA_ELIGIBLE_MODES: tuple[str, ...] = (
    "replit-teams",
    "replit-deployments",
)

# ---------------------------------------------------------------------------
# User tiers
# ---------------------------------------------------------------------------

REPLIT_VALID_USER_TIERS: tuple[str, ...] = (
    "student",
    "individual",
    "team-member",
    "admin",
)

# ---------------------------------------------------------------------------
# Typosquat heuristics (supply-chain guard)
# ---------------------------------------------------------------------------

_TYPOSQUAT_MAX_NAME_LENGTH = 40
_TYPOSQUAT_SUSPICIOUS_PUNCTUATION = re.compile(r"[_\-]{3,}|[0-9]{5,}|\.\.")


def _is_typosquat_suspicious(package_name: str) -> bool:
    """Return True if the package name exhibits typosquatting heuristics."""
    if not package_name:
        return False
    if len(package_name) > _TYPOSQUAT_MAX_NAME_LENGTH:
        return True
    if _TYPOSQUAT_SUSPICIOUS_PUNCTUATION.search(package_name):
        return True
    return False


# ---------------------------------------------------------------------------
# Network egress patterns (sandbox guard)
# ---------------------------------------------------------------------------

_SANDBOX_EGRESS_PATTERNS: list[re.Pattern] = [
    re.compile(r"\bfetch\s*\("),
    re.compile(r"\burllib\.request\b"),
    re.compile(r"\bhttp\.get\s*\("),
    re.compile(r"\bhttp\.request\s*\("),
    re.compile(r"\bhttps\.get\s*\("),
    re.compile(r"\bhttps\.request\s*\("),
    re.compile(r"\bnew\s+WebSocket\s*\("),
    re.compile(r"\bsocket\.connect\s*\("),
    re.compile(r"\brequests\.get\s*\("),
    re.compile(r"\brequests\.post\s*\("),
    re.compile(r"\baiohttp\b"),
    re.compile(r"\bhttpx\b"),
    re.compile(r"\baxios\s*\."),
]


def _detect_sandbox_egress(code: str) -> Optional[str]:
    """Return the pattern string of the first matched egress pattern, or None."""
    if not code:
        return None
    for pattern in _SANDBOX_EGRESS_PATTERNS:
        if pattern.search(code):
            return pattern.pattern
    return None


# ---------------------------------------------------------------------------
# Secret patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",            re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",                re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",         re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",            re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",        re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",    re.compile(
        r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
    ("Bearer token",              re.compile(
        r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}",
        re.IGNORECASE,
    )),
    ("Database URL with creds",   re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    # PT-ADAPT-REPLIT-2: Replit auth tokens must never appear in audit entries.
    ("Replit auth token",         re.compile(
        r"replit[_\-]?(auth|token|key|secret)\s*[:=]\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
    ("Replit session cookie",     re.compile(
        r"connect\.sid\s*[:=]\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Destructive SQL patterns
# ---------------------------------------------------------------------------

_DESTRUCTIVE_SQL_PATTERNS: list[re.Pattern] = [
    re.compile(r"\bDROP\s+(TABLE|DATABASE|SCHEMA)\b", re.IGNORECASE),
    re.compile(r"\bTRUNCATE\s+TABLE\b", re.IGNORECASE),
    re.compile(r"\bDELETE\s+FROM\b(?!\s+WHERE\b)", re.IGNORECASE),
    re.compile(r"\bDROP\s+ALL\s+TABLES\b", re.IGNORECASE),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Guard helpers
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    """Return the name of the first matched secret pattern, or None."""
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_for_phi(text: str) -> Optional[str]:
    """Return the pattern string of the first PHI indicator match, or None."""
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _detect_destructive_sql(query: str) -> Optional[str]:
    """Return the pattern string of the first destructive SQL match, or None."""
    if not query:
        return None
    for pattern in _DESTRUCTIVE_SQL_PATTERNS:
        if pattern.search(query):
            return pattern.pattern
    return None


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(
        p.lower() in ("hipaa", "hitech", "hipaa-hitech")
        for p in pack_binding
    )


# ---------------------------------------------------------------------------
# ReplitAgentGovernedClient
# ---------------------------------------------------------------------------

class ReplitAgentGovernedClient(BaseGovernanceIntegration):
    """REST-client shim for Replit Agent governance.

    Replit is a browser-based IDE with a uniquely diverse user base. This
    Python shim participates in the governance decision loop by governing all
    eight Replit Agent hook surfaces, with special safeguards for minor and
    student users.

    Eight distinct governable surfaces (parity with TS adapter):
      1. Agent task (intercept_agent_task) -- REQUIRES description
      2. Sandbox code execution (intercept_sandbox_code_execution)
      3. File system mutation (intercept_file_system_mutation)
      4. Package install (intercept_package_install) -- supply-chain gate
      5. Deployment (intercept_deployment) -- CRITICAL; minor/student blocked
      6. Secret access (intercept_secret_access) -- default-deny; minor blocked
      7. Database query (intercept_database_query) -- destructive SQL gate
      8. Chat (intercept_chat) -- secret + PHI scan
    """

    _VALID_EVENT_TYPES = _VALID_EVENT_TYPES
    _FRAMEWORK_NAME = "replit-agent"
    _LAYER_NAME = "replit-agent-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        pack_binding: list[str],
        deployment_mode: str,
        user_tier: str = "individual",
        user_is_minor: bool = False,
        allow_deployment: Optional[bool] = None,
        allow_secret_access: bool = False,
        allow_package_install: bool = True,
        package_install_allow_list: Optional[list[str]] = None,
        sandbox_resource_cap: Optional[dict[str, Any]] = None,
        multi_file_edit_cap: int = 25,
    ) -> None:
        """Create a ReplitAgentGovernedClient.

        Args:
            client: GovernanceClient REST connection.
            agent_name: Agent identifier for audit attribution.
            pack_binding: Compliance packs that govern this agent.
            deployment_mode: One of 'replit-cloud', 'replit-teams',
                             'replit-deployments'. Required.
            user_tier: 'student', 'individual', 'team-member', or 'admin'.
            user_is_minor: True activates minor safeguards (COPPA/FERPA).
                           Incompatible with user_tier='admin'.
            allow_deployment: Explicit opt-in for deployment. Default: True only
                              for 'replit-deployments' mode; False otherwise.
                              Ignored (denied) when user_is_minor=True.
            allow_secret_access: Explicit opt-in for Replit Secrets. Default: False.
                                 Denied unconditionally when user_is_minor=True.
            allow_package_install: Allow package installation. Default: True.
                                   Denied for minor + student combo.
            package_install_allow_list: When set, restricts installs to only
                                        listed package names.
            sandbox_resource_cap: Advisory CPU/memory caps for sandbox execution.
            multi_file_edit_cap: Maximum files per file-system mutation. Default: 25.

        Raises:
            ValueError: If deployment_mode is invalid, user_tier is invalid,
                        user_is_minor=True with user_tier='admin', or
                        multi_file_edit_cap < 1.
        """
        super().__init__(client)

        # PT-ADAPT-REPLIT-3: validate deployment_mode at construction time.
        if deployment_mode not in REPLIT_VALID_DEPLOYMENT_MODES:
            raise ValueError(
                f"ReplitAgentGovernedClient: invalid deployment_mode '{deployment_mode}'. "
                f"Must be one of: {', '.join(REPLIT_VALID_DEPLOYMENT_MODES)}. "
                "Deployment mode is required to determine deployment permission and "
                "educational-safeguard defaults."
            )

        # Validate user_tier.
        if user_tier not in REPLIT_VALID_USER_TIERS:
            raise ValueError(
                f"ReplitAgentGovernedClient: invalid user_tier '{user_tier}'. "
                f"Must be one of: {', '.join(REPLIT_VALID_USER_TIERS)}."
            )

        # PT-ADAPT-REPLIT-3: user_is_minor + user_tier='admin' is a logical inconsistency.
        if user_is_minor and user_tier == "admin":
            raise ValueError(
                "ReplitAgentGovernedClient: conflicting configuration -- "
                "user_is_minor=True is incompatible with user_tier='admin'. "
                "A minor user cannot hold admin privileges."
            )

        # PT-ADAPT-REPLIT-3: multi_file_edit_cap must be a positive integer.
        if multi_file_edit_cap < 1:
            raise ValueError(
                f"ReplitAgentGovernedClient: multi_file_edit_cap must be >= 1. "
                f"Received: {multi_file_edit_cap}."
            )

        # Validate sandbox_resource_cap values if provided.
        if sandbox_resource_cap is not None:
            if "maxCpuSeconds" in sandbox_resource_cap:
                val = sandbox_resource_cap["maxCpuSeconds"]
                if val is not None and val < 0:
                    raise ValueError(
                        f"ReplitAgentGovernedClient: sandbox_resource_cap.maxCpuSeconds "
                        f"must be >= 0. Received: {val}."
                    )
            if "maxMemoryMb" in sandbox_resource_cap:
                val = sandbox_resource_cap["maxMemoryMb"]
                if val is not None and val < 0:
                    raise ValueError(
                        f"ReplitAgentGovernedClient: sandbox_resource_cap.maxMemoryMb "
                        f"must be >= 0. Received: {val}."
                    )

        self.agent_name = agent_name
        self.pack_binding = pack_binding
        self.deployment_mode = deployment_mode
        self.user_tier = user_tier
        self.user_is_minor = user_is_minor
        # Resolve allow_deployment default: only True by default in replit-deployments mode.
        if allow_deployment is None:
            self.allow_deployment = deployment_mode == "replit-deployments"
        else:
            self.allow_deployment = allow_deployment
        self.allow_secret_access = allow_secret_access
        self.allow_package_install = allow_package_install
        self.package_install_allow_list = package_install_allow_list
        self.sandbox_resource_cap = sandbox_resource_cap or {}
        self.multi_file_edit_cap = multi_file_edit_cap

    # ------------------------------------------------------------------
    # intercept_agent_task -- high-level task gate (REQUIRES description)
    # ------------------------------------------------------------------

    def intercept_agent_task(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Replit Agent high-level task.

        REQUIRES a non-empty task_description. Governance cannot audit an
        unlabeled high-level task.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-REPLIT-1)
          2. task_description required

        Args:
            request: Task request dict with keys:
                     taskDescription, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        task_description = str(request.get("taskDescription", request.get("description", ""))).strip()
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-REPLIT-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Replit Agent task request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # task_description is required.
        if not task_description:
            reason_code = "replit-agent-task-description-required"
            return self._deny(
                agent_id,
                "Replit Agent task denied: taskDescription is required for governance audit. "
                "Every agent task must carry a non-empty taskDescription so the compliance "
                "system can evaluate and record the intended operation. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "replit:agent-task-requested",
            "args": {
                "taskDescription": task_description[:200],
                "deploymentMode": self.deployment_mode,
                "userTier": self.user_tier,
                "userIsMinor": self.user_is_minor,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_sandbox_code_execution -- code execution with egress scan
    # ------------------------------------------------------------------

    def intercept_sandbox_code_execution(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Replit sandbox code execution.

        Scans for network-egress patterns. For minor users: egress = DENIED.
        For non-minor: egress = audit note (allowed with warning).

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-REPLIT-1)
          2. Network egress scan (minor: deny; non-minor: audit)

        Args:
            request: Execution request dict with keys:
                     code, language, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        code = str(request.get("code", ""))
        language = str(request.get("language", "unknown"))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-REPLIT-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Replit sandbox code execution request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        egress_pattern = _detect_sandbox_egress(code)
        if egress_pattern and self.user_is_minor:
            reason_code = "replit-sandbox-network-egress-blocked-for-minor"
            return self._deny(
                agent_id,
                f"Replit sandbox code execution blocked: network egress pattern "
                f"detected ('{egress_pattern}') in code and user_is_minor is True. "
                "Minor users may not execute code that makes outbound network requests. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Non-minor with egress: allowed, include egress flag in audit.
        args: dict[str, Any] = {
            "language": language,
            "deploymentMode": self.deployment_mode,
            "userIsMinor": self.user_is_minor,
        }
        if egress_pattern:
            args["egressPatternDetected"] = True
            args["egressPatternSource"] = egress_pattern
        else:
            args["egressPatternDetected"] = False

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "replit:sandbox-code-execution-requested",
            "args": args,
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_file_system_mutation -- blast-radius cap
    # ------------------------------------------------------------------

    def intercept_file_system_mutation(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Replit file-system mutation operations.

        Blast-radius cap: file count > multi_file_edit_cap (default 25) = DENIED.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-REPLIT-1)
          2. Blast-radius file count check

        Args:
            request: File-system mutation request dict with keys:
                     files, description, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        files: list[str] = request.get("files", [])
        description = str(request.get("description", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-REPLIT-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Replit file-system mutation request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        if len(files) > self.multi_file_edit_cap:
            reason_code = "replit-file-system-mutation-blast-radius-exceeded"
            return self._deny(
                agent_id,
                f"Replit file-system mutation blocked: {len(files)} files exceeds the "
                f"blast-radius cap of {self.multi_file_edit_cap}. Reduce the number of "
                "files in a single mutation operation or increase multi_file_edit_cap in "
                f"ReplitAgentGovernedClient. Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "replit:file-system-mutation-requested",
            "args": {
                "fileCount": len(files),
                "cap": self.multi_file_edit_cap,
                "description": description[:120],
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_package_install -- supply-chain gate
    # ------------------------------------------------------------------

    def intercept_package_install(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Replit package installation.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-REPLIT-1)
          2. minor + student: unconditional denial
          3. allow_package_install=False: denial
          4. package_install_allow_list: only listed packages allowed
             (PT-ADAPT-REPLIT-6: offending package name in audit)
          5. Typosquat heuristics: name length or punctuation flags

        Args:
            request: Package install request dict with keys:
                     packageName, manager, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        package_name = str(request.get("packageName", request.get("package", ""))).strip()
        manager = str(request.get("manager", "unknown"))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-REPLIT-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Replit package install request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Gate: minor + student -> DENIED.
        if self.user_is_minor and self.user_tier == "student":
            reason_code = "replit-package-install-not-permitted-minor-student"
            return self._deny(
                agent_id,
                f"Replit package install blocked: user_is_minor is True and user_tier "
                f"is 'student'. Minor students may not install packages without explicit "
                f"authorization. Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Gate: allow_package_install=False.
        if not self.allow_package_install:
            reason_code = "replit-package-install-not-permitted"
            return self._deny(
                agent_id,
                f"Replit package install blocked: allow_package_install is False in config. "
                f"Set allow_package_install=True in ReplitAgentGovernedClient to enable. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Gate: allow_list enforcement (PT-ADAPT-REPLIT-6).
        if self.package_install_allow_list is not None and len(self.package_install_allow_list) > 0:
            if package_name not in self.package_install_allow_list:
                reason_code = "replit-package-install-not-in-allowlist"
                return self._deny(
                    agent_id,
                    f"Replit package install blocked: package '{package_name}' is not in "
                    "package_install_allow_list. Only pre-approved packages may be installed "
                    f"in this environment. Reason code: {reason_code}.",
                    pack_binding=pack_binding,
                    reason_code=reason_code,
                    # PT-ADAPT-REPLIT-6: include offending package name (it is not a secret).
                    extra={"offendingPackage": package_name, "manager": manager},
                )

        # Gate: typosquat heuristic.
        if _is_typosquat_suspicious(package_name):
            reason_code = "replit-package-install-typosquat-suspected"
            return self._deny(
                agent_id,
                f"Replit package install flagged: package name '{package_name}' matches "
                f"typosquatting heuristics (name length > {_TYPOSQUAT_MAX_NAME_LENGTH} chars "
                "or suspicious punctuation). Supply-chain review required before install. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
                # For typosquat, escalate to require_approval rather than hard deny.
                require_approval=True,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "replit:package-install-requested",
            "args": {
                "packageName": package_name,
                "manager": manager,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_deployment -- CRITICAL gate (PT-ADAPT-REPLIT-4)
    # ------------------------------------------------------------------

    def intercept_deployment(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Replit deployment operations.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-REPLIT-1)
          2. PT-ADAPT-REPLIT-4: user_is_minor -> ALWAYS DENIED
          3. user_tier='student' -> ALWAYS DENIED
          4. Non-deployments mode without allow_deployment=True -> DENIED

        Args:
            request: Deployment request dict with keys:
                     target, branch, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        target = str(request.get("target", "production"))
        branch = str(request.get("branch", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-REPLIT-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Replit deployment request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # PT-ADAPT-REPLIT-4: minor user ALWAYS DENIED.
        if self.user_is_minor:
            reason_code = "replit-deployment-not-permitted-minor"
            return self._deny(
                agent_id,
                "Replit deployment blocked: user_is_minor is True. Minor users may never "
                "trigger production deployments. This is an unconditional governance rule. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Student tier ALWAYS DENIED.
        if self.user_tier == "student":
            reason_code = "replit-deployment-not-permitted-student"
            return self._deny(
                agent_id,
                "Replit deployment blocked: user_tier is 'student'. Student-tier users "
                "may not trigger production deployments. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Mode check: only replit-deployments mode allows deployment by default.
        is_deploy_mode = self.deployment_mode == "replit-deployments"
        if not is_deploy_mode and not self.allow_deployment:
            reason_code = "replit-deployment-not-permitted-mode"
            return self._deny(
                agent_id,
                f"Replit deployment blocked: deployment_mode is '{self.deployment_mode}' "
                "(not 'replit-deployments') and allow_deployment is not explicitly set to "
                "True. Only the 'replit-deployments' mode or explicit allow_deployment=True "
                f"permits deployment operations. Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "replit:deployment-requested",
            "args": {
                "target": target,
                "branch": branch,
                "deploymentMode": self.deployment_mode,
                "userTier": self.user_tier,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_secret_access -- high-sensitivity gate (PT-ADAPT-REPLIT-5)
    # ------------------------------------------------------------------

    def intercept_secret_access(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Replit Secrets manager reads.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-REPLIT-1)
          2. PT-ADAPT-REPLIT-5: user_is_minor -> ALWAYS DENIED
          3. allow_secret_access not True -> DENIED (governance default-deny)

        Args:
            request: Secret access request dict with keys:
                     secretName, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        secret_name = str(request.get("secretName", request.get("key", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-REPLIT-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Replit secret access request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # PT-ADAPT-REPLIT-5: minor user ALWAYS DENIED.
        if self.user_is_minor:
            reason_code = "replit-secret-access-not-permitted"
            return self._deny(
                agent_id,
                "Replit secret access blocked: user_is_minor is True. Minor users may never "
                "access Replit Secrets. This is an unconditional governance rule. "
                f"Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # Default-deny: allow_secret_access must be explicitly True.
        if not self.allow_secret_access:
            reason_code = "replit-secret-access-not-permitted"
            return self._deny(
                agent_id,
                "Replit secret access blocked: allow_secret_access is not enabled. "
                "Set allow_secret_access=True in ReplitAgentGovernedClient to permit "
                f"Replit Secrets reads. Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
            )

        # NOTE: secret_name recorded for audit traceability; the VALUE is never included.
        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "replit:secret-access-requested",
            "args": {
                "secretName": secret_name,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_database_query -- destructive SQL gate
    # ------------------------------------------------------------------

    def intercept_database_query(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Replit database queries.

        Scans for destructive SQL patterns and requires approval for DROP,
        TRUNCATE, and unguarded DELETE operations.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-REPLIT-1)
          2. Destructive SQL pattern scan

        Args:
            request: Database query request dict with keys:
                     query, dbType, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        query = str(request.get("query", ""))
        db_type = str(request.get("dbType", request.get("db_type", "unknown")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-REPLIT-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Replit database query request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        destructive_pattern = _detect_destructive_sql(query)
        if destructive_pattern:
            reason_code = "replit-database-query-destructive-op-requires-approval"
            return self._deny(
                agent_id,
                f"Replit database query flagged: destructive SQL pattern detected "
                f"('{destructive_pattern}'). Destructive operations (DROP, TRUNCATE, "
                f"unguarded DELETE) require human approval before execution. "
                f"dbType: {db_type}. Reason code: {reason_code}.",
                pack_binding=pack_binding,
                reason_code=reason_code,
                require_approval=True,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "replit:database-query-requested",
            "args": {
                "queryPreview": query[:80],
                "dbType": db_type,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_chat -- secret + PHI scan
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate Replit Agent chat interactions.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-REPLIT-1)
          2. Secret pattern scan
          3. PHI gate under HIPAA binding

        Args:
            request: Chat request dict with keys:
                     promptText, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        prompt_text = str(request.get("promptText", request.get("prompt", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-REPLIT-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Replit Agent chat request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Secret scan.
        secret_match = _scan_for_secrets(prompt_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Replit Agent chat blocked: secret pattern '{secret_match}' in prompt.",
                pack_binding=pack_binding,
                reason_code="replit-chat-secret-in-prompt",
            )

        # PHI gate under HIPAA binding.
        if _is_hipaa_binding(pack_binding):
            phi_match = _scan_for_phi(prompt_text)
            if phi_match:
                return self._deny(
                    agent_id,
                    f"Replit Agent chat routed for HIPAA review: PHI indicator "
                    f"'{phi_match}' in prompt. Human review required before dispatch.",
                    pack_binding=pack_binding,
                    reason_code="replit-chat-phi-hipaa-review-required",
                    require_approval=True,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "replit:chat-requested",
            "args": {
                "deploymentMode": self.deployment_mode,
                "userTier": self.user_tier,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown ReplitAgentGovernedClient event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier: scan tool results for secrets.
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] ReplitAgentGovernedClient output classifier: possible "
                    f"secret in tool result \"{payload.get('toolName', 'unknown')}\" "
                    f"(agent: {agent_id}).",
                    file=sys.stderr,
                )

        # Output exfiltration scanner: scan LLM results for secrets/PHI.
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] ReplitAgentGovernedClient output exfiltration scanner: "
                    f"possible secret/PHI in LLM response (agent: {agent_id}).",
                    file=sys.stderr,
                )

        # Inject deployment mode metadata.
        enriched = {
            "deploymentMode": self.deployment_mode,
            "userTier": self.user_tier,
            "userIsMinor": self.user_is_minor,
            **payload,
        }
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # Convenience hook methods (canonical event surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
        reason_code: Optional[str] = None,
        require_approval: bool = False,
        extra: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Build a DENY (or REQUIRE_APPROVAL) GovernanceDecision."""
        from connexum_governance.models import GovernanceDecision, DecisionType
        decision_type = DecisionType.REQUIRE_APPROVAL if require_approval else DecisionType.DENY
        d = GovernanceDecision(
            decision=decision_type,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce and not require_approval:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# ReplitAgentPolicyBridge
# ---------------------------------------------------------------------------

class ReplitAgentPolicyBridge:
    """Bridge for Python-hosted policy participation in the Replit governance loop."""

    def __init__(
        self,
        adapter: ReplitAgentGovernedClient,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:
                import logging as _logging
                _logging.getLogger(__name__).warning(
                    "Governance audit operation failed: %s", exc
                )

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
