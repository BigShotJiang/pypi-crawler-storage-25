"""deepagents integration for Connexum governance.

This framework is TypeScript-native. This integration is a REST shim so a
Python governance policy can sit in front of a Node orchestrator. See
`src/orchestrator-adapters/deepagents.ts` for the primary adapter.

deepagents returns a compiled LangGraph graph as its execution substrate.
This Python shim exposes the canonical six-hook governance event surface and
adds three deepagents-specific surfaces: sub-agent spawn, todo-list
middleware, and context summarization.

Architecture:
  The deepagents TypeScript runtime calls this Python shim via HTTP when it
  needs a governance decision (ALLOW / REQUIRE_APPROVAL / DENY). The shim
  validates the inbound JSON payload, runs local guard checks (pack-binding
  primacy, PHI scan, sub-agent pack inheritance), and forwards a canonical
  event to the governance REST API.

  Python-hosted policy engine participation:
    adapter = DeepAgentsGovernance(client=gov, ...)
    adapter.emit_event("agentStart", {...})          # forward canonical event
    adapter.wrap_webhook(request_body)               # validate + forward inbound

Canonical event shape for each hook:
  agentStart   -> {"eventType": "agentStart",   "agentId": ..., "packBinding": [...], ...}
  toolCall     -> {"eventType": "toolCall",     "agentId": ..., "toolName": ..., ...}
  toolResult   -> {"eventType": "toolResult",   "agentId": ..., "toolName": ..., ...}
  llmCall      -> {"eventType": "llmCall",      "agentId": ..., "model": ..., ...}
  llmResult    -> {"eventType": "llmResult",    "agentId": ..., "model": ..., ...}
  agentEnd     -> {"eventType": "agentEnd",     "agentId": ..., "success": ..., ...}

deepagents-specific surfaces:
  subAgentSpawn  -> pack inheritance check (child cannot escalate above parent)
  todoList       -> PHI classification per item at emit time
  summarization  -> distilled PHI scan on context summaries

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.deepagents import DeepAgentsGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = DeepAgentsGovernance(
        client=gov,
        no_delegation_packs=["strict-hipaa"],
        approved_models=["gpt-4o", "claude-sonnet-4-6"],
    )

    # Forward a canonical event from the TS runtime:
    adapter.emit_event("agentStart", {
        "agentId": "research-agent",
        "packBinding": ["hipaa"],
        "model": "gpt-4o",
    })

    # Validate + forward an inbound webhook from the deepagents runtime:
    decision = adapter.wrap_webhook(request_json_body)

    # Python-side sub-agent spawn governance:
    result = adapter.check_sub_agent_spawn(
        parent_agent_id="parent",
        child_agent_id="child",
        parent_pack_binding=["hipaa", "soc2"],
        requested_child_pack_binding=["hipaa"],
    )
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------

class DeepAgentsUnboundDataError(RuntimeError):
    """Raised when a deepagents sub-agent spawn results in an empty pack binding."""

    def __init__(self, parent_agent_id: str, child_agent_id: str):
        super().__init__(
            f'Sub-agent spawn refused: effective pack binding for "{child_agent_id}" '
            f'(spawned by "{parent_agent_id}") is empty after inheritance filtering. '
            "Every agent MUST carry packBinding before any action fires. Fail closed."
        )
        self.parent_agent_id = parent_agent_id
        self.child_agent_id = child_agent_id


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


# ---------------------------------------------------------------------------
# Canonical event type set
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
    # deepagents-specific
    "subAgentSpawn",
    "todoList",
    "summarization",
})


# ---------------------------------------------------------------------------
# DeepAgentsGovernance
# ---------------------------------------------------------------------------

class DeepAgentsGovernance(BaseGovernanceIntegration):
    """REST-client shim for deepagents governance.

    deepagents is TypeScript-native (runs on Node). This Python shim allows
    a Python-hosted governance policy engine to participate in the decision
    loop by:
      1. Receiving canonical events from the deepagents TS runtime via HTTP
         (wrap_webhook)
      2. Emitting canonical events directly to the governance REST API
         (emit_event)
      3. Running local guard checks: pack-binding primacy, PHI scan, sub-agent
         pack inheritance before forwarding
      4. Providing a policy_bridge() helper so a Python policy function can
         be called for each governance decision

    The deepagents TS runtime's three additional surfaces are also exposed:
      - check_sub_agent_spawn(): pack inheritance + no-delegation enforcement
      - check_todo_list():        PHI classification at emit time per item
      - check_summarization():    distilled-PHI scan on context summary text
    """

    _FRAMEWORK_NAME = "deepagents"
    _LAYER_NAME = "deepagents-rest-shim"
    # deepagents exempts both agentEnd and summarization from pack-binding primacy
    _EXEMPT_EVENT_TYPES = frozenset({"agentEnd", "summarization"})

    def __init__(
        self,
        client: GovernanceClient,
        no_delegation_packs: Optional[list[str]] = None,
        approved_models: Optional[list[str]] = None,
        sensitive_tools: Optional[list[str]] = None,
        sensitive_arg_keys: Optional[list[str]] = None,
        classify_todo_items: bool = True,
        classify_summaries: bool = True,
    ):
        """
        Args:
            client: Configured GovernanceClient pointing at the governance REST API.
            no_delegation_packs: Pack IDs that prohibit inheritance in sub-agent spawns.
            approved_models: LLM model IDs approved for use.
            sensitive_tools: Tool names requiring reviewer approval.
            sensitive_arg_keys: Argument keys to scan for PHI.
            classify_todo_items: Classify todo-list items for PHI at emit time.
            classify_summaries: Apply PHI classifier to context summaries.
        """
        super().__init__(client)
        self.no_delegation_packs = set(no_delegation_packs or [])
        self.approved_models = approved_models or []
        self.sensitive_tools = sensitive_tools or []
        self.sensitive_arg_keys = sensitive_arg_keys or ["query", "content", "message", "body"]
        self.classify_todo_items = classify_todo_items
        self.classify_summaries = classify_summaries

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API.

        This is the primary method called by the deepagents TS runtime or by
        the Python policy engine to emit lifecycle events.

        Args:
            event_type: One of the canonical event types (agentStart, toolCall, etc.)
            payload: Event-specific payload. Must include "agentId".

        Returns:
            GovernanceDecision from the governance API.
        """
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown deepagents event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", "unknown")

        # Provider compliance for llmCall events
        if event_type == "llmCall":
            model = payload.get("model", "")
            if self.approved_models and model not in self.approved_models:
                from connexum_governance.models import DecisionType
                reason = (
                    f'deepagents LLM model "{model}" is not on the approved provider list. '
                    f"Approved: {', '.join(self.approved_models)}"
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # PHI scan on tool call args
        if event_type == "toolCall":
            tool_args = payload.get("args", {})
            exfil_key = self._scan_args(tool_args)
            if exfil_key:
                from connexum_governance.models import DecisionType
                tool_name = payload.get("toolName", "unknown")
                reason = (
                    f'Possible data exfiltration in deepagents tool "{tool_name}" args '
                    f'(key: "{exfil_key}"). Blocked at G5/G7 egress guard.'
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # PHI scan on tool results (output classifier)
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _contains_phi(result_text):
                print(
                    f"[GOVERNANCE] deepagents output classifier: possible PHI in "
                    f'tool result for "{payload.get("toolName", "unknown")}" '
                    f"(agent: {agent_id}).",
                    file=sys.stderr,
                )

        # PHI scan on LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _contains_phi(response_text):
                print(
                    f"[GOVERNANCE] deepagents output exfiltration scanner: possible PHI "
                    f'in LLM response (model: {payload.get("model", "unknown")}, '
                    f"agent: {agent_id}).",
                    file=sys.stderr,
                )

        # Delegate pack-binding primacy + REST dispatch + audit tracking to base (M2)
        # _EXEMPT_EVENT_TYPES = {"agentEnd", "summarization"} for deepagents
        return super().emit_event(event_type, payload)

    # ------------------------------------------------------------------
    # wrap_webhook -- validate + forward an inbound webhook payload
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload from the deepagents TS runtime and forward it.

        The deepagents Node runtime sends lifecycle events to this Python
        policy engine over HTTP. This method:
          1. Validates the required "eventType" and "agentId" fields
          2. Runs local guard checks (PHI scan, pack-binding check)
          3. Forwards to the governance REST API via emit_event()

        Args:
            request_body: Parsed JSON body from the inbound webhook request.

        Returns:
            GovernanceDecision that should be serialised and returned as the
            HTTP response to the deepagents runtime.

        Raises:
            ValueError: Required fields are missing from the request body.
        """
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError(
                "deepagents webhook payload missing required field: 'eventType'"
            )

        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError(
                "deepagents webhook payload missing required field: 'agentId'"
            )

        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge -- Python policy participation in the decision loop
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "DeepAgentsPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation.

        The bridge allows a Python policy function to be called for each
        governance decision before the decision is forwarded to the TS runtime.

        Args:
            pack_binding: Pack binding that governs decisions via this bridge.
            decision_callback: Callable(event_type, payload) -> GovernanceDecision
                               or None. If None is returned, the bridge falls
                               back to the governance REST API.

        Returns:
            DeepAgentsPolicyBridge instance.
        """
        return DeepAgentsPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # check_sub_agent_spawn -- pack inheritance governance
    # ------------------------------------------------------------------

    def check_sub_agent_spawn(
        self,
        parent_agent_id: str,
        child_agent_id: str,
        parent_pack_binding: list[str],
        requested_child_pack_binding: list[str],
        child_model: Optional[str] = None,
    ) -> dict[str, Any]:
        """Govern sub-agent spawn with pack inheritance enforcement.

        Pack inheritance rules (mirrors TS DeepAgentsAdapter.subAgentSpawn):
          1. Effective binding = parent binding INTERSECT requested child binding
             (child cannot escalate privilege above parent)
          2. Remove any packs in no_delegation_packs
          3. If effective binding is empty after filtering, deny (fail closed)

        Args:
            parent_agent_id: ID of the spawning parent agent.
            child_agent_id: ID of the new child agent.
            parent_pack_binding: Pack binding of the parent agent.
            requested_child_pack_binding: Pack binding the child requests.
            child_model: Optional model the child agent will use.

        Returns:
            Dict with keys:
              - "effective_pack_binding": list[str] -- the resolved binding
              - "audit_id": str

        Raises:
            DeepAgentsUnboundDataError: effective binding is empty after filtering.
        """
        # Step 1: child cannot escalate above parent
        inherited = [p for p in requested_child_pack_binding if p in parent_pack_binding]

        # Step 2: remove no-delegation packs
        filtered_packs = [p for p in inherited if p in self.no_delegation_packs]
        effective = [p for p in inherited if p not in self.no_delegation_packs]

        audit_id = str(uuid.uuid4())

        if filtered_packs:
            print(
                f"[GOVERNANCE] deepagents sub-agent spawn: filtered out no-delegation packs "
                f"{filtered_packs} for child \"{child_agent_id}\".",
                file=sys.stderr,
            )

        # Step 3: fail closed on empty effective binding
        if not effective:
            raise DeepAgentsUnboundDataError(parent_agent_id, child_agent_id)

        agent = AgentIdentity(name=parent_agent_id)
        try:
            self.client.check_action(
                tool="deepagents.subAgentSpawn",
                input={
                    "eventType": "subAgentSpawn",
                    "parentAgentId": parent_agent_id,
                    "childAgentId": child_agent_id,
                    "parentPackBinding": parent_pack_binding,
                    "requestedChildPackBinding": requested_child_pack_binding,
                    "effectivePackBinding": effective,
                    "filteredPacks": filtered_packs,
                    "childModel": child_model,
                    "subagentSpawn": True,
                    "framework": "deepagents",
                    "layer": "deepagents-task-tool",
                    "packBinding": effective,
                    "auditId": audit_id,
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return {"effective_pack_binding": effective, "audit_id": audit_id}

    # ------------------------------------------------------------------
    # check_todo_list -- PHI classification per todo item at emit time
    # ------------------------------------------------------------------

    def check_todo_list(
        self,
        agent_id: str,
        items: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None,
    ) -> list[dict[str, Any]]:
        """Classify todo-list items for PHI/PAN at emit time.

        Mirrors TS DeepAgentsAdapter.processTodoList. Classification happens
        before the todo list enters the cycle's context (fail-forward rule).

        Returns the classified items with a "data_class" field added.
        """
        if not self.classify_todo_items:
            return [{"data_class": "CLEAN", **item} for item in items]

        classified = []
        for item in items:
            text = item.get("description", "") + " " + str(item.get("metadata", {}))
            data_class = "CLEAN"
            if _contains_phi(text):
                if re.search(r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b", text):
                    data_class = "PAN"
                else:
                    data_class = "PHI"
            elif re.search(r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b", text):
                data_class = "PII"
            classified.append({"data_class": data_class, **item})

        sensitive = [c for c in classified if c["data_class"] in ("PHI", "PAN")]
        if sensitive:
            print(
                f"[GOVERNANCE] deepagents todo-list contains {len(sensitive)} item(s) "
                f"with PHI/PAN (agent: {agent_id}). Data-class tags applied at emit time.",
                file=sys.stderr,
            )

        try:
            agent = AgentIdentity(name=agent_id)
            self.client.check_action(
                tool="deepagents.todoList",
                input={
                    "eventType": "todoList",
                    "agentId": agent_id,
                    "todoItemCount": len(classified),
                    "sensitiveItemCount": len(sensitive),
                    "packBinding": pack_binding or [],
                    "framework": "deepagents",
                    "layer": "deepagents-todo-middleware",
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return classified

    # ------------------------------------------------------------------
    # check_summarization -- distilled PHI scan on context summary
    # ------------------------------------------------------------------

    def check_summarization(
        self,
        agent_id: str,
        summary_text: str,
        pack_binding: Optional[list[str]] = None,
        cycle_id: Optional[str] = None,
        original_message_count: Optional[int] = None,
    ) -> dict[str, Any]:
        """Apply PHI classifier to a deepagents context summary.

        Summaries can contain distilled PHI even when underlying messages
        were individually redacted. This hook catches that risk.

        Returns:
            Dict with keys:
              - "has_phi_content": bool
              - "audit_id": str
        """
        audit_id = str(uuid.uuid4())

        if not self.classify_summaries:
            return {"has_phi_content": False, "audit_id": audit_id}

        has_phi = _contains_phi(summary_text)

        if has_phi:
            print(
                f"[GOVERNANCE] deepagents summarization: possible PHI detected in "
                f"context summary (agent: {agent_id}, cycle: {cycle_id}). "
                "Distilled PHI can appear in summaries even when underlying messages were redacted.",
                file=sys.stderr,
            )

        try:
            agent = AgentIdentity(name=agent_id)
            self.client.check_action(
                tool="deepagents.summarization",
                input={
                    "eventType": "summarization",
                    "agentId": agent_id,
                    "cycleId": cycle_id,
                    "originalMessageCount": original_message_count,
                    "summaryHasPhi": has_phi,
                    "packBinding": pack_binding or [],
                    "framework": "deepagents",
                    "layer": "deepagents-summary-classifier",
                    "auditId": audit_id,
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return {"has_phi_content": has_phi, "audit_id": audit_id}

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(self, agent_id: str, pack_binding: list[str], model: str,
                    **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        return self.emit_event("agentStart", {
            "agentId": agent_id, "packBinding": pack_binding, "model": model, **kwargs
        })

    def tool_call(self, agent_id: str, tool_name: str, args: dict[str, Any],
                  pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pack_binding or [], **kwargs
        })

    def tool_result(self, agent_id: str, tool_name: str, result: Any,
                    success: bool = True, pack_binding: Optional[list[str]] = None,
                    **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pack_binding or [], **kwargs
        })

    def llm_call(self, agent_id: str, model: str, messages: list[dict[str, Any]],
                 pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pack_binding or [], **kwargs
        })

    def llm_result(self, agent_id: str, model: str, response_text: str,
                   pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pack_binding or [], **kwargs
        })

    def agent_end(self, agent_id: str, success: bool,
                  pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pack_binding or [], **kwargs
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _scan_args(self, args: dict[str, Any]) -> Optional[str]:
        """Scan tool arguments for PHI patterns on sensitive keys."""
        for key in self.sensitive_arg_keys:
            value = args.get(key)
            if isinstance(value, str) and _contains_phi(value):
                return key
        return None


# ---------------------------------------------------------------------------
# DeepAgentsPolicyBridge
# ---------------------------------------------------------------------------

class DeepAgentsPolicyBridge:
    """Bridge for Python-hosted policy participation in the deepagents decision loop.

    Allows a Python policy function to intercept governance decisions before
    they reach the governance REST API. If the callback returns None, the
    adapter falls back to the REST API.
    """

    def __init__(
        self,
        adapter: DeepAgentsGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call the Python policy and fall back to governance REST API if needed."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
