"""Google Agent Development Kit (ADK) integration for Connexum governance.

Hooks into the Google ADK agent lifecycle with six canonical governance hook
surfaces. Python-native: delegates to the google-adk package when installed.

Hook surfaces (parity with src/orchestrator-adapters/google-adk.ts):
  agentStart   -> gate at ADK session start
  toolCall     -> pre-tool gate before ADK function invocation
  toolResult   -> post-tool G-series output classification
  llmCall      -> pre-Gemini gate (Vertex AI vs AI Studio distinction)
  llmResult    -> post-Gemini output exfiltration scan
  agentEnd     -> terminal audit event sealing

ADK-specific considerations:
  - ADK agents run on Vertex AI Agent Engine, Cloud Run, and GKE.
  - Provider compliance: BAA coverage is ONLY valid for Vertex AI paths.
    Direct Gemini API (AI Studio) calls do NOT carry a BAA. The adapter
    enforces this via require_vertex_ai flag when a HIPAA pack is bound.
  - Session context: ADK carries conversation state via session_id and
    user_id. Both are forwarded in canonical audit events.
  - Tool specs use Google function declaration format; normalised to
    canonical shape before emitting audit events.

Lazy import: google-adk is NOT hard-required at import time.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.google_adk import GoogleAdkGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = GoogleAdkGovernance(
        client=gov,
        approved_tools=["search", "calculator"],
        require_vertex_ai=True,  # HIPAA: block AI Studio paths
    )

    adapter.agent_start(session_id="sess-001", user_id="user-001", pack_binding=["hipaa"])
    adapter.tool_call(session_id="sess-001", tool_name="search", args={"query": "AI governance"})
    adapter.tool_result(session_id="sess-001", tool_name="search", result="results...", success=True)
    adapter.llm_call(session_id="sess-001", model="gemini-1.5-pro", messages=[], via_vertex=True)
    adapter.llm_result(session_id="sess-001", model="gemini-1.5-pro", response_text="Summary...")
    adapter.agent_end(session_id="sess-001", success=True)
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation


# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------

class BaaRegionError(RuntimeError):
    """Raised when an LLM call violates BAA region requirements."""

    def __init__(self, session_id: str, model: str, reason: str):
        super().__init__(
            f'BAA region violation for session "{session_id}", model "{model}": {reason}'
        )
        self.session_id = session_id
        self.model = model


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


# ---------------------------------------------------------------------------
# GoogleAdkGovernance
# ---------------------------------------------------------------------------

class GoogleAdkGovernance:
    """Governance adapter for the Google Agent Development Kit (ADK).

    Exposes six lifecycle hooks that map to the canonical governance event
    surfaces. Works without the google-adk package installed by accepting
    plain Python dicts.

    Provider compliance note:
      Google ADK agents call Gemini via Vertex AI. When require_vertex_ai=True,
      llm_call will deny any call that has via_vertex=False. This enforces the
      BAA coverage boundary (Vertex AI has a BAA; AI Studio does not).
    """

    def __init__(
        self,
        client: GovernanceClient,
        approved_tools: Optional[list[str]] = None,
        sensitive_tools: Optional[list[str]] = None,
        require_vertex_ai: bool = False,
        agent_name: str = "google-adk-agent",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            approved_tools: Allowlist of tool names. None means all tools allowed.
            sensitive_tools: Tools requiring reviewer approval.
            require_vertex_ai: When True, llm_call denies if via_vertex=False.
                               Enforces the HIPAA BAA coverage boundary.
            agent_name: Default agent identity name for audit events.
        """
        self.client = client
        self.approved_tools = approved_tools
        self.sensitive_tools = sensitive_tools or []
        self.require_vertex_ai = require_vertex_ai
        self.agent_name = agent_name

        # session_id -> state
        self._sessions: dict[str, dict[str, Any]] = {}
        self._pending_audits: dict[str, str] = {}

    # ------------------------------------------------------------------
    # agentStart
    # ------------------------------------------------------------------

    def agent_start(
        self,
        session_id: str,
        user_id: str = "unknown",
        pack_binding: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Gate at ADK session start.

        Registers the session and checks governance. Records pack_binding
        for later BAA enforcement at llm_call.

        Raises:
            GovernanceViolation: governance server denies.
        """
        pack = pack_binding or []
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        decision = self.client.check_action(
            tool="agent.start",
            input={
                "sessionId": session_id,
                "userId": user_id,
                "packBinding": pack,
                "metadata": metadata or {},
                "framework": "google-adk",
            },
            agent=agent,
        )

        self._sessions[session_id] = {
            "user_id": user_id,
            "pack_binding": pack,
        }
        if decision.audit_id:
            self._pending_audits[f"start:{session_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolCall
    # ------------------------------------------------------------------

    def tool_call(
        self,
        session_id: str,
        tool_name: str,
        args: dict[str, Any],
        tool_spec: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Pre-tool governance check.

        Checks:
          1. Tool allowlist (if configured)
          2. Sensitive-tool REQUIRE_APPROVAL routing
          3. Governance check_action

        Raises:
            GovernanceViolation: governance server denies.
        """
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        # Allowlist check
        if self.approved_tools is not None and tool_name not in self.approved_tools:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Tool "{tool_name}" is not in the approved tools list. '
                f"Approved: {', '.join(self.approved_tools)}"
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        decision = self.client.check_action(
            tool=f"tool.{tool_name}",
            input={
                "sessionId": session_id,
                "toolName": tool_name,
                "argsDigest": str(args)[:500],
                "toolSpec": tool_spec or {},
                "packBinding": pack,
                "framework": "google-adk",
                "sensitive": tool_name in self.sensitive_tools,
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"tool:{session_id}:{tool_name}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolResult
    # ------------------------------------------------------------------

    def tool_result(
        self,
        session_id: str,
        tool_name: str,
        result: Any,
        success: bool = True,
        duration_ms: Optional[int] = None,
    ) -> None:
        """Post-tool G-series classification and audit chain close."""
        audit_id = self._pending_audits.pop(f"tool:{session_id}:{tool_name}", None)
        result_text = str(result) if not isinstance(result, str) else result
        phi_found = _contains_phi(result_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output classifier: possible PHI in ADK tool result "
                f'"{tool_name}" (session: {session_id}). Audit ID: {audit_id}',
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success and not phi_found,
                    summary=result_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Output classifier: PHI in tool result",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # llmCall
    # ------------------------------------------------------------------

    def llm_call(
        self,
        session_id: str,
        model: str,
        messages: list[dict[str, Any]],
        tools: Optional[list[dict[str, Any]]] = None,
        via_vertex: bool = True,
    ) -> GovernanceDecision:
        """Pre-Gemini governance check.

        Enforces the Vertex AI BAA boundary:
          - When require_vertex_ai=True and via_vertex=False, the call is denied.
          - BAA is ONLY valid for Vertex AI paths (not AI Studio direct calls).

        Raises:
            BaaRegionError: via_vertex=False under require_vertex_ai=True.
            GovernanceViolation: governance server denies.
        """
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        # BAA region enforcement
        if self.require_vertex_ai and not via_vertex:
            reason = (
                "Direct Gemini API (AI Studio) calls do not carry a BAA. "
                "HIPAA pack requires Vertex AI invocation path. "
                "Set via_vertex=True to use the BAA-covered path."
            )
            from connexum_governance.models import GovernanceDecision, DecisionType
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise BaaRegionError(session_id, model, reason)
            return d

        decision = self.client.check_action(
            tool="llm.call",
            input={
                "sessionId": session_id,
                "model": model,
                "messageCount": len(messages),
                "toolCount": len(tools or []),
                "packBinding": pack,
                "viaVertex": via_vertex,
                "framework": "google-adk",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"llm:{session_id}:{model}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # llmResult
    # ------------------------------------------------------------------

    def llm_result(
        self,
        session_id: str,
        model: str,
        response_text: str,
        usage: Optional[dict[str, int]] = None,
    ) -> None:
        """Post-Gemini output exfiltration scan and audit chain close."""
        audit_id = self._pending_audits.pop(f"llm:{session_id}:{model}", None)
        phi_found = _contains_phi(response_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output exfiltration scanner: possible PHI in "
                f"Gemini response (model: {model}, session: {session_id}). "
                "Flagged for compliance review.",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=not phi_found,
                    summary=response_text[:200],
                    error=None if not phi_found else "Output exfiltration scanner: PHI in LLM response",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # agentEnd
    # ------------------------------------------------------------------

    def agent_end(
        self,
        session_id: str,
        success: bool,
        summary: Optional[str] = None,
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
    ) -> None:
        """Terminal audit event sealing and session cleanup."""
        session = self._sessions.pop(session_id, {})
        audit_id = self._pending_audits.pop(f"start:{session_id}", None)
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        try:
            self.client.check_action(
                tool="agent.end",
                input={
                    "sessionId": session_id,
                    "userId": session.get("user_id", "unknown"),
                    "success": success,
                    "summary": summary or ("Session complete" if success else "Session failed"),
                    "durationMs": duration_ms,
                    "error": error,
                    "packBinding": session.get("pack_binding", []),
                    "framework": "google-adk",
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success,
                    summary=summary or "",
                    duration_ms=duration_ms,
                    error=error,
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)
