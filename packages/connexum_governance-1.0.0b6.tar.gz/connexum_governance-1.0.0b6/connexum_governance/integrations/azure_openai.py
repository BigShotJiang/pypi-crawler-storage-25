"""Azure OpenAI governance integration for Connexum governance.

Wraps calls to the Azure OpenAI Service Chat Completions API with
pre-call governance checks and post-call G-series output classification.

Azure OpenAI differs from the base OpenAI API on:
- URL structure: https://<resource>.openai.azure.com/openai/deployments/<deployment>/
- Auth: api-key header OR Azure AD Bearer token
- API version: required query parameter
- Content filter results in responses (content_filter_results field)

BAA status: Azure OpenAI is in scope for the Microsoft Business Associate
Agreement (BAA), which covers HIPAA-eligible Azure services. Azure OpenAI
is listed as a HIPAA-eligible service under the Microsoft Online Services
Business Associate Agreement.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.azure_openai import AzureOpenAIGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    ag = AzureOpenAIGovernance(
        client=gov,
        agent_name="azure-agent",
        resource_name="my-resource",
        deployment_name="gpt-4o-deploy",
    )

    decision = ag.intercept_request({
        "messages": [{"role": "user", "content": "Hello"}],
        "max_tokens": 512,
    })
"""

from __future__ import annotations

import sys
import time
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
    GovernanceViolation,
)

_PROVIDER_ID = "azure_openai"
_BAA_AVAILABLE = True
_BAA_SCOPE = "microsoft_baa"
_BAA_NOTES = (
    "Azure OpenAI is covered by the Microsoft HIPAA Business Associate Agreement "
    "for eligible Azure services. Confirm your Azure subscription includes the BAA addendum."
)


class AzureOpenAIGovernance:
    """Governance wrapper for the Azure OpenAI Chat Completions API.

    Intercepts requests before they reach the Azure endpoint and
    classifies responses through the nine-guard G-series after receipt.

    Also inspects Azure-specific content_filter_results in responses and
    reports any active content filter flags in the governance metadata.

    Does NOT depend on the openai or azure-openai package at import time.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        resource_name: Optional[str] = None,
        deployment_name: Optional[str] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)
        self.resource_name = resource_name
        self.deployment_name = deployment_name

        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        """Check a pending Azure OpenAI chat completions request against governance.

        Extracts: deployment name (model analogue), system prompt digest,
        message count, tool names, and Azure-specific metadata.

        Args:
            request: The dict passed to the Azure chat completions endpoint.
                Typically contains: messages, max_tokens, tools, temperature.

        Returns:
            GovernanceDecision (ALLOW / DENY / REQUIRE_APPROVAL).

        Raises:
            GovernanceViolation: if enforce=True and the decision is DENY.
        """
        messages = request.get("messages", [])
        system_digest = ""
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "system":
                content = msg.get("content", "")
                if isinstance(content, str):
                    system_digest = content[:500]
                elif isinstance(content, list):
                    system_digest = " ".join(
                        p.get("text", "") for p in content if isinstance(p, dict)
                    )[:500]
                break

        tools = request.get("tools", [])
        tool_names = [
            t.get("function", {}).get("name", "")
            for t in tools
            if isinstance(t, dict)
        ]
        tool_names = list(filter(None, tool_names))

        gov_input: dict[str, Any] = {
            "model": self.deployment_name or request.get("model", "unknown"),
            "resourceName": self.resource_name or "unknown",
            "deploymentName": self.deployment_name or "unknown",
            "maxTokens": request.get("max_tokens"),
            "systemPromptDigest": system_digest,
            "messageCount": len(messages),
            "toolCount": len(tool_names),
            "toolNames": tool_names,
            "provider": "azure_openai",
        }

        return self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )

    def intercept_response(
        self,
        response: dict[str, Any],
        audit_id: str,
    ) -> ClassifiedResponse:
        """Classify an Azure OpenAI response through the G-series guards.

        In addition to standard classification, checks Azure-specific
        content_filter_results in the response choices and records any
        active filters in the ClassifiedResponse metadata.

        Args:
            response: Raw response dict from Azure OpenAI.
            audit_id: The audit_id from the preceding intercept_request decision.

        Returns:
            ClassifiedResponse indicating whether the response is safe to return.
        """
        start = time.monotonic()

        # Check Azure content filter results
        content_filter_flags: list[str] = []
        for choice in response.get("choices", []):
            if isinstance(choice, dict):
                cfr = choice.get("content_filter_results", {})
                for guard_name, guard_data in cfr.items():
                    if isinstance(guard_data, dict) and guard_data.get("filtered"):
                        content_filter_flags.append(guard_name)

        # Merge content filter flags into the response for classification
        enriched_response = dict(response)
        if content_filter_flags:
            enriched_response["_azure_content_filter_triggered"] = content_filter_flags

        classified = self.client.classify_output(
            audit_id=audit_id,
            output=enriched_response,
            agent=self.agent,
        )

        elapsed_ms = int((time.monotonic() - start) * 1000)

        # Merge Azure content filter flags into classified metadata
        if content_filter_flags:
            if classified.metadata is None:
                object.__setattr__(classified, "metadata", {})
            classified.metadata["azureContentFilterFlags"] = content_filter_flags  # type: ignore[index]

        try:
            self.client.report_result(
                audit_id=audit_id,
                success=classified.allowed and not content_filter_flags,
                summary=(
                    f"Response classified. Guards: {classified.guards_triggered}. "
                    f"Azure filters: {content_filter_flags}"
                    if classified.guards_triggered or content_filter_flags
                    else "Response classified clean."
                ),
                duration_ms=elapsed_ms,
                error=(
                    f"Guards: {classified.guards_triggered} / Azure filters: {content_filter_flags}"
                    if not classified.allowed or content_filter_flags
                    else None
                ),
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return classified

    def wrap(self, azure_client: Any) -> "AzureOpenAIClientProxy":
        """Return a proxy around an openai.AzureOpenAI client instance.

        Args:
            azure_client: An openai.AzureOpenAI client instance.

        Returns:
            AzureOpenAIClientProxy wrapping the provided client.
        """
        return AzureOpenAIClientProxy(raw_client=azure_client, governance=self)


class _GovernedAzureChatCompletions:
    """Proxy for azure_client.chat.completions with governance enforcement."""

    def __init__(self, raw_completions: Any, governance: AzureOpenAIGovernance):
        self._raw = raw_completions
        self._gov = governance

    def create(self, **kwargs: Any) -> Any:
        """Intercept chat.completions.create with governance checks."""
        decision = self._gov.intercept_request(kwargs)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {
                "id": "gov-denied",
                "object": "chat.completion",
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": f"[GOVERNANCE DENIED] {decision.reason}",
                        },
                        "finish_reason": "governance_denied",
                        "content_filter_results": {},
                    }
                ],
                "model": self._gov.deployment_name or "unknown",
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            }

        if decision.requires_approval:
            return {
                "id": f"gov-pending-{decision.audit_id}",
                "object": "chat.completion",
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": (
                                f"[GOVERNANCE PENDING] Action requires approval. "
                                f"Audit ID: {decision.audit_id}"
                            ),
                        },
                        "finish_reason": "governance_pending",
                        "content_filter_results": {},
                    }
                ],
                "model": self._gov.deployment_name or "unknown",
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            }

        response = self._raw.create(**kwargs)

        if hasattr(response, "model_dump"):
            response_dict = response.model_dump()
        elif hasattr(response, "to_dict"):
            response_dict = response.to_dict()
        else:
            response_dict = dict(response) if not isinstance(response, dict) else response

        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=response_dict,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] Azure OpenAI response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )
            if classified.metadata and classified.metadata.get("azureContentFilterFlags"):
                print(
                    f"[WARN] Azure content filter triggered: "
                    f"{classified.metadata['azureContentFilterFlags']}",
                    file=sys.stderr,
                )

        return response


class _GovernedAzureChat:
    def __init__(self, raw_chat: Any, governance: AzureOpenAIGovernance):
        self.completions = _GovernedAzureChatCompletions(
            raw_completions=raw_chat.completions,
            governance=governance,
        )


class AzureOpenAIClientProxy:
    """Thin proxy around an openai.AzureOpenAI client with governance.

    Intercepts chat.completions.create. Other attributes pass through
    to the underlying client unchanged.
    """

    def __init__(self, raw_client: Any, governance: AzureOpenAIGovernance):
        self._raw = raw_client
        self._chat = _GovernedAzureChat(
            raw_chat=raw_client.chat,
            governance=governance,
        )

    @property
    def chat(self) -> _GovernedAzureChat:
        return self._chat

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)
