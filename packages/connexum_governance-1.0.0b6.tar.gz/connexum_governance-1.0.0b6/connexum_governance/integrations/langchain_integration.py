"""
GovernedLangChain -- governance enforcement for LangChain and LangGraph (Python).

This is a FRAMEWORK ADAPTER, not an LLM provider shim. It operates at a
different interception layer from AnthropicGovernance, OpenAIGovernance, etc.:

  LLM provider shims intercept:  client.messages.create() / generate_content()
  Framework adapters intercept:  agent.invoke() / chain.invoke() / tool dispatch

Both layers can coexist for defense-in-depth. A customer running LangChain on
top of Anthropic can use AnthropicGovernance for the LLM boundary AND
GovernanceCallbackHandler for the framework boundary.

Architecture:
  - GovernanceCallbackHandler  -- sync callback handler intercepting:
      on_agent_action(action)     before tool dispatch (agent loop)
      on_tool_start(serialized, input_str)  before tool._run() (direct calls)
      on_llm_start(serialized, prompts)     before LLM call (injection scan)
      on_chain_end(outputs)                 after chain (audit log, no throw)
  - AsyncGovernanceCallbackHandler -- same hooks, async
  - GovernedTool  -- BaseTool subclass that wraps _run/_arun with governance
  - governed_tool()  -- convenience factory function
  - as_governed_tool()  -- decorator for tool functions
  - wrap_agent_executor()  -- injects handler into AgentExecutor.callbacks
  - wrap_state_graph()  -- DEPRECATED thin re-export to langgraph_integration.
      Use connexum_governance.integrations.langgraph_integration for the full
      dedicated LangGraph adapter (per-node + compile-level + edge governance).
  - create_governed_langchain()  -- primary public factory

=== CRITICAL ARCHITECTURAL NOTE: Callback Blocking Limitation ===

LangChain's callback system is designed for OBSERVABILITY, not BLOCKING.
Whether a raise from on_agent_action / on_tool_start propagates to the
caller depends on the LangChain version:

  LangChain >= 0.2.x (current as of 2026):
    Callbacks are wrapped in try/except in some executor paths. Whether an
    exception from on_agent_action blocks tool dispatch is NOT guaranteed
    by the LangChain callback contract. It varies by executor type and
    LangChain minor version.

  Tested behavior (langchain 0.2.x, langchain-core 0.2.x):
    - AgentExecutor respects raises from on_agent_action when callbacks
      are registered directly on the executor (not via runnable config).
    - ToolNode in LangGraph does NOT call these callbacks reliably in all
      versions; tool wrapping (GovernedTool / governed_tool()) is required
      for guaranteed blocking.

  CONCLUSION: The GovernedTool._run() / ._arun() path is the ONLY GUARANTEED
  BLOCKING PRIMITIVE. The callback handler provides defense-in-depth and
  observability but cannot be relied upon as the sole enforcement gate.
  Document this to customers: use governed_tool() for tools you want
  blocked; use the callback handler for audit coverage.

Action name namespace (for pack rule targeting):
  framework.langchain.agent_action    -- on_agent_action check
  framework.langchain.tool_invoke     -- on_tool_start + GovernedTool._run()
  framework.langchain.llm_start       -- on_llm_start check
  framework.langchain.graph.tool_node -- wrap_state_graph ToolNode interception

Supported LangChain version range (tested):
  langchain >= 0.2.0, < 0.4.0
  langchain-core >= 0.2.0, < 0.4.0
  langgraph >= 0.0.30, < 0.4.0

Architectural difference vs LangChain JS:

  Python LangChain callbacks are synchronous by default (BaseCallbackHandler),
  with a separate AsyncCallbackHandler for async usage. In JS there is a single
  handler class with optional async methods.

  Python LangChain tools implement _run()/  _arun() rather than invoke().
  invoke() is a thin wrapper around _run() added in langchain-core 0.2.x.
  The guaranteed blocking point is _run() / _arun(), NOT invoke().

  Python callback hooks receive 'serialized' as a plain dict (not a Serialized
  class), and kwargs carry run_id, parent_run_id, tags, metadata. The
  on_agent_action hook receives an AgentAction dataclass rather than a plain
  dict as in JS.

Optional peer dependencies:
  langchain >= 0.2.0
  langchain-core >= 0.2.0
  langgraph >= 0.0.30

@connexum/python-sdk -- Framework Adapter Layer (Sprint 5, WS-06)
"""

from __future__ import annotations

import sys
import asyncio
from dataclasses import dataclass
from typing import Any, Callable, Optional, Union

from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations._wire_shape import build_check_action_body

# ---------------------------------------------------------------------------
# Type aliases for check function injection (test isolation)
#
# The _check_fn parameter accepts a callable with the same contract as the
# governance HTTP check, allowing tests to run without a live server.
#
# Signature:
#   async (governance_server_url: str, body: dict) -> dict
#
# Returns a dict with keys: decision (ALLOW|DENY|REQUIRE_APPROVAL),
# reason (str, optional), approvalId (str, optional), auditId (str, optional)
# ---------------------------------------------------------------------------

CheckFnType = Callable[[str, dict], Any]


# ---------------------------------------------------------------------------
# LangChain type contracts (minimal interfaces, no import of langchain package)
#
# These dataclasses / protocols capture the shape of LangChain primitives we
# interact with. They are intentionally minimal -- only the fields and methods
# our adapter uses. This avoids requiring langchain as a hard dependency in the
# test environment and in SDK consumers that don't use LangChain.
# ---------------------------------------------------------------------------

@dataclass
class LangChainAgentAction:
    """Minimal shape of a LangChain AgentAction."""
    tool: str
    """The name of the tool to call."""
    tool_input: Union[str, dict]
    """The input to pass to the tool."""
    log: str = ""
    """Raw LLM output log (optional)."""


# ---------------------------------------------------------------------------
# Internal HTTP check helper
#
# Performs the governance check against the server (or injected _check_fn).
# Returns a normalized result dict with keys: decision, reason, approvalId, auditId.
# ---------------------------------------------------------------------------

def _do_check_sync(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """
    Run a synchronous governance check.

    If check_fn is provided (test injection), calls it directly.
    Otherwise performs a real HTTP POST to the governance server.
    """
    if check_fn is not None:
        # The check_fn contract is async -- run it using asyncio.run() which
        # creates a fresh event loop (Python 3.7+). If a loop is already running
        # (e.g. inside pytest-asyncio), fall back to a thread pool.
        if asyncio.iscoroutinefunction(check_fn):
            try:
                loop = asyncio.get_running_loop()
                # Running loop detected -- use a thread pool to avoid nested loops.
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(
                        lambda: asyncio.run(check_fn(governance_server_url, body))
                    )
                    return future.result()
            except RuntimeError:
                # No running loop -- safe to use asyncio.run()
                return asyncio.run(check_fn(governance_server_url, body))
        else:
            return check_fn(governance_server_url, body)

    # Real HTTP path -- lazy import httpx to avoid hard dependency
    try:
        import httpx as _httpx
        with _httpx.Client(timeout=5.0) as client:
            resp = client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


async def _do_check_async(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """
    Run an asynchronous governance check.

    If check_fn is provided (test injection), awaits it directly.
    Otherwise performs a real async HTTP POST to the governance server.
    """
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            return await check_fn(governance_server_url, body)
        else:
            return check_fn(governance_server_url, body)

    # Real async HTTP path -- lazy import httpx to avoid hard dependency
    try:
        import httpx as _httpx
        async with _httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


# ---------------------------------------------------------------------------
# Decision enforcement helpers
# ---------------------------------------------------------------------------

def _enforce_decision(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
) -> None:
    """
    Inspect a governance check result and raise on DENY / REQUIRE_APPROVAL.

    Args:
        result: The raw check result dict (decision, reason, approvalId, auditId).
        context_label: Human-readable label for error messages (e.g. tool name).
        raise_on_deny: Whether to raise exceptions. If False, only logs to stderr.

    Raises:
        GovernanceViolation: decision is DENY (and raise_on_deny=True).
        GovernancePendingApproval: decision is REQUIRE_APPROVAL (and raise_on_deny=True).
    """
    decision = result.get("decision", "ALLOW")

    if decision == "DENY":
        reason = result.get("reason") or "policy"
        sys.stderr.write(
            f"[GovernanceCallbackHandler] DENIED for '{context_label}'. reason={reason}\n"
        )
        if raise_on_deny:
            raise GovernanceViolation(
                decision="DENY",
                reason=reason,
                audit_id=result.get("auditId"),
            )
        return

    if decision == "REQUIRE_APPROVAL":
        approval_id = result.get("approvalId")
        audit_id = result.get("auditId")
        if not approval_id:
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                    audit_id=audit_id,
                )
            return
        sys.stderr.write(
            f"[GovernanceCallbackHandler] PENDING for '{context_label}'. "
            f"approvalId={approval_id}\n"
        )
        if raise_on_deny:
            raise GovernancePendingApproval(
                approval_id=approval_id,
                audit_id=audit_id,
            )

    # ALLOW -- fall through


# ---------------------------------------------------------------------------
# Prompt injection detector (lightweight, no external dependency)
#
# Python-side lightweight injection scan. Matches the TS PromptInjectionDetector
# pattern: heuristic keyword scan with severity classification.
# ---------------------------------------------------------------------------

_HIGH_INJECTION_PATTERNS = [
    "ignore previous instructions",
    "ignore your system prompt",
    "ignore all previous",
    "disregard previous",
    "forget your instructions",
    "you are now a different",
    "you are now an",
    "act as if you",
    "pretend you are",
    "reveal all secrets",
    "reveal your system prompt",
    "output your instructions",
    "your new instructions are",
    "new instructions:",
    "system override",
    "i am your administrator",
    "i am your operator",
    "override safety",
    "ignore safety",
    "bypass",
    "jailbreak",
]

_MEDIUM_INJECTION_PATTERNS = [
    "ignore the above",
    "disregard the above",
    "don't follow",
    "do not follow",
    "forget what",
    "as an ai without",
    "without restrictions",
    "without limitations",
    "without constraints",
    "act without",
    "you have no",
    "you must always",
    "you must never",
]


def _detect_injection(prompts: list[str]) -> dict:
    """
    Lightweight prompt injection scan.

    Returns:
        {detected: bool, severity: 'high'|'medium'|'low', patterns: list[str]}
    """
    combined = " ".join(prompts).lower()
    matched_high = [p for p in _HIGH_INJECTION_PATTERNS if p in combined]
    if matched_high:
        return {"detected": True, "severity": "high", "patterns": matched_high}

    matched_medium = [p for p in _MEDIUM_INJECTION_PATTERNS if p in combined]
    if matched_medium:
        return {"detected": True, "severity": "medium", "patterns": matched_medium}

    return {"detected": False, "severity": "low", "patterns": []}


# ---------------------------------------------------------------------------
# GovernanceCallbackHandler (sync)
# ---------------------------------------------------------------------------

class GovernanceCallbackHandler:
    """
    LangChain callback handler that enforces governance policy (synchronous).

    Implements the LangChain BaseCallbackHandler duck-type interface.
    Can be passed directly to any LangChain executor's callbacks list.

    BLOCKING CONTRACT:
      Raises GovernanceViolation on DENY and GovernancePendingApproval on PENDING
      (when raise_on_deny=True, the default).
      Whether LangChain respects these raises depends on the executor and version.
      See module-level CRITICAL ARCHITECTURAL NOTE and raise_on_deny option.

    Usage:
        from connexum_governance.integrations.langchain_integration import (
            GovernanceCallbackHandler,
        )

        handler = GovernanceCallbackHandler(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )
        executor = AgentExecutor(agent=agent, tools=tools, callbacks=[handler])
    """

    name = "GovernanceCallbackHandler"

    def __init__(
        self,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list[str]] = None,
        raise_on_deny: bool = True,
        llm_start_deny_threshold: str = "high",
        _check_fn: Optional[CheckFnType] = None,
    ):
        """
        Args:
            governance_server_url: URL of the governance server.
            license_key: License / JWT key for the governance server.
            pack_ids: Compliance pack IDs to evaluate against.
            raise_on_deny: When True (default), DENY raises GovernanceViolation
                and PENDING raises GovernancePendingApproval.
                When False, violations are logged to stderr but not raised.
                IMPORTANT: Even with raise_on_deny=True, LangChain may swallow
                exceptions in some executor configurations. Use GovernedTool
                for guaranteed blocking. See CRITICAL ARCHITECTURAL NOTE.
            llm_start_deny_threshold: Minimum injection severity to raise on.
                'high' (default) raises only on high-severity injection.
                'medium' raises on medium or high.
            _check_fn: Test injection hook. If provided, replaces the real HTTP
                check with a callable. Not part of the public API.
        """
        if not governance_server_url:
            raise ValueError(
                "[GovernanceCallbackHandler] governance_server_url is required"
            )
        if not license_key:
            raise ValueError(
                "[GovernanceCallbackHandler] license_key is required"
            )

        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._llm_start_deny_threshold = llm_start_deny_threshold
        self._check_fn = _check_fn

    def _check(self, body: dict) -> dict:
        """Run a synchronous governance check."""
        return _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=body,
            check_fn=self._check_fn,
        )

    def on_agent_action(
        self,
        action: Any,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """
        Fires before LangChain dispatches a tool from an agent action.

        Runs governance check. On DENY, raises GovernanceViolation (if raise_on_deny=True).
        On PENDING, raises GovernancePendingApproval (if raise_on_deny=True).

        NOTE: LangChain may catch exceptions from this callback depending on version.
        Use GovernedTool for guaranteed blocking.

        Args:
            action: AgentAction with .tool (str) and .tool_input (str | dict).
        """
        # Support both dataclass (LangChainAgentAction) and real LangChain AgentAction
        tool_name = getattr(action, "tool", None) or getattr(action, "name", "unknown")
        tool_input = getattr(action, "tool_input", None)
        if tool_input is None:
            tool_input = getattr(action, "input", "")

        input_str = (
            tool_input
            if isinstance(tool_input, str)
            else str(tool_input)
        )

        result = self._check(build_check_action_body(
            tool_name=tool_name,
            agent_name="langchain-callback-handler",
            framework_action="framework.langchain.agent_action",
            input_dict={"toolInput": input_str},
            message_preview=input_str[:200],
            pack_ids=self._pack_ids,
            extra_metadata={"toolName": tool_name, "inputPreview": input_str[:200]},
            source="on_agent_action",
        ))

        _enforce_decision(result, tool_name, self._raise_on_deny)

    def on_tool_start(
        self,
        serialized: dict,
        input_str: str,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """
        Fires when a Tool's _run() is called directly.

        Catches direct tool._run() calls that may bypass on_agent_action in
        some executor patterns. Runs governance check.

        Args:
            serialized: Dict with 'name' (str) or 'id' (list) identifying the tool.
            input_str: String input passed to the tool.
        """
        tool_name = (
            serialized.get("name")
            or (serialized.get("id") or ["unknown"])[-1]
        ) if serialized else "unknown"

        result = self._check(build_check_action_body(
            tool_name=tool_name,
            agent_name="langchain-callback-handler",
            framework_action="framework.langchain.tool_invoke",
            input_dict={"toolInput": str(input_str)},
            message_preview=str(input_str)[:200],
            pack_ids=self._pack_ids,
            extra_metadata={"toolName": tool_name, "inputPreview": str(input_str)[:200]},
            source="on_tool_start",
        ))

        _enforce_decision(result, tool_name, self._raise_on_deny)

    def on_llm_start(
        self,
        serialized: dict,
        prompts: list[str],
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """
        Fires before any LLM call.

        Runs prompt injection scan on the prompts first. HIGH severity (or
        MEDIUM if llm_start_deny_threshold='medium') raises GovernanceViolation.
        Then runs governance server check with action 'framework.langchain.llm_start'.

        Args:
            serialized: Dict identifying the LLM (has 'name' or 'id').
            prompts: List of prompt strings to be sent to the LLM.
        """
        # ---- Prompt injection scan ----
        detection = _detect_injection(prompts)
        if detection["detected"]:
            severity = detection["severity"]
            should_deny = severity == "high" or (
                self._llm_start_deny_threshold == "medium" and severity == "medium"
            )
            sys.stderr.write(
                f"[GovernanceCallbackHandler] prompt-injection:{severity} detected "
                f"on llm_start. patterns={detection['patterns']}\n"
            )
            if should_deny:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason=(
                            f"Prompt injection detected on LLM input "
                            f"(severity={severity}, "
                            f"patterns={detection['patterns']}). "
                            "Request blocked by connexum-governance "
                            "(Onyx #5 / OWASP LLM01)."
                        ),
                    )
                return
            # MEDIUM below threshold -- logged above, allow through

        # ---- Governance server check ----
        llm_name = (
            serialized.get("name")
            or (serialized.get("id") or ["unknown"])[-1]
        ) if serialized else "unknown"
        message_preview = prompts[0][:200] if prompts else ""

        result = self._check(build_check_action_body(
            tool_name=f"llm:{llm_name}",
            agent_name="langchain-callback-handler",
            framework_action="framework.langchain.llm_start",
            input_dict={"prompts": prompts},
            message_preview=message_preview,
            pack_ids=self._pack_ids,
            extra_metadata={"llmName": llm_name, "promptCount": len(prompts)},
            source="on_llm_start",
        ))

        _enforce_decision(result, llm_name, self._raise_on_deny)

    def on_chain_end(
        self,
        outputs: dict,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """
        Fires when a chain completes. Logs outputs for audit; does NOT raise.

        This is an observability hook. Governance violations at chain-end are
        reported to stderr but the chain output is not blocked (it has already
        completed). Use on_agent_action / on_tool_start for pre-execution gating.
        """
        sys.stderr.write(
            f"[GovernanceCallbackHandler] chain_end. "
            f"outputKeys={list(outputs.keys()) if outputs else []}\n"
        )

    def on_agent_finish(
        self,
        finish: Any,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Fires when the agent finishes. Audit log only, no governance check."""
        pass

    def on_chain_start(
        self,
        serialized: dict,
        inputs: dict,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Fires when a chain starts. Passthrough hook for compat."""
        pass


# ---------------------------------------------------------------------------
# AsyncGovernanceCallbackHandler
# ---------------------------------------------------------------------------

class AsyncGovernanceCallbackHandler:
    """
    LangChain async callback handler that enforces governance policy.

    Same hooks as GovernanceCallbackHandler but all methods are async.
    Pass this handler when using async LangChain executors.

    Architectural note: Python LangChain has a separate AsyncCallbackHandler
    class hierarchy, unlike JS which uses a single class with optional async
    methods. This class mirrors that Python-native separation.

    BLOCKING CONTRACT: Same as GovernanceCallbackHandler. See module header.
    """

    name = "AsyncGovernanceCallbackHandler"

    def __init__(
        self,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list[str]] = None,
        raise_on_deny: bool = True,
        llm_start_deny_threshold: str = "high",
        _check_fn: Optional[CheckFnType] = None,
    ):
        if not governance_server_url:
            raise ValueError(
                "[AsyncGovernanceCallbackHandler] governance_server_url is required"
            )
        if not license_key:
            raise ValueError(
                "[AsyncGovernanceCallbackHandler] license_key is required"
            )

        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._llm_start_deny_threshold = llm_start_deny_threshold
        self._check_fn = _check_fn

    async def _check(self, body: dict) -> dict:
        """Run an asynchronous governance check."""
        return await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=body,
            check_fn=self._check_fn,
        )

    async def on_agent_action(
        self,
        action: Any,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Async version of on_agent_action. See GovernanceCallbackHandler."""
        tool_name = getattr(action, "tool", None) or getattr(action, "name", "unknown")
        tool_input = getattr(action, "tool_input", None)
        if tool_input is None:
            tool_input = getattr(action, "input", "")

        input_str = (
            tool_input
            if isinstance(tool_input, str)
            else str(tool_input)
        )

        result = await self._check(build_check_action_body(
            tool_name=tool_name,
            agent_name="langchain-callback-handler-async",
            framework_action="framework.langchain.agent_action",
            input_dict={"toolInput": input_str},
            message_preview=input_str[:200],
            pack_ids=self._pack_ids,
            extra_metadata={"toolName": tool_name, "inputPreview": input_str[:200]},
            source="on_agent_action",
        ))

        _enforce_decision(result, tool_name, self._raise_on_deny)

    async def on_tool_start(
        self,
        serialized: dict,
        input_str: str,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Async version of on_tool_start. See GovernanceCallbackHandler."""
        tool_name = (
            serialized.get("name")
            or (serialized.get("id") or ["unknown"])[-1]
        ) if serialized else "unknown"

        result = await self._check(build_check_action_body(
            tool_name=tool_name,
            agent_name="langchain-callback-handler-async",
            framework_action="framework.langchain.tool_invoke",
            input_dict={"toolInput": str(input_str)},
            message_preview=str(input_str)[:200],
            pack_ids=self._pack_ids,
            extra_metadata={"toolName": tool_name, "inputPreview": str(input_str)[:200]},
            source="on_tool_start",
        ))

        _enforce_decision(result, tool_name, self._raise_on_deny)

    async def on_llm_start(
        self,
        serialized: dict,
        prompts: list[str],
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Async version of on_llm_start. See GovernanceCallbackHandler."""
        detection = _detect_injection(prompts)
        if detection["detected"]:
            severity = detection["severity"]
            should_deny = severity == "high" or (
                self._llm_start_deny_threshold == "medium" and severity == "medium"
            )
            sys.stderr.write(
                f"[AsyncGovernanceCallbackHandler] prompt-injection:{severity} "
                f"on llm_start. patterns={detection['patterns']}\n"
            )
            if should_deny:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason=(
                            f"Prompt injection detected on LLM input "
                            f"(severity={severity}, "
                            f"patterns={detection['patterns']}). "
                            "Request blocked by connexum-governance "
                            "(Onyx #5 / OWASP LLM01)."
                        ),
                    )
                return

        llm_name = (
            serialized.get("name")
            or (serialized.get("id") or ["unknown"])[-1]
        ) if serialized else "unknown"
        message_preview = prompts[0][:200] if prompts else ""

        result = await self._check(build_check_action_body(
            tool_name=f"llm:{llm_name}",
            agent_name="langchain-callback-handler-async",
            framework_action="framework.langchain.llm_start",
            input_dict={"prompts": prompts},
            message_preview=message_preview,
            pack_ids=self._pack_ids,
            extra_metadata={"llmName": llm_name, "promptCount": len(prompts)},
            source="on_llm_start",
        ))

        _enforce_decision(result, llm_name, self._raise_on_deny)

    async def on_chain_end(
        self,
        outputs: dict,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Async chain_end. Audit log only, no raise."""
        sys.stderr.write(
            f"[AsyncGovernanceCallbackHandler] chain_end. "
            f"outputKeys={list(outputs.keys()) if outputs else []}\n"
        )

    async def on_agent_finish(
        self,
        finish: Any,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Fires when the agent finishes. Passthrough, no governance check."""
        pass

    async def on_chain_start(
        self,
        serialized: dict,
        inputs: dict,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Fires when a chain starts. Passthrough hook for compat."""
        pass


# ---------------------------------------------------------------------------
# GovernedTool -- wraps a LangChain Tool with governed _run() and _arun()
#
# This is the GUARANTEED BLOCKING PRIMITIVE.
#
# Unlike the callback handler (which LangChain may swallow), wrapping _run()
# ensures governance runs INSIDE the tool's invocation path, regardless of
# which LangChain executor or LangGraph ToolNode is in use.
# ---------------------------------------------------------------------------

class GovernedTool:
    """
    Wraps a LangChain tool so that _run() and _arun() run a governance check
    BEFORE delegating to the underlying tool implementation.

    This is the GUARANTEED BLOCKING path (unlike callback handlers which
    LangChain may swallow in some executor configurations).

    The returned object exposes .name, .description, .run(), .arun(),
    ._run(), ._arun(), and .invoke() -- compatible with LangChain's BaseTool
    duck-typing interface.

    Usage:
        from connexum_governance.integrations.langchain_integration import GovernedTool

        raw_tool = MyTool()  # any tool with .name and ._run()
        safe_tool = GovernedTool(
            tool=raw_tool,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
        )
        # Pass safe_tool to AgentExecutor's tools list
    """

    def __init__(
        self,
        tool: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list[str]] = None,
        raise_on_deny: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        if tool is None:
            raise ValueError("[GovernedTool] tool is required")
        tool_name = getattr(tool, "name", None)
        if not tool_name:
            raise ValueError("[GovernedTool] tool.name is required")
        if not governance_server_url:
            raise ValueError("[GovernedTool] governance_server_url is required")
        if not license_key:
            raise ValueError("[GovernedTool] license_key is required")

        self._underlying = tool
        self.name: str = tool_name
        self.description: str = getattr(tool, "description", "") or ""
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._check_fn = _check_fn

    def _governance_check_sync(self, input_str: str) -> dict:
        return _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name=self.name,
                agent_name=f"langchain-tool:{self.name}",
                framework_action="framework.langchain.tool_invoke",
                input_dict={"input": input_str},
                message_preview=input_str[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"toolName": self.name, "inputPreview": input_str[:200]},
                source="GovernedTool._run",
            ),
            check_fn=self._check_fn,
        )

    async def _governance_check_async(self, input_str: str) -> dict:
        return await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name=self.name,
                agent_name=f"langchain-tool:{self.name}",
                framework_action="framework.langchain.tool_invoke",
                input_dict={"input": input_str},
                message_preview=input_str[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"toolName": self.name, "inputPreview": input_str[:200]},
                source="GovernedTool._arun",
            ),
            check_fn=self._check_fn,
        )

    def _run(self, *args: Any, **kwargs: Any) -> str:
        """
        Governed _run(). Runs governance check before calling underlying tool.

        DENY -> raises GovernanceViolation (guaranteed blocking).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying tool._run().

        This is the GUARANTEED BLOCKING PRIMITIVE for sync tool invocations.
        """
        # Normalize input to string for governance check
        if args:
            input_str = str(args[0]) if not isinstance(args[0], str) else args[0]
        elif kwargs:
            import json as _json
            input_str = _json.dumps(kwargs)
        else:
            input_str = ""

        result = self._governance_check_sync(input_str)
        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "Tool call denied by governance policy"
            sys.stderr.write(
                f"[GovernedTool:{self.name}] _run DENIED. reason={reason}\n"
            )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return f"[GOVERNANCE DENIED] {reason}"

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
                return "[GOVERNANCE PENDING] Approval required but no approvalId returned"
            sys.stderr.write(
                f"[GovernedTool:{self.name}] _run PENDING. approvalId={approval_id}\n"
            )
            if self._raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )
            return f"[GOVERNANCE PENDING] approvalId={approval_id}"

        # ALLOW -- delegate to underlying tool
        underlying_run = getattr(self._underlying, "_run", None)
        if underlying_run is not None:
            return underlying_run(*args, **kwargs)
        # Fallback to invoke() or run() if _run not available
        invoke = getattr(self._underlying, "invoke", None)
        if invoke is not None:
            inp = args[0] if args else (kwargs.get("input") or "")
            return invoke(inp)
        raise AttributeError(
            f"[GovernedTool] Underlying tool '{self.name}' has no _run() or invoke() method"
        )

    async def _arun(self, *args: Any, **kwargs: Any) -> str:
        """
        Governed _arun(). Async version of _run().

        DENY -> raises GovernanceViolation (guaranteed blocking).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying tool._arun() or _run().

        This is the GUARANTEED BLOCKING PRIMITIVE for async tool invocations.
        """
        if args:
            input_str = str(args[0]) if not isinstance(args[0], str) else args[0]
        elif kwargs:
            import json as _json
            input_str = _json.dumps(kwargs)
        else:
            input_str = ""

        result = await self._governance_check_async(input_str)
        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "Tool call denied by governance policy"
            sys.stderr.write(
                f"[GovernedTool:{self.name}] _arun DENIED. reason={reason}\n"
            )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return f"[GOVERNANCE DENIED] {reason}"

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
                return "[GOVERNANCE PENDING] Approval required but no approvalId returned"
            sys.stderr.write(
                f"[GovernedTool:{self.name}] _arun PENDING. approvalId={approval_id}\n"
            )
            if self._raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )
            return f"[GOVERNANCE PENDING] approvalId={approval_id}"

        # ALLOW -- delegate to underlying tool
        underlying_arun = getattr(self._underlying, "_arun", None)
        if underlying_arun is not None:
            return await underlying_arun(*args, **kwargs)
        underlying_run = getattr(self._underlying, "_run", None)
        if underlying_run is not None:
            return underlying_run(*args, **kwargs)
        invoke = getattr(self._underlying, "invoke", None)
        if invoke is not None:
            inp = args[0] if args else (kwargs.get("input") or "")
            return invoke(inp)
        raise AttributeError(
            f"[GovernedTool] Underlying tool '{self.name}' has no _arun(), _run(), or invoke() method"
        )

    def run(self, *args: Any, **kwargs: Any) -> str:
        """Public run() -- delegates to _run() (same governance check)."""
        return self._run(*args, **kwargs)

    async def arun(self, *args: Any, **kwargs: Any) -> str:
        """Public arun() -- delegates to _arun() (same governance check)."""
        return await self._arun(*args, **kwargs)

    def invoke(self, input: Any, config: Any = None, **kwargs: Any) -> str:
        """invoke() compatibility shim (langchain-core 0.2.x interface)."""
        return self._run(input)

    async def ainvoke(self, input: Any, config: Any = None, **kwargs: Any) -> str:
        """ainvoke() compatibility shim (async langchain-core 0.2.x interface)."""
        return await self._arun(input)


# ---------------------------------------------------------------------------
# governed_tool -- convenience factory function
# ---------------------------------------------------------------------------

def governed_tool(
    tool: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list[str]] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedTool:
    """
    Factory function to create a GovernedTool wrapping any LangChain tool.

    Provides defense-in-depth for direct tool._run() calls that bypass the
    agent callback system (e.g. when tools are invoked outside an AgentExecutor,
    or in LangGraph ToolNode configurations that do not fire callbacks).

    Args:
        tool: The LangChain tool to wrap (must have .name and ._run()).
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedTool instance wrapping the provided tool.
    """
    return GovernedTool(
        tool=tool,
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )


# ---------------------------------------------------------------------------
# as_governed_tool -- decorator for tool functions
# ---------------------------------------------------------------------------

def as_governed_tool(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list[str]] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Callable:
    """
    Decorator that wraps a tool class or tool function with governance.

    Usage:
        @as_governed_tool(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
        )
        class MySearchTool(BaseTool):
            name = "web_search"
            ...

    Returns:
        A decorator that wraps the target class/function in a GovernedTool.
    """
    def decorator(tool_or_class: Any) -> GovernedTool:
        # If decorating a class, instantiate it first
        instance = tool_or_class() if isinstance(tool_or_class, type) else tool_or_class
        return GovernedTool(
            tool=instance,
            governance_server_url=governance_server_url,
            license_key=license_key,
            pack_ids=pack_ids,
            raise_on_deny=raise_on_deny,
            _check_fn=_check_fn,
        )
    return decorator


# ---------------------------------------------------------------------------
# wrap_agent_executor
# ---------------------------------------------------------------------------

def wrap_agent_executor(
    executor: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list[str]] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Injects a GovernanceCallbackHandler into a LangChain AgentExecutor's
    callbacks list. Returns the same executor instance with governance wired.

    Usage:
        executor = AgentExecutor(agent=agent, tools=tools)
        executor = wrap_agent_executor(
            executor,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
        )
        result = executor.invoke({"input": "What is the weather?"})

    BLOCKING GUARANTEE:
        Callback raises propagate through AgentExecutor in langchain 0.2.x when
        the handler is registered on the executor (not via runnable config).
        This is NOT guaranteed across all LangChain versions.
        Use GovernedTool for guaranteed blocking regardless of LangChain version.

    Args:
        executor: LangChain AgentExecutor with a .callbacks attribute.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same executor with GovernanceCallbackHandler injected.
    """
    handler = GovernanceCallbackHandler(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )

    if not hasattr(executor, "callbacks") or executor.callbacks is None:
        executor.callbacks = []

    # Avoid double-injection if wrap_agent_executor is called multiple times
    already_injected = any(
        isinstance(cb, GovernanceCallbackHandler)
        for cb in executor.callbacks
    )
    if not already_injected:
        executor.callbacks.append(handler)

    return executor


# ---------------------------------------------------------------------------
# wrap_state_graph (LangGraph) -- THIN RE-EXPORT
#
# The canonical implementation has moved to langgraph_integration.py which
# provides the full dedicated LangGraph adapter:
#   - per-node governance (guaranteed, one check per node turn)
#   - compile-level Pregel invoke/ainvoke governance
#   - conditional edge transition governance
#   - GovernedStateGraph proxy class for clean construction workflows
#
# This function is kept here for backwards compatibility: existing customer
# code importing wrap_state_graph from langchain_integration continues to
# work without changes.
#
# Customers using LangGraph standalone (without other LangChain primitives)
# should import directly from langgraph_integration for the richer API.
#
# DEPRECATION: In a future release, this re-export will be removed.
# Migrate to: from connexum_governance.integrations.langgraph_integration import wrap_state_graph
# ---------------------------------------------------------------------------

def wrap_state_graph(
    graph: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list[str]] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Injects governance into a LangGraph StateGraph.

    DEPRECATED THIN RE-EXPORT: This function now delegates to the dedicated
    LangGraph adapter (langgraph_integration.wrap_state_graph). Existing
    customers are not broken -- this signature is fully compatible.

    For new code, import directly from the dedicated adapter:

        from connexum_governance.integrations.langgraph_integration import (
            wrap_state_graph,
            GovernedStateGraph,
            create_governed_langgraph,
        )

    The dedicated adapter adds per-node governance, compile-level Pregel
    governance, and conditional edge transition governance beyond what this
    re-export previously provided.

    IMPORTANT: action namespaces have changed in the dedicated adapter:
      OLD (LangChain adapter):  'framework.langchain.graph.tool_node'
      NEW (LangGraph adapter):  'framework.langgraph.tool_node'
                                'framework.langgraph.node_execute'
                                'framework.langgraph.invoke'

    If your compliance pack rules target 'framework.langchain.graph.tool_node',
    update them to target 'framework.langgraph.tool_node' for the new adapter.

    Args:
        graph: LangGraph StateGraph with an .add_node() method.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same StateGraph with add_node() and compile() wrapped.
    """
    from connexum_governance.integrations.langgraph_integration import (
        wrap_state_graph as _langgraph_wrap_state_graph,
    )
    return _langgraph_wrap_state_graph(
        graph=graph,
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )


# ---------------------------------------------------------------------------
# create_governed_langchain -- primary public factory
# ---------------------------------------------------------------------------

@dataclass
class GovernedLangChainInstance:
    """
    Governed LangChain object returned by create_governed_langchain.

    Exposes all integration helpers for the LangChain framework adapter.
    """

    callback_handler: "GovernanceCallbackHandler"
    """
    Drop-in GovernanceCallbackHandler for any executor's callbacks list.
    Provides observability + best-effort blocking.
    See CRITICAL ARCHITECTURAL NOTE in module header.
    """

    async_callback_handler: "AsyncGovernanceCallbackHandler"
    """
    Async GovernanceCallbackHandler for async executor callbacks lists.
    """

    _governance_server_url: str
    _license_key: str
    _pack_ids: list
    _raise_on_deny: bool
    _check_fn: Optional[CheckFnType]

    def governed_tool(self, tool: Any) -> GovernedTool:
        """
        Wrap a single LangChain tool with governed _run() / _arun().
        GUARANTEED BLOCKING: governance check runs before tool execution.
        """
        return GovernedTool(
            tool=tool,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_agent(self, executor: Any) -> Any:
        """
        Inject governance callback handler into a LangChain AgentExecutor.
        Returns the same executor with handler wired.
        """
        return wrap_agent_executor(
            executor=executor,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_graph(self, graph: Any) -> Any:
        """
        Inject governance into a LangGraph StateGraph.

        Delegates to langgraph_integration.wrap_state_graph (the canonical
        implementation). Wraps add_node() and compile() for per-node and
        per-invocation governance.

        For the full dedicated LangGraph API (including conditional edge
        governance and GovernedStateGraph proxy), use:
            from connexum_governance.integrations.langgraph_integration import (
                create_governed_langgraph,
            )
        """
        return wrap_state_graph(
            graph=graph,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )


def create_governed_langchain(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list[str]] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedLangChainInstance:
    """
    Primary factory for the LangChain governance adapter.

    Returns a GovernedLangChainInstance exposing all integration helpers.

    Usage:
        gov = create_governed_langchain(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        # Option 1 (guaranteed blocking): wrap individual tools
        safe_search = gov.governed_tool(search_tool)
        executor = AgentExecutor(agent=agent, tools=[safe_search])

        # Option 2 (defense-in-depth): wrap the entire executor
        executor = gov.wrap_agent(executor)

        # Option 3 (LangGraph): wrap the state graph
        graph = gov.wrap_graph(state_graph)

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedLangChainInstance with all integration helpers.
    """
    callback_handler = GovernanceCallbackHandler(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )
    async_callback_handler = AsyncGovernanceCallbackHandler(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )

    return GovernedLangChainInstance(
        callback_handler=callback_handler,
        async_callback_handler=async_callback_handler,
        _governance_server_url=governance_server_url,
        _license_key=license_key,
        _pack_ids=pack_ids or [],
        _raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )
