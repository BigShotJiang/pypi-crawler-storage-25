"""LangGraph integration for Connexum governance.

Provides a GovernanceTool that wraps any LangChain tool with
pre-execution governance checks. Works with LangGraph's ToolNode.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations import GovernanceTool
    from langchain_community.tools import ShellTool

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    shell = GovernanceTool(
        wrapped_tool=ShellTool(),
        client=gov,
        agent_name="research-agent",
    )
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Optional

from connexum_governance.client import AsyncGovernanceClient, GovernanceClient
from connexum_governance.models import AgentIdentity


class GovernanceTool:
    """Wraps a LangChain BaseTool with governance enforcement.

    Intercepts invoke/ainvoke to run check_action before the tool
    executes and report_result after.

    Works with any tool that has .name and .invoke() / .ainvoke().
    """

    def __init__(
        self,
        wrapped_tool: Any,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        _async_client: Optional[AsyncGovernanceClient] = None,
    ):
        self.wrapped_tool = wrapped_tool
        self.client = client
        self._async_client = _async_client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)

        # Proxy attributes so LangGraph sees this as a valid tool
        self.name = wrapped_tool.name
        self.description = getattr(wrapped_tool, "description", "")
        self.args_schema = getattr(wrapped_tool, "args_schema", None)

    @property
    def tool_name(self) -> str:
        return self.wrapped_tool.name

    def invoke(self, input: Any, config: Any = None, **kwargs: Any) -> Any:
        """Synchronous invoke with governance check."""
        tool_input = input if isinstance(input, dict) else {"input": str(input)}

        decision = self.client.check_action(
            tool=f"tool.{self.tool_name}",
            input=tool_input,
            agent=self.agent,
        )

        if decision.denied:
            return f"[GOVERNANCE DENIED] {decision.reason}"

        if decision.requires_approval:
            return (
                f"[GOVERNANCE PENDING] Action requires approval. "
                f"Audit ID: {decision.audit_id}"
            )

        start = time.monotonic()
        error_msg = None
        try:
            result = self.wrapped_tool.invoke(input, config, **kwargs)
            return result
        except Exception as exc:
            error_msg = str(exc)
            raise
        finally:
            elapsed_ms = int((time.monotonic() - start) * 1000)
            if decision.audit_id:
                try:
                    self.client.report_result(
                        audit_id=decision.audit_id,
                        success=error_msg is None,
                        summary=str(result)[:200] if error_msg is None else "",
                        duration_ms=elapsed_ms,
                        error=error_msg,
                    )
                except Exception as exc:  # H2: never swallow -- always log
                    import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)  # Don't fail the tool call over reporting

    async def ainvoke(self, input: Any, config: Any = None, **kwargs: Any) -> Any:
        """Async invoke with governance check.

        If an AsyncGovernanceClient was provided via _async_client, uses it
        for non-blocking governance checks. Otherwise, runs the sync client
        in a thread executor to avoid blocking the event loop.
        """
        tool_input = input if isinstance(input, dict) else {"input": str(input)}

        if self._async_client is not None:
            decision = await self._async_client.check_action(
                tool=f"tool.{self.tool_name}",
                input=tool_input,
                agent=self.agent,
            )
        else:
            loop = asyncio.get_event_loop()
            decision = await loop.run_in_executor(
                None,
                lambda: self.client.check_action(
                    tool=f"tool.{self.tool_name}",
                    input=tool_input,
                    agent=self.agent,
                ),
            )

        if decision.denied:
            return f"[GOVERNANCE DENIED] {decision.reason}"

        if decision.requires_approval:
            return (
                f"[GOVERNANCE PENDING] Action requires approval. "
                f"Audit ID: {decision.audit_id}"
            )

        start = time.monotonic()
        error_msg = None
        try:
            if hasattr(self.wrapped_tool, "ainvoke"):
                result = await self.wrapped_tool.ainvoke(input, config, **kwargs)
            else:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: self.wrapped_tool.invoke(input, config, **kwargs),
                )
            return result
        except Exception as exc:
            error_msg = str(exc)
            raise
        finally:
            elapsed_ms = int((time.monotonic() - start) * 1000)
            if decision.audit_id:
                try:
                    if self._async_client is not None:
                        await self._async_client.report_result(
                            audit_id=decision.audit_id,
                            success=error_msg is None,
                            summary=str(result)[:200] if error_msg is None else "",
                            duration_ms=elapsed_ms,
                            error=error_msg,
                        )
                    else:
                        loop = asyncio.get_event_loop()
                        await loop.run_in_executor(
                            None,
                            lambda: self.client.report_result(
                                audit_id=decision.audit_id,
                                success=error_msg is None,
                                summary=str(result)[:200] if error_msg is None else "",
                                duration_ms=elapsed_ms,
                                error=error_msg,
                            ),
                        )
                except Exception as exc:  # H2: never swallow -- always log
                    import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)  # Don't fail the tool call over reporting
