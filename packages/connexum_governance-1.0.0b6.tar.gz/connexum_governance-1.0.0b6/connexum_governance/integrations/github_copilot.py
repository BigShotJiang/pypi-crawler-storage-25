"""GitHub Copilot classic governance integration.

Governs GitHub Copilot classic: the autocomplete + Copilot Chat surface
inside VS Code, JetBrains IDEs, Vim, and Visual Studio. Distinct from
Copilot Workspace, which is the agentic PR-level surface
(see copilot_workspace.py).

Architecture:
  The primary adapter is TypeScript-native (`src/ide-adapters/github-copilot.ts`).
  This Python shim lets a Python-hosted governance policy server participate
  in the Copilot decision loop via HTTP.

  Two principal surfaces:
    intercept_completion(request) -- pre/post-completion gate + ingress scan
    intercept_chat(request)       -- pre/post-chat gate + ingress scan

Copilot deployment flavours:
  'individual'  -- prompts may be retained for training. NOT BAA-eligible.
                   BLOCKED under HIPAA binding (PT-ADAPT-GHCOPILOT-3).
  'business'    -- prompt retention disabled by default. BAA-eligible.
  'enterprise'  -- enterprise-level data commitments. BAA-eligible.

Key governance actions (mirror of TS adapter):
  PT-ADAPT-GHCOPILOT-1: pre-completion secret scan on surrounding context
  PT-ADAPT-GHCOPILOT-2: post-completion ingress secret scan
  PT-ADAPT-GHCOPILOT-3: Copilot Individual blocked under HIPAA binding

Provider: OpenAI (GitHub Copilot backend).

DEFERRED-COPILOT-EDITOR-SHIMS: Editor-specific shims (VS Code, JetBrains,
Vim, Visual Studio) are deferred. This adapter is editor-agnostic and
receives normalised events from a thin shim per editor.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.github_copilot import GitHubCopilotGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = GitHubCopilotGovernance(
        client=gov,
        agent_name="copilot-agent",
        pack_binding=["soc2"],
        copilot_flavour="business",
    )

    decision = adapter.intercept_completion({
        "filePath": "/workspace/api.py",
        "surroundingContext": "def process_order(",
        "packBinding": ["soc2"],
        "direction": "pre",
    })

    decision = adapter.intercept_chat({
        "promptText": "Explain this function",
        "packBinding": ["soc2"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Literal, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Copilot flavour constants
# ---------------------------------------------------------------------------

CopilotFlavour = Literal["individual", "business", "enterprise"]

COPILOT_DATA_RETENTION: dict[str, str] = {
    "individual": "prompts-may-be-retained-for-training",
    "business":   "prompt-retention-disabled-by-default",
    "enterprise": "enterprise-level-data-commitments",
}

# Flavours that carry a BAA-eligible data-processing agreement
COPILOT_BAA_ELIGIBLE_FLAVOURS = frozenset({"business", "enterprise"})

# ---------------------------------------------------------------------------
# Pen-test IDs mirrored from TS adapter
# ---------------------------------------------------------------------------
# PT-ADAPT-GHCOPILOT-1: pre-completion secret scan on surrounding context
# PT-ADAPT-GHCOPILOT-2: post-completion ingress secret scan
# PT-ADAPT-GHCOPILOT-3: Copilot Individual blocked under HIPAA binding

# ---------------------------------------------------------------------------
# Secret patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",          re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT (classic)",    re.compile(r"ghp_[0-9A-Za-z]{36}")),
    ("GitHub fine-grained PAT", re.compile(r"github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",       re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",          re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("OAuth bearer token",      re.compile(r"Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
    ("Generic secret env var",  re.compile(r"(SECRET|PASSWORD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Database URL with creds", re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("Private key header",      re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Azure SAS token",         re.compile(r"sig=[0-9A-Za-z%+/]{20,}")),
    ("Stripe secret key",       re.compile(r"sk_live_[0-9A-Za-z]{24,}")),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bsocial[_\s]?security\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\bdob\b"),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_for_phi(text: str) -> Optional[str]:
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(p.lower() in ("hipaa", "hitech") for p in pack_binding)


# ---------------------------------------------------------------------------
# GitHubCopilotGovernance
# ---------------------------------------------------------------------------

class GitHubCopilotGovernance(BaseGovernanceIntegration):
    """REST-client shim for GitHub Copilot classic governance.

    GitHub Copilot is TypeScript-native. This Python shim participates in
    the decision loop by:
      1. Gating completion requests (intercept_completion)
      2. Gating chat requests (intercept_chat)
      3. Enforcing flavour compliance (individual blocked under HIPAA)
      4. Providing policy_bridge() for Python policy participation

    Provider: OpenAI (Copilot backend).
    Flavour compliance: individual blocked under HIPAA (PT-ADAPT-GHCOPILOT-3).
    """

    _FRAMEWORK_NAME = "github-copilot"
    _LAYER_NAME = "github-copilot-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        copilot_flavour: CopilotFlavour = "business",
        content_exclusion_paths: Optional[list[str]] = None,
        hipaa_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            copilot_flavour: Copilot deployment flavour (individual/business/enterprise).
            content_exclusion_paths: File path prefixes to exclude from Copilot context.
            hipaa_reviewer_tier: Reviewer tier for HIPAA-bound violations.
        """
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.copilot_flavour: CopilotFlavour = copilot_flavour
        self.content_exclusion_paths = content_exclusion_paths or []
        self.hipaa_reviewer_tier = hipaa_reviewer_tier

    # ------------------------------------------------------------------
    # intercept_completion -- pre/post-completion gate + ingress scan
    # ------------------------------------------------------------------

    def intercept_completion(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a GitHub Copilot completion event.

        Handles both pre-completion (outbound gate) and post-completion
        (ingress scan) directions based on request['direction']:
          'pre'  -- gate the outbound completion request (default)
          'post' -- scan the incoming completion text for secrets

        Guards applied for 'pre' direction:
          1. Pack-binding primacy
          2. Content Exclusion path check
          3. Secret scan on surrounding context (PT-ADAPT-GHCOPILOT-1)
          4. PHI proximity check under HIPAA
          5. Flavour compliance (individual blocked under HIPAA, PT-ADAPT-GHCOPILOT-3)

        Guards applied for 'post' direction:
          1. Pack-binding primacy
          2. Secret scan on completion text (PT-ADAPT-GHCOPILOT-2)

        Args:
            request: Completion request dict with keys:
                     filePath, surroundingContext, completionText (post only),
                     direction ('pre'|'post'), packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        direction = str(request.get("direction", "pre"))
        file_path = str(request.get("filePath", request.get("file_path", "")))
        surrounding_context = str(request.get("surroundingContext", request.get("context", "")))
        completion_text = str(request.get("completionText", request.get("completion", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "GitHub Copilot completion request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
                pack_binding=pack_binding,
            )

        if direction == "post":
            # PT-ADAPT-GHCOPILOT-2: post-completion ingress scan
            secret_match = _scan_for_secrets(completion_text)
            if secret_match:
                return self._deny(
                    agent_id,
                    f"Completion response blocked: secret pattern '{secret_match}' "
                    "found in completion text. GitHub Copilot has historically surfaced "
                    "API keys from training data. This completion will not be surfaced.",
                    pack_binding=pack_binding,
                )
            return self.emit_event("toolResult", {
                "agentId": agent_id,
                "toolName": "copilot:completion-received",
                "result": completion_text[:100],
                "packBinding": pack_binding,
            })

        # 'pre' direction -- PT-ADAPT-GHCOPILOT-1

        # 1. Content Exclusion path check
        exclusion = self._check_content_exclusion(file_path)
        if exclusion:
            return self._deny(
                agent_id,
                f"File '{file_path}' matches a Content Exclusion path "
                f"configured in the pack binding ({exclusion}). "
                "Completion request blocked.",
                pack_binding=pack_binding,
            )

        # 2. Secret scan on surrounding context
        secret_match = _scan_for_secrets(surrounding_context)
        if secret_match:
            return self._deny(
                agent_id,
                f"Completion request blocked: secret pattern '{secret_match}' "
                f"detected in surrounding code context ({file_path}). "
                "Remove the secret from context before requesting a completion.",
                pack_binding=pack_binding,
            )

        # 3. PHI proximity check under HIPAA
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(surrounding_context)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "copilot",
                    "messageCount": 0,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Completion request routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' found in surrounding context ({file_path}). "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                    "filePath": file_path,
                })

            # 4. Flavour compliance under HIPAA (PT-ADAPT-GHCOPILOT-3)
            if self.copilot_flavour not in COPILOT_BAA_ELIGIBLE_FLAVOURS:
                return self._deny(
                    agent_id,
                    f"GitHub Copilot flavour '{self.copilot_flavour}' is not BAA-eligible "
                    f"under HIPAA binding. "
                    f"Upgrade to Copilot Business or Copilot Enterprise to use Copilot "
                    "in a HIPAA-regulated context. "
                    f"Retention posture: {COPILOT_DATA_RETENTION.get(self.copilot_flavour, 'unknown')}.",
                    pack_binding=pack_binding,
                )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "copilot",
            "messageCount": 0,
            "packBinding": pack_binding,
            "filePath": file_path,
            "completionRequest": True,
        })

    # ------------------------------------------------------------------
    # intercept_chat -- pre/post-chat gate + ingress scan
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a GitHub Copilot Chat event.

        Handles both pre-chat (outbound gate) and post-chat (ingress scan)
        directions based on request['direction']:
          'pre'  -- gate the outbound chat request (default)
          'post' -- scan the incoming chat response for secrets

        Guards applied for 'pre' direction:
          1. Pack-binding primacy
          2. Secret scan on prompt text
          3. Content Exclusion check on attached files
          4. PHI proximity check under HIPAA
          5. Flavour compliance (individual blocked under HIPAA)

        Args:
            request: Chat request dict with keys:
                     promptText, responseText (post only), attachedFilePaths,
                     direction ('pre'|'post'), packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        direction = str(request.get("direction", "pre"))
        prompt_text = str(request.get("promptText", request.get("prompt", "")))
        response_text = str(request.get("responseText", request.get("response", "")))
        attached_file_paths: list[str] = list(request.get("attachedFilePaths", []))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "GitHub Copilot chat request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
                pack_binding=pack_binding,
            )

        if direction == "post":
            # Post-chat ingress: scan response for secrets
            secret_match = _scan_for_secrets(response_text)
            if secret_match:
                return self._deny(
                    agent_id,
                    f"Chat response blocked: secret pattern '{secret_match}' "
                    "found in response text.",
                    pack_binding=pack_binding,
                )
            return self.emit_event("llmResult", {
                "agentId": agent_id,
                "model": "copilot",
                "responseText": response_text[:100],
                "packBinding": pack_binding,
            })

        # 'pre' direction

        # 1. Secret scan on prompt text
        secret_match = _scan_for_secrets(prompt_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Chat request blocked: secret pattern '{secret_match}' "
                "detected in prompt text.",
                pack_binding=pack_binding,
            )

        # 2. Content Exclusion check on attached files
        for fp in attached_file_paths:
            exclusion = self._check_content_exclusion(fp)
            if exclusion:
                return self._deny(
                    agent_id,
                    f"Chat request blocked: attached file '{fp}' matches Content "
                    f"Exclusion path '{exclusion}'. Remove the file from context.",
                    pack_binding=pack_binding,
                )

        # 3. PHI proximity check under HIPAA
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(prompt_text)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "copilot",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Chat request routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' found in prompt. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

            # 4. Flavour compliance under HIPAA (PT-ADAPT-GHCOPILOT-3)
            if self.copilot_flavour not in COPILOT_BAA_ELIGIBLE_FLAVOURS:
                return self._deny(
                    agent_id,
                    f"GitHub Copilot flavour '{self.copilot_flavour}' is not BAA-eligible "
                    f"under HIPAA binding. "
                    "Upgrade to Copilot Business or Copilot Enterprise.",
                    pack_binding=pack_binding,
                )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "copilot",
            "messageCount": 1,
            "packBinding": pack_binding,
            "chatRequest": True,
            "attachedFilePaths": attached_file_paths,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API (M2: delegates to base)."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown GitHubCopilot event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] GitHubCopilot output classifier: possible secret in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] GitHubCopilot output exfiltration scanner: possible "
                    f'secret/PHI in LLM response (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Inject Copilot flavour metadata and delegate to base
        enriched = {"copilotFlavour": self.copilot_flavour, **payload}
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload and forward it as a canonical governance event."""
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError(
                "GitHubCopilot webhook payload missing required field: 'eventType'"
            )
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError(
                "GitHubCopilot webhook payload missing required field: 'agentId'"
            )
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "GitHubCopilotPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return GitHubCopilotPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _check_content_exclusion(self, file_path: str) -> Optional[str]:
        """Check if file_path matches any Content Exclusion path. Returns the matching path or None."""
        if not file_path:
            return None
        for pattern in self.content_exclusion_paths:
            if file_path.startswith(pattern) or pattern in file_path:
                return pattern
        return None

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# GitHubCopilotPolicyBridge
# ---------------------------------------------------------------------------

class GitHubCopilotPolicyBridge:
    """Bridge for Python-hosted policy participation in the GitHub Copilot loop."""

    def __init__(
        self,
        adapter: GitHubCopilotGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
