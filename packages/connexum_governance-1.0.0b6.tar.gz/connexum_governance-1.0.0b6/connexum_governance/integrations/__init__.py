"""Framework integration wrappers for AI orchestrators and LLM providers."""

from connexum_governance.integrations.langgraph import GovernanceTool
from connexum_governance.integrations.crewai import GovernanceCallback
from connexum_governance.integrations.autogen import GovernanceGuardrail

# LLM provider integrations (Batch 1)
from connexum_governance.integrations.anthropic import AnthropicGovernance
from connexum_governance.integrations.openai import OpenAIGovernance
from connexum_governance.integrations.gemini import GeminiGovernance
from connexum_governance.integrations.azure_openai import AzureOpenAIGovernance
from connexum_governance.integrations.bedrock import BedrockGovernance
from connexum_governance.integrations.ollama import OllamaGovernance
from connexum_governance.integrations.cody import CodyGovernedClient, CodyPolicyBridge
from connexum_governance.integrations.tabnine import TabnineGovernedClient, TabninePolicyBridge
from connexum_governance.integrations.windsurf import WindsurfGovernedClient, WindsurfPolicyBridge
from connexum_governance.integrations.replit_agent import ReplitAgentGovernedClient, ReplitAgentPolicyBridge
from connexum_governance.integrations.copilot_studio import CopilotStudioGovernedClient, CopilotStudioPolicyBridge
from connexum_governance.integrations.aider import AiderGovernedClient, AiderPolicyBridge
from connexum_governance.integrations.zed_ai import ZedAIGovernedClient, ZedAIPolicyBridge
from connexum_governance.integrations.notebook_ai import NotebookAIGovernedClient, NotebookAIPolicyBridge

# F-NEW-CRIT-4 (2026-05-02): added DeepSeek, HuggingFace, Replicate
# wrappers so the README's "wraps any LLM platform" claim covers the
# Python SDK too. Each adapter is BAA: false; pack-level
# blockedProviders policy still enforces blocks for regulated workflows.
from connexum_governance.integrations.deepseek import DeepSeekGovernance
from connexum_governance.integrations.huggingface import (
    GovernedHuggingFace,
    GovernedHuggingFaceProxy,
    HuggingFaceGovernance,  # backward-compat alias
)
from connexum_governance.integrations.replicate import ReplicateGovernance

# Orchestrator integrations (Batch 2a)
from connexum_governance.integrations.langchain import GovernanceCallbackHandler

# LangChain framework adapter (Sprint 5, WS-06) -- mirrors governed-langchain.ts
from connexum_governance.integrations.langchain_integration import (
    GovernanceCallbackHandler as LangChainGovernanceCallbackHandler,
    AsyncGovernanceCallbackHandler,
    GovernedTool,
    governed_tool,
    as_governed_tool,
    wrap_agent_executor,
    wrap_state_graph,
    create_governed_langchain,
)
from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation as LangChainGovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations.claude_agent_sdk import (
    ClaudeAgentGovernance,
    PhantomAgentError,
    SubscriptionGateError,
    UnboundDataError,
)
from connexum_governance.integrations.google_adk import GoogleAdkGovernance, BaaRegionError
from connexum_governance.integrations.bedrock_agentcore import (
    BedrockAgentCoreGovernance,
    BedrockBaaRegionError,
)
from connexum_governance.integrations.haystack import HaystackGovernance
from connexum_governance.integrations.llamaindex import LlamaIndexGovernance

# OpenAI Agents SDK framework adapter (Sprint 5, WS-08) -- guardrail-native blocking
from connexum_governance.integrations.openai_agents_integration import (
    GovernanceInputGuardrail,
    GovernanceOutputGuardrail,
    GovernanceAgentHooks,
    governed_function_tool,
    wrap_agent as wrap_openai_agent,
    create_governed_openai_agents,
)

# LlamaIndex framework adapter (Sprint 5, WS-09) -- FunctionTool.__call__ blocking
from connexum_governance.integrations.llama_index_integration import (
    GovernanceLlamaIndexCallback,
    GovernedFunctionTool as LlamaIndexGovernedFunctionTool,
    GovernedQueryEngineProxy,
    GovernedChatEngineProxy,
    governed_function_tool as llama_index_governed_function_tool,
    wrap_query_engine,
    wrap_chat_engine,
    wrap_agent_worker,
    create_governed_llama_index,
    GovernedLlamaIndexInstance,
)

# AutoGen v0.4 framework adapter (Sprint 5, WS-10) -- FunctionTool.run() blocking
from connexum_governance.integrations.autogen_integration import (
    GovernedAutoGenTool,
    governed_autogen_tool,
    wrap_chat_agent as wrap_autogen_agent,
    wrap_group_chat as wrap_autogen_group_chat,
    create_governed_autogen,
    GovernedAutoGenInstance,
)

# LangGraph standalone adapter (Sprint 5, WS-10) -- per-node + compile-level blocking
from connexum_governance.integrations.langgraph_integration import (
    GovernedStateGraph,
    wrap_state_graph as langgraph_wrap_state_graph,
    wrap_pregel,
    create_governed_langgraph,
    GovernedLangGraphInstance,
)

# Pydantic AI framework adapter (Sprint 5, WS-13) -- tool decorator + run wrap blocking
from connexum_governance.integrations.pydantic_ai_integration import (
    governed_tool_decorator as pydantic_ai_governed_tool_decorator,
    governed_tool_plain_decorator,
    wrap_agent_run as wrap_pydantic_ai_agent_run,
    wrap_agent as wrap_pydantic_ai_agent,
    GovernedAgentResult,
    create_governed_pydantic_ai,
    GovernedPydanticAIInstance,
)

# Haystack v2 framework adapter (Sprint 5, WS-13) -- pipeline + component + tool blocking
from connexum_governance.integrations.haystack_integration import (
    GovernedComponent as HaystackGovernedComponent,
    governed_component as haystack_governed_component,
    wrap_pipeline as wrap_haystack_pipeline,
    wrap_tool_invoker as wrap_haystack_tool_invoker,
    wrap_generator as wrap_haystack_generator,
    create_governed_haystack,
    GovernedHaystackInstance,
)

# CrewAI framework adapter (Sprint 5, WS-09) -- BaseTool._run() blocking
from connexum_governance.integrations.crewai_integration import (
    GovernanceCrewAITool,
    governed_crewai_tool,
    make_governance_step_callback,
    make_governance_task_callback,
    wrap_agent as wrap_crewai_agent,
    wrap_crew,
    create_governed_crewai,
    GovernedCrewAIInstance,
)

# Orchestrator integrations (Batch 2b)
from connexum_governance.integrations.openai_agents import (
    OpenAIAgentsGovernance,
    OpenAIAgentsHandoffDeniedError,
    OpenAIAgentsMaxTurnsError,
)
from connexum_governance.integrations.semantic_kernel import (
    SemanticKernelGovernance,
    SKGovernanceFilterShim,
    SKFunctionNotFoundError,
    SKMemoryAccessDeniedError,
)
from connexum_governance.integrations.deepagents import (
    DeepAgentsGovernance,
    DeepAgentsPolicyBridge,
    DeepAgentsUnboundDataError,
)
from connexum_governance.integrations.openclaw import (
    OpenClawGovernance,
    OpenClawPolicyBridge,
    OpenClawMemoryPhiError,
    OpenClawUnsanctionedWorkspaceError,
)
from connexum_governance.integrations.paperclip import (
    PaperclipGovernance,
    PaperclipPolicyBridge,
    PaperclipTaskTypeError,
    PaperclipPlanStepsError,
)

# IDE integrations (Batch 3 -- Python parity)
from connexum_governance.integrations.claude_code import (
    ClaudeCodeGovernance,
    ClaudeCodePolicyBridge,
)
from connexum_governance.integrations.continue_dev import (
    ContinueDevGovernance,
    ContinueDevPolicyBridge,
)
from connexum_governance.integrations.copilot_workspace import (
    CopilotWorkspaceGovernance,
    CopilotWorkspacePolicyBridge,
)
from connexum_governance.integrations.cursor import (
    CursorGovernance,
    CursorPolicyBridge,
)
from connexum_governance.integrations.github_copilot import (
    GitHubCopilotGovernance,
    GitHubCopilotPolicyBridge,
)
from connexum_governance.integrations.jetbrains_ai import (
    JetBrainsAIGovernance,
    JetBrainsAIPolicyBridge,
)
from connexum_governance.integrations.amazon_q_developer import (
    AmazonQDeveloperGovernance,
    AmazonQDeveloperPolicyBridge,
)

__all__ = [
    # Original orchestrator integrations (Batch 0)
    "GovernanceTool",
    "GovernanceCallback",
    "GovernanceGuardrail",
    # LangChain framework adapter (Sprint 5, WS-06)
    "LangChainGovernanceCallbackHandler",
    "AsyncGovernanceCallbackHandler",
    "GovernedTool",
    "governed_tool",
    "as_governed_tool",
    "wrap_agent_executor",
    "wrap_state_graph",
    "create_governed_langchain",
    "LangChainGovernanceViolation",
    "GovernancePendingApproval",
    # OpenAI Agents SDK framework adapter (Sprint 5, WS-08)
    "GovernanceInputGuardrail",
    "GovernanceOutputGuardrail",
    "GovernanceAgentHooks",
    "governed_function_tool",
    "wrap_openai_agent",
    "create_governed_openai_agents",
    # LlamaIndex framework adapter (Sprint 5, WS-09)
    "GovernanceLlamaIndexCallback",
    "LlamaIndexGovernedFunctionTool",
    "GovernedQueryEngineProxy",
    "GovernedChatEngineProxy",
    "llama_index_governed_function_tool",
    "wrap_query_engine",
    "wrap_chat_engine",
    "wrap_agent_worker",
    "create_governed_llama_index",
    "GovernedLlamaIndexInstance",
    # AutoGen v0.4 framework adapter (Sprint 5, WS-10)
    "GovernedAutoGenTool",
    "governed_autogen_tool",
    "wrap_autogen_agent",
    "wrap_autogen_group_chat",
    "create_governed_autogen",
    "GovernedAutoGenInstance",
    # LangGraph standalone adapter (Sprint 5, WS-10)
    "GovernedStateGraph",
    "langgraph_wrap_state_graph",
    "wrap_pregel",
    "create_governed_langgraph",
    "GovernedLangGraphInstance",
    # Pydantic AI framework adapter (Sprint 5, WS-13)
    "pydantic_ai_governed_tool_decorator",
    "governed_tool_plain_decorator",
    "wrap_pydantic_ai_agent_run",
    "wrap_pydantic_ai_agent",
    "GovernedAgentResult",
    "create_governed_pydantic_ai",
    "GovernedPydanticAIInstance",
    # Haystack v2 framework adapter (Sprint 5, WS-13)
    "HaystackGovernedComponent",
    "haystack_governed_component",
    "wrap_haystack_pipeline",
    "wrap_haystack_tool_invoker",
    "wrap_haystack_generator",
    "create_governed_haystack",
    "GovernedHaystackInstance",
    # CrewAI framework adapter (Sprint 5, WS-09)
    "GovernanceCrewAITool",
    "governed_crewai_tool",
    "make_governance_step_callback",
    "make_governance_task_callback",
    "wrap_crewai_agent",
    "wrap_crew",
    "create_governed_crewai",
    "GovernedCrewAIInstance",
    # LLM provider integrations (Batch 1)
    "AnthropicGovernance",
    "OpenAIGovernance",
    "GeminiGovernance",
    "AzureOpenAIGovernance",
    "BedrockGovernance",
    "OllamaGovernance",
    # F-NEW-PRODUCT-AGENT-DIR-HUGGINGFACE-WRAPPER: GovernedHuggingFace + proxy
    "GovernedHuggingFace",
    "GovernedHuggingFaceProxy",
    "HuggingFaceGovernance",  # backward-compat alias
    "DeepSeekGovernance",
    "ReplicateGovernance",
    # Orchestrator integrations (Batch 2a)
    "GovernanceCallbackHandler",
    "ClaudeAgentGovernance",
    "PhantomAgentError",
    "SubscriptionGateError",
    "UnboundDataError",
    "GoogleAdkGovernance",
    "BaaRegionError",
    "BedrockAgentCoreGovernance",
    "BedrockBaaRegionError",
    "HaystackGovernance",
    "LlamaIndexGovernance",
    # Orchestrator integrations (Batch 2b)
    "OpenAIAgentsGovernance",
    "OpenAIAgentsHandoffDeniedError",
    "OpenAIAgentsMaxTurnsError",
    "SemanticKernelGovernance",
    "SKGovernanceFilterShim",
    "SKFunctionNotFoundError",
    "SKMemoryAccessDeniedError",
    "DeepAgentsGovernance",
    "DeepAgentsPolicyBridge",
    "DeepAgentsUnboundDataError",
    "OpenClawGovernance",
    "OpenClawPolicyBridge",
    "OpenClawMemoryPhiError",
    "OpenClawUnsanctionedWorkspaceError",
    "PaperclipGovernance",
    "PaperclipPolicyBridge",
    "PaperclipTaskTypeError",
    "PaperclipPlanStepsError",
    # IDE integrations (Batch 3 -- Python parity)
    "ClaudeCodeGovernance",
    "ClaudeCodePolicyBridge",
    "ContinueDevGovernance",
    "ContinueDevPolicyBridge",
    "CopilotWorkspaceGovernance",
    "CopilotWorkspacePolicyBridge",
    "CursorGovernance",
    "CursorPolicyBridge",
    "GitHubCopilotGovernance",
    "GitHubCopilotPolicyBridge",
    "JetBrainsAIGovernance",
    "JetBrainsAIPolicyBridge",
    "AmazonQDeveloperGovernance",
    "AmazonQDeveloperPolicyBridge",
]
