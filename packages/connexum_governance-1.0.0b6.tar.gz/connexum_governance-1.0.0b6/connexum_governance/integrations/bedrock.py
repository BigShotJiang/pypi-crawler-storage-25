"""AWS Bedrock governance integration for Connexum governance.

Wraps calls to the AWS Bedrock Runtime API (InvokeModel / Converse)
with pre-call governance checks and post-call G-series output classification.

Bedrock differs from standard LLM APIs on:
- Model family prefix in model ID (anthropic.*, amazon.*, meta.*, mistral.*)
- Converse API (unified multi-model interface) vs model-specific InvokeModel
- Region is an explicit data-sovereignty signal
- AWS Signature Version 4 authentication

BAA status: AWS Bedrock is covered by the AWS Business Associate Agreement
for HIPAA-eligible services. AWS BAA covers Bedrock as a HIPAA-eligible
service. Region matters: PHI must remain in BAA-covered regions.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.bedrock import BedrockGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    bg = BedrockGovernance(
        client=gov,
        agent_name="bedrock-agent",
        region="us-east-1",
    )

    # Intercept a Bedrock Converse API request
    decision = bg.intercept_request({
        "modelId": "anthropic.claude-3-haiku-20240307-v1:0",
        "messages": [{"role": "user", "content": [{"text": "Hello"}]}],
    })
"""

from __future__ import annotations

import sys
import time
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
    GovernanceViolation,
)

_PROVIDER_ID = "bedrock"
_BAA_AVAILABLE = True
_BAA_SCOPE = "aws_baa_hipaa_eligible"
_BAA_NOTES = (
    "AWS Bedrock is covered under the AWS Business Associate Agreement as a "
    "HIPAA-eligible service. Region selection matters: PHI must stay in BAA-covered "
    "AWS regions. Verify your region is HIPAA-eligible before processing PHI."
)

# Model family detection by prefix
_MODEL_FAMILY_PREFIXES: dict[str, str] = {
    "anthropic.": "claude",
    "amazon.": "titan",
    "meta.": "llama",
    "mistral.": "mistral",
    "cohere.": "cohere",
    "ai21.": "jurassic",
}


def _detect_model_family(model_id: str) -> str:
    """Return the model family string for a Bedrock model ID."""
    for prefix, family in _MODEL_FAMILY_PREFIXES.items():
        if model_id.startswith(prefix):
            return family
    return "unknown"


class BedrockGovernance:
    """Governance wrapper for the AWS Bedrock Runtime API.

    Intercepts Bedrock Converse and InvokeModel requests before they
    reach the AWS endpoint and classifies responses through the nine-guard
    G-series after receipt.

    Does NOT depend on boto3 or botocore at import time.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        region: Optional[str] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)
        self.region = region

        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        """Check a pending Bedrock Converse or InvokeModel request against governance.

        Supports both the Bedrock Converse API format (messages + modelId) and
        the raw InvokeModel format (body as dict). Extracts model ID, model family,
        region, message count, system prompt digest, and tool names.

        Args:
            request: The request dict for the Bedrock API call.
                Converse format: modelId, messages, system (optional), toolConfig.
                InvokeModel format: modelId, body (dict with prompt or messages).

        Returns:
            GovernanceDecision (ALLOW / DENY / REQUIRE_APPROVAL).

        Raises:
            GovernanceViolation: if enforce=True and the decision is DENY.
        """
        model_id = request.get("modelId", request.get("model_id", "unknown"))
        model_family = _detect_model_family(model_id)

        # Converse API messages format
        messages = request.get("messages", [])

        # System prompt digest (Converse API uses system array of contentBlocks)
        system_blocks = request.get("system", [])
        system_digest = ""
        if isinstance(system_blocks, list):
            system_digest = " ".join(
                block.get("text", "") for block in system_blocks if isinstance(block, dict)
            )[:500]
        elif isinstance(system_blocks, str):
            system_digest = system_blocks[:500]

        # Tool names from Converse API toolConfig
        tool_config = request.get("toolConfig", {})
        tool_names: list[str] = []
        if isinstance(tool_config, dict):
            tools = tool_config.get("tools", [])
            for tool_item in tools:
                if isinstance(tool_item, dict):
                    tool_spec = tool_item.get("toolSpec", {})
                    name = tool_spec.get("name", "")
                    if name:
                        tool_names.append(name)

        gov_input: dict[str, Any] = {
            "model": model_id,
            "modelFamily": model_family,
            "region": self.region or "unknown",
            "systemPromptDigest": system_digest,
            "messageCount": len(messages),
            "toolCount": len(tool_names),
            "toolNames": tool_names,
            "provider": "bedrock",
        }

        return self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )

    def intercept_response(
        self,
        response: dict[str, Any],
        audit_id: str,
    ) -> ClassifiedResponse:
        """Classify a Bedrock runtime response through the G-series guards.

        Args:
            response: Raw response dict from Bedrock (Converse or InvokeModel format).
            audit_id: The audit_id from the preceding intercept_request decision.

        Returns:
            ClassifiedResponse indicating whether the response is safe to return.
        """
        start = time.monotonic()

        classified = self.client.classify_output(
            audit_id=audit_id,
            output=response,
            agent=self.agent,
        )

        elapsed_ms = int((time.monotonic() - start) * 1000)

        try:
            self.client.report_result(
                audit_id=audit_id,
                success=classified.allowed,
                summary=(
                    f"Response classified. Guards triggered: {classified.guards_triggered}"
                    if classified.guards_triggered
                    else "Response classified clean."
                ),
                duration_ms=elapsed_ms,
                error=(
                    f"Guards triggered: {classified.guards_triggered}"
                    if not classified.allowed
                    else None
                ),
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return classified

    def wrap(self, bedrock_client: Any) -> "BedrockClientProxy":
        """Return a proxy around a boto3 Bedrock runtime client.

        Intercepts converse() and invoke_model() calls.

        Args:
            bedrock_client: A boto3 Bedrock runtime client
                (e.g. boto3.client('bedrock-runtime')).

        Returns:
            BedrockClientProxy wrapping the provided client.
        """
        return BedrockClientProxy(raw_client=bedrock_client, governance=self)


class BedrockClientProxy:
    """Thin proxy around a boto3 bedrock-runtime client with governance.

    Intercepts converse() and invoke_model() calls. All other attributes
    pass through to the underlying client unchanged.
    """

    def __init__(self, raw_client: Any, governance: BedrockGovernance):
        self._raw = raw_client
        self._gov = governance

    def converse(self, **kwargs: Any) -> Any:
        """Intercept Bedrock Converse API call with governance checks."""
        request = dict(kwargs)
        decision = self._gov.intercept_request(request)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {
                "output": {
                    "message": {
                        "role": "assistant",
                        "content": [
                            {"text": f"[GOVERNANCE DENIED] {decision.reason}"}
                        ],
                    }
                },
                "stopReason": "GOVERNANCE_DENIED",
                "usage": {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0},
            }

        if decision.requires_approval:
            return {
                "output": {
                    "message": {
                        "role": "assistant",
                        "content": [
                            {
                                "text": (
                                    f"[GOVERNANCE PENDING] Action requires approval. "
                                    f"Audit ID: {decision.audit_id}"
                                )
                            }
                        ],
                    }
                },
                "stopReason": "GOVERNANCE_PENDING",
                "usage": {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0},
            }

        response = self._raw.converse(**kwargs)

        if hasattr(response, "model_dump"):
            response_dict = response.model_dump()
        elif isinstance(response, dict):
            response_dict = response
        else:
            response_dict = dict(response)

        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=response_dict,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] Bedrock response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return response

    def invoke_model(self, **kwargs: Any) -> Any:
        """Intercept Bedrock InvokeModel API call with governance checks."""
        request = dict(kwargs)
        decision = self._gov.intercept_request(request)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {
                "body": {"error": f"[GOVERNANCE DENIED] {decision.reason}"},
                "contentType": "application/json",
                "stopReason": "GOVERNANCE_DENIED",
            }

        if decision.requires_approval:
            return {
                "body": {
                    "content": (
                        f"[GOVERNANCE PENDING] Action requires approval. "
                        f"Audit ID: {decision.audit_id}"
                    )
                },
                "contentType": "application/json",
                "stopReason": "GOVERNANCE_PENDING",
            }

        response = self._raw.invoke_model(**kwargs)

        response_dict = response if isinstance(response, dict) else {}
        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=response_dict,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] Bedrock invoke_model response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)
