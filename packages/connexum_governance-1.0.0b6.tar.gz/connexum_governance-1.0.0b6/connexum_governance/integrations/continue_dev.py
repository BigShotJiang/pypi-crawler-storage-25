"""Continue.dev IDE governance integration.

Continue.dev is an open-source AI code assistant for VS Code and JetBrains
(https://continue.dev). The primary adapter is TypeScript-native
(`src/ide-adapters/continue-dev.ts`). This Python shim lets a Python-hosted
governance policy server participate in the Continue.dev decision loop via HTTP.

Architecture:
  Continue.dev fires two principal request types on its extension surface:
    completions (inline code completion)
    chat (chat assistant)

  The Python shim:
    1. Accepts inbound requests via intercept_completion() or intercept_chat()
    2. Runs local guard checks (secrets, PHI, privileged paths)
    3. Forwards a canonical governance event to the REST API
    4. Returns a policy decision in the Continue.dev config.json-compatible shape

Provider note:
  Continue.dev is configurable -- it supports Anthropic, OpenAI, Ollama, and
  many other backends via config.ts `models` array. The approved_models list
  should list all model IDs that the tenant has approved for use.

Canonical event shapes:
  toolCall   -> {"eventType": "toolCall",   "agentId": ..., "toolName": ..., ...}
  toolResult -> {"eventType": "toolResult", "agentId": ..., ...}
  llmCall    -> {"eventType": "llmCall",    "agentId": ..., "model": ..., ...}
  llmResult  -> {"eventType": "llmResult",  "agentId": ..., ...}

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.continue_dev import ContinueDevGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = ContinueDevGovernance(
        client=gov,
        agent_name="continue-dev-agent",
        pack_binding=["soc2"],
        approved_models=["gpt-4o", "claude-haiku-4-5", "codellama"],
    )

    # In a Python server receiving Continue.dev extension callbacks:
    decision = adapter.intercept_completion({
        "model": "gpt-4o",
        "context": "def process_patient(",
        "filePath": "src/health/processor.py",
    })
    decision = adapter.intercept_chat({
        "model": "gpt-4o",
        "message": "Explain this function",
        "attachedFilePaths": ["src/health/processor.py"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Secret patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",          re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",              re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",       re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",          re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",      re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",  re.compile(r"(SECRET|PASSWORD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Database URL with creds", re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("Bearer token",            re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bsocial[_\s]?security\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Privileged file path patterns (file writes outside project root)
# ---------------------------------------------------------------------------

_SENSITIVE_PATH_PATTERNS: list[re.Pattern] = [
    re.compile(r"^/etc/"),
    re.compile(r"^/root/"),
    re.compile(r"^/?\.env$"),
    re.compile(r"\.env\."),
    re.compile(r"secrets?/", re.IGNORECASE),
    re.compile(r"private_?key", re.IGNORECASE),
    re.compile(r"\.pem$", re.IGNORECASE),
    re.compile(r"\.key$", re.IGNORECASE),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})

# Continue.dev API version this shim is tested against
CONTINUE_TESTED_API_VERSION = "0.8"


def _scan_for_secrets(text: str) -> Optional[str]:
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_for_phi_indicators(text: str) -> Optional[str]:
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _is_sensitive_path(file_path: str) -> bool:
    return any(p.search(file_path) for p in _SENSITIVE_PATH_PATTERNS)


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(p.lower() in ("hipaa", "hitech") for p in pack_binding)


# ---------------------------------------------------------------------------
# ContinueDevGovernance
# ---------------------------------------------------------------------------

class ContinueDevGovernance(BaseGovernanceIntegration):
    """REST-client shim for Continue.dev governance.

    Continue.dev is TypeScript-native. This Python shim participates in the
    decision loop by:
      1. Accepting completion and chat requests from the Continue.dev extension
         (via intercept_completion / intercept_chat)
      2. Running local guard checks (secrets, PHI, privileged path detection)
      3. Forwarding canonical events to the governance REST API
      4. Providing policy_bridge() for Python policy participation

    Provider is configurable (Continue.dev supports many backends).
    """

    _FRAMEWORK_NAME = "continue-dev"
    _LAYER_NAME = "continue-dev-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        approved_models: Optional[list[str]] = None,
        sensitive_tools: Optional[list[str]] = None,
        sensitive_arg_keys: Optional[list[str]] = None,
        project_root: Optional[str] = None,
        hipaa_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            approved_models: Model IDs approved for use.
            sensitive_tools: Tool names requiring approval.
            sensitive_arg_keys: Argument keys to scan for PHI.
            project_root: Project root path; file writes outside this path
                          are treated as privileged (require approval).
            hipaa_reviewer_tier: Reviewer tier for HIPAA-bound PHI violations.
        """
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.approved_models = approved_models or []
        self.sensitive_tools = sensitive_tools or []
        self.sensitive_arg_keys = sensitive_arg_keys or [
            "content", "message", "context", "surroundingContext",
        ]
        self.project_root = project_root
        self.hipaa_reviewer_tier = hipaa_reviewer_tier

    # ------------------------------------------------------------------
    # intercept_completion -- Continue.dev inline completion gate
    # ------------------------------------------------------------------

    def intercept_completion(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate an inline code completion request from Continue.dev.

        Maps to the Continue.dev extension `onToolCallStart` surface when
        the tool is an inline completion request.

        Guards applied:
          1. Secret pattern scan on surrounding code context
          2. PHI proximity indicator check under HIPAA binding
          3. Provider compliance (model on approved list)
          4. Sensitive file path protection

        Args:
            request: Completion request dict with keys:
                     model, context (or surroundingContext), filePath, sdkVersion, etc.

        Returns:
            GovernanceDecision.
        """
        model = str(request.get("model", ""))
        context = str(
            request.get("surroundingContext",
            request.get("context", ""))
        )
        file_path = str(request.get("filePath", request.get("file_path", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                'Continue.dev completion request carries no pack binding. '
                'Pack-binding primacy: every request MUST carry packBinding.',
                pack_binding=pack_binding,
            )

        # 1. Secret scan on context
        secret_match = _scan_for_secrets(context)
        if secret_match:
            return self._deny(
                agent_id,
                f'Completion request blocked: secret pattern "{secret_match}" detected '
                f'in surrounding code context ({file_path}). '
                'Remove the secret before requesting a completion.',
                pack_binding=pack_binding,
            )

        # 2. PHI proximity check under HIPAA
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi_indicators(context)
            if phi_indicator:
                reason = (
                    f'Completion request routed for HIPAA review: PHI indicator '
                    f'"{phi_indicator}" found in surrounding context ({file_path}). '
                    f'Reviewer tier: {self.hipaa_reviewer_tier}.'
                )
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": model,
                    "messageCount": 0,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": reason,
                    "filePath": file_path,
                })

        # 3. Provider compliance
        if self.approved_models and model and model not in self.approved_models:
            return self._deny(
                agent_id,
                f'Continue.dev model "{model}" is not on the approved list. '
                f'Approved: {", ".join(self.approved_models)}.',
                pack_binding=pack_binding,
            )

        # 4. Sensitive path protection
        if file_path and _is_sensitive_path(file_path):
            return self._deny(
                agent_id,
                f'Sensitive path blocked by ContinueDevGovernance: {file_path}',
                pack_binding=pack_binding,
            )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": model,
            "messageCount": 0,
            "packBinding": pack_binding,
            "filePath": file_path,
            "completionRequest": True,
        })

    # ------------------------------------------------------------------
    # intercept_chat -- Continue.dev chat assistant gate
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Continue.dev chat request.

        Maps to the Continue.dev extension `onChatRequest` surface.

        Guards applied:
          1. Secret scan on prompt message
          2. PHI proximity check under HIPAA
          3. Provider compliance
          4. Attached file path protection

        Args:
            request: Chat request dict with keys:
                     model, message (or prompt), attachedFilePaths, sdkVersion, etc.

        Returns:
            GovernanceDecision.
        """
        model = str(request.get("model", ""))
        message = str(request.get("message", request.get("prompt", "")))
        attached_file_paths: list[str] = list(request.get("attachedFilePaths", []))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                'Continue.dev chat request carries no pack binding. '
                'Pack-binding primacy: every request MUST carry packBinding.',
                pack_binding=pack_binding,
            )

        # 1. Secret scan on prompt
        secret_match = _scan_for_secrets(message)
        if secret_match:
            return self._deny(
                agent_id,
                f'Chat request blocked: secret pattern "{secret_match}" detected in prompt.',
                pack_binding=pack_binding,
            )

        # 2. PHI proximity check under HIPAA
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi_indicators(message)
            if phi_indicator:
                reason = (
                    f'Chat request routed for HIPAA review: PHI indicator '
                    f'"{phi_indicator}" found in message. '
                    f'Reviewer tier: {self.hipaa_reviewer_tier}.'
                )
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": model,
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": reason,
                })

        # 3. Provider compliance
        if self.approved_models and model and model not in self.approved_models:
            return self._deny(
                agent_id,
                f'Continue.dev model "{model}" is not on the approved list. '
                f'Approved: {", ".join(self.approved_models)}.',
                pack_binding=pack_binding,
            )

        # 4. Sensitive file path protection for attached files
        for fp in attached_file_paths:
            if _is_sensitive_path(fp):
                return self._deny(
                    agent_id,
                    f'Chat request blocked: attached file path "{fp}" is sensitive.',
                    pack_binding=pack_binding,
                )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": model,
            "messageCount": 1,
            "packBinding": pack_binding,
            "chatRequest": True,
            "attachedFilePaths": attached_file_paths,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API.

        Args:
            event_type: Canonical event type.
            payload: Event payload. Must include "agentId".

        Returns:
            GovernanceDecision from the governance API.
        """
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown ContinueDev event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Provider compliance for llmCall
        if event_type == "llmCall":
            model = payload.get("model", "")
            if self.approved_models and model and model not in self.approved_models:
                from connexum_governance.models import DecisionType
                reason = (
                    f'ContinueDev LLM model "{model}" is not on the approved provider list. '
                    f"Approved: {', '.join(self.approved_models)}"
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] ContinueDev output classifier: possible secret in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi_indicators(response_text):
                print(
                    f"[GOVERNANCE] ContinueDev output exfiltration scanner: possible secret/PHI in "
                    f'LLM response (model: {payload.get("model", "unknown")}, agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Delegate pack-binding primacy + REST dispatch + audit tracking to base (M2)
        return super().emit_event(event_type, payload)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload from a Continue.dev extension webhook and forward it.

        Args:
            request_body: Parsed JSON body with "eventType" and "agentId".

        Returns:
            GovernanceDecision.
        """
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError("ContinueDev webhook payload missing required field: 'eventType'")
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError("ContinueDev webhook payload missing required field: 'agentId'")
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "ContinueDevPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return ContinueDevPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# ContinueDevPolicyBridge
# ---------------------------------------------------------------------------

class ContinueDevPolicyBridge:
    """Bridge for Python-hosted policy participation in the Continue.dev loop."""

    def __init__(
        self,
        adapter: ContinueDevGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
