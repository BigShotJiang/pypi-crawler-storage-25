"""LangChain integration for Connexum governance.

Provides a GovernanceCallbackHandler that subclasses LangChain's
BaseCallbackHandler and intercepts agent/chain lifecycle events with
six canonical governance hook surfaces.

Hook surfaces (parity with src/orchestrator-adapters/langchain.ts):
  agentStart   -> on_chain_start
  toolCall     -> on_tool_start
  toolResult   -> on_tool_end
  llmCall      -> on_llm_start
  llmResult    -> on_llm_end
  agentEnd     -> on_chain_end

Lazy import: langchain is not hard-required. If absent an ImportError
is raised at first use with an actionable install message.

=== ARCHITECTURAL CAVEAT: DENY does not block tool execution (WS-05 ITEM 4) ===

LangChain's callback system is designed for OBSERVABILITY, not blocking.
GovernanceCallbackHandler.on_tool_start() runs a governance check and will
raise GovernanceViolation when raise_on_deny=True. HOWEVER, whether LangChain
respects that raise to block tool dispatch depends on the executor type and
LangChain version:

  - AgentExecutor (classic): Generally does propagate raises from on_agent_action.
    on_tool_start raises are less consistently propagated depending on LC version.
  - LangGraph ToolNode: Does NOT call these callbacks reliably in all versions.
    Use GovernedTool (from this module) or GovernanceTool (langgraph.py) instead.

CONCLUSION: This is an architectural reality of the LangChain callback system.
The behavior is NOT changed (see DIVERGENCE-004 / WS-05 ITEM 4). GovernedTool._run()
/ GovernanceTool.invoke() are the ONLY GUARANTEED BLOCKING PRIMITIVES in the
LangChain / LangGraph adapter stack.

CUSTOMER GUIDANCE:
  - Use GovernedTool / governed_tool() for tools you need hard blocking on.
  - Use GovernanceCallbackHandler for audit coverage and defense-in-depth only.
  - Do NOT rely solely on raise_on_deny=True in the callback handler for blocking.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.langchain import GovernanceCallbackHandler

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    handler = GovernanceCallbackHandler(client=gov, agent_name="qa-agent")

    # Pass to any LangChain chain or agent
    chain.invoke(input, config={"callbacks": [handler]})
"""

from __future__ import annotations

import sys
import time
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceViolation

# PHI / secret patterns for lightweight egress scanning
_PHI_PATTERNS_RE: "re.Pattern[str] | None" = None


def _phi_pattern():
    import re
    global _PHI_PATTERNS_RE
    if _PHI_PATTERNS_RE is None:
        _PHI_PATTERNS_RE = re.compile(
            r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"            # SSN
            r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"  # PAN
            r"|\b(patient_id|mrn|dob|diagnosis|ssn|npi)\s*[:=])",  # PHI labels
            re.IGNORECASE,
        )
    return _PHI_PATTERNS_RE


def _contains_phi(text: str) -> bool:
    return bool(_phi_pattern().search(text))


def _contains_secret(text: str) -> bool:
    """Detect obvious secret patterns (G2 guard equivalent)."""
    import re
    return bool(re.search(
        r"(sk-ant-[a-zA-Z0-9]{20,}"
        r"|sk-[a-zA-Z0-9]{20,}"
        r"|ghp_[a-zA-Z0-9]{36,}"
        r"|AKIA[0-9A-Z]{16}"
        r"|AIzaSy[a-zA-Z0-9_-]{30,}"
        r"|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----)",
        text,
    ))


class GovernanceCallbackHandler:
    """LangChain BaseCallbackHandler subclass with governance enforcement.

    Does NOT inherit from LangChain's BaseCallbackHandler directly; instead
    it exposes the same callback method names so LangChain calls them via
    duck typing when the handler is passed in the callbacks list.

    Covers all six canonical governance hook surfaces:
      on_chain_start  -> agentStart governance check
      on_tool_start   -> toolCall governance check (honor DENY / REQUIRE_APPROVAL)
      on_tool_end     -> toolResult G-series classification
      on_llm_start    -> llmCall governance check
      on_llm_end      -> llmResult output classification
      on_chain_end    -> agentEnd audit close
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        sensitive_tools: Optional[list[str]] = None,
        raise_on_deny: bool = False,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Canonical name of the LangChain agent/chain.
            agent_role: Optional role descriptor forwarded to audit events.
            sensitive_tools: Tools whose results should trigger G2/PHI scanning.
                             Defaults to all tools when None.
            raise_on_deny: When True, tool denials are raised as GovernanceViolation.
                           When False (default), a denial string is returned.
        """
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)
        self.sensitive_tools = sensitive_tools
        self.raise_on_deny = raise_on_deny

        # run_id -> audit_id for in-progress spans
        self._run_audits: dict[str, str] = {}
        # run_id -> start time (monotonic)
        self._run_starts: dict[str, float] = {}

    # ------------------------------------------------------------------
    # agentStart -- on_chain_start
    # ------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        run_id: Any = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Governance check at chain/agent start.

        Calls check_action with tool='agent.start'. Records audit_id for
        later closure at on_chain_end. Honours DENY/REQUIRE_APPROVAL.
        """
        run_key = str(run_id) if run_id else str(uuid.uuid4())
        chain_type = serialized.get("id", ["unknown"])[-1] if serialized else "unknown"

        decision = self.client.check_action(
            tool="agent.start",
            input={
                "chainType": chain_type,
                "runId": run_key,
                "inputKeys": list(inputs.keys()) if inputs else [],
                "tags": tags or [],
                "agentName": self.agent.name,
            },
            agent=self.agent,
        )

        self._run_starts[run_key] = time.monotonic()
        if decision.audit_id:
            self._run_audits[run_key] = decision.audit_id

        if decision.denied and self.raise_on_deny:
            raise GovernanceViolation(decision)

    # ------------------------------------------------------------------
    # toolCall -- on_tool_start
    # ------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        run_id: Any = None,
        parent_run_id: Any = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        """Governance check before tool invocation.

        Calls check_action with tool='tool.<name>'. Honours DENY/REQUIRE_APPROVAL
        by raising GovernanceViolation when raise_on_deny=True.

        Returns:
            GovernanceDecision on ALLOW (for callers that inspect the return value).
            LangChain's callback system ignores the return value, so this is purely
            for API consistency with other adapter on_tool_start implementations.

            NOTE (ITEM 3 / DIVERGENCE-003): LangChain callbacks fire after tool
            dispatch is scheduled. Even returning the GovernanceDecision here does
            not block tool execution at the LangChain level. GovernedTool._run() is
            the GUARANTEED blocking primitive. This return value is for customer code
            that calls the handler directly (not via LangChain's callback mechanism).
        """
        run_key = str(run_id) if run_id else str(uuid.uuid4())
        tool_name = serialized.get("name", "unknown_tool") if serialized else "unknown_tool"

        decision = self.client.check_action(
            tool=f"tool.{tool_name}",
            input={
                "toolName": tool_name,
                "inputDigest": str(input_str)[:500],
                "runId": run_key,
            },
            agent=self.agent,
        )

        self._run_starts[run_key] = time.monotonic()
        if decision.audit_id:
            self._run_audits[run_key] = decision.audit_id

        # ARCHITECTURAL NOTE (WS-05 ITEM 4 -- do not "fix" this):
        # LangChain's callback system does NOT guarantee that a raise from
        # on_tool_start will block tool execution. The raise may propagate in
        # AgentExecutor but is NOT part of LangChain's callback contract.
        # LangGraph ToolNode does not call callbacks reliably.
        # GovernedTool._run() / GovernanceTool.invoke() are the guaranteed
        # blocking primitives. This raise is best-effort defense-in-depth only.
        if decision.denied and self.raise_on_deny:
            raise GovernanceViolation(decision)

        # Return the GovernanceDecision uniformly on ALLOW so callers that invoke
        # this handler directly (outside LangChain's callback machinery) receive
        # the decision object rather than None. LangChain itself ignores this value.
        return decision

    # ------------------------------------------------------------------
    # toolResult -- on_tool_end
    # ------------------------------------------------------------------

    def on_tool_end(
        self,
        output: str,
        run_id: Any = None,
        parent_run_id: Any = None,
        tags: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> None:
        """G-series scan on tool output and audit chain close.

        C1 fix: after the local lightweight G2/PHI scan, also calls
        client.classify_output() to run the full nine-guard G-series
        classification on the governance server side. This closes the
        gap where orchestrator tool outputs bypassed the full G-series
        even though LLM provider outputs were classified.
        """
        run_key = str(run_id) if run_id else ""
        audit_id = self._run_audits.pop(run_key, None)
        elapsed_ms = int((time.monotonic() - self._run_starts.pop(run_key, time.monotonic())) * 1000)

        # G2 + PHI egress scan on tool result text (lightweight local check)
        output_text = str(output)
        secret_found = _contains_secret(output_text)
        phi_found = _contains_phi(output_text)
        local_clean = not secret_found and not phi_found

        if not local_clean:
            print(
                f"[GOVERNANCE] G-series classification: tool output flagged "
                f"(secret={secret_found}, phi={phi_found}). "
                f"Audit ID: {audit_id}",
                file=sys.stderr,
            )

        # C1 fix: full G-series classification via governance server classify_output()
        server_clean = True
        if audit_id:
            try:
                classified = self.client.classify_output(
                    audit_id=audit_id,
                    output={"toolOutput": output_text, "agentName": self.agent.name},
                    agent=self.agent,
                )
                server_clean = classified.allowed
                if not server_clean:
                    print(
                        f"[GOVERNANCE] G-series server classification: tool output flagged "
                        f"(agent={self.agent.name}, audit={audit_id}). "
                        f"Guards triggered: {classified.guards_triggered}. "
                        "(C1: postActionClassify)",
                        file=sys.stderr,
                    )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        clean = local_clean and server_clean

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=clean,
                    summary=output_text[:200],
                    duration_ms=elapsed_ms,
                    error=None if clean else "G-series output classification blocked",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # llmCall -- on_llm_start
    # ------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        run_id: Any = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Governance check before LLM call (intercept_request equivalent)."""
        run_key = str(run_id) if run_id else str(uuid.uuid4())
        llm_name = serialized.get("id", ["unknown"])[-1] if serialized else "unknown"

        # Lightweight PHI ingress scan on the first prompt
        first_prompt = prompts[0] if prompts else ""
        phi_in_prompt = _contains_phi(first_prompt)

        decision = self.client.check_action(
            tool="llm.call",
            input={
                "llmName": llm_name,
                "promptCount": len(prompts),
                "promptDigest": first_prompt[:500],
                "phiDetected": phi_in_prompt,
                "runId": run_key,
            },
            agent=self.agent,
        )

        self._run_starts[run_key] = time.monotonic()
        if decision.audit_id:
            self._run_audits[run_key] = decision.audit_id

        if decision.denied and self.raise_on_deny:
            raise GovernanceViolation(decision)

    # ------------------------------------------------------------------
    # llmResult -- on_llm_end
    # ------------------------------------------------------------------

    def on_llm_end(
        self,
        response: Any,
        run_id: Any = None,
        tags: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> None:
        """G-series output classification on LLM response + audit chain close."""
        run_key = str(run_id) if run_id else ""
        audit_id = self._run_audits.pop(run_key, None)
        elapsed_ms = int((time.monotonic() - self._run_starts.pop(run_key, time.monotonic())) * 1000)

        # Extract text from LangChain LLMResult / ChatResult structure
        response_text = ""
        if hasattr(response, "generations"):
            for gen_list in response.generations:
                for gen in gen_list:
                    if hasattr(gen, "text"):
                        response_text += gen.text
                    elif hasattr(gen, "message") and hasattr(gen.message, "content"):
                        response_text += str(gen.message.content)
        elif isinstance(response, str):
            response_text = response

        secret_found = _contains_secret(response_text)
        phi_found = _contains_phi(response_text)
        clean = not secret_found and not phi_found

        if not clean:
            print(
                f"[GOVERNANCE] G-series classification: LLM response flagged "
                f"(secret={secret_found}, phi={phi_found}). "
                f"Audit ID: {audit_id}",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=clean,
                    summary=response_text[:200],
                    duration_ms=elapsed_ms,
                    error=None if clean else "G-series LLM output classification blocked",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # agentEnd -- on_chain_end
    # ------------------------------------------------------------------

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        run_id: Any = None,
        tags: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Audit chain close on chain/agent end."""
        run_key = str(run_id) if run_id else ""
        audit_id = self._run_audits.pop(run_key, None)
        elapsed_ms = int((time.monotonic() - self._run_starts.pop(run_key, time.monotonic())) * 1000)

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=True,
                    summary=str(list(outputs.keys()))[:200] if outputs else "",
                    duration_ms=elapsed_ms,
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # on_chain_error / on_tool_error -- error surfaces
    # ------------------------------------------------------------------

    def on_chain_error(
        self,
        error: BaseException,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Report chain error to audit chain."""
        run_key = str(run_id) if run_id else ""
        audit_id = self._run_audits.pop(run_key, None)
        elapsed_ms = int((time.monotonic() - self._run_starts.pop(run_key, time.monotonic())) * 1000)

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=False,
                    summary="",
                    duration_ms=elapsed_ms,
                    error=str(error)[:500],
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    def on_tool_error(
        self,
        error: BaseException,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Report tool error to audit chain."""
        run_key = str(run_id) if run_id else ""
        audit_id = self._run_audits.pop(run_key, None)
        elapsed_ms = int((time.monotonic() - self._run_starts.pop(run_key, time.monotonic())) * 1000)

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=False,
                    summary="",
                    duration_ms=elapsed_ms,
                    error=str(error)[:500],
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)
