"""Anthropic governance integration for Connexum governance.

Wraps calls to the Anthropic Messages API with pre-call governance
checks and post-call G-series output classification.

BAA status: Anthropic offers a Business Associate Agreement (BAA) for
eligible customers on enterprise plans. This is registered with the
governance server at initialization time.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.anthropic import AnthropicGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    ag = AnthropicGovernance(client=gov, agent_name="chat-agent")

    # Intercept a request before sending to Anthropic
    decision = ag.intercept_request({
        "model": "claude-3-haiku-20240307",
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": "Hello"}],
    })

    # Use the proxy (requires anthropic package installed)
    import anthropic
    raw_client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    governed_client = ag.wrap(raw_client)
    response = governed_client.messages.create(
        model="claude-3-haiku-20240307",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

from __future__ import annotations

import sys
import time
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
    GovernanceViolation,
)

# BAA metadata (Anthropic offers BAA for enterprise customers)
_PROVIDER_ID = "anthropic"
_BAA_AVAILABLE = True
_BAA_SCOPE = "enterprise"
_BAA_NOTES = "Anthropic BAA available for eligible enterprise customers. Contact Anthropic sales."


class AnthropicGovernance:
    """Governance wrapper for the Anthropic Messages API.

    Intercepts requests before they reach the Anthropic endpoint and
    classifies responses through the nine-guard G-series after receipt.

    Does NOT depend on the anthropic package at import time. The wrap()
    method lazily imports it so this module is always importable even
    when the anthropic SDK is not installed.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)

        # Register BAA / compliance metadata with the governance server.
        # Non-fatal if the server is unreachable.
        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        """Check a pending Anthropic messages.create request against governance.

        Extracts: model, max_tokens, system prompt digest (first 500 chars),
        message count, and tool declarations. Passes these to check_action
        so the governance server can apply pack-binding rules without
        forwarding raw message content.

        Args:
            request: The dict that would be passed to messages.create.

        Returns:
            GovernanceDecision (ALLOW / DENY / REQUIRE_APPROVAL).

        Raises:
            GovernanceViolation: if enforce=True and the decision is DENY.
        """
        system_prompt = request.get("system", "")
        if isinstance(system_prompt, list):
            # Anthropic system block list format
            system_prompt = " ".join(
                b.get("text", "") for b in system_prompt if isinstance(b, dict)
            )
        system_digest = str(system_prompt)[:500]

        messages = request.get("messages", [])
        tools = request.get("tools", [])

        gov_input: dict[str, Any] = {
            "model": request.get("model", "unknown"),
            "maxTokens": request.get("max_tokens"),
            "systemPromptDigest": system_digest,
            "messageCount": len(messages),
            "toolCount": len(tools),
            "toolNames": [t.get("name", "") for t in tools if isinstance(t, dict)],
        }

        decision = self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )
        return decision

    def intercept_response(
        self,
        response: dict[str, Any],
        audit_id: str,
    ) -> ClassifiedResponse:
        """Classify an Anthropic messages.create response through the G-series guards.

        Calls classify_output to screen for secrets (G2), PHI (G3), unsafe
        content (G1), and policy violations. Also calls report_result to
        close the audit chain.

        Args:
            response: The raw response dict from Anthropic (or SDK object
                converted to dict via model_dump() / to_dict()).
            audit_id: The audit_id from the preceding intercept_request decision.

        Returns:
            ClassifiedResponse indicating whether the response is safe to return.
        """
        start = time.monotonic()

        classified = self.client.classify_output(
            audit_id=audit_id,
            output=response,
            agent=self.agent,
        )

        elapsed_ms = int((time.monotonic() - start) * 1000)

        # Report the result to close the audit chain entry.
        try:
            self.client.report_result(
                audit_id=audit_id,
                success=classified.allowed,
                summary=(
                    f"Response classified. Guards triggered: {classified.guards_triggered}"
                    if classified.guards_triggered
                    else "Response classified clean."
                ),
                duration_ms=elapsed_ms,
                error=(
                    f"Guards triggered: {classified.guards_triggered}"
                    if not classified.allowed
                    else None
                ),
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return classified

    def wrap(self, anthropic_client: Any) -> "AnthropicClientProxy":
        """Return a proxy around an anthropic.Anthropic client instance.

        The proxy intercepts messages.create calls, runs governance, and
        classifies the response. Requires the anthropic package.

        Args:
            anthropic_client: An anthropic.Anthropic or anthropic.AsyncAnthropic
                client instance.

        Returns:
            AnthropicClientProxy wrapping the provided client.
        """
        return AnthropicClientProxy(
            raw_client=anthropic_client,
            governance=self,
        )


class _GovernedMessages:
    """Proxy for anthropic_client.messages with governance enforcement."""

    def __init__(self, raw_messages: Any, governance: AnthropicGovernance):
        self._raw = raw_messages
        self._gov = governance

    def create(self, **kwargs: Any) -> Any:
        """Intercept messages.create with governance checks."""
        decision = self._gov.intercept_request(kwargs)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            # Return a synthetic denial response if not enforcing.
            return {
                "id": "gov-denied",
                "type": "message",
                "role": "assistant",
                "content": [{"type": "text", "text": f"[GOVERNANCE DENIED] {decision.reason}"}],
                "model": kwargs.get("model", "unknown"),
                "stop_reason": "governance_denied",
                "usage": {"input_tokens": 0, "output_tokens": 0},
            }

        if decision.requires_approval:
            return {
                "id": f"gov-pending-{decision.audit_id}",
                "type": "message",
                "role": "assistant",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            f"[GOVERNANCE PENDING] Action requires approval. "
                            f"Audit ID: {decision.audit_id}"
                        ),
                    }
                ],
                "model": kwargs.get("model", "unknown"),
                "stop_reason": "governance_pending",
                "usage": {"input_tokens": 0, "output_tokens": 0},
            }

        # Call the real Anthropic API.
        response = self._raw.create(**kwargs)

        # Convert SDK response object to dict for classification.
        if hasattr(response, "model_dump"):
            response_dict = response.model_dump()
        elif hasattr(response, "to_dict"):
            response_dict = response.to_dict()
        else:
            response_dict = dict(response) if not isinstance(response, dict) else response

        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=response_dict,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] Anthropic response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return response


class AnthropicClientProxy:
    """Thin proxy around an anthropic.Anthropic client that enforces governance.

    Only .messages is proxied. Attributes that provide a path back to the
    raw provider (._raw_client, .beta, .beta.messages) are blocked and raise
    GovernanceViolation to prevent governance bypass.

    C3 fix (2026-04-24): _raw_client and beta access raise GovernanceViolation.
    """

    # Attributes that bypass governance and must be blocked.
    _BLOCKED_ATTRS: frozenset[str] = frozenset({
        "_raw_client",
        "_raw",
        "beta",
        "with_raw_response",
        "with_streaming_response",
    })

    def __init__(self, raw_client: Any, governance: AnthropicGovernance):
        # Use object.__setattr__ to avoid triggering __setattr__ overrides.
        object.__setattr__(self, "_proxy_raw", raw_client)
        object.__setattr__(self, "_proxy_messages", _GovernedMessages(
            raw_messages=raw_client.messages,
            governance=governance,
        ))
        object.__setattr__(self, "_proxy_governance", governance)

    @property
    def messages(self) -> _GovernedMessages:
        return object.__getattribute__(self, "_proxy_messages")

    def __getattr__(self, name: str) -> Any:
        """Block bypass paths; allow other attributes to fall through."""
        # Block any attribute that provides access back to raw provider.
        if name in AnthropicClientProxy._BLOCKED_ATTRS:
            from connexum_governance.models import GovernanceDecision, DecisionType
            import uuid
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=(
                    f"direct provider access via '{name}' is not permitted under governance. "
                    "Use governed_client.messages.create() only. "
                    "(C3: AnthropicClientProxy bypass protection)"
                ),
                audit_id=str(uuid.uuid4()),
            )
            from connexum_governance.models import GovernanceViolation
            raise GovernanceViolation(d)
        # Also block names starting with underscore that look like private client state.
        if name.startswith("_raw") or name.startswith("__"):
            from connexum_governance.models import GovernanceDecision, DecisionType
            import uuid
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=(
                    f"attribute '{name}' is blocked; direct provider access is not permitted "
                    "under governance. (C3: AnthropicClientProxy bypass protection)"
                ),
                audit_id=str(uuid.uuid4()),
            )
            from connexum_governance.models import GovernanceViolation
            raise GovernanceViolation(d)
        raw = object.__getattribute__(self, "_proxy_raw")
        return getattr(raw, name)
