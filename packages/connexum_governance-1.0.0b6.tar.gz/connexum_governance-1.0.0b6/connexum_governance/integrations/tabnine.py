"""Tabnine governance integration.

Tabnine is an enterprise code-completion AI that is editor-agnostic (VS Code,
JetBrains, Vim, Emacs, Eclipse, Sublime Text, Visual Studio). Its original
positioning is enterprise-compliance-first: every enterprise deal involves a
security questionnaire. That customer base is already sensitized to governance,
making this adapter a high-value integration.

Architecture:
  The primary adapter is TypeScript-native (src/ide-adapters/tabnine.ts).
  This Python shim lets a Python-hosted governance policy server participate
  in the Tabnine decision loop via HTTP.

  Seven distinct governable surfaces (parity with TS adapter):
    intercept_inline_completion(request)    -- inline completion gate
    intercept_chat(request)                 -- chat request gate
    intercept_code_review(request)          -- code review gate
    intercept_test_generation(request)      -- test generation gate
    intercept_documentation(request)        -- documentation generation gate
    intercept_commit_message(request)       -- commit message generation gate
    intercept_learn_from_codebase(request)  -- on-prem learning gate (STRICT)

  Deployment modes:
    tabnine-cloud          -- Tabnine-managed SaaS
    enterprise-self-hosted -- Customer-operated instance (air-gapped, VPC)
    pro                    -- Individual Tabnine Pro; no enterprise controls

  Privacy gate -- learnFromCodebase (the Tabnine-distinct surface):
    'pro' mode:
      ALWAYS DENIED. Pro has no on-premises training capability.
      Reason code: tabnine-learn-from-codebase-not-permitted-in-mode
    'tabnine-cloud' mode:
      ALWAYS DENIED. Training on Tabnine servers means data leaves the
      customer network perimeter.
      Reason code: tabnine-learn-from-codebase-not-permitted-in-mode
    'enterprise-self-hosted' WITHOUT learn_from_codebase=True:
      DENIED. Operator must make an explicit governance decision.
      Reason code: tabnine-learn-from-codebase-not-permitted-in-mode
    'enterprise-self-hosted' WITH learn_from_codebase=True:
      ALLOWED. Training corpus is still scanned for embedded secrets.

  Pen-test IDs mirrored from TS adapter:
    PT-ADAPT-TABNINE-1: empty pack_binding denied (pack-binding primacy)
    PT-ADAPT-TABNINE-2: auth tokens never appear in audit entries
    PT-ADAPT-TABNINE-3: invalid deployment_mode raises ValueError at init
    PT-ADAPT-TABNINE-4: learnFromCodebase privacy gate produces audit entry
                        with reason code tabnine-learn-from-codebase-not-permitted-in-mode

BAA-eligible deployment modes:
  enterprise-self-hosted (customer controls data residency)
  tabnine-cloud (with active Tabnine BAA)

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.tabnine import TabnineGovernedClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = TabnineGovernedClient(
        client=gov,
        agent_name="tabnine-agent",
        pack_binding=["hipaa"],
        deployment_mode="enterprise-self-hosted",
        learn_from_codebase=True,
    )

    # Gate an inline completion:
    decision = adapter.intercept_inline_completion({
        "filePath": "src/auth.py",
        "surroundingContext": "def login(user, password):",
        "packBinding": ["hipaa"],
    })

    # Gate a learnFromCodebase (blocked unless enterprise-self-hosted + opt-in):
    decision = adapter.intercept_learn_from_codebase({
        "repos": ["github.com/acme/api"],
        "packBinding": ["soc2"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Deployment modes
# ---------------------------------------------------------------------------

TABNINE_VALID_DEPLOYMENT_MODES: tuple[str, ...] = (
    "tabnine-cloud",
    "enterprise-self-hosted",
    "pro",
)

TABNINE_BAA_ELIGIBLE_MODES: tuple[str, ...] = (
    "enterprise-self-hosted",  # customer controls data residency
    "tabnine-cloud",           # eligible with active Tabnine BAA
)

# Modes where on-premises model training is architecturally possible.
# Even within this set the learn_from_codebase opt-in flag is still required.
TABNINE_LEARN_CAPABLE_MODES: tuple[str, ...] = (
    "enterprise-self-hosted",
)

# ---------------------------------------------------------------------------
# Secret patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",            re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",                re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",         re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",            re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",        re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",    re.compile(
        r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
    ("Bearer token",              re.compile(
        r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}",
        re.IGNORECASE,
    )),
    ("Database URL with creds",   re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("Tabnine auth token",        re.compile(
        r"tabnine[_\-]?(auth|token|key|secret)\s*[:=]\s*[\"']?\S{8,}[\"']?",
        re.IGNORECASE,
    )),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    """Return the name of the first matched secret pattern, or None."""
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_for_phi(text: str) -> Optional[str]:
    """Return the pattern string of the first matched PHI indicator, or None."""
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(
        p.lower() in ("hipaa", "hitech", "hipaa-hitech")
        for p in pack_binding
    )


def _scan_diff_for_secrets(diff: str) -> Optional[tuple[int, str]]:
    """
    Scan a unified diff for secret patterns on added lines (+).
    Returns (line_number, pattern_name) of the first match, or None.
    """
    for i, line in enumerate(diff.splitlines(), start=1):
        if not line.startswith("+") or line.startswith("+++"):
            continue
        content = line[1:]
        match = _scan_for_secrets(content)
        if match:
            return (i, match)
    return None


# ---------------------------------------------------------------------------
# TabnineGovernedClient
# ---------------------------------------------------------------------------

class TabnineGovernedClient(BaseGovernanceIntegration):
    """REST-client shim for Tabnine governance.

    Tabnine is TypeScript-native. This Python shim participates in the decision
    loop by governing all seven Tabnine hook surfaces:
      1. Inline completion (intercept_inline_completion)
      2. Chat (intercept_chat)
      3. Code review (intercept_code_review)
      4. Test generation (intercept_test_generation)
      5. Documentation generation (intercept_documentation)
      6. Commit message generation (intercept_commit_message)
      7. On-prem codebase learning (intercept_learn_from_codebase) -- STRICT

    Deployment modes: tabnine-cloud, enterprise-self-hosted, pro.
    BAA-eligible modes: enterprise-self-hosted, tabnine-cloud (with active BAA).
    pro is never BAA-eligible.
    learnFromCodebase is ALWAYS DENIED except in enterprise-self-hosted with
    explicit learn_from_codebase=True opt-in.

    Pen-tests:
      PT-ADAPT-TABNINE-1: empty pack_binding => denied (pack-binding primacy)
      PT-ADAPT-TABNINE-2: auth tokens never appear in audit entries
      PT-ADAPT-TABNINE-3: invalid deployment_mode raises ValueError at init
      PT-ADAPT-TABNINE-4: learnFromCodebase privacy gate with reason code
                          tabnine-learn-from-codebase-not-permitted-in-mode
    """

    _FRAMEWORK_NAME = "tabnine"
    _LAYER_NAME = "tabnine-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        deployment_mode: str = "tabnine-cloud",
        learn_from_codebase: bool = False,
        hipaa_reviewer_tier: str = "T2_LEAD",
        test_gen_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            deployment_mode: Tabnine deployment mode.
                             One of: tabnine-cloud, enterprise-self-hosted, pro.
            learn_from_codebase: Explicit opt-in for on-premises codebase learning.
                                 Only meaningful in 'enterprise-self-hosted' mode.
                                 Default: False (governance default-deny).
            hipaa_reviewer_tier: Reviewer tier for HIPAA/PHI requests.
            test_gen_reviewer_tier: Reviewer tier for test generation under regulated packs.

        Raises:
            ValueError: If deployment_mode is not a valid Tabnine deployment mode
                        (PT-ADAPT-TABNINE-3).
        """
        # PT-ADAPT-TABNINE-3: validate deployment_mode at construction time.
        if deployment_mode not in TABNINE_VALID_DEPLOYMENT_MODES:
            raise ValueError(
                f"TabnineGovernedClient: invalid deployment_mode '{deployment_mode}'. "
                f"Must be one of: {', '.join(TABNINE_VALID_DEPLOYMENT_MODES)}. "
                "Deployment mode is required to enforce data-residency and "
                "training-eligibility bounds."
            )
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.deployment_mode = deployment_mode
        self.learn_from_codebase = learn_from_codebase
        self.hipaa_reviewer_tier = hipaa_reviewer_tier
        self.test_gen_reviewer_tier = test_gen_reviewer_tier

    # ------------------------------------------------------------------
    # intercept_inline_completion -- inline completion gate
    # ------------------------------------------------------------------

    def intercept_inline_completion(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Tabnine inline completion request.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-TABNINE-1)
          2. Deployment mode BAA check under HIPAA binding
          3. Secret scan on surrounding context
          4. PHI proximity check under HIPAA binding

        Args:
            request: Inline completion request dict with keys:
                     surroundingContext, filePath, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        surrounding_context = str(
            request.get("surroundingContext", request.get("context", ""))
        )
        file_path = str(request.get("filePath", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-TABNINE-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Tabnine inline completion request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Deployment mode BAA check under HIPAA
        if _is_hipaa_binding(pack_binding) and self.deployment_mode not in TABNINE_BAA_ELIGIBLE_MODES:
            return self._deny(
                agent_id,
                f"Tabnine inline completion blocked: deployment mode '{self.deployment_mode}' "
                f"is not BAA-eligible for HIPAA pack binding {pack_binding}. "
                "Use 'enterprise-self-hosted' or 'tabnine-cloud' with an active Tabnine BAA.",
                pack_binding=pack_binding,
            )

        # Secret scan
        secret_match = _scan_for_secrets(surrounding_context)
        if secret_match:
            return self._deny(
                agent_id,
                f"Inline completion blocked: secret pattern '{secret_match}' in surrounding "
                f"context ({file_path or 'unknown file'}).",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(surrounding_context)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "tabnine",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Inline completion routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' in context. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "tabnine",
            "messageCount": 1,
            "packBinding": pack_binding,
            "filePath": file_path,
            "deploymentMode": self.deployment_mode,
        })

    # ------------------------------------------------------------------
    # intercept_chat -- chat gate
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Tabnine Chat request.

        Guards applied for 'pre' direction:
          1. Pack-binding primacy (PT-ADAPT-TABNINE-1)
          2. Deployment mode BAA check under HIPAA binding
          3. Secret scan on prompt
          4. PHI proximity check under HIPAA binding

        Guards applied for 'post' direction:
          1. Secret scan on response text

        Args:
            request: Chat request dict with keys:
                     promptText, responseText (post), direction,
                     packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        direction = str(request.get("direction", "pre"))
        prompt_text = str(request.get("promptText", request.get("prompt", "")))
        response_text = str(request.get("responseText", request.get("response", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-TABNINE-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Tabnine chat request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        if direction == "post":
            secret_match = _scan_for_secrets(response_text)
            if secret_match:
                return self._deny(
                    agent_id,
                    f"Chat response blocked: secret pattern '{secret_match}' in response.",
                    pack_binding=pack_binding,
                )
            return self.emit_event("llmResult", {
                "agentId": agent_id,
                "model": "tabnine",
                "responseText": response_text[:100],
                "packBinding": pack_binding,
            })

        # 'pre' direction

        # Deployment mode BAA check under HIPAA
        if _is_hipaa_binding(pack_binding) and self.deployment_mode not in TABNINE_BAA_ELIGIBLE_MODES:
            return self._deny(
                agent_id,
                f"Tabnine chat blocked: deployment mode '{self.deployment_mode}' is not "
                f"BAA-eligible for HIPAA pack binding {pack_binding}. "
                "Use 'enterprise-self-hosted' or 'tabnine-cloud' with an active Tabnine BAA.",
                pack_binding=pack_binding,
            )

        # Secret scan
        secret_match = _scan_for_secrets(prompt_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Chat request blocked: secret pattern '{secret_match}' in prompt.",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(prompt_text)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "tabnine",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Chat request routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' found in prompt. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "tabnine",
            "messageCount": 1,
            "packBinding": pack_binding,
            "deploymentMode": self.deployment_mode,
        })

    # ------------------------------------------------------------------
    # intercept_code_review -- code review gate
    # ------------------------------------------------------------------

    def intercept_code_review(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Tabnine code review request.

        Tabnine can perform automated code review on diff fragments.
        The diff is scanned for secrets on added lines before review
        generation is permitted.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-TABNINE-1)
          2. Diff secret scan (added lines only)

        Args:
            request: Code review request dict with keys:
                     diff, filePath, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        diff = str(request.get("diff", ""))
        file_path = str(request.get("filePath", "unknown"))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-TABNINE-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Tabnine code review request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Diff secret scan
        finding = _scan_diff_for_secrets(diff)
        if finding:
            line_num, pattern_name = finding
            return self._deny(
                agent_id,
                f"Code review blocked: secret pattern '{pattern_name}' "
                f"detected in diff at line {line_num}. "
                f"Remove the secret before requesting a code review. File: {file_path}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "tabnine:code-review-requested",
            "args": {
                "filePath": file_path,
                "diffPassed": True,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_test_generation -- test generation gate
    # ------------------------------------------------------------------

    def intercept_test_generation(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Tabnine test generation request.

        Tabnine can scaffold unit tests from function context. The context
        is scanned for secrets and PHI under HIPAA binding.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-TABNINE-1)
          2. Secret scan on function context
          3. PHI proximity check under HIPAA binding

        Args:
            request: Test generation request dict with keys:
                     functionContext, targetFile, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        function_context = str(
            request.get("functionContext", request.get("function", ""))
        )
        target_file = str(request.get("targetFile", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-TABNINE-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Tabnine test generation request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Secret scan
        secret_match = _scan_for_secrets(function_context)
        if secret_match:
            return self._deny(
                agent_id,
                f"Test generation blocked: secret pattern '{secret_match}' in function context.",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(function_context)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "tabnine",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Test generation routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' in function context. "
                        "Ensure generated tests do not contain identifiable health information. "
                        f"Reviewer tier: {self.test_gen_reviewer_tier}."
                    ),
                })

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "tabnine:test-generation-requested",
            "args": {
                "targetFile": target_file,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_documentation -- documentation generation gate
    # ------------------------------------------------------------------

    def intercept_documentation(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Tabnine documentation generation request.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-TABNINE-1)
          2. Secret scan on symbol context
          3. PHI proximity check under HIPAA binding

        Args:
            request: Documentation request dict with keys:
                     symbolContext, targetFile, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        symbol_context = str(
            request.get("symbolContext", request.get("symbol", ""))
        )
        target_file = str(request.get("targetFile", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-TABNINE-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Tabnine documentation request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Secret scan
        secret_match = _scan_for_secrets(symbol_context)
        if secret_match:
            return self._deny(
                agent_id,
                f"Documentation generation blocked: secret pattern '{secret_match}' "
                "in symbol context.",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(symbol_context)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "tabnine",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Documentation generation routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}'. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "tabnine:documentation-requested",
            "args": {
                "targetFile": target_file,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_commit_message -- commit message generation gate
    # ------------------------------------------------------------------

    def intercept_commit_message(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Tabnine commit message generation request.

        Classifies the unified diff for secret leaks BEFORE the generation
        prompt is sent.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-TABNINE-1)
          2. Diff secret scan (added lines only)

        Args:
            request: Commit message request dict with keys:
                     diff, branchName, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        diff = str(request.get("diff", ""))
        branch_name = str(request.get("branchName", "unknown"))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-TABNINE-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Tabnine commit message request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Diff secret scan
        finding = _scan_diff_for_secrets(diff)
        if finding:
            line_num, pattern_name = finding
            return self._deny(
                agent_id,
                f"Commit message generation blocked: secret pattern '{pattern_name}' "
                f"detected in diff at line {line_num}. "
                "Remove the secret from staged changes before generating a commit message. "
                f"Branch: {branch_name}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "tabnine:commit-message-requested",
            "args": {
                "branchName": branch_name,
                "diffPassed": True,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_learn_from_codebase -- on-prem learning gate (PT-ADAPT-TABNINE-4)
    # ------------------------------------------------------------------

    def intercept_learn_from_codebase(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Tabnine learnFromCodebase operation (PT-ADAPT-TABNINE-4).

        This is the Tabnine-distinct privacy-critical surface. Tabnine Enterprise
        can fine-tune a local model on customer code. Strict-mode enforcement:

          'pro' mode:
            ALWAYS DENIED. No on-premises training capability.
            Reason code: tabnine-learn-from-codebase-not-permitted-in-mode
          'tabnine-cloud' mode:
            ALWAYS DENIED. Training data would leave the customer network.
            Reason code: tabnine-learn-from-codebase-not-permitted-in-mode
          'enterprise-self-hosted' without learn_from_codebase=True:
            DENIED. Explicit operator opt-in required.
            Reason code: tabnine-learn-from-codebase-not-permitted-in-mode
          'enterprise-self-hosted' with learn_from_codebase=True:
            ALLOWED. Training corpus scanned for embedded secrets.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-TABNINE-1)
          2. Deployment mode + opt-in strict gate (PT-ADAPT-TABNINE-4)
          3. Secret scan on dataScope (if opt-in is confirmed)

        Args:
            request: Learn request dict with keys:
                     repos, dataScope, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        repos: list[str] = request.get("repos", [])
        data_scope = str(request.get("dataScope", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-TABNINE-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Tabnine learnFromCodebase request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # PT-ADAPT-TABNINE-4: strict mode check -- only learn-capable modes allowed.
        if self.deployment_mode not in TABNINE_LEARN_CAPABLE_MODES:
            return self._deny(
                agent_id,
                f"Tabnine learnFromCodebase blocked: deployment mode "
                f"'{self.deployment_mode}' does not support on-premises model training. "
                "On-prem learning requires 'enterprise-self-hosted' mode. "
                f"In '{self.deployment_mode}' mode, training data would leave the "
                "customer network perimeter or is not supported. "
                "Reason code: tabnine-learn-from-codebase-not-permitted-in-mode.",
                pack_binding=pack_binding,
            )

        # PT-ADAPT-TABNINE-4: explicit opt-in required even in enterprise-self-hosted.
        if not self.learn_from_codebase:
            return self._deny(
                agent_id,
                "Tabnine learnFromCodebase blocked: 'enterprise-self-hosted' mode detected "
                "but the adapter was not configured with learn_from_codebase=True. "
                "This is a deliberate governance default-deny. To enable on-premises "
                "codebase learning, set learn_from_codebase=True in TabnineGovernedClient "
                "and acknowledge that the training corpus will be scanned for secrets and "
                "PHI before the learn operation proceeds. "
                "Reason code: tabnine-learn-from-codebase-not-permitted-in-mode.",
                pack_binding=pack_binding,
            )

        # Opt-in confirmed. Scan dataScope for embedded secrets.
        if data_scope:
            secret_match = _scan_for_secrets(data_scope)
            if secret_match:
                return self._deny(
                    agent_id,
                    f"Tabnine learnFromCodebase blocked: secret pattern '{secret_match}' "
                    f"found in dataScope. Remove credentials from the data scope before "
                    "initiating codebase learning.",
                    pack_binding=pack_binding,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "tabnine:learn-from-codebase-requested",
            "args": {
                "repos": repos,
                "repoCount": len(repos),
                "deploymentMode": self.deployment_mode,
                "learnFromCodebaseOptIn": True,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown TabnineGovernedClient event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] TabnineGovernedClient output classifier: possible secret in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] TabnineGovernedClient output exfiltration scanner: possible "
                    f"secret/PHI in LLM response (agent: {agent_id}).",
                    file=sys.stderr,
                )

        # Inject deployment mode metadata and delegate to base
        enriched = {"deploymentMode": self.deployment_mode, **payload}
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload and forward it as a canonical governance event."""
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError(
                "TabnineGovernedClient webhook payload missing required field: 'eventType'"
            )
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError(
                "TabnineGovernedClient webhook payload missing required field: 'agentId'"
            )
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "TabninePolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return TabninePolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (canonical event surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# TabninePolicyBridge
# ---------------------------------------------------------------------------

class TabninePolicyBridge:
    """Bridge for Python-hosted policy participation in the Tabnine governance loop."""

    def __init__(
        self,
        adapter: TabnineGovernedClient,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:
                import logging as _logging
                _logging.getLogger(__name__).warning(
                    "Governance audit operation failed: %s", exc
                )

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
