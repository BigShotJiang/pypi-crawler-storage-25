"""
GovernedAutoGen -- governance enforcement for AutoGen v0.4+ (Python).

This is a FRAMEWORK ADAPTER operating at the autogen-agentchat / autogen-core
layer. It targets the REWRITTEN async-first AutoGen v0.4+ API
(packages: autogen-agentchat >= 0.4.0, autogen-core >= 0.4.0).

IMPORTANT: This adapter targets AutoGen v0.4+ ONLY. The deprecated pyautogen
package (legacy v0.2.x, synchronous) is NOT supported. If you are using
`import autogen` from pyautogen, migrate to autogen-agentchat / autogen-core
before using this adapter.

=== ARCHITECTURAL CONTRAST: AutoGen v0.4 vs other frameworks ===

LangChain's callback system is OBSERVABILITY-first. GovernedTool._run() is the
only guaranteed blocking path (see langchain_integration.py).

OpenAI Agents SDK provides FIRST-CLASS blocking via input/output guardrails --
a contract-guaranteed gate in the SDK's public API.

LlamaIndex and CrewAI: GovernedFunctionTool.__call__ / GovernanceCrewAITool._run()
are the guaranteed gates; callbacks provide observability.

AutoGen v0.4 uses an async-first message-passing design. The primary surfaces:

  FunctionTool (autogen_core.tools.FunctionTool / BaseTool):
    FunctionTool wraps a Python callable and is the primary tool primitive in
    autogen-core. The tool's run() and run_json() methods are the GUARANTEED
    BLOCKING PRIMITIVES. Subclassing FunctionTool and overriding run()/run_json()
    ensures governance runs before the underlying callable is invoked, regardless
    of which agent or orchestrator triggers the tool.

  BaseChatAgent.on_messages(messages, cancellation_token):
    The async message handler on all AutoGen v0.4 agents. Wrapping on_messages
    intercepts all incoming messages at the agent boundary. This provides an
    additional governance check for message injection (catching prompt injection
    that arrives via agent-to-agent messages or user input).

  RoundRobinGroupChat / SelectorGroupChat / Swarm:
    Multi-agent orchestrators. Each has a run() and run_stream() method. Wrapping
    run() provides a per-conversation governance check (catches drift across
    multi-turn multi-agent conversations). For handoff checks, wrap run() to
    inspect the flow before each turn.

  CancellationToken:
    AutoGen v0.4 uses CancellationToken for cooperative cancellation. On DENY,
    the adapter optionally cancels via the token (configurable) rather than
    raising an exception. This allows graceful cancellation compatible with
    AsyncIO task supervision.

BLOCKING STORY (ranked best to worst):
  1. GovernedAutoGenTool.run() / run_json()    -- GUARANTEED
       Runs inside tool dispatch path regardless of agent/orchestrator.
  2. wrap_chat_agent() on_messages intercept   -- GUARANTEED at agent boundary
       Blocks before any agent processing of the message.
  3. wrap_group_chat() run() intercept         -- BEST-EFFORT per conversation turn
       Catches orchestrator-level policy drift; fires per run() call.
  4. CancellationToken cancel path             -- GRACEFUL (configurable)
       Cooperative cancellation instead of exception on DENY.

ARCHITECTURE NOTE for customers:
  - Use GovernedAutoGenTool (or governed_autogen_tool() factory) for all tools
    registered with AutoGen agents. This is the GUARANTEED blocking path.
  - Use wrap_chat_agent() for defense-in-depth at the message boundary.
  - Use wrap_group_chat() for per-conversation governance checks.
  - CancellationToken integration is configurable (cancel_on_deny=True/False).

Action name namespace (for pack rule targeting):
  framework.autogen.tool_run          -- GovernedAutoGenTool.run() / run_json()
  framework.autogen.message_received  -- wrap_chat_agent on_messages
  framework.autogen.handoff           -- group chat handoff check
  framework.autogen.group_chat_run    -- wrap_group_chat pre-run check

Supported AutoGen version range (tested against mock primitives):
  autogen-agentchat >= 0.4.0
  autogen-core >= 0.4.0

IMPORTANT: Do NOT install pyautogen (legacy) alongside autogen-agentchat.
They conflict. Use `pip install autogen-agentchat autogen-core`.

Optional peer dependencies:
  autogen-agentchat >= 0.4.0
  autogen-core >= 0.4.0

@connexum/python-sdk -- Framework Adapter Layer (Sprint 5, WS-10)
"""

from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Union

from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations._wire_shape import build_check_action_body

# ---------------------------------------------------------------------------
# Type alias for check function injection (test isolation)
#
# Signature: async (governance_server_url: str, body: dict) -> dict
# Returns: {decision: ALLOW|DENY|REQUIRE_APPROVAL, reason, approvalId, auditId}
# ---------------------------------------------------------------------------

CheckFnType = Callable[[str, dict], Any]


# ---------------------------------------------------------------------------
# HTTP check helpers (same pattern as other adapters)
# ---------------------------------------------------------------------------

async def _do_check_async(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """Run an asynchronous governance check."""
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            return await check_fn(governance_server_url, body)
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        async with _httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


def _do_check_sync(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    """Run a synchronous governance check (used for sync fallback paths)."""
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            try:
                loop = asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(
                        lambda: asyncio.run(check_fn(governance_server_url, body))
                    )
                    return future.result()
            except RuntimeError:
                return asyncio.run(check_fn(governance_server_url, body))
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        with _httpx.Client(timeout=5.0) as client:
            resp = client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


# ---------------------------------------------------------------------------
# Decision enforcement helpers
# ---------------------------------------------------------------------------

def _enforce_decision_async_raises(
    result: dict,
    context_label: str,
    cancel_token: Any = None,
    cancel_on_deny: bool = False,
) -> None:
    """
    Raise GovernanceViolation or GovernancePendingApproval based on the decision.

    If cancel_on_deny=True and a CancellationToken is provided, cancels via
    the token instead of raising on DENY. This provides graceful AutoGen-native
    cancellation rather than an exception propagating through the async graph.

    Args:
        result: Governance check result dict.
        context_label: Human-readable label for error messages.
        cancel_token: AutoGen CancellationToken (optional). If provided and
            cancel_on_deny=True, cancels the token on DENY.
        cancel_on_deny: If True, cancel via token on DENY (graceful). If False
            (default), raise GovernanceViolation.
    """
    decision = result.get("decision", "ALLOW")

    if decision == "DENY":
        reason = result.get("reason") or "policy"
        sys.stderr.write(
            f"[GovernedAutoGen] DENIED for '{context_label}'. reason={reason}\n"
        )
        if cancel_on_deny and cancel_token is not None:
            # Graceful cooperative cancellation via AutoGen CancellationToken
            try:
                cancel_token.cancel()
            except Exception as cancel_exc:
                sys.stderr.write(
                    f"[GovernedAutoGen] CancellationToken.cancel() failed "
                    f"(token may already be cancelled): {cancel_exc}\n"
                )
            raise GovernanceViolation(
                decision="DENY",
                reason=f"[cancelled via CancellationToken] {reason}",
                audit_id=result.get("auditId"),
            )
        raise GovernanceViolation(
            decision="DENY",
            reason=reason,
            audit_id=result.get("auditId"),
        )

    if decision == "REQUIRE_APPROVAL":
        approval_id = result.get("approvalId")
        audit_id = result.get("auditId")
        if not approval_id:
            raise GovernanceViolation(
                decision="DENY",
                reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                audit_id=audit_id,
            )
        sys.stderr.write(
            f"[GovernedAutoGen] PENDING for '{context_label}'. "
            f"approvalId={approval_id}\n"
        )
        raise GovernancePendingApproval(
            approval_id=approval_id,
            audit_id=audit_id,
        )

    # ALLOW -- fall through


# ---------------------------------------------------------------------------
# GovernedAutoGenTool -- PRIMARY BLOCKING PRIMITIVE
#
# Subclasses / wraps a FunctionTool (autogen_core) and overrides run() and
# run_json() to enforce governance before the underlying tool callable runs.
#
# Why this is the GUARANTEED gate:
#   FunctionTool.run(args_dict, cancellation_token) is called by the AutoGen
#   runtime for every tool invocation. Overriding it means governance runs
#   inside the tool dispatch path regardless of which agent or orchestrator
#   triggered the call. Even agents that bypass on_messages routing will
#   still hit this gate when the tool is invoked.
# ---------------------------------------------------------------------------


class GovernedAutoGenTool:
    """
    Wraps an AutoGen FunctionTool / BaseTool with governance enforcement.

    This is the GUARANTEED BLOCKING PRIMITIVE for AutoGen v0.4+.

    Governance runs inside run() and run_json() -- the dispatch points called
    by the AutoGen runtime for every tool invocation -- regardless of which
    agent or orchestrator triggers the call.

    Usage:
        from connexum_governance.integrations.autogen_integration import (
            GovernedAutoGenTool,
        )

        # Wrap a FunctionTool
        raw_tool = FunctionTool(my_search_fn, description="Search the web")
        governed = GovernedAutoGenTool(
            tool=raw_tool,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )
        agent = AssistantAgent("assistant", tools=[governed])
    """

    def __init__(
        self,
        tool: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        cancel_on_deny: bool = False,
        _check_fn: Optional[CheckFnType] = None,
    ):
        """
        Args:
            tool: The AutoGen FunctionTool / BaseTool to wrap. Must have a
                .name attribute and a .run() or .run_json() method.
            governance_server_url: URL of the governance server.
            license_key: License / JWT key for the governance server.
            pack_ids: Compliance pack IDs to evaluate against.
            raise_on_deny: When True (default), DENY raises GovernanceViolation.
                When False, violations are logged to stderr but not raised.
            cancel_on_deny: When True, on DENY: cancel via CancellationToken
                (if provided to run()) THEN raise GovernanceViolation. Enables
                cooperative AutoGen-native cancellation on top of the exception.
            _check_fn: Test injection hook. Replaces the real HTTP check.
                Not part of the public API.
        """
        if tool is None:
            raise ValueError("[GovernedAutoGenTool] tool is required")
        tool_name = getattr(tool, "name", None)
        if not tool_name:
            raise ValueError(
                "[GovernedAutoGenTool] tool.name is required"
            )
        if not governance_server_url:
            raise ValueError(
                "[GovernedAutoGenTool] governance_server_url is required"
            )
        if not license_key:
            raise ValueError(
                "[GovernedAutoGenTool] license_key is required"
            )

        self._underlying = tool
        self.name: str = tool_name
        self.description: str = getattr(tool, "description", "") or ""
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._cancel_on_deny = cancel_on_deny
        self._check_fn = _check_fn

    async def _governance_check(self, input_preview: str, source: str) -> dict:
        """Run an async governance check for this tool."""
        return await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name=self.name,
                agent_name=f"autogen-tool:{self.name}",
                framework_action="framework.autogen.tool_run",
                input_dict={"input": input_preview[:200]},
                message_preview=input_preview[:200],
                pack_ids=self._pack_ids,
                extra_metadata={"toolName": self.name, "inputPreview": input_preview[:200]},
                source=source,
            ),
            check_fn=self._check_fn,
        )

    def _build_input_preview(self, args: Any) -> str:
        """Normalize tool args to a string preview for governance."""
        if isinstance(args, str):
            return args
        if isinstance(args, dict):
            import json as _json
            try:
                return _json.dumps(args)
            except Exception:
                return str(args)
        return str(args) if args is not None else ""

    async def run(
        self,
        args: Any,
        cancellation_token: Any = None,
        **kwargs: Any,
    ) -> Any:
        """
        Governed run(). Runs governance check before calling the underlying tool.

        DENY -> raises GovernanceViolation (and optionally cancels via token).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying tool.run().

        Args:
            args: Tool arguments (dict, str, or any serializable type).
            cancellation_token: AutoGen CancellationToken (optional).
                Used for cooperative cancellation when cancel_on_deny=True.
        """
        input_preview = self._build_input_preview(args)
        result = await self._governance_check(input_preview, "GovernedAutoGenTool.run")

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "Tool call denied by governance policy"
            sys.stderr.write(
                f"[GovernedAutoGenTool:{self.name}] run DENIED. reason={reason}\n"
            )
            if self._cancel_on_deny and cancellation_token is not None:
                try:
                    cancellation_token.cancel()
                except Exception as cancel_exc:
                    sys.stderr.write(
                        f"[GovernedAutoGenTool:{self.name}] CancellationToken.cancel() "
                        f"failed (token may already be cancelled): {cancel_exc}\n"
                    )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return f"[GOVERNANCE DENIED] {reason}"

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
                return "[GOVERNANCE PENDING] Approval required but no approvalId returned"
            sys.stderr.write(
                f"[GovernedAutoGenTool:{self.name}] run PENDING. approvalId={approval_id}\n"
            )
            if self._raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )
            return f"[GOVERNANCE PENDING] approvalId={approval_id}"

        # ALLOW -- delegate to underlying tool
        underlying_run = getattr(self._underlying, "run", None)
        if underlying_run is not None:
            if asyncio.iscoroutinefunction(underlying_run):
                return await underlying_run(args, cancellation_token, **kwargs)
            return underlying_run(args, **kwargs)
        raise AttributeError(
            f"[GovernedAutoGenTool] Underlying tool '{self.name}' has no run() method"
        )

    async def run_json(
        self,
        args: dict,
        cancellation_token: Any = None,
        **kwargs: Any,
    ) -> Any:
        """
        Governed run_json(). Same as run() but specifically for JSON-dict args.

        AutoGen's FunctionTool.run_json() is the entry point when the LLM
        provides tool args as a JSON object (the common case). Governing this
        path ensures ALL tool invocations -- both string and JSON -- are checked.

        DENY -> raises GovernanceViolation (and optionally cancels via token).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying tool.run_json() or .run().
        """
        input_preview = self._build_input_preview(args)
        result = await self._governance_check(input_preview, "GovernedAutoGenTool.run_json")

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "Tool call denied by governance policy"
            sys.stderr.write(
                f"[GovernedAutoGenTool:{self.name}] run_json DENIED. reason={reason}\n"
            )
            if self._cancel_on_deny and cancellation_token is not None:
                try:
                    cancellation_token.cancel()
                except Exception as cancel_exc:
                    sys.stderr.write(
                        f"[GovernedAutoGenTool:{self.name}] CancellationToken.cancel() "
                        f"failed in run_json (token may already be cancelled): {cancel_exc}\n"
                    )
            if self._raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return f"[GOVERNANCE DENIED] {reason}"

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if self._raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
                return "[GOVERNANCE PENDING] Approval required but no approvalId returned"
            sys.stderr.write(
                f"[GovernedAutoGenTool:{self.name}] run_json PENDING. "
                f"approvalId={approval_id}\n"
            )
            if self._raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )
            return f"[GOVERNANCE PENDING] approvalId={approval_id}"

        # ALLOW -- delegate to underlying tool
        underlying_run_json = getattr(self._underlying, "run_json", None)
        if underlying_run_json is not None:
            if asyncio.iscoroutinefunction(underlying_run_json):
                return await underlying_run_json(args, cancellation_token, **kwargs)
            return underlying_run_json(args, **kwargs)
        # Fallback to run() if run_json() not present
        underlying_run = getattr(self._underlying, "run", None)
        if underlying_run is not None:
            if asyncio.iscoroutinefunction(underlying_run):
                return await underlying_run(args, cancellation_token, **kwargs)
            return underlying_run(args, **kwargs)
        raise AttributeError(
            f"[GovernedAutoGenTool] Underlying tool '{self.name}' has no "
            "run_json() or run() method"
        )


# ---------------------------------------------------------------------------
# governed_autogen_tool -- convenience factory
# ---------------------------------------------------------------------------


def governed_autogen_tool(
    tool: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    cancel_on_deny: bool = False,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedAutoGenTool:
    """
    Factory function to create a GovernedAutoGenTool wrapping any AutoGen tool.

    Wraps the tool's run() and run_json() methods with governance enforcement.
    This is the GUARANTEED BLOCKING path for AutoGen v0.4+ tool execution.

    Args:
        tool: The AutoGen FunctionTool / BaseTool to wrap.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        cancel_on_deny: Whether to cancel via CancellationToken on DENY.
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedAutoGenTool instance wrapping the provided tool.
    """
    return GovernedAutoGenTool(
        tool=tool,
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        cancel_on_deny=cancel_on_deny,
        _check_fn=_check_fn,
    )


# ---------------------------------------------------------------------------
# wrap_chat_agent -- agent-level message boundary intercept
# ---------------------------------------------------------------------------


def wrap_chat_agent(
    agent: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wraps an AutoGen v0.4 BaseChatAgent's on_messages() method with governance.

    Intercepts all incoming messages at the agent boundary BEFORE the agent
    processes them. Provides defense-in-depth against prompt injection arriving
    via agent-to-agent messages or user input.

    Also auto-wraps any tools registered on the agent (via agent.tools attribute)
    with GovernedAutoGenTool for guaranteed tool-level blocking.

    BLOCKING CONTRACT:
      on_messages() governance check fires before the agent processes the message.
      If the check returns DENY, raises GovernanceViolation and the message is
      never processed by the agent.

    Idempotent: calling wrap_chat_agent twice on the same agent will not
    double-wrap (checked via _connexum_governed marker).

    Args:
        agent: An AutoGen v0.4 BaseChatAgent (or duck-type equivalent with
            on_messages() and optionally .tools).
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same agent with on_messages() wrapped and tools governed.
    """
    # Idempotency guard
    if getattr(agent, "_connexum_governed", False):
        return agent

    agent_name = getattr(agent, "name", "unknown")
    original_on_messages = agent.on_messages

    async def governed_on_messages(
        messages: Any,
        cancellation_token: Any = None,
        **kwargs: Any,
    ) -> Any:
        # Build message preview
        if isinstance(messages, list):
            preview_parts = []
            for m in messages:
                if isinstance(m, str):
                    preview_parts.append(m)
                elif hasattr(m, "content"):
                    content = getattr(m, "content", "")
                    preview_parts.append(str(content) if content else "")
                elif isinstance(m, dict):
                    preview_parts.append(m.get("content", "") or "")
            message_preview = " ".join(preview_parts)[:200]
        elif isinstance(messages, str):
            message_preview = messages[:200]
        elif hasattr(messages, "content"):
            message_preview = str(getattr(messages, "content", ""))[:200]
        else:
            message_preview = str(messages)[:200]

        # Governance check at message boundary
        result = await _do_check_async(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name="message_received",
                agent_name=f"autogen-agent:{agent_name}",
                framework_action="framework.autogen.message_received",
                input_dict={"message": message_preview},
                message_preview=message_preview,
                pack_ids=pack_ids,
                extra_metadata={"agentName": agent_name, "messagePreview": message_preview},
                source="wrap_chat_agent.on_messages",
            ),
            check_fn=_check_fn,
        )

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "Message blocked by governance policy"
            sys.stderr.write(
                f"[wrap_chat_agent:{agent_name}] on_messages DENIED. reason={reason}\n"
            )
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
            return None

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
                return None
            sys.stderr.write(
                f"[wrap_chat_agent:{agent_name}] on_messages PENDING. "
                f"approvalId={approval_id}\n"
            )
            if raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )
            return None

        # ALLOW -- delegate to original on_messages
        if asyncio.iscoroutinefunction(original_on_messages):
            if cancellation_token is not None:
                return await original_on_messages(messages, cancellation_token, **kwargs)
            return await original_on_messages(messages, **kwargs)
        if cancellation_token is not None:
            return original_on_messages(messages, cancellation_token, **kwargs)
        return original_on_messages(messages, **kwargs)

    agent.on_messages = governed_on_messages
    agent._connexum_governed = True

    # Auto-wrap tools registered on this agent
    agent_tools = getattr(agent, "tools", None)
    if agent_tools is not None:
        governed_tools = []
        for t in agent_tools:
            if getattr(t, "_connexum_governed", False):
                governed_tools.append(t)
                continue
            tool_name = getattr(t, "name", None)
            if tool_name:
                wrapped = GovernedAutoGenTool(
                    tool=t,
                    governance_server_url=governance_server_url,
                    license_key=license_key,
                    pack_ids=pack_ids,
                    raise_on_deny=raise_on_deny,
                    _check_fn=_check_fn,
                )
                wrapped._connexum_governed = True
                governed_tools.append(wrapped)
            else:
                sys.stderr.write(
                    f"[wrap_chat_agent] Tool without .name skipped: {t!r}\n"
                )
                governed_tools.append(t)
        agent.tools = governed_tools

    return agent


# ---------------------------------------------------------------------------
# wrap_group_chat -- orchestrator-level governance intercept
# ---------------------------------------------------------------------------


def wrap_group_chat(
    chat: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wraps an AutoGen v0.4 group chat orchestrator with governance enforcement.

    Intercepts run() and run_stream() on RoundRobinGroupChat, SelectorGroupChat,
    Swarm, or any duck-type equivalent. Runs a governance check before each
    orchestrator-level run, catching drift across multi-agent conversations.

    BLOCKING CONTRACT:
      run() / run_stream() governance check fires before any agent is invoked.
      DENY raises GovernanceViolation and the orchestrator run is blocked.

    Handoff detection: wrap_group_chat also checks handoff action namespace
    (framework.autogen.handoff) on each transition detected in streaming runs.

    Idempotent: calling wrap_group_chat twice will not double-wrap.

    Args:
        chat: An AutoGen v0.4 group chat instance with run() and/or run_stream().
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        The same group chat with run() and run_stream() wrapped.
    """
    if getattr(chat, "_connexum_governed", False):
        return chat

    chat_name = getattr(chat, "name", type(chat).__name__)

    async def _pre_run_check(action: str, message_preview: str = "") -> None:
        """Run governance check before orchestrator run."""
        # Tool-name slot uses last segment of action namespace for pack-rule routing
        tool_slot = action.split(".")[-1] if "." in action else action
        result = await _do_check_async(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name=tool_slot,
                agent_name=f"autogen-group-chat:{chat_name}",
                framework_action=action,
                input_dict={"message": message_preview[:200]},
                message_preview=message_preview[:200],
                pack_ids=pack_ids,
                extra_metadata={"chatName": chat_name, "chatType": type(chat).__name__},
                source="wrap_group_chat",
            ),
            check_fn=_check_fn,
        )
        decision = result.get("decision", "ALLOW")
        if decision == "DENY":
            reason = result.get("reason") or "Group chat run blocked by governance policy"
            sys.stderr.write(
                f"[wrap_group_chat:{chat_name}] DENIED. reason={reason}\n"
            )
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=reason,
                    audit_id=result.get("auditId"),
                )
        elif decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            audit_id = result.get("auditId")
            if not approval_id:
                if raise_on_deny:
                    raise GovernanceViolation(
                        decision="DENY",
                        reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                        audit_id=audit_id,
                    )
            elif raise_on_deny:
                raise GovernancePendingApproval(
                    approval_id=approval_id,
                    audit_id=audit_id,
                )

    # Wrap run()
    original_run = getattr(chat, "run", None)
    if original_run is not None:
        async def governed_run(task: Any = None, *args: Any, **kwargs: Any) -> Any:
            # Build task preview
            task_preview = ""
            if isinstance(task, str):
                task_preview = task[:200]
            elif hasattr(task, "content"):
                task_preview = str(getattr(task, "content", ""))[:200]
            elif isinstance(task, dict):
                task_preview = task.get("content", "")[:200]

            await _pre_run_check("framework.autogen.group_chat_run", task_preview)

            if asyncio.iscoroutinefunction(original_run):
                if task is not None:
                    return await original_run(task, *args, **kwargs)
                return await original_run(*args, **kwargs)
            if task is not None:
                return original_run(task, *args, **kwargs)
            return original_run(*args, **kwargs)

        chat.run = governed_run

    # Wrap run_stream()
    original_run_stream = getattr(chat, "run_stream", None)
    if original_run_stream is not None:
        async def governed_run_stream(task: Any = None, *args: Any, **kwargs: Any):
            task_preview = ""
            if isinstance(task, str):
                task_preview = task[:200]
            elif hasattr(task, "content"):
                task_preview = str(getattr(task, "content", ""))[:200]

            await _pre_run_check("framework.autogen.group_chat_run", task_preview)

            # Yield from original stream, checking handoff events
            if asyncio.iscoroutinefunction(original_run_stream):
                gen = original_run_stream(task, *args, **kwargs) if task is not None else original_run_stream(*args, **kwargs)
                async for item in gen:
                    # Check for handoff events in streamed messages
                    item_type = getattr(item, "type", None) or getattr(item, "__class__", {})
                    type_name = str(item_type).lower() if item_type else ""
                    if "handoff" in type_name or getattr(item, "is_handoff", False):
                        try:
                            await _pre_run_check("framework.autogen.handoff")
                        except (GovernanceViolation, GovernancePendingApproval):
                            raise
                        except Exception as exc:
                            sys.stderr.write(
                                f"[wrap_group_chat] handoff check error: {exc}\n"
                            )
                    yield item
            else:
                # Sync generator (uncommon in AutoGen v0.4 but supported)
                gen = original_run_stream(task, *args, **kwargs) if task is not None else original_run_stream(*args, **kwargs)
                if hasattr(gen, "__anext__"):
                    # It returned an async generator even from a non-coroutine function
                    async for item in gen:
                        yield item
                else:
                    for item in gen:
                        yield item

        chat.run_stream = governed_run_stream

    chat._connexum_governed = True
    return chat


# ---------------------------------------------------------------------------
# GovernedAutoGenInstance -- namespace returned by factory
# ---------------------------------------------------------------------------


@dataclass
class GovernedAutoGenInstance:
    """
    Governed AutoGen object returned by create_governed_autogen().

    Exposes all integration helpers for the AutoGen v0.4 framework adapter.
    """

    _governance_server_url: str = field(repr=False)
    _license_key: str = field(repr=False)
    _pack_ids: list = field(default_factory=list, repr=False)
    _raise_on_deny: bool = field(default=True, repr=False)
    _cancel_on_deny: bool = field(default=False, repr=False)
    _check_fn: Optional[CheckFnType] = field(default=None, repr=False)

    def governed_tool(self, tool: Any) -> GovernedAutoGenTool:
        """
        Wrap a single AutoGen tool with governed run() / run_json().

        GUARANTEED BLOCKING: governance check runs before tool execution.
        """
        return GovernedAutoGenTool(
            tool=tool,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            cancel_on_deny=self._cancel_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_agent(self, agent: Any) -> Any:
        """
        Wrap an AutoGen v0.4 BaseChatAgent's on_messages() with governance.

        Also auto-wraps tools registered on the agent.
        Idempotent.
        """
        return wrap_chat_agent(
            agent=agent,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_group_chat(self, chat: Any) -> Any:
        """
        Wrap an AutoGen v0.4 group chat orchestrator with governance.

        Wraps run() and run_stream() for per-conversation governance checks.
        Idempotent.
        """
        return wrap_group_chat(
            chat=chat,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )


def create_governed_autogen(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    cancel_on_deny: bool = False,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedAutoGenInstance:
    """
    Primary factory for the AutoGen v0.4 governance adapter.

    Returns a GovernedAutoGenInstance exposing all integration helpers.

    ARCHITECTURAL NOTE: AutoGen v0.4 is async-first. All governance checks
    in this adapter are async. The primary blocking primitive is
    GovernedAutoGenTool.run() / run_json() -- guaranteed to fire before
    any tool execution regardless of agent or orchestrator.

    Enforcement layers (in order of blocking strength):
    1. GovernedAutoGenTool (run/run_json) -- GUARANTEED for tool dispatch
    2. wrap_chat_agent on_messages         -- GUARANTEED at agent boundary
    3. wrap_group_chat run/run_stream      -- BEST-EFFORT per conversation
    4. CancellationToken cancel path       -- GRACEFUL (cooperative cancel)

    Usage:
        gov = create_governed_autogen(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        # Option 1 (GUARANTEED BLOCKING): wrap individual tools
        safe_tool = gov.governed_tool(raw_function_tool)
        agent = AssistantAgent("assistant", tools=[safe_tool])

        # Option 2 (agent message boundary): wrap the agent
        agent = gov.wrap_agent(agent)

        # Option 3 (conversation-level): wrap the group chat
        group_chat = gov.wrap_group_chat(RoundRobinGroupChat([agent1, agent2]))
        await group_chat.run(task="Analyze this patient data")

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        cancel_on_deny: Whether to cancel via CancellationToken on DENY.
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedAutoGenInstance with all integration helpers.
    """
    if not governance_server_url:
        raise ValueError(
            "[create_governed_autogen] governance_server_url is required"
        )
    if not license_key:
        raise ValueError(
            "[create_governed_autogen] license_key is required"
        )

    return GovernedAutoGenInstance(
        _governance_server_url=governance_server_url,
        _license_key=license_key,
        _pack_ids=pack_ids or [],
        _raise_on_deny=raise_on_deny,
        _cancel_on_deny=cancel_on_deny,
        _check_fn=_check_fn,
    )
