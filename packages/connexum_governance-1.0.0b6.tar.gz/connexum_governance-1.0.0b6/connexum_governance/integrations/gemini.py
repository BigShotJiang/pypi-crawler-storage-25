"""Google Gemini governance integration for Connexum governance.

Wraps calls to the Gemini GenerativeModel API with pre-call governance
checks and post-call G-series output classification.

BAA status: Google Gemini (consumer tier) does NOT offer a BAA. Google
Cloud Vertex AI Gemini may offer BAA through Google Cloud's HIPAA-eligible
services, but the base Gemini API does not.

Supports Gemini's function calling format:
  - functionCall.name / functionCall.args in model responses
  - tools array in generation requests

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.gemini import GeminiGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    gg = GeminiGovernance(client=gov, agent_name="gemini-agent")

    # Intercept a request
    decision = gg.intercept_request({
        "model": "gemini-1.5-flash",
        "contents": [{"role": "user", "parts": [{"text": "Hello"}]}],
    })

    # Use the proxy (requires google-generativeai package)
    import google.generativeai as genai
    raw_model = genai.GenerativeModel("gemini-1.5-flash")
    governed_model = gg.wrap(raw_model)
    response = governed_model.generate_content("Hello")
"""

from __future__ import annotations

import sys
import time
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
    GovernanceViolation,
)

_PROVIDER_ID = "gemini"
_BAA_AVAILABLE = False
_BAA_SCOPE = None
_BAA_NOTES = (
    "Gemini API (consumer tier) does not offer a BAA. "
    "Vertex AI Gemini may be HIPAA-eligible through Google Cloud -- "
    "use GeminiGovernance only for non-PHI workloads unless confirmed via Vertex AI."
)

# F-NEW-GEMMA-PY (Layer 5.5.2): Gemma model-family parity with TypeScript
# (see src/llm-adapters/google.ts KNOWN_GEMMA_MODEL_IDS at line 161).
# Gemma is Google's open-weight family (Apache 2.0 + Gemma Terms of Use).
# Capability bundle distinguishes open-weight from closed-weight Gemini for
# packs that gate on model provenance (e.g., EU AI Act Art. 53 source-code
# disclosure obligations for general-purpose models).
#
# Gemma 4 forward-compat: family detection is prefix-based (`gemma-`,
# `paligemma-`), so future Gemma generations (gemma-5-*, etc.) classify
# as 'gemma' even before the explicit registry entry lands.
#
# Source: Google AI Studio + Vertex AI Model Garden + DeepMind Gemma pages
# (Gemma 2: gemma-2-Nb-it, paligemma; Gemma 3: gemma-3-Nb-it; Gemma 4 GA
# April 2026: edge "Any-to-Any" E2B/E4B + 26B-MoE + 31B-dense, all
# instruction-tuned).
KNOWN_GEMMA_MODEL_IDS: tuple[str, ...] = (
    # Gemma 2 generation
    "gemma-2-2b-it",
    "gemma-2-9b-it",
    "gemma-2-27b-it",
    # Gemma 3 generation (released early 2025)
    "gemma-3-1b-it",
    "gemma-3-4b-it",
    "gemma-3-12b-it",
    "gemma-3-27b-it",
    # Gemma 4 generation (released April 2026; instruction-tuned variants).
    # E2B / E4B are "Any-to-Any" (text + image + audio) edge models;
    # 26b-a4b is a Mixture-of-Experts (26B total / 4B active);
    # 31b is the dense flagship (vision + text).
    "gemma-4-e2b-it",
    "gemma-4-e4b-it",
    "gemma-4-26b-a4b-it",
    "gemma-4-31b-it",
    # Multimodal vision (Gemma 2 generation). No PaliGemma-3 / PaliGemma-4
    # shipped as of 2026-05-09; multimodal succession in Gemma 4 is via the
    # E2B/E4B Any-to-Any line above.
    "paligemma-3b-mix-224",
)
_GEMMA_PREFIXES: tuple[str, ...] = ("gemma-", "paligemma-")
_GEMINI_PREFIX = "gemini-"


def get_google_model_family(model_id: str) -> str:
    """Classify a Google model id as 'gemma' / 'gemini' / 'unknown'.

    Mirrors the TypeScript implementation at
    src/llm-adapters/google.ts:getGoogleModelFamily.

    Prefix-based so Gemma 3, Gemma 4, and any future generation classify
    correctly even before they land in KNOWN_GEMMA_MODEL_IDS.

    Args:
        model_id: e.g. 'gemma-2-9b-it', 'gemma-4-27b-it', 'gemini-1.5-pro'.

    Returns:
        'gemma' for open-weight Gemma family (incl. paligemma + future
        generations), 'gemini' for closed-weight Gemini family,
        'unknown' for anything else.
    """
    if not isinstance(model_id, str):
        return "unknown"
    lower = model_id.lower()
    if any(lower.startswith(p) for p in _GEMMA_PREFIXES):
        return "gemma"
    if lower.startswith(_GEMINI_PREFIX):
        return "gemini"
    return "unknown"


def is_open_weight_google_model(model_id: str) -> bool:
    """True for Gemma-family ids; False for Gemini-family or unknown."""
    return get_google_model_family(model_id) == "gemma"


class GeminiGovernance:
    """Governance wrapper for the Gemini GenerativeModel API.

    Intercepts generation requests and classifies responses through the
    nine-guard G-series. Emits a warning at init if the governance server
    is configured with a HIPAA pack binding, since Gemini lacks a BAA.

    Does NOT depend on the google-generativeai package at import time.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)

        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        """Check a pending generate_content request against governance.

        Extracts: model, message count (from contents), tool names
        (from tools/function_declarations), and system instruction digest.

        Args:
            request: The dict describing the generation request.
                May contain: model, contents, tools, system_instruction.

        Returns:
            GovernanceDecision (ALLOW / DENY / REQUIRE_APPROVAL).

        Raises:
            GovernanceViolation: if enforce=True and the decision is DENY.
        """
        contents = request.get("contents", [])

        # Extract system instruction digest (Gemini uses system_instruction field)
        system_instruction = request.get("system_instruction", "")
        if isinstance(system_instruction, dict):
            parts = system_instruction.get("parts", [])
            system_instruction = " ".join(
                p.get("text", "") for p in parts if isinstance(p, dict)
            )
        system_digest = str(system_instruction)[:500]

        # Extract tool names from function declarations
        tools = request.get("tools", [])
        tool_names: list[str] = []
        for tool_item in tools:
            if isinstance(tool_item, dict):
                fn_decls = tool_item.get("function_declarations", [])
                for fn in fn_decls:
                    if isinstance(fn, dict):
                        name = fn.get("name", "")
                        if name:
                            tool_names.append(name)

        # F-NEW-GEMMA-PY: surface Google model family + open-weight provenance
        # so packs that gate on model provenance (e.g., EU AI Act Art. 53)
        # can branch on the Gemma vs Gemini distinction.
        model_id = request.get("model", "unknown")
        family = get_google_model_family(model_id) if isinstance(model_id, str) else "unknown"

        gov_input: dict[str, Any] = {
            "model": model_id,
            "family": family,
            "isOpenWeight": family == "gemma",
            "systemPromptDigest": system_digest,
            "messageCount": len(contents),
            "toolCount": len(tool_names),
            "toolNames": tool_names,
        }

        return self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )

    def intercept_response(
        self,
        response: dict[str, Any],
        audit_id: str,
    ) -> ClassifiedResponse:
        """Classify a Gemini generate_content response through the G-series guards.

        Args:
            response: Raw response dict (or SDK object converted to dict).
            audit_id: The audit_id from the preceding intercept_request decision.

        Returns:
            ClassifiedResponse indicating whether the response is safe to return.
        """
        start = time.monotonic()

        classified = self.client.classify_output(
            audit_id=audit_id,
            output=response,
            agent=self.agent,
        )

        elapsed_ms = int((time.monotonic() - start) * 1000)

        try:
            self.client.report_result(
                audit_id=audit_id,
                success=classified.allowed,
                summary=(
                    f"Response classified. Guards triggered: {classified.guards_triggered}"
                    if classified.guards_triggered
                    else "Response classified clean."
                ),
                duration_ms=elapsed_ms,
                error=(
                    f"Guards triggered: {classified.guards_triggered}"
                    if not classified.allowed
                    else None
                ),
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return classified

    def wrap(self, gemini_model: Any) -> "GeminiModelProxy":
        """Return a proxy around a google.generativeai.GenerativeModel instance.

        Args:
            gemini_model: A google.generativeai.GenerativeModel instance.

        Returns:
            GeminiModelProxy wrapping the provided model.
        """
        return GeminiModelProxy(raw_model=gemini_model, governance=self)


def _response_to_dict(response: Any) -> dict[str, Any]:
    """Convert a Gemini SDK GenerateContentResponse to a plain dict."""
    if isinstance(response, dict):
        return response
    if hasattr(response, "to_dict"):
        return response.to_dict()
    if hasattr(response, "__dict__"):
        return response.__dict__
    return {"raw": str(response)}


class GeminiModelProxy:
    """Thin proxy around a google.generativeai.GenerativeModel with governance.

    Intercepts generate_content() calls. All other attributes pass through
    to the underlying model unchanged.
    """

    def __init__(self, raw_model: Any, governance: GeminiGovernance):
        self._raw = raw_model
        self._gov = governance

    def generate_content(self, contents: Any, **kwargs: Any) -> Any:
        """Intercept generate_content with governance checks."""
        # Build a request dict for intercept_request
        if isinstance(contents, str):
            contents_list = [{"role": "user", "parts": [{"text": contents}]}]
        elif isinstance(contents, list):
            contents_list = contents
        else:
            contents_list = [contents]

        model_name = getattr(self._raw, "model_name", "unknown")
        request: dict[str, Any] = {
            "model": model_name,
            "contents": contents_list,
        }
        if "tools" in kwargs:
            request["tools"] = kwargs["tools"]
        if "system_instruction" in kwargs:
            request["system_instruction"] = kwargs["system_instruction"]

        decision = self._gov.intercept_request(request)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {
                "candidates": [
                    {
                        "content": {
                            "parts": [{"text": f"[GOVERNANCE DENIED] {decision.reason}"}],
                            "role": "model",
                        },
                        "finish_reason": "GOVERNANCE_DENIED",
                    }
                ]
            }

        if decision.requires_approval:
            return {
                "candidates": [
                    {
                        "content": {
                            "parts": [
                                {
                                    "text": (
                                        f"[GOVERNANCE PENDING] Action requires approval. "
                                        f"Audit ID: {decision.audit_id}"
                                    )
                                }
                            ],
                            "role": "model",
                        },
                        "finish_reason": "GOVERNANCE_PENDING",
                    }
                ]
            }

        response = self._raw.generate_content(contents, **kwargs)
        response_dict = _response_to_dict(response)

        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=response_dict,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] Gemini response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)
