"""Ollama governance integration for Connexum governance.

Wraps calls to the Ollama REST API (self-hosted LLMs) with pre-call
governance checks and post-call G-series output classification.

Ollama runs locally at loopback (127.0.0.1:11434 by default). Since it
is self-hosted and local, no BAA is required -- there is no third-party
data processor involved. However, governance enforcement is still valuable
to prevent local model calls from accessing PHI without proper audit logging,
restrict tool use, and enforce organizational policies on local LLM usage.

Wire format:
  POST <base_url>/api/chat  -- chat (non-streaming and streaming)
  POST <base_url>/api/generate  -- single-turn generate

SSRF note: The TS adapter registers a loopback allowance with ssrf-guard.
The Python SDK does not implement ssrf-guard (that lives in the TypeScript
governance engine). At the Python layer, we validate that the base_url
is loopback (127.0.0.1 or localhost) and emit a warning if it is not.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.ollama import OllamaGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    og = OllamaGovernance(
        client=gov,
        agent_name="ollama-agent",
        base_url="http://127.0.0.1:11434",
    )

    decision = og.intercept_request({
        "model": "llama3.2",
        "messages": [{"role": "user", "content": "Hello"}],
    })
"""

from __future__ import annotations

import sys
import time
from typing import Any, Optional
from urllib.parse import urlparse

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
    GovernanceViolation,
)

_PROVIDER_ID = "ollama"
_BAA_AVAILABLE = False
_BAA_SCOPE = None
_BAA_NOTES = "Ollama is self-hosted and local. No third-party BAA required."

# Loopback addresses considered safe for SSRF purposes
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})


def _is_loopback(url: str) -> bool:
    """Return True if the URL resolves to a loopback address."""
    try:
        parsed = urlparse(url)
        return parsed.hostname in _LOOPBACK_HOSTS
    except Exception as exc:
        # H2: URL parse failure defaults to False (not loopback), log for diagnostics.
        import logging as _logging
        _logging.getLogger(__name__).warning("_is_loopback URL parse failed for %r: %s", url, exc)
        return False


class OllamaGovernance:
    """Governance wrapper for the Ollama REST API.

    Intercepts /api/chat and /api/generate requests and classifies responses
    through the nine-guard G-series. Validates that the Ollama base URL is
    loopback to prevent accidental data exfiltration.

    Emits a warning if a HIPAA-relevant system prompt is detected, since Ollama
    (local) has no BAA -- processing PHI via a local model is a HIPAA risk
    unless the local compute is within a covered entity's secure environment.

    Does NOT depend on the ollama or requests package at import time.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        base_url: str = "http://127.0.0.1:11434",
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)
        self.base_url = base_url

        if not _is_loopback(base_url):
            print(
                f"[WARN] OllamaGovernance: base_url '{base_url}' is not a loopback address. "
                "Data may be sent to a remote host. Ensure this is intentional and the "
                "remote host is within your security boundary.",
                file=sys.stderr,
            )

        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        """Check a pending Ollama /api/chat or /api/generate request.

        Extracts: model name, message count, system prompt digest, and
        tool names (Ollama 0.3.x tool-use format: tools array in request).

        Args:
            request: The dict for the Ollama API request.
                /api/chat format: model, messages, tools (optional), options.
                /api/generate format: model, prompt, system (optional).

        Returns:
            GovernanceDecision (ALLOW / DENY / REQUIRE_APPROVAL).

        Raises:
            GovernanceViolation: if enforce=True and the decision is DENY.
        """
        model = request.get("model", "unknown")

        # /api/chat format
        messages = request.get("messages", [])
        system_digest = ""
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "system":
                content = msg.get("content", "")
                system_digest = str(content)[:500]
                break

        # /api/generate format has a top-level "system" field
        if not system_digest:
            gen_system = request.get("system", "")
            if gen_system:
                system_digest = str(gen_system)[:500]

        # Ollama 0.3.x tool-use format
        tools = request.get("tools", [])
        tool_names: list[str] = []
        for tool_item in tools:
            if isinstance(tool_item, dict):
                fn = tool_item.get("function", {})
                name = fn.get("name", "")
                if name:
                    tool_names.append(name)

        # Also check for "prompt" field (generate format)
        has_generate_prompt = bool(request.get("prompt"))

        gov_input: dict[str, Any] = {
            "model": model,
            "baseUrl": self.base_url,
            "systemPromptDigest": system_digest,
            "messageCount": len(messages),
            "toolCount": len(tool_names),
            "toolNames": tool_names,
            "isGenerateFormat": has_generate_prompt,
            "provider": "ollama",
        }

        return self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )

    def intercept_response(
        self,
        response: dict[str, Any],
        audit_id: str,
    ) -> ClassifiedResponse:
        """Classify an Ollama API response through the G-series guards.

        Args:
            response: Raw response dict from Ollama.
            audit_id: The audit_id from the preceding intercept_request decision.

        Returns:
            ClassifiedResponse indicating whether the response is safe to return.
        """
        start = time.monotonic()

        classified = self.client.classify_output(
            audit_id=audit_id,
            output=response,
            agent=self.agent,
        )

        elapsed_ms = int((time.monotonic() - start) * 1000)

        try:
            self.client.report_result(
                audit_id=audit_id,
                success=classified.allowed,
                summary=(
                    f"Response classified. Guards triggered: {classified.guards_triggered}"
                    if classified.guards_triggered
                    else "Response classified clean."
                ),
                duration_ms=elapsed_ms,
                error=(
                    f"Guards triggered: {classified.guards_triggered}"
                    if not classified.allowed
                    else None
                ),
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return classified

    def wrap(self, ollama_client: Any) -> "OllamaClientProxy":
        """Return a proxy around an ollama-python client instance.

        Intercepts chat() and generate() calls.

        Args:
            ollama_client: An ollama.Client instance (from the ollama Python package).

        Returns:
            OllamaClientProxy wrapping the provided client.
        """
        return OllamaClientProxy(raw_client=ollama_client, governance=self)


class OllamaClientProxy:
    """Thin proxy around an ollama.Client with governance.

    Intercepts chat() and generate() calls. All other attributes pass
    through to the underlying client unchanged.
    """

    def __init__(self, raw_client: Any, governance: OllamaGovernance):
        self._raw = raw_client
        self._gov = governance

    def chat(self, **kwargs: Any) -> Any:
        """Intercept ollama.chat() with governance checks."""
        request = dict(kwargs)
        decision = self._gov.intercept_request(request)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {
                "model": kwargs.get("model", "unknown"),
                "message": {
                    "role": "assistant",
                    "content": f"[GOVERNANCE DENIED] {decision.reason}",
                },
                "done": True,
                "done_reason": "governance_denied",
            }

        if decision.requires_approval:
            return {
                "model": kwargs.get("model", "unknown"),
                "message": {
                    "role": "assistant",
                    "content": (
                        f"[GOVERNANCE PENDING] Action requires approval. "
                        f"Audit ID: {decision.audit_id}"
                    ),
                },
                "done": True,
                "done_reason": "governance_pending",
            }

        response = self._raw.chat(**kwargs)

        response_dict = response if isinstance(response, dict) else {}
        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=response_dict,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] Ollama response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return response

    def generate(self, **kwargs: Any) -> Any:
        """Intercept ollama.generate() with governance checks."""
        request = dict(kwargs)
        decision = self._gov.intercept_request(request)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {
                "model": kwargs.get("model", "unknown"),
                "response": f"[GOVERNANCE DENIED] {decision.reason}",
                "done": True,
                "done_reason": "governance_denied",
            }

        if decision.requires_approval:
            return {
                "model": kwargs.get("model", "unknown"),
                "response": (
                    f"[GOVERNANCE PENDING] Action requires approval. "
                    f"Audit ID: {decision.audit_id}"
                ),
                "done": True,
                "done_reason": "governance_pending",
            }

        response = self._raw.generate(**kwargs)

        response_dict = response if isinstance(response, dict) else {}
        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=response_dict,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] Ollama generate response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)
