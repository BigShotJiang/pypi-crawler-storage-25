"""HuggingFace governance integration for Connexum governance.

Wraps HuggingFace InferenceClient (text_generation / chat_completion),
transformers.pipeline(), and raw HTTP inference API calls with pre-call
governance checks and post-call G-series output classification.

BAA status: HuggingFace does NOT offer a standard BAA. Enterprise Hub
plans may negotiate per-deployment data processing terms; treat
HuggingFace as no-BAA for HIPAA-scoped data unless explicitly agreed.

Closes F-NEW-PRODUCT-AGENT-DIR-HUGGINGFACE-WRAPPER.

Surfaces covered:
  1. ``huggingface_hub.InferenceClient`` — text_generation / chat_completion
  2. ``transformers.pipeline()`` — callable pipeline (text inputs)
  3. Raw HTTP shape — {model, inputs: str} used by direct POST callers

Usage::

    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.huggingface import GovernedHuggingFace

    gov = GovernanceClient(api_url="...", license_key="...")
    hf = GovernedHuggingFace(client=gov, agent_name="hf-agent")

    # Intercept an InferenceClient chat_completion request
    decision = hf.intercept_request({
        "model": "meta-llama/Llama-3.1-8B-Instruct",
        "messages": [{"role": "user", "content": "Hello"}],
        "max_tokens": 256,
    })

    # Intercept a transformers.pipeline() call
    decision = hf.intercept_request({
        "model": "gpt2",
        "inputs": "Tell me a story",
        "max_new_tokens": 128,
    })

    # Wrap a real client instance for automatic governance
    from huggingface_hub import InferenceClient
    raw_client = InferenceClient(model="meta-llama/Llama-3.1-8B-Instruct")
    governed = hf.wrap(raw_client)
    result = governed.text_generation(prompt="Hello world")
"""

from __future__ import annotations

import sys
import time
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
    GovernanceViolation,
)

_PROVIDER_ID = "huggingface"
_BAA_AVAILABLE = False
_BAA_SCOPE = None
_BAA_NOTES = (
    "HuggingFace does not offer a standard BAA. Enterprise Hub plans "
    "may negotiate per-deployment data processing terms; treat as "
    "no-BAA for HIPAA-scoped data unless explicitly agreed."
)


class GovernedHuggingFace:
    """Governance wrapper for HuggingFace inference surfaces.

    Supports three request shapes:
    - InferenceClient chat_completion: ``{model, messages: [...], max_tokens}``
    - InferenceClient / pipeline text_generation: ``{model, inputs: str, max_new_tokens}``
    - Raw HTTP: same as text_generation shape above

    Does NOT import ``huggingface_hub`` or ``transformers`` at import time —
    the wrapper intercepts dict-shaped requests and is library-agnostic.

    Per Locked Invariant 10 (push-receive only), this wrapper never calls
    OUT to customer infrastructure beyond the HuggingFace inference endpoint
    itself. The governance check fires against the Connexum sidecar; the
    actual HF call is owned entirely by the customer's code.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
    ) -> None:
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)
        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        """Check a pending HuggingFace inference request against governance.

        Handles both the chat_completion shape (``messages`` list) and the
        text_generation / pipeline shape (``inputs`` string).

        Args:
            request: Dict describing the inference call. Recognised keys:
                ``model``, ``messages``, ``inputs``, ``max_tokens``,
                ``max_new_tokens``.

        Returns:
            GovernanceDecision (ALLOW / DENY / REQUIRE_APPROVAL).

        Raises:
            GovernanceViolation: if enforce=True and the decision is DENY.
        """
        messages = request.get("messages", [])
        system_digest = ""

        # Chat-completion shape: extract system message digest
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "system":
                c = msg.get("content", "")
                if isinstance(c, str):
                    system_digest = c[:500]
                break

        # Text-generation / pipeline shape: extract inputs string
        prompt = request.get("inputs", "")
        if isinstance(prompt, str) and prompt and not system_digest:
            system_digest = prompt[:500]

        # Resolve max token budget across all shape variants
        max_tokens: Optional[int] = (
            request.get("max_tokens")
            or request.get("max_new_tokens")
        )

        gov_input: dict[str, Any] = {
            "provider": _PROVIDER_ID,
            "model": request.get("model", "unknown"),
            "maxTokens": max_tokens,
            "systemPromptDigest": system_digest,
            "messageCount": len(messages),
        }
        return self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )

    def intercept_response(
        self,
        response: Any,
        audit_id: str,
    ) -> ClassifiedResponse:
        """Classify a HuggingFace inference response through the G-series guards.

        Normalises all HF response shapes to a plain dict before
        classification. Closes the audit chain via ``report_result``.

        Args:
            response: Raw HF response (str, list[dict], or dict).
            audit_id: The audit_id from the preceding ``intercept_request``
                decision.

        Returns:
            ClassifiedResponse indicating whether the response is safe.
        """
        start = time.monotonic()

        # Normalise HF response shapes to plain dict
        if isinstance(response, str):
            payload: dict[str, Any] = {"generated_text": response}
        elif isinstance(response, list) and response and isinstance(response[0], dict):
            payload = response[0]
        elif isinstance(response, dict):
            payload = response
        else:
            payload = {"raw": str(response)}

        classified = self.client.classify_output(
            audit_id=audit_id,
            output=payload,
            agent=self.agent,
        )

        elapsed_ms = int((time.monotonic() - start) * 1000)

        try:
            self.client.report_result(
                audit_id=audit_id,
                success=classified.allowed,
                summary=(
                    f"Response classified. Guards triggered: {classified.guards_triggered}"
                    if classified.guards_triggered
                    else "Response classified clean."
                ),
                duration_ms=elapsed_ms,
                error=(
                    f"Guards triggered: {classified.guards_triggered}"
                    if not classified.allowed
                    else None
                ),
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "Governance audit operation failed: %s", exc
            )

        return classified

    def wrap(self, hf_client: Any) -> "GovernedHuggingFaceProxy":
        """Return a proxy around an InferenceClient or Pipeline instance.

        The proxy intercepts ``text_generation()``, ``chat_completion()``,
        and ``__call__()`` (Pipeline) with governance checks.

        Args:
            hf_client: An ``InferenceClient`` instance or a
                ``transformers.Pipeline`` callable.

        Returns:
            GovernedHuggingFaceProxy wrapping the provided client.
        """
        return GovernedHuggingFaceProxy(raw_client=hf_client, governance=self)


class GovernedHuggingFaceProxy:
    """Thin proxy around an HF InferenceClient or Pipeline with governance.

    Intercepts ``text_generation()``, ``chat_completion()``, and
    ``__call__()`` (Pipeline). All other attributes pass through to the
    underlying client unchanged.
    """

    def __init__(self, raw_client: Any, governance: GovernedHuggingFace) -> None:
        self._raw = raw_client
        self._gov = governance

    # ------------------------------------------------------------------
    # InferenceClient surface — text_generation
    # ------------------------------------------------------------------

    def text_generation(self, prompt: str = "", **kwargs: Any) -> Any:
        """Intercept InferenceClient.text_generation() with governance."""
        model = kwargs.get("model") or getattr(self._raw, "model", "unknown")
        request: dict[str, Any] = {
            "model": model,
            "inputs": prompt,
            "max_new_tokens": kwargs.get("max_new_tokens") or kwargs.get("max_tokens"),
        }
        decision = self._gov.intercept_request(request)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {"generated_text": f"[GOVERNANCE DENIED] {decision.reason}"}

        if decision.requires_approval:
            return {
                "generated_text": (
                    f"[GOVERNANCE PENDING] Requires approval. "
                    f"Audit ID: {decision.audit_id}"
                )
            }

        result = self._raw.text_generation(prompt, **kwargs)

        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=result,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] HuggingFace response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return result

    # ------------------------------------------------------------------
    # InferenceClient surface — chat_completion
    # ------------------------------------------------------------------

    def chat_completion(
        self, messages: Any = None, **kwargs: Any
    ) -> Any:
        """Intercept InferenceClient.chat_completion() with governance."""
        model = kwargs.get("model") or getattr(self._raw, "model", "unknown")
        request: dict[str, Any] = {
            "model": model,
            "messages": messages or [],
            "max_tokens": kwargs.get("max_tokens"),
        }
        decision = self._gov.intercept_request(request)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": f"[GOVERNANCE DENIED] {decision.reason}",
                        },
                        "finish_reason": "GOVERNANCE_DENIED",
                    }
                ]
            }

        if decision.requires_approval:
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": (
                                f"[GOVERNANCE PENDING] Requires approval. "
                                f"Audit ID: {decision.audit_id}"
                            ),
                        },
                        "finish_reason": "GOVERNANCE_PENDING",
                    }
                ]
            }

        result = self._raw.chat_completion(messages, **kwargs)

        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=result if isinstance(result, (dict, list, str)) else {"raw": str(result)},
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] HuggingFace response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return result

    # ------------------------------------------------------------------
    # transformers.Pipeline surface — __call__
    # ------------------------------------------------------------------

    def __call__(self, inputs: Any = "", **kwargs: Any) -> Any:
        """Intercept Pipeline.__call__() with governance."""
        model = getattr(self._raw, "model", None) or kwargs.get("model", "unknown")
        if callable(model):
            model = "unknown"
        request: dict[str, Any] = {
            "model": str(model),
            "inputs": inputs if isinstance(inputs, str) else str(inputs),
            "max_new_tokens": kwargs.get("max_new_tokens"),
        }
        decision = self._gov.intercept_request(request)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return [{"generated_text": f"[GOVERNANCE DENIED] {decision.reason}"}]

        if decision.requires_approval:
            return [
                {
                    "generated_text": (
                        f"[GOVERNANCE PENDING] Requires approval. "
                        f"Audit ID: {decision.audit_id}"
                    )
                }
            ]

        result = self._raw(inputs, **kwargs)

        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=result,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] HuggingFace pipeline response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return result

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


# ---------------------------------------------------------------------------
# Backward-compatible alias — existing code using HuggingFaceGovernance
# continues to work unchanged. The alias points to the full GovernedHuggingFace
# class, so all new methods (wrap, report_result, etc.) are available via
# either name.
# ---------------------------------------------------------------------------
HuggingFaceGovernance = GovernedHuggingFace
