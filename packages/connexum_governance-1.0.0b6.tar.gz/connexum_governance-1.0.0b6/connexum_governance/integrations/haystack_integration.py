"""
GovernedHaystack -- governance enforcement for Haystack v2 (Python).

This is a FRAMEWORK ADAPTER for Haystack v2 (haystack-ai package).
It targets the REWRITTEN Haystack v2 API only. The deprecated Farm-Haystack
v1.x API (deepset-haystack / farm-haystack packages) is NOT supported.

IMPORTANT: Haystack v2 is a ground-up rewrite of the Haystack framework.
If you are importing from farm_haystack, migrate to haystack-ai >= 2.0.0
before using this adapter.

=== ARCHITECTURAL CONTRAST: Haystack v2 vs Prior Adapters ===

LangChain's callback system is OBSERVABILITY-first. GovernedTool._run() is the
only guaranteed blocking path (see langchain_integration.py).

OpenAI Agents SDK provides FIRST-CLASS blocking via input/output guardrails.

Pydantic AI requires function-level decorator interception (no hook system).

Haystack v2 is PIPELINE-first. Its primary abstraction is a DAG of components,
each of which has a run() method. Governance enforcement works at two levels:

  Pipeline.run(data):
    The single entry point for executing a Haystack pipeline. Wrapping Pipeline.run()
    fires a governance check on the full input dict BEFORE any component runs.
    This is the PIPELINE-LEVEL blocking gate.

  Component run() method:
    Each Haystack component (marked with @component decorator) exposes a run()
    method. GovernedComponent wraps any component instance and intercepts run()
    to fire a governance check on component inputs before delegating.
    This is the COMPONENT-LEVEL blocking gate.

  ToolInvoker (special case):
    Haystack v2's ToolInvoker component dispatches LLM tool calls. Wrapping it
    specifically (wrap_tool_invoker) provides per-tool-call governance for agentic
    pipelines that use LLM tool calling.

  Generator (OpenAIGenerator / AnthropicGenerator / etc.):
    Generator components issue LLM calls. wrap_generator() wraps any generator
    component to run a prompt injection scan and governance check before the LLM
    call. This is a DEFENSE-IN-DEPTH layer alongside the pipeline-level check.

BLOCKING STORY (ranked best to worst):
  1. wrap_pipeline()                    -- GUARANTEED (single entry point for DAG)
        Fires before ANY component runs. One check per pipeline execution.
  2. GovernedComponent (component wrap) -- GUARANTEED per-component
        Fires before each component's run(). More granular than pipeline-level.
  3. wrap_tool_invoker()                -- GUARANTEED for tool calls
        Specifically wraps Haystack ToolInvoker for per-tool-call governance.
  4. wrap_generator()                   -- DEFENSE-IN-DEPTH
        Pre-LLM-call injection scan + governance check on generator inputs.

IMPORTANT NOTE on Haystack v2 RAG use in healthcare:
  Haystack v2 is heavily used in clinical document Q&A pipelines. The HIPAA
  compliance pack's 'framework.haystack.pipeline_run' action namespace enables
  customers to gate all clinical RAG pipeline executions through HIPAA-grade
  governance checks with a single wrap_pipeline() call.

Action name namespace (for pack rule targeting):
  framework.haystack.pipeline_run   -- Pipeline.run() gate (GUARANTEED)
  framework.haystack.component_run  -- GovernedComponent.run() (GUARANTEED)
  framework.haystack.tool_invoke    -- wrap_tool_invoker (GUARANTEED)
  framework.haystack.generator_call -- wrap_generator (DEFENSE-IN-DEPTH)

Supported haystack-ai version range (tested against mock primitives):
  haystack-ai >= 2.0.0

Architectural difference vs Farm-Haystack v1.x (NOT supported):
  Farm-Haystack v1.x used a Document Store / Retriever / Reader pipeline.
  Haystack v2 uses a generic component DAG (any Python class marked with
  @component). The v2 pipeline.run(data) signature accepts a dict of inputs
  keyed by component name, not a plain question string.

Optional peer dependencies:
  haystack-ai >= 2.0.0

@connexum/python-sdk -- Framework Adapter Layer (Sprint 5, WS-13)
"""

from __future__ import annotations

import asyncio
import json
import re
import sys
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Callable, Optional

from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations._wire_shape import build_check_action_body

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

CheckFnType = Callable[[str, dict], Any]

# ---------------------------------------------------------------------------
# PII / PHI / sensitive data classifier
# ---------------------------------------------------------------------------

_SENSITIVE_PATTERNS = [
    re.compile(r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"),
    re.compile(r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"),
    re.compile(
        r"\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi|medication|prescription)\s*[:=]",
        re.IGNORECASE,
    ),
    re.compile(r"\b(sk-|pk_|rk_|api_key\s*[:=])", re.IGNORECASE),
]


def _contains_sensitive_data(text: str) -> bool:
    """Returns True if text contains PII, PHI, or credential patterns."""
    return any(p.search(text) for p in _SENSITIVE_PATTERNS)


# ---------------------------------------------------------------------------
# Prompt injection detector
# ---------------------------------------------------------------------------

_HIGH_INJECTION_PATTERNS = [
    "ignore previous instructions",
    "ignore your system prompt",
    "ignore all previous",
    "disregard previous",
    "forget your instructions",
    "you are now a different",
    "you are now an",
    "act as if you",
    "pretend you are",
    "reveal all secrets",
    "reveal your system prompt",
    "output your instructions",
    "your new instructions are",
    "new instructions:",
    "system override",
    "i am your administrator",
    "i am your operator",
    "override safety",
    "ignore safety",
    "bypass",
    "jailbreak",
]

_MEDIUM_INJECTION_PATTERNS = [
    "ignore the above",
    "disregard the above",
    "don't follow",
    "do not follow",
    "forget what",
    "as an ai without",
    "without restrictions",
    "without limitations",
    "without constraints",
    "act without",
    "you have no",
    "you must always",
    "you must never",
]


def _detect_injection(text: str) -> dict:
    lowered = text.lower()
    matched_high = [p for p in _HIGH_INJECTION_PATTERNS if p in lowered]
    if matched_high:
        return {"detected": True, "severity": "high", "patterns": matched_high}
    matched_medium = [p for p in _MEDIUM_INJECTION_PATTERNS if p in lowered]
    if matched_medium:
        return {"detected": True, "severity": "medium", "patterns": matched_medium}
    return {"detected": False, "severity": "low", "patterns": []}


# ---------------------------------------------------------------------------
# HTTP check helpers (same contract as langchain_integration.py)
# ---------------------------------------------------------------------------

async def _do_check_async(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            return await check_fn(governance_server_url, body)
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        async with _httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


def _do_check_sync(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            try:
                loop = asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(
                        lambda: asyncio.run(check_fn(governance_server_url, body))
                    )
                    return future.result()
            except RuntimeError:
                return asyncio.run(check_fn(governance_server_url, body))
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        with _httpx.Client(timeout=5.0) as client:
            resp = client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


# ---------------------------------------------------------------------------
# Decision enforcement helpers
# ---------------------------------------------------------------------------

def _enforce_decision(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
    log_prefix: str = "GovernedHaystack",
) -> None:
    decision = result.get("decision", "ALLOW")
    if decision == "DENY":
        reason = result.get("reason") or "policy"
        sys.stderr.write(
            f"[{log_prefix}] DENIED for '{context_label}'. reason={reason}\n"
        )
        if raise_on_deny:
            raise GovernanceViolation(
                decision="DENY",
                reason=reason,
                audit_id=result.get("auditId"),
            )
        return
    if decision == "REQUIRE_APPROVAL":
        approval_id = result.get("approvalId")
        audit_id = result.get("auditId")
        if not approval_id:
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                    audit_id=audit_id,
                )
            return
        sys.stderr.write(
            f"[{log_prefix}] PENDING for '{context_label}'. approvalId={approval_id}\n"
        )
        if raise_on_deny:
            raise GovernancePendingApproval(
                approval_id=approval_id,
                audit_id=audit_id,
            )


def _input_dict_preview(data: Any) -> str:
    """Serialize an input dict to a truncated string for governance preview."""
    if data is None:
        return ""
    if isinstance(data, str):
        return data[:200]
    try:
        return json.dumps(data)[:200]
    except Exception:
        return str(data)[:200]


# ---------------------------------------------------------------------------
# GovernedComponent
#
# PRIMARY BLOCKING PRIMITIVE (component-level).
#
# Wraps any Haystack v2 component's run() method with a governance pre-check.
# The component duck-type in Haystack v2: any class with a run(**kwargs) method.
# ---------------------------------------------------------------------------


class GovernedComponent:
    """
    Wrapper for any Haystack v2 component that intercepts run() with governance.

    Haystack v2 components are Python classes decorated with @component. They
    expose a run(**kwargs) method that receives typed inputs and returns a dict
    of typed outputs. GovernedComponent wraps any such component and intercepts
    run() to fire a governance check before delegating.

    GUARANTEED BLOCKING: governance runs inside run() before any component
    computation. This fires regardless of how the component is used -- whether
    via pipeline.run() or called directly.

    Usage:
        from connexum_governance.integrations.haystack_integration import (
            GovernedComponent,
        )

        raw_component = MyHaystackComponent()
        safe_component = GovernedComponent(
            component=raw_component,
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        # Drop safe_component into a Haystack pipeline:
        pipeline.add_component("my_component", safe_component)
    """

    def __init__(
        self,
        component: Any,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        """
        Args:
            component: Any Haystack v2 component with a run() method.
            governance_server_url: URL of the governance server.
            license_key: License / JWT key for the governance server.
            pack_ids: Compliance pack IDs to evaluate against.
            raise_on_deny: When True (default), DENY raises GovernanceViolation.
            _check_fn: Test injection hook. Not part of the public API.
        """
        if component is None:
            raise ValueError("[GovernedComponent] component is required")
        if not governance_server_url:
            raise ValueError("[GovernedComponent] governance_server_url is required")
        if not license_key:
            raise ValueError("[GovernedComponent] license_key is required")

        self._underlying = component
        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._check_fn = _check_fn

        # Expose component name for Haystack pipeline compatibility
        self.name = getattr(component, "name", None) or getattr(
            component, "__class__", type(component)
        ).__name__

    def run(self, **kwargs: Any) -> Any:
        """
        Governed run(). Fires governance check before delegating to underlying component.

        DENY -> raises GovernanceViolation (guaranteed blocking).
        PENDING -> raises GovernancePendingApproval.
        ALLOW -> delegates to underlying component.run(**kwargs).

        This is the GUARANTEED BLOCKING PRIMITIVE for component-level enforcement.
        """
        input_preview = _input_dict_preview(kwargs)

        result = _do_check_sync(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name=self.name,
                agent_name=f"haystack-component:{self.name}",
                framework_action="framework.haystack.component_run",
                input_dict=kwargs if isinstance(kwargs, dict) else None,
                message_preview=input_preview,
                pack_ids=self._pack_ids,
                extra_metadata={"componentName": self.name, "inputPreview": input_preview},
                source="GovernedComponent.run",
            ),
            check_fn=self._check_fn,
        )
        _enforce_decision(result, self.name, self._raise_on_deny, "GovernedComponent")
        return self._underlying.run(**kwargs)

    async def run_async(self, **kwargs: Any) -> Any:
        """
        Async governed run(). For async-capable Haystack components.

        Fires governance check before delegating. If the underlying component
        has a run_async() method, delegates to it; otherwise falls back to run().
        """
        input_preview = _input_dict_preview(kwargs)

        result = await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=build_check_action_body(
                tool_name=self.name,
                agent_name=f"haystack-component:{self.name}",
                framework_action="framework.haystack.component_run",
                input_dict=kwargs if isinstance(kwargs, dict) else None,
                message_preview=input_preview,
                pack_ids=self._pack_ids,
                extra_metadata={"componentName": self.name, "inputPreview": input_preview},
                source="GovernedComponent.run_async",
            ),
            check_fn=self._check_fn,
        )
        _enforce_decision(result, self.name, self._raise_on_deny, "GovernedComponent")

        # Delegate to async run if available, else sync run
        underlying_run_async = getattr(self._underlying, "run_async", None)
        if underlying_run_async is not None:
            return await underlying_run_async(**kwargs)
        return self._underlying.run(**kwargs)

    def __getattr__(self, name: str) -> Any:
        """Proxy attribute access to the underlying component for Haystack compat."""
        return getattr(self._underlying, name)


def governed_component(
    component: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedComponent:
    """
    Factory function to create a GovernedComponent wrapping any Haystack component.

    Args:
        component: Any Haystack v2 component with a run() method.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Whether to raise on DENY / PENDING (default True).
        _check_fn: Test injection hook (not public API).

    Returns:
        GovernedComponent instance wrapping the provided component.
    """
    return GovernedComponent(
        component=component,
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )


# ---------------------------------------------------------------------------
# wrap_pipeline
#
# PIPELINE-LEVEL blocking gate. Monkeypatches Pipeline.run() to fire a
# governance check on the full input dict before any component runs.
# ---------------------------------------------------------------------------


def wrap_pipeline(
    pipeline: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Monkeypatches a Haystack v2 Pipeline's run() method to fire a governance
    check on the full input dict before any component executes.

    This is the PIPELINE-LEVEL BLOCKING GATE. A single governance check covers
    the entire pipeline execution. For per-component governance, use
    GovernedComponent or governed_component() for individual components.

    Idempotent: calling wrap_pipeline twice will not double-wrap (checked via
    _connexum_governed marker on the run method).

    IMPORTANT: Haystack v2's Pipeline.run(data) accepts a dict of inputs keyed
    by component name (e.g., {'embedder': {'text': 'query'}}). The full input
    dict is serialized for the governance preview.

    Args:
        pipeline: A Haystack v2 Pipeline instance with a run() method.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        The same pipeline instance with run() wrapped.
    """
    if pipeline is None:
        raise ValueError("[wrap_pipeline] pipeline is required")

    original_run = getattr(pipeline, "run", None)
    if original_run is None:
        raise ValueError("[wrap_pipeline] pipeline.run() is required")

    # Idempotency check
    if getattr(original_run, "_connexum_governed", False):
        return pipeline

    @wraps(original_run)
    def governed_run(data: Any = None, **kwargs: Any) -> Any:
        input_preview = _input_dict_preview(data)

        result = _do_check_sync(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name="pipeline.run",
                agent_name="haystack-pipeline",
                framework_action="framework.haystack.pipeline_run",
                input_dict=data if isinstance(data, dict) else {"data": input_preview},
                message_preview=input_preview,
                pack_ids=pack_ids,
                extra_metadata={"inputPreview": input_preview},
                source="wrap_pipeline.run",
            ),
            check_fn=_check_fn,
        )
        _enforce_decision(result, "pipeline.run", raise_on_deny, "wrap_pipeline")

        if data is not None:
            return original_run(data, **kwargs)
        return original_run(**kwargs)

    governed_run._connexum_governed = True
    pipeline.run = governed_run
    pipeline._connexum_governed = True
    return pipeline


# ---------------------------------------------------------------------------
# wrap_tool_invoker
#
# TOOL-INVOKE blocking gate for Haystack v2 ToolInvoker component.
#
# ToolInvoker is the Haystack v2 component that dispatches LLM tool calls.
# It receives a list of ChatMessage objects with tool call information and
# invokes the appropriate tool functions. Wrapping its run() method with
# GovernedComponent behavior provides per-tool-call governance.
# ---------------------------------------------------------------------------


def wrap_tool_invoker(
    invoker: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wraps a Haystack v2 ToolInvoker component's run() method with governance.

    ToolInvoker dispatches tool calls made by LLMs in agentic Haystack pipelines.
    Wrapping it provides per-tool-call governance on top of the pipeline-level gate.

    This is the GUARANTEED BLOCKING PRIMITIVE for per-tool-call governance in
    Haystack v2 agentic pipelines.

    Idempotent: checking via _connexum_governed marker on the run method.

    Args:
        invoker: A Haystack v2 ToolInvoker component instance (or duck-type).
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        The same invoker with run() wrapped for governance.
    """
    if invoker is None:
        raise ValueError("[wrap_tool_invoker] invoker is required")

    original_run = getattr(invoker, "run", None)
    if original_run is None:
        raise ValueError("[wrap_tool_invoker] invoker.run() is required")

    if getattr(original_run, "_connexum_governed", False):
        return invoker

    invoker_name = getattr(invoker, "name", None) or type(invoker).__name__

    @wraps(original_run)
    def governed_run(**kwargs: Any) -> Any:
        # Extract tool name from kwargs for better logging.
        # ToolInvoker typically receives 'messages' kwarg with tool call info.
        messages = kwargs.get("messages", [])
        tool_names = []
        if isinstance(messages, list):
            for msg in messages:
                # Attempt to extract tool call names from the message
                tool_calls = getattr(msg, "tool_calls", None) or (
                    msg.get("tool_calls", []) if isinstance(msg, dict) else []
                )
                for tc in tool_calls:
                    name = (
                        getattr(tc, "tool_name", None)
                        or (tc.get("function", {}).get("name") if isinstance(tc, dict) else None)
                        or "unknown_tool"
                    )
                    tool_names.append(name)

        input_preview = _input_dict_preview(kwargs)

        # Use first detected tool name as the canonical toolName for the server,
        # full list goes in tools[] (legacy passthrough) and metadata for
        # audit/policy granularity.
        primary_tool = tool_names[0] if tool_names else "unknown_tool"
        result = _do_check_sync(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name=primary_tool,
                agent_name=f"haystack-tool-invoker:{invoker_name}",
                framework_action="framework.haystack.tool_invoke",
                input_dict=kwargs if isinstance(kwargs, dict) else None,
                message_preview=input_preview,
                pack_ids=pack_ids,
                extra_metadata={
                    "componentName": invoker_name,
                    "toolNames": tool_names,
                    "inputPreview": input_preview,
                },
                source="wrap_tool_invoker.run",
                tools=tool_names or [primary_tool],
            ),
            check_fn=_check_fn,
        )
        _enforce_decision(
            result,
            f"ToolInvoker:{','.join(tool_names) or 'unknown'}",
            raise_on_deny,
            "wrap_tool_invoker",
        )
        return original_run(**kwargs)

    governed_run._connexum_governed = True
    invoker.run = governed_run
    invoker._connexum_governed = True
    return invoker


# ---------------------------------------------------------------------------
# wrap_generator
#
# DEFENSE-IN-DEPTH: wraps any Haystack v2 Generator component (OpenAIGenerator,
# AnthropicGenerator, etc.) to run a prompt injection scan + governance check
# before the LLM call.
# ---------------------------------------------------------------------------


def wrap_generator(
    generator: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    injection_deny_threshold: str = "high",
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Wraps a Haystack v2 Generator component's run() method with governance.

    Generator components (OpenAIGenerator, AnthropicGenerator, etc.) issue
    LLM calls. Wrapping run() provides prompt injection scanning and a
    governance check before any LLM call is made.

    This is a DEFENSE-IN-DEPTH layer alongside the pipeline-level gate.
    Use wrap_pipeline() as the primary gate; use wrap_generator() for
    defense-in-depth at the LLM boundary (especially for prompt injection).

    Haystack v2 generators typically receive 'prompt' (str) or 'messages'
    (list) as the primary input kwarg.

    Args:
        generator: A Haystack v2 Generator component with a run() method.
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        injection_deny_threshold: 'high' or 'medium' injection scan threshold.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        The same generator with run() wrapped for governance.
    """
    if generator is None:
        raise ValueError("[wrap_generator] generator is required")

    original_run = getattr(generator, "run", None)
    if original_run is None:
        raise ValueError("[wrap_generator] generator.run() is required")

    if getattr(original_run, "_connexum_governed", False):
        return generator

    generator_name = getattr(generator, "name", None) or type(generator).__name__

    @wraps(original_run)
    def governed_run(**kwargs: Any) -> Any:
        # Extract prompt from kwargs -- generators use 'prompt' or 'messages'
        prompt = kwargs.get("prompt", "")
        messages = kwargs.get("messages", [])
        if not prompt and messages:
            if isinstance(messages, list):
                prompt = " ".join(
                    m.get("content", "") if isinstance(m, dict) else str(m)
                    for m in messages
                )
        prompt_text = str(prompt) if prompt else _input_dict_preview(kwargs)

        # Prompt injection scan
        detection = _detect_injection(prompt_text)
        if detection["detected"]:
            severity = detection["severity"]
            should_block = severity == "high" or (
                injection_deny_threshold == "medium" and severity == "medium"
            )
            sys.stderr.write(
                f"[wrap_generator] prompt-injection:{severity} detected for "
                f"'{generator_name}'. patterns={detection['patterns']}\n"
            )
            if should_block and raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason=(
                        f"Prompt injection detected in generator input "
                        f"(severity={severity}, patterns={detection['patterns']}). "
                        "Blocked by connexum-governance (Onyx #5 / OWASP LLM01)."
                    ),
                )

        # Governance server check
        result = _do_check_sync(
            governance_server_url=governance_server_url,
            license_key=license_key,
            body=build_check_action_body(
                tool_name=f"generator:{generator_name}",
                agent_name=f"haystack-generator:{generator_name}",
                framework_action="framework.haystack.generator_call",
                input_dict={"prompt": prompt_text[:2000]},
                message_preview=prompt_text[:200],
                pack_ids=pack_ids,
                extra_metadata={
                    "generatorName": generator_name,
                    "promptPreview": prompt_text[:200],
                    "injectionDetected": detection["detected"],
                    "injectionSeverity": detection["severity"],
                },
                source="wrap_generator.run",
            ),
            check_fn=_check_fn,
        )
        _enforce_decision(result, generator_name, raise_on_deny, "wrap_generator")
        return original_run(**kwargs)

    governed_run._connexum_governed = True
    generator.run = governed_run
    generator._connexum_governed = True
    return generator


# ---------------------------------------------------------------------------
# GovernedHaystackInstance -- namespace returned by factory
# ---------------------------------------------------------------------------


@dataclass
class GovernedHaystackInstance:
    """
    Governed Haystack object returned by create_governed_haystack().

    Exposes all integration helpers for the Haystack v2 framework adapter.
    """

    _governance_server_url: str = field(repr=False)
    _license_key: str = field(repr=False)
    _pack_ids: list = field(default_factory=list, repr=False)
    _raise_on_deny: bool = field(default=True, repr=False)
    _injection_deny_threshold: str = field(default="high", repr=False)
    _check_fn: Optional[CheckFnType] = field(default=None, repr=False)

    def governed_component(self, component: Any) -> GovernedComponent:
        """
        Wrap a Haystack v2 component with per-run() governance.

        GUARANTEED BLOCKING: fires before every component.run() call.

        Args:
            component: Any Haystack v2 component with a run() method.

        Returns:
            GovernedComponent wrapping the provided component.
        """
        return GovernedComponent(
            component=component,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_pipeline(self, pipeline: Any) -> Any:
        """
        Wrap a Haystack v2 Pipeline's run() with pipeline-level governance.

        GUARANTEED BLOCKING: one check fires before any component runs.
        Returns the same pipeline instance with run() wrapped.
        """
        return wrap_pipeline(
            pipeline=pipeline,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_tool_invoker(self, invoker: Any) -> Any:
        """
        Wrap a Haystack v2 ToolInvoker component for per-tool-call governance.

        GUARANTEED BLOCKING: fires before each tool dispatch.
        Returns the same invoker with run() wrapped.
        """
        return wrap_tool_invoker(
            invoker=invoker,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_generator(self, generator: Any) -> Any:
        """
        Wrap a Haystack v2 Generator component for pre-LLM-call governance.

        DEFENSE-IN-DEPTH: runs injection scan + governance check before LLM call.
        Returns the same generator with run() wrapped.
        """
        return wrap_generator(
            generator=generator,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            injection_deny_threshold=self._injection_deny_threshold,
            _check_fn=self._check_fn,
        )


# ---------------------------------------------------------------------------
# create_governed_haystack -- primary public factory
# ---------------------------------------------------------------------------


def create_governed_haystack(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    injection_deny_threshold: str = "high",
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedHaystackInstance:
    """
    Primary factory for the Haystack v2 governance adapter.

    Returns a GovernedHaystackInstance exposing all integration helpers.

    IMPORTANT: This adapter targets Haystack v2 (haystack-ai >= 2.0.0) ONLY.
    Farm-Haystack v1.x is not supported.

    Haystack v2 is pipeline-first. The recommended approach for maximum coverage:

        gov = create_governed_haystack(...)

        # Option 1 (RECOMMENDED for full coverage):
        # Wrap the pipeline for a pipeline-level gate + wrap individual components
        # that handle sensitive data for defense-in-depth.
        pipeline = Pipeline()
        gov.wrap_pipeline(pipeline)               # pipeline-level gate
        pipeline.add_component("embedder",
            gov.governed_component(embedder))     # component-level gate
        pipeline.add_component("llm",
            gov.governed_component(generator))    # component-level gate
        pipeline.add_component("tools",
            gov.wrap_tool_invoker(tool_invoker))  # per-tool gate for agentic

        # Option 2 (LLM boundary defense-in-depth):
        gov.wrap_generator(openai_generator)  # injection scan + check before LLM

        # Option 3 (component-only, no pipeline):
        safe_retriever = gov.governed_component(retriever)
        safe_retriever.run(query="patient records for MRN 12345")
        # GovernanceViolation raised on DENY before retriever runs

    HEALTHCARE NOTE: For HIPAA-compliant clinical document Q&A pipelines,
    the 'framework.haystack.pipeline_run' action namespace enables HIPAA pack
    enforcement at the pipeline boundary. One call to gov.wrap_pipeline() covers
    all clinical RAG query traffic through that pipeline.

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation.
        injection_deny_threshold: 'high' (default) or 'medium' injection threshold.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        GovernedHaystackInstance with all integration helpers.
    """
    if not governance_server_url:
        raise ValueError(
            "[create_governed_haystack] governance_server_url is required"
        )
    if not license_key:
        raise ValueError(
            "[create_governed_haystack] license_key is required"
        )

    return GovernedHaystackInstance(
        _governance_server_url=governance_server_url,
        _license_key=license_key,
        _pack_ids=pack_ids or [],
        _raise_on_deny=raise_on_deny,
        _injection_deny_threshold=injection_deny_threshold,
        _check_fn=_check_fn,
    )
