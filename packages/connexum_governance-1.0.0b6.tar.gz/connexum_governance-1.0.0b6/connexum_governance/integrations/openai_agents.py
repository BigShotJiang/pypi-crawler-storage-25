"""OpenAI Agents SDK integration for Connexum governance.

Hooks into the OpenAI Agents SDK runner lifecycle with six canonical
governance hook surfaces. Python-native: integrates with the
openai-agents package when installed.

Hook surfaces (parity with src/orchestrator-adapters/openai-agents.ts):
  agentStart   -> gate at runner.run entry (allowed-agents list + pack-binding)
  toolCall     -> pre-tool gate at the Agents SDK layer
  toolResult   -> post-tool G-series output classification
  llmCall      -> pre-LLM gate (approved model list)
  llmResult    -> post-LLM output exfiltration scan
  agentEnd     -> terminal audit event sealing

OpenAI Agents SDK-specific considerations:
  - Handoffs (agent-to-agent control transfer) are first-class primitives.
    They map onto the delegation surface. check_handoff() fires at every
    handoff boundary before the SDK routes control.
  - Session state transitions emit canonical plan-step events.
  - The Agents SDK is at v1.x. The runner lifecycle hooks (on_run_start,
    on_run_end, on_tool_call, on_handoff) are confirmed in the Python SDK.
    Use Runner.run_streamed() events where available.
  - This adapter intercepts both the standard Runner.run path and the
    streamed path via the same hook surfaces.

Lazy import: openai-agents is NOT hard-required. This module is always
importable. Hook methods work without the SDK installed.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.openai_agents import OpenAIAgentsGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = OpenAIAgentsGovernance(
        client=gov,
        allowed_agents=["research-agent", "writer-agent"],
        approved_models=["gpt-4o", "gpt-4o-mini"],
        sensitive_tools=["write_file", "exec_code"],
        sensitive_handoff_targets=["admin-agent"],
    )

    # At run start:
    adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")

    # Before a tool call at the SDK layer:
    adapter.tool_call("research-agent", "web_search", {"query": "governance"})

    # After tool result:
    adapter.tool_result("research-agent", "web_search", "results...", success=True)

    # Before each LLM call:
    adapter.llm_call("research-agent", "gpt-4o", messages=[...])

    # After LLM response:
    adapter.llm_result("research-agent", "gpt-4o", response_text="...")

    # At run end:
    adapter.agent_end("research-agent", success=True, summary="Task complete")

    # For handoff governance:
    adapter.check_handoff(from_agent="research-agent", to_agent="writer-agent",
                          handoff_input="Draft the report")
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation


# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------

class OpenAIAgentsHandoffDeniedError(RuntimeError):
    """Raised when a handoff to a sensitive agent is denied."""

    def __init__(self, from_agent: str, to_agent: str, reason: str):
        super().__init__(
            f'Handoff from "{from_agent}" to "{to_agent}" denied: {reason}'
        )
        self.from_agent = from_agent
        self.to_agent = to_agent
        self.reason = reason


class OpenAIAgentsMaxTurnsError(RuntimeError):
    """Raised when an agent exceeds the maximum number of turns."""

    def __init__(self, agent_id: str, max_turns: int):
        super().__init__(
            f'Agent "{agent_id}" exceeded max_turns_per_run ({max_turns}). '
            "Run suppressed to prevent runaway execution."
        )
        self.agent_id = agent_id
        self.max_turns = max_turns


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


# ---------------------------------------------------------------------------
# OpenAIAgentsGovernance
# ---------------------------------------------------------------------------

class OpenAIAgentsGovernance:
    """Governance adapter for the OpenAI Agents SDK.

    Exposes six lifecycle hooks that map to the canonical governance event
    surfaces. Adds check_handoff() as a first-class handoff-governance surface
    (OpenAI Agents SDK-specific: agent-to-agent handoffs are a core primitive).

    Does NOT hard-depend on the openai-agents package. All hook methods accept
    plain Python dicts / strings so they can be called from any SDK version or
    from tests without the SDK installed.
    """

    def __init__(
        self,
        client: GovernanceClient,
        allowed_agents: list[str],
        approved_models: list[str],
        sensitive_tools: Optional[list[str]] = None,
        sensitive_handoff_targets: Optional[list[str]] = None,
        sensitive_arg_keys: Optional[list[str]] = None,
        max_turns_per_run: Optional[int] = None,
        max_plan_steps: Optional[int] = None,
        enforce_pack_binding: bool = True,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            allowed_agents: Agent names permitted to run under governance.
                            Empty list causes all run starts to be denied (fail closed).
            approved_models: LLM model IDs approved for use.
            sensitive_tools: Tool names that require reviewer approval at the SDK layer.
            sensitive_handoff_targets: Agent names that require approval before receiving
                                       a handoff (maps to DelegationDecision contract).
            sensitive_arg_keys: Argument keys to scan for PHI / exfiltration patterns.
            max_turns_per_run: Cap on LLM turns per run. Enforces against runaway loops.
            max_plan_steps: Maximum plan steps. Mirrors TS adapter prePlan check.
            enforce_pack_binding: If True (default), agents must carry non-empty
                                  packBinding at spawn.
        """
        self.client = client
        self.allowed_agents = allowed_agents
        self.approved_models = approved_models
        self.sensitive_tools = sensitive_tools or []
        self.sensitive_handoff_targets = sensitive_handoff_targets or []
        self.sensitive_arg_keys = sensitive_arg_keys or ["query", "body", "content", "message"]
        self.max_turns_per_run = max_turns_per_run
        self.max_plan_steps = max_plan_steps
        self.enforce_pack_binding = enforce_pack_binding

        # Per-agent state
        self._active_runs: dict[str, dict[str, Any]] = {}
        self._turn_counters: dict[str, int] = {}
        self._tool_call_counters: dict[str, int] = {}
        self._pending_audits: dict[str, str] = {}

    # ------------------------------------------------------------------
    # agentStart -- gate at runner.run entry
    # ------------------------------------------------------------------

    def agent_start(
        self,
        agent_id: str,
        pack_binding: list[str],
        model: str,
        run_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        session_state: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Gate at OpenAI Agents SDK run start.

        Checks:
          1. Allowed-agents list (fail closed on empty list)
          2. Pack-binding primacy
          3. Provider compliance (approved_models list)
          4. Governance check_action

        Raises:
            GovernanceViolation: governance server denies.
        """
        # Allowed-agents check (mirrors TS handleRunStart)
        if agent_id not in self.allowed_agents:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = f'Agent "{agent_id}" is not in the allowed agents list'
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        # Pack-binding primacy
        if self.enforce_pack_binding and not pack_binding:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Agent "{agent_id}" attempted agent_start without a pack binding. '
                "Every agent MUST carry packBinding before any action fires."
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        # Provider compliance
        if model not in self.approved_models:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'LLM model "{model}" is not on the approved provider list. '
                f"Approved: {', '.join(self.approved_models)}"
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        effective_run_id = run_id or str(uuid.uuid4())
        agent = AgentIdentity(name=agent_id, session_id=effective_run_id)
        decision = self.client.check_action(
            tool="agent.start",
            input={
                "agentId": agent_id,
                "runId": effective_run_id,
                "packBinding": pack_binding,
                "model": model,
                "sessionState": session_state or {},
                "metadata": metadata or {},
                "framework": "openai-agents",
            },
            agent=agent,
        )

        if decision.denied and self.client.enforce:
            raise GovernanceViolation(decision)

        self._active_runs[agent_id] = {
            "pack_binding": pack_binding,
            "model": model,
            "run_id": effective_run_id,
        }
        self._turn_counters[agent_id] = 0
        self._tool_call_counters[agent_id] = 0

        if decision.audit_id:
            self._pending_audits[f"start:{agent_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolCall -- pre-tool gate at the Agents SDK layer
    # ------------------------------------------------------------------

    def tool_call(
        self,
        agent_id: str,
        tool_name: str,
        args: dict[str, Any],
        tool_call_id: Optional[str] = None,
    ) -> GovernanceDecision:
        """Pre-tool governance check at the Agents SDK layer.

        Distinct from the LLM provider adapter: this fires at plan / handoff
        boundaries, not at the model call level. Both emit to the same audit
        chain with distinct event types (AC 15 parity).

        Checks:
          1. Active run check
          2. Pack-binding presence
          3. Exfiltration scan on sensitive arg keys
          4. Sensitive-tool routing (REQUIRE_APPROVAL)
        """
        snapshot = self._active_runs.get(agent_id)
        if snapshot is None:
            # Auto-initialize default agent state on first tool_call when agent_start()
            # was not called. This avoids the "DENY without explanation" UX problem
            # (DIVERGENCE-006 / WS-05 ITEM 6). Customers who need strict lifecycle
            # ordering should call agent_start() explicitly before the first tool_call();
            # this auto-init provides a safe default for the common case where ordering
            # is not enforced by the caller.
            import sys as _sys
            _sys.stderr.write(
                f"[OpenAIAgentsGovernance] agent_start() not called for '{agent_id}' "
                f"before tool_call(). Auto-initializing with default state. "
                "For strict lifecycle enforcement, call agent_start() explicitly "
                "before the first tool_call().\n"
            )
            self._active_runs[agent_id] = {
                "pack_binding": [],
                "model": "unknown",
                "run_id": str(uuid.uuid4()),
            }
            self._turn_counters[agent_id] = 0
            self._tool_call_counters[agent_id] = 0
            snapshot = self._active_runs[agent_id]

        if self.enforce_pack_binding and not snapshot.get("pack_binding"):
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Agent "{agent_id}" called tool_call({tool_name}) without a pack binding.'
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        # Exfiltration scan
        exfil_key = self._scan_args(args)
        if exfil_key:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Possible data exfiltration in args for tool "{tool_name}" '
                f'(key: "{exfil_key}"). Blocked at G5/G7 egress guard.'
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        count = self._tool_call_counters.get(agent_id, 0) + 1
        self._tool_call_counters[agent_id] = count

        agent = AgentIdentity(name=agent_id, session_id=snapshot.get("run_id"))
        decision = self.client.check_action(
            tool=f"tool.{tool_name}",
            input={
                "agentId": agent_id,
                "toolName": tool_name,
                "toolCallId": tool_call_id or str(uuid.uuid4()),
                "argsDigest": str(args)[:500],
                "callCount": count,
                "packBinding": snapshot.get("pack_binding", []),
                "sensitive": tool_name in self.sensitive_tools,
                "framework": "openai-agents",
                "layer": "agents-sdk",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"tool:{agent_id}:{tool_name}:{count}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolResult -- post-tool G-series classification
    # ------------------------------------------------------------------

    def tool_result(
        self,
        agent_id: str,
        tool_name: str,
        result: Any,
        success: bool = True,
        duration_ms: Optional[int] = None,
    ) -> None:
        """Post-tool G-series classification and audit chain close."""
        count = self._tool_call_counters.get(agent_id, 1)
        audit_key = f"tool:{agent_id}:{tool_name}:{count}"
        audit_id = self._pending_audits.pop(audit_key, None)

        result_text = str(result) if not isinstance(result, str) else result
        phi_found = _contains_phi(result_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output classifier: possible PHI in OpenAI Agents SDK "
                f'tool result "{tool_name}" (agent: {agent_id}). '
                f"Audit ID: {audit_id}",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success and not phi_found,
                    summary=result_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Output classifier: PHI in tool result",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # llmCall -- pre-LLM gate
    # ------------------------------------------------------------------

    def llm_call(
        self,
        agent_id: str,
        model: str,
        messages: list[dict[str, Any]],
        tools: Optional[list[dict[str, Any]]] = None,
    ) -> GovernanceDecision:
        """Pre-LLM governance check.

        Also tracks the turn counter to enforce max_turns_per_run.
        """
        snapshot = self._active_runs.get(agent_id)
        if snapshot is None:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = f'Agent "{agent_id}" called llm_call without prior agent_start'
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        # Turn counter (max_turns_per_run guard -- mirrors TS MaxTurnsExceeded)
        turns = self._turn_counters.get(agent_id, 0) + 1
        self._turn_counters[agent_id] = turns
        if self.max_turns_per_run is not None and turns > self.max_turns_per_run:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Agent "{agent_id}" exceeded max_turns_per_run ({self.max_turns_per_run}). '
                "Runaway agent suppressed."
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise OpenAIAgentsMaxTurnsError(agent_id, self.max_turns_per_run)
            return d

        # Provider compliance per-call
        if model not in self.approved_models:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'LLM model "{model}" is not on the approved provider list. '
                f"Approved: {', '.join(self.approved_models)}"
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        agent = AgentIdentity(name=agent_id, session_id=snapshot.get("run_id"))
        decision = self.client.check_action(
            tool="llm.call",
            input={
                "agentId": agent_id,
                "model": model,
                "messageCount": len(messages),
                "toolCount": len(tools or []),
                "turnCount": turns,
                "packBinding": snapshot.get("pack_binding", []),
                "framework": "openai-agents",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"llm:{agent_id}:{model}:{turns}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # llmResult -- post-LLM exfiltration scan
    # ------------------------------------------------------------------

    def llm_result(
        self,
        agent_id: str,
        model: str,
        response_text: str,
        usage: Optional[dict[str, int]] = None,
    ) -> None:
        """Post-LLM output exfiltration scan and audit chain close."""
        turns = self._turn_counters.get(agent_id, 1)
        audit_id = self._pending_audits.pop(f"llm:{agent_id}:{model}:{turns}", None)

        phi_found = _contains_phi(response_text)
        if phi_found:
            print(
                f"[GOVERNANCE] Output exfiltration scanner: possible PHI in "
                f'OpenAI Agents LLM response (model: {model}, agent: {agent_id}). '
                "Flagged for compliance review.",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=not phi_found,
                    summary=response_text[:200],
                    error=None if not phi_found else "Output exfiltration scanner: PHI in LLM response",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # agentEnd -- terminal audit event sealing
    # ------------------------------------------------------------------

    def agent_end(
        self,
        agent_id: str,
        success: bool,
        summary: Optional[str] = None,
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
        final_state: Optional[dict[str, Any]] = None,
    ) -> None:
        """Terminal audit event sealing and active-run cleanup."""
        snapshot = self._active_runs.pop(agent_id, {})
        turn_count = self._turn_counters.pop(agent_id, 0)
        tool_count = self._tool_call_counters.pop(agent_id, 0)
        start_audit_id = self._pending_audits.pop(f"start:{agent_id}", None)

        agent = AgentIdentity(name=agent_id, session_id=snapshot.get("run_id"))
        try:
            self.client.check_action(
                tool="agent.end",
                input={
                    "agentId": agent_id,
                    "runId": snapshot.get("run_id"),
                    "success": success,
                    "summary": summary or ("Run complete" if success else "Run failed"),
                    "durationMs": duration_ms,
                    "error": error,
                    "turnCount": turn_count,
                    "toolCallCount": tool_count,
                    "packBinding": snapshot.get("pack_binding", []),
                    "model": snapshot.get("model"),
                    "finalStateKeys": list(final_state.keys()) if final_state else [],
                    "framework": "openai-agents",
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        if start_audit_id:
            try:
                self.client.report_result(
                    audit_id=start_audit_id,
                    success=success,
                    summary=summary or "",
                    duration_ms=duration_ms,
                    error=error,
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # check_handoff -- OpenAI Agents SDK-specific handoff governance
    # ------------------------------------------------------------------

    def check_handoff(
        self,
        from_agent: str,
        to_agent: str,
        handoff_input: Any = None,
        handoff_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Gate at agent-to-agent handoff boundary.

        Handoffs in the OpenAI Agents SDK are first-class primitives that
        transfer control between agents. They map onto the DelegationDecision
        contract in the TS adapter.

        Sensitive handoff targets (in sensitive_handoff_targets list) require
        reviewer approval before the SDK routes control.

        Raises:
            OpenAIAgentsHandoffDeniedError: sensitive target with no reviewer queue,
                                           or governance server denies.
        """
        snapshot = self._active_runs.get(from_agent, {})
        effective_handoff_id = handoff_id or str(uuid.uuid4())

        # Sensitive handoff target check (REQUIRE_APPROVAL routing)
        if to_agent in self.sensitive_handoff_targets:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Handoff to sensitive agent "{to_agent}" requires human-reviewer approval. '
                "Route to approval queue before continuing."
            )
            d = GovernanceDecision(
                decision=DecisionType.REQUIRE_APPROVAL,
                reason=reason,
                audit_id=effective_handoff_id,
            )
            return d

        agent = AgentIdentity(name=from_agent, session_id=snapshot.get("run_id"))
        decision = self.client.check_action(
            tool="agent.handoff",
            input={
                "handoffId": effective_handoff_id,
                "fromAgent": from_agent,
                "toAgent": to_agent,
                "handoffInputDigest": str(handoff_input or "")[:300],
                "packBinding": snapshot.get("pack_binding", []),
                "metadata": metadata or {},
                "framework": "openai-agents",
            },
            agent=agent,
        )

        if decision.denied:
            if self.client.enforce:
                raise OpenAIAgentsHandoffDeniedError(from_agent, to_agent, decision.reason)
            return decision

        return decision

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _scan_args(self, args: dict[str, Any]) -> Optional[str]:
        """Scan tool arguments for PHI patterns on sensitive keys."""
        for key in self.sensitive_arg_keys:
            value = args.get(key)
            if isinstance(value, str) and _contains_phi(value):
                return key
        return None
