"""
GovernedOpenAIAgents -- governance enforcement for the OpenAI Agents SDK (Python).

This is a FRAMEWORK ADAPTER operating at the SDK layer, not the LLM provider layer.
It sits between customer code and the openai-agents Runner, intercepting tool calls,
agent input/output, and handoffs.

=== ARCHITECTURAL CONTRAST: OpenAI Agents SDK vs LangChain ===

LangChain's callback system is OBSERVABILITY-first. Whether a raise from
on_agent_action or on_tool_start actually blocks execution is NOT guaranteed
by the LangChain callback contract -- it depends on the executor type and
LangChain minor version. GovernedTool._run() is the only guaranteed blocking
path in LangChain (see langchain_integration.py module header).

The OpenAI Agents SDK provides a fundamentally different contract:

  input_guardrails=[...]   -- OpenAI's FIRST-CLASS blocking mechanism.
    These callables fire BEFORE the agent processes input. If a guardrail
    returns GuardrailFunctionOutput(tripwire_triggered=True), the SDK raises
    InputGuardrailTripwireTriggered and the run is BLOCKED. This is part of
    the SDK's public API contract, not a side-effect of exception propagation.

  output_guardrails=[...]  -- Same shape, fires AFTER the agent produces output.
    Returns OutputGuardrailFunctionOutput. Tripwire blocks the output and raises
    OutputGuardrailTripwireTriggered.

  AgentHooks                -- Lifecycle observability hooks (on_start, on_end,
    on_tool_start, on_tool_end, on_handoff). NOT designed as blocking primitives.
    The hooks fire synchronously but the SDK does not guarantee that exceptions
    from hooks will propagate to the caller in all SDK versions. Use these for
    audit logging and defense-in-depth, NOT as your sole enforcement gate.

CONCLUSION:
  - Input/output guardrails are the PRIMARY guaranteed blocking primitives.
  - AgentHooks on_tool_start provides per-tool defense-in-depth (secondary gate).
  - governed_function_tool() wraps at definition time -- guaranteed blocking
    regardless of which agent or runner is in use (mirrors GovernedTool in LC).
  - Document to customers: use guardrails + governed_function_tool for tools you
    want blocked; use hooks for audit coverage and defense-in-depth.

This is a significant architectural improvement over LangChain:
  LangChain:   GovernedTool (required) + callbacks (observability)
  OpenAI Agents: guardrails (SDK contract, guaranteed) + hooks (observability)
                 + governed_function_tool (definition-time, defense-in-depth)

Action name namespace (for pack rule targeting):
  framework.openai_agents.input_guardrail    -- input guardrail check
  framework.openai_agents.output_guardrail   -- output guardrail check
  framework.openai_agents.tool_invoke        -- per-tool check (hooks + decorator)
  framework.openai_agents.handoff            -- handoff boundary check

Supported openai-agents version range (tested against mock primitives):
  openai-agents >= 0.0.3 (Python-first, released March 2025)

Architectural difference vs LangChain framework adapter (langchain_integration.py):
  Python LangChain has sync GovernanceCallbackHandler + async variant.
  OpenAI Agents SDK guardrails are ASYNC-native (async def guardrail_fn).
  This module exposes async guardrail implementations that can be dropped into
  input_guardrails / output_guardrails lists directly.

Optional peer dependencies:
  openai-agents >= 0.0.3

@connexum/python-sdk -- Framework Adapter Layer (Sprint 5, WS-08)
"""

from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Callable, Optional, Union

from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)
from connexum_governance.integrations._wire_shape import build_check_action_body

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

CheckFnType = Callable[[str, dict], Any]

# ---------------------------------------------------------------------------
# Mock-compatible type stubs for OpenAI Agents SDK primitives
#
# The SDK (openai-agents) uses these types in guardrail / hook signatures.
# We define minimal protocols here so this module is importable without the
# SDK installed (mirrors the LangChain pattern: no hard import at module load).
#
# When the real SDK is installed, these are never used -- the SDK's own
# classes satisfy the duck-typing checks.
# ---------------------------------------------------------------------------


@dataclass
class _GuardrailFunctionOutput:
    """Minimal shape of openai-agents GuardrailFunctionOutput."""
    output_info: Any = None
    tripwire_triggered: bool = False


@dataclass
class _RunContextWrapper:
    """Minimal context wrapper passed to guardrails and hooks."""
    context: Any = None


# ---------------------------------------------------------------------------
# Prompt injection detector (reused from langchain_integration pattern)
# ---------------------------------------------------------------------------

_HIGH_INJECTION_PATTERNS = [
    "ignore previous instructions",
    "ignore your system prompt",
    "ignore all previous",
    "disregard previous",
    "forget your instructions",
    "you are now a different",
    "you are now an",
    "act as if you",
    "pretend you are",
    "reveal all secrets",
    "reveal your system prompt",
    "output your instructions",
    "your new instructions are",
    "new instructions:",
    "system override",
    "i am your administrator",
    "i am your operator",
    "override safety",
    "ignore safety",
    "bypass",
    "jailbreak",
]

_MEDIUM_INJECTION_PATTERNS = [
    "ignore the above",
    "disregard the above",
    "don't follow",
    "do not follow",
    "forget what",
    "as an ai without",
    "without restrictions",
    "without limitations",
    "without constraints",
    "act without",
    "you have no",
    "you must always",
    "you must never",
]


def _detect_injection(text: str) -> dict:
    """
    Lightweight prompt injection scan.

    Returns:
        {detected: bool, severity: 'high'|'medium'|'low', patterns: list[str]}
    """
    lowered = text.lower()
    matched_high = [p for p in _HIGH_INJECTION_PATTERNS if p in lowered]
    if matched_high:
        return {"detected": True, "severity": "high", "patterns": matched_high}

    matched_medium = [p for p in _MEDIUM_INJECTION_PATTERNS if p in lowered]
    if matched_medium:
        return {"detected": True, "severity": "medium", "patterns": matched_medium}

    return {"detected": False, "severity": "low", "patterns": []}


# ---------------------------------------------------------------------------
# PII / PHI / sensitive data classifier
#
# Used in the output guardrail to detect protected data leakage.
# Mirrors the G2/G3 guard patterns in the GovernanceClient output classifier.
# ---------------------------------------------------------------------------

import re as _re

_SENSITIVE_PATTERNS = [
    # SSN
    _re.compile(r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"),
    # Credit card (16-digit groups)
    _re.compile(r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"),
    # PHI keywords
    _re.compile(
        r"\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi|medication|prescription)\s*[:=]",
        _re.IGNORECASE,
    ),
    # API key heuristic
    _re.compile(r"\b(sk-|pk_|rk_|api_key\s*[:=])", _re.IGNORECASE),
]


def _contains_sensitive_data(text: str) -> bool:
    """Returns True if text contains PII, PHI, or credential patterns."""
    return any(p.search(text) for p in _SENSITIVE_PATTERNS)


# ---------------------------------------------------------------------------
# HTTP check helpers (same pattern as langchain_integration.py)
# ---------------------------------------------------------------------------

async def _do_check_async(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            return await check_fn(governance_server_url, body)
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        async with _httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


def _do_check_sync(
    governance_server_url: str,
    license_key: str,
    body: dict,
    check_fn: Optional[CheckFnType],
) -> dict:
    if check_fn is not None:
        if asyncio.iscoroutinefunction(check_fn):
            try:
                loop = asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(
                        lambda: asyncio.run(check_fn(governance_server_url, body))
                    )
                    return future.result()
            except RuntimeError:
                return asyncio.run(check_fn(governance_server_url, body))
        return check_fn(governance_server_url, body)

    try:
        import httpx as _httpx
        with _httpx.Client(timeout=5.0) as client:
            resp = client.post(
                f"{governance_server_url.rstrip('/')}/api/v1/governance/check-action",
                headers={
                    "Authorization": f"Bearer {license_key}",
                    "Content-Type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            return resp.json()
    except Exception as exc:
        raise exc


# ---------------------------------------------------------------------------
# Decision enforcement helpers
# ---------------------------------------------------------------------------

def _make_denied_output(reason: str) -> _GuardrailFunctionOutput:
    """Return a tripwire-triggered guardrail output (blocks the run)."""
    return _GuardrailFunctionOutput(
        output_info={"reason": reason, "source": "connexum-governance"},
        tripwire_triggered=True,
    )


def _make_allowed_output() -> _GuardrailFunctionOutput:
    """Return a non-tripwire guardrail output (allows the run)."""
    return _GuardrailFunctionOutput(
        output_info={"source": "connexum-governance"},
        tripwire_triggered=False,
    )


def _enforce_result_sync(
    result: dict,
    context_label: str,
    raise_on_deny: bool,
) -> None:
    """Raise on DENY / PENDING when raise_on_deny=True (sync path for hooks)."""
    decision = result.get("decision", "ALLOW")
    if decision == "DENY":
        reason = result.get("reason") or "policy"
        sys.stderr.write(
            f"[GovernanceAgentHooks] DENIED for '{context_label}'. reason={reason}\n"
        )
        if raise_on_deny:
            raise GovernanceViolation(
                decision="DENY",
                reason=reason,
                audit_id=result.get("auditId"),
            )
        return
    if decision == "REQUIRE_APPROVAL":
        approval_id = result.get("approvalId")
        if not approval_id:
            if raise_on_deny:
                raise GovernanceViolation(
                    decision="DENY",
                    reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                    audit_id=result.get("auditId"),
                )
            return
        sys.stderr.write(
            f"[GovernanceAgentHooks] PENDING for '{context_label}'. "
            f"approvalId={approval_id}\n"
        )
        if raise_on_deny:
            raise GovernancePendingApproval(
                approval_id=approval_id,
                audit_id=result.get("auditId"),
            )


# ---------------------------------------------------------------------------
# GovernanceInputGuardrail
#
# PRIMARY BLOCKING PRIMITIVE for agent input.
# OpenAI Agents SDK guarantees that input_guardrail tripwires block the run.
# ---------------------------------------------------------------------------


class GovernanceInputGuardrail:
    """
    Governance input guardrail for the OpenAI Agents SDK.

    This is one of the PRIMARY BLOCKING PRIMITIVES in the OpenAI Agents SDK.
    When the tripwire is triggered, the SDK raises InputGuardrailTripwireTriggered
    and the agent run is blocked. This is part of the SDK's public API contract.

    BLOCKING CONTRACT (OpenAI Agents SDK):
      tripwire_triggered=True -> SDK raises InputGuardrailTripwireTriggered.
      This is GUARANTEED by the OpenAI Agents SDK guardrail contract.
      Contrast with LangChain callbacks where blocking is version-dependent.

    Usage:
        from connexum_governance.integrations.openai_agents_integration import (
            GovernanceInputGuardrail,
        )

        guardrail = GovernanceInputGuardrail(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        agent = Agent(
            name="my-agent",
            instructions="You are a helpful assistant.",
            input_guardrails=[guardrail.as_guardrail_fn()],
        )
    """

    def __init__(
        self,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        injection_deny_threshold: str = "high",
        _check_fn: Optional[CheckFnType] = None,
    ):
        """
        Args:
            governance_server_url: URL of the governance server.
            license_key: License / JWT key for the governance server.
            pack_ids: Compliance pack IDs to evaluate against.
            injection_deny_threshold: Minimum injection severity to block.
                'high' (default): blocks on high-severity injection only.
                'medium': blocks on medium or high.
            _check_fn: Test injection hook. Replaces the real HTTP check.
                Not part of the public API.
        """
        if not governance_server_url:
            raise ValueError(
                "[GovernanceInputGuardrail] governance_server_url is required"
            )
        if not license_key:
            raise ValueError(
                "[GovernanceInputGuardrail] license_key is required"
            )

        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._injection_deny_threshold = injection_deny_threshold
        self._check_fn = _check_fn

    async def __call__(
        self,
        ctx: Any,
        agent: Any,
        input: Union[str, list],
    ) -> _GuardrailFunctionOutput:
        """
        OpenAI Agents SDK guardrail callable signature.

        Fires before the agent processes input. Returns GuardrailFunctionOutput
        with tripwire_triggered=True to block (SDK raises
        InputGuardrailTripwireTriggered) or tripwire_triggered=False to allow.

        Args:
            ctx: RunContextWrapper from the SDK.
            agent: The Agent instance being invoked.
            input: The raw input (str or list of message dicts).

        Returns:
            GuardrailFunctionOutput: tripwire_triggered=True blocks the run.
        """
        # Normalize input to string for inspection
        if isinstance(input, list):
            input_text = " ".join(
                m.get("content", "") if isinstance(m, dict) else str(m)
                for m in input
            )
        else:
            input_text = str(input)

        # ---- Prompt injection scan (runs before governance server call) ----
        detection = _detect_injection(input_text)
        if detection["detected"]:
            severity = detection["severity"]
            should_block = severity == "high" or (
                self._injection_deny_threshold == "medium" and severity == "medium"
            )
            sys.stderr.write(
                f"[GovernanceInputGuardrail] prompt-injection:{severity} detected. "
                f"patterns={detection['patterns']}\n"
            )
            if should_block:
                return _make_denied_output(
                    f"Prompt injection detected (severity={severity}, "
                    f"patterns={detection['patterns']}). "
                    "Blocked by connexum-governance (Onyx #5 / OWASP LLM01)."
                )

        # ---- Governance server check ----
        agent_name = getattr(agent, "name", "unknown") if agent else "unknown"
        try:
            result = await _do_check_async(
                governance_server_url=self._governance_server_url,
                license_key=self._license_key,
                body=build_check_action_body(
                    tool_name="input_guardrail",
                    agent_name=f"openai-agent:{agent_name}",
                    framework_action="framework.openai_agents.input_guardrail",
                    input_dict={"input": input_text[:2000]},
                    message_preview=input_text[:200],
                    pack_ids=self._pack_ids,
                    extra_metadata={"agentName": agent_name, "inputPreview": input_text[:200]},
                    source="GovernanceInputGuardrail",
                ),
                check_fn=self._check_fn,
            )
        except Exception as exc:
            # Fail-closed but surface the real reason so customers can see schema /
            # auth failures instead of a generic block. The HTTPStatusError chain
            # carries the response body; include it when present.
            detail = str(exc)
            response = getattr(exc, "response", None)
            if response is not None:
                try:
                    body_text = response.text
                    if body_text:
                        detail = f"{detail} | server_body={body_text[:500]}"
                except Exception as body_exc:
                    sys.stderr.write(
                        f"[OpenAIGuardrail] could not extract response body for "
                        f"diagnostic: {body_exc}\n"
                    )
            sys.stderr.write(
                f"[GovernanceInputGuardrail] governance check failed: {detail}. "
                "Fail-closed: blocking input.\n"
            )
            return _make_denied_output(
                f"Governance server error: {detail}. Blocked fail-closed."
            )

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "policy"
            sys.stderr.write(
                f"[GovernanceInputGuardrail] DENIED for agent '{agent_name}'. "
                f"reason={reason}\n"
            )
            return _make_denied_output(reason)

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            reason = (
                f"Action requires approval. approvalId={approval_id}"
                if approval_id
                else "Governance returned REQUIRE_APPROVAL with no approvalId"
            )
            sys.stderr.write(
                f"[GovernanceInputGuardrail] PENDING for agent '{agent_name}'. "
                f"approvalId={approval_id}\n"
            )
            return _make_denied_output(reason)

        # ALLOW
        return _make_allowed_output()

    def as_guardrail_fn(self) -> "GovernanceInputGuardrail":
        """
        Return self for use in input_guardrails=[...] lists.

        The OpenAI Agents SDK accepts any async callable with the signature
        (ctx, agent, input) -> GuardrailFunctionOutput. This class implements
        __call__ with that signature, so it can be passed directly.
        """
        return self


# ---------------------------------------------------------------------------
# GovernanceOutputGuardrail
#
# PRIMARY BLOCKING PRIMITIVE for agent output.
# OpenAI Agents SDK guarantees that output_guardrail tripwires block the output.
# ---------------------------------------------------------------------------


class GovernanceOutputGuardrail:
    """
    Governance output guardrail for the OpenAI Agents SDK.

    This is one of the PRIMARY BLOCKING PRIMITIVES in the OpenAI Agents SDK.
    When the tripwire is triggered, the SDK raises OutputGuardrailTripwireTriggered.

    In addition to the governance server check, this guardrail scans output
    for PII / PHI / credential leakage using the built-in sensitive data
    classifier (G2/G3 equivalent). Leakage causes a tripwire regardless of
    the governance server response.

    BLOCKING CONTRACT (OpenAI Agents SDK):
      tripwire_triggered=True -> SDK raises OutputGuardrailTripwireTriggered.
      This is GUARANTEED by the OpenAI Agents SDK guardrail contract.

    Usage:
        from connexum_governance.integrations.openai_agents_integration import (
            GovernanceOutputGuardrail,
        )

        guardrail = GovernanceOutputGuardrail(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
            scan_output_for_sensitive_data=True,
        )

        agent = Agent(
            name="my-agent",
            output_guardrails=[guardrail.as_guardrail_fn()],
        )
    """

    def __init__(
        self,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        scan_output_for_sensitive_data: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        """
        Args:
            governance_server_url: URL of the governance server.
            license_key: License / JWT key for the governance server.
            pack_ids: Compliance pack IDs to evaluate against.
            scan_output_for_sensitive_data: If True (default), scan output
                text for PII / PHI / credentials using the built-in classifier.
                Matching data causes a tripwire even if the governance server
                returns ALLOW.
            _check_fn: Test injection hook. Replaces the real HTTP check.
                Not part of the public API.
        """
        if not governance_server_url:
            raise ValueError(
                "[GovernanceOutputGuardrail] governance_server_url is required"
            )
        if not license_key:
            raise ValueError(
                "[GovernanceOutputGuardrail] license_key is required"
            )

        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._scan_output = scan_output_for_sensitive_data
        self._check_fn = _check_fn

    async def __call__(
        self,
        ctx: Any,
        agent: Any,
        output: Any,
    ) -> _GuardrailFunctionOutput:
        """
        OpenAI Agents SDK output guardrail callable signature.

        Fires after the agent produces output. Returns GuardrailFunctionOutput
        with tripwire_triggered=True to block (SDK raises
        OutputGuardrailTripwireTriggered) or tripwire_triggered=False to allow.

        Args:
            ctx: RunContextWrapper from the SDK.
            agent: The Agent instance that produced the output.
            output: The agent's final output (str, dict, or pydantic model).

        Returns:
            GuardrailFunctionOutput: tripwire_triggered=True blocks the output.
        """
        # Normalize output to string
        if isinstance(output, str):
            output_text = output
        elif hasattr(output, "model_dump"):
            import json as _json
            output_text = _json.dumps(output.model_dump())
        elif isinstance(output, dict):
            import json as _json
            output_text = _json.dumps(output)
        else:
            output_text = str(output)

        # ---- PII / PHI / sensitive data scan ----
        if self._scan_output and _contains_sensitive_data(output_text):
            reason = (
                "Output contains PII / PHI / credential patterns. "
                "Blocked by connexum-governance output classifier (G2/G3)."
            )
            sys.stderr.write(
                f"[GovernanceOutputGuardrail] sensitive data detected in output. "
                f"Triggering tripwire.\n"
            )
            return _make_denied_output(reason)

        # ---- Governance server check ----
        agent_name = getattr(agent, "name", "unknown") if agent else "unknown"
        try:
            result = await _do_check_async(
                governance_server_url=self._governance_server_url,
                license_key=self._license_key,
                body=build_check_action_body(
                    tool_name="output_guardrail",
                    agent_name=f"openai-agent:{agent_name}",
                    framework_action="framework.openai_agents.output_guardrail",
                    input_dict={"output": output_text[:2000]},
                    message_preview=output_text[:200],
                    pack_ids=self._pack_ids,
                    extra_metadata={"agentName": agent_name, "outputPreview": output_text[:200]},
                    source="GovernanceOutputGuardrail",
                ),
                check_fn=self._check_fn,
            )
        except Exception as exc:
            detail = str(exc)
            response = getattr(exc, "response", None)
            if response is not None:
                try:
                    body_text = response.text
                    if body_text:
                        detail = f"{detail} | server_body={body_text[:500]}"
                except Exception as body_exc:
                    sys.stderr.write(
                        f"[OpenAIGuardrail] could not extract response body for "
                        f"diagnostic: {body_exc}\n"
                    )
            sys.stderr.write(
                f"[GovernanceOutputGuardrail] governance check failed: {detail}. "
                "Fail-closed: blocking output.\n"
            )
            return _make_denied_output(
                f"Governance server error: {detail}. Blocked fail-closed."
            )

        decision = result.get("decision", "ALLOW")

        if decision == "DENY":
            reason = result.get("reason") or "policy"
            sys.stderr.write(
                f"[GovernanceOutputGuardrail] DENIED for agent '{agent_name}'. "
                f"reason={reason}\n"
            )
            return _make_denied_output(reason)

        if decision == "REQUIRE_APPROVAL":
            approval_id = result.get("approvalId")
            reason = (
                f"Output requires approval. approvalId={approval_id}"
                if approval_id
                else "Governance returned REQUIRE_APPROVAL with no approvalId"
            )
            return _make_denied_output(reason)

        return _make_allowed_output()

    def as_guardrail_fn(self) -> "GovernanceOutputGuardrail":
        """Return self for use in output_guardrails=[...] lists."""
        return self


# ---------------------------------------------------------------------------
# GovernanceAgentHooks
#
# OBSERVABILITY + DEFENSE-IN-DEPTH (secondary gate)
# Not the primary blocking mechanism -- use guardrails for that.
# on_tool_start raises GovernanceViolation on DENY, providing defense-in-depth
# at the tool boundary alongside the input guardrail.
# ---------------------------------------------------------------------------


class GovernanceAgentHooks:
    """
    AgentHooks implementation that enforces governance at lifecycle boundaries.

    BLOCKING CONTRACT:
      on_tool_start raises GovernanceViolation on DENY (defense-in-depth alongside
      the input guardrail). Whether the OpenAI Agents SDK propagates this raise
      depends on the SDK version -- treat it as defense-in-depth, NOT as the
      primary blocking gate. Use GovernanceInputGuardrail for primary blocking.

      on_handoff logs to the audit chain but does NOT block by default (handoff
      governance is handled at the input guardrail level for the target agent).

      on_tool_end optionally scans tool output for sensitive data.

      on_start / on_end emit audit lifecycle events.

    Usage:
        from connexum_governance.integrations.openai_agents_integration import (
            GovernanceAgentHooks,
        )

        hooks = GovernanceAgentHooks(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        agent = Agent(
            name="my-agent",
            hooks=hooks,
        )
    """

    def __init__(
        self,
        governance_server_url: str,
        license_key: str,
        pack_ids: Optional[list] = None,
        raise_on_deny: bool = True,
        scan_tool_output: bool = True,
        _check_fn: Optional[CheckFnType] = None,
    ):
        """
        Args:
            governance_server_url: URL of the governance server.
            license_key: License / JWT key for the governance server.
            pack_ids: Compliance pack IDs to evaluate against.
            raise_on_deny: When True (default), on_tool_start raises
                GovernanceViolation on DENY. Set False for observability-only mode.
                Note: even with raise_on_deny=True, SDK version may affect whether
                the raise propagates. Use input_guardrails for guaranteed blocking.
            scan_tool_output: If True (default), on_tool_end scans tool output
                for PII / PHI / credentials and logs warnings.
            _check_fn: Test injection hook. Not part of the public API.
        """
        if not governance_server_url:
            raise ValueError(
                "[GovernanceAgentHooks] governance_server_url is required"
            )
        if not license_key:
            raise ValueError(
                "[GovernanceAgentHooks] license_key is required"
            )

        self._governance_server_url = governance_server_url
        self._license_key = license_key
        self._pack_ids = pack_ids or []
        self._raise_on_deny = raise_on_deny
        self._scan_tool_output = scan_tool_output
        self._check_fn = _check_fn

    async def _check(self, body: dict) -> dict:
        return await _do_check_async(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            body=body,
            check_fn=self._check_fn,
        )

    async def on_start(
        self,
        context: Any,
        agent: Any,
    ) -> None:
        """
        Fires when the agent starts running. Emits lifecycle audit event.

        This is an OBSERVABILITY hook. It does not run a governance check
        (input guardrail covers the input at this point). Logs the agent start
        to audit trail via stderr.
        """
        agent_name = getattr(agent, "name", "unknown") if agent else "unknown"
        sys.stderr.write(
            f"[GovernanceAgentHooks] agent_start: agent={agent_name}\n"
        )

    async def on_end(
        self,
        context: Any,
        agent: Any,
        output: Any,
    ) -> None:
        """
        Fires when the agent finishes. Emits lifecycle audit event.

        This is an OBSERVABILITY hook. Output is already screened by the
        output guardrail at this point. Logs the agent end to audit trail.
        """
        agent_name = getattr(agent, "name", "unknown") if agent else "unknown"
        sys.stderr.write(
            f"[GovernanceAgentHooks] agent_end: agent={agent_name}\n"
        )

    async def on_tool_start(
        self,
        context: Any,
        agent: Any,
        tool: Any,
    ) -> None:
        """
        Fires before a tool is called. Defense-in-depth governance check.

        Runs a governance check with action 'framework.openai_agents.tool_invoke'.
        On DENY, raises GovernanceViolation (if raise_on_deny=True).
        On PENDING, raises GovernancePendingApproval (if raise_on_deny=True).

        BLOCKING NOTE: This provides defense-in-depth alongside input guardrails.
        Whether the SDK propagates this raise in all versions is not part of the
        public AgentHooks contract. Use GovernanceInputGuardrail as the primary gate.

        Args:
            context: RunContextWrapper from the SDK.
            agent: The Agent instance.
            tool: The tool being invoked (has .name attribute).
        """
        tool_name = getattr(tool, "name", None) or getattr(tool, "__name__", "unknown")
        agent_name = getattr(agent, "name", "unknown") if agent else "unknown"

        result = await self._check(build_check_action_body(
            tool_name=tool_name,
            agent_name=f"openai-agent:{agent_name}",
            framework_action="framework.openai_agents.tool_invoke",
            pack_ids=self._pack_ids,
            extra_metadata={"toolName": tool_name, "agentName": agent_name},
            source="on_tool_start",
        ))

        _enforce_result_sync(result, tool_name, self._raise_on_deny)

    async def on_tool_end(
        self,
        context: Any,
        agent: Any,
        tool: Any,
        result: Any,
    ) -> None:
        """
        Fires after a tool completes. Optional output scan.

        Scans tool output for PII / PHI / credentials if scan_tool_output=True.
        Logs a warning if sensitive data is detected. This is an OBSERVABILITY
        hook -- it does not block (output guardrail covers agent-level output).
        """
        if not self._scan_tool_output:
            return

        tool_name = getattr(tool, "name", None) or getattr(tool, "__name__", "unknown")
        result_text = str(result) if not isinstance(result, str) else result

        if _contains_sensitive_data(result_text):
            sys.stderr.write(
                f"[GovernanceAgentHooks] on_tool_end: sensitive data detected in "
                f"output from tool '{tool_name}'. Consider output guardrail coverage.\n"
            )

    async def on_handoff(
        self,
        context: Any,
        agent: Any,
        source: Any,
    ) -> None:
        """
        Fires when an agent handoff occurs. Logs the handoff to audit trail.

        Handoffs cross trust boundaries in the OpenAI Agents SDK. This hook
        logs the handoff event with the source and target agent for audit
        trail integrity.

        NOTE: This hook does NOT block the handoff by default. The target
        agent's input guardrail will fire when the target agent processes input.
        For proactive handoff blocking, use wrap_agent() to inject guardrails
        on all agents in the handoff chain.

        Args:
            context: RunContextWrapper.
            agent: The target agent (receiving the handoff).
            source: The source agent (initiating the handoff).
        """
        target_name = getattr(agent, "name", "unknown") if agent else "unknown"
        source_name = getattr(source, "name", "unknown") if source else "unknown"

        sys.stderr.write(
            f"[GovernanceAgentHooks] handoff: source={source_name} -> "
            f"target={target_name}. "
            f"Logging to audit chain. "
            f"action=framework.openai_agents.handoff\n"
        )

        # Log the handoff event to governance server (observability, non-blocking)
        try:
            await self._check(build_check_action_body(
                tool_name="handoff",
                agent_name=f"openai-agent:{target_name}",
                framework_action="framework.openai_agents.handoff",
                pack_ids=self._pack_ids,
                extra_metadata={
                    "sourceAgent": source_name,
                    "targetAgent": target_name,
                },
                source="on_handoff",
            ))
        except Exception as exc:
            sys.stderr.write(
                f"[GovernanceAgentHooks] on_handoff audit log failed: {exc}\n"
            )


# ---------------------------------------------------------------------------
# governed_function_tool
#
# DEFINITION-TIME blocking. Wraps the @function_tool decorator so governance
# runs before the tool function executes, regardless of which agent or runner
# the tool is registered on.
#
# Mirrors the GovernedTool pattern from langchain_integration.py but adapted
# for the OpenAI Agents SDK function_tool contract.
# ---------------------------------------------------------------------------


def governed_function_tool(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    _check_fn: Optional[CheckFnType] = None,
) -> Callable:
    """
    Decorator factory for governed function tools (definition-time blocking).

    Wraps a function so that governance runs BEFORE the tool executes,
    regardless of which agent or runner the tool is registered on.

    This provides GUARANTEED BLOCKING at tool definition time -- a tool wrapped
    with governed_function_tool will always check governance before executing,
    even if the agent has no input guardrail attached.

    This is equivalent to GovernedTool._run() in langchain_integration.py.
    Both provide definition-time guarantee that bypasses orchestrator-level
    hook registration gaps.

    Usage:
        from connexum_governance.integrations.openai_agents_integration import (
            governed_function_tool,
        )

        gov_tool = governed_function_tool(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        # Async function tool:
        @gov_tool
        async def web_search(query: str) -> str:
            return f"Results for: {query}"

        # Sync function tool:
        @gov_tool
        def calculate(expression: str) -> str:
            return str(eval(expression))

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), DENY raises GovernanceViolation
            before the underlying function runs.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        A decorator that wraps any function with a governance pre-check.
    """
    if not governance_server_url:
        raise ValueError("[governed_function_tool] governance_server_url is required")
    if not license_key:
        raise ValueError("[governed_function_tool] license_key is required")

    def decorator(fn: Callable) -> Callable:
        tool_name = getattr(fn, "__name__", "unknown_tool")

        if asyncio.iscoroutinefunction(fn):
            @wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                # Build input preview for governance
                import json as _json
                try:
                    input_preview = _json.dumps(kwargs or dict(enumerate(args)))[:200]
                except Exception:
                    input_preview = str(args)[:200]

                result = await _do_check_async(
                    governance_server_url=governance_server_url,
                    license_key=license_key,
                    body=build_check_action_body(
                        tool_name=tool_name,
                        agent_name=f"openai-tool:{tool_name}",
                        framework_action="framework.openai_agents.tool_invoke",
                        input_dict={"input": input_preview},
                        message_preview=input_preview,
                        pack_ids=pack_ids,
                        extra_metadata={"toolName": tool_name, "inputPreview": input_preview},
                        source="governed_function_tool",
                    ),
                    check_fn=_check_fn,
                )

                decision = result.get("decision", "ALLOW")
                if decision == "DENY":
                    reason = result.get("reason") or "Tool call denied by governance"
                    sys.stderr.write(
                        f"[governed_function_tool:{tool_name}] DENIED. reason={reason}\n"
                    )
                    if raise_on_deny:
                        raise GovernanceViolation(
                            decision="DENY",
                            reason=reason,
                            audit_id=result.get("auditId"),
                        )
                    return f"[GOVERNANCE DENIED] {reason}"

                if decision == "REQUIRE_APPROVAL":
                    approval_id = result.get("approvalId")
                    if not approval_id:
                        if raise_on_deny:
                            raise GovernanceViolation(
                                decision="DENY",
                                reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                                audit_id=result.get("auditId"),
                            )
                        return "[GOVERNANCE PENDING] No approvalId returned"
                    sys.stderr.write(
                        f"[governed_function_tool:{tool_name}] PENDING. "
                        f"approvalId={approval_id}\n"
                    )
                    if raise_on_deny:
                        raise GovernancePendingApproval(
                            approval_id=approval_id,
                            audit_id=result.get("auditId"),
                        )
                    return f"[GOVERNANCE PENDING] approvalId={approval_id}"

                # ALLOW -- call the underlying function
                return await fn(*args, **kwargs)

            async_wrapper._governed = True
            async_wrapper._governed_tool_name = tool_name
            return async_wrapper

        else:
            @wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                import json as _json
                try:
                    input_preview = _json.dumps(kwargs or dict(enumerate(args)))[:200]
                except Exception:
                    input_preview = str(args)[:200]

                result = _do_check_sync(
                    governance_server_url=governance_server_url,
                    license_key=license_key,
                    body=build_check_action_body(
                        tool_name=tool_name,
                        agent_name=f"openai-tool:{tool_name}",
                        framework_action="framework.openai_agents.tool_invoke",
                        input_dict={"input": input_preview},
                        message_preview=input_preview,
                        pack_ids=pack_ids,
                        extra_metadata={"toolName": tool_name, "inputPreview": input_preview},
                        source="governed_function_tool",
                    ),
                    check_fn=_check_fn,
                )

                decision = result.get("decision", "ALLOW")
                if decision == "DENY":
                    reason = result.get("reason") or "Tool call denied by governance"
                    sys.stderr.write(
                        f"[governed_function_tool:{tool_name}] DENIED. reason={reason}\n"
                    )
                    if raise_on_deny:
                        raise GovernanceViolation(
                            decision="DENY",
                            reason=reason,
                            audit_id=result.get("auditId"),
                        )
                    return f"[GOVERNANCE DENIED] {reason}"

                if decision == "REQUIRE_APPROVAL":
                    approval_id = result.get("approvalId")
                    if not approval_id:
                        if raise_on_deny:
                            raise GovernanceViolation(
                                decision="DENY",
                                reason="Governance returned REQUIRE_APPROVAL with no approvalId",
                                audit_id=result.get("auditId"),
                            )
                        return "[GOVERNANCE PENDING] No approvalId returned"
                    sys.stderr.write(
                        f"[governed_function_tool:{tool_name}] PENDING. "
                        f"approvalId={approval_id}\n"
                    )
                    if raise_on_deny:
                        raise GovernancePendingApproval(
                            approval_id=approval_id,
                            audit_id=result.get("auditId"),
                        )
                    return f"[GOVERNANCE PENDING] approvalId={approval_id}"

                return fn(*args, **kwargs)

            sync_wrapper._governed = True
            sync_wrapper._governed_tool_name = tool_name
            return sync_wrapper

    return decorator


# ---------------------------------------------------------------------------
# wrap_agent
#
# Convenience wrapper: injects guardrails + hooks onto an existing Agent.
# ---------------------------------------------------------------------------


def wrap_agent(
    agent: Any,
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    scan_output: bool = True,
    injection_deny_threshold: str = "high",
    _check_fn: Optional[CheckFnType] = None,
) -> Any:
    """
    Convenience wrapper: injects governance onto an existing OpenAI Agent.

    Attaches GovernanceInputGuardrail, GovernanceOutputGuardrail, and
    GovernanceAgentHooks to the agent's input_guardrails, output_guardrails,
    and hooks attributes respectively.

    Idempotent: calling wrap_agent twice will not double-inject guardrails
    (checked by presence of _connexum_governed marker on guardrail objects).

    Args:
        agent: An openai-agents Agent instance (or duck-type equivalent).
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: Passed to GovernanceAgentHooks (hook-level DENY behavior).
        scan_output: If True, GovernanceOutputGuardrail scans for PII/PHI.
        injection_deny_threshold: Passed to GovernanceInputGuardrail.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        The same agent instance with governance wired.
    """
    input_guardrail = GovernanceInputGuardrail(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        injection_deny_threshold=injection_deny_threshold,
        _check_fn=_check_fn,
    )
    input_guardrail._connexum_governed = True

    output_guardrail = GovernanceOutputGuardrail(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        scan_output_for_sensitive_data=scan_output,
        _check_fn=_check_fn,
    )
    output_guardrail._connexum_governed = True

    hooks = GovernanceAgentHooks(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        scan_tool_output=scan_output,
        _check_fn=_check_fn,
    )
    hooks._connexum_governed = True

    # Inject input guardrails (idempotent)
    if not hasattr(agent, "input_guardrails") or agent.input_guardrails is None:
        agent.input_guardrails = []
    already_has_input = any(
        getattr(g, "_connexum_governed", False) for g in agent.input_guardrails
    )
    if not already_has_input:
        agent.input_guardrails.append(input_guardrail)

    # Inject output guardrails (idempotent)
    if not hasattr(agent, "output_guardrails") or agent.output_guardrails is None:
        agent.output_guardrails = []
    already_has_output = any(
        getattr(g, "_connexum_governed", False) for g in agent.output_guardrails
    )
    if not already_has_output:
        agent.output_guardrails.append(output_guardrail)

    # Inject hooks (idempotent -- replace if not yet governed)
    existing_hooks = getattr(agent, "hooks", None)
    if not getattr(existing_hooks, "_connexum_governed", False):
        agent.hooks = hooks

    return agent


# ---------------------------------------------------------------------------
# GovernedOpenAIAgentsInstance -- namespace returned by factory
# ---------------------------------------------------------------------------


@dataclass
class GovernedOpenAIAgentsInstance:
    """
    Governed OpenAI Agents SDK object returned by create_governed_openai_agents().

    Exposes all integration helpers for the OpenAI Agents SDK framework adapter.
    """

    input_guardrail: GovernanceInputGuardrail
    """
    GovernanceInputGuardrail. PRIMARY BLOCKING PRIMITIVE for agent input.
    SDK contract guarantees tripwire blocks run (raises InputGuardrailTripwireTriggered).
    """

    output_guardrail: GovernanceOutputGuardrail
    """
    GovernanceOutputGuardrail. PRIMARY BLOCKING PRIMITIVE for agent output.
    SDK contract guarantees tripwire blocks output (raises OutputGuardrailTripwireTriggered).
    Also scans for PII / PHI / credential leakage (G2/G3 equivalent).
    """

    hooks: GovernanceAgentHooks
    """
    GovernanceAgentHooks. OBSERVABILITY + DEFENSE-IN-DEPTH (secondary gate).
    on_tool_start raises GovernanceViolation on DENY (defense-in-depth alongside guardrails).
    on_handoff logs handoff boundary events to audit chain.
    """

    _governance_server_url: str = field(repr=False)
    _license_key: str = field(repr=False)
    _pack_ids: list = field(default_factory=list, repr=False)
    _raise_on_deny: bool = field(default=True, repr=False)
    _check_fn: Optional[CheckFnType] = field(default=None, repr=False)

    def function_tool_decorator(self) -> Callable:
        """
        Return a governed_function_tool decorator pre-configured with this instance's settings.

        Usage:
            gov = create_governed_openai_agents(...)
            tool_decorator = gov.function_tool_decorator()

            @tool_decorator
            async def web_search(query: str) -> str:
                ...
        """
        return governed_function_tool(
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )

    def wrap_agent(self, agent: Any) -> Any:
        """
        Inject governance guardrails + hooks onto an existing Agent.

        Returns the same agent with governance wired (idempotent).
        """
        return wrap_agent(
            agent=agent,
            governance_server_url=self._governance_server_url,
            license_key=self._license_key,
            pack_ids=self._pack_ids,
            raise_on_deny=self._raise_on_deny,
            _check_fn=self._check_fn,
        )


# ---------------------------------------------------------------------------
# create_governed_openai_agents -- primary public factory
# ---------------------------------------------------------------------------


def create_governed_openai_agents(
    governance_server_url: str,
    license_key: str,
    pack_ids: Optional[list] = None,
    raise_on_deny: bool = True,
    scan_output: bool = True,
    injection_deny_threshold: str = "high",
    _check_fn: Optional[CheckFnType] = None,
) -> GovernedOpenAIAgentsInstance:
    """
    Primary factory for the OpenAI Agents SDK governance adapter.

    Returns a GovernedOpenAIAgentsInstance exposing all integration helpers.

    ARCHITECTURAL NOTE: The OpenAI Agents SDK provides FIRST-CLASS blocking
    primitives via input_guardrails and output_guardrails. This is a materially
    better blocking story than LangChain's callback system.

    LangChain callbacks were designed for OBSERVABILITY and whether raises
    propagate to block execution is version-dependent. Customers must use
    GovernedTool._run() for guaranteed blocking in LangChain.

    OpenAI Agents SDK guardrails are designed to block: when a guardrail returns
    tripwire_triggered=True, the SDK raises a named exception and the run is
    stopped. No version-dependency, no executor-specific behavior.

    RECOMMENDATION: For customers using both frameworks, the OpenAI Agents SDK
    integration provides stronger out-of-the-box blocking guarantees. This should
    inform product positioning: "guaranteed first-class blocking on OpenAI Agents
    SDK vs defense-in-depth approach required on LangChain."

    Usage:
        from connexum_governance.integrations.openai_agents_integration import (
            create_governed_openai_agents,
        )

        gov = create_governed_openai_agents(
            governance_server_url="http://localhost:3200",
            license_key=os.environ["MYCC_LICENSE_KEY"],
            pack_ids=["hipaa"],
        )

        # Option 1: attach guardrails + hooks when defining an agent
        agent = Agent(
            name="my-agent",
            instructions="You are a helpful assistant.",
            input_guardrails=[gov.input_guardrail],
            output_guardrails=[gov.output_guardrail],
            hooks=gov.hooks,
        )

        # Option 2: wrap an existing agent (idempotent)
        agent = gov.wrap_agent(existing_agent)

        # Option 3: wrap tools at definition time (guaranteed blocking)
        @gov.function_tool_decorator()
        async def web_search(query: str) -> str:
            return f"Results for: {query}"

    Args:
        governance_server_url: URL of the governance server.
        license_key: License / JWT key for the governance server.
        pack_ids: Compliance pack IDs to evaluate against.
        raise_on_deny: When True (default), on_tool_start (in hooks) raises
            GovernanceViolation on DENY. Guardrails always block via tripwire.
        scan_output: Scan output for PII / PHI / credentials (G2/G3 equivalent).
        injection_deny_threshold: 'high' or 'medium' injection scan threshold.
        _check_fn: Test injection hook. Not part of the public API.

    Returns:
        GovernedOpenAIAgentsInstance with all integration helpers.
    """
    input_guardrail = GovernanceInputGuardrail(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        injection_deny_threshold=injection_deny_threshold,
        _check_fn=_check_fn,
    )

    output_guardrail = GovernanceOutputGuardrail(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        scan_output_for_sensitive_data=scan_output,
        _check_fn=_check_fn,
    )

    hooks_instance = GovernanceAgentHooks(
        governance_server_url=governance_server_url,
        license_key=license_key,
        pack_ids=pack_ids,
        raise_on_deny=raise_on_deny,
        scan_tool_output=scan_output,
        _check_fn=_check_fn,
    )

    return GovernedOpenAIAgentsInstance(
        input_guardrail=input_guardrail,
        output_guardrail=output_guardrail,
        hooks=hooks_instance,
        _governance_server_url=governance_server_url,
        _license_key=license_key,
        _pack_ids=pack_ids or [],
        _raise_on_deny=raise_on_deny,
        _check_fn=_check_fn,
    )
