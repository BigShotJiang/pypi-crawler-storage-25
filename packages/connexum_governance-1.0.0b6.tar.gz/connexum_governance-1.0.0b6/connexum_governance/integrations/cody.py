"""Sourcegraph Cody governance integration.

Sourcegraph Cody is an enterprise code intelligence + AI assistant that wraps
the Sourcegraph platform's code-search and context-fetch engine.

Architecture:
  The primary adapter is TypeScript-native (src/ide-adapters/cody.ts).
  This Python shim lets a Python-hosted governance policy server participate
  in the Cody decision loop via HTTP.

  Seven distinct governable surfaces (parity with TS adapter):
    intercept_code_search(request)   -- code-search query gate
    intercept_context_fetch(request) -- repository context fetch gate
    intercept_autocomplete(request)  -- inline autocomplete gate
    intercept_chat(request)          -- chat request gate
    intercept_commit_message(request)-- commit message generation gate
    intercept_recipe(request)        -- recipe execution gate
    intercept_embeddings_index(request) -- embeddings index gate

  Deployment modes:
    sourcegraph-cloud -- Sourcegraph-managed SaaS
    self-hosted       -- Customer-operated instance (air-gapped, on-prem)
    free-pro          -- Individual Cody Free / Cody Pro; no embeddings

  Pen-test IDs mirrored from TS adapter:
    PT-ADAPT-CODY-1: empty pack_binding denied (pack-binding primacy)
    PT-ADAPT-CODY-2: auth tokens never appear in audit entries
    PT-ADAPT-CODY-3: invalid deployment_mode raises ValueError at init
    PT-ADAPT-CODY-4: embeddings index blocked in free-pro mode

BAA-eligible deployment modes:
  sourcegraph-cloud (with active Sourcegraph BAA), self-hosted

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.cody import CodyGovernedClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = CodyGovernedClient(
        client=gov,
        agent_name="cody-agent",
        pack_binding=["hipaa"],
        deployment_mode="self-hosted",
    )

    # Gate a chat request:
    decision = adapter.intercept_chat({
        "promptText": "Explain this authentication function",
        "packBinding": ["hipaa"],
    })

    # Gate a code search:
    decision = adapter.intercept_code_search({
        "query": "type:function handlePatient",
        "repos": ["github.com/health/ehr"],
        "packBinding": ["hipaa"],
    })

    # Gate an embeddings index (blocked in free-pro mode):
    decision = adapter.intercept_embeddings_index({
        "repos": ["github.com/acme/api"],
        "packBinding": ["soc2"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Deployment modes
# ---------------------------------------------------------------------------

CODY_VALID_DEPLOYMENT_MODES: tuple[str, ...] = (
    "sourcegraph-cloud",
    "self-hosted",
    "free-pro",
)

CODY_BAA_ELIGIBLE_MODES: tuple[str, ...] = (
    "self-hosted",        # customer controls data residency
    "sourcegraph-cloud",  # eligible with active Sourcegraph BAA
)

# ---------------------------------------------------------------------------
# Secret patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",           re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",               re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",        re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",           re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",       re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",   re.compile(r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Bearer token",             re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
    ("Database URL with creds",  re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("Sourcegraph access token", re.compile(r"sgp_[0-9A-Za-z]{20,}")),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Sensitive file path patterns
# (paths that must not be injected into context windows)
# ---------------------------------------------------------------------------

_SENSITIVE_PATH_PATTERNS: list[re.Pattern] = [
    re.compile(r"^/etc/"),
    re.compile(r"^/root/"),
    re.compile(r"(^|/)\.env$"),
    re.compile(r"\.env\."),
    re.compile(r"secrets?/", re.IGNORECASE),
    re.compile(r"private_?key", re.IGNORECASE),
    re.compile(r"\.pem$", re.IGNORECASE),
    re.compile(r"\.key$", re.IGNORECASE),
    re.compile(r"id_rsa", re.IGNORECASE),
    re.compile(r"id_ed25519", re.IGNORECASE),
    re.compile(r"\.pfx$", re.IGNORECASE),
    re.compile(r"\.p12$", re.IGNORECASE),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    """Return the name of the first matched secret pattern, or None."""
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_for_phi(text: str) -> Optional[str]:
    """Return the pattern string of the first matched PHI indicator, or None."""
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _is_sensitive_path(file_path: str) -> bool:
    """Return True if the file path matches a sensitive-path pattern."""
    return any(p.search(file_path) for p in _SENSITIVE_PATH_PATTERNS)


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(
        p.lower() in ("hipaa", "hitech", "hipaa-hitech")
        for p in pack_binding
    )


def _scan_diff_for_secrets(diff: str) -> Optional[tuple[int, str]]:
    """
    Scan a unified diff for secret patterns on added lines (+).
    Returns (line_number, pattern_name) of the first match, or None.
    """
    for i, line in enumerate(diff.splitlines(), start=1):
        if not line.startswith("+") or line.startswith("+++"):
            continue
        content = line[1:]
        match = _scan_for_secrets(content)
        if match:
            return (i, match)
    return None


# ---------------------------------------------------------------------------
# CodyGovernedClient
# ---------------------------------------------------------------------------

class CodyGovernedClient(BaseGovernanceIntegration):
    """REST-client shim for Sourcegraph Cody governance.

    Sourcegraph Cody is TypeScript-native. This Python shim participates in
    the decision loop by governing all seven Cody hook surfaces:
      1. Code search (intercept_code_search)
      2. Context fetch (intercept_context_fetch)
      3. Autocomplete (intercept_autocomplete)
      4. Chat (intercept_chat)
      5. Commit message generation (intercept_commit_message)
      6. Recipe execution (intercept_recipe)
      7. Embeddings index (intercept_embeddings_index)

    Deployment modes: sourcegraph-cloud, self-hosted, free-pro.
    BAA-eligible modes: self-hosted, sourcegraph-cloud (with active BAA).
    free-pro is never BAA-eligible; embeddings index is blocked in free-pro.

    Pen-tests:
      PT-ADAPT-CODY-1: empty pack_binding => denied (pack-binding primacy)
      PT-ADAPT-CODY-2: auth tokens never appear in audit entries
      PT-ADAPT-CODY-3: invalid deployment_mode raises ValueError at init
      PT-ADAPT-CODY-4: embeddings index blocked in free-pro mode
    """

    _FRAMEWORK_NAME = "sourcegraph-cody"
    _LAYER_NAME = "sourcegraph-cody-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        deployment_mode: str = "sourcegraph-cloud",
        sourcegraph_instance_url: Optional[str] = None,
        hipaa_reviewer_tier: str = "T2_LEAD",
        recipe_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            deployment_mode: Cody deployment mode.
                             One of: sourcegraph-cloud, self-hosted, free-pro.
            sourcegraph_instance_url: Base URL for self-hosted instances
                                      (for audit provenance only; never logged in secrets).
            hipaa_reviewer_tier: Reviewer tier for HIPAA/PHI requests.
            recipe_reviewer_tier: Reviewer tier for recipe execution under regulated packs.

        Raises:
            ValueError: If deployment_mode is not a valid Cody deployment mode
                        (PT-ADAPT-CODY-3).
        """
        # PT-ADAPT-CODY-3: validate deployment_mode at construction time.
        if deployment_mode not in CODY_VALID_DEPLOYMENT_MODES:
            raise ValueError(
                f"CodyGovernedClient: invalid deployment_mode '{deployment_mode}'. "
                f"Must be one of: {', '.join(CODY_VALID_DEPLOYMENT_MODES)}. "
                "Deployment mode is required to enforce data-residency bounds."
            )
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.deployment_mode = deployment_mode
        self.sourcegraph_instance_url = sourcegraph_instance_url
        self.hipaa_reviewer_tier = hipaa_reviewer_tier
        self.recipe_reviewer_tier = recipe_reviewer_tier

    # ------------------------------------------------------------------
    # intercept_code_search -- code-search query gate
    # ------------------------------------------------------------------

    def intercept_code_search(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Sourcegraph Cody code-search request.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-CODY-1)
          2. Secret scan on query
          3. PHI proximity check under HIPAA binding

        Args:
            request: Code search request dict with keys:
                     query, repos, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        query = str(request.get("query", ""))
        repos: list[str] = request.get("repos", [])
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-CODY-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cody code search request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Secret scan on query
        secret_match = _scan_for_secrets(query)
        if secret_match:
            return self._deny(
                agent_id,
                f"Code search blocked: secret pattern '{secret_match}' found in query. "
                "Do not embed credentials or tokens in code-search queries.",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(query)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "sourcegraph-cody",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Code search routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' found in query. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "cody:code-search-requested",
            "args": {
                "queryLength": len(query),
                "repos": repos,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_context_fetch -- repository context fetch gate
    # ------------------------------------------------------------------

    def intercept_context_fetch(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Sourcegraph Cody context fetch request.

        Cody's context-fetch retrieves files and symbols from the Sourcegraph
        index and injects them into the AI prompt window. Sensitive file paths
        (private keys, .env files, secrets directories) are blocked.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-CODY-1)
          2. Sensitive path detection

        Args:
            request: Context fetch request dict with keys:
                     filePaths, symbols, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        file_paths: list[str] = request.get("filePaths", [])
        symbols: list[str] = request.get("symbols", [])
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-CODY-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cody context fetch request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        sensitive_paths = [p for p in file_paths if _is_sensitive_path(p)]
        if sensitive_paths:
            sample = sensitive_paths[:3]
            suffix = ", ..." if len(sensitive_paths) > 3 else ""
            return self._deny(
                agent_id,
                f"Context fetch blocked: {len(sensitive_paths)} sensitive path(s) detected: "
                f"[{', '.join(sample)}{suffix}]. "
                "Sensitive files must not be injected into AI context windows.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "cody:context-fetch-requested",
            "args": {
                "filePathCount": len(file_paths),
                "symbolCount": len(symbols),
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_autocomplete -- inline autocomplete gate
    # ------------------------------------------------------------------

    def intercept_autocomplete(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Sourcegraph Cody autocomplete request.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-CODY-1)
          2. Deployment mode BAA check under HIPAA binding
          3. Secret scan on surrounding context
          4. PHI proximity check under HIPAA binding

        Args:
            request: Autocomplete request dict with keys:
                     surroundingContext, filePath, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        surrounding_context = str(request.get("surroundingContext", request.get("context", "")))
        file_path = str(request.get("filePath", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-CODY-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cody autocomplete request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Deployment mode BAA check under HIPAA (PT-ADAPT-CODY-3 analogue)
        if _is_hipaa_binding(pack_binding) and self.deployment_mode not in CODY_BAA_ELIGIBLE_MODES:
            return self._deny(
                agent_id,
                f"Cody autocomplete blocked: deployment mode '{self.deployment_mode}' is not "
                f"BAA-eligible for HIPAA pack binding {pack_binding}. "
                "Use 'self-hosted' or 'sourcegraph-cloud' with an active Sourcegraph BAA.",
                pack_binding=pack_binding,
            )

        # Secret scan
        secret_match = _scan_for_secrets(surrounding_context)
        if secret_match:
            return self._deny(
                agent_id,
                f"Autocomplete blocked: secret pattern '{secret_match}' in surrounding context "
                f"({file_path or 'unknown file'}).",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(surrounding_context)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "sourcegraph-cody",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Autocomplete routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' in context. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "sourcegraph-cody",
            "messageCount": 1,
            "packBinding": pack_binding,
            "filePath": file_path,
            "deploymentMode": self.deployment_mode,
        })

    # ------------------------------------------------------------------
    # intercept_chat -- pre/post-chat gate
    # ------------------------------------------------------------------

    def intercept_chat(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Sourcegraph Cody chat request.

        Handles both pre-chat (direction='pre') and post-chat (direction='post').

        Guards applied for 'pre' direction:
          1. Pack-binding primacy (PT-ADAPT-CODY-1)
          2. Deployment mode BAA check under HIPAA binding
          3. Secret scan on prompt
          4. PHI proximity check under HIPAA binding

        Guards applied for 'post' direction:
          1. Secret scan on response text

        Args:
            request: Chat request dict with keys:
                     promptText, responseText (post), direction, repoContext,
                     packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        direction = str(request.get("direction", "pre"))
        prompt_text = str(request.get("promptText", request.get("prompt", "")))
        response_text = str(request.get("responseText", request.get("response", "")))
        repo_context: list[str] = request.get("repoContext", [])
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-CODY-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cody chat request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        if direction == "post":
            secret_match = _scan_for_secrets(response_text)
            if secret_match:
                return self._deny(
                    agent_id,
                    f"Chat response blocked: secret pattern '{secret_match}' in response.",
                    pack_binding=pack_binding,
                )
            return self.emit_event("llmResult", {
                "agentId": agent_id,
                "model": "sourcegraph-cody",
                "responseText": response_text[:100],
                "packBinding": pack_binding,
            })

        # 'pre' direction

        # Deployment mode BAA check under HIPAA
        if _is_hipaa_binding(pack_binding) and self.deployment_mode not in CODY_BAA_ELIGIBLE_MODES:
            return self._deny(
                agent_id,
                f"Cody chat blocked: deployment mode '{self.deployment_mode}' is not "
                f"BAA-eligible for HIPAA pack binding {pack_binding}. "
                "Use 'self-hosted' or 'sourcegraph-cloud' with an active Sourcegraph BAA.",
                pack_binding=pack_binding,
            )

        # Secret scan
        secret_match = _scan_for_secrets(prompt_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Chat request blocked: secret pattern '{secret_match}' in prompt.",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(prompt_text)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "sourcegraph-cody",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Chat request routed for HIPAA review: PHI indicator "
                        f"'{phi_indicator}' found in prompt. "
                        f"Reviewer tier: {self.hipaa_reviewer_tier}."
                    ),
                })

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": "sourcegraph-cody",
            "messageCount": 1,
            "packBinding": pack_binding,
            "attachedRepos": len(repo_context),
            "deploymentMode": self.deployment_mode,
        })

    # ------------------------------------------------------------------
    # intercept_commit_message -- commit message generation gate
    # ------------------------------------------------------------------

    def intercept_commit_message(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Sourcegraph Cody commit message generation request.

        Classifies the unified diff for secret leaks BEFORE the generation
        prompt is sent to the backend.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-CODY-1)
          2. Diff secret scan (added lines only)

        Args:
            request: Commit message request dict with keys:
                     diff, branchName, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        diff = str(request.get("diff", ""))
        branch_name = str(request.get("branchName", "unknown"))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-CODY-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cody commit message request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # Diff secret scan
        finding = _scan_diff_for_secrets(diff)
        if finding:
            line_num, pattern_name = finding
            return self._deny(
                agent_id,
                f"Commit message generation blocked: secret pattern '{pattern_name}' "
                f"detected in diff at line {line_num}. "
                "Remove the secret from staged changes before generating a commit message. "
                f"Branch: {branch_name}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "cody:commit-message-requested",
            "args": {
                "branchName": branch_name,
                "diffPassed": True,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_recipe -- recipe execution gate
    # ------------------------------------------------------------------

    def intercept_recipe(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Sourcegraph Cody recipe execution request.

        Cody recipes ("Explain code", "Generate unit test", etc.) are
        structured AI workflows. Recipe arguments are scanned for secrets
        and PHI before execution is permitted.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-CODY-1)
          2. Secret scan on recipe args
          3. PHI proximity check on recipe args under HIPAA binding

        Args:
            request: Recipe request dict with keys:
                     recipeId, recipeArgs, targetFilePath, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        recipe_id = str(request.get("recipeId", request.get("recipe", "")))
        recipe_args = request.get("recipeArgs", {})
        target_file_path = str(request.get("targetFilePath", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-CODY-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cody recipe execution request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        recipe_args_text = str(recipe_args)

        # Secret scan on recipe args
        secret_match = _scan_for_secrets(recipe_args_text)
        if secret_match:
            return self._deny(
                agent_id,
                f"Recipe execution blocked: secret pattern '{secret_match}' found in recipe "
                f"args for recipe '{recipe_id}'. Remove credentials from recipe arguments.",
                pack_binding=pack_binding,
            )

        # PHI proximity check
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(recipe_args_text)
            if phi_indicator:
                return self.emit_event("llmCall", {
                    "agentId": agent_id,
                    "model": "sourcegraph-cody",
                    "messageCount": 1,
                    "packBinding": pack_binding,
                    "requiresApproval": True,
                    "reason": (
                        f"Recipe execution for '{recipe_id}' routed for HIPAA review: "
                        f"PHI indicator '{phi_indicator}' in recipe arguments. "
                        f"Reviewer tier: {self.recipe_reviewer_tier}."
                    ),
                })

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "cody:recipe-execution-requested",
            "args": {
                "recipeId": recipe_id,
                "targetFilePath": target_file_path,
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_embeddings_index -- embeddings index gate (PT-ADAPT-CODY-4)
    # ------------------------------------------------------------------

    def intercept_embeddings_index(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Sourcegraph Cody embeddings index build request (PT-ADAPT-CODY-4).

        Embeddings indexing is an enterprise-only feature. It is blocked in
        'free-pro' deployment mode regardless of pack binding.

        Under HIPAA binding, 'sourcegraph-cloud' requires an active BAA;
        'self-hosted' is always eligible. 'free-pro' is never eligible.

        Guards applied:
          1. Pack-binding primacy (PT-ADAPT-CODY-1)
          2. Deployment mode check: free-pro => always denied (PT-ADAPT-CODY-4)
          3. BAA eligibility check under HIPAA binding

        Args:
            request: Embeddings index request dict with keys:
                     repos, packBinding, agentId, etc.

        Returns:
            GovernanceDecision.
        """
        repos: list[str] = request.get("repos", [])
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # PT-ADAPT-CODY-1: pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cody embeddings index request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
            )

        # PT-ADAPT-CODY-4: embeddings index blocked in free-pro mode.
        if self.deployment_mode == "free-pro":
            return self._deny(
                agent_id,
                f"Embeddings index operation blocked: CodyGovernedClient is configured in "
                f"'free-pro' mode. "
                "Embeddings indexing is only available in 'sourcegraph-cloud' and "
                "'self-hosted' deployment modes. "
                "Upgrade to a Sourcegraph Enterprise instance to use this feature.",
                pack_binding=pack_binding,
            )

        # BAA eligibility check under HIPAA binding
        if _is_hipaa_binding(pack_binding) and self.deployment_mode not in CODY_BAA_ELIGIBLE_MODES:
            return self._deny(
                agent_id,
                f"Embeddings index blocked: deployment mode '{self.deployment_mode}' is not "
                f"BAA-eligible for HIPAA pack binding {pack_binding}. "
                "Use 'self-hosted' or 'sourcegraph-cloud' with an active Sourcegraph BAA.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "cody:embeddings-index-requested",
            "args": {
                "repos": repos,
                "repoCount": len(repos),
                "deploymentMode": self.deployment_mode,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown CodyGovernedClient event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] CodyGovernedClient output classifier: possible secret in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] CodyGovernedClient output exfiltration scanner: possible "
                    f"secret/PHI in LLM response (agent: {agent_id}).",
                    file=sys.stderr,
                )

        # Inject deployment mode metadata and delegate to base
        enriched = {"deploymentMode": self.deployment_mode, **payload}
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload and forward it as a canonical governance event."""
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError(
                "CodyGovernedClient webhook payload missing required field: 'eventType'"
            )
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError(
                "CodyGovernedClient webhook payload missing required field: 'agentId'"
            )
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "CodyPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return CodyPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# CodyPolicyBridge
# ---------------------------------------------------------------------------

class CodyPolicyBridge:
    """Bridge for Python-hosted policy participation in the Cody governance loop."""

    def __init__(
        self,
        adapter: CodyGovernedClient,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:
                import logging as _logging
                _logging.getLogger(__name__).warning(
                    "Governance audit operation failed: %s", exc
                )

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
