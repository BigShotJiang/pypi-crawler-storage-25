"""OpenClaw integration for Connexum governance.

This framework is TypeScript-native. This integration is a REST shim so a
Python governance policy can sit in front of a Node orchestrator. See
`src/orchestrator-adapters/openclaw.ts` for the primary adapter.

OpenClaw is a messaging-platform-first agent runner (Telegram, WhatsApp, Slack,
Discord, Signal). This Python shim exposes the canonical six-hook governance
event surface and adds OpenClaw-specific surfaces: persistent memory governance
and outbound messaging platform egress checks.

Architecture:
  The OpenClaw TS runtime calls this Python shim via HTTP when it needs a
  governance decision. The shim validates the inbound JSON payload, runs
  local guard checks (pack-binding primacy, PHI scan, workspace allowlist,
  memory PHI gating), and forwards a canonical event to the governance REST API.

  Python-hosted policy engine participation:
    adapter = OpenClawGovernance(client=gov, ...)
    adapter.emit_event("agentStart", {...})        # forward canonical event
    adapter.wrap_webhook(request_body)             # validate + forward inbound
    adapter.policy_bridge(pack, callback)          # Python policy participation

Canonical event shape for each hook:
  agentStart      -> {"eventType": "agentStart",     "agentId": ..., "packBinding": [...], ...}
  toolCall        -> {"eventType": "toolCall",        "agentId": ..., "toolName": ..., ...}
  toolResult      -> {"eventType": "toolResult",      "agentId": ..., "toolName": ..., ...}
  llmCall         -> {"eventType": "llmCall",         "agentId": ..., "model": ..., ...}
  llmResult       -> {"eventType": "llmResult",       "agentId": ..., "model": ..., ...}
  agentEnd        -> {"eventType": "agentEnd",        "agentId": ..., "success": ..., ...}
  memoryWrite     -> {"eventType": "memoryWrite",     "agentId": ..., "key": ..., ...}
  memoryRead      -> {"eventType": "memoryRead",      "agentId": ..., "key": ..., ...}
  outboundMessage -> {"eventType": "outboundMessage", "agentId": ..., "platform": ..., ...}

ARCHITECTURAL NOTE:
  OpenClaw is designed for personal/SMB use cases. This shim governs any OpenClaw
  deployment that opts in by wrapping its action + memory layer. It does NOT turn
  OpenClaw into a multi-tenant compliance runtime. Regulated enterprise deployments
  must use this adapter AND a hardened runtime configuration with BAA confirmation
  on each messaging platform.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.openclaw import OpenClawGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = OpenClawGovernance(
        client=gov,
        registered_agents=["my-openclaw-agent"],
        approved_models=["gpt-4o-mini", "claude-haiku-4-5"],
        sanctioned_workspaces={
            "Slack": {"T01234ABCD"},
            "Discord": {"987654321012345678"},
        },
        block_phi_memory_write=True,
    )

    # Forward events from the TS runtime:
    adapter.emit_event("agentStart", {
        "agentId": "my-openclaw-agent",
        "packBinding": ["hipaa"],
        "model": "gpt-4o-mini",
        "platform": "Slack",
    })
"""

from __future__ import annotations

import hashlib
import hmac
import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------

class OpenClawMemoryPhiError(RuntimeError):
    """Raised when a memory write contains PHI under HIPAA binding."""

    def __init__(self, agent_id: str, key: str):
        super().__init__(
            f'OpenClaw agent "{agent_id}" attempted to write PHI to memory key "{key}" '
            "under an active HIPAA pack binding. Memory write blocked at ingress gate. Fail closed."
        )
        self.agent_id = agent_id
        self.key = key


class OpenClawUnsanctionedWorkspaceError(RuntimeError):
    """Raised when an outbound message targets an unsanctioned workspace."""

    def __init__(self, agent_id: str, platform: str, workspace_id: str):
        super().__init__(
            f'OpenClaw agent "{agent_id}" attempted to send to {platform} workspace '
            f'"{workspace_id}" which is NOT in the sanctioned workspace allowlist. '
            "Outbound message blocked at egress guard."
        )
        self.agent_id = agent_id
        self.platform = platform
        self.workspace_id = workspace_id


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)

_REGULATED_PACKS = {"hipaa", "hitech", "gdpr", "fcra", "ccpa"}


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


def _has_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(p.lower() in ("hipaa", "hitech") for p in pack_binding)


def _has_regulated_binding(pack_binding: list[str]) -> bool:
    return any(p.lower() in _REGULATED_PACKS for p in pack_binding)


def _pseudonymise(value: str, key: str) -> str:
    """HMAC-SHA256 pseudonymisation."""
    return hmac.new(key.encode(), value.encode(), hashlib.sha256).hexdigest()


# ---------------------------------------------------------------------------
# Canonical event type set
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
    # OpenClaw-specific
    "memoryWrite",
    "memoryRead",
    "outboundMessage",
})

_VALID_PLATFORMS = frozenset({
    "Telegram", "WhatsApp", "Slack", "Discord", "Signal", "Email", "SMS", "UNKNOWN",
})


# ---------------------------------------------------------------------------
# OpenClawGovernance
# ---------------------------------------------------------------------------

class OpenClawGovernance(BaseGovernanceIntegration):
    """REST-client shim for OpenClaw governance.

    OpenClaw is TypeScript-native. This Python shim participates in the
    decision loop by:
      1. Receiving lifecycle events from the OpenClaw TS runtime via HTTP
         (wrap_webhook)
      2. Running local guard checks (PHI scan, workspace allowlist, memory gating)
      3. Forwarding canonical events to the governance REST API (emit_event)
      4. Providing policy_bridge() for Python policy participation
    """

    _FRAMEWORK_NAME = "openclaw"
    _LAYER_NAME = "openclaw-rest-shim"
    # memoryRead is exempt: cross-session pseudonymisation fires regardless of pack
    _EXEMPT_EVENT_TYPES: frozenset[str] = frozenset({"agentEnd", "memoryRead"})

    def __init__(
        self,
        client: GovernanceClient,
        registered_agents: Optional[list[str]] = None,
        approved_models: Optional[list[str]] = None,
        sensitive_tools: Optional[list[str]] = None,
        sensitive_arg_keys: Optional[list[str]] = None,
        sanctioned_workspaces: Optional[dict[str, set]] = None,
        block_phi_memory_write: bool = True,
        pseudonymise_cross_session_reads: bool = True,
        pseudonymisation_key: Optional[str] = None,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            registered_agents: Agent IDs registered under governance.
            approved_models: LLM model IDs approved for use.
            sensitive_tools: Tool names requiring reviewer approval.
            sensitive_arg_keys: Argument keys to scan for PHI.
            sanctioned_workspaces: Map of platform -> set of allowed workspace IDs.
                                   If platform is present but workspace not in set, blocked.
                                   If platform not present, allowed (no policy configured).
            block_phi_memory_write: Block PHI memory writes under HIPAA binding.
            pseudonymise_cross_session_reads: Pseudonymise keys in cross-session reads
                                              under regulated pack bindings.
            pseudonymisation_key: HMAC key for pseudonymisation. If not provided, a
                                  session-scoped random key is used.
        """
        super().__init__(client)
        self.registered_agents = registered_agents or []
        self.approved_models = approved_models or []
        self.sensitive_tools = sensitive_tools or []
        self.sensitive_arg_keys = sensitive_arg_keys or ["query", "content", "message", "body"]
        self.sanctioned_workspaces: dict[str, set] = sanctioned_workspaces or {}
        self.block_phi_memory_write = block_phi_memory_write
        self.pseudonymise_cross_session_reads = pseudonymise_cross_session_reads
        self._pseudo_key = pseudonymisation_key or uuid.uuid4().hex

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API.

        Runs local guard checks before forwarding:
          - Pack-binding primacy
          - Provider compliance (llmCall)
          - PHI scan (toolCall args, toolResult, llmResult, outboundMessage content)
          - Workspace sanctioning (outboundMessage)
          - Memory PHI gating (memoryWrite under HIPAA)
          - Cross-session read pseudonymisation (memoryRead)

        Args:
            event_type: Canonical event type.
            payload: Event-specific payload. Must include "agentId".

        Returns:
            GovernanceDecision from the governance API.
        """
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown OpenClaw event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", "unknown")
        pack_binding: list[str] = payload.get("packBinding", [])

        # Provider compliance for llmCall
        if event_type == "llmCall":
            model = payload.get("model", "")
            if self.approved_models and model not in self.approved_models:
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f'OpenClaw LLM model "{model}" is not on the approved provider list. '
                    f"Approved: {', '.join(self.approved_models)}"
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # PHI scan on tool call args (G5/G7 egress guard)
        if event_type == "toolCall":
            args = payload.get("args", {})
            exfil_key = self._scan_args(args)
            if exfil_key:
                from connexum_governance.models import GovernanceDecision, DecisionType
                tool_name = payload.get("toolName", "unknown")
                reason = (
                    f'Possible data exfiltration in OpenClaw tool "{tool_name}" args '
                    f'(key: "{exfil_key}"). Blocked at G5/G7 egress guard.'
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _contains_phi(result_text):
                print(
                    f"[GOVERNANCE] OpenClaw output classifier: possible PHI in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _contains_phi(response_text):
                print(
                    f"[GOVERNANCE] OpenClaw output exfiltration scanner: possible PHI in "
                    f'LLM response (model: {payload.get("model", "unknown")}, agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Memory write PHI gating (PT-ADAPT-OPENCLAW-1)
        if event_type == "memoryWrite":
            value = str(payload.get("value", ""))
            key = payload.get("key", "unknown")
            has_phi = _contains_phi(value)
            hipaa_active = _has_hipaa_binding(pack_binding)

            if has_phi and hipaa_active and self.block_phi_memory_write:
                raise OpenClawMemoryPhiError(agent_id, key)

            if has_phi and not hipaa_active:
                print(
                    f"[GOVERNANCE] OpenClaw memory write PHI warning: key \"{key}\" "
                    f"contains PHI (agent: {agent_id}). No HIPAA binding -- surfaced to compliance.",
                    file=sys.stderr,
                )

        # Cross-session memory read pseudonymisation (PT-ADAPT-OPENCLAW-3)
        if event_type == "memoryRead":
            key = payload.get("key", "")
            session_id = payload.get("sessionId")
            is_cross_session = session_id is not None
            is_regulated = _has_regulated_binding(pack_binding) if pack_binding else False

            if is_cross_session and is_regulated and self.pseudonymise_cross_session_reads:
                pseudo_key = _pseudonymise(key, self._pseudo_key)
                payload = {**payload, "key": pseudo_key, "keyPseudonymised": True}

        # Outbound message workspace sanctioning (PT-ADAPT-OPENCLAW-2)
        if event_type == "outboundMessage":
            platform = payload.get("platform", "UNKNOWN")
            workspace_id = payload.get("workspaceId") or payload.get("recipientId", "")
            content = str(payload.get("content", ""))

            # PHI scan on outbound content
            if _contains_phi(content):
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f'OpenClaw outbound message to {platform} contains PHI/PAN. '
                    "Blocked at egress guard."
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

            # Workspace sanctioning
            if platform in self.sanctioned_workspaces:
                sanctioned_set = self.sanctioned_workspaces[platform]
                if workspace_id not in sanctioned_set:
                    raise OpenClawUnsanctionedWorkspaceError(agent_id, platform, workspace_id)

        return super().emit_event(event_type, payload)

    # ------------------------------------------------------------------
    # wrap_webhook -- validate + forward inbound webhook from OpenClaw TS
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload from the OpenClaw TS runtime and forward it.

        Validates required fields, runs guard checks, and forwards to the
        governance REST API.

        Args:
            request_body: Parsed JSON body from the inbound webhook.

        Returns:
            GovernanceDecision to serialise and return as the HTTP response.

        Raises:
            ValueError: Required fields missing.
        """
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError("OpenClaw webhook payload missing required field: 'eventType'")

        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError("OpenClaw webhook payload missing required field: 'agentId'")

        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge -- Python policy participation
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "OpenClawPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation.

        Args:
            pack_binding: Pack binding that governs decisions via this bridge.
            decision_callback: Callable(event_type, payload) -> GovernanceDecision or None.

        Returns:
            OpenClawPolicyBridge instance.
        """
        return OpenClawPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(self, agent_id: str, pack_binding: list[str], model: str,
                    platform: str = "UNKNOWN", **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        return self.emit_event("agentStart", {
            "agentId": agent_id, "packBinding": pack_binding,
            "model": model, "platform": platform, **kwargs
        })

    def tool_call(self, agent_id: str, tool_name: str, args: dict[str, Any],
                  pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pack_binding or [], **kwargs
        })

    def tool_result(self, agent_id: str, tool_name: str, result: Any,
                    success: bool = True, pack_binding: Optional[list[str]] = None,
                    **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pack_binding or [], **kwargs
        })

    def llm_call(self, agent_id: str, model: str, messages: list[dict[str, Any]],
                 pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pack_binding or [], **kwargs
        })

    def llm_result(self, agent_id: str, model: str, response_text: str,
                   pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pack_binding or [], **kwargs
        })

    def agent_end(self, agent_id: str, success: bool,
                  pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pack_binding or [], **kwargs
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _scan_args(self, args: dict[str, Any]) -> Optional[str]:
        """Scan tool arguments for PHI patterns on sensitive keys."""
        for key in self.sensitive_arg_keys:
            value = args.get(key)
            if isinstance(value, str) and _contains_phi(value):
                return key
        return None


# ---------------------------------------------------------------------------
# OpenClawPolicyBridge
# ---------------------------------------------------------------------------

class OpenClawPolicyBridge:
    """Bridge for Python-hosted policy participation in the OpenClaw decision loop."""

    def __init__(
        self,
        adapter: OpenClawGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
