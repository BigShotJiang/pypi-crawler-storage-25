"""Cursor IDE governance integration.

Cursor has no per-tool hook API equivalent to Claude Code PreToolUse.
The Python shim ships in three modes (selectable by integration_mode):

  'filesystem-sidecar'  -- Active enforcement floor; guards destructive
                           commands and sensitive path writes. Default.
  'mcp-server'          -- Cursor connects to a governance MCP server.
                           Deferred: raises IdeUnsupportedError.
  'vscode-extension'    -- Governance ships as a VS Code extension Cursor
                           inherits. Deferred: raises IdeUnsupportedError.

The default mode is 'filesystem-sidecar' (safest floor, does not depend
on Cursor-specific API stability).

Architecture:
  The primary adapter is TypeScript-native (`src/ide-adapters/cursor.ts`).
  This Python shim lets a Python-hosted governance policy server participate
  in the Cursor decision loop via HTTP.

  Two principal surfaces:
    intercept_composer(request)       -- gate a Composer (chat/agentic) request
    intercept_tab_completion(request) -- gate a tab-completion request

  User identity: resolved from cursor composer session ID.
  Provider: Anthropic or OpenAI (Cursor supports both).
  Cursor rules file reference: governance defers to rules specified in
    .cursorrules / cursor.rules files at project root.

TESTED_API_VERSION: Cursor 0.50+ (filesystem-sidecar mode).

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.cursor import CursorGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = CursorGovernance(
        client=gov,
        agent_name="cursor-agent",
        pack_binding=["soc2"],
        approved_providers=["anthropic", "openai"],
    )

    # Gate a Cursor Composer (agentic) request:
    decision = adapter.intercept_composer({
        "model": "claude-opus-4",
        "prompt": "Refactor this class",
        "composerSessionId": "sess-abc",
        "packBinding": ["soc2"],
    })

    # Gate a Cursor tab-completion request:
    decision = adapter.intercept_tab_completion({
        "model": "gpt-4o",
        "prefix": "def process(",
        "filePath": "/workspace/api.py",
        "packBinding": ["soc2"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Literal, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Cursor integration mode type
CursorIntegrationMode = Literal["filesystem-sidecar", "mcp-server", "vscode-extension"]

# Default integration mode (safest floor)
DEFAULT_INTEGRATION_MODE: CursorIntegrationMode = "filesystem-sidecar"

# Default approved providers for Cursor
_DEFAULT_APPROVED_PROVIDERS = ["anthropic", "openai"]

# Cursor tool name -> canonical governance tool name
_CURSOR_TOOL_MAP: dict[str, str] = {
    "edit_file": "Edit",
    "run_terminal": "Bash",
    "search": "Grep",
    "read_file": "Read",
}

# ---------------------------------------------------------------------------
# Destructive command patterns (G4 guard)
# ---------------------------------------------------------------------------

_DESTRUCTIVE_PATTERNS: list[re.Pattern] = [
    re.compile(r"\brm\s+(-[rR]f?|--recursive)\b"),
    re.compile(r"\bgit\s+push\s+--force\b"),
    re.compile(r"\bgit\s+reset\s+--hard\b"),
    re.compile(r"\bgit\s+clean\s+-f"),
    re.compile(r"\bdrop\s+(table|database)\b", re.IGNORECASE),
    re.compile(r"\btruncate\s+table\b", re.IGNORECASE),
    re.compile(r"\bnpm\s+publish\b"),
    re.compile(r"\bcurl\b.*\|\s*(bash|sh)\b"),
]

# ---------------------------------------------------------------------------
# Sensitive path patterns (G5 guard)
# ---------------------------------------------------------------------------

_SENSITIVE_PATH_PATTERNS: list[re.Pattern] = [
    re.compile(r"^/etc/"),
    re.compile(r"^/root/"),
    re.compile(r"^/?\.env$"),
    re.compile(r"\.env\."),
    re.compile(r"secrets?/", re.IGNORECASE),
    re.compile(r"private_?key", re.IGNORECASE),
    re.compile(r"\.pem$", re.IGNORECASE),
    re.compile(r"\.key$", re.IGNORECASE),
]

# ---------------------------------------------------------------------------
# Secret patterns (G7 / output classifier)
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",          re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",              re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",       re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",          re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",      re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",  re.compile(r"(SECRET|PASSWORD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Database URL with creds", re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("Bearer token",            re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bsocial[_\s]?security\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# IdeUnsupportedError
# ---------------------------------------------------------------------------

class IdeUnsupportedError(Exception):
    """Raised when a Cursor integration mode that is not yet implemented is invoked."""
    pass


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_for_phi(text: str) -> Optional[str]:
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _is_destructive_command(command: str, patterns: list[re.Pattern]) -> Optional[re.Pattern]:
    for pattern in patterns:
        if pattern.search(command):
            return pattern
    return None


def _is_sensitive_path(path: str) -> bool:
    return any(p.search(path) for p in _SENSITIVE_PATH_PATTERNS)


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(p.lower() in ("hipaa", "hitech") for p in pack_binding)


def _infer_provider(model: str) -> str:
    m = model.lower()
    if m.startswith("gpt-") or m.startswith("o1") or m.startswith("o3"):
        return "openai"
    if m.startswith("claude"):
        return "anthropic"
    if m.startswith("gemini"):
        return "google"
    if m.startswith("llama") or m.startswith("mistral") or m.startswith("codellama"):
        return "ollama"
    return ""


# ---------------------------------------------------------------------------
# CursorGovernance
# ---------------------------------------------------------------------------

class CursorGovernance(BaseGovernanceIntegration):
    """REST-client shim for Cursor IDE governance.

    Cursor is TypeScript-native. This Python shim participates in the
    decision loop by:
      1. Gating Composer (agentic) requests (intercept_composer)
      2. Gating tab-completion requests (intercept_tab_completion)
      3. Enforcing destructive command and sensitive path guards
      4. Providing policy_bridge() for Python policy participation

    Integration modes:
      'filesystem-sidecar' (default) -- active enforcement floor
      'mcp-server'                   -- deferred, raises IdeUnsupportedError
      'vscode-extension'             -- deferred, raises IdeUnsupportedError

    Providers: Anthropic and OpenAI (both supported by Cursor).
    """

    _FRAMEWORK_NAME = "cursor"
    _LAYER_NAME = "cursor-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        approved_providers: Optional[list[str]] = None,
        integration_mode: CursorIntegrationMode = DEFAULT_INTEGRATION_MODE,
        extra_blocked_commands: Optional[list[re.Pattern]] = None,
        hipaa_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            approved_providers: Provider IDs approved for use.
            integration_mode: Cursor integration mode (default: filesystem-sidecar).
            extra_blocked_commands: Additional destructive command patterns to block.
            hipaa_reviewer_tier: Reviewer tier for HIPAA-bound violations.
        """
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.approved_providers = approved_providers or list(_DEFAULT_APPROVED_PROVIDERS)
        self.integration_mode = integration_mode
        self.hipaa_reviewer_tier = hipaa_reviewer_tier

        # Merge default destructive patterns with custom ones
        self._blocked_patterns = list(_DESTRUCTIVE_PATTERNS)
        if extra_blocked_commands:
            self._blocked_patterns.extend(extra_blocked_commands)

    # ------------------------------------------------------------------
    # intercept_composer -- gate Cursor Composer (agentic/chat) requests
    # ------------------------------------------------------------------

    def intercept_composer(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Cursor Composer (agentic or chat) request.

        Maps to the Cursor Composer session surface. In filesystem-sidecar
        mode, applies destructive command guard if a tool invocation is
        embedded in the request.

        Guards applied:
          1. Pack-binding primacy
          2. Integration mode check (deferred modes raise IdeUnsupportedError)
          3. Destructive command guard (if tool = run_terminal/Bash)
          4. Sensitive path guard (if file path in request)
          5. PHI proximity check under HIPAA
          6. Provider compliance

        Args:
            request: Composer request dict with keys:
                     model, prompt (or message), composerSessionId, tool,
                     command, filePath, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        if self.integration_mode == "mcp-server":
            raise IdeUnsupportedError(
                "Cursor mcp-server mode is not yet implemented. "
                "Use 'filesystem-sidecar' mode or contact support. "
                "Full MCP server mode implementation is pending empirical "
                "validation against Cursor 0.50+."
            )
        if self.integration_mode == "vscode-extension":
            raise IdeUnsupportedError(
                "Cursor vscode-extension mode is not yet implemented. "
                "Use 'filesystem-sidecar' mode or contact support. "
                "VS Code extension implementation is pending validation "
                "of the Cursor extension host API surface."
            )

        model = str(request.get("model", ""))
        prompt = str(request.get("prompt", request.get("message", "")))
        tool = str(request.get("tool", ""))
        command = str(request.get("command", ""))
        file_path = str(request.get("filePath", request.get("file_path", request.get("path", ""))))
        agent_id = request.get("agentId", request.get("composerSessionId", self.agent_name))
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cursor Composer request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
                pack_binding=pack_binding,
            )

        # Map cursor tool name to canonical name
        canonical_tool = _CURSOR_TOOL_MAP.get(tool, tool)

        # Destructive command guard (G4)
        if canonical_tool == "Bash" and command:
            matched = _is_destructive_command(command, self._blocked_patterns)
            if matched:
                return self._deny(
                    agent_id,
                    f"Destructive command blocked by Cursor governance adapter "
                    f"(filesystem-sidecar). Pattern: {matched.pattern}",
                    pack_binding=pack_binding,
                )

        # Sensitive path guard (G5)
        if canonical_tool in ("Edit", "Write", "Read") and file_path:
            if _is_sensitive_path(file_path):
                return self._deny(
                    agent_id,
                    f"Sensitive path blocked by CursorGovernance: {file_path}",
                    pack_binding=pack_binding,
                )

        # PHI proximity check under HIPAA
        if _is_hipaa_binding(pack_binding) and prompt:
            phi_indicator = _scan_for_phi(prompt)
            if phi_indicator:
                return self._deny(
                    agent_id,
                    f"Cursor Composer request blocked under HIPAA: PHI indicator "
                    f'"{phi_indicator}" found in prompt. '
                    f"Reviewer tier: {self.hipaa_reviewer_tier}.",
                    pack_binding=pack_binding,
                )

        # Provider compliance
        provider = _infer_provider(model)
        if self.approved_providers and provider and provider not in self.approved_providers:
            return self._deny(
                agent_id,
                f'Cursor provider "{provider}" (model: "{model}") is not on the '
                f"approved provider list. Approved: {', '.join(self.approved_providers)}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": model,
            "messageCount": 1,
            "packBinding": pack_binding,
            "tool": canonical_tool,
            "integrationMode": self.integration_mode,
            "composerRequest": True,
        })

    # ------------------------------------------------------------------
    # intercept_tab_completion -- gate tab-completion requests
    # ------------------------------------------------------------------

    def intercept_tab_completion(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a Cursor tab-completion request.

        Maps to the Cursor inline completion surface.

        Guards applied:
          1. Pack-binding primacy
          2. Integration mode check
          3. Sensitive path guard (on filePath)
          4. Provider compliance

        Args:
            request: Tab-completion request dict with keys:
                     model, prefix (current line), filePath, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        if self.integration_mode == "mcp-server":
            raise IdeUnsupportedError(
                "Cursor mcp-server mode is not yet implemented. "
                "Use 'filesystem-sidecar' mode."
            )
        if self.integration_mode == "vscode-extension":
            raise IdeUnsupportedError(
                "Cursor vscode-extension mode is not yet implemented. "
                "Use 'filesystem-sidecar' mode."
            )

        model = str(request.get("model", ""))
        file_path = str(request.get("filePath", request.get("file_path", "")))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Cursor tab-completion request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
                pack_binding=pack_binding,
            )

        # Sensitive path guard
        if file_path and _is_sensitive_path(file_path):
            return self._deny(
                agent_id,
                f"Sensitive path blocked by CursorGovernance tab-completion: {file_path}",
                pack_binding=pack_binding,
            )

        # Provider compliance
        provider = _infer_provider(model)
        if self.approved_providers and provider and provider not in self.approved_providers:
            return self._deny(
                agent_id,
                f'Cursor tab-completion provider "{provider}" (model: "{model}") is not on '
                f"the approved provider list. Approved: {', '.join(self.approved_providers)}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": model,
            "messageCount": 0,
            "packBinding": pack_binding,
            "filePath": file_path,
            "tabCompletion": True,
            "integrationMode": self.integration_mode,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API.

        Runs integration-specific guards then delegates pack-binding primacy,
        REST API dispatch, and audit tracking to super().emit_event() (M2).

        Args:
            event_type: Canonical event type.
            payload: Event payload. Must include "agentId".

        Returns:
            GovernanceDecision from the governance API.
        """
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown Cursor event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)

        # Output classifier for tool results (secret scan)
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] Cursor output classifier: possible secret in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] Cursor output exfiltration scanner: possible "
                    f'secret/PHI in LLM response (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Inject integration mode into payload for REST context metadata
        enriched = {"integrationMode": self.integration_mode, **payload}

        # Delegate pack-binding primacy + REST dispatch + audit tracking to base
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload and forward it as a canonical governance event.

        Args:
            request_body: Parsed JSON body with "eventType" and "agentId".

        Returns:
            GovernanceDecision.
        """
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError("Cursor webhook payload missing required field: 'eventType'")
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError("Cursor webhook payload missing required field: 'agentId'")
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "CursorPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return CursorPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# CursorPolicyBridge
# ---------------------------------------------------------------------------

class CursorPolicyBridge:
    """Bridge for Python-hosted policy participation in the Cursor loop."""

    def __init__(
        self,
        adapter: CursorGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
