"""Aider terminal AI pair-programmer governance integration.

Aider (https://aider.chat) is a terminal-based AI pair programmer with full
project access: it reads, edits and creates files, runs git commands, executes
shell commands via ``/run``, and can auto-commit. This adapter governs every
programmable surface Aider exposes.

Unlike in-IDE adapters, Aider operates on the raw filesystem and git working
tree. The governance challenges are distinct:

  - Shell commands (``/run``) are arbitrary -- fork bombs, curl-pipe-sh, and
    ``rm -rf /`` are live threats, not hypotheticals.
  - File context (``/add``, repo-map) sends file contents to an LLM provider.
    If the added file contains a ``.env`` or private key the secret is now
    transmitted to an external party.
  - Auto-commit writes to git history with no human gate unless governance
    intervenes.
  - Voice input (transcription) may contain PII; CI deployments must never
    accept interactive input.
  - CI mode (``aider-ci-mode``) removes the human-in-the-loop entirely;
    stricter rules apply unconditionally.

Deployment modes:
  aider-cli-individual  -- single developer; interactive; moderate defaults.
  aider-cli-team        -- shared dev environment; secret_scan_files forced on.
  aider-ci-mode         -- CI/CD pipeline; no interactive surfaces; shell
                           commands always denied; voice always denied;
                           auto-commit requires explicit opt-in.

Hook surfaces (10 intercept_* methods):
  intercept_chat(request)
  intercept_file_edit(request)
  intercept_file_add(request)
  intercept_git_commit(request)
  intercept_git_diff(request)
  intercept_shell_command(request)
  intercept_test_run(request)
  intercept_lint_run(request)
  intercept_voice_input(request)
  intercept_repomap_build(request)

Pen-test IDs:
  PT-ADAPT-AIDER-1: empty packBinding denied at every intercept call
  PT-ADAPT-AIDER-2: secrets in scanned content never echoed in audit entries
  PT-ADAPT-AIDER-3: malformed config raises ValueError at construction
                    (invalid mode, negative cap, secret_scan_files=False in team/CI)
  PT-ADAPT-AIDER-4: CI mode with allow_shell_commands=True rejected at construction
  PT-ADAPT-AIDER-5: dangerous shell patterns denied with explicit reason codes
                    regardless of allowed_shell_prefixes
  PT-ADAPT-AIDER-6: file add with .env-like content denied with
                    aider-file-add-secret-detected even if user added it manually

Spec: P3-SUB-IDE-12

Usage::

    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.aider import AiderGovernedClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    client = AiderGovernedClient(
        client=gov,
        agent_name="aider-agent",
        pack_binding=["soc2"],
        deployment_mode="aider-cli-individual",
        allow_shell_commands=True,
        allowed_shell_prefixes=["npm ", "npx "],
    )

    decision = client.intercept_shell_command({
        "command": "npm test",
        "packBinding": ["soc2"],
    })
"""

from __future__ import annotations

import re
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Valid deployment modes
# ---------------------------------------------------------------------------

AIDER_VALID_DEPLOYMENT_MODES: tuple[str, ...] = (
    "aider-cli-individual",
    "aider-cli-team",
    "aider-ci-mode",
)

# ---------------------------------------------------------------------------
# Dangerous shell patterns (always denied -- no bypass)
# ---------------------------------------------------------------------------

_DANGEROUS_SHELL_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("rm-rf-root",     re.compile(r"\brm\s+(-[rRfF]{2}|--recursive\s+--force|--force\s+--recursive)\s+/\s*$")),
    ("rm-rf-slash",    re.compile(r"\brm\s+-[rRfF]{2}\s+/[^/]")),
    ("fork-bomb",      re.compile(r":\s*\(\s*\)\s*\{\s*:\s*\|")),
    ("curl-pipe-sh",   re.compile(r"\bcurl\b[^|]*\|\s*(bash|sh)\b")),
    ("wget-pipe-sh",   re.compile(r"\bwget\b[^|]*\|\s*(bash|sh)\b")),
    ("sudo-rm",        re.compile(r"\bsudo\s+rm\b")),
    ("dev-sda",        re.compile(r">\s*/dev/(sda|hda|nvme|disk)")),
    ("dd-if",          re.compile(r"\bdd\s+if=")),
    ("chmod-777",      re.compile(r"\bchmod\s+(0?777|a\+rwx)\b")),
    ("git-force-push", re.compile(r"\bgit\s+push\s+.*--force")),
    ("git-reset-hard", re.compile(r"\bgit\s+reset\s+--hard")),
    ("kill-nine-1",    re.compile(r"\bkill\s+-9\s+1\b")),
    ("rm-rf-home",     re.compile(r"\brm\s+-[rRfF]{2}\s+(~|\$HOME)\s*$")),
]

# ---------------------------------------------------------------------------
# Secret scan patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",           re.compile(r"AKIA[0-9A-Z]{16}")),
    ("AWS secret key",           re.compile(r"aws_secret_access_key\s*=\s*\S{20,}", re.IGNORECASE)),
    ("GitHub PAT",               re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",        re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",           re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Generic secret env var",   re.compile(r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY|ACCESS_TOKEN)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Bearer token",             re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
    ("Database URL with creds",  re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("env file marker",          re.compile(r"^(export\s+)?(SECRET|PASSWORD|PASSWD|API_KEY|TOKEN|KEY)\w*=\S", re.IGNORECASE | re.MULTILINE)),
]

# ---------------------------------------------------------------------------
# Sensitive repo-map path markers
# ---------------------------------------------------------------------------

_SENSITIVE_REPOMAP_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("dotenv-file",      re.compile(r"(^|\s|/|\\)\.env(\s|$|\.)", re.MULTILINE)),
    ("aws-creds",        re.compile(r"\.aws[/\\](credentials|config)")),
    ("ssh-private-key",  re.compile(r"(^|\s|/)(id_rsa|id_ed25519|id_ecdsa|id_dsa)(\s|$)", re.MULTILINE)),
    ("keystore",         re.compile(r"\.(jks|p12|pfx|keystore)(\s|$)")),
    ("gcloud-creds",     re.compile(r"application_default_credentials\.json")),
    ("kubeconfig",       re.compile(r"(^|\s|/)\.?kubeconfig(\s|$)", re.MULTILINE)),
]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


def _scan_for_secrets(text: str) -> Optional[str]:
    """Return name of first matched secret pattern, or None."""
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _sanitize_secret_from_audit(text: str) -> str:
    """Replace any matched secret values with [REDACTED]."""
    out = text
    for _name, pattern in _SECRET_PATTERNS:
        out = pattern.sub("[REDACTED]", out)
    return out


def _split_shell_separators(command: str) -> list[str]:
    """Split a shell command on common separator tokens for per-segment scanning."""
    segments = re.split(r";|&&|\|\||\$\(|`", command)
    return [s.rstrip(")").strip() for s in segments if s.strip()]


def _check_dangerous_shell(command: str) -> Optional[str]:
    """Return name of first dangerous pattern matched, or None."""
    segments = _split_shell_separators(command)
    for segment in segments:
        for name, pattern in _DANGEROUS_SHELL_PATTERNS:
            if pattern.search(segment):
                return name
    return None


def _is_path_allowed(file_path: str, allowed_paths: list[str]) -> bool:
    """Return True if file_path matches any allowed path (exact or prefix)."""
    for allowed in allowed_paths:
        if file_path == allowed or file_path.startswith(allowed + "/"):
            return True
    return False


# ---------------------------------------------------------------------------
# AiderGovernedClient
# ---------------------------------------------------------------------------

class AiderGovernedClient(BaseGovernanceIntegration):
    """Governance client for Aider terminal pair-programmer sessions.

    Mirrors AiderAdapter (TypeScript) method-for-method.

    Configuration:
        deployment_mode: 'aider-cli-individual' | 'aider-cli-team' | 'aider-ci-mode'
        allow_shell_commands: bool (default False; must be False in CI mode)
        allowed_shell_prefixes: list[str] (restrict commands to prefixes)
        allow_auto_commit: bool (default False)
        allow_voice_input: bool (default False)
        secret_scan_files: bool (default True; cannot be False in team/CI)
        allowed_file_paths: list[str] (bypass secret scan for these paths)
        repo_map_max_bytes: int (default 65536)
        multi_file_edit_cap: int (default 20)
    """

    _FRAMEWORK_NAME = "aider"
    _LAYER_NAME = "aider-governed-client"
    _VALID_EVENT_TYPES = _VALID_EVENT_TYPES

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        deployment_mode: str = "aider-cli-individual",
        allow_shell_commands: bool = False,
        allowed_shell_prefixes: Optional[list[str]] = None,
        allow_auto_commit: bool = False,
        allow_voice_input: bool = False,
        secret_scan_files: bool = True,
        allowed_file_paths: Optional[list[str]] = None,
        repo_map_max_bytes: int = 65536,
        multi_file_edit_cap: int = 20,
    ) -> None:
        """Initialise the Aider governed client.

        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            deployment_mode: Aider deployment context.
            allow_shell_commands: Permit Aider to run shell commands.
                Must remain False in aider-ci-mode (PT-ADAPT-AIDER-4).
            allowed_shell_prefixes: Restrict shell commands to these prefixes.
            allow_auto_commit: Permit Aider auto-commits to git.
            allow_voice_input: Permit voice transcription surface.
            secret_scan_files: Scan files before adding to LLM context.
                Cannot be False in team or CI mode (PT-ADAPT-AIDER-3).
            allowed_file_paths: File paths that bypass the secret scan.
            repo_map_max_bytes: Cap on repo-map content size sent to LLM.
            multi_file_edit_cap: Max files in a single edit cycle.

        Raises:
            ValueError: On any invalid configuration combination.
        """
        super().__init__(client)

        # Validate deployment mode
        if deployment_mode not in AIDER_VALID_DEPLOYMENT_MODES:
            raise ValueError(
                f"AiderGovernedClient: invalid deployment_mode '{deployment_mode}'. "
                f"Valid modes: {', '.join(AIDER_VALID_DEPLOYMENT_MODES)}."
            )

        # PT-ADAPT-AIDER-4: CI mode must never allow shell commands
        if deployment_mode == "aider-ci-mode" and allow_shell_commands:
            raise ValueError(
                "AiderGovernedClient: allow_shell_commands=True is rejected in "
                "aider-ci-mode. CI pipelines must be deterministic. Shell command "
                "execution is not permitted in CI mode regardless of configuration. "
                "Remove allow_shell_commands from the aider-ci-mode config or switch "
                "to aider-cli-individual / aider-cli-team."
            )

        # PT-ADAPT-AIDER-3: secret_scan_files cannot be disabled in team or CI mode
        if not secret_scan_files and deployment_mode in ("aider-cli-team", "aider-ci-mode"):
            raise ValueError(
                f"AiderGovernedClient: secret_scan_files=False is not permitted in "
                f"'{deployment_mode}'. Secret scanning is mandatory in team and CI "
                "deployment modes to prevent accidental transmission of secrets to "
                "LLM providers. Remove secret_scan_files=False from the config."
            )

        # Validate numeric caps
        if not isinstance(repo_map_max_bytes, int) or repo_map_max_bytes < 1:
            raise ValueError(
                f"AiderGovernedClient: repo_map_max_bytes must be a positive integer, "
                f"got: {repo_map_max_bytes!r}."
            )
        if not isinstance(multi_file_edit_cap, int) or multi_file_edit_cap < 1:
            raise ValueError(
                f"AiderGovernedClient: multi_file_edit_cap must be a positive integer, "
                f"got: {multi_file_edit_cap!r}."
            )

        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding: list[str] = pack_binding or []
        self.deployment_mode = deployment_mode
        self.allow_shell_commands = allow_shell_commands
        self.allowed_shell_prefixes: list[str] = allowed_shell_prefixes or []
        self.allow_auto_commit = allow_auto_commit
        self.allow_voice_input = allow_voice_input
        self.secret_scan_files = secret_scan_files
        self.allowed_file_paths: list[str] = allowed_file_paths or []
        self.repo_map_max_bytes = repo_map_max_bytes
        self.multi_file_edit_cap = multi_file_edit_cap

    # ------------------------------------------------------------------
    # intercept_chat
    # ------------------------------------------------------------------

    def intercept_chat(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an Aider chat request (user prompt to LLM).

        Args:
            request: dict with keys: prompt, packBinding, agentId (optional).

        Returns:
            GovernanceDecision (ALLOW or DENY).
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        prompt = str(request.get("prompt", ""))

        # PT-ADAPT-AIDER-1
        if not pack_binding:
            return self._deny(agent_id, "aider-chat-no-pack-binding: chat request carries no pack binding.")

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:chat",
            "args": {"promptLength": len(prompt), "mode": self.deployment_mode},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_file_edit
    # ------------------------------------------------------------------

    def intercept_file_edit(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an Aider SEARCH/REPLACE file edit.

        Args:
            request: dict with keys: filePath, searchBlock, replaceBlock,
                     affectedFileCount, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        file_path = str(request.get("filePath", ""))
        affected_count = int(request.get("affectedFileCount", 1))

        if not pack_binding:
            return self._deny(agent_id, "aider-file-edit-no-pack-binding: file edit request carries no pack binding.")

        if affected_count > self.multi_file_edit_cap:
            return self._deny(
                agent_id,
                f"aider-multi-file-edit-cap-exceeded: file edit denied -- "
                f"affectedFileCount ({affected_count}) exceeds multi_file_edit_cap "
                f"({self.multi_file_edit_cap}).",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:file-edit",
            "args": {"filePath": file_path, "affectedFileCount": affected_count},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_file_add
    # ------------------------------------------------------------------

    def intercept_file_add(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate Aider adding a file to its LLM context.

        Scans file content for secrets before allowing the add.

        Args:
            request: dict with keys: filePath, content, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        file_path = str(request.get("filePath", ""))
        content = str(request.get("content", ""))

        if not pack_binding:
            return self._deny(agent_id, "aider-file-add-no-pack-binding: file add request carries no pack binding.")

        # Path allowlist bypasses secret scan
        if _is_path_allowed(file_path, self.allowed_file_paths):
            return self.emit_event("toolCall", {
                "agentId": agent_id,
                "toolName": "aider:file-add",
                "args": {"filePath": file_path, "allowlisted": True},
                "packBinding": pack_binding,
            })

        # PT-ADAPT-AIDER-6: secret scan
        if self.secret_scan_files:
            finding = _scan_for_secrets(content)
            if finding:
                # PT-ADAPT-AIDER-2: never echo secret value in audit entry
                sanitized_path = _sanitize_secret_from_audit(file_path)
                return self._deny(
                    agent_id,
                    f"aider-file-add-secret-detected: file add blocked -- secret pattern "
                    f"'{finding}' detected in file content of '{sanitized_path}'. "
                    "Adding this file to LLM context would transmit secrets to an "
                    "external LLM provider. Remove the secret or add the path to "
                    "allowed_file_paths if the file is intentionally public.",
                    pack_binding=pack_binding,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:file-add",
            "args": {"filePath": file_path, "secretScanned": self.secret_scan_files},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_git_commit
    # ------------------------------------------------------------------

    def intercept_git_commit(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an Aider auto-commit.

        Args:
            request: dict with keys: message, stagedFiles, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        message = str(request.get("message", ""))
        staged_files = request.get("stagedFiles", [])

        if not pack_binding:
            return self._deny(agent_id, "aider-git-commit-no-pack-binding: git commit request carries no pack binding.")

        if not self.allow_auto_commit:
            return self._deny(
                agent_id,
                f"aider-auto-commit-not-permitted: auto-commit denied -- allow_auto_commit is False "
                f"(mode: {self.deployment_mode}). Set allow_auto_commit=True to enable Aider auto-commits.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:git-commit",
            "args": {
                "message": message[:100],
                "stagedFileCount": len(staged_files) if isinstance(staged_files, list) else 0,
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_git_diff
    # ------------------------------------------------------------------

    def intercept_git_diff(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an Aider git diff (read-only operation).

        Args:
            request: dict with keys: args, packBinding.

        Returns:
            GovernanceDecision (always ALLOW unless no pack binding).
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        args = str(request.get("args", ""))

        if not pack_binding:
            return self._deny(agent_id, "aider-git-diff-no-pack-binding: git diff request carries no pack binding.")

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:git-diff",
            "args": {"args": args, "readOnly": True},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_shell_command
    # ------------------------------------------------------------------

    def intercept_shell_command(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an Aider /run shell command.

        HIGH RISK. Multiple deny layers:
          1. CI mode: unconditional deny.
          2. opt-in required (allow_shell_commands must be True).
          3. Dangerous patterns: unconditional deny (PT-ADAPT-AIDER-5).
          4. Prefix allowlist: if configured, command must match a prefix.

        Args:
            request: dict with keys: command, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        command = str(request.get("command", ""))

        if not pack_binding:
            return self._deny(agent_id, "aider-shell-no-pack-binding: shell command request carries no pack binding.")

        # Layer 1: CI mode -- unconditional deny
        if self.deployment_mode == "aider-ci-mode":
            return self._deny(
                agent_id,
                "aider-shell-not-permitted-ci-mode: shell command denied in aider-ci-mode. "
                "CI pipelines must be deterministic. Interactive shell commands are not "
                "permitted in CI mode regardless of allow_shell_commands configuration.",
                pack_binding=pack_binding,
            )

        # Layer 2: opt-in required
        if not self.allow_shell_commands:
            return self._deny(
                agent_id,
                "aider-shell-not-permitted: shell command denied -- allow_shell_commands is False. "
                "Set allow_shell_commands=True in AiderGovernedClient to enable shell execution.",
                pack_binding=pack_binding,
            )

        # Layer 3: dangerous patterns (PT-ADAPT-AIDER-5) -- no bypass via prefixes
        dangerous_name = _check_dangerous_shell(command)
        if dangerous_name:
            return self._deny(
                agent_id,
                f"aider-shell-dangerous-pattern: shell command denied -- dangerous pattern "
                f"'{dangerous_name}' detected. This pattern is unconditionally blocked "
                "regardless of allowed_shell_prefixes.",
                pack_binding=pack_binding,
            )

        # Layer 4: prefix allowlist
        if self.allowed_shell_prefixes:
            trimmed = command.strip()
            prefix_match = any(trimmed.startswith(p) for p in self.allowed_shell_prefixes)
            if not prefix_match:
                return self._deny(
                    agent_id,
                    f"aider-shell-prefix-not-allowed: shell command denied -- no allowed prefix "
                    f"matched for '{trimmed[:80]}'. "
                    f"Allowed prefixes: [{', '.join(repr(p) for p in self.allowed_shell_prefixes)}].",
                    pack_binding=pack_binding,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:shell-command",
            "args": {"commandLength": len(command)},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_test_run
    # ------------------------------------------------------------------

    def intercept_test_run(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an Aider test suite run.

        Args:
            request: dict with keys: testCommand, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        test_command = str(request.get("testCommand", ""))

        if not pack_binding:
            return self._deny(agent_id, "aider-test-run-no-pack-binding: test run request carries no pack binding.")

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:test-run",
            "args": {"testCommand": test_command, "mode": self.deployment_mode},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_lint_run
    # ------------------------------------------------------------------

    def intercept_lint_run(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate an Aider lint run.

        Args:
            request: dict with keys: lintCommand, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        lint_command = str(request.get("lintCommand", ""))

        if not pack_binding:
            return self._deny(agent_id, "aider-lint-run-no-pack-binding: lint run request carries no pack binding.")

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:lint-run",
            "args": {"lintCommand": lint_command, "mode": self.deployment_mode},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_voice_input
    # ------------------------------------------------------------------

    def intercept_voice_input(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate Aider voice transcription input.

        Always denied in CI mode. Requires allow_voice_input=True otherwise.

        Args:
            request: dict with keys: transcribedText, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        transcribed_text = str(request.get("transcribedText", ""))

        if not pack_binding:
            return self._deny(agent_id, "aider-voice-no-pack-binding: voice input request carries no pack binding.")

        # CI mode: always deny (non-interactive)
        if self.deployment_mode == "aider-ci-mode":
            return self._deny(
                agent_id,
                "aider-voice-not-permitted-ci-mode: voice input denied in aider-ci-mode. "
                "CI pipelines are non-interactive. Voice input is not permitted in CI mode.",
                pack_binding=pack_binding,
            )

        if not self.allow_voice_input:
            return self._deny(
                agent_id,
                "aider-voice-not-permitted: voice input denied -- allow_voice_input is False. "
                "Voice transcription may contain PII. Set allow_voice_input=True to enable.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:voice-input",
            "args": {"transcribedLength": len(transcribed_text)},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_repomap_build
    # ------------------------------------------------------------------

    def intercept_repomap_build(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate Aider repo-map build (file structure sent to LLM).

        Enforces repo_map_max_bytes cap and scans for sensitive path references.

        Args:
            request: dict with keys: repomapContent, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        repomap_content = str(request.get("repomapContent", ""))

        if not pack_binding:
            return self._deny(agent_id, "aider-repomap-no-pack-binding: repomap build request carries no pack binding.")

        # Byte cap
        byte_size = len(repomap_content.encode("utf-8"))
        if byte_size > self.repo_map_max_bytes:
            return self._deny(
                agent_id,
                f"aider-repomap-too-large: repo-map build denied -- content size ({byte_size} bytes) "
                f"exceeds repo_map_max_bytes cap ({self.repo_map_max_bytes} bytes). "
                "Large repo-maps transmit significant project data to LLM providers.",
                pack_binding=pack_binding,
            )

        # Sensitive path scan
        for sens_name, pattern in _SENSITIVE_REPOMAP_PATTERNS:
            if pattern.search(repomap_content):
                return self._deny(
                    agent_id,
                    f"aider-repomap-sensitive-paths-detected: repo-map build denied -- "
                    f"sensitive path pattern '{sens_name}' detected in repo-map content. "
                    "Transmitting the repo-map would reveal sensitive file locations to "
                    "the LLM provider. Exclude the sensitive path from the Aider context.",
                    pack_binding=pack_binding,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "aider:repomap-build",
            "args": {"byteSize": byte_size, "repoMapMaxBytes": self.repo_map_max_bytes},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown Aider event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )
        enriched = {"deploymentMode": self.deployment_mode, **payload}
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "AiderPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return AiderPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# AiderPolicyBridge
# ---------------------------------------------------------------------------

class AiderPolicyBridge:
    """Bridge for Python-hosted policy participation in the Aider governance loop."""

    def __init__(
        self,
        adapter: AiderGovernedClient,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> None:
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:
                import logging as _logging
                _logging.getLogger(__name__).warning(
                    "Governance audit operation failed: %s", exc
                )
        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
