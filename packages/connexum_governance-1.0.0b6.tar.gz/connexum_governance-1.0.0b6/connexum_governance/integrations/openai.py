"""OpenAI governance integration for Connexum governance.

Wraps calls to the OpenAI Chat Completions API with pre-call governance
checks and post-call G-series output classification.

BAA status: OpenAI offers a Business Associate Agreement (BAA) only for
enterprise customers via the Healthcare Data Processing Addendum. Standard
API plans do not carry a BAA.

Supports both:
- Legacy function_calling format (function_call key in request)
- Tool use format (tools array in request, tool_calls in response)

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.openai import OpenAIGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    og = OpenAIGovernance(client=gov, agent_name="chat-agent")

    # Intercept before sending
    decision = og.intercept_request({
        "model": "gpt-4o",
        "messages": [{"role": "user", "content": "Hello"}],
    })

    # Use the proxy (requires openai package installed)
    import openai
    raw_client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    governed_client = og.wrap(raw_client)
    response = governed_client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

from __future__ import annotations

import sys
import time
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import (
    AgentIdentity,
    ClassifiedResponse,
    GovernanceDecision,
    GovernanceViolation,
)

_PROVIDER_ID = "openai"
_BAA_AVAILABLE = True
_BAA_SCOPE = "enterprise_only"
_BAA_NOTES = (
    "OpenAI BAA available via Healthcare Data Processing Addendum for enterprise customers only. "
    "Standard API plans do not carry a BAA."
)


class OpenAIGovernance:
    """Governance wrapper for the OpenAI Chat Completions API.

    Intercepts requests before they reach the OpenAI endpoint and
    classifies responses through the nine-guard G-series after receipt.

    Does NOT depend on the openai package at import time.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
    ):
        self.client = client
        self.agent = AgentIdentity(name=agent_name, role=agent_role)

        self.client.register_provider_compliance(
            provider=_PROVIDER_ID,
            baa_available=_BAA_AVAILABLE,
            baa_scope=_BAA_SCOPE,
            notes=_BAA_NOTES,
        )

    def intercept_request(self, request: dict[str, Any]) -> GovernanceDecision:
        """Check a pending chat.completions.create request against governance.

        Extracts: model, system prompt digest (first 500 chars), message count,
        tool names (both legacy function_calling and tool use formats).

        Args:
            request: The dict that would be passed to chat.completions.create.

        Returns:
            GovernanceDecision (ALLOW / DENY / REQUIRE_APPROVAL).

        Raises:
            GovernanceViolation: if enforce=True and the decision is DENY.
        """
        messages = request.get("messages", [])
        system_digest = ""
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "system":
                content = msg.get("content", "")
                if isinstance(content, str):
                    system_digest = content[:500]
                elif isinstance(content, list):
                    system_digest = " ".join(
                        p.get("text", "") for p in content if isinstance(p, dict)
                    )[:500]
                break

        # Tool use format (tools array)
        tools = request.get("tools", [])
        tool_names = [
            t.get("function", {}).get("name", "")
            for t in tools
            if isinstance(t, dict)
        ]

        # Legacy function_calling format (functions array)
        functions = request.get("functions", [])
        function_names = [
            f.get("name", "") for f in functions if isinstance(f, dict)
        ]

        all_tool_names = list(filter(None, tool_names + function_names))

        gov_input: dict[str, Any] = {
            "model": request.get("model", "unknown"),
            "maxTokens": request.get("max_tokens"),
            "systemPromptDigest": system_digest,
            "messageCount": len(messages),
            "toolCount": len(all_tool_names),
            "toolNames": all_tool_names,
        }

        return self.client.check_action(
            tool="llm.chat",
            input=gov_input,
            agent=self.agent,
        )

    def intercept_response(
        self,
        response: dict[str, Any],
        audit_id: str,
    ) -> ClassifiedResponse:
        """Classify an OpenAI chat.completions response through the G-series guards.

        Args:
            response: Raw response dict from OpenAI (or SDK object converted to dict).
            audit_id: The audit_id from the preceding intercept_request decision.

        Returns:
            ClassifiedResponse indicating whether the response is safe to return.
        """
        start = time.monotonic()

        classified = self.client.classify_output(
            audit_id=audit_id,
            output=response,
            agent=self.agent,
        )

        elapsed_ms = int((time.monotonic() - start) * 1000)

        try:
            self.client.report_result(
                audit_id=audit_id,
                success=classified.allowed,
                summary=(
                    f"Response classified. Guards triggered: {classified.guards_triggered}"
                    if classified.guards_triggered
                    else "Response classified clean."
                ),
                duration_ms=elapsed_ms,
                error=(
                    f"Guards triggered: {classified.guards_triggered}"
                    if not classified.allowed
                    else None
                ),
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return classified

    def wrap(self, openai_client: Any) -> "OpenAIClientProxy":
        """Return a proxy around an openai.OpenAI client instance.

        Args:
            openai_client: An openai.OpenAI client instance.

        Returns:
            OpenAIClientProxy wrapping the provided client.
        """
        return OpenAIClientProxy(
            raw_client=openai_client,
            governance=self,
        )


class _GovernedChatCompletions:
    """Proxy for openai_client.chat.completions with governance enforcement."""

    def __init__(self, raw_completions: Any, governance: OpenAIGovernance):
        self._raw = raw_completions
        self._gov = governance

    def create(self, **kwargs: Any) -> Any:
        """Intercept chat.completions.create with governance checks."""
        decision = self._gov.intercept_request(kwargs)

        if decision.denied:
            if self._gov.client.enforce:
                raise GovernanceViolation(decision)
            return {
                "id": "gov-denied",
                "object": "chat.completion",
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": f"[GOVERNANCE DENIED] {decision.reason}",
                        },
                        "finish_reason": "governance_denied",
                    }
                ],
                "model": kwargs.get("model", "unknown"),
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            }

        if decision.requires_approval:
            return {
                "id": f"gov-pending-{decision.audit_id}",
                "object": "chat.completion",
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": (
                                f"[GOVERNANCE PENDING] Action requires approval. "
                                f"Audit ID: {decision.audit_id}"
                            ),
                        },
                        "finish_reason": "governance_pending",
                    }
                ],
                "model": kwargs.get("model", "unknown"),
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            }

        response = self._raw.create(**kwargs)

        if hasattr(response, "model_dump"):
            response_dict = response.model_dump()
        elif hasattr(response, "to_dict"):
            response_dict = response.to_dict()
        else:
            response_dict = dict(response) if not isinstance(response, dict) else response

        if decision.audit_id:
            classified = self._gov.intercept_response(
                response=response_dict,
                audit_id=decision.audit_id,
            )
            if not classified.allowed:
                print(
                    f"[WARN] OpenAI response failed G-series classification: "
                    f"{classified.guards_triggered}",
                    file=sys.stderr,
                )

        return response


class _GovernedChat:
    """Proxy for openai_client.chat, exposing .completions."""

    def __init__(self, raw_chat: Any, governance: OpenAIGovernance):
        self.completions = _GovernedChatCompletions(
            raw_completions=raw_chat.completions,
            governance=governance,
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)


class OpenAIClientProxy:
    """Thin proxy around an openai.OpenAI client with governance on chat.completions.

    Only .chat.completions.create is intercepted. All other attributes pass
    through to the underlying client unchanged.
    """

    def __init__(self, raw_client: Any, governance: OpenAIGovernance):
        self._raw = raw_client
        self._chat = _GovernedChat(
            raw_chat=raw_client.chat,
            governance=governance,
        )

    @property
    def chat(self) -> _GovernedChat:
        return self._chat

    def __getattr__(self, name: str) -> Any:
        return getattr(self._raw, name)
