"""GitHub Copilot Workspace governance integration.

Copilot Workspace (Technical Preview as of 2026-04-22) does not expose
runtime per-tool hooks. AI governance fires exclusively at the PR boundary:
a webhook shim intercepts PRs authored by `copilot-workspace[bot]`, runs
diff evaluation against the active compliance pack plus a secret scanner,
and posts a check-run result.

Architecture:
  The primary adapter is TypeScript-native (`src/ide-adapters/copilot-workspace.ts`).
  This Python shim lets a Python-hosted governance policy server participate
  in the PR-boundary decision loop via HTTP.

  Two principal surfaces:
    intercept_spec_to_code(request) -- gate a spec-to-code generation request
    intercept_pr_preview(request)   -- evaluate a PR diff before check-run posting

  Runtime surfaces (tool-level hooks) raise IdeUnsupportedError -- Copilot
  Workspace operates at PR boundary only (mirrors AC 9 of the TS adapter).

Provider: OpenAI (Copilot Workspace backend). The shim enforces that the
provider in each request matches the configured approved_providers list.

Bot-author gate: only PRs authored by `copilot-workspace[bot]` are governed.
Other authors receive a neutral / no-op decision.

DEFERRED-COPILOT-WS-GITHUB-APP: Real GitHub App delivery (private key,
installation token, actual Checks API call) is stubbed in the Python shim
the same way as the TS adapter. Wire the real implementation when the GitHub
App is provisioned.

TESTED_API_VERSION = '2024-11-01' (GitHub Checks API version, spec-aligned).

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.copilot_workspace import CopilotWorkspaceGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    adapter = CopilotWorkspaceGovernance(
        client=gov,
        agent_name="copilot-workspace-agent",
        pack_binding=["soc2"],
    )

    # Gate a spec-to-code generation:
    decision = adapter.intercept_spec_to_code({
        "specText": "Build a REST API for patient records",
        "targetRepo": "acme/health-api",
        "prAuthor": "copilot-workspace[bot]",
        "packBinding": ["hipaa"],
    })

    # Evaluate a PR diff before posting a check-run:
    decision = adapter.intercept_pr_preview({
        "diff": unified_diff_text,
        "prUrl": "https://github.com/acme/health-api/pull/42",
        "prNumber": 42,
        "headSha": "abc123",
        "sender": "copilot-workspace[bot]",
        "packBinding": ["hipaa"],
    })
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# GitHub Checks API version this shim is aligned with (AC 11 equivalent)
COPILOT_WORKSPACE_TESTED_API_VERSION = "2024-11-01"

# The only PR author this adapter governs (bot-author gate)
COPILOT_WORKSPACE_BOT_AUTHOR = "copilot-workspace[bot]"

# Default approved providers for Copilot Workspace
_DEFAULT_APPROVED_PROVIDERS = ["openai"]

# ---------------------------------------------------------------------------
# Secret patterns (same set as continue_dev, shared guard responsibility)
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",          re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHub PAT",              re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",       re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",          re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Private key header",      re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----")),
    ("Generic secret env var",  re.compile(r"(SECRET|PASSWORD|API_KEY|PRIVATE_KEY)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Database URL with creds", re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("Bearer token",            re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
]

# ---------------------------------------------------------------------------
# PHI indicators
# ---------------------------------------------------------------------------

_PHI_INDICATORS: list[re.Pattern] = [
    re.compile(r"\bpatient[_\s]?(id|name|dob|ssn|mrn|record)\b", re.IGNORECASE),
    re.compile(r"\bdiagnos(is|es)\b", re.IGNORECASE),
    re.compile(r"\bprescription\b", re.IGNORECASE),
    re.compile(r"\bmedical[_\s]?record\b", re.IGNORECASE),
    re.compile(r"\bhealth[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bsocial[_\s]?security\b", re.IGNORECASE),
    re.compile(r"\bssn\b"),
    re.compile(r"\bdate[_\s]?of[_\s]?birth\b", re.IGNORECASE),
    re.compile(r"\btreatment[_\s]?plan\b", re.IGNORECASE),
    re.compile(r"\bhipaa\b", re.IGNORECASE),
    re.compile(r"\bphi\b"),
]

# ---------------------------------------------------------------------------
# Canonical event types
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    """Return the name of the first secret pattern found, or None."""
    if not text:
        return None
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _scan_diff_for_secrets(diff: str) -> list[dict[str, Any]]:
    """Scan a unified diff for secret patterns on added lines (lines starting with +)."""
    findings: list[dict[str, Any]] = []
    for line_num, line in enumerate(diff.splitlines(), start=1):
        if not line.startswith("+") or line.startswith("+++"):
            continue
        for name, pattern in _SECRET_PATTERNS:
            m = pattern.search(line)
            if m:
                findings.append({
                    "line": line_num,
                    "pattern": name,
                    "excerpt": line[max(0, m.start() - 10): m.end() + 10],
                })
    return findings


def _scan_for_phi(text: str) -> Optional[str]:
    """Return the first PHI indicator pattern found, or None."""
    if not text:
        return None
    for pattern in _PHI_INDICATORS:
        if pattern.search(text):
            return pattern.pattern
    return None


def _is_hipaa_binding(pack_binding: list[str]) -> bool:
    return any(p.lower() in ("hipaa", "hitech") for p in pack_binding)


class IdeUnsupportedError(Exception):
    """Raised when a Copilot Workspace surface that is unsupported is invoked."""
    pass


# ---------------------------------------------------------------------------
# CopilotWorkspaceGovernance
# ---------------------------------------------------------------------------

class CopilotWorkspaceGovernance(BaseGovernanceIntegration):
    """REST-client shim for GitHub Copilot Workspace governance.

    Copilot Workspace is TypeScript-native. This Python shim participates in
    the PR-boundary decision loop by:
      1. Gating spec-to-code requests (intercept_spec_to_code)
      2. Evaluating PR diffs before check-run posting (intercept_pr_preview)
      3. Providing policy_bridge() for Python policy participation

    Runtime per-tool hooks are NOT supported -- raise IdeUnsupportedError
    (mirrors AC 9 of the TS adapter).

    Provider: OpenAI (Copilot Workspace backend).
    Bot-author gate: only govern PRs from `copilot-workspace[bot]`.
    """

    _FRAMEWORK_NAME = "copilot-workspace"
    _LAYER_NAME = "copilot-workspace-rest-shim"

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        approved_providers: Optional[list[str]] = None,
        github_app_installation_id: Optional[int] = None,
        hipaa_reviewer_tier: str = "T2_LEAD",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            approved_providers: Provider IDs approved for use.
            github_app_installation_id: GitHub App installation ID (for real check-run delivery).
            hipaa_reviewer_tier: Reviewer tier for HIPAA-bound violations.
        """
        super().__init__(client)
        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding = pack_binding or []
        self.approved_providers = approved_providers or list(_DEFAULT_APPROVED_PROVIDERS)
        self.github_app_installation_id = github_app_installation_id
        self.hipaa_reviewer_tier = hipaa_reviewer_tier

    # ------------------------------------------------------------------
    # intercept_spec_to_code -- gate spec-to-code generation request
    # ------------------------------------------------------------------

    def intercept_spec_to_code(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Gate a spec-to-code generation request from Copilot Workspace.

        Maps to the GitHub Copilot Workspace spec-to-code surface where a
        natural language spec is converted into code changes.

        Guards applied:
          1. Pack-binding primacy
          2. Secret scan on spec text
          3. PHI proximity check under HIPAA binding
          4. Provider compliance
          5. Bot-author gate (non-bot authors produce neutral decision)

        Args:
            request: Spec-to-code request dict with keys:
                     specText, targetRepo, prAuthor, model, packBinding, etc.

        Returns:
            GovernanceDecision.
        """
        spec_text = str(request.get("specText", request.get("spec", "")))
        target_repo = str(request.get("targetRepo", request.get("repo", "")))
        pr_author = str(request.get("prAuthor", request.get("sender", "")))
        model = str(request.get("model", "gpt-4o"))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Workspace spec-to-code request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
                pack_binding=pack_binding,
            )

        # Bot-author gate: only govern Copilot Workspace PRs
        if pr_author and pr_author != COPILOT_WORKSPACE_BOT_AUTHOR:
            return self.emit_event("agentStart", {
                "agentId": agent_id,
                "packBinding": pack_binding,
                "prAuthor": pr_author,
                "reason": (
                    f"PR author '{pr_author}' is not '{COPILOT_WORKSPACE_BOT_AUTHOR}'. "
                    "CopilotWorkspaceGovernance only governs Copilot Workspace PRs. "
                    "Neutral pass-through."
                ),
                "neutral": True,
            })

        # Secret scan on spec text
        secret_match = _scan_for_secrets(spec_text)
        if secret_match:
            return self._deny(
                agent_id,
                f'Spec-to-code request blocked: secret pattern "{secret_match}" '
                f"detected in spec text. Remove the secret before submitting.",
                pack_binding=pack_binding,
            )

        # PHI proximity check under HIPAA
        if _is_hipaa_binding(pack_binding):
            phi_indicator = _scan_for_phi(spec_text)
            if phi_indicator:
                return self._deny(
                    agent_id,
                    f'Spec-to-code request blocked under HIPAA: PHI indicator '
                    f'"{phi_indicator}" found in spec text. '
                    f"Reviewer tier: {self.hipaa_reviewer_tier}. "
                    "Spec must not reference PHI in code generation prompts.",
                    pack_binding=pack_binding,
                )

        # Provider compliance
        provider = _infer_provider(model)
        if self.approved_providers and provider and provider not in self.approved_providers:
            return self._deny(
                agent_id,
                f'Copilot Workspace provider "{provider}" (model: "{model}") is not on '
                f"the approved provider list. Approved: {', '.join(self.approved_providers)}.",
                pack_binding=pack_binding,
            )

        return self.emit_event("llmCall", {
            "agentId": agent_id,
            "model": model,
            "messageCount": 1,
            "packBinding": pack_binding,
            "targetRepo": target_repo,
            "specToCode": True,
        })

    # ------------------------------------------------------------------
    # intercept_pr_preview -- evaluate PR diff before check-run posting
    # ------------------------------------------------------------------

    def intercept_pr_preview(
        self,
        request: dict[str, Any],
    ) -> GovernanceDecision:
        """Evaluate a PR diff from Copilot Workspace before posting a check-run.

        Maps to the PR-boundary enforcement surface. Runs the secret scanner
        and license violation detection on the unified diff.

        Bot-author gate: if the PR sender is not copilot-workspace[bot], returns
        a neutral decision (mirrors AC 9 of the TS adapter).

        User identity resolved from request.sender. Missing sender -> neutral
        decision (mirrors AC 12 fail-closed behaviour).

        Args:
            request: PR preview request dict with keys:
                     diff, prUrl, prNumber, headSha, sender, packBinding, etc.

        Returns:
            GovernanceDecision with PR evaluation result.
        """
        diff = str(request.get("diff", ""))
        pr_url = str(request.get("prUrl", request.get("pr_url", "")))
        pr_number = request.get("prNumber", request.get("pr_number"))
        head_sha = str(request.get("headSha", request.get("head_sha", "")))
        sender = str(request.get("sender", ""))
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)

        # Pack-binding primacy
        if not pack_binding:
            return self._deny(
                agent_id,
                "Copilot Workspace PR preview request carries no pack binding. "
                "Pack-binding primacy: every request MUST carry packBinding.",
                pack_binding=pack_binding,
            )

        # Bot-author gate
        if sender and sender != COPILOT_WORKSPACE_BOT_AUTHOR:
            return self.emit_event("agentStart", {
                "agentId": agent_id,
                "packBinding": pack_binding,
                "sender": sender,
                "reason": (
                    f"PR sender '{sender}' is not '{COPILOT_WORKSPACE_BOT_AUTHOR}'. "
                    "No governance action."
                ),
                "neutral": True,
            })

        # Missing sender -> neutral (fail-closed, not silent-approve)
        if not sender:
            return self.emit_event("agentStart", {
                "agentId": agent_id,
                "packBinding": pack_binding,
                "reason": "PR webhook payload missing sender. Neutral decision (unresolved identity).",
                "neutral": True,
                "identityUnresolved": True,
            })

        # Secret scanner on diff added lines
        findings = _scan_diff_for_secrets(diff)
        if findings:
            violations_text = "; ".join(
                f"line {f['line']}: {f['pattern']}" for f in findings[:5]
            )
            return self._deny(
                agent_id,
                f"PR diff blocked: {len(findings)} secret(s) detected in added lines. "
                f"Findings: {violations_text}. "
                "Remove all secrets before merging.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "pr-diff-evaluation",
            "args": {
                "prUrl": pr_url,
                "prNumber": pr_number,
                "headSha": head_sha,
                "diffLength": len(diff),
            },
            "packBinding": pack_binding,
            "prPreview": True,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API.

        Args:
            event_type: Canonical event type.
            payload: Event payload. Must include "agentId".

        Returns:
            GovernanceDecision from the governance API.
        """
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown CopilotWorkspace event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", self.agent_name)
        pack_binding: list[str] = payload.get("packBinding", self.pack_binding)
        # Normalise: ensure payload carries the resolved pack_binding for super()
        payload = {**payload, "agentId": agent_id, "packBinding": pack_binding}

        # Output classifier for tool results (secret scan)
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _scan_for_secrets(result_text):
                print(
                    f"[GOVERNANCE] CopilotWorkspace output classifier: possible secret in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _scan_for_secrets(response_text) or _scan_for_phi(response_text):
                print(
                    f"[GOVERNANCE] CopilotWorkspace output exfiltration scanner: possible "
                    f'secret/PHI in LLM response (agent: {agent_id}).',
                    file=sys.stderr,
                )

        return super().emit_event(event_type, payload)

    # ------------------------------------------------------------------
    # wrap_webhook
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a GitHub PR webhook payload and forward it as a governance event.

        Args:
            request_body: Parsed JSON body with "eventType" and "agentId".

        Returns:
            GovernanceDecision.
        """
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError(
                "CopilotWorkspace webhook payload missing required field: 'eventType'"
            )
        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError(
                "CopilotWorkspace webhook payload missing required field: 'agentId'"
            )
        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "CopilotWorkspacePolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return CopilotWorkspacePolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(
        self, agent_id: str, pack_binding: list[str], model: Optional[str] = None,
        **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {"agentId": agent_id, "packBinding": pack_binding}
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(
        self, agent_id: str, tool_name: str, args: dict[str, Any],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pb, **kwargs,
        })

    def tool_result(
        self, agent_id: str, tool_name: str, result: Any,
        success: bool = True, pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pb, **kwargs,
        })

    def llm_call(
        self, agent_id: str, model: str, messages: list[dict[str, Any]],
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pb, **kwargs,
        })

    def llm_result(
        self, agent_id: str, model: str, response_text: str,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pb, **kwargs,
        })

    def agent_end(
        self, agent_id: str, success: bool,
        pack_binding: Optional[list[str]] = None, **kwargs: Any
    ) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        pb = self.pack_binding if pack_binding is None else pack_binding
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pb, **kwargs,
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _infer_provider(model: str) -> str:
    """Infer the LLM provider from a model string."""
    m = model.lower()
    if m.startswith("gpt-") or m.startswith("o1") or m.startswith("o3"):
        return "openai"
    if m.startswith("claude"):
        return "anthropic"
    if m.startswith("gemini"):
        return "google"
    if m.startswith("llama") or m.startswith("mistral") or m.startswith("codellama"):
        return "ollama"
    return ""


# ---------------------------------------------------------------------------
# CopilotWorkspacePolicyBridge
# ---------------------------------------------------------------------------

class CopilotWorkspacePolicyBridge:
    """Bridge for Python-hosted policy participation in the Copilot Workspace loop."""

    def __init__(
        self,
        adapter: CopilotWorkspaceGovernance,
        pack_binding: list[str],
        decision_callback: Any,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
