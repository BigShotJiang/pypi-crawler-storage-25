"""AWS Bedrock AgentCore integration for Connexum governance.

Hooks into the AWS Bedrock AgentCore InvokeAgent lifecycle with six canonical
governance hook surfaces. Python-native: works alongside boto3 / the
bedrock-agentcore package.

Hook surfaces (parity with src/orchestrator-adapters/bedrock-agentcore.ts):
  agentStart   -> gate before InvokeAgent call
  toolCall     -> pre-action-group gate (Bedrock's tool concept)
  toolResult   -> post-action-group G-series classification
  llmCall      -> pre-foundation-model gate
  llmResult    -> post-model output exfiltration scan
  agentEnd     -> terminal audit event sealing

AgentCore-specific surfaces:
  - InvokeAgent API: agentStart is the pre-call gate; agentEnd seals the run.
  - Action groups: Bedrock's tool concept. Maps to toolCall/toolResult.
  - Knowledge Base retrieval: separate ingress class, tagged KNOWLEDGE_BASE.
  - HIPAA BAA region enforcement: Bedrock has BAA coverage in specific AWS
    regions. Any region not on the BAA list triggers BedrockBaaRegionError
    when a HIPAA pack is bound.

HIPAA BAA regions (as of 2026-Q1):
    us-east-1, us-west-2, eu-west-1, ap-southeast-2

Lazy import: boto3 and bedrock-agentcore are NOT hard-required at import time.

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.bedrock_agentcore import (
        BedrockAgentCoreGovernance,
    )

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = BedrockAgentCoreGovernance(
        client=gov,
        agent_id="AGENTID123",
        approved_regions=["us-east-1", "us-west-2"],
        approved_models=["anthropic.claude-3-5-sonnet-20241022-v2:0"],
        sensitive_action_groups=["execute_code", "write_file"],
    )

    adapter.agent_start("sess-001", pack_binding=["hipaa"], region="us-east-1")
    adapter.tool_call("sess-001", "web_search", {"query": "AI governance"})
    adapter.tool_result("sess-001", "web_search", "results...", success=True)
    adapter.llm_call("sess-001", "anthropic.claude-3-5-sonnet-20241022-v2:0", messages=[])
    adapter.llm_result("sess-001", "anthropic.claude-3-5-sonnet-20241022-v2:0", "Response...")
    adapter.agent_end("sess-001", success=True)
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation


# ---------------------------------------------------------------------------
# HIPAA BAA-covered Bedrock regions
# ---------------------------------------------------------------------------

BEDROCK_BAA_REGIONS: frozenset[str] = frozenset({
    "us-east-1",
    "us-west-2",
    "eu-west-1",
    "ap-southeast-2",
})


# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------

class BedrockBaaRegionError(RuntimeError):
    """Raised when a HIPAA-bound invocation uses a non-BAA region."""

    def __init__(self, session_id: str, region: str, baa_regions: frozenset[str]):
        super().__init__(
            f'Bedrock AgentCore session "{session_id}" invoked in region "{region}" '
            f"which is not on the HIPAA BAA-covered list. "
            f"Approved regions: {sorted(baa_regions)}. "
            "Set region to a BAA-covered region or remove the HIPAA pack binding."
        )
        self.session_id = session_id
        self.region = region
        self.baa_regions = baa_regions


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


# ---------------------------------------------------------------------------
# BedrockAgentCoreGovernance
# ---------------------------------------------------------------------------

class BedrockAgentCoreGovernance:
    """Governance adapter for AWS Bedrock AgentCore.

    Wraps the Bedrock InvokeAgent lifecycle with governance enforcement.
    Works without boto3 or the bedrock-agentcore package installed (accepts
    plain Python dicts for all hook arguments).

    HIPAA BAA note: Bedrock's BAA covers specific AWS regions only. When a
    HIPAA pack is bound at agent_start, the adapter verifies the invocation
    region is on the BAA-covered list before allowing the run to proceed.
    """

    def __init__(
        self,
        client: GovernanceClient,
        agent_id: str,
        approved_models: Optional[list[str]] = None,
        approved_regions: Optional[list[str]] = None,
        sensitive_action_groups: Optional[list[str]] = None,
        enforce_hipaa_baa_region: bool = True,
        agent_name: str = "bedrock-agentcore-agent",
    ):
        """
        Args:
            client: Configured GovernanceClient.
            agent_id: The Bedrock Agent ID (e.g. 'AGENTID123').
            approved_models: Bedrock model IDs approved for use.
            approved_regions: AWS regions the agent is allowed to run in.
            sensitive_action_groups: Action group names requiring reviewer approval.
            enforce_hipaa_baa_region: When True and pack includes 'hipaa',
                                      non-BAA regions are denied.
            agent_name: Default agent identity name for audit events.
        """
        self.client = client
        self.bedrock_agent_id = agent_id
        self.approved_models = approved_models or []
        self.approved_regions = approved_regions
        self.sensitive_action_groups = sensitive_action_groups or []
        self.enforce_hipaa_baa_region = enforce_hipaa_baa_region
        self.agent_name = agent_name

        # session_id -> state
        self._sessions: dict[str, dict[str, Any]] = {}
        self._pending_audits: dict[str, str] = {}

    # ------------------------------------------------------------------
    # agentStart
    # ------------------------------------------------------------------

    def agent_start(
        self,
        session_id: str,
        pack_binding: Optional[list[str]] = None,
        region: str = "us-east-1",
        alias_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Gate before InvokeAgent call.

        Checks:
          1. Region allowlist (if configured)
          2. HIPAA BAA region enforcement
          3. Governance check_action

        Raises:
            BedrockBaaRegionError: HIPAA pack bound in non-BAA region.
            GovernanceViolation: governance server denies.
        """
        pack = pack_binding or []
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        # Region allowlist check
        if self.approved_regions is not None and region not in self.approved_regions:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Region "{region}" is not in the approved regions list. '
                f"Approved: {', '.join(self.approved_regions)}"
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        # HIPAA BAA region enforcement
        hipaa_bound = "hipaa" in [p.lower() for p in pack]
        if self.enforce_hipaa_baa_region and hipaa_bound and region not in BEDROCK_BAA_REGIONS:
            raise BedrockBaaRegionError(session_id, region, BEDROCK_BAA_REGIONS)

        decision = self.client.check_action(
            tool="agent.start",
            input={
                "sessionId": session_id,
                "bedrockAgentId": self.bedrock_agent_id,
                "packBinding": pack,
                "region": region,
                "aliasId": alias_id,
                "metadata": metadata or {},
                "framework": "bedrock-agentcore",
            },
            agent=agent,
        )

        self._sessions[session_id] = {
            "pack_binding": pack,
            "region": region,
        }
        if decision.audit_id:
            self._pending_audits[f"start:{session_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolCall (action group)
    # ------------------------------------------------------------------

    def tool_call(
        self,
        session_id: str,
        action_group: str,
        args: dict[str, Any],
        action_spec: Optional[dict[str, Any]] = None,
    ) -> GovernanceDecision:
        """Pre-action-group governance check.

        Raises:
            GovernanceViolation: governance server denies.
        """
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        decision = self.client.check_action(
            tool=f"action.{action_group}",
            input={
                "sessionId": session_id,
                "actionGroup": action_group,
                "argsDigest": str(args)[:500],
                "packBinding": pack,
                "sensitive": action_group in self.sensitive_action_groups,
                "framework": "bedrock-agentcore",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"action:{session_id}:{action_group}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # toolResult (action group result)
    # ------------------------------------------------------------------

    def tool_result(
        self,
        session_id: str,
        action_group: str,
        result: Any,
        success: bool = True,
        duration_ms: Optional[int] = None,
        is_knowledge_base: bool = False,
    ) -> None:
        """Post-action-group G-series classification and audit chain close.

        Knowledge Base retrieval results are tagged separately in audit events.
        """
        audit_id = self._pending_audits.pop(f"action:{session_id}:{action_group}", None)
        result_text = str(result) if not isinstance(result, str) else result
        phi_found = _contains_phi(result_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output classifier: possible PHI in Bedrock action result "
                f'"{action_group}" (session: {session_id}, knowledge_base={is_knowledge_base}). '
                f"Audit ID: {audit_id}",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success and not phi_found,
                    summary=result_text[:200],
                    duration_ms=duration_ms,
                    error=None if not phi_found else "Output classifier: PHI in action result",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # llmCall
    # ------------------------------------------------------------------

    def llm_call(
        self,
        session_id: str,
        model_id: str,
        messages: list[dict[str, Any]],
        tools: Optional[list[dict[str, Any]]] = None,
    ) -> GovernanceDecision:
        """Pre-foundation-model gate.

        Checks model_id against the approved_models list.

        Raises:
            GovernanceViolation: unapproved model or governance server denies.
        """
        session = self._sessions.get(session_id, {})
        pack = session.get("pack_binding", [])
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        # Approved model check
        if self.approved_models and model_id not in self.approved_models:
            from connexum_governance.models import GovernanceDecision, DecisionType
            reason = (
                f'Foundation model "{model_id}" is not on the approved list. '
                f"Approved: {', '.join(self.approved_models)}"
            )
            d = GovernanceDecision(
                decision=DecisionType.DENY,
                reason=reason,
                audit_id=str(uuid.uuid4()),
            )
            if self.client.enforce:
                raise GovernanceViolation(d)
            return d

        decision = self.client.check_action(
            tool="llm.call",
            input={
                "sessionId": session_id,
                "modelId": model_id,
                "messageCount": len(messages),
                "toolCount": len(tools or []),
                "packBinding": pack,
                "framework": "bedrock-agentcore",
            },
            agent=agent,
        )

        if decision.audit_id:
            self._pending_audits[f"llm:{session_id}:{model_id}"] = decision.audit_id

        return decision

    # ------------------------------------------------------------------
    # llmResult
    # ------------------------------------------------------------------

    def llm_result(
        self,
        session_id: str,
        model_id: str,
        response_text: str,
        usage: Optional[dict[str, int]] = None,
    ) -> None:
        """Post-model output exfiltration scan and audit chain close."""
        audit_id = self._pending_audits.pop(f"llm:{session_id}:{model_id}", None)
        phi_found = _contains_phi(response_text)

        if phi_found:
            print(
                f"[GOVERNANCE] Output exfiltration scanner: possible PHI in "
                f"Bedrock model response (model: {model_id}, session: {session_id}). "
                "Flagged for compliance review.",
                file=sys.stderr,
            )

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=not phi_found,
                    summary=response_text[:200],
                    error=None if not phi_found else "Output exfiltration scanner: PHI in model response",
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

    # ------------------------------------------------------------------
    # agentEnd
    # ------------------------------------------------------------------

    def agent_end(
        self,
        session_id: str,
        success: bool,
        summary: Optional[str] = None,
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
    ) -> None:
        """Terminal audit event sealing and session cleanup."""
        session = self._sessions.pop(session_id, {})
        audit_id = self._pending_audits.pop(f"start:{session_id}", None)
        agent = AgentIdentity(name=self.agent_name, session_id=session_id)

        try:
            self.client.check_action(
                tool="agent.end",
                input={
                    "sessionId": session_id,
                    "bedrockAgentId": self.bedrock_agent_id,
                    "success": success,
                    "summary": summary or ("Run complete" if success else "Run failed"),
                    "durationMs": duration_ms,
                    "error": error,
                    "packBinding": session.get("pack_binding", []),
                    "region": session.get("region", "unknown"),
                    "framework": "bedrock-agentcore",
                },
                agent=agent,
            )
        except Exception as exc:  # H2: never swallow -- always log
            import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        if audit_id:
            try:
                self.client.report_result(
                    audit_id=audit_id,
                    success=success,
                    summary=summary or "",
                    duration_ms=duration_ms,
                    error=error,
                )
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)
