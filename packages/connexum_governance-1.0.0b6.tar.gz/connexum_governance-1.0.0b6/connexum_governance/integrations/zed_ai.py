"""Zed AI editor governance integration.

Zed (https://zed.dev) is a high-performance, Rust-native code editor with a
built-in AI assistant. This adapter governs every programmable AI surface Zed
exposes and is purpose-built for the privacy challenges of Zed's three
deployment modes.

Deployment modes:
  zed-cloud      -- Anthropic-backed default; requests route through zed.dev.
  zed-byok       -- Bring your own key; user configures a provider in settings;
                   requests route from the local machine directly to that provider.
  zed-local-only -- On-device Ollama / LM Studio integration; no data leaves
                   the machine. This adapter enforces strict local-only isolation:
                   any surface that can trigger network egress is DENIED
                   unconditionally when local_only_enforcement is True (the
                   default in this mode). PT-ADAPT-ZED-4 validates this.

Hook surfaces (9 intercept_* methods):

  intercept_inline_completion(request)
    Zed Predict / Zeta model auto-complete.
    In zed-local-only + local_only_enforcement: denied unless localProvider flag.

  intercept_chat(request)
    Assistant panel chat prompt.

  intercept_assistant_thread(request)
    Threaded conversation context (multi-turn assistant panel).

  intercept_slash_command(request)
    Slash commands: /explain, /refactor, /test, /diagnose, /migrate, etc.
    Denied if command not in slash_command_allow_list (when set).

  intercept_inline_transform(request)
    cmd-Enter inline transform of selected code.

  intercept_terminal_assist(request)
    Zed integrated terminal AI (assistant: terminal config).
    Requires allow_terminal_assist=True.
    When allowed_terminal_prefixes is set, command must match a prefix.

  intercept_file_context(request)
    Zed adds a file to assistant context (sent to LLM provider).
    Always scanned for secrets. Denied with zed-file-context-secret-detected.

  intercept_multi_buffer_edit(request)
    Simultaneous edits across multiple Zed buffers.
    Denied when buffer count > multi_buffer_edit_cap.

  intercept_voice_input(request)
    Voice mode input. Denied unless allow_voice_input=True.

Pen-test IDs:
  PT-ADAPT-ZED-1: empty pack_binding denied at every intercept call
  PT-ADAPT-ZED-2: API keys / Zed auth tokens never echoed in audit entries
  PT-ADAPT-ZED-3: malformed config raises ValueError at construction
                  (invalid mode, negative cap, local_only_enforcement=False
                  with zed-local-only mode)
  PT-ADAPT-ZED-4: local-only mode + network-egress feature ALWAYS denied
                  (even with explicit opt-in flags trying to override)
  PT-ADAPT-ZED-5: file context with .env content denied with
                  zed-file-context-secret-detected

Spec: P3-SUB-IDE-11

Usage::

    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.zed_ai import ZedAIGovernedClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )
    client = ZedAIGovernedClient(
        client=gov,
        agent_name="zed-agent",
        pack_binding=["soc2"],
        deployment_mode="zed-cloud",
        allow_terminal_assist=True,
        allowed_terminal_prefixes=["npm ", "npx "],
    )

    decision = client.intercept_chat({
        "prompt": "Explain this function",
        "packBinding": ["soc2"],
    })
"""

from __future__ import annotations

import re
import uuid
from typing import Any, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Valid deployment modes
# ---------------------------------------------------------------------------

ZED_VALID_DEPLOYMENT_MODES: tuple[str, ...] = (
    "zed-cloud",
    "zed-byok",
    "zed-local-only",
)

# ---------------------------------------------------------------------------
# Secret scan patterns
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("AWS access key",           re.compile(r"AKIA[0-9A-Z]{16}")),
    ("AWS secret key",           re.compile(r"aws_secret_access_key\s*=\s*\S{20,}", re.IGNORECASE)),
    ("GitHub PAT",               re.compile(r"ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82}")),
    ("Anthropic API key",        re.compile(r"sk-ant-[0-9A-Za-z\-_]{20,}")),
    ("OpenAI API key",           re.compile(r"sk-[0-9A-Za-z]{20,}")),
    ("Zed auth token",           re.compile(r"zed_[0-9A-Za-z\-_]{20,}")),
    ("Generic secret env var",   re.compile(r"(SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY|ACCESS_TOKEN)\w*\s*=\s*[\"']?\S{8,}[\"']?", re.IGNORECASE)),
    ("Bearer token",             re.compile(r"Authorization:\s*Bearer\s+[0-9A-Za-z\-._~+/]{20,}", re.IGNORECASE)),
    ("Database URL with creds",  re.compile(r"(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@")),
    ("env file marker",          re.compile(r"^(export\s+)?(SECRET|PASSWORD|PASSWD|API_KEY|TOKEN|KEY)\w*=\S", re.IGNORECASE | re.MULTILINE)),
]

# ---------------------------------------------------------------------------
# Valid event types forwarded to the governance REST API
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _scan_for_secrets(text: str) -> Optional[str]:
    """Return name of first matched secret pattern, or None."""
    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(text):
            return name
    return None


def _sanitize_secret_from_audit(text: str) -> str:
    """Replace any matched secret values with [REDACTED]."""
    out = text
    for _name, pattern in _SECRET_PATTERNS:
        out = pattern.sub("[REDACTED]", out)
    return out


def _is_local_provider(request: dict[str, Any]) -> bool:
    """Return True if the request signals use of a local (on-device) provider."""
    return bool(request.get("localProvider", False))


# ---------------------------------------------------------------------------
# ZedAIGovernedClient
# ---------------------------------------------------------------------------

class ZedAIGovernedClient(BaseGovernanceIntegration):
    """Governance client for Zed AI assistant sessions.

    Mirrors ZedAIAdapter (TypeScript) method-for-method.

    Configuration:
        deployment_mode: 'zed-cloud' | 'zed-byok' | 'zed-local-only'
        local_only_enforcement: bool (default True; zed-local-only only;
            cannot be False in zed-local-only -- raises ValueError)
        allow_terminal_assist: bool (default False)
        allowed_terminal_prefixes: list[str] (restrict terminal to prefixes)
        allow_voice_input: bool (default False)
        multi_buffer_edit_cap: int (default 15)
        slash_command_allow_list: list[str] | None (restrict slash commands)
    """

    _FRAMEWORK_NAME = "zed-ai"
    _LAYER_NAME = "zed-ai-governed-client"
    _VALID_EVENT_TYPES = _VALID_EVENT_TYPES

    def __init__(
        self,
        client: GovernanceClient,
        agent_name: str,
        agent_role: Optional[str] = None,
        pack_binding: Optional[list[str]] = None,
        deployment_mode: str = "zed-cloud",
        local_only_enforcement: bool = True,
        allow_terminal_assist: bool = False,
        allowed_terminal_prefixes: Optional[list[str]] = None,
        allow_voice_input: bool = False,
        multi_buffer_edit_cap: int = 15,
        slash_command_allow_list: Optional[list[str]] = None,
    ) -> None:
        """Initialise the Zed AI governed client.

        Args:
            client: Configured GovernanceClient.
            agent_name: Agent name for audit attribution.
            agent_role: Optional role description.
            pack_binding: Compliance packs governing this agent.
            deployment_mode: Zed AI deployment context.
            local_only_enforcement: Enforce local-only isolation in
                zed-local-only mode. Cannot be False in zed-local-only --
                raises ValueError (PT-ADAPT-ZED-3).
            allow_terminal_assist: Permit Zed terminal AI surface.
            allowed_terminal_prefixes: Restrict terminal commands to prefixes.
            allow_voice_input: Permit Zed voice mode input.
            multi_buffer_edit_cap: Max buffers in a single multi-buffer edit.
            slash_command_allow_list: When set, restricts slash commands to
                only those in this list.

        Raises:
            ValueError: On any invalid configuration combination.
        """
        super().__init__(client)

        # Validate deployment mode
        if deployment_mode not in ZED_VALID_DEPLOYMENT_MODES:
            raise ValueError(
                f"ZedAIGovernedClient: invalid deployment_mode '{deployment_mode}'. "
                f"Valid modes: {', '.join(ZED_VALID_DEPLOYMENT_MODES)}."
            )

        # PT-ADAPT-ZED-3: local_only_enforcement=False rejected in zed-local-only mode.
        # The combination creates an ambiguous privacy contract.
        if deployment_mode == "zed-local-only" and not local_only_enforcement:
            raise ValueError(
                "ZedAIGovernedClient: local_only_enforcement=False is not permitted "
                "in zed-local-only mode. Disabling enforcement while using the "
                "local-only mode creates an ambiguous privacy contract: users expect "
                "all data to stay on-device but the adapter would not enforce it. "
                "Either use zed-cloud or zed-byok mode (where network egress is "
                "expected), or keep local_only_enforcement=True (the default) in "
                "zed-local-only mode."
            )

        # Validate numeric cap
        if not isinstance(multi_buffer_edit_cap, int) or multi_buffer_edit_cap < 1:
            raise ValueError(
                f"ZedAIGovernedClient: multi_buffer_edit_cap must be a positive "
                f"integer, got: {multi_buffer_edit_cap!r}."
            )

        self.agent_name = agent_name
        self.agent_role = agent_role
        self.pack_binding: list[str] = pack_binding or []
        self.deployment_mode = deployment_mode
        self.local_only_enforcement = local_only_enforcement
        self.allow_terminal_assist = allow_terminal_assist
        self.allowed_terminal_prefixes: list[str] = allowed_terminal_prefixes or []
        self.allow_voice_input = allow_voice_input
        self.multi_buffer_edit_cap = multi_buffer_edit_cap
        # Normalise: empty list is treated as None (no restriction)
        self.slash_command_allow_list: Optional[list[str]] = (
            slash_command_allow_list if slash_command_allow_list else None
        )

    # ------------------------------------------------------------------
    # intercept_inline_completion
    # ------------------------------------------------------------------

    def intercept_inline_completion(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a Zed Predict / Zeta model inline completion suggestion.

        In zed-local-only mode with local_only_enforcement=True, the request
        must carry localProvider=True to pass.

        Args:
            request: dict with keys: prompt, packBinding, localProvider (optional).

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        prompt = str(request.get("prompt", ""))

        # PT-ADAPT-ZED-1
        if not pack_binding:
            return self._deny(agent_id, "zed-inline-completion-no-pack-binding: request carries no pack binding.")

        # PT-ADAPT-ZED-4: local-only enforcement
        local_deny = self._check_local_only(agent_id, request, "inline-completion", pack_binding)
        if local_deny is not None:
            return local_deny

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:inline-completion",
            "args": {"promptLength": len(prompt), "mode": self.deployment_mode},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_chat
    # ------------------------------------------------------------------

    def intercept_chat(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a Zed assistant panel chat prompt.

        Args:
            request: dict with keys: prompt, packBinding, localProvider (optional).

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        prompt = str(request.get("prompt", ""))

        if not pack_binding:
            return self._deny(agent_id, "zed-chat-no-pack-binding: chat request carries no pack binding.")

        local_deny = self._check_local_only(agent_id, request, "chat", pack_binding)
        if local_deny is not None:
            return local_deny

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:chat",
            "args": {"promptLength": len(prompt), "mode": self.deployment_mode},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_assistant_thread
    # ------------------------------------------------------------------

    def intercept_assistant_thread(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a Zed assistant threaded conversation request.

        Args:
            request: dict with keys: prompt, threadId, packBinding,
                     localProvider (optional).

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        prompt = str(request.get("prompt", ""))
        thread_id = str(request.get("threadId", ""))

        if not pack_binding:
            return self._deny(agent_id, "zed-assistant-thread-no-pack-binding: request carries no pack binding.")

        local_deny = self._check_local_only(agent_id, request, "assistant-thread", pack_binding)
        if local_deny is not None:
            return local_deny

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:assistant-thread",
            "args": {"promptLength": len(prompt), "threadId": thread_id, "mode": self.deployment_mode},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_slash_command
    # ------------------------------------------------------------------

    def intercept_slash_command(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a Zed slash command (/explain, /refactor, /test, etc.).

        When slash_command_allow_list is set, only listed commands pass.

        Args:
            request: dict with keys: command, args, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        command = str(request.get("command", "")).lstrip("/").strip().lower()
        args = str(request.get("args", ""))

        if not pack_binding:
            return self._deny(agent_id, "zed-slash-command-no-pack-binding: request carries no pack binding.")

        # Allow-list enforcement
        if self.slash_command_allow_list is not None:
            normalised_allow = [c.lstrip("/").lower() for c in self.slash_command_allow_list]
            if command not in normalised_allow:
                return self._deny(
                    agent_id,
                    f"zed-slash-command-not-allowed: slash command '/{command}' denied -- "
                    f"not in slash_command_allow_list. "
                    f"Allowed commands: [{', '.join(repr(c) for c in self.slash_command_allow_list)}].",
                    pack_binding=pack_binding,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:slash-command",
            "args": {"command": command, "args": args},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_inline_transform
    # ------------------------------------------------------------------

    def intercept_inline_transform(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate a Zed cmd-Enter inline transform of selected code.

        Args:
            request: dict with keys: selection, instruction, packBinding,
                     localProvider (optional).

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        selection = str(request.get("selection", ""))
        instruction = str(request.get("instruction", ""))

        if not pack_binding:
            return self._deny(agent_id, "zed-inline-transform-no-pack-binding: request carries no pack binding.")

        local_deny = self._check_local_only(agent_id, request, "inline-transform", pack_binding)
        if local_deny is not None:
            return local_deny

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:inline-transform",
            "args": {
                "selectionLength": len(selection),
                "instructionLength": len(instruction),
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_terminal_assist
    # ------------------------------------------------------------------

    def intercept_terminal_assist(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate Zed integrated terminal AI surface.

        Layers (in order):
          1. local-only enforcement (PT-ADAPT-ZED-4)
          2. opt-in required (allow_terminal_assist must be True)
          3. prefix allowlist (if allowed_terminal_prefixes is set)

        Args:
            request: dict with keys: command, packBinding, localProvider (optional).

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        command = str(request.get("command", ""))

        if not pack_binding:
            return self._deny(agent_id, "zed-terminal-assist-no-pack-binding: request carries no pack binding.")

        # PT-ADAPT-ZED-4: local-only enforcement before opt-in check.
        # allow_terminal_assist=True cannot override local-only mode.
        local_deny = self._check_local_only(agent_id, request, "terminal-assist", pack_binding)
        if local_deny is not None:
            return local_deny

        # Opt-in required
        if not self.allow_terminal_assist:
            return self._deny(
                agent_id,
                "zed-terminal-assist-not-permitted: terminal assist denied -- "
                "allow_terminal_assist is False. Zed terminal AI can execute "
                "arbitrary commands. Set allow_terminal_assist=True in "
                "ZedAIGovernedClient to enable this surface.",
                pack_binding=pack_binding,
            )

        # Prefix allowlist
        if self.allowed_terminal_prefixes:
            trimmed = command.strip()
            prefix_match = any(trimmed.startswith(p) for p in self.allowed_terminal_prefixes)
            if not prefix_match:
                return self._deny(
                    agent_id,
                    f"zed-terminal-assist-prefix-not-allowed: terminal assist denied -- "
                    f"no allowed prefix matched for '{trimmed[:80]}'. "
                    f"Allowed prefixes: [{', '.join(repr(p) for p in self.allowed_terminal_prefixes)}].",
                    pack_binding=pack_binding,
                )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:terminal-assist",
            "args": {"commandLength": len(command)},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_file_context
    # ------------------------------------------------------------------

    def intercept_file_context(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate Zed adding a file to the assistant context (sent to LLM).

        Always scanned for secrets. Denied with zed-file-context-secret-detected
        on finding. PT-ADAPT-ZED-5: .env content denied regardless of intent.

        Args:
            request: dict with keys: filePath, content, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        file_path = str(request.get("filePath", ""))
        content = str(request.get("content", ""))

        if not pack_binding:
            return self._deny(agent_id, "zed-file-context-no-pack-binding: request carries no pack binding.")

        # Secret scan always applied (PT-ADAPT-ZED-5)
        finding = _scan_for_secrets(content)
        if finding:
            # PT-ADAPT-ZED-2: never echo secret value in audit entry
            sanitized_path = _sanitize_secret_from_audit(file_path)
            return self._deny(
                agent_id,
                f"zed-file-context-secret-detected: file context blocked -- secret pattern "
                f"'{finding}' detected in content of '{sanitized_path}'. "
                "Adding this file to Zed AI context would transmit secrets to the "
                "LLM provider. Remove the secret from the file before adding it "
                "to the assistant context.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:file-context",
            "args": {"filePath": file_path, "contentLength": len(content)},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_multi_buffer_edit
    # ------------------------------------------------------------------

    def intercept_multi_buffer_edit(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate Zed multi-buffer editor operation.

        Denied when buffer count exceeds multi_buffer_edit_cap.

        Args:
            request: dict with keys: bufferPaths, instruction, packBinding.

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        buffer_paths = request.get("bufferPaths", [])
        instruction = str(request.get("instruction", ""))
        buffer_count = len(buffer_paths) if isinstance(buffer_paths, list) else 0

        if not pack_binding:
            return self._deny(agent_id, "zed-multi-buffer-edit-no-pack-binding: request carries no pack binding.")

        if buffer_count > self.multi_buffer_edit_cap:
            return self._deny(
                agent_id,
                f"zed-multi-buffer-edit-cap-exceeded: multi-buffer edit denied -- "
                f"buffer count ({buffer_count}) exceeds multi_buffer_edit_cap "
                f"({self.multi_buffer_edit_cap}). Reduce the number of buffers or "
                "raise multi_buffer_edit_cap.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:multi-buffer-edit",
            "args": {
                "bufferCount": buffer_count,
                "instructionLength": len(instruction),
            },
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # intercept_voice_input
    # ------------------------------------------------------------------

    def intercept_voice_input(self, request: dict[str, Any]) -> GovernanceDecision:
        """Gate Zed voice mode input.

        Layers (in order):
          1. local-only enforcement (PT-ADAPT-ZED-4) -- voice transcription
             typically routes through a network API even when the text model
             is local.
          2. opt-in required (allow_voice_input must be True)

        Args:
            request: dict with keys: transcribedText, packBinding,
                     localProvider (optional).

        Returns:
            GovernanceDecision.
        """
        agent_id = request.get("agentId", self.agent_name)
        pack_binding: list[str] = request.get("packBinding", self.pack_binding)
        transcribed_text = str(request.get("transcribedText", ""))

        if not pack_binding:
            return self._deny(agent_id, "zed-voice-input-no-pack-binding: request carries no pack binding.")

        # PT-ADAPT-ZED-4: local-only enforcement before opt-in check.
        local_deny = self._check_local_only(agent_id, request, "voice-input", pack_binding)
        if local_deny is not None:
            return local_deny

        if not self.allow_voice_input:
            return self._deny(
                agent_id,
                "zed-voice-input-not-permitted: voice input denied -- "
                "allow_voice_input is False. Voice transcription may contain PII "
                "and can route through external APIs. Set allow_voice_input=True "
                "in ZedAIGovernedClient to enable.",
                pack_binding=pack_binding,
            )

        return self.emit_event("toolCall", {
            "agentId": agent_id,
            "toolName": "zed-ai:voice-input",
            "args": {"transcribedLength": len(transcribed_text)},
            "packBinding": pack_binding,
        })

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API."""
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown Zed AI event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )
        enriched = {"deploymentMode": self.deployment_mode, **payload}
        return super().emit_event(event_type, enriched)

    # ------------------------------------------------------------------
    # policy_bridge
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> "ZedAIPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation."""
        return ZedAIPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _check_local_only(
        self,
        agent_id: str,
        request: dict[str, Any],
        surface: str,
        pack_binding: list[str],
    ) -> Optional[GovernanceDecision]:
        """Check local-only enforcement.

        Returns a DENY GovernanceDecision if enforcement applies, or None
        to continue. This is called BEFORE opt-in checks in every intercept
        method -- PT-ADAPT-ZED-4 ensures opt-in flags cannot override it.
        """
        if self.deployment_mode != "zed-local-only":
            return None
        if not self.local_only_enforcement:
            return None  # only possible if not zed-local-only (validated at init)

        if not _is_local_provider(request):
            return self._deny(
                agent_id,
                f"zed-local-only-network-not-permitted: {surface} denied in "
                "zed-local-only mode -- request does not carry localProvider=True. "
                "In zed-local-only mode with local_only_enforcement enabled, all "
                "AI surfaces require the request to signal local provider use "
                "(localProvider=True). This prevents data from being inadvertently "
                "routed to a network-based LLM provider.",
                pack_binding=pack_binding,
            )

        return None

    def _deny(
        self,
        agent_id: str,
        reason: str,
        pack_binding: Optional[list[str]] = None,
    ) -> GovernanceDecision:
        from connexum_governance.models import GovernanceDecision, DecisionType
        d = GovernanceDecision(
            decision=DecisionType.DENY,
            reason=reason,
            audit_id=str(uuid.uuid4()),
        )
        if self.client.enforce:
            raise GovernanceViolation(d)
        return d


# ---------------------------------------------------------------------------
# ZedAIPolicyBridge
# ---------------------------------------------------------------------------

class ZedAIPolicyBridge:
    """Bridge for Python-hosted policy participation in the Zed AI governance loop."""

    def __init__(
        self,
        adapter: ZedAIGovernedClient,
        pack_binding: list[str],
        decision_callback: Any,
    ) -> None:
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:
                import logging as _logging
                _logging.getLogger(__name__).warning(
                    "Governance audit operation failed: %s", exc
                )
        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })
