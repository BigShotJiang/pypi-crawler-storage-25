"""Paperclip integration for Connexum governance.

This framework is TypeScript-native. This integration is a REST shim so a
Python governance policy can sit in front of a Node orchestrator. See
`src/orchestrator-adapters/paperclip-adapter.ts` for the primary adapter.

Paperclip is Connexum's own internal orchestrator -- this is the tightest
integration. The Python shim exposes the canonical six-hook governance event
surface, a replay_policy() convenience for decision replays, and a
policy_bridge() helper for Python policy participation.

Architecture:
  Paperclip's four internal event types (task, plan, delegation, action) are
  dual-emitted: once to Paperclip's internal audit trail and once as a
  canonical event from the governance taxonomy. This Python shim mirrors that
  dual-emission pattern.

  Because Paperclip is our own orchestrator, the event schema is well-defined:
    task       -> maps to agentStart / toolCall / toolResult
    plan       -> maps to llmCall / llmResult
    delegation -> maps to agentEnd / policy relay
    action     -> maps to any hook surface per Paperclip's action type

  Python-hosted policy engine participation:
    adapter = PaperclipGovernance(client=gov, ...)
    adapter.emit_event("agentStart", {...})          # forward event
    adapter.wrap_webhook(request_body)               # validate + forward
    adapter.replay_policy(decision_id)               # replay decision

Canonical event shape for each hook:
  agentStart -> {"eventType": "agentStart", "agentId": ..., "packBinding": [...], ...}
  toolCall   -> {"eventType": "toolCall",   "agentId": ..., "toolName": ..., ...}
  toolResult -> {"eventType": "toolResult", "agentId": ..., "toolName": ..., ...}
  llmCall    -> {"eventType": "llmCall",    "agentId": ..., "model": ..., ...}
  llmResult  -> {"eventType": "llmResult",  "agentId": ..., "model": ..., ...}
  agentEnd   -> {"eventType": "agentEnd",   "agentId": ..., "success": ..., ...}

Paperclip-specific:
  replay_policy(decision_id) -- request a replay of a prior governance decision.
  check_task_type(task_type) -- validate that a task type is in the allowed list.
  check_delegation_policy()  -- enforce delegation policy (open vs restricted).

Usage:
    from connexum_governance import GovernanceClient
    from connexum_governance.integrations.paperclip import PaperclipGovernance

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    adapter = PaperclipGovernance(
        client=gov,
        allowed_task_types=["analysis", "summarization", "search"],
        max_plan_steps=10,
        delegation_policy="restricted",
        sensitive_tools=["exec_code", "write_file"],
    )

    # Forward canonical events from the Paperclip TS runtime:
    adapter.emit_event("agentStart", {
        "agentId": "paperclip-agent-01",
        "packBinding": ["hipaa", "soc2"],
        "model": "claude-haiku-4-5",
    })

    # Replay a prior decision:
    decision = adapter.replay_policy("decision-uuid-here")
"""

from __future__ import annotations

import re
import sys
import uuid
from typing import Any, Callable, Optional

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceDecision, GovernanceViolation
from connexum_governance.integrations._base import BaseGovernanceIntegration


# ---------------------------------------------------------------------------
# Error classes
# ---------------------------------------------------------------------------

class PaperclipTaskTypeError(RuntimeError):
    """Raised when a task type is not in the allowed list."""

    def __init__(self, task_type: str, allowed: list[str]):
        super().__init__(
            f'Paperclip task type "{task_type}" is not in the allowed task types list. '
            f"Allowed: {', '.join(allowed)}"
        )
        self.task_type = task_type
        self.allowed = allowed


class PaperclipPlanStepsError(RuntimeError):
    """Raised when a plan exceeds the maximum allowed steps."""

    def __init__(self, step_count: int, max_steps: int):
        super().__init__(
            f"Paperclip plan has {step_count} steps, exceeding the maximum of {max_steps}."
        )
        self.step_count = step_count
        self.max_steps = max_steps


# ---------------------------------------------------------------------------
# PHI helpers
# ---------------------------------------------------------------------------

_PHI_RE = re.compile(
    r"(\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
    r"|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{1,4}\b"
    r"|\b(patient_id|mrn|dob|date_of_birth|diagnosis|ssn|npi)\s*[:=])",
    re.IGNORECASE,
)


def _contains_phi(text: str) -> bool:
    return bool(_PHI_RE.search(text))


# ---------------------------------------------------------------------------
# Canonical event type set
# ---------------------------------------------------------------------------

_VALID_EVENT_TYPES = frozenset({
    "agentStart",
    "toolCall",
    "toolResult",
    "llmCall",
    "llmResult",
    "agentEnd",
    # Paperclip internal event type mappings
    "task",
    "plan",
    "delegation",
    "action",
})


# ---------------------------------------------------------------------------
# PaperclipGovernance
# ---------------------------------------------------------------------------

class PaperclipGovernance(BaseGovernanceIntegration):
    """REST-client shim for Paperclip governance.

    Paperclip is TypeScript-native but is Connexum's own orchestrator, making
    this the tightest Python-side integration. The shim:
      1. Forwards canonical events to the governance REST API
      2. Translates Paperclip's internal event types (task/plan/delegation/action)
         to canonical governance hook surfaces
      3. Provides replay_policy() for decision replay support
      4. Provides policy_bridge() for Python policy participation
    """

    _FRAMEWORK_NAME = "paperclip"
    _LAYER_NAME = "paperclip-rest-shim"
    # delegation is a Paperclip-internal event type exempt from pack-binding primacy
    _EXEMPT_EVENT_TYPES: frozenset[str] = frozenset({"agentEnd", "delegation"})

    def __init__(
        self,
        client: GovernanceClient,
        allowed_task_types: Optional[list[str]] = None,
        max_plan_steps: int = 20,
        delegation_policy: str = "open",
        sensitive_tools: Optional[list[str]] = None,
        sensitive_arg_keys: Optional[list[str]] = None,
        approved_models: Optional[list[str]] = None,
        audit_enabled: bool = True,
    ):
        """
        Args:
            client: Configured GovernanceClient.
            allowed_task_types: Task types this adapter allows.
                                Empty list allows all task types.
            max_plan_steps: Maximum steps in a Paperclip plan.
            delegation_policy: "open" allows all delegations; "restricted" checks
                               permissions against sensitive_tools.
            sensitive_tools: Tool names that are always denied or require approval
                             regardless of other rules.
            sensitive_arg_keys: Argument keys to scan for PHI.
            approved_models: LLM model IDs approved for use.
            audit_enabled: Emit audit events for all lifecycle hooks.
        """
        super().__init__(client)
        self.allowed_task_types = allowed_task_types or []
        self.max_plan_steps = max_plan_steps
        self.delegation_policy = delegation_policy
        self.sensitive_tools = sensitive_tools or []
        self.sensitive_arg_keys = sensitive_arg_keys or ["query", "content", "message", "body"]
        self.approved_models = approved_models or []
        self.audit_enabled = audit_enabled

        # In-memory audit trail (mirrors PaperclipAdapter.auditTrail in TS)
        self._audit_trail: list[dict[str, Any]] = []
        # Decision cache for replay support.
        # C4 fix: keyed on (decision_id, org_id, agent_id) tuple to prevent
        # cross-tenant replay attacks. An org-B token cannot replay an org-A
        # ALLOW decision by supplying the decision_id.
        self._decision_cache: dict[tuple[str, str, str], GovernanceDecision] = {}
        # Parallel map decision_id -> (org_id, agent_id) for reverse lookup
        self._decision_meta: dict[str, tuple[str, str]] = {}

    # ------------------------------------------------------------------
    # emit_event -- forward canonical event to governance REST API
    # ------------------------------------------------------------------

    def emit_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> GovernanceDecision:
        """Forward a canonical governance event to the REST API.

        Runs local guard checks before forwarding. Also maintains the internal
        Paperclip audit trail (dual-emission pattern).

        Args:
            event_type: Canonical or Paperclip-internal event type.
            payload: Event-specific payload.

        Returns:
            GovernanceDecision from the governance API.
        """
        if event_type not in _VALID_EVENT_TYPES:
            raise ValueError(
                f'Unknown Paperclip event type: "{event_type}". '
                f"Valid types: {sorted(_VALID_EVENT_TYPES)}"
            )

        agent_id = payload.get("agentId", "paperclip-agent")
        pack_binding: list[str] = payload.get("packBinding", [])

        # Provider compliance for llmCall
        if event_type == "llmCall":
            model = payload.get("model", "")
            if self.approved_models and model not in self.approved_models:
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f'Paperclip LLM model "{model}" is not on the approved provider list. '
                    f"Approved: {', '.join(self.approved_models)}"
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                self._record_audit(event_type, "DENY", reason, payload)
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # Task type validation
        if event_type in ("task", "agentStart"):
            task_type = payload.get("taskType", "")
            if self.allowed_task_types and task_type and task_type not in self.allowed_task_types:
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f'Paperclip task type "{task_type}" is not in the allowed task types list. '
                    f"Allowed: {', '.join(self.allowed_task_types)}"
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                self._record_audit(event_type, "DENY", reason, payload)
                if self.client.enforce:
                    raise PaperclipTaskTypeError(task_type, self.allowed_task_types)
                return d

        # Plan step count validation
        if event_type == "plan":
            step_count = payload.get("stepCount", 0)
            if step_count > self.max_plan_steps:
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f"Paperclip plan has {step_count} steps, exceeding max_plan_steps ({self.max_plan_steps})."
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                self._record_audit(event_type, "DENY", reason, payload)
                if self.client.enforce:
                    raise PaperclipPlanStepsError(step_count, self.max_plan_steps)
                return d

        # Delegation policy enforcement
        if event_type == "delegation" and self.delegation_policy == "restricted":
            permissions = payload.get("permissions", [])
            restricted = [p for p in permissions if p in self.sensitive_tools]
            if restricted:
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f"Paperclip delegation includes restricted permissions: {', '.join(restricted)}"
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                self._record_audit(event_type, "DENY", reason, payload)
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # PHI scan on tool call args
        if event_type in ("toolCall", "action"):
            args = payload.get("args", {})
            exfil_key = self._scan_args(args)
            if exfil_key:
                from connexum_governance.models import GovernanceDecision, DecisionType
                tool_name = payload.get("toolName", payload.get("actionType", "unknown"))
                reason = (
                    f'Possible data exfiltration in Paperclip event "{event_type}" args '
                    f'(key: "{exfil_key}"). Blocked at G5/G7 egress guard.'
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                self._record_audit(event_type, "DENY", reason, payload)
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # Output classifier for tool results
        if event_type == "toolResult":
            result_text = str(payload.get("result", ""))
            if _contains_phi(result_text):
                print(
                    f"[GOVERNANCE] Paperclip output classifier: possible PHI in "
                    f'tool result "{payload.get("toolName", "unknown")}" (agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Output exfiltration scanner for LLM results
        if event_type == "llmResult":
            response_text = str(payload.get("responseText", ""))
            if _contains_phi(response_text):
                print(
                    f"[GOVERNANCE] Paperclip output exfiltration scanner: possible PHI in "
                    f'LLM response (model: {payload.get("model", "unknown")}, agent: {agent_id}).',
                    file=sys.stderr,
                )

        # Sensitive tool gating (always DENY for tools in sensitive_tools)
        if event_type in ("toolCall", "action"):
            tool_name = payload.get("toolName", payload.get("actionType", ""))
            if tool_name in self.sensitive_tools:
                from connexum_governance.models import GovernanceDecision, DecisionType
                reason = (
                    f'Paperclip tool/action "{tool_name}" is in the sensitive_tools list. '
                    "Blocked regardless of other rules."
                )
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=reason,
                    audit_id=str(uuid.uuid4()),
                )
                self._record_audit(event_type, "DENY", reason, payload)
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

        # Dispatch via base class (pack-binding primacy + REST + audit correlation)
        decision = super().emit_event(event_type, payload)

        # Paperclip-specific: record in internal dual-emission audit trail
        self._record_audit(event_type, decision.decision.value, decision.reason, payload)

        if decision.audit_id:
            # C4 fix: cache on (decision_id, org_id, agent_id) tuple to prevent
            # cross-tenant replay. org_id comes from the GovernanceClient's
            # configured org_id; agent_id is the agent that triggered the event.
            org_id = getattr(self.client, "org_id", "") or ""
            cache_key = (decision.audit_id, org_id, agent_id)
            self._decision_cache[cache_key] = decision
            self._decision_meta[decision.audit_id] = (org_id, agent_id)

        return decision

    # ------------------------------------------------------------------
    # wrap_webhook -- validate + forward inbound webhook from Paperclip TS
    # ------------------------------------------------------------------

    def wrap_webhook(
        self,
        request_body: dict[str, Any],
    ) -> GovernanceDecision:
        """Accept a JSON payload from the Paperclip TS runtime and forward it.

        Args:
            request_body: Parsed JSON body from the inbound webhook.

        Returns:
            GovernanceDecision to serialise and return as the HTTP response.

        Raises:
            ValueError: Required fields missing.
        """
        event_type = request_body.get("eventType")
        if not event_type:
            raise ValueError("Paperclip webhook payload missing required field: 'eventType'")

        agent_id = request_body.get("agentId")
        if not agent_id:
            raise ValueError("Paperclip webhook payload missing required field: 'agentId'")

        return self.emit_event(str(event_type), dict(request_body))

    # ------------------------------------------------------------------
    # policy_bridge -- Python policy participation
    # ------------------------------------------------------------------

    def policy_bridge(
        self,
        pack_binding: list[str],
        decision_callback: Optional[Callable] = None,
    ) -> "PaperclipPolicyBridge":
        """Return a policy bridge for Python-hosted policy participation.

        Because Paperclip is our own orchestrator, this bridge is tighter than
        the generic shim: it maintains pack binding context and can call the
        Python policy directly before forwarding to the REST API.

        Args:
            pack_binding: Pack binding that governs decisions via this bridge.
            decision_callback: Optional callable(event_type, payload) -> GovernanceDecision or None.

        Returns:
            PaperclipPolicyBridge instance.
        """
        return PaperclipPolicyBridge(
            adapter=self,
            pack_binding=pack_binding,
            decision_callback=decision_callback,
        )

    # ------------------------------------------------------------------
    # replay_policy -- decision replay for Paperclip
    # ------------------------------------------------------------------

    def replay_policy(
        self,
        decision_id: str,
        override_payload: Optional[dict[str, Any]] = None,
        requesting_agent_id: Optional[str] = None,
    ) -> GovernanceDecision:
        """Request a replay of a prior governance decision.

        Paperclip can ask a Python policy for a decision replay when it needs
        to re-evaluate a governance decision (e.g., after a policy change or
        for audit purposes).

        C4 fix: The cache is keyed on (decision_id, org_id, agent_id). Before
        returning a cached decision, the caller's org_id (derived from the
        GovernanceClient JWT token via client.org_id) is compared to the
        org_id that was current when the decision was first cached. If they
        differ, GovernanceViolation is raised to block cross-tenant replay.

        Args:
            decision_id: The audit_id / decision_id to replay.
            override_payload: Optional additional context for the replay.
            requesting_agent_id: The agent_id of the requestor. Used to scope
                the cache key. Defaults to "paperclip-replay" if not supplied.

        Returns:
            GovernanceDecision (cached or freshly evaluated).

        Raises:
            GovernanceViolation: if the requesting org_id does not match the
                org_id that originally issued the decision (cross-tenant replay
                blocked).
        """
        caller_org_id = getattr(self.client, "org_id", "") or ""
        agent_id = requesting_agent_id or "paperclip-replay"

        # C4: Check if we have the decision cached for any org.
        if decision_id in self._decision_meta:
            cached_org_id, cached_agent_id = self._decision_meta[decision_id]
            # Re-verify org_id matches.
            if cached_org_id and cached_org_id != caller_org_id:
                from connexum_governance.models import GovernanceDecision, DecisionType
                d = GovernanceDecision(
                    decision=DecisionType.DENY,
                    reason=(
                        f"cross-tenant replay blocked: decision '{decision_id}' was issued "
                        f"for org '{cached_org_id}' but replayed by org '{caller_org_id}'. "
                        "(C4: PaperclipGovernance replay_policy cross-tenant protection)"
                    ),
                    audit_id=str(uuid.uuid4()),
                )
                self._record_audit("replayPolicy", "DENY", d.reason, {
                    "decisionId": decision_id,
                    "callerOrgId": caller_org_id,
                    "cachedOrgId": cached_org_id,
                })
                if self.client.enforce:
                    raise GovernanceViolation(d)
                return d

            # org_id matches -- return cached decision
            cache_key = (decision_id, cached_org_id, cached_agent_id)
            if cache_key in self._decision_cache:
                return self._decision_cache[cache_key]

        # Not in cache -- issue a replay request to the governance API
        agent = AgentIdentity(name=agent_id)
        decision = self.client.check_action(
            tool="paperclip.replayPolicy",
            input={
                "decisionId": decision_id,
                "replayRequest": True,
                "framework": "paperclip",
                **(override_payload or {}),
            },
            agent=agent,
        )

        if decision.audit_id:
            cache_key = (decision.audit_id, caller_org_id, agent_id)
            self._decision_cache[cache_key] = decision
            self._decision_meta[decision.audit_id] = (caller_org_id, agent_id)

        return decision

    # ------------------------------------------------------------------
    # get_audit_trail -- return Paperclip-internal audit trail
    # ------------------------------------------------------------------

    def get_audit_trail(self) -> list[dict[str, Any]]:
        """Return the Paperclip-internal audit trail.

        Mirrors PaperclipAdapter.getAuditTrail() from the TS adapter.
        """
        return list(self._audit_trail)

    # ------------------------------------------------------------------
    # Convenience hook methods (six canonical surfaces)
    # ------------------------------------------------------------------

    def agent_start(self, agent_id: str, pack_binding: list[str],
                    task_type: Optional[str] = None, model: Optional[str] = None,
                    **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit agentStart canonical event."""
        payload: dict[str, Any] = {
            "agentId": agent_id, "packBinding": pack_binding,
        }
        if task_type:
            payload["taskType"] = task_type
        if model:
            payload["model"] = model
        payload.update(kwargs)
        return self.emit_event("agentStart", payload)

    def tool_call(self, agent_id: str, tool_name: str, args: dict[str, Any],
                  pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit toolCall canonical event."""
        return self.emit_event("toolCall", {
            "agentId": agent_id, "toolName": tool_name, "args": args,
            "packBinding": pack_binding or [], **kwargs
        })

    def tool_result(self, agent_id: str, tool_name: str, result: Any,
                    success: bool = True, pack_binding: Optional[list[str]] = None,
                    **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit toolResult canonical event."""
        return self.emit_event("toolResult", {
            "agentId": agent_id, "toolName": tool_name, "result": str(result),
            "success": success, "packBinding": pack_binding or [], **kwargs
        })

    def llm_call(self, agent_id: str, model: str, messages: list[dict[str, Any]],
                 pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit llmCall canonical event."""
        return self.emit_event("llmCall", {
            "agentId": agent_id, "model": model, "messageCount": len(messages),
            "packBinding": pack_binding or [], **kwargs
        })

    def llm_result(self, agent_id: str, model: str, response_text: str,
                   pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit llmResult canonical event."""
        return self.emit_event("llmResult", {
            "agentId": agent_id, "model": model, "responseText": response_text,
            "packBinding": pack_binding or [], **kwargs
        })

    def agent_end(self, agent_id: str, success: bool,
                  pack_binding: Optional[list[str]] = None, **kwargs: Any) -> GovernanceDecision:
        """Convenience: emit agentEnd canonical event."""
        return self.emit_event("agentEnd", {
            "agentId": agent_id, "success": success,
            "packBinding": pack_binding or [], **kwargs
        })

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _record_audit(
        self,
        event_type: str,
        decision: str,
        reason: str,
        context: dict[str, Any],
    ) -> None:
        """Record an event in the Paperclip-internal audit trail."""
        if not self.audit_enabled:
            return
        import datetime
        self._audit_trail.append({
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            "eventType": event_type,
            "decision": decision,
            "reason": reason,
            "context": {k: v for k, v in context.items() if k != "packBinding"},
        })

    def _scan_args(self, args: dict[str, Any]) -> Optional[str]:
        """Scan tool arguments for PHI patterns on sensitive keys."""
        for key in self.sensitive_arg_keys:
            value = args.get(key)
            if isinstance(value, str) and _contains_phi(value):
                return key
        return None


# ---------------------------------------------------------------------------
# PaperclipPolicyBridge
# ---------------------------------------------------------------------------

class PaperclipPolicyBridge:
    """Bridge for Python-hosted policy participation in the Paperclip decision loop.

    Tighter than the generic shim because Paperclip is our own orchestrator.
    Maintains pack binding context and supports Python-side decision injection.
    """

    def __init__(
        self,
        adapter: PaperclipGovernance,
        pack_binding: list[str],
        decision_callback: Optional[Callable] = None,
    ):
        self._adapter = adapter
        self.pack_binding = pack_binding
        self._callback = decision_callback

    def decide(self, event_type: str, payload: dict[str, Any]) -> GovernanceDecision:
        """Call Python policy callback, fall back to governance REST API if None."""
        if self._callback is not None:
            try:
                result = self._callback(event_type, payload)
                if result is not None:
                    return result
            except Exception as exc:  # H2: never swallow -- always log
                import logging as _logging; _logging.getLogger(__name__).warning("Governance audit operation failed: %s", exc)

        return self._adapter.emit_event(event_type, {
            "packBinding": self.pack_binding,
            **payload,
        })

    def replay(self, decision_id: str) -> GovernanceDecision:
        """Convenience: replay a prior governance decision via the adapter."""
        return self._adapter.replay_policy(decision_id)
