"""
connexum_governance.autowrap._patches -- per-provider monkey-patch logic.

Each ``_patch_<provider>()`` function:
  1. Checks whether the provider module is already in sys.modules.
  2. If so, replaces the public class(es) with a thin governed subclass.
  3. If not, installs an ``sys.meta_path`` finder that patches at import time.
  4. Is idempotent: patching a module that is already patched is a no-op.

Supported providers:
  openai       -- OpenAI (and Azure OpenAI)
  anthropic    -- Anthropic
  google       -- google.generativeai (Gemini AI Studio)
  bedrock      -- boto3/botocore session wrapping
  replicate    -- Replicate (Llama path A)
  huggingface  -- SKIP (no wrapper today; logs [SKIP])

Design:
  We patch the *class* on the module object so that ``from openai import
  OpenAI`` (which already ran) as well as future ``import openai`` (which
  hasn't run yet) both see the governed class.

  For modules already imported we mutate the ``sys.modules`` entry in-place.
  For modules not yet imported we register a lazy patcher via importlib's
  meta path.

  The governed wrapper preserves the original class's ``__name__`` in the
  repr but uses ``__class__.__name__ == 'Governed<Provider>'`` so tests can
  assert identity.

F-NEW-PRODUCT-AGENT-DIR-WRAPPER slice 3
@connexum/python-sdk
"""

from __future__ import annotations

import importlib
import importlib.abc
import importlib.machinery
import logging
import os
import sys
import types
from typing import Any, Optional

_log = logging.getLogger(__name__)

# Governance config loaded once at patch time.
_GOVERNANCE_CFG: Optional[dict[str, Any]] = None

# Track which modules have been patched to maintain idempotency.
_PATCHED_MODULES: set[str] = set()


# ----------------------------------------------------------------------------
# Governance config loader
# ----------------------------------------------------------------------------


def _load_governance_config() -> dict[str, Any]:
    """Load governance.json from cwd or CONNEXUM_GOVERNANCE_JSON env var.

    Returns a minimal open-policy stub when no config file is found, so
    that ``CONNEXUM_AUTOWRAP=1 python -c "from openai import OpenAI"``
    never crashes.
    """
    global _GOVERNANCE_CFG
    if _GOVERNANCE_CFG is not None:
        return _GOVERNANCE_CFG

    cfg_path = os.environ.get("CONNEXUM_GOVERNANCE_JSON") or os.path.join(
        os.getcwd(), "governance.json"
    )
    if os.path.isfile(cfg_path):
        try:
            import json

            with open(cfg_path, encoding="utf-8") as fh:
                _GOVERNANCE_CFG = json.load(fh)
                _log.debug("[connexum-autowrap] loaded governance config: %s", cfg_path)
                return _GOVERNANCE_CFG
        except Exception as exc:
            _log.warning("[connexum-autowrap] could not parse %s: %s -- using stub", cfg_path, exc)

    # Safe stub -- open policy, no packs required
    _GOVERNANCE_CFG = {
        "tenantId": "local-dev",
        "agents": [],
        "autowrap": {"packs": []},
    }
    return _GOVERNANCE_CFG


def _packs_for_provider(provider: str) -> list[str]:
    """Return pack list for a given provider from governance.json."""
    cfg = _load_governance_config()
    # Check per-agent overrides first
    for agent in cfg.get("agents", []):
        if agent.get("provider") == provider:
            return agent.get("packs", [])
    # Fall back to global autowrap packs
    return cfg.get("autowrap", {}).get("packs", [])


def _tenant_id() -> str:
    cfg = _load_governance_config()
    return cfg.get("tenantId", "local-dev")


# ----------------------------------------------------------------------------
# Lazy importer (meta path finder)
# Used for providers that have NOT been imported yet.
# ----------------------------------------------------------------------------


class _LazyPatcher(importlib.abc.MetaPathFinder):
    """Install a post-import hook for a not-yet-imported module."""

    def __init__(self, module_name: str, patch_fn: "Any") -> None:
        self._module_name = module_name
        self._patch_fn = patch_fn

    def find_spec(
        self,
        fullname: str,
        path: Any,  # noqa: ANN401
        target: Optional[types.ModuleType] = None,
    ) -> None:
        # We only intercept the exact module name, and only when it first loads.
        if fullname != self._module_name:
            return None
        # Remove ourselves to avoid recursive patching
        if self in sys.meta_path:
            sys.meta_path.remove(self)
        return None  # Let normal import machinery do the work

    def find_module(self, fullname: str, path: Any = None) -> None:  # type: ignore[override]
        return None  # Python 2 compat stub; not used on Python 3


def _register_lazy_patcher(module_name: str, patch_fn: "Any") -> None:
    """Register a post-import hook using sys.modules write-hook pattern.

    We abuse the fact that after normal import machinery loads the module
    Python sets sys.modules[name].  We install a MetaPathFinder that, after
    removal of itself, lets the real loader run, then applies the patch by
    monitoring sys.modules.

    Simpler approach: import the module now (trigger its load) and then
    immediately patch it.  The customers' code runs AFTER our bootstrap,
    so if we import-and-patch here the module is already in sys.modules
    with the governed class when their code runs.
    """
    try:
        mod = importlib.import_module(module_name)
        patch_fn(mod)
    except ImportError:
        # Provider not installed -- nothing to patch.
        _log.debug("[connexum-autowrap] %s not installed -- skipping patch", module_name)
    except Exception as exc:
        _log.warning("[connexum-autowrap] failed to patch %s: %s", module_name, exc)


# ----------------------------------------------------------------------------
# Governed wrapper factories
# Each factory returns a subclass of the original that records its wrapper
# identity while preserving ALL original behaviour (pass-through __init__).
# ----------------------------------------------------------------------------


def _make_governed_class(original_cls: type, provider: str) -> type:
    """Return a governed subclass of ``original_cls``.

    The subclass:
    * Is named ``Governed<OriginalName>`` for test assertions.
    * Delegates __init__ fully to the original.
    * Records ``_connexum_governed = True`` on the instance.
    * Preserves __module__ so repr looks correct.
    """
    governed_name = f"Governed{original_cls.__name__}"

    # Build a new class dynamically; we can't use the ``class`` statement
    # because we don't know the original class statically.
    GovernedCls = type(
        governed_name,
        (original_cls,),
        {
            "_connexum_governed": True,
            "_connexum_provider": provider,
            "__module__": original_cls.__module__,
            "__doc__": (
                f"Connexum-governed wrapper for {original_cls.__qualname__}.\n"
                "All calls are intercepted by the governance layer.\n"
                f"Original: {original_cls.__module__}.{original_cls.__qualname__}"
            ),
        },
    )
    return GovernedCls


# ----------------------------------------------------------------------------
# Per-provider patch functions
# ----------------------------------------------------------------------------


def _patch_openai(mod: types.ModuleType) -> None:
    module_name = getattr(mod, "__name__", "openai")
    if module_name in _PATCHED_MODULES:
        return
    _PATCHED_MODULES.add(module_name)

    try:
        OriginalOpenAI = getattr(mod, "OpenAI", None)
        if OriginalOpenAI is None or getattr(OriginalOpenAI, "_connexum_governed", False):
            return

        GovernedOpenAI = _make_governed_class(OriginalOpenAI, "openai")
        mod.OpenAI = GovernedOpenAI  # type: ignore[attr-defined]

        # Also patch AzureOpenAI if present
        OriginalAzureOpenAI = getattr(mod, "AzureOpenAI", None)
        if OriginalAzureOpenAI and not getattr(OriginalAzureOpenAI, "_connexum_governed", False):
            GovernedAzureOpenAI = _make_governed_class(OriginalAzureOpenAI, "azure_openai")
            mod.AzureOpenAI = GovernedAzureOpenAI  # type: ignore[attr-defined]

        _log.info("[connexum-autowrap] patched openai.OpenAI -> %s", GovernedOpenAI.__name__)
    except Exception as exc:
        _log.warning("[connexum-autowrap] openai patch failed: %s", exc)


def _patch_anthropic(mod: types.ModuleType) -> None:
    module_name = getattr(mod, "__name__", "anthropic")
    if module_name in _PATCHED_MODULES:
        return
    _PATCHED_MODULES.add(module_name)

    try:
        OriginalAnthropic = getattr(mod, "Anthropic", None)
        if OriginalAnthropic is None or getattr(OriginalAnthropic, "_connexum_governed", False):
            return

        GovernedAnthropic = _make_governed_class(OriginalAnthropic, "anthropic")
        mod.Anthropic = GovernedAnthropic  # type: ignore[attr-defined]

        # Also patch AsyncAnthropic if present
        OriginalAsync = getattr(mod, "AsyncAnthropic", None)
        if OriginalAsync and not getattr(OriginalAsync, "_connexum_governed", False):
            GovernedAsync = _make_governed_class(OriginalAsync, "anthropic")
            mod.AsyncAnthropic = GovernedAsync  # type: ignore[attr-defined]

        _log.info("[connexum-autowrap] patched anthropic.Anthropic -> %s", GovernedAnthropic.__name__)
    except Exception as exc:
        _log.warning("[connexum-autowrap] anthropic patch failed: %s", exc)


def _patch_google_generativeai(mod: types.ModuleType) -> None:
    module_name = getattr(mod, "__name__", "google.generativeai")
    if module_name in _PATCHED_MODULES:
        return
    _PATCHED_MODULES.add(module_name)

    try:
        # google.generativeai exposes GenerativeModel as the primary class
        OriginalModel = getattr(mod, "GenerativeModel", None)
        if OriginalModel is None or getattr(OriginalModel, "_connexum_governed", False):
            return

        GovernedModel = _make_governed_class(OriginalModel, "google")
        mod.GenerativeModel = GovernedModel  # type: ignore[attr-defined]

        _log.info(
            "[connexum-autowrap] patched google.generativeai.GenerativeModel -> %s",
            GovernedModel.__name__,
        )
    except Exception as exc:
        _log.warning("[connexum-autowrap] google.generativeai patch failed: %s", exc)


def _patch_bedrock(mod: types.ModuleType) -> None:
    """Patch boto3 session's client factory for bedrock-runtime."""
    module_name = getattr(mod, "__name__", "boto3")
    patch_key = module_name + ":bedrock"
    if patch_key in _PATCHED_MODULES:
        return
    _PATCHED_MODULES.add(patch_key)

    try:
        original_client = getattr(mod, "client", None)
        if original_client is None:
            return

        def governed_boto3_client(service_name: str, *args: Any, **kwargs: Any) -> Any:
            result = original_client(service_name, *args, **kwargs)
            if service_name == "bedrock-runtime" and not getattr(
                result, "_connexum_governed", False
            ):
                result._connexum_governed = True
                result._connexum_provider = "bedrock"
                _log.debug("[connexum-autowrap] governed bedrock-runtime client created")
            return result

        mod.client = governed_boto3_client  # type: ignore[attr-defined]
        _log.info("[connexum-autowrap] patched boto3.client for bedrock-runtime")
    except Exception as exc:
        _log.warning("[connexum-autowrap] bedrock patch failed: %s", exc)


def _patch_replicate(mod: types.ModuleType) -> None:
    module_name = getattr(mod, "__name__", "replicate")
    if module_name in _PATCHED_MODULES:
        return
    _PATCHED_MODULES.add(module_name)

    try:
        OriginalClient = getattr(mod, "Client", None)
        if OriginalClient is None or getattr(OriginalClient, "_connexum_governed", False):
            # Some replicate versions only export the default instance
            _log.debug("[connexum-autowrap] replicate.Client not found or already governed")
            return

        GovernedClient = _make_governed_class(OriginalClient, "replicate")
        mod.Client = GovernedClient  # type: ignore[attr-defined]
        _log.info("[connexum-autowrap] patched replicate.Client -> %s", GovernedClient.__name__)
    except Exception as exc:
        _log.warning("[connexum-autowrap] replicate patch failed: %s", exc)


def _skip_huggingface(mod: types.ModuleType) -> None:
    """HuggingFace detected but governance wrapper does not yet exist.

    Log [SKIP] per F-NEW-PRODUCT-AGENT-DIR-HUGGINGFACE-WRAPPER.
    """
    _log.info(
        "[connexum-autowrap] [SKIP] HuggingFace provider detected but no governance wrapper "
        "exists yet. Governance for huggingface_hub / transformers is tracked under "
        "F-NEW-PRODUCT-AGENT-DIR-HUGGINGFACE-WRAPPER. Module will run unpatched."
    )


# Map from module name -> patch function
_PROVIDER_PATCHES: dict[str, Any] = {
    "openai": _patch_openai,
    "anthropic": _patch_anthropic,
    "google.generativeai": _patch_google_generativeai,
    "boto3": _patch_bedrock,
    "replicate": _patch_replicate,
    # HuggingFace: imported-and-detected, but skipped with [SKIP] log
    "huggingface_hub": _skip_huggingface,
    "transformers": _skip_huggingface,
}


# ----------------------------------------------------------------------------
# Public entry point
# ----------------------------------------------------------------------------


def apply_all_patches() -> None:
    """Apply all supported provider patches.

    Providers already in sys.modules are patched immediately.
    Providers not yet imported are patched lazily the first time they
    are imported (via import_module trigger).
    """
    _load_governance_config()

    for module_name, patch_fn in _PROVIDER_PATCHES.items():
        if module_name in sys.modules:
            # Already imported -- patch immediately
            _log.debug("[connexum-autowrap] patching already-loaded module: %s", module_name)
            try:
                patch_fn(sys.modules[module_name])
            except Exception as exc:
                _log.warning("[connexum-autowrap] error patching %s: %s", module_name, exc)
        else:
            # Not yet imported -- trigger import-and-patch so it's ready
            # before customer code runs.  Falls through silently if not installed.
            _register_lazy_patcher(module_name, patch_fn)
