"""
connexum_governance.autowrap -- CONNEXUM_AUTOWRAP=1 zero-code monkey-patch mode.

When CONNEXUM_AUTOWRAP=1 is set in the environment, importing this module (or
importing connexum_governance itself) patches the real provider SDK classes so
that any ``from openai import OpenAI; OpenAI()`` call in customer code yields a
governed instance -- no import edits required in the customer's codebase.

Activation (two paths):
  1. Automatic: ``connexum_governance.__init__`` calls ``_autowrap_if_enabled()``
     at the bottom of its module body. Any process that already imports
     connexum_governance before the customer SDK import benefits automatically.
  2. Explicit: customers can call ``connexum_governance.autowrap.activate()``
     themselves in a project entry-point if they need deterministic ordering.

Design constraints:
  * Idempotent -- activating twice must not double-wrap.
  * No side-effects when CONNEXUM_AUTOWRAP != '1'.
  * Preserves ALL original behavior; governance is additive only.
  * HuggingFace is detected but skipped (no wrapper today); emits [SKIP] log
    per F-NEW-PRODUCT-AGENT-DIR-HUGGINGFACE-WRAPPER.
  * Requires ``governance.json`` in cwd (or ``CONNEXUM_GOVERNANCE_JSON`` path).
    Falls back to a safe open-policy stub when the file is absent so that
    ``CONNEXUM_AUTOWRAP=1 python -c "from openai import OpenAI"`` never crashes.

F-NEW-PRODUCT-AGENT-DIR-WRAPPER slice 3
@connexum/python-sdk
"""

from __future__ import annotations

import logging
import os
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

_log = logging.getLogger(__name__)

# Module-level flag — prevents double-activation.
_ACTIVATED = False

# ----------------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------------


def activate() -> bool:
    """Activate monkey-patch governance for all supported providers.

    Safe to call multiple times (idempotent).  Returns True if activation
    happened in this call, False if it was already active.

    Raises:
        ImportError: when CONNEXUM_AUTOWRAP=1 is set but
            ``connexum_governance.autowrap`` itself is missing (should not
            happen in a correct install, but guards against partial installs).
    """
    global _ACTIVATED
    if _ACTIVATED:
        _log.debug("[connexum-autowrap] already active -- skipping re-activation")
        return False

    _ACTIVATED = True
    _log.info("[connexum-autowrap] activating zero-code governance patches")

    # Lazy import to avoid circular dependencies at module top level
    from connexum_governance.autowrap._patches import apply_all_patches

    apply_all_patches()
    return True


def is_active() -> bool:
    """Return True if autowrap patches have been applied in this process."""
    return _ACTIVATED


def deactivate_for_testing() -> None:
    """Reset activation state.  TEST-USE ONLY.

    Does NOT undo monkey-patches already applied (Python does not support
    reliable unpatching of sys.modules entries).  Use this only when you
    are constructing fresh subprocess invocations per test case.
    """
    global _ACTIVATED
    _ACTIVATED = False


# ----------------------------------------------------------------------------
# Internal helper called by connexum_governance.__init__
# ----------------------------------------------------------------------------


def _autowrap_if_enabled() -> None:
    """Called at connexum_governance import time.

    Activates patches iff CONNEXUM_AUTOWRAP=1.  Logs but never raises so
    that a misconfigured autowrap cannot prevent the governance SDK from
    loading.
    """
    if os.environ.get("CONNEXUM_AUTOWRAP") != "1":
        return
    try:
        activate()
    except Exception as exc:  # pragma: no cover
        _log.error("[connexum-autowrap] activation failed: %s", exc)
