"""
WebAuthnAttestor (Python SDK) -- F-NEW-CRIT-39e-2-PY slice 3.

Production-tier ``EndUserAttestor`` implementation that uses the WebAuthn
(FIDO2) API to obtain a hardware-bound assertion signature from the end
user's authenticator (YubiKey, platform passkey, etc.).

Mirrors the TS counterpart in
``packages/typescript-sdk/src/webauthn-attestor.ts``.

TOKEN FORMAT -- ``v4att.webauthn.<base64url-payload>.<base64url-signature>``

The "signature" stored in the token is the raw WebAuthn assertion signature
bytes obtained from the browser/authenticator (via a customer-supplied
``AssertionCallback``). The payload is the v4att claims object plus a
``webauthn: true`` marker so the governance-server's verification path
routes to the simplified WebAuthn verifier at
``packages/governance-server/src/end-user-attestation.ts:619``
(``verifyWebAuthnAttestation``).

SIMPLIFICATION (slice 3 / self-attestation path):
    Full WebAuthn attestation verification requires CBOR parsing of the
    authenticatorData and attestationObject plus COSE-format public key
    extraction. That is intentionally out of scope for slice 3 and is
    filed as ``F-NEW-CRIT-39e-2-WEBAUTHN-FULL-VERIFY``. The server-side
    verifier currently accepts the token if:

    1. Claims are structurally valid (sub/aud/exp/jti/action).
    2. The ``sub`` is registered in the tenant's key store (registration
       happens out-of-band via the WebAuthn registration ceremony --
       ``POST /api/v1/admin/attestation/keys/register``).
    3. The ``jti`` has not been seen before (replay protection).
    4. The token payload claims have not been tampered (structural).
    5. ``action`` matches the request's ``toolName``.

    The server does NOT re-verify the FIDO2 assertion signature against
    the authenticator's COSE public key in slice 3. This matches the TS
    SDK's slice-4 simplification exactly so the two SDKs are parity-
    matched at the wire layer.

PYTHON USAGE
============

The actual ``navigator.credentials.get()`` call lives in the customer's
browser; this Python attestor therefore accepts a callback that performs
the WebAuthn ceremony and returns the raw assertion bytes:

::

    from connexum_governance.webauthn_attestor import (
        WebAuthnAttestor, WebAuthnAssertion,
    )

    async def my_assertion_callback(challenge: bytes) -> WebAuthnAssertion:
        # Customer-side flow: ship challenge to browser, browser runs
        # navigator.credentials.get(), browser POSTs back the assertion
        # bytes. The exact transport is the customer's choice (HTTP,
        # WebSocket, Server-Sent Events).
        ...
        return WebAuthnAssertion(
            credential_id="<base64url credential id>",
            signature=<assertion.response.signature bytes>,
        )

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="alice@hospital.example",
        credential_id="<previously-enrolled base64url credential id>",
        assertion_callback=my_assertion_callback,
    )

    gov = AsyncGovernanceClient(
        api_url="https://gov.my-cc.io",
        license_key=os.environ["CONNEXUM_LICENSE"],
        org_id="tenant-alpha",
        attestor=attestor,
    )

The customer's host application (an async web service typically) holds
the WebAuthn ceremony; this attestor only handles claim construction +
token assembly so the wire shape is identical to the TS WebAuthnAttestor.

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 3
"""

from __future__ import annotations

import base64
import json
import secrets
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Awaitable, Callable, Optional

from connexum_governance.attestor._types import (
    AttestationContext,
    AttestorError,
    SignedAttestation,
)

__all__ = [
    "DEFAULT_WEBAUTHN_TTL_SECONDS",
    "WEBAUTHN_TOKEN_PREFIX",
    "WebAuthnAssertion",
    "WebAuthnAttestor",
    "build_webauthn_token",
]


# ---------------------------------------------------------------------------
# Wire format constants -- mirror packages/governance-server/src/end-user-attestation.ts:551
# ---------------------------------------------------------------------------

WEBAUTHN_TOKEN_PREFIX = "v4att.webauthn."

DEFAULT_WEBAUTHN_TTL_SECONDS = 90
"""Default token TTL. Mirrors TS WebAuthnAttestor (slice 4)."""


# ---------------------------------------------------------------------------
# WebAuthnAssertion -- output of the customer's browser ceremony
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class WebAuthnAssertion:
    """Result of a WebAuthn ``navigator.credentials.get()`` ceremony.

    The customer's browser performs the ceremony and ships these bytes
    back to the Python host. We do not interpret the bytes; we embed
    them verbatim in the token's signature segment.

    :param credential_id: ``assertion.id`` from the WebAuthn API. This
        is the base64url-encoded credential id (the registered passkey
        identifier). Becomes the ``keyId`` claim and is also used to
        bind the token to a specific authenticator.
    :param signature: Raw bytes from ``assertion.response.signature``.
        Server-side slice 3 does NOT verify these against the
        authenticator's COSE public key (see module docstring).
    """

    credential_id: str
    signature: bytes


# ---------------------------------------------------------------------------
# AssertionCallback type -- customer-supplied browser-bridge function
# ---------------------------------------------------------------------------


AssertionCallback = Callable[[bytes], Awaitable[WebAuthnAssertion]]
"""Async callback the customer supplies to drive the WebAuthn ceremony.

The callback receives a ``challenge`` byte string (32 bytes, suitable
for ``PublicKeyCredentialRequestOptions.challenge``) and must return a
``WebAuthnAssertion`` containing the assertion bytes from the browser.
"""


# ---------------------------------------------------------------------------
# Helpers -- base64url no padding, ISO8601-with-Z
# ---------------------------------------------------------------------------


def _b64url_no_pad(raw: bytes) -> str:
    """``base64url`` per RFC 4648 with padding stripped, ASCII string.

    Equivalent to Node ``Buffer.from(raw).toString('base64url')``.
    """

    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _iso8601_z(dt: datetime) -> str:
    """ISO-8601 with millisecond precision and trailing ``Z``."""

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    iso = dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    millis = dt.microsecond // 1000
    return f"{iso}.{millis:03d}Z"


# ---------------------------------------------------------------------------
# build_webauthn_token -- low-level token builder, exported for tests
# ---------------------------------------------------------------------------


def build_webauthn_token(
    *,
    sub: str,
    aud: str,
    iat_iso: str,
    exp_iso: str,
    jti: str,
    action: str,
    signature: bytes,
    nonce: Optional[str] = None,
    request_hash: Optional[str] = None,
    key_id: Optional[str] = None,
) -> str:
    """Build a v4att.webauthn token.

    Mirrors ``buildWebAuthnToken()`` server-side at
    ``packages/governance-server/src/end-user-attestation.ts:580`` and the
    TS SDK's ``WebAuthnAttestor.buildToken()`` at
    ``packages/typescript-sdk/src/webauthn-attestor.ts:313``.

    Claim insertion order mirrors the TS interface in
    ``webauthn-attestor.ts:155-169``:
    ``sub, aud, tenantId, iat, exp, jti, nonce?, requestHash?, action,
    keyId?, webauthn:true``.

    The server-side parser at ``end-user-attestation.ts:558`` only requires
    ``webauthn: true``; the rest is checked field-by-field at
    ``verifyWebAuthnAttestation``.

    :param signature: Raw WebAuthn assertion signature bytes. Embedded
        verbatim as the token's signature segment.
    """

    claims: dict = {
        "sub": sub,
        "aud": aud,
        "tenantId": aud,
        "iat": iat_iso,
        "exp": exp_iso,
        "jti": jti,
    }
    if nonce is not None:
        claims["nonce"] = nonce
    if request_hash is not None:
        claims["requestHash"] = request_hash
    # action MUST be set on a WebAuthn token -- the server's action-binding
    # check at end-user-attestation.ts:654 compares `claims.action` to the
    # incoming `toolName`. We truncate to 200 chars to mirror the TS slice 4
    # WebAuthnAttestor at webauthn-attestor.ts:293.
    claims["action"] = action[:200]
    if key_id is not None:
        claims["keyId"] = key_id
    # webauthn marker last to mirror TS interface field order.
    claims["webauthn"] = True

    payload_json = json.dumps(claims, separators=(",", ":"))
    payload_b64 = _b64url_no_pad(payload_json.encode("utf-8"))
    sig_b64 = _b64url_no_pad(signature)
    return f"{WEBAUTHN_TOKEN_PREFIX}{payload_b64}.{sig_b64}"


# ---------------------------------------------------------------------------
# WebAuthnAttestor -- the production EndUserAttestor implementation
# ---------------------------------------------------------------------------


class WebAuthnAttestor:
    """Production WebAuthn-backed ``EndUserAttestor`` for Python SDK callers.

    Mirrors the TS ``WebAuthnAttestor`` in
    ``packages/typescript-sdk/src/webauthn-attestor.ts:211`` at the wire
    layer.

    The Python host has no direct access to ``navigator.credentials``;
    the customer supplies an async ``assertion_callback`` that bridges
    to the browser/authenticator. The attestor builds the challenge,
    invokes the callback, wraps the response in a v4att.webauthn token,
    and returns a ``SignedAttestation``.

    :param rp_id: Relying-party id (e.g. ``my-cc.io``). Forwarded to the
        assertion callback so the browser can pass it to
        ``navigator.credentials.get()``.
    :param user_id: Opaque end-user identifier. Becomes the ``sub``
        claim in the token. Must match the userId registered with the
        gov-server's attestation key store.
    :param credential_id: Previously-enrolled base64url credential id
        from the registration ceremony.
    :param assertion_callback: Async callback the SDK invokes to drive
        the actual WebAuthn ceremony. Receives a 32-byte challenge,
        returns a ``WebAuthnAssertion``.
    :param ttl_seconds: Token TTL. Default 90 seconds.
    """

    __slots__ = (
        "_rp_id",
        "_user_id",
        "_credential_id",
        "_assertion_callback",
        "_ttl_seconds",
    )

    def __init__(
        self,
        *,
        rp_id: str,
        user_id: str,
        credential_id: str,
        assertion_callback: AssertionCallback,
        ttl_seconds: int = DEFAULT_WEBAUTHN_TTL_SECONDS,
    ) -> None:
        if not rp_id:
            raise ValueError("WebAuthnAttestor requires rp_id (relying-party id)")
        if not user_id:
            raise ValueError("WebAuthnAttestor requires user_id (sub claim)")
        if not credential_id:
            raise ValueError(
                "WebAuthnAttestor requires credential_id "
                "(base64url-encoded WebAuthn credential identifier from the "
                "registration ceremony)"
            )
        if assertion_callback is None:
            raise ValueError(
                "WebAuthnAttestor requires an assertion_callback to drive "
                "the navigator.credentials.get() ceremony. The Python "
                "process has no direct WebAuthn API; the customer's "
                "browser/authenticator does the actual signing and ships "
                "the assertion back via this async callback."
            )

        self._rp_id = rp_id
        self._user_id = user_id
        self._credential_id = credential_id
        self._assertion_callback = assertion_callback
        self._ttl_seconds = ttl_seconds

    async def sign(self, context: AttestationContext) -> SignedAttestation:
        """Drive a WebAuthn ceremony and return a v4att.webauthn token.

        Steps mirror TS ``WebAuthnAttestor.sign()`` at
        ``packages/typescript-sdk/src/webauthn-attestor.ts:218``:

        1. Build a 32-byte challenge from the SDK's context.
        2. Invoke ``assertion_callback`` (customer bridges to browser).
        3. Wrap the returned signature in a v4att.webauthn token with
           the canonical claims.

        :raises AttestorError: ``user-cancelled`` if the callback raises
            ``AttestorError(user-cancelled)`` (customer flow signals user
            dismissed the prompt). ``sign-failed`` for any other error
            from the callback or the signing primitives.
        """

        challenge = _build_challenge(context)

        try:
            assertion = await self._assertion_callback(challenge)
        except AttestorError:
            # Customer's callback signaled cancellation / error already
            # using AttestorError -- propagate as-is so the SDK's
            # GovernanceViolation wrap preserves the original code.
            raise
        except Exception as err:
            raise AttestorError(
                "sign-failed",
                f"WebAuthn assertion callback failed: {err}",
            ) from err

        if not isinstance(assertion, WebAuthnAssertion):
            raise AttestorError(
                "sign-failed",
                "WebAuthn assertion_callback must return a "
                "WebAuthnAssertion instance",
            )
        if not assertion.signature:
            raise AttestorError(
                "sign-failed",
                "WebAuthn assertion_callback returned empty signature bytes",
            )

        now = datetime.now(timezone.utc)
        exp = now + timedelta(seconds=self._ttl_seconds)
        jti = str(uuid.uuid4())

        token = build_webauthn_token(
            sub=self._user_id,
            aud=context.tenant_id,
            iat_iso=_iso8601_z(now),
            exp_iso=_iso8601_z(exp),
            jti=jti,
            action=context.action,
            signature=assertion.signature,
            nonce=context.nonce,
            request_hash=context.request_hash,
            # keyId binds the token to a specific authenticator credential
            # so an attacker who reuses a different credential's signature
            # cannot satisfy the action-bound claim. Note slice 3 does NOT
            # cryptographically verify this binding (filed
            # F-NEW-CRIT-39e-2-WEBAUTHN-FULL-VERIFY for the COSE check).
            key_id=assertion.credential_id,
        )

        return SignedAttestation(
            token=token,
            sub=self._user_id,
            jti=jti,
            exp=int(exp.timestamp() * 1000),
        )


# ---------------------------------------------------------------------------
# _build_challenge -- internal helper, exposed via test imports
# ---------------------------------------------------------------------------


def _build_challenge(context: AttestationContext) -> bytes:
    """Build a 32-byte challenge from the attestation context.

    Mirrors TS ``WebAuthnAttestor.sign()`` challenge construction at
    ``webauthn-attestor.ts:226-231``: ``nonce + requestHash`` (each hex)
    concatenated, sliced to 32 hex chars (= 16 bytes), then zero-padded
    to 32 bytes total. We then top up with cryptographically random
    bytes if the customer-supplied context had a short nonce or hash --
    the WebAuthn spec mandates ``>= 16`` bytes of challenge entropy.

    The challenge does NOT travel in the token (the browser binds it
    into the authenticatorData via the ceremony). It is used only to
    seed the browser's WebAuthn call.
    """

    hex_blob = (context.nonce + context.request_hash)[:64]
    try:
        challenge_bytes = bytes.fromhex(hex_blob)
    except ValueError:
        # Non-hex nonce/hash -- fall back to UTF-8 bytes truncated to 32
        challenge_bytes = (context.nonce + context.request_hash).encode("utf-8")[:32]

    if len(challenge_bytes) < 32:
        # Pad with cryptographically random bytes to satisfy WebAuthn
        # >= 16 bytes minimum (we go to 32 to match TS impl).
        challenge_bytes = challenge_bytes + secrets.token_bytes(32 - len(challenge_bytes))

    return challenge_bytes[:32]
