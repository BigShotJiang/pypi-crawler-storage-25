"""
PackDrivenClassifier -- Python mirror of the TypeScript PackDrivenClassifier.

Mirrors: src/classification/pack-driven-classifier.ts (commit ab3fde4)

Architecture:
  - Pack registry is loaded from the governance server over HTTP at session init
    via GovernanceClient.fetch_pack_registry().
  - Local in-memory cache with 5-minute TTL. Refreshed on cache miss or
    force_refresh=True.
  - Classifiers are re-hydrated from the pack declarations returned by the
    server (pattern strings are compiled to re.Pattern; custom classifiers
    that can only run server-side fall back to the pattern).
  - Canonical audit events are emitted per matched category via the
    GovernanceClient.report_pack_enforcement() path with type
    pack.enforcement.{action}.
  - Strictest-wins resolution: BLOCK > REQUIRE_APPROVAL > WARN > LOG > ALLOW

Differences from TypeScript version:
  - Custom classifier functions cannot be serialised over HTTP so patterns
    are the sole local mechanism. Server-side evaluation is the authoritative
    path for packs without pattern classifiers.
  - Thread safety: the registry map is replaced atomically on refresh.

@connexum/ai-governance (Python SDK)
"""

from __future__ import annotations

import hashlib
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Enums / Literals
# ---------------------------------------------------------------------------

GovernanceAction = str  # 'BLOCK' | 'REQUIRE_APPROVAL' | 'WARN' | 'LOG' | 'ALLOW'

ACTION_SEVERITY: Dict[str, int] = {
    "ALLOW": 0,
    "LOG": 1,
    "WARN": 2,
    "REQUIRE_APPROVAL": 3,
    "BLOCK": 4,
}

_VALID_ACTIONS = frozenset(ACTION_SEVERITY.keys())


def _normalize_action(raw: str) -> GovernanceAction:
    upper = raw.upper()
    return upper if upper in _VALID_ACTIONS else "LOG"


def _stricter(a: GovernanceAction, b: GovernanceAction) -> GovernanceAction:
    return a if ACTION_SEVERITY.get(a, 0) >= ACTION_SEVERITY.get(b, 0) else b


def _action_to_event_type(action: GovernanceAction) -> str:
    mapping = {
        "BLOCK": "pack.enforcement.block",
        "REQUIRE_APPROVAL": "pack.enforcement.require_approval",
        "WARN": "pack.enforcement.warn",
        "LOG": "pack.enforcement.log",
    }
    return mapping.get(action, "pack.enforcement.allow")


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ClassificationContext:
    """Input context for classification (mirrors TypeScript ClassificationContext)."""

    agent_id: Optional[str] = None
    org_id: Optional[str] = None
    project_id: Optional[str] = None
    # Pack IDs active for this project. None = all loaded packs apply.
    active_pack_ids: Optional[List[str]] = None
    # P1C-04: PCI DSS transaction context.
    # When present and a PCI DSS subject-keyed category (PAN / CVV / TRACK_DATA)
    # fires, the emitted audit event receives transaction_context and pci_event_type.
    transaction_context: Optional[Any] = None  # TransactionContext from models.py


@dataclass
class CategoryMatch:
    """A single category match from classify(). Mirrors TypeScript CategoryMatch."""

    pack_id: str
    category_id: str
    action: GovernanceAction
    match_confidence: float  # 0-1
    pack_version: str


@dataclass
class ClassifierResult:
    """Full result of classify(). Mirrors TypeScript ClassifierResult."""

    matched: List[CategoryMatch]
    has_match: bool


@dataclass
class GovernanceDecision:
    """Final governance decision after strictest-wins resolution."""

    action: GovernanceAction
    matched: List[CategoryMatch]
    decision_id: str


@dataclass
class PackEnforcementAuditEvent:
    """Canonical audit event emitted per matched category."""

    type: str  # pack.enforcement.{action}
    pack_id: str
    category_id: str
    match_confidence: float
    subject_digest: str  # SHA-256 of input
    action: GovernanceAction
    decision_id: str
    timestamp: str
    pack_version: str
    # GAP-1: organization ID written to every event for tenant attribution
    org_id: Optional[str] = None
    # P1C-04: PCI DSS Req-10 transaction fields.
    # Present when a PCI DSS subject-keyed category fires AND transaction_context supplied.
    #
    # PCI Req-10 audit field mapping:
    #   1. user identification  -- operator_id (from ClassificationContext identity)
    #   2. type of event        -- pci_event_type
    #   3. date and time        -- timestamp
    #   4. success or failure   -- action (BLOCK=failure)
    #   5. origination of event -- transaction_context.merchant_id
    #   6. affected data/system -- transaction_context.transaction_id
    transaction_context: Optional[Any] = None  # TransactionContext dict or object
    pci_event_type: Optional[str] = None       # AUTH/CAPTURE/REFUND/VOID/QUERY/DENIED


# ---------------------------------------------------------------------------
# Internal registry entry
# ---------------------------------------------------------------------------


@dataclass
class _CategoryRegistryEntry:
    pack_id: str
    pack_version: str
    category_id: str
    action: GovernanceAction
    pattern: Optional[re.Pattern]  # type: ignore[type-arg]
    # Optional: custom Python callable for test-wiring purposes
    classifier_fn: Optional[Callable[[str, ClassificationContext], bool]] = None
    # GAP-2: True if this category is subject-keyed (requires recipient on report_result)
    subject_keyed: bool = False


# ---------------------------------------------------------------------------
# PackDrivenClassifier
# ---------------------------------------------------------------------------

_CACHE_TTL_SECONDS = 300  # 5-minute TTL


class PackDrivenClassifier:
    """
    Python mirror of PackDrivenClassifier (TypeScript, ab3fde4).

    Usage with GovernanceClient:

        from connexum_governance import GovernanceClient
        from connexum_governance.classification import PackDrivenClassifier

        gov = GovernanceClient(api_url="http://localhost:3100",
                               license_key="...", project_id="proj_abc")
        classifier = PackDrivenClassifier()
        classifier.load_from_packs(gov.fetch_pack_registry())

        result = classifier.classify("Patient SSN: 123-45-6789", ClassificationContext())
        decision = classifier.apply_actions(result.matched, ClassificationContext(),
                                            "Patient SSN: 123-45-6789")
    """

    def __init__(self) -> None:
        # Map["{packId}::{categoryId}", _CategoryRegistryEntry]
        self._registry: Dict[str, _CategoryRegistryEntry] = {}
        self._audit_log: List[PackEnforcementAuditEvent] = []
        self._cache_loaded_at: Optional[float] = None

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_from_packs(
        self,
        pack_registry: List[Dict[str, Any]],
        force_refresh: bool = False,
    ) -> None:
        """
        Load category classifiers from the pack registry returned by the server.

        pack_registry is a list of pack descriptor dicts, each with the shape:
            {
              "id": "hipaa",
              "version": "1.0.0",
              "dataPolicy": {
                "scanCategories": ["PHI", "PII"],
                "categoryActions": {"PHI": "BLOCK", "PII": "WARN"},
              },
              "categoryClassifiers": {
                "PHI": {"pattern": "\\bSSN\\b", ...},
              }
            }

        Safe to call multiple times -- later calls ADD to the registry (same
        pack/category key overwrites). New packs take effect immediately.
        """
        now = time.monotonic()
        if (
            not force_refresh
            and self._cache_loaded_at is not None
            and (now - self._cache_loaded_at) < _CACHE_TTL_SECONDS
            and self._registry
        ):
            return  # cache still warm

        for pack in pack_registry:
            pack_id: str = pack.get("id", "")
            pack_version: str = pack.get("version", "0.0.0")
            data_policy: Dict[str, Any] = pack.get("dataPolicy", {})
            scan_categories: List[str] = data_policy.get("scanCategories", [])
            category_actions: Dict[str, str] = data_policy.get("categoryActions", {})
            category_classifiers: Dict[str, Any] = pack.get("categoryClassifiers", {})
            # GAP-2: load subject-keyed categories to know when to emit disclosure.unattributed
            subject_keyed_set: set = set(pack.get("subjectKeyedCategories", []))

            for category_id in scan_categories:
                raw_action = category_actions.get(category_id, "LOG")
                action = _normalize_action(raw_action)

                # Compile pattern if one was shipped with the pack descriptor
                clf_def: Dict[str, Any] = category_classifiers.get(category_id, {})
                pattern: Optional[re.Pattern] = None  # type: ignore[type-arg]
                raw_pattern: Optional[str] = clf_def.get("pattern")
                if raw_pattern:
                    try:
                        pattern = re.compile(raw_pattern, re.IGNORECASE)
                    except re.error:
                        pattern = None

                key = f"{pack_id}::{category_id}"
                self._registry[key] = _CategoryRegistryEntry(
                    pack_id=pack_id,
                    pack_version=pack_version,
                    category_id=category_id,
                    action=action,
                    pattern=pattern,
                    subject_keyed=category_id in subject_keyed_set,
                )

        self._cache_loaded_at = time.monotonic()

    def register_entry(
        self,
        pack_id: str,
        pack_version: str,
        category_id: str,
        action: GovernanceAction,
        pattern: Optional[re.Pattern] = None,  # type: ignore[type-arg]
        classifier_fn: Optional[Callable[[str, ClassificationContext], bool]] = None,
    ) -> None:
        """
        Register a single category entry directly (used by tests and
        behavioral validators that inject Python classifier functions).
        """
        key = f"{pack_id}::{category_id}"
        self._registry[key] = _CategoryRegistryEntry(
            pack_id=pack_id,
            pack_version=pack_version,
            category_id=category_id,
            action=action,
            pattern=pattern,
            classifier_fn=classifier_fn,
        )

    # ------------------------------------------------------------------
    # Classification
    # ------------------------------------------------------------------

    def classify(
        self,
        input_text: str,
        context: Optional[ClassificationContext] = None,
    ) -> ClassifierResult:
        """
        Classify an input string against all registered categories.

        Only evaluates packs whose IDs are in context.active_pack_ids (if set).
        Returns all matched categories.
        """
        if context is None:
            context = ClassificationContext()

        matched: List[CategoryMatch] = []

        for entry in self._registry.values():
            # Project-level pack selection gate
            if (
                context.active_pack_ids is not None
                and entry.pack_id not in context.active_pack_ids
            ):
                continue

            if self._run_classifier(input_text, context, entry):
                matched.append(
                    CategoryMatch(
                        pack_id=entry.pack_id,
                        category_id=entry.category_id,
                        action=entry.action,
                        match_confidence=1.0,
                        pack_version=entry.pack_version,
                    )
                )

        return ClassifierResult(matched=matched, has_match=len(matched) > 0)

    def apply_actions(
        self,
        matched: List[CategoryMatch],
        context: ClassificationContext,
        input_text: str,
    ) -> GovernanceDecision:
        """
        Resolve matched categories into a GovernanceDecision (strictest-wins).
        Emits a canonical audit event per matched category with SHA-256 digest.
        Mirrors TypeScript applyActions().

        P1C-04: When context.transaction_context is present and a pci-dss
        subject-keyed category fires, the audit event carries transaction_context
        and pci_event_type for PCI Req-10 compliance.
        """
        decision_id = str(uuid.uuid4())
        subject_digest = hashlib.sha256(input_text.encode()).hexdigest()
        timestamp = _utcnow_iso()
        # GAP-1: capture org_id for per-event tenant attribution
        org_id = context.org_id if context else None

        final_action: GovernanceAction = "ALLOW"
        for m in matched:
            final_action = _stricter(final_action, m.action)

        # P1C-04: resolve transaction context once for the decision cycle
        tx_ctx = getattr(context, "transaction_context", None) if context else None

        for m in matched:
            entry = self._registry.get(f"{m.pack_id}::{m.category_id}")

            # P1C-04: attach PCI Req-10 fields for pci-dss subject-keyed categories
            pci_transaction_context = None
            pci_event_type = None
            is_subject_keyed = entry.subject_keyed if entry else False
            if m.pack_id == "pci-dss" and is_subject_keyed and tx_ctx is not None:
                pci_transaction_context = tx_ctx
                # Derive pci_event_type using the final action (not per-match action)
                try:
                    from connexum_governance.models import derive_pci_event_type
                    tx_type = (
                        tx_ctx.transaction_type
                        if hasattr(tx_ctx, "transaction_type")
                        else tx_ctx.get("transactionType", "authorization")
                    )
                    pci_event_type = derive_pci_event_type(tx_type, final_action)
                except (ImportError, AttributeError, KeyError):
                    pci_event_type = "DENIED" if final_action == "BLOCK" else "AUTH"

            event = PackEnforcementAuditEvent(
                type=_action_to_event_type(m.action),
                pack_id=m.pack_id,
                category_id=m.category_id,
                match_confidence=m.match_confidence,
                subject_digest=subject_digest,
                action=m.action,
                decision_id=decision_id,
                timestamp=timestamp,
                pack_version=m.pack_version,
                org_id=org_id,
                transaction_context=pci_transaction_context,
                pci_event_type=pci_event_type,
            )
            self._audit_log.append(event)
            # GAP-2: emit disclosure.unattributed when subject-keyed category fires without recipient
            if entry and entry.subject_keyed:
                self._emit_disclosure_unattributed(m, subject_digest, decision_id, timestamp, org_id)

        return GovernanceDecision(
            action=final_action,
            matched=matched,
            decision_id=decision_id,
        )

    def _emit_disclosure_unattributed(
        self,
        m: "CategoryMatch",
        subject_digest: str,
        decision_id: str,
        timestamp: str,
        org_id: Optional[str],
    ) -> None:
        """GAP-2: emit disclosure.unattributed event when subject-keyed category fires without recipient."""
        event = PackEnforcementAuditEvent(
            type="disclosure.unattributed",
            pack_id=m.pack_id,
            category_id=m.category_id,
            match_confidence=m.match_confidence,
            subject_digest=subject_digest,
            action=m.action,
            decision_id=decision_id,
            timestamp=timestamp,
            pack_version=m.pack_version,
            org_id=org_id,
        )
        self._audit_log.append(event)

    def evaluate(
        self,
        input_text: str,
        context: Optional[ClassificationContext] = None,
    ) -> GovernanceDecision:
        """Convenience: classify + apply_actions in a single call."""
        if context is None:
            context = ClassificationContext()
        result = self.classify(input_text, context)
        return self.apply_actions(result.matched, context, input_text)

    # ------------------------------------------------------------------
    # Audit log access
    # ------------------------------------------------------------------

    def drain_audit_events(self) -> List[PackEnforcementAuditEvent]:
        """Return audit events emitted since last drain and clear the log."""
        events = list(self._audit_log)
        self._audit_log.clear()
        return events

    def peek_audit_events(self) -> List[PackEnforcementAuditEvent]:
        """Peek at audit events without draining."""
        return list(self._audit_log)

    @property
    def registry_size(self) -> int:
        """Number of registered (packId, categoryId) entries."""
        return len(self._registry)

    def list_registered_entries(
        self,
    ) -> List[Tuple[str, str, GovernanceAction]]:
        """
        List all registered (pack_id, category_id, action) tuples.
        Used by behavioral validators.
        """
        return [
            (e.pack_id, e.category_id, e.action)
            for e in self._registry.values()
        ]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _run_classifier(
        self,
        input_text: str,
        context: ClassificationContext,
        entry: _CategoryRegistryEntry,
    ) -> bool:
        # Custom classifier takes precedence (used in test wiring)
        if entry.classifier_fn is not None:
            return entry.classifier_fn(input_text, context)

        # Regex pattern fallback
        if entry.pattern is not None:
            return bool(entry.pattern.search(input_text))

        # No classifier defined -- default to false (no match) to avoid false
        # positives. Behavioral validators will catch missing classifiers.
        return False


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------


def _utcnow_iso() -> str:
    import datetime
    return datetime.datetime.utcnow().isoformat() + "Z"


# ---------------------------------------------------------------------------
# Module-level singleton (lazy-initialised from active packs)
# ---------------------------------------------------------------------------

_global_classifier: Optional[PackDrivenClassifier] = None


def get_global_classifier() -> PackDrivenClassifier:
    """Return the process-level singleton PackDrivenClassifier."""
    global _global_classifier
    if _global_classifier is None:
        _global_classifier = PackDrivenClassifier()
    return _global_classifier


def set_global_classifier(classifier: PackDrivenClassifier) -> None:
    """Replace the process-level singleton (used in tests)."""
    global _global_classifier
    _global_classifier = classifier
