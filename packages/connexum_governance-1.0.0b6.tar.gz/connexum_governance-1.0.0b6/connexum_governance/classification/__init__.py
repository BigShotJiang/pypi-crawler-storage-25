"""
Classification module for connexum-governance Python SDK.

Provides PackDrivenClassifier -- a local Python mirror of the TypeScript
PackDrivenClassifier (src/classification/pack-driven-classifier.ts).

The classifier loads pack registry data from the governance server at session
init and evaluates inputs locally, emitting canonical audit events per match
via client.report_result / the pack.enforcement.{action} event path.
"""

from connexum_governance.classification.pack_driven_classifier import (
    PackDrivenClassifier,
    GovernanceAction,
    CategoryMatch,
    ClassifierResult,
    GovernanceDecision,
    PackEnforcementAuditEvent,
    ClassificationContext,
)

__all__ = [
    "PackDrivenClassifier",
    "GovernanceAction",
    "CategoryMatch",
    "ClassifierResult",
    "GovernanceDecision",
    "PackEnforcementAuditEvent",
    "ClassificationContext",
]
