"""
Governance client for My Compliance Center API.

Provides both synchronous and asynchronous clients.
All governance logic runs server-side in the TypeScript engine.
This client is a thin HTTP wrapper.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import secrets
import sys
from typing import Any, Literal, Optional

import httpx

from connexum_governance.attestor import (
    AttestationContext,
    AttestorError,
    EndUserAttestor,
)
from connexum_governance.models import (
    ActionContext,
    AgentIdentity,
    ClassifiedResponse,
    DataSubjectIdentity,
    DecisionType,
    DelegationContext,
    GovernanceDecision,
    GovernanceViolation,
    PlanContext,
    RecipientIdentity,
    TaskContext,
    TransportDescriptor,
)
from connexum_governance.subscription import (
    SubscriptionGate,
    SubscriptionNotConfiguredError,
    SubscriptionInactiveError,
)


# F-NEW-CRIT-39e-2-PY Slice 4: helpers used by both GovernanceClient and
# AsyncGovernanceClient when wiring an EndUserAttestor into check_action.
# Mirrors `computeRequestHash` + AttestationContext construction in
# `packages/governance-server/src/end-user-attestation.ts:415-422` and the
# TS SDK at `packages/typescript-sdk/src/governed-llm-base.ts:287-307`.
def _compute_request_hash(tool: str, input_dict: dict[str, Any], agent_name: str) -> str:
    """Canonical SHA-256 hex hash for the attestation `request_hash` claim.

    canonical = toolName + ":" + JSON.stringify(input) + ":" + agentName

    `json.dumps(..., separators=(",", ":"))` matches Node's `JSON.stringify`
    byte-for-byte for primitive-valued dicts so the server's
    `computeRequestHash()` produces an identical hex string.
    """
    input_json = json.dumps(input_dict, separators=(",", ":"), sort_keys=False)
    canonical = f"{tool}:{input_json}:{agent_name}"
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _build_attestation_context(
    *,
    tool: str,
    input_dict: dict[str, Any],
    agent_name: str,
    tenant_id: str,
    user_id: Optional[str],
) -> AttestationContext:
    """Build the AttestationContext passed to `EndUserAttestor.sign()`."""
    return AttestationContext(
        tenant_id=tenant_id,
        action=tool[:200],
        nonce=secrets.token_hex(16),
        request_hash=_compute_request_hash(tool, input_dict, agent_name),
        user_id=user_id,
    )

__all__ = [
    "GovernanceClient",
    "AsyncGovernanceClient",
    "BiasClient",
    "SubscriptionNotConfiguredError",
    "SubscriptionInactiveError",
]


class GovernanceClient:
    """Synchronous governance client.

    Connects to the Connexum governance API server (local sidecar or remote SaaS).

    Usage:
        gov = GovernanceClient(
            api_url="http://localhost:3100",
            license_key="your-jwt-license-key",
        )

        decision = gov.check_action(
            tool="Bash",
            input={"command": "rm -rf /"},
            agent=AgentIdentity(name="cleanup-agent"),
        )

        if decision.denied:
            print(f"Blocked: {decision.reason}")
    """

    def __init__(
        self,
        api_url: str,
        license_key: str,
        installation_id: Optional[str] = None,
        org_id: Optional[str] = None,
        timeout: float = 5.0,
        enforce: bool = True,
        on_failure: Literal["open", "closed"] = "closed",
        license_server_url: Optional[str] = None,
        active_pack_ids: Optional[list[str]] = None,
        enforce_subscription: bool = False,
        project_id: Optional[str] = None,
        attestor: Optional[EndUserAttestor] = None,
    ):
        """
        Create a GovernanceClient.

        Args:
            api_url: URL of the governance API server.
            license_key: Bearer JWT for the governance API.
            license_server_url: URL of the license server (required when
                enforce_subscription=True). Defaults to None.
            active_pack_ids: List of active compliance pack IDs for
                grace-window resolution (e.g. ['hipaa', 'soc2']).
            enforce_subscription: When True, calls subscription.enforce()
                at construction time. Raises SubscriptionNotConfiguredError
                or SubscriptionInactiveError if the subscription is not
                active. Defaults to False to maintain backward compatibility.
            attestor: (F-NEW-CRIT-39e-2-PY) Default EndUserAttestor for the
                client lifetime. When set, every `check_action()` call
                invokes `attestor.sign(ctx)` and attaches the resulting
                `v4att.` token to the request body's `attestationToken`
                field AND the `X-Attestation-Token` header. A per-call
                `attestor=` argument on `check_action()` overrides this
                default. Requires `org_id` to be set (used as the `aud`
                claim). On sync clients, signing bridges via
                `asyncio.run()` and errors clearly when called from
                inside a running event loop -- use AsyncGovernanceClient
                in that case.
        """
        self.api_url = api_url.rstrip("/")
        self.license_key = license_key
        self.installation_id = installation_id or "default"
        self.org_id = org_id
        self._project_id = project_id
        self.enforce = enforce
        self.on_failure = on_failure
        self._default_attestor = attestor
        self._client = httpx.Client(
            base_url=self.api_url,
            headers={
                "Authorization": f"Bearer {license_key}",
                "Content-Type": "application/json",
                "X-Installation-Id": self.installation_id,
            },
            timeout=timeout,
        )

        # S-06: Subscription gate enforcement.
        # Raise at construction time if the subscription is not valid.
        if enforce_subscription:
            if not license_server_url:
                raise ValueError(
                    "license_server_url is required when enforce_subscription=True"
                )
            self._subscription_gate = SubscriptionGate(
                license_server_url=license_server_url,
                active_pack_ids=active_pack_ids or [],
            )
            # Raises SubscriptionNotConfiguredError or SubscriptionInactiveError
            self._subscription_gate.boot()
        else:
            self._subscription_gate = None

    def _fail_open_decision(self, error: Exception) -> GovernanceDecision:
        """Return a permissive decision when the governance server is unreachable."""
        print(
            f"[WARN] Governance server unreachable: {error}. Fail-open policy applied.",
            file=sys.stderr,
        )
        return GovernanceDecision(
            decision=DecisionType.ALLOW,
            reason="Governance server unreachable. Fail-open policy applied.",
            audit_id="",
            metadata={"failOpen": True, "error": str(error)},
        )

    def check_action(
        self,
        tool: str,
        input: dict[str, Any],
        agent: AgentIdentity | dict[str, Any],
        data_subject: Optional[DataSubjectIdentity] = None,
        recipient: Optional[RecipientIdentity] = None,
        transport: Optional[TransportDescriptor] = None,
        user_id: Optional[str] = None,
        llm_model: Optional[str] = None,
        attestor: Optional[EndUserAttestor] = None,
    ) -> GovernanceDecision:
        """Check if a tool call is allowed before execution.

        Args:
            tool: Tool name (e.g. "Bash", "Write", "WebFetch")
            input: Tool input parameters
            agent: Agent identity (AgentIdentity or dict)
            data_subject: (P3.5) Data subject whose information is being processed.
                Supply for subject-keyed categories (PHI, EDUCATION_RECORD, etc.)
                to satisfy HIPAA §164.528 / FERPA §99.32 disclosure accounting.
            recipient: (P3.5) Party who will receive the AI output.
                Required on report_result for subject-keyed ALLOW decisions.
            transport: (P3.5) Transport channel for the AI output.
                Required on report_result for subject-keyed ALLOW decisions.
            user_id: (CRIT-39f) Customer-provided end-user identifier for the
                regulator-grade audit chain. The customer's app authenticates
                the end-user with their own auth system and forwards that
                identifier here. Recorded as `userId` in the gov-server CRIT-39e
                chain entry so the regulator can answer "who did it?"
            llm_model: (CRIT-39f) Identifier of the LLM the agent invoked
                (e.g. 'claude-opus-4-7', 'gpt-4o'). Recorded as `llmModel` in
                the chain entry so the regulator can answer "which model?"
            attestor: (F-NEW-CRIT-39e-2-PY) Per-call EndUserAttestor override.
                When set, the SDK calls `attestor.sign(ctx)` before posting
                and attaches `attestationToken` to the body + the
                `X-Attestation-Token` header. Falls back to the client-level
                attestor passed to `__init__`. AttestorError is wrapped into
                GovernanceViolation with a DENY decision.

        Returns:
            GovernanceDecision with allow/deny/require_approval

        Raises:
            GovernanceViolation: If enforce=True and action is denied, or if
                an attestor was supplied and signing failed.
            ValueError: If an attestor is in effect but `org_id` is not set
                on the client.
            RuntimeError: If an attestor is in effect on the sync client
                while inside a running event loop.
        """
        if isinstance(agent, dict):
            agent = AgentIdentity(**agent)

        ctx = ActionContext(tool=tool, input=input, agent=agent)
        body = ctx.to_dict()
        # P3.5: attach five-dimensional identity fields when supplied
        if data_subject is not None:
            body["dataSubject"] = data_subject.to_dict()
        if recipient is not None:
            body["recipient"] = recipient.to_dict()
        if transport is not None:
            body["transport"] = transport.to_dict()
        # F-NEW-CRIT-39f: forward regulator-grade audit fields. Omit the keys
        # entirely when None so the gov-server falls back to its own
        # 'unknown' default rather than recording bogus values.
        if user_id is not None:
            body["userId"] = user_id
        if llm_model is not None:
            body["llmModel"] = llm_model

        # F-NEW-CRIT-39e-2-PY Slice 4: end-user attestation wiring.
        request_headers: Optional[dict[str, str]] = None
        effective_attestor = attestor or self._default_attestor
        if effective_attestor is not None:
            if not self.org_id:
                raise ValueError(
                    "EndUserAttestor requires org_id to be set on "
                    "GovernanceClient. The org_id becomes the `aud` claim "
                    "on the attestation token. Pass org_id=<tenant uuid> "
                    "to GovernanceClient(...) or AsyncGovernanceClient(...)."
                )
            attestation_ctx = _build_attestation_context(
                tool=tool,
                input_dict=input,
                agent_name=agent.name,
                tenant_id=self.org_id,
                user_id=user_id,
            )
            try:
                signed = asyncio.run(effective_attestor.sign(attestation_ctx))
            except RuntimeError as loop_err:
                # asyncio.run() refuses to run when an event loop is already
                # active in this thread. The user must use AsyncGovernanceClient
                # from inside an async context.
                if "asyncio.run() cannot be called" in str(loop_err) or (
                    "running event loop" in str(loop_err)
                ):
                    raise RuntimeError(
                        "GovernanceClient.check_action(attestor=...) cannot "
                        "be called from inside a running event loop. Use "
                        "AsyncGovernanceClient with `await client.check_action"
                        "(...)` instead."
                    ) from loop_err
                raise
            except AttestorError as att_err:
                raise GovernanceViolation(
                    GovernanceDecision(
                        decision=DecisionType.DENY,
                        reason=f"End-user attestation failed: {att_err}",
                        audit_id="",
                        metadata={"attestorError": att_err.code},
                    )
                ) from att_err
            body["attestationToken"] = signed.token
            request_headers = {"X-Attestation-Token": signed.token}

        try:
            resp = self._client.post(
                "/api/v1/governance/check-action",
                json=body,
                headers=request_headers,
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                return self._fail_open_decision(e)
            raise
        decision = GovernanceDecision.from_dict(resp.json())

        if self.enforce and decision.denied:
            raise GovernanceViolation(decision)

        return decision

    def report_result(
        self,
        audit_id: str,
        success: bool,
        summary: str = "",
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
        recipient: Optional[RecipientIdentity] = None,
        transport: Optional[TransportDescriptor] = None,
    ) -> None:
        """Report the result of a tool call after execution.

        Args:
            audit_id: The audit ID from the check_action decision
            success: Whether the tool call succeeded
            summary: Brief output summary (never raw secrets)
            duration_ms: How long the tool call took
            error: Error message if success is False
            recipient: (P3.5) Party who received the AI output.
                Required when the original check_action was ALLOW on a
                subject-keyed category. Server returns 400 missing_disclosure_attribution
                if omitted in that case.
            transport: (P3.5) Transport channel used for delivery.
                Required when the original check_action was ALLOW on a
                subject-keyed category.
        """
        payload: dict[str, Any] = {
            "auditId": audit_id,
            "success": success,
            "outputSummary": summary,
        }
        if duration_ms is not None:
            payload["durationMs"] = duration_ms
        if error:
            payload["error"] = error
        # P3.5: attach five-dimensional identity fields when supplied
        if recipient is not None:
            payload["recipient"] = recipient.to_dict()
        if transport is not None:
            payload["transport"] = transport.to_dict()

        try:
            resp = self._client.post(
                "/api/v1/governance/report-result",
                json=payload,
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                print(
                    f"[WARN] Governance server unreachable during report_result: {e}. Fail-open policy applied.",
                    file=sys.stderr,
                )
                return
            raise

    def check_task(self, task: TaskContext) -> GovernanceDecision:
        """Check if an orchestrator task is allowed.

        For LangGraph, CrewAI, AutoGen task-level governance.
        """
        try:
            resp = self._client.post(
                "/api/v1/governance/check-task",
                json=task.to_dict(),
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                return self._fail_open_decision(e)
            raise
        decision = GovernanceDecision.from_dict(resp.json())

        if self.enforce and decision.denied:
            raise GovernanceViolation(decision)

        return decision

    def check_plan(self, plan: PlanContext) -> GovernanceDecision:
        """Check if a multi-step plan is allowed.

        Returns blocked_steps if individual steps are denied.
        """
        try:
            resp = self._client.post(
                "/api/v1/governance/check-plan",
                json=plan.to_dict(),
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                return self._fail_open_decision(e)
            raise
        decision = GovernanceDecision.from_dict(resp.json())

        if self.enforce and decision.denied:
            raise GovernanceViolation(decision)

        return decision

    def check_delegation(self, delegation: DelegationContext) -> GovernanceDecision:
        """Check if delegation from one agent to another is allowed.

        Returns restricted_permissions if some permissions are denied.
        """
        try:
            resp = self._client.post(
                "/api/v1/governance/check-delegation",
                json=delegation.to_dict(),
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                return self._fail_open_decision(e)
            raise
        decision = GovernanceDecision.from_dict(resp.json())

        if self.enforce and decision.denied:
            raise GovernanceViolation(decision)

        return decision

    def classify_output(
        self,
        audit_id: str,
        output: dict[str, Any],
        agent: Optional[AgentIdentity] = None,
    ) -> "ClassifiedResponse":
        """Classify LLM provider output against the nine-guard G-series.

        Calls POST /api/v1/governance/classify and returns a ClassifiedResponse.
        Used by LLM provider integrations (anthropic, openai, etc.) to screen
        model responses for secrets, PHI, and policy violations before returning
        them to callers.

        Args:
            audit_id: The audit ID from the preceding check_action call.
            output: The raw provider response dict to classify.
            agent: Optional agent identity for the classification context.

        Returns:
            ClassifiedResponse with guards_triggered and allowed flag.
        """
        payload: dict[str, Any] = {
            "auditId": audit_id,
            "output": output,
        }
        if agent is not None:
            payload["agent"] = agent.to_dict() if isinstance(agent, AgentIdentity) else agent

        try:
            resp = self._client.post(
                "/api/v1/governance/classify",
                json=payload,
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                import logging as _log
                _log.getLogger(__name__).warning(
                    "Governance server unreachable during classify_output: %s. Fail-open applied.",
                    e,
                )
                # H5: fail-open must still write a classify.fail-open audit event.
                # Attempt server-side chain entry; if that fails too, write locally.
                self._emit_fail_open_audit_event(
                    event_type="classify.fail-open",
                    audit_id=audit_id,
                    reason=str(e),
                )
                return ClassifiedResponse(
                    allowed=True,
                    guards_triggered=[],
                    audit_id=audit_id,
                    metadata={"failOpen": True, "error": str(e)},
                )
            raise
        data = resp.json()
        return ClassifiedResponse.from_dict(data, audit_id=audit_id)

    def _emit_fail_open_audit_event(
        self,
        event_type: str,
        audit_id: str,
        reason: str,
    ) -> None:
        """H5: Emit a fail-open audit event to the server chain or local fallback file.

        When the primary governance API is unreachable, this method:
          1. Attempts to POST the event to /api/v1/audit/fail-open-event.
          2. If that also fails, writes the event to a local JSONL fallback file at
             ~/.connexum/fail-open-audit.jsonl (mode 0600) so no audit record is lost.
        """
        import datetime
        import json
        import os
        import stat
        import logging as _log

        event = {
            "type": event_type,
            "auditId": audit_id,
            "reason": reason,
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            "installationId": self.installation_id,
            "orgId": self.org_id,
        }

        # Attempt server-side chain entry
        try:
            self._client.post(
                "/api/v1/audit/fail-open-event",
                json=event,
                timeout=2.0,
            )
            return  # Server accepted it
        except Exception:
            pass  # Fall through to local file

        # Local file fallback
        try:
            conn_dir = os.path.expanduser("~/.connexum")
            os.makedirs(conn_dir, exist_ok=True)
            fpath = os.path.join(conn_dir, "fail-open-audit.jsonl")
            with open(fpath, "a") as f:
                f.write(json.dumps(event) + "\n")
            os.chmod(fpath, stat.S_IRUSR | stat.S_IWUSR)  # 0600
        except Exception as exc:
            _log.getLogger(__name__).warning(
                "classify.fail-open audit event could not be persisted: %s", exc
            )

    def register_provider_compliance(
        self,
        provider: str,
        baa_available: bool,
        baa_scope: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> None:
        """Register provider BAA/compliance metadata with the governance server.

        Calls POST /api/v1/governance/provider-compliance. Non-fatal on failure
        (registration is informational and should not break the integration init).

        Args:
            provider: Provider identifier (e.g. 'anthropic', 'openai', 'azure_openai').
            baa_available: True if the provider offers a BAA for this deployment.
            baa_scope: Optional description of the BAA scope or tier.
            notes: Optional free-text notes (e.g. 'enterprise only', 'local -- no BAA required').
        """
        payload: dict[str, Any] = {
            "provider": provider,
            "baaAvailable": baa_available,
        }
        if baa_scope is not None:
            payload["baaScope"] = baa_scope
        if notes is not None:
            payload["notes"] = notes

        try:
            resp = self._client.post(
                "/api/v1/governance/provider-compliance",
                json=payload,
            )
            resp.raise_for_status()
        except Exception as exc:
            # H2: Registration failures are non-fatal; governance decisions are not
            # blocked by registration errors. Log so operators can detect systematic issues.
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "register_provider_compliance failed (non-fatal): %s", exc
            )

    def fetch_pack_registry(
        self,
        force_refresh: bool = False,
    ) -> "list[dict[str, Any]]":
        """Fetch the full pack registry from the governance server.

        Returns a list of pack descriptor dicts, each containing id, version,
        dataPolicy (scanCategories + categoryActions), and categoryClassifiers
        (pattern strings). Used to hydrate PackDrivenClassifier.

        Args:
            force_refresh: When True, bypass any server-side cache headers.

        Returns:
            List of pack descriptor dicts.
        """
        params: dict[str, Any] = {}
        if force_refresh:
            params["nocache"] = "1"
        try:
            resp = self._client.get("/api/v1/packs/registry", params=params)
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                import logging as _log
                _log.getLogger(__name__).warning(
                    "fetch_pack_registry: governance server unreachable: %s. Returning empty registry.",
                    e,
                )
                return []
            raise
        data = resp.json()
        # Server returns {"packs": [...]} or directly [...]
        if isinstance(data, list):
            return data
        return data.get("packs", [])

    def set_project_packs(
        self,
        pack_ids: "list[str]",
        versions: "Optional[dict[str, str]]" = None,
    ) -> None:
        """Set the active compliance pack selection for the project bound to this client.

        Requires that this client was constructed with project_id set (W2).
        Calls POST /api/v1/projects/:projectId/packs.

        Args:
            pack_ids: List of pack IDs to activate for the project.
            versions: Optional map from packId to semver string to pin versions.

        Raises:
            ValueError: If project_id was not set at construction time.
        """
        project_id = getattr(self, "_project_id", None)
        if not project_id:
            raise ValueError(
                "set_project_packs requires project_id to be set at GovernanceClient construction"
            )
        payload: dict[str, Any] = {"packIds": pack_ids}
        if versions:
            payload["versions"] = versions
        try:
            resp = self._client.post(
                f"/api/v1/projects/{project_id}/packs",
                json=payload,
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                import logging as _log
                _log.getLogger(__name__).warning(
                    "set_project_packs: governance server unreachable: %s. Fail-open applied.",
                    e,
                )
                return
            raise

    def get_project_packs(self) -> "dict[str, Any]":
        """Get the current pack selection for the project bound to this client.

        Calls GET /api/v1/projects/:projectId/packs.

        Returns:
            Dict with selectedPackIds and selectedPackVersions.
        """
        project_id = getattr(self, "_project_id", None)
        if not project_id:
            raise ValueError(
                "get_project_packs requires project_id to be set at GovernanceClient construction"
            )
        try:
            resp = self._client.get(f"/api/v1/projects/{project_id}/packs")
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                import logging as _log
                _log.getLogger(__name__).warning(
                    "get_project_packs: governance server unreachable: %s. Returning empty selection.",
                    e,
                )
                return {"selectedPackIds": [], "selectedPackVersions": {}}
            raise
        return resp.json()

    def report_pack_enforcement(
        self,
        pack_id: str,
        category_id: str,
        action: str,
        decision_id: str,
        pack_version: str,
        subject_digest: str,
    ) -> None:
        """Report a pack enforcement audit event to the governance server.

        Emits a canonical pack.enforcement.{action} audit event. Called
        automatically by PackDrivenClassifier when connected to a client.

        Args:
            pack_id: The compliance pack that fired.
            category_id: The category that matched.
            action: GovernanceAction string (BLOCK, WARN, etc.).
            decision_id: UUID of the classification decision.
            pack_version: Semver of the pack that produced the match.
            subject_digest: SHA-256 hex digest of the input (never raw input).
        """
        payload: dict[str, Any] = {
            "packId": pack_id,
            "categoryId": category_id,
            "action": action,
            "decisionId": decision_id,
            "packVersion": pack_version,
            "subjectDigest": subject_digest,
            "type": f"pack.enforcement.{action.lower()}",
        }
        try:
            resp = self._client.post(
                "/api/v1/governance/pack-enforcement",
                json=payload,
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                import logging as _log
                _log.getLogger(__name__).warning(
                    "report_pack_enforcement: server unreachable: %s. Fail-open applied.",
                    e,
                )
                return
            raise

    def health(self) -> dict[str, Any]:
        """Check API server health.

        Note: Health check always raises on failure, regardless of on_failure policy.
        """
        resp = self._client.get("/api/v1/health")
        resp.raise_for_status()
        return resp.json()

    def close(self) -> None:
        """Close the HTTP client and stop any background subscription revalidation."""
        self._client.close()
        if self._subscription_gate is not None:
            self._subscription_gate.stop()

    def __enter__(self) -> GovernanceClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncGovernanceClient:
    """Asynchronous governance client.

    Same API as GovernanceClient but uses async/await.
    Built on httpx.AsyncClient for use in async frameworks.

    Usage:
        async with AsyncGovernanceClient(
            api_url="http://localhost:3100",
            license_key="your-jwt-license-key",
        ) as gov:
            decision = await gov.check_action(
                tool="Bash",
                input={"command": "ls"},
                agent=AgentIdentity(name="dev-agent"),
            )
    """

    def __init__(
        self,
        api_url: str,
        license_key: str,
        installation_id: Optional[str] = None,
        org_id: Optional[str] = None,
        timeout: float = 5.0,
        enforce: bool = True,
        on_failure: Literal["open", "closed"] = "closed",
        attestor: Optional[EndUserAttestor] = None,
    ):
        self.api_url = api_url.rstrip("/")
        self.license_key = license_key
        self.installation_id = installation_id or "default"
        self.org_id = org_id
        self.enforce = enforce
        self.on_failure = on_failure
        self._default_attestor = attestor
        self._client = httpx.AsyncClient(
            base_url=self.api_url,
            headers={
                "Authorization": f"Bearer {license_key}",
                "Content-Type": "application/json",
                "X-Installation-Id": self.installation_id,
            },
            timeout=timeout,
        )

    def _fail_open_decision(self, error: Exception) -> GovernanceDecision:
        """Return a permissive decision when the governance server is unreachable."""
        print(
            f"[WARN] Governance server unreachable: {error}. Fail-open policy applied.",
            file=sys.stderr,
        )
        return GovernanceDecision(
            decision=DecisionType.ALLOW,
            reason="Governance server unreachable. Fail-open policy applied.",
            audit_id="",
            metadata={"failOpen": True, "error": str(error)},
        )

    async def check_action(
        self,
        tool: str,
        input: dict[str, Any],
        agent: AgentIdentity | dict[str, Any],
        data_subject: Optional[DataSubjectIdentity] = None,
        recipient: Optional[RecipientIdentity] = None,
        transport: Optional[TransportDescriptor] = None,
        user_id: Optional[str] = None,
        llm_model: Optional[str] = None,
        attestor: Optional[EndUserAttestor] = None,
    ) -> GovernanceDecision:
        """Async version of check_action. See GovernanceClient.check_action for full docs.

        Args:
            data_subject: (P3.5) Data subject identity for subject-keyed categories.
            recipient: (P3.5) Recipient of the AI output.
            transport: (P3.5) Transport mechanism used for delivery.
            user_id: (CRIT-39f) Customer-provided end-user identifier.
            llm_model: (CRIT-39f) LLM model the agent invoked.
            attestor: (F-NEW-CRIT-39e-2-PY) Per-call EndUserAttestor override.
                Falls back to the client-level default when None. AttestorError
                is wrapped into GovernanceViolation with a DENY decision.

        Raises:
            ValueError: if attestor is in effect but org_id is not set.
        """
        if isinstance(agent, dict):
            agent = AgentIdentity(**agent)

        ctx = ActionContext(tool=tool, input=input, agent=agent)
        body = ctx.to_dict()
        if data_subject is not None:
            body["dataSubject"] = data_subject.to_dict()
        if recipient is not None:
            body["recipient"] = recipient.to_dict()
        if transport is not None:
            body["transport"] = transport.to_dict()
        # F-NEW-CRIT-39f: forward regulator-grade audit fields.
        if user_id is not None:
            body["userId"] = user_id
        if llm_model is not None:
            body["llmModel"] = llm_model

        # F-NEW-CRIT-39e-2-PY Slice 4: end-user attestation wiring.
        request_headers: Optional[dict[str, str]] = None
        effective_attestor = attestor or self._default_attestor
        if effective_attestor is not None:
            if not self.org_id:
                raise ValueError(
                    "EndUserAttestor requires org_id to be set on "
                    "AsyncGovernanceClient. The org_id becomes the `aud` "
                    "claim on the attestation token. Pass org_id=<tenant "
                    "uuid> to AsyncGovernanceClient(...)."
                )
            attestation_ctx = _build_attestation_context(
                tool=tool,
                input_dict=input,
                agent_name=agent.name,
                tenant_id=self.org_id,
                user_id=user_id,
            )
            try:
                signed = await effective_attestor.sign(attestation_ctx)
            except AttestorError as att_err:
                raise GovernanceViolation(
                    GovernanceDecision(
                        decision=DecisionType.DENY,
                        reason=f"End-user attestation failed: {att_err}",
                        audit_id="",
                        metadata={"attestorError": att_err.code},
                    )
                ) from att_err
            body["attestationToken"] = signed.token
            request_headers = {"X-Attestation-Token": signed.token}

        try:
            resp = await self._client.post(
                "/api/v1/governance/check-action",
                json=body,
                headers=request_headers,
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                return self._fail_open_decision(e)
            raise
        decision = GovernanceDecision.from_dict(resp.json())

        if self.enforce and decision.denied:
            raise GovernanceViolation(decision)

        return decision

    async def report_result(
        self,
        audit_id: str,
        success: bool,
        summary: str = "",
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
        recipient: Optional[RecipientIdentity] = None,
        transport: Optional[TransportDescriptor] = None,
    ) -> None:
        """Async version of report_result. See GovernanceClient.report_result for full docs.

        Args:
            recipient: (P3.5) Party who received the AI output.
            transport: (P3.5) Transport channel used for delivery.
        """
        payload: dict[str, Any] = {
            "auditId": audit_id,
            "success": success,
            "outputSummary": summary,
        }
        if duration_ms is not None:
            payload["durationMs"] = duration_ms
        if error:
            payload["error"] = error
        # P3.5: attach five-dimensional identity fields when supplied
        if recipient is not None:
            payload["recipient"] = recipient.to_dict()
        if transport is not None:
            payload["transport"] = transport.to_dict()

        try:
            resp = await self._client.post(
                "/api/v1/governance/report-result",
                json=payload,
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                print(
                    f"[WARN] Governance server unreachable during report_result: {e}. Fail-open policy applied.",
                    file=sys.stderr,
                )
                return
            raise

    async def check_task(self, task: TaskContext) -> GovernanceDecision:
        """Async version of check_task."""
        try:
            resp = await self._client.post(
                "/api/v1/governance/check-task",
                json=task.to_dict(),
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                return self._fail_open_decision(e)
            raise
        decision = GovernanceDecision.from_dict(resp.json())
        if self.enforce and decision.denied:
            raise GovernanceViolation(decision)
        return decision

    async def check_plan(self, plan: PlanContext) -> GovernanceDecision:
        """Async version of check_plan."""
        try:
            resp = await self._client.post(
                "/api/v1/governance/check-plan",
                json=plan.to_dict(),
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                return self._fail_open_decision(e)
            raise
        decision = GovernanceDecision.from_dict(resp.json())
        if self.enforce and decision.denied:
            raise GovernanceViolation(decision)
        return decision

    async def check_delegation(
        self, delegation: DelegationContext
    ) -> GovernanceDecision:
        """Async version of check_delegation."""
        try:
            resp = await self._client.post(
                "/api/v1/governance/check-delegation",
                json=delegation.to_dict(),
            )
            resp.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as e:
            if self.on_failure == "open":
                return self._fail_open_decision(e)
            raise
        decision = GovernanceDecision.from_dict(resp.json())
        if self.enforce and decision.denied:
            raise GovernanceViolation(decision)
        return decision

    async def health(self) -> dict[str, Any]:
        """Async version of health.

        Note: Health check always raises on failure, regardless of on_failure policy.
        """
        resp = await self._client.get("/api/v1/health")
        resp.raise_for_status()
        return resp.json()

    async def close(self) -> None:
        """Close the async HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> AsyncGovernanceClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


# ---------------------------------------------------------------------------
# GAP-S1-03: BiasClient -- thin HTTP wrapper for bias analysis endpoints
# ---------------------------------------------------------------------------

class BiasClient:
    """HTTP wrapper for the My Compliance Center bias analysis API.

    Provides typed access to equalized-odds (GAP-S1-03) and demographic-parity
    (P1D-05) bias endpoints.

    Usage::

        client = BiasClient(api_url="http://localhost:3100", api_token="your-token")
        result = client.submit_bias_analysis(
            agent_id="my-agent",
            records=[
                {"group": "female", "outcome": 1, "label": 1},
                {"group": "male",   "outcome": 0, "label": 1},
            ],
        )
        if result["equalizedOdds"]["tprViolation"]:
            print("TPR gap detected:", result["equalizedOdds"]["maxTprGap"])

    """

    def __init__(
        self,
        api_url: str,
        api_token: str,
        timeout: float = 10.0,
    ) -> None:
        self._base = api_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base,
            headers={
                "Authorization": f"Bearer {api_token}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    # ------------------------------------------------------------------
    # GAP-S1-03: Equalized odds
    # ------------------------------------------------------------------

    def submit_bias_analysis(
        self,
        agent_id: str,
        records: "list[dict[str, Any]]",
        tpr_threshold: "Optional[float]" = None,
        fpr_threshold: "Optional[float]" = None,
    ) -> "dict[str, Any]":
        """Submit outcome records and run equalized-odds assessment.

        Args:
            agent_id: The agent whose outcomes are being analyzed.
            records: List of dicts with keys ``group`` (str), ``outcome`` (0|1),
                ``label`` (0|1).
            tpr_threshold: TPR gap flagging threshold (default 0.10 server-side).
            fpr_threshold: FPR gap flagging threshold (default 0.10 server-side).

        Returns:
            Dict with keys ``recorded`` (int), ``totalRecords`` (int), and
            ``equalizedOdds`` (the full EO result dict).
        """
        # 1. Submit records.
        resp = self._client.post(
            "/api/v1/bias/equalized-odds/samples",
            json={"agentId": agent_id, "records": records},
        )
        resp.raise_for_status()
        submit = resp.json()

        # 2. Run assessment.
        assess_body: "dict[str, Any]" = {}
        if tpr_threshold is not None:
            assess_body["tprThreshold"] = tpr_threshold
        if fpr_threshold is not None:
            assess_body["fprThreshold"] = fpr_threshold
        resp2 = self._client.post(
            f"/api/v1/bias/equalized-odds/assess/{agent_id}",
            json=assess_body,
        )
        resp2.raise_for_status()
        eo = resp2.json()

        return {
            "recorded": submit.get("recorded"),
            "totalRecords": submit.get("totalRecords"),
            "equalizedOdds": eo,
        }

    def get_equalized_odds(self, agent_id: str) -> "Optional[dict[str, Any]]":
        """Retrieve the latest equalized-odds result for an agent.

        Returns None if no assessment exists yet.
        """
        resp = self._client.get(f"/api/v1/bias/equalized-odds/{agent_id}")
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # P1D-05: Demographic parity / disparate impact (original)
    # ------------------------------------------------------------------

    def submit_sample(
        self,
        agent_id: str,
        categories: "dict[str, str]",
        numeric_features: "Optional[dict[str, float]]" = None,
    ) -> "dict[str, Any]":
        """Submit a demographic-parity sample.

        Args:
            agent_id: The agent the sample belongs to.
            categories: Dict of protected category names to group values,
                e.g. ``{"gender": "female", "region": "US"}``.
            numeric_features: Optional numeric feature values for OOD detection.
        """
        payload: "dict[str, Any]" = {"agentId": agent_id, "categories": categories}
        if numeric_features is not None:
            payload["numericFeatures"] = numeric_features
        resp = self._client.post("/api/v1/bias/samples", json=payload)
        resp.raise_for_status()
        return resp.json()

    def run_assessment(self, agent_id: str, agent_name: str) -> "dict[str, Any]":
        """Run the full bias assessment (demographic parity, disparate impact, chi-square)."""
        resp = self._client.post(
            f"/api/v1/bias/assess/{agent_id}",
            json={"agentName": agent_name},
        )
        resp.raise_for_status()
        return resp.json()

    def get_fairness_summary(self, agent_id: str) -> "Optional[dict[str, Any]]":
        """Get focused fairness summary (demographic parity + disparate impact)."""
        resp = self._client.get(f"/api/v1/bias/fairness/{agent_id}")
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "BiasClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
