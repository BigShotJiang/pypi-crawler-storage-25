"""
Standalone Gemma adapter — Python parity of src/llm-adapters/gemma.ts.

F-NEW-GEMMA-PY (Tier 4.5). Companion to F-NEW-GEMMA-ADAPTER (the TS side).

Gemma is Google's open-weight family deployable to four real-world targets
(Vertex AI Model Garden / Google AI Studio generative-language / HuggingFace
Inference / customer self-hosted Ollama). The BAA / open-weight provenance
flags differ per target. This module centralises the metadata + validation
so Python client code calling GovernanceClient.check_action() can compute
the right flags before issuing the wire request.

This file is metadata + validation only. Actual HTTP traffic to Gemma
endpoints is handled by the customer's preferred Python LLM SDK
(`google-generativeai`, `vertexai`, `huggingface_hub`, `ollama`); this
module does not call out to any LLM provider.

Mirrors:
  - TS: src/llm-adapters/gemma.ts
  - TS tests: tests/llm-adapters/gemma.test.ts

@connexum_governance / Python SDK
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

GemmaDeploymentTarget = Literal[
    "vertex-ai",
    "generative-language",
    "huggingface",
    "self-hosted-ollama",
]


@dataclass(frozen=True)
class GemmaMetadata:
    """Audit-chain metadata bundle for one Gemma call.

    Attributes match the TS `GemmaMetadata` interface field-for-field so
    cross-SDK audit consumers can rely on a single shape.
    """

    family: Literal["gemma"]
    """Always 'gemma'. Kept for shape-parity with other adapter metadata."""

    is_open_weight: Literal[True]
    """Always True for Gemma — auditors care that the model is open-weight."""

    baa_inherits: bool
    """
    Whether the deployment target's BAA covers Gemma usage:
      - vertex-ai            → True  (Vertex BAA covers Model Garden models)
      - generative-language  → False (Google AI Studio has no BAA)
      - huggingface          → False (BAA is a separate HF contract)
      - self-hosted-ollama   → False (BAA is customer-side; we cannot assert)
    """

    display_name: str
    """
    Audit-chain display name combining modelId + deployment target so two
    audit entries for the same modelId served from different hosters are
    distinguishable in compliance reports.
    """

    deployment_target: GemmaDeploymentTarget
    """Echo of the input deployment target so consumers can pass-through."""


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Frozen tuple — caller cannot mutate.
KNOWN_GEMMA_MODEL_IDS: tuple[str, ...] = (
    # Text-only Gemma 2
    "gemma-2-2b-it",
    "gemma-2-9b-it",
    "gemma-2-27b-it",
    # Multimodal paligemma (F-NEW-GEMMA-VISION)
    "paligemma-3b-mix-224",
    "paligemma-3b-mix-448",
    "paligemma-3b-pt-224",
    "paligemma-3b-pt-448",
    "paligemma-3b-pt-896",
)

# Multimodal subset of KNOWN_GEMMA_MODEL_IDS — paligemma family.
_GEMMA_VISION_SET: frozenset[str] = frozenset({
    "paligemma-3b-mix-224",
    "paligemma-3b-mix-448",
    "paligemma-3b-pt-224",
    "paligemma-3b-pt-448",
    "paligemma-3b-pt-896",
})

_ALLOWED_DEPLOYMENT_TARGETS: frozenset[str] = frozenset({
    "vertex-ai",
    "generative-language",
    "huggingface",
    "self-hosted-ollama",
})

_TARGET_LABEL: dict[str, str] = {
    "vertex-ai": "Vertex AI",
    "generative-language": "Google AI Studio",
    "huggingface": "HuggingFace Inference",
    "self-hosted-ollama": "Self-hosted (Ollama)",
}


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_gemma_model_id(model_id: str) -> bool:
    """
    Return True if `model_id` is a recognised Gemma model ID.

    Recognition is (a) exact match against KNOWN_GEMMA_MODEL_IDS, or
    (b) lowercase `gemma-` / `paligemma-` prefix. Future Gemma 3 / 4 IDs
    validate via the prefix path without requiring this file to change.

    Case-sensitive — "Gemma-2-9b-it" with a capital G is rejected. Defends
    against typo / copy-paste from marketing material that uses Title Case.
    """
    if not isinstance(model_id, str) or not model_id:
        return False
    if model_id in KNOWN_GEMMA_MODEL_IDS:
        return True
    return model_id.startswith("gemma-") or model_id.startswith("paligemma-")


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------

def get_gemma_metadata(
    model_id: str,
    deployment_target: GemmaDeploymentTarget,
) -> GemmaMetadata:
    """
    Produce the metadata bundle for a Gemma call. Raises `ValueError` on
    unknown deployment target so a typo at the call site fails loudly
    instead of silently fabricating a BAA flag.
    """
    if deployment_target not in _ALLOWED_DEPLOYMENT_TARGETS:
        raise ValueError(
            f"Unknown Gemma deployment target: {deployment_target!r}. "
            f"Expected one of: {sorted(_ALLOWED_DEPLOYMENT_TARGETS)}."
        )

    # BAA inheritance: only Vertex AI carries an inherited BAA today.
    baa_inherits = deployment_target == "vertex-ai"

    target_label = _TARGET_LABEL[deployment_target]
    display_name = f"Google Gemma (open-weight): {model_id} via {target_label}"

    return GemmaMetadata(
        family="gemma",
        is_open_weight=True,
        baa_inherits=baa_inherits,
        display_name=display_name,
        deployment_target=deployment_target,
    )


# ---------------------------------------------------------------------------
# Multimodal detection
# ---------------------------------------------------------------------------

def is_gemma_multimodal(model_id: str) -> bool:
    """
    Return True if the model is multimodal (image+text in). Returns False
    for non-Gemma IDs. Matches the TS isGemmaMultimodal() semantics.
    """
    if not validate_gemma_model_id(model_id):
        return False
    if model_id in _GEMMA_VISION_SET:
        return True
    return model_id.lower().startswith("paligemma-")


# ---------------------------------------------------------------------------
# Subfamily helper
# ---------------------------------------------------------------------------

def gemma_subfamily_of(model_id: str) -> Optional[Literal["gemma"]]:
    """
    Return 'gemma' if the model_id is a recognised Gemma family ID,
    otherwise None. Useful when a caller has an arbitrary model_id and
    wants to route to the Gemma-specific path only on a definite match.
    """
    return "gemma" if validate_gemma_model_id(model_id) else None
