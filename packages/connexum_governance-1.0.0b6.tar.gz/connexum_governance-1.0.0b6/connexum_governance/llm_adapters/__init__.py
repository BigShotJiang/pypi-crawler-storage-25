"""
LLM adapter metadata + validation helpers.

The Python SDK is a thin HTTP client per the package README; wire-level LLM
adapter logic lives in the TypeScript governance server. This module exports
the Python-side equivalents of the small metadata + validation pieces that
client code needs BEFORE sending a governance check request — e.g. validate
the Gemma model ID, derive the BAA inheritance flag per deployment target.

Symbols re-exported here mirror the TypeScript surface at
`src/llm-adapters/<adapter>.ts` so audit consumers reading the chain from
either SDK see semantically equivalent metadata.
"""

from .gemma import (
    GemmaDeploymentTarget,
    GemmaMetadata,
    KNOWN_GEMMA_MODEL_IDS,
    validate_gemma_model_id,
    get_gemma_metadata,
    is_gemma_multimodal,
    gemma_subfamily_of,
)

__all__ = [
    "GemmaDeploymentTarget",
    "GemmaMetadata",
    "KNOWN_GEMMA_MODEL_IDS",
    "validate_gemma_model_id",
    "get_gemma_metadata",
    "is_gemma_multimodal",
    "gemma_subfamily_of",
]
