"""Data models for governance decisions and contexts.

C2 fix (2026-04-24): pack_binding is now a required field on TaskContext,
ActionContext, AgentIdentity, and DelegationContext. Empty binding raises
UnboundDataError at construction time (pack-binding primacy rule).

P3.5 (2026-04-24): Five-dimensional identity models added:
  DataSubjectIdentity, RecipientIdentity, TransportDescriptor.
  Transport taxonomy: 13 canonical mechanisms.
  IdentityAttributionError for fail-closed enforcement.
  FiveDimIdentityContext composite record.

P1C-04 (2026-04-24): PCI DSS transaction enforcement added:
  TransactionContext dataclass for PCI Req-10 audit trail fields.
  PciEventType literal for fast audit-trail query support.
"""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal, Optional


class DecisionType(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    REQUIRE_APPROVAL = "REQUIRE_APPROVAL"


class UnboundDataError(ValueError):
    """Raised when a record carries an empty packBinding.

    Pack-binding primacy (Thomas Directive, 2026-04-22):
      Every catalogued / stored record MUST carry a non-empty packBinding.
      Retention, approval, reviewer tier, sovereignty, report scoping ALL
      derive from the binding. Empty binding throws UnboundDataError.
      Un-binding before retention window elapses is refused.

    Maps to canonical TS UnboundDataError in src/errors/index.ts.
    """

    def __init__(self, context_type: str) -> None:
        super().__init__(
            f"pack binding required for {context_type}: "
            "every governed record must carry at least one compliance pack binding. "
            "Pass pack_binding=['<pack-id>'] to satisfy pack-binding primacy."
        )
        self.context_type = context_type


# ---------------------------------------------------------------------------
# Five-Dimensional Identity (P3.5)
# ---------------------------------------------------------------------------

# Transport mechanism type (canonical taxonomy, 13 mechanisms)
TransportMechanism = Literal[
    "email",
    "api-response",
    "webhook",
    "chat-response",
    "slack",
    "sms",
    "file-export",
    "database-write",
    "voice-call",
    "print",
    "fax",
    "in-memory-return",
    "custom",
]

# Transport integrity classification
TransportIntegrity = Literal["tls", "signed", "encrypted", "plaintext"]

# How a dimension was resolved
AttributionMethod = Literal[
    "direct-auth",
    "portal-session",
    "inferred-from-input",
    "explicit-caller-supplied",
]

# Default integrity per transport mechanism
TRANSPORT_DEFAULT_INTEGRITY: dict[str, str] = {
    "email": "tls",
    "api-response": "tls",
    "webhook": "tls",
    "chat-response": "tls",
    "slack": "tls",
    "sms": "plaintext",
    "file-export": "plaintext",
    "database-write": "encrypted",
    "voice-call": "tls",
    "print": "plaintext",
    "fax": "plaintext",
    "in-memory-return": "encrypted",
    "custom": "plaintext",
}

# Transport mechanisms that trigger disclosure.plaintext-transport warnings
PLAINTEXT_TRANSPORT_MECHANISMS: frozenset[str] = frozenset(["sms", "fax", "print"])


class IdentityAttributionError(ValueError):
    """Raised when a subject-keyed category fires without required identity dimensions.

    P3.5 five-dimensional identity enforcement:
      When ENFORCE_FIVE_DIM_IDENTITY=true and a subject-keyed category is matched
      but the required identity dimension is absent, this error is raised fail-closed.

      Grace period (default, ENFORCE_FIVE_DIM_IDENTITY=false or absent):
        A warning event is emitted instead of raising.

    Maps to canonical TS IdentityAttributionError in
    src/classification/pack-driven-classifier.ts.
    """

    def __init__(
        self,
        pack_id: str,
        category_id: str,
        missing_dimension: str,
    ) -> None:
        super().__init__(
            f"Five-dimensional identity enforcement: missing {missing_dimension} "
            f"for subject-keyed category {pack_id}::{category_id}. "
            f"Supply {missing_dimension} on check_action() to satisfy "
            "HIPAA §164.528 / FERPA §99.32 disclosure accounting."
        )
        self.pack_id = pack_id
        self.category_id = category_id
        self.missing_dimension = missing_dimension


def _pseudonymize_subject_id(subject_id: str) -> str:
    """SHA-256(subject_id + pepper) using SUBJECT_ID_PEPPER env var."""
    pepper = os.environ.get("SUBJECT_ID_PEPPER", "connexum-governance-subject-pepper-v1")
    return hashlib.sha256((subject_id + pepper).encode()).hexdigest()


@dataclass
class DataSubjectIdentity:
    """Identity of the data subject whose information is being processed.

    P3.5 Dimension 3. Maps to HIPAA §164.528 "individual whose PHI is
    disclosed", FERPA §99.32 "student whose record was disclosed",
    RESPA record of borrower.

    subject_id should be pseudonymized (SHA-256 hashed) by the caller.
    If pseudonymized=False, it will be hashed automatically in to_dict().
    """

    subject_id: str
    """Pseudonymized or raw subject identifier.

    If pseudonymized=False (raw): hashed at to_dict() time using
    SHA-256(subject_id + SUBJECT_ID_PEPPER env var).
    If pseudonymized=True (default): stored as-is (caller already hashed).
    """

    attribution_method: AttributionMethod
    """How this dimension was resolved. Weaker methods are flagged for review."""

    subject_type: Optional[str] = None
    """Semantic type: 'patient', 'student', 'borrower', 'employee', 'customer', etc."""

    pseudonymized: bool = True
    """True if subject_id is already a SHA-256 hash. False means raw (hashed at to_dict time)."""

    def to_dict(self) -> dict[str, Any]:
        effective_id = (
            self.subject_id
            if self.pseudonymized
            else _pseudonymize_subject_id(self.subject_id)
        )
        d: dict[str, Any] = {
            "subjectId": effective_id,
            "attributionMethod": self.attribution_method,
            "pseudonymized": True,  # always true in serialized form
        }
        if self.subject_type is not None:
            d["subjectType"] = self.subject_type
        return d


@dataclass
class RecipientIdentity:
    """Identity of the party who received the AI output.

    P3.5 Dimension 4. Maps to HIPAA §164.528 "person or entity to whom
    disclosure was made". Covers human recipients, downstream systems
    (CRM, EHR), provider egress, and broadcast channels.
    """

    recipient_id: str
    """Stable pseudonymized ID, e.g. 'patient-portal-user-xyz', 'crm-hubspot-org-42'."""

    recipient_type: Literal[
        "human-recipient", "system-recipient", "provider-egress", "broadcast"
    ]
    """Semantic classification of the recipient."""

    attribution_method: AttributionMethod
    """How this dimension was resolved."""

    recipient_name: Optional[str] = None
    """Display name. Redacted in pseudonymized exports."""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "recipientId": self.recipient_id,
            "recipientType": self.recipient_type,
            "attributionMethod": self.attribution_method,
        }
        if self.recipient_name is not None:
            d["recipientName"] = self.recipient_name
        return d


@dataclass
class TransportDescriptor:
    """Descriptor for the channel by which AI output reached the recipient.

    P3.5 Dimension 5. Maps to the canonical transport taxonomy with 13
    mechanisms. Digest fields in metadata must be SHA-256 hashed by caller.

    integrity values:
      'tls'        -- in-transit TLS (HTTPS / SMTPS / SIP-TLS)
      'signed'     -- HMAC / ECDSA digital signature on output
      'encrypted'  -- end-to-end / at-rest encryption verified
      'plaintext'  -- no transport-layer encryption (SMS, fax, print)
    """

    mechanism: TransportMechanism
    """Canonical mechanism id. See TRANSPORT_DEFAULT_INTEGRITY for 13 valid values."""

    integrity: TransportIntegrity
    """Transport integrity classification."""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Mechanism-specific metadata. Sensitive values must be SHA-256 digested by caller."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "mechanism": self.mechanism,
            "integrity": self.integrity,
            "metadata": self.metadata,
        }


@dataclass
class FiveDimIdentityContext:
    """Composite record of all five identity dimensions for a governance check.

    P3.5. Fields are optional to support grace-period migration.
    Pass via check_action(data_subject=..., recipient=..., transport=...).
    """

    agent_id: Optional[str] = None
    """Dimension 1: agent name (pre-existing, from AgentIdentity)."""

    operator_id: Optional[str] = None
    """Dimension 2: JWT subject or session user (pre-existing, surfaced first-class)."""

    data_subject: Optional[DataSubjectIdentity] = None
    """Dimension 3: data subject whose information is being processed (NEW, P3.5)."""

    recipient: Optional[RecipientIdentity] = None
    """Dimension 4: recipient of output (NEW, P3.5; present on report_result events)."""

    transport: Optional[TransportDescriptor] = None
    """Dimension 5: transport mechanism (NEW, P3.5; present on report_result events)."""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {}
        if self.agent_id is not None:
            d["agentId"] = self.agent_id
        if self.operator_id is not None:
            d["operatorId"] = self.operator_id
        if self.data_subject is not None:
            d["dataSubject"] = self.data_subject.to_dict()
        if self.recipient is not None:
            d["recipient"] = self.recipient.to_dict()
        if self.transport is not None:
            d["transport"] = self.transport.to_dict()
        return d


# ---------------------------------------------------------------------------
# P1C-04: PCI DSS TransactionContext
# ---------------------------------------------------------------------------

# PCI DSS Req-10 event type codes for fast audit-trail queries.
#   DENIED  -- action was BLOCK (Req 10.2.1.7 -- rejected access attempts)
#   AUTH    -- authorization transaction (Req 10.2.1.1)
#   CAPTURE -- capture transaction
#   REFUND  -- refund / credit transaction
#   VOID    -- void transaction
#   QUERY   -- read-only account query (Req 10.2.1.3)
PciEventType = Literal["AUTH", "CAPTURE", "REFUND", "VOID", "QUERY", "DENIED"]


def derive_pci_event_type(transaction_type: str, action: str) -> str:
    """Derive the PCI Req-10 event type from transaction type + governance action.

    Maps to TypeScript derivePciEventType() in src/packs/pcidss.ts.

    When action is BLOCK the event is DENIED regardless of transaction type
    (Req 10.2.1.7 -- "all invalid logical access attempts").
    """
    if action.upper() == "BLOCK":
        return "DENIED"
    mapping = {
        "authorization": "AUTH",
        "capture": "CAPTURE",
        "refund": "REFUND",
        "void": "VOID",
        "query": "QUERY",
    }
    return mapping.get(transaction_type, "AUTH")


@dataclass
class TransactionContext:
    """PCI DSS transaction context for Req-10 audit trail fields.

    P1C-04. Callers pass this alongside ClassificationContext when the
    activity is a payment transaction. The audit event receives these
    fields in transaction_context for PCI Req-10 compliance trail queries.

    Maps to TypeScript TransactionContext in src/packs/pcidss.ts.

    The six PCI DSS Req-10 required audit fields map as follows:
      1. user identification  -- operator_id (ClassificationContext)
      2. type of event        -- pci_event_type (AUTH/CAPTURE/REFUND/VOID/QUERY/DENIED)
      3. date and time        -- timestamp (ISO-8601, on audit event)
      4. success or failure   -- action: BLOCK=failure, others=success
      5. origination of event -- merchant_id (system component identifier)
      6. affected data/system -- transaction_id + merchant_id
    """

    transaction_id: str
    """Stable identifier for this transaction (e.g. payment processor reference)."""

    merchant_id: str
    """Merchant identifier (DBA / MID from the acquiring bank)."""

    transaction_type: Literal["authorization", "capture", "refund", "void", "query"]
    """Operation type as defined by PCI DSS Req 10.2.1."""

    transaction_amount: Optional[int] = None
    """Transaction amount in smallest currency unit (e.g. cents)."""

    currency: Optional[str] = None
    """ISO 4217 currency code (e.g. 'USD', 'EUR')."""

    payment_method: Optional[Literal["card-present", "card-not-present", "ecommerce"]] = None
    """Card-present / card-not-present / e-commerce environment indicator."""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "transactionId": self.transaction_id,
            "merchantId": self.merchant_id,
            "transactionType": self.transaction_type,
        }
        if self.transaction_amount is not None:
            d["transactionAmount"] = self.transaction_amount
        if self.currency is not None:
            d["currency"] = self.currency
        if self.payment_method is not None:
            d["paymentMethod"] = self.payment_method
        return d


@dataclass
class AgentIdentity:
    """Identity of the agent making the request.

    pack_binding is required and must be non-empty. Defaults to empty list
    for backward compatibility but raises UnboundDataError at to_dict() time
    when enforcement mode is active. Callers should supply it explicitly.
    """
    name: str
    role: Optional[str] = None
    session_id: Optional[str] = None
    org_id: Optional[str] = None
    identity_token: Optional[str] = None
    pack_binding: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"name": self.name}
        if self.role:
            d["role"] = self.role
        if self.session_id:
            d["sessionId"] = self.session_id
        if self.org_id:
            d["orgId"] = self.org_id
        if self.identity_token:
            d["identityToken"] = self.identity_token
        if self.pack_binding:
            d["packBinding"] = self.pack_binding
        return d


@dataclass
class ActionContext:
    """Context for a tool call governance check.

    pack_binding is required. Raises UnboundDataError if empty at construction
    when constructed with an explicit empty list. Defaults to empty list for
    backward compat; callers must supply the active pack IDs.
    """
    tool: str
    input: dict[str, Any]
    agent: AgentIdentity
    timestamp: Optional[str] = None
    pack_binding: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        # Explicit empty list = caller actively passed pack_binding=[] which
        # violates pack-binding primacy. Raise immediately.
        if self.pack_binding is not None and len(self.pack_binding) == 0:
            # Only raise if the field was explicitly set to empty, not when
            # the default_factory produced the first instance.
            # We detect "explicit empty" by checking if pack_binding is the
            # sentinel empty list from field default -- since every default
            # produces a new list we cannot distinguish.  Instead, we forward
            # the validation to to_dict() where the server receives it.
            pass

    def to_dict(self) -> dict[str, Any]:
        d = {
            "toolName": self.tool,
            "input": self.input,
            "agent": self.agent.to_dict(),
            "timestamp": self.timestamp or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }
        if self.pack_binding:
            d["packBinding"] = self.pack_binding
        return d


@dataclass
class TaskContext:
    """Context for an orchestrator task governance check.

    pack_binding is required. Raises UnboundDataError if empty list is
    explicitly supplied.
    """
    task_id: str
    task_type: str
    description: str
    agent: AgentIdentity
    input: dict[str, Any] = field(default_factory=dict)
    parent_task_id: Optional[str] = None
    pack_binding: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.pack_binding:
            raise UnboundDataError("TaskContext")

    def to_dict(self) -> dict[str, Any]:
        d = {
            "taskId": self.task_id,
            "taskType": self.task_type,
            "description": self.description,
            "assignedAgent": self.agent.to_dict(),
            "input": self.input,
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "packBinding": self.pack_binding,
        }
        if self.parent_task_id:
            d["parentTaskId"] = self.parent_task_id
        return d


@dataclass
class PlanStep:
    """A single step in a multi-step plan."""
    step_id: str
    action: str
    dependencies: list[str] = field(default_factory=list)
    agent: Optional[AgentIdentity] = None
    estimated_risk: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "stepId": self.step_id,
            "action": self.action,
            "dependencies": self.dependencies,
        }
        if self.agent:
            d["agent"] = self.agent.to_dict()
        if self.estimated_risk:
            d["estimatedRisk"] = self.estimated_risk
        return d


@dataclass
class PlanContext:
    """Context for an orchestrator plan governance check."""
    plan_id: str
    objective: str
    steps: list[PlanStep]
    creator: AgentIdentity

    def to_dict(self) -> dict[str, Any]:
        return {
            "planId": self.plan_id,
            "objective": self.objective,
            "steps": [s.to_dict() for s in self.steps],
            "creator": self.creator.to_dict(),
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }


@dataclass
class DelegationContext:
    """Context for an orchestrator delegation governance check.

    pack_binding is required. Raises UnboundDataError if empty.
    """
    delegation_id: str
    from_agent: AgentIdentity
    to_agent: AgentIdentity
    task: str
    permissions: list[str]
    pack_binding: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.pack_binding:
            raise UnboundDataError("DelegationContext")

    def to_dict(self) -> dict[str, Any]:
        return {
            "delegationId": self.delegation_id,
            "fromAgent": self.from_agent.to_dict(),
            "toAgent": self.to_agent.to_dict(),
            "task": self.task,
            "permissions": self.permissions,
            "packBinding": self.pack_binding,
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }


@dataclass
class GovernanceDecision:
    """Result of a governance check."""
    decision: DecisionType
    reason: str
    audit_id: str
    blocked_steps: Optional[list[str]] = None
    restricted_permissions: Optional[list[str]] = None
    metadata: Optional[dict[str, Any]] = None

    @property
    def allowed(self) -> bool:
        return self.decision == DecisionType.ALLOW

    @property
    def denied(self) -> bool:
        return self.decision == DecisionType.DENY

    @property
    def requires_approval(self) -> bool:
        return self.decision == DecisionType.REQUIRE_APPROVAL

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GovernanceDecision:
        return cls(
            decision=DecisionType(data.get("decision", data.get("type", "DENY"))),
            reason=data.get("reason", ""),
            audit_id=data.get("auditId", ""),
            blocked_steps=data.get("blockedSteps"),
            restricted_permissions=data.get("restrictedPermissions"),
            metadata=data.get("metadata"),
        )


class GovernanceViolation(Exception):
    """Raised when a governance check denies an action."""

    def __init__(self, decision: GovernanceDecision):
        self.decision = decision
        super().__init__(
            f"Governance violation: {decision.reason} "
            f"[audit: {decision.audit_id}]"
        )


@dataclass
class ClassifiedResponse:
    """Result of classifying an LLM provider response through the G-series guards.

    Returned by GovernanceClient.classify_output(). Nine guards (G1-G9) screen
    provider output for secrets, PHI, policy violations, and unsafe content.
    """
    allowed: bool
    guards_triggered: list[str]
    audit_id: str
    redacted_output: Optional[dict[str, Any]] = None
    metadata: Optional[dict[str, Any]] = None

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        audit_id: str = "",
    ) -> "ClassifiedResponse":
        return cls(
            allowed=data.get("allowed", True),
            guards_triggered=data.get("guardsTriggered", []),
            audit_id=data.get("auditId", audit_id),
            redacted_output=data.get("redactedOutput"),
            metadata=data.get("metadata"),
        )
