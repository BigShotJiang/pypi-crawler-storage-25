"""
connexum_governance.preflight -- Slice 4 of F-NEW-PRODUCT-AGENT-DIR-WRAPPER.

For each agent entry in governance.json (populated by the --agent-dir scanner),
issue a synthetic check_action probe to the local governance sidecar and
verify the governance hook fires. No LLM API calls are made; this is a
wiring test only.

Usage (CLI):
    CONNEXUM_GOVERNANCE_JSON=./governance.json python3 -m connexum_governance.preflight

Usage (API):
    from connexum_governance.preflight import run_preflight
    report = run_preflight()
    print(report.summary_line())
    if not report.passed_all():
        sys.exit(1)

Returns a PreflightReport with a per-agent PreflightAgentResult. An agent
is PASS if the sidecar returns a structured decision response (any of ALLOW /
DENY / REQUIRE_APPROVAL / BLOCK) — proof that the governance hook is reachable
and pack policy is being evaluated. FAIL indicates a network error, a 5xx
response, or a missing `decision` field (governance not wired).

F-NEW-PRODUCT-AGENT-DIR-WRAPPER slice 4
@connexum/python-sdk
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx

_log = logging.getLogger(__name__)

# Synthetic tool name used for preflight probes — does not trigger any
# real behaviour; it is chosen to be recognisable in audit logs.
_PREFLIGHT_TOOL_NAME = "__connexum_preflight_probe__"

_VALID_DECISIONS = frozenset({"ALLOW", "DENY", "REQUIRE_APPROVAL", "BLOCK"})

# Default sidecar URL — mirrors the testbed start-sidecar.sh default.
DEFAULT_SIDECAR_URL = os.environ.get(
    "CONNEXUM_TESTBED_URL", "http://127.0.0.1:4200"
)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class PreflightAgentResult:
    """Per-agent wiring verification result."""

    agent_id: str
    file_path: str
    provider: str
    framework: Optional[str]
    packs: list[str]
    passed: bool
    decision: Optional[str]
    audit_id: Optional[str]
    error: Optional[str]
    elapsed_ms: float

    def status_symbol(self) -> str:
        return "✓" if self.passed else "✗"

    def one_line(self) -> str:
        if self.passed:
            return (
                f"  {self.status_symbol()} {self.file_path} "
                f"[{self.provider}] → {self.decision} "
                f"({self.elapsed_ms:.0f}ms)"
            )
        return (
            f"  {self.status_symbol()} {self.file_path} "
            f"[{self.provider}] → FAIL: {self.error}"
        )


@dataclass
class PreflightReport:
    """Summary of all per-agent preflight probes."""

    total: int
    passed: int
    failed: int
    results: list[PreflightAgentResult] = field(default_factory=list)
    sidecar_url: str = DEFAULT_SIDECAR_URL
    elapsed_seconds: float = 0.0

    def passed_all(self) -> bool:
        return self.failed == 0

    def summary_line(self) -> str:
        if self.total == 0:
            return "No agents found in governance.json — nothing to preflight."
        if self.passed_all():
            return (
                f"{self.passed}/{self.total} agents governed successfully "
                f"({self.elapsed_seconds:.1f}s)"
            )
        return (
            f"{self.passed} governed, {self.failed} need manual review "
            f"({self.elapsed_seconds:.1f}s)"
        )

    def print_report(self) -> None:
        """Print a human-readable preflight report to stdout."""
        print(f"\nConnexum Governance Preflight — {self.sidecar_url}")
        print(f"{'─' * 60}")
        for r in self.results:
            print(r.one_line())
        print(f"{'─' * 60}")
        mark = "✓" if self.passed_all() else "✗"
        print(f"{mark} {self.summary_line()}\n")


# ---------------------------------------------------------------------------
# Governance.json loader
# ---------------------------------------------------------------------------


def _load_governance_json(path: Optional[str]) -> dict[str, Any]:
    """Load governance.json from an explicit path, CONNEXUM_GOVERNANCE_JSON
    env var, or cwd/governance.json."""
    resolved = (
        path
        or os.environ.get("CONNEXUM_GOVERNANCE_JSON")
        or os.path.join(os.getcwd(), "governance.json")
    )
    if not os.path.isfile(resolved):
        raise FileNotFoundError(
            f"governance.json not found at {resolved!r}. "
            "Run the --agent-dir scanner first to generate it."
        )
    with open(resolved, encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# Per-agent probe
# ---------------------------------------------------------------------------


def _probe_agent(
    agent: dict[str, Any],
    *,
    client: httpx.Client,
    sidecar_url: str,
    org_id: str,
    api_token: str,
) -> PreflightAgentResult:
    """Issue a synthetic check_action for one agent entry and return the result."""
    agent_id = agent.get("agentId", "unknown")
    file_path = agent.get("filePath", "")
    provider = agent.get("provider", "unknown")
    framework = agent.get("framework")
    packs = agent.get("packs", [])

    headers: dict[str, str] = {"Content-Type": "application/json"}
    if api_token:
        headers["Authorization"] = f"Bearer {api_token}"

    payload = {
        "toolName": _PREFLIGHT_TOOL_NAME,
        "agent": {
            "name": agent_id,
            "orgId": org_id,
        },
        "input": {
            "__preflight": True,
            "agentId": agent_id,
            "provider": provider,
            "filePath": file_path,
        },
        "userId": f"preflight@{org_id}",
        # Carry packs as context so pack-aware policies can respond
        "metadata": {"packs": packs, "preflight": True},
    }

    t0 = time.monotonic()
    try:
        resp = client.post(
            f"{sidecar_url}/api/v1/governance/check-action",
            json=payload,
            headers=headers,
            timeout=10.0,
        )
    except (httpx.ConnectError, httpx.TimeoutException) as exc:
        elapsed = (time.monotonic() - t0) * 1000
        return PreflightAgentResult(
            agent_id=agent_id,
            file_path=file_path,
            provider=provider,
            framework=framework,
            packs=packs,
            passed=False,
            decision=None,
            audit_id=None,
            error=f"Connection failed: {exc}",
            elapsed_ms=elapsed,
        )

    elapsed = (time.monotonic() - t0) * 1000

    if resp.status_code >= 500:
        return PreflightAgentResult(
            agent_id=agent_id,
            file_path=file_path,
            provider=provider,
            framework=framework,
            packs=packs,
            passed=False,
            decision=None,
            audit_id=None,
            error=f"Sidecar returned {resp.status_code}: {resp.text[:200]}",
            elapsed_ms=elapsed,
        )

    try:
        body = resp.json()
    except Exception:
        return PreflightAgentResult(
            agent_id=agent_id,
            file_path=file_path,
            provider=provider,
            framework=framework,
            packs=packs,
            passed=False,
            decision=None,
            audit_id=None,
            error=f"Non-JSON response ({resp.status_code}): {resp.text[:200]}",
            elapsed_ms=elapsed,
        )

    decision = body.get("decision")
    audit_id = body.get("auditId")

    # Any structured decision means the governance hook fired and pack
    # policy was evaluated — governance is wired.
    passed = decision in _VALID_DECISIONS

    return PreflightAgentResult(
        agent_id=agent_id,
        file_path=file_path,
        provider=provider,
        framework=framework,
        packs=packs,
        passed=passed,
        decision=decision,
        audit_id=audit_id,
        error=None if passed else f"Unexpected response body: {body}",
        elapsed_ms=elapsed,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def run_preflight(
    governance_json_path: Optional[str] = None,
    sidecar_url: str = DEFAULT_SIDECAR_URL,
    org_id: str = "preflight-org",
    api_token: str = "",
) -> PreflightReport:
    """Run governance wiring checks for all agents in governance.json.

    Does NOT make any LLM API calls. Each probe is a synthetic
    check_action request to the local governance sidecar that confirms:
      * The sidecar is reachable
      * The governance hook fires
      * A structured decision is returned (ALLOW / DENY / REQUIRE_APPROVAL)

    :param governance_json_path: explicit path to governance.json; falls
        back to CONNEXUM_GOVERNANCE_JSON env var or cwd/governance.json.
    :param sidecar_url: base URL of the local governance sidecar.
        Default: http://127.0.0.1:4200.
    :param org_id: org id used in the synthetic probe request body.
    :param api_token: optional Bearer token for the sidecar.
    :returns: PreflightReport with per-agent results.
    :raises FileNotFoundError: if governance.json is missing.
    """
    cfg = _load_governance_json(governance_json_path)
    agents: list[dict[str, Any]] = cfg.get("agents", [])

    results: list[PreflightAgentResult] = []
    t_start = time.monotonic()

    with httpx.Client() as client:
        for agent in agents:
            result = _probe_agent(
                agent,
                client=client,
                sidecar_url=sidecar_url,
                org_id=org_id,
                api_token=api_token,
            )
            results.append(result)
            _log.debug(
                "[preflight] %s %s → %s",
                result.status_symbol(),
                result.file_path,
                result.decision or result.error,
            )

    elapsed = time.monotonic() - t_start
    passed = sum(1 for r in results if r.passed)
    failed = len(results) - passed

    return PreflightReport(
        total=len(results),
        passed=passed,
        failed=failed,
        results=results,
        sidecar_url=sidecar_url,
        elapsed_seconds=elapsed,
    )


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def _main() -> None:
    import sys

    logging.basicConfig(level=logging.WARNING)
    try:
        report = run_preflight()
    except FileNotFoundError as exc:
        print(f"✗ {exc}", file=__import__("sys").stderr)
        __import__("sys").exit(2)

    report.print_report()
    sys.exit(0 if report.passed_all() else 1)


if __name__ == "__main__":
    _main()
