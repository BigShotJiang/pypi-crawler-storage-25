"""
connexum-governance: Python client for My Compliance Center AI governance.

Thin HTTP client that connects to the Connexum governance API server.
The governance engine runs in TypeScript. This client sends governance
checks and receives decisions. No engine duplication.

Usage:
    from connexum_governance import GovernanceClient

    gov = GovernanceClient(
        api_url="http://localhost:3100",
        license_key=os.environ["CONNEXUM_LICENSE"],
    )

    decision = gov.check_action(
        tool="file_write",
        input={"path": "/etc/config.json"},
        agent={"name": "research-agent"},
    )

    if decision.denied:
        raise GovernanceViolation(decision.reason)
"""

from connexum_governance.client import GovernanceClient, AsyncGovernanceClient, BiasClient
from connexum_governance.models import (
    GovernanceDecision,
    GovernanceViolation,
    AgentIdentity,
    ActionContext,
    TaskContext,
    PlanContext,
    DelegationContext,
    ClassifiedResponse,
    # P3.5 five-dimensional identity
    DataSubjectIdentity,
    RecipientIdentity,
    TransportDescriptor,
    FiveDimIdentityContext,
    IdentityAttributionError,
    TRANSPORT_DEFAULT_INTEGRITY,
    PLAINTEXT_TRANSPORT_MECHANISMS,
)

# LangChain framework adapter (Sprint 5, WS-06)
from connexum_governance.integrations.langchain_integration import (
    GovernanceCallbackHandler as LangChainGovernanceCallbackHandler,
    AsyncGovernanceCallbackHandler,
    GovernedTool,
    governed_tool,
    as_governed_tool,
    wrap_agent_executor,
    wrap_state_graph,
    create_governed_langchain,
)
from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation as LangChainGovernanceViolation,
    GovernancePendingApproval,
)

# OpenAI Agents SDK framework adapter (Sprint 5, WS-08) -- guardrail-native blocking
from connexum_governance.integrations.openai_agents_integration import (
    GovernanceInputGuardrail,
    GovernanceOutputGuardrail,
    GovernanceAgentHooks,
    governed_function_tool,
    wrap_agent as wrap_openai_agent,
    create_governed_openai_agents,
)

# LlamaIndex framework adapter (Sprint 5, WS-09) -- FunctionTool.__call__ blocking
from connexum_governance.integrations.llama_index_integration import (
    GovernanceLlamaIndexCallback,
    GovernedFunctionTool as LlamaIndexGovernedFunctionTool,
    GovernedQueryEngineProxy,
    GovernedChatEngineProxy,
    governed_function_tool as llama_index_governed_function_tool,
    wrap_query_engine,
    wrap_chat_engine,
    wrap_agent_worker,
    create_governed_llama_index,
)

# AutoGen v0.4 framework adapter (Sprint 5, WS-10) -- FunctionTool.run() blocking
from connexum_governance.integrations.autogen_integration import (
    GovernedAutoGenTool,
    governed_autogen_tool,
    wrap_chat_agent as wrap_autogen_agent,
    wrap_group_chat as wrap_autogen_group_chat,
    create_governed_autogen,
    GovernedAutoGenInstance,
)

# LangGraph standalone adapter (Sprint 5, WS-10) -- per-node + compile-level blocking
from connexum_governance.integrations.langgraph_integration import (
    GovernedStateGraph,
    wrap_state_graph as langgraph_wrap_state_graph,
    wrap_pregel,
    create_governed_langgraph,
    GovernedLangGraphInstance,
)

# CrewAI framework adapter (Sprint 5, WS-09) -- BaseTool._run() blocking
from connexum_governance.integrations.crewai_integration import (
    GovernanceCrewAITool,
    governed_crewai_tool,
    make_governance_step_callback,
    make_governance_task_callback,
    wrap_agent as wrap_crewai_agent,
    wrap_crew,
    create_governed_crewai,
)

# F-NEW-CRIT-39e-2-PY slice 3: WebAuthnAttestor production attestor.
# Exported lazily-importable to avoid forcing the cryptography optional
# dependency on every SDK install -- WebAuthnAttestor itself has no hard
# cryptography requirement (it does NOT sign locally; the customer's
# browser supplies the signature bytes via assertion_callback).
from connexum_governance.attestor import (
    AttestationContext,
    AttestorError,
    EndUserAttestor,
    SignedAttestation,
)
from connexum_governance.webauthn_attestor import (
    WEBAUTHN_TOKEN_PREFIX,
    WebAuthnAssertion,
    WebAuthnAttestor,
    build_webauthn_token,
)

__version__ = "1.0.0b6"

# ---------------------------------------------------------------------------
# Slice 3: Zero-code monkey-patch mode
# Activate governance patches when CONNEXUM_AUTOWRAP=1 is set.
# Import is deferred to avoid circular imports -- autowrap imports models
# from connexum_governance, so it must run after all other imports above.
# ---------------------------------------------------------------------------
from connexum_governance.autowrap import _autowrap_if_enabled as _activate_autowrap_if_enabled  # noqa: E402
_activate_autowrap_if_enabled()
__all__ = [
    "GovernanceClient",
    "AsyncGovernanceClient",
    "BiasClient",
    "GovernanceDecision",
    "GovernanceViolation",
    "AgentIdentity",
    "ActionContext",
    "TaskContext",
    "PlanContext",
    "DelegationContext",
    "ClassifiedResponse",
    # P3.5 five-dimensional identity
    "DataSubjectIdentity",
    "RecipientIdentity",
    "TransportDescriptor",
    "FiveDimIdentityContext",
    "IdentityAttributionError",
    "TRANSPORT_DEFAULT_INTEGRITY",
    "PLAINTEXT_TRANSPORT_MECHANISMS",
    # LangChain framework adapter (Sprint 5, WS-06)
    "LangChainGovernanceCallbackHandler",
    "AsyncGovernanceCallbackHandler",
    "GovernedTool",
    "governed_tool",
    "as_governed_tool",
    "wrap_agent_executor",
    "wrap_state_graph",
    "create_governed_langchain",
    "LangChainGovernanceViolation",
    "GovernancePendingApproval",
    # OpenAI Agents SDK framework adapter (Sprint 5, WS-08)
    "GovernanceInputGuardrail",
    "GovernanceOutputGuardrail",
    "GovernanceAgentHooks",
    "governed_function_tool",
    "wrap_openai_agent",
    "create_governed_openai_agents",
    # LlamaIndex framework adapter (Sprint 5, WS-09)
    "GovernanceLlamaIndexCallback",
    "LlamaIndexGovernedFunctionTool",
    "GovernedQueryEngineProxy",
    "GovernedChatEngineProxy",
    "llama_index_governed_function_tool",
    "wrap_query_engine",
    "wrap_chat_engine",
    "wrap_agent_worker",
    "create_governed_llama_index",
    # AutoGen v0.4 framework adapter (Sprint 5, WS-10)
    "GovernedAutoGenTool",
    "governed_autogen_tool",
    "wrap_autogen_agent",
    "wrap_autogen_group_chat",
    "create_governed_autogen",
    "GovernedAutoGenInstance",
    # LangGraph standalone adapter (Sprint 5, WS-10)
    "GovernedStateGraph",
    "langgraph_wrap_state_graph",
    "wrap_pregel",
    "create_governed_langgraph",
    "GovernedLangGraphInstance",
    # CrewAI framework adapter (Sprint 5, WS-09)
    "GovernanceCrewAITool",
    "governed_crewai_tool",
    "make_governance_step_callback",
    "make_governance_task_callback",
    "wrap_crewai_agent",
    "wrap_crew",
    "create_governed_crewai",
    # F-NEW-CRIT-39e-2-PY: End-user attestation
    "AttestationContext",
    "AttestorError",
    "EndUserAttestor",
    "SignedAttestation",
    # slice 3 -- production WebAuthn attestor
    "WEBAUTHN_TOKEN_PREFIX",
    "WebAuthnAssertion",
    "WebAuthnAttestor",
    "build_webauthn_token",
]
