"""
Internal types for connexum_governance.attestor.

These types mirror the TypeScript SDK's AttestationContext and
SignedAttestation interfaces in
``packages/typescript-sdk/src/attestation.ts`` so a Python-issued
attestation token is byte-for-byte identical to a TypeScript-issued
token at the wire layer.

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 1
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class AttestationContext:
    """Context passed to ``EndUserAttestor.sign()`` for each
    ``/check-action`` call.

    Mirrors the TS ``AttestationContext`` interface exactly. The SDK
    supplies ``tenant_id``, ``action``, ``nonce``, ``request_hash`` from
    its own configuration and the outbound check request; the optional
    ``user_id`` is for human-readable audit only (the binding identity
    is the ``sub`` claim baked into the attestor by the caller).
    """

    tenant_id: str
    """Tenant id (from client-server config). Becomes the ``aud`` claim."""

    action: str
    """Action being attested. Truncated to 200 chars in the token."""

    nonce: str
    """Per-call nonce to prevent replay. SDK generates via
    ``secrets.token_hex(16)``."""

    request_hash: str
    """SHA-256 hex hash of the canonical request body for tamper
    detection."""

    user_id: Optional[str] = None
    """Optional human-readable user id for audit (the ``sub`` claim is
    set by the attestor implementation, not by the context)."""


@dataclass(frozen=True)
class SignedAttestation:
    """Result of a successful signing operation.

    The SDK inserts ``token`` into the ``X-Attestation-Token`` header
    and the check-action body's ``attestationToken`` field.
    """

    token: str
    """v4att-format token: ``v4att.<base64url-payload>.<base64url-signature>``.
    Mirrors the server-side format in
    ``packages/governance-server/src/end-user-attestation.ts``."""

    sub: str
    """``sub`` claim. Opaque end-user identifier."""

    jti: str
    """``jti`` (UUID v4). Server tracks for replay protection."""

    exp: int
    """``exp`` as Unix epoch milliseconds. Convenience for SDK callers
    that want to know when to re-sign."""


class AttestorError(Exception):
    """Error raised by ``EndUserAttestor`` implementations.

    The ``code`` attribute is one of:
      * ``user-cancelled`` -- hardware-backed attestors (WebAuthn,
        YubiKey) where the user dismissed the prompt.
      * ``no-key``         -- no signing key is available for this
        user/tenant.
      * ``sign-failed``    -- crypto operation failed (hardware error,
        KMS error, etc.).
    """

    __slots__ = ("code",)

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"[AttestorError:{code}] {message}")
        self.code = code
