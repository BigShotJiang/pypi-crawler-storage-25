"""
End-User Attestation Interface (Python SDK) -- F-NEW-CRIT-39e-2-PY slice 1.

Customer-side SDK protocol so customer host apps can supply attestation
tokens to the Python governance client. The client calls
``await attestor.sign(context)`` before each ``/check-action`` HTTP
request and includes the resulting token in:

  * HTTP header: ``X-Attestation-Token: <token>``
  * Request body field: ``attestationToken: <token>``

TOKEN FORMAT (mirrors
``packages/governance-server/src/end-user-attestation.ts``):

::

    v4att.<base64url-payload>.<base64url-signature>

where:

  * payload   -- base64url-encoded UTF-8 JSON (the claims object)
  * signature -- base64url-encoded 64-byte Ed25519 signature over the
                 raw payload bytes (no PASETO PAE; raw payload only)
  * version prefix ``v4att.`` is non-negotiable (prevents algorithm
    substitution attacks per
    ``packages/typescript-sdk/src/attestation.ts:16``)

This is structurally equivalent to PASETO v4.public, but the server
team intentionally chose a simpler signing input (raw payload bytes,
not a PAE-encoded message). Because of this, the third-party
``pyseto`` library is INCOMPATIBLE with the v4att wire format -- its
output would be rejected by the server with ``invalid-signature``
even with the correct key. Use ``cryptography.hazmat.primitives``
instead.

PRODUCTION USE: implement ``EndUserAttestor`` with a hardware-backed
key store (WebAuthn / FIDO2, YubiKey, AWS KMS, Azure Key Vault, GCP
KMS). See ``F-NEW-CRIT-39e-2-PY`` slice 3 for the WebAuthn Python
implementation.

TEST-ONLY HELPERS: ``SoftwareKeyAttestor`` lives in
``connexum_governance.testing`` (NOT this module). Production code
must NOT import from the ``connexum_governance.testing`` namespace.

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 1
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from connexum_governance.attestor._types import (
    AttestationContext,
    AttestorError,
    SignedAttestation,
)

__all__ = [
    "AttestationContext",
    "AttestorError",
    "EndUserAttestor",
    "SignedAttestation",
]


@runtime_checkable
class EndUserAttestor(Protocol):
    """Customer-side attestor contract.

    The host application implements this protocol and passes an
    instance to the SDK constructor. The SDK calls ``sign()`` before
    each ``/check-action`` request and includes the resulting token in
    the request.

    Implementations:

      * ``connexum_governance.testing.SoftwareKeyAttestor``
        -- in-memory Ed25519 key, TEST-ONLY
      * (future) ``connexum_governance.WebAuthnAttestor``
        -- FIDO2 passkey, slice 3
      * (future) ``connexum_governance.kms.KMSAttestor``
        -- AWS KMS / Azure Key Vault / GCP KMS, slice 5+

    The protocol is async-native to match the TS SDK's
    ``Promise<SignedAttestation>`` contract and to support hardware
    attestors that may take user interaction time (WebAuthn) or
    network round-trips (KMS).
    """

    async def sign(self, context: AttestationContext) -> SignedAttestation:
        """Sign an attestation for a specific governance check.

        Returns a ``SignedAttestation`` whose ``token`` the SDK will
        include in the ``X-Attestation-Token`` header and the request
        body's ``attestationToken`` field.

        :raises AttestorError: if signing fails
            (``user-cancelled`` / ``no-key`` / ``sign-failed``).
        """
        ...
