"""
F-NEW-CRIT-1 contract tests: framework adapter wire-shape against live gov-server.

PURPOSE
-------
Prove the documented bug: every framework adapter under
`connexum_governance.integrations.*_integration` constructs an HTTP body of
shape {action, tools, messagePreview, packIds, metadata} and POSTs it to
`/api/v1/governance/check-action`. The server schema requires
`{toolName, agent, ...}` (see Python SDK models.ActionContext.to_dict). The
result is a 400 "Validation failed" on every customer call.

These tests:
  1. Start a fake underlying object matching each framework's interface.
  2. Wrap with the public governance factory pointing at the LIVE gov-server
     on port 4201 with `license_key='testbed-license-placeholder'`.
  3. Invoke the documented blocking primitive.
  4. Capture the actual HTTP request via an httpx transport interceptor.
  5. Assert the request is BROKEN: missing toolName / agent fields.

RED BASELINE: every adapter test must fail with the broken-shape assertion
before Loom's fix lands. Post-fix, the same tests must pass without
modification (DA-RULE-7 requires symmetric assertions).

DO NOT MOCK THE TRANSPORT. The whole point is to catch the contract bug
that mocks would have hidden -- which is exactly how this shipped.

The interceptor is a pass-through capture: it records the outbound request
shape AND lets the request hit the real server, so we also have the
server's verdict on every payload.
"""
from __future__ import annotations

import asyncio
import json
import os
import socket
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx
import pytest


GOV_URL = "http://127.0.0.1:4201"
LICENSE = "testbed-license-placeholder"


# ---------------------------------------------------------------------------
# Live testbed gate -- skip cleanly if the gov-server is not running on 4201.
# These tests intentionally bypass the auto-spawn fixture in conftest.py
# (which uses port 3200) and target the live testbed instead.
# ---------------------------------------------------------------------------

def _testbed_alive() -> bool:
    try:
        with socket.create_connection(("127.0.0.1", 4201), timeout=1):
            return True
    except OSError:
        return False


pytestmark = pytest.mark.skipif(
    not _testbed_alive(),
    reason="Live gov-server testbed on 127.0.0.1:4201 not running",
)


# ---------------------------------------------------------------------------
# Wire interceptor: captures outbound bodies, lets them reach the real server.
# ---------------------------------------------------------------------------

@dataclass
class CapturedRequest:
    method: str
    url: str
    headers: dict
    body: dict
    response_status: int
    response_body: dict


@dataclass
class WireCapture:
    requests: list[CapturedRequest] = field(default_factory=list)

    def latest(self) -> CapturedRequest:
        assert self.requests, "No HTTP requests captured"
        return self.requests[-1]


def _install_capture() -> WireCapture:
    """Monkey-patch httpx.Client.send + AsyncClient.send to record + forward."""
    cap = WireCapture()
    orig_sync = httpx.Client.send
    orig_async = httpx.AsyncClient.send

    def _record(req: httpx.Request, resp: httpx.Response) -> None:
        # Only record governance check-action calls; ignore unrelated traffic.
        if "/check-action" not in str(req.url) and "/api/v1/governance" not in str(req.url):
            return
        try:
            body_json = json.loads(req.content.decode("utf-8")) if req.content else {}
        except Exception:
            body_json = {"_raw": req.content.decode("utf-8", errors="replace")}
        try:
            resp_json = resp.json()
        except Exception:
            resp_json = {"_raw": resp.text}
        cap.requests.append(
            CapturedRequest(
                method=req.method,
                url=str(req.url),
                headers=dict(req.headers),
                body=body_json,
                response_status=resp.status_code,
                response_body=resp_json,
            )
        )

    def patched_sync(self, request, *a, **kw):
        resp = orig_sync(self, request, *a, **kw)
        _record(request, resp)
        return resp

    async def patched_async(self, request, *a, **kw):
        resp = await orig_async(self, request, *a, **kw)
        _record(request, resp)
        return resp

    httpx.Client.send = patched_sync  # type: ignore[assignment]
    httpx.AsyncClient.send = patched_async  # type: ignore[assignment]

    cap._restore = lambda: (
        setattr(httpx.Client, "send", orig_sync),
        setattr(httpx.AsyncClient, "send", orig_async),
    )
    return cap


@pytest.fixture
def wire():
    cap = _install_capture()
    try:
        yield cap
    finally:
        cap._restore()


# ---------------------------------------------------------------------------
# Server-schema-compliance assertion (the core contract check).
# ---------------------------------------------------------------------------

def assert_request_matches_server_schema(req: CapturedRequest) -> None:
    """
    Assert the captured request body matches the gov-server check-action schema.

    PASS criteria (post-fix):
      - URL path includes /api/v1/governance/check-action
      - Body has top-level "toolName" (string)
      - Body has top-level "agent" (object with at least "name")
      - Server response is NOT a 400 "Validation failed"

    FAIL criteria (RED baseline -- broken adapters):
      - Missing toolName -> server returns 400 with "Required field 'toolName'"
      - Missing agent -> server returns 400 with "Required field 'agent'"
      - Wrong endpoint (TS SDK posts to /check) -> 404
    """
    # 1. Endpoint correctness
    assert "/api/v1/governance/check-action" in req.url, (
        f"Wrong endpoint. Got URL: {req.url}\n"
        f"Expected /api/v1/governance/check-action\n"
        f"(TS SDK has a known bug posting to /check which 404s.)"
    )

    # 2. Server verdict: must NOT be a schema validation failure
    if req.response_status == 400:
        err = req.response_body.get("error", "")
        details = req.response_body.get("details", [])
        if err == "Validation failed":
            missing = [d.get("field") for d in details]
            raise AssertionError(
                "Server rejected adapter request with HTTP 400 'Validation failed'.\n"
                f"  Missing required fields: {missing}\n"
                f"  Adapter sent body keys: {sorted(req.body.keys())}\n"
                f"  Full response: {req.response_body}\n"
                "F-NEW-CRIT-1: adapter constructs wrong shape; should route through "
                "GovernanceClient.check_action()."
            )

    # 3. Body shape check (defensive: catch the bug even if server changes)
    assert "toolName" in req.body, (
        f"Adapter body missing required 'toolName' field. "
        f"Sent body keys: {sorted(req.body.keys())}. "
        f"F-NEW-CRIT-1 broken-shape adapter."
    )
    assert "agent" in req.body, (
        f"Adapter body missing required 'agent' field. "
        f"Sent body keys: {sorted(req.body.keys())}. "
        f"F-NEW-CRIT-1 broken-shape adapter."
    )
    assert isinstance(req.body["agent"], dict) and req.body["agent"].get("name"), (
        f"'agent' must be an object with a 'name' field. Got: {req.body['agent']!r}"
    )


# ---------------------------------------------------------------------------
# 1) crewai_integration -- GovernanceCrewAITool via governed_crewai_tool factory
# ---------------------------------------------------------------------------

def test_crewai_governed_tool_run_uses_correct_wire_shape(wire):
    from connexum_governance.integrations.crewai_integration import governed_crewai_tool

    class FakeCrewTool:
        name = "fake_crew_tool"
        description = "audit"
        def _run(self, tool_input=""): return f"ran:{tool_input}"

    safe = governed_crewai_tool(
        tool=FakeCrewTool(),
        governance_server_url=GOV_URL,
        license_key=LICENSE,
        raise_on_deny=False,  # don't blow up; we want to inspect the wire
    )
    try:
        safe._run("audit-payload")
    except Exception:
        pass  # we only care about what was sent
    assert_request_matches_server_schema(wire.latest())


# ---------------------------------------------------------------------------
# 2) langchain_integration -- GovernedTool via governed_tool factory
# ---------------------------------------------------------------------------

def test_langchain_governed_tool_run_uses_correct_wire_shape(wire):
    from connexum_governance.integrations.langchain_integration import governed_tool

    class FakeLcTool:
        name = "fake_lc_tool"
        description = "audit"
        def _run(self, *a, **kw): return "ran"

    safe = governed_tool(
        tool=FakeLcTool(),
        governance_server_url=GOV_URL,
        license_key=LICENSE,
        raise_on_deny=False,
    )
    try:
        safe._run("audit-payload")
    except Exception:
        pass
    assert_request_matches_server_schema(wire.latest())


# ---------------------------------------------------------------------------
# 3) langgraph_integration -- wrap_pregel
# ---------------------------------------------------------------------------

def test_langgraph_wrap_pregel_invoke_uses_correct_wire_shape(wire):
    from connexum_governance.integrations.langgraph_integration import wrap_pregel

    class FakePregel:
        def invoke(self, state, config=None, **kw): return {"ok": True, "state": state}

    governed = wrap_pregel(
        FakePregel(),
        governance_server_url=GOV_URL,
        license_key=LICENSE,
        raise_on_deny=False,
    )
    try:
        governed.invoke({"messages": ["audit-payload"]})
    except Exception:
        pass
    assert_request_matches_server_schema(wire.latest())


# ---------------------------------------------------------------------------
# 4) llama_index_integration -- GovernedFunctionTool.__call__
# ---------------------------------------------------------------------------

def test_llama_index_governed_function_tool_call_uses_correct_wire_shape(wire):
    from connexum_governance.integrations.llama_index_integration import (
        GovernedFunctionTool,
    )

    class FakeMeta:
        name = "fake_li_tool"
        fn_name = "fake_li_tool"
        description = "audit"

    class FakeLiTool:
        metadata = FakeMeta()
        name = "fake_li_tool"
        def __call__(self, *a, **kw): return "ran"

    safe = GovernedFunctionTool(
        tool=FakeLiTool(),
        governance_server_url=GOV_URL,
        license_key=LICENSE,
        raise_on_deny=False,
    )
    try:
        safe("audit-payload")
    except Exception:
        pass
    assert_request_matches_server_schema(wire.latest())


# ---------------------------------------------------------------------------
# 5) autogen_integration -- GovernedAutoGenTool.run (async)
# ---------------------------------------------------------------------------

def test_autogen_governed_tool_run_uses_correct_wire_shape(wire):
    from connexum_governance.integrations.autogen_integration import GovernedAutoGenTool

    class FakeAgTool:
        name = "fake_ag_tool"
        description = "audit"
        async def run(self, args, **kw): return f"ran:{args}"

    safe = GovernedAutoGenTool(
        tool=FakeAgTool(),
        governance_server_url=GOV_URL,
        license_key=LICENSE,
        raise_on_deny=False,
    )
    try:
        asyncio.run(safe.run("audit-payload"))
    except Exception:
        pass
    assert_request_matches_server_schema(wire.latest())


# ---------------------------------------------------------------------------
# 6) openai_agents_integration -- GovernanceInputGuardrail
#    Note: this adapter is fail-CLOSED on HTTP error: a 400 is silently
#    converted to a tripwire DenyOutput inside the guardrail. The wire
#    interceptor still captures the outbound body, which is the assertion
#    target.
# ---------------------------------------------------------------------------

def test_openai_agents_input_guardrail_uses_correct_wire_shape(wire):
    from connexum_governance.integrations.openai_agents_integration import (
        create_governed_openai_agents,
    )

    inst = create_governed_openai_agents(
        governance_server_url=GOV_URL,
        license_key=LICENSE,
        raise_on_deny=False,
    )

    class FakeAgent:
        name = "fake-openai-agent"

    try:
        asyncio.run(inst.input_guardrail(ctx=None, agent=FakeAgent(), input="audit-payload"))
    except Exception:
        pass
    assert_request_matches_server_schema(wire.latest())


# ---------------------------------------------------------------------------
# 7) haystack_integration -- GovernedComponent.run
# ---------------------------------------------------------------------------

def test_haystack_governed_component_run_uses_correct_wire_shape(wire):
    from connexum_governance.integrations.haystack_integration import GovernedComponent

    class FakeComponent:
        def run(self, query=""): return {"answer": query}

    safe = GovernedComponent(
        component=FakeComponent(),
        governance_server_url=GOV_URL,
        license_key=LICENSE,
        raise_on_deny=False,
    )
    try:
        safe.run(query="audit-payload")
    except Exception:
        pass
    assert_request_matches_server_schema(wire.latest())


# ---------------------------------------------------------------------------
# 8) pydantic_ai_integration -- wrap_runs (exercises run_sync wrapping)
# ---------------------------------------------------------------------------

def test_pydantic_ai_wrap_runs_uses_correct_wire_shape(wire):
    from connexum_governance.integrations.pydantic_ai_integration import (
        create_governed_pydantic_ai,
    )

    inst = create_governed_pydantic_ai(
        governance_server_url=GOV_URL,
        license_key=LICENSE,
        raise_on_deny=False,
    )

    class FakeAgent:
        def run_sync(self, prompt, **kw): return f"agent:{prompt}"
        async def run(self, prompt, **kw): return f"agent:{prompt}"

    fa = FakeAgent()
    inst.wrap_runs(fa)
    try:
        fa.run_sync("audit-payload")
    except Exception:
        pass
    assert_request_matches_server_schema(wire.latest())
