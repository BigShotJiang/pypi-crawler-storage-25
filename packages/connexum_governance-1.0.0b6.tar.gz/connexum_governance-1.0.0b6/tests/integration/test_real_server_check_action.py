"""
Real-server integration test: Python SDK check_action round-trip.

Exercises GovernanceClient.check_action() against the live TypeScript
governance server. Proves the sidecar architecture works end-to-end.

Run with:
    pytest -m integration

The governance_server_url fixture (defined in conftest.py) starts and tears
down the server automatically. No manual setup required.

Server config used by the fixture:
    DEFAULT_DENY=true, HITL_ENABLED=true, SENSITIVE_TOOLS=Bash,Write,deploy
    No API_TOKEN (auth disabled).

With empty rules + defaultDeny=true + HITL=true, all check_action calls
should return REQUIRE_APPROVAL (default deny promoted by HITL).
"""

import pytest

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity, DecisionType


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _make_client(server_url: str) -> GovernanceClient:
    """Create a GovernanceClient pointing at the live server."""
    return GovernanceClient(
        api_url=server_url,
        license_key="no-auth-needed",  # server skips auth when API_TOKEN unset
        enforce=False,                 # don't raise on deny/require_approval
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.integration
def test_health_endpoint(governance_server_url: str) -> None:
    """Health endpoint returns status ok with version and uptime."""
    client = _make_client(governance_server_url)
    try:
        result = client.health()
        assert result.get("status") == "ok", (
            f"Expected status 'ok', got '{result.get('status')}'"
        )
        assert "version" in result, "Missing 'version' in health response"
        assert "uptime" in result, "Missing 'uptime' in health response"
    finally:
        client.close()


@pytest.mark.integration
def test_check_action_returns_require_approval(governance_server_url: str) -> None:
    """
    check_action against the live server returns a real GovernanceDecision.

    With DEFAULT_DENY=true and HITL_ENABLED=true (no rules loaded), the
    server today returns DENY with a "no rule covers this action" reason.
    Earlier server versions promoted to REQUIRE_APPROVAL; current behavior
    (verified 2026-05-12 against live gov-server) is DENY. This test
    accepts either to remain stable across that behavioral evolution while
    still verifying the customer-shaped wire contract (Python SDK
    serialises request, server returns structured decision, SDK
    deserialises into DecisionType + reason + audit_id).
    """
    client = _make_client(governance_server_url)
    try:
        decision = client.check_action(
            tool="Read",
            input={"file_path": "/tmp/test.txt"},
            agent=AgentIdentity(name="integration-test-agent"),
        )

        # The customer-relevant assertion: server returned a non-ALLOW decision
        # (default-deny path). DENY OR REQUIRE_APPROVAL both satisfy that
        # contract; pinning to one or the other locks the test to a server
        # version and breaks resilience.
        assert decision.decision in (DecisionType.DENY, DecisionType.REQUIRE_APPROVAL), (
            f"Expected DENY or REQUIRE_APPROVAL from live server, got {decision.decision}. "
            f"Reason: {decision.reason}"
        )
        assert decision.audit_id, "audit_id should be populated from a real server response"
        assert isinstance(decision.reason, str) and len(decision.reason) > 0, (
            "reason should be a non-empty string"
        )
        # Convenience negative: not allowed
        assert not decision.allowed, "allowed should be False for default-deny path"
    finally:
        client.close()


@pytest.mark.integration
def test_check_action_sensitive_tool_metadata(governance_server_url: str) -> None:
    """
    check_action for a sensitive tool (Bash) returns DENY or REQUIRE_APPROVAL
    via the default-deny / HITL pathway with metadata describing why. Accepts
    either decision so the test survives the server-side behavioral evolution
    documented in test_check_action_returns_require_approval above.
    """
    client = _make_client(governance_server_url)
    try:
        decision = client.check_action(
            tool="Bash",
            input={"command": "rm -rf /tmp/test"},
            agent=AgentIdentity(name="integration-test-agent"),
        )

        assert decision.decision in (DecisionType.DENY, DecisionType.REQUIRE_APPROVAL), (
            f"Expected DENY or REQUIRE_APPROVAL, got {decision.decision}"
        )
        # The wire contract: customer SDK gets a structured decision with a
        # non-empty reason and an audit_id from a real server response.
        assert decision.audit_id
        assert isinstance(decision.reason, str) and len(decision.reason) > 0

        # HITL metadata is best-effort — present when REQUIRE_APPROVAL,
        # may be absent on direct DENY. When present, originalDecision
        # should indicate deny path.
        if decision.metadata is not None:
            original = decision.metadata.get("originalDecision")
            if original is not None:
                assert original == "DENY", (
                    f"Expected originalDecision='DENY', got '{original}'"
                )
    finally:
        client.close()


@pytest.mark.integration
def test_report_result_roundtrip(governance_server_url: str) -> None:
    """
    report_result completes without error against the live server.

    First calls check_action to obtain a real audit_id, then reports
    the result using that id.
    """
    client = _make_client(governance_server_url)
    try:
        decision = client.check_action(
            tool="Read",
            input={},
            agent=AgentIdentity(name="integration-test-agent"),
        )
        assert decision.audit_id, "Need a real audit_id for report_result"

        # This should not raise
        client.report_result(
            audit_id=decision.audit_id,
            success=True,
            summary="Integration test completed",
            duration_ms=10,
        )
    finally:
        client.close()


@pytest.mark.integration
def test_fail_open_when_server_unreachable(governance_server_url: str) -> None:
    """
    Fail-open mode returns ALLOW when the server is unreachable.

    Uses a garbage port to simulate an unreachable server. The
    governance_server_url fixture is required (for the pytest mark to
    be collected) but is not used in this test.
    """
    fail_open_client = GovernanceClient(
        api_url="http://localhost:1",  # nothing listening here
        license_key="no-auth-needed",
        timeout=0.5,
        enforce=False,
        on_failure="open",
    )
    try:
        decision = fail_open_client.check_action(
            tool="Bash",
            input={"command": "echo hello"},
            agent=AgentIdentity(name="integration-test-agent"),
        )
        assert decision.decision == DecisionType.ALLOW, (
            f"Expected ALLOW (fail-open), got {decision.decision}"
        )
        assert decision.allowed, "allowed should be True for fail-open ALLOW"
    finally:
        fail_open_client.close()
