"""
Integration test fixtures for Python SDK real-server tests.

Starts the TypeScript governance server as a subprocess, waits for it to be
ready, yields the server URL, then tears it down after the session ends.

Usage:
    pytest -m integration

Requirements:
    - The governance server must be reachable via:
        npx tsx packages/governance-server/src/index.ts
      Run from the project root (/root/AI-Agents-GS/).
    - Port 3200 must be free before starting tests.
    - No API_TOKEN env var needed (auth disabled when unset).
"""

import os
import socket
import subprocess
import time
from pathlib import Path
from typing import Generator

import pytest


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SERVER_PORT = 3200
SERVER_HOST = "localhost"
SERVER_URL = f"http://{SERVER_HOST}:{SERVER_PORT}"
HEALTH_PATH = "/api/v1/health"
STARTUP_TIMEOUT = 30  # seconds to wait for server ready
POLL_INTERVAL = 0.5   # seconds between TCP probes

# Repo root: three levels up from this file
# packages/python-sdk/tests/integration/conftest.py -> root
REPO_ROOT = Path(__file__).parent.parent.parent.parent.parent


# ---------------------------------------------------------------------------
# TCP readiness probe
# ---------------------------------------------------------------------------

def _tcp_probe(host: str, port: int) -> bool:
    """Return True if a TCP connection to host:port can be established."""
    try:
        with socket.create_connection((host, port), timeout=1):
            return True
    except (OSError, ConnectionRefusedError):
        return False


def _wait_for_server(host: str, port: int, timeout: float) -> bool:
    """Poll TCP until port is open or timeout is reached."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _tcp_probe(host, port):
            return True
        time.sleep(POLL_INTERVAL)
    return False


# ---------------------------------------------------------------------------
# Session-scoped fixture
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def governance_server_url() -> Generator[str, None, None]:
    """
    Start the TypeScript governance server, wait for readiness, yield its URL,
    and tear down on session end.

    Marked session-scoped so the server starts once per pytest session,
    not once per test.
    """
    env = {
        **os.environ,
        "PORT": str(SERVER_PORT),
        "DEFAULT_DENY": "true",
        "HITL_ENABLED": "true",
        "SENSITIVE_TOOLS": "Bash,Write,deploy",
        # API_TOKEN intentionally absent -> server skips auth when unset
        # Secrets required by the server's fail-closed security gates.
        # These are test-only values. They are never used in production.
        "APPROVAL_SECRET": "test-integration-approval-secret-32ch",
        "JWT_SECRET": "test-integration-jwt-secret-32chars!",
        "TRUST_ANCHOR_HMAC": "test-integration-hmac-secret-32char",
        "ENCRYPTION_KEY": "test-integration-encryption-key-32c",
    }

    start_cmd = [
        "npx",
        "tsx",
        "packages/governance-server/src/index.ts",
    ]

    proc = subprocess.Popen(
        start_cmd,
        cwd=str(REPO_ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    try:
        ready = _wait_for_server(SERVER_HOST, SERVER_PORT, STARTUP_TIMEOUT)
        if not ready:
            proc.kill()
            proc.wait(timeout=5)
            # Collect any output for diagnostics
            output = b""
            if proc.stdout:
                output = proc.stdout.read()
            raise RuntimeError(
                f"Governance server did not start within {STARTUP_TIMEOUT}s. "
                f"Server output:\n{output.decode(errors='replace')}"
            )

        yield SERVER_URL

    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
