"""
F-NEW-PRODUCT-AGENT-DIR-WRAPPER slice 4 — preflight wiring tests.

Per Evidence-First Protocol: real HTTP against the testbed governance-sidecar
at http://127.0.0.1:4200. No mocks.

Tests:
  1. Single-agent governance.json → pass (decision present, auditId present)
  2. Multi-agent report: 2 agents, both pass
  3. Bad sidecar URL → all agents fail with connection error
  4. Empty agents list → total=0, passed_all=True
  5. governance.json missing → FileNotFoundError
  6. PreflightReport.summary_line() wording
  7. Mixed pass/fail: 1 bad URL agent + 1 good → summary shows 1 governed / 1 needs review
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import httpx
import pytest

from connexum_governance.preflight import (
    PreflightReport,
    run_preflight,
)

# ---------------------------------------------------------------------------
# Sidecar availability guard
# ---------------------------------------------------------------------------

SIDECAR_URL = os.environ.get("CONNEXUM_TESTBED_URL", "http://127.0.0.1:4200")


def _sidecar_up() -> bool:
    try:
        r = httpx.get(f"{SIDECAR_URL}/api/v1/health", timeout=3.0)
        return r.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


_SIDECAR_LIVE = _sidecar_up()
requires_sidecar = pytest.mark.skipif(
    not _SIDECAR_LIVE,
    reason=f"governance-sidecar not running at {SIDECAR_URL}",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_governance_json(tmp_path: Path, agents: list[dict]) -> str:
    """Write a minimal governance.json and return its path."""
    p = tmp_path / "governance.json"
    p.write_text(json.dumps({"agents": agents}, indent=2))
    return str(p)


def _sample_agent(
    file_path: str = "agents/bot.py",
    provider: str = "openai",
    agent_id: str = "auto-test001",
    packs: list[str] | None = None,
) -> dict:
    return {
        "agentId": agent_id,
        "filePath": file_path,
        "language": "python",
        "provider": provider,
        "framework": None,
        "wrapMode": "shim",
        "packs": packs or ["hipaa"],
    }


# ---------------------------------------------------------------------------
# Test 1: single agent → sidecar returns structured decision
# ---------------------------------------------------------------------------


@requires_sidecar
def test_single_agent_passes_preflight(tmp_path: Path) -> None:
    gj = _write_governance_json(tmp_path, [_sample_agent()])

    report = run_preflight(
        governance_json_path=gj,
        sidecar_url=SIDECAR_URL,
    )

    assert report.total == 1
    assert report.passed == 1
    assert report.failed == 0
    assert report.passed_all()
    assert len(report.results) == 1

    r = report.results[0]
    assert r.passed is True
    assert r.decision in {"ALLOW", "DENY", "REQUIRE_APPROVAL", "BLOCK"}, \
        f"Expected a governance decision; got {r.decision!r}"
    assert r.agent_id == "auto-test001"
    assert r.provider == "openai"
    assert r.error is None
    assert r.elapsed_ms > 0


@requires_sidecar
def test_single_agent_has_audit_id(tmp_path: Path) -> None:
    """audit_id proves the request reached the audit chain, not just the router."""
    gj = _write_governance_json(tmp_path, [_sample_agent()])
    report = run_preflight(governance_json_path=gj, sidecar_url=SIDECAR_URL)
    r = report.results[0]
    assert r.audit_id is not None, "auditId must be present — proves hook fired"


# ---------------------------------------------------------------------------
# Test 2: multi-agent report — all pass
# ---------------------------------------------------------------------------


@requires_sidecar
def test_multi_agent_all_pass(tmp_path: Path) -> None:
    agents = [
        _sample_agent("agents/openai_bot.py", "openai", "auto-oa001"),
        _sample_agent("agents/anthropic_bot.py", "anthropic", "auto-an001"),
    ]
    gj = _write_governance_json(tmp_path, agents)

    report = run_preflight(governance_json_path=gj, sidecar_url=SIDECAR_URL)

    assert report.total == 2
    assert report.passed == 2
    assert report.failed == 0
    assert report.passed_all()
    assert "2/2 agents governed" in report.summary_line()


# ---------------------------------------------------------------------------
# Test 3: bad sidecar URL → all agents fail with connection error
# ---------------------------------------------------------------------------


def test_bad_sidecar_url_fails_gracefully(tmp_path: Path) -> None:
    """Connection errors must not raise; they produce FAIL results."""
    gj = _write_governance_json(tmp_path, [_sample_agent()])

    report = run_preflight(
        governance_json_path=gj,
        sidecar_url="http://127.0.0.1:19999",  # nothing listening here
    )

    assert report.total == 1
    assert report.failed == 1
    assert not report.passed_all()
    r = report.results[0]
    assert r.passed is False
    assert r.error is not None
    assert "Connection failed" in r.error


# ---------------------------------------------------------------------------
# Test 4: empty agents list
# ---------------------------------------------------------------------------


def test_empty_agents_list(tmp_path: Path) -> None:
    gj = _write_governance_json(tmp_path, [])
    report = run_preflight(governance_json_path=gj, sidecar_url=SIDECAR_URL)

    assert report.total == 0
    assert report.passed == 0
    assert report.failed == 0
    assert report.passed_all()
    assert "No agents" in report.summary_line()


# ---------------------------------------------------------------------------
# Test 5: governance.json missing → FileNotFoundError
# ---------------------------------------------------------------------------


def test_missing_governance_json_raises(tmp_path: Path) -> None:
    missing_path = str(tmp_path / "no_such_file.json")
    with pytest.raises(FileNotFoundError, match="governance.json not found"):
        run_preflight(governance_json_path=missing_path)


# ---------------------------------------------------------------------------
# Test 6: summary_line wording for pass / partial-fail
# ---------------------------------------------------------------------------


def test_summary_line_all_pass() -> None:
    report = PreflightReport(total=3, passed=3, failed=0)
    line = report.summary_line()
    assert "3/3" in line
    assert "governed" in line


def test_summary_line_partial_fail() -> None:
    report = PreflightReport(total=5, passed=3, failed=2)
    line = report.summary_line()
    assert "3 governed" in line
    assert "2 need manual review" in line


def test_summary_line_empty() -> None:
    report = PreflightReport(total=0, passed=0, failed=0)
    assert "No agents" in report.summary_line()


# ---------------------------------------------------------------------------
# Test 7: mixed pass/fail summary (bad-URL agent vs live-sidecar agent)
# ---------------------------------------------------------------------------


@requires_sidecar
def test_mixed_results_summary(tmp_path: Path) -> None:
    """One agent probed against a dead port (FAIL) + one against live sidecar (PASS)."""
    agents = [_sample_agent("agents/bot_a.py", "openai", "auto-mx001")]
    gj = _write_governance_json(tmp_path, agents)

    # FAIL run (dead port)
    report_fail = run_preflight(
        governance_json_path=gj,
        sidecar_url="http://127.0.0.1:19998",
    )
    # PASS run (live sidecar)
    report_pass = run_preflight(
        governance_json_path=gj,
        sidecar_url=SIDECAR_URL,
    )

    assert report_fail.failed == 1
    assert report_pass.passed == 1
    # all-pass branch returns "1/1 agents governed successfully"
    assert "governed" in report_pass.summary_line()
    assert "need manual review" not in report_pass.summary_line()
