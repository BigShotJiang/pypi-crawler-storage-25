"""GAP-S1-03: Tests for BiasClient SDK wrapper.

Confirms that BiasClient calls the correct endpoints, parses responses
correctly, and surfaces equalized-odds fields with the right types.
Uses httpx.MockTransport so no live server is needed.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import BiasClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

EO_SAMPLE_RESPONSE = {
    "recorded": 4,
    "totalRecords": 4,
}

EO_ASSESS_RESPONSE = {
    "agentId": "test-agent",
    "assessedAt": "2026-04-25T10:00:00.000Z",
    "totalRecords": 4,
    "groups": [
        {
            "group": "A",
            "tpr": 0.8,
            "fpr": 0.3,
            "truePositives": 8,
            "falsePositives": 3,
            "trueNegatives": 7,
            "falseNegatives": 2,
            "positives": 10,
            "negatives": 10,
        },
        {
            "group": "B",
            "tpr": 0.4,
            "fpr": 0.1,
            "truePositives": 4,
            "falsePositives": 1,
            "trueNegatives": 9,
            "falseNegatives": 6,
            "positives": 10,
            "negatives": 10,
        },
    ],
    "maxTprGap": 0.4,
    "maxFprGap": 0.2,
    "tprViolation": True,
    "fprViolation": True,
    "tprThreshold": 0.10,
    "fprThreshold": 0.10,
    "recommendations": [
        "[Equalized Odds] TPR gap 0.400 exceeds threshold 0.10.",
        "[Equalized Odds] FPR gap 0.200 exceeds threshold 0.10.",
        "[EEOC / EU AI Act Art. 10] Document equalized-odds findings.",
    ],
}

EO_GET_RESPONSE = EO_ASSESS_RESPONSE

BIAS_SAMPLES_RESPONSE = {"recorded": True, "totalSamples": 1}
BIAS_ASSESS_RESPONSE = {
    "agentId": "test-agent",
    "agentName": "Test Agent",
    "assessedAt": "2026-04-25T10:00:00.000Z",
    "totalSamples": 1,
    "categories": [],
    "overallBiased": False,
    "biasScore": 0,
    "oodDetections": 0,
    "recommendations": ["Insufficient samples (1/20). Collect more data."],
    "maxDemographicParity": 0,
    "minDisparateImpactRatio": 1,
    "disparateImpactViolation": False,
}
FAIRNESS_RESPONSE = {
    "agentId": "test-agent",
    "agentName": "Test Agent",
    "summary": {"maxDemographicParity": 0.3, "minDisparateImpactRatio": 0.6, "disparateImpactViolation": False},
    "categories": [],
}


def make_bias_client(responses: dict[str, Any]) -> BiasClient:
    """Build a BiasClient wired to a mock httpx transport."""
    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path in responses:
            body = responses[path]
            if callable(body):
                body = body(request)
            return httpx.Response(200, json=body)
        return httpx.Response(404, json={"error": "not found"})

    client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
    client._client = httpx.Client(
        base_url="http://test-bias-server",
        headers=client._client.headers,
        transport=httpx.MockTransport(handler),
    )
    return client


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestBiasClientSubmitBiasAnalysis:
    """Tests for BiasClient.submit_bias_analysis."""

    def test_calls_correct_endpoints_and_returns_eo_result(self):
        """submit_bias_analysis must POST to samples + assess and return structured result."""
        captured_bodies: list[dict[str, Any]] = []

        def handler(request: httpx.Request) -> httpx.Response:
            path = request.url.path
            body = json.loads(request.content)
            captured_bodies.append({"path": path, "body": body})
            if path == "/api/v1/bias/equalized-odds/samples":
                return httpx.Response(201, json=EO_SAMPLE_RESPONSE)
            if "/equalized-odds/assess/" in path:
                return httpx.Response(200, json=EO_ASSESS_RESPONSE)
            return httpx.Response(404, json={"error": "not found"})

        client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
        client._client = httpx.Client(
            base_url="http://test-bias-server",
            headers=client._client.headers,
            transport=httpx.MockTransport(handler),
        )

        records = [
            {"group": "A", "outcome": 1, "label": 1},
            {"group": "B", "outcome": 0, "label": 1},
        ]
        result = client.submit_bias_analysis("test-agent", records)

        # Two requests: samples + assess
        assert len(captured_bodies) == 2
        samples_req = captured_bodies[0]
        assert samples_req["path"] == "/api/v1/bias/equalized-odds/samples"
        assert samples_req["body"]["agentId"] == "test-agent"
        assert len(samples_req["body"]["records"]) == 2

        assess_req = captured_bodies[1]
        assert "/equalized-odds/assess/test-agent" in assess_req["path"]

        # Return shape
        assert result["recorded"] == 4
        assert result["totalRecords"] == 4
        eo = result["equalizedOdds"]
        assert eo["tprViolation"] is True
        assert eo["fprViolation"] is True
        assert abs(eo["maxTprGap"] - 0.4) < 0.001
        assert abs(eo["maxFprGap"] - 0.2) < 0.001
        assert len(eo["groups"]) == 2

    def test_passes_custom_thresholds_to_assess_body(self):
        """Custom tpr_threshold / fpr_threshold must be forwarded to the assess call."""
        captured_assess_body: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            path = request.url.path
            if path == "/api/v1/bias/equalized-odds/samples":
                return httpx.Response(201, json=EO_SAMPLE_RESPONSE)
            if "/equalized-odds/assess/" in path:
                captured_assess_body.update(json.loads(request.content))
                return httpx.Response(200, json=EO_ASSESS_RESPONSE)
            return httpx.Response(404, json={"error": "not found"})

        client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
        client._client = httpx.Client(
            base_url="http://test-bias-server",
            headers=client._client.headers,
            transport=httpx.MockTransport(handler),
        )

        client.submit_bias_analysis(
            "test-agent",
            [{"group": "A", "outcome": 1, "label": 1}],
            tpr_threshold=0.25,
            fpr_threshold=0.15,
        )

        assert captured_assess_body.get("tprThreshold") == 0.25
        assert captured_assess_body.get("fprThreshold") == 0.15

    def test_no_thresholds_when_not_provided(self):
        """When thresholds are not set, assess body should be empty."""
        captured_assess_body: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            path = request.url.path
            if path == "/api/v1/bias/equalized-odds/samples":
                return httpx.Response(201, json=EO_SAMPLE_RESPONSE)
            if "/equalized-odds/assess/" in path:
                captured_assess_body.update(json.loads(request.content))
                return httpx.Response(200, json=EO_ASSESS_RESPONSE)
            return httpx.Response(404, json={"error": "not found"})

        client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
        client._client = httpx.Client(
            base_url="http://test-bias-server",
            headers=client._client.headers,
            transport=httpx.MockTransport(handler),
        )

        client.submit_bias_analysis("test-agent", [{"group": "A", "outcome": 1, "label": 1}])
        assert "tprThreshold" not in captured_assess_body
        assert "fprThreshold" not in captured_assess_body


class TestBiasClientGetEqualizedOdds:
    """Tests for BiasClient.get_equalized_odds."""

    def test_returns_result_when_present(self):
        responses = {"/api/v1/bias/equalized-odds/test-agent": EO_GET_RESPONSE}
        client = make_bias_client(responses)
        result = client.get_equalized_odds("test-agent")
        assert result is not None
        assert result["agentId"] == "test-agent"
        assert "groups" in result

    def test_returns_none_on_404(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, json={"error": "not found"})

        client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
        client._client = httpx.Client(
            base_url="http://test-bias-server",
            headers=client._client.headers,
            transport=httpx.MockTransport(handler),
        )
        result = client.get_equalized_odds("nonexistent-agent")
        assert result is None


class TestBiasClientDemographicParity:
    """Tests for original P1D-05 demographic parity wrappers."""

    def test_submit_sample_posts_correct_body(self):
        captured_body: dict[str, Any] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/bias/samples":
                captured_body.update(json.loads(request.content))
                return httpx.Response(201, json=BIAS_SAMPLES_RESPONSE)
            return httpx.Response(404, json={"error": "not found"})

        client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
        client._client = httpx.Client(
            base_url="http://test-bias-server",
            headers=client._client.headers,
            transport=httpx.MockTransport(handler),
        )

        result = client.submit_sample(
            "my-agent",
            {"gender": "female", "region": "US"},
            {"responseTime": 120.0},
        )

        assert captured_body["agentId"] == "my-agent"
        assert captured_body["categories"]["gender"] == "female"
        assert captured_body["numericFeatures"]["responseTime"] == 120.0
        assert result["recorded"] is True

    def test_run_assessment_posts_to_correct_path(self):
        captured_path = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured_path.append(request.url.path)
            return httpx.Response(200, json=BIAS_ASSESS_RESPONSE)

        client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
        client._client = httpx.Client(
            base_url="http://test-bias-server",
            headers=client._client.headers,
            transport=httpx.MockTransport(handler),
        )

        result = client.run_assessment("my-agent", "My Agent")
        assert captured_path[0] == "/api/v1/bias/assess/my-agent"
        assert result["agentId"] == "test-agent"

    def test_get_fairness_summary_returns_none_on_404(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, json={"error": "not found"})

        client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
        client._client = httpx.Client(
            base_url="http://test-bias-server",
            headers=client._client.headers,
            transport=httpx.MockTransport(handler),
        )
        result = client.get_fairness_summary("absent-agent")
        assert result is None

    def test_get_fairness_summary_returns_data_when_present(self):
        def handler(request: httpx.Request) -> httpx.Response:
            if "/fairness/" in request.url.path:
                return httpx.Response(200, json=FAIRNESS_RESPONSE)
            return httpx.Response(404, json={"error": "not found"})

        client = BiasClient(api_url="http://test-bias-server", api_token="test-token")
        client._client = httpx.Client(
            base_url="http://test-bias-server",
            headers=client._client.headers,
            transport=httpx.MockTransport(handler),
        )
        result = client.get_fairness_summary("test-agent")
        assert result is not None
        assert result["agentId"] == "test-agent"
        assert "summary" in result
