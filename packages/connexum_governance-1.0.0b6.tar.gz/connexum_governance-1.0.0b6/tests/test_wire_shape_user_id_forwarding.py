"""F-NEW-CRIT-39f-followup (Python): build_check_action_body must accept
user_id and llm_model so all 9 framework adapters can forward them.

Audit (2026-05-03): all 9 framework adapters call build_check_action_body
in _wire_shape.py. Function signature today omits user_id and llm_model.
Result: every framework adapter call lands in the audit chain with
userId='unknown' and llmModel='unknown' regardless of context.

Single chokepoint fix: extend build_check_action_body signature.
Adapters call sites get optional kwargs; existing callers unaffected.

@connexum/ai-governance F-NEW-CRIT-39f-followup
"""

from __future__ import annotations

from connexum_governance.integrations._wire_shape import build_check_action_body


def test_user_id_kwarg_lands_in_body() -> None:
    """user_id kwarg flows through to top-level userId in the wire body."""
    body = build_check_action_body(
        tool_name="web_search",
        agent_name="crewai-tool:web_search",
        user_id="thomas@my-cc.io",
    )
    assert body.get("userId") == "thomas@my-cc.io", (
        f"build_check_action_body must accept user_id and emit userId. Got: {body}"
    )


def test_llm_model_kwarg_lands_in_body() -> None:
    """llm_model kwarg flows through to top-level llmModel."""
    body = build_check_action_body(
        tool_name="agent_step",
        agent_name="langchain-agent",
        llm_model="claude-opus-4-7",
    )
    assert body.get("llmModel") == "claude-opus-4-7", (
        f"build_check_action_body must accept llm_model and emit llmModel. Got: {body}"
    )


def test_both_kwargs_present() -> None:
    body = build_check_action_body(
        tool_name="web_search",
        agent_name="autogen-agent",
        user_id="alice@example.com",
        llm_model="gpt-4o",
    )
    assert body["userId"] == "alice@example.com"
    assert body["llmModel"] == "gpt-4o"


def test_neither_kwarg_supplied_then_keys_absent() -> None:
    """Backward compat: when adapters haven't been updated yet, omitted kwargs
    must NOT appear as null/empty - server falls back to its 'unknown' default."""
    body = build_check_action_body(
        tool_name="x",
        agent_name="y",
    )
    assert "userId" not in body, f"Omitted user_id must NOT appear. Got: {body}"
    assert "llmModel" not in body, f"Omitted llm_model must NOT appear. Got: {body}"


def test_existing_signature_unaffected() -> None:
    """Existing 9 framework adapters use these kwargs today; they MUST
    continue to work after the user_id/llm_model addition."""
    body = build_check_action_body(
        tool_name="fake_lc_tool",
        agent_name="GovernedTool._run",
        agent_role="tool",
        framework_action="framework.langchain.tool_invoke",
        input_dict={"query": "test"},
        message_preview="test query",
        pack_ids=["hipaa", "soc2"],
        extra_metadata={"sourceNode": "agent"},
        source="GovernedTool._run",
        tools=["fake_lc_tool"],
    )
    assert body["toolName"] == "fake_lc_tool"
    assert body["agent"]["name"] == "GovernedTool._run"
    assert body["agent"]["role"] == "tool"
    assert body["input"] == {"query": "test"}
    assert body["sessionInfo"]["metadata"]["frameworkAction"] == "framework.langchain.tool_invoke"
