"""F-NEW-CRIT-39e-2-PY Slice 4: Python SDK Client.check_action(attestor=...) wiring.

Proves:
  1. GovernanceClient and AsyncGovernanceClient accept attestor= in __init__
     and per-call on check_action().
  2. When an attestor is in effect, check_action() calls attestor.sign(ctx)
     and attaches signed.token to body['attestationToken'] AND the
     'X-Attestation-Token' request header.
  3. AttestorError raised by sign() is wrapped into a GovernanceViolation
     with a DENY decision (mirrors TS governed-llm-base.ts:217).
  4. Per-call attestor= overrides the client-level default.
  5. ValueError raised when an attestor is in effect but org_id is None
     (the org_id becomes the aud claim).
  6. The wire format produced by the SDK is consumable by the
     SoftwareKeyAttestor reference impl: token has 'v4att.' prefix,
     decoded payload carries the expected sub/aud/action/jti claims.

Test strategy: capture the wire request via httpx.BaseTransport
(established pattern in test_check_action_user_model_forwarding.py) and
assert on body + headers. No real governance server required for the
wiring proof; the cross-SDK contract test against a real sidecar lives
in Slice 5.

@connexum/ai-governance F-NEW-CRIT-39e-2-PY Slice 4
"""

from __future__ import annotations

import asyncio
import base64
import json
from typing import Any

import httpx
import pytest

from connexum_governance.attestor import (
    AttestationContext,
    AttestorError,
    EndUserAttestor,
    SignedAttestation,
)
from connexum_governance.client import AsyncGovernanceClient, GovernanceClient
from connexum_governance.models import AgentIdentity, GovernanceViolation
from connexum_governance.testing.software_key_attestor import (
    SoftwareKeyAttestor,
    generate_software_key,
)


_TEST_ORG_ID = "00000000-0000-4000-8000-000000000001"


# ---------------------------------------------------------------------------
# Shared test fixtures
# ---------------------------------------------------------------------------


class _CapturingTransport(httpx.BaseTransport):
    """Sync transport that records the request and returns ALLOW."""

    def __init__(self) -> None:
        self.captured: list[dict[str, Any]] = []

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content.decode("utf-8")) if request.content else {}
        self.captured.append({
            "url": str(request.url),
            "body": body,
            "headers": dict(request.headers),
        })
        return httpx.Response(
            200,
            json={
                "decision": "ALLOW",
                "reason": "test-stub",
                "auditId": "audit-stub-attestor",
                "metadata": {},
            },
        )


class _AsyncCapturingTransport(httpx.AsyncBaseTransport):
    """Async transport that records the request and returns ALLOW."""

    def __init__(self) -> None:
        self.captured: list[dict[str, Any]] = []

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content.decode("utf-8")) if request.content else {}
        self.captured.append({
            "url": str(request.url),
            "body": body,
            "headers": dict(request.headers),
        })
        return httpx.Response(
            200,
            json={
                "decision": "ALLOW",
                "reason": "test-stub",
                "auditId": "audit-stub-attestor-async",
                "metadata": {},
            },
        )


class _RaisingAttestor:
    """EndUserAttestor that always raises AttestorError. Used to prove the
    GovernanceViolation wrap path."""

    def __init__(self, code: str = "user-cancelled", message: str = "fingerprint dismissed") -> None:
        self._code = code
        self._message = message

    async def sign(self, context: AttestationContext) -> SignedAttestation:
        raise AttestorError(self._code, self._message)


def _make_sync_client(*, org_id: str | None, attestor: EndUserAttestor | None = None) -> tuple[GovernanceClient, _CapturingTransport]:
    transport = _CapturingTransport()
    client = GovernanceClient(
        api_url="http://test-server.local",
        license_key="test-license",
        org_id=org_id,
        on_failure="open",
        enforce=False,
        attestor=attestor,
    )
    client._client = httpx.Client(  # type: ignore[attr-defined]
        transport=transport,
        base_url="http://test-server.local",
        headers={"Authorization": "Bearer test-license"},
    )
    return client, transport


def _make_async_client(*, org_id: str | None, attestor: EndUserAttestor | None = None) -> tuple[AsyncGovernanceClient, _AsyncCapturingTransport]:
    transport = _AsyncCapturingTransport()
    client = AsyncGovernanceClient(
        api_url="http://test-server.local",
        license_key="test-license",
        org_id=org_id,
        on_failure="open",
        enforce=False,
        attestor=attestor,
    )
    client._client = httpx.AsyncClient(  # type: ignore[attr-defined]
        transport=transport,
        base_url="http://test-server.local",
        headers={"Authorization": "Bearer test-license"},
    )
    return client, transport


def _make_software_attestor(sub: str = "user-thomas") -> SoftwareKeyAttestor:
    keypair = generate_software_key()
    return SoftwareKeyAttestor(
        private_key=keypair.private_key,
        sub_claim=sub,
        ttl_seconds=60,
    )


# ---------------------------------------------------------------------------
# Test 1: baseline without attestor -- no token, no header
# ---------------------------------------------------------------------------


def test_no_attestor_baseline_no_attestation_token() -> None:
    """Without an attestor, the existing wire format is unchanged: no
    `attestationToken` body field, no `X-Attestation-Token` header."""
    client, transport = _make_sync_client(org_id=_TEST_ORG_ID)
    client.check_action(
        tool="Read",
        input={"file_path": "/tmp/x.txt"},
        agent=AgentIdentity(name="rex-agent", role="researcher"),
    )
    assert len(transport.captured) == 1
    captured = transport.captured[0]
    assert "attestationToken" not in captured["body"]
    # httpx normalizes header names to lowercase
    assert "x-attestation-token" not in captured["headers"]


# ---------------------------------------------------------------------------
# Test 2: constructor-level attestor attaches token to body + header
# ---------------------------------------------------------------------------


def test_constructor_attestor_attaches_token_and_header() -> None:
    attestor = _make_software_attestor(sub="user-thomas")
    client, transport = _make_sync_client(org_id=_TEST_ORG_ID, attestor=attestor)
    client.check_action(
        tool="Read",
        input={"file_path": "/tmp/x.txt"},
        agent=AgentIdentity(name="rex-agent", role="researcher"),
    )
    assert len(transport.captured) == 1
    captured = transport.captured[0]

    token = captured["body"].get("attestationToken")
    assert token is not None, "body must carry attestationToken when attestor is set"
    assert isinstance(token, str)
    assert token.startswith("v4att."), f"token must use v4att. wire prefix, got: {token[:20]}"

    header_token = captured["headers"].get("x-attestation-token")
    assert header_token == token, "X-Attestation-Token header must match body field exactly"


# ---------------------------------------------------------------------------
# Test 3: per-call attestor override
# ---------------------------------------------------------------------------


def test_per_call_attestor_overrides_client_default() -> None:
    default_attestor = _make_software_attestor(sub="user-default")
    override_attestor = _make_software_attestor(sub="user-override")
    client, transport = _make_sync_client(
        org_id=_TEST_ORG_ID, attestor=default_attestor,
    )
    client.check_action(
        tool="Read",
        input={"file_path": "/tmp/x.txt"},
        agent=AgentIdentity(name="rex-agent", role="researcher"),
        attestor=override_attestor,
    )
    captured = transport.captured[0]
    token = captured["body"]["attestationToken"]

    # Decode payload to verify the override sub claim made it through
    payload_b64 = token.split(".")[1]
    payload_b64_padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    payload = json.loads(base64.urlsafe_b64decode(payload_b64_padded))
    assert payload["sub"] == "user-override", (
        f"per-call attestor must override client default; sub claim was {payload['sub']}"
    )


# ---------------------------------------------------------------------------
# Test 4: AttestorError wraps to GovernanceViolation with DENY
# ---------------------------------------------------------------------------


def test_attestor_error_wraps_to_governance_violation() -> None:
    raising = _RaisingAttestor(code="user-cancelled", message="dismissed prompt")
    client, _ = _make_sync_client(org_id=_TEST_ORG_ID, attestor=raising)

    with pytest.raises(GovernanceViolation) as exc_info:
        client.check_action(
            tool="Read",
            input={"file_path": "/tmp/x.txt"},
            agent=AgentIdentity(name="rex-agent", role="researcher"),
        )
    decision = exc_info.value.decision
    assert decision.decision.value == "DENY"
    assert decision.metadata.get("attestorError") == "user-cancelled"
    assert "End-user attestation failed" in decision.reason


# ---------------------------------------------------------------------------
# Test 5: missing org_id raises ValueError
# ---------------------------------------------------------------------------


def test_missing_org_id_raises_value_error() -> None:
    attestor = _make_software_attestor()
    client, _ = _make_sync_client(org_id=None, attestor=attestor)
    with pytest.raises(ValueError, match="org_id"):
        client.check_action(
            tool="Read",
            input={"file_path": "/tmp/x.txt"},
            agent=AgentIdentity(name="rex-agent", role="researcher"),
        )


# ---------------------------------------------------------------------------
# Test 6: payload claims match TS schema (sub/aud/action/jti/iat/exp/tenantId)
# ---------------------------------------------------------------------------


def test_payload_claims_match_ts_schema() -> None:
    attestor = _make_software_attestor(sub="user-thomas")
    client, transport = _make_sync_client(org_id=_TEST_ORG_ID, attestor=attestor)
    client.check_action(
        tool="VeryLongToolNameThatExceedsTwoHundredCharacters" * 10,
        input={"file_path": "/tmp/x.txt"},
        agent=AgentIdentity(name="rex-agent", role="researcher"),
        user_id="thomas@my-cc.io",
    )
    token = transport.captured[0]["body"]["attestationToken"]
    payload_b64 = token.split(".")[1]
    payload_b64_padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    payload = json.loads(base64.urlsafe_b64decode(payload_b64_padded))

    assert payload["sub"] == "user-thomas"
    assert payload["aud"] == _TEST_ORG_ID
    assert payload["tenantId"] == _TEST_ORG_ID
    assert "iat" in payload
    assert "exp" in payload
    assert "jti" in payload
    # action truncated to 200 chars (server-side constraint mirror)
    assert len(payload["action"]) == 200
    # request_hash bound to the tool/input/agent canonical form
    assert "requestHash" in payload
    assert len(payload["requestHash"]) == 64  # SHA-256 hex


# ---------------------------------------------------------------------------
# Test 7: AsyncGovernanceClient parity
# ---------------------------------------------------------------------------


def test_async_client_attestor_attaches_token() -> None:
    attestor = _make_software_attestor(sub="user-async")

    async def _run() -> dict[str, Any]:
        client, transport = _make_async_client(org_id=_TEST_ORG_ID, attestor=attestor)
        await client.check_action(
            tool="Read",
            input={"file_path": "/tmp/y.txt"},
            agent=AgentIdentity(name="async-agent", role="researcher"),
        )
        await client._client.aclose()  # type: ignore[attr-defined]
        return transport.captured[0]

    captured = asyncio.run(_run())
    token = captured["body"].get("attestationToken")
    assert token is not None, "async body must carry attestationToken"
    assert token.startswith("v4att.")
    assert captured["headers"].get("x-attestation-token") == token

    payload_b64 = token.split(".")[1]
    payload_b64_padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    payload = json.loads(base64.urlsafe_b64decode(payload_b64_padded))
    assert payload["sub"] == "user-async"
