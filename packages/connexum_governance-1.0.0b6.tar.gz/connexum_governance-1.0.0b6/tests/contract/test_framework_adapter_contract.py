"""Python Framework Adapter Contract Suite

Runs shared invariants against all 8 Python framework adapter implementations:
  1. LangChain           (GovernanceCallbackHandler.on_tool_start)
  2. OpenAI Agents SDK   (OpenAIAgentsGovernance.agent_start + tool_call)
  3. LlamaIndex          (LlamaIndexGovernance.tool_call)
  4. CrewAI              (GovernanceCallback.on_tool_start)
  5. AutoGen             (GovernanceGuardrail.protect decorator)
  6. LangGraph           (GovernanceTool.invoke)
  7. Pydantic AI         (governed_tool_decorator / create_governed_pydantic_ai)
  8. Haystack v2         (HaystackGovernance.pipeline_start + node_start)

Contract invariants (applied per adapter via pytest parametrize):
  1.  Adapter constructs without error
  2.  ALLOW: primary call path completes without GovernanceViolation
  3.  DENY with enforce: governance blocks (raises GovernanceViolation or returns denial)
  4.  PENDING: governance routes to approval (no crash)
  5.  Governance check fires on the primary call path (check payload captured)
  6.  Action key in governance payload matches documented adapter action name
  7.  Constructor requires mandatory parameters (rejects None/missing)
  8.  Async variant behaves consistently (where applicable)
  9.  Public factory returns expected adapter type

Divergences found:
  - DIVERGENCE-002: PydanticAI uses standalone URL/key params (not GovernanceClient)
    unlike the other 7 adapters. This is an intentional design choice for TS parity
    but breaks the uniform construction contract.
  - DIVERGENCE-003: RESOLVED (WS-05 ITEM 3). LangChain GovernanceCallbackHandler
    on_tool_start now returns GovernanceDecision on ALLOW (matching OpenAI Agents /
    LlamaIndex). LangChain ignores the return value internally; this is for callers
    that invoke the handler directly.
  - DIVERGENCE-004: LangChain on_tool_start DENY does not raise even with raise_on_deny=True
    (callback system design limitation: GovernedTool._run() is the blocking primitive).
  - DIVERGENCE-005: RESOLVED (WS-05 ITEM 5). CrewAI / AutoGen / LangGraph now send
    `tool.<name>` (with `tool.` prefix) matching OpenAIAgents / LlamaIndex / LangChain.
  - DIVERGENCE-006: RESOLVED (WS-05 ITEM 6). OpenAIAgents now auto-initializes default
    agent state on first tool_call() if agent_start() was not called. A warning is emitted
    to stderr. Explicit agent_start() is still recommended for strict lifecycle enforcement.
  - DIVERGENCE-007: RESOLVED (WS-05 ITEM 7). PydanticAI now sends both `tool` key
    (value: `tool.<name>`) AND `action` key (`framework.pydantic_ai.tool_invoke`).
    The `action` key is retained for downstream filtering by pack rules targeting the
    pydantic_ai action namespace.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation as LangchainGovernanceViolation,
)
from tests.conftest import make_client, make_transport

# Unified catch for both GovernanceViolation types (models vs langchain_errors)
_ALL_GOVERNANCE_VIOLATIONS = (GovernanceViolation, LangchainGovernanceViolation)


# ---------------------------------------------------------------------------
# Shared response stubs
# ---------------------------------------------------------------------------

_ALLOW_RESP = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-fw-allow"}
_DENY_RESP = {"decision": "DENY", "reason": "Framework contract denial", "auditId": "aud-fw-deny"}
_PENDING_RESP = {
    "decision": "REQUIRE_APPROVAL",
    "reason": "Requires approval",
    "approvalId": "ap-fw-contract-001",
    "auditId": "aud-fw-pending",
}
_CLASSIFY_CLEAN = {"allowed": True, "guardsTriggered": [], "auditId": "aud-fw-classify"}
_OK = {"ok": True}


def _full_route(decision_resp: dict) -> dict[str, Any]:
    return {
        "/api/v1/governance/check-action": decision_resp,
        "/api/v1/governance/check-task": decision_resp,
        "/api/v1/governance/report-result": _OK,
        "/api/v1/governance/classify": _CLASSIFY_CLEAN,
        "/api/v1/governance/provider-compliance": _OK,
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }


def _transport_for(decision: str) -> httpx.MockTransport:
    resp = {"allow": _ALLOW_RESP, "deny": _DENY_RESP, "pending": _PENDING_RESP}[decision]
    return make_transport(_full_route(resp))


def _capturing_transport(decision: str, captures: list[dict]) -> httpx.MockTransport:
    resp = {"allow": _ALLOW_RESP, "deny": _DENY_RESP, "pending": _PENDING_RESP}[decision]

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path in (
            "/api/v1/governance/check-action",
            "/api/v1/governance/check-task",
        ):
            try:
                body = json.loads(request.content)
                captures.append(body)
            except Exception:
                pass
            return httpx.Response(200, json=resp)
        return httpx.Response(200, json=_OK)

    return httpx.MockTransport(handler)


# ---------------------------------------------------------------------------
# Adapter configuration
# ---------------------------------------------------------------------------

@dataclass
class FrameworkAdapterConfig:
    """Per-adapter configuration for the framework contract suite."""

    name: str

    # Build adapter from GovernanceClient (or None for non-GovernanceClient adapters)
    adapter_factory: Callable[..., Any]

    # Exercise the primary tool-dispatch path: (adapter, tool_name) -> Any
    invoke_tool: Callable[[Any, str], Any]

    # Expected action key value or prefix in governance payload
    # Checked against `tool`, `toolName`, and `action` keys
    expected_action_value: str

    # Whether to do prefix-matching (True) or exact-match (False)
    action_prefix_match: bool = True

    # Whether a DENY (enforce=True) raises GovernanceViolation
    deny_raises: bool = True

    # When True, skip invariant 3 (DENY blocking) with an explanation.
    # Used for adapters where DENY cannot be detected via return value or exception.
    skip_deny_test: Optional[str] = None  # None = don't skip; str = skip reason

    # Whether this adapter uses GovernanceClient (standard) or standalone (PydanticAI)
    uses_governance_client: bool = True

    # Async variant: (adapter, tool_name) -> Any  (coroutine)
    invoke_tool_async: Optional[Callable[[Any, str], Any]] = None

    # For deny test: factory that builds adapter with enforce=True for deny verification
    deny_adapter_factory: Optional[Callable[..., Any]] = None


# ---------------------------------------------------------------------------
# Per-adapter implementations
# ---------------------------------------------------------------------------

# ------ 1. LangChain --------------------------------------------------------
# LangChain uses two adapter paths:
#   a) GovernanceCallbackHandler.on_tool_start -> sends check_action(tool=f"tool.{name}")
#      Returns None (callback style). Does NOT raise on DENY (DIVERGENCE-003/004).
#   b) GovernedTool._run() -> the GUARANTEED blocking primitive.
# Contract tests path (a) for action namespace / check firing.
# DENY blocking is documented as DIVERGENCE-004.

from connexum_governance.integrations.langchain import GovernanceCallbackHandler as LCHandler

class _LCAdapter:
    """Thin wrapper for the LangChain GovernanceCallbackHandler contract tests."""
    def __init__(self, client: GovernanceClient):
        self._handler = LCHandler(client=client, agent_name="contract-lc")

    def invoke_tool(self, tool_name: str) -> Any:
        # Calls check_action(tool=f"tool.{tool_name}") internally.
        # Returns None (callback style -- DIVERGENCE-003).
        self._handler.on_tool_start(
            serialized={"name": tool_name, "id": [tool_name]},
            input_str="contract test",
            run_id="run-lc-contract-001",
        )
        return None  # DIVERGENCE-003: on_tool_start always returns None

def _lc_adapter_factory(client: GovernanceClient) -> Any:
    return _LCAdapter(client)

def _lc_invoke(adapter: Any, tool_name: str) -> Any:
    return adapter.invoke_tool(tool_name)


# ------ 2. OpenAI Agents SDK ------------------------------------------------
# OpenAIAgentsGovernance requires agent_start() before tool_call().
# Calling tool_call() without agent_start() returns DENY with a descriptive reason
# (DIVERGENCE-006). The _oai_invoke helper calls agent_start() first.

from connexum_governance.integrations.openai_agents import OpenAIAgentsGovernance

def _oai_adapter_factory(client: GovernanceClient) -> Any:
    return OpenAIAgentsGovernance(
        client=client,
        allowed_agents=["contract-agent"],
        approved_models=["gpt-4o"],
        sensitive_tools=[],
        sensitive_handoff_targets=[],
        enforce_pack_binding=False,  # Disable pack binding for contract tests
    )

def _oai_invoke(adapter: Any, tool_name: str) -> Any:
    # DIVERGENCE-006: Must call agent_start first to register the run.
    adapter.agent_start(
        agent_id="contract-agent",
        pack_binding=[],
        model="gpt-4o",
        run_id="run-oai-contract-001",
    )
    return adapter.tool_call(
        "contract-agent",
        tool_name,
        {"query": "contract test"},
    )


# ------ 3. LlamaIndex -------------------------------------------------------
# LlamaIndexGovernance.tool_call signature:
#   tool_call(session_id: str, tool_name: str, args: dict, react_trace: Optional[dict])
# Sends check_action(tool=f"tool.{tool_name}").

from connexum_governance.integrations.llamaindex import LlamaIndexGovernance

def _li_adapter_factory(client: GovernanceClient) -> Any:
    return LlamaIndexGovernance(
        client=client,
        agent_name="contract-li-agent",
        approved_models=["gpt-4o"],
    )

def _li_invoke(adapter: Any, tool_name: str) -> Any:
    # Full signature: (session_id, tool_name, args, react_trace=None)
    return adapter.tool_call(
        "session-li-contract-001",
        tool_name,
        {"query": "contract test"},
    )


# ------ 4. CrewAI -----------------------------------------------------------
# GovernanceCallback.on_tool_start sends check_action(tool=f"tool.{tool_name}")
# (DIVERGENCE-005 resolved). Returns "[GOVERNANCE DENIED] ..." string on DENY.

from connexum_governance.integrations.crewai import GovernanceCallback

def _crew_adapter_factory(client: GovernanceClient) -> Any:
    return GovernanceCallback(client=client, agent_name="contract-crew-agent")

def _crew_invoke(adapter: Any, tool_name: str) -> Any:
    return adapter.on_tool_start(tool_name, {"query": "contract test"})


# ------ 5. AutoGen ----------------------------------------------------------
# GovernanceGuardrail.protect(tool_name) is a decorator.
# Sends check_action(tool=f"tool.{tool_name}") (DIVERGENCE-005 resolved).
# Raises GovernanceViolation on DENY (enforce=True default behavior via raise_on_deny).

from connexum_governance.integrations.autogen import GovernanceGuardrail

def _autogen_adapter_factory(client: GovernanceClient) -> Any:
    return GovernanceGuardrail(client=client, agent_name="contract-autogen-agent")

def _autogen_invoke(adapter: Any, tool_name: str) -> Any:
    """Wrap a sync function with @adapter.protect() and call it."""
    call_log: list[str] = []

    @adapter.protect(tool_name)
    def my_tool(query: str) -> str:
        call_log.append(query)
        return "autogen-contract-result"

    return my_tool(query="contract test")


# ------ 6. LangGraph --------------------------------------------------------
# GovernanceTool wraps a tool-duck-type object (name, description, invoke, ainvoke).
# Sends check_action(tool=f"tool.{self.tool_name}") (DIVERGENCE-005 resolved).
# Returns "[GOVERNANCE DENIED] ..." string on DENY (deny_raises=False by default).

from connexum_governance.integrations.langgraph import GovernanceTool as LGTool

class _MockLangChainTool:
    """Minimal tool duck-typing GovernanceTool.wrapped_tool expectations."""
    name = "contract_lg_tool"
    description = "Contract test LangGraph tool"
    args_schema = None

    def invoke(self, input: Any, config: Any = None, **kwargs: Any) -> str:
        return "langgraph-contract-result"

    async def ainvoke(self, input: Any, config: Any = None, **kwargs: Any) -> str:
        return "langgraph-contract-result-async"

def _lg_adapter_factory(client: GovernanceClient) -> Any:
    return LGTool(
        wrapped_tool=_MockLangChainTool(),
        client=client,
        agent_name="contract-lg-agent",
    )

def _lg_invoke(adapter: Any, tool_name: str) -> Any:
    # GovernanceTool.invoke uses wrapped_tool.name as the action name.
    # tool_name param is ignored here since the name comes from wrapped_tool.
    return adapter.invoke({"query": "contract test"})

async def _lg_invoke_async(adapter: Any, tool_name: str) -> Any:
    return await adapter.ainvoke({"query": "contract test"})


# ------ 7. Pydantic AI (DIVERGENCE-002: standalone URL/key params) ----------
# create_governed_pydantic_ai / governed_tool_decorator use URL + key + _check_fn,
# NOT a GovernanceClient. Sends both `tool` key (f"tool.{name}") and `action` key
# (framework.pydantic_ai.tool_invoke). DIVERGENCE-007 resolved.
# _check_fn must return a dict with `decision` key.

from connexum_governance.integrations.pydantic_ai_integration import (
    create_governed_pydantic_ai,
    governed_tool_decorator,
)

def _make_pydantic_check_fn(decision: str):
    """Create a check_fn for PydanticAI that returns the given decision."""
    async def _check_fn(url: str, body: dict) -> dict:
        captured_bodies.append(body)
        if decision == "allow":
            return {"decision": "ALLOW", "auditId": "aud-pydantic-contract"}
        if decision == "deny":
            return {"decision": "DENY", "reason": "contract denial", "auditId": "aud-pydantic-deny"}
        return {
            "decision": "REQUIRE_APPROVAL",
            "approvalId": "ap-contract-001",
            "auditId": "aud-pydantic-pending",
        }
    return _check_fn

# Module-level capture list for PydanticAI (since check_fn closure captures it)
captured_bodies: list[dict] = []

class _PydanticAIAdapterStub:
    """Wraps PydanticAI standalone factory for contract testing."""
    def __init__(self, gov_server_url: str, license_key: str, decision: str = "allow"):
        self._gov_server_url = gov_server_url
        self._license_key = license_key
        self._decision = decision

    def invoke_tool(self, tool_name: str) -> Any:
        """Test via governed_tool_decorator (the standard sync path)."""
        class _MockAgent:
            def tool(self_inner, func: Any) -> Any:  # noqa: N805
                return func  # passthrough -- just returns the function unchanged

        check_fn = _make_pydantic_check_fn(self._decision)

        @governed_tool_decorator(
            agent=_MockAgent(),
            governance_server_url=self._gov_server_url,
            license_key=self._license_key,
            raise_on_deny=True,
            _check_fn=check_fn,
        )
        async def my_tool(ctx: Any, query: str) -> str:
            return f"pydantic-result-{query}"

        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(my_tool(None, query="contract_test"))
        finally:
            loop.close()


def _pydantic_adapter_factory(client: GovernanceClient) -> Any:
    # DIVERGENCE-002: PydanticAI uses URL/key, not GovernanceClient.
    # Extract URL and key from GovernanceClient for test convenience.
    return _PydanticAIAdapterStub(
        gov_server_url=client.api_url,
        license_key=client.license_key,
        decision="allow",
    )

def _pydantic_deny_adapter_factory(client: GovernanceClient) -> Any:
    return _PydanticAIAdapterStub(
        gov_server_url=client.api_url,
        license_key=client.license_key,
        decision="deny",
    )

def _pydantic_invoke(adapter: Any, tool_name: str) -> Any:
    return adapter.invoke_tool(tool_name)


# ------ 8. Haystack v2 ------------------------------------------------------
# HaystackGovernance requires pipeline_start() before node_start().
# pipeline_start sends check_action(tool="agent.start").
# node_start sends check_action(tool=f"node.{node_type}").

from connexum_governance.integrations.haystack import HaystackGovernance

def _haystack_adapter_factory(client: GovernanceClient) -> Any:
    return HaystackGovernance(
        client=client,
        agent_name="contract-haystack-agent",
        approved_backends=["openai", "anthropic"],
    )

def _haystack_invoke(adapter: Any, tool_name: str) -> Any:
    # pipeline_start is required to register pipeline state.
    adapter.pipeline_start(
        pipeline_id="contract-pipeline-001",
        pipeline_name="contract-test-pipeline",
        pack_binding=["hipaa"],
    )
    return adapter.node_start(
        pipeline_id="contract-pipeline-001",
        node_id=tool_name,
        node_type="PromptNode",
        inputs={"query": "contract test"},
    )


# ---------------------------------------------------------------------------
# Adapter registry
# ---------------------------------------------------------------------------

FRAMEWORK_CONFIGS: list[FrameworkAdapterConfig] = [
    FrameworkAdapterConfig(
        name="LangChain",
        adapter_factory=_lc_adapter_factory,
        invoke_tool=_lc_invoke,
        # GovernanceCallbackHandler sends tool=f"tool.{name}" -> "tool.contract_ns_tool"
        expected_action_value="tool.",
        action_prefix_match=True,
        deny_raises=False,  # DIVERGENCE-004: on_tool_start callback does not raise
        # DIVERGENCE-004: on_tool_start returns None on DENY (callback system limitation).
        # GovernedTool._run() is the guaranteed blocking path, not covered in this adapter test.
        skip_deny_test=(
            "DIVERGENCE-004: LangChain GovernanceCallbackHandler.on_tool_start "
            "returns None on DENY (callback style -- does not raise or return denial string). "
            "GovernedTool._run() is the blocking primitive, not tested here."
        ),
        uses_governance_client=True,
    ),
    FrameworkAdapterConfig(
        name="OpenAIAgents",
        adapter_factory=_oai_adapter_factory,
        invoke_tool=_oai_invoke,
        # After agent_start, tool_call sends tool=f"tool.{name}" -> "tool.contract_allow_tool"
        expected_action_value="tool.",
        action_prefix_match=True,
        deny_raises=True,  # GovernanceViolation raised when enforce=True
        uses_governance_client=True,
    ),
    FrameworkAdapterConfig(
        name="LlamaIndex",
        adapter_factory=_li_adapter_factory,
        invoke_tool=_li_invoke,
        # tool_call sends tool=f"tool.{name}"
        expected_action_value="tool.",
        action_prefix_match=True,
        deny_raises=True,
        uses_governance_client=True,
    ),
    FrameworkAdapterConfig(
        name="CrewAI",
        adapter_factory=_crew_adapter_factory,
        invoke_tool=_crew_invoke,
        # on_tool_start sends tool=f"tool.{name}" (normalized, DIVERGENCE-005 resolved)
        expected_action_value="tool.",
        action_prefix_match=True,
        deny_raises=False,  # Returns "[GOVERNANCE DENIED] ..." string
        uses_governance_client=True,
    ),
    FrameworkAdapterConfig(
        name="AutoGen",
        adapter_factory=_autogen_adapter_factory,
        invoke_tool=_autogen_invoke,
        # protect() sends tool=f"tool.{name}" (normalized, DIVERGENCE-005 resolved)
        expected_action_value="tool.",
        action_prefix_match=True,
        deny_raises=True,
        uses_governance_client=True,
    ),
    FrameworkAdapterConfig(
        name="LangGraph",
        adapter_factory=_lg_adapter_factory,
        invoke_tool=_lg_invoke,
        invoke_tool_async=_lg_invoke_async,
        # GovernanceTool sends tool=f"tool.{wrapped_tool.name}" (normalized, DIVERGENCE-005 resolved)
        expected_action_value="tool.contract_lg_tool",  # prefixed name from _MockLangChainTool
        action_prefix_match=False,  # exact match
        deny_raises=False,  # Returns "[GOVERNANCE DENIED] ..." string
        uses_governance_client=True,
    ),
    FrameworkAdapterConfig(
        name="PydanticAI",
        adapter_factory=_pydantic_adapter_factory,
        invoke_tool=_pydantic_invoke,
        # governed_tool_decorator sends both tool=f"tool.{name}" and action="framework.pydantic_ai.tool_invoke"
        # DIVERGENCE-007 resolved: tool key now present with tool. prefix
        expected_action_value="tool.",
        action_prefix_match=True,
        deny_raises=True,
        deny_adapter_factory=_pydantic_deny_adapter_factory,
        uses_governance_client=False,  # DIVERGENCE-002
    ),
    FrameworkAdapterConfig(
        name="HaystackV2",
        adapter_factory=_haystack_adapter_factory,
        invoke_tool=_haystack_invoke,
        # pipeline_start sends tool="agent.start", node_start sends tool=f"node.{type}"
        expected_action_value="agent.",
        action_prefix_match=True,
        deny_raises=True,
        uses_governance_client=True,
    ),
]

FRAMEWORK_IDS = [cfg.name for cfg in FRAMEWORK_CONFIGS]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fw_adapter(cfg: FrameworkAdapterConfig, decision: str, enforce: bool = False) -> Any:
    transport = _transport_for(decision)
    client = make_client(transport, enforce=enforce)
    return cfg.adapter_factory(client)


def _is_denied(result: Any) -> bool:
    if result is None:
        return False
    if isinstance(result, str):
        return "[GOVERNANCE DENIED]" in result or "denied" in result.lower()
    if hasattr(result, "denied"):
        return bool(result.denied)
    if hasattr(result, "decision"):
        from connexum_governance.models import DecisionType
        try:
            return result.decision == DecisionType.DENY or str(result.decision) == "DENY"
        except Exception:
            pass
    return False


def _is_governance_blocked(result: Any, raised: bool) -> bool:
    """True if governance blocked the call (either via raise or denied result)."""
    if raised:
        return True
    return _is_denied(result)


def _action_matches(captured: list[dict], expected: str, prefix_match: bool) -> tuple[bool, list[str]]:
    """Check if any captured payload has an action matching expected value."""
    all_actions: list[str] = []
    for payload in captured:
        for key in ("tool", "toolName", "action"):
            val = payload.get(key)
            if val and isinstance(val, str):
                all_actions.append(val)

    if prefix_match:
        found = any(a.startswith(expected) or a == expected for a in all_actions)
    else:
        found = any(a == expected for a in all_actions)

    return found, all_actions


# ---------------------------------------------------------------------------
# Contract test class
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("cfg", FRAMEWORK_CONFIGS, ids=FRAMEWORK_IDS)
class TestFrameworkAdapterContract:
    """9-invariant contract suite for Python framework adapters."""

    # -------------------------------------------------------------------
    # Invariant 1: Adapter constructs without error
    # -------------------------------------------------------------------

    def test_1_constructor_valid(self, cfg: FrameworkAdapterConfig):
        """Adapter instantiates without error."""
        adapter = _make_fw_adapter(cfg, "allow")
        assert adapter is not None, f"[{cfg.name}] Adapter factory must return non-None"

    # -------------------------------------------------------------------
    # Invariant 2: ALLOW: primary call completes without GovernanceViolation
    # -------------------------------------------------------------------

    def test_2_allow_no_violation(self, cfg: FrameworkAdapterConfig):
        """ALLOW verdict: invoke_tool completes without raising GovernanceViolation."""
        adapter = _make_fw_adapter(cfg, "allow")
        try:
            result = cfg.invoke_tool(adapter, "contract_allow_tool")
            assert not _is_denied(result), (
                f"[{cfg.name}] ALLOW should not return a denied result, got: {result!r}"
            )
        except _ALL_GOVERNANCE_VIOLATIONS as exc:
            pytest.fail(
                f"[{cfg.name}] GovernanceViolation raised on ALLOW verdict: {exc}"
            )

    # -------------------------------------------------------------------
    # Invariant 3: DENY with enforce: governance blocks call
    # -------------------------------------------------------------------

    def test_3_deny_blocks_call(self, cfg: FrameworkAdapterConfig):
        """DENY verdict: governance blocks the call (raises or returns denial string)."""
        if cfg.skip_deny_test is not None:
            pytest.skip(cfg.skip_deny_test)

        transport = _transport_for("deny")
        client = make_client(transport, enforce=cfg.deny_raises)

        # PydanticAI uses a separate deny factory (check_fn-based, not transport-based)
        if cfg.deny_adapter_factory is not None:
            adapter = cfg.deny_adapter_factory(client)
        else:
            adapter = cfg.adapter_factory(client)

        raised = False
        result = None
        try:
            result = cfg.invoke_tool(adapter, "contract_deny_tool")
        except _ALL_GOVERNANCE_VIOLATIONS:
            raised = True

        assert _is_governance_blocked(result, raised), (
            f"[{cfg.name}] DENY should either raise GovernanceViolation or return denied result. "
            f"raised={raised}, result={result!r}"
        )

    # -------------------------------------------------------------------
    # Invariant 4: PENDING: governance routes to approval without crash
    # -------------------------------------------------------------------

    def test_4_pending_no_crash(self, cfg: FrameworkAdapterConfig):
        """PENDING verdict: invoke completes or raises without crashing unexpectedly."""
        adapter = _make_fw_adapter(cfg, "pending", enforce=False)
        try:
            result = cfg.invoke_tool(adapter, "contract_pending_tool")
            # Non-raising adapters may return a pending indication string or GovernanceDecision
        except Exception as exc:
            exc_type = type(exc).__name__
            if exc_type not in ("GovernanceViolation", "GovernancePendingApproval"):
                raise

    # -------------------------------------------------------------------
    # Invariant 5: Governance check fires on primary call path
    # -------------------------------------------------------------------

    def test_5_governance_check_fires(self, cfg: FrameworkAdapterConfig):
        """A governance check_action or check_task request fires on invoke_tool."""
        # PydanticAI uses check_fn; capture via the module-level list
        if not cfg.uses_governance_client:
            captured_bodies.clear()
            adapter = _make_fw_adapter(cfg, "allow")
            try:
                cfg.invoke_tool(adapter, "contract_check_fires_tool")
            except GovernanceViolation:
                pass
            # PydanticAI's check_fn captures into captured_bodies
            assert len(captured_bodies) >= 1, (
                f"[{cfg.name}] Expected at least one governance check to fire. "
                f"Captured bodies: {captured_bodies}"
            )
            return

        captured: list[dict] = []
        transport = _capturing_transport("allow", captured)
        client = make_client(transport, enforce=False)
        adapter = cfg.adapter_factory(client)

        try:
            cfg.invoke_tool(adapter, "contract_check_fires_tool")
        except _ALL_GOVERNANCE_VIOLATIONS:
            pass  # Even if raised, the check may have fired first

        assert len(captured) >= 1, (
            f"[{cfg.name}] Expected at least one governance check_action or check_task "
            f"to fire on invoke_tool. No requests captured."
        )

    # -------------------------------------------------------------------
    # Invariant 6: Action key in governance payload matches documented name
    # -------------------------------------------------------------------

    def test_6_action_namespace(self, cfg: FrameworkAdapterConfig):
        """Governance payload contains an action matching the documented adapter action."""
        # PydanticAI: use check_fn capture
        if not cfg.uses_governance_client:
            captured_bodies.clear()
            adapter = _make_fw_adapter(cfg, "allow")
            try:
                cfg.invoke_tool(adapter, "contract_ns_tool")
            except GovernanceViolation:
                pass

            if not captured_bodies:
                pytest.skip(f"[{cfg.name}] No captures; invariant 5 covers this")

            found, all_actions = _action_matches(
                captured_bodies, cfg.expected_action_value, cfg.action_prefix_match
            )
            assert found, (
                f"[{cfg.name}] Expected action matching '{cfg.expected_action_value}' "
                f"(prefix={cfg.action_prefix_match}). Got: {all_actions}"
            )
            return

        captured: list[dict] = []
        transport = _capturing_transport("allow", captured)
        client = make_client(transport, enforce=False)
        adapter = cfg.adapter_factory(client)

        try:
            cfg.invoke_tool(adapter, "contract_ns_tool")
        except _ALL_GOVERNANCE_VIOLATIONS:
            pass

        if not captured:
            pytest.skip(f"[{cfg.name}] No governance captures; invariant 5 covers this")

        found, all_actions = _action_matches(captured, cfg.expected_action_value, cfg.action_prefix_match)
        assert found, (
            f"[{cfg.name}] Expected action matching '{cfg.expected_action_value}' "
            f"(prefix={cfg.action_prefix_match}). Got: {all_actions}"
        )

    # -------------------------------------------------------------------
    # Invariant 7: Constructor requires mandatory parameters
    # -------------------------------------------------------------------

    def test_7_constructor_validates_required_params(self, cfg: FrameworkAdapterConfig):
        """Adapter constructor rejects None/invalid mandatory inputs."""
        if not cfg.uses_governance_client:
            # PydanticAI uses URL/key directly -- test those
            with pytest.raises((ValueError, TypeError)):
                create_governed_pydantic_ai(governance_server_url="", license_key="")
            return

        with pytest.raises((TypeError, ValueError, AttributeError) + _ALL_GOVERNANCE_VIOLATIONS):
            # Passing None as client should fail at construction or first use
            adapter = cfg.adapter_factory(None)  # type: ignore
            # Trigger first use in case construction succeeds
            cfg.invoke_tool(adapter, "trigger_validation")

    # -------------------------------------------------------------------
    # Invariant 8: Async variant behaves consistently (where applicable)
    # -------------------------------------------------------------------

    def test_8_async_sync_consistent(self, cfg: FrameworkAdapterConfig):
        """Async variant produces consistent results on ALLOW (where applicable)."""
        if cfg.invoke_tool_async is None:
            pytest.skip(f"[{cfg.name}] No async variant configured")

        # Sync path
        sync_adapter = _make_fw_adapter(cfg, "allow")
        sync_result = cfg.invoke_tool(sync_adapter, "contract_sync_tool")

        # Async path
        async_adapter = _make_fw_adapter(cfg, "allow")
        loop = asyncio.new_event_loop()
        try:
            async_result = loop.run_until_complete(
                cfg.invoke_tool_async(async_adapter, "contract_async_tool")
            )
        finally:
            loop.close()

        assert not _is_denied(sync_result), f"[{cfg.name}] Sync ALLOW must not be denied"
        assert not _is_denied(async_result), f"[{cfg.name}] Async ALLOW must not be denied"

    # -------------------------------------------------------------------
    # Invariant 9: Public factory returns expected type
    # -------------------------------------------------------------------

    def test_9_public_factory_type(self, cfg: FrameworkAdapterConfig):
        """Public factory returns a non-None adapter instance."""
        adapter = _make_fw_adapter(cfg, "allow")
        assert adapter is not None, f"[{cfg.name}] Factory must return non-None"
        assert callable(cfg.invoke_tool), (
            f"[{cfg.name}] invoke_tool config must be callable"
        )
