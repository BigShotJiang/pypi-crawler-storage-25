"""Python LLM Provider Contract Suite

Runs 13 shared invariants against every governed LLM provider adapter
in the Python SDK.

Adapters registered:
  - Anthropic (AnthropicGovernance from integrations.anthropic)

Pattern: pytest parametrize over adapter configs; each param set drives all
13 invariants. New adapters are added by extending ADAPTER_CONFIGS.

Invariants:
 1.  Adapter constructs without error from a valid GovernanceClient
 2.  GovernanceClient api_url is stored correctly (construction contract)
 3.  GovernanceClient license_key is stored correctly (construction contract)
 4.  ALLOW verdict -> intercept_request returns allowed=True (enforce=False)
 5.  DENY verdict -> intercept_request returns allowed=False (enforce=False)
 6.  PENDING verdict -> intercept_request returns requires_approval (enforce=False)
 7.  DENY with enforce=True -> GovernanceViolation raised
 8.  fail-open: enforce=False, server DENY -> no GovernanceViolation raised
 9.  fail-closed: enforce=True, server DENY -> GovernanceViolation raised
 10. Tool name in governance payload when tools present in request
 11. Action name ('llm.chat') appears in governance check payload
 12. enforce=False never raises on any decision (ALLOW / DENY / PENDING)
 13. Multiple sequential intercept_request calls each fire independent governance check
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.models import GovernanceDecision, DecisionType
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared response stubs
# ---------------------------------------------------------------------------

_ALLOW_RESP = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-c-allow"}
_DENY_RESP = {"decision": "DENY", "reason": "Contract test denial", "auditId": "aud-c-deny"}
_PENDING_RESP = {
    "decision": "REQUIRE_APPROVAL",
    "reason": "Requires approval",
    "auditId": "aud-c-pending",
}
_CLASSIFY_CLEAN = {"allowed": True, "guardsTriggered": [], "auditId": "aud-c-classify"}
_OK = {"ok": True}


def _make_transport_for_decision(decision: str) -> httpx.MockTransport:
    """Build a mock transport that returns the given decision for all check endpoints."""
    resp = {"allow": _ALLOW_RESP, "deny": _DENY_RESP, "pending": _PENDING_RESP}[decision]
    return make_transport({
        "/api/v1/governance/check-action": resp,
        "/api/v1/governance/check-task": resp,
        "/api/v1/governance/report-result": _OK,
        "/api/v1/governance/classify": _CLASSIFY_CLEAN,
        "/api/v1/governance/provider-compliance": _OK,
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    })


# ---------------------------------------------------------------------------
# Adapter configuration
# ---------------------------------------------------------------------------

@dataclass
class AdapterConfig:
    """Configuration for running the contract suite against one LLM provider adapter."""

    # Display name for parametrize IDs
    name: str

    # Factory: GovernanceClient -> adapter instance
    adapter_factory: Callable[[GovernanceClient], Any]

    # Minimal request dict for the primary call path
    minimal_request: dict[str, Any]

    # Request dict that includes at least one tool (for invariant 10)
    request_with_tool: dict[str, Any]

    # Expected tool name in the request_with_tool (for invariant 10)
    expected_tool_name: str

    # Expected action/tool key in the governance check payload (for invariant 11)
    expected_action_name: str

    # Whether the adapter raises GovernanceViolation when enforce=True and server DENYs
    raises_on_enforce: bool = True


# ---------------------------------------------------------------------------
# Adapter configs -- extend this list to register new adapters
# ---------------------------------------------------------------------------

from connexum_governance.integrations.anthropic import AnthropicGovernance

ADAPTER_CONFIGS: list[AdapterConfig] = [
    AdapterConfig(
        name="Anthropic",
        adapter_factory=lambda client: AnthropicGovernance(
            client=client,
            agent_name="contract-test-anthropic",
            agent_role="chat",
        ),
        minimal_request={
            "model": "claude-3-haiku-20240307",
            "max_tokens": 128,
            "messages": [{"role": "user", "content": "contract test"}],
        },
        request_with_tool={
            "model": "claude-3-haiku-20240307",
            "max_tokens": 128,
            "messages": [{"role": "user", "content": "use the search tool"}],
            "tools": [{"name": "web_search", "description": "Search the web"}],
        },
        expected_tool_name="web_search",
        expected_action_name="llm.chat",
        raises_on_enforce=True,
    ),
]


# ---------------------------------------------------------------------------
# Helper: make adapter from config + decision + enforce flag
# ---------------------------------------------------------------------------

def _make_adapter(cfg: AdapterConfig, decision: str, enforce: bool) -> Any:
    transport = _make_transport_for_decision(decision)
    client = make_client(transport, enforce=enforce)
    return cfg.adapter_factory(client)


def _make_adapter_with_capture(
    cfg: AdapterConfig,
    capture_list: list[dict],
    decision: str = "allow",
    enforce: bool = False,
) -> Any:
    """Make adapter with a custom transport that captures governance payloads."""
    decision_resp = {"allow": _ALLOW_RESP, "deny": _DENY_RESP, "pending": _PENDING_RESP}[decision]

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path in (
            "/api/v1/governance/check-action",
            "/api/v1/governance/check-task",
        ):
            try:
                body = json.loads(request.content)
                capture_list.append(body)
            except Exception:
                pass
            return httpx.Response(200, json=decision_resp)
        if request.url.path == "/api/v1/governance/classify":
            return httpx.Response(200, json=_CLASSIFY_CLEAN)
        return httpx.Response(200, json=_OK)

    transport = httpx.MockTransport(handler)
    client = make_client(transport, enforce=enforce)
    return cfg.adapter_factory(client)


# ---------------------------------------------------------------------------
# Parametrized test classes -- one class per invariant group
# ---------------------------------------------------------------------------

ADAPTER_IDS = [cfg.name for cfg in ADAPTER_CONFIGS]


@pytest.mark.parametrize("cfg", ADAPTER_CONFIGS, ids=ADAPTER_IDS)
class TestLLMProviderContract:
    """13-invariant contract suite for Python LLM provider adapters."""

    # -------------------------------------------------------------------
    # Invariant 1: Constructor accepts valid config
    # -------------------------------------------------------------------

    def test_1_constructor_valid(self, cfg: AdapterConfig):
        """Adapter instantiates without error given a valid GovernanceClient."""
        adapter = _make_adapter(cfg, "allow", enforce=False)
        assert adapter is not None, (
            f"[{cfg.name}] Adapter factory must return a non-None instance"
        )

    # -------------------------------------------------------------------
    # Invariant 2: GovernanceClient api_url stored correctly
    # -------------------------------------------------------------------

    def test_2_client_api_url_stored(self, cfg: AdapterConfig):
        """GovernanceClient stores api_url (without trailing slash)."""
        transport = _make_transport_for_decision("allow")
        client = make_client(transport, enforce=False)
        adapter = cfg.adapter_factory(client)
        gov_client = getattr(adapter, "client", None)
        if gov_client is not None:
            assert hasattr(gov_client, "api_url"), (
                f"[{cfg.name}] GovernanceClient must expose api_url"
            )
            # api_url should not end with slash (rstrip contract)
            assert not gov_client.api_url.endswith("/"), (
                f"[{cfg.name}] GovernanceClient.api_url must not end with '/'"
            )

    # -------------------------------------------------------------------
    # Invariant 3: GovernanceClient license_key stored correctly
    # -------------------------------------------------------------------

    def test_3_client_license_key_stored(self, cfg: AdapterConfig):
        """GovernanceClient stores license_key."""
        transport = _make_transport_for_decision("allow")
        client = make_client(transport, enforce=False)
        adapter = cfg.adapter_factory(client)
        gov_client = getattr(adapter, "client", None)
        if gov_client is not None:
            assert hasattr(gov_client, "license_key"), (
                f"[{cfg.name}] GovernanceClient must expose license_key"
            )
            assert gov_client.license_key == "test-key", (
                f"[{cfg.name}] GovernanceClient.license_key must match what was passed"
            )

    # -------------------------------------------------------------------
    # Invariant 4: ALLOW -> allowed=True
    # -------------------------------------------------------------------

    def test_4_allow_verdict(self, cfg: AdapterConfig):
        """ALLOW verdict: intercept_request returns decision.allowed == True."""
        adapter = _make_adapter(cfg, "allow", enforce=False)
        decision = adapter.intercept_request(cfg.minimal_request)
        assert decision.allowed, (
            f"[{cfg.name}] Expected allowed=True on ALLOW verdict, got: {decision}"
        )

    # -------------------------------------------------------------------
    # Invariant 5: DENY -> allowed=False (enforce=False, no raise)
    # -------------------------------------------------------------------

    def test_5_deny_verdict_not_enforced(self, cfg: AdapterConfig):
        """DENY verdict with enforce=False: allowed=False, no exception raised."""
        adapter = _make_adapter(cfg, "deny", enforce=False)
        decision = adapter.intercept_request(cfg.minimal_request)
        assert not decision.allowed, (
            f"[{cfg.name}] Expected allowed=False on DENY (enforce=False), got: {decision}"
        )
        assert decision.denied, (
            f"[{cfg.name}] Expected decision.denied=True on DENY verdict"
        )

    # -------------------------------------------------------------------
    # Invariant 6: PENDING -> requires_approval (enforce=False)
    # -------------------------------------------------------------------

    def test_6_pending_verdict(self, cfg: AdapterConfig):
        """REQUIRE_APPROVAL verdict: decision.requires_approval=True (enforce=False)."""
        adapter = _make_adapter(cfg, "pending", enforce=False)
        decision = adapter.intercept_request(cfg.minimal_request)
        assert decision.requires_approval, (
            f"[{cfg.name}] Expected requires_approval=True on PENDING verdict, got: {decision}"
        )
        assert not decision.allowed, (
            f"[{cfg.name}] PENDING decision must not be allowed"
        )

    # -------------------------------------------------------------------
    # Invariant 7: DENY with enforce=True -> GovernanceViolation raised
    # -------------------------------------------------------------------

    def test_7_deny_raises_when_enforced(self, cfg: AdapterConfig):
        """DENY with enforce=True raises GovernanceViolation."""
        if not cfg.raises_on_enforce:
            pytest.skip(f"[{cfg.name}] Adapter does not raise on DENY with enforce=True")
        adapter = _make_adapter(cfg, "deny", enforce=True)
        with pytest.raises(GovernanceViolation):
            adapter.intercept_request(cfg.minimal_request)

    # -------------------------------------------------------------------
    # Invariant 8: fail-open -- enforce=False, server DENY -> no raise
    # -------------------------------------------------------------------

    def test_8_fail_open(self, cfg: AdapterConfig):
        """enforce=False: DENY from server does not raise GovernanceViolation."""
        adapter = _make_adapter(cfg, "deny", enforce=False)
        try:
            decision = adapter.intercept_request(cfg.minimal_request)
            assert not decision.allowed, (
                f"[{cfg.name}] Expected not-allowed result on fail-open DENY"
            )
        except GovernanceViolation as exc:
            pytest.fail(
                f"[{cfg.name}] GovernanceViolation raised with enforce=False "
                f"(fail-open violation): {exc}"
            )

    # -------------------------------------------------------------------
    # Invariant 9: fail-closed -- enforce=True, server DENY -> raise
    # -------------------------------------------------------------------

    def test_9_fail_closed(self, cfg: AdapterConfig):
        """enforce=True: DENY from server raises GovernanceViolation."""
        if not cfg.raises_on_enforce:
            pytest.skip(f"[{cfg.name}] Adapter does not raise on DENY with enforce=True")
        adapter = _make_adapter(cfg, "deny", enforce=True)
        with pytest.raises(GovernanceViolation):
            adapter.intercept_request(cfg.minimal_request)

    # -------------------------------------------------------------------
    # Invariant 10: Tool name in governance payload
    # -------------------------------------------------------------------

    def test_10_tool_name_in_payload(self, cfg: AdapterConfig):
        """Tool names from the request appear in the governance check payload."""
        captured: list[dict] = []
        adapter = _make_adapter_with_capture(cfg, captured, decision="allow")

        adapter.intercept_request(cfg.request_with_tool)

        assert len(captured) >= 1, (
            f"[{cfg.name}] Expected at least one governance check to fire"
        )

        all_tool_names: list[str] = []
        for payload in captured:
            inp = payload.get("input", {})
            tool_names = inp.get("toolNames", [])
            if tool_names:
                all_tool_names.extend(tool_names)

        assert cfg.expected_tool_name in all_tool_names, (
            f"[{cfg.name}] Expected tool '{cfg.expected_tool_name}' in payload. "
            f"Got: {all_tool_names}. Payloads: {captured}"
        )

    # -------------------------------------------------------------------
    # Invariant 11: Action name in governance payload
    # -------------------------------------------------------------------

    def test_11_action_name_in_payload(self, cfg: AdapterConfig):
        """Expected action name appears in the governance check payload."""
        captured: list[dict] = []
        adapter = _make_adapter_with_capture(cfg, captured, decision="allow")

        adapter.intercept_request(cfg.minimal_request)

        assert len(captured) >= 1, (
            f"[{cfg.name}] Expected at least one governance check"
        )

        all_actions: list[str] = []
        for payload in captured:
            # Adapters may use 'tool', 'toolName', or 'action' as the key
            for key in ("tool", "toolName", "action"):
                val = payload.get(key, "")
                if val:
                    all_actions.append(str(val))

        assert cfg.expected_action_name in all_actions, (
            f"[{cfg.name}] Expected action '{cfg.expected_action_name}' in payloads. "
            f"Got: {all_actions}. Full payloads: {captured}"
        )

    # -------------------------------------------------------------------
    # Invariant 12: enforce=False never raises on any decision
    # -------------------------------------------------------------------

    def test_12_enforce_false_never_raises(self, cfg: AdapterConfig):
        """enforce=False: no GovernanceViolation raised regardless of decision."""
        for decision in ("allow", "deny", "pending"):
            adapter = _make_adapter(cfg, decision, enforce=False)
            try:
                adapter.intercept_request(cfg.minimal_request)
            except GovernanceViolation as exc:
                pytest.fail(
                    f"[{cfg.name}] GovernanceViolation raised with enforce=False "
                    f"on '{decision}' decision -- backward compat violation: {exc}"
                )

    # -------------------------------------------------------------------
    # Invariant 13: Multiple sequential calls fire independent checks
    # -------------------------------------------------------------------

    def test_13_multiple_calls_independent(self, cfg: AdapterConfig):
        """Multiple sequential intercept_request calls each fire independent governance check."""
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            if request.url.path in (
                "/api/v1/governance/check-action",
                "/api/v1/governance/check-task",
            ):
                call_count += 1
            return httpx.Response(200, json=_ALLOW_RESP)

        transport = httpx.MockTransport(handler)
        client = make_client(transport, enforce=False)
        adapter = cfg.adapter_factory(client)

        adapter.intercept_request(cfg.minimal_request)
        adapter.intercept_request(cfg.minimal_request)
        adapter.intercept_request(cfg.minimal_request)

        assert call_count >= 3, (
            f"[{cfg.name}] Expected >= 3 governance checks for 3 sequential calls. "
            f"Got {call_count}. Possible caching at shim layer."
        )
