"""F-NEW-CRIT-39f-py: Python SDK forwards user_id + llm_model into the
check-action wire body so the gov-server CRIT-39e schema receives the
regulator-grade fields.

Closes the loop in Python the same way CRIT-39f closed it in TypeScript.
Single SDK fix benefits all 9 of Loom's Python framework adapters
(LangChain Py, OpenAI Agents, LlamaIndex, CrewAI, AutoGen, LangGraph,
Pydantic AI, Haystack v2, Semantic Kernel).

Test strategy: capture the wire body via a fake httpx client. We
assert what would be POSTed to /api/v1/governance/check-action.

@connexum/ai-governance F-NEW-CRIT-39f-py
"""

from __future__ import annotations

import json
from typing import Any, Optional

import httpx
import pytest

from connexum_governance.client import GovernanceClient
from connexum_governance.models import AgentIdentity


class _CapturingTransport(httpx.BaseTransport):
    """httpx Transport that records the request and returns a static ALLOW response."""

    def __init__(self) -> None:
        self.captured: list[dict[str, Any]] = []

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content.decode("utf-8")) if request.content else {}
        self.captured.append({
            "url": str(request.url),
            "body": body,
        })
        return httpx.Response(
            200,
            json={
                "decision": "ALLOW",
                "reason": "test-stub",
                "auditId": "audit-stub-123",
                "metadata": {},
            },
        )


def _make_client_with_transport() -> tuple[GovernanceClient, _CapturingTransport]:
    transport = _CapturingTransport()
    http_client = httpx.Client(
        transport=transport,
        base_url="http://test-server.local",
    )
    client = GovernanceClient(
        api_url="http://test-server.local",
        license_key="test-key",
        on_failure="open",
        enforce=False,
    )
    # Replace the internal httpx client with our capturing one.
    client._client = http_client  # type: ignore[attr-defined]
    return client, transport


def test_user_id_kwarg_forwarded_to_wire_body() -> None:
    """user_id kwarg on check_action must appear as 'userId' in the wire body."""
    client, transport = _make_client_with_transport()
    agent = AgentIdentity(name="rex-agent", role="researcher")
    client.check_action(
        tool="Read",
        input={"file_path": "/tmp/x.txt"},
        agent=agent,
        user_id="thomas@my-cc.io",
    )
    assert len(transport.captured) == 1
    body = transport.captured[0]["body"]
    assert body.get("userId") == "thomas@my-cc.io", (
        f"Wire body must include userId for server CRIT-39e to record. Got: {body}"
    )


def test_llm_model_kwarg_forwarded_to_wire_body() -> None:
    """llm_model kwarg on check_action must appear as 'llmModel' in the wire body."""
    client, transport = _make_client_with_transport()
    agent = AgentIdentity(name="rex-agent", role="researcher")
    client.check_action(
        tool="Read",
        input={"file_path": "/tmp/x.txt"},
        agent=agent,
        llm_model="claude-opus-4-7",
    )
    assert len(transport.captured) == 1
    body = transport.captured[0]["body"]
    assert body.get("llmModel") == "claude-opus-4-7", (
        f"Wire body must include llmModel for server CRIT-39e to record. Got: {body}"
    )


def test_both_user_and_model_forwarded() -> None:
    """Both fields together flow correctly."""
    client, transport = _make_client_with_transport()
    agent = AgentIdentity(name="shield-agent", role="security")
    client.check_action(
        tool="Bash",
        input={"command": "ls"},
        agent=agent,
        user_id="alice@example.com",
        llm_model="gpt-4o",
    )
    body = transport.captured[0]["body"]
    assert body.get("userId") == "alice@example.com"
    assert body.get("llmModel") == "gpt-4o"


def test_neither_set_then_omitted_from_wire_body() -> None:
    """When neither kwarg supplied, wire body must NOT include the keys.

    Server defaults to 'unknown' when the field is absent. Sending an
    explicit null or empty string would be wrong - operator who hasn't
    integrated yet must not have their entries marked with bogus values.
    """
    client, transport = _make_client_with_transport()
    agent = AgentIdentity(name="rex-agent", role="researcher")
    client.check_action(
        tool="Read",
        input={"file_path": "/tmp/x.txt"},
        agent=agent,
    )
    body = transport.captured[0]["body"]
    assert "userId" not in body, f"Omitted user_id must NOT appear in wire body. Got: {body}"
    assert "llmModel" not in body, f"Omitted llm_model must NOT appear in wire body. Got: {body}"


def test_existing_basic_fields_unaffected() -> None:
    """Backward compat: existing required fields still work alongside new fields."""
    client, transport = _make_client_with_transport()
    agent = AgentIdentity(name="rex-agent", role="researcher")
    client.check_action(
        tool="Read",
        input={"file_path": "/tmp/x.txt"},
        agent=agent,
        user_id="thomas@my-cc.io",
        llm_model="claude-opus-4-7",
    )
    body = transport.captured[0]["body"]
    assert body.get("userId") == "thomas@my-cc.io"
    assert body.get("llmModel") == "claude-opus-4-7"
    # Verify the existing toolName + agent fields are still there
    assert body.get("toolName") == "Read"
    assert body.get("agent", {}).get("name") == "rex-agent"
