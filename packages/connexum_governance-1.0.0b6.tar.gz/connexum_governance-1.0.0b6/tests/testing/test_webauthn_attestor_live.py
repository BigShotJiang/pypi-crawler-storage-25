"""
F-NEW-CRIT-39e-2-PY slice 3 -- WebAuthnAttestor live integration tests.

These tests require the testbed governance-sidecar running at
``http://127.0.0.1:4200``. They exercise the Python WebAuthnAttestor's
full flow against the real server's ``verifyWebAuthnAttestation`` path,
covering:

  * register a key (the standard registration ceremony)
  * sign a v4att.webauthn token via the WebAuthnAttestor
  * POST /check-action with the token in the X-Attestation-Token header
  * assert 200 (server's simplified verifier accepts)

The server-side WebAuthn slice 4 simplification means the signature
bytes are NOT cryptographically verified (filed
F-NEW-CRIT-39e-2-WEBAUTHN-FULL-VERIFY). Any non-empty signature byte
string passes the wire check. The actions tested here verify:

  * Token prefix routing (`v4att.webauthn.`)
  * Action binding (claims.action == toolName)
  * Tenant audience (claims.aud == agent.orgId)
  * Replay protection (second use of jti -> 401 token-replayed)

If the sidecar is down, these tests are skipped.

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 3
"""

from __future__ import annotations

import base64
import json
import os
import uuid
from typing import Tuple

import httpx
import pytest

from connexum_governance.attestor import AttestationContext, AttestorError
from connexum_governance.testing import compute_request_hash, generate_software_key
from connexum_governance.webauthn_attestor import (
    WEBAUTHN_TOKEN_PREFIX,
    WebAuthnAssertion,
    WebAuthnAttestor,
)


SIDECAR_URL = os.environ.get("CONNEXUM_TESTBED_URL", "http://127.0.0.1:4200")
HEALTH_PATH = "/api/v1/health"
CHALLENGE_PATH = "/api/v1/admin/attestation/keys/challenge"
REGISTER_PATH = "/api/v1/admin/attestation/keys/register"
CHECK_ACTION_PATH = "/api/v1/governance/check-action"


def _b64url_no_pad(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _mint_admin_jwt(sub: str, org: str) -> str:
    header = _b64url_no_pad(
        json.dumps({"alg": "none", "typ": "JWT"}, separators=(",", ":")).encode()
    )
    payload = _b64url_no_pad(
        json.dumps(
            {"sub": sub, "org": org, "role": "ORG_ADMIN",
             "iat": 0, "exp": 9_999_999_999},
            separators=(",", ":"),
        ).encode()
    )
    return f"{header}.{payload}.fakesig"


def _is_sidecar_up() -> bool:
    try:
        r = httpx.get(f"{SIDECAR_URL}{HEALTH_PATH}", timeout=3.0)
        return r.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(
    not _is_sidecar_up(),
    reason=(
        "F-NEW-CRIT-39e-2-PY slice 3 WebAuthn live tests require the "
        f"governance-sidecar at {SIDECAR_URL}. Start it via "
        "/root/sample-customer-env/governance-sidecar/start-sidecar.sh."
    ),
)


async def _register_webauthn_user(
    client: httpx.AsyncClient,
    *,
    user_id: str,
    tenant_id: str,
) -> str:
    """Register a user in the sidecar's keystore so verifyWebAuthnAttestation's
    `unknown-user` check passes. WebAuthn registration in slice 3 still
    flows through the same admin keystore endpoint as Ed25519 -- the
    server does not differentiate the registration ceremony per token
    type. Returns the public key PEM (unused for WebAuthn verification
    in slice 4, but the endpoint requires it).
    """
    kp = generate_software_key()
    admin_jwt = _mint_admin_jwt(f"admin@{tenant_id}", tenant_id)
    headers = {"Authorization": f"Bearer {admin_jwt}"}

    r = await client.post(
        f"{SIDECAR_URL}{CHALLENGE_PATH}",
        headers=headers,
        json={"userId": user_id, "tenantId": tenant_id},
    )
    assert r.status_code == 200, f"challenge POST failed: {r.status_code} {r.text}"
    challenge = r.json()["challenge"]

    r = await client.post(
        f"{SIDECAR_URL}{REGISTER_PATH}",
        headers=headers,
        json={
            "userId": user_id,
            "tenantId": tenant_id,
            "challenge": challenge,
            "credentialId": f"wa-cred-{uuid.uuid4().hex[:8]}",
            "publicKeyPem": kp.public_key_pem,
        },
    )
    assert r.status_code == 201, f"register POST failed: {r.status_code} {r.text}"
    return kp.public_key_pem


def _unique_tenant(label: str) -> str:
    return f"py-wa-{label}-{uuid.uuid4().hex[:8]}"


# ---------------------------------------------------------------------------
# Test 1: WebAuthnAttestor round-trip -- token accepted by server
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_webauthn_token_accepted_by_live_sidecar() -> None:
    """A Python-built v4att.webauthn token is accepted by the server's
    verifyWebAuthnAttestation path. This is the slice-3 parity proof:
    same wire format as TS WebAuthnAttestor, server accepts both.
    """
    tenant = _unique_tenant("rt")
    user = f"alice@{tenant}.test"

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        # Simulate browser-supplied signature bytes. Slice 3 does not
        # verify these cryptographically (filed F-NEW-CRIT-39e-2-WEBAUTHN-
        # FULL-VERIFY). We pass non-empty placeholder bytes which is what
        # a real authenticator would produce.
        return WebAuthnAssertion(credential_id=f"cred-{uuid.uuid4().hex[:8]}",
                                  signature=b"a" * 64)

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id=user,
        credential_id="cred-stable",
        assertion_callback=cb,
    )

    async with httpx.AsyncClient(timeout=5.0) as c:
        await _register_webauthn_user(c, user_id=user, tenant_id=tenant)

        ctx = AttestationContext(
            tenant_id=tenant,
            action="wa_tool",
            nonce=f"n-wa-{uuid.uuid4().hex}",
            request_hash=compute_request_hash("wa_tool", "{}", "test-agent"),
            user_id=user,
        )
        signed = await attestor.sign(ctx)

        assert signed.token.startswith(WEBAUTHN_TOKEN_PREFIX), \
            f"token must be v4att.webauthn.; got prefix {signed.token[:25]!r}"

        r = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": signed.token},
            json={
                "toolName": "wa_tool",
                "agent": {"name": "test-agent", "orgId": tenant},
                "input": {},
                "userId": user,
            },
        )

    assert r.status_code == 200, (
        f"WebAuthn token rejected by server -- status={r.status_code} "
        f"body={r.text}. This indicates the Python WebAuthnAttestor's "
        f"v4att.webauthn wire format has drifted from the server's "
        f"parseWebAuthnAttestationToken at "
        f"packages/governance-server/src/end-user-attestation.ts:558."
    )
    body = r.json()
    assert "decision" in body, f"unexpected response body: {body}"
    assert "auditId" in body, \
        f"no auditId -- WebAuthn attestation may have failed early: {body}"


# ---------------------------------------------------------------------------
# Test 2: wrong-action -- 401 action-mismatch
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_webauthn_action_mismatch_rejected() -> None:
    """The server compares ``claims.action`` to ``toolName`` and rejects
    on mismatch. Sign for action='read_only', send check-action with
    toolName='delete_database' -> 401 action-mismatch.
    """
    tenant = _unique_tenant("act")
    user = f"alice@{tenant}.test"

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="c", signature=b"\x42" * 32)

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id=user,
        credential_id="c",
        assertion_callback=cb,
    )

    async with httpx.AsyncClient(timeout=5.0) as c:
        await _register_webauthn_user(c, user_id=user, tenant_id=tenant)

        # Sign for a DIFFERENT action than what we'll send to check-action
        ctx = AttestationContext(
            tenant_id=tenant,
            action="read_only",
            nonce=f"n-act-{uuid.uuid4().hex}",
            request_hash=compute_request_hash("read_only", "{}", "test-agent"),
        )
        signed = await attestor.sign(ctx)

        r = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": signed.token},
            json={
                "toolName": "delete_database",  # mismatched
                "agent": {"name": "test-agent", "orgId": tenant},
                "input": {},
                "userId": user,
            },
        )

    assert r.status_code == 401, \
        f"expected 401 action-mismatch; got {r.status_code} {r.text}"
    body = r.json()
    assert body.get("error") == "attestation-failed"
    assert body.get("reason") == "action-mismatch", \
        f"expected reason='action-mismatch'; got {body.get('reason')}"


# ---------------------------------------------------------------------------
# Test 3: WebAuthn replay -- jti rejected on second use
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_webauthn_replay_rejected_with_token_replayed_reason() -> None:
    """First use of a WebAuthn token succeeds; replayed jti gets
    rejected. This proves the server's jti-replay set (end-user-
    attestation.ts:642) is engaged for the WebAuthn path.
    """
    tenant = _unique_tenant("rep")
    user = f"alice@{tenant}.test"

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="cred-replay", signature=b"\x99" * 48)

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id=user,
        credential_id="cred-replay",
        assertion_callback=cb,
    )

    async with httpx.AsyncClient(timeout=5.0) as c:
        await _register_webauthn_user(c, user_id=user, tenant_id=tenant)

        ctx = AttestationContext(
            tenant_id=tenant,
            action="replay_tool",
            nonce=f"n-rep-{uuid.uuid4().hex}",
            request_hash=compute_request_hash("replay_tool", "{}", "test-agent"),
        )
        signed = await attestor.sign(ctx)

        body = {
            "toolName": "replay_tool",
            "agent": {"name": "test-agent", "orgId": tenant},
            "input": {},
            "userId": user,
        }

        first = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": signed.token},
            json=body,
        )
        assert first.status_code == 200, f"first use must succeed; got {first.status_code} {first.text}"

        # Replay the SAME token a second time
        second = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": signed.token},
            json=body,
        )

    assert second.status_code == 401, \
        f"replayed WebAuthn token must be rejected; got {second.status_code} {second.text}"
    body2 = second.json()
    assert body2.get("error") == "attestation-failed"
    assert body2.get("reason") == "token-replayed", \
        f"expected reason='token-replayed'; got {body2.get('reason')}"


# ---------------------------------------------------------------------------
# Test 4: Client-level wiring -- AsyncGovernanceClient(attestor=WebAuthnAttestor)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_client_with_webauthn_attestor_end_to_end() -> None:
    """AsyncGovernanceClient + WebAuthnAttestor -- check_action attaches
    the v4att.webauthn token to body + header and the server accepts.
    This is the customer-facing wiring proof for slice 4 (client) +
    slice 3 (WebAuthnAttestor) together.
    """
    from connexum_governance.client import AsyncGovernanceClient
    from connexum_governance.models import AgentIdentity

    tenant = _unique_tenant("wire")
    user = f"alice@{tenant}.test"

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="cred-wire", signature=b"\x77" * 64)

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id=user,
        credential_id="cred-wire",
        assertion_callback=cb,
    )

    # Register user out-of-band
    async with httpx.AsyncClient(timeout=5.0) as bootstrap:
        await _register_webauthn_user(bootstrap, user_id=user, tenant_id=tenant)

    client = AsyncGovernanceClient(
        api_url=SIDECAR_URL,
        license_key=_mint_admin_jwt(user, tenant),
        org_id=tenant,
        attestor=attestor,
        on_failure="closed",
        enforce=False,
    )
    try:
        decision = await client.check_action(
            tool="wire_tool",
            input={},
            # NOTE: agent.org_id MUST equal client.org_id for the server's
            # WebAuthn audience check. The server reads tenant from
            # agent.orgId first, falling back to cfg.reporterOrgId. The
            # Python client does not (currently) backfill agent.org_id from
            # the client-level org_id automatically -- the caller passes
            # it explicitly. See server index.ts:1502.
            agent=AgentIdentity(name="test-agent", role="researcher", org_id=tenant),
            user_id=user,
        )
    finally:
        await client.close()

    # The server's pack-evaluation may DENY by default; we only care
    # that the attestation layer accepted the WebAuthn token (i.e. the
    # decision dict was returned at all, not a 401 raise).
    assert decision is not None
    assert decision.audit_id, f"no audit_id -- server may have rejected attestation: {decision}"
