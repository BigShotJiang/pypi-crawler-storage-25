"""
F-NEW-CRIT-39e-2-PY slice 1 -- SoftwareKeyAttestor live integration tests.

These tests exercise the Python ``SoftwareKeyAttestor`` against a live
governance-sidecar at ``http://127.0.0.1:4200``. They are NOT mocks --
the sidecar must be running. Bring it up via:

    cd /root/sample-customer-env/governance-sidecar
    bash start-sidecar.sh

Each test registers a fresh public key via the admin endpoint
``POST /api/v1/admin/attestation/keys/register`` (authenticated with a
minted JWT -- ``decodeClaims`` does not verify the signature, only
shape -- which is acceptable for an in-memory testbed sidecar) and
then sends a ``POST /api/v1/governance/check-action`` with the signed
attestation token in the ``X-Attestation-Token`` header.

The server returns:

  * ``200`` with a body decision (``ALLOW`` / ``DENY`` / ``REQUIRE_APPROVAL``)
    when attestation passed. The decision itself depends on the
    sidecar's pack policy. For the testbed config (DEFAULT_DENY=true,
    no packs activated for the test tool name) the decision is always
    ``DENY``. That is the SUCCESS path for these tests -- we are
    asserting the attestation layer accepted the token.
  * ``401`` with body ``{error: 'attestation-failed', reason: '<code>'}``
    when attestation failed.

Cross-SDK contract: test 7 builds an equivalent token via Node's
``node:crypto`` (the same primitive ``crypto.sign(null, payloadBytes, key)``
used by ``packages/typescript-sdk/src/attestation.ts:195``) and
submits it to the same sidecar with the same registered key. If both
the Python-built and TS-equivalent tokens verify, the wire formats
are byte-identical at the security-critical layer.

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 1
"""

from __future__ import annotations

import asyncio
import base64
import importlib
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
import warnings
from datetime import datetime, timedelta, timezone
from typing import Tuple

import httpx
import pytest

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from connexum_governance.attestor import (
    AttestationContext,
    AttestorError,
    EndUserAttestor,
    SignedAttestation,
)
from connexum_governance.testing import (
    SoftwareKeyAttestor,
    build_attestation_token,
    compute_request_hash,
    generate_software_key,
)


# ---------------------------------------------------------------------------
# Sidecar config
# ---------------------------------------------------------------------------

SIDECAR_URL = os.environ.get("CONNEXUM_TESTBED_URL", "http://127.0.0.1:4200")
HEALTH_PATH = "/api/v1/health"
CHALLENGE_PATH = "/api/v1/admin/attestation/keys/challenge"
REGISTER_PATH = "/api/v1/admin/attestation/keys/register"
CHECK_ACTION_PATH = "/api/v1/governance/check-action"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _b64url_no_pad(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _mint_admin_jwt(sub: str, org: str) -> str:
    """Mint an unsigned JWT with ``role=ORG_ADMIN``.

    The server's ``decodeClaims`` helper at
    ``packages/governance-server/src/auth-helpers.ts:33-58``
    intentionally does NOT verify the signature -- it only base64
    decodes the payload and checks ``sub`` / ``org`` / ``role`` are
    present. Production endpoints sit behind an upstream auth layer
    that does verify; for the testbed sidecar this minted token is
    sufficient and is what the existing TS tests use.
    """
    header = _b64url_no_pad(
        json.dumps({"alg": "none", "typ": "JWT"}, separators=(",", ":")).encode()
    )
    payload = _b64url_no_pad(
        json.dumps(
            {"sub": sub, "org": org, "role": "ORG_ADMIN",
             "iat": 0, "exp": 9_999_999_999},
            separators=(",", ":"),
        ).encode()
    )
    return f"{header}.{payload}.fakesig"


def _is_sidecar_up() -> bool:
    try:
        r = httpx.get(f"{SIDECAR_URL}{HEALTH_PATH}", timeout=3.0)
        return r.status_code == 200
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(
    not _is_sidecar_up(),
    reason=(
        "F-NEW-CRIT-39e-2-PY slice 1 tests require the testbed "
        f"governance-sidecar running at {SIDECAR_URL}. "
        "Start it via /root/sample-customer-env/governance-sidecar/start-sidecar.sh."
    ),
)


async def _register_key(
    client: httpx.AsyncClient,
    *,
    user_id: str,
    tenant_id: str,
    public_key_pem: str,
    credential_id: str = "test-cred",
) -> None:
    """Register a public key against the live sidecar.

    Uses the admin JWT path (challenge -> register).
    """
    admin_jwt = _mint_admin_jwt(f"admin@{tenant_id}", tenant_id)
    headers = {"Authorization": f"Bearer {admin_jwt}"}

    # Step 1: get a challenge
    r = await client.post(
        f"{SIDECAR_URL}{CHALLENGE_PATH}",
        headers=headers,
        json={"userId": user_id, "tenantId": tenant_id},
    )
    assert r.status_code == 200, f"challenge POST failed: {r.status_code} {r.text}"
    challenge = r.json()["challenge"]

    # Step 2: register the key
    r = await client.post(
        f"{SIDECAR_URL}{REGISTER_PATH}",
        headers=headers,
        json={
            "userId": user_id,
            "tenantId": tenant_id,
            "challenge": challenge,
            "credentialId": credential_id,
            "publicKeyPem": public_key_pem,
        },
    )
    assert r.status_code == 201, f"register POST failed: {r.status_code} {r.text}"


def _unique_tenant(label: str) -> str:
    """Generate a unique tenant id per test case to avoid cross-test
    contamination on the in-memory key store / replay cache."""
    return f"py-slice1-{label}-{uuid.uuid4().hex[:8]}"


# ---------------------------------------------------------------------------
# Test 1: sign happy path -- token shape and claim decoding
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_sign_returns_v4att_token_with_canonical_claim_shape() -> None:
    """The token must start with ``v4att.``, split into 3 segments,
    and decode to the exact claim schema mirrored from
    ``packages/typescript-sdk/src/attestation.ts:155-167``.
    """

    kp = generate_software_key()
    sub = "alice@happy-path.test"
    attestor = SoftwareKeyAttestor(kp.private_key, sub, ttl_seconds=60)

    ctx = AttestationContext(
        tenant_id="tenant-happy",
        action="example_tool",
        nonce="n-happy-001",
        request_hash=compute_request_hash("example_tool", "{}", "test-agent"),
        user_id=sub,
    )

    signed = await attestor.sign(ctx)

    assert signed.token.startswith("v4att."), \
        f"Token must use v4att. prefix; got {signed.token[:20]!r}"
    parts = signed.token.split(".")
    assert len(parts) == 3, f"Token must have 3 dot-separated segments; got {len(parts)}"
    assert parts[0] == "v4att"

    # Decode the payload and assert exact field set
    # (no iss, no agentId, no toolName -- per F-NEW-CRIT-39e-2-PY spec)
    payload_b64 = parts[1]
    # Re-pad for stdlib base64
    pad = "=" * (-len(payload_b64) % 4)
    claims = json.loads(base64.urlsafe_b64decode(payload_b64 + pad).decode("utf-8"))

    assert claims["sub"] == sub
    assert claims["aud"] == "tenant-happy"
    assert claims["tenantId"] == "tenant-happy"
    assert claims["action"] == "example_tool"
    assert claims["nonce"] == "n-happy-001"
    assert "requestHash" in claims
    assert "iat" in claims and claims["iat"].endswith("Z")
    assert "exp" in claims and claims["exp"].endswith("Z")
    assert "jti" in claims and len(claims["jti"]) == 36  # UUID v4

    # Forbidden fields per spec
    assert "iss" not in claims, "spec forbids iss claim"
    assert "agentId" not in claims, "spec forbids agentId claim"
    assert "toolName" not in claims, "spec forbids toolName claim"

    # SignedAttestation surface
    assert signed.sub == sub
    assert signed.jti == claims["jti"]
    assert isinstance(signed.exp, int) and signed.exp > 0


# ---------------------------------------------------------------------------
# Test 2: round-trip with sidecar (the parity proof)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_round_trip_with_live_sidecar_returns_200() -> None:
    """Register key, sign token, send check-action -- sidecar must
    return 200. The decision body may be DENY for default-deny pack
    policy reasons; the success criterion is HTTP 200 (attestation
    accepted), not 401 (attestation rejected).
    """

    tenant = _unique_tenant("rt")
    sub = f"alice@{tenant}.test"
    kp = generate_software_key()
    attestor = SoftwareKeyAttestor(kp.private_key, sub, ttl_seconds=60)

    async with httpx.AsyncClient(timeout=5.0) as c:
        await _register_key(c, user_id=sub, tenant_id=tenant,
                            public_key_pem=kp.public_key_pem)

        ctx = AttestationContext(
            tenant_id=tenant,
            action="rt_tool",
            nonce=f"n-rt-{uuid.uuid4().hex[:8]}",
            request_hash=compute_request_hash("rt_tool", "{}", "test-agent"),
            user_id=sub,
        )
        signed = await attestor.sign(ctx)

        r = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": signed.token},
            json={
                "toolName": "rt_tool",
                "agent": {"name": "test-agent", "orgId": tenant},
                "input": {},
                "userId": sub,
            },
        )

    # Attestation must have passed -- a 401 here means the wire format
    # broke, the signature did not verify, or some other parity bug.
    assert r.status_code == 200, (
        f"Round-trip FAILED -- sidecar returned {r.status_code}. "
        f"Body: {r.text}. "
        f"This indicates a wire-format mismatch between Python "
        f"SoftwareKeyAttestor and the server's verifyAttestation()."
    )

    body = r.json()
    # Decision is whatever the pack engine decides; we don't assert it.
    # We only care that the token verified.
    assert "decision" in body, f"unexpected response body: {body}"
    # Audit id implies the request reached pack evaluation -- proof
    # the attestation layer did not short-circuit with 401.
    assert "auditId" in body, f"no auditId in response -- attestation may have failed early: {body}"


# ---------------------------------------------------------------------------
# Test 3: expired token -- 401 with reason: 'expired'
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_expired_token_rejected_with_expired_reason() -> None:
    """ttl=1, sleep > 1s, send -> 401 with reason='expired'."""

    tenant = _unique_tenant("exp")
    sub = f"alice@{tenant}.test"
    kp = generate_software_key()
    attestor = SoftwareKeyAttestor(kp.private_key, sub, ttl_seconds=1)

    async with httpx.AsyncClient(timeout=5.0) as c:
        await _register_key(c, user_id=sub, tenant_id=tenant,
                            public_key_pem=kp.public_key_pem)

        signed = await attestor.sign(AttestationContext(
            tenant_id=tenant, action="exp_tool",
            nonce="n-exp-1",
            request_hash=compute_request_hash("exp_tool", "{}", "test-agent"),
        ))

        # Wait past expiry. Server clock skew tolerance is 30s by default
        # but exp itself is enforced strictly (expMs < nowMs).
        await asyncio.sleep(2.5)

        r = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": signed.token},
            json={
                "toolName": "exp_tool",
                "agent": {"name": "test-agent", "orgId": tenant},
                "input": {},
                "userId": sub,
            },
        )

    assert r.status_code == 401, f"expected 401 expired; got {r.status_code} {r.text}"
    body = r.json()
    assert body.get("error") == "attestation-failed"
    assert body.get("reason") == "expired", \
        f"expected reason='expired'; got {body.get('reason')}"


# ---------------------------------------------------------------------------
# Test 4: wrong audience -- sign with aud=org-a, send to org-b
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_wrong_audience_rejected_with_wrong_audience_reason() -> None:
    """Sign for tenant A, send check-action with agent.orgId=tenant B
    -> 401 with reason='wrong-audience'.
    """

    tenant_target = _unique_tenant("audA")
    tenant_other = _unique_tenant("audB")
    sub = f"alice@{tenant_target}.test"
    kp = generate_software_key()

    # Register against tenant_target so the unknown-user check passes
    # before audience check would fire (server checks aud BEFORE key
    # lookup, so this also works if no key were registered, but having
    # a key makes the test more focused on the aud claim itself).
    async with httpx.AsyncClient(timeout=5.0) as c:
        await _register_key(c, user_id=sub, tenant_id=tenant_target,
                            public_key_pem=kp.public_key_pem)

        # Sign with aud = tenant_other -- WRONG audience
        attestor = SoftwareKeyAttestor(kp.private_key, sub, ttl_seconds=60)
        signed = await attestor.sign(AttestationContext(
            tenant_id=tenant_other,  # NOT tenant_target
            action="aud_tool",
            nonce="n-aud-1",
            request_hash=compute_request_hash("aud_tool", "{}", "test-agent"),
        ))

        # Send check-action targeting tenant_target -- the body's
        # agent.orgId is what server uses as expectedTenantId
        r = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": signed.token},
            json={
                "toolName": "aud_tool",
                "agent": {"name": "test-agent", "orgId": tenant_target},
                "input": {},
                "userId": sub,
            },
        )

    assert r.status_code == 401, f"expected 401 wrong-audience; got {r.status_code} {r.text}"
    body = r.json()
    assert body.get("error") == "attestation-failed"
    assert body.get("reason") == "wrong-audience", \
        f"expected reason='wrong-audience'; got {body.get('reason')}"


# ---------------------------------------------------------------------------
# Test 5: mutated signature -- 401 with reason: 'invalid-signature'
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_mutated_signature_rejected_with_invalid_signature_reason() -> None:
    """Flip the first character of the signature segment (still
    base64-valid) -> 401 with reason='invalid-signature'.

    Mutating the payload segment instead would more likely produce
    'malformed' (broken JSON) before the signature even gets checked,
    which would not exercise the Ed25519 verify path. We mutate the
    signature so the payload still parses but verify fails.
    """

    tenant = _unique_tenant("muts")
    sub = f"alice@{tenant}.test"
    kp = generate_software_key()
    attestor = SoftwareKeyAttestor(kp.private_key, sub, ttl_seconds=60)

    async with httpx.AsyncClient(timeout=5.0) as c:
        await _register_key(c, user_id=sub, tenant_id=tenant,
                            public_key_pem=kp.public_key_pem)

        signed = await attestor.sign(AttestationContext(
            tenant_id=tenant, action="mut_tool",
            nonce="n-mut-1",
            request_hash=compute_request_hash("mut_tool", "{}", "test-agent"),
        ))

        # Split the v4att.<payload>.<sig> token into segments
        prefix, rest = signed.token.split(".", 1)
        payload_b64, sig_b64 = rest.rsplit(".", 1)

        # Flip first char of signature (keep base64 validity)
        flipped = ("A" if sig_b64[0] != "A" else "B") + sig_b64[1:]
        mutated_token = f"{prefix}.{payload_b64}.{flipped}"

        r = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": mutated_token},
            json={
                "toolName": "mut_tool",
                "agent": {"name": "test-agent", "orgId": tenant},
                "input": {},
                "userId": sub,
            },
        )

    assert r.status_code == 401, f"expected 401 invalid-signature; got {r.status_code} {r.text}"
    body = r.json()
    assert body.get("error") == "attestation-failed"
    assert body.get("reason") == "invalid-signature", \
        f"expected reason='invalid-signature'; got {body.get('reason')}"


# ---------------------------------------------------------------------------
# Test 6: production-import guard
# ---------------------------------------------------------------------------


def test_production_import_emits_deprecation_warning_when_prod_env_set(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``CONNEXUM_PROD=1`` causes a DeprecationWarning at import time
    of ``connexum_governance.testing``. Without the env var, the
    warning is suppressed. Both cases must allow the import to
    succeed (the boundary is informational, not blocking).

    We test both via warnings.catch_warnings and a fresh module
    re-import to bypass the cached import in this test process.
    """

    # Clear any cached module references so the import code runs again
    for mod_name in list(sys.modules.keys()):
        if mod_name.startswith("connexum_governance.testing"):
            del sys.modules[mod_name]

    # CASE A: no env var -- import works silently
    monkeypatch.delenv("CONNEXUM_PROD", raising=False)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        importlib.import_module("connexum_governance.testing")
    prod_warnings = [
        x for x in w
        if issubclass(x.category, DeprecationWarning)
        and "connexum_governance.testing" in str(x.message)
    ]
    assert prod_warnings == [], \
        "no DeprecationWarning expected when CONNEXUM_PROD is unset"

    # Reset for CASE B
    for mod_name in list(sys.modules.keys()):
        if mod_name.startswith("connexum_governance.testing"):
            del sys.modules[mod_name]

    # CASE B: env var set -- import emits DeprecationWarning
    monkeypatch.setenv("CONNEXUM_PROD", "1")
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        importlib.import_module("connexum_governance.testing")
    prod_warnings = [
        x for x in w
        if issubclass(x.category, DeprecationWarning)
        and "connexum_governance.testing" in str(x.message)
    ]
    assert len(prod_warnings) >= 1, (
        "expected at least one DeprecationWarning when CONNEXUM_PROD=1; "
        f"got: {[str(x.message) for x in w]}"
    )

    # Restore for the rest of the test session
    monkeypatch.delenv("CONNEXUM_PROD", raising=False)
    for mod_name in list(sys.modules.keys()):
        if mod_name.startswith("connexum_governance.testing"):
            del sys.modules[mod_name]
    importlib.import_module("connexum_governance.testing")


# ---------------------------------------------------------------------------
# Test 7: cross-SDK contract -- TS-built token verifies against the
# same server middleware as Python-built tokens.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cross_sdk_contract_ts_signed_token_verifies() -> None:
    """The definitive Python<->TS parity proof.

    We build an equivalent token via Node ``crypto.sign(null,
    payloadBytes, privateKey)`` -- the exact primitive the TS SDK uses
    at ``packages/typescript-sdk/src/attestation.ts:195``. Then we
    submit it to the live sidecar with a key registered via the Python
    SDK's ``generate_software_key()`` PEM. If both token sources
    verify against the same registered key on the same server, the
    Python wire format is byte-equivalent to TS at the
    security-critical layer.

    Skipped if Node is unavailable on the test host.
    """

    # Skip if node is missing (rare on the testbed but be safe)
    try:
        subprocess.check_output(["node", "--version"], stderr=subprocess.DEVNULL)
    except (FileNotFoundError, subprocess.CalledProcessError):
        pytest.skip("node binary not available on this host")

    tenant = _unique_tenant("xs")
    sub = f"alice@{tenant}.test"

    # Generate key with the SAME helper a customer would use (Python)
    kp = generate_software_key()

    # Build a TS-equivalent token by spawning Node
    priv_pem_node = kp.private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("ascii")

    now = datetime.now(timezone.utc)
    exp_dt = now + timedelta(seconds=60)

    def _iso_z(dt: datetime) -> str:
        return dt.strftime("%Y-%m-%dT%H:%M:%S") + f".{dt.microsecond // 1000:03d}Z"

    # NB: claim insertion order mirrors the TS SoftwareKeyAttestor
    # in packages/typescript-sdk/src/testing/attestation-helpers.ts:130-141.
    claims = {
        "sub": sub,
        "iat": _iso_z(now),
        "exp": _iso_z(exp_dt),
        "jti": str(uuid.uuid4()),
        "aud": tenant,
        "tenantId": tenant,
        "nonce": "xs-nonce-1",
        "action": "xs_tool",
        "requestHash": compute_request_hash("xs_tool", "{}", "test-agent"),
    }

    node_script = (
        "const crypto = require('node:crypto');\n"
        "const fs = require('node:fs');\n"
        "const { privPem, claims } = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));\n"
        "const payloadJson = JSON.stringify(claims);\n"
        "const payloadBytes = Buffer.from(payloadJson, 'utf-8');\n"
        "const payloadB64 = payloadBytes.toString('base64url');\n"
        "const privateKey = crypto.createPrivateKey(privPem);\n"
        "const sig = crypto.sign(null, payloadBytes, privateKey);\n"
        "const sigB64 = sig.toString('base64url');\n"
        "process.stdout.write(`v4att.${payloadB64}.${sigB64}`);\n"
    )

    with tempfile.NamedTemporaryFile(
        "w", suffix=".json", delete=False
    ) as input_file:
        json.dump({"privPem": priv_pem_node, "claims": claims}, input_file)
        input_path = input_file.name
    with tempfile.NamedTemporaryFile(
        "w", suffix=".cjs", delete=False
    ) as script_file:
        script_file.write(node_script)
        script_path = script_file.name

    try:
        ts_token = subprocess.check_output(
            ["node", script_path, input_path],
            stderr=subprocess.PIPE,
        ).decode("ascii")
    finally:
        os.unlink(input_path)
        os.unlink(script_path)

    assert ts_token.startswith("v4att."), \
        f"node-built token must use v4att. prefix; got {ts_token[:20]!r}"

    # Also build a Python-side token with identical claims for direct
    # byte comparison of the (deterministic) payload portion.
    py_token = build_attestation_token(claims, kp.private_key)
    assert py_token.startswith("v4att.")
    py_payload = py_token.split(".")[1]
    ts_payload = ts_token.split(".")[1]
    assert py_payload == ts_payload, (
        "Python and TS payload base64 must be byte-identical for "
        "cross-SDK contract; payload-byte mismatch indicates dict/JSON "
        "ordering drift. "
        f"py={py_payload[:60]}... ts={ts_payload[:60]}..."
    )

    # Now ship the TS-built token to the live sidecar with the
    # Python-registered key
    async with httpx.AsyncClient(timeout=5.0) as c:
        await _register_key(c, user_id=sub, tenant_id=tenant,
                            public_key_pem=kp.public_key_pem)

        r = await c.post(
            f"{SIDECAR_URL}{CHECK_ACTION_PATH}",
            headers={"X-Attestation-Token": ts_token},
            json={
                "toolName": "xs_tool",
                "agent": {"name": "test-agent", "orgId": tenant},
                "input": {},
                "userId": sub,
            },
        )

    assert r.status_code == 200, (
        f"CROSS-SDK CONTRACT FAILED -- TS-equivalent token rejected by "
        f"server. status={r.status_code} body={r.text}. "
        f"This indicates the Python SoftwareKeyAttestor's wire format "
        f"has drifted from packages/typescript-sdk/src/attestation.ts."
    )
