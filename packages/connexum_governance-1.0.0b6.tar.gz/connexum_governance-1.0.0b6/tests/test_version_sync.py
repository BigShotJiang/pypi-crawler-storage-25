"""
F-NEW-MED-11: enforce that pyproject.toml `version` and
connexum_governance/__init__.py `__version__` stay in sync. Diverging
versions cause PyPI publication confusion (the wheel ships one version
while runtime introspection reports another).
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

import connexum_governance


PYPROJECT = Path(__file__).resolve().parent.parent / "pyproject.toml"


def _pyproject_version() -> str:
    text = PYPROJECT.read_text(encoding="utf-8")
    # Match the [project] section's `version = "..."` (not [tool.*].version)
    in_project = False
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("[project]"):
            in_project = True
            continue
        if stripped.startswith("[") and not stripped.startswith("[project."):
            in_project = False
        if in_project:
            m = re.match(r'version\s*=\s*"([^"]+)"', stripped)
            if m:
                return m.group(1)
    raise RuntimeError("Could not find [project].version in pyproject.toml")


def test_pyproject_version_matches_module_version() -> None:
    py_version = _pyproject_version()
    mod_version = connexum_governance.__version__
    assert py_version == mod_version, (
        f"Version drift detected. "
        f"pyproject.toml = {py_version}; connexum_governance.__version__ = {mod_version}. "
        f"Update both before tagging a release."
    )


def test_version_is_pep440_compliant() -> None:
    """Sanity check that the version string is parseable per PEP 440."""
    from packaging.version import Version, InvalidVersion  # type: ignore[import-not-found]

    try:
        Version(connexum_governance.__version__)
    except InvalidVersion as exc:  # pragma: no cover -- bad version is rare
        pytest.fail(f"__version__ {connexum_governance.__version__!r} is not PEP 440 compliant: {exc}")
    except ImportError:
        # packaging may not be installed in minimal envs; fall back to a
        # loose check for the b<N> beta marker we use today.
        v = connexum_governance.__version__
        assert re.match(r"^\d+\.\d+\.\d+(b\d+|rc\d+|a\d+)?$", v), \
            f"__version__ {v!r} not in expected M.N.P[b/rc/a]<digit>* shape"
