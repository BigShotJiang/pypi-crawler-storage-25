"""Tests for GovernanceClient and AsyncGovernanceClient."""

import httpx
import pytest

from connexum_governance import (
    GovernanceClient,
    AsyncGovernanceClient,
    GovernanceDecision,
    GovernanceViolation,
    AgentIdentity,
    TaskContext,
    PlanContext,
    DelegationContext,
)
from connexum_governance.models import DecisionType, PlanStep
from tests.conftest import make_client, make_async_client


class TestGovernanceClient:
    """Synchronous client tests."""

    def test_check_action_allow(self, allow_transport):
        client = make_client(allow_transport)
        decision = client.check_action(
            tool="Bash",
            input={"command": "ls"},
            agent=AgentIdentity(name="test-agent"),
        )
        assert decision.allowed
        assert decision.audit_id == "aud-001"

    def test_check_action_deny_raises(self, deny_transport):
        client = make_client(deny_transport, enforce=True)
        with pytest.raises(GovernanceViolation) as exc_info:
            client.check_action(
                tool="Bash",
                input={"command": "rm -rf /"},
                agent=AgentIdentity(name="test-agent"),
            )
        assert "Tool blocked by policy" in str(exc_info.value)
        assert exc_info.value.decision.audit_id == "aud-002"

    def test_check_action_deny_no_enforce(self, deny_transport):
        client = make_client(deny_transport, enforce=False)
        decision = client.check_action(
            tool="Bash",
            input={"command": "rm -rf /"},
            agent=AgentIdentity(name="test-agent"),
        )
        assert decision.denied
        assert not decision.allowed

    def test_check_action_with_dict_agent(self, allow_transport):
        client = make_client(allow_transport)
        decision = client.check_action(
            tool="Write",
            input={"path": "/tmp/test.txt"},
            agent={"name": "dict-agent", "role": "writer"},
        )
        assert decision.allowed

    def test_check_action_require_approval(self, approval_transport):
        client = make_client(approval_transport)
        decision = client.check_action(
            tool="Deploy",
            input={"env": "production"},
            agent=AgentIdentity(name="deploy-agent"),
        )
        assert decision.requires_approval
        assert not decision.allowed
        assert not decision.denied

    def test_report_result(self, allow_transport):
        client = make_client(allow_transport)
        # Should not raise
        client.report_result(
            audit_id="aud-001",
            success=True,
            summary="Command completed",
            duration_ms=42,
        )

    def test_report_result_with_error(self, allow_transport):
        client = make_client(allow_transport)
        client.report_result(
            audit_id="aud-001",
            success=False,
            error="Permission denied",
        )

    def test_check_task(self, allow_transport):
        client = make_client(allow_transport)
        task = TaskContext(
            task_id="t-001",
            task_type="analysis",
            description="Analyze dataset",
            agent=AgentIdentity(name="analyst"),
            pack_binding=["soc2"],
        )
        decision = client.check_task(task)
        assert decision.allowed

    def test_check_task_denied(self, deny_transport):
        client = make_client(deny_transport, enforce=True)
        task = TaskContext(
            task_id="t-002",
            task_type="deploy",
            description="Deploy to prod",
            agent=AgentIdentity(name="deployer"),
            pack_binding=["soc2"],
        )
        with pytest.raises(GovernanceViolation):
            client.check_task(task)

    def test_check_plan(self, allow_transport):
        client = make_client(allow_transport)
        plan = PlanContext(
            plan_id="p-001",
            objective="Research and report",
            steps=[
                PlanStep(step_id="s1", action="search"),
                PlanStep(step_id="s2", action="summarize", dependencies=["s1"]),
            ],
            creator=AgentIdentity(name="planner"),
        )
        decision = client.check_plan(plan)
        assert decision.allowed

    def test_check_delegation(self, allow_transport):
        client = make_client(allow_transport)
        delegation = DelegationContext(
            delegation_id="d-001",
            from_agent=AgentIdentity(name="manager"),
            to_agent=AgentIdentity(name="worker"),
            task="file cleanup",
            permissions=["read", "write"],
            pack_binding=["soc2"],
        )
        decision = client.check_delegation(delegation)
        assert decision.allowed

    def test_check_delegation_denied(self, deny_transport):
        client = make_client(deny_transport, enforce=True)
        delegation = DelegationContext(
            delegation_id="d-002",
            from_agent=AgentIdentity(name="intern"),
            to_agent=AgentIdentity(name="external"),
            task="access production",
            permissions=["admin"],
            pack_binding=["soc2"],
        )
        with pytest.raises(GovernanceViolation):
            client.check_delegation(delegation)

    def test_health(self, allow_transport):
        client = make_client(allow_transport)
        result = client.health()
        assert result["status"] == "healthy"

    def test_context_manager(self, allow_transport):
        with make_client(allow_transport) as client:
            decision = client.check_action(
                tool="Read",
                input={"path": "/tmp/test"},
                agent=AgentIdentity(name="reader"),
            )
            assert decision.allowed

    def test_headers(self, allow_transport):
        client = GovernanceClient(
            api_url="http://test-server/",
            license_key="my-secret-key",
            installation_id="inst-123",
        )
        headers = client._client.headers
        assert headers["authorization"] == "Bearer my-secret-key"
        assert headers["x-installation-id"] == "inst-123"

    def test_url_trailing_slash(self):
        client = GovernanceClient(
            api_url="http://test-server///",
            license_key="key",
        )
        assert client.api_url == "http://test-server"


class TestAsyncGovernanceClient:
    """Async client tests."""

    @pytest.mark.asyncio
    async def test_check_action_allow(self, allow_transport):
        client = make_async_client(allow_transport)
        decision = await client.check_action(
            tool="Bash",
            input={"command": "ls"},
            agent=AgentIdentity(name="async-agent"),
        )
        assert decision.allowed

    @pytest.mark.asyncio
    async def test_check_action_deny_raises(self, deny_transport):
        client = make_async_client(deny_transport, enforce=True)
        with pytest.raises(GovernanceViolation):
            await client.check_action(
                tool="Bash",
                input={"command": "rm -rf /"},
                agent=AgentIdentity(name="async-agent"),
            )

    @pytest.mark.asyncio
    async def test_async_context_manager(self, allow_transport):
        async with make_async_client(allow_transport) as client:
            decision = await client.check_action(
                tool="Read",
                input={"path": "/tmp"},
                agent=AgentIdentity(name="reader"),
            )
            assert decision.allowed

    @pytest.mark.asyncio
    async def test_async_health(self, allow_transport):
        client = make_async_client(allow_transport)
        result = await client.health()
        assert result["status"] == "healthy"

    @pytest.mark.asyncio
    async def test_async_report_result(self, allow_transport):
        client = make_async_client(allow_transport)
        await client.report_result(
            audit_id="aud-001",
            success=True,
            summary="Done",
        )


class TestFailOpenPolicy:
    """Tests for on_failure='open' and on_failure='closed' behavior."""

    def test_fail_open_returns_allow_on_unreachable(self):
        """When on_failure='open' and the server is unreachable, check_action
        should return a permissive ALLOW decision instead of raising."""
        client = GovernanceClient(
            api_url="http://localhost:1",
            license_key="test-key",
            timeout=0.1,
            on_failure="open",
        )
        decision = client.check_action(
            tool="Bash",
            input={"command": "ls"},
            agent=AgentIdentity(name="test-agent"),
        )
        assert decision.allowed
        assert decision.reason == "Governance server unreachable. Fail-open policy applied."
        assert decision.metadata is not None
        assert decision.metadata["failOpen"] is True
        assert "error" in decision.metadata

    def test_fail_closed_raises_on_unreachable(self):
        """When on_failure='closed' (default) and the server is unreachable,
        check_action should raise an exception."""
        client = GovernanceClient(
            api_url="http://localhost:1",
            license_key="test-key",
            timeout=0.1,
            on_failure="closed",
        )
        with pytest.raises((httpx.ConnectError, httpx.TimeoutException)):
            client.check_action(
                tool="Bash",
                input={"command": "ls"},
                agent=AgentIdentity(name="test-agent"),
            )

    def test_fail_open_report_result_does_not_raise(self):
        """When on_failure='open', report_result should silently return
        instead of raising on connection failure."""
        client = GovernanceClient(
            api_url="http://localhost:1",
            license_key="test-key",
            timeout=0.1,
            on_failure="open",
        )
        # Should not raise
        client.report_result(
            audit_id="aud-001",
            success=True,
            summary="Done",
        )

    def test_default_on_failure_is_closed(self):
        """The default on_failure policy should be 'closed'."""
        client = GovernanceClient(
            api_url="http://localhost:1",
            license_key="test-key",
        )
        assert client.on_failure == "closed"


class TestAsyncFailOpenPolicy:
    """Async tests for on_failure='open' and on_failure='closed' behavior."""

    @pytest.mark.asyncio
    async def test_async_fail_open_returns_allow_on_unreachable(self):
        """Async client with on_failure='open' should return ALLOW
        when the server is unreachable."""
        client = AsyncGovernanceClient(
            api_url="http://localhost:1",
            license_key="test-key",
            timeout=0.1,
            on_failure="open",
        )
        decision = await client.check_action(
            tool="Bash",
            input={"command": "ls"},
            agent=AgentIdentity(name="test-agent"),
        )
        assert decision.allowed
        assert decision.metadata is not None
        assert decision.metadata["failOpen"] is True
        await client.close()

    @pytest.mark.asyncio
    async def test_async_fail_closed_raises_on_unreachable(self):
        """Async client with on_failure='closed' should raise
        when the server is unreachable."""
        client = AsyncGovernanceClient(
            api_url="http://localhost:1",
            license_key="test-key",
            timeout=0.1,
            on_failure="closed",
        )
        with pytest.raises((httpx.ConnectError, httpx.TimeoutException)):
            await client.check_action(
                tool="Bash",
                input={"command": "ls"},
                agent=AgentIdentity(name="test-agent"),
            )
        await client.close()
