"""
F-NEW-CRIT-4: README listed DeepSeek, HuggingFace, Replicate-Llama as
supported but no Python wrapper existed. The fix adds three thin
LLM-provider integrations following the openai/anthropic/gemini
pattern.

This test asserts:
  - All three classes import cleanly from connexum_governance.integrations
  - Each constructor registers provider compliance with BAA: false
  - intercept_request returns a GovernanceDecision shape
  - The provider id surfaces in the gov_input
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from connexum_governance.integrations.deepseek import DeepSeekGovernance
from connexum_governance.integrations.huggingface import HuggingFaceGovernance
from connexum_governance.integrations.replicate import ReplicateGovernance


@pytest.fixture
def gov_client() -> MagicMock:
    c = MagicMock()
    c.check_action.return_value = MagicMock(decision="ALLOW", auditId="aid-test")
    return c


def test_deepseek_imports_and_registers_baa_false(gov_client: MagicMock) -> None:
    DeepSeekGovernance(client=gov_client, agent_name="ds-test")
    gov_client.register_provider_compliance.assert_called_once()
    args, kwargs = gov_client.register_provider_compliance.call_args
    assert kwargs["provider"] == "deepseek"
    assert kwargs["baa_available"] is False


def test_huggingface_imports_and_registers_baa_false(gov_client: MagicMock) -> None:
    HuggingFaceGovernance(client=gov_client, agent_name="hf-test")
    args, kwargs = gov_client.register_provider_compliance.call_args
    assert kwargs["provider"] == "huggingface"
    assert kwargs["baa_available"] is False


def test_replicate_imports_and_registers_baa_false(gov_client: MagicMock) -> None:
    ReplicateGovernance(client=gov_client, agent_name="rep-test")
    args, kwargs = gov_client.register_provider_compliance.call_args
    assert kwargs["provider"] == "replicate"
    assert kwargs["baa_available"] is False


def test_deepseek_intercept_request_calls_check_action_with_provider(
    gov_client: MagicMock,
) -> None:
    dg = DeepSeekGovernance(client=gov_client, agent_name="ds-test")
    dg.intercept_request({
        "model": "deepseek-chat",
        "messages": [{"role": "user", "content": "Hello"}],
    })
    gov_client.check_action.assert_called_once()
    kwargs = gov_client.check_action.call_args.kwargs
    assert kwargs["tool"] == "llm.chat"
    assert kwargs["input"]["provider"] == "deepseek"
    assert kwargs["input"]["model"] == "deepseek-chat"


def test_huggingface_intercept_request_supports_inputs_str_form(
    gov_client: MagicMock,
) -> None:
    hg = HuggingFaceGovernance(client=gov_client, agent_name="hf-test")
    hg.intercept_request({
        "model": "meta-llama/Llama-3.1-8B-Instruct",
        "inputs": "What is the meaning of life?",
    })
    kwargs = gov_client.check_action.call_args.kwargs
    assert kwargs["input"]["provider"] == "huggingface"
    assert "meaning of life" in kwargs["input"]["systemPromptDigest"]


def test_replicate_intercept_request_extracts_prompt_from_input(
    gov_client: MagicMock,
) -> None:
    rg = ReplicateGovernance(client=gov_client, agent_name="rep-test")
    rg.intercept_request({
        "model": "meta/llama-3-70b-instruct",
        "input": {"prompt": "Hello world", "max_tokens": 100},
    })
    kwargs = gov_client.check_action.call_args.kwargs
    assert kwargs["input"]["provider"] == "replicate"
    assert kwargs["input"]["model"] == "meta/llama-3-70b-instruct"
    assert "Hello world" in kwargs["input"]["systemPromptDigest"]
    assert kwargs["input"]["maxTokens"] == 100
