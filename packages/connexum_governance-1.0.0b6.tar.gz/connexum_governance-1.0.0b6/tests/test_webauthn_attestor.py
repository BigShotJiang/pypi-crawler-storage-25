"""
F-NEW-CRIT-39e-2-PY slice 3 -- WebAuthnAttestor unit tests.

No sidecar required. These tests pin the wire format (claim shape, token
prefix, signature embedding, expiry math) so any future regression that
breaks parity with the TS WebAuthnAttestor or the server's
verifyWebAuthnAttestation surfaces here before the live integration
tests run.

Live sidecar-dependent tests live in
``tests/testing/test_webauthn_attestor_live.py``.

@connexum/python-sdk F-NEW-CRIT-39e-2-PY slice 3
"""

from __future__ import annotations

import base64
import json
import uuid
from typing import List

import pytest

from connexum_governance.attestor import (
    AttestationContext,
    AttestorError,
    SignedAttestation,
)
from connexum_governance.webauthn_attestor import (
    DEFAULT_WEBAUTHN_TTL_SECONDS,
    WEBAUTHN_TOKEN_PREFIX,
    WebAuthnAssertion,
    WebAuthnAttestor,
    _build_challenge,
    build_webauthn_token,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _decode_payload(token: str) -> dict:
    """Decode the base64url payload from a v4att.webauthn token."""
    assert token.startswith(WEBAUTHN_TOKEN_PREFIX), token[:30]
    rest = token[len(WEBAUTHN_TOKEN_PREFIX):]
    payload_b64, sig_b64 = rest.rsplit(".", 1)
    pad = "=" * (-len(payload_b64) % 4)
    return json.loads(base64.urlsafe_b64decode(payload_b64 + pad).decode("utf-8"))


def _decode_sig(token: str) -> bytes:
    assert token.startswith(WEBAUTHN_TOKEN_PREFIX), token[:30]
    rest = token[len(WEBAUTHN_TOKEN_PREFIX):]
    _, sig_b64 = rest.rsplit(".", 1)
    pad = "=" * (-len(sig_b64) % 4)
    return base64.urlsafe_b64decode(sig_b64 + pad)


def _make_ctx(
    *,
    tenant_id: str = "py-wa-tenant",
    action: str = "Read",
    nonce: str = "n" * 32,
    request_hash: str = "0123456789abcdef" * 4,
) -> AttestationContext:
    return AttestationContext(
        tenant_id=tenant_id,
        action=action,
        nonce=nonce,
        request_hash=request_hash,
        user_id="alice@example",
    )


# ---------------------------------------------------------------------------
# Test 1: token prefix + structure
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_webauthn_token_uses_v4att_webauthn_prefix() -> None:
    """v4att.webauthn. prefix is the routing key for the server's WebAuthn
    verifier (end-user-attestation.ts:559). If this drifts, the server
    falls back to the Ed25519 verifier and the token is rejected with
    invalid-signature.
    """
    captured_challenges: List[bytes] = []

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        captured_challenges.append(challenge)
        return WebAuthnAssertion(credential_id="cred-1", signature=b"raw-sig-bytes-test-1")

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="alice@example",
        credential_id="cred-1",
        assertion_callback=cb,
    )

    signed = await attestor.sign(_make_ctx())

    assert signed.token.startswith(WEBAUTHN_TOKEN_PREFIX), \
        f"token must use {WEBAUTHN_TOKEN_PREFIX} prefix; got: {signed.token[:30]!r}"
    # Three segments after prefix split: prefix is 'v4att.webauthn.' so the
    # token is 'v4att.webauthn.<payload>.<sig>'. The full token split('.')
    # yields ['v4att', 'webauthn', '<payload>', '<sig>'] = 4 parts.
    parts = signed.token.split(".")
    assert len(parts) == 4
    assert parts[0] == "v4att"
    assert parts[1] == "webauthn"

    # SignedAttestation surface
    assert signed.sub == "alice@example"
    assert isinstance(signed.exp, int) and signed.exp > 0
    # jti is a UUID v4
    assert len(signed.jti) == 36
    uuid.UUID(signed.jti)


# ---------------------------------------------------------------------------
# Test 2: webauthn:true marker is in payload claims
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_webauthn_marker_present_in_claims() -> None:
    """``webauthn: true`` is the structural marker the server checks at
    end-user-attestation.ts:558. Without it, parseWebAuthnAttestationToken
    returns null and verifyWebAuthnAttestation rejects with malformed-token.
    """

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="cred-x", signature=b"x" * 64)

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="bob@example",
        credential_id="cred-x",
        assertion_callback=cb,
    )

    signed = await attestor.sign(_make_ctx(tenant_id="t-marker"))
    claims = _decode_payload(signed.token)

    assert claims["webauthn"] is True, \
        f"missing webauthn:true marker -- server will reject as malformed; claims={claims}"
    assert claims["sub"] == "bob@example"
    assert claims["aud"] == "t-marker"
    assert claims["tenantId"] == "t-marker"
    assert claims["action"] == "Read"


# ---------------------------------------------------------------------------
# Test 3: signature bytes are embedded verbatim
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_signature_bytes_embedded_verbatim() -> None:
    """The customer-supplied WebAuthn assertion bytes appear unchanged
    in the token's signature segment. This is the difference between the
    Ed25519 SoftwareKeyAttestor (which signs the payload) and the
    WebAuthnAttestor (which embeds the browser's signature). The server
    does NOT re-verify these in slice 3 (filed
    F-NEW-CRIT-39e-2-WEBAUTHN-FULL-VERIFY).
    """
    expected_sig = bytes(range(64))  # 64 distinct bytes 0..63

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="abc-cred", signature=expected_sig)

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="carol@example",
        credential_id="abc-cred",
        assertion_callback=cb,
    )

    signed = await attestor.sign(_make_ctx())
    sig_bytes = _decode_sig(signed.token)
    assert sig_bytes == expected_sig, \
        f"signature corruption in transit; expected {expected_sig.hex()[:40]}... got {sig_bytes.hex()[:40]}..."


# ---------------------------------------------------------------------------
# Test 4: action is truncated to 200 chars (server constraint mirror)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_action_truncated_to_200_chars() -> None:
    """Server's verifyWebAuthnAttestation compares claims.action to
    toolName exactly. The TS WebAuthnAttestor slices action to 200 chars
    (webauthn-attestor.ts:293) -- we must mirror so cross-SDK tokens
    are accepted identically.
    """

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="c", signature=b"sig")

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="alice@example",
        credential_id="c",
        assertion_callback=cb,
    )

    long_action = "A" * 500
    signed = await attestor.sign(_make_ctx(action=long_action))
    claims = _decode_payload(signed.token)
    assert len(claims["action"]) == 200, \
        f"action must be truncated to 200 chars; got {len(claims['action'])}"
    assert claims["action"] == "A" * 200


# ---------------------------------------------------------------------------
# Test 5: credential_id propagates to keyId claim
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_credential_id_becomes_key_id_claim() -> None:
    """The WebAuthn ``assertion.id`` from the browser binds the token to
    the specific authenticator credential. The TS impl puts this in
    keyId at webauthn-attestor.ts:294. Customer audit trails depend on
    this id to identify which physical key was used.
    """

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(
            credential_id="opaque-credential-id-base64url",
            signature=b"some-sig",
        )

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="dave@example",
        credential_id="opaque-credential-id-base64url",
        assertion_callback=cb,
    )
    signed = await attestor.sign(_make_ctx())
    claims = _decode_payload(signed.token)
    assert claims["keyId"] == "opaque-credential-id-base64url", \
        f"keyId claim must mirror credential_id; got {claims.get('keyId')!r}"


# ---------------------------------------------------------------------------
# Test 6: AttestorError(user-cancelled) propagates from callback
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_user_cancelled_propagates_with_original_code() -> None:
    """If the customer's assertion callback raises
    AttestorError('user-cancelled', ...) (because the user dismissed the
    biometric prompt), the SDK must preserve the original code so the
    upstream GovernanceViolation reports the correct reason.
    """

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        raise AttestorError("user-cancelled", "biometric prompt dismissed by user")

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="alice@example",
        credential_id="c",
        assertion_callback=cb,
    )

    with pytest.raises(AttestorError) as exc_info:
        await attestor.sign(_make_ctx())
    assert exc_info.value.code == "user-cancelled"


# ---------------------------------------------------------------------------
# Test 7: arbitrary callback exception wraps as sign-failed
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_callback_exception_wraps_as_sign_failed() -> None:
    """A bare Exception from the callback (network failure, timeout in
    the customer's browser bridge, etc.) becomes
    AttestorError('sign-failed', ...). Customers can then distinguish
    user-cancelled (their problem) from infrastructure failures.
    """

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        raise RuntimeError("WebSocket to browser bridge dropped")

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="alice@example",
        credential_id="c",
        assertion_callback=cb,
    )

    with pytest.raises(AttestorError) as exc_info:
        await attestor.sign(_make_ctx())
    assert exc_info.value.code == "sign-failed"
    assert "WebSocket" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 8: empty signature bytes -> sign-failed (would hit server malformed-token)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_empty_signature_rejected_before_token_emission() -> None:
    """An empty signature bytestring would produce a 0-length b64url
    segment which the server's parser tolerates but the verifier later
    rejects. Catching it client-side gives a clearer error and saves a
    HTTP round-trip.
    """

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="c", signature=b"")

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="alice@example",
        credential_id="c",
        assertion_callback=cb,
    )

    with pytest.raises(AttestorError) as exc_info:
        await attestor.sign(_make_ctx())
    assert exc_info.value.code == "sign-failed"
    assert "empty signature" in str(exc_info.value).lower()


# ---------------------------------------------------------------------------
# Test 9: jti uniqueness across sign() calls
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_jti_unique_per_sign_call() -> None:
    """Server-side jti-replay protection (end-user-attestation.ts:642)
    rejects a token whose jti has been seen before. Each sign() call
    must produce a fresh jti or every-other request from the same client
    breaks.
    """

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="c", signature=b"sig")

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="alice@example",
        credential_id="c",
        assertion_callback=cb,
    )

    a = await attestor.sign(_make_ctx())
    b = await attestor.sign(_make_ctx())
    assert a.jti != b.jti


# ---------------------------------------------------------------------------
# Test 10: challenge length is 32 bytes (WebAuthn minimum)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_challenge_passed_to_callback_is_32_bytes() -> None:
    """WebAuthn spec mandates challenge >= 16 bytes; we pad/build to 32
    so the browser API call has full entropy. The TS impl does the same
    (webauthn-attestor.ts:228-232).
    """
    captured: List[bytes] = []

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        captured.append(challenge)
        return WebAuthnAssertion(credential_id="c", signature=b"sig")

    attestor = WebAuthnAttestor(
        rp_id="my-cc.io",
        user_id="alice@example",
        credential_id="c",
        assertion_callback=cb,
    )

    await attestor.sign(_make_ctx())
    assert len(captured) == 1
    assert len(captured[0]) == 32


# ---------------------------------------------------------------------------
# Test 11: constructor validates required fields
# ---------------------------------------------------------------------------


def test_constructor_rejects_missing_rp_id_or_user_id_or_credential() -> None:
    """Missing arguments produce a clear ValueError, not a runtime
    NoneType crash inside the WebAuthn ceremony.
    """

    async def cb(challenge: bytes) -> WebAuthnAssertion:
        return WebAuthnAssertion(credential_id="c", signature=b"sig")

    with pytest.raises(ValueError, match="rp_id"):
        WebAuthnAttestor(rp_id="", user_id="u", credential_id="c", assertion_callback=cb)
    with pytest.raises(ValueError, match="user_id"):
        WebAuthnAttestor(rp_id="rp", user_id="", credential_id="c", assertion_callback=cb)
    with pytest.raises(ValueError, match="credential_id"):
        WebAuthnAttestor(rp_id="rp", user_id="u", credential_id="", assertion_callback=cb)
    with pytest.raises(ValueError, match="assertion_callback"):
        WebAuthnAttestor(rp_id="rp", user_id="u", credential_id="c", assertion_callback=None)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Test 12: build_webauthn_token low-level helper is callable
#          and produces server-parseable shape
# ---------------------------------------------------------------------------


def test_build_webauthn_token_helper_produces_parseable_token() -> None:
    """Direct call into the builder, used by the cross-SDK contract pen-tests
    that build a Python-emitted token outside the WebAuthnAttestor class.
    """
    token = build_webauthn_token(
        sub="alice@example",
        aud="tenant-a",
        iat_iso="2026-05-04T12:00:00.000Z",
        exp_iso="2026-05-04T12:01:30.000Z",
        jti="11111111-2222-4333-8444-555555555555",
        action="Bash",
        signature=b"raw-webauthn-signature-from-fido2",
        nonce="n" * 32,
        request_hash="0" * 64,
        key_id="creds-id-abc",
    )
    assert token.startswith(WEBAUTHN_TOKEN_PREFIX)
    claims = _decode_payload(token)
    assert claims["webauthn"] is True
    assert claims["sub"] == "alice@example"
    assert claims["aud"] == "tenant-a"
    assert claims["tenantId"] == "tenant-a"
    assert claims["iat"] == "2026-05-04T12:00:00.000Z"
    assert claims["exp"] == "2026-05-04T12:01:30.000Z"
    assert claims["jti"] == "11111111-2222-4333-8444-555555555555"
    assert claims["action"] == "Bash"
    assert claims["nonce"] == "n" * 32
    assert claims["requestHash"] == "0" * 64
    assert claims["keyId"] == "creds-id-abc"

    # Sig segment decode round-trip
    sig = _decode_sig(token)
    assert sig == b"raw-webauthn-signature-from-fido2"
