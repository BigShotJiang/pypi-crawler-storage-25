"""Tests for governance data models."""

import pytest

from connexum_governance.models import (
    AgentIdentity,
    ActionContext,
    TaskContext,
    PlanStep,
    PlanContext,
    DelegationContext,
    GovernanceDecision,
    GovernanceViolation,
    DecisionType,
    UnboundDataError,
)


class TestAgentIdentity:
    def test_minimal(self):
        agent = AgentIdentity(name="bot")
        d = agent.to_dict()
        assert d == {"name": "bot"}

    def test_full(self):
        agent = AgentIdentity(
            name="analyst",
            role="researcher",
            session_id="sess-1",
            org_id="org-1",
            identity_token="tok-abc",
        )
        d = agent.to_dict()
        assert d["name"] == "analyst"
        assert d["role"] == "researcher"
        assert d["sessionId"] == "sess-1"
        assert d["orgId"] == "org-1"
        assert d["identityToken"] == "tok-abc"

    def test_optional_fields_omitted(self):
        agent = AgentIdentity(name="bot", role="helper")
        d = agent.to_dict()
        assert "sessionId" not in d
        assert "orgId" not in d


class TestActionContext:
    def test_to_dict(self):
        ctx = ActionContext(
            tool="Bash",
            input={"command": "ls"},
            agent=AgentIdentity(name="dev"),
        )
        d = ctx.to_dict()
        assert d["toolName"] == "Bash"
        assert d["input"] == {"command": "ls"}
        assert d["agent"]["name"] == "dev"
        assert d["timestamp"].endswith("Z")

    def test_custom_timestamp(self):
        ctx = ActionContext(
            tool="Read",
            input={"path": "/tmp"},
            agent=AgentIdentity(name="r"),
            timestamp="2026-01-01T00:00:00Z",
        )
        assert ctx.to_dict()["timestamp"] == "2026-01-01T00:00:00Z"


class TestTaskContext:
    def test_to_dict(self):
        task = TaskContext(
            task_id="t-1",
            task_type="analysis",
            description="Analyze logs",
            agent=AgentIdentity(name="analyst"),
            input={"log_path": "/var/log"},
            pack_binding=["hipaa", "soc2"],
        )
        d = task.to_dict()
        assert d["taskId"] == "t-1"
        assert d["taskType"] == "analysis"
        assert d["assignedAgent"]["name"] == "analyst"
        assert d["input"]["log_path"] == "/var/log"
        assert d["packBinding"] == ["hipaa", "soc2"]

    def test_parent_task(self):
        task = TaskContext(
            task_id="t-2",
            task_type="sub",
            description="Subtask",
            agent=AgentIdentity(name="worker"),
            parent_task_id="t-1",
            pack_binding=["soc2"],
        )
        d = task.to_dict()
        assert d["parentTaskId"] == "t-1"

    def test_empty_pack_binding_raises_unbound_data_error(self):
        """C2: TaskContext without pack_binding raises UnboundDataError."""
        with pytest.raises(UnboundDataError, match="pack binding required"):
            TaskContext(
                task_id="t-3",
                task_type="analysis",
                description="No pack binding",
                agent=AgentIdentity(name="agent"),
                pack_binding=[],
            )


class TestPlanContext:
    def test_to_dict(self):
        plan = PlanContext(
            plan_id="p-1",
            objective="Deploy update",
            steps=[
                PlanStep(step_id="s1", action="build"),
                PlanStep(
                    step_id="s2",
                    action="deploy",
                    dependencies=["s1"],
                    estimated_risk="high",
                ),
            ],
            creator=AgentIdentity(name="planner"),
        )
        d = plan.to_dict()
        assert d["planId"] == "p-1"
        assert len(d["steps"]) == 2
        assert d["steps"][1]["dependencies"] == ["s1"]
        assert d["steps"][1]["estimatedRisk"] == "high"


class TestDelegationContext:
    def test_to_dict(self):
        delegation = DelegationContext(
            delegation_id="d-1",
            from_agent=AgentIdentity(name="manager"),
            to_agent=AgentIdentity(name="worker"),
            task="cleanup",
            permissions=["read", "write"],
            pack_binding=["soc2"],
        )
        d = delegation.to_dict()
        assert d["delegationId"] == "d-1"
        assert d["fromAgent"]["name"] == "manager"
        assert d["toAgent"]["name"] == "worker"
        assert d["permissions"] == ["read", "write"]
        assert d["packBinding"] == ["soc2"]

    def test_empty_pack_binding_raises_unbound_data_error(self):
        """C2: DelegationContext without pack_binding raises UnboundDataError."""
        with pytest.raises(UnboundDataError, match="pack binding required"):
            DelegationContext(
                delegation_id="d-2",
                from_agent=AgentIdentity(name="manager"),
                to_agent=AgentIdentity(name="worker"),
                task="cleanup",
                permissions=["read"],
                pack_binding=[],
            )


class TestGovernanceDecision:
    def test_from_dict_allow(self):
        d = GovernanceDecision.from_dict({
            "decision": "ALLOW",
            "reason": "OK",
            "auditId": "a-1",
        })
        assert d.allowed
        assert not d.denied
        assert not d.requires_approval
        assert d.reason == "OK"

    def test_from_dict_deny(self):
        d = GovernanceDecision.from_dict({
            "decision": "DENY",
            "reason": "Blocked",
            "auditId": "a-2",
        })
        assert d.denied
        assert not d.allowed

    def test_from_dict_require_approval(self):
        d = GovernanceDecision.from_dict({
            "decision": "REQUIRE_APPROVAL",
            "reason": "Needs sign-off",
            "auditId": "a-3",
        })
        assert d.requires_approval

    def test_from_dict_legacy_type_field(self):
        d = GovernanceDecision.from_dict({
            "type": "ALLOW",
            "reason": "OK",
            "auditId": "a-4",
        })
        assert d.allowed

    def test_from_dict_with_extras(self):
        d = GovernanceDecision.from_dict({
            "decision": "DENY",
            "reason": "Plan has risky steps",
            "auditId": "a-5",
            "blockedSteps": ["s2", "s3"],
            "restrictedPermissions": ["admin"],
            "metadata": {"policyId": "pol-1"},
        })
        assert d.blocked_steps == ["s2", "s3"]
        assert d.restricted_permissions == ["admin"]
        assert d.metadata["policyId"] == "pol-1"

    def test_defaults(self):
        d = GovernanceDecision.from_dict({})
        assert d.denied  # defaults to DENY
        assert d.reason == ""
        assert d.audit_id == ""


class TestGovernanceViolation:
    def test_message(self):
        decision = GovernanceDecision(
            decision=DecisionType.DENY,
            reason="Not allowed",
            audit_id="a-99",
        )
        exc = GovernanceViolation(decision)
        assert "Not allowed" in str(exc)
        assert "a-99" in str(exc)
        assert exc.decision is decision

    def test_is_exception(self):
        decision = GovernanceDecision(
            decision=DecisionType.DENY,
            reason="Blocked",
            audit_id="a-100",
        )
        assert isinstance(GovernanceViolation(decision), Exception)
