"""
Tests for connexum_governance.llm_adapters.gemma — Python parity of the
TypeScript standalone Gemma adapter (F-NEW-GEMMA-PY, Tier 4.5).

Step 0 probe: pre-implementation, the import in this file fails because
connexum_governance/llm_adapters/gemma.py does not exist. Run this file before
writing the implementation to confirm the RED state, then add the file.

Mirrors the TS test matrix at tests/llm-adapters/gemma.test.ts so the two
SDKs report the same model-ID rules + the same BAA / open-weight flags
per deployment target. Audit consumers reading the audit chain from either
SDK should see semantically equivalent metadata.
"""

import pytest

# Intentionally importing the not-yet-existing module — RED state probe.
from connexum_governance.llm_adapters.gemma import (
    GemmaDeploymentTarget,
    GemmaMetadata,
    KNOWN_GEMMA_MODEL_IDS,
    validate_gemma_model_id,
    get_gemma_metadata,
    is_gemma_multimodal,
    gemma_subfamily_of,
)


class TestModelIdRegistry:
    def test_known_ids_contain_text_and_multimodal_set(self):
        assert "gemma-2-2b-it" in KNOWN_GEMMA_MODEL_IDS
        assert "gemma-2-9b-it" in KNOWN_GEMMA_MODEL_IDS
        assert "gemma-2-27b-it" in KNOWN_GEMMA_MODEL_IDS
        assert "paligemma-3b-mix-224" in KNOWN_GEMMA_MODEL_IDS
        assert "paligemma-3b-pt-448" in KNOWN_GEMMA_MODEL_IDS

    def test_known_ids_is_immutable(self):
        # Frozen tuple — cannot append / mutate.
        assert isinstance(KNOWN_GEMMA_MODEL_IDS, tuple)
        with pytest.raises((TypeError, AttributeError)):
            KNOWN_GEMMA_MODEL_IDS.append("rogue-model")  # type: ignore[attr-defined]


class TestValidateModelId:
    @pytest.mark.parametrize("model_id", [
        "gemma-2-2b-it",
        "gemma-2-9b-it",
        "gemma-2-27b-it",
    ])
    def test_accepts_gemma_2_text(self, model_id):
        assert validate_gemma_model_id(model_id) is True

    @pytest.mark.parametrize("model_id", [
        "paligemma-3b-mix-224",
        "paligemma-3b-pt-896",
    ])
    def test_accepts_paligemma_multimodal(self, model_id):
        assert validate_gemma_model_id(model_id) is True

    @pytest.mark.parametrize("model_id", [
        "gemma-3-7b-it",
        "gemma-4-100b-it",
        "paligemma-2-12b",
    ])
    def test_accepts_future_gemma_via_prefix(self, model_id):
        # Forward compatibility — Gemma 3 / 4 etc. should validate without
        # requiring this file to be edited every release.
        assert validate_gemma_model_id(model_id) is True

    @pytest.mark.parametrize("model_id", [
        "gemini-1.5-flash",
        "gpt-4o",
        "claude-opus-4-7",
        "",
    ])
    def test_rejects_non_gemma(self, model_id):
        assert validate_gemma_model_id(model_id) is False

    @pytest.mark.parametrize("model_id", [
        "Gemma-2-9b-it",       # case mismatch — must reject
        "gemini-gemma",        # spoof — must reject
        "not-gemma-2",         # spoof — must reject
    ])
    def test_rejects_spoofing(self, model_id):
        assert validate_gemma_model_id(model_id) is False


class TestGemmaMetadata:
    @pytest.mark.parametrize("target", [
        "vertex-ai",
        "generative-language",
        "huggingface",
        "self-hosted-ollama",
    ])
    def test_is_open_weight_always_true(self, target):
        meta = get_gemma_metadata("gemma-2-9b-it", target)
        assert meta.is_open_weight is True

    def test_baa_inherits_only_for_vertex(self):
        assert get_gemma_metadata("gemma-2-9b-it", "vertex-ai").baa_inherits is True
        assert get_gemma_metadata("gemma-2-9b-it", "generative-language").baa_inherits is False
        assert get_gemma_metadata("gemma-2-9b-it", "huggingface").baa_inherits is False
        assert get_gemma_metadata("gemma-2-9b-it", "self-hosted-ollama").baa_inherits is False

    def test_display_name_distinguishes_deployment_target(self):
        vertex = get_gemma_metadata("gemma-2-9b-it", "vertex-ai")
        hf = get_gemma_metadata("gemma-2-9b-it", "huggingface")
        assert "vertex" in vertex.display_name.lower()
        assert "huggingface" in hf.display_name.lower()
        assert vertex.display_name != hf.display_name
        # Both must include the modelId.
        assert "gemma-2-9b-it" in vertex.display_name
        assert "gemma-2-9b-it" in hf.display_name

    def test_deployment_target_passthrough(self):
        meta = get_gemma_metadata("paligemma-3b-mix-224", "self-hosted-ollama")
        assert meta.deployment_target == "self-hosted-ollama"

    def test_rejects_unknown_deployment_target(self):
        with pytest.raises(ValueError, match="deployment target"):
            get_gemma_metadata("gemma-2-9b-it", "rogue-target")  # type: ignore[arg-type]


class TestIsGemmaMultimodal:
    @pytest.mark.parametrize("model_id", [
        "paligemma-3b-mix-224",
        "paligemma-3b-pt-448",
    ])
    def test_paligemma_returns_true(self, model_id):
        assert is_gemma_multimodal(model_id) is True

    @pytest.mark.parametrize("model_id", [
        "gemma-2-2b-it",
        "gemma-2-9b-it",
        "gemma-2-27b-it",
    ])
    def test_text_only_returns_false(self, model_id):
        assert is_gemma_multimodal(model_id) is False

    @pytest.mark.parametrize("model_id", [
        "gpt-4o",
        "claude-opus-4-7",
        "",
    ])
    def test_non_gemma_returns_false(self, model_id):
        assert is_gemma_multimodal(model_id) is False


class TestSubfamilyOf:
    @pytest.mark.parametrize("model_id", [
        "gemma-2-2b-it",
        "gemma-3-7b-it",
        "paligemma-3b-mix-224",
    ])
    def test_gemma_ids_return_gemma(self, model_id):
        assert gemma_subfamily_of(model_id) == "gemma"

    @pytest.mark.parametrize("model_id", [
        "gemini-1.5-flash",
        "gpt-4o",
        "Gemma-2-9b-it",  # case mismatch
        "",
    ])
    def test_non_gemma_returns_none(self, model_id):
        assert gemma_subfamily_of(model_id) is None
