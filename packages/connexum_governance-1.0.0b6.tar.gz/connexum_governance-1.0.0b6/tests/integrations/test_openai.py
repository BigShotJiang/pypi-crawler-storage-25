"""Tests for OpenAIGovernance integration (B1-02).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 response classification
3. PHI ingress refusal
4. Provider compliance registration
5. Subscription gate
6. Audit chain append
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.openai import OpenAIGovernance, OpenAIClientProxy
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ALLOW_WITH_AUDIT = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-oai-001",
}

DENY_SECRET = {
    "decision": "DENY",
    "reason": "G2: secret pattern detected",
    "auditId": "aud-oai-002",
}

PHI_DENY = {
    "decision": "DENY",
    "reason": "G3: PHI ingress blocked",
    "auditId": "aud-oai-003",
}

CLASSIFY_CLEAN = {
    "allowed": True,
    "guardsTriggered": [],
    "auditId": "aud-oai-001",
}

CLASSIFY_SECRET_LEAK = {
    "allowed": False,
    "guardsTriggered": ["G2_SECRET_LEAK"],
    "auditId": "aud-oai-001",
}


def _make_transport_with_classify(action_response: dict, classify_response: dict) -> httpx.MockTransport:
    return make_transport({
        "/api/v1/governance/check-action": action_response,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/governance/classify": classify_response,
        "/api/v1/governance/provider-compliance": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    })


def _make_og(transport: httpx.MockTransport, enforce: bool = True) -> OpenAIGovernance:
    client = make_client(transport, enforce=enforce)
    return OpenAIGovernance(client=client, agent_name="test-agent", agent_role="chat")


def _mock_openai_client(response: dict[str, Any]) -> Any:
    class MockCompletions:
        def create(self, **kwargs: Any) -> dict:
            return response

    class MockChat:
        completions = MockCompletions()

    class MockOpenAI:
        chat = MockChat()

    return MockOpenAI()


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestOpenAIHappyPath:
    def test_intercept_request_allow(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        og = _make_og(transport)

        decision = og.intercept_request({
            "model": "gpt-4o",
            "messages": [
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "Hello"},
            ],
        })
        assert decision.allowed
        assert decision.audit_id == "aud-oai-001"

    def test_system_message_extracted_as_digest(self):
        """System message content sent as systemPromptDigest."""
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_request({
            "model": "gpt-4o",
            "messages": [{"role": "system", "content": "System instructions here"}],
        })
        assert captured[0]["input"]["systemPromptDigest"] == "System instructions here"

    def test_tool_names_extracted(self):
        """Tool names from tools array forwarded in governance input."""
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_request({
            "model": "gpt-4o",
            "messages": [],
            "tools": [
                {"type": "function", "function": {"name": "search", "description": "Search"}},
                {"type": "function", "function": {"name": "calculator"}},
            ],
        })
        assert captured[0]["input"]["toolNames"] == ["search", "calculator"]
        assert captured[0]["input"]["toolCount"] == 2

    def test_legacy_functions_extracted(self):
        """Legacy functions array also extracted as tool names."""
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_request({
            "model": "gpt-4",
            "messages": [],
            "functions": [{"name": "legacy_fn", "description": "A function"}],
        })
        assert "legacy_fn" in captured[0]["input"]["toolNames"]

    def test_intercept_response_clean(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        og = _make_og(transport)

        response = {
            "id": "chatcmpl-001",
            "choices": [{"message": {"role": "assistant", "content": "Hello!"}}],
        }
        classified = og.intercept_response(response=response, audit_id="aud-oai-001")
        assert classified.allowed
        assert classified.guards_triggered == []


# ---------------------------------------------------------------------------
# 2. Secret leak G2
# ---------------------------------------------------------------------------

class TestOpenAISecretLeak:
    def test_g2_secret_in_response(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        og = _make_og(transport)

        classified = og.intercept_response(
            response={"choices": [{"message": {"content": "sk-abc123"}}]},
            audit_id="aud-oai-001",
        )
        assert not classified.allowed
        assert "G2_SECRET_LEAK" in classified.guards_triggered

    def test_proxy_warns_on_g2(self, capsys):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        og = _make_og(transport)

        proxy = og.wrap(_mock_openai_client({
            "id": "chatcmpl-002",
            "choices": [{"message": {"content": "sk-secret"}}],
            "model": "gpt-4o",
        }))
        proxy.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hi"}],
        )
        captured = capsys.readouterr()
        assert "G-series classification" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal
# ---------------------------------------------------------------------------

class TestOpenAIPhiIngress:
    def test_phi_ingress_denied_no_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        decision = og.intercept_request({
            "model": "gpt-4o",
            "messages": [
                {"role": "system", "content": "Patient SSN: 123-45-6789"},
            ],
        })
        assert decision.denied

    def test_phi_ingress_raises_when_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=True)

        with pytest.raises(GovernanceViolation):
            og.intercept_request({
                "model": "gpt-4o",
                "messages": [{"role": "system", "content": "Patient record"}],
            })


# ---------------------------------------------------------------------------
# 4. Provider compliance registration
# ---------------------------------------------------------------------------

class TestOpenAIProviderCompliance:
    def test_baa_metadata_registered_on_init(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json={"ok": True})

        _ = _make_og(httpx.MockTransport(handler))
        assert len(registered) == 1
        assert registered[0]["provider"] == "openai"
        assert registered[0]["baaAvailable"] is True
        assert registered[0]["baaScope"] == "enterprise_only"

    def test_notes_indicate_enterprise_only(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_og(httpx.MockTransport(handler))
        assert "enterprise" in registered[0]["notes"].lower()


# ---------------------------------------------------------------------------
# 5. Subscription gate
# ---------------------------------------------------------------------------

class TestOpenAISubscriptionGate:
    def test_subscription_revoked_blocks_request(self):
        sub_deny = {
            "decision": "DENY",
            "reason": "Subscription inactive",
            "auditId": "aud-sub-oai",
        }
        transport = _make_transport_with_classify(sub_deny, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        decision = og.intercept_request({
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "Hello"}],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# 6. Audit chain append
# ---------------------------------------------------------------------------

class TestOpenAIAuditChain:
    def test_report_result_called_after_classify(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_CLEAN)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_response(
            response={"choices": [{"message": {"content": "OK"}}]},
            audit_id="aud-oai-001",
        )
        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-oai-001"
        assert reported[0]["success"] is True

    def test_report_result_marks_failure_on_blocked(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_SECRET_LEAK)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_response(
            response={"choices": [{"message": {"content": "sk-secret"}}]},
            audit_id="aud-oai-001",
        )
        assert reported[0]["success"] is False


# ---------------------------------------------------------------------------
# wrap() proxy
# ---------------------------------------------------------------------------

class TestOpenAIProxy:
    def test_wrap_returns_proxy(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        og = _make_og(transport)
        proxy = og.wrap(_mock_openai_client({"id": "test"}))
        assert isinstance(proxy, OpenAIClientProxy)

    def test_proxy_denied_returns_denial_choice(self):
        deny = {"decision": "DENY", "reason": "blocked", "auditId": "aud-x"}
        transport = _make_transport_with_classify(deny, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        proxy = og.wrap(_mock_openai_client({"choices": []}))
        result = proxy.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert result["choices"][0]["finish_reason"] == "governance_denied"
        assert "[GOVERNANCE DENIED]" in result["choices"][0]["message"]["content"]

    def test_proxy_requires_approval_returns_pending(self):
        approval = {"decision": "REQUIRE_APPROVAL", "reason": "needs sign-off", "auditId": "aud-y"}
        transport = _make_transport_with_classify(approval, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        proxy = og.wrap(_mock_openai_client({"choices": []}))
        result = proxy.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Deploy now"}],
        )
        assert result["choices"][0]["finish_reason"] == "governance_pending"
        assert "[GOVERNANCE PENDING]" in result["choices"][0]["message"]["content"]
