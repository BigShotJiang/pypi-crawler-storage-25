"""Tests for the Replit Agent governance integration (P3-SUB-IDE-13).

Mirrors the TS test coverage (tests/ide/replit-agent.test.ts).

Coverage:
  --- Initialization ---
  P-REPLIT-01: valid config initialises correctly
  P-REPLIT-02: invalid deployment_mode raises ValueError
  P-REPLIT-03: invalid user_tier raises ValueError
  P-REPLIT-04: PT-ADAPT-REPLIT-3 -- user_is_minor + user_tier='admin' raises ValueError
  P-REPLIT-05: PT-ADAPT-REPLIT-3 -- negative multi_file_edit_cap raises ValueError
  P-REPLIT-06: PT-ADAPT-REPLIT-3 -- negative sandbox_resource_cap.maxCpuSeconds raises ValueError
  P-REPLIT-07: PT-ADAPT-REPLIT-1 -- empty pack_binding denied in intercept_agent_task

  --- intercept_agent_task ---
  P-REPLIT-08: clean task description => ALLOW
  P-REPLIT-09: empty taskDescription => DENY with replit-agent-task-description-required
  P-REPLIT-10: whitespace-only taskDescription => DENY

  --- intercept_sandbox_code_execution ---
  P-REPLIT-11: clean code => ALLOW
  P-REPLIT-12: egress pattern (fetch) + non-minor => ALLOW with egressPatternDetected
  P-REPLIT-13: egress pattern (urllib.request) + minor => DENY with replit-sandbox-network-egress-blocked-for-minor
  P-REPLIT-14: egress pattern (requests.get) + minor => DENY
  P-REPLIT-15: no egress + minor => ALLOW

  --- intercept_file_system_mutation ---
  P-REPLIT-16: files below cap => ALLOW
  P-REPLIT-17: files at cap boundary (25) => ALLOW
  P-REPLIT-18: files exceeding cap => DENY
  P-REPLIT-19: custom multi_file_edit_cap respected

  --- intercept_package_install ---
  P-REPLIT-20: normal package + individual => ALLOW
  P-REPLIT-21: minor + student => DENY with replit-package-install-not-permitted-minor-student
  P-REPLIT-22: minor + non-student => ALLOW (minor alone doesn't block install)
  P-REPLIT-23: allow_package_install=False => DENY
  P-REPLIT-24: package in allow_list => ALLOW
  P-REPLIT-25: PT-ADAPT-REPLIT-6 -- package NOT in allow_list => DENY + offendingPackage in reason
  P-REPLIT-26: typosquat -- name > 40 chars => REQUIRE_APPROVAL
  P-REPLIT-27: typosquat -- suspicious punctuation => REQUIRE_APPROVAL

  --- intercept_deployment ---
  P-REPLIT-28: PT-ADAPT-REPLIT-4 -- minor user => DENY with replit-deployment-not-permitted-minor
  P-REPLIT-29: student tier => DENY with replit-deployment-not-permitted-student
  P-REPLIT-30: non-deployments mode + no opt-in => DENY
  P-REPLIT-31: replit-deployments mode => ALLOW
  P-REPLIT-32: replit-cloud + allow_deployment=True => ALLOW
  P-REPLIT-33: replit-teams + no opt-in => DENY
  P-REPLIT-34: minor overrides even replit-deployments mode

  --- intercept_secret_access ---
  P-REPLIT-35: PT-ADAPT-REPLIT-5 -- minor => DENY with replit-secret-access-not-permitted
  P-REPLIT-36: allow_secret_access not set => DENY
  P-REPLIT-37: allow_secret_access=True + non-minor => ALLOW
  P-REPLIT-38: allow_secret_access=True + minor => DENY (minor always wins)

  --- intercept_database_query ---
  P-REPLIT-39: clean SELECT => ALLOW
  P-REPLIT-40: DROP TABLE => REQUIRE_APPROVAL
  P-REPLIT-41: TRUNCATE TABLE => REQUIRE_APPROVAL
  P-REPLIT-42: unguarded DELETE FROM => REQUIRE_APPROVAL

  --- intercept_chat ---
  P-REPLIT-43: clean prompt => ALLOW
  P-REPLIT-44: secret in prompt => DENY
  P-REPLIT-45: PHI indicator + hipaa pack => REQUIRE_APPROVAL
  P-REPLIT-46: PHI indicator + non-hipaa pack => ALLOW

  --- PT-ADAPT-REPLIT-2: auth token not in output ---
  P-REPLIT-47: Replit auth token in prompt is denied; raw value not in denial reason

  --- Constants ---
  P-REPLIT-48: REPLIT_VALID_DEPLOYMENT_MODES correct
  P-REPLIT-49: REPLIT_BAA_ELIGIBLE_MODES correct
  P-REPLIT-50: REPLIT_VALID_USER_TIERS correct
"""

from __future__ import annotations

import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.replit_agent import (
    ReplitAgentGovernedClient,
    ReplitAgentPolicyBridge,
    REPLIT_VALID_DEPLOYMENT_MODES,
    REPLIT_BAA_ELIGIBLE_MODES,
    REPLIT_VALID_USER_TIERS,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-replit-001",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    deployment_mode: str = "replit-cloud",
    user_tier: str = "individual",
    user_is_minor: bool = False,
    allow_deployment: bool | None = None,
    allow_secret_access: bool = False,
    allow_package_install: bool = True,
    package_install_allow_list: list[str] | None = None,
    multi_file_edit_cap: int = 25,
    pack_binding: list[str] | None = None,
) -> ReplitAgentGovernedClient:
    client = make_client(transport, enforce=enforce)
    return ReplitAgentGovernedClient(
        client=client,
        agent_name="replit-agent-test",
        pack_binding=pack_binding if pack_binding is not None else ["soc2"],
        deployment_mode=deployment_mode,
        user_tier=user_tier,
        user_is_minor=user_is_minor,
        allow_deployment=allow_deployment,
        allow_secret_access=allow_secret_access,
        allow_package_install=allow_package_install,
        package_install_allow_list=package_install_allow_list,
        multi_file_edit_cap=multi_file_edit_cap,
    )


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------

class TestInitialization:
    def test_p_replit_01_valid_config_initialises(self):
        adapter = _adapter(_transport(), deployment_mode="replit-teams", user_tier="team-member")
        assert adapter.deployment_mode == "replit-teams"
        assert adapter.user_tier == "team-member"

    def test_p_replit_02_invalid_deployment_mode_raises(self):
        client = make_client(_transport())
        with pytest.raises(ValueError, match="invalid deployment_mode"):
            ReplitAgentGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="replit-unknown",
            )

    def test_p_replit_03_invalid_user_tier_raises(self):
        client = make_client(_transport())
        with pytest.raises(ValueError, match="invalid user_tier"):
            ReplitAgentGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="replit-cloud",
                user_tier="superuser",
            )

    def test_p_replit_04_minor_admin_conflict_raises(self):
        """PT-ADAPT-REPLIT-3: user_is_minor + user_tier='admin' is invalid."""
        client = make_client(_transport())
        with pytest.raises(ValueError, match="incompatible"):
            ReplitAgentGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="replit-cloud",
                user_is_minor=True,
                user_tier="admin",
            )

    def test_p_replit_05_negative_multi_file_edit_cap_raises(self):
        """PT-ADAPT-REPLIT-3: negative multi_file_edit_cap raises ValueError."""
        client = make_client(_transport())
        with pytest.raises(ValueError, match="multi_file_edit_cap"):
            ReplitAgentGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="replit-cloud",
                multi_file_edit_cap=-1,
            )

    def test_p_replit_06_negative_sandbox_cpu_cap_raises(self):
        """PT-ADAPT-REPLIT-3: negative sandbox_resource_cap.maxCpuSeconds raises ValueError."""
        client = make_client(_transport())
        with pytest.raises(ValueError, match="maxCpuSeconds"):
            ReplitAgentGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="replit-cloud",
                sandbox_resource_cap={"maxCpuSeconds": -10},
            )

    def test_p_replit_07_empty_pack_binding_denied(self):
        """PT-ADAPT-REPLIT-1: empty pack_binding denied in intercept_agent_task."""
        adapter = _adapter(_transport(), pack_binding=["soc2"])
        # Override pack_binding to empty for this specific request.
        decision = adapter.intercept_agent_task({
            "taskDescription": "do something",
            "packBinding": [],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# intercept_agent_task
# ---------------------------------------------------------------------------

class TestInterceptAgentTask:
    def test_p_replit_08_clean_task_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_agent_task({
            "taskDescription": "Build a Flask REST API with JWT auth",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_09_empty_description_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_agent_task({
            "taskDescription": "",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-agent-task-description-required" in decision.reason

    def test_p_replit_10_whitespace_description_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_agent_task({
            "taskDescription": "   ",
            "packBinding": ["soc2"],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# intercept_sandbox_code_execution
# ---------------------------------------------------------------------------

class TestInterceptSandboxCodeExecution:
    def test_p_replit_11_clean_code_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_sandbox_code_execution({
            "code": "x = [i**2 for i in range(10)]",
            "language": "python",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_12_egress_non_minor_allow_with_note(self):
        adapter = _adapter(_transport(), user_is_minor=False)
        decision = adapter.intercept_sandbox_code_execution({
            "code": 'const res = await fetch("https://api.example.com");',
            "language": "javascript",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_13_egress_urllib_minor_denied(self):
        adapter = _adapter(_transport(), user_is_minor=True)
        decision = adapter.intercept_sandbox_code_execution({
            "code": "import urllib.request; urllib.request.urlopen('http://example.com')",
            "language": "python",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-sandbox-network-egress-blocked-for-minor" in decision.reason

    def test_p_replit_14_egress_requests_minor_denied(self):
        adapter = _adapter(_transport(), user_is_minor=True)
        decision = adapter.intercept_sandbox_code_execution({
            "code": "import requests; requests.get('https://example.com')",
            "language": "python",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_p_replit_15_no_egress_minor_allow(self):
        adapter = _adapter(_transport(), user_is_minor=True)
        decision = adapter.intercept_sandbox_code_execution({
            "code": "result = sum(range(100))",
            "language": "python",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# intercept_file_system_mutation
# ---------------------------------------------------------------------------

class TestInterceptFileSystemMutation:
    def test_p_replit_16_files_below_cap_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_file_system_mutation({
            "files": [f"src/file{i}.py" for i in range(10)],
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_17_files_at_cap_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_file_system_mutation({
            "files": [f"src/file{i}.py" for i in range(25)],
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_18_files_exceeding_cap_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_file_system_mutation({
            "files": [f"src/file{i}.py" for i in range(26)],
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "blast-radius" in decision.reason

    def test_p_replit_19_custom_cap_respected(self):
        adapter = _adapter(_transport(), multi_file_edit_cap=5)
        decision = adapter.intercept_file_system_mutation({
            "files": [f"src/file{i}.py" for i in range(6)],
            "packBinding": ["soc2"],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# intercept_package_install
# ---------------------------------------------------------------------------

class TestInterceptPackageInstall:
    def test_p_replit_20_normal_package_allow(self):
        adapter = _adapter(_transport(), user_tier="individual")
        decision = adapter.intercept_package_install({
            "packageName": "requests",
            "manager": "pip",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_21_minor_student_denied(self):
        adapter = _adapter(_transport(), user_is_minor=True, user_tier="student")
        decision = adapter.intercept_package_install({
            "packageName": "numpy",
            "manager": "pip",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-package-install-not-permitted-minor-student" in decision.reason

    def test_p_replit_22_minor_non_student_allow(self):
        """Minor alone (without student tier) does not block package install."""
        adapter = _adapter(_transport(), user_is_minor=True, user_tier="individual")
        decision = adapter.intercept_package_install({
            "packageName": "lodash",
            "manager": "npm",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_23_allow_package_install_false_denied(self):
        adapter = _adapter(_transport(), allow_package_install=False)
        decision = adapter.intercept_package_install({
            "packageName": "express",
            "manager": "npm",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "allow_package_install" in decision.reason

    def test_p_replit_24_package_in_allow_list_allow(self):
        adapter = _adapter(
            _transport(),
            package_install_allow_list=["express", "lodash", "axios"],
        )
        decision = adapter.intercept_package_install({
            "packageName": "lodash",
            "manager": "npm",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_25_package_not_in_allow_list_denied_with_name(self):
        """PT-ADAPT-REPLIT-6: offending package name must appear in denial reason."""
        adapter = _adapter(
            _transport(),
            package_install_allow_list=["express", "lodash"],
        )
        decision = adapter.intercept_package_install({
            "packageName": "malicious-pkg",
            "manager": "npm",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-package-install-not-in-allowlist" in decision.reason
        # PT-ADAPT-REPLIT-6: the offending package name must appear (it is not a secret).
        assert "malicious-pkg" in decision.reason

    def test_p_replit_26_typosquat_long_name_require_approval(self):
        adapter = _adapter(_transport())
        long_name = "a" * 41
        decision = adapter.intercept_package_install({
            "packageName": long_name,
            "manager": "npm",
            "packBinding": ["soc2"],
        })
        assert decision.requires_approval

    def test_p_replit_27_typosquat_suspicious_punctuation(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_package_install({
            "packageName": "valid---pkg",
            "manager": "npm",
            "packBinding": ["soc2"],
        })
        assert decision.requires_approval


# ---------------------------------------------------------------------------
# intercept_deployment
# ---------------------------------------------------------------------------

class TestInterceptDeployment:
    def test_p_replit_28_minor_denied_with_correct_reason(self):
        """PT-ADAPT-REPLIT-4: minor user => DENY with replit-deployment-not-permitted-minor."""
        adapter = _adapter(_transport(), user_is_minor=True, user_tier="individual")
        decision = adapter.intercept_deployment({
            "target": "production",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-deployment-not-permitted-minor" in decision.reason

    def test_p_replit_29_student_denied(self):
        adapter = _adapter(_transport(), user_tier="student")
        decision = adapter.intercept_deployment({
            "target": "production",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-deployment-not-permitted-student" in decision.reason

    def test_p_replit_30_non_deployments_no_opt_in_denied(self):
        adapter = _adapter(_transport(), deployment_mode="replit-cloud")
        decision = adapter.intercept_deployment({
            "target": "production",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-deployment-not-permitted-mode" in decision.reason

    def test_p_replit_31_replit_deployments_mode_allow(self):
        adapter = _adapter(_transport(), deployment_mode="replit-deployments", user_tier="team-member")
        decision = adapter.intercept_deployment({
            "target": "production",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_32_cloud_with_allow_deployment_allow(self):
        adapter = _adapter(
            _transport(),
            deployment_mode="replit-cloud",
            allow_deployment=True,
            user_tier="admin",
        )
        decision = adapter.intercept_deployment({
            "target": "production",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_33_replit_teams_no_opt_in_denied(self):
        adapter = _adapter(_transport(), deployment_mode="replit-teams", user_tier="team-member")
        decision = adapter.intercept_deployment({
            "target": "production",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_p_replit_34_minor_overrides_deployments_mode(self):
        """Minor flag overrides even replit-deployments mode."""
        adapter = _adapter(
            _transport(),
            deployment_mode="replit-deployments",
            user_is_minor=True,
            user_tier="individual",
        )
        decision = adapter.intercept_deployment({
            "target": "production",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-deployment-not-permitted-minor" in decision.reason


# ---------------------------------------------------------------------------
# intercept_secret_access
# ---------------------------------------------------------------------------

class TestInterceptSecretAccess:
    def test_p_replit_35_minor_denied(self):
        """PT-ADAPT-REPLIT-5: minor => DENY with replit-secret-access-not-permitted."""
        adapter = _adapter(_transport(), user_is_minor=True, user_tier="individual")
        decision = adapter.intercept_secret_access({
            "secretName": "DATABASE_URL",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-secret-access-not-permitted" in decision.reason

    def test_p_replit_36_default_deny_without_opt_in(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_secret_access({
            "secretName": "API_KEY",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_p_replit_37_allow_secret_access_true_non_minor_allow(self):
        adapter = _adapter(_transport(), allow_secret_access=True, user_is_minor=False)
        decision = adapter.intercept_secret_access({
            "secretName": "STRIPE_KEY",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_38_allow_secret_access_true_minor_still_denied(self):
        """allow_secret_access=True does NOT override minor guard."""
        adapter = _adapter(
            _transport(),
            allow_secret_access=True,
            user_is_minor=True,
            user_tier="individual",
        )
        decision = adapter.intercept_secret_access({
            "secretName": "STRIPE_KEY",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "replit-secret-access-not-permitted" in decision.reason


# ---------------------------------------------------------------------------
# intercept_database_query
# ---------------------------------------------------------------------------

class TestInterceptDatabaseQuery:
    def test_p_replit_39_clean_select_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_database_query({
            "query": "SELECT id, name FROM users WHERE active = true",
            "dbType": "postgresql",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_40_drop_table_require_approval(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_database_query({
            "query": "DROP TABLE users",
            "dbType": "postgresql",
            "packBinding": ["soc2"],
        })
        assert decision.requires_approval

    def test_p_replit_41_truncate_require_approval(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_database_query({
            "query": "TRUNCATE TABLE audit_logs",
            "dbType": "sqlite",
            "packBinding": ["soc2"],
        })
        assert decision.requires_approval

    def test_p_replit_42_unguarded_delete_require_approval(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_database_query({
            "query": "DELETE FROM sessions",
            "dbType": "replit-db",
            "packBinding": ["soc2"],
        })
        assert decision.requires_approval


# ---------------------------------------------------------------------------
# intercept_chat
# ---------------------------------------------------------------------------

class TestInterceptChat:
    def test_p_replit_43_clean_prompt_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "How do I sort a dictionary in Python?",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_p_replit_44_secret_in_prompt_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "Help me use: sk-ant-api03-xyzabcdef1234567890abcdef1234567890",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_p_replit_45_phi_hipaa_require_approval(self):
        adapter = _adapter(_transport(), pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Show patient records for diagnosis review",
            "packBinding": ["hipaa"],
        })
        assert decision.requires_approval

    def test_p_replit_46_phi_non_hipaa_allow(self):
        adapter = _adapter(_transport(), pack_binding=["soc2"])
        decision = adapter.intercept_chat({
            "promptText": "Show patient records for diagnosis review",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# PT-ADAPT-REPLIT-2: auth token not echoed in output
# ---------------------------------------------------------------------------

class TestAuthTokenRedaction:
    def test_p_replit_47_replit_token_not_in_denial_reason(self):
        """PT-ADAPT-REPLIT-2: Replit auth token detected, raw value not echoed verbatim."""
        adapter = _adapter(_transport())
        # The secret scanner should match the replit_auth pattern and deny.
        decision = adapter.intercept_chat({
            "promptText": "replit_auth_secret=my-super-secret-token-here-abc123",
            "packBinding": ["soc2"],
        })
        # Decision should be DENY due to secret match.
        assert decision.denied
        # The raw token value must NOT appear verbatim in the reason string.
        assert "my-super-secret-token-here-abc123" not in decision.reason


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_p_replit_48_valid_deployment_modes(self):
        assert "replit-cloud" in REPLIT_VALID_DEPLOYMENT_MODES
        assert "replit-teams" in REPLIT_VALID_DEPLOYMENT_MODES
        assert "replit-deployments" in REPLIT_VALID_DEPLOYMENT_MODES
        assert len(REPLIT_VALID_DEPLOYMENT_MODES) == 3

    def test_p_replit_49_baa_eligible_modes(self):
        assert "replit-teams" in REPLIT_BAA_ELIGIBLE_MODES
        assert "replit-deployments" in REPLIT_BAA_ELIGIBLE_MODES
        assert "replit-cloud" not in REPLIT_BAA_ELIGIBLE_MODES

    def test_p_replit_50_valid_user_tiers(self):
        assert "student" in REPLIT_VALID_USER_TIERS
        assert "individual" in REPLIT_VALID_USER_TIERS
        assert "team-member" in REPLIT_VALID_USER_TIERS
        assert "admin" in REPLIT_VALID_USER_TIERS
