"""Tests for Semantic Kernel governance integration (B2-03).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 -- PHI in function result triggers output classifier
3. PHI ingress refusal -- exfiltration scan on function args
4. Provider compliance -- unapproved model blocks llm_call
5. Subscription gate -- plugin allowlist denies unlisted plugin
6. Audit chain append -- each hook produces canonical event

SK-specific additional tests:
  - Memory plugin reads routed to REQUIRE_APPROVAL
  - MCP plugin invocations routed to REQUIRE_APPROVAL
  - Skill delegation governed via check_skill_delegation()
  - InvokePromptAsync path intercepted (is_prompt_invocation=True)
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.semantic_kernel import (
    SemanticKernelGovernance,
    SKGovernanceFilterShim,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-sk-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-sk-002"}
APPROVAL = {"decision": "REQUIRE_APPROVAL", "reason": "Needs sign-off", "auditId": "aud-sk-003"}

_ALLOWED_PLUGINS = ["MathPlugin", "TextPlugin", "WebSearchPlugin"]
_APPROVED_MODELS = ["gpt-4o", "gpt-4o-mini"]


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    allowed_plugins: list[str] | None = None,
    approved_models: list[str] | None = None,
) -> SemanticKernelGovernance:
    client = make_client(transport, enforce=enforce)
    return SemanticKernelGovernance(
        client=client,
        allowed_plugins=allowed_plugins if allowed_plugins is not None else _ALLOWED_PLUGINS,
        sensitive_functions=["DataPlugin.query_db", "AdminPlugin.delete"],
        memory_plugin_names=["MemoryPlugin", "SemanticMemory"],
        approved_models=approved_models if approved_models is not None else _APPROVED_MODELS,
        sensitive_arg_keys=["query", "input"],
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestSemanticKernelHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        assert decision.allowed
        assert "sess-001" in adapter._sessions

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        decision = adapter.tool_call("sess-001", "MathPlugin.add", {"a": 1, "b": 2})
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("sess-001", "MathPlugin.add", {"a": 1, "b": 2})
        adapter.tool_result("sess-001", "MathPlugin.add", "3", success=True)
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.llm_call(
            "sess-001", "gpt-4o", messages=[{"role": "user", "content": "Hello"}]
        )
        assert decision.allowed

    def test_llm_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        adapter.llm_call("sess-001", "gpt-4o", messages=[])
        adapter.llm_result("sess-001", "gpt-4o", "Clean response text.")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_clean(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        adapter.agent_end("sess-001", success=True)
        assert "sess-001" not in adapter._sessions

    def test_full_workflow_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        adapter.tool_call("sess-001", "WebSearchPlugin.search", {"query": "AI governance"})
        adapter.tool_result("sess-001", "WebSearchPlugin.search", "search results", success=True)
        adapter.llm_call("sess-001", "gpt-4o", [{"role": "user", "content": "summarize"}])
        adapter.llm_result("sess-001", "gpt-4o", "Summary here.")
        adapter.agent_end("sess-001", success=True)


# ---------------------------------------------------------------------------
# 2. Secret leak / PHI in function result -- output classifier
# ---------------------------------------------------------------------------

class TestSemanticKernelSecretLeak:
    def test_phi_in_function_result_flags_output_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("sess-001", "WebSearchPlugin.search", {"query": "patients"})
        adapter.tool_result(
            "sess-001",
            "WebSearchPlugin.search",
            "patient_id=12345, ssn=123-45-6789",
            success=True,
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_function_result_marks_report_failure(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("sess-001", "TextPlugin.transform", {"query": "test"})
        adapter.tool_result(
            "sess-001", "TextPlugin.transform", "npi=1234567890 mrn=ABC", success=True
        )
        assert any(r["success"] is False for r in reported)

    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        adapter.llm_call("sess-001", "gpt-4o", [])
        adapter.llm_result("sess-001", "gpt-4o", "Patient dob: 1980-01-15 has been processed.")
        captured = capsys.readouterr()
        assert "PHI" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- exfiltration scan on function args
# ---------------------------------------------------------------------------

class TestSemanticKernelPhiIngress:
    def test_phi_in_query_arg_denied(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        decision = adapter.tool_call(
            "sess-001",
            "WebSearchPlugin.search",
            {"query": "ssn=123-45-6789"},
        )
        assert decision.denied

    def test_phi_in_input_arg_denied(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.tool_call(
            "sess-001",
            "TextPlugin.process",
            {"input": "patient_id=99 dob=2000-01-01"},
        )
        assert decision.denied

    def test_clean_args_pass(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.tool_call(
            "sess-001",
            "MathPlugin.add",
            {"a": 5, "b": 3},
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved model blocks llm_call
# ---------------------------------------------------------------------------

class TestSemanticKernelProviderCompliance:
    def test_unapproved_model_denied_at_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            "sess-001", pack_binding=["hipaa"], model="unapproved-model-xyz"
        )
        assert decision.denied

    def test_unapproved_model_denied_at_llm_call(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.llm_call(
            "sess-001",
            "claude-opus-4-model",
            messages=[{"role": "user", "content": "hello"}],
        )
        assert decision.denied

    def test_approved_model_passes_llm_call(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.llm_call(
            "sess-001",
            "gpt-4o-mini",
            messages=[{"role": "user", "content": "hello"}],
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 5. Subscription gate -- plugin allowlist denies unlisted plugin
# ---------------------------------------------------------------------------

class TestSemanticKernelSubscriptionGate:
    def test_unlisted_plugin_denied(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.tool_call(
            "sess-001",
            "UnknownPlugin.some_fn",
            {"input": "data"},
        )
        assert decision.denied
        assert "UnknownPlugin" in decision.reason

    def test_empty_pack_binding_denied_at_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("sess-001", pack_binding=[], model="gpt-4o")
        assert decision.denied

    def test_memory_plugin_read_requires_approval(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.tool_call(
            "sess-001",
            "MemoryPlugin.recall",
            {"query": "prior context"},
            is_memory_read=True,
        )
        assert decision.requires_approval

    def test_sensitive_function_requires_approval(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.tool_call(
            "sess-001",
            "DataPlugin.query_db",
            {"input": "SELECT 1"},
        )
        assert decision.requires_approval

    def test_mcp_plugin_requires_approval(self):
        # Any plugin named with mcp_ prefix is treated as an MCP plugin
        adapter = _adapter(_transport(), allowed_plugins=["mcp_github"])
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        decision = adapter.tool_call(
            "sess-001",
            "mcp_github.list_repos",
            {"input": "owner=connexum"},
        )
        assert decision.requires_approval


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip
# ---------------------------------------------------------------------------

class TestSemanticKernelAuditChain:
    def test_tool_result_uses_audit_id_from_tool_call(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("sess-001", "MathPlugin.add", {"a": 1, "b": 2})
        adapter.tool_result("sess-001", "MathPlugin.add", "3", success=True)
        assert len(reported) >= 1
        assert reported[0]["auditId"] == "aud-sk-001"
        assert reported[0]["success"] is True

    def test_llm_result_uses_audit_id_from_llm_call(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        adapter.llm_call("sess-001", "gpt-4o", [{"role": "user", "content": "hi"}])
        adapter.llm_result("sess-001", "gpt-4o", "Hello!")
        assert len(reported) >= 1
        assert reported[0]["auditId"] == "aud-sk-001"

    def test_agent_end_fires_check_action(self):
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        adapter.agent_end("sess-001", success=True)
        action_calls = [c for c in calls if "check-action" in c]
        assert len(action_calls) >= 2  # agent_start + agent_end

    def test_skill_delegation_approved(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        decision = adapter.check_skill_delegation(
            session_id="sess-001",
            caller_plugin="MathPlugin",
            caller_function="add",
            target_plugin="TextPlugin",
            target_function="format",
        )
        assert decision.allowed or decision.requires_approval

    def test_skill_delegation_to_sensitive_function_requires_approval(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.check_skill_delegation(
            session_id="sess-001",
            caller_plugin="MathPlugin",
            caller_function="compute",
            target_plugin="DataPlugin",
            target_function="query_db",
        )
        assert decision.requires_approval

    def test_filter_shim_instantiation(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], model="gpt-4o")
        shim = adapter.to_function_invocation_filter()
        assert isinstance(shim, SKGovernanceFilterShim)
        assert shim._adapter is adapter
