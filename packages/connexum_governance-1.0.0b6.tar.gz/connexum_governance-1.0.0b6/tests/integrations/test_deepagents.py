"""Tests for deepagents governance integration (B2-07).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 -- PHI in tool result flags output classifier
3. PHI ingress refusal -- exfiltration scan on tool args
4. Provider compliance -- unapproved model blocked at llmCall event
5. Subscription gate -- empty pack binding denied
6. Audit chain append -- each hook produces canonical event

deepagents-specific additional tests:
  - Sub-agent spawn pack inheritance (child cannot escalate above parent)
  - No-delegation pack filtering
  - Sub-agent spawn with empty effective binding raises UnboundDataError
  - Todo-list PHI classification
  - Context summarization distilled-PHI detection
  - wrap_webhook validates required fields
  - policy_bridge routes to callback
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.deepagents import (
    DeepAgentsGovernance,
    DeepAgentsUnboundDataError,
    DeepAgentsPolicyBridge,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-da-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-da-002"}

_APPROVED_MODELS = ["gpt-4o", "claude-haiku-4-5"]


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    no_delegation_packs: list[str] | None = None,
    approved_models: list[str] | None = None,
) -> DeepAgentsGovernance:
    client = make_client(transport, enforce=enforce)
    return DeepAgentsGovernance(
        client=client,
        no_delegation_packs=no_delegation_packs or [],
        approved_models=approved_models if approved_models is not None else _APPROVED_MODELS,
        sensitive_tools=["exec_code"],
        sensitive_arg_keys=["query", "content"],
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestDeepAgentsHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("agent-1", pack_binding=["hipaa"], model="gpt-4o")
        assert decision.allowed

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call("agent-1", "web_search", {"query": "governance"}, pack_binding=["hipaa"])
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_call("agent-1", "web_search", {"query": "docs"}, pack_binding=["hipaa"])
        adapter.tool_result("agent-1", "web_search", "Clean results", success=True, pack_binding=["hipaa"])
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call("agent-1", "gpt-4o", messages=[], pack_binding=["hipaa"])
        assert decision.allowed

    def test_llm_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_call("agent-1", "gpt-4o", messages=[], pack_binding=["hipaa"])
        adapter.llm_result("agent-1", "gpt-4o", "Clean response.", pack_binding=["hipaa"])
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_end("agent-1", success=True, pack_binding=["hipaa"])
        assert decision.allowed

    def test_full_event_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("agent-1", pack_binding=["hipaa"], model="gpt-4o")
        adapter.tool_call("agent-1", "search", {"query": "news"}, pack_binding=["hipaa"])
        adapter.tool_result("agent-1", "search", "results", success=True, pack_binding=["hipaa"])
        adapter.llm_call("agent-1", "gpt-4o", [], pack_binding=["hipaa"])
        adapter.llm_result("agent-1", "gpt-4o", "response", pack_binding=["hipaa"])
        adapter.agent_end("agent-1", success=True)


# ---------------------------------------------------------------------------
# 2. Secret leak / PHI in tool result
# ---------------------------------------------------------------------------

class TestDeepAgentsSecretLeak:
    def test_phi_in_tool_result_flags_output_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "agent-1", "db_query", "patient_id=12345, ssn=123-45-6789",
            success=True, pack_binding=["soc2"]
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_call("agent-1", "gpt-4o", [], pack_binding=["hipaa"])
        adapter.llm_result(
            "agent-1", "gpt-4o",
            "Patient dob: 1980-01-15 is being processed.",
            pack_binding=["hipaa"]
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- exfiltration scan on tool args
# ---------------------------------------------------------------------------

class TestDeepAgentsPhiIngress:
    def test_phi_in_content_arg_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "agent-1",
            "send_data",
            {"content": "Patient SSN: 123-45-6789"},
            pack_binding=["soc2"],
        )
        assert decision.denied

    def test_phi_in_query_arg_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "agent-1",
            "search",
            {"query": "ssn=123-45-6789"},
            pack_binding=["hipaa"],
        )
        assert decision.denied

    def test_clean_args_pass(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "agent-1",
            "search",
            {"query": "AI governance"},
            pack_binding=["hipaa"],
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved model blocked
# ---------------------------------------------------------------------------

class TestDeepAgentsProviderCompliance:
    def test_unapproved_model_denied_at_llm_call(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "agent-1", "unapproved-model-xyz", [],
            pack_binding=["hipaa"]
        )
        assert decision.denied
        assert "unapproved-model-xyz" in decision.reason

    def test_approved_model_passes(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "agent-1", "claude-haiku-4-5", [],
            pack_binding=["hipaa"]
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 5. Subscription gate -- empty pack binding denied
# ---------------------------------------------------------------------------

class TestDeepAgentsSubscriptionGate:
    def test_missing_pack_binding_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("agent-1", pack_binding=[], model="gpt-4o")
        assert decision.denied
        assert "pack binding" in decision.reason.lower()

    def test_missing_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call("agent-1", "search", {"query": "test"}, pack_binding=[])
        assert decision.denied

    def test_unknown_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="Unknown deepagents event type"):
            adapter.emit_event("unknownEvent", {"agentId": "agent-1", "packBinding": ["hipaa"]})

    def test_wrap_webhook_missing_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({"agentId": "agent-1"})

    def test_wrap_webhook_missing_agent_id_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({"eventType": "agentStart"})


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip
# ---------------------------------------------------------------------------

class TestDeepAgentsAuditChain:
    def test_tool_call_and_result_audit_round_trip(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.tool_call("agent-1", "search", {"query": "docs"}, pack_binding=["hipaa"])
        adapter.tool_result("agent-1", "search", "results", success=True, pack_binding=["hipaa"])
        # report_result should have been called
        assert len(reported) >= 1

    def test_emit_event_forwards_to_governance_api(self):
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.emit_event("agentStart", {
            "agentId": "agent-1",
            "packBinding": ["hipaa"],
            "model": "gpt-4o",
        })
        assert any("check-action" in c for c in calls)

    def test_wrap_webhook_forwards_valid_payload(self):
        calls: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append({"path": request.url.path, "body": json.loads(request.content)})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "agent-1",
            "toolName": "search",
            "args": {},
            "packBinding": ["hipaa"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# deepagents-specific: sub-agent spawn pack inheritance
# ---------------------------------------------------------------------------

class TestDeepAgentsSubAgentSpawn:
    def test_child_cannot_escalate_above_parent(self):
        adapter = _adapter(_transport())
        result = adapter.check_sub_agent_spawn(
            parent_agent_id="parent",
            child_agent_id="child",
            parent_pack_binding=["hipaa", "soc2"],
            requested_child_pack_binding=["hipaa"],  # subset of parent
        )
        assert "hipaa" in result["effective_pack_binding"]
        assert "soc2" not in result["effective_pack_binding"]

    def test_child_cannot_request_pack_parent_does_not_have(self):
        adapter = _adapter(_transport())
        result = adapter.check_sub_agent_spawn(
            parent_agent_id="parent",
            child_agent_id="child",
            parent_pack_binding=["soc2"],
            requested_child_pack_binding=["hipaa", "soc2"],  # hipaa escalation attempt
        )
        assert "hipaa" not in result["effective_pack_binding"]
        assert "soc2" in result["effective_pack_binding"]

    def test_no_delegation_pack_filtered(self):
        adapter = _adapter(_transport(), no_delegation_packs=["strict-hipaa"])
        result = adapter.check_sub_agent_spawn(
            parent_agent_id="parent",
            child_agent_id="child",
            parent_pack_binding=["strict-hipaa", "soc2"],
            requested_child_pack_binding=["strict-hipaa", "soc2"],
        )
        assert "strict-hipaa" not in result["effective_pack_binding"]
        assert "soc2" in result["effective_pack_binding"]

    def test_empty_effective_binding_raises(self):
        adapter = _adapter(_transport(), no_delegation_packs=["hipaa"])
        with pytest.raises(DeepAgentsUnboundDataError):
            adapter.check_sub_agent_spawn(
                parent_agent_id="parent",
                child_agent_id="child",
                parent_pack_binding=["hipaa"],
                requested_child_pack_binding=["hipaa"],
            )

    def test_todo_list_phi_classification(self, capsys):
        adapter = _adapter(_transport())
        items = [
            {"description": "Process patient ssn=123-45-6789", "metadata": {}},
            {"description": "Send quarterly report", "metadata": {}},
        ]
        classified = adapter.check_todo_list("agent-1", items, pack_binding=["hipaa"])
        phi_items = [c for c in classified if c["data_class"] == "PHI"]
        clean_items = [c for c in classified if c["data_class"] == "CLEAN"]
        assert len(phi_items) == 1
        assert len(clean_items) == 1
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_summarization_phi_detection(self, capsys):
        adapter = _adapter(_transport())
        result = adapter.check_summarization(
            "agent-1",
            "Summary: Patient patient_id=ABC received treatment on dob=1980-01-15",
            pack_binding=["hipaa"],
        )
        assert result["has_phi_content"] is True
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_summarization_clean_text(self, capsys):
        adapter = _adapter(_transport())
        result = adapter.check_summarization(
            "agent-1",
            "Meeting summary: Discussed quarterly roadmap and product milestones.",
            pack_binding=["soc2"],
        )
        assert result["has_phi_content"] is False

    def test_policy_bridge_uses_callback(self):
        called: list[dict] = []

        def callback(event_type: str, payload: dict) -> Any:
            called.append({"event_type": event_type, "payload": payload})
            from connexum_governance.models import GovernanceDecision, DecisionType
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="Python policy allowed",
                audit_id="py-policy-001",
            )

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(["hipaa"], callback)
        decision = bridge.decide("agentStart", {"agentId": "agent-1", "model": "gpt-4o"})
        assert decision.allowed
        assert called[0]["event_type"] == "agentStart"
