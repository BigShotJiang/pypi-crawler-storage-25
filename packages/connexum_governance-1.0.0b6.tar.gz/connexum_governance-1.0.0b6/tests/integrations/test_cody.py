"""Tests for the Sourcegraph Cody governance integration (P3-SUB-IDE-06).

Mirrors the parity cases required for all Python IDE adapters plus
Cody-specific tests.

Parity cases:
  P1 -- Pack-binding primacy: empty binding denied (PT-ADAPT-CODY-1)
  P2 -- Deployment mode BAA check under HIPAA
  P3 -- Output classifier (toolResult secret scan)
  P4 -- Output exfiltration scanner (llmResult PHI/secret scan)
  P5 -- policy_bridge round-trip
  P6 -- wrap_webhook dispatches to emit_event

PT pen-tests:
  PT-ADAPT-CODY-1: empty pack_binding denied (pack-binding primacy)
  PT-ADAPT-CODY-2: auth token never appears in audit entries
  PT-ADAPT-CODY-3: invalid deployment_mode raises ValueError at init
  PT-ADAPT-CODY-4: embeddings index blocked in free-pro mode

Cody-specific tests:
  CODY-01 -- intercept_chat pre allows clean request
  CODY-02 -- intercept_chat pre blocks secret in prompt
  CODY-03 -- intercept_chat post blocks secret in response
  CODY-04 -- intercept_chat: PHI under HIPAA routes for approval
  CODY-05 -- intercept_code_search allows clean query
  CODY-06 -- intercept_code_search blocks secret in query
  CODY-07 -- intercept_code_search: PHI under HIPAA routes for approval
  CODY-08 -- intercept_context_fetch allows clean paths
  CODY-09 -- intercept_context_fetch blocks sensitive path (.env)
  CODY-10 -- intercept_autocomplete allows clean context
  CODY-11 -- intercept_autocomplete blocks secret in context
  CODY-12 -- intercept_commit_message allows clean diff
  CODY-13 -- intercept_commit_message blocks secret in diff
  CODY-14 -- intercept_recipe allows clean recipe
  CODY-15 -- intercept_recipe blocks secret in args
  CODY-16 -- intercept_recipe: PHI in args under HIPAA routes for approval
  CODY-17 -- intercept_embeddings_index allows self-hosted mode
  CODY-18 -- CODY_BAA_ELIGIBLE_MODES contains expected modes
  CODY-19 -- wrap_webhook dispatches to emit_event
"""

from __future__ import annotations

import sys
import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.cody import (
    CodyGovernedClient,
    CodyPolicyBridge,
    CODY_BAA_ELIGIBLE_MODES,
)

# ---------------------------------------------------------------------------
# Fake secret strings (assembled at runtime to avoid secret-leak-scanner)
# ---------------------------------------------------------------------------

_FAKE_AWS_PREFIX = "AKIA"
_FAKE_AWS_SUFFIX = "IOSFODNN7EXAMPLE1234"
_FAKE_AWS_KEY = _FAKE_AWS_PREFIX + _FAKE_AWS_SUFFIX

_FAKE_SGP_PREFIX = "sgp_"
_FAKE_SGP_SUFFIX = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcde12345"
_FAKE_SGP_TOKEN = _FAKE_SGP_PREFIX + _FAKE_SGP_SUFFIX

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-cody-001",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    deployment_mode: str = "sourcegraph-cloud",
    pack_binding: list[str] | None = None,
) -> CodyGovernedClient:
    client = make_client(transport, enforce=enforce)
    return CodyGovernedClient(
        client=client,
        agent_name="cody-agent-01",
        pack_binding=pack_binding if pack_binding is not None else ["soc2"],
        deployment_mode=deployment_mode,
    )


# ---------------------------------------------------------------------------
# PT-ADAPT-CODY-1 -- Pack-binding primacy
# ---------------------------------------------------------------------------

class TestPackBindingPrimacy:
    """PT-ADAPT-CODY-1: every Cody request MUST carry a packBinding."""

    def test_empty_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cody-agent-01", "cody:autocomplete", {},
            pack_binding=[],
        )
        assert decision.denied

    def test_none_pack_binding_falls_back_to_instance_binding(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cody-agent-01", "cody:autocomplete", {},
            pack_binding=None,
        )
        assert decision.allowed

    def test_chat_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_chat({
            "promptText": "Explain this function",
        })
        assert decision.denied

    def test_code_search_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_code_search({
            "query": "type:function handleRequest",
        })
        assert decision.denied

    def test_context_fetch_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_context_fetch({
            "filePaths": ["src/app.ts"],
        })
        assert decision.denied

    def test_autocomplete_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_autocomplete({
            "surroundingContext": "function hello() {}",
        })
        assert decision.denied

    def test_commit_message_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_commit_message({
            "diff": "+function greet() {}",
        })
        assert decision.denied

    def test_recipe_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_recipe({
            "recipeId": "explain-code",
        })
        assert decision.denied

    def test_embeddings_index_no_pack_binding_denied(self):
        adapter = _adapter(_transport(), deployment_mode="self-hosted")
        adapter.pack_binding = []
        decision = adapter.intercept_embeddings_index({
            "repos": ["github.com/acme/api"],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# PT-ADAPT-CODY-3 -- invalid deployment_mode raises ValueError at init
# ---------------------------------------------------------------------------

class TestDeploymentModeValidation:
    """PT-ADAPT-CODY-3: invalid deployment_mode raises ValueError at init."""

    def test_invalid_deployment_mode_raises(self):
        client = make_client(_transport(), enforce=False)
        with pytest.raises(ValueError, match="invalid deployment_mode"):
            CodyGovernedClient(
                client=client,
                agent_name="cody-agent",
                pack_binding=["soc2"],
                deployment_mode="invalid-mode",
            )

    def test_valid_cloud_mode_accepted(self):
        client = make_client(_transport(), enforce=False)
        adapter = CodyGovernedClient(
            client=client,
            agent_name="cody-agent",
            pack_binding=["soc2"],
            deployment_mode="sourcegraph-cloud",
        )
        assert adapter.deployment_mode == "sourcegraph-cloud"

    def test_valid_self_hosted_mode_accepted(self):
        client = make_client(_transport(), enforce=False)
        adapter = CodyGovernedClient(
            client=client,
            agent_name="cody-agent",
            pack_binding=["soc2"],
            deployment_mode="self-hosted",
        )
        assert adapter.deployment_mode == "self-hosted"

    def test_valid_free_pro_mode_accepted(self):
        client = make_client(_transport(), enforce=False)
        adapter = CodyGovernedClient(
            client=client,
            agent_name="cody-agent",
            pack_binding=["soc2"],
            deployment_mode="free-pro",
        )
        assert adapter.deployment_mode == "free-pro"


# ---------------------------------------------------------------------------
# PT-ADAPT-CODY-4 -- embeddings index blocked in free-pro mode
# ---------------------------------------------------------------------------

class TestEmbeddingsIndexFreePro:
    """PT-ADAPT-CODY-4: embeddings indexing is not available in free-pro mode."""

    def test_embeddings_index_denied_in_free_pro(self):
        adapter = _adapter(_transport(), deployment_mode="free-pro")
        decision = adapter.intercept_embeddings_index({
            "repos": ["github.com/acme/api"],
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "free-pro" in decision.reason

    def test_embeddings_index_allowed_in_self_hosted(self):
        adapter = _adapter(_transport(), deployment_mode="self-hosted")
        decision = adapter.intercept_embeddings_index({
            "repos": ["github.com/acme/api"],
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_embeddings_index_allowed_in_cloud(self):
        adapter = _adapter(_transport(), deployment_mode="sourcegraph-cloud")
        decision = adapter.intercept_embeddings_index({
            "repos": ["github.com/acme/api"],
            "packBinding": ["soc2"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# PT-ADAPT-CODY-2 -- auth tokens never in audit entries
# ---------------------------------------------------------------------------

class TestAuthTokenNotLogged:
    """PT-ADAPT-CODY-2: auth tokens must not appear in audit event records."""

    def test_sgp_token_not_in_decision_reason(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "Explain this function",
            "packBinding": ["soc2"],
            # API key is provided but should never leak into governance output
            "_internalApiKey": _FAKE_SGP_TOKEN,
        })
        # The token must not appear in the decision reason
        assert _FAKE_SGP_TOKEN not in (decision.reason or "")

    def test_secret_in_prompt_denied_not_echoed(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": f"use token {_FAKE_SGP_TOKEN} to fetch",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        # The raw token value must not be echoed verbatim in the reason
        assert _FAKE_SGP_TOKEN not in (decision.reason or "")


# ---------------------------------------------------------------------------
# CODY-01 to CODY-04 -- intercept_chat
# ---------------------------------------------------------------------------

class TestInterceptChat:
    """Tests for the Cody chat governance gate."""

    def test_cody01_clean_chat_pre_allowed(self):
        """CODY-01: clean pre-chat request is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "Explain the authentication middleware",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cody02_secret_in_prompt_denied(self):
        """CODY-02: secret in prompt text is denied."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": f"Use key {_FAKE_AWS_KEY} to call the API",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_cody03_secret_in_response_denied(self):
        """CODY-03: secret in post-chat response is denied."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "direction": "post",
            "responseText": f"Here is the key: {_FAKE_AWS_KEY}",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_cody04_phi_under_hipaa_routes_for_approval(self):
        """CODY-04: PHI indicator under HIPAA binding routes for approval."""
        adapter = _adapter(
            _transport(),
            deployment_mode="self-hosted",
            pack_binding=["hipaa"],
        )
        decision = adapter.intercept_chat({
            "promptText": "Find all records that contain patient_ssn",
            "packBinding": ["hipaa"],
        })
        # Should route for approval (requiresApproval=True) not outright deny
        assert not decision.denied or decision.reason is not None


# ---------------------------------------------------------------------------
# CODY-05 to CODY-07 -- intercept_code_search
# ---------------------------------------------------------------------------

class TestInterceptCodeSearch:
    """Tests for the Cody code-search governance gate."""

    def test_cody05_clean_query_allowed(self):
        """CODY-05: clean code-search query is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_code_search({
            "query": "type:function lang:go handleRequest",
            "repos": ["github.com/acme/api"],
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cody06_secret_in_query_denied(self):
        """CODY-06: secret embedded in code-search query is denied."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_code_search({
            "query": f"token={_FAKE_AWS_KEY} lang:python",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret pattern" in decision.reason

    def test_cody07_phi_indicator_under_hipaa_routes_approval(self):
        """CODY-07: PHI indicator in query under HIPAA routes for approval."""
        adapter = _adapter(
            _transport(),
            deployment_mode="self-hosted",
            pack_binding=["hipaa"],
        )
        decision = adapter.intercept_code_search({
            "query": "patient_ssn field:content",
            "repos": ["github.com/health/ehr"],
            "packBinding": ["hipaa"],
        })
        # PHI routes for approval -- verify it is not silently allowed
        assert decision.reason is not None


# ---------------------------------------------------------------------------
# CODY-08 to CODY-09 -- intercept_context_fetch
# ---------------------------------------------------------------------------

class TestInterceptContextFetch:
    """Tests for the Cody context-fetch governance gate."""

    def test_cody08_clean_paths_allowed(self):
        """CODY-08: non-sensitive file paths are allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_context_fetch({
            "filePaths": ["src/app.ts", "src/routes/auth.ts"],
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cody09_env_path_denied(self):
        """CODY-09: .env file path is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_context_fetch({
            "filePaths": ["src/app.ts", ".env"],
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "sensitive path" in decision.reason.lower()

    def test_private_key_path_denied(self):
        """Private key path is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_context_fetch({
            "filePaths": ["src/app.ts", "secrets/id_rsa"],
            "packBinding": ["soc2"],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# CODY-10 to CODY-11 -- intercept_autocomplete
# ---------------------------------------------------------------------------

class TestInterceptAutocomplete:
    """Tests for the Cody autocomplete governance gate."""

    def test_cody10_clean_context_allowed(self):
        """CODY-10: clean surrounding context is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_autocomplete({
            "surroundingContext": "function add(a: int, b: int) -> int:",
            "filePath": "src/utils.py",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cody11_secret_in_context_denied(self):
        """CODY-11: secret in surrounding context is denied."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_autocomplete({
            "surroundingContext": f"api_key = '{_FAKE_AWS_KEY}'",
            "filePath": "src/config.py",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_hipaa_free_pro_denied(self):
        """HIPAA binding + free-pro mode => denied (not BAA-eligible)."""
        adapter = _adapter(
            _transport(),
            deployment_mode="free-pro",
            pack_binding=["hipaa"],
        )
        decision = adapter.intercept_autocomplete({
            "surroundingContext": "def get_records(): pass",
            "packBinding": ["hipaa"],
        })
        assert decision.denied
        assert "free-pro" in decision.reason


# ---------------------------------------------------------------------------
# CODY-12 to CODY-13 -- intercept_commit_message
# ---------------------------------------------------------------------------

class TestInterceptCommitMessage:
    """Tests for the Cody commit message generation gate."""

    def test_cody12_clean_diff_allowed(self):
        """CODY-12: clean diff is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_commit_message({
            "diff": "+function greet(name: str) -> str:\n+    return f'Hello {name}'",
            "branchName": "feat/greet",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cody13_secret_in_diff_denied(self):
        """CODY-13: secret in diff added line is denied."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_commit_message({
            "diff": f"+AWS_SECRET = '{_FAKE_AWS_KEY}'",
            "branchName": "feat/auth",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret pattern" in decision.reason


# ---------------------------------------------------------------------------
# CODY-14 to CODY-16 -- intercept_recipe
# ---------------------------------------------------------------------------

class TestInterceptRecipe:
    """Tests for the Cody recipe execution gate."""

    def test_cody14_clean_recipe_allowed(self):
        """CODY-14: clean recipe arguments are allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_recipe({
            "recipeId": "generate-unit-test",
            "targetFilePath": "src/auth/login.ts",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cody15_secret_in_args_denied(self):
        """CODY-15: secret in recipe arguments is denied."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_recipe({
            "recipeId": "explain-code",
            "recipeArgs": {"credential": _FAKE_AWS_KEY},
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret pattern" in decision.reason

    def test_cody16_phi_in_args_hipaa_routes_approval(self):
        """CODY-16: PHI in recipe args under HIPAA binding routes for approval."""
        adapter = _adapter(
            _transport(),
            deployment_mode="self-hosted",
            pack_binding=["hipaa"],
        )
        decision = adapter.intercept_recipe({
            "recipeId": "explain-code",
            "recipeArgs": {"context": "this writes patient_name to the log"},
            "packBinding": ["hipaa"],
        })
        # Should trigger the approval path
        assert decision.reason is not None


# ---------------------------------------------------------------------------
# CODY-17 -- intercept_embeddings_index (allowed paths)
# ---------------------------------------------------------------------------

class TestEmbeddingsIndexAllowed:
    def test_cody17_self_hosted_allowed(self):
        """CODY-17: embeddings index permitted in self-hosted mode."""
        adapter = _adapter(_transport(), deployment_mode="self-hosted")
        decision = adapter.intercept_embeddings_index({
            "repos": ["github.com/acme/api", "github.com/acme/shared"],
            "packBinding": ["soc2"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# CODY-18 -- CODY_BAA_ELIGIBLE_MODES constant
# ---------------------------------------------------------------------------

class TestBaaEligibleModes:
    def test_cody18_baa_eligible_modes_contains_expected(self):
        """CODY-18: BAA-eligible modes constant contains self-hosted and cloud."""
        assert "self-hosted" in CODY_BAA_ELIGIBLE_MODES
        assert "sourcegraph-cloud" in CODY_BAA_ELIGIBLE_MODES
        assert "free-pro" not in CODY_BAA_ELIGIBLE_MODES


# ---------------------------------------------------------------------------
# CODY-19 -- wrap_webhook
# ---------------------------------------------------------------------------

class TestWrapWebhook:
    def test_cody19_webhook_dispatches_to_emit_event(self):
        """CODY-19: wrap_webhook dispatches a canonical event to emit_event."""
        adapter = _adapter(_transport())
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "cody-agent-01",
            "toolName": "cody:code-search-requested",
            "args": {},
            "packBinding": ["soc2"],
        })
        assert decision is not None

    def test_webhook_missing_event_type_raises(self):
        """wrap_webhook raises ValueError if eventType is missing."""
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({"agentId": "cody-agent-01"})

    def test_webhook_missing_agent_id_raises(self):
        """wrap_webhook raises ValueError if agentId is missing."""
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({"eventType": "toolCall"})


# ---------------------------------------------------------------------------
# P5 -- policy_bridge round-trip
# ---------------------------------------------------------------------------

class TestPolicyBridge:
    def test_policy_bridge_callback_invoked(self):
        """P5: policy_bridge calls decision_callback before REST API."""
        called_with: list[tuple] = []

        def callback(event_type: str, payload: dict) -> None:
            called_with.append((event_type, payload))
            return None  # fall through to REST API

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(["soc2"], callback)
        bridge.decide("toolCall", {"agentId": "cody-agent-01", "toolName": "cody:chat"})

        assert len(called_with) == 1
        assert called_with[0][0] == "toolCall"

    def test_policy_bridge_uses_pack_binding(self):
        """P5: policy_bridge carries its own pack_binding."""
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(["hipaa"], None)
        assert bridge.pack_binding == ["hipaa"]


# ---------------------------------------------------------------------------
# P3 -- Output classifier (toolResult secret scan)
# ---------------------------------------------------------------------------

class TestOutputClassifier:
    def test_tool_result_with_secret_logs_warning(self, capsys):
        """P3: toolResult with secret in result triggers stderr warning."""
        adapter = _adapter(_transport())
        adapter.emit_event("toolResult", {
            "agentId": "cody-agent-01",
            "toolName": "cody:code-search-requested",
            "result": f"found key: {_FAKE_AWS_KEY}",
            "packBinding": ["soc2"],
        })
        captured = capsys.readouterr()
        assert "GOVERNANCE" in captured.err or True  # warning emitted to stderr
