"""Tests for Haystack governance integration (B2-08).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak / PHI in node output -- output classifier
3. PHI ingress refusal -- retriever node PHI detection
4. Provider compliance -- unapproved LLM backend blocks prompt_node_call
5. Subscription gate -- governance server DENY at pipeline_start
6. Audit chain append -- canonical events round-trip
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.haystack import HaystackGovernance
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-hs-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-hs-002"}
SUB_DENY = {
    "decision": "DENY",
    "reason": "Subscription inactive or expired",
    "auditId": "aud-hs-003",
}


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    approved_backends: list[str] | None = None,
) -> HaystackGovernance:
    client = make_client(transport, enforce=enforce)
    return HaystackGovernance(
        client=client,
        approved_backends=approved_backends,
        sensitive_nodes=["admin_node"],
        default_pack_binding=["gdpr"],
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestHaystackHappyPath:
    def test_pipeline_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.pipeline_start(
            "pipe-001",
            "rag_pipeline",
            pack_binding=["gdpr"],
        )
        assert decision.allowed
        assert "pipe-001" in adapter._pipelines

    def test_node_start_allow(self):
        adapter = _adapter(_transport())
        adapter.pipeline_start("pipe-001", "rag_pipeline")
        decision = adapter.node_start(
            "pipe-001", "retriever", "BM25Retriever",
            inputs={"query": "What is AI governance?"},
        )
        assert decision.allowed

    def test_node_end_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.pipeline_start("pipe-001", "rag_pipeline")
        adapter.node_start("pipe-001", "retriever", "Retriever")
        adapter.node_end(
            "pipe-001", "retriever", "Retriever",
            outputs={"documents": [{"content": "AI governance is important."}]},
        )
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_prompt_node_call_allow(self):
        adapter = _adapter(_transport(), approved_backends=["openai", "anthropic"])
        adapter.pipeline_start("pipe-001", "rag_pipeline")
        decision = adapter.prompt_node_call(
            "pipe-001", "generator", "openai", "gpt-4o",
            prompt="Summarize the retrieved documents.",
        )
        assert decision.allowed

    def test_prompt_node_result_clean(self, capsys):
        adapter = _adapter(_transport(), approved_backends=["openai"])
        adapter.pipeline_start("pipe-001", "rag_pipeline")
        adapter.prompt_node_call("pipe-001", "gen", "openai", "gpt-4o", prompt="Summarize")
        adapter.prompt_node_result("pipe-001", "gen", "openai", result="Clean summary.")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_pipeline_end_clean(self):
        adapter = _adapter(_transport())
        adapter.pipeline_start("pipe-001", "rag_pipeline")
        adapter.pipeline_end("pipe-001", success=True, summary="Done")
        assert "pipe-001" not in adapter._pipelines

    def test_full_pipeline_sequence(self):
        adapter = _adapter(_transport(), approved_backends=["openai"])
        adapter.pipeline_start("pipe-full", "medical_rag", pack_binding=["gdpr", "hipaa"])
        adapter.node_start("pipe-full", "retriever", "EmbeddingRetriever", inputs={"query": "AI"})
        adapter.node_end("pipe-full", "retriever", "EmbeddingRetriever", outputs={"docs": []})
        adapter.prompt_node_call("pipe-full", "gen", "openai", "gpt-4o", prompt="Summarize")
        adapter.prompt_node_result("pipe-full", "gen", "openai", result="Summary here.")
        adapter.pipeline_end("pipe-full", success=True)


# ---------------------------------------------------------------------------
# 2. PHI in node output -- output classifier
# ---------------------------------------------------------------------------

class TestHaystackSecretLeak:
    def test_phi_in_node_output_flags_classifier(self, capsys):
        """PHI in node output triggers output classifier warning."""
        adapter = _adapter(_transport())
        adapter.pipeline_start("pipe-g2", "pipeline")
        adapter.node_start("pipe-g2", "retriever", "Retriever")
        adapter.node_end(
            "pipe-g2", "retriever", "Retriever",
            outputs={"content": "Patient SSN: 123-45-6789"},
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_prompt_result_flags_exfiltration(self, capsys):
        """PHI in PromptNode result triggers exfiltration scanner warning."""
        adapter = _adapter(_transport(), approved_backends=["openai"])
        adapter.pipeline_start("pipe-g2b", "pipeline")
        adapter.prompt_node_call("pipe-g2b", "gen", "openai", "gpt-4o", prompt="Summarize")
        adapter.prompt_node_result(
            "pipe-g2b", "gen", "openai",
            result="The patient mrn=XYZ diagnosis=hypertension is treated.",
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_node_output_marks_report_failure(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-g2c", "pipeline")
        adapter.node_start("pipe-g2c", "db", "SQLRetriever")
        adapter.node_end("pipe-g2c", "db", "SQLRetriever", outputs="ssn=123-45-6789")

        assert any(r["success"] is False for r in reported)


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- retriever node detects PHI in inputs
# ---------------------------------------------------------------------------

class TestHaystackPhiIngress:
    def test_retriever_node_phi_in_inputs_flagged(self):
        """PHI in Retriever inputs is flagged in the governance check_action."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-phi", "pipeline")
        adapter.node_start(
            "pipe-phi", "ret", "Retriever",
            inputs={"query": "Patient SSN: 123-45-6789 medical records"},
        )

        # Find the node_start call
        node_calls = [c for c in captured if c.get("input", {}).get("nodeType") == "Retriever"]
        assert len(node_calls) >= 1
        assert node_calls[0]["input"]["phiInInputs"] is True

    def test_non_retriever_node_phi_not_checked(self):
        """Non-retriever nodes do not trigger PHI ingress scan."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-phi2", "pipeline")
        adapter.node_start(
            "pipe-phi2", "preprocessor", "PreProcessor",
            inputs={"text": "SSN: 123-45-6789"},  # PHI present but in non-retriever node
        )

        node_calls = [c for c in captured if c.get("input", {}).get("nodeType") == "PreProcessor"]
        assert len(node_calls) >= 1
        assert node_calls[0]["input"]["phiInInputs"] is False


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved LLM backend
# ---------------------------------------------------------------------------

class TestHaystackProviderCompliance:
    def test_unapproved_backend_denied(self):
        """Backend not in approved_backends is denied at prompt_node_call."""
        adapter = _adapter(_transport(), approved_backends=["openai", "anthropic"])
        adapter.pipeline_start("pipe-backend", "pipeline", pack_binding=["hipaa"])
        decision = adapter.prompt_node_call(
            "pipe-backend", "gen", "cohere", "command-r",
            prompt="Summarize",
        )
        assert decision.denied
        assert "cohere" in decision.reason

    def test_approved_backend_passes(self):
        """Approved backend passes provider compliance check."""
        adapter = _adapter(_transport(), approved_backends=["openai", "anthropic"])
        adapter.pipeline_start("pipe-backend-ok", "pipeline", pack_binding=["hipaa"])
        decision = adapter.prompt_node_call(
            "pipe-backend-ok", "gen", "anthropic", "claude-haiku-4-5",
            prompt="Summarize",
        )
        assert decision.allowed

    def test_no_approved_backends_allows_any(self):
        """When approved_backends=None, all backends are permitted."""
        adapter = _adapter(_transport(), approved_backends=None)
        adapter.pipeline_start("pipe-open", "pipeline")
        decision = adapter.prompt_node_call(
            "pipe-open", "gen", "any-backend", "any-model",
            prompt="Test",
        )
        assert decision.allowed

    def test_pack_binding_forwarded_in_prompt_node_call(self):
        """Pack binding is included in the prompt_node_call governance input."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-pack", "pipeline", pack_binding=["hipaa", "gdpr"])
        adapter.prompt_node_call("pipe-pack", "gen", "openai", "gpt-4o", prompt="Test")

        llm_calls = [c for c in captured if c.get("input", {}).get("backendId") == "openai"]
        assert len(llm_calls) >= 1
        assert "hipaa" in llm_calls[0]["input"]["packBinding"]


# ---------------------------------------------------------------------------
# 5. Subscription gate -- governance server DENY
# ---------------------------------------------------------------------------

class TestHaystackSubscriptionGate:
    def test_pipeline_start_subscription_deny(self):
        """Governance DENY at pipeline_start is returned as denied decision."""
        transport = _transport(**{"/api/v1/governance/check-action": SUB_DENY})
        adapter = _adapter(transport, enforce=False)
        decision = adapter.pipeline_start(
            "pipe-sub",
            "rag_pipeline",
            pack_binding=["gdpr"],
        )
        assert decision.denied
        assert "subscription" in decision.reason.lower() or "inactive" in decision.reason.lower()

    def test_node_start_governance_deny(self):
        """Governance DENY at node_start is returned."""
        transport = _transport(**{"/api/v1/governance/check-action": DENY})
        adapter = _adapter(transport, enforce=False)
        adapter._pipelines["pipe-deny"] = {"pack_binding": ["gdpr"]}
        decision = adapter.node_start("pipe-deny", "retriever", "Retriever")
        assert decision.denied

    def test_eval_mode_pipeline_start_allow(self):
        """eval_mode pipelines are tagged with eval audit path."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-eval", "eval_pipeline", eval_mode=True)

        assert captured[0]["input"]["evalMode"] is True
        assert captured[0]["input"]["auditPath"] == "eval"


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip
# ---------------------------------------------------------------------------

class TestHaystackAuditChain:
    def test_node_end_uses_audit_id_from_node_start(self):
        """audit_id from node_start is used in node_end report_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-chain", "pipeline")
        adapter.node_start("pipe-chain", "retriever", "Retriever")
        adapter.node_end("pipe-chain", "retriever", "Retriever", outputs={"docs": []})

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-hs-001"
        assert reported[0]["success"] is True

    def test_prompt_node_result_uses_audit_id_from_prompt_node_call(self):
        """audit_id from prompt_node_call is used in prompt_node_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-llm-chain", "pipeline")
        adapter.prompt_node_call("pipe-llm-chain", "gen", "openai", "gpt-4o", prompt="Test")
        adapter.prompt_node_result("pipe-llm-chain", "gen", "openai", result="Response text.")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-hs-001"

    def test_pipeline_end_fires_terminal_check_action(self):
        """pipeline_end fires check_action to seal terminal audit event."""
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-end", "pipeline")
        adapter.pipeline_end("pipe-end", success=True)

        action_calls = [c for c in calls if "check-action" in c]
        assert len(action_calls) >= 2

    def test_eval_step_uses_eval_audit_path(self):
        """eval_step fires check_action with auditPath=eval."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.pipeline_start("pipe-eval-step", "eval_pipeline", eval_mode=True)
        adapter.eval_step(
            "pipe-eval-step",
            eval_set_id="eval-set-001",
            metric_name="f1_score",
            result=0.87,
        )

        eval_calls = [c for c in captured if c.get("input", {}).get("metricName") == "f1_score"]
        assert len(eval_calls) == 1
        assert eval_calls[0]["input"]["auditPath"] == "eval"
