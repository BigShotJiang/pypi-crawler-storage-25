"""Tests for Claude Agent SDK governance integration (B2-04).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 -- PHI in tool result triggers output classifier
3. PHI ingress refusal -- exfiltration scan on tool args
4. Provider compliance -- unapproved model blocks llm_call
5. Subscription gate -- governance server DENY at agent_start
6. Audit chain append -- each hook produces canonical event
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.claude_agent_sdk import (
    ClaudeAgentGovernance,
    PhantomAgentError,
    SubscriptionGateError,
    UnboundDataError,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-cas-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-cas-002"}
SUB_DENY = {
    "decision": "DENY",
    "reason": "Subscription inactive or expired",
    "auditId": "aud-cas-003",
}

_REGISTERED = ["agent-alpha"]
_APPROVED_MODELS = ["claude-haiku-4-5", "claude-sonnet-4-6"]


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    registered: list[str] | None = None,
    approved: list[str] | None = None,
) -> ClaudeAgentGovernance:
    client = make_client(transport, enforce=enforce)
    return ClaudeAgentGovernance(
        client=client,
        registered_agents=registered if registered is not None else _REGISTERED,
        approved_models=approved if approved is not None else _APPROVED_MODELS,
        sensitive_tools=["file_write", "bash"],
        sensitive_arg_keys=["query", "content"],
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestClaudeAgentSdkHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            agent_id="agent-alpha",
            pack_binding=["hipaa"],
            model="claude-haiku-4-5",
        )
        assert decision.allowed
        assert "agent-alpha" in adapter._active_agents

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["soc2"], model="claude-haiku-4-5")
        decision = adapter.tool_call("agent-alpha", "web_search", {"query": "governance docs"})
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["soc2"], model="claude-haiku-4-5")
        adapter.tool_call("agent-alpha", "web_search", {"query": "docs"})
        adapter.tool_result("agent-alpha", "web_search", "Clean search results", success=True)
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        decision = adapter.llm_call(
            "agent-alpha",
            "claude-haiku-4-5",
            messages=[{"role": "user", "content": "Hello"}],
        )
        assert decision.allowed

    def test_llm_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        adapter.llm_call("agent-alpha", "claude-haiku-4-5", messages=[])
        adapter.llm_result("agent-alpha", "claude-haiku-4-5", "This is a clean response.")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_clean(self):
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        adapter.agent_end("agent-alpha", success=True, summary="Task complete")
        assert "agent-alpha" not in adapter._active_agents

    def test_full_run_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        adapter.tool_call("agent-alpha", "search", {"query": "news"})
        adapter.tool_result("agent-alpha", "search", "results", success=True)
        adapter.llm_call("agent-alpha", "claude-haiku-4-5", [{"role": "user", "content": "hi"}])
        adapter.llm_result("agent-alpha", "claude-haiku-4-5", "Hello!")
        adapter.agent_end("agent-alpha", success=True)


# ---------------------------------------------------------------------------
# 2. Secret leak / PHI in tool result -- output classifier (G2 equivalent)
# ---------------------------------------------------------------------------

class TestClaudeAgentSdkSecretLeak:
    def test_phi_in_tool_result_flags_output_classifier(self, capsys):
        """Tool result containing PHI triggers output classifier warning."""
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["soc2"], model="claude-haiku-4-5")
        adapter.tool_call("agent-alpha", "db_query", {"query": "SELECT * FROM patients"})
        adapter.tool_result(
            "agent-alpha",
            "db_query",
            "patient_id=12345, ssn=123-45-6789",
            success=True,
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_tool_result_marks_report_failure(self):
        """report_result is called with success=False when PHI detected."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("agent-alpha", pack_binding=["soc2"], model="claude-haiku-4-5")
        adapter.tool_call("agent-alpha", "db", {"query": "SELECT 1"})
        adapter.tool_result("agent-alpha", "db", "npi=1234567890 mrn=ABC", success=True)

        assert any(r["success"] is False for r in reported)

    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        """LLM response with PHI triggers exfiltration scanner warning."""
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        adapter.llm_call("agent-alpha", "claude-haiku-4-5", [])
        adapter.llm_result(
            "agent-alpha",
            "claude-haiku-4-5",
            "The patient dob: 1980-01-15 has been processed.",
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- exfiltration scan on tool args
# ---------------------------------------------------------------------------

class TestClaudeAgentSdkPhiIngress:
    def test_tool_call_with_phi_in_content_denied(self):
        """PHI in tool args triggers G5/G7 egress guard -- call denied."""
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["soc2"], model="claude-haiku-4-5")
        decision = adapter.tool_call(
            "agent-alpha",
            "send_message",
            {"content": "Patient SSN: 123-45-6789 please process this"},
        )
        assert decision.denied
        assert "G5" in decision.reason or "G7" in decision.reason or "exfiltration" in decision.reason.lower()

    def test_phi_in_query_arg_denied(self):
        """PHI in query argument is caught by exfiltration scan."""
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        decision = adapter.tool_call(
            "agent-alpha",
            "search",
            {"query": "ssn=123-45-6789"},
        )
        assert decision.denied

    def test_clean_args_not_denied(self):
        """Clean tool args pass the exfiltration scan."""
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        decision = adapter.tool_call(
            "agent-alpha",
            "search",
            {"query": "AI governance compliance"},
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved model blocks llm_call
# ---------------------------------------------------------------------------

class TestClaudeAgentSdkProviderCompliance:
    def test_unapproved_model_denied_at_agent_start(self):
        """Model not in approved_models list is denied at agent_start."""
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            "agent-alpha",
            pack_binding=["hipaa"],
            model="unapproved-model-xyz",
        )
        assert decision.denied
        assert "unapproved-model-xyz" in decision.reason

    def test_unapproved_model_denied_at_llm_call(self):
        """Model switched after spawn to unapproved model is denied at llm_call."""
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        # Manually override the stored model to simulate a switch
        adapter._active_agents["agent-alpha"]["model"] = "claude-haiku-4-5"
        decision = adapter.llm_call(
            "agent-alpha",
            "gpt-4-turbo",  # not in approved list
            messages=[{"role": "user", "content": "hi"}],
        )
        assert decision.denied
        assert "gpt-4-turbo" in decision.reason

    def test_approved_model_passes(self):
        """Approved model passes provider compliance check."""
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-sonnet-4-6")
        decision = adapter.llm_call(
            "agent-alpha",
            "claude-sonnet-4-6",
            messages=[{"role": "user", "content": "hello"}],
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 5. Subscription gate -- governance server DENY at agent_start
# ---------------------------------------------------------------------------

class TestClaudeAgentSdkSubscriptionGate:
    def test_subscription_deny_raises_subscription_gate_error(self):
        """Subscription DENY from governance server raises SubscriptionGateError."""
        transport = _transport(**{"/api/v1/governance/check-action": SUB_DENY})
        adapter = _adapter(transport)
        with pytest.raises(SubscriptionGateError):
            adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")

    def test_phantom_agent_raises_phantom_error(self):
        """Unregistered agent raises PhantomAgentError at agent_start."""
        adapter = _adapter(_transport())
        with pytest.raises(PhantomAgentError):
            adapter.agent_start("unregistered-agent", pack_binding=["hipaa"], model="claude-haiku-4-5")

    def test_empty_pack_binding_raises_unbound_error(self):
        """Empty pack_binding raises UnboundDataError when enforce_pack_binding=True."""
        adapter = _adapter(_transport())
        with pytest.raises(UnboundDataError):
            adapter.agent_start("agent-alpha", pack_binding=[], model="claude-haiku-4-5")

    def test_tool_call_without_agent_start_raises_phantom_error(self):
        """tool_call without prior agent_start raises PhantomAgentError."""
        adapter = _adapter(_transport())
        with pytest.raises(PhantomAgentError):
            adapter.tool_call("agent-alpha", "search", {"query": "test"})

    def test_llm_call_without_agent_start_raises_phantom_error(self):
        """llm_call without prior agent_start raises PhantomAgentError."""
        adapter = _adapter(_transport())
        with pytest.raises(PhantomAgentError):
            adapter.llm_call("agent-alpha", "claude-haiku-4-5", [])


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip through governance API
# ---------------------------------------------------------------------------

class TestClaudeAgentSdkAuditChain:
    def test_tool_result_uses_audit_id_from_tool_call(self):
        """audit_id from tool_call decision is used to close audit in tool_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("agent-alpha", pack_binding=["soc2"], model="claude-haiku-4-5")
        adapter.tool_call("agent-alpha", "search", {"query": "docs"})
        adapter.tool_result("agent-alpha", "search", "results", success=True)

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-cas-001"
        assert reported[0]["success"] is True

    def test_llm_result_uses_audit_id_from_llm_call(self):
        """audit_id from llm_call decision is used to close audit in llm_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        adapter.llm_call("agent-alpha", "claude-haiku-4-5", [{"role": "user", "content": "hi"}])
        adapter.llm_result("agent-alpha", "claude-haiku-4-5", "Hello!")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-cas-001"

    def test_agent_end_fires_check_action_for_terminal_event(self):
        """agent_end fires a check_action call to seal the terminal audit event."""
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("agent-alpha", pack_binding=["hipaa"], model="claude-haiku-4-5")
        adapter.agent_end("agent-alpha", success=True, summary="done")

        # agent_start and agent_end each make a check_action call
        action_calls = [c for c in calls if "check-action" in c]
        assert len(action_calls) >= 2

    def test_tool_counter_increments_per_call(self):
        """Tool call counter increments across multiple tool calls."""
        adapter = _adapter(_transport())
        adapter.agent_start("agent-alpha", pack_binding=["soc2"], model="claude-haiku-4-5")
        adapter.tool_call("agent-alpha", "search", {"query": "a"})
        adapter.tool_call("agent-alpha", "search", {"query": "b"})
        adapter.tool_call("agent-alpha", "search", {"query": "c"})
        assert adapter._tool_counters.get("agent-alpha", 0) == 3

    def test_max_tool_calls_enforced(self):
        """Agent exceeding max_tool_calls_per_run is denied."""
        client = make_client(_transport(), enforce=False)
        adapter = ClaudeAgentGovernance(
            client=client,
            registered_agents=["agent-alpha"],
            approved_models=["claude-haiku-4-5"],
            max_tool_calls_per_run=2,
        )
        adapter.agent_start("agent-alpha", pack_binding=["soc2"], model="claude-haiku-4-5")
        adapter.tool_call("agent-alpha", "search", {})
        adapter.tool_call("agent-alpha", "search", {})
        # Third call exceeds the limit
        decision = adapter.tool_call("agent-alpha", "search", {})
        assert decision.denied
        assert "max_tool_calls_per_run" in decision.reason or "Runaway" in decision.reason
