"""
Tests for connexum_governance.integrations.llama_index_integration

LlamaIndex Python framework adapter -- Sprint 5, WS-09.

All tests run offline -- no real llama-index or llama-index-core package required.
LlamaIndex primitives are mocked via minimal class implementations.
Governance server calls are injected via the _check_fn parameter.

Coverage:

  GovernanceLlamaIndexCallback:
    on_event_start():
      - ALLOW -> returns event_id without raising
      - DENY -> raises GovernanceViolation (raise_on_deny=True)
      - DENY -> logs + returns (raise_on_deny=False)
      - PENDING -> raises GovernancePendingApproval (raise_on_deny=True)
      - PENDING with no approvalId -> raises GovernanceViolation
      - FUNCTION_CALL event_type -> action namespace 'framework.llamaindex.tool_call'
      - AGENT_STEP event_type -> action namespace 'framework.llamaindex.agent_step'
      - RETRIEVE event_type -> action namespace 'framework.llamaindex.query'
      - Unknown event_type -> action namespace 'framework.llamaindex.agent_step'
    on_event_end():
      - Always returns without raising (audit log only)
    Constructor validation:
      - Missing governance_server_url -> raises ValueError
      - Missing license_key -> raises ValueError

  GovernedFunctionTool:
    __call__():
      - ALLOW -> calls underlying tool.__call__(), returns result
      - DENY -> raises GovernanceViolation (raise_on_deny=True)
      - DENY -> logs + returns (raise_on_deny=False)
      - PENDING -> raises GovernancePendingApproval (raise_on_deny=True)
      - PENDING (no approvalId) -> raises GovernanceViolation
      - Action namespace 'framework.llamaindex.tool_call' sent
      - Tool name from metadata.name
      - Tool name from tool.name (fallback)
      - Underlying tool NOT called on DENY
      - String input forwarded as messagePreview
      - Dict input JSON-serialized as messagePreview
    acall():
      - ALLOW -> calls underlying tool.acall(), returns result
      - DENY -> raises GovernanceViolation
      - PENDING -> raises GovernancePendingApproval
      - Fallback to __call__ when acall() not available
      - Async underlying function called correctly
    Constructor validation:
      - tool=None -> raises ValueError
      - tool.metadata.name missing -> raises ValueError
      - missing governance_server_url -> raises ValueError
      - missing license_key -> raises ValueError
    Metadata proxy:
      - .metadata.name matches underlying tool name
      - .name matches underlying tool name
      - .description matches underlying tool description

  governed_function_tool() factory:
    - Returns GovernedFunctionTool instance
    - ALLOW -> underlying tool called
    - DENY -> raises GovernanceViolation

  GovernedQueryEngineProxy (via wrap_query_engine()):
    query():
      - ALLOW -> delegates to engine.query(), returns response
      - DENY -> raises GovernanceViolation before engine.query() called
      - PENDING -> raises GovernancePendingApproval
      - Action namespace 'framework.llamaindex.query' sent
      - engine.query() NOT called on DENY
    aquery():
      - ALLOW -> delegates to engine.aquery()
      - DENY -> raises GovernanceViolation
    Constructor validation:
      - engine=None -> raises ValueError
      - missing governance_server_url -> raises ValueError
      - missing license_key -> raises ValueError

  GovernedChatEngineProxy (via wrap_chat_engine()):
    chat():
      - ALLOW -> delegates to engine.chat(), returns response
      - DENY -> raises GovernanceViolation before engine.chat() called
      - PENDING -> raises GovernancePendingApproval
      - Action namespace 'framework.llamaindex.chat_message' sent
    achat():
      - ALLOW -> delegates to engine.achat()
      - DENY -> raises GovernanceViolation
    Constructor validation:
      - engine=None -> raises ValueError

  wrap_agent_worker():
    - Injects GovernanceLlamaIndexCallback into worker.callback_manager.handlers
    - Wraps all worker.tools with GovernedFunctionTool
    - Idempotency: second call does NOT double-wrap tools or callbacks
    - Worker with no tools -- does not raise
    - Worker with no callback_manager -- does not raise
    - Tool without metadata.name -- kept unwrapped with warning

  create_governed_llama_index() factory:
    - Returns GovernedLlamaIndexInstance with .callback set
    - .governed_tool() returns GovernedFunctionTool
    - .wrap_query_engine() returns GovernedQueryEngineProxy
    - .wrap_chat_engine() returns GovernedChatEngineProxy
    - .wrap_agent_worker() wraps tools on worker
    - Constructor validation: missing governance_server_url -> ValueError

  Fail-open / fail-closed:
    - GovernedFunctionTool: governance server raises -> exception propagates
    - GovernedQueryEngineProxy: governance server raises -> exception propagates
    - GovernanceLlamaIndexCallback: governance server raises -> exception propagates
"""

from __future__ import annotations

import asyncio
import json
from typing import Any, Optional
from unittest.mock import MagicMock

import pytest

from connexum_governance.integrations.llama_index_integration import (
    GovernanceLlamaIndexCallback,
    GovernedFunctionTool,
    GovernedQueryEngineProxy,
    GovernedChatEngineProxy,
    governed_function_tool,
    wrap_query_engine,
    wrap_chat_engine,
    wrap_agent_worker,
    create_governed_llama_index,
    GovernedLlamaIndexInstance,
)
from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)


# ---------------------------------------------------------------------------
# Shared decision constants
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-li-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-li-002"}
PENDING = {
    "decision": "REQUIRE_APPROVAL",
    "approvalId": "appr-li-001",
    "auditId": "aud-li-003",
}
PENDING_NO_ID = {
    "decision": "REQUIRE_APPROVAL",
    "approvalId": None,
    "auditId": "aud-li-004",
}


# ---------------------------------------------------------------------------
# Mock LlamaIndex primitives
# ---------------------------------------------------------------------------

class MockToolMetadata:
    """Minimal LlamaIndex ToolMetadata."""
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description


class MockFunctionTool:
    """Minimal LlamaIndex FunctionTool."""
    def __init__(self, name: str, description: str = "", fn: Any = None):
        self.metadata = MockToolMetadata(name=name, description=description)
        self._fn = fn or (lambda *a, **kw: f"result:{a}")

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._fn(*args, **kwargs)

    async def acall(self, *args: Any, **kwargs: Any) -> Any:
        result = self._fn(*args, **kwargs)
        if asyncio.iscoroutine(result):
            return await result
        return result


class MockQueryEngine:
    """Minimal LlamaIndex QueryEngine."""
    def __init__(self, response: str = "query_response"):
        self._response = response
        self.query_called_with = None

    def query(self, query_str: str, **kwargs: Any) -> str:
        self.query_called_with = query_str
        return self._response

    async def aquery(self, query_str: str, **kwargs: Any) -> str:
        self.query_called_with = query_str
        return self._response + "_async"


class MockChatEngine:
    """Minimal LlamaIndex ChatEngine."""
    def __init__(self, response: str = "chat_response"):
        self._response = response
        self.chat_called_with = None

    def chat(self, message: str, **kwargs: Any) -> str:
        self.chat_called_with = message
        return self._response

    async def achat(self, message: str, **kwargs: Any) -> str:
        self.chat_called_with = message
        return self._response + "_async"


class MockCallbackManager:
    """Minimal LlamaIndex CallbackManager with handlers list."""
    def __init__(self):
        self.handlers = []


class MockAgentWorker:
    """Minimal LlamaIndex agent worker."""
    def __init__(self, tools: Optional[list] = None, callback_manager: Any = None):
        self.tools = tools or []
        self.callback_manager = callback_manager


# ---------------------------------------------------------------------------
# Check function factories
# ---------------------------------------------------------------------------

def make_sync_check(decision: dict):
    """Return a sync check_fn that always returns the given decision."""
    def _check_fn(url: str, body: dict) -> dict:
        return decision
    return _check_fn


def make_async_check(decision: dict):
    """Return an async check_fn that always returns the given decision."""
    async def _check_fn(url: str, body: dict) -> dict:
        return decision
    return _check_fn


def make_capturing_check(decision: dict):
    """Return a check_fn that captures the last body sent to it."""
    captured = {"body": None}

    def _check_fn(url: str, body: dict) -> dict:
        captured["body"] = body
        return decision

    return _check_fn, captured


def make_raising_check(exc: Exception):
    """Return a check_fn that raises the given exception."""
    def _check_fn(url: str, body: dict) -> dict:
        raise exc
    return _check_fn


# ---------------------------------------------------------------------------
# Shared governance config
# ---------------------------------------------------------------------------

URL = "http://localhost:3200"
KEY = "test-license-key"
PACKS = ["hipaa"]


# ===========================================================================
# GovernanceLlamaIndexCallback tests
# ===========================================================================

class TestGovernanceLlamaIndexCallbackConstructor:
    def test_missing_url_raises(self):
        with pytest.raises(ValueError, match="governance_server_url"):
            GovernanceLlamaIndexCallback(
                governance_server_url="",
                license_key=KEY,
            )

    def test_missing_key_raises(self):
        with pytest.raises(ValueError, match="license_key"):
            GovernanceLlamaIndexCallback(
                governance_server_url=URL,
                license_key="",
            )

    def test_valid_construction(self):
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
        )
        assert cb._governance_server_url == URL
        assert cb._license_key == KEY
        assert cb._pack_ids == PACKS
        assert cb._raise_on_deny is True


class TestGovernanceLlamaIndexCallbackOnEventStart:
    def _make_callback(self, decision: dict, raise_on_deny: bool = True):
        return GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
            raise_on_deny=raise_on_deny,
            _check_fn=make_sync_check(decision),
        )

    def test_allow_returns_event_id(self):
        cb = self._make_callback(ALLOW)
        result = cb.on_event_start("FUNCTION_CALL", {}, event_id="evt-001")
        assert result == "evt-001"

    def test_deny_raises_governance_violation(self):
        cb = self._make_callback(DENY)
        with pytest.raises(GovernanceViolation) as exc_info:
            cb.on_event_start("FUNCTION_CALL", {}, event_id="evt-002")
        assert exc_info.value.decision == "DENY"
        assert exc_info.value.reason == "Policy violation"

    def test_deny_no_raise_returns(self):
        cb = self._make_callback(DENY, raise_on_deny=False)
        # Should not raise -- logs to stderr
        result = cb.on_event_start("FUNCTION_CALL", {}, event_id="evt-003")
        # Returns event_id even on DENY with raise_on_deny=False (post-enforce fall-through)
        assert result == "evt-003"

    def test_pending_raises_governance_pending(self):
        cb = self._make_callback(PENDING)
        with pytest.raises(GovernancePendingApproval) as exc_info:
            cb.on_event_start("FUNCTION_CALL", {}, event_id="evt-004")
        assert exc_info.value.approval_id == "appr-li-001"

    def test_pending_no_id_raises_violation(self):
        cb = self._make_callback(PENDING_NO_ID)
        with pytest.raises(GovernanceViolation):
            cb.on_event_start("FUNCTION_CALL", {}, event_id="evt-005")

    def test_function_call_event_uses_tool_call_namespace(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb.on_event_start("FUNCTION_CALL", {"function_call": "search_tool"})
        assert captured["body"]["action"] == "framework.llamaindex.tool_call"

    def test_agent_step_event_uses_agent_step_namespace(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb.on_event_start("AGENT_STEP", {"step_type": "reasoning"})
        assert captured["body"]["action"] == "framework.llamaindex.agent_step"

    def test_retrieve_event_uses_query_namespace(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb.on_event_start("RETRIEVE", {"query_str": "What is HIPAA?"})
        assert captured["body"]["action"] == "framework.llamaindex.query"

    def test_unknown_event_uses_agent_step_namespace(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb.on_event_start("LLM", {})
        assert captured["body"]["action"] == "framework.llamaindex.agent_step"

    def test_payload_query_str_sent_as_message_preview(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb.on_event_start("RETRIEVE", {"query_str": "HIPAA retention policy"})
        assert "HIPAA retention policy" in captured["body"]["messagePreview"]


class TestGovernanceLlamaIndexCallbackOnEventEnd:
    def test_on_event_end_does_not_raise(self):
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(DENY),  # even with DENY server
        )
        # Should never raise -- observability only
        cb.on_event_end("FUNCTION_CALL", {}, event_id="evt-end-001")

    def test_on_event_end_with_no_payload(self):
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        cb.on_event_end("LLM", event_id="evt-end-002")

    def test_start_trace_passthrough(self):
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        cb.start_trace("trace-001")  # should not raise

    def test_end_trace_passthrough(self):
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        cb.end_trace("trace-001", {})  # should not raise


# ===========================================================================
# GovernedFunctionTool tests
# ===========================================================================

class TestGovernedFunctionToolConstructor:
    def test_tool_none_raises(self):
        with pytest.raises(ValueError, match="tool is required"):
            GovernedFunctionTool(
                tool=None,
                governance_server_url=URL,
                license_key=KEY,
            )

    def test_missing_metadata_name_raises(self):
        class BadTool:
            metadata = MockToolMetadata(name="")
        with pytest.raises(ValueError, match="metadata.name"):
            GovernedFunctionTool(
                tool=BadTool(),
                governance_server_url=URL,
                license_key=KEY,
            )

    def test_missing_url_raises(self):
        tool = MockFunctionTool(name="search")
        with pytest.raises(ValueError, match="governance_server_url"):
            GovernedFunctionTool(tool=tool, governance_server_url="", license_key=KEY)

    def test_missing_key_raises(self):
        tool = MockFunctionTool(name="search")
        with pytest.raises(ValueError, match="license_key"):
            GovernedFunctionTool(tool=tool, governance_server_url=URL, license_key="")

    def test_metadata_proxy_exposes_name(self):
        tool = MockFunctionTool(name="web_search", description="Searches the web")
        gt = GovernedFunctionTool(tool=tool, governance_server_url=URL, license_key=KEY)
        assert gt.metadata.name == "web_search"
        assert gt.name == "web_search"

    def test_metadata_proxy_exposes_description(self):
        tool = MockFunctionTool(name="search", description="Search tool")
        gt = GovernedFunctionTool(tool=tool, governance_server_url=URL, license_key=KEY)
        assert gt.description == "Search tool"
        assert gt.metadata.description == "Search tool"

    def test_fallback_name_from_tool_name_attribute(self):
        """Tool without .metadata but with .name attribute should work."""
        class SimpleTool:
            name = "simple_tool"
            description = "Simple"
            def __call__(self, x):
                return f"result:{x}"

        gt = GovernedFunctionTool(
            tool=SimpleTool(),
            governance_server_url=URL,
            license_key=KEY,
        )
        assert gt.name == "simple_tool"


class TestGovernedFunctionToolCall:
    def _make_tool(self, decision: dict, raise_on_deny: bool = True, fn: Any = None):
        underlying = MockFunctionTool(name="test_tool", fn=fn)
        return GovernedFunctionTool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
            raise_on_deny=raise_on_deny,
            _check_fn=make_sync_check(decision),
        )

    def test_allow_calls_underlying_tool(self):
        call_log = []
        def track_fn(*args, **kwargs):
            call_log.append(args)
            return "tracked_result"

        gt = self._make_tool(ALLOW, fn=track_fn)
        result = gt("input_value")
        assert result == "tracked_result"
        assert len(call_log) == 1

    def test_deny_raises_governance_violation(self):
        gt = self._make_tool(DENY)
        with pytest.raises(GovernanceViolation) as exc_info:
            gt("sensitive_query")
        assert exc_info.value.decision == "DENY"
        assert exc_info.value.reason == "Policy violation"

    def test_deny_underlying_not_called(self):
        call_log = []
        def track_fn(*args, **kwargs):
            call_log.append(args)
            return "should_not_reach"

        gt = self._make_tool(DENY, fn=track_fn)
        with pytest.raises(GovernanceViolation):
            gt("input")
        assert len(call_log) == 0

    def test_deny_no_raise_returns_denied_string(self):
        gt = self._make_tool(DENY, raise_on_deny=False)
        result = gt("input")
        assert "[GOVERNANCE DENIED]" in result

    def test_pending_raises_governance_pending(self):
        gt = self._make_tool(PENDING)
        with pytest.raises(GovernancePendingApproval) as exc_info:
            gt("input")
        assert exc_info.value.approval_id == "appr-li-001"

    def test_pending_no_id_raises_violation(self):
        gt = self._make_tool(PENDING_NO_ID)
        with pytest.raises(GovernanceViolation):
            gt("input")

    def test_action_namespace_tool_call(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockFunctionTool(name="my_tool")
        gt = GovernedFunctionTool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt("some_input")
        assert captured["body"]["action"] == "framework.llamaindex.tool_call"

    def test_tool_name_sent_in_body(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockFunctionTool(name="search_tool")
        gt = GovernedFunctionTool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt("query")
        assert "search_tool" in captured["body"]["tools"]

    def test_string_input_as_message_preview(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockFunctionTool(name="tool")
        gt = GovernedFunctionTool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt("what is the retention period?")
        assert "what is the retention period?" in captured["body"]["messagePreview"]

    def test_dict_input_json_serialized(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockFunctionTool(name="tool")
        gt = GovernedFunctionTool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt({"query": "retention"})
        preview = captured["body"]["messagePreview"]
        assert "retention" in preview


class TestGovernedFunctionToolAcall:
    def _make_async_tool(self, decision: dict, raise_on_deny: bool = True):
        underlying = MockFunctionTool(name="async_tool")
        return GovernedFunctionTool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
            raise_on_deny=raise_on_deny,
            _check_fn=make_async_check(decision),
        )

    @pytest.mark.asyncio
    async def test_allow_calls_underlying_acall(self):
        call_log = []

        class AsyncTool:
            metadata = MockToolMetadata(name="async_tool")
            async def acall(self, *args, **kwargs):
                call_log.append(args)
                return "async_result"
            def __call__(self, *args, **kwargs):
                return "sync_fallback"

        gt = GovernedFunctionTool(
            tool=AsyncTool(),
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(ALLOW),
        )
        result = await gt.acall("input")
        assert result == "async_result"
        assert len(call_log) == 1

    @pytest.mark.asyncio
    async def test_deny_raises_governance_violation(self):
        gt = self._make_async_tool(DENY)
        with pytest.raises(GovernanceViolation):
            await gt.acall("input")

    @pytest.mark.asyncio
    async def test_pending_raises_governance_pending(self):
        gt = self._make_async_tool(PENDING)
        with pytest.raises(GovernancePendingApproval):
            await gt.acall("input")

    @pytest.mark.asyncio
    async def test_fallback_to_call_when_no_acall(self):
        class SyncOnlyTool:
            metadata = MockToolMetadata(name="sync_only")
            def __call__(self, *args, **kwargs):
                return "sync_result"

        gt = GovernedFunctionTool(
            tool=SyncOnlyTool(),
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(ALLOW),
        )
        result = await gt.acall("input")
        assert result == "sync_result"

    @pytest.mark.asyncio
    async def test_action_namespace_tool_call_async(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockFunctionTool(name="async_search")
        gt = GovernedFunctionTool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        await gt.acall("input")
        assert captured["body"]["action"] == "framework.llamaindex.tool_call"


# ===========================================================================
# governed_function_tool() factory tests
# ===========================================================================

class TestGovernedFunctionToolFactory:
    def test_returns_governed_function_tool_instance(self):
        tool = MockFunctionTool(name="factory_tool")
        gt = governed_function_tool(
            tool=tool,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert isinstance(gt, GovernedFunctionTool)

    def test_allow_underlying_called(self):
        call_log = []
        def track_fn(*args, **kwargs):
            call_log.append(True)
            return "factory_result"

        tool = MockFunctionTool(name="factory_tool", fn=track_fn)
        gt = governed_function_tool(
            tool=tool,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        result = gt("input")
        assert result == "factory_result"
        assert len(call_log) == 1

    def test_deny_raises(self):
        tool = MockFunctionTool(name="factory_tool")
        gt = governed_function_tool(
            tool=tool,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(DENY),
        )
        with pytest.raises(GovernanceViolation):
            gt("input")


# ===========================================================================
# GovernedQueryEngineProxy tests (via wrap_query_engine)
# ===========================================================================

class TestGovernedQueryEngineProxy:
    def _make_proxy(self, decision: dict, raise_on_deny: bool = True):
        engine = MockQueryEngine()
        proxy = wrap_query_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
            raise_on_deny=raise_on_deny,
            _check_fn=make_sync_check(decision),
        )
        return proxy, engine

    def test_constructor_engine_none_raises(self):
        with pytest.raises(ValueError, match="engine is required"):
            GovernedQueryEngineProxy(
                engine=None,
                governance_server_url=URL,
                license_key=KEY,
            )

    def test_constructor_missing_url_raises(self):
        with pytest.raises(ValueError, match="governance_server_url"):
            GovernedQueryEngineProxy(
                engine=MockQueryEngine(),
                governance_server_url="",
                license_key=KEY,
            )

    def test_constructor_missing_key_raises(self):
        with pytest.raises(ValueError, match="license_key"):
            GovernedQueryEngineProxy(
                engine=MockQueryEngine(),
                governance_server_url=URL,
                license_key="",
            )

    def test_allow_delegates_to_engine_query(self):
        proxy, engine = self._make_proxy(ALLOW)
        result = proxy.query("What is HIPAA?")
        assert result == "query_response"
        assert engine.query_called_with == "What is HIPAA?"

    def test_deny_raises_before_engine_called(self):
        proxy, engine = self._make_proxy(DENY)
        with pytest.raises(GovernanceViolation):
            proxy.query("sensitive query")
        assert engine.query_called_with is None

    def test_pending_raises_governance_pending(self):
        proxy, engine = self._make_proxy(PENDING)
        with pytest.raises(GovernancePendingApproval):
            proxy.query("query")

    def test_action_namespace_query(self):
        check_fn, captured = make_capturing_check(ALLOW)
        engine = MockQueryEngine()
        proxy = wrap_query_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        proxy.query("test query")
        assert captured["body"]["action"] == "framework.llamaindex.query"

    def test_query_string_sent_as_message_preview(self):
        check_fn, captured = make_capturing_check(ALLOW)
        engine = MockQueryEngine()
        proxy = wrap_query_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        proxy.query("HIPAA retention policy")
        assert "HIPAA retention policy" in captured["body"]["messagePreview"]

    @pytest.mark.asyncio
    async def test_aquery_allow_delegates(self):
        engine = MockQueryEngine()
        proxy = wrap_query_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(ALLOW),
        )
        result = await proxy.aquery("async query")
        assert result == "query_response_async"

    @pytest.mark.asyncio
    async def test_aquery_deny_raises(self):
        engine = MockQueryEngine()
        proxy = wrap_query_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(DENY),
        )
        with pytest.raises(GovernanceViolation):
            await proxy.aquery("blocked query")


# ===========================================================================
# GovernedChatEngineProxy tests (via wrap_chat_engine)
# ===========================================================================

class TestGovernedChatEngineProxy:
    def _make_proxy(self, decision: dict, raise_on_deny: bool = True):
        engine = MockChatEngine()
        proxy = wrap_chat_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
            raise_on_deny=raise_on_deny,
            _check_fn=make_sync_check(decision),
        )
        return proxy, engine

    def test_constructor_engine_none_raises(self):
        with pytest.raises(ValueError, match="engine is required"):
            GovernedChatEngineProxy(
                engine=None,
                governance_server_url=URL,
                license_key=KEY,
            )

    def test_allow_delegates_to_engine_chat(self):
        proxy, engine = self._make_proxy(ALLOW)
        result = proxy.chat("Tell me about HIPAA")
        assert result == "chat_response"
        assert engine.chat_called_with == "Tell me about HIPAA"

    def test_deny_raises_before_engine_called(self):
        proxy, engine = self._make_proxy(DENY)
        with pytest.raises(GovernanceViolation):
            proxy.chat("sensitive message")
        assert engine.chat_called_with is None

    def test_pending_raises_governance_pending(self):
        proxy, engine = self._make_proxy(PENDING)
        with pytest.raises(GovernancePendingApproval):
            proxy.chat("message")

    def test_action_namespace_chat_message(self):
        check_fn, captured = make_capturing_check(ALLOW)
        engine = MockChatEngine()
        proxy = wrap_chat_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        proxy.chat("test message")
        assert captured["body"]["action"] == "framework.llamaindex.chat_message"

    @pytest.mark.asyncio
    async def test_achat_allow_delegates(self):
        engine = MockChatEngine()
        proxy = wrap_chat_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(ALLOW),
        )
        result = await proxy.achat("async message")
        assert result == "chat_response_async"

    @pytest.mark.asyncio
    async def test_achat_deny_raises(self):
        engine = MockChatEngine()
        proxy = wrap_chat_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(DENY),
        )
        with pytest.raises(GovernanceViolation):
            await proxy.achat("blocked message")


# ===========================================================================
# wrap_agent_worker tests
# ===========================================================================

class TestWrapAgentWorker:
    def _make_worker_with_tools(self, *tool_names):
        tools = [MockFunctionTool(name=n) for n in tool_names]
        cm = MockCallbackManager()
        return MockAgentWorker(tools=tools, callback_manager=cm)

    def test_wraps_tools_with_governed_function_tool(self):
        worker = self._make_worker_with_tools("search", "calculator")
        wrap_agent_worker(
            worker=worker,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert all(isinstance(t, GovernedFunctionTool) for t in worker.tools)
        assert worker.tools[0].name == "search"
        assert worker.tools[1].name == "calculator"

    def test_injects_callback_into_callback_manager(self):
        worker = self._make_worker_with_tools("search")
        wrap_agent_worker(
            worker=worker,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert any(
            isinstance(h, GovernanceLlamaIndexCallback)
            for h in worker.callback_manager.handlers
        )

    def test_idempotency_no_double_wrap_tools(self):
        worker = self._make_worker_with_tools("search")
        wrap_agent_worker(worker=worker, governance_server_url=URL, license_key=KEY,
                          _check_fn=make_sync_check(ALLOW))
        # Second call -- already wrapped tools should not be double-wrapped
        wrap_agent_worker(worker=worker, governance_server_url=URL, license_key=KEY,
                          _check_fn=make_sync_check(ALLOW))
        assert all(isinstance(t, GovernedFunctionTool) for t in worker.tools)
        assert len(worker.tools) == 1

    def test_idempotency_no_double_inject_callback(self):
        worker = self._make_worker_with_tools("search")
        wrap_agent_worker(worker=worker, governance_server_url=URL, license_key=KEY,
                          _check_fn=make_sync_check(ALLOW))
        wrap_agent_worker(worker=worker, governance_server_url=URL, license_key=KEY,
                          _check_fn=make_sync_check(ALLOW))
        governance_callbacks = [
            h for h in worker.callback_manager.handlers
            if isinstance(h, GovernanceLlamaIndexCallback)
        ]
        assert len(governance_callbacks) == 1

    def test_worker_with_no_tools_does_not_raise(self):
        worker = MockAgentWorker(tools=[], callback_manager=MockCallbackManager())
        # Should not raise
        wrap_agent_worker(
            worker=worker,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert worker.tools == []

    def test_worker_with_no_callback_manager_does_not_raise(self):
        worker = MockAgentWorker(tools=[MockFunctionTool(name="t")], callback_manager=None)
        wrap_agent_worker(
            worker=worker,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert isinstance(worker.tools[0], GovernedFunctionTool)

    def test_tool_without_name_kept_unwrapped_with_warning(self, capsys):
        class NamelessTool:
            metadata = MockToolMetadata(name="")

        worker = MockAgentWorker(
            tools=[NamelessTool()],
            callback_manager=MockCallbackManager(),
        )
        wrap_agent_worker(
            worker=worker,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        # Tool should remain unwrapped
        assert not isinstance(worker.tools[0], GovernedFunctionTool)


# ===========================================================================
# create_governed_llama_index factory tests
# ===========================================================================

class TestCreateGovernedLlamaIndex:
    def test_returns_governed_llama_index_instance(self):
        gov = create_governed_llama_index(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert isinstance(gov, GovernedLlamaIndexInstance)

    def test_callback_is_set(self):
        gov = create_governed_llama_index(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert isinstance(gov.callback, GovernanceLlamaIndexCallback)

    def test_governed_tool_returns_governed_function_tool(self):
        gov = create_governed_llama_index(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        tool = MockFunctionTool(name="factory_search")
        gt = gov.governed_tool(tool)
        assert isinstance(gt, GovernedFunctionTool)
        assert gt.name == "factory_search"

    def test_wrap_query_engine_returns_proxy(self):
        gov = create_governed_llama_index(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        engine = MockQueryEngine()
        proxy = gov.wrap_query_engine(engine)
        assert isinstance(proxy, GovernedQueryEngineProxy)

    def test_wrap_chat_engine_returns_proxy(self):
        gov = create_governed_llama_index(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        engine = MockChatEngine()
        proxy = gov.wrap_chat_engine(engine)
        assert isinstance(proxy, GovernedChatEngineProxy)

    def test_wrap_agent_worker_wraps_tools(self):
        gov = create_governed_llama_index(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        worker = MockAgentWorker(
            tools=[MockFunctionTool(name="w_tool")],
            callback_manager=MockCallbackManager(),
        )
        gov.wrap_agent_worker(worker)
        assert isinstance(worker.tools[0], GovernedFunctionTool)

    def test_missing_url_raises(self):
        with pytest.raises(ValueError):
            create_governed_llama_index(
                governance_server_url="",
                license_key=KEY,
            )


# ===========================================================================
# Fail-open / fail-closed tests
# ===========================================================================

class TestFailBehavior:
    def test_governed_tool_server_error_propagates(self):
        tool = MockFunctionTool(name="erring_tool")
        gt = GovernedFunctionTool(
            tool=tool,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_raising_check(ConnectionError("server down")),
        )
        with pytest.raises(ConnectionError, match="server down"):
            gt("input")

    def test_query_proxy_server_error_propagates(self):
        engine = MockQueryEngine()
        proxy = wrap_query_engine(
            engine=engine,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_raising_check(ConnectionError("server down")),
        )
        with pytest.raises(ConnectionError, match="server down"):
            proxy.query("query")

    def test_callback_server_error_propagates(self):
        cb = GovernanceLlamaIndexCallback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_raising_check(ConnectionError("server down")),
        )
        with pytest.raises(ConnectionError, match="server down"):
            cb.on_event_start("FUNCTION_CALL", {})
