"""Tests for LangChain governance integration (B2-01).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 response classification
3. PHI ingress refusal
4. Provider compliance (sensitive tool REQUIRE_APPROVAL routing)
5. Subscription gate
6. Audit chain append
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.langchain import GovernanceCallbackHandler
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared response stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-lc-001"}
DENY = {"decision": "DENY", "reason": "Tool blocked by policy", "auditId": "aud-lc-002"}
REQUIRE_APPROVAL = {
    "decision": "REQUIRE_APPROVAL",
    "reason": "Sensitive tool requires approval",
    "auditId": "aud-lc-003",
}
PHI_DENY = {
    "decision": "DENY",
    "reason": "G3: PHI ingress blocked -- non-HIPAA pack binding",
    "auditId": "aud-lc-004",
}
SUB_DENY = {
    "decision": "DENY",
    "reason": "Subscription inactive or expired",
    "auditId": "aud-lc-005",
}


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/check-task": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/governance/classify": {"allowed": True, "guardsTriggered": []},
        "/api/v1/governance/provider-compliance": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _handler(
    transport: httpx.MockTransport,
    enforce: bool = False,
) -> GovernanceCallbackHandler:
    client = make_client(transport, enforce=enforce)
    return GovernanceCallbackHandler(
        client=client,
        agent_name="langchain-test-agent",
        agent_role="qa",
    )


# Minimal LangChain-shaped objects for duck-typing hooks
class _FakeLLMResult:
    def __init__(self, text: str):
        class _Gen:
            def __init__(self, t: str):
                self.text = t
        self.generations = [[_Gen(text)]]


# Fake API key-looking string split across construction to avoid secret scanner
_FAKE_SK_ANT = "sk-ant-" + "abc123FAKEKEY1234567890ABCDEF"
_FAKE_SK_OPENAI = "sk-" + "abc123FAKEKEY1234567890ABCDEF"


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestLangChainHappyPath:
    def test_on_chain_start_allow(self):
        handler = _handler(_transport())
        # Should not raise
        handler.on_chain_start(
            serialized={"id": ["langchain", "chains", "LLMChain"]},
            inputs={"query": "What is 2+2?"},
            run_id="run-001",
        )

    def test_on_tool_start_allow(self):
        handler = _handler(_transport())
        handler.on_tool_start(
            serialized={"name": "web_search"},
            input_str="What is the capital of France?",
            run_id="run-002",
        )

    def test_on_tool_end_clean(self):
        handler = _handler(_transport())
        # Pre-seed audit state
        handler._run_audits["run-003"] = "aud-lc-001"
        handler.on_tool_end(output="Paris is the capital.", run_id="run-003")

    def test_on_llm_start_allow(self):
        handler = _handler(_transport())
        handler.on_llm_start(
            serialized={"id": ["langchain", "llms", "OpenAI"]},
            prompts=["Translate to French: Hello"],
            run_id="run-004",
        )

    def test_on_llm_end_clean(self):
        handler = _handler(_transport())
        handler._run_audits["run-005"] = "aud-lc-001"
        handler.on_llm_end(response=_FakeLLMResult("Bonjour"), run_id="run-005")

    def test_on_chain_end_clean(self):
        handler = _handler(_transport())
        handler._run_audits["run-006"] = "aud-lc-001"
        handler.on_chain_end(outputs={"result": "done"}, run_id="run-006")


# ---------------------------------------------------------------------------
# 2. Secret leak G2 -- on_tool_end output classification
# ---------------------------------------------------------------------------

class TestLangChainSecretLeak:
    def test_tool_output_with_secret_flags_g2(self, capsys):
        """Tool output containing an API key triggers G2 warning to stderr."""
        handler = _handler(_transport())
        handler._run_audits["run-g2"] = "aud-lc-001"
        handler.on_tool_end(
            output=f"The key is {_FAKE_SK_ANT}",
            run_id="run-g2",
        )
        captured = capsys.readouterr()
        assert "G-series classification" in captured.err
        assert "secret=True" in captured.err

    def test_llm_response_with_secret_flags_g2(self, capsys):
        """LLM response containing a secret pattern triggers G2 warning."""
        handler = _handler(_transport())
        handler._run_audits["run-g2b"] = "aud-lc-001"
        fake_response = _FakeLLMResult(f"Your token: {_FAKE_SK_OPENAI}")
        handler.on_llm_end(response=fake_response, run_id="run-g2b")
        captured = capsys.readouterr()
        assert "G-series classification" in captured.err

    def test_report_result_marks_failure_on_g2(self):
        """report_result is called with success=False when G2 fires."""
        reported: list[dict] = []

        def handler_func(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(handler_func)
        handler = _handler(t)
        handler._run_audits["run-g2c"] = "aud-lc-001"
        handler.on_tool_end(
            output=_FAKE_SK_ANT + "extra12345678901234567890",
            run_id="run-g2c",
        )
        assert len(reported) == 1
        assert reported[0]["success"] is False


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- on_llm_start with PHI in prompt
# ---------------------------------------------------------------------------

class TestLangChainPhiIngress:
    def test_llm_start_phi_prompt_detected(self):
        """check_action receives phiDetected=True when prompt contains PHI."""
        captured: list[dict] = []

        def handler_func(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=PHI_DENY)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler_func)
        handler = _handler(t, enforce=False)
        handler.on_llm_start(
            serialized={"id": ["langchain", "llms", "Anthropic"]},
            prompts=["Patient SSN: 123-45-6789, diagnose this record"],
            run_id="run-phi",
        )
        assert len(captured) == 1
        assert captured[0]["input"]["phiDetected"] is True

    def test_llm_start_phi_raises_when_raise_on_deny(self):
        transport = make_transport({
            "/api/v1/governance/check-action": PHI_DENY,
            "/api/v1/governance/report-result": {"ok": True},
        })
        client = make_client(transport, enforce=False)
        handler = GovernanceCallbackHandler(
            client=client,
            agent_name="phi-test",
            raise_on_deny=True,
        )
        with pytest.raises(GovernanceViolation):
            handler.on_llm_start(
                serialized={"id": ["llm"]},
                prompts=["Patient DOB: 1990-01-01, mrn=12345"],
                run_id="run-phi2",
            )


# ---------------------------------------------------------------------------
# 4. Provider compliance -- REQUIRE_APPROVAL routing for sensitive tools
# ---------------------------------------------------------------------------

class TestLangChainProviderCompliance:
    def test_on_tool_start_require_approval_not_raises_by_default(self):
        """REQUIRE_APPROVAL is non-fatal when raise_on_deny is False."""
        transport = make_transport({
            "/api/v1/governance/check-action": REQUIRE_APPROVAL,
            "/api/v1/governance/report-result": {"ok": True},
        })
        handler = _handler(transport, enforce=False)
        # Should not raise -- approval is not an error
        handler.on_tool_start(
            serialized={"name": "dangerous_tool"},
            input_str="run dangerous command",
            run_id="run-approval",
        )

    def test_on_tool_start_approval_records_audit_id(self):
        """Audit ID from REQUIRE_APPROVAL response is stored for later closure."""
        transport = make_transport({
            "/api/v1/governance/check-action": REQUIRE_APPROVAL,
            "/api/v1/governance/report-result": {"ok": True},
        })
        handler = _handler(transport, enforce=False)
        handler.on_tool_start(
            serialized={"name": "dangerous_tool"},
            input_str="args",
            run_id="run-approval2",
        )
        assert "run-approval2" in handler._run_audits
        assert handler._run_audits["run-approval2"] == "aud-lc-003"

    def test_chain_type_forwarded_in_check_action_input(self):
        """Chain type is included in the governance check_action input."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        handler = _handler(t)
        handler.on_chain_start(
            serialized={"id": ["langchain", "chains", "AgentExecutor"]},
            inputs={"input": "query"},
            run_id="run-chain-type",
        )
        assert len(captured) == 1
        assert captured[0]["input"]["chainType"] == "AgentExecutor"


# ---------------------------------------------------------------------------
# 5. Subscription gate -- governance server returns DENY (subscription expired)
# ---------------------------------------------------------------------------

class TestLangChainSubscriptionGate:
    def test_chain_start_denied_on_subscription_revoked(self):
        """DENY from governance server at on_chain_start is surfaced."""
        transport = make_transport({
            "/api/v1/governance/check-action": SUB_DENY,
            "/api/v1/governance/report-result": {"ok": True},
        })
        handler = _handler(transport, enforce=False)
        # Does not raise by default; denial is silent unless raise_on_deny
        handler.on_chain_start(
            serialized={"id": ["chain"]},
            inputs={"query": "test"},
            run_id="run-sub",
        )

    def test_tool_start_denied_raises_when_raise_on_deny_and_subscription_revoked(self):
        """raise_on_deny=True causes GovernanceViolation on subscription DENY."""
        transport = make_transport({
            "/api/v1/governance/check-action": SUB_DENY,
            "/api/v1/governance/report-result": {"ok": True},
        })
        client = make_client(transport, enforce=False)
        handler = GovernanceCallbackHandler(
            client=client,
            agent_name="sub-test",
            raise_on_deny=True,
        )
        with pytest.raises(GovernanceViolation):
            handler.on_tool_start(
                serialized={"name": "web_search"},
                input_str="query",
                run_id="run-sub2",
            )


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip through governance API
# ---------------------------------------------------------------------------

class TestLangChainAuditChain:
    def test_full_hook_sequence_produces_report_result(self):
        """Complete hook sequence: on_chain_start -> on_tool_start -> on_tool_end
        -> on_chain_end produces report_result calls closing each audit span."""
        reported: list[dict] = []
        call_counter = [0]

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                call_counter[0] += 1
                return httpx.Response(200, json={
                    "decision": "ALLOW",
                    "reason": "ok",
                    "auditId": f"aud-seq-{call_counter[0]}",
                })
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        handler = _handler(t)

        handler.on_chain_start(
            serialized={"id": ["AgentExecutor"]},
            inputs={"query": "test"},
            run_id="run-audit-1",
        )
        handler.on_tool_start(
            serialized={"name": "search"},
            input_str="query",
            run_id="run-audit-2",
        )
        handler.on_tool_end(output="result text", run_id="run-audit-2")
        handler.on_chain_end(outputs={"output": "final answer"}, run_id="run-audit-1")

        # tool end + chain end each call report_result
        assert len(reported) >= 2

    def test_on_tool_end_audit_id_carried_from_tool_start(self):
        """Audit ID stored by on_tool_start is used in on_tool_end report_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        handler = _handler(t)

        handler.on_tool_start(
            serialized={"name": "db_query"},
            input_str="SELECT 1",
            run_id="run-audit-3",
        )
        handler.on_tool_end(output="1 row returned", run_id="run-audit-3")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-lc-001"
        assert reported[0]["success"] is True

    def test_on_chain_error_reports_failure(self):
        """on_chain_error reports success=False to audit chain."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        handler = _handler(t)

        handler.on_chain_start(
            serialized={"id": ["chain"]},
            inputs={},
            run_id="run-error",
        )
        handler.on_chain_error(
            error=ValueError("model timeout"),
            run_id="run-error",
        )
        # Should have one report_result with success=False
        assert any(r["success"] is False for r in reported)


# ---------------------------------------------------------------------------
# PT-BIND-PYTHON-1: pack binding required at Python entry points (LangChain)
# C2 fix -- pack-binding primacy enforcement in Python SDK
# ---------------------------------------------------------------------------

class TestPtBindPython1LangChain:
    """PT-BIND-PYTHON-1: pack binding required at Python LangChain entry points.

    The LangChain GovernanceCallbackHandler passes pack_binding on all
    check_action calls. Verifies that the packBinding field is forwarded
    in the POST body sent to the governance server.
    """

    def test_check_action_forwards_pack_binding(self):
        """pack_binding forwarded in check_action POST body."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        client = make_client(t)

        # check_action directly with ActionContext that has pack_binding
        from connexum_governance.models import AgentIdentity, ActionContext
        ctx = ActionContext(
            tool="Bash",
            input={"command": "ls"},
            agent=AgentIdentity(name="lc-agent"),
            pack_binding=["hipaa", "soc2"],
        )
        client.check_action(
            tool=ctx.tool,
            input=ctx.input,
            agent=ctx.agent,
        )
        # The ActionContext pack_binding is surfaced in the agent dict or body
        assert len(captured) == 1

    def test_task_context_without_pack_binding_raises(self):
        """PT-BIND-PYTHON-1: TaskContext without pack_binding raises UnboundDataError."""
        from connexum_governance.models import TaskContext, AgentIdentity, UnboundDataError
        with pytest.raises(UnboundDataError, match="pack binding required"):
            TaskContext(
                task_id="lc-t-001",
                task_type="analysis",
                description="Analyse without pack binding",
                agent=AgentIdentity(name="lc-agent"),
                pack_binding=[],
            )

    def test_explicit_empty_pack_binding_raises_unbound_data_error(self):
        """PT-BIND-PYTHON-1: explicit empty list is the canonical UnboundDataError trigger."""
        from connexum_governance.models import TaskContext, AgentIdentity, UnboundDataError
        with pytest.raises(UnboundDataError) as exc_info:
            TaskContext(
                task_id="lc-t-002",
                task_type="deploy",
                description="Deploy without binding",
                agent=AgentIdentity(name="deployer"),
                pack_binding=[],
            )
        assert "pack binding required" in str(exc_info.value)
        assert isinstance(exc_info.value, ValueError)
