"""Tests for the GitHub Copilot classic governance integration (B3-05).

Mirrors the 6 parity cases required for all Python IDE adapters:
  P1 -- Pack-binding primacy: empty binding denied
  P2 -- Provider/flavour compliance gate
  P3 -- Output classifier (toolResult secret scan)
  P4 -- Output exfiltration scanner (llmResult PHI/secret scan)
  P5 -- policy_bridge round-trip
  P6 -- wrap_webhook dispatches to emit_event

Plus GitHub Copilot-specific tests:
  GHC-01 -- intercept_completion pre allows clean request
  GHC-02 -- intercept_completion pre blocks secret in surrounding context (PT-ADAPT-GHCOPILOT-1)
  GHC-03 -- intercept_completion post blocks secret in completion text (PT-ADAPT-GHCOPILOT-2)
  GHC-04 -- intercept_completion blocks individual flavour under HIPAA (PT-ADAPT-GHCOPILOT-3)
  GHC-05 -- intercept_completion business flavour under HIPAA is allowed
  GHC-06 -- intercept_chat pre allows clean request
  GHC-07 -- intercept_chat pre blocks secret in prompt
  GHC-08 -- intercept_chat post blocks secret in response
  GHC-09 -- intercept_chat blocks individual flavour under HIPAA (PT-ADAPT-GHCOPILOT-3)
  GHC-10 -- content exclusion path blocking
  GHC-11 -- COPILOT_BAA_ELIGIBLE_FLAVOURS contains business and enterprise only
"""

from __future__ import annotations

import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.github_copilot import (
    GitHubCopilotGovernance,
    COPILOT_DATA_RETENTION,
    COPILOT_BAA_ELIGIBLE_FLAVOURS,
)

# ---------------------------------------------------------------------------
# Fake secret strings (assembled at runtime to avoid secret-leak-scanner)
# ---------------------------------------------------------------------------

_FAKE_SK_PREFIX = "sk-"
_FAKE_SK_SUFFIX = "abc12345678901234567890"
_FAKE_OPENAI_KEY = _FAKE_SK_PREFIX + _FAKE_SK_SUFFIX

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-ghc-001",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    copilot_flavour: str = "business",
    pack_binding: list[str] | None = None,
) -> GitHubCopilotGovernance:
    client = make_client(transport, enforce=enforce)
    return GitHubCopilotGovernance(
        client=client,
        agent_name="copilot-agent-01",
        pack_binding=pack_binding if pack_binding is not None else ["soc2"],
        copilot_flavour=copilot_flavour,  # type: ignore[arg-type]
    )


# ---------------------------------------------------------------------------
# P1 -- Pack-binding primacy
# ---------------------------------------------------------------------------

class TestPackBindingPrimacy:
    def test_empty_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "copilot-agent-01", "read_file", {"path": "/workspace/main.py"},
            pack_binding=[],
        )
        assert decision.denied

    def test_none_pack_binding_falls_back_to_instance_binding(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "copilot-agent-01", "read_file", {"path": "/workspace/main.py"},
            pack_binding=None,
        )
        assert decision.allowed

    def test_missing_pack_binding_on_emit_event_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.emit_event("toolCall", {
            "agentId": "copilot-agent-01",
            "toolName": "completion",
            "args": {},
        })
        assert decision.denied

    def test_completion_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_completion({
            "filePath": "/workspace/api.py",
            "surroundingContext": "def hello():",
        })
        assert decision.denied

    def test_chat_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_chat({
            "promptText": "Explain this function",
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# P2 -- Provider/flavour compliance gate
# ---------------------------------------------------------------------------

class TestFlavourCompliance:
    def test_business_flavour_under_soc2_allowed(self):
        """Business flavour under SOC2 (no HIPAA) is allowed."""
        adapter = _adapter(_transport(), copilot_flavour="business")
        decision = adapter.intercept_completion({
            "filePath": "/workspace/api.py",
            "surroundingContext": "def fetch_orders():",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_individual_flavour_non_hipaa_allowed(self):
        """Individual flavour without HIPAA binding is allowed."""
        adapter = _adapter(_transport(), copilot_flavour="individual")
        decision = adapter.intercept_completion({
            "filePath": "/workspace/api.py",
            "surroundingContext": "def fetch_orders():",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_enterprise_flavour_under_hipaa_allowed(self):
        """Enterprise flavour under HIPAA is BAA-eligible (allowed)."""
        adapter = _adapter(_transport(), copilot_flavour="enterprise")
        decision = adapter.intercept_completion({
            "filePath": "/workspace/api.py",
            "surroundingContext": "def process_data():",
            "packBinding": ["hipaa"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# P3 -- Output classifier (toolResult secret scan)
# ---------------------------------------------------------------------------

class TestOutputClassifier:
    def test_secret_in_tool_result_flags_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "copilot-agent-01", "completion",
            "SECRET_KEY=abc12345678",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert "secret" in captured.err.lower() or "classifier" in captured.err.lower()

    def test_clean_tool_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "copilot-agent-01", "completion",
            "def process(): pass",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P4 -- Output exfiltration scanner (llmResult)
# ---------------------------------------------------------------------------

class TestOutputExfiltrationScanner:
    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "copilot-agent-01", "copilot",
            "The patient_id is 12345 and diagnosis is diabetes.",
            pack_binding=["hipaa"],
        )
        captured = capsys.readouterr()
        assert "exfiltration" in captured.err.lower() or "phi" in captured.err.lower() or "secret" in captured.err.lower()

    def test_clean_llm_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "copilot-agent-01", "copilot",
            "Here is the refactored function.",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P5 -- policy_bridge round-trip
# ---------------------------------------------------------------------------

class TestPolicyBridge:
    def test_policy_bridge_callback_called(self):
        from connexum_governance.models import GovernanceDecision, DecisionType
        callback_calls = []

        def my_policy(event_type, payload):
            callback_calls.append((event_type, payload))
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="custom-allow",
                audit_id="bridge-ghc-001",
            )

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=my_policy)
        result = bridge.decide("toolCall", {
            "agentId": "copilot-agent-01",
            "toolName": "completion",
            "args": {},
        })
        assert len(callback_calls) == 1
        assert result.allowed

    def test_policy_bridge_falls_back_to_rest_api_when_callback_returns_none(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=lambda e, p: None)
        result = bridge.decide("toolCall", {
            "agentId": "copilot-agent-01",
            "toolName": "chat",
            "args": {},
        })
        assert result.allowed

    def test_policy_bridge_no_callback(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=None)
        result = bridge.decide("llmCall", {
            "agentId": "copilot-agent-01",
            "model": "copilot",
            "messageCount": 1,
        })
        assert result.allowed


# ---------------------------------------------------------------------------
# P6 -- wrap_webhook dispatches to emit_event
# ---------------------------------------------------------------------------

class TestWrapWebhook:
    def test_wrap_webhook_dispatches_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "copilot-agent-01",
            "toolName": "completion",
            "args": {},
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_wrap_webhook_missing_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({
                "agentId": "copilot-agent-01",
                "packBinding": ["soc2"],
            })

    def test_wrap_webhook_missing_agent_id_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({
                "eventType": "toolCall",
                "packBinding": ["soc2"],
            })

    def test_wrap_webhook_invalid_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="Unknown"):
            adapter.wrap_webhook({
                "eventType": "unknownSurface",
                "agentId": "copilot-agent-01",
                "packBinding": ["soc2"],
            })


# ---------------------------------------------------------------------------
# GHC-01 to GHC-11 -- GitHub Copilot-specific tests
# ---------------------------------------------------------------------------

class TestGitHubCopilotCompletion:
    def test_ghc_01_completion_pre_clean_allowed(self):
        """GHC-01: Clean pre-completion request is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_completion({
            "filePath": "/workspace/api.py",
            "surroundingContext": "def process_order(order_id: int):",
            "direction": "pre",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_ghc_02_completion_pre_secret_in_context_blocked(self):
        """GHC-02: Secret in surrounding context blocks pre-completion (PT-ADAPT-GHCOPILOT-1)."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_completion({
            "filePath": "/workspace/api.py",
            "surroundingContext": "key = " + _FAKE_OPENAI_KEY,
            "direction": "pre",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_ghc_03_completion_post_secret_in_completion_blocked(self):
        """GHC-03: Secret in completion text blocks post-completion (PT-ADAPT-GHCOPILOT-2)."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_completion({
            "completionText": "api_key = " + _FAKE_OPENAI_KEY,
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_ghc_04_completion_individual_under_hipaa_blocked(self):
        """GHC-04: Copilot Individual flavour is blocked under HIPAA (PT-ADAPT-GHCOPILOT-3)."""
        adapter = _adapter(_transport(), copilot_flavour="individual")
        decision = adapter.intercept_completion({
            "filePath": "/workspace/health/api.py",
            "surroundingContext": "def process_payment():",
            "direction": "pre",
            "packBinding": ["hipaa"],
        })
        assert decision.denied
        assert "individual" in decision.reason.lower()
        assert "baa" in decision.reason.lower() or "hipaa" in decision.reason.lower()

    def test_ghc_05_completion_business_under_hipaa_allowed(self):
        """GHC-05: Copilot Business flavour is BAA-eligible and allowed under HIPAA."""
        adapter = _adapter(_transport(), copilot_flavour="business")
        decision = adapter.intercept_completion({
            "filePath": "/workspace/health/api.py",
            "surroundingContext": "def process_payment():",
            "direction": "pre",
            "packBinding": ["hipaa"],
        })
        assert decision.allowed

    def test_ghc_10_content_exclusion_path_blocked(self):
        """GHC-10: File matching content exclusion path is blocked."""
        client = make_client(_transport(), enforce=False)
        adapter = GitHubCopilotGovernance(
            client=client,
            agent_name="copilot-agent-01",
            pack_binding=["soc2"],
            content_exclusion_paths=["secrets/", ".env"],
        )
        decision = adapter.intercept_completion({
            "filePath": "secrets/api_keys.py",
            "surroundingContext": "KEY = 'value'",
            "direction": "pre",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "exclusion" in decision.reason.lower() or "content" in decision.reason.lower()

    def test_ghc_post_clean_completion_allowed(self):
        """Post-completion scan with clean text is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_completion({
            "completionText": "def hello(): return 'world'",
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


class TestGitHubCopilotChat:
    def test_ghc_06_chat_pre_clean_allowed(self):
        """GHC-06: Clean pre-chat request is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "Explain how this function works",
            "direction": "pre",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_ghc_07_chat_pre_secret_in_prompt_blocked(self):
        """GHC-07: Secret in prompt text blocks chat request."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "My API key is " + _FAKE_OPENAI_KEY,
            "direction": "pre",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_ghc_08_chat_post_secret_in_response_blocked(self):
        """GHC-08: Secret in chat response blocks post-chat."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "responseText": "You can use this key: " + _FAKE_OPENAI_KEY,
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_ghc_09_chat_individual_under_hipaa_blocked(self):
        """GHC-09: Copilot Individual flavour is blocked on chat under HIPAA."""
        adapter = _adapter(_transport(), copilot_flavour="individual")
        decision = adapter.intercept_chat({
            "promptText": "How should I handle this?",
            "direction": "pre",
            "packBinding": ["hipaa"],
        })
        assert decision.denied
        assert "individual" in decision.reason.lower()

    def test_ghc_post_clean_chat_allowed(self):
        """Post-chat scan with clean response is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "responseText": "Here is the refactored function.",
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


class TestCopilotConstants:
    def test_ghc_11_baa_eligible_flavours(self):
        """GHC-11: Only business and enterprise are BAA-eligible."""
        assert "individual" not in COPILOT_BAA_ELIGIBLE_FLAVOURS
        assert "business" in COPILOT_BAA_ELIGIBLE_FLAVOURS
        assert "enterprise" in COPILOT_BAA_ELIGIBLE_FLAVOURS

    def test_data_retention_individual(self):
        """Individual retention posture is prompts-may-be-retained-for-training."""
        assert "training" in COPILOT_DATA_RETENTION["individual"]

    def test_data_retention_business(self):
        """Business retention posture is prompt-retention-disabled-by-default."""
        assert "disabled" in COPILOT_DATA_RETENTION["business"]

    def test_data_retention_enterprise(self):
        """Enterprise retention posture has enterprise-level commitments."""
        assert "enterprise" in COPILOT_DATA_RETENTION["enterprise"]


# ---------------------------------------------------------------------------
# Six canonical surfaces
# ---------------------------------------------------------------------------

class TestCanonicalSurfaces:
    def test_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("copilot-agent-01", pack_binding=["soc2"])
        assert decision.allowed

    def test_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "copilot-agent-01", "completion", {},
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_tool_result(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_result(
            "copilot-agent-01", "completion", "def hello(): pass",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_call(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "copilot-agent-01", "copilot",
            [{"role": "user", "content": "complete this"}],
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_result(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_result(
            "copilot-agent-01", "copilot",
            "def hello(): return 'world'",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_agent_end(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_end("copilot-agent-01", success=True, pack_binding=["soc2"])
        assert decision.allowed
