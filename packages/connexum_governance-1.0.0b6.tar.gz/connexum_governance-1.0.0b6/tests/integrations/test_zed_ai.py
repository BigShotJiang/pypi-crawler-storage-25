"""Tests for the Zed AI editor governance integration.

Spec: P3-SUB-IDE-11

Mirrors the TypeScript test suite case-for-case (parity discipline).

Coverage (38 tests):

Construction / config validation:
  01 -- Initialises with defaults (zed-cloud mode)
  02 -- Initialises with all-custom config
  03 -- Invalid deployment_mode raises ValueError (PT-ADAPT-ZED-3)
  04 -- Zero multi_buffer_edit_cap raises ValueError (PT-ADAPT-ZED-3)
  05 -- Negative multi_buffer_edit_cap raises ValueError (PT-ADAPT-ZED-3)
  06 -- PT-ADAPT-ZED-3: local_only_enforcement=False in zed-local-only raises ValueError

Pack-binding primacy (PT-ADAPT-ZED-1):
  07 -- Empty pack_binding denied on intercept_chat
  08 -- Empty pack_binding denied on intercept_inline_completion

intercept_inline_completion:
  09 -- Cloud mode inline completion => ALLOW
  10 -- Local-only mode + localProvider=True => ALLOW
  11 -- Local-only mode + no localProvider => DENY (PT-ADAPT-ZED-4)

intercept_chat:
  12 -- Cloud mode chat => ALLOW
  13 -- Local-only mode + no localProvider => DENY (PT-ADAPT-ZED-4)
  14 -- BYOK mode chat => ALLOW

intercept_assistant_thread:
  15 -- Cloud mode assistant thread => ALLOW
  16 -- Local-only mode + no localProvider => DENY (PT-ADAPT-ZED-4)

intercept_slash_command:
  17 -- Known slash command with no allow-list => ALLOW
  18 -- Slash command in allow-list => ALLOW
  19 -- Slash command NOT in allow-list => DENY (zed-slash-command-not-allowed)
  20 -- Leading slash stripped from command on comparison

intercept_inline_transform:
  21 -- Cloud mode inline transform => ALLOW
  22 -- Local-only mode + no localProvider => DENY (PT-ADAPT-ZED-4)

intercept_terminal_assist:
  23 -- Terminal assist denied by default (allow_terminal_assist=False)
  24 -- Terminal assist allowed with opt-in
  25 -- Terminal assist allowed with opt-in + matching prefix
  26 -- Terminal assist denied when prefix does not match
  27 -- PT-ADAPT-ZED-4: local-only mode + allow_terminal_assist=True STILL denied

intercept_file_context:
  28 -- Clean file => ALLOW
  29 -- File with AWS key content => DENY (PT-ADAPT-ZED-5)
  30 -- File with generic SECRET= env var => DENY
  31 -- File with database URL containing credentials => DENY
  32 -- PT-ADAPT-ZED-5: .env-like content denied (zed-file-context-secret-detected)
  33 -- PT-ADAPT-ZED-2: secret content never echoed in deny reason

intercept_multi_buffer_edit:
  34 -- Buffer count within cap => ALLOW
  35 -- Buffer count exceeding cap => DENY (zed-multi-buffer-edit-cap-exceeded)

intercept_voice_input:
  36 -- Voice input with allow_voice_input=False => DENY
  37 -- PT-ADAPT-ZED-4: local-only mode + allow_voice_input=True STILL denied
  38 -- Voice input allowed with opt-in in cloud mode
"""

from __future__ import annotations

import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.zed_ai import (
    ZedAIGovernedClient,
    ZedAIPolicyBridge,
    ZED_VALID_DEPLOYMENT_MODES,
    _scan_for_secrets,
)
from connexum_governance.models import DecisionType

# ---------------------------------------------------------------------------
# Fake secret tokens -- assembled at runtime to avoid static-analysis scanners
# ---------------------------------------------------------------------------

_FAKE_AWS_KEY = "AKIA" + "ABCDEFGHIJKLMNOP"
_FAKE_OPENAI_KEY = "sk-" + "abc12345678901234567890"
_FAKE_DB_URL = "postgres" + "://user:s3cret@host:5432/mydb"
_FAKE_ENV_SECRET = "API_KEY" + "=supersecretvalue123"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW_PATHS = {
    "/api/v1/governance/check-action": {
        "decision": "ALLOW",
        "reason": "Permitted",
        "auditId": "aud-zed-001",
    },
    "/api/v1/governance/check-task": {
        "decision": "ALLOW",
        "reason": "Permitted",
        "auditId": "aud-zed-002",
    },
    "/api/v1/governance/check-plan": {
        "decision": "ALLOW",
        "reason": "Permitted",
        "auditId": "aud-zed-003",
    },
    "/api/v1/governance/check-delegation": {
        "decision": "ALLOW",
        "reason": "Permitted",
        "auditId": "aud-zed-004",
    },
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_ALLOW_PATHS)


def _adapter(
    transport: httpx.MockTransport | None = None,
    enforce: bool = False,
    deployment_mode: str = "zed-cloud",
    local_only_enforcement: bool = True,
    allow_terminal_assist: bool = False,
    allowed_terminal_prefixes: list[str] | None = None,
    allow_voice_input: bool = False,
    multi_buffer_edit_cap: int = 15,
    slash_command_allow_list: list[str] | None = None,
    pack_binding: list[str] | None = None,
) -> ZedAIGovernedClient:
    t = transport or _transport()
    client = make_client(t, enforce=enforce)
    return ZedAIGovernedClient(
        client=client,
        agent_name="zed-test-agent",
        pack_binding=pack_binding if pack_binding is not None else ["soc2"],
        deployment_mode=deployment_mode,
        local_only_enforcement=local_only_enforcement,
        allow_terminal_assist=allow_terminal_assist,
        allowed_terminal_prefixes=allowed_terminal_prefixes,
        allow_voice_input=allow_voice_input,
        multi_buffer_edit_cap=multi_buffer_edit_cap,
        slash_command_allow_list=slash_command_allow_list,
    )


# ---------------------------------------------------------------------------
# Construction / config validation
# ---------------------------------------------------------------------------

class TestZedAIConstruction:
    def test_01_initialises_with_defaults(self):
        adapter = _adapter()
        assert adapter.deployment_mode == "zed-cloud"
        assert adapter.allow_terminal_assist is False
        assert adapter.allow_voice_input is False
        assert adapter.local_only_enforcement is True
        assert adapter.multi_buffer_edit_cap == 15
        assert adapter.slash_command_allow_list is None

    def test_02_initialises_with_all_custom_config(self):
        adapter = _adapter(
            deployment_mode="zed-byok",
            allow_terminal_assist=True,
            allowed_terminal_prefixes=["npm ", "npx "],
            allow_voice_input=False,
            multi_buffer_edit_cap=10,
            slash_command_allow_list=["explain", "refactor", "test"],
        )
        assert adapter.deployment_mode == "zed-byok"
        assert adapter.allow_terminal_assist is True
        assert adapter.allowed_terminal_prefixes == ["npm ", "npx "]
        assert adapter.multi_buffer_edit_cap == 10
        assert adapter.slash_command_allow_list == ["explain", "refactor", "test"]

    def test_03_invalid_deployment_mode_raises(self):
        with pytest.raises(ValueError, match="invalid deployment_mode"):
            _adapter(deployment_mode="zed-invalid")

    def test_04_zero_multi_buffer_edit_cap_raises(self):
        with pytest.raises(ValueError, match="multi_buffer_edit_cap"):
            _adapter(multi_buffer_edit_cap=0)

    def test_05_negative_multi_buffer_edit_cap_raises(self):
        with pytest.raises(ValueError, match="multi_buffer_edit_cap"):
            _adapter(multi_buffer_edit_cap=-1)

    def test_06_local_only_enforcement_false_in_local_mode_raises(self):
        """PT-ADAPT-ZED-3: local_only_enforcement=False in zed-local-only raises ValueError."""
        with pytest.raises(ValueError, match="local_only_enforcement=False is not permitted"):
            _adapter(
                deployment_mode="zed-local-only",
                local_only_enforcement=False,
            )


# ---------------------------------------------------------------------------
# Pack-binding primacy (PT-ADAPT-ZED-1)
# ---------------------------------------------------------------------------

class TestZedAIPackBinding:
    def test_07_empty_pack_binding_denied_on_chat(self):
        adapter = _adapter(pack_binding=[])
        result = adapter.intercept_chat({"prompt": "Hello", "packBinding": []})
        assert result.decision == DecisionType.DENY
        assert "pack-binding" in result.reason.lower() or "no pack binding" in result.reason.lower()

    def test_08_empty_pack_binding_denied_on_inline_completion(self):
        adapter = _adapter(pack_binding=[])
        result = adapter.intercept_inline_completion({
            "prompt": "const x =",
            "packBinding": [],
        })
        assert result.decision == DecisionType.DENY
        assert "pack-binding" in result.reason.lower() or "no pack binding" in result.reason.lower()


# ---------------------------------------------------------------------------
# intercept_inline_completion
# ---------------------------------------------------------------------------

class TestZedAIInlineCompletion:
    def test_09_cloud_mode_inline_completion_allow(self):
        adapter = _adapter(deployment_mode="zed-cloud")
        result = adapter.intercept_inline_completion({
            "prompt": "const x =",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_10_local_only_mode_with_local_provider_allow(self):
        """Local-only mode + localProvider=True => ALLOW."""
        adapter = _adapter(deployment_mode="zed-local-only")
        result = adapter.intercept_inline_completion({
            "prompt": "function foo(",
            "packBinding": ["soc2"],
            "localProvider": True,
        })
        assert result.decision == DecisionType.ALLOW

    def test_11_local_only_mode_no_local_provider_deny(self):
        """PT-ADAPT-ZED-4: local-only mode + no localProvider => DENY."""
        adapter = _adapter(deployment_mode="zed-local-only")
        result = adapter.intercept_inline_completion({
            "prompt": "const y =",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-local-only-network-not-permitted" in result.reason


# ---------------------------------------------------------------------------
# intercept_chat
# ---------------------------------------------------------------------------

class TestZedAIChat:
    def test_12_cloud_mode_chat_allow(self):
        adapter = _adapter(deployment_mode="zed-cloud")
        result = adapter.intercept_chat({"prompt": "Explain this code", "packBinding": ["soc2"]})
        assert result.decision == DecisionType.ALLOW

    def test_13_local_only_mode_no_local_provider_deny(self):
        """PT-ADAPT-ZED-4: local-only mode + no localProvider => DENY."""
        adapter = _adapter(deployment_mode="zed-local-only")
        result = adapter.intercept_chat({"prompt": "What does this do?", "packBinding": ["soc2"]})
        assert result.decision == DecisionType.DENY
        assert "zed-local-only-network-not-permitted" in result.reason
        assert "chat" in result.reason

    def test_14_byok_mode_chat_allow(self):
        adapter = _adapter(deployment_mode="zed-byok")
        result = adapter.intercept_chat({"prompt": "Refactor this", "packBinding": ["soc2"]})
        assert result.decision == DecisionType.ALLOW


# ---------------------------------------------------------------------------
# intercept_assistant_thread
# ---------------------------------------------------------------------------

class TestZedAIAssistantThread:
    def test_15_cloud_mode_assistant_thread_allow(self):
        adapter = _adapter(deployment_mode="zed-cloud")
        result = adapter.intercept_assistant_thread({
            "prompt": "Continue this conversation",
            "threadId": "thread-abc-123",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_16_local_only_mode_no_local_provider_deny(self):
        """PT-ADAPT-ZED-4."""
        adapter = _adapter(deployment_mode="zed-local-only")
        result = adapter.intercept_assistant_thread({
            "prompt": "Follow up",
            "threadId": "thread-xyz-456",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-local-only-network-not-permitted" in result.reason


# ---------------------------------------------------------------------------
# intercept_slash_command
# ---------------------------------------------------------------------------

class TestZedAISlashCommand:
    def test_17_no_allow_list_any_command_allowed(self):
        adapter = _adapter()
        result = adapter.intercept_slash_command({
            "command": "explain",
            "args": "",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_18_command_in_allow_list_allowed(self):
        adapter = _adapter(slash_command_allow_list=["explain", "refactor", "test"])
        result = adapter.intercept_slash_command({
            "command": "refactor",
            "args": "this function",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_19_command_not_in_allow_list_denied(self):
        adapter = _adapter(slash_command_allow_list=["explain", "refactor"])
        result = adapter.intercept_slash_command({
            "command": "migrate",
            "args": "database",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-slash-command-not-allowed" in result.reason
        assert "migrate" in result.reason

    def test_20_leading_slash_stripped_on_comparison(self):
        """Leading slash in command should be stripped before allow-list comparison."""
        adapter = _adapter(slash_command_allow_list=["explain"])
        result = adapter.intercept_slash_command({
            "command": "/explain",
            "args": "",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW


# ---------------------------------------------------------------------------
# intercept_inline_transform
# ---------------------------------------------------------------------------

class TestZedAIInlineTransform:
    def test_21_cloud_mode_inline_transform_allow(self):
        adapter = _adapter(deployment_mode="zed-cloud")
        result = adapter.intercept_inline_transform({
            "selection": "const x = 1",
            "instruction": "convert to TypeScript interface",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_22_local_only_mode_no_local_provider_deny(self):
        """PT-ADAPT-ZED-4."""
        adapter = _adapter(deployment_mode="zed-local-only")
        result = adapter.intercept_inline_transform({
            "selection": "function f() {}",
            "instruction": "add JSDoc",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-local-only-network-not-permitted" in result.reason


# ---------------------------------------------------------------------------
# intercept_terminal_assist
# ---------------------------------------------------------------------------

class TestZedAITerminalAssist:
    def test_23_terminal_assist_denied_by_default(self):
        adapter = _adapter(allow_terminal_assist=False)
        result = adapter.intercept_terminal_assist({
            "command": "npm test",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-terminal-assist-not-permitted" in result.reason

    def test_24_terminal_assist_allowed_with_opt_in(self):
        adapter = _adapter(allow_terminal_assist=True)
        result = adapter.intercept_terminal_assist({
            "command": "npm test",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_25_terminal_assist_allowed_with_matching_prefix(self):
        adapter = _adapter(
            allow_terminal_assist=True,
            allowed_terminal_prefixes=["npm ", "npx "],
        )
        result = adapter.intercept_terminal_assist({
            "command": "npm run build",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_26_terminal_assist_denied_prefix_no_match(self):
        adapter = _adapter(
            allow_terminal_assist=True,
            allowed_terminal_prefixes=["npm ", "npx "],
        )
        result = adapter.intercept_terminal_assist({
            "command": "rm -rf dist",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-terminal-assist-prefix-not-allowed" in result.reason

    def test_27_local_only_mode_allow_terminal_still_denied(self):
        """PT-ADAPT-ZED-4: allow_terminal_assist=True cannot override local-only mode."""
        adapter = _adapter(
            deployment_mode="zed-local-only",
            allow_terminal_assist=True,
        )
        result = adapter.intercept_terminal_assist({
            "command": "npm test",
            "packBinding": ["soc2"],
            # No localProvider=True => local-only gate fires first
        })
        assert result.decision == DecisionType.DENY
        assert "zed-local-only-network-not-permitted" in result.reason
        # Must NOT mention the opt-in gate reason (that gate was not reached)
        assert "zed-terminal-assist-not-permitted" not in result.reason


# ---------------------------------------------------------------------------
# intercept_file_context
# ---------------------------------------------------------------------------

class TestZedAIFileContext:
    def test_28_clean_file_allow(self):
        adapter = _adapter()
        result = adapter.intercept_file_context({
            "filePath": "src/utils.ts",
            "content": "export function add(a: number, b: number) { return a + b; }",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_29_file_with_aws_key_denied(self):
        """PT-ADAPT-ZED-5."""
        adapter = _adapter()
        result = adapter.intercept_file_context({
            "filePath": "config.env",
            "content": f"AWS_ACCESS_KEY_ID={_FAKE_AWS_KEY}",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-file-context-secret-detected" in result.reason
        assert "AWS access key" in result.reason

    def test_30_file_with_secret_env_var_denied(self):
        adapter = _adapter()
        result = adapter.intercept_file_context({
            "filePath": ".env.local",
            "content": _FAKE_ENV_SECRET,
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-file-context-secret-detected" in result.reason

    def test_31_file_with_db_url_credentials_denied(self):
        adapter = _adapter()
        result = adapter.intercept_file_context({
            "filePath": "db.config.ts",
            "content": f"const db = '{_FAKE_DB_URL}';",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-file-context-secret-detected" in result.reason

    def test_32_dotenv_content_denied(self):
        """PT-ADAPT-ZED-5: .env-like content denied."""
        adapter = _adapter()
        result = adapter.intercept_file_context({
            "filePath": ".env",
            "content": f"DATABASE_URL={_FAKE_DB_URL}\nAPI_KEY=verysecretvalue123",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-file-context-secret-detected" in result.reason

    def test_33_secret_not_echoed_in_deny_reason(self):
        """PT-ADAPT-ZED-2: secret content never echoed in deny reason."""
        adapter = _adapter()
        result = adapter.intercept_file_context({
            "filePath": "secrets.env",
            "content": f"OPENAI_KEY={_FAKE_OPENAI_KEY}",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        # The raw secret value must not appear in the deny reason
        assert _FAKE_OPENAI_KEY not in result.reason


# ---------------------------------------------------------------------------
# intercept_multi_buffer_edit
# ---------------------------------------------------------------------------

class TestZedAIMultiBufferEdit:
    def test_34_buffer_count_within_cap_allow(self):
        adapter = _adapter(multi_buffer_edit_cap=15)
        buffer_paths = [f"src/file{i}.ts" for i in range(5)]
        result = adapter.intercept_multi_buffer_edit({
            "bufferPaths": buffer_paths,
            "instruction": "Add error handling",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW

    def test_35_buffer_count_exceeds_cap_denied(self):
        adapter = _adapter(multi_buffer_edit_cap=5)
        buffer_paths = [f"src/file{i}.ts" for i in range(10)]
        result = adapter.intercept_multi_buffer_edit({
            "bufferPaths": buffer_paths,
            "instruction": "Refactor all",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-multi-buffer-edit-cap-exceeded" in result.reason
        assert "10" in result.reason
        assert "5" in result.reason


# ---------------------------------------------------------------------------
# intercept_voice_input
# ---------------------------------------------------------------------------

class TestZedAIVoiceInput:
    def test_36_voice_input_denied_by_default(self):
        adapter = _adapter(deployment_mode="zed-cloud", allow_voice_input=False)
        result = adapter.intercept_voice_input({
            "transcribedText": "Refactor this function",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.DENY
        assert "zed-voice-input-not-permitted" in result.reason

    def test_37_local_only_mode_allow_voice_still_denied(self):
        """PT-ADAPT-ZED-4: allow_voice_input=True cannot override local-only mode."""
        adapter = _adapter(
            deployment_mode="zed-local-only",
            allow_voice_input=True,
        )
        result = adapter.intercept_voice_input({
            "transcribedText": "Explain this bug",
            "packBinding": ["soc2"],
            # No localProvider=True => local-only gate fires first
        })
        assert result.decision == DecisionType.DENY
        assert "zed-local-only-network-not-permitted" in result.reason
        assert "zed-voice-input-not-permitted" not in result.reason

    def test_38_voice_input_allowed_with_opt_in_cloud_mode(self):
        adapter = _adapter(deployment_mode="zed-cloud", allow_voice_input=True)
        result = adapter.intercept_voice_input({
            "transcribedText": "Add logging here",
            "packBinding": ["soc2"],
        })
        assert result.decision == DecisionType.ALLOW
