"""Tests for CrewAI governance integration.

Covers:
- GovernanceCallback happy path (task start/end, tool start/end)
- Denial and approval routing
- PT-BIND-PYTHON-1: pack binding required at Python entry points
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.crewai import GovernanceCallback
from connexum_governance.models import (
    AgentIdentity,
    TaskContext,
    UnboundDataError,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-crew-001"}
DENY = {"decision": "DENY", "reason": "Task blocked", "auditId": "aud-crew-002"}
REQUIRE_APPROVAL = {
    "decision": "REQUIRE_APPROVAL",
    "reason": "Task requires human approval",
    "auditId": "aud-crew-003",
}


class MockTask:
    """Simulates a CrewAI Task object."""
    id = "crew-task-001"
    task_type = "analysis"
    description = "Analyze report for anomalies"


class MockTaskWithBinding:
    """Simulates a CrewAI Task that carries pack_binding."""
    id = "crew-task-002"
    task_type = "analysis"
    description = "Analyze PHI with pack binding"
    pack_binding = ["hipaa"]


def _allow_transport() -> httpx.MockTransport:
    def hf(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=ALLOW)
    return httpx.MockTransport(hf)


def _deny_transport() -> httpx.MockTransport:
    def hf(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/governance/check-task":
            return httpx.Response(200, json=DENY)
        if request.url.path == "/api/v1/governance/check-action":
            return httpx.Response(200, json=DENY)
        return httpx.Response(200, json={"ok": True})
    return httpx.MockTransport(hf)


def _approval_transport() -> httpx.MockTransport:
    def hf(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=REQUIRE_APPROVAL)
    return httpx.MockTransport(hf)


# ---------------------------------------------------------------------------
# GovernanceCallback functional tests
# ---------------------------------------------------------------------------

class TestGovernanceCallbackCrewAI:
    """Basic functional coverage for GovernanceCallback."""

    def test_task_start_allowed(self):
        """on_task_start returns None when governance allows."""
        client = make_client(_allow_transport())
        callback = GovernanceCallback(
            client=client,
            agent_name="analyst",
            pack_binding=["soc2"],
        )
        result = callback.on_task_start(MockTask())
        assert result is None

    def test_task_start_denied_non_enforce(self):
        """on_task_start returns denial string when not enforcing."""
        client = make_client(_deny_transport(), enforce=False)
        callback = GovernanceCallback(
            client=client,
            agent_name="analyst",
            pack_binding=["soc2"],
        )
        result = callback.on_task_start(MockTask())
        assert result is not None
        assert "[GOVERNANCE DENIED]" in result

    def test_task_start_denied_enforce_raises(self):
        """on_task_start raises GovernanceViolation when enforce=True."""
        client = make_client(_deny_transport(), enforce=True)
        callback = GovernanceCallback(
            client=client,
            agent_name="analyst",
            pack_binding=["soc2"],
        )
        with pytest.raises(GovernanceViolation):
            callback.on_task_start(MockTask())

    def test_task_end_closes_audit(self):
        """on_task_end calls report_result to close the audit chain entry."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-task":
                return httpx.Response(200, json=ALLOW)
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json={"ok": True})

        client = make_client(httpx.MockTransport(hf))
        callback = GovernanceCallback(
            client=client,
            agent_name="analyst",
            pack_binding=["soc2"],
        )
        callback.on_task_start(MockTask())
        callback.on_task_end(MockTask(), "Task complete")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-crew-001"
        assert reported[0]["success"] is True

    def test_approval_required_on_task(self):
        """on_task_start returns PENDING string when approval required."""
        client = make_client(_approval_transport(), enforce=False)
        callback = GovernanceCallback(
            client=client,
            agent_name="analyst",
            pack_binding=["hipaa"],
        )
        result = callback.on_task_start(MockTask())
        assert result is not None
        assert "[GOVERNANCE PENDING]" in result

    def test_tool_start_allowed(self):
        """on_tool_start returns None when governance allows."""
        client = make_client(_allow_transport())
        callback = GovernanceCallback(
            client=client,
            agent_name="analyst",
            pack_binding=["soc2"],
        )
        result = callback.on_tool_start("search", {"query": "test"})
        assert result is None

    def test_tool_start_denied_non_enforce(self):
        """on_tool_start returns denial string when not enforcing."""
        client = make_client(_deny_transport(), enforce=False)
        callback = GovernanceCallback(
            client=client,
            agent_name="analyst",
            pack_binding=["soc2"],
        )
        result = callback.on_tool_start("exec_code", {"code": "rm -rf /"})
        assert result is not None
        assert "[GOVERNANCE DENIED]" in result

    def test_task_level_pack_binding_overrides_callback(self):
        """Task-level pack_binding attribute takes precedence."""
        captured_bodies: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-task":
                captured_bodies.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        client = make_client(httpx.MockTransport(hf))
        callback = GovernanceCallback(
            client=client,
            agent_name="analyst",
            pack_binding=["soc2"],  # callback-level binding
        )
        callback.on_task_start(MockTaskWithBinding())  # task carries ["hipaa"]

        assert len(captured_bodies) == 1
        body = captured_bodies[0]
        # Task-level binding ["hipaa"] should be forwarded (not ["soc2"])
        assert body.get("packBinding") == ["hipaa"]


# ---------------------------------------------------------------------------
# PT-BIND-PYTHON-1: pack binding required at Python entry points (CrewAI)
# C2 fix -- pack-binding primacy enforcement
# ---------------------------------------------------------------------------

class TestPtBindPython1CrewAI:
    """PT-BIND-PYTHON-1: pack binding required at Python CrewAI entry points.

    Pen-test ID: PT-BIND-PYTHON-1
    Finding: C2 -- pack-binding primacy not enforced in Python SDK.
    Fix: TaskContext / DelegationContext raise UnboundDataError when empty.
    """

    def test_task_context_without_pack_binding_raises_unbound_data_error(self):
        """PT-BIND-PYTHON-1: check_task without pack_binding raises UnboundDataError."""
        with pytest.raises(UnboundDataError, match="pack binding required"):
            TaskContext(
                task_id="pt-bind-1",
                task_type="analysis",
                description="Pack binding missing",
                agent=AgentIdentity(name="crew-agent"),
                pack_binding=[],
            )

    def test_task_context_explicit_empty_raises(self):
        """PT-BIND-PYTHON-1: explicit empty list triggers UnboundDataError (not silent pass)."""
        with pytest.raises(UnboundDataError) as exc_info:
            TaskContext(
                task_id="pt-bind-2",
                task_type="deploy",
                description="Deploy without binding",
                agent=AgentIdentity(name="crew-deployer"),
                pack_binding=[],
            )
        assert isinstance(exc_info.value, ValueError)
        assert "pack binding required" in str(exc_info.value).lower()

    def test_tool_output_with_secret_triggers_denied_warning(self):
        """PT-BIND-PYTHON-1 (extension): tool output containing a secret pattern
        is classified and a warning is emitted. The classification uses the
        G-series path via on_tool_end.

        Note: The CrewAI on_tool_end hook currently does not call classify_output
        (it is a no-op per the current implementation). This test verifies that
        on_task_start + on_task_end complete the governance cycle without error
        even when tool output contains a secret pattern, and that the audit
        chain is properly closed.

        The full G-series classification on tool outputs is enforced via C1
        (postActionClassify). This test documents the expected no-op on_tool_end
        behaviour pending C1 wiring.
        """
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-task":
                return httpx.Response(200, json=ALLOW)
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json={"ok": True})

        client = make_client(httpx.MockTransport(hf))
        callback = GovernanceCallback(
            client=client,
            agent_name="crew-agent",
            pack_binding=["hipaa"],
        )
        callback.on_task_start(MockTask())
        # Simulated tool output that contains a secret pattern
        secret_output = "sk-ant-api-key-1234567890abcdefghij"
        callback.on_tool_end("search", secret_output)
        # on_task_end closes audit chain
        callback.on_task_end(MockTask(), secret_output)

        # Audit chain entry must be closed
        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-crew-001"
