"""Tests for GovernedHuggingFace integration.

Closes F-NEW-PRODUCT-AGENT-DIR-HUGGINGFACE-WRAPPER.

Covers the six parity cases from the governed-LLM wrapper contract:
1. Happy path ALLOW — InferenceClient (chat_completion shape)
2. Happy path ALLOW — transformers.pipeline (inputs string shape)
3. Secret leak G2 response classification
4. PHI ingress refusal (DENY decision)
5. Provider compliance registration (no BAA)
6. Audit chain append (report_result called on intercept_response)

Additional:
7. wrap() proxy returns GovernedHuggingFaceProxy
8. Proxy DENY returns governance-denied dict (enforce=False)
9. raw HTTP shape (model + inputs) correctly parsed
10. GovernedHuggingFace == HuggingFaceGovernance alias (backward compat)
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.huggingface import (
    GovernedHuggingFace,
    GovernedHuggingFaceProxy,
    HuggingFaceGovernance,  # backward-compat alias
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared response fixtures
# ---------------------------------------------------------------------------

ALLOW_WITH_AUDIT = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-hf-001",
}

PHI_DENY = {
    "decision": "DENY",
    "reason": "G3: PHI ingress blocked under HIPAA pack",
    "auditId": "aud-hf-003",
}

CLASSIFY_CLEAN = {
    "allowed": True,
    "guardsTriggered": [],
    "auditId": "aud-hf-001",
}

CLASSIFY_SECRET_LEAK = {
    "allowed": False,
    "guardsTriggered": ["G2_SECRET_LEAK"],
    "auditId": "aud-hf-001",
}


def _make_transport_with_classify(
    action_response: dict, classify_response: dict
) -> httpx.MockTransport:
    return make_transport(
        {
            "/api/v1/governance/check-action": action_response,
            "/api/v1/governance/report-result": {"ok": True},
            "/api/v1/governance/classify": classify_response,
            "/api/v1/governance/provider-compliance": {"ok": True},
            "/api/v1/health": {"status": "healthy"},
        }
    )


def _make_hf(transport: httpx.MockTransport, enforce: bool = True) -> GovernedHuggingFace:
    client = make_client(transport, enforce=enforce)
    return GovernedHuggingFace(client=client, agent_name="hf-agent", agent_role="generator")


def _mock_inference_client(response: Any) -> Any:
    """Minimal InferenceClient mock that returns a canned response."""

    class MockInferenceClient:
        model = "meta-llama/Llama-3.1-8B-Instruct"

        def text_generation(self, prompt: str, **kwargs: Any) -> Any:
            return response

        def chat_completion(self, messages: Any, **kwargs: Any) -> Any:
            return response

    return MockInferenceClient()


def _mock_pipeline(response: Any) -> Any:
    """Minimal transformers.Pipeline mock."""

    class MockPipeline:
        def __call__(self, inputs: Any, **kwargs: Any) -> Any:
            return response

    return MockPipeline()


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW — InferenceClient chat_completion shape
# ---------------------------------------------------------------------------


class TestGovernedHuggingFaceHappyPathChat:
    def test_intercept_request_allow_chat_shape(self) -> None:
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        hf = _make_hf(transport)

        decision = hf.intercept_request(
            {
                "model": "meta-llama/Llama-3.1-8B-Instruct",
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 256,
            }
        )
        assert decision.allowed
        assert decision.audit_id == "aud-hf-001"

    def test_intercept_response_clean_dict_shape(self) -> None:
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        hf = _make_hf(transport)

        # HF chat_completion response dict shape
        response = {
            "choices": [{"message": {"role": "assistant", "content": "Hello back"}}]
        }
        classified = hf.intercept_response(response=response, audit_id="aud-hf-001")
        assert classified.allowed
        assert classified.guards_triggered == []


# ---------------------------------------------------------------------------
# 2. Happy path ALLOW — transformers.pipeline inputs string shape
# ---------------------------------------------------------------------------


class TestGovernedHuggingFaceHappyPathPipeline:
    def test_intercept_request_allow_inputs_string_shape(self) -> None:
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        hf = _make_hf(transport)

        decision = hf.intercept_request(
            {
                "model": "gpt2",
                "inputs": "What is the meaning of life?",
                "max_new_tokens": 128,
            }
        )
        assert decision.allowed

    def test_inputs_string_populates_system_digest(self) -> None:
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        hf = _make_hf(t)

        hf.intercept_request(
            {"model": "gpt2", "inputs": "Explain quantum computing in simple terms."}
        )
        assert "quantum computing" in captured[0]["input"]["systemPromptDigest"]
        assert captured[0]["input"]["provider"] == "huggingface"

    def test_intercept_response_list_of_dict_shape(self) -> None:
        """HF text-generation returns list[dict] with generated_text."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        hf = _make_hf(transport)

        response = [{"generated_text": "The meaning of life is 42."}]
        classified = hf.intercept_response(response=response, audit_id="aud-hf-001")
        assert classified.allowed

    def test_intercept_response_raw_string_shape(self) -> None:
        """HF Inference API sometimes returns a raw string."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        hf = _make_hf(transport)

        classified = hf.intercept_response(response="Some generated text.", audit_id="aud-hf-001")
        assert classified.allowed


# ---------------------------------------------------------------------------
# 3. Secret leak G2 response classification
# ---------------------------------------------------------------------------


class TestGovernedHuggingFaceSecretLeak:
    def test_g2_secret_in_response(self) -> None:
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        hf = _make_hf(transport)

        classified = hf.intercept_response(
            response={"generated_text": "hf_abc123secrettoken"},
            audit_id="aud-hf-001",
        )
        assert not classified.allowed
        assert "G2_SECRET_LEAK" in classified.guards_triggered


# ---------------------------------------------------------------------------
# 4. PHI ingress refusal
# ---------------------------------------------------------------------------


class TestGovernedHuggingFacePhiIngress:
    def test_phi_denied_no_enforce(self) -> None:
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        hf = _make_hf(transport, enforce=False)

        decision = hf.intercept_request(
            {
                "model": "meta-llama/Llama-3.1-8B-Instruct",
                "messages": [
                    {"role": "system", "content": "Patient MRN: 12345, DOB: 1990-03-15"}
                ],
            }
        )
        assert decision.denied

    def test_phi_raises_when_enforce(self) -> None:
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        hf = _make_hf(transport, enforce=True)

        with pytest.raises(GovernanceViolation):
            hf.intercept_request(
                {
                    "model": "gpt2",
                    "inputs": "Patient SSN: 123-45-6789 DOB: 1990-01-01",
                }
            )


# ---------------------------------------------------------------------------
# 5. Provider compliance registration (no BAA)
# ---------------------------------------------------------------------------


class TestGovernedHuggingFaceProviderCompliance:
    def test_baa_not_available_registered(self) -> None:
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_hf(httpx.MockTransport(handler))
        assert len(registered) == 1
        assert registered[0]["provider"] == "huggingface"
        assert registered[0]["baaAvailable"] is False

    def test_notes_mention_enterprise_hub(self) -> None:
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_hf(httpx.MockTransport(handler))
        notes = registered[0]["notes"].lower()
        assert "enterprise" in notes or "baa" in notes


# ---------------------------------------------------------------------------
# 6. Audit chain append (report_result closes audit)
# ---------------------------------------------------------------------------


class TestGovernedHuggingFaceAuditChain:
    def test_report_result_closes_chain(self) -> None:
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_CLEAN)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        hf = _make_hf(t)

        hf.intercept_response(
            response={"generated_text": "Safe output"},
            audit_id="aud-hf-001",
        )
        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-hf-001"
        assert reported[0]["success"] is True

    def test_report_result_failure_on_blocked_response(self) -> None:
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_SECRET_LEAK)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        hf = _make_hf(t)

        hf.intercept_response(
            response={"generated_text": "hf_secrettoken"},
            audit_id="aud-hf-001",
        )
        assert reported[0]["success"] is False


# ---------------------------------------------------------------------------
# 7. wrap() proxy returns GovernedHuggingFaceProxy
# ---------------------------------------------------------------------------


class TestGovernedHuggingFaceProxy:
    def test_wrap_inference_client_returns_proxy(self) -> None:
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        hf = _make_hf(transport)

        proxy = hf.wrap(_mock_inference_client({"generated_text": "OK"}))
        assert isinstance(proxy, GovernedHuggingFaceProxy)

    def test_proxy_text_generation_allow(self) -> None:
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        hf = _make_hf(transport)

        mock_response = [{"generated_text": "The answer is 42."}]
        proxy = hf.wrap(_mock_inference_client(mock_response))
        result = proxy.text_generation(prompt="What is 6 * 7?")
        assert result == mock_response

    def test_proxy_pipeline_call_allow(self) -> None:
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        hf = _make_hf(transport)

        mock_response = [{"generated_text": "Hello world!"}]
        proxy = hf.wrap(_mock_pipeline(mock_response))
        result = proxy("Tell me a story")
        assert result == mock_response

    def test_proxy_deny_raises_when_enforce(self) -> None:
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        hf = _make_hf(transport, enforce=True)

        proxy = hf.wrap(_mock_inference_client({}))
        with pytest.raises(GovernanceViolation):
            proxy.text_generation(prompt="Patient SSN: 123-45-6789")

    def test_proxy_deny_returns_denial_dict_when_no_enforce(self) -> None:
        deny = {"decision": "DENY", "reason": "policy block", "auditId": "aud-x"}
        transport = _make_transport_with_classify(deny, CLASSIFY_CLEAN)
        hf = _make_hf(transport, enforce=False)

        proxy = hf.wrap(_mock_inference_client({}))
        result = proxy.text_generation(prompt="unsafe input")
        assert isinstance(result, dict)
        assert "[GOVERNANCE DENIED]" in str(result.get("generated_text", ""))


# ---------------------------------------------------------------------------
# 8. raw HTTP shape correctness
# ---------------------------------------------------------------------------


class TestGovernedHuggingFaceRawHttpShape:
    def test_raw_http_shape_provider_id_in_gov_input(self) -> None:
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        hf = _make_hf(t)

        # Raw HTTP HF Inference API shape
        hf.intercept_request(
            {
                "model": "sentence-transformers/all-MiniLM-L6-v2",
                "inputs": "My name is John Doe and I need help.",
            }
        )
        assert captured[0]["input"]["provider"] == "huggingface"
        assert captured[0]["input"]["model"] == "sentence-transformers/all-MiniLM-L6-v2"

    def test_max_new_tokens_forwarded_to_gov_input(self) -> None:
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        hf = _make_hf(t)

        hf.intercept_request(
            {"model": "gpt2", "inputs": "Hello", "max_new_tokens": 512}
        )
        assert captured[0]["input"]["maxTokens"] == 512

    def test_max_tokens_forwarded_from_chat_shape(self) -> None:
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        hf = _make_hf(t)

        hf.intercept_request(
            {
                "model": "meta-llama/Llama-3.1-8B-Instruct",
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 1024,
            }
        )
        assert captured[0]["input"]["maxTokens"] == 1024


# ---------------------------------------------------------------------------
# 9. Backward-compat alias: HuggingFaceGovernance is GovernedHuggingFace
# ---------------------------------------------------------------------------


class TestBackwardCompatAlias:
    def test_alias_is_same_class(self) -> None:
        assert HuggingFaceGovernance is GovernedHuggingFace

    def test_alias_instantiates_with_wrap(self) -> None:
        """Alias class must also carry wrap() — ensures alias is full class, not stub."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        client = make_client(transport)
        hf = HuggingFaceGovernance(client=client, agent_name="alias-agent")
        assert hasattr(hf, "wrap")


# ---------------------------------------------------------------------------
# 10. Subscription gate
# ---------------------------------------------------------------------------


class TestGovernedHuggingFaceSubscriptionGate:
    def test_subscription_revoked_blocks(self) -> None:
        sub_deny = {
            "decision": "DENY",
            "reason": "Subscription inactive",
            "auditId": "aud-sub-hf",
        }
        transport = _make_transport_with_classify(sub_deny, CLASSIFY_CLEAN)
        hf = _make_hf(transport, enforce=False)

        decision = hf.intercept_request(
            {
                "model": "gpt2",
                "inputs": "Hello",
            }
        )
        assert decision.denied
