"""Tests for the Microsoft Copilot Studio governance integration (P3-SUB-IDE-09).

Mirrors the TS test coverage (tests/ide/copilot-studio.test.ts).

Coverage:
  --- Initialization ---
  P-CS-01: valid cloud config initialises correctly
  P-CS-02: valid government config with gcc tier initialises correctly
  P-CS-03: valid sovereign config initialises correctly
  P-CS-04: PT-ADAPT-COPILOTSTUDIO-3 -- invalid deployment_mode raises ValueError
  P-CS-05: PT-ADAPT-COPILOTSTUDIO-3 -- invalid tenant_tier raises ValueError
  P-CS-06: PT-ADAPT-COPILOTSTUDIO-3 -- gcc + cloud mode conflict raises ValueError
  P-CS-07: PT-ADAPT-COPILOTSTUDIO-3 -- sovereign tier + government mode conflict raises ValueError
  P-CS-08: PT-ADAPT-COPILOTSTUDIO-3 -- commercial tier + government mode conflict raises ValueError
  P-CS-09: PT-ADAPT-COPILOTSTUDIO-1 -- empty pack_binding denied in intercept_agent_build
  P-CS-10: data_residency_region stored

  --- intercept_agent_build ---
  P-CS-11: description + owner present => ALLOW
  P-CS-12: empty agentDescription => DENY with copilot-studio-agent-description-required
  P-CS-13: whitespace agentDescription => DENY
  P-CS-14: empty agentOwner => DENY with copilot-studio-agent-owner-required
  P-CS-15: whitespace agentOwner => DENY
  P-CS-16: description + owner in government mode => ALLOW

  --- intercept_topic_creation ---
  P-CS-17: topicName present => ALLOW
  P-CS-18: empty topicName => ALLOW (advisory field only)
  P-CS-19: topic creation in government mode => ALLOW
  P-CS-20: PT-ADAPT-COPILOTSTUDIO-1 -- empty pack_binding denied in topic creation

  --- intercept_action_definition ---
  P-CS-21: no actionBody in cloud => ALLOW
  P-CS-22: Microsoft URL in government mode => ALLOW
  P-CS-23: PT-ADAPT-COPILOTSTUDIO-6 -- external URL in government => DENY
  P-CS-24: external URL in cloud mode => ALLOW
  P-CS-25: external URL in sovereign mode => DENY
  P-CS-26: allowed_connector_prefixes overrides default in government
  P-CS-27: multiple offending hosts in government => DENY

  --- intercept_connector_add ---
  P-CS-28: Microsoft connector in cloud => ALLOW
  P-CS-29: Microsoft connector in government => ALLOW
  P-CS-30: third-party connector in government => DENY
  P-CS-31: public-internet egress connector in government => DENY
  P-CS-32: third-party connector in cloud => ALLOW
  P-CS-33: connector in allowed_connector_prefixes in government => ALLOW
  P-CS-34: connector in sovereign mode follows government rules

  --- intercept_knowledge_source_add ---
  P-CS-35: sharepoint source in cloud => ALLOW
  P-CS-36: public-website source in cloud => ALLOW
  P-CS-37: public-website source in government => DENY
  P-CS-38: public-website source in sovereign => DENY
  P-CS-39: allowed_knowledge_sources list enforced in cloud
  P-CS-40: source not in allowed_knowledge_sources => DENY
  P-CS-41: uploaded-file source in government => ALLOW

  --- intercept_publish ---
  P-CS-42: teams channel in cloud => ALLOW
  P-CS-43: PT-ADAPT-COPILOTSTUDIO-4 -- public-web in government => DENY
  P-CS-44: public-web in sovereign => DENY with same reason code
  P-CS-45: teams in government => ALLOW
  P-CS-46: custom channel in government => ALLOW
  P-CS-47: allowed_channels list enforced in cloud
  P-CS-48: channel not in allowed_channels => DENY
  P-CS-49: sovereign + require_governance_center_approval=True + teams => ALLOW
  P-CS-50: sovereign without require_governance_center_approval + teams => DENY

  --- intercept_governance_center_policy ---
  P-CS-51: admin role + require_governance_center_approval=True => ALLOW
  P-CS-52: PT-ADAPT-COPILOTSTUDIO-5 -- non-admin role => DENY (copilot-studio-admin-only)
  P-CS-53: PT-ADAPT-COPILOTSTUDIO-5 -- empty role => DENY
  P-CS-54: sovereign + admin + require_approval=False => DENY
  P-CS-55: sovereign + admin + require_approval=True => ALLOW

  --- intercept_chat_test ---
  P-CS-56: clean prompt => ALLOW
  P-CS-57: Azure connection string in prompt => DENY
  P-CS-58: generic API_KEY in prompt => DENY
  P-CS-59: Bearer token in prompt => DENY

  --- PT-ADAPT-COPILOTSTUDIO-2: secrets not in audit entries ---
  P-CS-60: Azure connection string: raw secret value not in denial reason

  --- Constants ---
  P-CS-61: COPILOT_STUDIO_VALID_DEPLOYMENT_MODES correct
  P-CS-62: COPILOT_STUDIO_BAA_ELIGIBLE_MODES correct
  P-CS-63: COPILOT_STUDIO_VALID_TENANT_TIERS correct
  P-CS-64: COPILOT_STUDIO_GOVERNMENT_TENANT_TIERS correct
"""

from __future__ import annotations

import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.copilot_studio import (
    CopilotStudioGovernedClient,
    CopilotStudioPolicyBridge,
    COPILOT_STUDIO_VALID_DEPLOYMENT_MODES,
    COPILOT_STUDIO_BAA_ELIGIBLE_MODES,
    COPILOT_STUDIO_VALID_TENANT_TIERS,
    COPILOT_STUDIO_GOVERNMENT_TENANT_TIERS,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-cs-001",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    deployment_mode: str = "copilot-studio-cloud",
    tenant_tier: str | None = None,
    data_residency_region: str | None = None,
    allowed_channels: list[str] | None = None,
    allowed_connector_prefixes: list[str] | None = None,
    allowed_knowledge_sources: list[str] | None = None,
    require_governance_center_approval: bool = False,
    pack_binding: list[str] | None = None,
) -> CopilotStudioGovernedClient:
    client = make_client(transport, enforce=enforce)
    return CopilotStudioGovernedClient(
        client=client,
        agent_name="copilot-studio-test",
        pack_binding=pack_binding if pack_binding is not None else ["soc2"],
        deployment_mode=deployment_mode,
        tenant_tier=tenant_tier,
        data_residency_region=data_residency_region,
        allowed_channels=allowed_channels,
        allowed_connector_prefixes=allowed_connector_prefixes,
        allowed_knowledge_sources=allowed_knowledge_sources,
        require_governance_center_approval=require_governance_center_approval,
    )


def _cloud() -> CopilotStudioGovernedClient:
    return _adapter(_transport())


def _gov(**kwargs) -> CopilotStudioGovernedClient:
    return _adapter(_transport(), deployment_mode="copilot-studio-government", **kwargs)


def _sov(**kwargs) -> CopilotStudioGovernedClient:
    return _adapter(_transport(), deployment_mode="copilot-studio-sovereign", **kwargs)


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------

class TestInitialization:
    def test_p_cs_01_valid_cloud_config(self):
        adapter = _cloud()
        assert adapter.deployment_mode == "copilot-studio-cloud"
        assert adapter.tenant_tier is None

    def test_p_cs_02_valid_government_config_with_gcc(self):
        adapter = _gov(tenant_tier="gcc")
        assert adapter.deployment_mode == "copilot-studio-government"
        assert adapter.tenant_tier == "gcc"

    def test_p_cs_03_valid_sovereign_config(self):
        adapter = _sov(tenant_tier="sovereign", require_governance_center_approval=True)
        assert adapter.deployment_mode == "copilot-studio-sovereign"

    def test_p_cs_04_invalid_deployment_mode_raises(self):
        client = make_client(_transport())
        with pytest.raises(ValueError, match="invalid deployment_mode"):
            CopilotStudioGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="copilot-studio-unknown",
            )

    def test_p_cs_05_invalid_tenant_tier_raises(self):
        client = make_client(_transport())
        with pytest.raises(ValueError, match="invalid tenant_tier"):
            CopilotStudioGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="copilot-studio-cloud",
                tenant_tier="enterprise",
            )

    def test_p_cs_06_gcc_plus_cloud_conflict_raises(self):
        """PT-ADAPT-COPILOTSTUDIO-3: gcc tier + cloud mode conflict."""
        client = make_client(_transport())
        with pytest.raises(ValueError, match="conflicting"):
            CopilotStudioGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="copilot-studio-cloud",
                tenant_tier="gcc",
            )

    def test_p_cs_07_sovereign_tier_government_mode_conflict_raises(self):
        """PT-ADAPT-COPILOTSTUDIO-3: sovereign tier + government mode conflict."""
        client = make_client(_transport())
        with pytest.raises(ValueError, match="conflicting"):
            CopilotStudioGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="copilot-studio-government",
                tenant_tier="sovereign",
            )

    def test_p_cs_08_commercial_tier_government_mode_conflict_raises(self):
        """PT-ADAPT-COPILOTSTUDIO-3: commercial tier + government mode conflict."""
        client = make_client(_transport())
        with pytest.raises(ValueError, match="conflicting"):
            CopilotStudioGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["soc2"],
                deployment_mode="copilot-studio-government",
                tenant_tier="commercial",
            )

    def test_p_cs_09_empty_pack_binding_denied(self):
        """PT-ADAPT-COPILOTSTUDIO-1: empty pack_binding denied."""
        adapter = _cloud()
        decision = adapter.intercept_agent_build({
            "agentDescription": "Test agent",
            "agentOwner": "owner@test.com",
            "packBinding": [],
        })
        assert decision.decision.value == "DENY" or str(decision.decision) in ("DENY", "DecisionType.DENY")

    def test_p_cs_10_data_residency_region_stored(self):
        adapter = _adapter(_transport(), data_residency_region="us-gov")
        assert adapter.data_residency_region == "us-gov"


# ---------------------------------------------------------------------------
# intercept_agent_build
# ---------------------------------------------------------------------------

class TestInterceptAgentBuild:
    def test_p_cs_11_description_and_owner_present_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_agent_build({
            "agentDescription": "HR onboarding assistant",
            "agentOwner": "hr-team@contoso.com",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_12_empty_description_deny(self):
        adapter = _cloud()
        decision = adapter.intercept_agent_build({
            "agentDescription": "",
            "agentOwner": "hr-team@contoso.com",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "description-required" in decision.reason

    def test_p_cs_13_whitespace_description_deny(self):
        adapter = _cloud()
        decision = adapter.intercept_agent_build({
            "agentDescription": "   ",
            "agentOwner": "hr-team@contoso.com",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()

    def test_p_cs_14_empty_owner_deny(self):
        adapter = _cloud()
        decision = adapter.intercept_agent_build({
            "agentDescription": "Valid description",
            "agentOwner": "",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "owner-required" in decision.reason

    def test_p_cs_15_whitespace_owner_deny(self):
        adapter = _cloud()
        decision = adapter.intercept_agent_build({
            "agentDescription": "Valid description",
            "agentOwner": "   ",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()

    def test_p_cs_16_description_and_owner_in_government_allow(self):
        adapter = _gov()
        decision = adapter.intercept_agent_build({
            "agentDescription": "DoD procurement assistant",
            "agentOwner": "dod-team@mil.gov",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")


# ---------------------------------------------------------------------------
# intercept_topic_creation
# ---------------------------------------------------------------------------

class TestInterceptTopicCreation:
    def test_p_cs_17_topic_name_present_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_topic_creation({
            "topicName": "Employee FAQ",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_18_empty_topic_name_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_topic_creation({
            "topicName": "",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_19_topic_creation_government_allow(self):
        adapter = _gov()
        decision = adapter.intercept_topic_creation({
            "topicName": "GCC Procurement Topic",
            "packBinding": ["hipaa"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_20_empty_pack_binding_denied_topic_creation(self):
        """PT-ADAPT-COPILOTSTUDIO-1: empty pack_binding denied."""
        adapter = _cloud()
        decision = adapter.intercept_topic_creation({
            "topicName": "Some Topic",
            "packBinding": [],
        })
        assert "DENY" in str(decision.decision).upper()


# ---------------------------------------------------------------------------
# intercept_action_definition
# ---------------------------------------------------------------------------

class TestInterceptActionDefinition:
    def test_p_cs_21_no_action_body_cloud_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_action_definition({
            "actionName": "SendEmail",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_22_microsoft_url_in_government_allow(self):
        adapter = _gov()
        decision = adapter.intercept_action_definition({
            "actionName": "SharePointUpload",
            "actionBody": '{"endpoint": "https://contoso.sharepoint.com/sites/hr"}',
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_23_external_url_in_government_deny(self):
        """PT-ADAPT-COPILOTSTUDIO-6: external URL in government mode."""
        adapter = _gov()
        decision = adapter.intercept_action_definition({
            "actionName": "SlackNotify",
            "actionBody": '{"webhook": "https://hooks.slack.com/services/T00/B00/XYZ"}',
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "action-egress-not-permitted" in decision.reason

    def test_p_cs_24_external_url_in_cloud_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_action_definition({
            "actionName": "SlackNotify",
            "actionBody": '{"webhook": "https://hooks.slack.com/services/T00/B00/XYZ"}',
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_25_external_url_in_sovereign_deny(self):
        adapter = _sov(require_governance_center_approval=True)
        decision = adapter.intercept_action_definition({
            "actionName": "GitHubAction",
            "actionBody": '{"api": "https://api.github.com/repos/org/repo"}',
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "action-egress-not-permitted" in decision.reason

    def test_p_cs_26_allowed_connector_prefixes_overrides_default(self):
        adapter = _gov(allowed_connector_prefixes=["hooks.slack.com"])
        decision = adapter.intercept_action_definition({
            "actionName": "SlackNotify",
            "actionBody": '{"webhook": "https://hooks.slack.com/services/T00/B00/XYZ"}',
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_27_multiple_offending_hosts_government_deny(self):
        adapter = _gov()
        decision = adapter.intercept_action_definition({
            "actionName": "MultiEgress",
            "actionBody": "call https://api.stripe.com/charges and https://api.twilio.com/messages",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()


# ---------------------------------------------------------------------------
# intercept_connector_add
# ---------------------------------------------------------------------------

class TestInterceptConnectorAdd:
    def test_p_cs_28_microsoft_connector_cloud_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_connector_add({
            "connectorId": "shared_sharepointonline",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_29_microsoft_connector_government_allow(self):
        adapter = _gov()
        decision = adapter.intercept_connector_add({
            "connectorId": "shared_office365outlook",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_30_third_party_connector_government_deny(self):
        adapter = _gov()
        decision = adapter.intercept_connector_add({
            "connectorId": "shared_salesforce",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "connector-not-permitted-government" in decision.reason

    def test_p_cs_31_egress_connector_government_deny(self):
        adapter = _gov()
        decision = adapter.intercept_connector_add({
            "connectorId": "shared_twitter",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()

    def test_p_cs_32_third_party_connector_cloud_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_connector_add({
            "connectorId": "shared_salesforce",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_33_explicit_allowed_prefix_in_government_allow(self):
        adapter = _gov(allowed_connector_prefixes=["shared_salesforce"])
        decision = adapter.intercept_connector_add({
            "connectorId": "shared_salesforce",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_34_sovereign_mode_follows_government_rules(self):
        adapter = _sov(require_governance_center_approval=True)
        decision = adapter.intercept_connector_add({
            "connectorId": "shared_github",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "connector-not-permitted-government" in decision.reason


# ---------------------------------------------------------------------------
# intercept_knowledge_source_add
# ---------------------------------------------------------------------------

class TestInterceptKnowledgeSourceAdd:
    def test_p_cs_35_sharepoint_cloud_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_knowledge_source_add({
            "sourceType": "sharepoint",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_36_public_website_cloud_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_knowledge_source_add({
            "sourceType": "public-website",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_37_public_website_government_deny(self):
        adapter = _gov()
        decision = adapter.intercept_knowledge_source_add({
            "sourceType": "public-website",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "public-website-not-permitted-government" in decision.reason

    def test_p_cs_38_public_website_sovereign_deny(self):
        adapter = _sov(require_governance_center_approval=True)
        decision = adapter.intercept_knowledge_source_add({
            "sourceType": "public-website",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "public-website-not-permitted-government" in decision.reason

    def test_p_cs_39_allowed_knowledge_sources_enforced(self):
        adapter = _adapter(
            _transport(), allowed_knowledge_sources=["sharepoint", "dataverse"]
        )
        decision = adapter.intercept_knowledge_source_add({
            "sourceType": "sharepoint",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_40_source_not_in_allowed_list_deny(self):
        adapter = _adapter(
            _transport(), allowed_knowledge_sources=["sharepoint", "dataverse"]
        )
        decision = adapter.intercept_knowledge_source_add({
            "sourceType": "uploaded-file",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "knowledge-source-not-permitted" in decision.reason

    def test_p_cs_41_uploaded_file_government_allow(self):
        adapter = _gov()
        decision = adapter.intercept_knowledge_source_add({
            "sourceType": "uploaded-file",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")


# ---------------------------------------------------------------------------
# intercept_publish
# ---------------------------------------------------------------------------

class TestInterceptPublish:
    def test_p_cs_42_teams_cloud_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_publish({
            "channel": "teams",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_43_public_web_government_deny(self):
        """PT-ADAPT-COPILOTSTUDIO-4: public-web in government mode."""
        adapter = _gov()
        decision = adapter.intercept_publish({
            "channel": "public-web",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "public-channel-not-permitted-government" in decision.reason

    def test_p_cs_44_public_web_sovereign_deny_same_reason_code(self):
        adapter = _sov(require_governance_center_approval=True)
        decision = adapter.intercept_publish({
            "channel": "public-web",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "public-channel-not-permitted-government" in decision.reason

    def test_p_cs_45_teams_government_allow(self):
        adapter = _gov()
        decision = adapter.intercept_publish({
            "channel": "teams",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_46_custom_channel_government_allow(self):
        adapter = _gov()
        decision = adapter.intercept_publish({
            "channel": "custom",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_47_allowed_channels_enforced(self):
        adapter = _adapter(
            _transport(), allowed_channels=["teams", "m365-copilot"]
        )
        decision = adapter.intercept_publish({
            "channel": "teams",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_48_channel_not_in_allowed_list_deny(self):
        adapter = _adapter(
            _transport(), allowed_channels=["teams", "m365-copilot"]
        )
        decision = adapter.intercept_publish({
            "channel": "custom",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "channel-not-permitted" in decision.reason

    def test_p_cs_49_sovereign_require_approval_true_teams_allow(self):
        adapter = _sov(require_governance_center_approval=True)
        decision = adapter.intercept_publish({
            "channel": "teams",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_50_sovereign_no_require_approval_teams_deny(self):
        adapter = _sov(require_governance_center_approval=False)
        decision = adapter.intercept_publish({
            "channel": "teams",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "publish-requires-governance-approval" in decision.reason


# ---------------------------------------------------------------------------
# intercept_governance_center_policy
# ---------------------------------------------------------------------------

class TestInterceptGovernanceCenterPolicy:
    def test_p_cs_51_admin_plus_require_approval_allow(self):
        adapter = _adapter(
            _transport(), require_governance_center_approval=True
        )
        decision = adapter.intercept_governance_center_policy({
            "policyName": "DataRetentionPolicy",
            "userRole": "admin",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_52_non_admin_deny(self):
        """PT-ADAPT-COPILOTSTUDIO-5: non-admin denied."""
        adapter = _adapter(
            _transport(), require_governance_center_approval=True
        )
        decision = adapter.intercept_governance_center_policy({
            "policyName": "DataRetentionPolicy",
            "userRole": "user",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "admin-only" in decision.reason

    def test_p_cs_53_empty_role_deny(self):
        """PT-ADAPT-COPILOTSTUDIO-5: empty role denied."""
        adapter = _adapter(
            _transport(), require_governance_center_approval=True
        )
        decision = adapter.intercept_governance_center_policy({
            "policyName": "DataRetentionPolicy",
            "userRole": "",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "admin-only" in decision.reason

    def test_p_cs_54_sovereign_admin_require_false_deny(self):
        adapter = _sov(require_governance_center_approval=False)
        decision = adapter.intercept_governance_center_policy({
            "policyName": "AccessPolicy",
            "userRole": "admin",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        assert "governance-center-approval-required" in decision.reason

    def test_p_cs_55_sovereign_admin_require_true_allow(self):
        adapter = _sov(require_governance_center_approval=True)
        decision = adapter.intercept_governance_center_policy({
            "policyName": "AccessPolicy",
            "userRole": "admin",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")


# ---------------------------------------------------------------------------
# intercept_chat_test
# ---------------------------------------------------------------------------

class TestInterceptChatTest:
    def test_p_cs_56_clean_prompt_allow(self):
        adapter = _cloud()
        decision = adapter.intercept_chat_test({
            "promptText": "What is our leave policy?",
            "packBinding": ["soc2"],
        })
        assert str(decision.decision) in ("ALLOW", "DecisionType.ALLOW")

    def test_p_cs_57_azure_connection_string_deny(self):
        adapter = _cloud()
        decision = adapter.intercept_chat_test({
            "promptText": "Use DefaultEndpointsProtocol=https;AccountName=mystorageaccount;AccountKey=abc123==",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()

    def test_p_cs_58_generic_api_key_deny(self):
        adapter = _cloud()
        decision = adapter.intercept_chat_test({
            "promptText": "API_KEY=super-secret-key-value-here",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()

    def test_p_cs_59_bearer_token_deny(self):
        adapter = _cloud()
        decision = adapter.intercept_chat_test({
            "promptText": "Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyMTIzIn0.signature",
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()


# ---------------------------------------------------------------------------
# PT-ADAPT-COPILOTSTUDIO-2: secrets not in audit entries
# ---------------------------------------------------------------------------

class TestSecretsNotInAuditEntries:
    def test_p_cs_60_azure_connection_string_raw_value_not_in_reason(self):
        """PT-ADAPT-COPILOTSTUDIO-2: raw secret value must not appear in denial reason."""
        adapter = _cloud()
        SECRET_VALUE = "DefaultEndpointsProtocol=https;AccountName=mystorageaccount;AccountKey=realSecretKey+abc/DEF=="
        decision = adapter.intercept_chat_test({
            "promptText": SECRET_VALUE,
            "packBinding": ["soc2"],
        })
        assert "DENY" in str(decision.decision).upper()
        # The raw AccountKey value must not appear in the reason text.
        assert "realSecretKey+abc/DEF==" not in decision.reason


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

class TestConstants:
    def test_p_cs_61_valid_deployment_modes_correct(self):
        assert sorted(COPILOT_STUDIO_VALID_DEPLOYMENT_MODES) == sorted([
            "copilot-studio-cloud",
            "copilot-studio-government",
            "copilot-studio-sovereign",
        ])

    def test_p_cs_62_baa_eligible_modes_correct(self):
        assert sorted(COPILOT_STUDIO_BAA_ELIGIBLE_MODES) == sorted([
            "copilot-studio-government",
            "copilot-studio-sovereign",
        ])

    def test_p_cs_63_valid_tenant_tiers_correct(self):
        assert sorted(COPILOT_STUDIO_VALID_TENANT_TIERS) == sorted([
            "commercial", "dod", "gcc", "gcc-high", "government", "sovereign",
        ])

    def test_p_cs_64_government_tenant_tiers_correct(self):
        assert sorted(COPILOT_STUDIO_GOVERNMENT_TENANT_TIERS) == sorted([
            "dod", "gcc", "gcc-high", "government",
        ])
