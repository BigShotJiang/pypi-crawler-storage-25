"""
Tests for connexum_governance.integrations.autogen_integration

AutoGen v0.4+ Python framework adapter -- Sprint 5, WS-10.

All tests run offline -- no real autogen-agentchat or autogen-core package
required. AutoGen primitives are mocked via minimal class implementations.
Governance server calls are injected via the _check_fn parameter.

Coverage:

  GovernedAutoGenTool:
    run():
      - ALLOW -> delegates to underlying tool.run(), returns result
      - DENY -> raises GovernanceViolation (raise_on_deny=True, default)
      - DENY -> returns '[GOVERNANCE DENIED] ...' (raise_on_deny=False)
      - PENDING -> raises GovernancePendingApproval (raise_on_deny=True)
      - PENDING (no approvalId) -> raises GovernanceViolation
      - Action namespace 'framework.autogen.tool_run' sent
      - Tool name forwarded to governance check
      - String input forwarded as messagePreview
      - Dict input JSON-serialized as messagePreview
      - None input handled as empty string
      - Underlying tool NOT called on DENY
      - CancellationToken cancel() called when cancel_on_deny=True + DENY
      - Async run() -- ALLOW, DENY, PENDING
    run_json():
      - ALLOW -> delegates to underlying tool.run_json(), returns result
      - DENY -> raises GovernanceViolation
      - PENDING -> raises GovernancePendingApproval
      - Action namespace 'framework.autogen.tool_run' sent
      - Fallback to run() when run_json() not available
      - ALLOW -> delegates with fallback chain
    Constructor validation:
      - tool=None -> raises ValueError
      - tool.name missing -> raises ValueError
      - missing governance_server_url -> raises ValueError
      - missing license_key -> raises ValueError
    Attributes:
      - .name matches underlying tool
      - .description matches underlying tool

  governed_autogen_tool() factory:
    - Returns GovernedAutoGenTool instance
    - ALLOW -> underlying tool called
    - DENY -> raises GovernanceViolation

  wrap_chat_agent():
    - Wraps on_messages with governance check
    - ALLOW -> delegates to original on_messages
    - DENY -> raises GovernanceViolation
    - PENDING -> raises GovernancePendingApproval
    - Action namespace 'framework.autogen.message_received' sent
    - Agent name forwarded in metadata
    - List of message objects extracted to preview
    - String message preview
    - Message object with .content attribute
    - raise_on_deny=False -> logs, does NOT raise, returns None
    - Auto-wraps tools registered on agent
    - Idempotency: calling twice does not double-wrap
    - _connexum_governed marker set on agent

  wrap_group_chat():
    - Wraps run() with pre-run governance check
    - ALLOW -> delegates to original run()
    - DENY -> raises GovernanceViolation
    - PENDING -> raises GovernancePendingApproval
    - Action namespace 'framework.autogen.group_chat_run' sent
    - Wraps run_stream() with governance check
    - Idempotency: calling twice does not double-wrap
    - _connexum_governed marker set on chat

  create_governed_autogen() factory:
    - Returns GovernedAutoGenInstance
    - governed_tool() returns GovernedAutoGenTool
    - wrap_agent() wraps on_messages
    - wrap_group_chat() wraps run()
    - Constructor validation: missing url -> ValueError
    - Constructor validation: missing key -> ValueError

  Error classes:
    - GovernanceViolation: correct attributes
    - GovernancePendingApproval: correct attributes

  Fail-open / fail-closed:
    - raise_on_deny=False: DENY logged, not raised
    - raise_on_deny=True (default): DENY always raises
"""

from __future__ import annotations

import asyncio
import pytest
from typing import Any, Optional

from connexum_governance.integrations.autogen_integration import (
    GovernedAutoGenTool,
    governed_autogen_tool,
    wrap_chat_agent,
    wrap_group_chat,
    create_governed_autogen,
    GovernedAutoGenInstance,
)
from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)


# ---------------------------------------------------------------------------
# Helper: mock check functions
# ---------------------------------------------------------------------------

async def allow_fn(url: str, body: dict) -> dict:
    return {"decision": "ALLOW"}


async def deny_fn(url: str, body: dict) -> dict:
    return {"decision": "DENY", "reason": "autogen policy test denial"}


async def pending_fn(url: str, body: dict) -> dict:
    return {
        "decision": "REQUIRE_APPROVAL",
        "approvalId": "approval-autogen-123",
        "auditId": "audit-autogen-456",
    }


async def pending_no_id_fn(url: str, body: dict) -> dict:
    return {"decision": "REQUIRE_APPROVAL"}


def make_capture_fn(result: str, captures: list[dict], approval_id: Optional[str] = None):
    """Returns an async check function that records bodies in captures list."""
    async def check_fn(url: str, body: dict) -> dict:
        captures.append(dict(body))
        if result == "DENY":
            return {"decision": "DENY", "reason": "test denial"}
        if result == "REQUIRE_APPROVAL":
            return {
                "decision": "REQUIRE_APPROVAL",
                "approvalId": approval_id or "approval-test-id",
                "auditId": "audit-test-id",
            }
        return {"decision": "ALLOW"}
    return check_fn


# ---------------------------------------------------------------------------
# Helper: mock AutoGen primitives (no real package needed)
# ---------------------------------------------------------------------------

class MockAutoGenTool:
    """Minimal FunctionTool duck-type for testing."""

    def __init__(
        self,
        name: str,
        description: str = "Mock AutoGen tool",
        return_value: Any = "tool-result",
    ):
        self.name = name
        self.description = description
        self._return_value = return_value
        self.call_count = 0
        self.run_json_call_count = 0

    async def run(self, args: Any, cancellation_token: Any = None, **kwargs: Any) -> Any:
        self.call_count += 1
        return self._return_value

    async def run_json(self, args: dict, cancellation_token: Any = None, **kwargs: Any) -> Any:
        self.run_json_call_count += 1
        return self._return_value


class MockAutoGenToolNoRunJson:
    """AutoGen tool with run() but no run_json()."""

    def __init__(self, name: str = "no-run-json-tool", return_value: Any = "fallback-result"):
        self.name = name
        self.description = "tool without run_json"
        self._return_value = return_value
        self.call_count = 0

    async def run(self, args: Any, cancellation_token: Any = None, **kwargs: Any) -> Any:
        self.call_count += 1
        return self._return_value


class MockCancellationToken:
    """Mock AutoGen CancellationToken."""

    def __init__(self):
        self.cancelled = False

    def cancel(self) -> None:
        self.cancelled = True

    @property
    def is_cancelled(self) -> bool:
        return self.cancelled


class MockMessage:
    """Mock AutoGen message with .content attribute."""

    def __init__(self, content: str = "test content"):
        self.content = content


class MockChatAgent:
    """Minimal BaseChatAgent duck-type for testing."""

    def __init__(self, name: str = "test-agent", tools: Optional[list] = None):
        self.name = name
        self.tools = tools or []
        self.on_messages_call_count = 0

    async def on_messages(
        self, messages: Any, cancellation_token: Any = None, **kwargs: Any
    ) -> Any:
        self.on_messages_call_count += 1
        return {"response": "agent response"}


class MockGroupChat:
    """Minimal RoundRobinGroupChat / SelectorGroupChat duck-type."""

    def __init__(self, name: str = "test-group-chat"):
        self.name = name
        self.run_call_count = 0
        self.run_stream_call_count = 0

    async def run(self, task: Any = None, **kwargs: Any) -> Any:
        self.run_call_count += 1
        return {"result": "group-chat-result"}

    async def run_stream(self, task: Any = None, **kwargs: Any):
        self.run_stream_call_count += 1
        yield {"chunk": 1}
        yield {"chunk": 2}


BASE_CONFIG = {
    "governance_server_url": "http://localhost:3200",
    "license_key": "test-license-key",
}


# ===========================================================================
# GovernedAutoGenTool -- run()
# ===========================================================================

class TestGovernedAutoGenToolRun:
    """Tests for GovernedAutoGenTool.run()."""

    @pytest.mark.asyncio
    async def test_run_allow_delegates_to_underlying(self):
        underlying = MockAutoGenTool("web_search", return_value="search results")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=allow_fn, **BASE_CONFIG
        )
        result = await tool.run({"query": "test"})
        assert result == "search results"
        assert underlying.call_count == 1

    @pytest.mark.asyncio
    async def test_run_deny_raises_governance_violation(self):
        underlying = MockAutoGenTool("restricted_tool")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=deny_fn, **BASE_CONFIG
        )
        with pytest.raises(GovernanceViolation) as exc_info:
            await tool.run("some input")
        assert exc_info.value.decision == "DENY"
        assert underlying.call_count == 0

    @pytest.mark.asyncio
    async def test_run_deny_no_raise_returns_string(self):
        underlying = MockAutoGenTool("restricted_tool")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=deny_fn, raise_on_deny=False, **BASE_CONFIG
        )
        result = await tool.run("input")
        assert "[GOVERNANCE DENIED]" in result
        assert underlying.call_count == 0

    @pytest.mark.asyncio
    async def test_run_pending_raises_governance_pending(self):
        underlying = MockAutoGenTool("approval_tool")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=pending_fn, **BASE_CONFIG
        )
        with pytest.raises(GovernancePendingApproval) as exc_info:
            await tool.run("input")
        assert exc_info.value.approval_id == "approval-autogen-123"
        assert exc_info.value.audit_id == "audit-autogen-456"
        assert underlying.call_count == 0

    @pytest.mark.asyncio
    async def test_run_pending_no_id_raises_violation(self):
        underlying = MockAutoGenTool("approval_tool")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=pending_no_id_fn, **BASE_CONFIG
        )
        with pytest.raises(GovernanceViolation) as exc_info:
            await tool.run("input")
        assert exc_info.value.decision == "DENY"

    @pytest.mark.asyncio
    async def test_run_action_namespace(self):
        captures = []
        tool = GovernedAutoGenTool(
            tool=MockAutoGenTool("my_tool"),
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await tool.run("test input")
        assert len(captures) == 1
        assert captures[0]["action"] == "framework.autogen.tool_run"

    @pytest.mark.asyncio
    async def test_run_tool_name_in_check_body(self):
        captures = []
        tool = GovernedAutoGenTool(
            tool=MockAutoGenTool("my_specific_tool"),
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await tool.run("input")
        assert "my_specific_tool" in captures[0]["tools"]

    @pytest.mark.asyncio
    async def test_run_string_input_forwarded(self):
        captures = []
        tool = GovernedAutoGenTool(
            tool=MockAutoGenTool("tool"),
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await tool.run("my string input")
        assert "my string input" in captures[0]["messagePreview"]

    @pytest.mark.asyncio
    async def test_run_dict_input_json_serialized(self):
        captures = []
        tool = GovernedAutoGenTool(
            tool=MockAutoGenTool("tool"),
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await tool.run({"key": "value", "nested": {"a": 1}})
        preview = captures[0]["messagePreview"]
        assert "key" in preview

    @pytest.mark.asyncio
    async def test_run_none_input_handled(self):
        captures = []
        tool = GovernedAutoGenTool(
            tool=MockAutoGenTool("tool"),
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await tool.run(None)
        # Should not crash, preview is empty string
        assert captures[0]["messagePreview"] == ""

    @pytest.mark.asyncio
    async def test_run_cancel_on_deny_calls_token_cancel(self):
        underlying = MockAutoGenTool("restricted")
        token = MockCancellationToken()
        tool = GovernedAutoGenTool(
            tool=underlying,
            _check_fn=deny_fn,
            cancel_on_deny=True,
            **BASE_CONFIG,
        )
        with pytest.raises(GovernanceViolation):
            await tool.run("input", cancellation_token=token)
        assert token.cancelled is True

    @pytest.mark.asyncio
    async def test_run_cancel_on_deny_false_does_not_cancel_token(self):
        underlying = MockAutoGenTool("restricted")
        token = MockCancellationToken()
        tool = GovernedAutoGenTool(
            tool=underlying,
            _check_fn=deny_fn,
            cancel_on_deny=False,
            **BASE_CONFIG,
        )
        with pytest.raises(GovernanceViolation):
            await tool.run("input", cancellation_token=token)
        assert token.cancelled is False

    @pytest.mark.asyncio
    async def test_run_allow_underlying_not_called_on_deny(self):
        underlying = MockAutoGenTool("tool")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=deny_fn, raise_on_deny=False, **BASE_CONFIG
        )
        await tool.run("input")
        assert underlying.call_count == 0


# ===========================================================================
# GovernedAutoGenTool -- run_json()
# ===========================================================================

class TestGovernedAutoGenToolRunJson:
    """Tests for GovernedAutoGenTool.run_json()."""

    @pytest.mark.asyncio
    async def test_run_json_allow_delegates(self):
        underlying = MockAutoGenTool("json_tool", return_value="json-result")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=allow_fn, **BASE_CONFIG
        )
        result = await tool.run_json({"key": "val"})
        assert result == "json-result"
        assert underlying.run_json_call_count == 1

    @pytest.mark.asyncio
    async def test_run_json_deny_raises(self):
        underlying = MockAutoGenTool("json_tool")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=deny_fn, **BASE_CONFIG
        )
        with pytest.raises(GovernanceViolation):
            await tool.run_json({"key": "val"})
        assert underlying.run_json_call_count == 0

    @pytest.mark.asyncio
    async def test_run_json_pending_raises(self):
        underlying = MockAutoGenTool("json_tool")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=pending_fn, **BASE_CONFIG
        )
        with pytest.raises(GovernancePendingApproval):
            await tool.run_json({"key": "val"})

    @pytest.mark.asyncio
    async def test_run_json_action_namespace(self):
        captures = []
        tool = GovernedAutoGenTool(
            tool=MockAutoGenTool("json_tool"),
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await tool.run_json({"key": "val"})
        assert captures[0]["action"] == "framework.autogen.tool_run"

    @pytest.mark.asyncio
    async def test_run_json_fallback_to_run_when_no_run_json(self):
        underlying = MockAutoGenToolNoRunJson("no-json-tool", return_value="fallback")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=allow_fn, **BASE_CONFIG
        )
        result = await tool.run_json({"key": "val"})
        assert result == "fallback"
        assert underlying.call_count == 1

    @pytest.mark.asyncio
    async def test_run_json_cancel_on_deny(self):
        underlying = MockAutoGenTool("json_tool")
        token = MockCancellationToken()
        tool = GovernedAutoGenTool(
            tool=underlying,
            _check_fn=deny_fn,
            cancel_on_deny=True,
            **BASE_CONFIG,
        )
        with pytest.raises(GovernanceViolation):
            await tool.run_json({"key": "val"}, cancellation_token=token)
        assert token.cancelled is True


# ===========================================================================
# GovernedAutoGenTool -- constructor validation and attributes
# ===========================================================================

class TestGovernedAutoGenToolConstructor:
    """Tests for GovernedAutoGenTool constructor validation."""

    def test_tool_none_raises(self):
        with pytest.raises(ValueError, match="tool is required"):
            GovernedAutoGenTool(tool=None, **BASE_CONFIG, _check_fn=allow_fn)

    def test_tool_without_name_raises(self):
        tool_no_name = type("NoName", (), {})()  # object with no .name
        with pytest.raises(ValueError, match="tool.name is required"):
            GovernedAutoGenTool(tool=tool_no_name, **BASE_CONFIG, _check_fn=allow_fn)

    def test_missing_governance_server_url_raises(self):
        with pytest.raises(ValueError, match="governance_server_url is required"):
            GovernedAutoGenTool(
                tool=MockAutoGenTool("t"),
                governance_server_url="",
                license_key="key",
                _check_fn=allow_fn,
            )

    def test_missing_license_key_raises(self):
        with pytest.raises(ValueError, match="license_key is required"):
            GovernedAutoGenTool(
                tool=MockAutoGenTool("t"),
                governance_server_url="http://localhost:3200",
                license_key="",
                _check_fn=allow_fn,
            )

    def test_name_matches_underlying(self):
        underlying = MockAutoGenTool("my_tool_name")
        tool = GovernedAutoGenTool(tool=underlying, _check_fn=allow_fn, **BASE_CONFIG)
        assert tool.name == "my_tool_name"

    def test_description_matches_underlying(self):
        underlying = MockAutoGenTool("t", description="My tool description")
        tool = GovernedAutoGenTool(tool=underlying, _check_fn=allow_fn, **BASE_CONFIG)
        assert tool.description == "My tool description"


# ===========================================================================
# governed_autogen_tool() factory
# ===========================================================================

class TestGovernedAutoGenToolFactory:
    """Tests for governed_autogen_tool() factory function."""

    def test_returns_governed_tool_instance(self):
        underlying = MockAutoGenTool("factory_tool")
        result = governed_autogen_tool(
            tool=underlying, _check_fn=allow_fn, **BASE_CONFIG
        )
        assert isinstance(result, GovernedAutoGenTool)

    @pytest.mark.asyncio
    async def test_factory_allow_calls_underlying(self):
        underlying = MockAutoGenTool("factory_tool", return_value="factory-result")
        tool = governed_autogen_tool(
            tool=underlying, _check_fn=allow_fn, **BASE_CONFIG
        )
        result = await tool.run("input")
        assert result == "factory-result"

    @pytest.mark.asyncio
    async def test_factory_deny_raises(self):
        underlying = MockAutoGenTool("factory_tool")
        tool = governed_autogen_tool(
            tool=underlying, _check_fn=deny_fn, **BASE_CONFIG
        )
        with pytest.raises(GovernanceViolation):
            await tool.run("input")


# ===========================================================================
# wrap_chat_agent()
# ===========================================================================

class TestWrapChatAgent:
    """Tests for wrap_chat_agent()."""

    @pytest.mark.asyncio
    async def test_allow_delegates_to_original_on_messages(self):
        agent = MockChatAgent("test-agent")
        wrapped = wrap_chat_agent(agent, _check_fn=allow_fn, **BASE_CONFIG)
        result = await wrapped.on_messages([MockMessage("hello")])
        assert result == {"response": "agent response"}
        assert agent.on_messages_call_count == 1

    @pytest.mark.asyncio
    async def test_deny_raises_governance_violation(self):
        agent = MockChatAgent("test-agent")
        wrap_chat_agent(agent, _check_fn=deny_fn, **BASE_CONFIG)
        with pytest.raises(GovernanceViolation):
            await agent.on_messages([MockMessage("hello")])
        assert agent.on_messages_call_count == 0

    @pytest.mark.asyncio
    async def test_pending_raises_governance_pending(self):
        agent = MockChatAgent("test-agent")
        wrap_chat_agent(agent, _check_fn=pending_fn, **BASE_CONFIG)
        with pytest.raises(GovernancePendingApproval):
            await agent.on_messages([MockMessage("hello")])

    @pytest.mark.asyncio
    async def test_action_namespace_message_received(self):
        agent = MockChatAgent("test-agent")
        captures = []
        wrap_chat_agent(
            agent,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await agent.on_messages([MockMessage("hello")])
        assert captures[0]["action"] == "framework.autogen.message_received"

    @pytest.mark.asyncio
    async def test_agent_name_in_metadata(self):
        agent = MockChatAgent("my-specific-agent")
        captures = []
        wrap_chat_agent(
            agent,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await agent.on_messages([MockMessage("hello")])
        assert captures[0]["metadata"]["agentName"] == "my-specific-agent"

    @pytest.mark.asyncio
    async def test_list_message_objects_extracted_to_preview(self):
        agent = MockChatAgent("agent")
        captures = []
        wrap_chat_agent(
            agent,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        msgs = [MockMessage("hello world"), MockMessage("second msg")]
        await agent.on_messages(msgs)
        preview = captures[0]["messagePreview"]
        assert "hello world" in preview

    @pytest.mark.asyncio
    async def test_string_message_preview(self):
        agent = MockChatAgent("agent")
        captures = []
        wrap_chat_agent(
            agent,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await agent.on_messages("plain string message")
        assert "plain string message" in captures[0]["messagePreview"]

    @pytest.mark.asyncio
    async def test_raise_on_deny_false_returns_none(self):
        agent = MockChatAgent("agent")
        wrap_chat_agent(
            agent, _check_fn=deny_fn, raise_on_deny=False, **BASE_CONFIG
        )
        result = await agent.on_messages([MockMessage("hello")])
        assert result is None
        assert agent.on_messages_call_count == 0

    def test_idempotency_does_not_double_wrap(self):
        agent = MockChatAgent("agent")
        wrap_chat_agent(agent, _check_fn=allow_fn, **BASE_CONFIG)
        original_governed_fn = agent.on_messages
        wrap_chat_agent(agent, _check_fn=allow_fn, **BASE_CONFIG)
        # Second call should be a no-op due to idempotency guard
        assert agent.on_messages is original_governed_fn

    def test_connexum_governed_marker_set(self):
        agent = MockChatAgent("agent")
        wrap_chat_agent(agent, _check_fn=allow_fn, **BASE_CONFIG)
        assert getattr(agent, "_connexum_governed", False) is True

    def test_auto_wraps_tools_on_agent(self):
        raw_tool = MockAutoGenTool("agent_tool")
        agent = MockChatAgent("agent", tools=[raw_tool])
        wrap_chat_agent(agent, _check_fn=allow_fn, **BASE_CONFIG)
        # Tool should have been replaced with GovernedAutoGenTool
        assert len(agent.tools) == 1
        assert isinstance(agent.tools[0], GovernedAutoGenTool)

    def test_already_governed_tools_not_double_wrapped(self):
        raw_tool = MockAutoGenTool("agent_tool")
        governed = GovernedAutoGenTool(tool=raw_tool, _check_fn=allow_fn, **BASE_CONFIG)
        governed._connexum_governed = True
        agent = MockChatAgent("agent", tools=[governed])
        wrap_chat_agent(agent, _check_fn=allow_fn, **BASE_CONFIG)
        # The already-governed tool should still be a GovernedAutoGenTool (no double wrap)
        assert isinstance(agent.tools[0], GovernedAutoGenTool)


# ===========================================================================
# wrap_group_chat()
# ===========================================================================

class TestWrapGroupChat:
    """Tests for wrap_group_chat()."""

    @pytest.mark.asyncio
    async def test_run_allow_delegates_to_original(self):
        chat = MockGroupChat("my-group")
        wrap_group_chat(chat, _check_fn=allow_fn, **BASE_CONFIG)
        result = await chat.run("do something")
        assert result == {"result": "group-chat-result"}
        assert chat.run_call_count == 1

    @pytest.mark.asyncio
    async def test_run_deny_raises_governance_violation(self):
        chat = MockGroupChat("my-group")
        wrap_group_chat(chat, _check_fn=deny_fn, **BASE_CONFIG)
        with pytest.raises(GovernanceViolation):
            await chat.run("task")
        assert chat.run_call_count == 0

    @pytest.mark.asyncio
    async def test_run_pending_raises_governance_pending(self):
        chat = MockGroupChat("my-group")
        wrap_group_chat(chat, _check_fn=pending_fn, **BASE_CONFIG)
        with pytest.raises(GovernancePendingApproval):
            await chat.run("task")

    @pytest.mark.asyncio
    async def test_run_action_namespace_group_chat_run(self):
        chat = MockGroupChat("my-group")
        captures = []
        wrap_group_chat(
            chat,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        await chat.run("task")
        assert captures[0]["action"] == "framework.autogen.group_chat_run"

    @pytest.mark.asyncio
    async def test_run_stream_governance_checked_before_stream(self):
        chat = MockGroupChat("my-group")
        captures = []
        wrap_group_chat(
            chat,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        chunks = []
        async for chunk in chat.run_stream("task"):
            chunks.append(chunk)
        assert len(captures) >= 1
        assert captures[0]["action"] == "framework.autogen.group_chat_run"
        assert len(chunks) == 2  # MockGroupChat yields 2 chunks

    @pytest.mark.asyncio
    async def test_run_stream_deny_raises_before_any_chunks(self):
        chat = MockGroupChat("my-group")
        wrap_group_chat(chat, _check_fn=deny_fn, **BASE_CONFIG)
        with pytest.raises(GovernanceViolation):
            async for _ in chat.run_stream("task"):
                pass
        assert chat.run_stream_call_count == 0

    def test_idempotency_does_not_double_wrap(self):
        chat = MockGroupChat("my-group")
        wrap_group_chat(chat, _check_fn=allow_fn, **BASE_CONFIG)
        original_run = chat.run
        wrap_group_chat(chat, _check_fn=allow_fn, **BASE_CONFIG)
        assert chat.run is original_run

    def test_connexum_governed_marker_set(self):
        chat = MockGroupChat("my-group")
        wrap_group_chat(chat, _check_fn=allow_fn, **BASE_CONFIG)
        assert getattr(chat, "_connexum_governed", False) is True


# ===========================================================================
# create_governed_autogen() factory
# ===========================================================================

class TestCreateGovernedAutogen:
    """Tests for create_governed_autogen() factory."""

    def test_returns_governed_autogen_instance(self):
        instance = create_governed_autogen(**BASE_CONFIG, _check_fn=allow_fn)
        assert isinstance(instance, GovernedAutoGenInstance)

    def test_missing_url_raises(self):
        with pytest.raises(ValueError, match="governance_server_url is required"):
            create_governed_autogen(
                governance_server_url="",
                license_key="key",
                _check_fn=allow_fn,
            )

    def test_missing_key_raises(self):
        with pytest.raises(ValueError, match="license_key is required"):
            create_governed_autogen(
                governance_server_url="http://localhost:3200",
                license_key="",
                _check_fn=allow_fn,
            )

    def test_governed_tool_returns_governed_autogen_tool(self):
        instance = create_governed_autogen(**BASE_CONFIG, _check_fn=allow_fn)
        raw = MockAutoGenTool("factory_tool")
        result = instance.governed_tool(raw)
        assert isinstance(result, GovernedAutoGenTool)

    @pytest.mark.asyncio
    async def test_governed_tool_allow_works(self):
        instance = create_governed_autogen(**BASE_CONFIG, _check_fn=allow_fn)
        raw = MockAutoGenTool("factory_tool", return_value="result")
        tool = instance.governed_tool(raw)
        out = await tool.run("input")
        assert out == "result"

    def test_wrap_agent_sets_governed_marker(self):
        instance = create_governed_autogen(**BASE_CONFIG, _check_fn=allow_fn)
        agent = MockChatAgent("test-agent")
        instance.wrap_agent(agent)
        assert getattr(agent, "_connexum_governed", False) is True

    @pytest.mark.asyncio
    async def test_wrap_agent_governance_fires_on_messages(self):
        captures = []
        instance = create_governed_autogen(
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        agent = MockChatAgent("agent")
        instance.wrap_agent(agent)
        await agent.on_messages([MockMessage("hello")])
        assert len(captures) == 1
        assert captures[0]["action"] == "framework.autogen.message_received"

    def test_wrap_group_chat_sets_governed_marker(self):
        instance = create_governed_autogen(**BASE_CONFIG, _check_fn=allow_fn)
        chat = MockGroupChat("my-group")
        instance.wrap_group_chat(chat)
        assert getattr(chat, "_connexum_governed", False) is True

    @pytest.mark.asyncio
    async def test_wrap_group_chat_governance_fires_on_run(self):
        captures = []
        instance = create_governed_autogen(
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        chat = MockGroupChat("my-group")
        instance.wrap_group_chat(chat)
        await chat.run("task")
        assert len(captures) == 1
        assert captures[0]["action"] == "framework.autogen.group_chat_run"


# ===========================================================================
# Error class assertions
# ===========================================================================

class TestErrorClasses:
    """Tests verifying GovernanceViolation and GovernancePendingApproval attributes."""

    def test_governance_violation_attributes(self):
        exc = GovernanceViolation(
            decision="DENY",
            reason="test reason",
            audit_id="audit-123",
        )
        assert exc.decision == "DENY"
        assert exc.reason == "test reason"
        assert exc.audit_id == "audit-123"

    def test_governance_pending_approval_attributes(self):
        exc = GovernancePendingApproval(
            approval_id="approval-abc",
            audit_id="audit-xyz",
        )
        assert exc.approval_id == "approval-abc"
        assert exc.audit_id == "audit-xyz"


# ===========================================================================
# Fail-open / fail-closed
# ===========================================================================

class TestFailOpenFailClosed:
    """Tests for raise_on_deny behavior."""

    @pytest.mark.asyncio
    async def test_raise_on_deny_true_always_raises(self):
        tool = GovernedAutoGenTool(
            tool=MockAutoGenTool("t"),
            _check_fn=deny_fn,
            raise_on_deny=True,
            **BASE_CONFIG,
        )
        with pytest.raises(GovernanceViolation):
            await tool.run("input")

    @pytest.mark.asyncio
    async def test_raise_on_deny_false_logs_not_raises(self):
        tool = GovernedAutoGenTool(
            tool=MockAutoGenTool("t"),
            _check_fn=deny_fn,
            raise_on_deny=False,
            **BASE_CONFIG,
        )
        result = await tool.run("input")
        assert "[GOVERNANCE DENIED]" in result

    @pytest.mark.asyncio
    async def test_allow_always_passes_through(self):
        underlying = MockAutoGenTool("t", return_value="pass")
        tool = GovernedAutoGenTool(
            tool=underlying, _check_fn=allow_fn, **BASE_CONFIG
        )
        result = await tool.run("input")
        assert result == "pass"
