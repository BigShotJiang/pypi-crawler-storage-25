"""F-NEW-GEMMA-PY (Layer 5.5.2): Gemma family parity tests.

Mirrors the TypeScript google.ts model-family detection. Validates:
  - KNOWN_GEMMA_MODEL_IDS includes Gemma 2, Gemma 3, Gemma 4, paligemma
  - get_google_model_family() prefix-detects all gemma-* and paligemma-*
  - is_open_weight_google_model() True for gemma family, False for gemini
  - intercept_request() surfaces family + isOpenWeight in the gov_input
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from connexum_governance.integrations.gemini import (
    KNOWN_GEMMA_MODEL_IDS,
    get_google_model_family,
    is_open_weight_google_model,
    GeminiGovernance,
)


class TestKnownModelRegistry:
    def test_gemma_2_present(self):
        for mid in ("gemma-2-2b-it", "gemma-2-9b-it", "gemma-2-27b-it"):
            assert mid in KNOWN_GEMMA_MODEL_IDS

    def test_gemma_3_present(self):
        for mid in ("gemma-3-1b-it", "gemma-3-4b-it", "gemma-3-12b-it", "gemma-3-27b-it"):
            assert mid in KNOWN_GEMMA_MODEL_IDS

    def test_gemma_4_present(self):
        for mid in ("gemma-4-e2b-it", "gemma-4-e4b-it", "gemma-4-26b-a4b-it", "gemma-4-31b-it"):
            assert mid in KNOWN_GEMMA_MODEL_IDS

    def test_paligemma_present(self):
        assert "paligemma-3b-mix-224" in KNOWN_GEMMA_MODEL_IDS

    def test_total_count_matches_typescript(self):
        # 3 + 4 + 4 + 1 = 12. Mirror count must match TS.
        assert len(KNOWN_GEMMA_MODEL_IDS) == 12


class TestFamilyDetection:
    @pytest.mark.parametrize("model_id", list(KNOWN_GEMMA_MODEL_IDS))
    def test_known_gemma_ids_classify_as_gemma(self, model_id):
        assert get_google_model_family(model_id) == "gemma"

    @pytest.mark.parametrize("model_id", ["gemini-1.5-pro", "gemini-2.0-flash"])
    def test_gemini_ids_classify_as_gemini(self, model_id):
        assert get_google_model_family(model_id) == "gemini"

    @pytest.mark.parametrize("model_id", ["gpt-4", "claude-3-opus", "deepseek-chat", "", "random-string"])
    def test_unknown_ids_classify_as_unknown(self, model_id):
        assert get_google_model_family(model_id) == "unknown"

    def test_forward_compat_future_gemma_generations(self):
        # Prefix-based detection: gemma-5/7 etc. classify before registry adds them.
        for future_id in ["gemma-5-99b-it", "gemma-7-1t-it", "paligemma-9-100b-instruct"]:
            assert get_google_model_family(future_id) == "gemma"

    def test_non_string_input_returns_unknown(self):
        assert get_google_model_family(None) == "unknown"
        assert get_google_model_family(42) == "unknown"

    def test_case_insensitive(self):
        assert get_google_model_family("GEMMA-4-E2B-IT") == "gemma"
        assert get_google_model_family("Gemma-3-27B-IT") == "gemma"


class TestOpenWeightFlag:
    @pytest.mark.parametrize("model_id", list(KNOWN_GEMMA_MODEL_IDS))
    def test_gemma_is_open_weight(self, model_id):
        assert is_open_weight_google_model(model_id) is True

    @pytest.mark.parametrize("model_id", ["gemini-1.5-pro", "gemini-2.0-flash"])
    def test_gemini_is_not_open_weight(self, model_id):
        assert is_open_weight_google_model(model_id) is False

    @pytest.mark.parametrize("model_id", ["gpt-4", "", "random"])
    def test_unknown_is_not_open_weight(self, model_id):
        assert is_open_weight_google_model(model_id) is False


class TestInterceptRequestSurfacesFamily:
    def _make_gg(self):
        client = MagicMock()
        return GeminiGovernance(client=client, agent_name="test-agent")

    def test_gemma_request_surfaces_family_gemma_isopenweight_true(self):
        gg = self._make_gg()
        gg.intercept_request({
            "model": "gemma-4-e4b-it",
            "contents": [{"role": "user", "parts": [{"text": "hi"}]}],
        })
        call = gg.client.check_action.call_args
        gov_input = call.kwargs["input"]
        assert gov_input["model"] == "gemma-4-e4b-it"
        assert gov_input["family"] == "gemma"
        assert gov_input["isOpenWeight"] is True

    def test_gemini_request_surfaces_family_gemini_isopenweight_false(self):
        gg = self._make_gg()
        gg.intercept_request({
            "model": "gemini-1.5-pro",
            "contents": [{"role": "user", "parts": [{"text": "hi"}]}],
        })
        call = gg.client.check_action.call_args
        gov_input = call.kwargs["input"]
        assert gov_input["family"] == "gemini"
        assert gov_input["isOpenWeight"] is False

    def test_unknown_model_surfaces_family_unknown_isopenweight_false(self):
        gg = self._make_gg()
        gg.intercept_request({"model": "fictional-model-xyz", "contents": []})
        call = gg.client.check_action.call_args
        gov_input = call.kwargs["input"]
        assert gov_input["family"] == "unknown"
        assert gov_input["isOpenWeight"] is False
