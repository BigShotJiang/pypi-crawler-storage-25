"""Tests for OllamaGovernance integration (B1-06).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 response classification
3. PHI ingress refusal
4. Provider compliance registration (no BAA required for local Ollama)
5. Subscription gate
6. Audit chain append

Also covers Ollama-specific behavior:
- Non-loopback base_url warning
- /api/chat and /api/generate format support
- Tool names from Ollama 0.3.x tools array
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.ollama import (
    OllamaGovernance,
    OllamaClientProxy,
    _is_loopback,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ALLOW_WITH_AUDIT = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-oll-001",
}

PHI_DENY = {
    "decision": "DENY",
    "reason": "G3: PHI ingress blocked",
    "auditId": "aud-oll-003",
}

CLASSIFY_CLEAN = {
    "allowed": True,
    "guardsTriggered": [],
    "auditId": "aud-oll-001",
}

CLASSIFY_SECRET_LEAK = {
    "allowed": False,
    "guardsTriggered": ["G2_SECRET_LEAK"],
    "auditId": "aud-oll-001",
}


def _make_transport_with_classify(action_response: dict, classify_response: dict) -> httpx.MockTransport:
    return make_transport({
        "/api/v1/governance/check-action": action_response,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/governance/classify": classify_response,
        "/api/v1/governance/provider-compliance": {"ok": True},
        "/api/v1/health": {"status": "healthy"},
    })


def _make_og(
    transport: httpx.MockTransport,
    enforce: bool = True,
    base_url: str = "http://127.0.0.1:11434",
) -> OllamaGovernance:
    client = make_client(transport, enforce=enforce)
    return OllamaGovernance(
        client=client,
        agent_name="ollama-agent",
        agent_role="inference",
        base_url=base_url,
    )


def _mock_ollama_client(chat_response: dict, generate_response: dict) -> Any:
    class MockOllamaClient:
        def chat(self, **kwargs: Any) -> dict:
            return chat_response

        def generate(self, **kwargs: Any) -> dict:
            return generate_response

    return MockOllamaClient()


# ---------------------------------------------------------------------------
# Loopback validation helper
# ---------------------------------------------------------------------------

class TestLoopbackHelper:
    def test_loopback_127(self):
        assert _is_loopback("http://127.0.0.1:11434") is True

    def test_loopback_localhost(self):
        assert _is_loopback("http://localhost:11434") is True

    def test_non_loopback(self):
        assert _is_loopback("http://192.168.1.100:11434") is False

    def test_remote_host(self):
        assert _is_loopback("https://ollama.example.com") is False


# ---------------------------------------------------------------------------
# Non-loopback warning
# ---------------------------------------------------------------------------

class TestOllamaLoopbackWarning:
    def test_non_loopback_warns(self, capsys):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        _make_og(transport, base_url="http://192.168.1.100:11434")
        captured = capsys.readouterr()
        assert "not a loopback address" in captured.err

    def test_loopback_no_warning(self, capsys):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        _make_og(transport, base_url="http://127.0.0.1:11434")
        captured = capsys.readouterr()
        assert "not a loopback address" not in captured.err


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestOllamaHappyPath:
    def test_intercept_request_allow_chat(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        og = _make_og(transport)

        decision = og.intercept_request({
            "model": "llama3.2",
            "messages": [{"role": "user", "content": "Hello"}],
        })
        assert decision.allowed
        assert decision.audit_id == "aud-oll-001"

    def test_intercept_request_allow_generate(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        og = _make_og(transport)

        decision = og.intercept_request({
            "model": "mistral",
            "prompt": "Hello world",
            "system": "You are concise.",
        })
        assert decision.allowed

    def test_system_message_from_messages_extracted(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_request({
            "model": "llama3.2",
            "messages": [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": "Hi"},
            ],
        })
        assert captured[0]["input"]["systemPromptDigest"] == "You are a helpful assistant."

    def test_generate_system_field_extracted(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_request({
            "model": "mistral",
            "prompt": "Hello",
            "system": "Be precise.",
        })
        assert captured[0]["input"]["systemPromptDigest"] == "Be precise."
        assert captured[0]["input"]["isGenerateFormat"] is True

    def test_tool_names_extracted(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_request({
            "model": "llama3.2",
            "messages": [],
            "tools": [
                {"type": "function", "function": {"name": "run_python", "description": "Execute Python"}},
                {"type": "function", "function": {"name": "search_web"}},
            ],
        })
        assert captured[0]["input"]["toolNames"] == ["run_python", "search_web"]
        assert captured[0]["input"]["toolCount"] == 2

    def test_intercept_response_clean(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        og = _make_og(transport)

        classified = og.intercept_response(
            response={"message": {"role": "assistant", "content": "Hello!"}, "done": True},
            audit_id="aud-oll-001",
        )
        assert classified.allowed


# ---------------------------------------------------------------------------
# 2. Secret leak G2
# ---------------------------------------------------------------------------

class TestOllamaSecretLeak:
    def test_g2_secret_in_response(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        og = _make_og(transport)

        classified = og.intercept_response(
            response={"message": {"content": "MY_SECRET=abc123"}, "done": True},
            audit_id="aud-oll-001",
        )
        assert not classified.allowed
        assert "G2_SECRET_LEAK" in classified.guards_triggered

    def test_proxy_chat_warns_on_g2(self, capsys):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        og = _make_og(transport)

        proxy = og.wrap(_mock_ollama_client(
            chat_response={"message": {"content": "secret-value"}, "done": True},
            generate_response={},
        ))
        proxy.chat(model="llama3.2", messages=[{"role": "user", "content": "Hi"}])
        captured = capsys.readouterr()
        assert "G-series classification" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal
# ---------------------------------------------------------------------------

class TestOllamaPhiIngress:
    def test_phi_denied_no_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        decision = og.intercept_request({
            "model": "llama3.2",
            "messages": [{"role": "system", "content": "Patient SSN: 123-45-6789"}],
        })
        assert decision.denied

    def test_phi_raises_when_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=True)

        with pytest.raises(GovernanceViolation):
            og.intercept_request({
                "model": "llama3.2",
                "messages": [{"role": "system", "content": "PHI data"}],
            })


# ---------------------------------------------------------------------------
# 4. Provider compliance registration
# ---------------------------------------------------------------------------

class TestOllamaProviderCompliance:
    def test_no_baa_registered(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_og(httpx.MockTransport(handler))
        assert len(registered) == 1
        assert registered[0]["provider"] == "ollama"
        assert registered[0]["baaAvailable"] is False

    def test_notes_indicate_local(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_og(httpx.MockTransport(handler))
        assert "local" in registered[0]["notes"].lower()


# ---------------------------------------------------------------------------
# 5. Subscription gate
# ---------------------------------------------------------------------------

class TestOllamaSubscriptionGate:
    def test_subscription_revoked_blocks(self):
        sub_deny = {
            "decision": "DENY",
            "reason": "Subscription inactive",
            "auditId": "aud-sub-oll",
        }
        transport = _make_transport_with_classify(sub_deny, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        decision = og.intercept_request({
            "model": "llama3.2",
            "messages": [{"role": "user", "content": "Hello"}],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# 6. Audit chain append
# ---------------------------------------------------------------------------

class TestOllamaAuditChain:
    def test_report_result_closes_chain(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_CLEAN)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_response(
            response={"message": {"content": "Done"}, "done": True},
            audit_id="aud-oll-001",
        )
        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-oll-001"
        assert reported[0]["success"] is True

    def test_report_result_failure_on_blocked(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_SECRET_LEAK)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        og = _make_og(t)

        og.intercept_response(
            response={"message": {"content": "secret-value"}},
            audit_id="aud-oll-001",
        )
        assert reported[0]["success"] is False


# ---------------------------------------------------------------------------
# wrap() proxy
# ---------------------------------------------------------------------------

class TestOllamaProxy:
    def test_wrap_returns_proxy(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        og = _make_og(transport)
        proxy = og.wrap(_mock_ollama_client({}, {}))
        assert isinstance(proxy, OllamaClientProxy)

    def test_proxy_chat_denied_returns_message(self):
        deny = {"decision": "DENY", "reason": "policy block", "auditId": "aud-d"}
        transport = _make_transport_with_classify(deny, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        proxy = og.wrap(_mock_ollama_client({}, {}))
        result = proxy.chat(model="llama3.2", messages=[{"role": "user", "content": "Hi"}])
        assert result["done_reason"] == "governance_denied"
        assert "[GOVERNANCE DENIED]" in result["message"]["content"]

    def test_proxy_generate_denied_returns_response(self):
        deny = {"decision": "DENY", "reason": "blocked", "auditId": "aud-e"}
        transport = _make_transport_with_classify(deny, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        proxy = og.wrap(_mock_ollama_client({}, {}))
        result = proxy.generate(model="mistral", prompt="Hello")
        assert result["done_reason"] == "governance_denied"
        assert "[GOVERNANCE DENIED]" in result["response"]

    def test_proxy_chat_allows_clean(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        og = _make_og(transport)

        good_resp = {
            "model": "llama3.2",
            "message": {"role": "assistant", "content": "Safe reply"},
            "done": True,
            "done_reason": "stop",
        }
        proxy = og.wrap(_mock_ollama_client(good_resp, {}))
        result = proxy.chat(model="llama3.2", messages=[{"role": "user", "content": "Hi"}])
        assert result["message"]["content"] == "Safe reply"

    def test_proxy_requires_approval(self):
        approval = {"decision": "REQUIRE_APPROVAL", "reason": "needs sign-off", "auditId": "aud-y"}
        transport = _make_transport_with_classify(approval, CLASSIFY_CLEAN)
        og = _make_og(transport, enforce=False)

        proxy = og.wrap(_mock_ollama_client({}, {}))
        result = proxy.chat(model="llama3.2", messages=[{"role": "user", "content": "Deploy"}])
        assert result["done_reason"] == "governance_pending"
        assert "[GOVERNANCE PENDING]" in result["message"]["content"]
