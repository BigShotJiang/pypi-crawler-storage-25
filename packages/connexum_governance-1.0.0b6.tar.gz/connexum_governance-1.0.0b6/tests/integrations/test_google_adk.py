"""Tests for Google ADK governance integration (B2-05).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak / PHI in tool result -- G2 output classifier
3. PHI ingress refusal -- unapproved tool or disallowed path
4. Provider compliance -- BAA region enforcement (Vertex AI vs AI Studio)
5. Subscription gate -- governance server DENY at agent_start
6. Audit chain append -- canonical events round-trip
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.google_adk import (
    BaaRegionError,
    GoogleAdkGovernance,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-adk-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-adk-002"}
SUB_DENY = {
    "decision": "DENY",
    "reason": "Subscription inactive or expired",
    "auditId": "aud-adk-003",
}


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    approved_tools: list[str] | None = None,
    require_vertex_ai: bool = False,
) -> GoogleAdkGovernance:
    client = make_client(transport, enforce=enforce)
    return GoogleAdkGovernance(
        client=client,
        approved_tools=approved_tools,
        sensitive_tools=["admin_action"],
        require_vertex_ai=require_vertex_ai,
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestGoogleAdkHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            session_id="sess-001",
            user_id="user-001",
            pack_binding=["hipaa"],
        )
        assert decision.allowed
        assert "sess-001" in adapter._sessions

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"])
        decision = adapter.tool_call("sess-001", "calculator", {"expression": "2+2"})
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"])
        adapter.tool_call("sess-001", "search", {"q": "AI"})
        adapter.tool_result("sess-001", "search", "Search results: AI governance overview")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"])
        decision = adapter.llm_call(
            "sess-001",
            "gemini-1.5-pro",
            messages=[{"role": "user", "parts": [{"text": "Hello"}]}],
            via_vertex=True,
        )
        assert decision.allowed

    def test_llm_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"])
        adapter.llm_call("sess-001", "gemini-1.5-pro", [])
        adapter.llm_result("sess-001", "gemini-1.5-pro", "Here is the summary.")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_clean(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"])
        adapter.agent_end("sess-001", success=True, summary="Completed")
        assert "sess-001" not in adapter._sessions

    def test_full_run_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-002", user_id="user-002", pack_binding=["gdpr"])
        adapter.tool_call("sess-002", "search", {"q": "test"})
        adapter.tool_result("sess-002", "search", "found results")
        adapter.llm_call("sess-002", "gemini-1.5-flash", [], via_vertex=True)
        adapter.llm_result("sess-002", "gemini-1.5-flash", "Here you go!")
        adapter.agent_end("sess-002", success=True)


# ---------------------------------------------------------------------------
# 2. PHI in tool result -- G2 / output classifier
# ---------------------------------------------------------------------------

class TestGoogleAdkSecretLeak:
    def test_phi_in_tool_result_flags_classifier(self, capsys):
        """PHI in tool result triggers output classifier warning."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-g2", pack_binding=["soc2"])
        adapter.tool_call("sess-g2", "db", {"q": "SELECT *"})
        adapter.tool_result(
            "sess-g2",
            "db",
            "ssn=123-45-6789 patient_id=ABC",
            success=True,
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_tool_result_marks_report_failure(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-g2b", pack_binding=["soc2"])
        adapter.tool_call("sess-g2b", "search", {})
        adapter.tool_result("sess-g2b", "search", "npi=1234567890 diagnosis=hypertension")

        assert any(r["success"] is False for r in reported)

    def test_phi_in_llm_result_flags_exfiltration(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-g2c", pack_binding=["hipaa"])
        adapter.llm_call("sess-g2c", "gemini-1.5-pro", [], via_vertex=True)
        adapter.llm_result(
            "sess-g2c",
            "gemini-1.5-pro",
            "The patient dob: 1990-01-01 has been processed.",
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress / tool not in allowlist -- denial
# ---------------------------------------------------------------------------

class TestGoogleAdkPhiIngress:
    def test_tool_not_in_allowlist_denied(self):
        """Tool not in approved_tools list is denied."""
        adapter = _adapter(_transport(), approved_tools=["search", "calculator"])
        adapter.agent_start("sess-allow", pack_binding=["soc2"])
        decision = adapter.tool_call("sess-allow", "admin_action", {"arg": "value"})
        assert decision.denied
        assert "admin_action" in decision.reason

    def test_tool_in_allowlist_passes(self):
        """Tool in approved_tools list passes."""
        adapter = _adapter(_transport(), approved_tools=["search", "calculator"])
        adapter.agent_start("sess-allow2", pack_binding=["soc2"])
        decision = adapter.tool_call("sess-allow2", "search", {"q": "query"})
        assert decision.allowed

    def test_no_allowlist_all_tools_pass(self):
        """When approved_tools=None, all tools are permitted."""
        adapter = _adapter(_transport(), approved_tools=None)
        adapter.agent_start("sess-allow3", pack_binding=["soc2"])
        decision = adapter.tool_call("sess-allow3", "any_tool", {})
        assert decision.allowed


# ---------------------------------------------------------------------------
# 4. Provider compliance -- BAA region enforcement (Vertex AI vs AI Studio)
# ---------------------------------------------------------------------------

class TestGoogleAdkProviderCompliance:
    def test_ai_studio_denied_when_require_vertex_ai(self):
        """Direct AI Studio call is denied when require_vertex_ai=True."""
        adapter = _adapter(_transport(), require_vertex_ai=True)
        adapter.agent_start("sess-baa", pack_binding=["hipaa"])
        decision = adapter.llm_call(
            "sess-baa",
            "gemini-1.5-pro",
            [],
            via_vertex=False,  # AI Studio path
        )
        assert decision.denied
        assert "BAA" in decision.reason or "Vertex" in decision.reason

    def test_vertex_ai_allowed_when_require_vertex_ai(self):
        """Vertex AI path is allowed when require_vertex_ai=True."""
        adapter = _adapter(_transport(), require_vertex_ai=True)
        adapter.agent_start("sess-baa2", pack_binding=["hipaa"])
        decision = adapter.llm_call(
            "sess-baa2",
            "gemini-1.5-pro",
            [],
            via_vertex=True,
        )
        assert decision.allowed

    def test_ai_studio_allowed_when_not_require_vertex(self):
        """AI Studio path allowed when require_vertex_ai=False."""
        adapter = _adapter(_transport(), require_vertex_ai=False)
        adapter.agent_start("sess-baa3", pack_binding=["soc2"])
        decision = adapter.llm_call(
            "sess-baa3",
            "gemini-1.5-flash",
            [],
            via_vertex=False,
        )
        assert decision.allowed

    def test_session_id_and_user_id_forwarded_in_audit(self):
        """session_id and user_id appear in governance check_action input."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-ctx", user_id="user-007", pack_binding=["hipaa"])

        assert len(captured) >= 1
        start_call = captured[0]
        assert start_call["input"]["sessionId"] == "sess-ctx"
        assert start_call["input"]["userId"] == "user-007"


# ---------------------------------------------------------------------------
# 5. Subscription gate -- governance server DENY
# ---------------------------------------------------------------------------

class TestGoogleAdkSubscriptionGate:
    def test_agent_start_subscription_deny(self):
        """Governance DENY at agent_start is returned as denied decision."""
        transport = _transport(**{"/api/v1/governance/check-action": SUB_DENY})
        adapter = _adapter(transport, enforce=False)
        decision = adapter.agent_start(
            "sess-sub",
            pack_binding=["hipaa"],
        )
        assert decision.denied
        assert "subscription" in decision.reason.lower() or "inactive" in decision.reason.lower()

    def test_tool_call_governance_deny(self):
        """Governance DENY at tool_call is returned as denied decision."""
        transport = _transport(**{"/api/v1/governance/check-action": SUB_DENY})
        adapter = _adapter(transport, enforce=False)
        adapter.agent_start("sess-sub2", pack_binding=["hipaa"])
        # Override session without governance denial at agent_start
        adapter._sessions["sess-sub2"] = {"pack_binding": ["hipaa"]}
        # Now trigger tool_call against the denying server
        transport2 = _transport(**{"/api/v1/governance/check-action": DENY})
        client2 = make_client(transport2, enforce=False)
        adapter2 = GoogleAdkGovernance(client=client2, agent_name="test")
        adapter2._sessions["sess-deny"] = {"pack_binding": ["hipaa"]}
        decision = adapter2.tool_call("sess-deny", "search", {})
        assert decision.denied


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip
# ---------------------------------------------------------------------------

class TestGoogleAdkAuditChain:
    def test_tool_result_uses_audit_id_from_tool_call(self):
        """audit_id from tool_call is used in tool_result report_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-chain", pack_binding=["soc2"])
        adapter.tool_call("sess-chain", "search", {"q": "test"})
        adapter.tool_result("sess-chain", "search", "some results")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-adk-001"
        assert reported[0]["success"] is True

    def test_llm_result_uses_audit_id_from_llm_call(self):
        """audit_id from llm_call is used in llm_result report_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-llm-chain", pack_binding=["hipaa"])
        adapter.llm_call("sess-llm-chain", "gemini-1.5-pro", [], via_vertex=True)
        adapter.llm_result("sess-llm-chain", "gemini-1.5-pro", "Hello!")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-adk-001"

    def test_agent_end_fires_terminal_check_action(self):
        """agent_end fires check_action to seal terminal audit event."""
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-end", pack_binding=["soc2"])
        adapter.agent_end("sess-end", success=True)

        action_calls = [c for c in calls if "check-action" in c]
        # agent_start + agent_end each call check_action
        assert len(action_calls) >= 2

    def test_framework_tag_in_check_action_input(self):
        """framework: google-adk is included in all governance check_action inputs."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-tag", pack_binding=["soc2"])

        assert captured[0]["input"]["framework"] == "google-adk"
