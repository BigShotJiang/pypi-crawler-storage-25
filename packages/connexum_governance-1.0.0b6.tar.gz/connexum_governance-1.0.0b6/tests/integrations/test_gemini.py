"""Tests for GeminiGovernance integration (B1-03).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 response classification
3. PHI ingress refusal
4. Provider compliance registration (no BAA on consumer tier)
5. Subscription gate
6. Audit chain append
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.gemini import GeminiGovernance, GeminiModelProxy
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ALLOW_WITH_AUDIT = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-gem-001",
}

PHI_DENY = {
    "decision": "DENY",
    "reason": "G3: PHI ingress blocked under HIPAA pack",
    "auditId": "aud-gem-003",
}

CLASSIFY_CLEAN = {
    "allowed": True,
    "guardsTriggered": [],
    "auditId": "aud-gem-001",
}

CLASSIFY_SECRET_LEAK = {
    "allowed": False,
    "guardsTriggered": ["G2_SECRET_LEAK"],
    "auditId": "aud-gem-001",
}


def _make_transport_with_classify(action_response: dict, classify_response: dict) -> httpx.MockTransport:
    return make_transport({
        "/api/v1/governance/check-action": action_response,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/governance/classify": classify_response,
        "/api/v1/governance/provider-compliance": {"ok": True},
        "/api/v1/health": {"status": "healthy"},
    })


def _make_gg(transport: httpx.MockTransport, enforce: bool = True) -> GeminiGovernance:
    client = make_client(transport, enforce=enforce)
    return GeminiGovernance(client=client, agent_name="gemini-agent", agent_role="generator")


def _mock_gemini_model(response_dict: dict[str, Any]) -> Any:
    class MockGenerativeModel:
        model_name = "gemini-1.5-flash"

        def generate_content(self, contents: Any, **kwargs: Any) -> dict:
            return response_dict

    return MockGenerativeModel()


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestGeminiHappyPath:
    def test_intercept_request_allow(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        gg = _make_gg(transport)

        decision = gg.intercept_request({
            "model": "gemini-1.5-flash",
            "contents": [{"role": "user", "parts": [{"text": "Hello"}]}],
        })
        assert decision.allowed
        assert decision.audit_id == "aud-gem-001"

    def test_intercept_response_clean(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        gg = _make_gg(transport)

        response = {
            "candidates": [
                {"content": {"parts": [{"text": "Hello back"}], "role": "model"}}
            ]
        }
        classified = gg.intercept_response(response=response, audit_id="aud-gem-001")
        assert classified.allowed
        assert classified.guards_triggered == []

    def test_tool_names_extracted_from_function_declarations(self):
        """Tool names from tools[].function_declarations forwarded to governance."""
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        gg = _make_gg(t)

        gg.intercept_request({
            "model": "gemini-1.5-pro",
            "contents": [],
            "tools": [
                {
                    "function_declarations": [
                        {"name": "search_web", "description": "Search"},
                        {"name": "execute_code", "description": "Run code"},
                    ]
                }
            ],
        })
        assert captured[0]["input"]["toolNames"] == ["search_web", "execute_code"]
        assert captured[0]["input"]["toolCount"] == 2

    def test_system_instruction_extracted(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        gg = _make_gg(t)

        gg.intercept_request({
            "model": "gemini-1.5-flash",
            "contents": [],
            "system_instruction": {
                "parts": [{"text": "You are a helpful assistant."}]
            },
        })
        assert captured[0]["input"]["systemPromptDigest"] == "You are a helpful assistant."

    def test_string_system_instruction(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        gg = _make_gg(t)

        gg.intercept_request({
            "model": "gemini-1.5-flash",
            "contents": [],
            "system_instruction": "Be concise.",
        })
        assert captured[0]["input"]["systemPromptDigest"] == "Be concise."


# ---------------------------------------------------------------------------
# 2. Secret leak G2
# ---------------------------------------------------------------------------

class TestGeminiSecretLeak:
    def test_g2_secret_in_response(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        gg = _make_gg(transport)

        classified = gg.intercept_response(
            response={"candidates": [{"content": {"parts": [{"text": "AIzaSy-secret-key"}]}}]},
            audit_id="aud-gem-001",
        )
        assert not classified.allowed
        assert "G2_SECRET_LEAK" in classified.guards_triggered

    def test_proxy_logs_g2_warning(self, capsys):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        gg = _make_gg(transport)

        mock_resp = {
            "candidates": [
                {"content": {"parts": [{"text": "AIzaSy-leaked"}], "role": "model"}}
            ]
        }
        proxy = gg.wrap(_mock_gemini_model(mock_resp))
        proxy.generate_content("Hello")
        captured = capsys.readouterr()
        assert "G-series classification" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal
# ---------------------------------------------------------------------------

class TestGeminiPhiIngress:
    def test_phi_denied_no_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        gg = _make_gg(transport, enforce=False)

        decision = gg.intercept_request({
            "model": "gemini-1.5-flash",
            "contents": [],
            "system_instruction": "Patient MRN: 12345, DOB: 1990-03-15",
        })
        assert decision.denied

    def test_phi_raises_when_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        gg = _make_gg(transport, enforce=True)

        with pytest.raises(GovernanceViolation):
            gg.intercept_request({
                "model": "gemini-1.5-flash",
                "contents": [],
                "system_instruction": "PHI in system instruction",
            })


# ---------------------------------------------------------------------------
# 4. Provider compliance registration (no BAA on consumer tier)
# ---------------------------------------------------------------------------

class TestGeminiProviderCompliance:
    def test_baa_not_available_registered(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_gg(httpx.MockTransport(handler))
        assert len(registered) == 1
        assert registered[0]["provider"] == "gemini"
        assert registered[0]["baaAvailable"] is False

    def test_notes_mention_vertex_ai(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_gg(httpx.MockTransport(handler))
        assert "vertex" in registered[0]["notes"].lower()


# ---------------------------------------------------------------------------
# 5. Subscription gate
# ---------------------------------------------------------------------------

class TestGeminiSubscriptionGate:
    def test_subscription_revoked_blocks(self):
        sub_deny = {
            "decision": "DENY",
            "reason": "Subscription inactive",
            "auditId": "aud-sub-gem",
        }
        transport = _make_transport_with_classify(sub_deny, CLASSIFY_CLEAN)
        gg = _make_gg(transport, enforce=False)

        decision = gg.intercept_request({
            "model": "gemini-1.5-flash",
            "contents": [{"role": "user", "parts": [{"text": "Hello"}]}],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# 6. Audit chain append
# ---------------------------------------------------------------------------

class TestGeminiAuditChain:
    def test_report_result_closes_chain(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_CLEAN)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        gg = _make_gg(t)

        gg.intercept_response(
            response={"candidates": [{"content": {"parts": [{"text": "Done"}]}}]},
            audit_id="aud-gem-001",
        )
        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-gem-001"
        assert reported[0]["success"] is True

    def test_report_result_failure_on_blocked_response(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_SECRET_LEAK)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        gg = _make_gg(t)

        gg.intercept_response(
            response={"candidates": [{"content": {"parts": [{"text": "AIzaSy-leaked"}]}}]},
            audit_id="aud-gem-001",
        )
        assert reported[0]["success"] is False


# ---------------------------------------------------------------------------
# wrap() proxy
# ---------------------------------------------------------------------------

class TestGeminiProxy:
    def test_wrap_returns_proxy(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        gg = _make_gg(transport)

        proxy = gg.wrap(_mock_gemini_model({"candidates": []}))
        assert isinstance(proxy, GeminiModelProxy)

    def test_proxy_allows_normal_content(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        gg = _make_gg(transport)

        mock_resp = {
            "candidates": [
                {"content": {"parts": [{"text": "Safe reply"}], "role": "model"}}
            ]
        }
        proxy = gg.wrap(_mock_gemini_model(mock_resp))
        result = proxy.generate_content("Say hello")
        # Returns the raw model response when allowed
        assert result["candidates"][0]["content"]["parts"][0]["text"] == "Safe reply"

    def test_proxy_denied_returns_denial_candidate(self):
        deny = {"decision": "DENY", "reason": "policy block", "auditId": "aud-x"}
        transport = _make_transport_with_classify(deny, CLASSIFY_CLEAN)
        gg = _make_gg(transport, enforce=False)

        proxy = gg.wrap(_mock_gemini_model({"candidates": []}))
        result = proxy.generate_content("Generate something unsafe")
        assert result["candidates"][0]["finish_reason"] == "GOVERNANCE_DENIED"
        assert "[GOVERNANCE DENIED]" in result["candidates"][0]["content"]["parts"][0]["text"]

    def test_proxy_string_content_converted(self):
        """Proxy handles string content (not just list of contents)."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        gg = _make_gg(transport)

        mock_resp = {
            "candidates": [
                {"content": {"parts": [{"text": "OK"}], "role": "model"}}
            ]
        }
        proxy = gg.wrap(_mock_gemini_model(mock_resp))
        # Should not raise
        result = proxy.generate_content("simple string prompt")
        assert result["candidates"][0]["content"]["parts"][0]["text"] == "OK"
