"""Tests for the JetBrains AI Assistant governance integration (B3-06).

Mirrors the 6 parity cases required for all Python IDE adapters:
  P1 -- Pack-binding primacy: empty binding denied
  P2 -- Backend compliance gate
  P3 -- Output classifier (toolResult secret scan)
  P4 -- Output exfiltration scanner (llmResult PHI/secret scan)
  P5 -- policy_bridge round-trip
  P6 -- wrap_webhook dispatches to emit_event

Plus JetBrains AI-specific tests:
  JB-01 -- intercept_chat pre allows clean request
  JB-02 -- intercept_chat pre blocks secret in prompt
  JB-03 -- intercept_chat post blocks secret in response
  JB-04 -- intercept_inline pre allows clean request
  JB-05 -- intercept_inline blocks secret in surrounding context
  JB-06 -- intercept_refactor blocks PHI under HIPAA (PT-ADAPT-JBAI-1)
  JB-07 -- intercept_commit_message blocks secret in diff (PT-ADAPT-JBAI-2)
  JB-08 -- intercept_datagrip_result blocks PHI columns under HIPAA (PT-ADAPT-JBAI-3)
  JB-09 -- intercept_datagrip_result warns (not blocks) PHI columns without HIPAA
  JB-10 -- jetbrains-cloud backend blocked under HIPAA
  JB-11 -- anthropic backend allowed under HIPAA
  JB-12 -- JETBRAINS_BAA_ELIGIBLE_BACKENDS contains expected backends
"""

from __future__ import annotations

import sys
import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.jetbrains_ai import (
    JetBrainsAIGovernance,
    JETBRAINS_BAA_ELIGIBLE_BACKENDS,
)

# ---------------------------------------------------------------------------
# Fake secret strings (assembled at runtime to avoid secret-leak-scanner)
# ---------------------------------------------------------------------------

_FAKE_SK_PREFIX = "sk-"
_FAKE_SK_SUFFIX = "abc12345678901234567890"
_FAKE_OPENAI_KEY = _FAKE_SK_PREFIX + _FAKE_SK_SUFFIX

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-jb-001",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    ai_backend: str = "anthropic",
    ide_variant: str = "intellij-idea",
    pack_binding: list[str] | None = None,
) -> JetBrainsAIGovernance:
    client = make_client(transport, enforce=enforce)
    return JetBrainsAIGovernance(
        client=client,
        agent_name="jb-ai-agent-01",
        pack_binding=pack_binding if pack_binding is not None else ["soc2"],
        ai_backend=ai_backend,  # type: ignore[arg-type]
        ide_variant=ide_variant,  # type: ignore[arg-type]
    )


# ---------------------------------------------------------------------------
# P1 -- Pack-binding primacy
# ---------------------------------------------------------------------------

class TestPackBindingPrimacy:
    def test_empty_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "jb-ai-agent-01", "jb:completion",
            {"filePath": "/workspace/main.py"},
            pack_binding=[],
        )
        assert decision.denied

    def test_none_pack_binding_falls_back_to_instance_binding(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "jb-ai-agent-01", "jb:completion",
            {"filePath": "/workspace/main.py"},
            pack_binding=None,
        )
        assert decision.allowed

    def test_missing_pack_binding_on_emit_event_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.emit_event("toolCall", {
            "agentId": "jb-ai-agent-01",
            "toolName": "jb:completion",
            "args": {},
        })
        assert decision.denied

    def test_chat_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_chat({
            "promptText": "Explain this function",
        })
        assert decision.denied

    def test_inline_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_inline({
            "surroundingContext": "def process():",
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# P2 -- Backend compliance gate
# ---------------------------------------------------------------------------

class TestBackendCompliance:
    def test_anthropic_backend_under_hipaa_allowed(self):
        """Anthropic is BAA-eligible."""
        adapter = _adapter(_transport(), ai_backend="anthropic", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Explain this method",
            "packBinding": ["hipaa"],
        })
        assert decision.allowed

    def test_jetbrains_cloud_backend_under_hipaa_blocked(self):
        """JetBrains Cloud is NOT BAA-eligible."""
        adapter = _adapter(_transport(), ai_backend="jetbrains-cloud", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Explain this method",
            "packBinding": ["hipaa"],
            "backend": "jetbrains-cloud",
        })
        assert decision.denied
        assert "baa" in decision.reason.lower() or "hipaa" in decision.reason.lower()

    def test_jetbrains_cloud_non_hipaa_allowed(self):
        """JetBrains Cloud is allowed without HIPAA binding."""
        adapter = _adapter(_transport(), ai_backend="jetbrains-cloud")
        decision = adapter.intercept_chat({
            "promptText": "Refactor this function",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_ollama_backend_under_hipaa_allowed(self):
        """Ollama (self-hosted) is BAA-eligible."""
        adapter = _adapter(_transport(), ai_backend="ollama", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Explain this",
            "packBinding": ["hipaa"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# P3 -- Output classifier (toolResult secret scan)
# ---------------------------------------------------------------------------

class TestOutputClassifier:
    def test_secret_in_tool_result_flags_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "jb-ai-agent-01", "jb:completion",
            "SECRET_KEY=abc12345678",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert "secret" in captured.err.lower() or "classifier" in captured.err.lower()

    def test_clean_tool_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "jb-ai-agent-01", "jb:completion",
            "def hello(): pass",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P4 -- Output exfiltration scanner (llmResult)
# ---------------------------------------------------------------------------

class TestOutputExfiltrationScanner:
    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "jb-ai-agent-01", "anthropic",
            "The patient_id is 12345 and diagnosis is diabetes.",
            pack_binding=["hipaa"],
        )
        captured = capsys.readouterr()
        assert "exfiltration" in captured.err.lower() or "phi" in captured.err.lower() or "secret" in captured.err.lower()

    def test_clean_llm_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "jb-ai-agent-01", "anthropic",
            "Here is the refactored function.",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P5 -- policy_bridge round-trip
# ---------------------------------------------------------------------------

class TestPolicyBridge:
    def test_policy_bridge_callback_called(self):
        from connexum_governance.models import GovernanceDecision, DecisionType
        calls = []

        def my_policy(event_type, payload):
            calls.append((event_type, payload))
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="custom-allow",
                audit_id="bridge-jb-001",
            )

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=my_policy)
        result = bridge.decide("toolCall", {
            "agentId": "jb-ai-agent-01",
            "toolName": "jb:completion",
            "args": {},
        })
        assert len(calls) == 1
        assert result.allowed

    def test_policy_bridge_falls_back_to_rest_api_when_callback_returns_none(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=lambda e, p: None)
        result = bridge.decide("toolCall", {
            "agentId": "jb-ai-agent-01",
            "toolName": "jb:chat",
            "args": {},
        })
        assert result.allowed

    def test_policy_bridge_no_callback(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=None)
        result = bridge.decide("llmCall", {
            "agentId": "jb-ai-agent-01",
            "model": "anthropic",
            "messageCount": 1,
        })
        assert result.allowed


# ---------------------------------------------------------------------------
# P6 -- wrap_webhook dispatches to emit_event
# ---------------------------------------------------------------------------

class TestWrapWebhook:
    def test_wrap_webhook_dispatches_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "jb-ai-agent-01",
            "toolName": "jb:completion",
            "args": {},
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_wrap_webhook_missing_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({"agentId": "jb-ai-agent-01", "packBinding": ["soc2"]})

    def test_wrap_webhook_missing_agent_id_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({"eventType": "toolCall", "packBinding": ["soc2"]})

    def test_wrap_webhook_invalid_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="Unknown"):
            adapter.wrap_webhook({
                "eventType": "unknownSurface",
                "agentId": "jb-ai-agent-01",
                "packBinding": ["soc2"],
            })


# ---------------------------------------------------------------------------
# JB-01 to JB-12 -- JetBrains AI-specific tests
# ---------------------------------------------------------------------------

class TestJetBrainsAIChat:
    def test_jb_01_chat_pre_clean_allowed(self):
        """JB-01: Clean pre-chat request is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "Explain this function",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_jb_02_chat_pre_secret_blocked(self):
        """JB-02: Secret in chat prompt is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "My key is " + _FAKE_OPENAI_KEY,
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_jb_03_chat_post_secret_in_response_blocked(self):
        """JB-03: Secret in chat response is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "responseText": "Use this: " + _FAKE_OPENAI_KEY,
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_jb_chat_post_clean_allowed(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "responseText": "Here is the refactored code.",
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


class TestJetBrainsAIInline:
    def test_jb_04_inline_pre_clean_allowed(self):
        """JB-04: Clean inline completion request is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_inline({
            "surroundingContext": "def process_order(order_id: int):",
            "filePath": "/workspace/orders.py",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_jb_05_inline_secret_in_context_blocked(self):
        """JB-05: Secret in surrounding context blocks inline completion."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_inline({
            "surroundingContext": "key = " + _FAKE_OPENAI_KEY,
            "filePath": "/workspace/config.py",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_jb_inline_post_secret_blocked(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_inline({
            "completionText": "key = " + _FAKE_OPENAI_KEY,
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.denied


class TestJetBrainsAIRefactor:
    def test_jb_06_refactor_phi_under_hipaa_blocked(self):
        """JB-06: PHI indicator in refactor target under HIPAA is blocked (PT-ADAPT-JBAI-1)."""
        adapter = _adapter(_transport(), ai_backend="anthropic", pack_binding=["hipaa"])
        decision = adapter.intercept_refactor({
            "targetSymbol": "process_patient_records",
            "intent": "Optimize performance",
            "surroundingContext": "def process_patient_records(patient_id, diagnosis):",
            "filePath": "/workspace/health/processor.py",
            "packBinding": ["hipaa"],
        })
        assert decision.denied
        assert "hipaa" in decision.reason.lower() or "phi" in decision.reason.lower()

    def test_jb_refactor_clean_allowed(self):
        """Clean refactor request (no PHI) is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_refactor({
            "targetSymbol": "calculate_tax",
            "intent": "Simplify logic",
            "surroundingContext": "def calculate_tax(price, rate):",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_jb_refactor_secret_blocked(self):
        """Secret in refactor context is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_refactor({
            "targetSymbol": "connect",
            "intent": "Refactor",
            "surroundingContext": "api_key = " + _FAKE_OPENAI_KEY,
            "packBinding": ["soc2"],
        })
        assert decision.denied


class TestJetBrainsAICommitMessage:
    def test_jb_07_commit_message_secret_in_diff_blocked(self):
        """JB-07: Secret in diff added line blocks commit message generation (PT-ADAPT-JBAI-2)."""
        adapter = _adapter(_transport())
        _prefix = "AKIA"
        _suffix = "ABCDEFGHIJKLMNOPQRST"
        diff = (
            "diff --git a/config.py b/config.py\n"
            "--- a/config.py\n"
            "+++ b/config.py\n"
            "@@ -1,2 +1,3 @@\n"
            f"+AWS_KEY = {_prefix}{_suffix}\n"
        )
        decision = adapter.intercept_commit_message({
            "diff": diff,
            "branchName": "feature/add-aws-config",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_jb_commit_message_clean_diff_allowed(self):
        """Clean diff produces allowed commit message request."""
        adapter = _adapter(_transport())
        diff = (
            "diff --git a/api.py b/api.py\n"
            "+def hello(): return 'world'\n"
        )
        decision = adapter.intercept_commit_message({
            "diff": diff,
            "branchName": "feature/hello",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


class TestJetBrainsAIDataGrip:
    def test_jb_08_datagrip_phi_columns_under_hipaa_blocked(self):
        """JB-08: PHI column names in DataGrip result under HIPAA are blocked (PT-ADAPT-JBAI-3)."""
        adapter = _adapter(_transport(), ide_variant="datagrip", pack_binding=["hipaa"])
        decision = adapter.intercept_datagrip_result({
            "columns": ["id", "patient_id", "diagnosis", "order_date"],
            "query": "SELECT * FROM patients",
            "packBinding": ["hipaa"],
        })
        assert decision.denied
        assert "phi" in decision.reason.lower() or "hipaa" in decision.reason.lower()

    def test_jb_09_datagrip_phi_columns_without_hipaa_warns(self, capsys):
        """JB-09: PHI columns without HIPAA binding produce a warning (not a deny)."""
        adapter = _adapter(_transport(), ide_variant="datagrip")
        decision = adapter.intercept_datagrip_result({
            "columns": ["id", "patient_id", "diagnosis"],
            "query": "SELECT * FROM patients",
            "packBinding": ["soc2"],
        })
        captured = capsys.readouterr()
        # Should warn but allow
        assert decision.allowed
        assert "phi" in captured.err.lower() or "warn" in captured.err.lower()

    def test_jb_datagrip_clean_columns_allowed(self):
        """Clean column names pass without warning."""
        adapter = _adapter(_transport(), ide_variant="datagrip")
        decision = adapter.intercept_datagrip_result({
            "columns": ["id", "product_name", "quantity", "price"],
            "query": "SELECT * FROM products",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_jb_datagrip_pci_columns_under_hipaa_blocked(self):
        """PCI-indicator columns (card_number, cvv) under HIPAA are also blocked."""
        adapter = _adapter(_transport(), ide_variant="datagrip", pack_binding=["hipaa"])
        decision = adapter.intercept_datagrip_result({
            "columns": ["id", "card_number", "cvv", "expiry"],
            "query": "SELECT * FROM payments",
            "packBinding": ["hipaa"],
        })
        assert decision.denied


class TestJetBrainsBackendConstants:
    def test_jb_12_baa_eligible_backends(self):
        """JB-12: JETBRAINS_BAA_ELIGIBLE_BACKENDS contains expected backends."""
        assert "jetbrains-cloud" not in JETBRAINS_BAA_ELIGIBLE_BACKENDS
        assert "ollama" in JETBRAINS_BAA_ELIGIBLE_BACKENDS
        assert "openai" in JETBRAINS_BAA_ELIGIBLE_BACKENDS
        assert "anthropic" in JETBRAINS_BAA_ELIGIBLE_BACKENDS
        assert "azure-openai" in JETBRAINS_BAA_ELIGIBLE_BACKENDS

    def test_jb_10_jetbrains_cloud_blocked_under_hipaa(self):
        """JB-10: jetbrains-cloud backend is blocked under HIPAA."""
        adapter = _adapter(_transport(), ai_backend="jetbrains-cloud", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Explain this",
            "packBinding": ["hipaa"],
            "backend": "jetbrains-cloud",
        })
        assert decision.denied

    def test_jb_11_anthropic_allowed_under_hipaa(self):
        """JB-11: anthropic backend is BAA-eligible and allowed under HIPAA."""
        adapter = _adapter(_transport(), ai_backend="anthropic", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Explain this function",
            "packBinding": ["hipaa"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# Six canonical surfaces
# ---------------------------------------------------------------------------

class TestCanonicalSurfaces:
    def test_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("jb-ai-agent-01", pack_binding=["soc2"])
        assert decision.allowed

    def test_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "jb-ai-agent-01", "jb:completion", {}, pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_tool_result(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_result(
            "jb-ai-agent-01", "jb:completion", "def hello(): pass",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_call(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "jb-ai-agent-01", "anthropic",
            [{"role": "user", "content": "complete this"}],
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_result(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_result(
            "jb-ai-agent-01", "anthropic",
            "def hello(): return 'world'",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_agent_end(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_end("jb-ai-agent-01", success=True, pack_binding=["soc2"])
        assert decision.allowed
