"""Tests for the Amazon Q Developer governance integration (B3-07).

Mirrors the 6 parity cases required for all Python IDE adapters:
  P1 -- Pack-binding primacy: empty binding denied
  P2 -- BAA region compliance gate
  P3 -- Output classifier (toolResult secret scan)
  P4 -- Output exfiltration scanner (llmResult PHI/secret scan)
  P5 -- policy_bridge round-trip
  P6 -- wrap_webhook dispatches to emit_event

Plus Amazon Q Developer-specific tests:
  AQ-01 -- intercept_chat pre allows clean request in BAA region
  AQ-02 -- intercept_chat pre blocks non-BAA region under HIPAA (PT-ADAPT-AMAZONQ-1)
  AQ-03 -- intercept_chat pre blocks secret in prompt
  AQ-04 -- intercept_chat post blocks secret in response
  AQ-05 -- intercept_aws_op allows non-destructive operation
  AQ-06 -- intercept_aws_op blocks destructive operation (PT-ADAPT-AMAZONQ-3)
  AQ-07 -- intercept_aws_op blocks non-BAA region under HIPAA
  AQ-08 -- intercept_iam_policy blocks wildcard-action under HIPAA (PT-ADAPT-AMAZONQ-2)
  AQ-09 -- intercept_iam_policy warns (not blocks) wildcard-action without HIPAA
  AQ-10 -- intercept_code_transform blocks non-BAA region under HIPAA
  AQ-11 -- AMAZON_Q_BAA_REGIONS contains expected regions
  AQ-12 -- DESTRUCTIVE_AWS_OPERATIONS blocks known operations
"""

from __future__ import annotations

import sys
import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.amazon_q_developer import (
    AmazonQDeveloperGovernance,
    AMAZON_Q_BAA_REGIONS,
    _DESTRUCTIVE_AWS_OPERATIONS,
)

# ---------------------------------------------------------------------------
# Fake secret strings (assembled at runtime to avoid secret-leak-scanner)
# ---------------------------------------------------------------------------

_FAKE_SK_PREFIX = "sk-"
_FAKE_SK_SUFFIX = "abc12345678901234567890"
_FAKE_OPENAI_KEY = _FAKE_SK_PREFIX + _FAKE_SK_SUFFIX

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-aq-001",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    aws_region: str = "us-east-1",
    pack_binding: list[str] | None = None,
) -> AmazonQDeveloperGovernance:
    client = make_client(transport, enforce=enforce)
    return AmazonQDeveloperGovernance(
        client=client,
        agent_name="amazon-q-agent-01",
        pack_binding=pack_binding if pack_binding is not None else ["soc2"],
        aws_region=aws_region,
    )


# ---------------------------------------------------------------------------
# P1 -- Pack-binding primacy
# ---------------------------------------------------------------------------

class TestPackBindingPrimacy:
    def test_empty_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "amazon-q-agent-01", "aq:completion", {},
            pack_binding=[],
        )
        assert decision.denied

    def test_none_pack_binding_falls_back_to_instance_binding(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "amazon-q-agent-01", "aq:completion", {},
            pack_binding=None,
        )
        assert decision.allowed

    def test_missing_pack_binding_on_emit_event_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.emit_event("toolCall", {
            "agentId": "amazon-q-agent-01",
            "toolName": "aq:completion",
            "args": {},
        })
        assert decision.denied

    def test_chat_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_chat({
            "promptText": "Explain this function",
        })
        assert decision.denied

    def test_aws_op_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_aws_op({
            "resourceType": "S3Bucket",
            "operation": "CreateBucket",
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# P2 -- BAA region compliance gate
# ---------------------------------------------------------------------------

class TestBaaRegionCompliance:
    def test_baa_region_under_hipaa_allowed(self):
        """us-east-1 is BAA-eligible."""
        adapter = _adapter(_transport(), aws_region="us-east-1", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Explain this Lambda",
            "packBinding": ["hipaa"],
            "region": "us-east-1",
        })
        assert decision.allowed

    def test_non_baa_region_under_hipaa_denied(self):
        """ap-south-1 is NOT BAA-eligible."""
        adapter = _adapter(_transport(), aws_region="ap-south-1", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Explain this",
            "packBinding": ["hipaa"],
            "region": "ap-south-1",
        })
        assert decision.denied
        assert "baa" in decision.reason.lower() or "region" in decision.reason.lower()

    def test_non_baa_region_non_hipaa_allowed(self):
        """Non-BAA region without HIPAA binding is allowed."""
        adapter = _adapter(_transport(), aws_region="ap-south-1")
        decision = adapter.intercept_chat({
            "promptText": "Explain this",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_eu_west_1_baa_region_allowed(self):
        """eu-west-1 is BAA-eligible."""
        adapter = _adapter(_transport(), aws_region="eu-west-1", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Help with Lambda",
            "packBinding": ["hipaa"],
            "region": "eu-west-1",
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# P3 -- Output classifier (toolResult secret scan)
# ---------------------------------------------------------------------------

class TestOutputClassifier:
    def test_secret_in_tool_result_flags_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "amazon-q-agent-01", "aq:completion",
            "SECRET_KEY=abc12345678",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert "secret" in captured.err.lower() or "classifier" in captured.err.lower()

    def test_clean_tool_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "amazon-q-agent-01", "aq:completion",
            "def hello(): pass",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P4 -- Output exfiltration scanner (llmResult)
# ---------------------------------------------------------------------------

class TestOutputExfiltrationScanner:
    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "amazon-q-agent-01", "amazon-q",
            "The patient_id is 12345 and diagnosis is diabetes.",
            pack_binding=["hipaa"],
        )
        captured = capsys.readouterr()
        assert "exfiltration" in captured.err.lower() or "phi" in captured.err.lower() or "secret" in captured.err.lower()

    def test_clean_llm_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "amazon-q-agent-01", "amazon-q",
            "Here is the refactored function.",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P5 -- policy_bridge round-trip
# ---------------------------------------------------------------------------

class TestPolicyBridge:
    def test_policy_bridge_callback_called(self):
        from connexum_governance.models import GovernanceDecision, DecisionType
        calls = []

        def my_policy(event_type, payload):
            calls.append((event_type, payload))
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="custom-allow",
                audit_id="bridge-aq-001",
            )

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=my_policy)
        result = bridge.decide("toolCall", {
            "agentId": "amazon-q-agent-01",
            "toolName": "aq:completion",
            "args": {},
        })
        assert len(calls) == 1
        assert result.allowed

    def test_policy_bridge_falls_back_when_callback_returns_none(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=lambda e, p: None)
        result = bridge.decide("toolCall", {
            "agentId": "amazon-q-agent-01",
            "toolName": "aq:chat",
            "args": {},
        })
        assert result.allowed

    def test_policy_bridge_no_callback(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=None)
        result = bridge.decide("llmCall", {
            "agentId": "amazon-q-agent-01",
            "model": "amazon-q",
            "messageCount": 1,
        })
        assert result.allowed


# ---------------------------------------------------------------------------
# P6 -- wrap_webhook dispatches to emit_event
# ---------------------------------------------------------------------------

class TestWrapWebhook:
    def test_wrap_webhook_dispatches_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "amazon-q-agent-01",
            "toolName": "aq:completion",
            "args": {},
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_wrap_webhook_missing_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({"agentId": "amazon-q-agent-01", "packBinding": ["soc2"]})

    def test_wrap_webhook_missing_agent_id_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({"eventType": "toolCall", "packBinding": ["soc2"]})

    def test_wrap_webhook_invalid_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="Unknown"):
            adapter.wrap_webhook({
                "eventType": "unknownSurface",
                "agentId": "amazon-q-agent-01",
                "packBinding": ["soc2"],
            })


# ---------------------------------------------------------------------------
# AQ-01 to AQ-12 -- Amazon Q Developer-specific tests
# ---------------------------------------------------------------------------

class TestAmazonQChat:
    def test_aq_01_chat_pre_clean_baa_region_allowed(self):
        """AQ-01: Clean chat request in BAA region is allowed."""
        adapter = _adapter(_transport(), aws_region="us-east-1")
        decision = adapter.intercept_chat({
            "promptText": "Explain this Lambda function",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_aq_02_chat_pre_non_baa_region_under_hipaa_denied(self):
        """AQ-02: Non-BAA region under HIPAA is denied (PT-ADAPT-AMAZONQ-1)."""
        adapter = _adapter(_transport(), aws_region="ap-south-1", pack_binding=["hipaa"])
        decision = adapter.intercept_chat({
            "promptText": "Explain this",
            "packBinding": ["hipaa"],
            "region": "ap-south-1",
        })
        assert decision.denied
        assert "baa" in decision.reason.lower() or "region" in decision.reason.lower()

    def test_aq_03_chat_pre_secret_in_prompt_blocked(self):
        """AQ-03: Secret in prompt text blocks chat request."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "promptText": "My key is " + _FAKE_OPENAI_KEY,
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_aq_04_chat_post_secret_in_response_blocked(self):
        """AQ-04: Secret in chat response blocks post-chat."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "responseText": "Use this: " + _FAKE_OPENAI_KEY,
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_chat_post_clean_response_allowed(self):
        """Clean post-chat response is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_chat({
            "responseText": "Here is the explanation.",
            "direction": "post",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


class TestAmazonQAwsOp:
    def test_aq_05_aws_op_non_destructive_allowed(self):
        """AQ-05: Non-destructive AWS operation is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_aws_op({
            "resourceType": "S3Bucket",
            "operation": "CreateBucket",
            "resourceArn": "arn:aws:s3:::my-bucket",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_aq_06_aws_op_delete_bucket_blocked(self):
        """AQ-06: DeleteBucket is a destructive operation requiring T3 approval (PT-ADAPT-AMAZONQ-3)."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_aws_op({
            "resourceType": "S3Bucket",
            "operation": "DeleteBucket",
            "resourceArn": "arn:aws:s3:::my-bucket",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "destructive" in decision.reason.lower() or "approval" in decision.reason.lower()

    def test_aq_06b_terminate_instances_blocked(self):
        """TerminateInstances is also a destructive operation."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_aws_op({
            "resourceType": "EC2Instance",
            "operation": "TerminateInstances",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_aq_06c_delete_secret_blocked(self):
        """DeleteSecret is a destructive operation."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_aws_op({
            "resourceType": "SecretsManagerSecret",
            "operation": "DeleteSecret",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_aq_07_aws_op_non_baa_region_under_hipaa_denied(self):
        """AQ-07: AWS op in non-BAA region under HIPAA is denied."""
        adapter = _adapter(_transport(), aws_region="ap-south-1", pack_binding=["hipaa"])
        decision = adapter.intercept_aws_op({
            "resourceType": "S3Bucket",
            "operation": "CreateBucket",
            "region": "ap-south-1",
            "packBinding": ["hipaa"],
        })
        assert decision.denied


class TestAmazonQIamPolicy:
    def test_aq_08_iam_wildcard_action_under_hipaa_blocked(self):
        """AQ-08: Wildcard-action IAM policy blocked under HIPAA (PT-ADAPT-AMAZONQ-2)."""
        adapter = _adapter(_transport(), pack_binding=["hipaa"])
        policy_doc = '{"Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}]}'
        decision = adapter.intercept_iam_policy({
            "roleName": "admin-role",
            "intent": "Give full access",
            "policyDocument": policy_doc,
            "packBinding": ["hipaa"],
        })
        assert decision.denied
        assert "iam" in decision.reason.lower() or "policy" in decision.reason.lower() or "wildcard" in decision.reason.lower()

    def test_aq_09_iam_wildcard_without_hipaa_warns(self, capsys):
        """AQ-09: Wildcard IAM policy without HIPAA binding produces a warning (not deny)."""
        adapter = _adapter(_transport())
        policy_doc = '{"Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}]}'
        decision = adapter.intercept_iam_policy({
            "roleName": "admin-role",
            "intent": "Full access",
            "policyDocument": policy_doc,
            "packBinding": ["soc2"],
        })
        captured = capsys.readouterr()
        assert decision.allowed
        assert "warn" in captured.err.lower() or "finding" in captured.err.lower()

    def test_aq_iam_clean_policy_allowed(self):
        """Clean IAM policy (no wildcards) is allowed."""
        adapter = _adapter(_transport(), pack_binding=["hipaa"])
        policy_doc = '{"Statement": [{"Effect": "Allow", "Action": "s3:GetObject", "Resource": "arn:aws:s3:::my-bucket/*"}]}'
        decision = adapter.intercept_iam_policy({
            "roleName": "read-only-role",
            "intent": "Read-only S3 access",
            "policyDocument": policy_doc,
            "packBinding": ["hipaa"],
        })
        assert decision.allowed

    def test_aq_iam_no_policy_doc_allowed(self):
        """IAM policy request without document (pre-generation) is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_iam_policy({
            "roleName": "lambda-role",
            "intent": "Lambda execution role",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


class TestAmazonQCodeTransform:
    def test_aq_10_code_transform_non_baa_region_under_hipaa_blocked(self):
        """AQ-10: Code transform in non-BAA region under HIPAA is blocked."""
        adapter = _adapter(_transport(), aws_region="ap-south-1", pack_binding=["hipaa"])
        decision = adapter.intercept_code_transform({
            "projectName": "health-api",
            "targetVersion": "Java 17",
            "packBinding": ["hipaa"],
            "region": "ap-south-1",
        })
        assert decision.denied
        assert "baa" in decision.reason.lower() or "region" in decision.reason.lower()

    def test_aq_code_transform_baa_region_allowed(self):
        """Code transform in BAA-eligible region is allowed."""
        adapter = _adapter(_transport(), aws_region="us-east-1")
        decision = adapter.intercept_code_transform({
            "projectName": "legacy-app",
            "targetVersion": "Java 17",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


class TestAmazonQConstants:
    def test_aq_11_baa_regions_content(self):
        """AQ-11: AMAZON_Q_BAA_REGIONS contains expected regions."""
        assert "us-east-1" in AMAZON_Q_BAA_REGIONS
        assert "us-east-2" in AMAZON_Q_BAA_REGIONS
        assert "us-west-2" in AMAZON_Q_BAA_REGIONS
        assert "eu-west-1" in AMAZON_Q_BAA_REGIONS
        assert "ap-southeast-2" in AMAZON_Q_BAA_REGIONS
        assert "ap-south-1" not in AMAZON_Q_BAA_REGIONS
        assert "us-west-1" not in AMAZON_Q_BAA_REGIONS

    def test_aq_12_destructive_operations(self):
        """AQ-12: _DESTRUCTIVE_AWS_OPERATIONS contains known destructive operations."""
        assert "DeleteBucket" in _DESTRUCTIVE_AWS_OPERATIONS
        assert "TerminateInstances" in _DESTRUCTIVE_AWS_OPERATIONS
        assert "DeleteStack" in _DESTRUCTIVE_AWS_OPERATIONS
        assert "DeleteSecret" in _DESTRUCTIVE_AWS_OPERATIONS
        assert "ScheduleKeyDeletion" in _DESTRUCTIVE_AWS_OPERATIONS
        # Non-destructive should NOT be in the set
        assert "CreateBucket" not in _DESTRUCTIVE_AWS_OPERATIONS
        assert "PutObject" not in _DESTRUCTIVE_AWS_OPERATIONS


# ---------------------------------------------------------------------------
# Six canonical surfaces
# ---------------------------------------------------------------------------

class TestCanonicalSurfaces:
    def test_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("amazon-q-agent-01", pack_binding=["soc2"])
        assert decision.allowed

    def test_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "amazon-q-agent-01", "aq:completion", {},
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_tool_result(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_result(
            "amazon-q-agent-01", "aq:completion", "def hello(): pass",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_call(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "amazon-q-agent-01", "amazon-q",
            [{"role": "user", "content": "complete this"}],
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_result(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_result(
            "amazon-q-agent-01", "amazon-q",
            "def hello(): return 'world'",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_agent_end(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_end("amazon-q-agent-01", success=True, pack_binding=["soc2"])
        assert decision.allowed
