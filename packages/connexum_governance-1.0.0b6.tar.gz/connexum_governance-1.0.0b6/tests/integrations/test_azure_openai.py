"""Tests for AzureOpenAIGovernance integration (B1-04).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 response classification
3. PHI ingress refusal
4. Provider compliance registration (BAA in scope for Azure)
5. Subscription gate
6. Audit chain append

Also covers Azure-specific behavior:
- content_filter_results detection
- resource_name/deployment_name forwarded to governance
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.azure_openai import (
    AzureOpenAIGovernance,
    AzureOpenAIClientProxy,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ALLOW_WITH_AUDIT = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-az-001",
}

PHI_DENY = {
    "decision": "DENY",
    "reason": "G3: PHI ingress blocked",
    "auditId": "aud-az-003",
}

CLASSIFY_CLEAN = {
    "allowed": True,
    "guardsTriggered": [],
    "auditId": "aud-az-001",
}

CLASSIFY_SECRET_LEAK = {
    "allowed": False,
    "guardsTriggered": ["G2_SECRET_LEAK"],
    "auditId": "aud-az-001",
}


def _make_transport_with_classify(action_response: dict, classify_response: dict) -> httpx.MockTransport:
    return make_transport({
        "/api/v1/governance/check-action": action_response,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/governance/classify": classify_response,
        "/api/v1/governance/provider-compliance": {"ok": True},
        "/api/v1/health": {"status": "healthy"},
    })


def _make_ag(
    transport: httpx.MockTransport,
    enforce: bool = True,
) -> AzureOpenAIGovernance:
    client = make_client(transport, enforce=enforce)
    return AzureOpenAIGovernance(
        client=client,
        agent_name="azure-agent",
        agent_role="chat",
        resource_name="my-resource",
        deployment_name="gpt-4o-deployment",
    )


def _mock_azure_client(response_dict: dict[str, Any]) -> Any:
    class MockCompletions:
        def create(self, **kwargs: Any) -> dict:
            return response_dict

    class MockChat:
        completions = MockCompletions()

    class MockAzureOpenAI:
        chat = MockChat()

    return MockAzureOpenAI()


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestAzureOpenAIHappyPath:
    def test_intercept_request_allow(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)

        decision = ag.intercept_request({
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 256,
        })
        assert decision.allowed
        assert decision.audit_id == "aud-az-001"

    def test_deployment_name_forwarded(self):
        """Deployment name sent as model in governance input."""
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        ag = _make_ag(t)
        ag.intercept_request({"messages": []})
        assert captured[0]["input"]["deploymentName"] == "gpt-4o-deployment"
        assert captured[0]["input"]["resourceName"] == "my-resource"

    def test_system_digest_extracted(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        ag = _make_ag(t)
        ag.intercept_request({
            "messages": [
                {"role": "system", "content": "You are a governance bot."},
                {"role": "user", "content": "Hello"},
            ],
        })
        assert captured[0]["input"]["systemPromptDigest"] == "You are a governance bot."

    def test_intercept_response_clean(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)

        classified = ag.intercept_response(
            response={
                "id": "chatcmpl-az-001",
                "choices": [{"message": {"role": "assistant", "content": "Hello!"}, "content_filter_results": {}}],
            },
            audit_id="aud-az-001",
        )
        assert classified.allowed


# ---------------------------------------------------------------------------
# 2. Secret leak G2
# ---------------------------------------------------------------------------

class TestAzureOpenAISecretLeak:
    def test_g2_secret_in_response(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        ag = _make_ag(transport)

        classified = ag.intercept_response(
            response={"choices": [{"message": {"content": "sk-abc-secret"}}]},
            audit_id="aud-az-001",
        )
        assert not classified.allowed
        assert "G2_SECRET_LEAK" in classified.guards_triggered

    def test_proxy_warns_on_g2(self, capsys):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        ag = _make_ag(transport)

        proxy = ag.wrap(_mock_azure_client({
            "id": "chatcmpl-az-002",
            "choices": [{"message": {"content": "sk-secret"}, "content_filter_results": {}}],
        }))
        proxy.chat.completions.create(
            messages=[{"role": "user", "content": "Hi"}],
        )
        captured = capsys.readouterr()
        assert "G-series classification" in captured.err


# ---------------------------------------------------------------------------
# 2b. Azure content filter results
# ---------------------------------------------------------------------------

class TestAzureContentFilter:
    def test_content_filter_flag_detected(self, capsys):
        """Azure content_filter_results.filtered=True triggers warning."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)

        response_with_filter = {
            "id": "chatcmpl-cf-001",
            "choices": [
                {
                    "message": {"role": "assistant", "content": "Filtered content"},
                    "content_filter_results": {
                        "hate": {"filtered": True, "severity": "medium"},
                    },
                }
            ],
        }
        classified = ag.intercept_response(
            response=response_with_filter,
            audit_id="aud-az-001",
        )
        assert classified.metadata is not None
        assert "hate" in classified.metadata.get("azureContentFilterFlags", [])


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal
# ---------------------------------------------------------------------------

class TestAzureOpenAIPhiIngress:
    def test_phi_denied_no_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        ag = _make_ag(transport, enforce=False)

        decision = ag.intercept_request({
            "messages": [{"role": "system", "content": "Patient SSN: 123-45-6789"}],
        })
        assert decision.denied

    def test_phi_raises_when_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        ag = _make_ag(transport, enforce=True)

        with pytest.raises(GovernanceViolation):
            ag.intercept_request({
                "messages": [{"role": "system", "content": "PHI record"}],
            })


# ---------------------------------------------------------------------------
# 4. Provider compliance registration
# ---------------------------------------------------------------------------

class TestAzureOpenAIProviderCompliance:
    def test_baa_in_scope_registered(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_ag(httpx.MockTransport(handler))
        assert len(registered) == 1
        assert registered[0]["provider"] == "azure_openai"
        assert registered[0]["baaAvailable"] is True
        assert registered[0]["baaScope"] == "microsoft_baa"

    def test_notes_mention_hipaa(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_ag(httpx.MockTransport(handler))
        assert "hipaa" in registered[0]["notes"].lower()


# ---------------------------------------------------------------------------
# 5. Subscription gate
# ---------------------------------------------------------------------------

class TestAzureOpenAISubscriptionGate:
    def test_subscription_revoked_blocks(self):
        sub_deny = {
            "decision": "DENY",
            "reason": "Subscription inactive",
            "auditId": "aud-sub-az",
        }
        transport = _make_transport_with_classify(sub_deny, CLASSIFY_CLEAN)
        ag = _make_ag(transport, enforce=False)

        decision = ag.intercept_request({
            "messages": [{"role": "user", "content": "Hello"}],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# 6. Audit chain append
# ---------------------------------------------------------------------------

class TestAzureOpenAIAuditChain:
    def test_report_result_closes_chain(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_CLEAN)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        ag = _make_ag(t)

        ag.intercept_response(
            response={"choices": [{"message": {"content": "OK"}, "content_filter_results": {}}]},
            audit_id="aud-az-001",
        )
        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-az-001"
        assert reported[0]["success"] is True

    def test_report_result_failure_on_blocked(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_SECRET_LEAK)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        ag = _make_ag(t)

        ag.intercept_response(
            response={"choices": [{"message": {"content": "sk-leaked"}, "content_filter_results": {}}]},
            audit_id="aud-az-001",
        )
        assert reported[0]["success"] is False


# ---------------------------------------------------------------------------
# wrap() proxy
# ---------------------------------------------------------------------------

class TestAzureOpenAIProxy:
    def test_wrap_returns_proxy(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)
        proxy = ag.wrap(_mock_azure_client({"choices": []}))
        assert isinstance(proxy, AzureOpenAIClientProxy)

    def test_proxy_denied_returns_denial_choice(self):
        deny = {"decision": "DENY", "reason": "policy block", "auditId": "aud-d"}
        transport = _make_transport_with_classify(deny, CLASSIFY_CLEAN)
        ag = _make_ag(transport, enforce=False)

        proxy = ag.wrap(_mock_azure_client({"choices": []}))
        result = proxy.chat.completions.create(
            messages=[{"role": "user", "content": "Deploy now"}],
        )
        assert result["choices"][0]["finish_reason"] == "governance_denied"
        assert "[GOVERNANCE DENIED]" in result["choices"][0]["message"]["content"]

    def test_proxy_allows_normal_response(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)

        azure_resp = {
            "id": "chatcmpl-az-ok",
            "object": "chat.completion",
            "choices": [
                {
                    "message": {"role": "assistant", "content": "Hello!"},
                    "finish_reason": "stop",
                    "content_filter_results": {},
                }
            ],
        }
        proxy = ag.wrap(_mock_azure_client(azure_resp))
        result = proxy.chat.completions.create(
            messages=[{"role": "user", "content": "Hello"}],
        )
        # Proxy returns the raw model response (dict) when allowed
        assert result["choices"][0]["message"]["content"] == "Hello!"
