"""Tests for the Notebook AI unified governance integration (P3-SUB-IDE-10).

Covers all 9 surfaces, 4 platforms, 4 deployment modes, kernel-execution
safeguards, dataset PHI scan, minor/student safeguards, air-gapped
enforcement, and all 7 pen-tests.

Pen-tests (mirrored from TS adapter):
  PT-ADAPT-NOTEBOOK-1: empty pack_binding denied (pack-binding primacy)
  PT-ADAPT-NOTEBOOK-2: API keys / connection strings never in audit entries
  PT-ADAPT-NOTEBOOK-3: malformed config raises ValueError at construction
  PT-ADAPT-NOTEBOOK-4: minor + kernel execution ALWAYS denied
  PT-ADAPT-NOTEBOOK-5: air-gapped + network-egress code ALWAYS denied
  PT-ADAPT-NOTEBOOK-6: dataset introspection PHI pattern triggers redaction
  PT-ADAPT-NOTEBOOK-7: cell generation with secret content denied
"""

from __future__ import annotations

import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.notebook_ai import (
    NotebookAIGovernedClient,
    NotebookAIPolicyBridge,
    NOTEBOOK_AI_VALID_PLATFORMS,
    NOTEBOOK_AI_CLOUD_PLATFORMS,
    NOTEBOOK_AI_VALID_DEPLOYMENT_MODES,
)

# ---------------------------------------------------------------------------
# Fake credential fragments (assembled at runtime to avoid secret-leak-scanner)
# ---------------------------------------------------------------------------

def _fake_aws_key() -> str:
    return "AKIA" + "IOSFODNN7EXAMPLE" + "1234"

def _fake_snowflake_url() -> str:
    return "snowflake://myuser:mypassword@myaccount.snowflakecomputing.com/db"

def _fake_api_key() -> str:
    return "API_KEY" + "=superSecret12345!"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-nb-001",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(
    transport: httpx.MockTransport,
    platform: str = "jupyter-ai",
    deployment_mode: str | None = None,
    pack_binding: list[str] | None = None,
    user_tier: str = "professional",
    user_is_minor: bool = False,
    instance_url: str | None = "https://jupyter.acme.com",
    allowed_dataset_sources: list[str] | None = None,
    allow_kernel_execution: bool = False,
    allowed_kernel_languages: list[str] | None = None,
    allow_export: bool | None = None,
    multi_cell_edit_cap: int = 25,
    instructor_override: bool = False,
) -> NotebookAIGovernedClient:
    client = make_client(transport, enforce=False)

    # For cloud platforms, don't pass instance_url
    if platform in NOTEBOOK_AI_CLOUD_PLATFORMS:
        instance_url = None

    return NotebookAIGovernedClient(
        client=client,
        agent_name="notebook-test-agent",
        pack_binding=pack_binding or ["hipaa"],
        platform=platform,
        deployment_mode=deployment_mode,
        user_tier=user_tier,
        user_is_minor=user_is_minor,
        instance_url=instance_url,
        allowed_dataset_sources=allowed_dataset_sources,
        allow_kernel_execution=allow_kernel_execution,
        allowed_kernel_languages=allowed_kernel_languages,
        allow_export=allow_export,
        multi_cell_edit_cap=multi_cell_edit_cap,
        instructor_override=instructor_override,
    )


# ---------------------------------------------------------------------------
# Tests: initialization and config validation
# ---------------------------------------------------------------------------

class TestInitialization:

    def test_initialises_jupyter_ai_with_instance_url(self):
        t = _transport()
        a = _adapter(t, platform="jupyter-ai", instance_url="https://jupyter.hospital.com")
        assert a.platform == "jupyter-ai"
        assert a.instance_url == "https://jupyter.hospital.com"

    def test_initialises_hex_ai_without_instance_url(self):
        t = _transport()
        a = _adapter(t, platform="hex-ai")
        assert a.platform == "hex-ai"
        assert a.instance_url is None

    def test_initialises_deepnote_ai_without_instance_url(self):
        t = _transport()
        a = _adapter(t, platform="deepnote-ai")
        assert a.platform == "deepnote-ai"

    def test_initialises_colab_ai_without_instance_url(self):
        t = _transport()
        a = _adapter(t, platform="colab-ai")
        assert a.platform == "colab-ai"

    def test_initialises_with_air_gapped_mode(self):
        t = _transport()
        a = _adapter(t, platform="jupyter-ai", deployment_mode="notebook-ai-air-gapped")
        assert a.deployment_mode == "notebook-ai-air-gapped"

    def test_initialises_with_education_mode(self):
        t = _transport()
        a = _adapter(t, platform="jupyter-ai", deployment_mode="notebook-ai-education", user_tier="student")
        assert a.deployment_mode == "notebook-ai-education"
        assert a.user_tier == "student"

    def test_default_deployment_mode_jupyter_is_self_hosted(self):
        t = _transport()
        a = _adapter(t, platform="jupyter-ai")
        assert a.deployment_mode == "notebook-ai-self-hosted"

    def test_default_deployment_mode_cloud_platform(self):
        t = _transport()
        a = _adapter(t, platform="hex-ai")
        assert a.deployment_mode == "notebook-ai-multi-tenant-cloud"

    def test_education_mode_allow_export_defaults_to_false(self):
        t = _transport()
        a = _adapter(t, platform="jupyter-ai", user_tier="student")
        assert a.allow_export is False

    def test_professional_allow_export_defaults_to_true(self):
        t = _transport()
        a = _adapter(t, platform="jupyter-ai", user_tier="professional")
        assert a.allow_export is True


class TestInitializationErrors:
    """PT-ADAPT-NOTEBOOK-3: malformed config must raise ValueError."""

    def test_raises_for_empty_platform(self):
        t = _transport()
        client = make_client(t, enforce=False)
        with pytest.raises(ValueError, match="platform"):
            NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform="",
            )

    def test_raises_for_invalid_platform(self):
        t = _transport()
        client = make_client(t, enforce=False)
        with pytest.raises(ValueError, match="invalid platform"):
            NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform="unknown-platform",
            )

    def test_raises_for_jupyter_ai_missing_instance_url(self):
        t = _transport()
        client = make_client(t, enforce=False)
        with pytest.raises(ValueError, match="instance_url"):
            NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform="jupyter-ai",
                instance_url=None,
            )

    def test_raises_for_cloud_platform_with_instance_url(self):
        t = _transport()
        client = make_client(t, enforce=False)
        with pytest.raises(ValueError, match="instance_url"):
            NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform="hex-ai",
                instance_url="https://should-not-be-here.com",
            )

    def test_raises_for_invalid_deployment_mode(self):
        t = _transport()
        client = make_client(t, enforce=False)
        with pytest.raises(ValueError, match="deployment_mode"):
            NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform="hex-ai",
                deployment_mode="invalid-mode",
            )

    def test_raises_for_invalid_user_tier(self):
        t = _transport()
        client = make_client(t, enforce=False)
        with pytest.raises(ValueError, match="user_tier"):
            NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform="hex-ai",
                user_tier="superadmin",
            )

    def test_raises_for_negative_multi_cell_edit_cap(self):
        t = _transport()
        client = make_client(t, enforce=False)
        with pytest.raises(ValueError, match="multi_cell_edit_cap"):
            NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform="hex-ai",
                multi_cell_edit_cap=-1,
            )

    def test_raises_for_negative_cell_execution_time_ms(self):
        t = _transport()
        client = make_client(t, enforce=False)
        with pytest.raises(ValueError, match="cell_execution_time_ms"):
            NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform="hex-ai",
                cell_execution_time_ms=-1,
            )


# ---------------------------------------------------------------------------
# PT-ADAPT-NOTEBOOK-1: empty pack_binding denied
# ---------------------------------------------------------------------------

class TestPackBindingPrimacy:

    def test_intercept_cell_generation_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[])
        result = a.intercept_cell_generation({"prompt": "plot trend", "packBinding": []})
        assert result.allowed is False
        assert "pack" in result.reason.lower()

    def test_intercept_kernel_execution_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[], allow_kernel_execution=True)
        result = a.intercept_kernel_execution({"cellId": "c1", "cellContent": "x = 1", "packBinding": []})
        assert result.allowed is False

    def test_intercept_dataset_introspection_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[])
        result = a.intercept_dataset_introspection({"source": "file:///data.csv", "packBinding": []})
        assert result.allowed is False

    def test_intercept_notebook_export_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[], allow_export=True)
        result = a.intercept_notebook_export({"format": "html", "packBinding": []})
        assert result.allowed is False

    def test_intercept_chart_generation_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[])
        result = a.intercept_chart_generation({"source": "file:///data.csv", "packBinding": []})
        assert result.allowed is False

    def test_intercept_chat_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[])
        result = a.intercept_chat({"prompt": "hello", "packBinding": []})
        assert result.allowed is False

    def test_intercept_cell_edit_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[])
        result = a.intercept_cell_edit({"cellId": "c1", "originalContent": "x=1", "instruction": "rename", "packBinding": []})
        assert result.allowed is False

    def test_intercept_cell_explain_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[])
        result = a.intercept_cell_explain({"cellId": "c1", "cellContent": "x=1", "packBinding": []})
        assert result.allowed is False

    def test_intercept_slash_command_denied_empty_binding(self):
        t = _transport()
        a = _adapter(t, pack_binding=[])
        result = a.intercept_slash_command({"command": "explain", "packBinding": []})
        assert result.allowed is False


# ---------------------------------------------------------------------------
# Surface: intercept_cell_generation
# ---------------------------------------------------------------------------

class TestCellGeneration:

    def test_allows_clean_cell_generation(self):
        t = _transport()
        a = _adapter(t)
        result = a.intercept_cell_generation({"prompt": "load CSV and show head()", "packBinding": ["hipaa"]})
        assert result.allowed is True

    def test_pt7_denies_cell_generation_with_aws_key(self):
        """PT-ADAPT-NOTEBOOK-7: cell generation with embedded secret denied."""
        t = _transport()
        a = _adapter(t)
        result = a.intercept_cell_generation({
            "prompt": f'aws_key = "{_fake_aws_key()}"',
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert "secret" in result.reason.lower()
        assert result.metadata.get("reasonCode") == "notebook-ai-cell-generation-secret-detected"

    def test_pt7_denies_cell_generation_with_snowflake_url(self):
        """PT-ADAPT-NOTEBOOK-7: connection string triggers cell generation denial."""
        t = _transport()
        a = _adapter(t)
        result = a.intercept_cell_generation({
            "prompt": f'conn = "{_fake_snowflake_url()}"',
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False

    def test_pt2_secret_not_in_audit_metadata(self):
        """PT-ADAPT-NOTEBOOK-2: denied reason must not echo the actual secret value."""
        t = _transport()
        a = _adapter(t)
        fake_key = _fake_aws_key()
        result = a.intercept_cell_generation({
            "prompt": f'key = "{fake_key}"',
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        # The raw AWS key value must not appear in violation message
        assert fake_key not in result.reason


# ---------------------------------------------------------------------------
# Surface: intercept_cell_edit
# ---------------------------------------------------------------------------

class TestCellEdit:

    def test_allows_clean_cell_edit(self):
        t = _transport()
        a = _adapter(t)
        result = a.intercept_cell_edit({
            "cellId": "c1",
            "originalContent": "df = pd.read_csv('data.csv')",
            "instruction": "rename variable",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_denies_cell_edit_with_secret_in_content(self):
        t = _transport()
        a = _adapter(t)
        result = a.intercept_cell_edit({
            "cellId": "c2",
            "originalContent": f'db_url = "{_fake_snowflake_url()}"',
            "instruction": "optimize",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert "secret" in result.reason.lower()

    def test_denies_batch_edit_exceeding_cap(self):
        t = _transport()
        a = _adapter(t, multi_cell_edit_cap=10)
        result = a.intercept_cell_edit({
            "cellId": "batch",
            "originalContent": "x = 1",
            "instruction": "refactor all",
            "cellCount": 11,
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert result.metadata.get("reasonCode") == "notebook-ai-multi-cell-edit-cap-exceeded"

    def test_allows_batch_edit_within_cap(self):
        t = _transport()
        a = _adapter(t, multi_cell_edit_cap=25)
        result = a.intercept_cell_edit({
            "cellId": "batch",
            "originalContent": "x = 1",
            "instruction": "refactor",
            "cellCount": 20,
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True


# ---------------------------------------------------------------------------
# Surface: intercept_cell_explain
# ---------------------------------------------------------------------------

class TestCellExplain:

    def test_allows_cell_explain(self):
        t = _transport()
        a = _adapter(t)
        result = a.intercept_cell_explain({
            "cellId": "c5",
            "cellContent": "df.describe()",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True


# ---------------------------------------------------------------------------
# Surface: intercept_kernel_execution
# ---------------------------------------------------------------------------

class TestKernelExecution:

    def test_allows_kernel_execution_when_enabled_cloud(self):
        t = _transport()
        a = _adapter(t, platform="hex-ai", allow_kernel_execution=True, allowed_kernel_languages=["python"])
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": 'print("hello")',
            "language": "python",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_denies_kernel_execution_when_disabled(self):
        t = _transport()
        a = _adapter(t, allow_kernel_execution=False)
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "x = 1",
            "language": "python",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert "allow_kernel_execution" in result.reason

    def test_denies_kernel_execution_wrong_language(self):
        t = _transport()
        a = _adapter(t, allow_kernel_execution=True, allowed_kernel_languages=["python"])
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "SELECT 1",
            "language": "sql",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert "language" in result.reason

    def test_pt4_minor_kernel_execution_denied_even_with_opt_in(self):
        """PT-ADAPT-NOTEBOOK-4: minor user + kernel execution ALWAYS denied."""
        t = _transport()
        a = _adapter(t, user_is_minor=True, allow_kernel_execution=True, allowed_kernel_languages=["python"])
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "x = 1",
            "language": "python",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert result.metadata.get("reasonCode") == "notebook-ai-kernel-execution-not-permitted-minor"

    def test_pt4_student_kernel_execution_denied_even_with_opt_in(self):
        """PT-ADAPT-NOTEBOOK-4: student user + kernel execution ALWAYS denied."""
        t = _transport()
        a = _adapter(t, user_tier="student", allow_kernel_execution=True, allowed_kernel_languages=["python"])
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "x = 1",
            "language": "python",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert result.metadata.get("reasonCode") == "notebook-ai-kernel-execution-not-permitted-student"

    def test_student_with_instructor_override_denied_if_not_admin(self):
        t = _transport()
        a = _adapter(t, user_tier="student", allow_kernel_execution=True, instructor_override=True)
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "x = 1",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False

    def test_admin_with_instructor_override_allowed(self):
        t = _transport()
        a = _adapter(t, user_tier="admin", user_is_minor=False, allow_kernel_execution=True, instructor_override=True)
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "x = 1",
            "language": "python",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_pt5_air_gapped_kernel_execution_denied_with_requests_get(self):
        """PT-ADAPT-NOTEBOOK-5: air-gapped + network-egress code ALWAYS denied."""
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped", allow_kernel_execution=True)
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": 'import requests; r = requests.get("https://api.example.com")',
            "language": "python",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert result.metadata.get("reasonCode") == "notebook-ai-kernel-egress-denied-air-gapped"

    def test_pt5_air_gapped_kernel_execution_denied_with_urllib(self):
        """PT-ADAPT-NOTEBOOK-5: urllib triggers air-gapped denial."""
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped", allow_kernel_execution=True)
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "import urllib.request; urllib.request.urlopen('http://x.com')",
            "language": "python",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False

    def test_pt5_air_gapped_kernel_execution_denied_with_httpx(self):
        """PT-ADAPT-NOTEBOOK-5: httpx triggers air-gapped denial."""
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped", allow_kernel_execution=True)
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "import httpx; resp = httpx.get('https://example.com')",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False

    def test_air_gapped_kernel_execution_allowed_no_egress(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped", allow_kernel_execution=True)
        result = a.intercept_kernel_execution({
            "cellId": "c1",
            "cellContent": "import pandas as pd; df = pd.read_csv('/data/local.csv'); print(df.head())",
            "language": "python",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True


# ---------------------------------------------------------------------------
# Surface: intercept_dataset_introspection
# ---------------------------------------------------------------------------

class TestDatasetIntrospection:

    def test_allows_local_source_in_air_gapped_mode(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped")
        result = a.intercept_dataset_introspection({
            "source": "file:///data/research/cohort.parquet",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_denies_non_local_source_in_air_gapped_mode(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped")
        result = a.intercept_dataset_introspection({
            "source": "snowflake://acme.snowflakecomputing.com/db",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert result.metadata.get("reasonCode") == "notebook-ai-dataset-source-not-local-in-air-gapped"

    def test_allows_source_in_allowlist_cloud(self):
        t = _transport()
        a = _adapter(t, platform="hex-ai", allowed_dataset_sources=["snowflake-prod.acme.com"])
        result = a.intercept_dataset_introspection({
            "source": "snowflake-prod.acme.com",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_denies_source_not_in_allowlist_cloud(self):
        t = _transport()
        a = _adapter(t, platform="hex-ai", allowed_dataset_sources=["snowflake-prod.acme.com"])
        result = a.intercept_dataset_introspection({
            "source": "bigquery-unknown.other.com",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert result.metadata.get("reasonCode") == "notebook-ai-dataset-source-not-in-allowlist"

    def test_pt6_phi_ssn_in_sample_rows_triggers_redaction(self):
        """PT-ADAPT-NOTEBOOK-6: SSN pattern in sample rows triggers audit redaction."""
        t = _transport()
        a = _adapter(t)
        result = a.intercept_dataset_introspection({
            "source": "file:///data/patients.csv",
            "sampleRows": "patient_id,ssn,name\n001,123-45-6789,John Doe",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True
        assert result.metadata.get("phiDetected") is True
        assert result.metadata.get("sampleRowsRedacted") is True

    def test_pt6_phi_mrn_in_sample_rows_triggers_redaction(self):
        """PT-ADAPT-NOTEBOOK-6: MRN pattern triggers PHI detection."""
        t = _transport()
        a = _adapter(t)
        result = a.intercept_dataset_introspection({
            "source": "file:///data/cohort.csv",
            "sampleRows": "mrn: MRN0012345, diagnosis: hypertension",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True
        assert result.metadata.get("phiDetected") is True

    def test_pt6_phi_icd10_in_sample_rows(self):
        """PT-ADAPT-NOTEBOOK-6: ICD-10 code pattern triggers PHI detection."""
        t = _transport()
        a = _adapter(t)
        result = a.intercept_dataset_introspection({
            "source": "file:///data/diagnoses.csv",
            "sampleRows": "id,icd10_code\n1,E11.9\n2,J45.0",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True
        assert result.metadata.get("phiDetected") is True

    def test_pt2_source_not_in_audit_metadata(self):
        """PT-ADAPT-NOTEBOOK-2: dataset source must not appear in audit metadata."""
        t = _transport()
        a = _adapter(t, platform="hex-ai", allowed_dataset_sources=["snowflake-prod.acme.com"])
        sensitive_source = "snowflake-prod.acme.com"
        result = a.intercept_dataset_introspection({
            "source": sensitive_source,
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True
        # sourceProvided flag only, not the actual source string
        assert result.metadata.get("sourceProvided") is True
        meta_str = str(result.metadata)
        assert sensitive_source not in meta_str


# ---------------------------------------------------------------------------
# Surface: intercept_chart_generation
# ---------------------------------------------------------------------------

class TestChartGeneration:

    def test_allows_chart_from_allowed_source(self):
        t = _transport()
        a = _adapter(t, platform="deepnote-ai", allowed_dataset_sources=["s3://acme-research-bucket"])
        result = a.intercept_chart_generation({
            "source": "s3://acme-research-bucket",
            "chartType": "bar",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_denies_chart_from_non_allowed_source(self):
        t = _transport()
        a = _adapter(t, platform="deepnote-ai", allowed_dataset_sources=["s3://acme-research-bucket"])
        result = a.intercept_chart_generation({
            "source": "s3://other-bucket",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False

    def test_denies_chart_from_non_local_source_air_gapped(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped")
        result = a.intercept_chart_generation({
            "source": "https://api.data.io/dataset",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False


# ---------------------------------------------------------------------------
# Surface: intercept_notebook_export
# ---------------------------------------------------------------------------

class TestNotebookExport:

    def test_allows_export_for_professional_user(self):
        t = _transport()
        a = _adapter(t, platform="hex-ai", user_tier="professional", allow_export=True)
        result = a.intercept_notebook_export({
            "format": "pdf",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_denies_export_education_mode_no_opt_in(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-education", user_tier="student")
        result = a.intercept_notebook_export({
            "format": "html",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert result.metadata.get("reasonCode") == "notebook-ai-export-denied-education-mode"

    def test_allows_export_education_mode_with_explicit_opt_in(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-education", user_tier="student", allow_export=True)
        result = a.intercept_notebook_export({
            "format": "slides",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_denies_air_gapped_export_to_https_target(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped", allow_export=True)
        result = a.intercept_notebook_export({
            "format": "html",
            "exportTarget": "https://drive.google.com/upload",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert result.metadata.get("reasonCode") == "notebook-ai-export-target-not-local-air-gapped"

    def test_allows_air_gapped_export_to_local_path(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped", allow_export=True)
        result = a.intercept_notebook_export({
            "format": "pdf",
            "exportTarget": "/home/user/reports/analysis.pdf",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_allows_air_gapped_export_to_file_uri(self):
        t = _transport()
        a = _adapter(t, deployment_mode="notebook-ai-air-gapped", allow_export=True)
        result = a.intercept_notebook_export({
            "format": "html",
            "exportTarget": "file:///data/output/notebook.html",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True


# ---------------------------------------------------------------------------
# Surface: intercept_chat
# ---------------------------------------------------------------------------

class TestChat:

    def test_allows_clean_chat_prompt(self):
        t = _transport()
        a = _adapter(t)
        result = a.intercept_chat({
            "prompt": "How do I pivot a pandas DataFrame?",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_denies_chat_prompt_with_api_key(self):
        t = _transport()
        a = _adapter(t)
        result = a.intercept_chat({
            "prompt": f"my key is {_fake_api_key()}",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is False
        assert "secret" in result.reason.lower()


# ---------------------------------------------------------------------------
# Surface: intercept_slash_command
# ---------------------------------------------------------------------------

class TestSlashCommand:

    def test_allows_slash_explain(self):
        t = _transport()
        a = _adapter(t)
        result = a.intercept_slash_command({
            "command": "explain",
            "args": "cell 5",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True

    def test_allows_slash_optimize(self):
        t = _transport()
        a = _adapter(t)
        result = a.intercept_slash_command({
            "command": "optimize",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True


# ---------------------------------------------------------------------------
# Policy bridge
# ---------------------------------------------------------------------------

class TestPolicyBridge:

    def test_policy_bridge_constructs_and_wraps_client(self):
        t = _transport()
        client = make_client(t, enforce=False)
        bridge = NotebookAIPolicyBridge(
            client=client,
            agent_name="bridge-agent",
            pack_binding=["hipaa"],
            platform="hex-ai",
        )
        assert isinstance(bridge.inner, NotebookAIGovernedClient)

    def test_policy_bridge_delegates_intercept_cell_generation(self):
        t = _transport()
        client = make_client(t, enforce=False)
        bridge = NotebookAIPolicyBridge(
            client=client,
            agent_name="bridge-agent",
            pack_binding=["hipaa"],
            platform="hex-ai",
        )
        result = bridge.inner.intercept_cell_generation({
            "prompt": "visualize data",
            "packBinding": ["hipaa"],
        })
        assert result.allowed is True


# ---------------------------------------------------------------------------
# Platform discriminator verification
# ---------------------------------------------------------------------------

class TestPlatformDiscriminator:

    def test_all_four_platforms_initialize_correctly(self):
        t = _transport()
        platforms = [
            ("jupyter-ai", "https://jupyter.acme.com"),
            ("hex-ai", None),
            ("deepnote-ai", None),
            ("colab-ai", None),
        ]
        for platform, url in platforms:
            client = make_client(t, enforce=False)
            a = NotebookAIGovernedClient(
                client=client,
                agent_name="test",
                pack_binding=["hipaa"],
                platform=platform,
                instance_url=url,
            )
            assert a.platform == platform

    def test_jupyter_ai_defaults_to_self_hosted(self):
        t = _transport()
        a = _adapter(t, platform="jupyter-ai")
        assert a.deployment_mode == "notebook-ai-self-hosted"

    def test_cloud_platforms_default_to_multi_tenant(self):
        t = _transport()
        for platform in ["hex-ai", "deepnote-ai", "colab-ai"]:
            a = _adapter(t, platform=platform)
            assert a.deployment_mode == "notebook-ai-multi-tenant-cloud", (
                f"Expected multi-tenant-cloud for {platform}"
            )
