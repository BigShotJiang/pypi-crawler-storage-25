"""Tests for OpenClaw governance integration (B2-10).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 -- PHI in tool result flags output classifier
3. PHI ingress refusal -- exfiltration scan on tool args
4. Provider compliance -- unapproved model blocked at llmCall event
5. Subscription gate -- empty pack binding denied
6. Audit chain append -- each hook produces canonical event

OpenClaw-specific additional tests:
  - Memory write PHI blocking under HIPAA (PT-ADAPT-OPENCLAW-1)
  - Unsanctioned workspace blocking (PT-ADAPT-OPENCLAW-2)
  - Cross-session memory read pseudonymisation (PT-ADAPT-OPENCLAW-3)
  - wrap_webhook validates required fields
  - policy_bridge routes to callback
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.openclaw import (
    OpenClawGovernance,
    OpenClawMemoryPhiError,
    OpenClawUnsanctionedWorkspaceError,
    OpenClawPolicyBridge,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-oc-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-oc-002"}

_APPROVED_MODELS = ["gpt-4o-mini", "claude-haiku-4-5"]


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    sanctioned_workspaces: dict | None = None,
    approved_models: list[str] | None = None,
) -> OpenClawGovernance:
    client = make_client(transport, enforce=enforce)
    return OpenClawGovernance(
        client=client,
        registered_agents=["oc-agent-01"],
        approved_models=approved_models if approved_models is not None else _APPROVED_MODELS,
        sensitive_tools=["exec_code"],
        sensitive_arg_keys=["query", "content"],
        sanctioned_workspaces=sanctioned_workspaces or {"Slack": {"T-ALLOWED-WS"}},
        block_phi_memory_write=True,
        pseudonymise_cross_session_reads=True,
        pseudonymisation_key="test-pseudo-key-abc123",
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestOpenClawHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            "oc-agent-01", pack_binding=["hipaa"], model="gpt-4o-mini", platform="Slack"
        )
        assert decision.allowed

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "oc-agent-01", "web_search", {"query": "governance"}, pack_binding=["hipaa"]
        )
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_call("oc-agent-01", "search", {"query": "docs"}, pack_binding=["hipaa"])
        adapter.tool_result("oc-agent-01", "search", "Clean results", pack_binding=["hipaa"])
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "oc-agent-01", "gpt-4o-mini", [], pack_binding=["hipaa"]
        )
        assert decision.allowed

    def test_llm_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_call("oc-agent-01", "gpt-4o-mini", [], pack_binding=["hipaa"])
        adapter.llm_result("oc-agent-01", "gpt-4o-mini", "Clean response.", pack_binding=["hipaa"])
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_end("oc-agent-01", success=True)
        assert decision.allowed

    def test_full_event_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("oc-agent-01", pack_binding=["hipaa"], model="gpt-4o-mini")
        adapter.tool_call("oc-agent-01", "search", {"query": "news"}, pack_binding=["hipaa"])
        adapter.tool_result("oc-agent-01", "search", "results", pack_binding=["hipaa"])
        adapter.llm_call("oc-agent-01", "gpt-4o-mini", [], pack_binding=["hipaa"])
        adapter.llm_result("oc-agent-01", "gpt-4o-mini", "response", pack_binding=["hipaa"])
        adapter.agent_end("oc-agent-01", success=True)


# ---------------------------------------------------------------------------
# 2. Secret leak / PHI in tool result
# ---------------------------------------------------------------------------

class TestOpenClawSecretLeak:
    def test_phi_in_tool_result_flags_output_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "oc-agent-01", "db_query",
            "patient_id=12345, ssn=123-45-6789",
            pack_binding=["soc2"]
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_call("oc-agent-01", "gpt-4o-mini", [], pack_binding=["hipaa"])
        adapter.llm_result(
            "oc-agent-01", "gpt-4o-mini",
            "Patient dob: 1980-01-15 processed.",
            pack_binding=["hipaa"]
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- exfiltration scan on tool args
# ---------------------------------------------------------------------------

class TestOpenClawPhiIngress:
    def test_phi_in_content_arg_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "oc-agent-01",
            "send_message",
            {"content": "Patient SSN: 123-45-6789"},
            pack_binding=["soc2"],
        )
        assert decision.denied

    def test_phi_in_query_arg_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "oc-agent-01",
            "search",
            {"query": "ssn=123-45-6789"},
            pack_binding=["hipaa"],
        )
        assert decision.denied

    def test_clean_args_pass(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "oc-agent-01",
            "search",
            {"query": "AI governance"},
            pack_binding=["hipaa"],
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved model blocked
# ---------------------------------------------------------------------------

class TestOpenClawProviderCompliance:
    def test_unapproved_model_denied_at_llm_call(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "oc-agent-01", "unapproved-model-xyz", [],
            pack_binding=["hipaa"]
        )
        assert decision.denied

    def test_approved_model_passes(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "oc-agent-01", "claude-haiku-4-5", [],
            pack_binding=["hipaa"]
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 5. Subscription gate -- empty pack binding denied
# ---------------------------------------------------------------------------

class TestOpenClawSubscriptionGate:
    def test_missing_pack_binding_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            "oc-agent-01", pack_binding=[], model="gpt-4o-mini"
        )
        assert decision.denied

    def test_missing_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call("oc-agent-01", "search", {"query": "test"}, pack_binding=[])
        assert decision.denied

    def test_unknown_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="Unknown OpenClaw event type"):
            adapter.emit_event("unknownEvent", {"agentId": "oc-agent-01", "packBinding": ["hipaa"]})

    def test_wrap_webhook_missing_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({"agentId": "oc-agent-01"})

    def test_wrap_webhook_missing_agent_id_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({"eventType": "agentStart"})


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip
# ---------------------------------------------------------------------------

class TestOpenClawAuditChain:
    def test_tool_call_and_result_audit_round_trip(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.tool_call("oc-agent-01", "search", {"query": "docs"}, pack_binding=["hipaa"])
        adapter.tool_result("oc-agent-01", "search", "results", pack_binding=["hipaa"])
        assert len(reported) >= 1

    def test_emit_event_forwards_to_governance_api(self):
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.emit_event("agentStart", {
            "agentId": "oc-agent-01",
            "packBinding": ["hipaa"],
            "model": "gpt-4o-mini",
            "platform": "Slack",
        })
        assert any("check-action" in c for c in calls)

    def test_wrap_webhook_forwards_valid_payload(self):
        calls: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append({"path": request.url.path})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "oc-agent-01",
            "toolName": "search",
            "args": {},
            "packBinding": ["hipaa"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# OpenClaw-specific: memory PHI gating (PT-ADAPT-OPENCLAW-1)
# ---------------------------------------------------------------------------

class TestOpenClawMemoryPhiGating:
    def test_memory_write_with_phi_under_hipaa_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(OpenClawMemoryPhiError):
            adapter.emit_event("memoryWrite", {
                "agentId": "oc-agent-01",
                "key": "patient_data",
                "value": "ssn=123-45-6789 patient_id=ABC",
                "packBinding": ["hipaa"],
            })

    def test_memory_write_clean_value_allowed(self):
        adapter = _adapter(_transport())
        decision = adapter.emit_event("memoryWrite", {
            "agentId": "oc-agent-01",
            "key": "session_context",
            "value": "User prefers dark mode",
            "packBinding": ["hipaa"],
        })
        assert decision.allowed

    def test_memory_write_phi_without_hipaa_warns_not_blocks(self, capsys):
        adapter = _adapter(_transport())
        decision = adapter.emit_event("memoryWrite", {
            "agentId": "oc-agent-01",
            "key": "some_key",
            "value": "ssn=123-45-6789",
            "packBinding": ["soc2"],  # no HIPAA binding
        })
        # Should not raise, should warn
        assert decision.allowed
        captured = capsys.readouterr()
        assert "PHI" in captured.err


# ---------------------------------------------------------------------------
# OpenClaw-specific: workspace sanctioning (PT-ADAPT-OPENCLAW-2)
# ---------------------------------------------------------------------------

class TestOpenClawWorkspaceSanctioning:
    def test_unsanctioned_slack_workspace_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(OpenClawUnsanctionedWorkspaceError):
            adapter.emit_event("outboundMessage", {
                "agentId": "oc-agent-01",
                "platform": "Slack",
                "workspaceId": "T-UNSANCTIONED-WS",
                "recipientId": "T-UNSANCTIONED-WS",
                "content": "Hello team",
                "packBinding": ["soc2"],
            })

    def test_sanctioned_slack_workspace_allowed(self):
        adapter = _adapter(_transport())
        decision = adapter.emit_event("outboundMessage", {
            "agentId": "oc-agent-01",
            "platform": "Slack",
            "workspaceId": "T-ALLOWED-WS",
            "recipientId": "T-ALLOWED-WS",
            "content": "Hello team",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_outbound_message_with_phi_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.emit_event("outboundMessage", {
            "agentId": "oc-agent-01",
            "platform": "Slack",
            "workspaceId": "T-ALLOWED-WS",
            "recipientId": "T-ALLOWED-WS",
            "content": "Patient SSN is 123-45-6789",
            "packBinding": ["hipaa"],
        })
        assert decision.denied

    def test_platform_not_in_sanctioned_workspaces_allowed(self):
        adapter = _adapter(_transport(), sanctioned_workspaces={})
        decision = adapter.emit_event("outboundMessage", {
            "agentId": "oc-agent-01",
            "platform": "Discord",
            "workspaceId": "any-discord-server",
            "recipientId": "any-discord-server",
            "content": "Hello",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# OpenClaw-specific: cross-session pseudonymisation (PT-ADAPT-OPENCLAW-3)
# ---------------------------------------------------------------------------

class TestOpenClawCrossSessionPseudonymisation:
    def test_cross_session_read_under_regulated_pack_pseudonymises_key(self):
        payloads_sent: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                payloads_sent.append(json.loads(request.content))
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.emit_event("memoryRead", {
            "agentId": "oc-agent-01",
            "key": "real_patient_id_ABC",
            "sessionId": "other-session-id",  # cross-session
            "packBinding": ["hipaa"],
        })

        # The key in the forwarded payload should be pseudonymised, not the original
        assert len(payloads_sent) >= 1
        forwarded_key = payloads_sent[0].get("input", {}).get("key", "")
        assert forwarded_key != "real_patient_id_ABC"

    def test_policy_bridge_callback_intercepts_decision(self):
        called: list[dict] = []

        def callback(event_type: str, payload: dict) -> Any:
            called.append({"event_type": event_type})
            from connexum_governance.models import GovernanceDecision, DecisionType
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="Python policy allowed",
                audit_id="py-oc-001",
            )

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(["hipaa"], callback)
        decision = bridge.decide("agentStart", {"agentId": "oc-agent-01"})
        assert decision.allowed
        assert called[0]["event_type"] == "agentStart"
