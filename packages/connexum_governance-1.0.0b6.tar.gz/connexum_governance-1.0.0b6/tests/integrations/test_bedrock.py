"""Tests for BedrockGovernance integration (B1-05).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 response classification
3. PHI ingress refusal
4. Provider compliance registration (BAA in scope for AWS Bedrock)
5. Subscription gate
6. Audit chain append

Also covers Bedrock-specific behavior:
- Model family detection from model ID prefix
- Region forwarded to governance
- Converse API and InvokeModel support
- Tool names from toolConfig.tools[].toolSpec
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.bedrock import (
    BedrockGovernance,
    BedrockClientProxy,
    _detect_model_family,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ALLOW_WITH_AUDIT = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-bdr-001",
}

PHI_DENY = {
    "decision": "DENY",
    "reason": "G3: PHI ingress blocked",
    "auditId": "aud-bdr-003",
}

CLASSIFY_CLEAN = {
    "allowed": True,
    "guardsTriggered": [],
    "auditId": "aud-bdr-001",
}

CLASSIFY_SECRET_LEAK = {
    "allowed": False,
    "guardsTriggered": ["G2_SECRET_LEAK"],
    "auditId": "aud-bdr-001",
}


def _make_transport_with_classify(action_response: dict, classify_response: dict) -> httpx.MockTransport:
    return make_transport({
        "/api/v1/governance/check-action": action_response,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/governance/classify": classify_response,
        "/api/v1/governance/provider-compliance": {"ok": True},
        "/api/v1/health": {"status": "healthy"},
    })


def _make_bg(transport: httpx.MockTransport, enforce: bool = True) -> BedrockGovernance:
    client = make_client(transport, enforce=enforce)
    return BedrockGovernance(
        client=client,
        agent_name="bedrock-agent",
        agent_role="inference",
        region="us-east-1",
    )


def _mock_bedrock_client(response_dict: dict[str, Any]) -> Any:
    class MockBedrockRuntime:
        def converse(self, **kwargs: Any) -> dict:
            return response_dict

        def invoke_model(self, **kwargs: Any) -> dict:
            return response_dict

    return MockBedrockRuntime()


# ---------------------------------------------------------------------------
# Model family detection
# ---------------------------------------------------------------------------

class TestModelFamilyDetection:
    def test_anthropic_prefix(self):
        assert _detect_model_family("anthropic.claude-3-haiku-20240307-v1:0") == "claude"

    def test_amazon_prefix(self):
        assert _detect_model_family("amazon.titan-text-express-v1") == "titan"

    def test_meta_prefix(self):
        assert _detect_model_family("meta.llama3-8b-instruct-v1:0") == "llama"

    def test_mistral_prefix(self):
        assert _detect_model_family("mistral.mistral-7b-instruct-v0:2") == "mistral"

    def test_unknown_prefix(self):
        assert _detect_model_family("custom.unknown-model") == "unknown"


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestBedrockHappyPath:
    def test_intercept_request_allow(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        bg = _make_bg(transport)

        decision = bg.intercept_request({
            "modelId": "anthropic.claude-3-haiku-20240307-v1:0",
            "messages": [{"role": "user", "content": [{"text": "Hello"}]}],
        })
        assert decision.allowed
        assert decision.audit_id == "aud-bdr-001"

    def test_model_family_and_region_forwarded(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        bg = _make_bg(t)
        bg.intercept_request({
            "modelId": "anthropic.claude-3-sonnet-20240229-v1:0",
            "messages": [],
        })
        assert captured[0]["input"]["modelFamily"] == "claude"
        assert captured[0]["input"]["region"] == "us-east-1"

    def test_system_array_extracted(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        bg = _make_bg(t)
        bg.intercept_request({
            "modelId": "anthropic.claude-3-haiku-20240307-v1:0",
            "messages": [],
            "system": [{"text": "You are a helpful assistant."}],
        })
        assert captured[0]["input"]["systemPromptDigest"] == "You are a helpful assistant."

    def test_tool_names_from_tool_config(self):
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        bg = _make_bg(t)
        bg.intercept_request({
            "modelId": "anthropic.claude-3-haiku-20240307-v1:0",
            "messages": [],
            "toolConfig": {
                "tools": [
                    {"toolSpec": {"name": "search_database", "description": "Search"}},
                    {"toolSpec": {"name": "run_query"}},
                ]
            },
        })
        assert captured[0]["input"]["toolNames"] == ["search_database", "run_query"]
        assert captured[0]["input"]["toolCount"] == 2

    def test_intercept_response_clean(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        bg = _make_bg(transport)

        response = {
            "output": {
                "message": {
                    "role": "assistant",
                    "content": [{"text": "Hello back"}],
                }
            },
            "stopReason": "end_turn",
        }
        classified = bg.intercept_response(response=response, audit_id="aud-bdr-001")
        assert classified.allowed


# ---------------------------------------------------------------------------
# 2. Secret leak G2
# ---------------------------------------------------------------------------

class TestBedrockSecretLeak:
    def test_g2_secret_in_response(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        bg = _make_bg(transport)

        classified = bg.intercept_response(
            response={"output": {"message": {"content": [{"text": "AWS_SECRET_KEY=abc123"}]}}},
            audit_id="aud-bdr-001",
        )
        assert not classified.allowed
        assert "G2_SECRET_LEAK" in classified.guards_triggered

    def test_proxy_converse_warns_on_g2(self, capsys):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        bg = _make_bg(transport)

        mock_resp = {
            "output": {"message": {"role": "assistant", "content": [{"text": "secret-key"}]}},
            "stopReason": "end_turn",
        }
        proxy = bg.wrap(_mock_bedrock_client(mock_resp))
        proxy.converse(
            modelId="anthropic.claude-3-haiku-20240307-v1:0",
            messages=[{"role": "user", "content": [{"text": "Hi"}]}],
        )
        captured = capsys.readouterr()
        assert "G-series classification" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal
# ---------------------------------------------------------------------------

class TestBedrockPhiIngress:
    def test_phi_denied_no_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        bg = _make_bg(transport, enforce=False)

        decision = bg.intercept_request({
            "modelId": "amazon.titan-text-express-v1",
            "messages": [],
            "system": [{"text": "Patient MRN: 12345"}],
        })
        assert decision.denied

    def test_phi_raises_when_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        bg = _make_bg(transport, enforce=True)

        with pytest.raises(GovernanceViolation):
            bg.intercept_request({
                "modelId": "amazon.titan-text-express-v1",
                "messages": [],
                "system": [{"text": "PHI data here"}],
            })


# ---------------------------------------------------------------------------
# 4. Provider compliance registration
# ---------------------------------------------------------------------------

class TestBedrockProviderCompliance:
    def test_baa_in_scope_registered(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_bg(httpx.MockTransport(handler))
        assert len(registered) == 1
        assert registered[0]["provider"] == "bedrock"
        assert registered[0]["baaAvailable"] is True
        assert registered[0]["baaScope"] == "aws_baa_hipaa_eligible"

    def test_notes_mention_region(self):
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        _ = _make_bg(httpx.MockTransport(handler))
        assert "region" in registered[0]["notes"].lower()


# ---------------------------------------------------------------------------
# 5. Subscription gate
# ---------------------------------------------------------------------------

class TestBedrockSubscriptionGate:
    def test_subscription_revoked_blocks(self):
        sub_deny = {
            "decision": "DENY",
            "reason": "Subscription inactive",
            "auditId": "aud-sub-bdr",
        }
        transport = _make_transport_with_classify(sub_deny, CLASSIFY_CLEAN)
        bg = _make_bg(transport, enforce=False)

        decision = bg.intercept_request({
            "modelId": "anthropic.claude-3-haiku-20240307-v1:0",
            "messages": [],
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# 6. Audit chain append
# ---------------------------------------------------------------------------

class TestBedrockAuditChain:
    def test_report_result_closes_chain(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_CLEAN)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        bg = _make_bg(t)

        bg.intercept_response(
            response={"output": {"message": {"content": [{"text": "Done"}]}}},
            audit_id="aud-bdr-001",
        )
        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-bdr-001"
        assert reported[0]["success"] is True

    def test_report_result_failure_on_blocked(self):
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_SECRET_LEAK)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        bg = _make_bg(t)

        bg.intercept_response(
            response={"output": {"message": {"content": [{"text": "secret-value"}]}}},
            audit_id="aud-bdr-001",
        )
        assert reported[0]["success"] is False


# ---------------------------------------------------------------------------
# wrap() proxy
# ---------------------------------------------------------------------------

class TestBedrockProxy:
    def test_wrap_returns_proxy(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        bg = _make_bg(transport)
        proxy = bg.wrap(_mock_bedrock_client({"output": {}}))
        assert isinstance(proxy, BedrockClientProxy)

    def test_proxy_converse_denied_returns_governance_message(self):
        deny = {"decision": "DENY", "reason": "policy block", "auditId": "aud-d"}
        transport = _make_transport_with_classify(deny, CLASSIFY_CLEAN)
        bg = _make_bg(transport, enforce=False)

        proxy = bg.wrap(_mock_bedrock_client({}))
        result = proxy.converse(
            modelId="anthropic.claude-3-haiku-20240307-v1:0",
            messages=[{"role": "user", "content": [{"text": "Hi"}]}],
        )
        assert result["stopReason"] == "GOVERNANCE_DENIED"
        text = result["output"]["message"]["content"][0]["text"]
        assert "[GOVERNANCE DENIED]" in text

    def test_proxy_invoke_model_denied(self):
        deny = {"decision": "DENY", "reason": "blocked", "auditId": "aud-e"}
        transport = _make_transport_with_classify(deny, CLASSIFY_CLEAN)
        bg = _make_bg(transport, enforce=False)

        proxy = bg.wrap(_mock_bedrock_client({}))
        result = proxy.invoke_model(
            modelId="amazon.titan-text-express-v1",
            body={"inputText": "Hello"},
        )
        assert result["stopReason"] == "GOVERNANCE_DENIED"

    def test_proxy_converse_allows_clean(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        bg = _make_bg(transport)

        good_resp = {
            "output": {
                "message": {
                    "role": "assistant",
                    "content": [{"text": "Safe reply"}],
                }
            },
            "stopReason": "end_turn",
        }
        proxy = bg.wrap(_mock_bedrock_client(good_resp))
        result = proxy.converse(
            modelId="anthropic.claude-3-haiku-20240307-v1:0",
            messages=[{"role": "user", "content": [{"text": "Hello"}]}],
        )
        assert result["output"]["message"]["content"][0]["text"] == "Safe reply"
