"""Tests for AnthropicGovernance integration (B1-01).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 response classification
3. PHI ingress refusal
4. Provider compliance registration
5. Subscription gate
6. Audit chain append
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.models import ClassifiedResponse, DecisionType
from connexum_governance.integrations.anthropic import AnthropicGovernance, AnthropicClientProxy
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Test fixtures and helpers
# ---------------------------------------------------------------------------

ALLOW_WITH_AUDIT = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-ant-001",
}

DENY_SECRET = {
    "decision": "DENY",
    "reason": "G2: secret pattern detected in system prompt",
    "auditId": "aud-ant-002",
}

PHI_DENY = {
    "decision": "DENY",
    "reason": "G3: PHI ingress blocked -- HIPAA pack binding requires PHI consent",
    "auditId": "aud-ant-003",
}

APPROVAL_RESPONSE = {
    "decision": "REQUIRE_APPROVAL",
    "reason": "Requires manager sign-off",
    "auditId": "aud-ant-004",
}

CLASSIFY_CLEAN = {
    "allowed": True,
    "guardsTriggered": [],
    "auditId": "aud-ant-001",
}

CLASSIFY_SECRET_LEAK = {
    "allowed": False,
    "guardsTriggered": ["G2_SECRET_LEAK"],
    "auditId": "aud-ant-001",
}


def _make_transport_with_classify(
    action_response: dict[str, Any],
    classify_response: dict[str, Any],
) -> httpx.MockTransport:
    return make_transport({
        "/api/v1/governance/check-action": action_response,
        "/api/v1/governance/check-task": action_response,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/governance/classify": classify_response,
        "/api/v1/governance/provider-compliance": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    })


def _make_ag(transport: httpx.MockTransport, enforce: bool = True) -> AnthropicGovernance:
    client = make_client(transport, enforce=enforce)
    return AnthropicGovernance(client=client, agent_name="test-agent", agent_role="chat")


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestAnthropicHappyPath:
    def test_intercept_request_allow(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)

        request = {
            "model": "claude-3-haiku-20240307",
            "max_tokens": 512,
            "messages": [{"role": "user", "content": "Hello"}],
        }
        decision = ag.intercept_request(request)
        assert decision.allowed
        assert decision.audit_id == "aud-ant-001"

    def test_intercept_response_clean(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)

        response = {
            "id": "msg_001",
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": "Hello there!"}],
        }
        classified = ag.intercept_response(response=response, audit_id="aud-ant-001")
        assert classified.allowed
        assert classified.guards_triggered == []

    def test_request_with_tools_sends_tool_names(self):
        """Tool names extracted and forwarded in governance input."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)

        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                body = json.loads(request.content)
                captured.append(body)
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        ag = _make_ag(t)

        decision = ag.intercept_request({
            "model": "claude-3-opus-20240229",
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": "Use the search tool"}],
            "tools": [{"name": "web_search", "description": "Search the web"}],
        })
        assert decision.allowed
        assert len(captured) == 1
        assert captured[0]["input"]["toolNames"] == ["web_search"]
        assert captured[0]["input"]["toolCount"] == 1

    def test_system_prompt_digest_truncated(self):
        """System prompt digest is capped at 500 chars."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        long_system = "x" * 1000

        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                body = json.loads(request.content)
                captured.append(body)
                return httpx.Response(200, json=ALLOW_WITH_AUDIT)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        ag = _make_ag(t)
        ag.intercept_request({
            "model": "claude-3-haiku-20240307",
            "max_tokens": 100,
            "system": long_system,
            "messages": [],
        })
        assert len(captured[0]["input"]["systemPromptDigest"]) == 500


# ---------------------------------------------------------------------------
# 2. Secret leak G2 -- response classification
# ---------------------------------------------------------------------------

class TestAnthropicSecretLeak:
    def test_intercept_response_secret_triggers_g2(self):
        """G2 guard: response containing a secret pattern blocks classification."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        ag = _make_ag(transport)

        response = {
            "id": "msg_002",
            "content": [{"type": "text", "text": "My key is sk-ant-abc123..."}],
        }
        classified = ag.intercept_response(response=response, audit_id="aud-ant-001")
        assert not classified.allowed
        assert "G2_SECRET_LEAK" in classified.guards_triggered

    def test_proxy_logs_g2_warning_to_stderr(self, capsys):
        """The proxy prints a G-series warning to stderr when classification blocks."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_SECRET_LEAK)
        ag = _make_ag(transport)

        class MockMessages:
            def create(self, **kwargs: Any) -> dict:
                return {
                    "id": "msg_secret",
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "text", "text": "sk-ant-abc123"}],
                    "model": "claude-3-haiku-20240307",
                    "stop_reason": "end_turn",
                    "usage": {"input_tokens": 2, "output_tokens": 4},
                }

        class MockAnthropic:
            messages = MockMessages()

        proxy = ag.wrap(MockAnthropic())
        proxy.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=100,
            messages=[{"role": "user", "content": "Hi"}],
        )
        captured = capsys.readouterr()
        assert "G-series classification" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal
# ---------------------------------------------------------------------------

class TestAnthropicPhiIngress:
    def test_phi_ingress_denied(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        ag = _make_ag(transport, enforce=False)

        decision = ag.intercept_request({
            "model": "claude-3-haiku-20240307",
            "max_tokens": 256,
            "system": "Patient DOB: 1980-01-01, SSN: 123-45-6789",
            "messages": [{"role": "user", "content": "Analyze this patient record"}],
        })
        assert decision.denied
        assert "PHI" in decision.reason or "G3" in decision.reason

    def test_phi_ingress_raises_when_enforce(self):
        transport = _make_transport_with_classify(PHI_DENY, CLASSIFY_CLEAN)
        ag = _make_ag(transport, enforce=True)

        with pytest.raises(GovernanceViolation):
            ag.intercept_request({
                "model": "claude-3-haiku-20240307",
                "max_tokens": 256,
                "system": "Patient record with SSN",
                "messages": [],
            })


# ---------------------------------------------------------------------------
# 4. Provider compliance registration
# ---------------------------------------------------------------------------

class TestAnthropicProviderCompliance:
    def test_provider_compliance_registered_on_init(self):
        """AnthropicGovernance registers BAA metadata at construction."""
        registered: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                registered.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        _ = _make_ag(t)
        assert len(registered) == 1
        assert registered[0]["provider"] == "anthropic"
        assert registered[0]["baaAvailable"] is True
        assert registered[0]["baaScope"] == "enterprise"

    def test_provider_compliance_failure_is_non_fatal(self):
        """Registration failure does not prevent normal operation."""
        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/provider-compliance":
                return httpx.Response(500, json={"error": "server error"})
            return httpx.Response(200, json=ALLOW_WITH_AUDIT)

        t = httpx.MockTransport(handler)
        # Should not raise
        ag = _make_ag(t)
        assert ag.agent.name == "test-agent"


# ---------------------------------------------------------------------------
# 5. Subscription gate
# ---------------------------------------------------------------------------

class TestAnthropicSubscriptionGate:
    def test_denied_when_subscription_revoked(self):
        """When governance server returns DENY for subscription, request is blocked."""
        sub_deny = {
            "decision": "DENY",
            "reason": "Subscription inactive or expired",
            "auditId": "aud-sub-001",
        }
        transport = _make_transport_with_classify(sub_deny, CLASSIFY_CLEAN)
        ag = _make_ag(transport, enforce=False)

        decision = ag.intercept_request({
            "model": "claude-3-haiku-20240307",
            "max_tokens": 100,
            "messages": [{"role": "user", "content": "Hello"}],
        })
        assert decision.denied
        assert "subscription" in decision.reason.lower() or "inactive" in decision.reason.lower()


# ---------------------------------------------------------------------------
# 6. Audit chain append
# ---------------------------------------------------------------------------

class TestAnthropicAuditChain:
    def test_audit_chain_report_result_called(self):
        """intercept_response calls report_result to close the audit chain."""
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_CLEAN)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        ag = _make_ag(t)

        ag.intercept_response(
            response={"id": "msg_003", "content": [{"type": "text", "text": "Done"}]},
            audit_id="aud-ant-001",
        )

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-ant-001"
        assert reported[0]["success"] is True

    def test_audit_chain_marks_failure_on_blocked_response(self):
        """report_result marks success=False when response classification blocks."""
        reported: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/classify":
                return httpx.Response(200, json=CLASSIFY_SECRET_LEAK)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(handler)
        ag = _make_ag(t)

        ag.intercept_response(
            response={"content": [{"type": "text", "text": "sk-ant-secret"}]},
            audit_id="aud-ant-001",
        )

        assert len(reported) == 1
        assert reported[0]["success"] is False


# ---------------------------------------------------------------------------
# wrap() proxy
# ---------------------------------------------------------------------------

class TestAnthropicProxy:
    def test_wrap_returns_proxy(self):
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)

        class MockAnthropicClient:
            class messages:
                @staticmethod
                def create(**kwargs: Any) -> dict:
                    return {
                        "id": "msg_mock",
                        "type": "message",
                        "role": "assistant",
                        "content": [{"type": "text", "text": "Mocked"}],
                        "model": kwargs.get("model", "unknown"),
                        "stop_reason": "end_turn",
                        "usage": {"input_tokens": 5, "output_tokens": 3},
                    }

        proxy = ag.wrap(MockAnthropicClient())
        assert isinstance(proxy, AnthropicClientProxy)

    def test_wrap_proxy_calls_governance(self):
        """Proxy intercepts create() and goes through governance."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport)

        class MockMessages:
            def create(self, **kwargs: Any) -> dict:
                return {
                    "id": "msg_mock",
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "text", "text": "OK"}],
                    "model": kwargs.get("model", "unknown"),
                    "stop_reason": "end_turn",
                    "usage": {"input_tokens": 2, "output_tokens": 2},
                }

        class MockAnthropic:
            messages = MockMessages()

        proxy = ag.wrap(MockAnthropic())
        result = proxy.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=100,
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert result["id"] == "msg_mock"

    def test_wrap_proxy_returns_denial_when_blocked(self):
        transport = _make_transport_with_classify(
            {"decision": "DENY", "reason": "blocked by policy", "auditId": "aud-x"},
            CLASSIFY_CLEAN,
        )
        ag = _make_ag(transport, enforce=False)

        class MockMessages:
            def create(self, **kwargs: Any) -> dict:
                return {"id": "should-not-reach"}

        class MockAnthropic:
            messages = MockMessages()

        proxy = ag.wrap(MockAnthropic())
        result = proxy.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=100,
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert result["stop_reason"] == "governance_denied"
        assert "[GOVERNANCE DENIED]" in result["content"][0]["text"]


# ---------------------------------------------------------------------------
# PT-PYTHON-WRAP-RAW-1: _raw_client and beta.messages bypass blocked (C3)
# ---------------------------------------------------------------------------

class TestPtPythonWrapRaw1:
    """PT-PYTHON-WRAP-RAW-1: AnthropicClientProxy blocks _raw_client and beta bypass.

    Pen-test ID: PT-PYTHON-WRAP-RAW-1
    Finding: C3 -- AnthropicClientProxy exposes _raw_client via __getattr__,
    allowing governed_client._raw_client.messages.create(...) to bypass all
    governance checks entirely.

    Fix: __getattr__ raises GovernanceViolation on _raw_client, beta, and any
    other path that reaches the underlying provider directly.
    """

    def _make_proxy(self, enforce: bool = True) -> AnthropicClientProxy:
        """Build a proxy wrapping a MockAnthropic client."""
        transport = _make_transport_with_classify(ALLOW_WITH_AUDIT, CLASSIFY_CLEAN)
        ag = _make_ag(transport, enforce=enforce)

        class MockMessages:
            def create(self, **kwargs: Any) -> dict:
                return {
                    "id": "msg_bypass",
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "text", "text": "bypass succeeded"}],
                    "model": "claude-3-haiku-20240307",
                    "stop_reason": "end_turn",
                    "usage": {"input_tokens": 1, "output_tokens": 1},
                }

        class MockBeta:
            messages = MockMessages()

        class MockAnthropic:
            messages = MockMessages()
            beta = MockBeta()

        return ag.wrap(MockAnthropic())

    def test_raw_client_access_raises_governance_violation(self):
        """PT-PYTHON-WRAP-RAW-1: _raw_client access raises GovernanceViolation."""
        proxy = self._make_proxy()
        with pytest.raises(GovernanceViolation) as exc_info:
            _ = proxy._raw_client
        assert "direct provider access" in str(exc_info.value).lower() or \
               "not permitted" in str(exc_info.value).lower()

    def test_beta_access_raises_governance_violation(self):
        """PT-PYTHON-WRAP-RAW-1: .beta access raises GovernanceViolation."""
        proxy = self._make_proxy()
        with pytest.raises(GovernanceViolation) as exc_info:
            _ = proxy.beta
        assert "direct provider access" in str(exc_info.value).lower() or \
               "not permitted" in str(exc_info.value).lower()

    def test_beta_messages_create_cannot_bypass_governance(self):
        """PT-PYTHON-WRAP-RAW-1: .beta.messages.create cannot be reached via proxy."""
        proxy = self._make_proxy()
        with pytest.raises(GovernanceViolation):
            # This must raise at the .beta access step, before .messages.create
            _ = proxy.beta.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=100,
                messages=[{"role": "user", "content": "bypass"}],
            )

    def test_raw_prefix_attribute_blocked(self):
        """PT-PYTHON-WRAP-RAW-1: any _raw* attribute access is blocked."""
        proxy = self._make_proxy()
        with pytest.raises(GovernanceViolation):
            _ = proxy._raw  # must not expose the underlying client

    def test_with_raw_response_attribute_blocked(self):
        """PT-PYTHON-WRAP-RAW-1: with_raw_response bypass path is blocked."""
        proxy = self._make_proxy()
        with pytest.raises(GovernanceViolation):
            _ = proxy.with_raw_response

    def test_governed_messages_still_works_after_bypass_attempt(self):
        """PT-PYTHON-WRAP-RAW-1: proxy.messages.create still works after blocked bypass."""
        proxy = self._make_proxy()
        # Bypass attempt (should raise)
        try:
            _ = proxy._raw_client
        except GovernanceViolation:
            pass  # expected

        # Normal governed call must still work
        result = proxy.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=100,
            messages=[{"role": "user", "content": "hello"}],
        )
        assert result is not None
