"""Tests for LlamaIndex governance integration (B2-09).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak / PHI in tool result -- output classifier
3. PHI ingress refusal -- document retrieval PHI detection
4. Provider compliance -- unapproved model blocks llm_call
5. Subscription gate -- governance server DENY at agent_start
6. Audit chain append -- canonical events round-trip
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.llamaindex import (
    HEALTHCARE_DOCUMENT_CLASSES,
    LlamaIndexGovernance,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-li-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-li-002"}
SUB_DENY = {
    "decision": "DENY",
    "reason": "Subscription inactive or expired",
    "auditId": "aud-li-003",
}

_APPROVED_MODELS = ["gpt-4o", "claude-haiku-4-5", "claude-sonnet-4-6"]


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    approved_models: list[str] | None = None,
) -> LlamaIndexGovernance:
    client = make_client(transport, enforce=enforce)
    return LlamaIndexGovernance(
        client=client,
        approved_models=approved_models if approved_models is not None else _APPROVED_MODELS,
        sensitive_tools=["write_file", "execute_code"],
        agent_name="test-llamaindex-agent",
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestLlamaIndexHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            "sess-001",
            agent_type="ReActAgent",
            pack_binding=["hipaa"],
        )
        assert decision.allowed
        assert "sess-001" in adapter._sessions

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"])
        decision = adapter.tool_call(
            "sess-001", "search_tool",
            {"query": "AI governance standards"},
        )
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"])
        adapter.tool_call("sess-001", "search_tool", {})
        adapter.tool_result("sess-001", "search_tool", "Clean search results")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"])
        decision = adapter.llm_call(
            "sess-001",
            "gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
        assert decision.allowed

    def test_document_retrieval_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"])
        adapter.document_retrieval(
            "sess-001",
            chunks=["AI governance is important for healthcare AI systems."],
            document_class="ClinicalNote",
        )
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_response_synthesis_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"])
        adapter.document_retrieval("sess-001", chunks=["Clean content"])
        adapter.response_synthesis("sess-001", synthesized_text="Here is the clean summary.")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_clean(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["hipaa"])
        adapter.agent_end("sess-001", success=True, summary="Task complete")
        assert "sess-001" not in adapter._sessions

    def test_full_react_agent_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-full", agent_type="ReActAgent", pack_binding=["hipaa"])
        adapter.tool_call(
            "sess-full", "search",
            {"query": "treatment guidelines"},
            react_trace={"thought": "I need to search", "action": "search"},
        )
        adapter.tool_result("sess-full", "search", "Guidelines found", success=True)
        adapter.llm_call("sess-full", "gpt-4o", [{"role": "user", "content": "synthesize"}])
        adapter.document_retrieval("sess-full", chunks=["doc chunk 1"])
        adapter.response_synthesis("sess-full", synthesized_text="Synthesized answer.")
        adapter.agent_end("sess-full", success=True)


# ---------------------------------------------------------------------------
# 2. PHI in tool result -- output classifier
# ---------------------------------------------------------------------------

class TestLlamaIndexSecretLeak:
    def test_phi_in_tool_result_flags_classifier(self, capsys):
        """PHI in tool result triggers output classifier warning."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-g2", pack_binding=["soc2"])
        adapter.tool_call("sess-g2", "db_query", {})
        adapter.tool_result(
            "sess-g2",
            "db_query",
            "patient_id=123 ssn=123-45-6789",
            success=True,
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_response_synthesis_flagged(self, capsys):
        """Distilled PHI in synthesized response triggers classifier."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-g2b", pack_binding=["hipaa"])
        adapter.document_retrieval("sess-g2b", chunks=["chunk1"])
        adapter.response_synthesis(
            "sess-g2b",
            synthesized_text="The patient dob: 1990-01-01 has been diagnosed.",
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_report_result_marks_failure(self):
        """report_result success=False when PHI detected in tool result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-g2c", pack_binding=["soc2"])
        adapter.tool_call("sess-g2c", "query", {})
        adapter.tool_result("sess-g2c", "query", "npi=1234567890 diagnosis=diabetes")

        assert any(r["success"] is False for r in reported)


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- document retrieval PHI detection
# ---------------------------------------------------------------------------

class TestLlamaIndexPhiIngress:
    def test_phi_in_retrieved_chunks_flagged(self, capsys):
        """PHI in retrieved document chunks triggers ingress classification warning."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-phi", pack_binding=["hipaa"])
        adapter.document_retrieval(
            "sess-phi",
            chunks=["Patient SSN: 123-45-6789 medical history record"],
            document_class="MedicalRecord",
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err
        assert "document_class" in captured.err.lower() or "MedicalRecord" in captured.err

    def test_phi_in_chunks_forwarded_to_governance(self):
        """phiDetected=True is forwarded in document_retrieval check_action input."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-phi-fwd", pack_binding=["hipaa"])
        adapter.document_retrieval(
            "sess-phi-fwd",
            chunks=[{"text": "Patient mrn=ABC ssn=123-45-6789 DOB: 1990-01-01"}],
            document_class="LabReport",
        )

        retrieval_calls = [
            c for c in captured
            if c.get("input", {}).get("toolName", "") == "" and
            "document.retrieval" in c.get("toolName", "")
        ]
        # Find document.retrieval check
        doc_calls = [c for c in captured if "document.retrieval" in str(c.get("input", {}))]
        # Alternative: check any call with phiDetected
        phi_calls = [c for c in captured if c.get("input", {}).get("phiDetected") is True]
        assert len(phi_calls) >= 1

    def test_healthcare_document_class_is_flagged(self):
        """Healthcare document classes trigger isHealthcareClass=True."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-hc", pack_binding=["hipaa"])
        adapter.document_retrieval(
            "sess-hc",
            chunks=["lab values normal"],
            document_class="LabReport",
        )

        hc_calls = [c for c in captured if c.get("input", {}).get("isHealthcareClass") is True]
        assert len(hc_calls) >= 1

    def test_non_healthcare_document_class_not_flagged(self):
        """Non-healthcare document classes do not set isHealthcareClass=True."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-non-hc", pack_binding=["soc2"])
        adapter.document_retrieval(
            "sess-non-hc",
            chunks=["general business document"],
            document_class="BusinessReport",
        )

        non_hc_calls = [c for c in captured if c.get("input", {}).get("isHealthcareClass") is False]
        assert len(non_hc_calls) >= 1


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved model blocks llm_call
# ---------------------------------------------------------------------------

class TestLlamaIndexProviderCompliance:
    def test_unapproved_model_denied(self):
        """Model not in approved_models is denied at llm_call."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-model", pack_binding=["hipaa"])
        decision = adapter.llm_call(
            "sess-model",
            "deepseek-r1",  # not in approved list
            messages=[],
        )
        assert decision.denied
        assert "deepseek-r1" in decision.reason

    def test_approved_model_passes(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-model-ok", pack_binding=["soc2"])
        decision = adapter.llm_call("sess-model-ok", "gpt-4o", [])
        assert decision.allowed

    def test_no_approved_models_allows_any(self):
        """When approved_models=[] (empty), all models are allowed."""
        client = make_client(_transport())
        adapter = LlamaIndexGovernance(
            client=client,
            approved_models=[],  # empty = no restriction
        )
        adapter.agent_start("sess-open", pack_binding=["soc2"])
        decision = adapter.llm_call("sess-open", "any-model", [])
        assert decision.allowed

    def test_react_trace_forwarded_in_tool_call_input(self):
        """ReAct trace fields are forwarded in tool_call governance input."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-react", pack_binding=["hipaa"])
        adapter.tool_call(
            "sess-react",
            "search",
            {"query": "AI governance"},
            react_trace={
                "thought": "I need more information",
                "action": "search",
                "observation": None,
            },
        )

        tool_calls = [c for c in captured if c.get("input", {}).get("toolName") == "search"]
        assert len(tool_calls) >= 1
        assert tool_calls[0]["input"]["reactTrace"]["thought"] == "I need more information"


# ---------------------------------------------------------------------------
# 5. Subscription gate -- governance server DENY
# ---------------------------------------------------------------------------

class TestLlamaIndexSubscriptionGate:
    def test_agent_start_subscription_deny(self):
        """Governance DENY at agent_start is returned as denied decision."""
        transport = _transport(**{"/api/v1/governance/check-action": SUB_DENY})
        adapter = _adapter(transport, enforce=False)
        decision = adapter.agent_start("sess-sub", pack_binding=["hipaa"])
        assert decision.denied
        assert "subscription" in decision.reason.lower() or "inactive" in decision.reason.lower()

    def test_tool_call_governance_deny(self):
        """Governance DENY at tool_call is returned."""
        transport = _transport(**{"/api/v1/governance/check-action": DENY})
        adapter = _adapter(transport, enforce=False)
        adapter._sessions["sess-deny"] = {"pack_binding": ["soc2"]}
        decision = adapter.tool_call("sess-deny", "search", {})
        assert decision.denied


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip
# ---------------------------------------------------------------------------

class TestLlamaIndexAuditChain:
    def test_tool_result_uses_audit_id_from_tool_call(self):
        """audit_id from tool_call is used in tool_result report_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-audit", pack_binding=["hipaa"])
        adapter.tool_call("sess-audit", "search", {"query": "test"})
        adapter.tool_result("sess-audit", "search", "clean results")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-li-001"
        assert reported[0]["success"] is True

    def test_response_synthesis_uses_audit_id_from_document_retrieval(self):
        """audit_id from document_retrieval is used in response_synthesis."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-synth", pack_binding=["hipaa"])
        adapter.document_retrieval("sess-synth", chunks=["chunk1", "chunk2"])
        adapter.response_synthesis("sess-synth", synthesized_text="Clean synthesized answer.")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-li-001"

    def test_agent_end_fires_terminal_check_action(self):
        """agent_end fires check_action to seal terminal audit event."""
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-end", pack_binding=["soc2"])
        adapter.agent_end("sess-end", success=True)

        action_calls = [c for c in calls if "check-action" in c]
        assert len(action_calls) >= 2

    def test_healthcare_document_classes_constant(self):
        """HEALTHCARE_DOCUMENT_CLASSES constant includes expected classes."""
        assert "MedicalRecord" in HEALTHCARE_DOCUMENT_CLASSES
        assert "LabReport" in HEALTHCARE_DOCUMENT_CLASSES
        assert "ClinicalNote" in HEALTHCARE_DOCUMENT_CLASSES
        assert "PatientChart" in HEALTHCARE_DOCUMENT_CLASSES
        assert "PathologyReport" in HEALTHCARE_DOCUMENT_CLASSES
        assert "BusinessReport" not in HEALTHCARE_DOCUMENT_CLASSES

    def test_framework_tag_in_all_check_action_inputs(self):
        """framework: llamaindex tag is present in all check_action inputs."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-tag", pack_binding=["soc2"])

        assert all(c["input"].get("framework") == "llamaindex" for c in captured)
