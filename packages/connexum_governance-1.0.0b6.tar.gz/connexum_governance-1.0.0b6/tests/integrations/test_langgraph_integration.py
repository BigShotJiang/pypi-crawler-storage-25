"""
Tests for connexum_governance.integrations.langgraph_integration

Standalone LangGraph Python framework adapter -- Sprint 5, WS-10.

All tests run offline -- no real langgraph or langchain packages required.
LangGraph primitives are mocked via minimal class implementations.
Governance server calls are injected via the _check_fn parameter.

Coverage:

  GovernedStateGraph:
    add_node():
      - Wraps node fn with governance pre-check
      - ALLOW -> calls original node fn
      - DENY -> raises GovernanceViolation
      - PENDING -> raises GovernancePendingApproval
      - Action namespace 'framework.langgraph.node_execute' sent
      - ToolNode-named nodes use 'framework.langgraph.tool_node'
      - Async node functions wrapped as async
      - Sync node functions wrapped as sync
      - Node name forwarded in metadata
    add_conditional_edges():
      - Wraps routing function with governance pre-check
      - ALLOW -> calls original routing function
      - DENY -> raises GovernanceViolation
      - PENDING -> raises GovernancePendingApproval
      - Action namespace 'framework.langgraph.edge_transition' sent
      - Source node name forwarded in metadata
    compile():
      - Returns governed Pregel (invoke/ainvoke wrapped)
      - Pregel invoke ALLOW -> delegates to original invoke
      - Pregel invoke DENY -> raises GovernanceViolation
      - Pregel ainvoke ALLOW -> delegates to original ainvoke
      - Pregel ainvoke DENY -> raises GovernanceViolation
      - Action namespace 'framework.langgraph.invoke' sent
    Constructor validation:
      - graph=None -> raises ValueError
      - missing governance_server_url -> raises ValueError
      - missing license_key -> raises ValueError
    __getattr__:
      - Other methods forwarded to underlying graph

  wrap_state_graph():
    - add_node() wrapped (per-node governance)
    - compile() wrapped (per-invocation governance)
    - DENY from wrapped node -> GovernanceViolation
    - ALLOW from wrapped node -> original node called
    - Idempotency: calling twice does not double-wrap
    - _connexum_governed marker set on graph

  wrap_pregel():
    - invoke() wrapped: ALLOW -> delegates, DENY -> raises
    - ainvoke() wrapped: ALLOW -> delegates, DENY -> raises
    - Action namespace 'framework.langgraph.invoke'
    - State dict preview extracted from 'messages' key
    - State dict preview extracted from 'input' key
    - String state preview
    - Idempotency: calling twice does not double-wrap
    - _connexum_governed marker set on runnable

  create_governed_langgraph() factory:
    - Returns GovernedLangGraphInstance
    - governed_state_graph() returns GovernedStateGraph
    - wrap_graph() wraps StateGraph in place
    - wrap_pregel() wraps compiled Pregel
    - Constructor validation: missing url -> ValueError
    - Constructor validation: missing key -> ValueError

  LangChain adapter re-export compatibility:
    - wrap_state_graph imported from langchain_integration works
    - Calls langgraph_integration.wrap_state_graph under the hood
    - create_governed_langchain().wrap_graph() still works (backwards compat)

  Error propagation:
    - GovernanceViolation raised from node fires from graph.invoke
    - GovernancePendingApproval raised from edge fires from routing
"""

from __future__ import annotations

import asyncio
import pytest
from typing import Any, Optional

from connexum_governance.integrations.langgraph_integration import (
    GovernedStateGraph,
    wrap_state_graph,
    wrap_pregel,
    create_governed_langgraph,
    GovernedLangGraphInstance,
)
from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)


# ---------------------------------------------------------------------------
# Helper: mock check functions
# ---------------------------------------------------------------------------

async def allow_fn(url: str, body: dict) -> dict:
    return {"decision": "ALLOW"}


async def deny_fn(url: str, body: dict) -> dict:
    return {"decision": "DENY", "reason": "langgraph policy denial"}


async def pending_fn(url: str, body: dict) -> dict:
    return {
        "decision": "REQUIRE_APPROVAL",
        "approvalId": "approval-lg-123",
        "auditId": "audit-lg-456",
    }


async def pending_no_id_fn(url: str, body: dict) -> dict:
    return {"decision": "REQUIRE_APPROVAL"}


def make_capture_fn(result: str, captures: list[dict], approval_id: Optional[str] = None):
    """Returns an async check function that records bodies."""
    async def check_fn(url: str, body: dict) -> dict:
        captures.append(dict(body))
        if result == "DENY":
            return {"decision": "DENY", "reason": "test denial"}
        if result == "REQUIRE_APPROVAL":
            return {
                "decision": "REQUIRE_APPROVAL",
                "approvalId": approval_id or "approval-test-id",
                "auditId": "audit-test-id",
            }
        return {"decision": "ALLOW"}
    return check_fn


# ---------------------------------------------------------------------------
# Helper: mock LangGraph primitives (no real langgraph needed)
# ---------------------------------------------------------------------------

class MockStateGraph:
    """Minimal StateGraph duck-type for testing."""

    def __init__(self):
        self._nodes: dict = {}
        self._edges: list = []
        self._conditional_edges: list = []
        self.add_node_call_count = 0
        self.compile_call_count = 0

    def add_node(self, name: str, fn: Any, *args: Any, **kwargs: Any) -> None:
        self._nodes[name] = fn
        self.add_node_call_count += 1

    def add_edge(self, source: str, target: str) -> None:
        self._edges.append((source, target))

    def add_conditional_edges(
        self, source: str, path: Any, *args: Any, **kwargs: Any
    ) -> None:
        self._conditional_edges.append((source, path))

    def compile(self, *args: Any, **kwargs: Any) -> "MockPregelRunnable":
        self.compile_call_count += 1
        return MockPregelRunnable(nodes=self._nodes)

    def set_entry_point(self, name: str) -> None:
        pass  # passthrough

    def set_finish_point(self, name: str) -> None:
        pass  # passthrough


class MockPregelRunnable:
    """Minimal Pregel runnable duck-type."""

    def __init__(self, nodes: Optional[dict] = None):
        self._nodes = nodes or {}
        self.invoke_call_count = 0
        self.ainvoke_call_count = 0

    def invoke(self, state: Any = None, config: Any = None, **kwargs: Any) -> Any:
        self.invoke_call_count += 1
        return {"output": "invoke-result", "state": state}

    async def ainvoke(self, state: Any = None, config: Any = None, **kwargs: Any) -> Any:
        self.ainvoke_call_count += 1
        return {"output": "ainvoke-result", "state": state}


BASE_CONFIG = {
    "governance_server_url": "http://localhost:3200",
    "license_key": "test-license-key",
}


# ===========================================================================
# GovernedStateGraph -- add_node()
# ===========================================================================

class TestGovernedStateGraphAddNode:
    """Tests for GovernedStateGraph.add_node()."""

    def test_add_node_registers_on_underlying_graph(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)
        g.add_node("agent", lambda state: state)
        assert "agent" in raw._nodes

    @pytest.mark.asyncio
    async def test_node_allow_calls_original(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)

        result_holder = []

        def agent_fn(state):
            result_holder.append(state)
            return {"processed": True}

        g.add_node("agent", agent_fn)
        # Invoke the wrapped node directly
        wrapped_fn = raw._nodes["agent"]
        out = wrapped_fn({"messages": ["hello"]})
        assert out == {"processed": True}
        assert len(result_holder) == 1

    @pytest.mark.asyncio
    async def test_node_deny_raises_governance_violation(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=deny_fn, **BASE_CONFIG)
        g.add_node("agent", lambda state: state)
        wrapped_fn = raw._nodes["agent"]
        with pytest.raises(GovernanceViolation):
            wrapped_fn({"messages": ["hello"]})

    @pytest.mark.asyncio
    async def test_node_pending_raises_governance_pending(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=pending_fn, **BASE_CONFIG)
        g.add_node("agent", lambda state: state)
        wrapped_fn = raw._nodes["agent"]
        with pytest.raises(GovernancePendingApproval):
            wrapped_fn({"messages": ["hello"]})

    @pytest.mark.asyncio
    async def test_node_action_namespace(self):
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        g.add_node("agent", lambda state: state)
        wrapped_fn = raw._nodes["agent"]
        wrapped_fn({})
        assert captures[0]["action"] == "framework.langgraph.node_execute"

    @pytest.mark.asyncio
    async def test_tool_node_action_namespace(self):
        """Nodes named 'tools' use framework.langgraph.tool_node action."""
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        g.add_node("tools", lambda state: state)
        wrapped_fn = raw._nodes["tools"]
        wrapped_fn({})
        assert captures[0]["action"] == "framework.langgraph.tool_node"

    @pytest.mark.asyncio
    async def test_tool_node_name_variation(self):
        """Nodes named 'tool_node' also use tool_node action."""
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        g.add_node("tool_node", lambda state: state)
        wrapped_fn = raw._nodes["tool_node"]
        wrapped_fn({})
        assert captures[0]["action"] == "framework.langgraph.tool_node"

    @pytest.mark.asyncio
    async def test_async_node_wrapped_as_async(self):
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )

        async def async_node(state):
            return {"async": True}

        g.add_node("async_agent", async_node)
        wrapped_fn = raw._nodes["async_agent"]
        assert asyncio.iscoroutinefunction(wrapped_fn)
        out = await wrapped_fn({})
        assert out == {"async": True}

    @pytest.mark.asyncio
    async def test_async_node_deny_raises(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=deny_fn, **BASE_CONFIG)

        async def async_node(state):
            return state

        g.add_node("async_agent", async_node)
        wrapped_fn = raw._nodes["async_agent"]
        with pytest.raises(GovernanceViolation):
            await wrapped_fn({})

    def test_node_name_in_metadata(self):
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        g.add_node("my_agent_node", lambda state: state)
        wrapped_fn = raw._nodes["my_agent_node"]
        wrapped_fn({})
        assert captures[0]["metadata"]["nodeName"] == "my_agent_node"


# ===========================================================================
# GovernedStateGraph -- add_conditional_edges()
# ===========================================================================

class TestGovernedStateGraphConditionalEdges:
    """Tests for GovernedStateGraph.add_conditional_edges()."""

    def test_edge_allow_calls_original_routing(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)

        results = []

        def route(state):
            results.append(state)
            return "next_node"

        g.add_conditional_edges("agent", route)
        # Invoke the wrapped routing function
        _, wrapped_path = raw._conditional_edges[0]
        out = wrapped_path({"key": "val"})
        assert out == "next_node"
        assert len(results) == 1

    def test_edge_deny_raises_governance_violation(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=deny_fn, **BASE_CONFIG)

        def route(state):
            return "next_node"

        g.add_conditional_edges("agent", route)
        _, wrapped_path = raw._conditional_edges[0]
        with pytest.raises(GovernanceViolation):
            wrapped_path({})

    def test_edge_pending_raises_governance_pending(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=pending_fn, **BASE_CONFIG)

        def route(state):
            return "next_node"

        g.add_conditional_edges("agent", route)
        _, wrapped_path = raw._conditional_edges[0]
        with pytest.raises(GovernancePendingApproval):
            wrapped_path({})

    def test_edge_action_namespace(self):
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        g.add_conditional_edges("agent", lambda state: "end")
        _, wrapped_path = raw._conditional_edges[0]
        wrapped_path({})
        assert captures[0]["action"] == "framework.langgraph.edge_transition"

    def test_edge_source_name_in_metadata(self):
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        g.add_conditional_edges("my_source_node", lambda state: "end")
        _, wrapped_path = raw._conditional_edges[0]
        wrapped_path({})
        assert captures[0]["metadata"]["source"] == "my_source_node"

    @pytest.mark.asyncio
    async def test_async_routing_fn_wrapped_as_async(self):
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )

        async def async_route(state):
            return "next"

        g.add_conditional_edges("agent", async_route)
        _, wrapped_path = raw._conditional_edges[0]
        assert asyncio.iscoroutinefunction(wrapped_path)
        out = await wrapped_path({})
        assert out == "next"


# ===========================================================================
# GovernedStateGraph -- compile()
# ===========================================================================

class TestGovernedStateGraphCompile:
    """Tests for GovernedStateGraph.compile() returning governed Pregel."""

    def test_compile_returns_governed_pregel(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)
        app = g.compile()
        assert getattr(app, "_connexum_governed", False) is True

    def test_compile_pregel_invoke_allow(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)
        app = g.compile()
        result = app.invoke({"messages": ["hello"]})
        assert result["output"] == "invoke-result"

    def test_compile_pregel_invoke_deny_raises(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=deny_fn, **BASE_CONFIG)
        app = g.compile()
        with pytest.raises(GovernanceViolation):
            app.invoke({"messages": ["hello"]})

    @pytest.mark.asyncio
    async def test_compile_pregel_ainvoke_allow(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)
        app = g.compile()
        result = await app.ainvoke({"messages": ["hello"]})
        assert result["output"] == "ainvoke-result"

    @pytest.mark.asyncio
    async def test_compile_pregel_ainvoke_deny_raises(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=deny_fn, **BASE_CONFIG)
        app = g.compile()
        with pytest.raises(GovernanceViolation):
            await app.ainvoke({"messages": ["hello"]})

    def test_compile_invoke_action_namespace(self):
        captures = []
        raw = MockStateGraph()
        g = GovernedStateGraph(
            graph=raw,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        app = g.compile()
        app.invoke({})
        assert any(c["action"] == "framework.langgraph.invoke" for c in captures)

    def test_compile_delegates_to_underlying_graph(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)
        g.compile()
        assert raw.compile_call_count == 1


# ===========================================================================
# GovernedStateGraph -- constructor and passthrough
# ===========================================================================

class TestGovernedStateGraphConstructor:
    """Tests for GovernedStateGraph constructor and __getattr__."""

    def test_graph_none_raises(self):
        with pytest.raises(ValueError, match="graph is required"):
            GovernedStateGraph(graph=None, **BASE_CONFIG, _check_fn=allow_fn)

    def test_missing_url_raises(self):
        with pytest.raises(ValueError, match="governance_server_url is required"):
            GovernedStateGraph(
                graph=MockStateGraph(),
                governance_server_url="",
                license_key="key",
                _check_fn=allow_fn,
            )

    def test_missing_key_raises(self):
        with pytest.raises(ValueError, match="license_key is required"):
            GovernedStateGraph(
                graph=MockStateGraph(),
                governance_server_url="http://localhost:3200",
                license_key="",
                _check_fn=allow_fn,
            )

    def test_getattr_forwards_to_underlying(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)
        # add_edge is not intercepted, should forward to raw
        g.add_edge("a", "b")
        assert ("a", "b") in raw._edges

    def test_set_entry_point_forwarded(self):
        raw = MockStateGraph()
        g = GovernedStateGraph(graph=raw, _check_fn=allow_fn, **BASE_CONFIG)
        # Should not raise (passthrough)
        g.set_entry_point("agent")


# ===========================================================================
# wrap_state_graph()
# ===========================================================================

class TestWrapStateGraph:
    """Tests for wrap_state_graph() convenience function."""

    def test_add_node_wrapped(self):
        raw = MockStateGraph()
        wrap_state_graph(raw, _check_fn=allow_fn, **BASE_CONFIG)
        raw.add_node("agent", lambda state: state)
        # Should have injected a governed wrapper (verify by calling it)
        assert "agent" in raw._nodes

    def test_allow_calls_original_node(self):
        raw = MockStateGraph()
        wrap_state_graph(raw, _check_fn=allow_fn, **BASE_CONFIG)
        results = []

        def my_node(state):
            results.append(state)
            return state

        raw.add_node("agent", my_node)
        wrapped_fn = raw._nodes["agent"]
        wrapped_fn({"hello": True})
        assert len(results) == 1

    def test_deny_raises_from_wrapped_node(self):
        raw = MockStateGraph()
        wrap_state_graph(raw, _check_fn=deny_fn, **BASE_CONFIG)
        raw.add_node("agent", lambda state: state)
        wrapped_fn = raw._nodes["agent"]
        with pytest.raises(GovernanceViolation):
            wrapped_fn({})

    def test_compile_wrapped_returns_governed_pregel(self):
        raw = MockStateGraph()
        wrap_state_graph(raw, _check_fn=allow_fn, **BASE_CONFIG)
        app = raw.compile()
        assert getattr(app, "_connexum_governed", False) is True

    def test_idempotency_does_not_double_wrap(self):
        raw = MockStateGraph()
        wrap_state_graph(raw, _check_fn=allow_fn, **BASE_CONFIG)
        original_add_node = raw.add_node
        wrap_state_graph(raw, _check_fn=allow_fn, **BASE_CONFIG)
        # Second call should be no-op due to idempotency guard
        assert raw.add_node is original_add_node

    def test_connexum_governed_marker_set(self):
        raw = MockStateGraph()
        wrap_state_graph(raw, _check_fn=allow_fn, **BASE_CONFIG)
        assert getattr(raw, "_connexum_governed", False) is True


# ===========================================================================
# wrap_pregel()
# ===========================================================================

class TestWrapPrege:
    """Tests for wrap_pregel() convenience function."""

    def test_invoke_allow_delegates(self):
        pregel = MockPregelRunnable()
        wrap_pregel(pregel, _check_fn=allow_fn, **BASE_CONFIG)
        result = pregel.invoke({"messages": ["hello"]})
        assert result["output"] == "invoke-result"
        assert pregel.invoke_call_count == 1

    def test_invoke_deny_raises(self):
        pregel = MockPregelRunnable()
        wrap_pregel(pregel, _check_fn=deny_fn, **BASE_CONFIG)
        with pytest.raises(GovernanceViolation):
            pregel.invoke({"messages": ["hello"]})
        assert pregel.invoke_call_count == 0

    def test_invoke_pending_raises(self):
        pregel = MockPregelRunnable()
        wrap_pregel(pregel, _check_fn=pending_fn, **BASE_CONFIG)
        with pytest.raises(GovernancePendingApproval):
            pregel.invoke({})

    @pytest.mark.asyncio
    async def test_ainvoke_allow_delegates(self):
        pregel = MockPregelRunnable()
        wrap_pregel(pregel, _check_fn=allow_fn, **BASE_CONFIG)
        result = await pregel.ainvoke({"messages": ["hello"]})
        assert result["output"] == "ainvoke-result"
        assert pregel.ainvoke_call_count == 1

    @pytest.mark.asyncio
    async def test_ainvoke_deny_raises(self):
        pregel = MockPregelRunnable()
        wrap_pregel(pregel, _check_fn=deny_fn, **BASE_CONFIG)
        with pytest.raises(GovernanceViolation):
            await pregel.ainvoke({"messages": ["hello"]})

    def test_invoke_action_namespace(self):
        captures = []
        pregel = MockPregelRunnable()
        wrap_pregel(
            pregel,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        pregel.invoke({})
        assert captures[0]["action"] == "framework.langgraph.invoke"

    def test_state_dict_messages_key_extracted(self):
        captures = []
        pregel = MockPregelRunnable()
        wrap_pregel(
            pregel,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        pregel.invoke({"messages": ["hello world"]})
        assert "hello world" in captures[0]["messagePreview"]

    def test_state_dict_input_key_extracted(self):
        captures = []
        pregel = MockPregelRunnable()
        wrap_pregel(
            pregel,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        pregel.invoke({"input": "query text"})
        assert "query text" in captures[0]["messagePreview"]

    def test_string_state_preview(self):
        captures = []
        pregel = MockPregelRunnable()
        wrap_pregel(
            pregel,
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        pregel.invoke("plain string state")
        assert "plain string state" in captures[0]["messagePreview"]

    def test_idempotency_does_not_double_wrap(self):
        pregel = MockPregelRunnable()
        wrap_pregel(pregel, _check_fn=allow_fn, **BASE_CONFIG)
        original_invoke = pregel.invoke
        wrap_pregel(pregel, _check_fn=allow_fn, **BASE_CONFIG)
        assert pregel.invoke is original_invoke

    def test_connexum_governed_marker_set(self):
        pregel = MockPregelRunnable()
        wrap_pregel(pregel, _check_fn=allow_fn, **BASE_CONFIG)
        assert getattr(pregel, "_connexum_governed", False) is True


# ===========================================================================
# create_governed_langgraph() factory
# ===========================================================================

class TestCreateGovernedLangGraph:
    """Tests for create_governed_langgraph() factory."""

    def test_returns_governed_langgraph_instance(self):
        instance = create_governed_langgraph(**BASE_CONFIG, _check_fn=allow_fn)
        assert isinstance(instance, GovernedLangGraphInstance)

    def test_missing_url_raises(self):
        with pytest.raises(ValueError, match="governance_server_url is required"):
            create_governed_langgraph(
                governance_server_url="",
                license_key="key",
                _check_fn=allow_fn,
            )

    def test_missing_key_raises(self):
        with pytest.raises(ValueError, match="license_key is required"):
            create_governed_langgraph(
                governance_server_url="http://localhost:3200",
                license_key="",
                _check_fn=allow_fn,
            )

    def test_governed_state_graph_returns_govstategraph(self):
        instance = create_governed_langgraph(**BASE_CONFIG, _check_fn=allow_fn)
        raw = MockStateGraph()
        result = instance.governed_state_graph(raw)
        assert isinstance(result, GovernedStateGraph)

    def test_wrap_graph_sets_governed_marker(self):
        instance = create_governed_langgraph(**BASE_CONFIG, _check_fn=allow_fn)
        raw = MockStateGraph()
        instance.wrap_graph(raw)
        assert getattr(raw, "_connexum_governed", False) is True

    def test_wrap_pregel_sets_governed_marker(self):
        instance = create_governed_langgraph(**BASE_CONFIG, _check_fn=allow_fn)
        pregel = MockPregelRunnable()
        instance.wrap_pregel(pregel)
        assert getattr(pregel, "_connexum_governed", False) is True

    def test_wrap_graph_governance_fires_on_compile_invoke(self):
        captures = []
        instance = create_governed_langgraph(
            _check_fn=make_capture_fn("ALLOW", captures),
            **BASE_CONFIG,
        )
        raw = MockStateGraph()
        instance.wrap_graph(raw)
        app = raw.compile()
        app.invoke({})
        assert any(c["action"] == "framework.langgraph.invoke" for c in captures)


# ===========================================================================
# LangChain adapter re-export compatibility
# ===========================================================================

class TestLangChainAdapterReExport:
    """Verify wrap_state_graph re-export from langchain_integration still works."""

    def test_langchain_wrap_state_graph_importable(self):
        from connexum_governance.integrations.langchain_integration import (
            wrap_state_graph as lc_wrap_state_graph,
        )
        assert callable(lc_wrap_state_graph)

    def test_langchain_wrap_state_graph_governs_add_node(self):
        from connexum_governance.integrations.langchain_integration import (
            wrap_state_graph as lc_wrap_state_graph,
        )
        raw = MockStateGraph()
        lc_wrap_state_graph(raw, _check_fn=allow_fn, **BASE_CONFIG)
        results = []

        def my_fn(state):
            results.append(True)
            return state

        raw.add_node("agent", my_fn)
        wrapped_fn = raw._nodes["agent"]
        wrapped_fn({})
        assert len(results) == 1

    def test_langchain_wrap_state_graph_deny_raises(self):
        from connexum_governance.integrations.langchain_integration import (
            wrap_state_graph as lc_wrap_state_graph,
        )
        raw = MockStateGraph()
        lc_wrap_state_graph(raw, _check_fn=deny_fn, **BASE_CONFIG)
        raw.add_node("agent", lambda state: state)
        wrapped_fn = raw._nodes["agent"]
        with pytest.raises(GovernanceViolation):
            wrapped_fn({})

    def test_create_governed_langchain_wrap_graph_works(self):
        """create_governed_langchain().wrap_graph() still delegates correctly."""
        from connexum_governance.integrations.langchain_integration import (
            create_governed_langchain,
        )
        gov = create_governed_langchain(
            _check_fn=allow_fn, **BASE_CONFIG
        )
        raw = MockStateGraph()
        gov.wrap_graph(raw)
        assert getattr(raw, "_connexum_governed", False) is True

    def test_create_governed_langchain_wrap_graph_deny_raises(self):
        """wrap_graph() from langchain instance blocks on DENY."""
        from connexum_governance.integrations.langchain_integration import (
            create_governed_langchain,
        )
        gov = create_governed_langchain(_check_fn=deny_fn, **BASE_CONFIG)
        raw = MockStateGraph()
        gov.wrap_graph(raw)
        raw.add_node("agent", lambda state: state)
        wrapped_fn = raw._nodes["agent"]
        with pytest.raises(GovernanceViolation):
            wrapped_fn({})
