"""Tests for Bedrock AgentCore governance integration (B2-06).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak / PHI in action result -- output classifier
3. PHI ingress refusal -- non-BAA region with HIPAA pack
4. Provider compliance -- unapproved model blocks llm_call
5. Subscription gate -- governance server DENY at agent_start
6. Audit chain append -- canonical events round-trip
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.bedrock_agentcore import (
    BEDROCK_BAA_REGIONS,
    BedrockAgentCoreGovernance,
    BedrockBaaRegionError,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-bac-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-bac-002"}
SUB_DENY = {
    "decision": "DENY",
    "reason": "Subscription inactive or expired",
    "auditId": "aud-bac-003",
}

_APPROVED_MODELS = [
    "anthropic.claude-3-5-sonnet-20241022-v2:0",
    "amazon.titan-text-express-v1",
]
_APPROVED_REGIONS = ["us-east-1", "us-west-2"]


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


_SENTINEL = object()


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    approved_models: list[str] | None = None,
    approved_regions: Any = _SENTINEL,
    enforce_hipaa_baa_region: bool = True,
) -> BedrockAgentCoreGovernance:
    client = make_client(transport, enforce=enforce)
    regions = _APPROVED_REGIONS if approved_regions is _SENTINEL else approved_regions
    return BedrockAgentCoreGovernance(
        client=client,
        agent_id="AGENT123456",
        approved_models=approved_models if approved_models is not None else _APPROVED_MODELS,
        approved_regions=regions,
        sensitive_action_groups=["execute_code", "write_file"],
        enforce_hipaa_baa_region=enforce_hipaa_baa_region,
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestBedrockAgentCoreHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            "sess-001",
            pack_binding=["soc2"],
            region="us-east-1",
        )
        assert decision.allowed
        assert "sess-001" in adapter._sessions

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], region="us-east-1")
        decision = adapter.tool_call("sess-001", "web_search", {"query": "governance"})
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], region="us-east-1")
        adapter.tool_call("sess-001", "search", {})
        adapter.tool_result("sess-001", "search", "Clean search results")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], region="us-east-1")
        decision = adapter.llm_call(
            "sess-001",
            "anthropic.claude-3-5-sonnet-20241022-v2:0",
            messages=[{"role": "user", "content": "Hello"}],
        )
        assert decision.allowed

    def test_llm_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], region="us-east-1")
        adapter.llm_call("sess-001", "anthropic.claude-3-5-sonnet-20241022-v2:0", [])
        adapter.llm_result(
            "sess-001",
            "anthropic.claude-3-5-sonnet-20241022-v2:0",
            "Here is the summary.",
        )
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_clean(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-001", pack_binding=["soc2"], region="us-east-1")
        adapter.agent_end("sess-001", success=True, summary="Complete")
        assert "sess-001" not in adapter._sessions

    def test_full_run_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("sess-full", pack_binding=["hipaa"], region="us-east-1")
        adapter.tool_call("sess-full", "kb_retrieve", {"query": "patient info"})
        adapter.tool_result("sess-full", "kb_retrieve", "General info returned")
        adapter.llm_call(
            "sess-full",
            "anthropic.claude-3-5-sonnet-20241022-v2:0",
            [{"role": "user", "content": "Summarise"}],
        )
        adapter.llm_result(
            "sess-full",
            "anthropic.claude-3-5-sonnet-20241022-v2:0",
            "Here is the summary.",
        )
        adapter.agent_end("sess-full", success=True)


# ---------------------------------------------------------------------------
# 2. PHI in action result -- output classifier
# ---------------------------------------------------------------------------

class TestBedrockAgentCoreSecretLeak:
    def test_phi_in_action_result_flags_classifier(self, capsys):
        """PHI in action result triggers output classifier warning."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-g2", pack_binding=["soc2"], region="us-east-1")
        adapter.tool_call("sess-g2", "db", {})
        adapter.tool_result(
            "sess-g2",
            "db",
            "ssn=123-45-6789 patient_id=ABC",
            success=True,
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_knowledge_base_phi_flagged(self, capsys):
        """Knowledge base retrieval result with PHI triggers classifier."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-kb", pack_binding=["hipaa"], region="us-east-1")
        adapter.tool_call("sess-kb", "kb_search", {})
        adapter.tool_result(
            "sess-kb",
            "kb_search",
            "Patient mrn=XYZ123 diagnosis=cancer",
            is_knowledge_base=True,
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err
        assert "knowledge_base=True" in captured.err

    def test_phi_report_result_marks_failure(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-rep", pack_binding=["soc2"], region="us-east-1")
        adapter.tool_call("sess-rep", "query", {})
        adapter.tool_result("sess-rep", "query", "npi=1234567890 mrn=ABC")

        assert any(r["success"] is False for r in reported)


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- non-BAA region with HIPAA pack
# ---------------------------------------------------------------------------

class TestBedrockAgentCorePhiIngress:
    def test_hipaa_in_non_baa_region_raises(self):
        """HIPAA-bound session in non-BAA region raises BedrockBaaRegionError."""
        # approved_regions=None so region allowlist doesn't block before HIPAA BAA check
        adapter = _adapter(_transport(), enforce_hipaa_baa_region=True, approved_regions=None)
        with pytest.raises(BedrockBaaRegionError) as exc_info:
            adapter.agent_start(
                "sess-baa",
                pack_binding=["hipaa"],
                region="ap-northeast-1",  # Not in BAA regions
            )
        assert "ap-northeast-1" in str(exc_info.value)
        assert "BAA" in str(exc_info.value)

    def test_hipaa_in_baa_region_allowed(self):
        """HIPAA-bound session in BAA-covered region is allowed."""
        adapter = _adapter(_transport(), enforce_hipaa_baa_region=True)
        decision = adapter.agent_start(
            "sess-baa-ok",
            pack_binding=["hipaa"],
            region="us-east-1",
        )
        assert decision.allowed

    def test_non_hipaa_pack_in_any_region_allowed(self):
        """Non-HIPAA pack can use any approved region."""
        adapter = _adapter(
            _transport(),
            approved_regions=None,
            enforce_hipaa_baa_region=True,
        )
        decision = adapter.agent_start(
            "sess-soc2",
            pack_binding=["soc2"],
            region="ap-northeast-1",
        )
        assert decision.allowed

    def test_region_not_in_approved_list_denied(self):
        """Region outside approved_regions list is denied."""
        adapter = _adapter(
            _transport(),
            approved_regions=["us-east-1"],
            enforce_hipaa_baa_region=False,
        )
        decision = adapter.agent_start(
            "sess-region",
            pack_binding=["soc2"],
            region="eu-west-1",
        )
        assert decision.denied
        assert "eu-west-1" in decision.reason


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved model blocks llm_call
# ---------------------------------------------------------------------------

class TestBedrockAgentCoreProviderCompliance:
    def test_unapproved_model_denied(self):
        """Model not in approved_models is denied at llm_call."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-model", pack_binding=["soc2"], region="us-east-1")
        decision = adapter.llm_call(
            "sess-model",
            "meta.llama3-8b-instruct-v1:0",  # not in approved list
            messages=[],
        )
        assert decision.denied
        assert "meta.llama3-8b-instruct-v1:0" in decision.reason

    def test_approved_model_passes(self):
        """Approved model passes provider compliance check."""
        adapter = _adapter(_transport())
        adapter.agent_start("sess-model-ok", pack_binding=["soc2"], region="us-east-1")
        decision = adapter.llm_call(
            "sess-model-ok",
            "anthropic.claude-3-5-sonnet-20241022-v2:0",
            messages=[],
        )
        assert decision.allowed

    def test_no_approved_models_list_allows_any(self):
        """When approved_models=[], all models are allowed (empty list = no restriction)."""
        client = make_client(_transport())
        adapter = BedrockAgentCoreGovernance(
            client=client,
            agent_id="AGENT_X",
            approved_models=[],  # empty = no restriction
            approved_regions=None,
        )
        adapter.agent_start("sess-open", pack_binding=["soc2"], region="us-east-1")
        decision = adapter.llm_call("sess-open", "any-model-id", [])
        assert decision.allowed

    def test_bedrock_agent_id_forwarded_in_check_action(self):
        """bedrockAgentId is included in governance check_action input."""
        captured: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/check-action":
                captured.append(json.loads(request.content))
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        client = make_client(t)
        adapter = BedrockAgentCoreGovernance(
            client=client,
            agent_id="MY_AGENT_456",
            approved_regions=None,
        )
        adapter.agent_start("sess-id-fwd", pack_binding=["soc2"], region="us-east-1")

        assert captured[0]["input"]["bedrockAgentId"] == "MY_AGENT_456"


# ---------------------------------------------------------------------------
# 5. Subscription gate -- governance server DENY at agent_start
# ---------------------------------------------------------------------------

class TestBedrockAgentCoreSubscriptionGate:
    def test_subscription_deny_at_agent_start(self):
        """Governance DENY at agent_start is returned as denied decision."""
        transport = _transport(**{"/api/v1/governance/check-action": SUB_DENY})
        adapter = _adapter(transport, enforce=False)
        decision = adapter.agent_start(
            "sess-sub",
            pack_binding=["soc2"],
            region="us-east-1",
        )
        assert decision.denied
        assert "subscription" in decision.reason.lower() or "inactive" in decision.reason.lower()

    def test_tool_call_governance_deny(self):
        """Governance DENY at tool_call is returned."""
        transport = _transport(**{"/api/v1/governance/check-action": DENY})
        adapter = _adapter(transport, enforce=False)
        adapter._sessions["sess-deny"] = {"pack_binding": ["soc2"], "region": "us-east-1"}
        decision = adapter.tool_call("sess-deny", "search", {})
        assert decision.denied


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip
# ---------------------------------------------------------------------------

class TestBedrockAgentCoreAuditChain:
    def test_tool_result_uses_audit_id_from_tool_call(self):
        """audit_id from tool_call is used in tool_result report_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-audit", pack_binding=["soc2"], region="us-east-1")
        adapter.tool_call("sess-audit", "search", {"q": "test"})
        adapter.tool_result("sess-audit", "search", "results")

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-bac-001"
        assert reported[0]["success"] is True

    def test_llm_result_uses_audit_id_from_llm_call(self):
        """audit_id from llm_call is used in llm_result report_result."""
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            if request.url.path == "/api/v1/governance/check-action":
                return httpx.Response(200, json=ALLOW)
            return httpx.Response(200, json={"ok": True})

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-llm-audit", pack_binding=["hipaa"], region="us-east-1")
        adapter.llm_call(
            "sess-llm-audit",
            "anthropic.claude-3-5-sonnet-20241022-v2:0",
            [{"role": "user", "content": "hi"}],
        )
        adapter.llm_result(
            "sess-llm-audit",
            "anthropic.claude-3-5-sonnet-20241022-v2:0",
            "Hello!",
        )

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-bac-001"

    def test_agent_end_fires_terminal_check_action(self):
        """agent_end fires check_action to seal terminal audit event."""
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("sess-end-audit", pack_binding=["soc2"], region="us-east-1")
        adapter.agent_end("sess-end-audit", success=True)

        action_calls = [c for c in calls if "check-action" in c]
        assert len(action_calls) >= 2

    def test_baa_regions_constant_correct(self):
        """BAA regions constant includes expected AWS regions."""
        assert "us-east-1" in BEDROCK_BAA_REGIONS
        assert "us-west-2" in BEDROCK_BAA_REGIONS
        assert "eu-west-1" in BEDROCK_BAA_REGIONS
        assert "ap-southeast-2" in BEDROCK_BAA_REGIONS
        # Non-BAA regions should NOT be in the list
        assert "ap-northeast-1" not in BEDROCK_BAA_REGIONS
