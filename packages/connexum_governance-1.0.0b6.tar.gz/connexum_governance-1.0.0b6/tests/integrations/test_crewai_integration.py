"""
Tests for connexum_governance.integrations.crewai_integration

CrewAI Python framework adapter -- Sprint 5, WS-09.

All tests run offline -- no real crewai package required.
CrewAI primitives are mocked via minimal class implementations.
Governance server calls are injected via the _check_fn parameter.

Coverage:

  GovernanceCrewAITool:
    _run():
      - ALLOW -> calls underlying tool._run(), returns result
      - DENY -> raises GovernanceViolation (raise_on_deny=True)
      - DENY -> returns '[GOVERNANCE DENIED] ...' (raise_on_deny=False)
      - PENDING -> raises GovernancePendingApproval (raise_on_deny=True)
      - PENDING (no approvalId) -> raises GovernanceViolation
      - Action namespace 'framework.crewai.tool_run' sent
      - Tool name forwarded to governance check
      - Underlying tool NOT called on DENY
      - String input forwarded as messagePreview
      - Dict input JSON-serialized as messagePreview
      - None input handled as empty string
      - Fallback to tool.run() when ._run() not available
    _arun():
      - ALLOW -> calls underlying tool._arun(), returns result
      - DENY -> raises GovernanceViolation
      - PENDING -> raises GovernancePendingApproval
      - Fallback to _run() when _arun() not available
    run() public shim:
      - Delegates to _run()
    Constructor validation:
      - tool=None -> raises ValueError
      - tool.name missing -> raises ValueError
      - missing governance_server_url -> raises ValueError
      - missing license_key -> raises ValueError
    Attributes:
      - .name matches underlying tool
      - .description matches underlying tool

  governed_crewai_tool() factory:
    - Returns GovernanceCrewAITool instance
    - ALLOW -> underlying tool called
    - DENY -> raises GovernanceViolation

  make_governance_step_callback():
    - Returns callable
    - ALLOW -> callback returns without raising
    - DENY with raise_on_deny=False -> logs, does NOT raise (observability mode)
    - DENY with raise_on_deny=True -> raises GovernanceViolation
    - PENDING with raise_on_deny=True -> raises GovernancePendingApproval
    - Action namespace 'framework.crewai.agent_step' sent
    - String step_output forwarded as messagePreview
    - step_output with .output attribute extracted
    - step_output=None handled as empty string

  make_governance_task_callback():
    - Returns callable
    - ALLOW -> callback returns without raising
    - DENY with raise_on_deny=False -> logs, does NOT raise (observability mode)
    - DENY with raise_on_deny=True -> raises GovernanceViolation
    - Action namespace 'framework.crewai.task_complete' sent
    - String task_output forwarded as messagePreview
    - task_output with .raw attribute extracted
    - task_output with .result attribute extracted
    - task_output=None handled as empty string

  wrap_agent():
    - Wraps all tools on agent with GovernanceCrewAITool
    - Agent with no tools -- returns agent unchanged
    - Idempotency: already-wrapped tools not double-wrapped
    - Tool without .name -- kept unwrapped with warning

  wrap_crew():
    - Wraps all agents' tools in the crew
    - Injects step_callback
    - Injects task_callback
    - Wraps kickoff() with pre-kickoff governance check
    - kickoff() ALLOW -> delegates to original kickoff
    - kickoff() DENY -> raises GovernanceViolation before kickoff runs
    - Existing step_callback is chained (not replaced)
    - Existing task_callback is chained (not replaced)
    - Action namespace 'framework.crewai.crew_kickoff' sent on kickoff()
    - Async kickoff_async() wrapped with async governance check
    - kickoff_async() DENY -> raises GovernanceViolation

  create_governed_crewai() factory:
    - Returns GovernedCrewAIInstance
    - .governed_tool() returns GovernanceCrewAITool
    - .wrap_agent() wraps agent tools
    - .wrap_crew() runs full crew wrapping
    - .make_step_callback() returns callable
    - .make_task_callback() returns callable
    - Constructor validation: missing governance_server_url -> ValueError

  Fail-open / fail-closed:
    - GovernanceCrewAITool._run(): governance server raises -> exception propagates
    - step_callback: governance server raises -> exception propagates
    - wrap_crew kickoff: governance server raises -> exception propagates
"""

from __future__ import annotations

import asyncio
from typing import Any, Optional

import pytest

from connexum_governance.integrations.crewai_integration import (
    GovernanceCrewAITool,
    governed_crewai_tool,
    make_governance_step_callback,
    make_governance_task_callback,
    wrap_agent,
    wrap_crew,
    create_governed_crewai,
    GovernedCrewAIInstance,
)
from connexum_governance.integrations.langchain_errors import (
    GovernanceViolation,
    GovernancePendingApproval,
)


# ---------------------------------------------------------------------------
# Shared decision constants
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-crew-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-crew-002"}
PENDING = {
    "decision": "REQUIRE_APPROVAL",
    "approvalId": "appr-crew-001",
    "auditId": "aud-crew-003",
}
PENDING_NO_ID = {
    "decision": "REQUIRE_APPROVAL",
    "approvalId": None,
    "auditId": "aud-crew-004",
}


# ---------------------------------------------------------------------------
# Mock CrewAI primitives
# ---------------------------------------------------------------------------

class MockBaseTool:
    """Minimal CrewAI BaseTool."""
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
        self._call_log = []

    def _run(self, tool_input: Any = "", **kwargs: Any) -> str:
        self._call_log.append(tool_input)
        return f"result:{tool_input}"


class MockBaseToolWithArun(MockBaseTool):
    """BaseTool with async _arun."""
    async def _arun(self, tool_input: Any = "", **kwargs: Any) -> str:
        self._call_log.append(tool_input)
        return f"async_result:{tool_input}"


class MockBaseToolRunOnly:
    """BaseTool without _run but with .run() (fallback). Does not inherit MockBaseTool."""
    def __init__(self, name: str):
        self.name = name
        self.description = ""
        self._call_log = []

    def run(self, tool_input: Any = "", **kwargs: Any) -> str:
        self._call_log.append(tool_input)
        return f"run_result:{tool_input}"

    # No _run method -- must fall back to .run()


class MockTaskOutput:
    """Minimal CrewAI TaskOutput."""
    def __init__(self, raw: str = "task_result"):
        self.raw = raw


class MockStepOutput:
    """Minimal CrewAI step output."""
    def __init__(self, output: str = "step_result"):
        self.output = output


class MockAgent:
    """Minimal CrewAI Agent."""
    def __init__(self, tools: Optional[list] = None):
        self.tools = tools or []


class MockCrew:
    """Minimal CrewAI Crew."""
    def __init__(self, agents: Optional[list] = None):
        self.agents = agents or []
        self.step_callback = None
        self.task_callback = None
        self._kickoff_called = False
        self._kickoff_async_called = False

    def kickoff(self, *args: Any, **kwargs: Any) -> str:
        self._kickoff_called = True
        return "crew_result"

    async def kickoff_async(self, *args: Any, **kwargs: Any) -> str:
        self._kickoff_async_called = True
        return "crew_async_result"


# ---------------------------------------------------------------------------
# Check function factories
# ---------------------------------------------------------------------------

def make_sync_check(decision: dict):
    def _check_fn(url: str, body: dict) -> dict:
        return decision
    return _check_fn


def make_async_check(decision: dict):
    async def _check_fn(url: str, body: dict) -> dict:
        return decision
    return _check_fn


def make_capturing_check(decision: dict):
    captured = {"body": None}

    def _check_fn(url: str, body: dict) -> dict:
        captured["body"] = body
        return decision

    return _check_fn, captured


def make_raising_check(exc: Exception):
    def _check_fn(url: str, body: dict) -> dict:
        raise exc
    return _check_fn


# ---------------------------------------------------------------------------
# Shared config
# ---------------------------------------------------------------------------

URL = "http://localhost:3200"
KEY = "test-license-key"
PACKS = ["hipaa"]


# ===========================================================================
# GovernanceCrewAITool constructor tests
# ===========================================================================

class TestGovernanceCrewAIToolConstructor:
    def test_tool_none_raises(self):
        with pytest.raises(ValueError, match="tool is required"):
            GovernanceCrewAITool(
                tool=None,
                governance_server_url=URL,
                license_key=KEY,
            )

    def test_tool_missing_name_raises(self):
        class BadTool:
            pass  # no .name
        with pytest.raises(ValueError, match="tool.name is required"):
            GovernanceCrewAITool(
                tool=BadTool(),
                governance_server_url=URL,
                license_key=KEY,
            )

    def test_tool_empty_name_raises(self):
        class EmptyNameTool:
            name = ""
        with pytest.raises(ValueError, match="tool.name is required"):
            GovernanceCrewAITool(
                tool=EmptyNameTool(),
                governance_server_url=URL,
                license_key=KEY,
            )

    def test_missing_url_raises(self):
        tool = MockBaseTool(name="search")
        with pytest.raises(ValueError, match="governance_server_url"):
            GovernanceCrewAITool(tool=tool, governance_server_url="", license_key=KEY)

    def test_missing_key_raises(self):
        tool = MockBaseTool(name="search")
        with pytest.raises(ValueError, match="license_key"):
            GovernanceCrewAITool(tool=tool, governance_server_url=URL, license_key="")

    def test_name_attribute(self):
        tool = MockBaseTool(name="web_search", description="Searches the web")
        gt = GovernanceCrewAITool(tool=tool, governance_server_url=URL, license_key=KEY)
        assert gt.name == "web_search"

    def test_description_attribute(self):
        tool = MockBaseTool(name="search", description="Search tool")
        gt = GovernanceCrewAITool(tool=tool, governance_server_url=URL, license_key=KEY)
        assert gt.description == "Search tool"


# ===========================================================================
# GovernanceCrewAITool._run tests
# ===========================================================================

class TestGovernanceCrewAIToolRun:
    def _make_tool(self, decision: dict, raise_on_deny: bool = True, tool_cls=None):
        underlying = (tool_cls or MockBaseTool)(name="crew_tool")
        return GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
            raise_on_deny=raise_on_deny,
            _check_fn=make_sync_check(decision),
        ), underlying

    def test_allow_calls_underlying_run(self):
        gt, underlying = self._make_tool(ALLOW)
        result = gt._run("input_text")
        assert result == "result:input_text"
        assert underlying._call_log == ["input_text"]

    def test_deny_raises_governance_violation(self):
        gt, _ = self._make_tool(DENY)
        with pytest.raises(GovernanceViolation) as exc_info:
            gt._run("sensitive_input")
        assert exc_info.value.decision == "DENY"
        assert exc_info.value.reason == "Policy violation"

    def test_deny_underlying_not_called(self):
        gt, underlying = self._make_tool(DENY)
        with pytest.raises(GovernanceViolation):
            gt._run("input")
        assert underlying._call_log == []

    def test_deny_no_raise_returns_denied_string(self):
        gt, underlying = self._make_tool(DENY, raise_on_deny=False)
        result = gt._run("input")
        assert "[GOVERNANCE DENIED]" in result
        assert underlying._call_log == []

    def test_pending_raises_governance_pending(self):
        gt, _ = self._make_tool(PENDING)
        with pytest.raises(GovernancePendingApproval) as exc_info:
            gt._run("input")
        assert exc_info.value.approval_id == "appr-crew-001"

    def test_pending_no_id_raises_violation(self):
        gt, _ = self._make_tool(PENDING_NO_ID)
        with pytest.raises(GovernanceViolation):
            gt._run("input")

    def test_action_namespace_tool_run(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockBaseTool(name="action_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt._run("input")
        assert captured["body"]["action"] == "framework.crewai.tool_run"

    def test_tool_name_sent_in_body(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockBaseTool(name="specific_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt._run("input")
        assert "specific_tool" in captured["body"]["tools"]

    def test_string_input_as_message_preview(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockBaseTool(name="tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt._run("search for retention policy")
        assert "search for retention policy" in captured["body"]["messagePreview"]

    def test_dict_input_json_serialized(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockBaseTool(name="tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt._run({"query": "HIPAA requirements"})
        preview = captured["body"]["messagePreview"]
        assert "HIPAA" in preview

    def test_none_input_handled_as_empty(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockBaseTool(name="tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        gt._run(None)
        assert captured["body"]["messagePreview"] == ""

    def test_fallback_to_run_method_when_no_run_dunder(self):
        """Tools without _run but with .run() should work via fallback."""
        underlying = MockBaseToolRunOnly(name="run_only_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        result = gt._run("input")
        assert result == "run_result:input"

    def test_public_run_delegates_to_run_dunder(self):
        underlying = MockBaseTool(name="pub_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        result = gt.run("public_input")
        assert result == "result:public_input"


# ===========================================================================
# GovernanceCrewAITool._arun tests
# ===========================================================================

class TestGovernanceCrewAIToolArun:
    @pytest.mark.asyncio
    async def test_allow_calls_underlying_arun(self):
        underlying = MockBaseToolWithArun(name="async_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(ALLOW),
        )
        result = await gt._arun("async_input")
        assert result == "async_result:async_input"

    @pytest.mark.asyncio
    async def test_deny_raises_governance_violation(self):
        underlying = MockBaseToolWithArun(name="async_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(DENY),
        )
        with pytest.raises(GovernanceViolation):
            await gt._arun("input")

    @pytest.mark.asyncio
    async def test_pending_raises_governance_pending(self):
        underlying = MockBaseToolWithArun(name="async_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(PENDING),
        )
        with pytest.raises(GovernancePendingApproval):
            await gt._arun("input")

    @pytest.mark.asyncio
    async def test_fallback_to_run_when_no_arun(self):
        underlying = MockBaseTool(name="sync_only")  # no _arun
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_async_check(ALLOW),
        )
        result = await gt._arun("sync_fallback_input")
        assert result == "result:sync_fallback_input"

    @pytest.mark.asyncio
    async def test_arun_action_namespace(self):
        check_fn, captured = make_capturing_check(ALLOW)
        underlying = MockBaseToolWithArun(name="ns_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        await gt._arun("input")
        assert captured["body"]["action"] == "framework.crewai.tool_run"


# ===========================================================================
# governed_crewai_tool() factory tests
# ===========================================================================

class TestGovernedCrewAIToolFactory:
    def test_returns_governance_crewai_tool_instance(self):
        tool = MockBaseTool(name="factory_tool")
        gt = governed_crewai_tool(
            tool=tool,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert isinstance(gt, GovernanceCrewAITool)

    def test_allow_underlying_called(self):
        underlying = MockBaseTool(name="factory_tool")
        gt = governed_crewai_tool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        result = gt._run("factory_input")
        assert result == "result:factory_input"

    def test_deny_raises(self):
        tool = MockBaseTool(name="factory_tool")
        gt = governed_crewai_tool(
            tool=tool,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(DENY),
        )
        with pytest.raises(GovernanceViolation):
            gt._run("input")


# ===========================================================================
# make_governance_step_callback tests
# ===========================================================================

class TestMakeGovernanceStepCallback:
    def _make_callback(self, decision: dict, raise_on_deny: bool = False):
        return make_governance_step_callback(
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
            raise_on_deny=raise_on_deny,
            _check_fn=make_sync_check(decision),
        )

    def test_returns_callable(self):
        cb = self._make_callback(ALLOW)
        assert callable(cb)

    def test_allow_does_not_raise(self):
        cb = self._make_callback(ALLOW)
        cb("step_output")  # should not raise

    def test_deny_no_raise_does_not_raise_by_default(self):
        cb = self._make_callback(DENY, raise_on_deny=False)
        cb("step_output")  # observability mode -- no raise

    def test_deny_with_raise_on_deny_raises(self):
        cb = self._make_callback(DENY, raise_on_deny=True)
        with pytest.raises(GovernanceViolation):
            cb("step_output")

    def test_pending_with_raise_on_deny_raises(self):
        cb = make_governance_step_callback(
            governance_server_url=URL,
            license_key=KEY,
            raise_on_deny=True,
            _check_fn=make_sync_check(PENDING),
        )
        with pytest.raises(GovernancePendingApproval):
            cb("step_output")

    def test_action_namespace_agent_step(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_step_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb("step output text")
        assert captured["body"]["action"] == "framework.crewai.agent_step"

    def test_string_output_sent_as_preview(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_step_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb("step_result_text")
        assert "step_result_text" in captured["body"]["messagePreview"]

    def test_output_with_output_attribute_extracted(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_step_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        step = MockStepOutput(output="structured_step_result")
        cb(step)
        assert "structured_step_result" in captured["body"]["messagePreview"]

    def test_none_output_handled_as_empty(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_step_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb(None)
        # Should not raise; body should have empty or minimal messagePreview
        assert captured["body"] is not None


# ===========================================================================
# make_governance_task_callback tests
# ===========================================================================

class TestMakeGovernanceTaskCallback:
    def _make_callback(self, decision: dict, raise_on_deny: bool = False):
        return make_governance_task_callback(
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=PACKS,
            raise_on_deny=raise_on_deny,
            _check_fn=make_sync_check(decision),
        )

    def test_returns_callable(self):
        cb = self._make_callback(ALLOW)
        assert callable(cb)

    def test_allow_does_not_raise(self):
        cb = self._make_callback(ALLOW)
        cb("task_output")

    def test_deny_no_raise_by_default(self):
        cb = self._make_callback(DENY, raise_on_deny=False)
        cb("task_output")  # no raise

    def test_deny_with_raise_on_deny_raises(self):
        cb = self._make_callback(DENY, raise_on_deny=True)
        with pytest.raises(GovernanceViolation):
            cb("task_output")

    def test_action_namespace_task_complete(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_task_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb("task result text")
        assert captured["body"]["action"] == "framework.crewai.task_complete"

    def test_string_output_sent_as_preview(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_task_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb("task_result_text")
        assert "task_result_text" in captured["body"]["messagePreview"]

    def test_task_output_with_raw_attribute(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_task_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        task_out = MockTaskOutput(raw="raw_task_result")
        cb(task_out)
        assert "raw_task_result" in captured["body"]["messagePreview"]

    def test_task_output_with_result_attribute(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_task_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )

        class ResultTask:
            result = "result_attr_value"

        cb(ResultTask())
        assert "result_attr_value" in captured["body"]["messagePreview"]

    def test_none_output_handled(self):
        check_fn, captured = make_capturing_check(ALLOW)
        cb = make_governance_task_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=check_fn,
        )
        cb(None)
        assert captured["body"] is not None


# ===========================================================================
# wrap_agent tests
# ===========================================================================

class TestWrapAgent:
    def test_wraps_all_tools_with_governance_tool(self):
        agent = MockAgent(tools=[
            MockBaseTool(name="search"),
            MockBaseTool(name="calculator"),
        ])
        wrap_agent(
            agent=agent,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert all(isinstance(t, GovernanceCrewAITool) for t in agent.tools)
        assert agent.tools[0].name == "search"
        assert agent.tools[1].name == "calculator"

    def test_agent_with_no_tools_returns_unchanged(self):
        agent = MockAgent(tools=[])
        result = wrap_agent(
            agent=agent,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert result is agent
        assert agent.tools == []

    def test_idempotency_already_wrapped_tools_not_double_wrapped(self):
        agent = MockAgent(tools=[MockBaseTool(name="search")])
        wrap_agent(agent=agent, governance_server_url=URL, license_key=KEY,
                   _check_fn=make_sync_check(ALLOW))
        wrap_agent(agent=agent, governance_server_url=URL, license_key=KEY,
                   _check_fn=make_sync_check(ALLOW))
        assert all(isinstance(t, GovernanceCrewAITool) for t in agent.tools)
        assert len(agent.tools) == 1

    def test_tool_without_name_kept_unwrapped(self, capsys):
        class BadTool:
            pass

        agent = MockAgent(tools=[BadTool()])
        wrap_agent(
            agent=agent,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert not isinstance(agent.tools[0], GovernanceCrewAITool)

    def test_returns_same_agent_instance(self):
        agent = MockAgent(tools=[MockBaseTool(name="t")])
        result = wrap_agent(
            agent=agent,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert result is agent


# ===========================================================================
# wrap_crew tests
# ===========================================================================

class TestWrapCrew:
    def _make_crew(self, *tool_name_sets):
        """Create a MockCrew with agents whose tools are named per tool_name_sets."""
        agents = []
        for names in tool_name_sets:
            tools = [MockBaseTool(name=n) for n in names]
            agents.append(MockAgent(tools=tools))
        return MockCrew(agents=agents)

    def test_wraps_all_agent_tools(self):
        crew = self._make_crew(["search", "calc"], ["email"])
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_sync_check(ALLOW))
        for agent in crew.agents:
            assert all(isinstance(t, GovernanceCrewAITool) for t in agent.tools)

    def test_injects_step_callback(self):
        crew = MockCrew()
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_sync_check(ALLOW))
        assert crew.step_callback is not None
        assert callable(crew.step_callback)

    def test_injects_task_callback(self):
        crew = MockCrew()
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_sync_check(ALLOW))
        assert crew.task_callback is not None
        assert callable(crew.task_callback)

    def test_kickoff_allow_delegates_to_original(self):
        crew = self._make_crew()
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_sync_check(ALLOW))
        result = crew.kickoff()
        assert result == "crew_result"
        assert crew._kickoff_called is True

    def test_kickoff_deny_raises_before_original_called(self):
        crew = self._make_crew()
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_sync_check(DENY))
        with pytest.raises(GovernanceViolation):
            crew.kickoff()
        assert crew._kickoff_called is False

    def test_kickoff_action_namespace(self):
        check_fn, captured = make_capturing_check(ALLOW)
        crew = self._make_crew()
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=check_fn)
        crew.kickoff()
        assert captured["body"]["action"] == "framework.crewai.crew_kickoff"

    def test_existing_step_callback_chained(self):
        existing_log = []

        def existing_cb(step_output):
            existing_log.append(step_output)

        crew = MockCrew()
        crew.step_callback = existing_cb
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_sync_check(ALLOW))
        crew.step_callback("test_step")
        assert "test_step" in existing_log

    def test_existing_task_callback_chained(self):
        existing_log = []

        def existing_cb(task_output):
            existing_log.append(task_output)

        crew = MockCrew()
        crew.task_callback = existing_cb
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_sync_check(ALLOW))
        crew.task_callback("test_task")
        assert "test_task" in existing_log

    @pytest.mark.asyncio
    async def test_kickoff_async_allow_delegates(self):
        crew = self._make_crew()
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_async_check(ALLOW))
        result = await crew.kickoff_async()
        assert result == "crew_async_result"
        assert crew._kickoff_async_called is True

    @pytest.mark.asyncio
    async def test_kickoff_async_deny_raises(self):
        crew = self._make_crew()
        wrap_crew(crew=crew, governance_server_url=URL, license_key=KEY,
                  _check_fn=make_async_check(DENY))
        with pytest.raises(GovernanceViolation):
            await crew.kickoff_async()
        assert crew._kickoff_async_called is False


# ===========================================================================
# create_governed_crewai factory tests
# ===========================================================================

class TestCreateGovernedCrewAI:
    def test_returns_governed_crewai_instance(self):
        gov = create_governed_crewai(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        assert isinstance(gov, GovernedCrewAIInstance)

    def test_governed_tool_returns_governance_crewai_tool(self):
        gov = create_governed_crewai(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        tool = MockBaseTool(name="factory_tool")
        gt = gov.governed_tool(tool)
        assert isinstance(gt, GovernanceCrewAITool)
        assert gt.name == "factory_tool"

    def test_wrap_agent_wraps_tools(self):
        gov = create_governed_crewai(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        agent = MockAgent(tools=[MockBaseTool(name="ag_tool")])
        gov.wrap_agent(agent)
        assert isinstance(agent.tools[0], GovernanceCrewAITool)

    def test_wrap_crew_runs_full_wrapping(self):
        gov = create_governed_crewai(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        crew = MockCrew(agents=[MockAgent(tools=[MockBaseTool(name="crew_tool")])])
        gov.wrap_crew(crew)
        assert isinstance(crew.agents[0].tools[0], GovernanceCrewAITool)
        assert crew.step_callback is not None
        assert crew.task_callback is not None

    def test_make_step_callback_returns_callable(self):
        gov = create_governed_crewai(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        cb = gov.make_step_callback()
        assert callable(cb)

    def test_make_task_callback_returns_callable(self):
        gov = create_governed_crewai(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_sync_check(ALLOW),
        )
        cb = gov.make_task_callback()
        assert callable(cb)

    def test_missing_url_raises(self):
        with pytest.raises(ValueError):
            create_governed_crewai(
                governance_server_url="",
                license_key=KEY,
            )

    def test_pack_ids_forwarded_to_tools(self):
        check_fn, captured = make_capturing_check(ALLOW)
        gov = create_governed_crewai(
            governance_server_url=URL,
            license_key=KEY,
            pack_ids=["hipaa", "soc2"],
            _check_fn=check_fn,
        )
        tool = MockBaseTool(name="pack_tool")
        gt = gov.governed_tool(tool)
        gt._run("input")
        assert "hipaa" in captured["body"]["packIds"]
        assert "soc2" in captured["body"]["packIds"]


# ===========================================================================
# Fail-open / fail-closed tests
# ===========================================================================

class TestFailBehavior:
    def test_tool_run_server_error_propagates(self):
        underlying = MockBaseTool(name="err_tool")
        gt = GovernanceCrewAITool(
            tool=underlying,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_raising_check(ConnectionError("server down")),
        )
        with pytest.raises(ConnectionError, match="server down"):
            gt._run("input")

    def test_step_callback_server_error_propagates(self):
        cb = make_governance_step_callback(
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_raising_check(ConnectionError("server down")),
        )
        with pytest.raises(ConnectionError, match="server down"):
            cb("step_output")

    def test_kickoff_server_error_propagates(self):
        crew = MockCrew()
        wrap_crew(
            crew=crew,
            governance_server_url=URL,
            license_key=KEY,
            _check_fn=make_raising_check(ConnectionError("server down")),
        )
        with pytest.raises(ConnectionError, match="server down"):
            crew.kickoff()
        assert crew._kickoff_called is False
