"""Tests for PaperclipGovernance -- B2-11 REST shim.

Six parity cases matching the canonical test surface:
  TC-1  agent_start emits agentStart event
  TC-2  tool_call / tool_result round-trip emits and closes audit chain
  TC-3  llm_call / llm_result round-trip with provider compliance check
  TC-4  pack-binding primacy -- empty binding fails closed (DENY)
  TC-5  agent_end emits agentEnd with success flag
  TC-6  deny transport -- non-enforce mode returns DENY without raising

Plus Paperclip-specific cases:
  TestPaperclipTaskTypeValidation     -- allowed_task_types enforcement
  TestPaperclipPlanStepsEnforcement   -- max_plan_steps enforcement
  TestPaperclipDelegationPolicy       -- open vs restricted delegation
  TestPaperclipReplayPolicy           -- replay from cache vs REST fallback
  TestPaperclipAuditTrail             -- dual-emission audit trail growth
  TestPaperclipInternalEventTypes     -- task/plan/delegation/action event types
  TestPaperclipPolicyBridge           -- policy_bridge callback interception
  TestPaperclipWebhook                -- wrap_webhook validation
  TestPaperclipPhiScan                -- G5/G7 PHI scan on tool call args
"""

from __future__ import annotations

import pytest

import httpx

from tests.conftest import (
    make_client,
    make_transport,
    ALLOW_RESPONSE,
    DENY_RESPONSE,
    APPROVAL_RESPONSE,
)
from connexum_governance.integrations.paperclip import (
    PaperclipGovernance,
    PaperclipPolicyBridge,
    PaperclipTaskTypeError,
    PaperclipPlanStepsError,
)
from connexum_governance.models import DecisionType, GovernanceViolation


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _allow_adapter(enforce: bool = True, **kwargs) -> PaperclipGovernance:
    transport = make_transport({
        "/api/v1/governance/check-action": ALLOW_RESPONSE,
        "/api/v1/governance/report-result": {"ok": True},
    })
    client = make_client(transport, enforce=enforce)
    return PaperclipGovernance(client=client, **kwargs)


def _deny_adapter(enforce: bool = True, **kwargs) -> PaperclipGovernance:
    transport = make_transport({
        "/api/v1/governance/check-action": DENY_RESPONSE,
        "/api/v1/governance/report-result": {"ok": True},
    })
    client = make_client(transport, enforce=enforce)
    return PaperclipGovernance(client=client, **kwargs)


def _approval_adapter(enforce: bool = True, **kwargs) -> PaperclipGovernance:
    transport = make_transport({
        "/api/v1/governance/check-action": APPROVAL_RESPONSE,
        "/api/v1/governance/report-result": {"ok": True},
    })
    client = make_client(transport, enforce=enforce)
    return PaperclipGovernance(client=client, **kwargs)


# ---------------------------------------------------------------------------
# TC-1: agent_start emits agentStart event
# ---------------------------------------------------------------------------

class TestPaperclipAgentStart:
    """TC-1: agent_start -> agentStart event emitted and ALLOW returned."""

    def test_agent_start_allow(self):
        adapter = _allow_adapter()
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["hipaa", "soc2"],
        )
        assert decision.decision == DecisionType.ALLOW

    def test_agent_start_with_task_type(self):
        adapter = _allow_adapter(allowed_task_types=["analysis", "summarization"])
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["soc2"],
            task_type="analysis",
        )
        assert decision.decision == DecisionType.ALLOW

    def test_agent_start_records_audit_trail(self):
        adapter = _allow_adapter()
        adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["hipaa"],
        )
        trail = adapter.get_audit_trail()
        assert len(trail) == 1
        assert trail[0]["eventType"] == "agentStart"

    def test_agent_start_with_model(self):
        adapter = _allow_adapter(approved_models=["claude-haiku-4-5"])
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["soc2"],
            model="claude-haiku-4-5",
        )
        assert decision.decision == DecisionType.ALLOW


# ---------------------------------------------------------------------------
# TC-2: tool_call / tool_result round-trip
# ---------------------------------------------------------------------------

class TestPaperclipToolCallRoundTrip:
    """TC-2: tool_call emits toolCall, tool_result closes audit chain."""

    def test_tool_call_allow(self):
        adapter = _allow_adapter()
        decision = adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="search_db",
            args={"query": "annual report"},
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.ALLOW

    def test_tool_result_allow(self):
        adapter = _allow_adapter()
        adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="search_db",
            args={"query": "annual report"},
            pack_binding=["soc2"],
        )
        decision = adapter.tool_result(
            agent_id="pp-agent-01",
            tool_name="search_db",
            result="Q4 results attached",
            success=True,
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.ALLOW

    def test_tool_call_result_clears_pending_audit(self):
        adapter = _allow_adapter()
        adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="search_db",
            args={"query": "safe query"},
            pack_binding=["soc2"],
        )
        assert len(adapter._pending_audits) == 1
        adapter.tool_result(
            agent_id="pp-agent-01",
            tool_name="search_db",
            result="ok",
            pack_binding=["soc2"],
        )
        assert len(adapter._pending_audits) == 0

    def test_tool_call_audit_trail_grows(self):
        adapter = _allow_adapter()
        adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="lookup",
            args={"query": "doc"},
            pack_binding=["soc2"],
        )
        adapter.tool_result(
            agent_id="pp-agent-01",
            tool_name="lookup",
            result="found",
            pack_binding=["soc2"],
        )
        trail = adapter.get_audit_trail()
        assert len(trail) == 2
        event_types = [e["eventType"] for e in trail]
        assert "toolCall" in event_types
        assert "toolResult" in event_types


# ---------------------------------------------------------------------------
# TC-3: llm_call / llm_result round-trip with provider compliance
# ---------------------------------------------------------------------------

class TestPaperclipLlmCallRoundTrip:
    """TC-3: llm_call/llm_result with approved_models enforcement."""

    def test_llm_call_approved_model(self):
        adapter = _allow_adapter(approved_models=["claude-haiku-4-5"])
        decision = adapter.llm_call(
            agent_id="pp-agent-01",
            model="claude-haiku-4-5",
            messages=[{"role": "user", "content": "Summarize this."}],
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.ALLOW

    def test_llm_call_unapproved_model_enforce_raises(self):
        adapter = _allow_adapter(
            enforce=True,
            approved_models=["claude-haiku-4-5"],
        )
        with pytest.raises(GovernanceViolation):
            adapter.llm_call(
                agent_id="pp-agent-01",
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                pack_binding=["soc2"],
            )

    def test_llm_call_unapproved_model_no_enforce_returns_deny(self):
        adapter = _allow_adapter(
            enforce=False,
            approved_models=["claude-haiku-4-5"],
        )
        decision = adapter.llm_call(
            agent_id="pp-agent-01",
            model="gpt-4o",
            messages=[],
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.DENY

    def test_llm_result_closes_audit(self):
        adapter = _allow_adapter(approved_models=["claude-haiku-4-5"])
        adapter.llm_call(
            agent_id="pp-agent-01",
            model="claude-haiku-4-5",
            messages=[],
            pack_binding=["soc2"],
        )
        assert len(adapter._pending_audits) == 1
        adapter.llm_result(
            agent_id="pp-agent-01",
            model="claude-haiku-4-5",
            response_text="Summary text",
            pack_binding=["soc2"],
        )
        assert len(adapter._pending_audits) == 0

    def test_empty_approved_models_allows_any_model(self):
        adapter = _allow_adapter(approved_models=[])
        decision = adapter.llm_call(
            agent_id="pp-agent-01",
            model="any-model-whatsoever",
            messages=[],
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.ALLOW


# ---------------------------------------------------------------------------
# TC-4: pack-binding primacy -- empty binding fails closed
# ---------------------------------------------------------------------------

class TestPaperclipPackBindingPrimacy:
    """TC-4: empty packBinding -> DENY or GovernanceViolation."""

    def test_empty_binding_agent_start_enforce_raises(self):
        adapter = _allow_adapter(enforce=True)
        with pytest.raises(GovernanceViolation):
            adapter.emit_event("agentStart", {
                "agentId": "pp-agent-01",
                "packBinding": [],
            })

    def test_empty_binding_tool_call_enforce_raises(self):
        adapter = _allow_adapter(enforce=True)
        with pytest.raises(GovernanceViolation):
            adapter.tool_call(
                agent_id="pp-agent-01",
                tool_name="some_tool",
                args={},
                pack_binding=[],
            )

    def test_empty_binding_no_enforce_returns_deny(self):
        adapter = _allow_adapter(enforce=False)
        decision = adapter.emit_event("agentStart", {
            "agentId": "pp-agent-01",
            "packBinding": [],
        })
        assert decision.decision == DecisionType.DENY
        assert "pack" in decision.reason.lower()

    def test_empty_binding_records_deny_in_audit_trail(self):
        adapter = _allow_adapter(enforce=False)
        adapter.emit_event("agentStart", {
            "agentId": "pp-agent-01",
            "packBinding": [],
        })
        trail = adapter.get_audit_trail()
        assert len(trail) >= 1
        assert trail[-1]["decision"] == "DENY"

    def test_agent_end_allows_empty_binding(self):
        # agentEnd is exempt from pack-binding primacy check
        adapter = _allow_adapter()
        decision = adapter.agent_end(
            agent_id="pp-agent-01",
            success=True,
            pack_binding=[],
        )
        assert decision.decision == DecisionType.ALLOW


# ---------------------------------------------------------------------------
# TC-5: agent_end with success flag
# ---------------------------------------------------------------------------

class TestPaperclipAgentEnd:
    """TC-5: agent_end emits agentEnd event with success flag."""

    def test_agent_end_success(self):
        adapter = _allow_adapter()
        decision = adapter.agent_end(
            agent_id="pp-agent-01",
            success=True,
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.ALLOW

    def test_agent_end_failure(self):
        adapter = _allow_adapter()
        decision = adapter.agent_end(
            agent_id="pp-agent-01",
            success=False,
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.ALLOW

    def test_agent_end_records_audit_trail(self):
        adapter = _allow_adapter()
        adapter.agent_end(
            agent_id="pp-agent-01",
            success=True,
            pack_binding=["soc2"],
        )
        trail = adapter.get_audit_trail()
        assert any(e["eventType"] == "agentEnd" for e in trail)


# ---------------------------------------------------------------------------
# TC-6: deny transport -- non-enforce mode returns DENY without raising
# ---------------------------------------------------------------------------

class TestPaperclipDenyNonEnforce:
    """TC-6: deny transport with enforce=False returns DENY, no exception."""

    def test_agent_start_deny_no_enforce(self):
        adapter = _deny_adapter(enforce=False)
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.DENY

    def test_tool_call_deny_no_enforce(self):
        adapter = _deny_adapter(enforce=False)
        decision = adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="search_db",
            args={"query": "safe"},
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.DENY

    def test_llm_call_deny_no_enforce(self):
        adapter = _deny_adapter(enforce=False)
        decision = adapter.llm_call(
            agent_id="pp-agent-01",
            model="claude-haiku-4-5",
            messages=[],
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.DENY

    def test_deny_enforce_raises_governance_violation(self):
        adapter = _deny_adapter(enforce=True)
        with pytest.raises(GovernanceViolation):
            adapter.agent_start(
                agent_id="pp-agent-01",
                pack_binding=["soc2"],
            )


# ---------------------------------------------------------------------------
# Paperclip-specific: task type validation
# ---------------------------------------------------------------------------

class TestPaperclipTaskTypeValidation:
    """allowed_task_types enforcement via task/agentStart events."""

    def test_allowed_task_type_passes(self):
        adapter = _allow_adapter(allowed_task_types=["analysis", "summarization"])
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["soc2"],
            task_type="analysis",
        )
        assert decision.decision == DecisionType.ALLOW

    def test_disallowed_task_type_enforce_raises(self):
        adapter = _allow_adapter(
            enforce=True,
            allowed_task_types=["analysis"],
        )
        with pytest.raises(PaperclipTaskTypeError) as exc_info:
            adapter.agent_start(
                agent_id="pp-agent-01",
                pack_binding=["soc2"],
                task_type="code_execution",
            )
        assert exc_info.value.task_type == "code_execution"
        assert "analysis" in exc_info.value.allowed

    def test_disallowed_task_type_no_enforce_returns_deny(self):
        adapter = _allow_adapter(
            enforce=False,
            allowed_task_types=["analysis"],
        )
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["soc2"],
            task_type="code_execution",
        )
        assert decision.decision == DecisionType.DENY

    def test_empty_allowed_list_permits_any_task_type(self):
        adapter = _allow_adapter(allowed_task_types=[])
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["soc2"],
            task_type="any-type-whatsoever",
        )
        assert decision.decision == DecisionType.ALLOW

    def test_task_event_type_also_validates(self):
        adapter = _allow_adapter(
            enforce=True,
            allowed_task_types=["analysis"],
        )
        with pytest.raises(PaperclipTaskTypeError):
            adapter.emit_event("task", {
                "agentId": "pp-agent-01",
                "packBinding": ["soc2"],
                "taskType": "restricted_task",
            })


# ---------------------------------------------------------------------------
# Paperclip-specific: plan step count enforcement
# ---------------------------------------------------------------------------

class TestPaperclipPlanStepsEnforcement:
    """max_plan_steps enforcement via plan event type."""

    def test_plan_within_limit_passes(self):
        adapter = _allow_adapter(max_plan_steps=10)
        decision = adapter.emit_event("plan", {
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
            "stepCount": 5,
        })
        assert decision.decision == DecisionType.ALLOW

    def test_plan_at_limit_passes(self):
        adapter = _allow_adapter(max_plan_steps=10)
        decision = adapter.emit_event("plan", {
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
            "stepCount": 10,
        })
        assert decision.decision == DecisionType.ALLOW

    def test_plan_exceeds_limit_enforce_raises(self):
        adapter = _allow_adapter(enforce=True, max_plan_steps=10)
        with pytest.raises(PaperclipPlanStepsError) as exc_info:
            adapter.emit_event("plan", {
                "agentId": "pp-agent-01",
                "packBinding": ["soc2"],
                "stepCount": 15,
            })
        assert exc_info.value.step_count == 15
        assert exc_info.value.max_steps == 10

    def test_plan_exceeds_limit_no_enforce_returns_deny(self):
        adapter = _allow_adapter(enforce=False, max_plan_steps=10)
        decision = adapter.emit_event("plan", {
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
            "stepCount": 25,
        })
        assert decision.decision == DecisionType.DENY

    def test_plan_no_step_count_passes(self):
        # stepCount=0 (default) should not trigger the check
        adapter = _allow_adapter(max_plan_steps=10)
        decision = adapter.emit_event("plan", {
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
        })
        assert decision.decision == DecisionType.ALLOW


# ---------------------------------------------------------------------------
# Paperclip-specific: delegation policy
# ---------------------------------------------------------------------------

class TestPaperclipDelegationPolicy:
    """open vs restricted delegation_policy enforcement."""

    def test_open_policy_allows_any_delegation(self):
        adapter = _allow_adapter(
            delegation_policy="open",
            sensitive_tools=["exec_code", "write_file"],
        )
        decision = adapter.emit_event("delegation", {
            "agentId": "pp-agent-01",
            "permissions": ["exec_code", "write_file"],
        })
        assert decision.decision == DecisionType.ALLOW

    def test_restricted_policy_blocks_sensitive_permissions(self):
        adapter = _allow_adapter(
            enforce=True,
            delegation_policy="restricted",
            sensitive_tools=["exec_code", "write_file"],
        )
        with pytest.raises(GovernanceViolation):
            adapter.emit_event("delegation", {
                "agentId": "pp-agent-01",
                "permissions": ["exec_code"],
            })

    def test_restricted_policy_allows_non_sensitive_permissions(self):
        adapter = _allow_adapter(
            delegation_policy="restricted",
            sensitive_tools=["exec_code"],
        )
        decision = adapter.emit_event("delegation", {
            "agentId": "pp-agent-01",
            "permissions": ["read_file", "list_dir"],
        })
        assert decision.decision == DecisionType.ALLOW

    def test_restricted_policy_no_enforce_returns_deny(self):
        adapter = _allow_adapter(
            enforce=False,
            delegation_policy="restricted",
            sensitive_tools=["write_file"],
        )
        decision = adapter.emit_event("delegation", {
            "agentId": "pp-agent-01",
            "permissions": ["write_file"],
        })
        assert decision.decision == DecisionType.DENY

    def test_delegation_exempt_from_pack_binding_primacy(self):
        # delegation event is exempt from pack-binding primacy check
        adapter = _allow_adapter(delegation_policy="open")
        decision = adapter.emit_event("delegation", {
            "agentId": "pp-agent-01",
            # No packBinding
        })
        assert decision.decision == DecisionType.ALLOW


# ---------------------------------------------------------------------------
# Paperclip-specific: replay_policy
# ---------------------------------------------------------------------------

class TestPaperclipReplayPolicy:
    """replay_policy() returns cached decision or falls back to REST API."""

    def test_replay_returns_cached_decision(self):
        adapter = _allow_adapter()
        # Emit an event to populate the cache
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["soc2"],
        )
        audit_id = decision.audit_id
        assert audit_id is not None
        # Replay should come from cache
        replayed = adapter.replay_policy(audit_id)
        assert replayed.decision == decision.decision

    def test_replay_fallback_to_api_when_not_cached(self):
        adapter = _allow_adapter()
        # Decision not in cache -> falls back to REST API
        decision = adapter.replay_policy("uncached-decision-id")
        assert decision.decision == DecisionType.ALLOW

    def test_bridge_replay_delegates_to_adapter(self):
        adapter = _allow_adapter()
        bridge = adapter.policy_bridge(pack_binding=["soc2"])
        # Populate cache via a direct agent_start
        decision = adapter.agent_start(
            agent_id="pp-agent-01",
            pack_binding=["soc2"],
        )
        audit_id = decision.audit_id
        replayed = bridge.replay(audit_id)
        assert replayed.decision == decision.decision


# ---------------------------------------------------------------------------
# Paperclip-specific: dual-emission audit trail
# ---------------------------------------------------------------------------

class TestPaperclipAuditTrail:
    """get_audit_trail() returns internal Paperclip audit trail entries."""

    def test_audit_trail_starts_empty(self):
        adapter = _allow_adapter()
        assert adapter.get_audit_trail() == []

    def test_audit_trail_grows_with_events(self):
        adapter = _allow_adapter()
        adapter.agent_start(agent_id="pp-agent-01", pack_binding=["soc2"])
        adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="lookup",
            args={"query": "doc"},
            pack_binding=["soc2"],
        )
        adapter.tool_result(
            agent_id="pp-agent-01",
            tool_name="lookup",
            result="found",
            pack_binding=["soc2"],
        )
        trail = adapter.get_audit_trail()
        assert len(trail) == 3

    def test_audit_trail_contains_required_fields(self):
        adapter = _allow_adapter()
        adapter.agent_start(agent_id="pp-agent-01", pack_binding=["soc2"])
        entry = adapter.get_audit_trail()[0]
        assert "timestamp" in entry
        assert "eventType" in entry
        assert "decision" in entry
        assert "reason" in entry

    def test_audit_trail_excludes_pack_binding_from_context(self):
        adapter = _allow_adapter()
        adapter.agent_start(agent_id="pp-agent-01", pack_binding=["hipaa", "soc2"])
        entry = adapter.get_audit_trail()[0]
        # packBinding must not appear in the stored context (privacy)
        assert "packBinding" not in entry.get("context", {})

    def test_audit_disabled_no_entries(self):
        adapter = _allow_adapter(audit_enabled=False)
        adapter.agent_start(agent_id="pp-agent-01", pack_binding=["soc2"])
        assert adapter.get_audit_trail() == []

    def test_audit_trail_returns_copy(self):
        adapter = _allow_adapter()
        adapter.agent_start(agent_id="pp-agent-01", pack_binding=["soc2"])
        trail = adapter.get_audit_trail()
        trail.clear()
        # Internal trail must not be mutated
        assert len(adapter.get_audit_trail()) == 1


# ---------------------------------------------------------------------------
# Paperclip-specific: internal event types (task/plan/delegation/action)
# ---------------------------------------------------------------------------

class TestPaperclipInternalEventTypes:
    """Paperclip-internal event types (task/plan/delegation/action) are valid."""

    def test_task_event_type_accepted(self):
        adapter = _allow_adapter()
        decision = adapter.emit_event("task", {
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
            "taskType": "analysis",
        })
        assert decision.decision == DecisionType.ALLOW

    def test_plan_event_type_accepted(self):
        adapter = _allow_adapter()
        decision = adapter.emit_event("plan", {
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
            "stepCount": 3,
        })
        assert decision.decision == DecisionType.ALLOW

    def test_delegation_event_type_accepted(self):
        adapter = _allow_adapter()
        decision = adapter.emit_event("delegation", {
            "agentId": "pp-agent-01",
            "permissions": ["read_file"],
        })
        assert decision.decision == DecisionType.ALLOW

    def test_action_event_type_accepted(self):
        adapter = _allow_adapter()
        decision = adapter.emit_event("action", {
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
            "actionType": "write_record",
            "args": {"content": "safe content"},
        })
        assert decision.decision == DecisionType.ALLOW

    def test_unknown_event_type_raises_value_error(self):
        adapter = _allow_adapter()
        with pytest.raises(ValueError, match="Unknown Paperclip event type"):
            adapter.emit_event("unknown_event", {
                "agentId": "pp-agent-01",
                "packBinding": ["soc2"],
            })


# ---------------------------------------------------------------------------
# Paperclip-specific: policy_bridge callback interception
# ---------------------------------------------------------------------------

class TestPaperclipPolicyBridge:
    """policy_bridge() callback intercepts decisions before REST API."""

    def test_bridge_callback_intercepts_decision(self):
        from connexum_governance.models import GovernanceDecision, DecisionType
        import uuid

        intercepted = []

        def my_policy(event_type, payload):
            intercepted.append((event_type, payload.get("agentId")))
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="Python policy says OK",
                audit_id=str(uuid.uuid4()),
            )

        adapter = _allow_adapter()
        bridge = adapter.policy_bridge(
            pack_binding=["hipaa"],
            decision_callback=my_policy,
        )
        decision = bridge.decide("agentStart", {
            "agentId": "pp-agent-01",
        })
        assert decision.decision == DecisionType.ALLOW
        assert decision.reason == "Python policy says OK"
        assert len(intercepted) == 1
        assert intercepted[0] == ("agentStart", "pp-agent-01")

    def test_bridge_callback_none_falls_back_to_api(self):
        adapter = _allow_adapter()
        bridge = adapter.policy_bridge(pack_binding=["soc2"])
        decision = bridge.decide("agentStart", {
            "agentId": "pp-agent-01",
        })
        assert decision.decision == DecisionType.ALLOW

    def test_bridge_callback_exception_falls_back_to_api(self):
        def bad_policy(event_type, payload):
            raise RuntimeError("policy engine crashed")

        adapter = _allow_adapter()
        bridge = adapter.policy_bridge(
            pack_binding=["soc2"],
            decision_callback=bad_policy,
        )
        # Should fall back to REST API (ALLOW)
        decision = bridge.decide("agentStart", {
            "agentId": "pp-agent-01",
        })
        assert decision.decision == DecisionType.ALLOW

    def test_bridge_carries_pack_binding_to_adapter(self):
        """Bridge injects pack_binding into emit_event payload."""
        received_payloads = []
        original_emit = None

        adapter = _allow_adapter()
        original_emit = adapter.emit_event

        def capture_emit(event_type, payload):
            received_payloads.append(payload.copy())
            return original_emit(event_type, payload)

        adapter.emit_event = capture_emit

        bridge = adapter.policy_bridge(pack_binding=["hipaa", "gdpr"])
        bridge.decide("agentStart", {"agentId": "pp-agent-01"})

        assert len(received_payloads) >= 1
        assert received_payloads[-1].get("packBinding") == ["hipaa", "gdpr"]

    def test_bridge_is_policy_bridge_instance(self):
        adapter = _allow_adapter()
        bridge = adapter.policy_bridge(pack_binding=["soc2"])
        assert isinstance(bridge, PaperclipPolicyBridge)


# ---------------------------------------------------------------------------
# Paperclip-specific: wrap_webhook validation
# ---------------------------------------------------------------------------

class TestPaperclipWebhook:
    """wrap_webhook() validates required fields and forwards event."""

    def test_valid_webhook_payload_forwarded(self):
        adapter = _allow_adapter()
        decision = adapter.wrap_webhook({
            "eventType": "agentStart",
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
        })
        assert decision.decision == DecisionType.ALLOW

    def test_missing_event_type_raises(self):
        adapter = _allow_adapter()
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({
                "agentId": "pp-agent-01",
                "packBinding": ["soc2"],
            })

    def test_missing_agent_id_raises(self):
        adapter = _allow_adapter()
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({
                "eventType": "agentStart",
                "packBinding": ["soc2"],
            })

    def test_webhook_with_internal_event_types(self):
        adapter = _allow_adapter()
        decision = adapter.wrap_webhook({
            "eventType": "task",
            "agentId": "pp-agent-01",
            "packBinding": ["soc2"],
            "taskType": "analysis",
        })
        assert decision.decision == DecisionType.ALLOW

    def test_webhook_task_type_validation_applies(self):
        adapter = _allow_adapter(
            enforce=True,
            allowed_task_types=["analysis"],
        )
        with pytest.raises(PaperclipTaskTypeError):
            adapter.wrap_webhook({
                "eventType": "task",
                "agentId": "pp-agent-01",
                "packBinding": ["soc2"],
                "taskType": "code_execution",
            })


# ---------------------------------------------------------------------------
# Paperclip-specific: G5/G7 PHI scan on tool call args
# ---------------------------------------------------------------------------

class TestPaperclipPhiScan:
    """G5/G7 PHI scan blocks tool calls with PHI in sensitive arg keys."""

    def test_phi_in_query_arg_blocked(self):
        adapter = _allow_adapter(enforce=True)
        with pytest.raises(GovernanceViolation):
            adapter.tool_call(
                agent_id="pp-agent-01",
                tool_name="search_records",
                args={"query": "ssn: 123-45-6789"},
                pack_binding=["hipaa"],
            )

    def test_phi_in_content_arg_blocked(self):
        adapter = _allow_adapter(enforce=True)
        with pytest.raises(GovernanceViolation):
            adapter.tool_call(
                agent_id="pp-agent-01",
                tool_name="write_record",
                args={"content": "patient_id: P-12345"},
                pack_binding=["hipaa"],
            )

    def test_phi_in_non_sensitive_key_passes(self):
        # PHI in a key NOT in sensitive_arg_keys should not trigger the check
        adapter = _allow_adapter(
            sensitive_arg_keys=["query", "content"],
        )
        decision = adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="lookup",
            args={"irrelevant_key": "ssn: 123-45-6789"},
            pack_binding=["hipaa"],
        )
        assert decision.decision == DecisionType.ALLOW

    def test_safe_tool_call_passes(self):
        adapter = _allow_adapter(enforce=True)
        decision = adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="get_weather",
            args={"city": "New York"},
            pack_binding=["soc2"],
        )
        assert decision.decision == DecisionType.ALLOW

    def test_phi_in_action_event_blocked(self):
        adapter = _allow_adapter(enforce=True)
        with pytest.raises(GovernanceViolation):
            adapter.emit_event("action", {
                "agentId": "pp-agent-01",
                "packBinding": ["hipaa"],
                "actionType": "send_message",
                "args": {"message": "dob: 1990-01-01"},
            })

    def test_phi_no_enforce_returns_deny(self):
        adapter = _allow_adapter(enforce=False)
        decision = adapter.tool_call(
            agent_id="pp-agent-01",
            tool_name="search_records",
            args={"query": "npi: 1234567890"},
            pack_binding=["hipaa"],
        )
        assert decision.decision == DecisionType.DENY

    def test_sensitive_tool_blocked_regardless_of_args(self):
        adapter = _allow_adapter(
            enforce=True,
            sensitive_tools=["exec_code"],
        )
        with pytest.raises(GovernanceViolation):
            adapter.tool_call(
                agent_id="pp-agent-01",
                tool_name="exec_code",
                args={"code": "print('safe')"},
                pack_binding=["soc2"],
            )


# ---------------------------------------------------------------------------
# PT-ADAPT-PAPERCLIP-REPLAY-1: cross-tenant replay blocked (C4)
# ---------------------------------------------------------------------------

class TestPtAdaptPaperclipReplay1:
    """PT-ADAPT-PAPERCLIP-REPLAY-1: cross-tenant replay is blocked by C4 fix.

    Pen-test ID: PT-ADAPT-PAPERCLIP-REPLAY-1
    Finding: C4 -- PaperclipGovernance.replay_policy keyed cache on decision_id
             only; an org-B token could replay an org-A ALLOW decision by
             supplying the decision_id obtained out-of-band.
    Fix: Cache keyed on (decision_id, org_id, agent_id). Before returning a
         cached result, caller's org_id must match the org_id that issued
         the original decision. Mismatch raises GovernanceViolation (enforce=True)
         or returns DENY (enforce=False).
    """

    def _make_adapter_for_org(self, org_id: str, enforce: bool = True) -> PaperclipGovernance:
        """Build a PaperclipGovernance adapter whose GovernanceClient carries the given org_id."""
        transport = make_transport({
            "/api/v1/governance/check-action": ALLOW_RESPONSE,
            "/api/v1/governance/report-result": {"ok": True},
        })
        from connexum_governance import GovernanceClient
        import httpx as _httpx
        client = GovernanceClient(
            api_url="http://test-server",
            license_key="test-key",
            org_id=org_id,
            enforce=enforce,
        )
        client._client = _httpx.Client(
            base_url="http://test-server",
            headers=client._client.headers,
            transport=transport,
        )
        return PaperclipGovernance(client=client)

    def test_cross_tenant_replay_raises_governance_violation(self):
        """PT-ADAPT-PAPERCLIP-REPLAY-1: org-B cannot replay org-A decision (enforce=True)."""
        adapter_a = self._make_adapter_for_org("org-alpha", enforce=True)
        adapter_b = self._make_adapter_for_org("org-beta", enforce=True)

        # org-alpha issues an ALLOW decision; decision is cached under org-alpha
        decision = adapter_a.agent_start(
            agent_id="agent-alpha",
            pack_binding=["soc2"],
        )
        audit_id = decision.audit_id
        assert audit_id is not None, "ALLOW transport must return an auditId"

        # Manually copy the internal cache state into adapter_b to simulate a
        # scenario where org-beta has learned the audit_id out of band.
        # The _decision_meta and _decision_cache are in adapter_a; we move only
        # the meta entry (not the full cache key) so adapter_b sees a cross-tenant
        # decision in its meta store.
        adapter_b._decision_meta[audit_id] = adapter_a._decision_meta[audit_id]
        # Also copy the cache entry so the replay path can find it
        cache_key_a = (audit_id, "org-alpha", "agent-alpha")
        if cache_key_a in adapter_a._decision_cache:
            adapter_b._decision_cache[cache_key_a] = adapter_a._decision_cache[cache_key_a]

        # org-beta attempting to replay org-alpha's decision must be blocked
        with pytest.raises(GovernanceViolation) as exc_info:
            adapter_b.replay_policy(audit_id, requesting_agent_id="agent-beta")

        assert "cross-tenant replay blocked" in str(exc_info.value).lower()

    def test_cross_tenant_replay_returns_deny_non_enforce(self):
        """PT-ADAPT-PAPERCLIP-REPLAY-1: org-B replay returns DENY when enforce=False."""
        adapter_a = self._make_adapter_for_org("org-alpha", enforce=False)
        adapter_b = self._make_adapter_for_org("org-beta", enforce=False)

        decision = adapter_a.agent_start(
            agent_id="agent-alpha",
            pack_binding=["hipaa"],
        )
        audit_id = decision.audit_id
        assert audit_id is not None

        # Simulate org-beta acquiring audit_id out of band
        adapter_b._decision_meta[audit_id] = adapter_a._decision_meta[audit_id]
        cache_key_a = (audit_id, "org-alpha", "agent-alpha")
        if cache_key_a in adapter_a._decision_cache:
            adapter_b._decision_cache[cache_key_a] = adapter_a._decision_cache[cache_key_a]

        result = adapter_b.replay_policy(audit_id, requesting_agent_id="agent-beta")
        assert result.decision == DecisionType.DENY
        assert "cross-tenant" in result.reason.lower()

    def test_same_org_replay_succeeds(self):
        """PT-ADAPT-PAPERCLIP-REPLAY-1 (negative): same org can replay its own decision."""
        adapter = self._make_adapter_for_org("org-alpha", enforce=True)

        decision = adapter.agent_start(
            agent_id="agent-alpha",
            pack_binding=["soc2"],
        )
        audit_id = decision.audit_id
        assert audit_id is not None

        # Same adapter replaying the same org's decision must succeed
        replayed = adapter.replay_policy(audit_id, requesting_agent_id="agent-alpha")
        assert replayed.decision == DecisionType.ALLOW

    def test_different_agents_same_org_replay_succeeds(self):
        """PT-ADAPT-PAPERCLIP-REPLAY-1 (negative): different agent within same org can replay."""
        adapter_a = self._make_adapter_for_org("org-alpha", enforce=True)

        decision = adapter_a.agent_start(
            agent_id="agent-alpha",
            pack_binding=["soc2"],
        )
        audit_id = decision.audit_id
        assert audit_id is not None

        # A second adapter for the same org is a legitimate in-org replay
        adapter_a2 = self._make_adapter_for_org("org-alpha", enforce=True)
        adapter_a2._decision_meta[audit_id] = adapter_a._decision_meta[audit_id]
        cache_key_a = (audit_id, "org-alpha", "agent-alpha")
        if cache_key_a in adapter_a._decision_cache:
            adapter_a2._decision_cache[cache_key_a] = adapter_a._decision_cache[cache_key_a]

        # Same org_id -- must succeed (different agent_id is fine within same org)
        replayed = adapter_a2.replay_policy(audit_id, requesting_agent_id="agent-alpha-2")
        assert replayed.decision == DecisionType.ALLOW
