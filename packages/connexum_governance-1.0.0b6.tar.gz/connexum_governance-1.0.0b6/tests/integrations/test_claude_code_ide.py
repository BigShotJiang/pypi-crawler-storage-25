"""Tests for Claude Code IDE governance integration (B3-01).

Covers the six standard parity cases:
1. Happy path ALLOW
2. Secret leak G2 -- PHI in tool result flags output classifier
3. PHI ingress refusal -- PHI in tool call argument blocked
4. Provider compliance -- unapproved model blocked at llmCall
5. Subscription gate -- empty pack binding denied
6. Audit chain append -- canonical events round-trip

Claude Code-specific tests:
  - intercept_hook PreToolUse destructive command blocked (G4 guard)
  - intercept_hook PreToolUse sensitive path blocked
  - intercept_hook PostToolUse PHI flags classifier
  - intercept_hook Stop maps to agentEnd
  - wrap_webhook validates required fields
  - policy_bridge routes to callback
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.claude_code import (
    ClaudeCodeGovernance,
    ClaudeCodePolicyBridge,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-cc-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-cc-002"}

_APPROVED_MODELS = ["claude-haiku-4-5", "claude-sonnet-4-6"]


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    approved_models: list[str] | None = None,
) -> ClaudeCodeGovernance:
    client = make_client(transport, enforce=enforce)
    return ClaudeCodeGovernance(
        client=client,
        agent_name="cc-agent-01",
        pack_binding=["hipaa"],
        approved_models=approved_models if approved_models is not None else _APPROVED_MODELS,
        sensitive_tools=["exec_code"],
        sensitive_arg_keys=["command", "content", "query"],
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestClaudeCodeHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("cc-agent-01", pack_binding=["hipaa"])
        assert decision.allowed

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cc-agent-01", "Read", {"file_path": "/workspace/src/main.py"},
            pack_binding=["hipaa"]
        )
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_call("cc-agent-01", "Read", {"file_path": "/workspace/app.py"}, pack_binding=["hipaa"])
        adapter.tool_result("cc-agent-01", "Read", "def main(): pass", pack_binding=["hipaa"])
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "cc-agent-01", "claude-haiku-4-5", [], pack_binding=["hipaa"]
        )
        assert decision.allowed

    def test_llm_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_call("cc-agent-01", "claude-haiku-4-5", [], pack_binding=["hipaa"])
        adapter.llm_result("cc-agent-01", "claude-haiku-4-5", "Here is a summary.", pack_binding=["hipaa"])
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_end("cc-agent-01", success=True)
        assert decision.allowed

    def test_full_event_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("cc-agent-01", pack_binding=["hipaa"])
        adapter.tool_call("cc-agent-01", "Bash", {"command": "ls /workspace"}, pack_binding=["hipaa"])
        adapter.tool_result("cc-agent-01", "Bash", "main.py\nREADME.md", pack_binding=["hipaa"])
        adapter.llm_call("cc-agent-01", "claude-haiku-4-5", [], pack_binding=["hipaa"])
        adapter.llm_result("cc-agent-01", "claude-haiku-4-5", "Analysis complete.", pack_binding=["hipaa"])
        adapter.agent_end("cc-agent-01", success=True)


# ---------------------------------------------------------------------------
# 2. Secret leak / PHI in tool result flags output classifier
# ---------------------------------------------------------------------------

class TestClaudeCodeSecretLeak:
    def test_phi_in_tool_result_flags_output_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "cc-agent-01", "Read",
            "patient_id=99999 ssn=123-45-6789",
            pack_binding=["soc2"]
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_call("cc-agent-01", "claude-haiku-4-5", [], pack_binding=["hipaa"])
        adapter.llm_result(
            "cc-agent-01", "claude-haiku-4-5",
            "Patient date_of_birth: 1985-03-12",
            pack_binding=["hipaa"]
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal
# ---------------------------------------------------------------------------

class TestClaudeCodePhiIngress:
    def test_phi_in_command_arg_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cc-agent-01",
            "Bash",
            {"command": "echo patient_id=12345 ssn=123-45-6789"},
            pack_binding=["hipaa"],
        )
        assert decision.denied

    def test_phi_in_content_arg_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cc-agent-01",
            "Write",
            {"content": "SSN: 123-45-6789"},
            pack_binding=["soc2"],
        )
        assert decision.denied

    def test_clean_args_pass(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cc-agent-01",
            "Bash",
            {"command": "pytest tests/"},
            pack_binding=["hipaa"],
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved model blocked
# ---------------------------------------------------------------------------

class TestClaudeCodeProviderCompliance:
    def test_unapproved_model_denied_at_llm_call(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "cc-agent-01", "gpt-4o", [],
            pack_binding=["hipaa"]
        )
        assert decision.denied

    def test_approved_model_passes(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "cc-agent-01", "claude-sonnet-4-6", [],
            pack_binding=["hipaa"]
        )
        assert decision.allowed

    def test_empty_model_string_skips_check(self):
        # If model is empty string, no model check fires
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "cc-agent-01", "", [],
            pack_binding=["hipaa"]
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 5. Subscription gate -- empty pack binding denied
# ---------------------------------------------------------------------------

class TestClaudeCodeSubscriptionGate:
    def test_missing_pack_binding_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("cc-agent-01", pack_binding=[])
        assert decision.denied

    def test_missing_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call("cc-agent-01", "Read", {}, pack_binding=[])
        assert decision.denied

    def test_unknown_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="Unknown ClaudeCode event type"):
            adapter.emit_event("unknownEvent", {"agentId": "cc-agent-01", "packBinding": ["hipaa"]})


# ---------------------------------------------------------------------------
# 6. Audit chain append
# ---------------------------------------------------------------------------

class TestClaudeCodeAuditChain:
    def test_tool_call_and_result_audit_round_trip(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.tool_call("cc-agent-01", "Read", {}, pack_binding=["hipaa"])
        adapter.tool_result("cc-agent-01", "Read", "content", pack_binding=["hipaa"])
        assert len(reported) >= 1

    def test_emit_event_forwards_to_governance_api(self):
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.emit_event("agentStart", {
            "agentId": "cc-agent-01",
            "packBinding": ["hipaa"],
        })
        assert any("check-action" in c for c in calls)


# ---------------------------------------------------------------------------
# Claude Code-specific: intercept_hook surfaces
# ---------------------------------------------------------------------------

class TestClaudeCodeInterceptHook:
    def test_pre_tool_use_destructive_command_blocked(self):
        adapter = _adapter(_transport())
        result = adapter.intercept_hook("PreToolUse", {
            "tool_name": "Bash",
            "tool_input": {"command": "rm -rf /workspace"},
        })
        assert result["continue"] is False
        assert "Destructive" in result["reason"]

    def test_pre_tool_use_sensitive_path_blocked(self):
        adapter = _adapter(_transport())
        result = adapter.intercept_hook("PreToolUse", {
            "tool_name": "Write",
            "tool_input": {"file_path": "/etc/sudoers"},
        })
        assert result["continue"] is False
        assert "Sensitive" in result["reason"]

    def test_pre_tool_use_clean_command_passes(self):
        adapter = _adapter(_transport())
        result = adapter.intercept_hook("PreToolUse", {
            "tool_name": "Bash",
            "tool_input": {"command": "pytest tests/ -x"},
        })
        assert result["continue"] is True

    def test_post_tool_use_phi_flags_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.intercept_hook("PostToolUse", {
            "tool_name": "Read",
            "tool_response": "patient_id=54321 dob: 1990-05-20",
        })
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_stop_hook_maps_to_agent_end(self):
        adapter = _adapter(_transport())
        result = adapter.intercept_hook("Stop", {"success": True})
        assert result["continue"] is True

    def test_unknown_hook_name_returns_false(self):
        adapter = _adapter(_transport())
        result = adapter.intercept_hook("UnknownHook", {})
        assert result["continue"] is False

    def test_wrap_webhook_missing_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({"agentId": "cc-agent-01"})

    def test_wrap_webhook_missing_agent_id_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({"eventType": "agentStart"})

    def test_wrap_webhook_valid_payload_passes(self):
        adapter = _adapter(_transport())
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "cc-agent-01",
            "toolName": "Read",
            "args": {},
            "packBinding": ["hipaa"],
        })
        assert decision.allowed

    def test_policy_bridge_callback_intercepts_decision(self):
        called: list[dict] = []

        def callback(event_type: str, payload: dict) -> Any:
            called.append({"event_type": event_type})
            from connexum_governance.models import GovernanceDecision, DecisionType
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="Python policy allowed",
                audit_id="py-cc-001",
            )

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(["hipaa"], callback)
        decision = bridge.decide("agentStart", {"agentId": "cc-agent-01"})
        assert decision.allowed
        assert called[0]["event_type"] == "agentStart"
