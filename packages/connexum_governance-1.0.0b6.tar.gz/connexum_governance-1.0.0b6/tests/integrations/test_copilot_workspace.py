"""Tests for the GitHub Copilot Workspace governance integration (B3-03).

Mirrors the 6 parity cases required for all Python IDE adapters:
  P1 -- Pack-binding primacy: empty binding denied
  P2 -- Provider compliance gate
  P3 -- Output classifier (toolResult secret scan)
  P4 -- Output exfiltration scanner (llmResult PHI/secret scan)
  P5 -- policy_bridge round-trip
  P6 -- wrap_webhook dispatches to emit_event

Plus Copilot Workspace-specific tests:
  CW-01 -- intercept_spec_to_code allows clean spec
  CW-02 -- intercept_spec_to_code blocks secret in spec text
  CW-03 -- intercept_spec_to_code blocks PHI under HIPAA
  CW-04 -- intercept_pr_preview allows clean diff
  CW-05 -- intercept_pr_preview blocks secret in diff added line
  CW-06 -- intercept_pr_preview neutral for non-bot author
  CW-07 -- intercept_pr_preview neutral for missing sender
  CW-08 -- bot-author gate on spec-to-code passes through non-bot as neutral
  CW-09 -- IdeUnsupportedError pattern: runtime surface not applicable
"""

from __future__ import annotations

import sys
import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.copilot_workspace import (
    CopilotWorkspaceGovernance,
    COPILOT_WORKSPACE_BOT_AUTHOR,
    COPILOT_WORKSPACE_TESTED_API_VERSION,
    IdeUnsupportedError,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-cw-001",
}

_DENY = {
    "decision": "DENY",
    "reason": "Denied by policy",
    "auditId": "aud-cw-002",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(transport: httpx.MockTransport, enforce: bool = False) -> CopilotWorkspaceGovernance:
    client = make_client(transport, enforce=enforce)
    return CopilotWorkspaceGovernance(
        client=client,
        agent_name="copilot-ws-agent-01",
        pack_binding=["soc2"],
        approved_providers=["openai"],
    )


# ---------------------------------------------------------------------------
# P1 -- Pack-binding primacy
# ---------------------------------------------------------------------------

class TestPackBindingPrimacy:
    def test_empty_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "copilot-ws-agent-01", "read_file", {"path": "/workspace/main.py"},
            pack_binding=[],
        )
        assert decision.denied

    def test_none_pack_binding_falls_back_to_instance_binding(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "copilot-ws-agent-01", "write_file", {"path": "/workspace/main.py"},
            pack_binding=None,
        )
        assert decision.allowed

    def test_missing_pack_binding_on_emit_event_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.emit_event("toolCall", {
            "agentId": "copilot-ws-agent-01",
            "toolName": "exec",
            "args": {},
        })
        assert decision.denied

    def test_spec_to_code_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_spec_to_code({
            "specText": "Build a hello world API",
            "prAuthor": COPILOT_WORKSPACE_BOT_AUTHOR,
        })
        assert decision.denied

    def test_pr_preview_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_pr_preview({
            "diff": "+def hello(): pass",
            "prUrl": "https://github.com/acme/repo/pull/1",
            "sender": COPILOT_WORKSPACE_BOT_AUTHOR,
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# P2 -- Provider compliance gate
# ---------------------------------------------------------------------------

class TestProviderCompliance:
    def test_approved_openai_provider_allowed(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_spec_to_code({
            "specText": "Build a REST endpoint",
            "model": "gpt-4o",
            "prAuthor": COPILOT_WORKSPACE_BOT_AUTHOR,
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_unapproved_provider_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_spec_to_code({
            "specText": "Build a REST endpoint",
            "model": "claude-opus-4",
            "prAuthor": COPILOT_WORKSPACE_BOT_AUTHOR,
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "anthropic" in decision.reason.lower() or "approved" in decision.reason.lower()

    def test_no_model_skips_provider_check(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_spec_to_code({
            "specText": "Build a REST endpoint",
            "model": "",
            "prAuthor": COPILOT_WORKSPACE_BOT_AUTHOR,
            "packBinding": ["soc2"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# P3 -- Output classifier (toolResult secret scan)
# ---------------------------------------------------------------------------

class TestOutputClassifier:
    def test_secret_in_tool_result_flags_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "copilot-ws-agent-01", "read_file",
            "SECRET_KEY=abc12345678",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert "secret" in captured.err.lower() or "classifier" in captured.err.lower()

    def test_clean_tool_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "copilot-ws-agent-01", "list_files",
            "['main.py', 'utils.py']",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P4 -- Output exfiltration scanner (llmResult)
# ---------------------------------------------------------------------------

class TestOutputExfiltrationScanner:
    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "copilot-ws-agent-01", "gpt-4o",
            "The patient_id is 12345 and diagnosis is diabetes.",
            pack_binding=["hipaa"],
        )
        captured = capsys.readouterr()
        assert "exfiltration" in captured.err.lower() or "phi" in captured.err.lower() or "secret" in captured.err.lower()

    def test_clean_llm_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "copilot-ws-agent-01", "gpt-4o",
            "Here is the updated code for the API endpoint.",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P5 -- policy_bridge round-trip
# ---------------------------------------------------------------------------

class TestPolicyBridge:
    def test_policy_bridge_callback_called(self):
        from connexum_governance.models import GovernanceDecision, DecisionType
        callback_calls = []

        def my_policy(event_type, payload):
            callback_calls.append((event_type, payload))
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="custom-allow",
                audit_id="bridge-001",
            )

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=my_policy)
        result = bridge.decide("toolCall", {
            "agentId": "copilot-ws-agent-01",
            "toolName": "generate_code",
            "args": {},
        })
        assert len(callback_calls) == 1
        assert callback_calls[0][0] == "toolCall"
        assert result.allowed

    def test_policy_bridge_falls_back_to_rest_api_when_callback_returns_none(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=lambda e, p: None)
        result = bridge.decide("toolCall", {
            "agentId": "copilot-ws-agent-01",
            "toolName": "list_files",
            "args": {},
        })
        assert result.allowed

    def test_policy_bridge_falls_back_to_rest_api_when_no_callback(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=None)
        result = bridge.decide("llmCall", {
            "agentId": "copilot-ws-agent-01",
            "model": "gpt-4o",
            "messageCount": 1,
        })
        assert result.allowed


# ---------------------------------------------------------------------------
# P6 -- wrap_webhook dispatches to emit_event
# ---------------------------------------------------------------------------

class TestWrapWebhook:
    def test_wrap_webhook_dispatches_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "copilot-ws-agent-01",
            "toolName": "generate_code",
            "args": {},
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_wrap_webhook_missing_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({
                "agentId": "copilot-ws-agent-01",
                "packBinding": ["soc2"],
            })

    def test_wrap_webhook_missing_agent_id_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({
                "eventType": "toolCall",
                "packBinding": ["soc2"],
            })

    def test_wrap_webhook_invalid_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="Unknown"):
            adapter.wrap_webhook({
                "eventType": "unknownEvent",
                "agentId": "copilot-ws-agent-01",
                "packBinding": ["soc2"],
            })


# ---------------------------------------------------------------------------
# CW-01 to CW-09 -- Copilot Workspace-specific tests
# ---------------------------------------------------------------------------

class TestCopilotWorkspaceIntercept:
    def test_cw_01_spec_to_code_clean_allowed(self):
        """CW-01: Clean spec with bot author is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_spec_to_code({
            "specText": "Build a REST endpoint to list all users",
            "targetRepo": "acme/api",
            "model": "gpt-4o",
            "prAuthor": COPILOT_WORKSPACE_BOT_AUTHOR,
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cw_02_spec_to_code_secret_in_spec_blocked(self):
        """CW-02: Secret pattern in spec text is blocked."""
        adapter = _adapter(_transport())
        _prefix = "sk-"
        _suffix = "abc12345678901234567890"
        secret_text = "Use this key: " + _prefix + _suffix
        decision = adapter.intercept_spec_to_code({
            "specText": secret_text,
            "targetRepo": "acme/api",
            "model": "gpt-4o",
            "prAuthor": COPILOT_WORKSPACE_BOT_AUTHOR,
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_cw_03_spec_to_code_phi_under_hipaa_blocked(self):
        """CW-03: PHI indicator in spec text under HIPAA binding is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_spec_to_code({
            "specText": "Generate code that processes patient_id and diagnosis records",
            "targetRepo": "acme/health",
            "model": "gpt-4o",
            "prAuthor": COPILOT_WORKSPACE_BOT_AUTHOR,
            "packBinding": ["hipaa"],
        })
        assert decision.denied
        assert "phi" in decision.reason.lower() or "hipaa" in decision.reason.lower()

    def test_cw_04_pr_preview_clean_diff_allowed(self):
        """CW-04: Clean PR diff from bot author is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_pr_preview({
            "diff": (
                "diff --git a/main.py b/main.py\n"
                "--- a/main.py\n"
                "+++ b/main.py\n"
                "@@ -1,3 +1,4 @@\n"
                "+def hello():\n"
                "+    return 'world'\n"
            ),
            "prUrl": "https://github.com/acme/api/pull/42",
            "prNumber": 42,
            "headSha": "deadbeef",
            "sender": COPILOT_WORKSPACE_BOT_AUTHOR,
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cw_05_pr_preview_secret_in_diff_blocked(self):
        """CW-05: Secret pattern in diff added line is blocked."""
        adapter = _adapter(_transport())
        _prefix = "AKIA"
        _suffix = "ABCDEFGHIJKLMNOPQRST"
        secret_line = "+" + _prefix + _suffix
        diff = (
            "diff --git a/config.py b/config.py\n"
            "--- a/config.py\n"
            "+++ b/config.py\n"
            "@@ -1,2 +1,3 @@\n"
            f"{secret_line}\n"
        )
        decision = adapter.intercept_pr_preview({
            "diff": diff,
            "prUrl": "https://github.com/acme/api/pull/43",
            "prNumber": 43,
            "headSha": "abc123",
            "sender": COPILOT_WORKSPACE_BOT_AUTHOR,
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "secret" in decision.reason.lower()

    def test_cw_06_pr_preview_non_bot_author_neutral(self):
        """CW-06: Non-bot PR sender produces neutral / allowed decision."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_pr_preview({
            "diff": "+def foo(): pass",
            "prUrl": "https://github.com/acme/api/pull/44",
            "sender": "regular-developer",
            "packBinding": ["soc2"],
        })
        # Non-bot author should produce a pass-through (not a deny)
        assert not decision.denied

    def test_cw_07_pr_preview_missing_sender_neutral(self):
        """CW-07: Missing sender produces neutral / non-deny decision (fail-closed)."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_pr_preview({
            "diff": "+def bar(): pass",
            "prUrl": "https://github.com/acme/api/pull/45",
            "packBinding": ["soc2"],
        })
        # Missing sender should produce neutral, not deny
        assert not decision.denied

    def test_cw_08_spec_to_code_non_bot_author_neutral(self):
        """CW-08: Non-bot author on spec-to-code passes through as neutral."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_spec_to_code({
            "specText": "Generate a login endpoint",
            "prAuthor": "human-developer",
            "model": "gpt-4o",
            "packBinding": ["soc2"],
        })
        assert not decision.denied

    def test_cw_09_api_version_constant(self):
        """CW-09: COPILOT_WORKSPACE_TESTED_API_VERSION is the expected GitHub API version."""
        assert COPILOT_WORKSPACE_TESTED_API_VERSION == "2024-11-01"

    def test_bot_author_constant(self):
        """Bot author constant matches the expected GitHub bot login."""
        assert COPILOT_WORKSPACE_BOT_AUTHOR == "copilot-workspace[bot]"


# ---------------------------------------------------------------------------
# Six canonical surfaces
# ---------------------------------------------------------------------------

class TestCanonicalSurfaces:
    def test_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("copilot-ws-agent-01", pack_binding=["soc2"])
        assert decision.allowed

    def test_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "copilot-ws-agent-01", "read_file", {"path": "/workspace/api.py"},
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_tool_result(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_result(
            "copilot-ws-agent-01", "read_file", "def hello(): pass",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_call(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "copilot-ws-agent-01", "gpt-4o",
            [{"role": "user", "content": "generate code"}],
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_result(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_result(
            "copilot-ws-agent-01", "gpt-4o",
            "def hello(): return 'world'",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_agent_end(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_end("copilot-ws-agent-01", success=True, pack_binding=["soc2"])
        assert decision.allowed
