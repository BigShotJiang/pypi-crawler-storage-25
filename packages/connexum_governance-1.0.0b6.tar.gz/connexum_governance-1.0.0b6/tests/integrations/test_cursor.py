"""Tests for the Cursor IDE governance integration (B3-04).

Mirrors the 6 parity cases required for all Python IDE adapters:
  P1 -- Pack-binding primacy: empty binding denied
  P2 -- Provider compliance gate
  P3 -- Output classifier (toolResult secret scan)
  P4 -- Output exfiltration scanner (llmResult PHI/secret scan)
  P5 -- policy_bridge round-trip
  P6 -- wrap_webhook dispatches to emit_event

Plus Cursor-specific tests:
  CU-01 -- intercept_composer allows clean request (filesystem-sidecar)
  CU-02 -- intercept_composer blocks destructive command (G4)
  CU-03 -- intercept_composer blocks sensitive path (G5)
  CU-04 -- intercept_composer blocks PHI under HIPAA
  CU-05 -- intercept_tab_completion allows clean request
  CU-06 -- intercept_tab_completion blocks sensitive path
  CU-07 -- intercept_composer raises IdeUnsupportedError in mcp-server mode
  CU-08 -- intercept_composer raises IdeUnsupportedError in vscode-extension mode
  CU-09 -- unapproved provider (ollama) denied
"""

from __future__ import annotations

import pytest
import httpx

from tests.conftest import make_client, make_transport

from connexum_governance.integrations.cursor import (
    CursorGovernance,
    IdeUnsupportedError,
    DEFAULT_INTEGRATION_MODE,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ALLOW = {
    "decision": "ALLOW",
    "reason": "Permitted",
    "auditId": "aud-cu-001",
}

_APPROVAL_PATHS = {
    "/api/v1/governance/check-action": _ALLOW,
    "/api/v1/governance/check-task": _ALLOW,
    "/api/v1/governance/check-plan": _ALLOW,
    "/api/v1/governance/check-delegation": _ALLOW,
    "/api/v1/governance/report-result": {"ok": True},
    "/api/v1/health": {"status": "healthy"},
}


def _transport() -> httpx.MockTransport:
    return make_transport(_APPROVAL_PATHS)


def _adapter(transport: httpx.MockTransport, enforce: bool = False) -> CursorGovernance:
    client = make_client(transport, enforce=enforce)
    return CursorGovernance(
        client=client,
        agent_name="cursor-agent-01",
        pack_binding=["soc2"],
        approved_providers=["anthropic", "openai"],
        integration_mode="filesystem-sidecar",
    )


# ---------------------------------------------------------------------------
# P1 -- Pack-binding primacy
# ---------------------------------------------------------------------------

class TestPackBindingPrimacy:
    def test_empty_pack_binding_on_tool_call_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cursor-agent-01", "read_file", {"path": "/workspace/main.py"},
            pack_binding=[],
        )
        assert decision.denied

    def test_none_pack_binding_falls_back_to_instance_binding(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cursor-agent-01", "read_file", {"path": "/workspace/main.py"},
            pack_binding=None,
        )
        assert decision.allowed

    def test_missing_pack_binding_on_emit_event_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.emit_event("toolCall", {
            "agentId": "cursor-agent-01",
            "toolName": "exec",
            "args": {},
        })
        assert decision.denied

    def test_composer_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_composer({
            "model": "claude-opus-4",
            "prompt": "Refactor this class",
        })
        assert decision.denied

    def test_tab_completion_no_pack_binding_denied(self):
        adapter = _adapter(_transport())
        adapter.pack_binding = []
        decision = adapter.intercept_tab_completion({
            "model": "gpt-4o",
            "prefix": "def process(",
            "filePath": "/workspace/api.py",
        })
        assert decision.denied


# ---------------------------------------------------------------------------
# P2 -- Provider compliance gate
# ---------------------------------------------------------------------------

class TestProviderCompliance:
    def test_anthropic_provider_allowed(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "claude-opus-4",
            "prompt": "Explain this function",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_openai_provider_allowed(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "gpt-4o",
            "prompt": "Refactor this function",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_unapproved_provider_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "gemini-2.0",
            "prompt": "Explain this",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "approved" in decision.reason.lower()

    def test_no_model_skips_provider_check(self):
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "",
            "prompt": "Hello",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


# ---------------------------------------------------------------------------
# P3 -- Output classifier (toolResult secret scan)
# ---------------------------------------------------------------------------

class TestOutputClassifier:
    def test_secret_in_tool_result_flags_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "cursor-agent-01", "read_file",
            "SECRET_KEY=abc12345678",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert "secret" in captured.err.lower() or "classifier" in captured.err.lower()

    def test_clean_tool_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.tool_result(
            "cursor-agent-01", "read_file",
            "def hello(): return 'world'",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P4 -- Output exfiltration scanner (llmResult)
# ---------------------------------------------------------------------------

class TestOutputExfiltrationScanner:
    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "cursor-agent-01", "claude-opus-4",
            "The patient_id is 12345 and diagnosis is hypertension.",
            pack_binding=["hipaa"],
        )
        captured = capsys.readouterr()
        assert "exfiltration" in captured.err.lower() or "phi" in captured.err.lower() or "secret" in captured.err.lower()

    def test_clean_llm_result_no_warning(self, capsys):
        adapter = _adapter(_transport())
        adapter.llm_result(
            "cursor-agent-01", "claude-opus-4",
            "Here is the refactored code.",
            pack_binding=["soc2"],
        )
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# P5 -- policy_bridge round-trip
# ---------------------------------------------------------------------------

class TestPolicyBridge:
    def test_policy_bridge_callback_called(self):
        from connexum_governance.models import GovernanceDecision, DecisionType
        callback_calls = []

        def my_policy(event_type, payload):
            callback_calls.append((event_type, payload))
            return GovernanceDecision(
                decision=DecisionType.ALLOW,
                reason="custom-allow",
                audit_id="bridge-cu-001",
            )

        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=my_policy)
        result = bridge.decide("toolCall", {
            "agentId": "cursor-agent-01",
            "toolName": "read_file",
            "args": {},
        })
        assert len(callback_calls) == 1
        assert result.allowed

    def test_policy_bridge_falls_back_to_rest_api_when_callback_returns_none(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=lambda e, p: None)
        result = bridge.decide("toolCall", {
            "agentId": "cursor-agent-01",
            "toolName": "read_file",
            "args": {},
        })
        assert result.allowed

    def test_policy_bridge_falls_back_to_rest_api_when_no_callback(self):
        adapter = _adapter(_transport())
        bridge = adapter.policy_bridge(pack_binding=["soc2"], decision_callback=None)
        result = bridge.decide("llmCall", {
            "agentId": "cursor-agent-01",
            "model": "claude-opus-4",
            "messageCount": 1,
        })
        assert result.allowed


# ---------------------------------------------------------------------------
# P6 -- wrap_webhook dispatches to emit_event
# ---------------------------------------------------------------------------

class TestWrapWebhook:
    def test_wrap_webhook_dispatches_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.wrap_webhook({
            "eventType": "toolCall",
            "agentId": "cursor-agent-01",
            "toolName": "read_file",
            "args": {},
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_wrap_webhook_missing_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="eventType"):
            adapter.wrap_webhook({
                "agentId": "cursor-agent-01",
                "packBinding": ["soc2"],
            })

    def test_wrap_webhook_missing_agent_id_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="agentId"):
            adapter.wrap_webhook({
                "eventType": "toolCall",
                "packBinding": ["soc2"],
            })

    def test_wrap_webhook_invalid_event_type_raises(self):
        adapter = _adapter(_transport())
        with pytest.raises(ValueError, match="Unknown"):
            adapter.wrap_webhook({
                "eventType": "unknownEvent",
                "agentId": "cursor-agent-01",
                "packBinding": ["soc2"],
            })


# ---------------------------------------------------------------------------
# CU-01 to CU-09 -- Cursor-specific tests
# ---------------------------------------------------------------------------

class TestCursorComposer:
    def test_cu_01_composer_clean_allowed(self):
        """CU-01: Clean Composer request is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "claude-opus-4",
            "prompt": "Refactor the authentication module",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cu_02_composer_destructive_command_blocked(self):
        """CU-02: Destructive command in run_terminal tool is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "claude-opus-4",
            "prompt": "Clean up old branches",
            "tool": "run_terminal",
            "command": "git push --force origin main",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "destructive" in decision.reason.lower()

    def test_cu_02b_rm_rf_blocked(self):
        """CU-02b: rm -rf command is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "gpt-4o",
            "prompt": "Delete temp files",
            "tool": "run_terminal",
            "command": "rm -rf /tmp/mydir",
            "packBinding": ["soc2"],
        })
        assert decision.denied

    def test_cu_03_composer_sensitive_path_blocked(self):
        """CU-03: Write to sensitive path is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "claude-opus-4",
            "prompt": "Update env config",
            "tool": "edit_file",
            "filePath": "/etc/passwd",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "sensitive" in decision.reason.lower()

    def test_cu_04_composer_phi_under_hipaa_blocked(self):
        """CU-04: PHI in Composer prompt under HIPAA binding is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "claude-opus-4",
            "prompt": "Generate code that processes patient_id and diagnosis data",
            "packBinding": ["hipaa"],
        })
        assert decision.denied
        assert "hipaa" in decision.reason.lower() or "phi" in decision.reason.lower()

    def test_cu_04_composer_phi_non_hipaa_allowed(self):
        """CU-04b: PHI-looking content without HIPAA binding is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "claude-opus-4",
            "prompt": "Generate code that processes patient_id data",
            "packBinding": ["soc2"],
        })
        assert decision.allowed


class TestCursorTabCompletion:
    def test_cu_05_tab_completion_clean_allowed(self):
        """CU-05: Clean tab-completion request is allowed."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_tab_completion({
            "model": "gpt-4o",
            "prefix": "def process(",
            "filePath": "/workspace/api.py",
            "packBinding": ["soc2"],
        })
        assert decision.allowed

    def test_cu_06_tab_completion_sensitive_path_blocked(self):
        """CU-06: Tab completion on a sensitive file path is blocked."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_tab_completion({
            "model": "gpt-4o",
            "prefix": "SECRET=",
            "filePath": "/root/.env",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "sensitive" in decision.reason.lower()


class TestCursorIntegrationModes:
    def test_cu_07_mcp_server_mode_raises_unsupported(self):
        """CU-07: mcp-server mode raises IdeUnsupportedError."""
        client = make_client(_transport(), enforce=False)
        adapter = CursorGovernance(
            client=client,
            agent_name="cursor-mcp",
            pack_binding=["soc2"],
            integration_mode="mcp-server",
        )
        with pytest.raises(IdeUnsupportedError, match="mcp-server"):
            adapter.intercept_composer({
                "model": "claude-opus-4",
                "prompt": "Hello",
                "packBinding": ["soc2"],
            })

    def test_cu_08_vscode_extension_mode_raises_unsupported(self):
        """CU-08: vscode-extension mode raises IdeUnsupportedError."""
        client = make_client(_transport(), enforce=False)
        adapter = CursorGovernance(
            client=client,
            agent_name="cursor-vscode",
            pack_binding=["soc2"],
            integration_mode="vscode-extension",
        )
        with pytest.raises(IdeUnsupportedError, match="vscode-extension"):
            adapter.intercept_composer({
                "model": "gpt-4o",
                "prompt": "Hello",
                "packBinding": ["soc2"],
            })

    def test_cu_09_unapproved_provider_ollama_denied(self):
        """CU-09: Ollama provider is not on the approved list."""
        adapter = _adapter(_transport())
        decision = adapter.intercept_composer({
            "model": "codellama",
            "prompt": "Complete this function",
            "packBinding": ["soc2"],
        })
        assert decision.denied
        assert "approved" in decision.reason.lower()

    def test_default_integration_mode(self):
        """Default integration mode is filesystem-sidecar."""
        assert DEFAULT_INTEGRATION_MODE == "filesystem-sidecar"


# ---------------------------------------------------------------------------
# Six canonical surfaces
# ---------------------------------------------------------------------------

class TestCanonicalSurfaces:
    def test_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("cursor-agent-01", pack_binding=["soc2"])
        assert decision.allowed

    def test_tool_call(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call(
            "cursor-agent-01", "read_file", {"path": "/workspace/api.py"},
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_tool_result(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_result(
            "cursor-agent-01", "read_file", "def hello(): pass",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_call(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_call(
            "cursor-agent-01", "claude-opus-4",
            [{"role": "user", "content": "refactor this"}],
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_llm_result(self):
        adapter = _adapter(_transport())
        decision = adapter.llm_result(
            "cursor-agent-01", "claude-opus-4",
            "def hello(): return 'world'",
            pack_binding=["soc2"],
        )
        assert decision.allowed

    def test_agent_end(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_end("cursor-agent-01", success=True, pack_binding=["soc2"])
        assert decision.allowed
