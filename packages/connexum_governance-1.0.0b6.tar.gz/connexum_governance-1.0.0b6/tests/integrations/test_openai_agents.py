"""Tests for OpenAI Agents SDK governance integration (B2-02).

Covers the six parity cases from docs/plans/2026-04-24-plan-python-sdk-parity.md:
1. Happy path ALLOW
2. Secret leak G2 -- PHI in tool result triggers output classifier
3. PHI ingress refusal -- exfiltration scan on tool args
4. Provider compliance -- unapproved model blocks agent_start and llm_call
5. Subscription gate -- allowed-agents list denies unlisted agent
6. Audit chain append -- each hook produces canonical event
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, GovernanceViolation
from connexum_governance.integrations.openai_agents import (
    OpenAIAgentsGovernance,
    OpenAIAgentsHandoffDeniedError,
    OpenAIAgentsMaxTurnsError,
)
from tests.conftest import make_client, make_transport


# ---------------------------------------------------------------------------
# Shared stubs
# ---------------------------------------------------------------------------

ALLOW = {"decision": "ALLOW", "reason": "Permitted", "auditId": "aud-oai-001"}
DENY = {"decision": "DENY", "reason": "Policy violation", "auditId": "aud-oai-002"}
APPROVAL = {"decision": "REQUIRE_APPROVAL", "reason": "Needs human sign-off", "auditId": "aud-oai-003"}

_ALLOWED_AGENTS = ["research-agent", "writer-agent"]
_APPROVED_MODELS = ["gpt-4o", "gpt-4o-mini"]


def _transport(**overrides: Any) -> httpx.MockTransport:
    defaults: dict[str, Any] = {
        "/api/v1/governance/check-action": ALLOW,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": {"status": "healthy", "version": "1.0.0"},
    }
    defaults.update(overrides)
    return make_transport(defaults)


def _adapter(
    transport: httpx.MockTransport,
    enforce: bool = False,
    allowed: list[str] | None = None,
    approved: list[str] | None = None,
) -> OpenAIAgentsGovernance:
    client = make_client(transport, enforce=enforce)
    return OpenAIAgentsGovernance(
        client=client,
        allowed_agents=allowed if allowed is not None else _ALLOWED_AGENTS,
        approved_models=approved if approved is not None else _APPROVED_MODELS,
        sensitive_tools=["exec_code", "write_file"],
        sensitive_handoff_targets=["admin-agent"],
        sensitive_arg_keys=["query", "content"],
        max_turns_per_run=None,
    )


# ---------------------------------------------------------------------------
# 1. Happy path ALLOW
# ---------------------------------------------------------------------------

class TestOpenAIAgentsHappyPath:
    def test_agent_start_allow(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        assert decision.allowed
        assert "research-agent" in adapter._active_runs

    def test_tool_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        decision = adapter.tool_call("research-agent", "web_search", {"query": "governance docs"})
        assert decision.allowed

    def test_tool_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("research-agent", "web_search", {"query": "docs"})
        adapter.tool_result("research-agent", "web_search", "Clean results", success=True)
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_llm_call_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.llm_call(
            "research-agent", "gpt-4o", messages=[{"role": "user", "content": "Hello"}]
        )
        assert decision.allowed

    def test_llm_result_clean(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        adapter.llm_call("research-agent", "gpt-4o", messages=[])
        adapter.llm_result("research-agent", "gpt-4o", "This is a clean response.")
        captured = capsys.readouterr()
        assert "PHI" not in captured.err

    def test_agent_end_clean(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        adapter.agent_end("research-agent", success=True, summary="Task complete")
        assert "research-agent" not in adapter._active_runs

    def test_full_run_sequence(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        adapter.tool_call("research-agent", "search", {"query": "news"})
        adapter.tool_result("research-agent", "search", "results", success=True)
        adapter.llm_call("research-agent", "gpt-4o", [{"role": "user", "content": "hi"}])
        adapter.llm_result("research-agent", "gpt-4o", "Hello!")
        adapter.agent_end("research-agent", success=True)

    def test_handoff_allow(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        decision = adapter.check_handoff("research-agent", "writer-agent", handoff_input="Draft report")
        assert decision.allowed or decision.requires_approval

    def test_handoff_sensitive_target_requires_approval(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.check_handoff("research-agent", "admin-agent", handoff_input="Escalate")
        assert decision.requires_approval


# ---------------------------------------------------------------------------
# 2. Secret leak / PHI in tool result -- output classifier (G2 equivalent)
# ---------------------------------------------------------------------------

class TestOpenAIAgentsSecretLeak:
    def test_phi_in_tool_result_flags_output_classifier(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("research-agent", "db_query", {"query": "SELECT patients"})
        adapter.tool_result(
            "research-agent",
            "db_query",
            "patient_id=12345, ssn=123-45-6789",
            success=True,
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err

    def test_phi_in_tool_result_marks_report_failure(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("research-agent", "db", {"query": "SELECT 1"})
        adapter.tool_result("research-agent", "db", "npi=1234567890 mrn=ABC", success=True)
        assert any(r["success"] is False for r in reported)

    def test_phi_in_llm_result_flags_exfiltration_scanner(self, capsys):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        adapter.llm_call("research-agent", "gpt-4o", [])
        adapter.llm_result(
            "research-agent",
            "gpt-4o",
            "The patient dob: 1980-01-15 has been processed.",
        )
        captured = capsys.readouterr()
        assert "PHI" in captured.err


# ---------------------------------------------------------------------------
# 3. PHI ingress refusal -- exfiltration scan on tool args
# ---------------------------------------------------------------------------

class TestOpenAIAgentsPhiIngress:
    def test_phi_in_content_arg_denied(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        decision = adapter.tool_call(
            "research-agent",
            "send_message",
            {"content": "Patient SSN: 123-45-6789"},
        )
        assert decision.denied

    def test_phi_in_query_arg_denied(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.tool_call(
            "research-agent",
            "search",
            {"query": "ssn=123-45-6789"},
        )
        assert decision.denied

    def test_clean_args_pass(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.tool_call(
            "research-agent",
            "search",
            {"query": "AI governance compliance"},
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 4. Provider compliance -- unapproved model blocks
# ---------------------------------------------------------------------------

class TestOpenAIAgentsProviderCompliance:
    def test_unapproved_model_denied_at_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start(
            "research-agent",
            pack_binding=["hipaa"],
            model="unapproved-model-xyz",
        )
        assert decision.denied
        assert "unapproved-model-xyz" in decision.reason

    def test_unapproved_model_denied_at_llm_call(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        decision = adapter.llm_call(
            "research-agent",
            "claude-opus-4",  # not in approved list
            messages=[{"role": "user", "content": "hi"}],
        )
        assert decision.denied
        assert "claude-opus-4" in decision.reason

    def test_approved_model_passes(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o-mini")
        decision = adapter.llm_call(
            "research-agent",
            "gpt-4o-mini",
            messages=[{"role": "user", "content": "hello"}],
        )
        assert decision.allowed


# ---------------------------------------------------------------------------
# 5. Subscription gate -- allowed-agents check (maps to subscription gate pattern)
# ---------------------------------------------------------------------------

class TestOpenAIAgentsSubscriptionGate:
    def test_unlisted_agent_denied_at_agent_start(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("unlisted-agent", pack_binding=["hipaa"], model="gpt-4o")
        assert decision.denied
        assert "unlisted-agent" in decision.reason or "allowed agents" in decision.reason.lower()

    def test_empty_pack_binding_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.agent_start("research-agent", pack_binding=[], model="gpt-4o")
        assert decision.denied

    def test_governance_server_deny_raises_violation_when_enforce_true(self):
        transport = _transport(**{"/api/v1/governance/check-action": DENY})
        client = make_client(transport, enforce=True)
        adapter = OpenAIAgentsGovernance(
            client=client,
            allowed_agents=["research-agent"],
            approved_models=["gpt-4o"],
        )
        with pytest.raises(GovernanceViolation):
            adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")

    def test_tool_call_without_agent_start_denied(self):
        adapter = _adapter(_transport())
        decision = adapter.tool_call("research-agent", "search", {"query": "test"})
        assert decision.denied

    def test_max_turns_per_run_enforced(self):
        client = make_client(_transport(), enforce=False)
        adapter = OpenAIAgentsGovernance(
            client=client,
            allowed_agents=["research-agent"],
            approved_models=["gpt-4o"],
            max_turns_per_run=2,
        )
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        adapter.llm_call("research-agent", "gpt-4o", [])
        adapter.llm_call("research-agent", "gpt-4o", [])
        # Third turn exceeds limit
        decision = adapter.llm_call("research-agent", "gpt-4o", [])
        assert decision.denied
        assert "max_turns_per_run" in decision.reason or "Runaway" in decision.reason


# ---------------------------------------------------------------------------
# 6. Audit chain append -- canonical events round-trip
# ---------------------------------------------------------------------------

class TestOpenAIAgentsAuditChain:
    def test_tool_result_uses_audit_id_from_tool_call(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("research-agent", "search", {"query": "docs"})
        adapter.tool_result("research-agent", "search", "results", success=True)

        assert len(reported) == 1
        assert reported[0]["auditId"] == "aud-oai-001"
        assert reported[0]["success"] is True

    def test_llm_result_uses_audit_id_from_llm_call(self):
        reported: list[dict] = []

        def hf(request: httpx.Request) -> httpx.Response:
            if request.url.path == "/api/v1/governance/report-result":
                reported.append(json.loads(request.content))
                return httpx.Response(200, json={"ok": True})
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        adapter.llm_call("research-agent", "gpt-4o", [{"role": "user", "content": "hi"}])
        adapter.llm_result("research-agent", "gpt-4o", "Hello!")

        assert len(reported) >= 1
        assert reported[0]["auditId"] == "aud-oai-001"

    def test_agent_end_fires_check_action(self):
        calls: list[str] = []

        def hf(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json=ALLOW)

        t = httpx.MockTransport(hf)
        adapter = _adapter(t)
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        adapter.agent_end("research-agent", success=True)

        action_calls = [c for c in calls if "check-action" in c]
        assert len(action_calls) >= 2  # agent_start + agent_end

    def test_turn_counter_increments(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        adapter.llm_call("research-agent", "gpt-4o", [])
        adapter.llm_call("research-agent", "gpt-4o", [])
        assert adapter._turn_counters.get("research-agent", 0) == 2

    def test_tool_call_counter_increments(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["soc2"], model="gpt-4o")
        adapter.tool_call("research-agent", "search", {"query": "a"})
        adapter.tool_call("research-agent", "search", {"query": "b"})
        assert adapter._tool_call_counters.get("research-agent", 0) == 2

    def test_state_cleared_after_agent_end(self):
        adapter = _adapter(_transport())
        adapter.agent_start("research-agent", pack_binding=["hipaa"], model="gpt-4o")
        adapter.agent_end("research-agent", success=True)
        assert "research-agent" not in adapter._active_runs
        assert "research-agent" not in adapter._turn_counters
        assert "research-agent" not in adapter._tool_call_counters
