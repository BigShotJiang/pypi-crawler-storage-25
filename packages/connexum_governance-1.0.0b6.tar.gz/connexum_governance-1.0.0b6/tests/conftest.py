"""Shared fixtures for governance SDK tests."""

import json
from typing import Any

import httpx
import pytest

from connexum_governance import GovernanceClient, AsyncGovernanceClient


ALLOW_RESPONSE = {
    "decision": "ALLOW",
    "reason": "Action permitted",
    "auditId": "aud-001",
}

DENY_RESPONSE = {
    "decision": "DENY",
    "reason": "Tool blocked by policy",
    "auditId": "aud-002",
}

APPROVAL_RESPONSE = {
    "decision": "REQUIRE_APPROVAL",
    "reason": "Requires manager sign-off",
    "auditId": "aud-003",
}

HEALTH_RESPONSE = {
    "status": "healthy",
    "version": "1.0.0",
}


def make_transport(responses: dict[str, Any]) -> httpx.MockTransport:
    """Create a mock transport that returns canned responses by path."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path

        if path in responses:
            body = responses[path]
            if callable(body):
                body = body(request)
            return httpx.Response(200, json=body)

        return httpx.Response(404, json={"error": "not found"})

    return httpx.MockTransport(handler)


@pytest.fixture
def allow_transport() -> httpx.MockTransport:
    """Transport that allows everything."""
    return make_transport({
        "/api/v1/governance/check-action": ALLOW_RESPONSE,
        "/api/v1/governance/check-task": ALLOW_RESPONSE,
        "/api/v1/governance/check-plan": ALLOW_RESPONSE,
        "/api/v1/governance/check-delegation": ALLOW_RESPONSE,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": HEALTH_RESPONSE,
    })


@pytest.fixture
def deny_transport() -> httpx.MockTransport:
    """Transport that denies everything."""
    return make_transport({
        "/api/v1/governance/check-action": DENY_RESPONSE,
        "/api/v1/governance/check-task": DENY_RESPONSE,
        "/api/v1/governance/check-plan": DENY_RESPONSE,
        "/api/v1/governance/check-delegation": DENY_RESPONSE,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": HEALTH_RESPONSE,
    })


@pytest.fixture
def approval_transport() -> httpx.MockTransport:
    """Transport that requires approval for everything."""
    return make_transport({
        "/api/v1/governance/check-action": APPROVAL_RESPONSE,
        "/api/v1/governance/check-task": APPROVAL_RESPONSE,
        "/api/v1/governance/check-plan": APPROVAL_RESPONSE,
        "/api/v1/governance/check-delegation": APPROVAL_RESPONSE,
        "/api/v1/governance/report-result": {"ok": True},
        "/api/v1/health": HEALTH_RESPONSE,
    })


def make_client(
    transport: httpx.MockTransport,
    enforce: bool = True,
) -> GovernanceClient:
    """Create a GovernanceClient with a mock transport."""
    client = GovernanceClient(
        api_url="http://test-server",
        license_key="test-key",
        enforce=enforce,
    )
    client._client = httpx.Client(
        base_url="http://test-server",
        headers=client._client.headers,
        transport=transport,
    )
    return client


def make_async_client(
    transport: httpx.MockTransport,
    enforce: bool = True,
) -> AsyncGovernanceClient:
    """Create an AsyncGovernanceClient with a mock transport."""
    client = AsyncGovernanceClient(
        api_url="http://test-server",
        license_key="test-key",
        enforce=enforce,
    )
    client._client = httpx.AsyncClient(
        base_url="http://test-server",
        headers=client._client.headers,
        transport=transport,
    )
    return client
