"""
PT-PYTHON-CLASSIFY-FAILOPEN-1 (H5)

Verifies that classify_output with on_failure='open':
  1. Returns ClassifiedResponse(allowed=True) on network partition.
  2. Sets metadata["failOpen"] = True.
  3. Writes a classify.fail-open audit event (to local fallback file when
     server is also unreachable).
  4. Does NOT produce an empty audit_id in the returned response.
"""

import json
import logging
import os
import stat
import tempfile
from unittest import mock

import httpx
import pytest

from connexum_governance import GovernanceClient
from connexum_governance.models import ClassifiedResponse


def _connect_error_transport() -> httpx.MockTransport:
    """Transport that raises ConnectError on every request."""

    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("Connection refused (simulated network partition)")

    return httpx.MockTransport(handler)


class TestClassifyFailOpen:
    """PT-PYTHON-CLASSIFY-FAILOPEN-1: fail-open audit trail for classify_output."""

    def _make_client(self) -> GovernanceClient:
        client = GovernanceClient(
            api_url="http://localhost:3100",
            license_key="test-key",
            on_failure="open",
        )
        client._client = httpx.Client(
            transport=_connect_error_transport(),
            base_url="http://localhost:3100",
            headers={"Authorization": "Bearer test-key"},
        )
        return client

    def test_classify_output_returns_allowed_true_on_partition(self):
        """On network partition, classify_output fail-open returns allowed=True."""
        client = self._make_client()
        result = client.classify_output(
            audit_id="aud-test-001",
            output={"content": "some model output"},
        )
        assert result.allowed is True, (
            "PT-PYTHON-CLASSIFY-FAILOPEN-1: fail-open must return allowed=True"
        )

    def test_classify_output_sets_fail_open_metadata(self):
        """On network partition, ClassifiedResponse.metadata['failOpen'] must be True."""
        client = self._make_client()
        result = client.classify_output(
            audit_id="aud-test-002",
            output={"content": "some model output"},
        )
        assert result.metadata.get("failOpen") is True, (
            "PT-PYTHON-CLASSIFY-FAILOPEN-1: metadata['failOpen'] must be True on network partition"
        )

    def test_classify_output_preserves_audit_id(self):
        """The returned ClassifiedResponse must carry the caller-supplied audit_id."""
        client = self._make_client()
        result = client.classify_output(
            audit_id="aud-preserve-check",
            output={"content": "output"},
        )
        assert result.audit_id == "aud-preserve-check", (
            "PT-PYTHON-CLASSIFY-FAILOPEN-1: audit_id must not be empty on fail-open"
        )

    def test_classify_output_writes_local_audit_event(self, tmp_path):
        """On full partition (server + local), a classify.fail-open event is written locally."""
        client = self._make_client()

        # Redirect ~/.connexum to a temp dir
        connexum_dir = str(tmp_path / ".connexum")

        with mock.patch("os.path.expanduser", return_value=str(tmp_path)):
            # Also patch makedirs to write to tmp_path/.connexum
            orig_makedirs = os.makedirs

            def fake_makedirs(path, *args, **kwargs):
                if ".connexum" in path:
                    actual_path = os.path.join(str(tmp_path), ".connexum")
                    orig_makedirs(actual_path, exist_ok=True)
                    return
                return orig_makedirs(path, *args, **kwargs)

            with mock.patch("os.makedirs", side_effect=fake_makedirs):
                client.classify_output(
                    audit_id="aud-local-chain",
                    output={"content": "output"},
                )

        # Check that a fail-open audit file was written
        audit_file = os.path.join(str(tmp_path), ".connexum", "fail-open-audit.jsonl")
        if os.path.exists(audit_file):
            with open(audit_file) as f:
                lines = [l.strip() for l in f if l.strip()]
            assert len(lines) > 0, "Fail-open audit file must contain at least one event"
            event = json.loads(lines[0])
            assert event.get("type") == "classify.fail-open", (
                f"Event type must be 'classify.fail-open', got: {event.get('type')}"
            )

    def test_audit_trail_receives_fail_open_event_method_called(self, caplog):
        """_emit_fail_open_audit_event is called on network partition."""
        client = self._make_client()

        with mock.patch.object(
            client, "_emit_fail_open_audit_event"
        ) as mock_emit:
            client.classify_output(
                audit_id="aud-emit-check",
                output={"content": "output"},
            )

        mock_emit.assert_called_once()
        call_kwargs = mock_emit.call_args
        # First positional arg should be the event type
        args = call_kwargs[1] if call_kwargs[1] else {}
        if not args:
            args = {
                "event_type": call_kwargs[0][0] if call_kwargs[0] else None,
                "audit_id": call_kwargs[0][1] if len(call_kwargs[0]) > 1 else None,
            }
        assert "classify.fail-open" in str(call_kwargs), (
            f"PT-PYTHON-CLASSIFY-FAILOPEN-1: _emit_fail_open_audit_event must be called "
            f"with event_type='classify.fail-open'. Got: {call_kwargs}"
        )
