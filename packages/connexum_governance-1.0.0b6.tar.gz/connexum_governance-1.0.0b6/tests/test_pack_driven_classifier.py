"""
E2E tests for PackDrivenClassifier (Python mirror of TypeScript ab3fde4).

Tests confirm:
1. load_from_packs() hydrates the registry from pack descriptors.
2. classify() matches categories against sample inputs.
3. apply_actions() emits canonical PackEnforcementAuditEvent with all required fields.
4. evaluate() (classify + apply_actions) works end-to-end.
5. register_entry() allows test-wiring of custom classifiers.
6. Project-scoped pack selection (active_pack_ids) filters correctly.
7. GovernanceClient.fetch_pack_registry() hydrates the classifier via mock server.
8. GovernanceClient.set_project_packs() calls the correct endpoint.
9. Cache TTL: load_from_packs does not re-process when cache is warm (force_refresh=False).
10. drain_audit_events() clears the log after draining.
"""

import re
import hashlib
import pytest
import httpx

from connexum_governance.classification.pack_driven_classifier import (
    PackDrivenClassifier,
    ClassificationContext,
    PackEnforcementAuditEvent,
    get_global_classifier,
    set_global_classifier,
)
from tests.conftest import make_transport


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

HIPAA_PACK_DESCRIPTOR = {
    "id": "hipaa",
    "name": "HIPAA",
    "version": "1.0.0",
    "dataPolicy": {
        "scanCategories": ["PHI", "PII"],
        "categoryActions": {"PHI": "BLOCK", "PII": "WARN"},
        "encryptionRequired": True,
    },
    "categoryClassifiers": {
        "PHI": {
            "pattern": r"\b\d{3}-\d{2}-\d{4}\b",
            "references": ["45 CFR 164.514(b)(2)"],
        },
        "PII": {
            "pattern": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
            "references": ["PII email pattern"],
        },
    },
}

FERPA_PACK_DESCRIPTOR = {
    "id": "ferpa",
    "name": "FERPA",
    "version": "1.0.0",
    "dataPolicy": {
        "scanCategories": ["EDUCATION_RECORD", "CREDENTIALS"],
        "categoryActions": {"EDUCATION_RECORD": "BLOCK", "CREDENTIALS": "BLOCK"},
        "encryptionRequired": True,
    },
    "categoryClassifiers": {
        "EDUCATION_RECORD": {
            "pattern": r"(?:student[_\-\s]?id|GPA|transcript)",
            "references": ["34 CFR 99.3"],
        },
        "CREDENTIALS": {
            "pattern": r"(?:API_KEY|password)\s*=\s*\S+",
            "references": [],
        },
    },
}


@pytest.fixture
def classifier_with_hipaa():
    c = PackDrivenClassifier()
    c.load_from_packs([HIPAA_PACK_DESCRIPTOR], force_refresh=True)
    return c


@pytest.fixture
def classifier_with_both():
    c = PackDrivenClassifier()
    c.load_from_packs([HIPAA_PACK_DESCRIPTOR, FERPA_PACK_DESCRIPTOR], force_refresh=True)
    return c


# ---------------------------------------------------------------------------
# Test 1: load_from_packs hydrates registry
# ---------------------------------------------------------------------------

class TestLoadFromPacks:
    def test_registry_size_after_load(self, classifier_with_hipaa):
        # PHI + PII = 2 entries
        assert classifier_with_hipaa.registry_size == 2

    def test_load_two_packs(self, classifier_with_both):
        # hipaa: PHI + PII (2), ferpa: EDUCATION_RECORD + CREDENTIALS (2) = 4
        assert classifier_with_both.registry_size == 4

    def test_load_empty_list_does_not_crash(self):
        c = PackDrivenClassifier()
        c.load_from_packs([], force_refresh=True)
        assert c.registry_size == 0

    def test_list_registered_entries(self, classifier_with_hipaa):
        entries = classifier_with_hipaa.list_registered_entries()
        pack_ids = {e[0] for e in entries}
        assert "hipaa" in pack_ids

    def test_duplicate_load_overwrites_not_doubles(self, classifier_with_hipaa):
        # Loading the same pack again should NOT double the count
        initial_size = classifier_with_hipaa.registry_size
        classifier_with_hipaa.load_from_packs([HIPAA_PACK_DESCRIPTOR], force_refresh=True)
        assert classifier_with_hipaa.registry_size == initial_size


# ---------------------------------------------------------------------------
# Test 2: classify() matches categories
# ---------------------------------------------------------------------------

class TestClassify:
    def test_phi_input_matches_hipaa_phi(self, classifier_with_hipaa):
        result = classifier_with_hipaa.classify("Patient SSN: 123-45-6789")
        assert result.has_match
        phi = next((m for m in result.matched if m.category_id == "PHI"), None)
        assert phi is not None
        assert phi.pack_id == "hipaa"
        assert phi.action == "BLOCK"
        assert phi.pack_version == "1.0.0"

    def test_email_matches_pii(self, classifier_with_hipaa):
        result = classifier_with_hipaa.classify("Contact: user@example.com")
        assert result.has_match
        pii = next((m for m in result.matched if m.category_id == "PII"), None)
        assert pii is not None
        assert pii.action == "WARN"

    def test_clean_input_no_match(self, classifier_with_hipaa):
        result = classifier_with_hipaa.classify("The weather today is sunny.")
        assert not result.has_match
        assert result.matched == []

    def test_education_record_matches_ferpa(self, classifier_with_both):
        result = classifier_with_both.classify("Student ID: STU12345 GPA 3.8 transcript")
        assert result.has_match
        educ = next((m for m in result.matched if m.category_id == "EDUCATION_RECORD"), None)
        assert educ is not None
        assert educ.pack_id == "ferpa"
        assert educ.action == "BLOCK"

    def test_active_pack_ids_filters_correctly(self, classifier_with_both):
        # With only ferpa active, HIPAA PHI must NOT fire
        ctx = ClassificationContext(active_pack_ids=["ferpa"])
        result = classifier_with_both.classify("Patient SSN: 123-45-6789", ctx)
        hipaa_match = next((m for m in result.matched if m.pack_id == "hipaa"), None)
        assert hipaa_match is None, "HIPAA must not fire when project is scoped to ferpa only"

    def test_active_pack_ids_includes_correct_pack(self, classifier_with_both):
        # With only hipaa active, FERPA must not fire
        ctx = ClassificationContext(active_pack_ids=["hipaa"])
        result = classifier_with_both.classify("Student ID: STU12345 GPA 3.8", ctx)
        ferpa_match = next((m for m in result.matched if m.pack_id == "ferpa"), None)
        assert ferpa_match is None


# ---------------------------------------------------------------------------
# Test 3: apply_actions() emits canonical audit events
# ---------------------------------------------------------------------------

class TestApplyActions:
    def test_emits_block_event_for_phi(self, classifier_with_hipaa):
        input_text = "Patient SSN: 123-45-6789"
        result = classifier_with_hipaa.classify(input_text)
        decision = classifier_with_hipaa.apply_actions(result.matched, ClassificationContext(), input_text)

        assert decision.action == "BLOCK"
        events = classifier_with_hipaa.drain_audit_events()
        block_events = [e for e in events if e.type == "pack.enforcement.block"]
        assert len(block_events) >= 1
        evt = block_events[0]
        assert evt.pack_id == "hipaa"
        assert evt.category_id == "PHI"
        assert evt.action == "BLOCK"
        assert evt.pack_version == "1.0.0"
        assert evt.decision_id
        assert evt.timestamp

    def test_subject_digest_is_sha256_not_raw_input(self, classifier_with_hipaa):
        input_text = "Patient SSN: 999-99-9999"
        result = classifier_with_hipaa.classify(input_text)
        classifier_with_hipaa.apply_actions(result.matched, ClassificationContext(), input_text)

        events = classifier_with_hipaa.drain_audit_events()
        assert len(events) >= 1
        evt = events[0]
        # Must be a 64-char hex string (SHA-256)
        assert re.match(r"^[0-9a-f]{64}$", evt.subject_digest), (
            f"subject_digest must be SHA-256 hex, got: {evt.subject_digest}"
        )
        # Must NOT contain the raw SSN
        assert "999-99-9999" not in evt.subject_digest

    def test_multiple_matched_categories_emit_one_event_each(self, classifier_with_both):
        # Input that triggers both PHI (SSN) and EDUCATION_RECORD (GPA)
        input_text = "SSN: 123-45-6789 and GPA transcript"
        result = classifier_with_both.classify(input_text)
        classifier_with_both.apply_actions(result.matched, ClassificationContext(), input_text)

        events = classifier_with_both.drain_audit_events()
        assert len(events) >= 2, f"Expected >= 2 events for multi-match, got {len(events)}"

    def test_strictest_wins_block_over_warn(self, classifier_with_hipaa):
        # SSN (BLOCK) + email (WARN) in same input -> final action = BLOCK
        input_text = "SSN: 123-45-6789 and user@example.com"
        result = classifier_with_hipaa.classify(input_text)
        decision = classifier_with_hipaa.apply_actions(result.matched, ClassificationContext(), input_text)
        assert decision.action == "BLOCK"

    def test_all_events_have_required_canonical_fields(self, classifier_with_both):
        input_text = "SSN: 123-45-6789 Student ID: STU111 GPA transcript"
        result = classifier_with_both.classify(input_text)
        classifier_with_both.apply_actions(result.matched, ClassificationContext(), input_text)
        events = classifier_with_both.drain_audit_events()
        for evt in events:
            assert evt.pack_id, f"Missing packId: {evt}"
            assert evt.category_id, f"Missing categoryId: {evt}"
            assert evt.action, f"Missing action: {evt}"
            assert evt.pack_version, f"Missing packVersion: {evt}"
            assert evt.decision_id, f"Missing decisionId: {evt}"
            assert evt.subject_digest, f"Missing subjectDigest: {evt}"
            assert evt.timestamp, f"Missing timestamp: {evt}"
            assert evt.type.startswith("pack.enforcement."), f"Bad event type: {evt.type}"


# ---------------------------------------------------------------------------
# Test 4: evaluate() convenience method
# ---------------------------------------------------------------------------

class TestEvaluate:
    def test_evaluate_phi(self, classifier_with_hipaa):
        decision = classifier_with_hipaa.evaluate("Patient SSN: 123-45-6789")
        assert decision.action == "BLOCK"
        assert any(m.category_id == "PHI" for m in decision.matched)

    def test_evaluate_clean_input(self, classifier_with_hipaa):
        decision = classifier_with_hipaa.evaluate("The project deadline is next Monday.")
        assert decision.action == "ALLOW"
        assert decision.matched == []


# ---------------------------------------------------------------------------
# Test 5: register_entry() allows test-wiring
# ---------------------------------------------------------------------------

class TestRegisterEntry:
    def test_custom_classifier_function(self):
        c = PackDrivenClassifier()
        c.register_entry(
            pack_id="test-pack",
            pack_version="0.1.0",
            category_id="CUSTOM_SECRET",
            action="BLOCK",
            classifier_fn=lambda text, ctx: "CANARY" in text,
        )
        result = c.classify("This contains CANARY in the text")
        assert result.has_match
        match = result.matched[0]
        assert match.category_id == "CUSTOM_SECRET"
        assert match.action == "BLOCK"

    def test_custom_pattern(self):
        c = PackDrivenClassifier()
        c.register_entry(
            pack_id="test-pack",
            pack_version="0.1.0",
            category_id="CUSTOM_PATTERN",
            action="WARN",
            pattern=re.compile(r"MAGIC_TOKEN_\d{6}"),
        )
        result = c.classify("Input contains MAGIC_TOKEN_123456 here")
        assert result.has_match
        assert result.matched[0].action == "WARN"

    def test_custom_function_takes_precedence_over_pattern(self):
        c = PackDrivenClassifier()
        # classifier_fn should run and pattern should be ignored
        c.register_entry(
            pack_id="test-pack",
            pack_version="0.1.0",
            category_id="PRIORITY",
            action="BLOCK",
            pattern=re.compile(r"NEVER_MATCH_THIS_XYZ999"),
            classifier_fn=lambda text, ctx: "TRIGGER" in text,
        )
        assert c.classify("TRIGGER present").has_match
        assert not c.classify("Something else entirely").has_match


# ---------------------------------------------------------------------------
# Test 6: drain and peek audit events
# ---------------------------------------------------------------------------

class TestAuditLogDrain:
    def test_drain_clears_log(self, classifier_with_hipaa):
        classifier_with_hipaa.evaluate("SSN: 123-45-6789")
        events_first = classifier_with_hipaa.drain_audit_events()
        assert len(events_first) >= 1
        events_second = classifier_with_hipaa.drain_audit_events()
        assert events_second == []

    def test_peek_does_not_drain(self, classifier_with_hipaa):
        classifier_with_hipaa.evaluate("SSN: 123-45-6789")
        events_peek1 = classifier_with_hipaa.peek_audit_events()
        events_peek2 = classifier_with_hipaa.peek_audit_events()
        assert len(events_peek1) == len(events_peek2)
        # Now drain -- should still have the events
        drained = classifier_with_hipaa.drain_audit_events()
        assert len(drained) == len(events_peek1)


# ---------------------------------------------------------------------------
# Test 7: GovernanceClient.fetch_pack_registry() via mock server
# ---------------------------------------------------------------------------

class TestFetchPackRegistry:
    def test_fetch_pack_registry_returns_list(self):
        transport = make_transport({
            "/api/v1/packs/registry": {
                "packs": [HIPAA_PACK_DESCRIPTOR, FERPA_PACK_DESCRIPTOR],
                "count": 2,
            }
        })
        from connexum_governance import GovernanceClient
        client = GovernanceClient(api_url="http://test-server", license_key="test-key")
        client._client = httpx.Client(
            base_url="http://test-server",
            headers=client._client.headers,
            transport=transport,
        )

        registry = client.fetch_pack_registry(force_refresh=True)
        assert isinstance(registry, list)
        assert len(registry) == 2
        ids = {p["id"] for p in registry}
        assert "hipaa" in ids
        assert "ferpa" in ids

    def test_fetch_pack_registry_direct_list_response(self):
        # Server returns a plain list (not wrapped in {packs: [...]})
        transport = make_transport({
            "/api/v1/packs/registry": [HIPAA_PACK_DESCRIPTOR],
        })
        from connexum_governance import GovernanceClient
        client = GovernanceClient(api_url="http://test-server", license_key="test-key")
        client._client = httpx.Client(
            base_url="http://test-server",
            headers=client._client.headers,
            transport=transport,
        )
        registry = client.fetch_pack_registry(force_refresh=True)
        assert isinstance(registry, list)
        assert len(registry) == 1

    def test_fetch_and_hydrate_classifier(self):
        transport = make_transport({
            "/api/v1/packs/registry": {
                "packs": [HIPAA_PACK_DESCRIPTOR],
                "count": 1,
            }
        })
        from connexum_governance import GovernanceClient
        client = GovernanceClient(api_url="http://test-server", license_key="test-key")
        client._client = httpx.Client(
            base_url="http://test-server",
            headers=client._client.headers,
            transport=transport,
        )

        registry = client.fetch_pack_registry(force_refresh=True)
        c = PackDrivenClassifier()
        c.load_from_packs(registry, force_refresh=True)

        # The pattern ships as a string in the descriptor -- classifier should compile it
        result = c.classify("SSN: 123-45-6789")
        assert result.has_match, "Classifier must detect SSN via registry-provided pattern"

    def test_fetch_pack_registry_fail_open(self):
        # Server is unreachable -- with on_failure='open' should return []
        import httpx as _httpx

        def fail_handler(request):
            raise _httpx.ConnectError("connection refused")

        transport = _httpx.MockTransport(fail_handler)
        from connexum_governance import GovernanceClient
        client = GovernanceClient(
            api_url="http://test-server",
            license_key="test-key",
            on_failure="open",
        )
        client._client = _httpx.Client(
            base_url="http://test-server",
            headers=client._client.headers,
            transport=transport,
        )
        registry = client.fetch_pack_registry(force_refresh=True)
        assert registry == [], "Fail-open must return empty list when server is unreachable"


# ---------------------------------------------------------------------------
# Test 8: GovernanceClient.set_project_packs()
# ---------------------------------------------------------------------------

class TestSetProjectPacks:
    def test_set_project_packs_success(self):
        RESPONSE = {
            "projectId": "proj-abc",
            "selectedPackIds": ["hipaa", "soc2"],
            "selectedPackVersions": {},
            "updatedAt": "2026-04-24T00:00:00Z",
            "updatedBy": "api",
        }

        def handler(request: httpx.Request) -> httpx.Response:
            assert "/api/v1/projects/proj-abc/packs" in request.url.path
            assert request.method == "POST"
            return httpx.Response(200, json=RESPONSE)

        transport = httpx.MockTransport(handler)
        from connexum_governance import GovernanceClient
        client = GovernanceClient(
            api_url="http://test-server",
            license_key="test-key",
            project_id="proj-abc",
        )
        client._client = httpx.Client(
            base_url="http://test-server",
            headers=client._client.headers,
            transport=transport,
        )
        # This should not raise
        client.set_project_packs(["hipaa", "soc2"])

    def test_set_project_packs_raises_without_project_id(self):
        from connexum_governance import GovernanceClient
        client = GovernanceClient(api_url="http://test-server", license_key="test-key")
        with pytest.raises(ValueError, match="project_id"):
            client.set_project_packs(["hipaa"])


# ---------------------------------------------------------------------------
# Test 9: Cache TTL
# ---------------------------------------------------------------------------

class TestCacheTTL:
    def test_warm_cache_skips_re_processing(self):
        c = PackDrivenClassifier()
        c.load_from_packs([HIPAA_PACK_DESCRIPTOR], force_refresh=True)
        size_after_first = c.registry_size

        # Load again WITHOUT force_refresh -- should skip (cache warm)
        # Add a second pack to the input -- it should NOT be loaded because cache is warm
        c.load_from_packs([HIPAA_PACK_DESCRIPTOR, FERPA_PACK_DESCRIPTOR], force_refresh=False)
        assert c.registry_size == size_after_first, (
            "Cache-warm load must not re-process input (registry size unchanged)"
        )

    def test_force_refresh_overrides_cache(self):
        c = PackDrivenClassifier()
        c.load_from_packs([HIPAA_PACK_DESCRIPTOR], force_refresh=True)

        c.load_from_packs([HIPAA_PACK_DESCRIPTOR, FERPA_PACK_DESCRIPTOR], force_refresh=True)
        # Now should include both packs
        pack_ids = {e[0] for e in c.list_registered_entries()}
        assert "ferpa" in pack_ids, "force_refresh=True must re-process all packs"


# ---------------------------------------------------------------------------
# Test 10: Global singleton
# ---------------------------------------------------------------------------

class TestGlobalSingleton:
    def test_get_global_classifier_returns_same_instance(self):
        c1 = get_global_classifier()
        c2 = get_global_classifier()
        assert c1 is c2

    def test_set_global_classifier(self):
        original = get_global_classifier()
        new_classifier = PackDrivenClassifier()
        set_global_classifier(new_classifier)
        assert get_global_classifier() is new_classifier
        # Restore
        set_global_classifier(original)
