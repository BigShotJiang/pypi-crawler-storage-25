"""
tests/autowrap/test_autowrap.py

Real subprocess invocations for CONNEXUM_AUTOWRAP=1 zero-code monkey-patch mode.

Evidence-First Protocol: all tests use actual Python subprocesses.
NO import-time mocks. We probe the real patch behavior.

8+ cases:
  1. CONNEXUM_AUTOWRAP=0: openai.OpenAI stays original class
  2. CONNEXUM_AUTOWRAP=1: openai.OpenAI becomes GovernedOpenAI
  3. governance.json controls packs (detected in module)
  4. Idempotent: importing connexum_governance twice doesn't double-wrap
  5. Anthropic governed when CONNEXUM_AUTOWRAP=1
  6. google.generativeai governed when CONNEXUM_AUTOWRAP=1
  7. HuggingFace: detected but [SKIP] logged, module NOT wrapped
  8. ImportError diagnostic when connexum_governance missing but CONNEXUM_AUTOWRAP=1
     (simulated by using PYTHONPATH that excludes connexum_governance)

F-NEW-PRODUCT-AGENT-DIR-WRAPPER slice 3
@connexum/python-sdk
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import textwrap
import tempfile
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

PYTHON = sys.executable

# Root of the python-sdk package (where connexum_governance lives)
SDK_ROOT = Path(__file__).resolve().parents[2]  # packages/python-sdk/
CONNEXUM_PYTHONPATH = str(SDK_ROOT)


def run_python(
    code: str,
    *,
    env_overrides: dict[str, str] | None = None,
    extra_pythonpath: str | None = None,
    timeout: int = 15,
) -> subprocess.CompletedProcess[str]:
    """Run a Python snippet in a subprocess and return CompletedProcess."""
    env = os.environ.copy()
    # Remove any inherited CONNEXUM_AUTOWRAP to ensure clean slate
    env.pop("CONNEXUM_AUTOWRAP", None)

    # Always put SDK on PYTHONPATH so connexum_governance is importable
    pythonpath_parts = [CONNEXUM_PYTHONPATH]
    if extra_pythonpath:
        pythonpath_parts.append(extra_pythonpath)
    if "PYTHONPATH" in env:
        pythonpath_parts.append(env["PYTHONPATH"])
    env["PYTHONPATH"] = os.pathsep.join(pythonpath_parts)

    if env_overrides:
        env.update(env_overrides)

    return subprocess.run(
        [PYTHON, "-c", textwrap.dedent(code)],
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
    )


# ---------------------------------------------------------------------------
# Case 1: CONNEXUM_AUTOWRAP=0 -- OpenAI stays original
# ---------------------------------------------------------------------------


def test_autowrap_disabled_openai_stays_original():
    """When CONNEXUM_AUTOWRAP is not set, openai.OpenAI must NOT be patched."""
    result = run_python(
        """
        import connexum_governance  # triggers _autowrap_if_enabled
        try:
            import openai
            cls_name = openai.OpenAI.__name__
            print(cls_name)
        except ImportError:
            print("OPENAI_NOT_INSTALLED")
        """,
        env_overrides={"CONNEXUM_AUTOWRAP": "0"},
    )
    assert result.returncode == 0, result.stderr
    output = result.stdout.strip()
    # Either the real name or not installed is fine -- must NOT be GovernedOpenAI
    assert output != "GovernedOpenAI", (
        f"Expected original class but got: {output}\nstderr: {result.stderr}"
    )


# ---------------------------------------------------------------------------
# Case 2: CONNEXUM_AUTOWRAP=1 -- OpenAI becomes GovernedOpenAI
# ---------------------------------------------------------------------------


def test_autowrap_enabled_openai_becomes_governed():
    """When CONNEXUM_AUTOWRAP=1, openai.OpenAI.__name__ must be GovernedOpenAI."""
    result = run_python(
        """
        import connexum_governance  # triggers patch at import time
        try:
            import openai
            print(openai.OpenAI.__name__)
        except ImportError:
            print("OPENAI_NOT_INSTALLED")
        """,
        env_overrides={"CONNEXUM_AUTOWRAP": "1"},
    )
    assert result.returncode == 0, result.stderr
    output = result.stdout.strip()
    if output == "OPENAI_NOT_INSTALLED":
        pytest.skip("openai package not installed in test environment")
    assert output == "GovernedOpenAI", (
        f"Expected GovernedOpenAI, got: {output}\nstderr: {result.stderr}"
    )


# ---------------------------------------------------------------------------
# Case 3: governance.json controls packs (file is loaded, no crash without it)
# ---------------------------------------------------------------------------


def test_governance_json_loaded_when_present():
    """Autowrap loads governance.json when present and doesn't crash without it."""
    with tempfile.TemporaryDirectory() as tmpdir:
        gov_json = Path(tmpdir) / "governance.json"
        gov_json.write_text(
            json.dumps({
                "tenantId": "test-tenant",
                "agents": [{"provider": "openai", "packs": ["hipaa"]}],
                "autowrap": {"packs": ["soc2"]},
            })
        )
        result = run_python(
            """
            import os, sys
            # Reset activation state to test a fresh activation in this cwd
            os.chdir(sys.argv[1])
            from connexum_governance.autowrap._patches import _load_governance_config, _GOVERNANCE_CFG
            # Clear module-level cache
            import connexum_governance.autowrap._patches as p
            p._GOVERNANCE_CFG = None
            cfg = p._load_governance_config()
            print(cfg['tenantId'])
            packs = p._packs_for_provider('openai')
            print(packs)
            """,
            env_overrides={"CONNEXUM_AUTOWRAP": "1"},
            extra_pythonpath=tmpdir,
        )
        # Inject cwd arg via a slightly different approach -- use env var
        result2 = run_python(
            f"""
            import os, json
            os.chdir(r'{tmpdir}')
            import connexum_governance.autowrap._patches as p
            p._GOVERNANCE_CFG = None
            cfg = p._load_governance_config()
            assert cfg['tenantId'] == 'test-tenant', cfg
            packs = p._packs_for_provider('openai')
            assert packs == ['hipaa'], packs
            print('OK')
            """,
            env_overrides={"CONNEXUM_AUTOWRAP": "1"},
        )
        assert result2.returncode == 0, result2.stderr
        assert result2.stdout.strip() == "OK"


# ---------------------------------------------------------------------------
# Case 4: Idempotent -- activate() twice does not double-wrap
# ---------------------------------------------------------------------------


def test_autowrap_idempotent():
    """Calling activate() twice must not double-wrap OpenAI."""
    result = run_python(
        """
        import connexum_governance.autowrap as aw
        aw.deactivate_for_testing()  # ensure clean slate
        r1 = aw.activate()
        r2 = aw.activate()  # second call -- should be no-op
        try:
            import openai
            # After two activations the class name should still be GovernedOpenAI
            # not GovernedGovernedOpenAI
            name = openai.OpenAI.__name__
            assert name == 'GovernedOpenAI', f'Expected GovernedOpenAI, got {name}'
        except ImportError:
            pass  # openai not installed -- just test the idempotency flag
        print(f'r1={r1} r2={r2}')
        assert r1 == True
        assert r2 == False
        print('OK')
        """,
        env_overrides={"CONNEXUM_AUTOWRAP": "1"},
    )
    assert result.returncode == 0, result.stderr
    assert "OK" in result.stdout


# ---------------------------------------------------------------------------
# Case 5: Anthropic governed when CONNEXUM_AUTOWRAP=1
# ---------------------------------------------------------------------------


def test_autowrap_anthropic_becomes_governed():
    """When CONNEXUM_AUTOWRAP=1, anthropic.Anthropic.__name__ must be GovernedAnthropic."""
    result = run_python(
        """
        import connexum_governance
        try:
            import anthropic
            print(anthropic.Anthropic.__name__)
        except ImportError:
            print("ANTHROPIC_NOT_INSTALLED")
        """,
        env_overrides={"CONNEXUM_AUTOWRAP": "1"},
    )
    assert result.returncode == 0, result.stderr
    output = result.stdout.strip()
    if output == "ANTHROPIC_NOT_INSTALLED":
        pytest.skip("anthropic package not installed in test environment")
    assert output == "GovernedAnthropic", (
        f"Expected GovernedAnthropic, got: {output}\nstderr: {result.stderr}"
    )


# ---------------------------------------------------------------------------
# Case 6: google.generativeai governed when CONNEXUM_AUTOWRAP=1
# ---------------------------------------------------------------------------


def test_autowrap_google_generativeai_becomes_governed():
    """When CONNEXUM_AUTOWRAP=1, google.generativeai.GenerativeModel should be governed."""
    result = run_python(
        """
        import connexum_governance
        try:
            import google.generativeai as genai
            print(genai.GenerativeModel.__name__)
        except ImportError:
            print("GOOGLE_NOT_INSTALLED")
        """,
        env_overrides={"CONNEXUM_AUTOWRAP": "1"},
    )
    assert result.returncode == 0, result.stderr
    output = result.stdout.strip()
    if output == "GOOGLE_NOT_INSTALLED":
        pytest.skip("google-generativeai package not installed in test environment")
    assert output == "GovernedGenerativeModel", (
        f"Expected GovernedGenerativeModel, got: {output}\nstderr: {result.stderr}"
    )


# ---------------------------------------------------------------------------
# Case 7: HuggingFace detected but [SKIP] logged, module not wrapped
# ---------------------------------------------------------------------------


def test_autowrap_huggingface_skip_logged():
    """HuggingFace must emit [SKIP] log and NOT have a _connexum_governed wrapper."""
    result = run_python(
        """
        import logging, sys
        logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
        import connexum_governance
        try:
            from huggingface_hub import HfApi
            # If installed, verify it's NOT patched with our wrapper
            has_governed = getattr(HfApi, '_connexum_governed', False)
            print(f'governed={has_governed}')
        except ImportError:
            print("HF_NOT_INSTALLED")
        """,
        env_overrides={"CONNEXUM_AUTOWRAP": "1"},
    )
    assert result.returncode == 0, result.stderr
    output = result.stdout.strip()
    if output == "HF_NOT_INSTALLED":
        # Package not installed -- check that the skip is also handled in patches
        pytest.skip("huggingface_hub not installed -- [SKIP] path not triggered")
    # If HuggingFace IS installed, the class must NOT be wrapped
    assert "governed=False" in output, (
        f"HuggingFace should NOT be wrapped, got: {output}\nstderr: {result.stderr}"
    )
    # The [SKIP] log should appear in stderr
    assert "[SKIP]" in result.stderr, (
        f"Expected [SKIP] in stderr but got: {result.stderr}"
    )


# ---------------------------------------------------------------------------
# Case 8: ImportError diagnostic when connexum_governance missing
# ---------------------------------------------------------------------------


def test_autowrap_missing_autowrap_submodule_gives_diagnostic():
    """When CONNEXUM_AUTOWRAP=1 but connexum_governance.autowrap is somehow
    missing (e.g. incomplete install), _autowrap_if_enabled() must NOT crash
    the whole SDK import -- it should log an error and continue.

    This tests the try/except guard in _autowrap_if_enabled().
    """
    result = run_python(
        """
        import connexum_governance.autowrap as aw
        # Simulate a broken activate() by monkey-patching it to raise
        import connexum_governance.autowrap._patches as patches
        original_apply = patches.apply_all_patches
        def broken_apply():
            raise ImportError("simulated missing dependency")
        patches.apply_all_patches = broken_apply

        # Deactivate so we can re-activate
        aw.deactivate_for_testing()

        # activate() should propagate the ImportError (caller handles it)
        try:
            aw.activate()
            # The error is swallowed in _autowrap_if_enabled but NOT in activate()
            # Actually activate() calls apply_all_patches which raises
            print("NO_ERROR_RAISED")
        except ImportError as e:
            print(f"CAUGHT:{e}")
        finally:
            patches.apply_all_patches = original_apply
            aw.deactivate_for_testing()
        """,
        env_overrides={"CONNEXUM_AUTOWRAP": "0"},
    )
    assert result.returncode == 0, result.stderr
    output = result.stdout.strip()
    # ImportError from apply_all_patches should propagate out of activate()
    assert "CAUGHT:simulated missing dependency" in output, (
        f"Expected ImportError to propagate, got: {output}\nstderr: {result.stderr}"
    )


# ---------------------------------------------------------------------------
# Case 9 (bonus): activate() function is idempotent at module level
# ---------------------------------------------------------------------------


def test_activate_returns_correct_booleans():
    """activate() returns True first time, False on subsequent calls."""
    result = run_python(
        """
        from connexum_governance.autowrap import activate, deactivate_for_testing, is_active
        deactivate_for_testing()
        assert not is_active()
        r1 = activate()
        assert r1 == True
        assert is_active()
        r2 = activate()
        assert r2 == False
        print('OK')
        """,
        env_overrides={"CONNEXUM_AUTOWRAP": "0"},  # don't auto-activate
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "OK"
