"""
F-NEW-LOW-1: _wire_shape.build_check_action_body silently truncated
tool_name at 200 chars to satisfy the gov-server schema's 1..200 char
limit. Without a warning, callers who passed a longer name lost the
suffix without knowing.

The fix: emit a WARNING log per truncated value with both lengths and
the trailing 40 chars of the original so log scrapers can see what was
dropped. This test asserts:
  - tool_name shorter than 200 chars: no warning, full name preserved
  - tool_name exactly 200 chars: no warning
  - tool_name longer than 200 chars: warning emitted with both lengths,
    body's toolName is truncated to 200 chars
"""

from __future__ import annotations

import logging

import pytest

from connexum_governance.integrations._wire_shape import (
    TOOL_NAME_MAX_CHARS,
    build_check_action_body,
)


def test_short_tool_name_passes_through_unchanged(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.WARNING)
    body = build_check_action_body(tool_name="short_tool", agent_name="agent-x")
    assert body["toolName"] == "short_tool"
    assert not any("truncated" in rec.message for rec in caplog.records), \
        f"Short name must not warn; got records: {[r.message for r in caplog.records]}"


def test_exact_max_length_does_not_warn(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.WARNING)
    name = "x" * TOOL_NAME_MAX_CHARS
    body = build_check_action_body(tool_name=name, agent_name="agent-x")
    assert body["toolName"] == name
    assert len(body["toolName"]) == TOOL_NAME_MAX_CHARS
    assert not any("truncated" in rec.message for rec in caplog.records), \
        "Exactly max-length name must not warn"


def test_over_max_length_warns_and_truncates(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.WARNING, logger="connexum_governance.wire_shape")
    long_name = "p" * 250 + "_END_OF_NAME_MARKER"  # 250 + 19 = 269 chars
    body = build_check_action_body(tool_name=long_name, agent_name="agent-x")

    # Body must have the truncated name
    assert len(body["toolName"]) == TOOL_NAME_MAX_CHARS, \
        f"toolName must be exactly {TOOL_NAME_MAX_CHARS}; got {len(body['toolName'])}"

    # Warning must have been emitted with both lengths
    truncation_records = [r for r in caplog.records if "truncated" in r.message]
    assert len(truncation_records) >= 1, \
        f"Expected at least one truncation warning; got: {[r.message for r in caplog.records]}"
    rec = truncation_records[0]
    msg = rec.getMessage()
    assert str(TOOL_NAME_MAX_CHARS) in msg, f"Message must include max length: {msg}"
    assert "269" in msg or "was 269" in msg, f"Message must include original length: {msg}"


def test_over_max_length_warning_includes_trailing_chars(caplog: pytest.LogCaptureFixture) -> None:
    """Trailing chars in warning help debugging by showing what was lost."""
    caplog.set_level(logging.WARNING, logger="connexum_governance.wire_shape")
    long_name = "padding_" * 30 + "END_OF_LONG_TOOL_NAME"  # > 200
    build_check_action_body(tool_name=long_name, agent_name="agent-x")
    truncation_records = [r for r in caplog.records if "truncated" in r.message]
    assert truncation_records, "Truncation warning must fire"
    msg = truncation_records[0].getMessage()
    # The trailing 40 chars include the end-of-name marker
    assert "END_OF_LONG_TOOL_NAME" in msg, \
        f"Warning must include trailing chars from original to aid debugging: {msg}"
