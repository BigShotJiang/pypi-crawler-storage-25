"""
PT-SUB-GRACE-CROSS-TENANT-1 (H7)

Verifies that resolve_grace_window_seconds sources active_pack_ids from the
server-validated entitlement token claims when present, NOT from caller input.

Scenario:
  - Entitlement token declares HIPAA (24h grace window).
  - Caller passes SOC 2 (48h grace window) as active_pack_ids.
  - Expected: 24h (HIPAA) governs because the token takes precedence.
"""

import json
import os
import stat
import tempfile
from pathlib import Path
from unittest import mock

import pytest

from connexum_governance.subscription import (
    SubscriptionGate,
    GRACE_WINDOWS_SECONDS,
    resolve_grace_window_seconds,
)


class TestGraceWindowH7:
    """PT-SUB-GRACE-CROSS-TENANT-1: token claims override caller-supplied pack IDs."""

    def _make_cached_token_with_pack_ids(self, pack_ids: list[str]) -> dict:
        """Build a fake cached entitlement token with packIds claim."""
        return {
            "token": "fake-jwt",
            "claims": {
                "status": "grace",
                "packIds": pack_ids,
                "exp": 9999999999,
            },
        }

    def test_token_pack_ids_override_caller_pack_ids(self, tmp_path):
        """
        PT-SUB-GRACE-CROSS-TENANT-1: entitlement token declares HIPAA (24h),
        caller passes SOC 2 (48h); assert 24h (HIPAA) governs.
        """
        hipaa_grace = GRACE_WINDOWS_SECONDS["hipaa"]
        soc2_grace = GRACE_WINDOWS_SECONDS["soc_2"]
        assert hipaa_grace < soc2_grace, "HIPAA must be stricter than SOC 2 for this test"

        # Patch _load_cached_token to return a token declaring HIPAA
        cached_token = self._make_cached_token_with_pack_ids(["hipaa"])

        events_emitted = []

        gate = SubscriptionGate(
            license_server_url="http://localhost:9999",
            active_pack_ids=["soc_2"],  # Caller supplies SOC 2 (less strict)
            emit_audit_event=lambda etype, data: events_emitted.append((etype, data)),
        )

        with mock.patch(
            "connexum_governance.subscription._load_cached_token",
            return_value=cached_token,
        ):
            gate._emit_grace_warning()

        assert len(events_emitted) == 1, "Expected exactly one grace warning event"
        event_type, event_data = events_emitted[0]
        assert event_type == "subscription.grace.warning"

        emitted_grace = event_data["graceWindowSeconds"]
        assert emitted_grace == hipaa_grace, (
            f"PT-SUB-GRACE-CROSS-TENANT-1: token declares HIPAA ({hipaa_grace}s), "
            f"caller passed SOC 2 ({soc2_grace}s), but emitted grace was {emitted_grace}s. "
            f"Token claims must take precedence."
        )

    def test_caller_pack_ids_used_when_no_token(self):
        """When no cached token exists, caller-supplied pack IDs are used as fallback."""
        soc2_grace = GRACE_WINDOWS_SECONDS["soc_2"]

        events_emitted = []
        gate = SubscriptionGate(
            license_server_url="http://localhost:9999",
            active_pack_ids=["soc_2"],
            emit_audit_event=lambda etype, data: events_emitted.append((etype, data)),
        )

        with mock.patch(
            "connexum_governance.subscription._load_cached_token",
            return_value=None,
        ):
            gate._emit_grace_warning()

        assert len(events_emitted) == 1
        emitted_grace = events_emitted[0][1]["graceWindowSeconds"]
        assert emitted_grace == soc2_grace, (
            f"When no token exists, caller-supplied SOC 2 ({soc2_grace}s) should govern"
        )

    def test_token_without_pack_ids_falls_back_to_caller(self):
        """Token with no packIds claim falls back to caller-supplied list."""
        hipaa_grace = GRACE_WINDOWS_SECONDS["hipaa"]

        cached_token = {
            "token": "fake-jwt",
            "claims": {
                "status": "grace",
                # No packIds key
                "exp": 9999999999,
            },
        }

        events_emitted = []
        gate = SubscriptionGate(
            license_server_url="http://localhost:9999",
            active_pack_ids=["hipaa"],  # Caller supplies HIPAA
            emit_audit_event=lambda etype, data: events_emitted.append((etype, data)),
        )

        with mock.patch(
            "connexum_governance.subscription._load_cached_token",
            return_value=cached_token,
        ):
            gate._emit_grace_warning()

        assert len(events_emitted) == 1
        emitted_grace = events_emitted[0][1]["graceWindowSeconds"]
        assert emitted_grace == hipaa_grace, (
            f"Token without packIds should fall back to caller HIPAA ({hipaa_grace}s)"
        )

    def test_resolve_grace_window_strictest_wins(self):
        """resolve_grace_window_seconds: strictest (shortest) window wins."""
        hipaa_grace = GRACE_WINDOWS_SECONDS["hipaa"]
        soc2_grace = GRACE_WINDOWS_SECONDS["soc_2"]

        # Both packs active: HIPAA is stricter
        result = resolve_grace_window_seconds(["soc_2", "hipaa"])
        assert result == hipaa_grace, (
            f"Strictest window must win: hipaa={hipaa_grace}s vs soc2={soc2_grace}s"
        )

    def test_grace_warning_not_emitted_twice_same_day(self):
        """Grace warning is emitted at most once per day to avoid log spam."""
        events_emitted = []
        gate = SubscriptionGate(
            license_server_url="http://localhost:9999",
            active_pack_ids=["soc_2"],
            emit_audit_event=lambda etype, data: events_emitted.append((etype, data)),
        )

        with mock.patch(
            "connexum_governance.subscription._load_cached_token",
            return_value=None,
        ):
            gate._emit_grace_warning()
            gate._emit_grace_warning()  # Second call same day

        assert len(events_emitted) == 1, (
            "Grace warning must not be emitted more than once per day"
        )
