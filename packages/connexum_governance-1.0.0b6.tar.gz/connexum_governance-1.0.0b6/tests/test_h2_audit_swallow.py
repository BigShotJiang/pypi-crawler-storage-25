"""
PT-PYTHON-AUDIT-SWALLOW-1 (H2)

Verify that governance audit operations NEVER silently swallow exceptions.
When a server error occurs:
  - If on_failure='open', the operation logs a warning and proceeds.
  - If on_failure='closed', the exception is re-raised.
  - In no case does an exception simply disappear without logging.

Also verifies that register_provider_compliance logs on failure rather than
silently passing.
"""

import logging
import re

import httpx
import pytest

from connexum_governance import GovernanceClient


def _error_transport(status_code: int = 500) -> httpx.MockTransport:
    """Transport that always returns an error."""

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code, json={"error": "Internal server error"})

    return httpx.MockTransport(handler)


def _connect_error_transport() -> httpx.MockTransport:
    """Transport that raises ConnectError on every request."""

    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("Connection refused")

    return httpx.MockTransport(handler)


class TestAuditSwallowH2:
    """PT-PYTHON-AUDIT-SWALLOW-1: audit failures are logged, never silently swallowed."""

    def test_register_provider_compliance_logs_on_failure(self, caplog):
        """register_provider_compliance must log a warning on server error (H2 fix)."""
        client = GovernanceClient(
            api_url="http://localhost:3100",
            license_key="test-key",
            on_failure="open",
        )
        # Replace internal client transport with error transport
        client._client = httpx.Client(
            transport=_connect_error_transport(),
            base_url="http://localhost:3100",
            headers={"Authorization": "Bearer test-key"},
        )

        with caplog.at_level(logging.WARNING, logger="connexum_governance.client"):
            # Should NOT raise; should log a warning
            client.register_provider_compliance(
                provider="test-provider",
                baa_available=False,
            )

        # Verify a warning was logged (not silently swallowed)
        warning_logs = [r for r in caplog.records if r.levelno >= logging.WARNING]
        assert len(warning_logs) > 0, (
            "PT-PYTHON-AUDIT-SWALLOW-1 FAIL: register_provider_compliance silently "
            "swallowed exception. Expected a WARNING log entry."
        )
        # Verify the log message names the operation
        log_messages = " ".join(r.getMessage() for r in warning_logs)
        assert "register_provider_compliance" in log_messages or "non-fatal" in log_messages, (
            f"Warning log must name the failing operation. Got: {log_messages}"
        )

    def test_classify_output_fail_open_logs_warning(self, caplog):
        """classify_output with on_failure='open' must log a warning on ConnectError."""
        client = GovernanceClient(
            api_url="http://localhost:3100",
            license_key="test-key",
            on_failure="open",
        )
        client._client = httpx.Client(
            transport=_connect_error_transport(),
            base_url="http://localhost:3100",
            headers={"Authorization": "Bearer test-key"},
        )

        with caplog.at_level(logging.WARNING):
            result = client.classify_output(
                audit_id="aud-test",
                output={"content": "test output"},
            )

        # Should return allowed=True on fail-open
        assert result.allowed is True, "fail-open should return allowed=True"
        # Should have failOpen metadata flag
        assert result.metadata.get("failOpen") is True, (
            "fail-open ClassifiedResponse must set metadata['failOpen'] = True"
        )

    def test_check_action_fail_open_does_not_swallow(self, caplog):
        """check_action with on_failure='open' returns ALLOW but logs on failure."""
        client = GovernanceClient(
            api_url="http://localhost:3100",
            license_key="test-key",
            on_failure="open",
        )
        client._client = httpx.Client(
            transport=_connect_error_transport(),
            base_url="http://localhost:3100",
            headers={"Authorization": "Bearer test-key"},
        )

        from connexum_governance.models import AgentIdentity
        decision = client.check_action(
            tool="Bash",
            input={"command": "ls"},
            agent=AgentIdentity(name="test-agent"),
        )

        # Fail-open means ALLOW
        assert decision.allowed is True

    def test_check_action_fail_closed_raises(self):
        """check_action with on_failure='closed' raises on server error (no silent swallow)."""
        client = GovernanceClient(
            api_url="http://localhost:3100",
            license_key="test-key",
            on_failure="closed",
        )
        client._client = httpx.Client(
            transport=_connect_error_transport(),
            base_url="http://localhost:3100",
            headers={"Authorization": "Bearer test-key"},
        )

        from connexum_governance.models import AgentIdentity
        with pytest.raises(Exception):
            client.check_action(
                tool="Bash",
                input={"command": "ls"},
                agent=AgentIdentity(name="test-agent"),
            )

    def test_no_bare_except_pass_in_codebase(self):
        """
        Static check: no Python file in connexum_governance/ has 'except Exception: pass'
        or a bare 'except Exception:' followed immediately by 'pass'.
        This prevents regressions after H2 fix.
        """
        import ast
        import os

        sdk_root = os.path.join(os.path.dirname(__file__), "..", "connexum_governance")
        sdk_root = os.path.normpath(sdk_root)

        violations = []

        for dirpath, _dirs, filenames in os.walk(sdk_root):
            for fname in filenames:
                if not fname.endswith(".py"):
                    continue
                fpath = os.path.join(dirpath, fname)
                with open(fpath) as f:
                    source = f.read()
                lines = source.splitlines()
                for i, line in enumerate(lines, start=1):
                    stripped = line.strip()
                    if stripped == "except Exception: pass":
                        violations.append(f"{fpath}:{i}: 'except Exception: pass' found")
                    elif stripped == "except Exception:":
                        # Check if next non-empty line is just 'pass'
                        for j in range(i, min(i + 3, len(lines))):
                            next_stripped = lines[j].strip()
                            if next_stripped == "pass":
                                violations.append(
                                    f"{fpath}:{i}-{j+1}: bare 'except Exception: pass' found"
                                )
                                break
                            elif next_stripped:
                                break

        assert violations == [], (
            "PT-PYTHON-AUDIT-SWALLOW-1 REGRESSION: bare 'except Exception: pass' found:\n"
            + "\n".join(violations)
        )
