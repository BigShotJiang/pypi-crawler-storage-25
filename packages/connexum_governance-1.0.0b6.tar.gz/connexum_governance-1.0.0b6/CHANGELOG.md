# Changelog -- connexum-governance Python SDK

## [Unreleased]

### Added

- **F-NEW-CRIT-39e-2-PY**: Python SDK attestor parity. `Attestor` /
  `EndUserAttestor` protocol + `SoftwareKeyAttestor` (testing-only,
  isolated under `connexum_governance.attestation.testing` per the TS
  /testing breaking-change pattern) + new `WebAuthnAttestor` (slice 3)
  + base-class `attestor` config field. The WebAuthnAttestor accepts an
  async `assertion_callback` that bridges to the customer's browser's
  `navigator.credentials.get()` flow and emits a
  `v4att.webauthn.<payload>.<sig>` token compatible with the gov-server's
  `verifyWebAuthnAttestation` slice-4 simplified verifier. Three new
  pen-tests at `packages/governance-server/tests/pentest/pt-py-
  attestation-{1,2,3}.test.ts` spawn the Python SDK as a real
  subprocess, register keys, sign tokens, and POST `/check-action`
  against an in-process governance-server — proving the Python wire
  format is byte-identical to TS where security-critical. Bumps version
  to `1.0.0b6`.

- `GovernanceClient` and `AsyncGovernanceClient` now accept an
  `attestor: EndUserAttestor | None` parameter on `__init__()` (default
  attestor for the client lifetime) and on `check_action()` (per-call
  override). When an attestor is in effect, `check_action()` builds an
  `AttestationContext` (tenant_id from `client.org_id`, action from `tool`
  truncated to 200 chars, nonce via `secrets.token_hex(16)`, request_hash
  via canonical SHA-256 of `tool:JSON(input):agent.name` matching the
  server-side `computeRequestHash()` byte-for-byte), calls
  `await attestor.sign(ctx)`, and attaches the resulting `v4att.` token to
  both the request body's `attestationToken` field AND the
  `X-Attestation-Token` request header. `AttestorError` raised by `sign()`
  is wrapped into a `GovernanceViolation` carrying a synthesized DENY
  decision (mirrors TS `governed-llm-base.ts:217`). The sync
  `GovernanceClient` bridges the async `sign()` via `asyncio.run()`; if
  called from inside a running event loop it raises a clear `RuntimeError`
  pointing the caller to `AsyncGovernanceClient`. `ValueError` raised when
  an attestor is in effect but `org_id` is unset (the org_id becomes the
  `aud` claim). 7/7 wiring tests cover: baseline (no attestor → no token),
  constructor-attestor attaches token + header, per-call attestor overrides
  client default, AttestorError → GovernanceViolation wrap, missing org_id
  → ValueError, payload claims match TS schema (sub/aud/tenantId/iat/exp/jti
  + 200-char action truncation + 64-hex requestHash), AsyncGovernanceClient
  parity. Closes F-NEW-CRIT-39e-2-PY Slice 4. Cross-SDK contract proof
  against a real running governance-sidecar lives in Slice 5 (pending).

- `connexum_governance.attestor.EndUserAttestor` protocol +
  `connexum_governance.testing.SoftwareKeyAttestor` implementation.
  Wire format: `v4att.<base64url-payload>.<base64url-signature>` with
  raw Ed25519 signature over payload bytes (mirrors TS
  `@connexum/typescript-sdk/testing`). Testing-only -- production
  deployments must use `WebAuthnAttestor` (slice 3, pending). Ships
  with 7 live integration tests against the testbed governance-sidecar
  including a cross-SDK contract test that proves a Python-built and
  a TS-built token both verify against the same registered key.
  (F-NEW-CRIT-39e-2-PY slice 1)

- `cryptography>=42` added to `pyproject.toml` `[project.optional-dependencies]`
  under a new `testing` group. Production base deps remain unchanged --
  `httpx>=0.25.0` only. Install the testing extras via
  `pip install 'connexum-governance[testing]'`.
  (F-NEW-CRIT-39e-2-PY slice 1)

- `connexum_governance.preflight` — Slice 4 of F-NEW-PRODUCT-AGENT-DIR-WRAPPER.
  `run_preflight(governance_json_path, sidecar_url)` reads the `governance.json`
  produced by the `--agent-dir` scanner and fires a synthetic `check_action` probe
  against the local governance sidecar for each detected agent. No LLM API calls
  are made. Returns a `PreflightReport` with per-agent pass/fail, decision,
  audit_id, and elapsed_ms. `PreflightReport.summary_line()` produces the
  CISO-facing summary: "28 governed, 2 need manual review". CLI entry point:
  `python3 -m connexum_governance.preflight`. Gracefully handles dead sidecar
  URL (connection errors become FAIL results, never raises). 10/10 tests pass
  against live testbed sidecar (auditId confirms audit chain fires).
  (F-NEW-PRODUCT-AGENT-DIR-WRAPPER slice 4)

## 1.0.0b2 -- 2026-05-02

### Fixed

- **F-NEW-CRIT-1**: Unified wire-shape across all framework adapters.
  Every adapter (langchain, langgraph, crewai, llama_index, autogen,
  openai_agents, haystack, pydantic_ai) previously POSTed
  `{action, tools, messagePreview, packIds, metadata}` which the
  gov-server schema rejected with 400 "Validation failed". They now
  go through `_wire_shape.build_check_action_body()` which produces
  the server-required `{toolName, agent: {name, role?}, input, sessionInfo}`
  shape while preserving framework metadata for pack rules + audit chain.

- **F-NEW-LOW-1**: `_wire_shape.build_check_action_body` no longer
  silently truncates `tool_name` at 200 chars. Truncation now emits
  a WARNING log with both lengths and the trailing 40 chars of the
  original so callers using fully-qualified function paths as tool
  ids see the loss in logs instead of silently mismatching pack rules.

- **F-NEW-LOW-5**: Pinned `[tool.pytest.ini_options].testpaths` so
  pytest invocations from any cwd discover the test suite. Previously
  callers running pytest from the repo root with mismatched
  `--rootdir` collected zero tests and reported a clean 0/0 pass
  which looked green but verified nothing.

### Added

- `packages/python-sdk/ADAPTERS_CATEGORY.md` — authoritative
  classification of every integration into 3 categories (LLM provider /
  framework adapter / IDE adapter). Closes F-NEW-LOW-3.

- `tests/test_wire_shape_truncation_warning.py` — 4 test cases
  asserting the truncation warning behavior.

## 1.0.0b1 -- 2026-04-24

Initial beta release with framework adapters (langchain, langgraph,
crewai, llama_index, autogen) and LLM provider integrations
(anthropic, openai, gemini, azure_openai, bedrock, ollama).
