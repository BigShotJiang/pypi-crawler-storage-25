## [1.11.2](https://github.com/hyperi-io/hyperi-ci/compare/v1.11.1...v1.11.2) (2026-04-21)


### Bug Fixes

* **toolchains:** drop non-coinstallable libc++/libomp/libunwind dev packages ([fc103c6](https://github.com/hyperi-io/hyperi-ci/commit/fc103c640dbb37c7070db4b62623dd2dd373742f))

## [1.11.1](https://github.com/hyperi-io/hyperi-ci/compare/v1.11.0...v1.11.1) (2026-04-21)


### Bug Fixes

* **native_deps:** append apt sources instead of overwriting ([f3dad80](https://github.com/hyperi-io/hyperi-ci/commit/f3dad8002f0b565f1dceff7448a15120ca913d66))

# [1.11.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.10.7...v1.11.0) (2026-04-21)


### Bug Fixes

* **native_deps:** tolerate missing lsb_release on macOS ([e701cd9](https://github.com/hyperi-io/hyperi-ci/commit/e701cd9fee2f491398f6ba70a4cef724168463de))
* **pgo:** disable strip for BOLT steps to avoid lld --strip-all/--emit-relocs conflict ([1a93cc1](https://github.com/hyperi-io/hyperi-ci/commit/1a93cc1b509fe79623838a481f209fc902b27489))


### Features

* **native_deps:** toolchains category, multi-version expansion, --all mode ([f0108cc](https://github.com/hyperi-io/hyperi-ci/commit/f0108cc4b38f56d1eac8c74d7ef1649f6949c008))

## [1.10.7](https://github.com/hyperi-io/hyperi-ci/compare/v1.10.6...v1.10.7) (2026-04-20)


### Bug Fixes

* install lld-NN and force lld as linker for BOLT steps ([af4dbe1](https://github.com/hyperi-io/hyperi-ci/commit/af4dbe12768d8fe78352d4ed9c42e20ce65094f1))

## [1.10.6](https://github.com/hyperi-io/hyperi-ci/compare/v1.10.5...v1.10.6) (2026-04-20)


### Bug Fixes

* alias javascript to typescript handler; gate TS tools on script/config presence ([a92bba7](https://github.com/hyperi-io/hyperi-ci/commit/a92bba79749ba29fdd51dadba814f14738e7a8ab))

## [1.10.5](https://github.com/hyperi-io/hyperi-ci/compare/v1.10.4...v1.10.5) (2026-04-20)


### Bug Fixes

* shim merge-fdata alongside llvm-bolt for cargo-pgo BOLT flow ([f6fcecf](https://github.com/hyperi-io/hyperi-ci/commit/f6fcecf8dbf7fc8305d40b32dbd6e3b6a294e5e0))

## [1.10.4](https://github.com/hyperi-io/hyperi-ci/compare/v1.10.3...v1.10.4) (2026-04-19)


### Bug Fixes

* **ci:** use GITHUB_TOKEN for GHCR login to enable first-push package creation ([e733377](https://github.com/hyperi-io/hyperi-ci/commit/e733377acd04ca7058a7a208b34627064b0e61e3))
* parameterize LLVM version, dedup pre-configured apt repos ([5ba0c4b](https://github.com/hyperi-io/hyperi-ci/commit/5ba0c4b4e544d805db19046c13820a3bc17896bd))

## [1.10.3](https://github.com/hyperi-io/hyperi-ci/compare/v1.10.2...v1.10.3) (2026-04-19)


### Bug Fixes

* pull bolt-21 from apt.llvm.org for latest BOLT upstream ([27ba197](https://github.com/hyperi-io/hyperi-ci/commit/27ba19778240eb97154b0ed6ce73421c30a020b2))

## [1.10.2](https://github.com/hyperi-io/hyperi-ci/compare/v1.10.1...v1.10.2) (2026-04-19)


### Bug Fixes

* install bolt-21 and shim versioned llvm-bolt onto PATH ([22755b7](https://github.com/hyperi-io/hyperi-ci/commit/22755b7134d0dde8ce8c644a43c485e7a21e2b72))

## [1.10.1](https://github.com/hyperi-io/hyperi-ci/compare/v1.10.0...v1.10.1) (2026-04-19)


### Bug Fixes

* **rust:** workload timeout = duration + 600s absolute grace ([3b006d7](https://github.com/hyperi-io/hyperi-ci/commit/3b006d701d9d42179da52a54b701509ff9d561b9))

# [1.10.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.9.6...v1.10.0) (2026-04-19)


### Features

* **rust:** universal install of Tier 2 tooling (cargo-pgo + llvm-bolt) ([5a16224](https://github.com/hyperi-io/hyperi-ci/commit/5a1622405f339c73211b22bc1020d0633c6e38b5))

## [1.9.6](https://github.com/hyperi-io/hyperi-ci/compare/v1.9.5...v1.9.6) (2026-04-18)


### Bug Fixes

* **rust:** pass instrumented binary as first positional arg to workload ([b370576](https://github.com/hyperi-io/hyperi-ci/commit/b370576564fb329c5bce1db26c921422a6938c90))

## [1.9.5](https://github.com/hyperi-io/hyperi-ci/compare/v1.9.4...v1.9.5) (2026-04-18)


### Bug Fixes

* **rust:** cargo-pgo install PATH + plain-build fallback ([68ca536](https://github.com/hyperi-io/hyperi-ci/commit/68ca53652a9a4e000e327b5bb50c17d68641fff3))

## [1.9.4](https://github.com/hyperi-io/hyperi-ci/compare/v1.9.3...v1.9.4) (2026-04-18)


### Bug Fixes

* **rust:** drop publish.channel fallback in build channel resolver ([95b2a89](https://github.com/hyperi-io/hyperi-ci/commit/95b2a89e9044ba545a4385ff30a5e5742fca257b))

## [1.9.3](https://github.com/hyperi-io/hyperi-ci/compare/v1.9.2...v1.9.3) (2026-04-18)


### Bug Fixes

* **rust:** resolve build channel from release-dispatch signal ([37399da](https://github.com/hyperi-io/hyperi-ci/commit/37399da37898efb61588b28ea730c2dd4413a0cd))

## [1.9.2](https://github.com/hyperi-io/hyperi-ci/compare/v1.9.1...v1.9.2) (2026-04-17)


### Bug Fixes

* **rust:** skip feature-gated binaries in binary detection ([a55d6ef](https://github.com/hyperi-io/hyperi-ci/commit/a55d6efe04c67f9f048fcfadecdb6844ef3f993c))

## [1.9.1](https://github.com/hyperi-io/hyperi-ci/compare/v1.9.0...v1.9.1) (2026-04-17)


### Bug Fixes

* jemalloc allocator at every channel, add integration tests ([f94a1ef](https://github.com/hyperi-io/hyperi-ci/commit/f94a1ef679ea0345ba125dbe908b3684bd3b77bc))

# [1.9.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.8.0...v1.9.0) (2026-04-16)


### Features

* channel-gated Rust release-track build optimisation ([754b308](https://github.com/hyperi-io/hyperi-ci/commit/754b30866c0615308458ff736d7cf8fc9f987245))

# [1.8.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.7.0...v1.8.0) (2026-04-16)


### Bug Fixes

* format test_rust_quality.py with ruff ([b13349c](https://github.com/hyperi-io/hyperi-ci/commit/b13349c42a294a356765e838335cd622887b74ba))


### Features

* rustdoc compliance hint (non-blocking) in Rust quality stage ([1ec69fe](https://github.com/hyperi-io/hyperi-ci/commit/1ec69fe17f6b64d6cec6e1e7b9d484a4290737cd))

# [1.7.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.6.3...v1.7.0) (2026-04-16)


### Features

* cargo hack feature_matrix check for Rust quality stage ([24c0be4](https://github.com/hyperi-io/hyperi-ci/commit/24c0be40c96d843dd43bbd31efc1eb23b476f0ac))

## [1.6.3](https://github.com/hyperi-io/hyperi-ci/compare/v1.6.2...v1.6.3) (2026-04-15)


### Bug Fixes

* add contents:read to container job permissions ([6b113b4](https://github.com/hyperi-io/hyperi-ci/commit/6b113b43bb112b2e7f23b582ef5eb5250d221d10))

## [1.6.2](https://github.com/hyperi-io/hyperi-ci/compare/v1.6.1...v1.6.2) (2026-04-15)


### Bug Fixes

* use vars context instead of secrets in workflow step if-conditions ([b267656](https://github.com/hyperi-io/hyperi-ci/commit/b2676561b94c1602fa1fd6b2fa07df72aec81185))

## [1.6.1](https://github.com/hyperi-io/hyperi-ci/compare/v1.6.0...v1.6.1) (2026-04-14)


### Bug Fixes

* update create-github-app-token from v2 to v3 in all workflows ([e9e1cf5](https://github.com/hyperi-io/hyperi-ci/commit/e9e1cf569b10226e27ac8825329705d508835bf4))

# [1.6.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.5.0...v1.6.0) (2026-04-14)


### Bug Fixes

* CLI UX consistency + prefer-hyperi-ci hook + submodule update ([970ed97](https://github.com/hyperi-io/hyperi-ci/commit/970ed97e8fd3f94fcbee0b55d00c288bceb5daa6))
* support 'latest' as tag argument in hyperi-ci release ([f834620](https://github.com/hyperi-io/hyperi-ci/commit/f8346201541d756d7d5f4688f60ddfa0af8e5aef))


### Features

* add container build job to all CI workflows ([401765d](https://github.com/hyperi-io/hyperi-ci/commit/401765d1b6d69a164d99cfad50ecff46cf3783fd))
* add container manifest parser for rustlib deployment contracts ([08603ff](https://github.com/hyperi-io/hyperi-ci/commit/08603ff1b72f458c274d32be99c064425d8b5cbf))
* add container stage handler with dispatch integration ([f50fa1d](https://github.com/hyperi-io/hyperi-ci/commit/f50fa1d9e1e2c4953b0a129e8241aa15f39fa76b))
* add docker buildx build and push execution module ([9f30844](https://github.com/hyperi-io/hyperi-ci/commit/9f308448c96c017a5eef3d8a0aa74cce2f224f54))
* add Dockerfile composer for contract-driven container builds ([9e018ab](https://github.com/hyperi-io/hyperi-ci/commit/9e018abb301f8da73d3db64b61ac61aa6d5c7a08))
* add hyperi-ci push command with --release and --no-ci flags ([7ad8265](https://github.com/hyperi-io/hyperi-ci/commit/7ad826504ada1fd6e5a7a3027392d939add2d800))
* add OCI label generation for container builds ([bf0fa2b](https://github.com/hyperi-io/hyperi-ci/commit/bf0fa2b596d43cbf9f21b68f0ccb416aba26d8f7))
* add Python and Node Dockerfile templates for container builds ([4c4585c](https://github.com/hyperi-io/hyperi-ci/commit/4c4585cebdbfa81bdf39aa2ab407310c21f2e923))
* JFrog migration + container pipeline + issue [#14](https://github.com/hyperi-io/hyperi-ci/issues/14) fix ([94862c8](https://github.com/hyperi-io/hyperi-ci/commit/94862c8ca0a472a3892dedba035c17a95ad4eae2))

# [1.5.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.10...v1.5.0) (2026-03-31)


### Features

* add AI/ML training restriction policy and crawler blocklist ([e93a364](https://github.com/hyperi-io/hyperi-ci/commit/e93a364861da15ce4db9116575758488c049a98d))

## [1.4.10](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.9...v1.4.10) (2026-03-29)


### Bug Fixes

* pip-audit now scans project venv instead of system venv ([e151a81](https://github.com/hyperi-io/hyperi-ci/commit/e151a8104d369b665c5710afd9ef652a3856eab2))

## [1.4.9](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.8...v1.4.9) (2026-03-27)


### Bug Fixes

* lint fixes and sccache dir creation in setup-rust-dev ([6a11704](https://github.com/hyperi-io/hyperi-ci/commit/6a117041767e83ce9cdc5a82e365269ed1697cb5))

## [1.4.8](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.7...v1.4.8) (2026-03-27)


### Bug Fixes

* add mold and clang to rust native-deps, add build optimisation script ([5ac84a6](https://github.com/hyperi-io/hyperi-ci/commit/5ac84a6dd25f1dc2f7e70b5eb864cea8d62705bb))

## [1.4.7](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.6...v1.4.7) (2026-03-27)


### Bug Fixes

* route renovate branches to lightweight runners ([cbe0275](https://github.com/hyperi-io/hyperi-ci/commit/cbe0275e9944250c3a7a417411bd01bee7077012))

## [1.4.6](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.5...v1.4.6) (2026-03-27)


### Bug Fixes

* remove dead init-release command and module ([caa5110](https://github.com/hyperi-io/hyperi-ci/commit/caa5110eedee2429183714182d046ca5f513b440))

## [1.4.5](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.4...v1.4.5) (2026-03-27)


### Bug Fixes

* rewrite README and CLAUDE.md for single versioning model ([68ec791](https://github.com/hyperi-io/hyperi-ci/commit/68ec791922ca11761501c85087876e31126afb89))

## [1.4.4](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.3...v1.4.4) (2026-03-27)


### Bug Fixes

* always create GH Release on publish (not just for binary projects) ([9ae2536](https://github.com/hyperi-io/hyperi-ci/commit/9ae25365437aeef2c9f441a09e53b9e2109e6fff))

## [1.4.3](https://github.com/hyperi-io/hyperi-ci/compare/v1.4.2...v1.4.3) (2026-03-27)


### Bug Fixes

* add consumer project migration guide for single versioning ([79f531f](https://github.com/hyperi-io/hyperi-ci/commit/79f531f3698f32e2cdb756d2745cf2f808df42a9))
* update hyperi-ai submodule with CI standards and release skill ([089fd05](https://github.com/hyperi-io/hyperi-ci/commit/089fd05f34f9982e5411f1efd51c7b3a4dad6216))

# [1.2.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.8...v1.2.0) (2026-03-26)


### Bug Fixes

* add --refresh to uvx for fresh PyPI resolution ([c24f711](https://github.com/hyperi-io/hyperi-ci/commit/c24f7112440a1d4ea7f9865df31ce547736b01a1))
* add auto-update gating logic ([f3255ec](https://github.com/hyperi-io/hyperi-ci/commit/f3255ec7e7fd43464f5b67fd4e3b210f8f8c6850))
* add check-commit CLI subcommand ([4646a82](https://github.com/hyperi-io/hyperi-ci/commit/4646a828330cf2d59cfde818605e2d17750a7e39))
* add commit message validation module with friendly rejections ([4b79d8e](https://github.com/hyperi-io/hyperi-ci/commit/4b79d8e7e839384593e6d5b1f96561eddce51c84))
* add install method detection and command building ([391f102](https://github.com/hyperi-io/hyperi-ci/commit/391f1022b7531e62d0fcd7acc7a454347a9ba0bf))
* add maybe_auto_update entry point ([8fdbd26](https://github.com/hyperi-io/hyperi-ci/commit/8fdbd2650aa656c4bcd5cb74a0bc1791e403ab29))
* add missing packaging dependency for upgrade module ([5ca9b96](https://github.com/hyperi-io/hyperi-ci/commit/5ca9b96b54955edfe3bb7c3b6f1616ce593597c5))
* add PT001, PT021, S106 to Python test_ignore defaults ([e04e541](https://github.com/hyperi-io/hyperi-ci/commit/e04e5413cdf31ce6797dcfa105e9ebe462d9034c))
* add publish.channel config with release default ([321fad7](https://github.com/hyperi-io/hyperi-ci/commit/321fad79aaa05a76911286a11d53bb509a827ba5))
* add PyPI version fetch with timeout ([49819f3](https://github.com/hyperi-io/hyperi-ci/commit/49819f3530efb0a105d55305f4c86e7f5210dcb3))
* add R2 binary publish to downloads.hyperi.io ([edce4b6](https://github.com/hyperi-io/hyperi-ci/commit/edce4b6e00866ef072fb2ce940e81a5cb0af81f2))
* add release command for tag-based publish dispatch ([ac46fdf](https://github.com/hyperi-io/hyperi-ci/commit/ac46fdfacc26f4449328a9aca4592ca96a6f8081))
* add release-merge reusable workflow for automated version conflict resolution ([7f63980](https://github.com/hyperi-io/hyperi-ci/commit/7f639802abb76cc7a0f6fa375b52f2e518c1a359))
* add ts package manager detection with importlib dispatcher ([8b0cc40](https://github.com/hyperi-io/hyperi-ci/commit/8b0cc400eb4ad9d32d1137b2d3f39c84b809e504))
* add upgrade command and auto-update to CLI ([4c5aed5](https://github.com/hyperi-io/hyperi-ci/commit/4c5aed57c1c8277978916872dc1fc6c3891a7833))
* add upgrade execution with permission error handling ([a872eb1](https://github.com/hyperi-io/hyperi-ci/commit/a872eb1f14ec2818df2d1f67181ad848efb92604))
* add upgrade module with PyPI version parsing ([143a9c0](https://github.com/hyperi-io/hyperi-ci/commit/143a9c08672bf3c2149fb147df3a62bd4f04ac37))
* bytes/text mismatch in _rlib_has_wrong_arch ([2985c1a](https://github.com/hyperi-io/hyperi-ci/commit/2985c1aee9719c3f6b0ad845069d4d07645a5749))
* channel-aware GH Release creation and R2 paths ([c22011a](https://github.com/hyperi-io/hyperi-ci/commit/c22011ad0f401e9df917e705f96374d769a5a144))
* clean R2 latest/ directory before upload ([c607b4a](https://github.com/hyperi-io/hyperi-ci/commit/c607b4a29742629a60af84a84e0b1c434505063b))
* default bandit to disabled, superseded by ruff S rules ([4688d87](https://github.com/hyperi-io/hyperi-ci/commit/4688d87057011fee0f107c776405482627ad0804))
* dispatch-triggered publish for self-hosting workflow ([b36dc22](https://github.com/hyperi-io/hyperi-ci/commit/b36dc220dd816cc50c873656d284167da26a9a4a))
* dispatch-triggered publish, remove release branch from python workflow ([29bf8c6](https://github.com/hyperi-io/hyperi-ci/commit/29bf8c6996ca584e44b301c5536719731a8ad779))
* dispatch-triggered publish, remove release branch from rust workflow ([cde8071](https://github.com/hyperi-io/hyperi-ci/commit/cde8071e9664e1368a4cd4372afa8acaf727c03a))
* drop version from binary filenames, fix version detection ([cf8e086](https://github.com/hyperi-io/hyperi-ci/commit/cf8e086b3a6b00d1e7178214427e513f63854caf)), closes [hyperi-io/dfe-receiver#6](https://github.com/hyperi-io/dfe-receiver/issues/6)
* ensure pm available in all ts handlers ([8f29ce3](https://github.com/hyperi-io/hyperi-ci/commit/8f29ce3bea021930ea8ce3abd344709d018f22fa))
* fallback npm install with user prefix for ARC runners ([1e06d47](https://github.com/hyperi-io/hyperi-ci/commit/1e06d47b74011f0a1b6c1feff94e48eed43d7672))
* gate registry publish on release channel only ([60f1a40](https://github.com/hyperi-io/hyperi-ci/commit/60f1a4025e83c409365fb38f7ece7d3bd2b4243f))
* generate commit-msg hook in init command ([7d0b85a](https://github.com/hyperi-io/hyperi-ci/commit/7d0b85a6a26f5f14924a9ea62e1b7696afbaef3a))
* generic binary publish to GitHub Releases ([05b21fc](https://github.com/hyperi-io/hyperi-ci/commit/05b21fcf1d8cfbf7fd622c59eed80d907a46943a))
* install PM via npm when corepack unavailable ([ecf852e](https://github.com/hyperi-io/hyperi-ci/commit/ecf852ec139238134ca09fc090dd4c48aba45cc6))
* make corepack enable non-fatal for ARC runners ([c96cdd0](https://github.com/hyperi-io/hyperi-ci/commit/c96cdd000a0c7c7f86fc52a47207c57b1ba20202))
* move plugin repos to deprecated in STATE.md ([51664f7](https://github.com/hyperi-io/hyperi-ci/commit/51664f7f56d09d1e60e7e36c3147476bc8123bb3))
* port commit-types SSOT from old CI ([306ce53](https://github.com/hyperi-io/hyperi-ci/commit/306ce537dec6a7aa872743933c65a984ecba3375))
* preserve yaml formatting in init-release ([d89576c](https://github.com/hyperi-io/hyperi-ci/commit/d89576c45d635dae99a0d01d611ad775ecd0d0b6))
* remove dead release-merge.yml, fix capture bug, update docs ([3a69312](https://github.com/hyperi-io/hyperi-ci/commit/3a69312eae9c256141ea9dfc87c68443014c5232))
* remove release-merge command (release branch eliminated) ([94b1cbc](https://github.com/hyperi-io/hyperi-ci/commit/94b1cbc49a670a3cdf452bcb7e41dba6e2a0158f))
* replace interrogate with ruff D rules for docstring checks ([20002e6](https://github.com/hyperi-io/hyperi-ci/commit/20002e60f144c93cd878d7f9b4e3168f932777fc))
* resolve manifest conflicts by merging content, not replacing ([695846d](https://github.com/hyperi-io/hyperi-ci/commit/695846dd5e5a816e354cbcde1fe90902fa9a1891))
* resolve ruff import sort and unused import errors ([ae7628f](https://github.com/hyperi-io/hyperi-ci/commit/ae7628feb45c58f5165470f3de1a9483b1685e4a))
* sanitize branch names with slashes in build artifact paths ([5cb4cc9](https://github.com/hyperi-io/hyperi-ci/commit/5cb4cc991f740eeb141e9f55c59e2c57388b7a7b))
* set 80% coverage default, add ruff github annotations ([558f76f](https://github.com/hyperi-io/hyperi-ci/commit/558f76f5aea63a48f3b9b5506d9b499ba5d68c93))
* set packaged defaults binaries destination to r2-binaries ([716d224](https://github.com/hyperi-io/hyperi-ci/commit/716d224b3233afe11ffeda86f06593ba84b8a0c6))
* single versioning on main, remove release branch and github plugin ([eeda102](https://github.com/hyperi-io/hyperi-ci/commit/eeda1029924e7ea7075bbe3dfe3dede54bde86eb))
* skip jfrog binary publish when credentials missing ([61bd1d9](https://github.com/hyperi-io/hyperi-ci/commit/61bd1d99c025c6252daa3a4e81133c9c4163ab16))
* two-branch release for self-hosting CI, fix hook symlink ([c88a2a3](https://github.com/hyperi-io/hyperi-ci/commit/c88a2a3d547cff62d9040b5701ed7f45f38acb19))
* update init template for single versioning and full commit types ([870f90e](https://github.com/hyperi-io/hyperi-ci/commit/870f90e6003f47a19e66494d48498e1e2bba02d0))
* update release skill for dispatch-triggered publish workflow ([1692b67](https://github.com/hyperi-io/hyperi-ci/commit/1692b673e91415e0abca95a1bdd91bdceabe1f8c))
* use corepack --install-directory for permission-restricted runners ([6aa37e4](https://github.com/hyperi-io/hyperi-ci/commit/6aa37e493fac5f96fffff4326667e9f63b1e0776))
* wire commit validation into quality stage ([8655663](https://github.com/hyperi-io/hyperi-ci/commit/8655663bad4ce30367acef402ce514b8b29fc440))


### Features

* add alpha/beta release channels to init-release and release-merge ([8da6206](https://github.com/hyperi-io/hyperi-ci/commit/8da62068acf5543a6060b9d9793a428969c2bc4c))
* add release-merge CLI command with auto conflict resolution ([1bb04fd](https://github.com/hyperi-io/hyperi-ci/commit/1bb04fd5364fdcedb138b2268102e75846ed1532))
* add two-tier quality config and shared helper ([808e014](https://github.com/hyperi-io/hyperi-ci/commit/808e01416bf60abdcab9df1c988435cfd38490cf))
* split Python ruff check into production/test passes ([fc413fa](https://github.com/hyperi-io/hyperi-ci/commit/fc413fa8226748bf7374b3b660a1f133d1ab3895))
* split Rust/Go/TypeScript quality into production/test passes ([dafe5a4](https://github.com/hyperi-io/hyperi-ci/commit/dafe5a4a5ca21d9fccd8e94ff8a77197c124822b))

# [1.2.0-dev.9](https://github.com/hyperi-io/hyperi-ci/compare/v1.2.0-dev.8...v1.2.0-dev.9) (2026-03-24)


### Bug Fixes

* resolve manifest conflicts by merging content, not replacing ([695846d](https://github.com/hyperi-io/hyperi-ci/commit/695846dd5e5a816e354cbcde1fe90902fa9a1891))

# [1.2.0-dev.8](https://github.com/hyperi-io/hyperi-ci/compare/v1.2.0-dev.7...v1.2.0-dev.8) (2026-03-23)


### Bug Fixes

* add PT001, PT021, S106 to Python test_ignore defaults ([e04e541](https://github.com/hyperi-io/hyperi-ci/commit/e04e5413cdf31ce6797dcfa105e9ebe462d9034c))

# [1.2.0-dev.7](https://github.com/hyperi-io/hyperi-ci/compare/v1.2.0-dev.6...v1.2.0-dev.7) (2026-03-22)


### Bug Fixes

* resolve ruff import sort and unused import errors ([ae7628f](https://github.com/hyperi-io/hyperi-ci/commit/ae7628feb45c58f5165470f3de1a9483b1685e4a))


### Features

* add two-tier quality config and shared helper ([808e014](https://github.com/hyperi-io/hyperi-ci/commit/808e01416bf60abdcab9df1c988435cfd38490cf))
* split Python ruff check into production/test passes ([fc413fa](https://github.com/hyperi-io/hyperi-ci/commit/fc413fa8226748bf7374b3b660a1f133d1ab3895))
* split Rust/Go/TypeScript quality into production/test passes ([dafe5a4](https://github.com/hyperi-io/hyperi-ci/commit/dafe5a4a5ca21d9fccd8e94ff8a77197c124822b))

# [1.2.0-dev.6](https://github.com/hyperi-io/hyperi-ci/compare/v1.2.0-dev.5...v1.2.0-dev.6) (2026-03-21)


### Bug Fixes

* set 80% coverage default, add ruff github annotations ([558f76f](https://github.com/hyperi-io/hyperi-ci/commit/558f76f5aea63a48f3b9b5506d9b499ba5d68c93))

# [1.2.0-dev.5](https://github.com/hyperi-io/hyperi-ci/compare/v1.2.0-dev.4...v1.2.0-dev.5) (2026-03-21)


### Bug Fixes

* default bandit to disabled, superseded by ruff S rules ([4688d87](https://github.com/hyperi-io/hyperi-ci/commit/4688d87057011fee0f107c776405482627ad0804))

# [1.2.0-dev.4](https://github.com/hyperi-io/hyperi-ci/compare/v1.2.0-dev.3...v1.2.0-dev.4) (2026-03-21)


### Bug Fixes

* replace interrogate with ruff D rules for docstring checks ([20002e6](https://github.com/hyperi-io/hyperi-ci/commit/20002e60f144c93cd878d7f9b4e3168f932777fc))

# [1.2.0-dev.3](https://github.com/hyperi-io/hyperi-ci/compare/v1.2.0-dev.2...v1.2.0-dev.3) (2026-03-21)


### Features

* add alpha/beta release channels to init-release and release-merge ([8da6206](https://github.com/hyperi-io/hyperi-ci/commit/8da62068acf5543a6060b9d9793a428969c2bc4c))

# [1.2.0-dev.2](https://github.com/hyperi-io/hyperi-ci/compare/v1.2.0-dev.1...v1.2.0-dev.2) (2026-03-20)


### Bug Fixes

* remove dead release-merge.yml, fix capture bug, update docs ([3a69312](https://github.com/hyperi-io/hyperi-ci/commit/3a69312eae9c256141ea9dfc87c68443014c5232))

# [1.2.0-dev.1](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.21...v1.2.0-dev.1) (2026-03-20)


### Features

* add release-merge CLI command with auto conflict resolution ([1bb04fd](https://github.com/hyperi-io/hyperi-ci/commit/1bb04fd5364fdcedb138b2268102e75846ed1532))

## [1.1.9-dev.21](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.20...v1.1.9-dev.21) (2026-03-20)


### Bug Fixes

* add release-merge reusable workflow for automated version conflict resolution ([7f63980](https://github.com/hyperi-io/hyperi-ci/commit/7f639802abb76cc7a0f6fa375b52f2e518c1a359))

## [1.1.9-dev.20](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.19...v1.1.9-dev.20) (2026-03-19)


### Bug Fixes

* clean R2 latest/ directory before upload ([c607b4a](https://github.com/hyperi-io/hyperi-ci/commit/c607b4a29742629a60af84a84e0b1c434505063b))

## [1.1.9-dev.19](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.18...v1.1.9-dev.19) (2026-03-18)


### Bug Fixes

* add missing packaging dependency for upgrade module ([5ca9b96](https://github.com/hyperi-io/hyperi-ci/commit/5ca9b96b54955edfe3bb7c3b6f1616ce593597c5))

## [1.1.9-dev.18](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.17...v1.1.9-dev.18) (2026-03-18)


### Bug Fixes

* drop version from binary filenames, fix version detection ([cf8e086](https://github.com/hyperi-io/hyperi-ci/commit/cf8e086b3a6b00d1e7178214427e513f63854caf)), closes [hyperi-io/dfe-receiver#6](https://github.com/hyperi-io/dfe-receiver/issues/6)

## [1.1.9-dev.17](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.16...v1.1.9-dev.17) (2026-03-17)


### Bug Fixes

* add auto-update gating logic ([f3255ec](https://github.com/hyperi-io/hyperi-ci/commit/f3255ec7e7fd43464f5b67fd4e3b210f8f8c6850))
* add install method detection and command building ([391f102](https://github.com/hyperi-io/hyperi-ci/commit/391f1022b7531e62d0fcd7acc7a454347a9ba0bf))
* add maybe_auto_update entry point ([8fdbd26](https://github.com/hyperi-io/hyperi-ci/commit/8fdbd2650aa656c4bcd5cb74a0bc1791e403ab29))
* add PyPI version fetch with timeout ([49819f3](https://github.com/hyperi-io/hyperi-ci/commit/49819f3530efb0a105d55305f4c86e7f5210dcb3))
* add upgrade command and auto-update to CLI ([4c5aed5](https://github.com/hyperi-io/hyperi-ci/commit/4c5aed57c1c8277978916872dc1fc6c3891a7833))
* add upgrade execution with permission error handling ([a872eb1](https://github.com/hyperi-io/hyperi-ci/commit/a872eb1f14ec2818df2d1f67181ad848efb92604))
* add upgrade module with PyPI version parsing ([143a9c0](https://github.com/hyperi-io/hyperi-ci/commit/143a9c08672bf3c2149fb147df3a62bd4f04ac37))

## [1.1.9-dev.16](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.15...v1.1.9-dev.16) (2026-03-16)


### Bug Fixes

* sanitize branch names with slashes in build artifact paths ([5cb4cc9](https://github.com/hyperi-io/hyperi-ci/commit/5cb4cc991f740eeb141e9f55c59e2c57388b7a7b))

## [1.1.9-dev.15](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.14...v1.1.9-dev.15) (2026-03-16)


### Bug Fixes

* move plugin repos to deprecated in STATE.md ([51664f7](https://github.com/hyperi-io/hyperi-ci/commit/51664f7f56d09d1e60e7e36c3147476bc8123bb3))

## [1.1.9-dev.14](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.13...v1.1.9-dev.14) (2026-03-16)


### Bug Fixes

* set packaged defaults binaries destination to r2-binaries ([716d224](https://github.com/hyperi-io/hyperi-ci/commit/716d224b3233afe11ffeda86f06593ba84b8a0c6))

## [1.1.9-dev.13](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.12...v1.1.9-dev.13) (2026-03-13)


### Bug Fixes

* add R2 binary publish to downloads.hyperi.io ([edce4b6](https://github.com/hyperi-io/hyperi-ci/commit/edce4b6e00866ef072fb2ce940e81a5cb0af81f2))

## [1.1.9-dev.12](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.11...v1.1.9-dev.12) (2026-03-13)


### Bug Fixes

* skip jfrog binary publish when credentials missing ([61bd1d9](https://github.com/hyperi-io/hyperi-ci/commit/61bd1d99c025c6252daa3a4e81133c9c4163ab16))

## [1.1.9-dev.11](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.10...v1.1.9-dev.11) (2026-03-12)


### Bug Fixes

* generic binary publish to GitHub Releases ([05b21fc](https://github.com/hyperi-io/hyperi-ci/commit/05b21fcf1d8cfbf7fd622c59eed80d907a46943a))

## [1.1.9-dev.10](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.9...v1.1.9-dev.10) (2026-03-12)


### Bug Fixes

* ensure pm available in all ts handlers ([8f29ce3](https://github.com/hyperi-io/hyperi-ci/commit/8f29ce3bea021930ea8ce3abd344709d018f22fa))

## [1.1.9-dev.9](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.8...v1.1.9-dev.9) (2026-03-12)


### Bug Fixes

* use corepack --install-directory for permission-restricted runners ([6aa37e4](https://github.com/hyperi-io/hyperi-ci/commit/6aa37e493fac5f96fffff4326667e9f63b1e0776))

## [1.1.9-dev.8](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.7...v1.1.9-dev.8) (2026-03-12)


### Bug Fixes

* add --refresh to uvx for fresh PyPI resolution ([c24f711](https://github.com/hyperi-io/hyperi-ci/commit/c24f7112440a1d4ea7f9865df31ce547736b01a1))

## [1.1.9-dev.7](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.6...v1.1.9-dev.7) (2026-03-12)


### Bug Fixes

* fallback npm install with user prefix for ARC runners ([1e06d47](https://github.com/hyperi-io/hyperi-ci/commit/1e06d47b74011f0a1b6c1feff94e48eed43d7672))

## [1.1.9-dev.6](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.5...v1.1.9-dev.6) (2026-03-12)


### Bug Fixes

* install PM via npm when corepack unavailable ([ecf852e](https://github.com/hyperi-io/hyperi-ci/commit/ecf852ec139238134ca09fc090dd4c48aba45cc6))

## [1.1.9-dev.5](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.4...v1.1.9-dev.5) (2026-03-12)


### Bug Fixes

* make corepack enable non-fatal for ARC runners ([c96cdd0](https://github.com/hyperi-io/hyperi-ci/commit/c96cdd000a0c7c7f86fc52a47207c57b1ba20202))

## [1.1.9-dev.4](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.3...v1.1.9-dev.4) (2026-03-12)


### Bug Fixes

* add ts package manager detection with importlib dispatcher ([8b0cc40](https://github.com/hyperi-io/hyperi-ci/commit/8b0cc400eb4ad9d32d1137b2d3f39c84b809e504))

## [1.1.9-dev.3](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.2...v1.1.9-dev.3) (2026-03-12)


### Bug Fixes

* bytes/text mismatch in _rlib_has_wrong_arch ([2985c1a](https://github.com/hyperi-io/hyperi-ci/commit/2985c1aee9719c3f6b0ad845069d4d07645a5749))

## [1.1.9-dev.2](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.9-dev.1...v1.1.9-dev.2) (2026-03-12)


### Bug Fixes

* preserve yaml formatting in init-release ([d89576c](https://github.com/hyperi-io/hyperi-ci/commit/d89576c45d635dae99a0d01d611ad775ecd0d0b6))

## [1.1.9-dev.1](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.8...v1.1.9-dev.1) (2026-03-12)


### Bug Fixes

* two-branch release for self-hosting CI, fix hook symlink ([c88a2a3](https://github.com/hyperi-io/hyperi-ci/commit/c88a2a3d547cff62d9040b5701ed7f45f38acb19))

## [1.1.8](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.7...v1.1.8) (2026-03-12)


### Bug Fixes

* add init-release command for release branch setup ([019118a](https://github.com/hyperi-io/hyperi-ci/commit/019118ad7b05b8e5875bbea3df3d70913078c74d))
* pre-commit hook enforces action version SSOT ([39a8bb9](https://github.com/hyperi-io/hyperi-ci/commit/39a8bb9a696da119da449262833a8b01367afb7d))
* split-runner build matrix and release channels ([c752184](https://github.com/hyperi-io/hyperi-ci/commit/c752184fa19faae4b3e5268b23b022d52f7c2760))
* update upload-artifact v4 to v7, add to SSOT ([01b1f3a](https://github.com/hyperi-io/hyperi-ci/commit/01b1f3aa0cb61f0066ee49431e47a316959c2fd5))

## [1.1.7](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.6...v1.1.7) (2026-03-12)


### Bug Fixes

* include zlib in cross-sysroot dependency resolution ([a3ff8c3](https://github.com/hyperi-io/hyperi-ci/commit/a3ff8c33edca3ab0e1b0fdebbac13700f7bbc748))

## [1.1.6](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.5...v1.1.6) (2026-03-12)


### Bug Fixes

* force apt-get update after widening custom repos for cross arch ([597e51b](https://github.com/hyperi-io/hyperi-ci/commit/597e51b08f46c4b7fd1d762a674e91e1cce42469))

## [1.1.5](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.4...v1.1.5) (2026-03-12)


### Bug Fixes

* widen custom APT repos for cross-arch sysroot ([3e02629](https://github.com/hyperi-io/hyperi-ci/commit/3e02629c77c974935627ec12d894646eac5bbcfe))

## [1.1.4](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.3...v1.1.4) (2026-03-11)


### Bug Fixes

* add dpkg min version check for native deps ([e21b6d6](https://github.com/hyperi-io/hyperi-ci/commit/e21b6d6ef460c4e2e433a9484aeafe1574e4409a))

## [1.1.3](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.2...v1.1.3) (2026-03-11)


### Bug Fixes

* expand rust native deps and fix arm64 arch detection ([58e308e](https://github.com/hyperi-io/hyperi-ci/commit/58e308e3186245362b411db0f0f04163ace1587b))

## [1.1.2](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.1...v1.1.2) (2026-03-11)


### Bug Fixes

* add apt repo support for latest native deps ([8236868](https://github.com/hyperi-io/hyperi-ci/commit/8236868bbdd633f2b603b6feedd63a29afda66ed))

## [1.1.1](https://github.com/hyperi-io/hyperi-ci/compare/v1.1.0...v1.1.1) (2026-03-11)


### Bug Fixes

* run clippy and tests per feature set, not unioned ([c25b50a](https://github.com/hyperi-io/hyperi-ci/commit/c25b50a5f186cd38e05c810f694ec8f3439717b2))

# [1.1.0](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.49...v1.1.0) (2026-03-11)


### Features

* add check command for local pre-push validation ([435d1ea](https://github.com/hyperi-io/hyperi-ci/commit/435d1eab3f6d77f5baeacc6cbfd28c889027d648))

## [1.0.49](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.48...v1.0.49) (2026-03-10)


### Bug Fixes

* skip cargo package verify on publish runner to avoid protoc requirement ([e760d74](https://github.com/hyperi-io/hyperi-ci/commit/e760d7403342e279c906f184ee556310626961f8))

## [1.0.48](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.47...v1.0.48) (2026-03-10)


### Bug Fixes

* detect all -sys crates for stale cross-compiled rlib cleanup ([6e2c406](https://github.com/hyperi-io/hyperi-ci/commit/6e2c406f0ef24f4bed34e5fbaa6f61b9a3c023bc))

## [1.0.47](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.46...v1.0.47) (2026-03-10)


### Bug Fixes

* set CC/CXX/AR for configure-based sys crate cross-compilation ([e3a3caa](https://github.com/hyperi-io/hyperi-ci/commit/e3a3caa2773a5b389f4f664c5248e2913fa80708))

## [1.0.46](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.45...v1.0.46) (2026-03-10)


### Bug Fixes

* detect and clean stale cmake -sys rlibs before cross builds ([effd85d](https://github.com/hyperi-io/hyperi-ci/commit/effd85d4633b71c9a24c45c55e0aa2abc64d0230))

## [1.0.45](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.44...v1.0.45) (2026-03-10)


### Bug Fixes

* clear cmake caches before cross-compilation to prevent stale x86_64 artifacts ([ee93de9](https://github.com/hyperi-io/hyperi-ci/commit/ee93de95463b8dea43e746f575041d9b65d932da))

## [1.0.44](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.43...v1.0.44) (2026-03-10)


### Bug Fixes

* use plain CC (not wrapper) and set CMAKE_C_COMPILER for cross builds ([22e1180](https://github.com/hyperi-io/hyperi-ci/commit/22e1180fe9797389ff7856c939218f5b2d7ff342))

## [1.0.43](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.42...v1.0.43) (2026-03-10)


### Bug Fixes

* use lowercase CC/CXX env vars for cc crate cross-compilation ([0556b08](https://github.com/hyperi-io/hyperi-ci/commit/0556b087f5c19bb2a46b66783ec23c599a5ada0f))

## [1.0.42](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.41...v1.0.42) (2026-03-09)


### Bug Fixes

* skip binary packaging for library-only Rust crates ([9ea21e8](https://github.com/hyperi-io/hyperi-ci/commit/9ea21e877c08a0ca34ce5b67b6cb7f8473093061))

## [1.0.41](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.40...v1.0.41) (2026-03-09)


### Bug Fixes

* use --no-cache for uvx during CI stabilisation period ([a6d3a64](https://github.com/hyperi-io/hyperi-ci/commit/a6d3a64d18f616f660756e6e5d41284de13df64a))

## [1.0.40](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.39...v1.0.40) (2026-03-09)


### Bug Fixes

* add confluent-kafka to python native deps config ([3f89b0b](https://github.com/hyperi-io/hyperi-ci/commit/3f89b0b4f1e522cd8dedb59a5e77f9ceaef41de1))

## [1.0.39](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.38...v1.0.39) (2026-03-09)


### Bug Fixes

* use plain string logger calls in native_deps (no kwargs) ([d5ba8a3](https://github.com/hyperi-io/hyperi-ci/commit/d5ba8a31d2fc5543fafd03fa8ec57e986de62586))

## [1.0.38](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.37...v1.0.38) (2026-03-09)


### Bug Fixes

* rename logger kwarg group to dep to avoid reserved name ([9f41643](https://github.com/hyperi-io/hyperi-ci/commit/9f41643958529e5bb564388ad347710395eca5fd))

## [1.0.37](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.36...v1.0.37) (2026-03-09)


### Bug Fixes

* replace hardcoded native dep detection with config-driven system ([e8e8a57](https://github.com/hyperi-io/hyperi-ci/commit/e8e8a5718a69eea383f4e3fd70caa6410823edbc))

## [1.0.36](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.35...v1.0.36) (2026-03-09)


### Bug Fixes

* check libprotobuf-dev package not just protoc binary for well-known types ([fad0328](https://github.com/hyperi-io/hyperi-ci/commit/fad0328e407f0e5d6e4248810ed989a5a0184f53))

## [1.0.35](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.34...v1.0.35) (2026-03-09)


### Bug Fixes

* install protoc independently of rdkafka check on ARC runners ([7c2ac4c](https://github.com/hyperi-io/hyperi-ci/commit/7c2ac4c88f74ef5b37be513a649951cf553ace8f))

## [1.0.34](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.33...v1.0.34) (2026-03-09)


### Bug Fixes

* add libprotobuf-dev to install system deps for protoc well-known types ([5eeaa81](https://github.com/hyperi-io/hyperi-ci/commit/5eeaa817e8a931097bb8561fd89ca2186ab8955b))

## [1.0.33](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.32...v1.0.33) (2026-03-09)


### Bug Fixes

* detect protoc/rdkafka deps from Cargo.toml when Cargo.lock absent ([91db4d3](https://github.com/hyperi-io/hyperi-ci/commit/91db4d3800420bb3cd47ee3cf5c5a0c5ceaeb543))

## [1.0.32](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.31...v1.0.32) (2026-03-09)


### Bug Fixes

* add JFROG_USERNAME secret for JFrog publish auth ([6959121](https://github.com/hyperi-io/hyperi-ci/commit/6959121544611bc78ff59faaf7a132952bd55c4d))

## [1.0.31](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.30...v1.0.31) (2026-03-09)


### Bug Fixes

* use _token username for JFrog PyPI publish ([3190913](https://github.com/hyperi-io/hyperi-ci/commit/3190913ecf3c8251c483f0f52dfb7d74956c91bf))

## [1.0.30](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.29...v1.0.30) (2026-03-09)


### Bug Fixes

* use hyperi-ci build in publish step for sdist exclusions ([51698e0](https://github.com/hyperi-io/hyperi-ci/commit/51698e0b27c18d8d8e861099463a89e965dff714))

## [1.0.29](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.28...v1.0.29) (2026-03-09)


### Bug Fixes

* auto-exclude AI agent dirs and org submodules from sdist ([6f7210f](https://github.com/hyperi-io/hyperi-ci/commit/6f7210f422f3ccdec0e0a1396bf3dc944194dce2))

## [1.0.28](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.27...v1.0.28) (2026-03-09)


### Bug Fixes

* remove UV_EXTRA_INDEX_URL from publish install deps step ([74cd699](https://github.com/hyperi-io/hyperi-ci/commit/74cd699a4a38837eaee46826c80439b1980d4098))

## [1.0.27](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.26...v1.0.27) (2026-03-09)


### Bug Fixes

* remove UV_EXTRA_INDEX_URL from dep resolution steps ([5e68a45](https://github.com/hyperi-io/hyperi-ci/commit/5e68a4555a33874de887480c07e94a672e6876a3))

## [1.0.26](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.25...v1.0.26) (2026-03-09)


### Bug Fixes

* use unauthenticated JFrog URL for dep resolution ([1f642b3](https://github.com/hyperi-io/hyperi-ci/commit/1f642b32b719a9e65c00d99659d03145364185f1))

## [1.0.25](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.24...v1.0.25) (2026-03-09)


### Bug Fixes

* restore JFrog index per-step with token guard ([6a4a522](https://github.com/hyperi-io/hyperi-ci/commit/6a4a522da8216a7973ab2160f7f1e3610718b110))

## [1.0.24](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.23...v1.0.24) (2026-03-09)


### Bug Fixes

* use uvx for standalone quality tools and checkout submodules ([9948535](https://github.com/hyperi-io/hyperi-ci/commit/994853566ee7755b3e77658e97e324851bb42039))

## [1.0.23](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.22...v1.0.23) (2026-03-09)


### Bug Fixes

* pass pyproject.toml config to bandit ([d71f134](https://github.com/hyperi-io/hyperi-ci/commit/d71f1341f3428fa54440cb4d0248f98028ab931d))

## [1.0.22](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.21...v1.0.22) (2026-03-09)


### Bug Fixes

* remove UV_EXTRA_INDEX_URL from python-ci workflow ([b15f9f4](https://github.com/hyperi-io/hyperi-ci/commit/b15f9f43520f6830d2ebfe24315d178de03ebd44))

## [1.0.21](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.20...v1.0.21) (2026-03-09)


### Bug Fixes

* always install semantic-release plugins ([c2e2e8c](https://github.com/hyperi-io/hyperi-ci/commit/c2e2e8c0f2a4f2f2ca1c03c53eff9dca434e2c49))

## [1.0.20](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.19...v1.0.20) (2026-03-09)


### Bug Fixes

* package config in wheel, publish to PyPI ([1b536a4](https://github.com/hyperi-io/hyperi-ci/commit/1b536a47ae7a9e59c07cfcabc3830744f932b5b2))
* simplify PyPI publish to use token ([f5ff6f9](https://github.com/hyperi-io/hyperi-ci/commit/f5ff6f96f67bfc509456e558a3d13098c906931f))

## [1.0.19](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.18...v1.0.19) (2026-03-09)


### Bug Fixes

* add semgrep SAST to all language quality pipelines ([a7e9532](https://github.com/hyperi-io/hyperi-ci/commit/a7e95328a10b7ab1e246d51a1399ae71b958b7e4))
* run semgrep via uvx, add --refresh to all workflows ([9f13069](https://github.com/hyperi-io/hyperi-ci/commit/9f13069982138771af83e8421445fb5f3bb4cf2f))

## [1.0.18](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.17...v1.0.18) (2026-03-09)


### Bug Fixes

* add semgrep SAST to Python quality pipeline ([3522a01](https://github.com/hyperi-io/hyperi-ci/commit/3522a01205f32551fe890dae15d22490ea440721))

## [1.0.17](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.16...v1.0.17) (2026-03-09)


### Bug Fixes

* replace pyright with ty for Python type checking ([100fa5d](https://github.com/hyperi-io/hyperi-ci/commit/100fa5d7d2f2a424c7e4e707182f85a3fffcd7d6))

## [1.0.16](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.15...v1.0.16) (2026-03-09)


### Bug Fixes

* add NODE_OPTIONS for pyright OOM in quality job ([250e7c3](https://github.com/hyperi-io/hyperi-ci/commit/250e7c368af6e18a25715bdf261a965afa1326cd))

## [1.0.15](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.14...v1.0.15) (2026-03-09)


### Bug Fixes

* resolve project tools via uv run when not on PATH ([1262da4](https://github.com/hyperi-io/hyperi-ci/commit/1262da441ade635f5adb45899d0286a574f948c0))

## [1.0.14](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.13...v1.0.14) (2026-03-09)


### Bug Fixes

* install all extras in python CI workflow ([2ce0422](https://github.com/hyperi-io/hyperi-ci/commit/2ce0422b709aa9198c87b3f84e7612013b6a6d47))

## [1.0.13](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.12...v1.0.13) (2026-03-09)


### Bug Fixes

* skip JFrog index for OSS projects and add publish-target to workflow ([82e046c](https://github.com/hyperi-io/hyperi-ci/commit/82e046c38f15ec57e487c9d3a56ef2e4d9edeb46))

## [1.0.12](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.11...v1.0.12) (2026-03-09)


### Bug Fixes

* migrate tool auto-fixes releaserc, license, and broken symlinks ([63153a0](https://github.com/hyperi-io/hyperi-ci/commit/63153a0b239346d9fe6fba9dcd3bb1a5472eb514))

## [1.0.11](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.10...v1.0.11) (2026-03-08)


### Bug Fixes

* add @semantic-release/exec to releaserc template ([dcdbae2](https://github.com/hyperi-io/hyperi-ci/commit/dcdbae2616b03483522859a61c519bcb7fd1d71e))

## [1.0.10](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.9...v1.0.10) (2026-03-08)


### Bug Fixes

* complete Go handlers and cross-language publish infra ([038167e](https://github.com/hyperi-io/hyperi-ci/commit/038167e3793ef2e1f08f872094adba526ff6b19e))

## [1.0.9](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.8...v1.0.9) (2026-03-08)


### Bug Fixes

* add post-build verification, binary packaging, and test threading ([a165b4f](https://github.com/hyperi-io/hyperi-ci/commit/a165b4fcafa1e31cd4d55cd2f33fe468d0e7ad20))

## [1.0.8](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.7...v1.0.8) (2026-03-07)


### Bug Fixes

* use .tmp/ for cross-sysroot instead of /tmp ([8d05365](https://github.com/hyperi-io/hyperi-ci/commit/8d053650e2b40c55986cab806e4188237840de67))

## [1.0.7](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.6...v1.0.7) (2026-03-07)


### Bug Fixes

* create g++ wrapper for cross-compilation sysroot ([ce1b8ab](https://github.com/hyperi-io/hyperi-ci/commit/ce1b8ab80fd9a42e63cad61f9198caf7f26061d5))

## [1.0.6](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.5...v1.0.6) (2026-03-07)


### Bug Fixes

* always update apt cache when cross sysroot needs packages ([c13cdfa](https://github.com/hyperi-io/hyperi-ci/commit/c13cdfa321ec7f43193ac68f094d976b32adbb65))

## [1.0.5](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.4...v1.0.5) (2026-03-07)


### Bug Fixes

* add sysroot include paths for cmake cross-compilation ([e9e8413](https://github.com/hyperi-io/hyperi-ci/commit/e9e841314df7d6f5a2477cb7420fc40b35c1ea96))

## [1.0.4](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.3...v1.0.4) (2026-03-07)


### Bug Fixes

* skip pre-installed tools on ARC runners ([a702704](https://github.com/hyperi-io/hyperi-ci/commit/a7027049928c5b14dc4829b80bd99bc9ebb0c2bc))
* wire workflows to use ARC pre-installed tools ([fb61a9f](https://github.com/hyperi-io/hyperi-ci/commit/fb61a9f018aa5a8534bbac74914c67527a50542e))

## [1.0.3](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.2...v1.0.3) (2026-03-06)


### Bug Fixes

* port cross-compilation sysroot from old CI ([770a1d2](https://github.com/hyperi-io/hyperi-ci/commit/770a1d27f5b1251ee777be715afde5d1a78b49af))

## [1.0.2](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.1...v1.0.2) (2026-03-06)


### Bug Fixes

* clear host linker flags for cross-compilation builds ([295e3af](https://github.com/hyperi-io/hyperi-ci/commit/295e3af9b031376d1b3af2b82cc270756f8a2b94))

## [1.0.1](https://github.com/hyperi-io/hyperi-ci/compare/v1.0.0...v1.0.1) (2026-03-06)


### Bug Fixes

* install rust cross-compilation targets before build ([2e083c4](https://github.com/hyperi-io/hyperi-ci/commit/2e083c47d896ab837a1a49a829a4196409b62dc7))

# 1.0.0 (2026-03-06)


### Bug Fixes

* add C/C++ deps to rust test project and cross-compile support ([025bb96](https://github.com/hyperi-io/hyperi-ci/commit/025bb96113baa9d870daeeacb173d8892e2f0a63))
* add CI tooling, publish pipelines, and self-hosting CI ([14693f1](https://github.com/hyperi-io/hyperi-ci/commit/14693f11558eacb8c4c8a522fe65f9b5ebf44332))
* add git credentials for private repo access in CI workflows ([48f2329](https://github.com/hyperi-io/hyperi-ci/commit/48f2329ae0f488b7d51bc10b0978670d4b117136))
* add hyperi-ai standards submodule ([9fe1685](https://github.com/hyperi-io/hyperi-ci/commit/9fe1685419076f5234c93e5f8289e1c27f77d5d9))
* make init existing-project-smart ([2aafae3](https://github.com/hyperi-io/hyperi-ci/commit/2aafae36d956dd1368d91fbc386bf226e8022cdc))
* pin hyperi-pylib to exact version 2.24.1 ([efbcff7](https://github.com/hyperi-io/hyperi-ci/commit/efbcff766ea8f4f051b9df8bf521168468c763cb))
* releaserc indent, optional cargo deny, uv cache ([74b63af](https://github.com/hyperi-io/hyperi-ci/commit/74b63af8edb92b9d7c30e65d8511de9ceccab92d))
* remove git credentials step (hyperi-ci is now public) ([1b24c63](https://github.com/hyperi-io/hyperi-ci/commit/1b24c63c3c78699adf01ea04002031ec7ac9d647))
* remove GITHUB_TOKEN from workflow_call secrets (reserved name) ([2c3f330](https://github.com/hyperi-io/hyperi-ci/commit/2c3f330ee648b09fc8f2380d45f4856d128bc609))
* remove JFrog index from HYPERCI_INSTALL ([f37a2c0](https://github.com/hyperi-io/hyperi-ci/commit/f37a2c0868718432a2fc3a935850aee3cfd6175f))
* ts quality handler tries common tsc script names ([fd9c628](https://github.com/hyperi-io/hyperi-ci/commit/fd9c628576874d3a5512fa625fd72efdb514f712))
* use archive URL to avoid submodule clone during install ([439b8ea](https://github.com/hyperi-io/hyperi-ci/commit/439b8ea759bae3687578075dd9d0fad0240c4614))
* use cross-repo token for private git access and update actions to latest ([b35f80d](https://github.com/hyperi-io/hyperi-ci/commit/b35f80d634bc3bf75128a2f03983ae0f81b316f8))
* use GIT_TOKEN secret (org-wide) for private repo access ([2f3a813](https://github.com/hyperi-io/hyperi-ci/commit/2f3a8133dcb194d73e20bca10105d548562de44f))
* workflow template triggers on all branches and adds workflow_dispatch ([d749632](https://github.com/hyperi-io/hyperi-ci/commit/d7496321e853b7712ae9f07052d9805b77931e47))


### Features

* add init command for project scaffolding ([80fb1f5](https://github.com/hyperi-io/hyperi-ci/commit/80fb1f5509075d59b502295a17343cc7abd20f36))
* add migrate command and per-language runner defaults ([8c370a6](https://github.com/hyperi-io/hyperi-ci/commit/8c370a66c468ab4428522afd98e1bf0465787228))
* add publish handlers for all languages ([6b06477](https://github.com/hyperi-io/hyperi-ci/commit/6b06477db73d58d81c86b6072e0a651507c7b798))
* add reusable CI workflow templates ([0262164](https://github.com/hyperi-io/hyperi-ci/commit/026216415768d904a48123506b383f1fc43f337c))
* add trigger, watch, and logs commands ([72ccd89](https://github.com/hyperi-io/hyperi-ci/commit/72ccd89240fe7a788a22e3afbbb361b3e63e1c56))
* initial hyperi-ci package ([8aeabbe](https://github.com/hyperi-io/hyperi-ci/commit/8aeabbe703b60f651f48c1b5413e1bcced212ead))
