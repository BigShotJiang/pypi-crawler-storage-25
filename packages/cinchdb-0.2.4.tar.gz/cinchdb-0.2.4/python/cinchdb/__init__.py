"""
Cinch Python SDK

Two auth modes:

    # API key mode (full account access)
    from cinchdb import Cinch
    client = Cinch(api_key="ck_live_...", org="acme")
    scope = client.scope("job_123", environment="prod", project="app")
    db = scope.create_database("redis", "cache")
    url = db.url()

    # Scope token mode (scoped agent access)
    agent = Cinch(scope_token="cinch_...")
    dbs = agent.scope_auth_databases()
"""

from .client import Cinch
from .credentials import RedactedUrl
from .database import Database
from .scope import Scope

# Errors
from .errors import (
    ApiError,
    AuthenticationError,
    CircuitBreakerOpenError,
    CinchError,
    ConflictError,
    ForbiddenError,
    NetworkError,
    NotFoundError,
    RetryExhaustedError,
    ScopeDeletedError,
    ScopeRecreatedError,
    SecurityError,
    TimeoutError,
    ValidationError,
)

# Circuit breaker (advanced)
from .circuit_breaker import CircuitBreaker, CircuitBreakerState

__version__ = "0.1.0"

__all__ = [
    # Core
    "Cinch",
    "Scope",
    "Database",
    "RedactedUrl",
    # Errors
    "CinchError",
    "AuthenticationError",
    "ForbiddenError",
    "ValidationError",
    "NotFoundError",
    "ConflictError",
    "ApiError",
    "TimeoutError",
    "NetworkError",
    "RetryExhaustedError",
    "CircuitBreakerOpenError",
    "SecurityError",
    "ScopeDeletedError",
    "ScopeRecreatedError",
    # Circuit breaker
    "CircuitBreaker",
    "CircuitBreakerState",
]
