"""
Database class - represents a database instance with connection info.

Databases are the primary data objects in Cinch. They belong to scopes
and are accessed via connection URLs containing auto-issued DB tokens.

Example:
    db = scope.database('my-redis')
    url = db.url()
    redis = Redis(str(url))
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Optional

from .credentials import RedactedUrl
from .errors import ValidationError

if TYPE_CHECKING:
    from .client import Cinch


class Database:
    """Represents a database with connection info and credential caching."""

    def __init__(
        self,
        client: Cinch,
        data: Dict[str, Any],
        project_slug: Optional[str] = None,
        environment_slug: Optional[str] = None,
    ) -> None:
        self._client = client
        self._project_slug = project_slug
        self._environment_slug = environment_slug

        # Cached connection info
        self._cached_url: Optional[str] = None
        self._cached_password: Optional[str] = None
        self._cached_env_vars: Optional[Dict[str, str]] = None

        # Database metadata
        self.id: str = data["id"]
        self.name: str = data["name"]
        self.database_type: str = data["database_type"]
        self.status: str = data["status"]
        self.scope_id: str = data["scope_id"]
        self.store_name: str = data["store_name"]
        self.memory_mb: int = data["memory_mb"]
        self.max_storage_mb: int = data["max_storage_mb"]
        self.created_at: int = data["created_at"]

    def url(self, force_refresh: bool = False) -> RedactedUrl:
        """Get connection URL for this database.

        Auto-issues a DB token on first call, caches the result.

        Args:
            force_refresh: Bypass cache and fetch fresh connection URL.

        Returns:
            Connection URL (redacted when printed).
        """
        if not force_refresh and self._cached_url:
            return RedactedUrl(self._cached_url)

        connection = self._fetch_connection()

        # Determine URL based on database type
        url: Optional[str] = None
        if self.database_type == "redis":
            url = connection.get("redis_url")
        elif self.database_type == "sql":
            url = connection.get("endpoint")
        elif self.database_type == "graph":
            url = connection.get("bolt_url") or connection.get("endpoint")

        if not url:
            raise ValidationError(
                f"API returned incomplete connection data for "
                f"{self.database_type} database {self.id}",
                request_path=f"/databases/{self.id}/connection",
                trace_id=self._client.trace_id,
            )

        # Cache everything
        self._cached_url = url
        self._cached_password = connection.get("password")
        self._cached_env_vars = connection.get("env_vars")

        return RedactedUrl(url)

    @property
    def password(self) -> Optional[str]:
        """Get the database password (cached from last url() call)."""
        return self._cached_password

    @property
    def env_vars(self) -> Optional[Dict[str, str]]:
        """Get environment variables for this connection (cached from last url() call)."""
        if self._cached_env_vars is None:
            return None
        return dict(self._cached_env_vars)

    def _fetch_connection(self) -> Dict[str, Any]:
        """Fetch connection from the appropriate endpoint."""
        if self._client.auth_mode == "scope_token":
            return self._client.request(
                "GET", f"/scope-auth/databases/{self.id}/connection"
            )

        org = self._client.org
        return self._client.request(
            "GET",
            f"/orgs/{org}/projects/{self._project_slug}/environments/"
            f"{self._environment_slug}/databases/{self.id}/connection",
        )

    def __repr__(self) -> str:
        return f"Database(id={self.id}, type={self.database_type}, name={self.name})"
