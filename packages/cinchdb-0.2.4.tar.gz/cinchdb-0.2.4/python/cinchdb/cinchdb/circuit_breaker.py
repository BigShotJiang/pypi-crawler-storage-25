"""
Circuit breaker to prevent cascading failures.

States:
- CLOSED: Normal operation, all requests go through
- OPEN: Too many failures, reject requests immediately
- HALF_OPEN: Testing if service recovered, allow one test request

Thresholds: 5 failures -> open, 60s open duration, 2 successes -> close
"""

from __future__ import annotations

import enum
import time


class CircuitBreakerState(enum.Enum):
    CLOSED = "CLOSED"
    OPEN = "OPEN"
    HALF_OPEN = "HALF_OPEN"


class CircuitBreaker:
    def __init__(
        self,
        failure_threshold: int = 5,
        open_duration: float = 60.0,
        success_threshold: int = 2,
    ) -> None:
        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._opened_at: float | None = None
        self._failure_threshold = failure_threshold
        self._open_duration = open_duration
        self._success_threshold = success_threshold

    def can_attempt(self) -> bool:
        if self._state == CircuitBreakerState.CLOSED:
            return True

        if self._state == CircuitBreakerState.HALF_OPEN:
            return True

        if self._state == CircuitBreakerState.OPEN:
            if (
                self._opened_at is not None
                and time.monotonic() - self._opened_at >= self._open_duration
            ):
                self._state = CircuitBreakerState.HALF_OPEN
                self._success_count = 0
                return True
            return False

        return False

    def record_success(self) -> None:
        if self._state == CircuitBreakerState.CLOSED:
            self._failure_count = 0
            return

        if self._state == CircuitBreakerState.HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self._success_threshold:
                self._state = CircuitBreakerState.CLOSED
                self._failure_count = 0
                self._success_count = 0
                self._opened_at = None

    def record_failure(self) -> None:
        if self._state == CircuitBreakerState.HALF_OPEN:
            self._state = CircuitBreakerState.OPEN
            self._opened_at = time.monotonic()
            self._success_count = 0
            return

        if self._state == CircuitBreakerState.CLOSED:
            self._failure_count += 1
            if self._failure_count >= self._failure_threshold:
                self._state = CircuitBreakerState.OPEN
                self._opened_at = time.monotonic()

    def get_retry_after(self) -> int:
        if self._state != CircuitBreakerState.OPEN or self._opened_at is None:
            return 0
        elapsed = time.monotonic() - self._opened_at
        remaining = self._open_duration - elapsed
        return max(0, int(remaining) + 1)

    @property
    def state(self) -> CircuitBreakerState:
        return self._state

    def reset(self) -> None:
        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._opened_at = None
