"""
Distributed tracing utilities for W3C Trace Context.

Generates trace IDs and span IDs for request correlation.
Formats traceparent header according to W3C spec.
"""

from __future__ import annotations

import os
import re
from typing import Optional, Tuple


def generate_trace_id() -> str:
    """Generate a random trace ID (32 hex chars)."""
    return os.urandom(16).hex()


def generate_span_id() -> str:
    """Generate a random span ID (16 hex chars)."""
    return os.urandom(8).hex()


def format_traceparent(trace_id: str, span_id: str) -> str:
    """Format W3C traceparent header: 00-{trace_id}-{span_id}-01."""
    return f"00-{trace_id}-{span_id}-01"


_TRACEPARENT_RE = re.compile(
    r"^00-([0-9a-f]{32})-([0-9a-f]{16})-[0-9a-f]{2}$", re.IGNORECASE
)


def parse_traceparent(traceparent: str) -> Optional[Tuple[str, str]]:
    """Parse W3C traceparent header. Returns (trace_id, span_id) or None."""
    m = _TRACEPARENT_RE.match(traceparent)
    if not m:
        return None
    return m.group(1), m.group(2)
