"""
Scope class - hierarchical permission boundary.

Scopes are permission boundaries for databases, not containers.
Databases are the primary objects; scopes control access.

Example:
    scope = client.scope("job_123", environment="prod", project="app")
    db = scope.create_database("redis", "cache")
    url = db.url()

    # Delegate access to agent
    token_resp = scope.token("write")
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .errors import (
    NotFoundError,
    ScopeDeletedError,
    ScopeRecreatedError,
    ValidationError,
)

if TYPE_CHECKING:
    from .client import Cinch
    from .database import Database


class Scope:
    """Represents a scope with its metadata. Behavior depends on auth mode."""

    def __init__(
        self,
        client: Cinch,
        data: Dict[str, Any],
        *,
        project_slug: Optional[str] = None,
        environment_slug: Optional[str] = None,
    ) -> None:
        self._client = client
        self._project_slug = project_slug
        self._environment_slug = environment_slug
        self._deleted = False

        # Scope metadata
        self.id: str = data["id"]
        self.environment_id: str = data["environment_id"]
        self.name: str = data["name"]
        self.slug: str = data["slug"]
        self.parent_id: Optional[str] = data.get("parent_id")
        self.path: str = data["path"]
        self.depth: int = data["depth"]
        self.config_overrides: Optional[str] = data.get("config_overrides")
        self.last_activity_at: Optional[int] = data.get("last_activity_at")
        self.created_at: int = data["created_at"]
        self.updated_at: int = data["updated_at"]

    def _check_deleted(self) -> None:
        if self._deleted:
            raise ScopeDeletedError(
                self.name,
                trace_id=self._client.trace_id,
                request_path=f"/scopes/{self.id}",
            )

    def _base_path(self) -> str:
        return (
            f"/orgs/{self._client.org}/projects/{self._project_slug}"
            f"/environments/{self._environment_slug}"
        )

    def _require_org_context(self, method: str) -> None:
        if not self._project_slug or not self._environment_slug:
            raise ValidationError(
                f"{method} requires org context (project and environment slugs). "
                "This scope was created in scope token mode without org context."
            )

    # =========================================================================
    # Database Management
    # =========================================================================

    def create_database(
        self,
        type: str,
        name: str = "default",
    ) -> Database:
        """Create a database in this scope.

        Args:
            type: Database type: 'redis', 'sql', or 'graph'.
            name: Optional store name suffix (default: 'default').

        Returns:
            Database instance.
        """
        self._check_deleted()
        self._require_org_context("create_database()")

        store_name = f"{self.id}_{type}_{name}"

        data = self._client.request(
            "POST",
            f"{self._base_path()}/databases",
            body={
                "type": type,
                "name": store_name,
                "scope_id": self.id,
            },
        )

        from .database import Database as DatabaseClass

        return DatabaseClass(
            self._client,
            data,
            project_slug=self._project_slug,
            environment_slug=self._environment_slug,
        )

    def database(
        self,
        name: str = "default",
        type: Optional[str] = None,
    ) -> Database:
        """Get an existing database by store name.

        Does NOT auto-create. Raises NotFoundError if database doesn't exist.

        Args:
            name: Store name suffix or database ID (default: 'default').
            type: Optional type filter ('redis', 'sql', 'graph').

        Returns:
            Database instance.
        """
        self._check_deleted()

        dbs = self.databases()

        for d in dbs:
            matches_name = (
                d.store_name == f"{self.id}_{d.database_type}_{name}"
                or d.store_name == name
                or d.id == name
            )
            matches_type = type is None or d.database_type == type
            if matches_name and matches_type:
                return d

        qualifier = f"{type} database '{name}'" if type else f"database '{name}'"
        raise NotFoundError(
            f"{qualifier} not found in scope '{self.name}'. "
            "Use create_database() to create it.",
            trace_id=self._client.trace_id,
            request_path=f"/scopes/{self.id}/databases",
        )

    def databases(self) -> List[Database]:
        """List all databases in this scope."""
        self._check_deleted()

        from .database import Database as DatabaseClass

        if self._client.auth_mode == "scope_token":
            data = self._client.request("GET", "/scope-auth/databases")
            return [
                DatabaseClass(self._client, d)
                for d in data["databases"]
                if d["scope_id"] == self.id
            ]

        self._require_org_context("databases()")

        data = self._client.request(
            "GET",
            f"{self._base_path()}/databases",
            query={"scope_id": self.id},
        )

        return [
            DatabaseClass(
                self._client,
                d,
                project_slug=self._project_slug,
                environment_slug=self._environment_slug,
            )
            for d in data["databases"]
        ]

    # =========================================================================
    # Scope Token Issuance
    # =========================================================================

    def token(
        self,
        permission: str,
        expires_in_days: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Issue a scope token for delegated access.

        Args:
            permission: Permission level: 'read', 'write', or 'admin'.
            expires_in_days: Optional expiry in days.

        Returns:
            Dict with token, scope_id, permission, expires_at.
        """
        self._check_deleted()
        self._require_org_context("token()")

        body: Dict[str, Any] = {"permission": permission}
        if expires_in_days is not None:
            body["expires_in_days"] = expires_in_days

        return self._client.request(
            "POST",
            f"{self._base_path()}/scopes/{self.id}/tokens",
            body=body,
        )

    # =========================================================================
    # Scope Hierarchy
    # =========================================================================

    def create_scope(
        self,
        name: str,
        **kwargs: Any,
    ) -> Scope:
        """Create a child scope.

        Args:
            name: Child scope name.
            **kwargs: Additional config passed to client.scope().

        Returns:
            New Scope instance.
        """
        self._check_deleted()

        return self._client.scope(
            name,
            environment=self._environment_slug,
            project=self._project_slug,
            parent=self.id,
            **kwargs,
        )

    def descendants(
        self,
        page: int = 1,
        limit: int = 100,
        depth: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Get descendant scopes.

        Returns:
            Dict with 'scopes' (list of Scope) and 'pagination'.
        """
        self._check_deleted()
        self._require_org_context("descendants()")

        query: Dict[str, Any] = {"page": page, "limit": limit}
        if depth is not None:
            query["depth"] = depth

        try:
            data = self._client.request(
                "GET",
                f"{self._base_path()}/scopes/{self.id}/descendants",
                query=query,
            )

            return {
                "scopes": [
                    Scope(
                        self._client,
                        s,
                        project_slug=self._project_slug,
                        environment_slug=self._environment_slug,
                    )
                    for s in data["scopes"]
                ],
                "pagination": data["pagination"],
            }
        except NotFoundError:
            self._handle_not_found()
            raise

    # =========================================================================
    # Lifecycle
    # =========================================================================

    def delete(self) -> None:
        """Delete this scope and all descendants. Cannot be undone."""
        self._check_deleted()
        self._require_org_context("delete()")

        self._client.request(
            "DELETE",
            f"{self._base_path()}/scopes/{self.id}",
        )
        self._deleted = True

    def refresh(self) -> None:
        """Refresh scope data from server. Updates mutable fields."""
        self._check_deleted()
        self._require_org_context("refresh()")

        try:
            data = self._client.request(
                "GET",
                f"{self._base_path()}/scopes/{self.id}",
            )
            self.config_overrides = data.get("config_overrides")
            self.last_activity_at = data.get("last_activity_at")
            self.updated_at = data["updated_at"]
        except NotFoundError:
            self._handle_not_found()
            raise

    def is_valid(self) -> bool:
        """Check if scope still exists on backend."""
        if self._deleted:
            return False
        try:
            self.refresh()
            return True
        except (NotFoundError, ScopeDeletedError):
            return False

    # =========================================================================
    # Internal
    # =========================================================================

    def _handle_not_found(self) -> None:
        """Handle 404 by checking if scope was deleted or recreated."""
        try:
            self._client.request(
                "GET",
                f"{self._base_path()}/scopes/{self.id}",
            )
            return
        except Exception:
            try:
                if self._environment_slug and self._project_slug:
                    scopes = self._client.scopes(
                        self._environment_slug, self._project_slug, 1, 100
                    )
                    for s in scopes:
                        if s.name == self.name and s.id != self.id:
                            self._deleted = True
                            raise ScopeRecreatedError(
                                self.name,
                                trace_id=self._client.trace_id,
                                request_path=f"/scopes/{self.id}",
                            )
            except (ScopeRecreatedError, ScopeDeletedError):
                raise
            except Exception:
                pass

            self._deleted = True
            raise ScopeDeletedError(
                self.name,
                trace_id=self._client.trace_id,
                request_path=f"/scopes/{self.id}",
            )

    def __repr__(self) -> str:
        return f"Scope(id={self.id}, name={self.name}, path={self.path})"
