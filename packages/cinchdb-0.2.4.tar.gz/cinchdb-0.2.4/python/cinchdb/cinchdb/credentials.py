"""
Credential redaction wrappers to prevent accidental leaks.

Connection URLs contain secrets that are easy to leak via logging.
These wrappers redact passwords when printed/logged while keeping
the full URL available for client libraries.
"""

from __future__ import annotations

import re


class RedactedUrl(str):
    """URL string that redacts passwords when printed or logged.

    When used as a string (passed to Redis/SQL client), returns full URL.
    When repr'd or logged, shows redacted version.

    Example:
        url = RedactedUrl('redis://:token123@host:6379')
        redis.connect(url)          # Full URL with credentials
        print(repr(url))            # Redacted: redis://***@host:6379
    """

    _SCHEME_RE = re.compile(r"^([a-zA-Z][a-zA-Z0-9+.-]*://)(.*)$")

    def __repr__(self) -> str:
        return self._redact()

    def __str__(self) -> str:
        # Return full URL for client libraries
        return super().__str__()

    def _redact(self) -> str:
        full = super().__str__()
        m = self._SCHEME_RE.match(full)
        if not m:
            return full

        scheme = m.group(1)
        rest = m.group(2)

        at_idx = rest.rfind("@")
        if at_idx == -1:
            return full

        auth = rest[:at_idx]
        host_and_path = rest[at_idx + 1 :]

        colon_idx = auth.find(":")
        if colon_idx == -1:
            return full

        username = auth[:colon_idx]
        return f"{scheme}{username}:***@{host_and_path}"
