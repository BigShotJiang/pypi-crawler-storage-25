"""
Main Cinch client class.

Two auth modes:
    # API key mode (full account access)
    client = Cinch(api_key="ck_live_...", org="acme")
    scope = client.scope("job_123", environment="prod")

    # Scope token mode (scoped agent access)
    client = Cinch(scope_token="cinch_...")
    dbs = client.scope_auth_databases()
"""

from __future__ import annotations

import os
import time
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional

import requests

from .circuit_breaker import CircuitBreaker
from .errors import (
    ApiError,
    AuthenticationError,
    CircuitBreakerOpenError,
    ConflictError,
    ForbiddenError,
    NetworkError,
    NotFoundError,
    RetryExhaustedError,
    SecurityError,
    TimeoutError,
    ValidationError,
)
from .trace import format_traceparent, generate_span_id, generate_trace_id

if TYPE_CHECKING:
    from .database import Database
    from .scope import Scope

AuthMode = Literal["api_key", "scope_token"]


class Cinch:
    """Cinch SDK client.

    Args:
        api_key: API key for full account access. Mutually exclusive with scope_token.
        scope_token: Scope token for scoped agent access. Mutually exclusive with api_key.
        org: Organization slug (required for API key mode).
        api_base: API base URL (default: https://api.cinchdb.dev).
        default_environment: Default environment for scope creation (API key mode).
        default_project: Default project for scope creation (API key mode).
        timeout: Request timeout in seconds (default: 30).
        max_retries: Max retry attempts (default: 3).
        trace_id: User-provided trace ID for correlation.
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        scope_token: Optional[str] = None,
        org: Optional[str] = None,
        api_base: Optional[str] = None,
        default_environment: Optional[str] = None,
        default_project: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        trace_id: Optional[str] = None,
    ) -> None:
        resolved_api_key = api_key or os.environ.get("CINCH_API_KEY", "")
        resolved_scope_token = scope_token or ""

        if resolved_api_key and resolved_scope_token:
            raise ValidationError(
                "Provide either api_key or scope_token, not both"
            )

        if not resolved_api_key and not resolved_scope_token:
            raise AuthenticationError(
                "Authentication required. Provide api_key or scope_token "
                "(or set CINCH_API_KEY env var)"
            )

        if resolved_api_key:
            self._auth_mode: AuthMode = "api_key"
            self._auth_token = resolved_api_key
            self._org = org or os.environ.get("CINCH_ORG", "")
            if not self._org:
                raise ValidationError(
                    "Organization required in API key mode. "
                    "Provide org or set CINCH_ORG env var"
                )
            self._default_environment = (
                default_environment or os.environ.get("CINCH_ENV")
            )
            self._default_project = (
                default_project or os.environ.get("CINCH_PROJECT")
            )
        else:
            self._auth_mode = "scope_token"
            self._auth_token = resolved_scope_token
            self._org = ""
            self._default_environment = None
            self._default_project = None

        self._api_base = (
            api_base
            or os.environ.get("CINCH_API_BASE")
            or "https://api.cinchdb.dev"
        )

        # TLS enforcement
        if not self._api_base.startswith("https://"):
            is_localhost = (
                "localhost" in self._api_base or "127.0.0.1" in self._api_base
            )
            if not is_localhost:
                raise SecurityError(
                    "API base URL must use HTTPS (except localhost for development)"
                )

        self._timeout = timeout
        self._max_retries = max_retries
        self._trace_id = trace_id or generate_trace_id()
        self._circuit_breaker = CircuitBreaker()
        self._session = requests.Session()

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self) -> Cinch:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # =========================================================================
    # API Key Mode Methods
    # =========================================================================

    def scope(
        self,
        name: str,
        *,
        environment: Optional[str] = None,
        project: Optional[str] = None,
        slug: Optional[str] = None,
        parent: Optional[str] = None,
        idle_ttl: Optional[str] = None,
        sleep_ttl: Optional[str] = None,
        destroy_ttl: Optional[str] = None,
        config_overrides: Optional[Dict[str, Any]] = None,
    ) -> Scope:
        """Create or get a scope (API key mode only)."""
        self._require_api_key_mode("scope()")

        env = environment or self._default_environment
        proj = project or self._default_project

        if not env:
            raise ValidationError(
                "Environment required. Provide environment or set default_environment"
            )
        if not proj:
            raise ValidationError(
                "Project required. Provide project or set default_project"
            )

        body: Dict[str, Any] = {"name": name, "slug": slug or name}
        if parent:
            body["parent_id"] = parent

        overrides: Dict[str, Any] = {}
        if idle_ttl is not None:
            overrides["idle_ttl"] = idle_ttl
        if sleep_ttl is not None:
            overrides["sleep_ttl"] = sleep_ttl
        if destroy_ttl is not None:
            overrides["destroy_ttl"] = destroy_ttl
        if config_overrides:
            overrides.update(config_overrides)
        if overrides:
            import json

            body["config_overrides"] = json.dumps(overrides)

        data = self.request(
            "POST",
            f"/orgs/{self._org}/projects/{proj}/environments/{env}/scopes",
            body=body,
        )

        from .scope import Scope as ScopeClass

        return ScopeClass(self, data, project_slug=proj, environment_slug=env)

    def scopes(
        self,
        environment: str,
        project: str,
        page: int = 1,
        limit: int = 100,
    ) -> List[Scope]:
        """List all scopes in an environment (API key mode only)."""
        self._require_api_key_mode("scopes()")

        data = self.request(
            "GET",
            f"/orgs/{self._org}/projects/{project}/environments/{environment}/scopes",
            query={"page": page, "limit": limit},
        )

        from .scope import Scope as ScopeClass

        return [
            ScopeClass(
                self, s, project_slug=project, environment_slug=environment
            )
            for s in data["scopes"]
        ]

    # =========================================================================
    # Scope Token Mode Methods
    # =========================================================================

    def scope_auth_databases(self) -> List[Database]:
        """List databases accessible via scope token (scope token mode only)."""
        self._require_scope_token_mode("scope_auth_databases()")

        data = self.request("GET", "/scope-auth/databases")

        from .database import Database as DatabaseClass

        return [DatabaseClass(self, d) for d in data["databases"]]

    def scope_auth_database(self, database_id: str) -> Database:
        """Get a specific database by ID (scope token mode only)."""
        self._require_scope_token_mode("scope_auth_database()")

        data = self.request("GET", "/scope-auth/databases")
        for d in data["databases"]:
            if d["id"] == database_id:
                from .database import Database as DatabaseClass

                return DatabaseClass(self, d)

        raise NotFoundError(
            f"Database '{database_id}' not found in scope hierarchy"
        )

    def scope_auth_scope(self, name: str) -> Scope:
        """Get a specific scope by name (scope token mode only).

        Args:
            name: Scope name to find.

        Returns:
            Scope instance.

        Raises:
            NotFoundError: If no scope with that name exists in the hierarchy.
        """
        self._require_scope_token_mode("scope_auth_scope()")

        data = self.request("GET", "/scope-auth/scopes")

        from .scope import Scope as ScopeClass

        for s in data["scopes"]:
            if s["name"] == name:
                return ScopeClass(self, s)

        raise NotFoundError(
            f"Scope '{name}' not found in scope hierarchy"
        )

    def scope_auth_scopes(self) -> List[Scope]:
        """List scopes accessible via scope token (scope token mode only)."""
        self._require_scope_token_mode("scope_auth_scopes()")

        data = self.request("GET", "/scope-auth/scopes")

        from .scope import Scope as ScopeClass

        return [ScopeClass(self, s) for s in data["scopes"]]

    # =========================================================================
    # HTTP Request
    # =========================================================================

    def request(
        self,
        method: str,
        path: str,
        *,
        body: Optional[Dict[str, Any]] = None,
        query: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make HTTP request to Cinch API with retry, circuit breaker, and tracing."""
        if not self._circuit_breaker.can_attempt():
            retry_after = self._circuit_breaker.get_retry_after()
            raise CircuitBreakerOpenError(
                f"Control plane unavailable, circuit breaker open. "
                f"Retry after {retry_after}s",
                retry_after=retry_after,
                trace_id=self._trace_id,
                request_path=path,
            )

        span_id = generate_span_id()
        url = f"{self._api_base}{path}"

        params: Optional[Dict[str, str]] = None
        if query:
            params = {k: str(v) for k, v in query.items() if v is not None}

        errors: List[Exception] = []

        for attempt in range(self._max_retries + 1):
            try:
                json_body = (
                    body
                    if method in ("POST", "PUT", "PATCH") and body
                    else None
                )
                response = self._session.request(
                    method,
                    url,
                    json=json_body,
                    params=params,
                    headers={
                        "Authorization": f"Bearer {self._auth_token}",
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                        "User-Agent": "cinch-python/0.2.0",
                        "traceparent": format_traceparent(
                            self._trace_id, span_id
                        ),
                    },
                    timeout=self._timeout,
                )

                if not response.ok:
                    error_message = f"HTTP {response.status_code}"
                    error_body: Optional[Dict[str, Any]] = None
                    request_id = response.headers.get("x-request-id")

                    try:
                        error_body = response.json()
                        if (
                            isinstance(error_body, dict)
                            and "error" in error_body
                        ):
                            error_message = error_body["error"]
                    except (ValueError, KeyError):
                        pass

                    ctx: Dict[str, Any] = dict(
                        status_code=response.status_code,
                        request_path=path,
                        trace_id=self._trace_id,
                        span_id=span_id,
                        request_id=request_id,
                    )

                    # Handle 409 idempotent conflicts
                    if (
                        response.status_code == 409
                        and error_body
                        and "existing" in error_body
                    ):
                        self._circuit_breaker.record_success()
                        return error_body["existing"]

                    if response.status_code == 401:
                        raise AuthenticationError(error_message, **ctx)
                    elif response.status_code == 403:
                        raise ForbiddenError(error_message, **ctx)
                    elif response.status_code == 404:
                        raise NotFoundError(error_message, **ctx)
                    elif response.status_code == 400:
                        raise ValidationError(error_message, **ctx)
                    elif response.status_code == 409:
                        raise ConflictError(
                            error_message,
                            existing=(
                                error_body.get("existing")
                                if error_body
                                else None
                            ),
                            **ctx,
                        )
                    else:
                        api_ctx = {
                            k: v
                            for k, v in ctx.items()
                            if k != "status_code"
                        }
                        raise ApiError(
                            error_message,
                            status_code=response.status_code,
                            **api_ctx,
                        )

                self._circuit_breaker.record_success()

                if response.status_code == 204:
                    return None

                return response.json()

            except (
                AuthenticationError,
                ForbiddenError,
                NotFoundError,
                ValidationError,
                ConflictError,
            ):
                # Non-retryable client errors — server IS responding,
                # so don't trip the circuit breaker. Propagate immediately.
                raise

            except ApiError as e:
                errors.append(e)
                is_server = e.status_code in (500, 502, 503, 504)
                if not is_server or attempt == self._max_retries:
                    self._circuit_breaker.record_failure()
                    if (
                        attempt == self._max_retries
                        and is_server
                        and self._max_retries > 0
                    ):
                        raise RetryExhaustedError(
                            f"All {self._max_retries + 1} attempts failed",
                            attempts=errors,
                            request_path=path,
                            trace_id=self._trace_id,
                            span_id=span_id,
                        )
                    raise
                backoff = 2**attempt
                time.sleep(backoff)

            except requests.exceptions.Timeout as e:
                errors.append(e)
                if attempt == self._max_retries:
                    self._circuit_breaker.record_failure()
                    raise RetryExhaustedError(
                        f"All {self._max_retries + 1} attempts failed",
                        attempts=errors,
                        request_path=path,
                        trace_id=self._trace_id,
                        span_id=span_id,
                    )
                backoff = 2**attempt
                time.sleep(backoff)

            except requests.exceptions.ConnectionError as e:
                errors.append(e)
                if attempt == self._max_retries:
                    self._circuit_breaker.record_failure()
                    raise RetryExhaustedError(
                        f"All {self._max_retries + 1} attempts failed",
                        attempts=errors,
                        request_path=path,
                        trace_id=self._trace_id,
                        span_id=span_id,
                    )
                backoff = 2**attempt
                time.sleep(backoff)

            except requests.exceptions.RequestException as e:
                self._circuit_breaker.record_failure()
                raise NetworkError(
                    str(e),
                    request_path=path,
                    trace_id=self._trace_id,
                    span_id=span_id,
                )

        raise RetryExhaustedError(
            f"All {self._max_retries + 1} attempts failed",
            attempts=errors,
            request_path=path,
            trace_id=self._trace_id,
        )

    # =========================================================================
    # Getters
    # =========================================================================

    @property
    def auth_mode(self) -> AuthMode:
        return self._auth_mode

    @property
    def org(self) -> str:
        return self._org

    @property
    def api_base(self) -> str:
        return self._api_base

    @property
    def default_environment(self) -> Optional[str]:
        return self._default_environment

    @property
    def default_project(self) -> Optional[str]:
        return self._default_project

    @property
    def trace_id(self) -> str:
        return self._trace_id

    # =========================================================================
    # Private Helpers
    # =========================================================================

    def _require_api_key_mode(self, method: str) -> None:
        if self._auth_mode != "api_key":
            raise ValidationError(
                f"{method} requires API key mode. "
                "Use scope_auth_databases()/scope_auth_scopes() with scope tokens."
            )

    def _require_scope_token_mode(self, method: str) -> None:
        if self._auth_mode != "scope_token":
            raise ValidationError(
                f"{method} requires scope token mode. "
                "Initialize with Cinch(scope_token='...')."
            )
