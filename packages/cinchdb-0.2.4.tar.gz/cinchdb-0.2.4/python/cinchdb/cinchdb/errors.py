"""
Error classes for Cinch SDK

Follows fail-fast principle: errors are explicit and descriptive.
All errors include trace context for debugging.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class CinchError(Exception):
    """Base error for all Cinch SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        request_path: Optional[str] = None,
        trace_id: Optional[str] = None,
        span_id: Optional[str] = None,
        retry_after: Optional[int] = None,
        request_id: Optional[str] = None,
        is_retryable: bool = False,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.request_path = request_path
        self.trace_id = trace_id
        self.span_id = span_id
        self.retry_after = retry_after
        self.request_id = request_id
        self.is_retryable = is_retryable


class AuthenticationError(CinchError):
    """Invalid or expired API key or scope token (401)."""

    def __init__(self, message: str, **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 401)
        kwargs["is_retryable"] = False
        super().__init__(message, **kwargs)


class ForbiddenError(CinchError):
    """Scope token lacks required permission (403)."""

    def __init__(self, message: str, **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 403)
        kwargs["is_retryable"] = False
        super().__init__(message, **kwargs)


class ValidationError(CinchError):
    """Missing fields or invalid values (400)."""

    def __init__(self, message: str, **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 400)
        kwargs["is_retryable"] = False
        super().__init__(message, **kwargs)


class NotFoundError(CinchError):
    """Resource does not exist (404)."""

    def __init__(self, message: str, **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 404)
        kwargs["is_retryable"] = False
        super().__init__(message, **kwargs)


class ConflictError(CinchError):
    """Duplicate resource (409). May contain existing resource data."""

    def __init__(
        self, message: str, existing: Any = None, **kwargs: Any
    ) -> None:
        kwargs.setdefault("status_code", 409)
        kwargs["is_retryable"] = False
        super().__init__(message, **kwargs)
        self.existing = existing


class ApiError(CinchError):
    """General API error (5xx or other non-standard status codes)."""

    def __init__(
        self, message: str, status_code: int = 500, **kwargs: Any
    ) -> None:
        kwargs["status_code"] = status_code
        kwargs["is_retryable"] = status_code in (500, 502, 503, 504)
        super().__init__(message, **kwargs)


class TimeoutError(CinchError):
    """Request exceeded timeout."""

    def __init__(self, message: str, **kwargs: Any) -> None:
        kwargs["is_retryable"] = True
        super().__init__(message, **kwargs)


class NetworkError(CinchError):
    """Connection refused, DNS failure, or other network error."""

    def __init__(self, message: str, **kwargs: Any) -> None:
        kwargs["is_retryable"] = True
        super().__init__(message, **kwargs)


class RetryExhaustedError(CinchError):
    """All retry attempts failed."""

    def __init__(
        self, message: str, attempts: List[Exception], **kwargs: Any
    ) -> None:
        kwargs["is_retryable"] = False
        super().__init__(message, **kwargs)
        self.attempts = attempts


class CircuitBreakerOpenError(CinchError):
    """Control plane unavailable, circuit breaker is open."""

    def __init__(
        self, message: str, retry_after: int, **kwargs: Any
    ) -> None:
        kwargs["is_retryable"] = False
        kwargs["retry_after"] = retry_after
        super().__init__(message, **kwargs)


class SecurityError(CinchError):
    """TLS requirement violated or other security issue."""

    def __init__(self, message: str, **kwargs: Any) -> None:
        kwargs["is_retryable"] = False
        super().__init__(message, **kwargs)


class ScopeDeletedError(CinchError):
    """Scope was deleted and is no longer valid."""

    def __init__(self, scope_name: str, **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 404)
        kwargs["is_retryable"] = False
        super().__init__(f"Scope '{scope_name}' was deleted", **kwargs)
        self.scope_name = scope_name


class ScopeRecreatedError(CinchError):
    """Scope was deleted and recreated with a different ID."""

    def __init__(self, scope_name: str, **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 404)
        kwargs["is_retryable"] = False
        super().__init__(
            f"Scope '{scope_name}' was deleted and recreated with new ID. "
            "Please create a new Scope instance",
            **kwargs,
        )
        self.scope_name = scope_name
