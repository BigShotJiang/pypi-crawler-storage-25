//! SQL REPL over HTTP (Phase Meridian Step c)
