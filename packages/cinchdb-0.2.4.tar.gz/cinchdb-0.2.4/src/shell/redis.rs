//! Embedded Redis REPL (Phase Meridian Step c)
