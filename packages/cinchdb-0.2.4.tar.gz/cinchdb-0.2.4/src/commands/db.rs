//! Database commands: create, list, show, shell, destroy, wake, token

use anyhow::Result;
use clap::Subcommand;

#[derive(Subcommand)]
pub enum DbCommands {
    /// Create a new database
    Create {
        /// Database name
        name: String,
        /// Database type
        #[arg(long, value_parser = ["redis", "sql", "graph"])]
        r#type: String,
        /// Scope (defaults to context scope or "default")
        #[arg(long)]
        scope: Option<String>,
        /// Memory allocation in MB
        #[arg(long)]
        memory_mb: Option<u32>,
        /// Idle timeout (e.g. "30m", "1h")
        #[arg(long)]
        idle_timeout: Option<String>,
        /// Sleep timeout (e.g. "24h")
        #[arg(long)]
        sleep_timeout: Option<String>,
    },
    /// List databases
    List {
        /// Filter by scope
        #[arg(long)]
        scope: Option<String>,
    },
    /// Show database details
    Show {
        /// Database name
        name: String,
        /// Print only the connection URL
        #[arg(long)]
        url: bool,
        /// Print only the password
        #[arg(long)]
        password: bool,
        /// Print as env vars
        #[arg(long)]
        env_vars: bool,
    },
    /// Open an interactive shell
    Shell {
        /// Database name
        name: String,
        /// One-shot command to execute
        command: Option<String>,
    },
    /// Destroy a database
    Destroy {
        /// Database name
        name: String,
        /// Skip confirmation
        #[arg(short, long)]
        yes: bool,
    },
    /// Wake an archived database
    Wake {
        /// Database name
        name: String,
    },
    /// Issue a database access token
    Token {
        /// Database name
        name: String,
        /// Read-only token
        #[arg(long)]
        read_only: bool,
        /// Token expiration (e.g. "24h", "7d")
        #[arg(long)]
        expires: Option<String>,
    },
}

pub async fn run(_command: DbCommands, _api_url: &str, _json: bool) -> Result<()> {
    anyhow::bail!("database commands not yet implemented (Phase Meridian Step b)")
}
