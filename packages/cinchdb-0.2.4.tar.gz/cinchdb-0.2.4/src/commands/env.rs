//! `cinch env <name>` - print eval-able environment variables for a database

use anyhow::Result;

pub async fn run(_name: &str, _scope: Option<&str>, _api_url: &str, _json: bool) -> Result<()> {
    anyhow::bail!("env command not yet implemented (Phase Meridian Step b)")
}
