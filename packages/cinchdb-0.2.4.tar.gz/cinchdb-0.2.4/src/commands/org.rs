//! Organization commands: list, switch, members

use anyhow::Result;
use clap::Subcommand;

#[derive(Subcommand)]
pub enum OrgCommands {
    /// List your organizations
    List,
    /// Switch active organization
    Switch {
        /// Organization slug
        slug: String,
    },
    /// Manage organization members
    Members {
        #[command(subcommand)]
        command: MembersCommands,
    },
}

#[derive(Subcommand)]
pub enum MembersCommands {
    /// List members
    List,
    /// Add a member
    Add {
        /// Email address
        email: String,
    },
    /// Remove a member
    Remove {
        /// Email address
        email: String,
    },
}

pub async fn run(_command: OrgCommands, _api_url: &str, _json: bool) -> Result<()> {
    anyhow::bail!("org commands not yet implemented (Phase Meridian Step e)")
}
