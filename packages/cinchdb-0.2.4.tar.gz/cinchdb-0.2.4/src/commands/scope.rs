//! Scope commands: create, list, show, destroy, token

use anyhow::Result;
use clap::Subcommand;

#[derive(Subcommand)]
pub enum ScopeCommands {
    /// Create a new scope
    Create {
        /// Scope name
        name: String,
        /// Parent scope for nesting
        #[arg(long)]
        parent: Option<String>,
    },
    /// List scopes
    List,
    /// Show scope details
    Show {
        /// Scope name
        name: String,
    },
    /// Destroy a scope (cascading delete)
    Destroy {
        /// Scope name
        name: String,
        /// Skip confirmation
        #[arg(short, long)]
        yes: bool,
    },
    /// Issue a scope token
    Token {
        /// Scope name
        name: String,
        /// Permission level
        #[arg(long, value_parser = ["read", "write", "admin"], default_value = "read")]
        permission: String,
        /// Token expiration (e.g. "24h", "7d")
        #[arg(long)]
        expires: Option<String>,
    },
}

pub async fn run(_command: ScopeCommands, _api_url: &str, _json: bool) -> Result<()> {
    anyhow::bail!("scope commands not yet implemented (Phase Meridian Step d)")
}
