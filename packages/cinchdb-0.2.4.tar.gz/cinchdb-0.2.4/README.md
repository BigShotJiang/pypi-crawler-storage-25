# cinchdb

CLI for [CinchDB](https://cinchdb.dev) - databases for agents.

## Install

```bash
# From PyPI (any platform)
pip install cinchdb

# From crates.io (requires Rust toolchain)
cargo install cinchdb

# From source
git clone https://github.com/cinchdatabase/cinch-cloud.git
cd cinch-cloud/cli
cargo install --path .
```

## Quick start

```bash
# Log in (opens browser)
cinch auth login

# Create a Redis database
cinch db create cache --type redis

# Open a shell
cinch db shell cache
```

## Commands

```
cinch auth login          # Browser-based login (--headless for CI)
cinch auth whoami         # Show current user and context
cinch auth api-keys list  # Manage API keys
cinch db create           # Create a database (redis, sql, graph)
cinch db list             # List databases
cinch db shell            # Interactive shell
cinch config              # Show/set persistent context
cinch config set org X    # Set default organization
```

Run `cinch --help` for the full command reference.
