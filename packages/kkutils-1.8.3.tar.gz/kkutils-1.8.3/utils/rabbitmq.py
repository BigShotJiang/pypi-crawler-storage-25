#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Last modified: 2018-09-29 00:59:38
'''
import asyncio
import logging
import os
import pickle
import threading
from functools import partial

import aio_pika
import pika

logging.getLogger('pika').setLevel(logging.ERROR)

__all__ = ['Pika', 'AioPika']


class Pika:

    def __init__(self, queue, **kwargs):
        uri = kwargs.pop('uri', os.environ.get('MQ_URI'))
        if not uri:
            host = kwargs.pop('host', os.environ.get('MQ_HOST', 'localhost'))
            port = kwargs.pop('port', os.environ.get('MQ_PORT', 5672))
            user = kwargs.pop('user', os.environ.get('MQ_USER', 'guest'))
            pwd = kwargs.pop('pwd', os.environ.get('MQ_PWD', 'guest'))
            vhost = kwargs.pop('vhost', os.environ.get('MQ_VHOST', '/'))
            uri = f'amqp://{user}:{pwd}@{host}:{port}{vhost}'

        self.uri = uri
        self.logger = logging.getLogger()
        self.queue = queue
        self._connection = None
        self._channels = {}
        self._queues = {}
        self._lock = threading.Lock()

    def connect(self):
        if self._connection is None or self._connection.is_closed:
            parameter = pika.URLParameters(self.uri)
            self._connection = pika.BlockingConnection(parameter)
            self.logger.info(self._connection)

    def init(self, queue=None, auto_ack=False):
        queue = queue or self.queue
        self.connect()

        if not (queue in self._channels and not self._channels[queue].is_closed):
            channel = self._connection.channel()
            channel.basic_qos(prefetch_count=1)
            q = channel.queue_declare(queue=queue, auto_delete=False, durable=False)
            self._channels[queue] = channel
            self._queues[queue] = q

        return queue

    def size(self, queue=None):
        queue = self.init(queue)
        return self._queues[queue].method.message_count

    def _consume(self, process, auto_ack, channel, method_frame, header_frame, body):
        try:
            if auto_ack:
                channel.basic_ack(delivery_tag=method_frame.delivery_tag)
            process(pickle.loads(body))
            if not auto_ack:
                channel.basic_ack(delivery_tag=method_frame.delivery_tag)
        except Exception as e:
            self.logger.exception(e)

    def consume(self, process, queue=None, auto_ack=False):
        queue = self.init(queue, auto_ack)
        channel = self._channels[queue]
        channel.basic_consume(queue, partial(self._consume, process, auto_ack))
        try:
            channel.start_consuming()
        except KeyboardInterrupt:
            channel.stop_consuming()
            self.close()

    def get(self, queue=None, auto_ack=True):
        with self._lock:
            queue = self.init(queue, auto_ack)
            msg = self._channels[queue].basic_get(queue, auto_ack=auto_ack)
        if msg[0] is None:
            return None
        return pickle.loads(msg[-1])

    def publish(self, msg, queue=None):
        with self._lock:
            queue = self.init(queue)
            self._channels[queue].basic_publish(exchange='',
                                                routing_key=queue,
                                                body=pickle.dumps(msg))

    def close(self):
        for channel in self._channels.values():
            if not channel.is_closed:
                channel.close()
        if self._connection is not None and not self._connection.is_closed:
            self._connection.close()


class AioPika(Pika):

    def __init__(self, queue, workers=1, **kwargs):
        super().__init__(queue, **kwargs)
        self.workers = workers
        self.lock = asyncio.Lock()
        self._consumer_tasks = {}
        self._stop_events = {}

    async def connect(self):
        async with self.lock:
            if self._connection is None or self._connection.is_closed:
                self._connection = await aio_pika.connect_robust(self.uri)
                self.logger.info(f'initialize {self._connection}')

    async def size(self, queue=None):
        queue = await self.init(queue)
        return self._queues[queue].declaration_result.message_count

    async def init(self, queue=None, auto_ack=False):
        queue = queue or self.queue
        await self.connect()

        async with self.lock:
            if not (queue in self._channels and not self._channels[queue].is_closed):
                channel = await self._connection.channel()
                await channel.set_qos(prefetch_count=1)
                q = await channel.declare_queue(queue, auto_delete=False, durable=False)
                self._channels[queue] = channel
                self._queues[queue] = q

        return queue

    async def _consume_with_channel(self, process, queue_name, stop_event, auto_ack):
        async with self.lock:
            channel = await self._connection.channel()
            await channel.set_qos(prefetch_count=1)
            q = await channel.declare_queue(queue_name, auto_delete=False, durable=False)

        async with q.iterator() as queue_iter:
            async for msg in queue_iter:
                if stop_event.is_set():
                    break
                try:
                    if auto_ack:
                        await msg.ack()
                    body = pickle.loads(msg.body)
                    await process(body)
                    if not auto_ack:
                        await msg.ack()
                except Exception as e:
                    self.logger.exception(e)
                    if not auto_ack:
                        await msg.nack(requeue=True)

    async def consume(self, process, queue=None, auto_ack=False):
        queue = await self.init(queue, auto_ack)

        if queue not in self._stop_events:
            self._stop_events[queue] = asyncio.Event()
            self._consumer_tasks[queue] = []

        stop_event = self._stop_events[queue]

        for _ in range(self.workers):
            task = asyncio.create_task(self._consume_with_channel(process, queue, stop_event, auto_ack))
            self._consumer_tasks[queue].append(task)

        return self._consumer_tasks[queue]

    async def stop_consume(self, queue=None):
        queue = queue or self.queue
        if queue in self._stop_events:
            self._stop_events[queue].set()
            if queue in self._consumer_tasks:
                await asyncio.gather(*self._consumer_tasks[queue], return_exceptions=True)
                del self._consumer_tasks[queue]
            del self._stop_events[queue]

    async def publish(self, msg, queue=None):
        queue = await self.init(queue)
        message = aio_pika.Message(pickle.dumps(msg))
        await self._channels[queue].default_exchange.publish(message, routing_key=queue)

    async def close(self):
        for queue in list(self._stop_events.keys()):
            await self.stop_consume(queue)

        for channel in list(self._channels.values()):
            if not channel.is_closed:
                await channel.close()

        if self._connection is not None and not self._connection.is_closed:
            await self._connection.close()
