import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import logging


class APIClientError(Exception):
    """Custom exception for API errors"""
    pass


class APIClient:
    def __init__(
        self,
        base_url: str,
        api_key: str = None,
        timeout: int = 10,
        retries: int = 3,
        backoff_factor: float = 0.3,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout

        self.session = requests.Session()

        # Retry strategy
        retry_strategy = Retry(
            total=retries,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
            backoff_factor=backoff_factor,
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

        # Logger
        self.logger = logging.getLogger(__name__)

    def _headers(self, extra_headers=None):
        headers = {
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        if extra_headers:
            headers.update(extra_headers)

        return headers

    def _request(
        self,
        method: str,
        endpoint: str,
        params: dict = None,
        data: dict = None,
        headers: dict = None,
    ):
        url = f"{self.base_url}/{endpoint.lstrip('/')}"

        try:
            self.logger.debug(f"Request: {method} {url}")

            response = self.session.request(
                method=method,
                url=url,
                headers=self._headers(headers),
                params=params,
                json=data,
                timeout=self.timeout,
            )

            self.logger.debug(f"Response status: {response.status_code}")

            response.raise_for_status()

            # Try JSON, fallback to text
            try:
                return response.json()
            except ValueError:
                return response.text

        except requests.exceptions.Timeout:
            raise APIClientError("Request timed out")

        except requests.exceptions.ConnectionError:
            raise APIClientError("Connection error")

        except requests.exceptions.HTTPError as e:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text

            raise APIClientError(
                f"HTTP {response.status_code}: {error_body}"
            ) from e

        except requests.exceptions.RequestException as e:
            raise APIClientError(f"Unexpected error: {str(e)}") from e

    # Public methods
    def get(self, endpoint, params=None, headers=None):
        return self._request("GET", endpoint, params=params, headers=headers)

    def post(self, endpoint, data=None, headers=None):
        return self._request("POST", endpoint, data=data, headers=headers)

    def put(self, endpoint, data=None, headers=None):
        return self._request("PUT", endpoint, data=data, headers=headers)

    def delete(self, endpoint, headers=None):
        return self._request("DELETE", endpoint, headers=headers)

    def patch(self, endpoint, data=None, headers=None):
        return self._request("PATCH", endpoint, data=data, headers=headers)