# My API Client

Simple reusable Python API client.

## Installation
pip install myapiclient-vishal

## Usage
```python
from myapiclient import APIClient

client = APIClient("https://jsonplaceholder.typicode.com")
print(client.get("posts"))
