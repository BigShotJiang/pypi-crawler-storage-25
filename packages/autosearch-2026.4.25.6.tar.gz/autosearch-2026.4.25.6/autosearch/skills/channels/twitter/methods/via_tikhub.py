from __future__ import annotations

import html
from collections.abc import Mapping
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime

import structlog

from autosearch.channels.base import PermanentError
from autosearch.core.models import Evidence, SubQuery
from autosearch.lib.tikhub_client import TikhubClient, TikhubError, to_channel_error

LOGGER = structlog.get_logger(__name__).bind(component="channel", channel="twitter")
SEARCH_PATH = "/api/v1/twitter/web/fetch_search_timeline"
MAX_TITLE_LENGTH = 80
MAX_SNIPPET_LENGTH = 300


def _clean_text(value: object) -> str:
    return " ".join(html.unescape(str(value or "")).split())


def _truncate_on_word_boundary(text: str, *, max_length: int) -> str:
    text = text.strip()
    if len(text) <= max_length:
        return text
    candidate = text[:max_length]
    if candidate and not candidate[-1].isspace():
        shortened = candidate.rsplit(None, 1)[0]
        if shortened:
            candidate = shortened
    return f"{candidate.rstrip()}…"


def _parse_created_at(value: object) -> datetime | None:
    if not value:
        return None

    raw_value = str(value)
    try:
        parsed = datetime.fromisoformat(raw_value.replace("Z", "+00:00"))
    except ValueError:
        try:
            parsed = parsedate_to_datetime(raw_value)
        except (TypeError, ValueError, IndexError, OverflowError):
            return None

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _extract_tweets(payload: Mapping[str, object]) -> list[Mapping[str, object]]:
    """Extract tweet objects — TikHub returns a flat list at data.timeline."""
    data = payload.get("data")
    if not isinstance(data, Mapping):
        raise PermanentError("twitter via_tikhub: unexpected payload shape (schema drift?)")
    timeline = data.get("timeline")
    if not isinstance(timeline, list):
        raise PermanentError("twitter via_tikhub: unexpected payload shape (schema drift?)")
    return [t for t in timeline if isinstance(t, Mapping)]


def _expand_url(entities: object) -> str:
    if not isinstance(entities, Mapping):
        return ""
    urls = entities.get("urls")
    if not isinstance(urls, list):
        return ""
    for u in urls:
        if not isinstance(u, Mapping):
            continue
        expanded = str(u.get("expanded_url") or "").strip()
        if expanded and not expanded.startswith("https://t.co"):
            return expanded
    return ""


def _to_evidence(tweet: Mapping[str, object], *, fetched_at: datetime) -> Evidence | None:
    tweet_id = str(tweet.get("tweet_id") or "").strip()
    screen_name = str(tweet.get("screen_name") or "").strip()
    text = _clean_text(tweet.get("text"))

    if not tweet_id or not screen_name:
        return None

    url = f"https://x.com/{screen_name}/status/{tweet_id}"
    title = _truncate_on_word_boundary(text, max_length=MAX_TITLE_LENGTH) or "Tweet"
    snippet = _truncate_on_word_boundary(text, max_length=MAX_SNIPPET_LENGTH) or None
    content = text or snippet

    return Evidence(
        url=url,
        title=title,
        snippet=snippet,
        content=content,
        source_channel=f"twitter:{screen_name}",
        fetched_at=fetched_at,
        published_at=_parse_created_at(tweet.get("created_at")),
    )


async def search(query: SubQuery, client: TikhubClient | None = None) -> list[Evidence]:
    try:
        tikhub_client = client or TikhubClient()
        payload = await tikhub_client.get(
            SEARCH_PATH,
            {"keyword": query.text, "search_type": "Latest"},
        )
    except TikhubError as exc:
        # Bug 1 (fix-plan): translate TikHub error → channels.base typed
        # error so a 401/403/429/402 surfaces as auth_failed/rate_limited
        # at the MCP boundary instead of looking like an empty result.
        LOGGER.warning("twitter_tikhub_search_failed", reason=str(exc))
        raise to_channel_error(exc) from exc
    except ValueError as exc:
        # TikhubClient() raises ValueError on missing TIKHUB_API_KEY; the
        # MCP boundary already returns not_configured for that case via
        # SKILL.md requires, so this is a redundant safety net.
        LOGGER.warning("twitter_tikhub_search_failed", reason=str(exc))
        return []

    tweets = _extract_tweets(payload)
    fetched_at = datetime.now(UTC)

    results: list[Evidence] = []
    for tweet in tweets:
        evidence = _to_evidence(tweet, fetched_at=fetched_at)
        if evidence is not None:
            results.append(evidence)

    return results
