from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class RunnerConfig:
    """Declarative configuration for a runner attached to a workdir.

    Attributes:
        dockerfile:       Path to the Dockerfile, relative to the workdir root.
                          Convention: .wex/docker/Dockerfile.{runner_name}
        image_name:       Docker image name. Defaults to "wex-{runner_name}".
        mount_path:       Host path to mount inside the container.
                          Defaults to the workdir's own path.
        container_workdir: Working directory inside the container.
        volumes:          Additional volume mappings {host: container}.
        ephemeral:        If True, destroy the container after each runner_exec call.
    """

    dockerfile: str | Path

    container_workdir: str = "/var/www/html"
    ephemeral: bool = False
    image_name: str = ""
    mount_path: str | Path | None = None
    volumes: dict[str, str] = field(default_factory=dict)
