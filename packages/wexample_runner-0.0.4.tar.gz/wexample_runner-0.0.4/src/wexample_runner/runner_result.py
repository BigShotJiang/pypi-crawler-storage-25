from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RunnerResult:
    exit_code: int
    stderr: str
    stdout: str

    def is_success(self) -> bool:
        return self.exit_code == 0

    def raise_on_error(self) -> None:
        if not self.is_success():
            raise RuntimeError(
                f"Command failed (exit {self.exit_code}):\n{self.stderr or self.stdout}"
            )
