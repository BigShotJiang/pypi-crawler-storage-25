from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wexample_runner.abstract_runner import AbstractRunner


class RunnerRegistry:
    """Global registry of named runners.

    Allows packages to register runners by name and retrieve them later,
    providing a central place to inspect the state of all known environments.
    """

    _runners: dict[str, AbstractRunner] = {}

    @classmethod
    def all(cls) -> dict[str, AbstractRunner]:
        return dict(cls._runners)

    @classmethod
    def get(cls, name: str) -> AbstractRunner | None:
        return cls._runners.get(name)

    @classmethod
    def get_or_raise(cls, name: str) -> AbstractRunner:
        runner = cls.get(name)
        if runner is None:
            raise KeyError(f"No runner registered under name '{name}'.")
        return runner

    @classmethod
    def register(cls, name: str, runner: AbstractRunner) -> None:
        cls._runners[name] = runner

    @classmethod
    def status(cls) -> list[dict]:
        """Return a list of dicts describing the state of each registered runner."""
        return [
            {
                "name": name,
                "type": type(runner).__name__,
                "is_built": runner.is_built,
                "is_running": runner.is_running,
                "ephemeral": runner.ephemeral,
            }
            for name, runner in cls._runners.items()
        ]
