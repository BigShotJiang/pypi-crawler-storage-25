from __future__ import annotations

from pathlib import Path

from wexample_runner.runner.abstract_runner import AbstractRunner
from wexample_runner.runner_result import RunnerResult


class DockerRunner(AbstractRunner):
    """Execute commands inside a Docker container.

    Manages the full lifecycle: image build, container creation, start, stop, destroy.
    """

    def __init__(
        self,
        image_name: str,
        dockerfile_path: Path | str | None = None,
        volumes: dict[str, str] | None = None,
        env: dict[str, str] | None = None,
        container_name: str | None = None,
        workdir: str = "/var/www/html",
        ephemeral: bool = False,
        user: str | None = None,
    ) -> None:
        super().__init__(ephemeral=ephemeral)
        self.image_name = image_name
        self.dockerfile_path = Path(dockerfile_path) if dockerfile_path else None
        self.volumes = volumes or {}
        self.env = env or {}
        self.workdir = workdir
        self.user = user
        self._container_name = container_name or self._build_container_name()

    @property
    def container_name(self) -> str:
        return self._container_name

    @property
    def is_built(self) -> bool:
        from wexample_helpers.helpers.docker import docker_image_exists

        return docker_image_exists(self.image_name)

    # --- Properties ---
    @property
    def is_running(self) -> bool:
        from wexample_helpers.helpers.docker import docker_container_is_running

        return docker_container_is_running(self.container_name)

    # --- Lifecycle ---
    def build(self) -> None:
        from wexample_helpers.helpers.docker import (
            docker_build_image,
            docker_image_exists,
        )

        if self.dockerfile_path and not docker_image_exists(self.image_name):
            docker_build_image(self.image_name, self.dockerfile_path)

    def destroy(self) -> None:
        from wexample_helpers.helpers.docker import (
            docker_container_exists,
            docker_image_exists,
            docker_remove_container,
            docker_remove_image,
        )

        if docker_container_exists(self.container_name):
            self.stop()
            docker_remove_container(self.container_name)

        if docker_image_exists(self.image_name):
            docker_remove_image(self.image_name)

    # --- Execution ---
    def execute(
        self,
        cmd: list[str] | str,
        workdir: str | None = None,
        env: dict[str, str] | None = None,
    ) -> RunnerResult:
        import subprocess

        from wexample_helpers.helpers.shell import shell_run

        if isinstance(cmd, str):
            cmd = ["sh", "-c", cmd]

        docker_cmd = ["docker", "exec"]

        if self.user:
            docker_cmd += ["--user", self.user]

        effective_workdir = workdir or self.workdir
        if effective_workdir:
            docker_cmd += ["-w", effective_workdir]

        effective_env = {**self.env, **(env or {})}
        for key, value in effective_env.items():
            docker_cmd += ["-e", f"{key}={value}"]

        docker_cmd += [self.container_name] + cmd

        try:
            result = shell_run(cmd=docker_cmd, check=False, capture=True)
            return RunnerResult(
                stdout=result.stdout or "",
                stderr=result.stderr or "",
                exit_code=result.returncode,
            )
        except subprocess.CalledProcessError as e:
            return RunnerResult(
                stdout=e.stdout or "",
                stderr=e.stderr or "",
                exit_code=e.returncode,
            )

    # --- Utilities ---
    def rebase_path(self, host_path: str | Path) -> str:
        """Rebase a host path to its equivalent inside the container.

        Example:
            host:      /home/user/project/src/MyFile.php
            mount:     /home/user/project → /var/www/html
            result:    /var/www/html/src/MyFile.php
        """
        host_path = Path(host_path).resolve()
        mount_host = Path(list(self.volumes.keys())[0]).resolve()
        container_root = list(self.volumes.values())[0]
        relative = host_path.relative_to(mount_host)
        return f"{container_root.rstrip('/')}/{relative}"

    def start(self) -> None:
        import os

        from wexample_helpers.helpers.docker import (
            docker_container_exists,
            docker_container_is_running,
            docker_run_container,
            docker_start_container,
        )

        if docker_container_exists(self.container_name):
            if not docker_container_is_running(self.container_name):
                docker_start_container(self.container_name)
        else:
            user = f"{os.getuid()}:{os.getgid()}"
            docker_run_container(
                self.container_name,
                self.image_name,
                volumes=self.volumes,
                user=user,
            )

    def stop(self) -> None:
        from wexample_helpers.helpers.docker import (
            docker_container_is_running,
            docker_stop_container,
        )

        if docker_container_is_running(self.container_name):
            docker_stop_container(self.container_name)

    def _build_container_name(self) -> str:
        from wexample_helpers.helpers.docker import docker_build_name_from_path

        anchor = list(self.volumes.keys())[0] if self.volumes else self.image_name
        return docker_build_name_from_path(root_path=anchor, image_name=self.image_name)
