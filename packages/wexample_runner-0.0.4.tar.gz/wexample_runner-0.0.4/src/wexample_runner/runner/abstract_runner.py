from __future__ import annotations

from abc import ABC, abstractmethod


class AbstractRunner(ABC):
    """Base class for all runners.

    A runner is an execution environment that can build, start, stop, and
    destroy itself, and execute commands within it.
    """

    def __init__(self, ephemeral: bool = False) -> None:
        self.ephemeral = ephemeral

    # --- Context manager (ephemeral support) ---
    def __enter__(self) -> AbstractRunner:
        self.ensure_running()
        return self

    def __exit__(self, *args) -> None:
        self.stop()
        if self.ephemeral:
            self.destroy()

    @property
    def is_built(self) -> bool:
        return False

    # --- Properties ---
    @property
    def is_running(self) -> bool:
        return False

    # --- Lifecycle ---
    def build(self) -> None:
        """Prepare the environment (build image, check connectivity, etc.). No-op if already built."""

    def destroy(self) -> None:
        """Completely remove the environment."""

    def ensure_running(self) -> None:
        """Build and start the environment if not already running."""
        self.build()
        self.start()

    # --- Execution ---
    @abstractmethod
    def execute(
        self,
        cmd: list[str] | str,
        workdir: str | None = None,
        env: dict[str, str] | None = None,
    ) -> RunnerResult:
        """Execute a command in this environment and return the result."""

    def start(self) -> None:
        """Start the environment. No-op if already running."""

    def stop(self) -> None:
        """Stop the environment without destroying it."""
