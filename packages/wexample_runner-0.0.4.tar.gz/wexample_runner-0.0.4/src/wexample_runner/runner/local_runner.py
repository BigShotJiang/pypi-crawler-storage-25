from __future__ import annotations

from wexample_runner.runner.abstract_runner import AbstractRunner
from wexample_runner.runner_result import RunnerResult


class LocalRunner(AbstractRunner):
    """Execute commands on the local machine via subprocess."""

    @property
    def is_built(self) -> bool:
        return True

    @property
    def is_running(self) -> bool:
        return True

    def execute(
        self,
        cmd: list[str] | str,
        workdir: str | None = None,
        env: dict[str, str] | None = None,
    ) -> RunnerResult:
        from wexample_helpers.helpers.shell import shell_run

        result = shell_run(
            cmd=cmd,
            cwd=workdir,
            env=env,
            check=False,
            capture=True,
        )

        return RunnerResult(
            stdout=result.stdout or "",
            stderr=result.stderr or "",
            exit_code=result.returncode,
        )
