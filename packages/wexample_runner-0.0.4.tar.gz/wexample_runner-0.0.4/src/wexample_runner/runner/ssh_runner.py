from __future__ import annotations

from wexample_runner.runner.abstract_runner import AbstractRunner
from wexample_runner.runner_result import RunnerResult


class SshRunner(AbstractRunner):
    """Execute commands on a remote server via SSH (using paramiko).

    Supports key-based and password authentication.
    The connection is opened on start() and closed on stop().
    """

    def __init__(
        self,
        host: str,
        user: str = "root",
        port: int = 22,
        key_path: str | None = None,
        password: str | None = None,
        ephemeral: bool = False,
    ) -> None:
        super().__init__(ephemeral=ephemeral)
        self.host = host
        self.user = user
        self.port = port
        self.key_path = key_path
        self.password = password
        self._client = None

    @property
    def is_built(self) -> bool:
        return True

    # --- Properties ---
    @property
    def is_running(self) -> bool:
        return (
            self._client is not None
            and self._client.get_transport() is not None
            and self._client.get_transport().is_active()
        )

    # --- Lifecycle ---
    def build(self) -> None:
        """No build step needed for SSH — connectivity is checked on start()."""

    def destroy(self) -> None:
        """No remote resources to destroy — just close the connection."""
        self.stop()

    # --- Execution ---
    def execute(
        self,
        cmd: list[str] | str,
        workdir: str | None = None,
        env: dict[str, str] | None = None,
    ) -> RunnerResult:
        if self._client is None:
            raise RuntimeError(
                "SshRunner is not started. Call start() or use as context manager."
            )

        if isinstance(cmd, list):
            import shlex

            cmd = shlex.join(cmd)

        if workdir:
            cmd = f"cd {shlex.quote(workdir)} && {cmd}"

        if env:
            env_prefix = " ".join(f"{k}={shlex.quote(v)}" for k, v in env.items())
            cmd = f"{env_prefix} {cmd}"

        _, stdout, stderr = self._client.exec_command(cmd)
        exit_code = stdout.channel.recv_exit_status()

        return RunnerResult(
            stdout=stdout.read().decode("utf-8", errors="replace"),
            stderr=stderr.read().decode("utf-8", errors="replace"),
            exit_code=exit_code,
        )

    def start(self) -> None:
        import paramiko

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=self.host,
            port=self.port,
            username=self.user,
            key_filename=self.key_path,
            password=self.password,
        )
        self._client = client

    def stop(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None
