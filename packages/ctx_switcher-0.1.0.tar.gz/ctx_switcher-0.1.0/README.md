# ctx

Save and restore full terminal context for developers juggling multiple repos and tasks.

## What it does

One command to snapshot your entire working state — git branch, open files, env vars, running processes, tmux sessions, and notes — and restore it later.

```bash
ctx save "frontend-v2"              # Save current context
ctx save "frontend-v2" --note "WIP" # Save with a note
ctx load "frontend-v2"              # Restore it
ctx list                            # See all saved contexts
```

## Installation

```bash
pip install ctx-switcher
```

## Commands

| Command | Description |
|---------|-------------|
| `ctx save <name>` | Save current context |
| `ctx load <name>` | Restore a saved context |
| `ctx list` | List all saved contexts |
| `ctx list --project <name>` | Filter by project |
| `ctx show <name>` | Show context details |
| `ctx delete <name>` | Delete a context |
| `ctx diff <a> <b>` | Compare two contexts |
| `ctx export <name>` | Export as JSON |
| `ctx import <file>` | Import from JSON |
| `ctx auto` | Auto-load context for cwd |
| `ctx notes <name> <text>` | Add a note |
| `ctx path <name>` | Show saved directory |

## What gets captured

- **Git state** — branch, commit, modified files, stash count
- **Working directory** — where you were
- **Environment variables** — configurable via `.ctx-config.yaml`
- **Running processes** — filtered to your user
- **Tmux session** — if running
- **Timestamps & notes**

## Restoring

`ctx load` prints instructions to restore your state. To export env vars to your shell:

```bash
eval "$(ctx load frontend-v2 --env)"
```

## Configuration

Create `.ctx-config.yaml` in your project or home directory:

```yaml
env_vars:
  - NODE_ENV
  - DATABASE_URL
  - PORT
  - API_KEY
```

## Storage

Contexts are stored at `~/.ctx-store/<hash>/<name>.json`. Safe to delete anytime.

## License

MIT
