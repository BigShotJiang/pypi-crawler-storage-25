"""Tests for storage module."""
import json
import os
import pytest
import tempfile
from unittest.mock import patch

from ctx_switcher import storage


@pytest.fixture
def store_dir(tmp_path):
    with patch.object(storage, "STORE_DIR", str(tmp_path / ".ctx-store")):
        yield str(tmp_path / ".ctx-store")


def _ctx(name="test", project="myapp", **kwargs):
    ctx = {
        "name": name,
        "project": project,
        "created_at": "2026-04-07T00:00:00Z",
        "updated_at": "2026-04-07T00:00:00Z",
        "notes": [],
        "cwd": "/tmp/myapp",
        "git": {"branch": "main", "commit": "abc123", "status": "", "stash_count": 0},
        "env": {},
        "processes": [],
        "tmux": None,
    }
    ctx.update(kwargs)
    return ctx


def test_save_and_load(store_dir):
    ctx = _ctx()
    storage.save(ctx)
    loaded = storage.load("myapp", "test")
    assert loaded["name"] == "test"
    assert loaded["project"] == "myapp"


def test_load_missing(store_dir):
    assert storage.load("myapp", "nonexistent") is None


def test_delete(store_dir):
    ctx = _ctx()
    storage.save(ctx)
    assert storage.delete("myapp", "test") is True
    assert storage.load("myapp", "test") is None


def test_delete_missing(store_dir):
    assert storage.delete("myapp", "nonexistent") is False


def test_list_all(store_dir):
    storage.save(_ctx("ctx1", "proj1"))
    storage.save(_ctx("ctx2", "proj2"))
    results = storage.list_all()
    assert len(results) == 2


def test_list_all_filter_project(store_dir):
    storage.save(_ctx("ctx1", "proj1"))
    storage.save(_ctx("ctx2", "proj2"))
    results = storage.list_all(project="proj1")
    assert len(results) == 1
    assert results[0]["name"] == "ctx1"


def test_find_by_name(store_dir):
    storage.save(_ctx("myctx", "proj1"))
    found = storage.find_by_name("myctx")
    assert found is not None
    assert found["name"] == "myctx"


def test_find_by_name_missing(store_dir):
    assert storage.find_by_name("nope") is None


def test_find_by_cwd(store_dir):
    storage.save(_ctx("ctx1", "proj1", cwd="/tmp/proj1"))
    storage.save(_ctx("ctx2", "proj1", cwd="/tmp/proj2"))
    found = storage.find_by_cwd("/tmp/proj1")
    assert found["name"] == "ctx1"


def test_find_by_cwd_missing(store_dir):
    assert storage.find_by_cwd("/nonexistent") is None


def test_save_overwrites(store_dir):
    storage.save(_ctx("test", "myapp", notes=["first"]))
    storage.save(_ctx("test", "myapp", notes=["second"]))
    loaded = storage.load("myapp", "test")
    assert loaded["notes"] == ["second"]


def test_list_empty(store_dir):
    assert storage.list_all() == []
