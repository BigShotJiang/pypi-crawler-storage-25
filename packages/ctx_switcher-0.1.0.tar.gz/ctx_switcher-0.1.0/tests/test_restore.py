"""Tests for restore module."""
import pytest
from ctx_switcher import restore


def _ctx(**kwargs):
    ctx = {
        "name": "test",
        "project": "myapp",
        "cwd": "/tmp/myapp",
        "git": {"branch": "feat/x", "commit": "abc", "status": "", "stash_count": 0},
        "env": {"PORT": "3000", "NODE_ENV": "dev"},
        "processes": [{"pid": 123, "command": "npm start", "started": "10:00"}],
        "tmux": None,
        "notes": [],
    }
    ctx.update(kwargs)
    return ctx


def test_format_output_basic():
    ctx = _ctx()
    out = restore.format_restore_output(ctx, None)
    assert "cd /tmp/myapp" in out
    assert "git checkout feat/x" in out
    assert "PORT" in out


def test_format_output_with_notes():
    ctx = _ctx(notes=["fix login", "needs review"])
    out = restore.format_restore_output(ctx, None)
    assert "fix login" in out
    assert "needs review" in out


def test_format_output_with_modified_files():
    ctx = _ctx(git={"branch": "main", "commit": "a", "status": "M  src/api.py\nA  new.py", "stash_count": 0})
    out = restore.format_restore_output(ctx, None)
    assert "src/api.py" in out
    assert "new.py" in out


def test_format_output_with_processes():
    ctx = _ctx(processes=[{"pid": 123, "command": "npm start", "started": "10:00"}])
    out = restore.format_restore_output(ctx, None)
    assert "npm start" in out


def test_format_output_with_tmux():
    ctx = _ctx(tmux={"session": "myapp", "windows": ["editor", "server"]})
    out = restore.format_restore_output(ctx, None)
    assert "myapp" in out
    assert "editor" in out


def test_env_only():
    ctx = _ctx()
    out = restore.format_restore_output(ctx, None)
    assert "eval" in out
