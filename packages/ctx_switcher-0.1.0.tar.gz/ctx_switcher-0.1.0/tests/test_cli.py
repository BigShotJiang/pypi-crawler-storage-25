"""Tests for CLI commands."""
import json
import pytest
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

from ctx_switcher.cli import main


@pytest.fixture
def runner():
    return CliRunner()


def _ctx(name="test", project="myapp"):
    return {
        "name": name, "project": project,
        "created_at": "2026-04-07T00:00:00Z",
        "updated_at": "2026-04-07T00:00:00Z",
        "notes": [], "cwd": "/tmp/myapp",
        "git": {"branch": "main", "commit": "abc", "status": "", "stash_count": 0},
        "env": {"PORT": "3000"}, "processes": [], "tmux": None,
    }


def test_version(runner):
    r = runner.invoke(main, ["--version"])
    assert "0.1.0" in r.output


def test_save(runner):
    with patch("ctx_switcher.cli.snapshot") as mock_snap:
        mock_snap.capture.return_value = _ctx()
        r = runner.invoke(main, ["save", "test"])
        assert r.exit_code == 0
        assert "Saved" in r.output


def test_save_with_note(runner):
    with patch("ctx_switcher.cli.snapshot") as mock_snap:
        ctx = _ctx()
        ctx["notes"] = ["hello"]
        mock_snap.capture.return_value = ctx
        r = runner.invoke(main, ["save", "test", "--note", "hello"])
        assert r.exit_code == 0


def test_load(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = _ctx()
        r = runner.invoke(main, ["load", "test"])
        assert r.exit_code == 0
        assert "cd /tmp/myapp" in r.output


def test_load_not_found(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = None
        r = runner.invoke(main, ["load", "nope"])
        assert r.exit_code == 1


def test_load_env_only(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = _ctx()
        r = runner.invoke(main, ["load", "test", "--env"])
        assert r.exit_code == 0
        assert "export PORT" in r.output


def test_list_empty(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.list_all.return_value = []
        r = runner.invoke(main, ["list"])
        assert r.exit_code == 0


def test_list_with_items(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.list_all.return_value = [_ctx()]
        r = runner.invoke(main, ["list"])
        assert r.exit_code == 0
        assert "test" in r.output


def test_show(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = _ctx()
        r = runner.invoke(main, ["show", "test"])
        assert r.exit_code == 0
        assert "test" in r.output


def test_show_not_found(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = None
        r = runner.invoke(main, ["show", "nope"])
        assert r.exit_code == 1


def test_delete(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = _ctx()
        mock_storage.delete.return_value = True
        r = runner.invoke(main, ["delete", "test"])
        assert r.exit_code == 0
        assert "Deleted" in r.output


def test_delete_not_found(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = None
        r = runner.invoke(main, ["delete", "nope"])
        assert r.exit_code == 1


def test_diff(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.side_effect = [_ctx("a"), _ctx("b")]
        r = runner.invoke(main, ["diff", "a", "b"])
        assert r.exit_code == 0


def test_diff_not_found(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = None
        r = runner.invoke(main, ["diff", "a", "b"])
        assert r.exit_code == 1


def test_export(runner):
    with patch("ctx_switcher.cli.export_import") as mock_ei, \
         patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = _ctx()
        mock_ei.export_context.return_value = '{"name": "test"}'
        r = runner.invoke(main, ["export", "test"])
        assert r.exit_code == 0


def test_export_not_found(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = None
        r = runner.invoke(main, ["export", "nope"])
        assert r.exit_code == 1


def test_import_cmd(runner, tmp_path):
    f = tmp_path / "ctx.json"
    f.write_text(json.dumps(_ctx()))
    with patch("ctx_switcher.cli.export_import") as mock_ei:
        mock_ei.import_context.return_value = _ctx()
        r = runner.invoke(main, ["import", str(f)])
        assert r.exit_code == 0


def test_auto(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_cwd.return_value = _ctx()
        r = runner.invoke(main, ["auto"])
        assert r.exit_code == 0


def test_auto_not_found(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_cwd.return_value = None
        r = runner.invoke(main, ["auto"])
        assert r.exit_code == 1


def test_notes(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = _ctx()
        r = runner.invoke(main, ["notes", "test", "new note"])
        assert r.exit_code == 0
        assert "Added note" in r.output


def test_notes_not_found(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = None
        r = runner.invoke(main, ["notes", "nope", "x"])
        assert r.exit_code == 1


def test_path(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = _ctx()
        r = runner.invoke(main, ["path", "test"])
        assert r.exit_code == 0
        assert "/tmp/myapp" in r.output


def test_path_not_found(runner):
    with patch("ctx_switcher.cli.storage") as mock_storage:
        mock_storage.find_by_name.return_value = None
        r = runner.invoke(main, ["path", "nope"])
        assert r.exit_code == 1
