"""Tests for git_state module."""
import pytest
from unittest.mock import patch, MagicMock

from ctx_switcher import git_state


def test_get_branch_success():
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="feat/pagination\n")
        assert git_state.get_branch("/fake") == "feat/pagination"


def test_get_branch_failure():
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=128, stdout="")
        assert git_state.get_branch("/fake") is None


def test_get_branch_no_git():
    with patch("subprocess.run", side_effect=FileNotFoundError):
        assert git_state.get_branch() is None


def test_get_commit_success():
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="a1b2c3d\n")
        assert git_state.get_commit("/fake") == "a1b2c3d"


def test_get_commit_failure():
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=128, stdout="")
        assert git_state.get_commit("/fake") is None


def test_get_status_success():
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="M src/api.py\n?? new.txt\n")
        assert git_state.get_status("/fake") == "M src/api.py\n?? new.txt"


def test_get_status_empty():
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="")
        assert git_state.get_status("/fake") == ""


def test_get_stash_count():
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="stash@{0}: WIP\nstash@{1}: WIP\n")
        assert git_state.get_stash_count("/fake") == 2


def test_get_stash_count_empty():
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="")
        assert git_state.get_stash_count("/fake") == 0


def test_get_project_name():
    assert git_state.get_project_name("/Users/dev/projects/myapp") == "myapp"


def test_get_project_name_trailing_slash():
    assert git_state.get_project_name("/Users/dev/projects/myapp/") == "myapp"


def test_capture():
    with patch.object(git_state, "get_branch", return_value="main"), \
         patch.object(git_state, "get_commit", return_value="abc123"), \
         patch.object(git_state, "get_status", return_value="M f.py"), \
         patch.object(git_state, "get_stash_count", return_value=1):
        result = git_state.capture("/fake")
        assert result["branch"] == "main"
        assert result["commit"] == "abc123"
        assert result["status"] == "M f.py"
        assert result["stash_count"] == 1
