"""Tests for snapshot module."""
import pytest
from unittest.mock import patch, MagicMock

from ctx_switcher import snapshot


def _mock_ctx():
    return {
        "name": "test",
        "project": "myapp",
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
        "notes": [],
        "cwd": "/tmp/myapp",
        "git": {"branch": "main", "commit": "abc", "status": "", "stash_count": 0},
        "env": {},
        "processes": [],
        "tmux": None,
    }


def test_capture_new():
    with patch.object(snapshot.git_state, "capture", return_value={"branch": "main", "commit": "abc", "status": "", "stash_count": 0}), \
         patch.object(snapshot.git_state, "get_project_name", return_value="myapp"), \
         patch.object(snapshot.env_state, "capture", return_value={}), \
         patch.object(snapshot.process_state, "capture", return_value=[]), \
         patch.object(snapshot.tmux_state, "capture", return_value=None), \
         patch.object(snapshot.storage, "load", return_value=None), \
         patch.object(snapshot.storage, "save") as mock_save:
        ctx = snapshot.capture("myctx", cwd="/tmp/myapp")
        assert ctx["name"] == "myctx"
        mock_save.assert_called_once()


def test_capture_with_note():
    with patch.object(snapshot.git_state, "capture", return_value={"branch": "main", "commit": "abc", "status": "", "stash_count": 0}), \
         patch.object(snapshot.git_state, "get_project_name", return_value="myapp"), \
         patch.object(snapshot.env_state, "capture", return_value={}), \
         patch.object(snapshot.process_state, "capture", return_value=[]), \
         patch.object(snapshot.tmux_state, "capture", return_value=None), \
         patch.object(snapshot.storage, "load", return_value=None), \
         patch.object(snapshot.storage, "save"):
        ctx = snapshot.capture("myctx", note="hello", cwd="/tmp")
        assert ctx["notes"] == ["hello"]


def test_capture_preserves_existing_notes():
    existing = _mock_ctx()
    existing["notes"] = ["old note"]
    with patch.object(snapshot.git_state, "capture", return_value={"branch": "main", "commit": "abc", "status": "", "stash_count": 0}), \
         patch.object(snapshot.git_state, "get_project_name", return_value="myapp"), \
         patch.object(snapshot.env_state, "capture", return_value={}), \
         patch.object(snapshot.process_state, "capture", return_value=[]), \
         patch.object(snapshot.tmux_state, "capture", return_value=None), \
         patch.object(snapshot.storage, "load", return_value=existing), \
         patch.object(snapshot.storage, "save"):
        ctx = snapshot.capture("test", note="new note", cwd="/tmp")
        assert "old note" in ctx["notes"]
        assert "new note" in ctx["notes"]


def test_capture_updates_existing_no_note():
    existing = _mock_ctx()
    existing["notes"] = ["keep me"]
    with patch.object(snapshot.git_state, "capture", return_value={"branch": "main", "commit": "abc", "status": "", "stash_count": 0}), \
         patch.object(snapshot.git_state, "get_project_name", return_value="myapp"), \
         patch.object(snapshot.env_state, "capture", return_value={}), \
         patch.object(snapshot.process_state, "capture", return_value=[]), \
         patch.object(snapshot.tmux_state, "capture", return_value=None), \
         patch.object(snapshot.storage, "load", return_value=existing), \
         patch.object(snapshot.storage, "save"):
        ctx = snapshot.capture("test", cwd="/tmp")
        assert ctx["notes"] == ["keep me"]
