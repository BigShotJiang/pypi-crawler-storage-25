"""Tests for diff module."""
from ctx_switcher import diff as diff_mod


def _ctx(**kwargs):
    ctx = {
        "name": "test", "project": "myapp", "cwd": "/tmp/myapp",
        "git": {"branch": "main", "commit": "abc", "status": "", "stash_count": 0},
        "env": {}, "processes": [], "tmux": None, "notes": [],
    }
    ctx.update(kwargs)
    return ctx


def test_no_diff():
    ctx = _ctx()
    assert diff_mod.diff(ctx, ctx) == []


def test_branch_diff():
    c1 = _ctx(git={"branch": "main", "commit": "a", "status": "", "stash_count": 0})
    c2 = _ctx(git={"branch": "dev", "commit": "b", "status": "", "stash_count": 0})
    diffs = diff_mod.diff(c1, c2)
    assert any(d[1] == "branch" for d in diffs)


def test_env_diff():
    c1 = _ctx(env={"PORT": "3000"})
    c2 = _ctx(env={"PORT": "4000"})
    diffs = diff_mod.diff(c1, c2)
    assert any(d[1] == "PORT" for d in diffs)


def test_env_added():
    c1 = _ctx(env={})
    c2 = _ctx(env={"NEW": "val"})
    diffs = diff_mod.diff(c1, c2)
    assert any("NEW" in str(d) for d in diffs)


def test_cwd_diff():
    c1 = _ctx(cwd="/a")
    c2 = _ctx(cwd="/b")
    diffs = diff_mod.diff(c1, c2)
    assert any(d[1] == "cwd" for d in diffs)


def test_status_diff():
    c1 = _ctx(git={"branch": "main", "commit": "a", "status": "M f.py", "stash_count": 0})
    c2 = _ctx(git={"branch": "main", "commit": "a", "status": "M f.py\nM g.py", "stash_count": 0})
    diffs = diff_mod.diff(c1, c2)
    assert any(d[1] == "added" for d in diffs)


def test_format_diff_no_diffs():
    assert "No differences" in diff_mod.format_diff("a", "b", [])


def test_format_diff_with_diffs():
    diffs = [("git", "branch", "main", "dev")]
    out = diff_mod.format_diff("a", "b", diffs)
    assert "main" in out and "dev" in out
