"""Tests for export_import module."""
import json
import os
import pytest
from unittest.mock import patch

from ctx_switcher import export_import


def test_export_not_found():
    with patch.object(export_import.storage, "load", return_value=None):
        assert export_import.export_context("p", "x") is None


def test_export_to_stdout():
    ctx = {"name": "x", "project": "p"}
    with patch.object(export_import.storage, "load", return_value=ctx):
        data = export_import.export_context("p", "x")
        assert json.loads(data)["name"] == "x"


def test_export_to_file(tmp_path):
    ctx = {"name": "x", "project": "p"}
    out = str(tmp_path / "out.json")
    with patch.object(export_import.storage, "load", return_value=ctx):
        export_import.export_context("p", "x", out)
        with open(out) as f:
            assert json.load(f)["name"] == "x"


def test_import(tmp_path):
    ctx = {"name": "imp", "project": "p", "git": {}, "env": {}, "processes": [], "notes": []}
    f = tmp_path / "ctx.json"
    f.write_text(json.dumps(ctx))
    with patch.object(export_import.storage, "save") as mock_save:
        result = export_import.import_context(str(f))
        assert result["name"] == "imp"
        mock_save.assert_called_once()
