"""Tests for env_state module."""
import pytest
import os
from unittest.mock import patch

from ctx_switcher import env_state


def test_capture_tracked_vars():
    env = {"NODE_ENV": "dev", "PORT": "3000", "OTHER": "x"}
    with patch.dict(os.environ, env, clear=True):
        result = env_state.capture(["NODE_ENV", "PORT"])
        assert result == {"NODE_ENV": "dev", "PORT": "3000"}


def test_capture_missing_vars():
    env = {"NODE_ENV": "dev"}
    with patch.dict(os.environ, env, clear=True):
        result = env_state.capture(["NODE_ENV", "MISSING"])
        assert result == {"NODE_ENV": "dev"}


def test_capture_defaults():
    env = {"NODE_ENV": "dev", "PYTHONPATH": "/src"}
    with patch.dict(os.environ, env, clear=True):
        result = env_state.capture()
        assert "NODE_ENV" in result
        assert "PYTHONPATH" in result


def test_capture_no_match():
    with patch.dict(os.environ, {}, clear=True):
        result = env_state.capture(["NONEXISTENT"])
        assert result == {}


def test_capture_empty_list():
    with patch.dict(os.environ, {"X": "1"}, clear=True):
        result = env_state.capture([])
        assert result == {}
