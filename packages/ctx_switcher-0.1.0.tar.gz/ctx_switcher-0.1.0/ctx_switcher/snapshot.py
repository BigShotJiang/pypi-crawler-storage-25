"""Snapshot - capture full context."""
import os
from datetime import datetime, timezone

from . import git_state, env_state, process_state, tmux_state, config, storage


def capture(name, note=None, cwd=None):
    _cwd = cwd or os.getcwd()
    cfg = config.load_config()

    ctx = {
        "name": name,
        "project": git_state.get_project_name(_cwd),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "notes": [note] if note else [],
        "cwd": _cwd,
        "git": git_state.capture(_cwd),
        "env": env_state.capture(cfg.get("env_vars")),
        "processes": process_state.capture(),
        "tmux": tmux_state.capture(),
    }

    # If context already exists, preserve existing notes and created_at
    existing = storage.load(ctx["project"], name)
    if existing:
        ctx["created_at"] = existing["created_at"]
        if note:
            ctx["notes"] = existing.get("notes", []) + [note]
        else:
            ctx["notes"] = existing.get("notes", [])

    storage.save(ctx)
    return ctx
