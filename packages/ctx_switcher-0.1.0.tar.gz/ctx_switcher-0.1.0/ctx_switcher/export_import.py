"""Export/import contexts as JSON."""
import json
import os

from . import storage


def export_context(project, name, output_path=None):
    ctx = storage.load(project, name)
    if not ctx:
        return None
    data = json.dumps(ctx, indent=2)
    if output_path:
        with open(output_path, "w") as f:
            f.write(data)
    return data


def import_context(file_path):
    with open(file_path) as f:
        ctx = json.load(f)
    storage.save(ctx)
    return ctx
