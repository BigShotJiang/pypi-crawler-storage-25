"""Restore a saved context."""
import subprocess
import os


def restore(ctx, env_only=False):
    """Restore context. Returns list of (success, message) tuples."""
    results = []

    if env_only:
        lines = []
        for k, v in ctx.get("env", {}).items():
            lines.append(f'export {k}="{v}"')
        return "\n".join(lines)

    # Print cd command
    cwd = ctx.get("cwd")
    if cwd:
        results.append(("cd", f"cd {cwd}"))

    # Git checkout
    branch = ctx.get("git", {}).get("branch")
    if branch:
        results.append(("git", f"git checkout {branch}"))

    # Env vars
    env_lines = []
    for k, v in ctx.get("env", {}).items():
        env_lines.append(f'export {k}="{v}"')
    if env_lines:
        results.append(("env", "\n".join(env_lines)))

    return results


def format_restore_output(ctx, restore_results):
    """Format restore output for display."""
    lines = []

    cwd = ctx.get("cwd")
    if cwd:
        lines.append(f"✓ Switch to: cd {cwd}")

    branch = ctx.get("git", {}).get("branch")
    if branch:
        lines.append(f"✓ Checkout: git checkout {branch}")

    env_vars = ctx.get("env", {})
    if env_vars:
        lines.append(f"✓ Env vars ({len(env_vars)}): {', '.join(env_vars.keys())}")

    notes = ctx.get("notes", [])
    if notes:
        lines.append("")
        lines.append("📝 Notes:")
        for n in notes:
            lines.append(f"  • {n}")

    status = ctx.get("git", {}).get("status", "")
    if status:
        lines.append("")
        lines.append("📝 Open files:")
        for line in status.split("\n"):
            if line.strip():
                status_char = line[:2]
                filepath = line[3:].strip()
                mod_type = "modified" if "M" in status_char else "added" if "A" in status_char else "deleted" if "D" in status_char else "changed"
                lines.append(f"  • {filepath} ({mod_type})")

    procs = ctx.get("processes", [])
    if procs:
        lines.append("")
        lines.append("🔄 Running processes:")
        for p in procs[:5]:
            lines.append(f"  • {p['command']} (pid {p['pid']})")

    tmux = ctx.get("tmux")
    if tmux:
        lines.append("")
        lines.append(f"🖥️  Tmux session: {tmux['session']} (windows: {', '.join(tmux.get('windows', []))})")

    lines.append("")
    lines.append('💡 Tip: Run eval "$(ctx load {} --env)" to export env vars in your shell'.format(ctx["name"]))

    return "\n".join(lines)
