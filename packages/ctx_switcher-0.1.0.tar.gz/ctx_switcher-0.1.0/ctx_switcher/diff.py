"""Context diff."""
from rich.console import Console
from rich.table import Table


def diff(ctx1, ctx2):
    """Compare two contexts. Returns a list of differences."""
    diffs = []

    # Basic fields
    for field in ["cwd", "project"]:
        if ctx1.get(field) != ctx2.get(field):
            diffs.append(("field", field, ctx1.get(field), ctx2.get(field)))

    # Git
    g1, g2 = ctx1.get("git", {}), ctx2.get("git", {})
    for k in ["branch", "commit", "stash_count"]:
        if g1.get(k) != g2.get(k):
            diffs.append(("git", k, g1.get(k), g2.get(k)))

    # Status diff
    s1 = set(g1.get("status", "").split("\n")) if g1.get("status") else set()
    s2 = set(g2.get("status", "").split("\n")) if g2.get("status") else set()
    added = s2 - s1
    removed = s1 - s2
    if added:
        diffs.append(("files", "added", None, "\n".join(sorted(added))))
    if removed:
        diffs.append(("files", "removed", "\n".join(sorted(removed)), None))

    # Env
    e1, e2 = ctx1.get("env", {}), ctx2.get("env", {})
    all_keys = set(e1) | set(e2)
    for k in sorted(all_keys):
        if e1.get(k) != e2.get(k):
            diffs.append(("env", k, e1.get(k), e2.get(k)))

    return diffs


def format_diff(name1, name2, diffs):
    if not diffs:
        return "No differences found."

    lines = [f"Comparing [bold]{name1}[/bold] vs [bold]{name2}[/bold]\n"]
    for category, key, old, new in diffs:
        if category == "field":
            lines.append(f"  {key}: {old or '(none)'} → {new or '(none)'}")
        elif category == "git":
            lines.append(f"  git.{key}: {old or '(none)'} → {new or '(none)'}")
        elif category == "files":
            direction = "added" if old is None else "removed"
            content = new if old is None else old
            lines.append(f"  Files {direction}: {content}")
        elif category == "env":
            lines.append(f"  env.{key}: {old or '(unset)'} → {new or '(unset)'}")

    return "\n".join(lines)
