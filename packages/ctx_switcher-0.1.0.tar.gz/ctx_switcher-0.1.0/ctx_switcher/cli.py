"""CLI entry point."""
import json
import os
import sys

import click
from rich.console import Console
from rich.table import Table

from . import snapshot, storage, restore, diff as diff_mod, export_import
from .git_state import get_project_name

console = Console()


def _get_project(ctx_name=None):
    """Get project name, trying to find existing context first."""
    if ctx_name:
        existing = storage.find_by_name(ctx_name)
        if existing:
            return existing["project"]
    return get_project_name()


@click.group()
@click.version_option("0.1.0", prog_name="ctx")
def main():
    """ctx — Save and restore terminal context."""
    pass


@main.command()
@click.argument("name")
@click.option("--note", "-n", help="Add a note to the context")
def save(name, note):
    """Save current context with a name."""
    ctx = snapshot.capture(name, note=note)
    console.print(f"[green]✓[/green] Saved context: [bold]{name}[/bold]")
    console.print(f"  Project: {ctx['project']}")
    console.print(f"  Branch: {ctx['git']['branch']}")
    if ctx['notes']:
        console.print(f"  Notes: {', '.join(ctx['notes'])}")


@main.command()
@click.argument("name")
@click.option("--env", "env_only", is_flag=True, help="Output env vars as export commands")
def load(name, env_only):
    """Restore a saved context."""
    ctx = storage.find_by_name(name)
    if not ctx:
        console.print(f"[red]✗[/red] Context '{name}' not found")
        sys.exit(1)

    if env_only:
        env_vars = ctx.get("env", {})
        for k, v in env_vars.items():
            print(f'export {k}="{v}"')
        return

    output = restore.format_restore_output(ctx, None)
    console.print(output)


@main.command("list")
@click.option("--project", "-p", help="Filter by project name")
def list_cmd(project):
    """List all saved contexts."""
    contexts = storage.list_all(project=project)
    if not contexts:
        console.print("[dim]No saved contexts[/dim]")
        return

    cwd = os.getcwd()
    current_project = get_project_name()

    table = Table(title="Saved Contexts", show_header=True, header_style="bold")
    table.add_column("Name")
    table.add_column("Project")
    table.add_column("Branch")
    table.add_column("Updated")

    for ctx in sorted(contexts, key=lambda c: c.get("updated_at", ""), reverse=True):
        branch = ctx.get("git", {}).get("branch", "?")
        updated = ctx.get("updated_at", "")
        marker = " ●" if ctx.get("project") == current_project else ""
        table.add_row(ctx["name"], ctx["project"], branch or "?", updated + marker)

    console.print(table)
    console.print("[dim]  ● = current project[/dim]")


@main.command()
@click.argument("name")
def show(name):
    """Show details of a saved context."""
    ctx = storage.find_by_name(name)
    if not ctx:
        console.print(f"[red]✗[/red] Context '{name}' not found")
        sys.exit(1)

    console.print(f"[bold]{ctx['name']}[/bold] ({ctx['project']})")
    console.print(f"  Created: {ctx.get('created_at', '?')}")
    console.print(f"  Updated: {ctx.get('updated_at', '?')}")
    console.print(f"  Path: {ctx.get('cwd', '?')}")
    console.print(f"  Branch: {ctx.get('git', {}).get('branch', '?')}")
    console.print(f"  Commit: {ctx.get('git', {}).get('commit', '?')}")

    notes = ctx.get("notes", [])
    if notes:
        console.print("\n  Notes:")
        for n in notes:
            console.print(f"    • {n}")

    status = ctx.get("git", {}).get("status", "")
    if status:
        console.print("\n  Modified files:")
        for line in status.split("\n"):
            if line.strip():
                console.print(f"    {line}")

    env_vars = ctx.get("env", {})
    if env_vars:
        console.print("\n  Environment:")
        for k, v in env_vars.items():
            console.print(f"    {k}={v}")

    procs = ctx.get("processes", [])
    if procs:
        console.print("\n  Processes:")
        for p in procs[:10]:
            console.print(f"    {p['command']} (pid {p['pid']})")

    tmux = ctx.get("tmux")
    if tmux:
        console.print(f"\n  Tmux: {tmux['session']} ({', '.join(tmux.get('windows', []))})")


@main.command()
@click.argument("name")
def delete(name):
    """Delete a saved context."""
    ctx = storage.find_by_name(name)
    if not ctx:
        console.print(f"[red]✗[/red] Context '{name}' not found")
        sys.exit(1)
    storage.delete(ctx["project"], name)
    console.print(f"[green]✓[/green] Deleted context: {name}")


@main.command()
@click.argument("name1")
@click.argument("name2")
def diff(name1, name2):
    """Compare two contexts."""
    ctx1 = storage.find_by_name(name1)
    ctx2 = storage.find_by_name(name2)
    if not ctx1:
        console.print(f"[red]✗[/red] Context '{name1}' not found")
        sys.exit(1)
    if not ctx2:
        console.print(f"[red]✗[/red] Context '{name2}' not found")
        sys.exit(1)

    diffs = diff_mod.diff(ctx1, ctx2)
    output = diff_mod.format_diff(name1, name2, diffs)
    console.print(output)


@main.command()
@click.argument("name")
@click.option("--output", "-o", help="Output file path")
def export(name, output):
    """Export a context as shareable JSON."""
    ctx = storage.find_by_name(name)
    if not ctx:
        console.print(f"[red]✗[/red] Context '{name}' not found")
        sys.exit(1)
    data = export_import.export_context(ctx["project"], name, output)
    if output:
        console.print(f"[green]✓[/green] Exported to {output}")
    else:
        print(data)


@main.command()
@click.argument("file", type=click.Path(exists=True))
def import_ctx(file):
    """Import a context from JSON file."""
    ctx = export_import.import_context(file)
    console.print(f"[green]✓[/green] Imported context: {ctx['name']} ({ctx['project']})")


@main.command()
def auto():
    """Auto-detect project from cwd and load matching context."""
    cwd = os.getcwd()
    ctx = storage.find_by_cwd(cwd)
    if not ctx:
        console.print(f"[dim]No matching context for {cwd}[/dim]")
        sys.exit(1)
    output = restore.format_restore_output(ctx, None)
    console.print(output)


@main.command()
@click.argument("name")
@click.argument("note")
def notes(name, note):
    """Add a note to a context."""
    ctx = storage.find_by_name(name)
    if not ctx:
        console.print(f"[red]✗[/red] Context '{name}' not found")
        sys.exit(1)
    ctx.setdefault("notes", []).append(note)
    from datetime import datetime, timezone
    ctx["updated_at"] = datetime.now(timezone.utc).isoformat()
    storage.save(ctx)
    console.print(f"[green]✓[/green] Added note to {name}")


@main.command()
@click.argument("name")
def path(name):
    """Show which directory a context was saved from."""
    ctx = storage.find_by_name(name)
    if not ctx:
        console.print(f"[red]✗[/red] Context '{name}' not found")
        sys.exit(1)
    print(ctx.get("cwd", "unknown"))


# Rename import command to avoid clash with Python keyword
main.add_command(import_ctx, "import")


if __name__ == "__main__":
    main()
