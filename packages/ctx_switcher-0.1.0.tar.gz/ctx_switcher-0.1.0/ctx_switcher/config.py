"""Config file handling."""
import os
import yaml


DEFAULT_CONFIG = {
    "env_vars": [
        "NODE_ENV", "DATABASE_URL", "PORT", "API_KEY",
        "VIRTUAL_ENV", "CONDA_DEFAULT_ENV", "PYTHONPATH",
    ],
}

CONFIG_PATHS = [
    ".ctx-config.yaml",
    os.path.expanduser("~/.ctx-config.yaml"),
]


def load_config():
    for p in CONFIG_PATHS:
        if os.path.exists(p):
            with open(p) as f:
                data = yaml.safe_load(f) or {}
                return {**DEFAULT_CONFIG, **data}
    return dict(DEFAULT_CONFIG)
