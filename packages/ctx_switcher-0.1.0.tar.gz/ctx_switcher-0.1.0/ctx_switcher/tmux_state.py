"""Tmux session capture."""
import subprocess


def capture():
    try:
        r = subprocess.run(
            ["tmux", "list-sessions", "-F", "#{session_name}:#{session_windows}"],
            capture_output=True, text=True,
        )
        if r.returncode != 0:
            return None
    except FileNotFoundError:
        return None

    # Find the attached session
    try:
        r2 = subprocess.run(
            ["tmux", "display-message", "-p", "#{session_name}"],
            capture_output=True, text=True,
        )
        active = r2.stdout.strip() if r2.returncode == 0 else None
    except FileNotFoundError:
        active = None

    sessions = []
    for line in r.stdout.strip().split("\n"):
        if not line:
            continue
        name, win_count = line.rsplit(":", 1)
        # Get window names
        try:
            wr = subprocess.run(
                ["tmux", "list-windows", "-t", name, "-F", "#{window_name}"],
                capture_output=True, text=True,
            )
            windows = wr.stdout.strip().split("\n") if wr.returncode == 0 else []
        except FileNotFoundError:
            windows = []
        sessions.append({"name": name, "windows": windows, "active": name == active})

    active_session = next((s for s in sessions if s["active"]), sessions[0] if sessions else None)
    if not active_session:
        return None
    return {
        "session": active_session["name"],
        "windows": active_session["windows"],
    }
