"""Context storage - save/load to ~/.ctx-store/."""
import json
import os
import hashlib
from datetime import datetime, timezone


STORE_DIR = os.path.expanduser("~/.ctx-store")


def _project_dir(project):
    h = hashlib.sha256(project.encode()).hexdigest()[:12]
    return os.path.join(STORE_DIR, h)


def _context_path(project, name):
    return os.path.join(_project_dir(project), f"{name}.json")


def save(context):
    d = _project_dir(context["project"])
    os.makedirs(d, exist_ok=True)
    path = _context_path(context["project"], context["name"])
    with open(path, "w") as f:
        json.dump(context, f, indent=2)
    return path


def load(project, name):
    path = _context_path(project, name)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)


def delete(project, name):
    path = _context_path(project, name)
    if os.path.exists(path):
        os.remove(path)
        return True
    return False


def list_all(project=None):
    """List all saved contexts, optionally filtered by project."""
    results = []
    if not os.path.exists(STORE_DIR):
        return results
    for proj_hash in os.listdir(STORE_DIR):
        proj_dir = os.path.join(STORE_DIR, proj_hash)
        if not os.path.isdir(proj_dir):
            continue
        for fname in os.listdir(proj_dir):
            if not fname.endswith(".json"):
                continue
            with open(os.path.join(proj_dir, fname)) as f:
                ctx = json.load(f)
            if project and ctx.get("project") != project:
                continue
            results.append(ctx)
    return results


def find_by_name(name):
    """Find a context by name across all projects."""
    for ctx in list_all():
        if ctx["name"] == name:
            return ctx
    return None


def find_by_cwd(cwd):
    """Find the most recent context for a given working directory."""
    matches = [c for c in list_all() if c.get("cwd") == cwd]
    if not matches:
        return None
    matches.sort(key=lambda c: c.get("updated_at", ""), reverse=True)
    return matches[0]
