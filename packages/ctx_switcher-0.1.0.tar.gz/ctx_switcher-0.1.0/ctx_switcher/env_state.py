"""Environment variable capture."""
import os


DEFAULT_TRACKED = [
    "NODE_ENV", "DATABASE_URL", "PORT", "API_KEY",
    "VIRTUAL_ENV", "CONDA_DEFAULT_ENV", "PYTHONPATH",
    "JAVA_HOME", "GOPATH", "DOCKER_HOST",
]


def capture(tracked_vars=None):
    tracked = tracked_vars or DEFAULT_TRACKED
    return {k: os.environ[k] for k in tracked if k in os.environ}
