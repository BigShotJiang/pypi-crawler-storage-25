"""Running process capture."""
import subprocess
import os


def capture(user_only=True):
    try:
        cmd = ["ps", "aux"]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            return []
    except FileNotFoundError:
        return []

    my_user = os.environ.get("USER", "")
    procs = []
    for line in r.stdout.strip().split("\n")[1:]:
        parts = line.split(None, 10)
        if len(parts) < 11:
            continue
        user, pid, cpu, mem, vsz, rss, tty, stat, started, time, command = parts
        if user_only and my_user and user != my_user:
            continue
        # Skip ps itself and short-lived system processes
        if "ps aux" in command:
            continue
        procs.append({
            "pid": int(pid),
            "command": command,
            "started": started,
        })
    return procs
