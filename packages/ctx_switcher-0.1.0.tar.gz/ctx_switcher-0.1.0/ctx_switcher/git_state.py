"""Git state capture."""
import subprocess
import os


def get_branch(cwd=None):
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, cwd=cwd
        )
        return r.stdout.strip() if r.returncode == 0 else None
    except FileNotFoundError:
        return None


def get_commit(cwd=None):
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, cwd=cwd
        )
        return r.stdout.strip() if r.returncode == 0 else None
    except FileNotFoundError:
        return None


def get_status(cwd=None):
    try:
        r = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, cwd=cwd
        )
        return r.stdout.strip() if r.returncode == 0 else ""
    except FileNotFoundError:
        return ""


def get_stash_count(cwd=None):
    try:
        r = subprocess.run(
            ["git", "stash", "list"],
            capture_output=True, text=True, cwd=cwd
        )
        if r.returncode != 0:
            return 0
        lines = [l for l in r.stdout.strip().split("\n") if l]
        return len(lines)
    except FileNotFoundError:
        return 0


def get_project_name(cwd=None):
    d = cwd or os.getcwd()
    return os.path.basename(d.rstrip("/"))


def capture(cwd=None):
    return {
        "branch": get_branch(cwd),
        "commit": get_commit(cwd),
        "status": get_status(cwd),
        "stash_count": get_stash_count(cwd),
    }
