"""MCP integration tests package."""
