from blux.text_doc import TextDocItem, build_sentence, build_sentence_for_md5, calc_md5


def test_build_sentence_formats_fields() -> None:
    sentence = build_sentence(
        title="标题",
        tags="标签1,标签2",
        desc="描述",
        owner_name="作者",
    )
    assert sentence == "【作者】 标题 (标签1,标签2) 描述"


def test_build_sentence_skips_dash_description() -> None:
    sentence = build_sentence(title="标题", desc="-", owner_name="作者")
    assert sentence == "【作者】 标题"


def test_md5_builder_is_stable() -> None:
    text = build_sentence_for_md5(
        title="标题", tags="标签", desc="描述", owner_name="作者"
    )
    assert text == "【作者】 标题 (标签) 描述"
    assert calc_md5(
        title="标题", tags="标签", desc="描述", owner_name="作者"
    ) == calc_md5(title="标题", tags="标签", desc="描述", owner_name="作者")


def test_text_doc_item_from_doc_builds_sentence_and_hash() -> None:
    item = TextDocItem.from_doc(
        {
            "bvid": "BV1xx411c7mW",
            "title": "标题",
            "tags": "标签",
            "owner": {"name": "作者"},
            "desc": "描述",
        }
    )
    assert item.build_sentence() == "【作者】 标题 (标签) 描述"
    assert len(item.calc_md5_hash()) == 4
