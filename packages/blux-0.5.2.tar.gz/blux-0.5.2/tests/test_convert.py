import json

from pathlib import Path
from unittest.mock import patch

import pytest

from blux.convert import convert_audio, probe_media


def test_probe_media_parses_ffprobe_json(tmp_path) -> None:
    media_path = tmp_path / "sample.m4a"
    media_path.write_bytes(b"fake")
    payload = {
        "format": {
            "format_name": "mov,mp4,m4a,3gp,3g2,mj2",
            "duration": "12.34",
            "size": "4096",
            "bit_rate": "128000",
        },
        "streams": [
            {
                "codec_name": "aac",
                "sample_rate": "44100",
                "channels": 2,
            }
        ],
    }

    with patch("blux.convert.ffmpeg.shutil.which", return_value="/usr/bin/ffprobe"):
        with patch("blux.convert.ffmpeg.subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            mock_run.return_value.stdout = json.dumps(payload)
            mock_run.return_value.stderr = ""
            probe = probe_media(media_path)

    assert probe.codec_name == "aac"
    assert probe.duration_sec == 12.34
    assert probe.sample_rate == 44100


def test_convert_audio_builds_ffmpeg_command(tmp_path) -> None:
    source = tmp_path / "sample.m4a"
    target = tmp_path / "sample.wav"
    source.write_bytes(b"fake")

    def fake_run(command, **kwargs):
        target.write_bytes(b"wav")

        class Result:
            returncode = 0
            stdout = ""
            stderr = ""

        assert command[0] == "/usr/bin/ffmpeg"
        assert "-c:a" in command
        assert "-b:a" in command
        assert str(target) == command[-1]
        return Result()

    with patch("blux.convert.ffmpeg.shutil.which", return_value="/usr/bin/ffmpeg"):
        with patch("blux.convert.ffmpeg.subprocess.run", side_effect=fake_run):
            output = convert_audio(
                source,
                output_path=target,
                format="wav",
                bitrate="24k",
            )

    assert output == target.resolve()
    assert target.read_bytes() == b"wav"


def test_convert_audio_requires_ffmpeg_binary(tmp_path) -> None:
    source = tmp_path / "sample.m4a"
    source.write_bytes(b"fake")

    with patch("blux.convert.ffmpeg.shutil.which", return_value=None):
        with pytest.raises(RuntimeError, match="Install ffmpeg first"):
            convert_audio(source, format="mp3")
