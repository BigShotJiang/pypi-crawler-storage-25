import pytest

from blux.bvs import av_to_bv, bv_to_av


@pytest.mark.parametrize(
    ("aid", "bvid"),
    [
        (100, "BV1xx411c7mW"),
        (10000, "BV1bx411c7ux"),
        (10000000, "BV1Ex411U7PA"),
    ],
)
def test_av_bv_roundtrip_known_values(aid: int, bvid: str) -> None:
    assert av_to_bv(aid) == bvid
    assert bv_to_av(bvid) == aid


def test_bv_to_av_rejects_invalid_prefix() -> None:
    with pytest.raises(ValueError):
        bv_to_av("av1xx411c7mW")


def test_av_to_bv_rejects_invalid_aid_range() -> None:
    with pytest.raises(ValueError):
        av_to_bv(0)
