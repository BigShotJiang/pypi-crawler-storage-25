import requests

from blux.search import (
    BiliSearcher,
    SearchAllResult,
    SearchType,
    SearchTypeResult,
    strip_html_tags,
)


class FakeResponse:
    def __init__(self, payload: dict | None = None):
        self._payload = payload or {}

    def raise_for_status(self) -> None:
        return

    def json(self) -> dict:
        return self._payload


class FakeSession:
    def __init__(self, payloads: dict[str, dict]):
        self.headers = {}
        self.cookies = requests.cookies.RequestsCookieJar()
        self.payloads = payloads

    def get(self, url: str, params=None, timeout=None):
        if url == BiliSearcher.BILIBILI_HOME:
            self.cookies.set("buvid3", "fake-buvid", domain=".bilibili.com")
            return FakeResponse({"code": 0})
        return FakeResponse(self.payloads[url])


def test_strip_html_tags() -> None:
    assert (
        strip_html_tags('<em class="keyword">教父</em> The Godfather')
        == "教父 The Godfather"
    )


def test_search_all_result_parses_video_groups() -> None:
    result = SearchAllResult(
        {
            "code": 0,
            "data": {
                "numResults": 1,
                "numPages": 1,
                "result": [
                    {
                        "result_type": "video",
                        "data": [
                            {
                                "aid": 1,
                                "bvid": "BV1xx411c7mW",
                                "title": '<em class="keyword">测试</em>标题',
                                "author": "作者",
                            }
                        ],
                    }
                ],
            },
        }
    )
    assert result.ok is True
    assert len(result.videos) == 1
    assert result.videos[0].title == "测试标题"


def test_search_type_result_parses_live_groups() -> None:
    result = SearchTypeResult(
        {
            "code": 0,
            "data": {
                "result": {
                    "live_room": [
                        {"roomid": 1, "uid": 2, "title": "直播间", "uname": "主播"}
                    ],
                    "live_user": [{"uid": 2, "uname": "主播", "roomid": 1}],
                }
            },
        },
        SearchType.LIVE.value,
    )
    assert result.ok is True
    assert len(result.live_rooms) == 1
    assert len(result.live_users) == 1
    assert len(result.items) == 2


def test_searcher_uses_session_and_parses_response(monkeypatch) -> None:
    payloads = {
        BiliSearcher.SEARCH_ALL_URL: {
            "code": 0,
            "data": {
                "numResults": 1,
                "numPages": 1,
                "result": [
                    {
                        "result_type": "video",
                        "data": [
                            {
                                "aid": 1,
                                "bvid": "BV1xx411c7mW",
                                "title": "标题",
                                "author": "作者",
                            }
                        ],
                    }
                ],
            },
        }
    }
    searcher = BiliSearcher(session=FakeSession(payloads))
    monkeypatch.setattr(searcher, "_build_signed_params", lambda params: params)
    result = searcher.search_all("测试")
    assert result.ok is True
    assert result.videos[0].bvid == "BV1xx411c7mW"
