import importlib.util
import sys

from pathlib import Path


HOOK_PATH = Path(__file__).resolve().parents[1] / ".githooks" / "scan_secrets.py"
HOOK_SPEC = importlib.util.spec_from_file_location("scan_secrets", HOOK_PATH)
scan_secrets = importlib.util.module_from_spec(HOOK_SPEC)
assert HOOK_SPEC.loader is not None
sys.modules[HOOK_SPEC.name] = scan_secrets
HOOK_SPEC.loader.exec_module(scan_secrets)


def test_scan_content_flags_local_paths_and_secret_env_refs(tmp_path) -> None:
    env_name = "SUDO" + "PASS"
    path_value = "/med" + "ia/data/blux"
    sample = f'cold_root = "{path_value}"\n' f'password = os.getenv("{env_name}")\n'
    violations = scan_secrets.scan_content(
        Path("demo.py"),
        sample,
        tmp_path,
    )

    reasons = [violation.reason for violation in violations]
    assert any("absolute local path" in reason for reason in reasons)
    assert any(
        f"sensitive env var reference '{env_name}'" in reason for reason in reasons
    )


def test_scan_content_allows_project_namespaced_env_vars(tmp_path) -> None:
    violations = scan_secrets.scan_content(
        Path("demo.py"),
        'output_root = os.getenv("BLUX_DOWNLOAD_OUTPUT_ROOT")\n',
        tmp_path,
    )

    assert violations == []


def test_read_worktree_text_skips_deleted_tracked_files(tmp_path) -> None:
    assert scan_secrets._read_worktree_text(tmp_path, Path("missing.py")) is None
