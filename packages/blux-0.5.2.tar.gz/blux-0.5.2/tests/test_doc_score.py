import math

from blux.doc_score import DocScorer, calc_doc_score, calc_doc_score_detail


def make_stats(**kwargs) -> dict:
    return {
        "view": 0,
        "like": 0,
        "coin": 0,
        "favorite": 0,
        "danmaku": 0,
        "reply": 0,
        **kwargs,
    }


def make_doc(stats: dict, pub_to_insert: int) -> dict:
    return {"stats": stats, "pub_to_insert": pub_to_insert}


def test_saturate_half_point_is_stable() -> None:
    alpha = 4.5
    half_saturation = math.exp(alpha) - 1
    assert DocScorer._saturate(half_saturation, alpha) == 0.5


def test_stat_score_is_monotonic() -> None:
    scorer = DocScorer()
    low = scorer._calc_stat_score(make_stats(view=100, like=10))
    high = scorer._calc_stat_score(make_stats(view=10000, like=1000))
    assert high > low


def test_anomaly_factor_penalizes_skewed_stats() -> None:
    scorer = DocScorer()
    balanced = scorer._calc_anomaly_factor(
        make_stats(
            view=100000, like=5000, coin=1000, favorite=1000, danmaku=3000, reply=500
        )
    )
    skewed = scorer._calc_anomaly_factor(
        make_stats(view=1000000, like=10, coin=0, favorite=1)
    )
    assert balanced == 1.0
    assert skewed < balanced


def test_time_factor_decreases_with_age() -> None:
    scorer = DocScorer()
    assert scorer._calc_time_factor(DocScorer.SECONDS_1H) > scorer._calc_time_factor(
        DocScorer.SECONDS_30D
    )


def test_calc_score_prefers_recent_balanced_documents() -> None:
    recent = calc_doc_score(
        make_doc(
            make_stats(
                view=50000, like=2000, coin=300, favorite=300, danmaku=800, reply=150
            ),
            DocScorer.SECONDS_1D,
        )
    )
    stale = calc_doc_score(
        make_doc(
            make_stats(
                view=50000, like=2000, coin=300, favorite=300, danmaku=800, reply=150
            ),
            DocScorer.SECONDS_30D,
        )
    )
    assert recent > stale > 0


def test_calc_score_detail_matches_total_score() -> None:
    doc = make_doc(
        make_stats(
            view=20000, like=1000, coin=200, favorite=150, danmaku=400, reply=80
        ),
        DocScorer.SECONDS_3D,
    )
    detail = calc_doc_score_detail(doc)
    assert detail["score"] == calc_doc_score(doc)
    assert set(detail["field_scores"].keys()) == set(DocScorer.STAT_FIELDS)
