from dataclasses import dataclass
from pathlib import Path

DEFAULT_VIDEO_QN = 16
DEFAULT_WORKERS = 2


@dataclass
class DownloadSettings:
    output_root: Path = Path("downloads")
    video_qn: int = DEFAULT_VIDEO_QN
    audio_strategy: str = "lowest"
    audio_convert_format: str | None = None
    audio_convert_codec: str | None = None
    audio_convert_bitrate: str | None = None
    audio_convert_sample_rate: int | None = None
    audio_convert_channels: int | None = None
    keep_original_audio: bool = True
    workers: int = DEFAULT_WORKERS
    resume: bool = True
    timeout: int = 30
    page_index: int = 1
