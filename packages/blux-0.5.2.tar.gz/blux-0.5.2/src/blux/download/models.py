from dataclasses import asdict, dataclass, field
from pathlib import Path
from urllib.parse import urlparse


def normalize_url(url: str) -> str:
    if url.startswith("//"):
        return f"https:{url}"
    return url


def suffix_from_url(url: str, default: str = ".bin") -> str:
    parsed = urlparse(normalize_url(url))
    suffix = Path(parsed.path).suffix
    return suffix or default


@dataclass
class VideoPage:
    page: int
    cid: int
    part: str
    duration: int = 0
    width: int = 0
    height: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "VideoPage":
        dimension = data.get("dimension") or {}
        return cls(
            page=int(data.get("page", 1)),
            cid=int(data.get("cid", 0)),
            part=data.get("part", ""),
            duration=int(data.get("duration", 0)),
            width=int(dimension.get("width", 0)),
            height=int(dimension.get("height", 0)),
        )

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class VideoView:
    aid: int
    bvid: str
    cid: int
    title: str
    desc: str
    pic: str
    owner_name: str = ""
    owner_mid: int = 0
    pages: list[VideoPage] = field(default_factory=list)

    @property
    def cover_url(self) -> str:
        return normalize_url(self.pic)

    def get_page(self, page_index: int) -> VideoPage:
        if not self.pages:
            return VideoPage(page=1, cid=self.cid, part=self.title)
        normalized_index = max(1, page_index)
        if normalized_index > len(self.pages):
            raise IndexError(
                f"Page index {page_index} exceeds total pages {len(self.pages)}"
            )
        return self.pages[normalized_index - 1]

    @classmethod
    def from_dict(cls, data: dict) -> "VideoView":
        return cls(
            aid=int(data.get("aid", 0)),
            bvid=data.get("bvid", ""),
            cid=int(data.get("cid", 0)),
            title=data.get("title", ""),
            desc=data.get("desc", ""),
            pic=data.get("pic", ""),
            owner_name=data.get("owner_name", ""),
            owner_mid=int(data.get("owner_mid", 0) or 0),
            pages=[VideoPage.from_dict(item) for item in data.get("pages", []) or []],
        )

    def to_dict(self) -> dict:
        return {
            "aid": self.aid,
            "bvid": self.bvid,
            "cid": self.cid,
            "title": self.title,
            "desc": self.desc,
            "pic": self.pic,
            "owner_name": self.owner_name,
            "owner_mid": self.owner_mid,
            "pages": [page.to_dict() for page in self.pages],
        }


@dataclass
class MediaStream:
    kind: str
    id: int
    quality_label: str
    codecs: str
    mime_type: str
    url: str
    backup_urls: list[str] = field(default_factory=list)
    bandwidth: int = 0
    width: int = 0
    height: int = 0
    frame_rate: str = ""
    size: int = 0

    @classmethod
    def from_dash_dict(
        cls,
        kind: str,
        data: dict,
        quality_map: dict[int, str] | None = None,
    ) -> "MediaStream":
        stream_id = int(data.get("id", 0))
        quality_label = (
            quality_map.get(stream_id, str(stream_id))
            if quality_map
            else str(stream_id)
        )
        return cls(
            kind=kind,
            id=stream_id,
            quality_label=quality_label,
            codecs=data.get("codecs", ""),
            mime_type=data.get("mimeType", data.get("mime_type", "")),
            url=normalize_url(data.get("baseUrl", data.get("base_url", ""))),
            backup_urls=[
                normalize_url(item)
                for item in data.get("backupUrl", data.get("backup_url", [])) or []
            ],
            bandwidth=int(data.get("bandwidth", 0) or 0),
            width=int(data.get("width", 0) or 0),
            height=int(data.get("height", 0) or 0),
            frame_rate=data.get("frameRate", data.get("frame_rate", "")),
            size=int(data.get("size", 0) or 0),
        )

    @property
    def candidate_urls(self) -> list[str]:
        return [self.url, *self.backup_urls]

    @property
    def suffix(self) -> str:
        if self.kind == "audio":
            return ".m4a"
        if "mp4" in self.mime_type or self.kind == "video":
            return ".mp4"
        return ".bin"

    @classmethod
    def from_dict(cls, data: dict) -> "MediaStream":
        return cls(
            kind=data.get("kind", ""),
            id=int(data.get("id", 0)),
            quality_label=data.get("quality_label", ""),
            codecs=data.get("codecs", ""),
            mime_type=data.get("mime_type", ""),
            url=normalize_url(data.get("url", "")),
            backup_urls=[normalize_url(item) for item in data.get("backup_urls", [])],
            bandwidth=int(data.get("bandwidth", 0) or 0),
            width=int(data.get("width", 0) or 0),
            height=int(data.get("height", 0) or 0),
            frame_rate=data.get("frame_rate", ""),
            size=int(data.get("size", 0) or 0),
        )

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class PlayInfo:
    video_streams: list[MediaStream] = field(default_factory=list)
    audio_streams: list[MediaStream] = field(default_factory=list)
    accepted_quality: dict[int, str] = field(default_factory=dict)
    timelength_ms: int = 0
    raw: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "PlayInfo":
        return cls(
            video_streams=[
                MediaStream.from_dict(item) for item in data.get("video_streams", [])
            ],
            audio_streams=[
                MediaStream.from_dict(item) for item in data.get("audio_streams", [])
            ],
            accepted_quality={
                int(key): value
                for key, value in (data.get("accepted_quality", {}) or {}).items()
            },
            timelength_ms=int(data.get("timelength_ms", 0) or 0),
            raw=data.get("raw", {}) or {},
        )

    def to_dict(self) -> dict:
        return {
            "video_streams": [stream.to_dict() for stream in self.video_streams],
            "audio_streams": [stream.to_dict() for stream in self.audio_streams],
            "accepted_quality": self.accepted_quality,
            "timelength_ms": self.timelength_ms,
            "raw": self.raw,
        }


@dataclass
class SnapshotInfo:
    pvdata_url: str = ""
    image_urls: list[str] = field(default_factory=list)
    index_points: list[int] = field(default_factory=list)
    img_x_len: int = 0
    img_y_len: int = 0
    img_x_size: int = 0
    img_y_size: int = 0
    raw: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "SnapshotInfo":
        return cls(
            pvdata_url=normalize_url(data.get("pvdata_url", data.get("pvdata", ""))),
            image_urls=[
                normalize_url(item)
                for item in (data.get("image_urls", data.get("image", [])) or [])
            ],
            index_points=[
                int(item)
                for item in (data.get("index_points", data.get("index", [])) or [])
            ],
            img_x_len=int(data.get("img_x_len", 0) or 0),
            img_y_len=int(data.get("img_y_len", 0) or 0),
            img_x_size=int(data.get("img_x_size", 0) or 0),
            img_y_size=int(data.get("img_y_size", 0) or 0),
            raw=data,
        )

    @property
    def frame_count(self) -> int:
        return len(self.index_points)

    @property
    def has_snapshot_images(self) -> bool:
        return bool(self.image_urls)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DownloadArtifact:
    kind: str
    path: Path
    source_url: str
    bytes_written: int


@dataclass
class DownloadResult:
    bvid: str
    title: str
    page_index: int
    output_dir: Path
    artifacts: list[DownloadArtifact] = field(default_factory=list)
    manifest_path: Path | None = None

    def add_artifact(self, artifact: DownloadArtifact) -> None:
        self.artifacts.append(artifact)
