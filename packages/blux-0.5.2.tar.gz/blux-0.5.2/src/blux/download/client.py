from pathlib import Path

import requests

from blux.wbi import REQUESTS_HEADERS, WbiSigner

from .config import DEFAULT_VIDEO_QN
from .models import MediaStream, PlayInfo, SnapshotInfo, VideoPage, VideoView


class BiliVideoClient:
    VIEW_URL = "https://api.bilibili.com/x/web-interface/view"
    PLAYURL_URL = "https://api.bilibili.com/x/player/wbi/playurl"
    VIDEOSHOT_URL = "https://api.bilibili.com/x/player/videoshot"
    BILIBILI_HOME = "https://www.bilibili.com"

    def __init__(self, session: requests.Session | None = None, timeout: int = 30):
        self.timeout = timeout
        self.session = session or requests.Session()
        self.session.headers.update({**REQUESTS_HEADERS, "Referer": self.BILIBILI_HOME})
        self.wbi_signer = WbiSigner(referer=self.BILIBILI_HOME)
        self._cookies_initialized = False

    def _ensure_cookies(self) -> None:
        if self._cookies_initialized:
            return
        response = self.session.get(self.BILIBILI_HOME, timeout=self.timeout)
        response.raise_for_status()
        self._cookies_initialized = True

    def _request_json(self, url: str, params: dict, referer: str | None = None) -> dict:
        headers = dict(self.session.headers)
        if referer:
            headers["Referer"] = referer
        response = self.session.get(
            url, params=params, headers=headers, timeout=self.timeout
        )
        response.raise_for_status()
        payload = response.json()
        if payload.get("code", 0) != 0:
            raise RuntimeError(
                f"Bilibili API error {payload.get('code')}: {payload.get('message')}"
            )
        return payload

    def fetch_video_view(self, bvid: str) -> VideoView:
        self._ensure_cookies()
        payload = self._request_json(self.VIEW_URL, {"bvid": bvid})
        data = payload["data"]
        pages = [VideoPage.from_dict(item) for item in data.get("pages", []) or []]
        return VideoView(
            aid=int(data.get("aid", 0)),
            bvid=data.get("bvid", bvid),
            cid=int(data.get("cid", 0)),
            title=data.get("title", ""),
            desc=data.get("desc", ""),
            pic=data.get("pic", ""),
            owner_name=(data.get("owner") or {}).get("name", ""),
            owner_mid=int((data.get("owner") or {}).get("mid", 0) or 0),
            pages=pages,
        )

    def fetch_playinfo(
        self,
        video_view: VideoView,
        page_index: int = 1,
        video_qn: int = DEFAULT_VIDEO_QN,
    ) -> PlayInfo:
        page = video_view.get_page(page_index)
        params = {
            "avid": video_view.aid,
            "bvid": video_view.bvid,
            "cid": page.cid,
            "fnval": 4048,
            "fnver": 0,
            "fourk": 0,
            "otype": "json",
            "qn": video_qn,
            "support_multi_audio": "true",
            "from_client": "BROWSER",
        }
        signed = self.wbi_signer.sign(params)
        payload = self._request_json(
            self.PLAYURL_URL,
            signed,
            referer=f"https://www.bilibili.com/video/{video_view.bvid}",
        )
        data = payload.get("data") or payload.get("result") or {}

        dash = data.get("dash") or {}
        accepted_quality = dict(
            zip(
                data.get("accept_quality", []) or [],
                data.get("accept_description", []) or [],
            )
        )
        video_streams = [
            MediaStream.from_dash_dict("video", item, accepted_quality)
            for item in dash.get("video", []) or []
        ]
        audio_streams = [
            MediaStream.from_dash_dict("audio", item)
            for item in dash.get("audio", []) or []
        ]

        durl = data.get("durl") or []
        if not video_streams and durl:
            total_size = sum(int(item.get("size", 0) or 0) for item in durl)
            video_streams = [
                MediaStream(
                    kind="video",
                    id=video_qn,
                    quality_label=accepted_quality.get(video_qn, str(video_qn)),
                    codecs="",
                    mime_type="video/mp4",
                    url=durl[0].get("url", ""),
                    backup_urls=durl[0].get("backup_url", []) or [],
                    bandwidth=0,
                    size=total_size,
                )
            ]

        return PlayInfo(
            video_streams=video_streams,
            audio_streams=audio_streams,
            accepted_quality=accepted_quality,
            timelength_ms=int(data.get("timelength", 0) or 0),
            raw=data,
        )

    def fetch_snapshot_info(
        self,
        video_view: VideoView,
        page_index: int = 1,
        include_index: bool = True,
    ) -> SnapshotInfo:
        page = video_view.get_page(page_index)
        payload = self._request_json(
            self.VIDEOSHOT_URL,
            {
                "aid": video_view.aid,
                "bvid": video_view.bvid,
                "cid": page.cid,
                "index": 1 if include_index else 0,
            },
            referer=f"https://www.bilibili.com/video/{video_view.bvid}",
        )
        return SnapshotInfo.from_dict(payload.get("data") or {})

    def fetch_danmaku_xml(self, cid: int) -> bytes:
        response = self.session.get(
            f"https://comment.bilibili.com/{cid}.xml",
            headers={**self.session.headers, "Referer": self.BILIBILI_HOME},
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.content

    def download_bytes(self, url: str) -> bytes:
        response = self.session.get(
            url, headers=self.session.headers, timeout=self.timeout
        )
        response.raise_for_status()
        return response.content

    def stream_to_path(
        self,
        urls: list[str],
        output_path: Path,
        referer: str,
        resume: bool = True,
    ) -> tuple[str, int]:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        existing_size = (
            output_path.stat().st_size if output_path.exists() and resume else 0
        )

        last_error: Exception | None = None
        for url in urls:
            headers = {**self.session.headers, "Referer": referer}
            if existing_size:
                headers["Range"] = f"bytes={existing_size}-"
            try:
                response = self.session.get(
                    url, headers=headers, stream=True, timeout=self.timeout
                )
                if response.status_code == 416:
                    return url, existing_size
                response.raise_for_status()
                is_partial = response.status_code == 206 and existing_size > 0
                mode = "ab" if is_partial else "wb"
                bytes_written = existing_size if is_partial else 0
                with open(output_path, mode) as file:
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        if not chunk:
                            continue
                        file.write(chunk)
                        bytes_written += len(chunk)
                return url, bytes_written
            except Exception as exc:
                last_error = exc
        if last_error is not None:
            raise last_error
        raise RuntimeError("No download URLs available")
