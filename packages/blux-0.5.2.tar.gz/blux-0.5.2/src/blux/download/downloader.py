import json
import re

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from blux.convert import convert_audio

from .client import BiliVideoClient
from .config import DownloadSettings
from .models import (
    DownloadArtifact,
    DownloadResult,
    MediaStream,
    PlayInfo,
    SnapshotInfo,
    VideoView,
    suffix_from_url,
)


def slugify(value: str) -> str:
    normalized = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff._-]+", "_", value).strip("._")
    return normalized or "untitled"


class BiliDownloader:
    def __init__(
        self,
        client: BiliVideoClient | None = None,
        settings: DownloadSettings | None = None,
    ):
        self.settings = settings or DownloadSettings()
        self.client = client or BiliVideoClient(timeout=self.settings.timeout)

    def inspect(
        self,
        bvid: str,
        *,
        page_index: int | None = None,
        video_qn: int | None = None,
    ) -> tuple[VideoView, PlayInfo, SnapshotInfo]:
        resolved_page = page_index or self.settings.page_index
        resolved_qn = video_qn or self.settings.video_qn
        video_view = self.client.fetch_video_view(bvid)
        playinfo = self.client.fetch_playinfo(
            video_view, page_index=resolved_page, video_qn=resolved_qn
        )
        snapshot_info = self.client.fetch_snapshot_info(
            video_view,
            page_index=resolved_page,
            include_index=True,
        )
        return video_view, playinfo, snapshot_info

    def _select_video_stream(
        self, playinfo: PlayInfo, preferred_qn: int
    ) -> MediaStream:
        if not playinfo.video_streams:
            raise RuntimeError("No video streams available")
        lower_or_equal = [
            stream for stream in playinfo.video_streams if stream.id <= preferred_qn
        ]
        if lower_or_equal:
            return sorted(
                lower_or_equal,
                key=lambda stream: (preferred_qn - stream.id, stream.bandwidth),
            )[0]
        return sorted(
            playinfo.video_streams,
            key=lambda stream: (stream.id - preferred_qn, stream.bandwidth),
        )[0]

    def _select_audio_stream(self, playinfo: PlayInfo) -> MediaStream:
        if not playinfo.audio_streams:
            raise RuntimeError("No audio streams available")
        reverse = self.settings.audio_strategy == "highest"
        return sorted(
            playinfo.audio_streams, key=lambda stream: stream.bandwidth, reverse=reverse
        )[0]

    def _build_output_dir(
        self, video_view: VideoView, page_index: int, output_root: Path | None = None
    ) -> Path:
        root = Path(output_root) if output_root else Path(self.settings.output_root)
        page_label = f"p{page_index:02d}"
        return root / f"{video_view.bvid}_{slugify(video_view.title)}" / page_label

    def _build_converted_audio_path(self, target_path: Path) -> Path:
        convert_format = (self.settings.audio_convert_format or "").strip().lower()
        if not convert_format:
            return target_path

        suffix = f".{convert_format.lstrip('.')}"
        converted_path = target_path.with_suffix(suffix)
        if converted_path == target_path:
            converted_path = target_path.with_name(
                f"{target_path.stem}_converted{suffix}"
            )
        return converted_path

    def _convert_downloaded_audio(
        self,
        target_path: Path,
    ) -> DownloadArtifact | None:
        if not self.settings.audio_convert_format:
            return None

        converted_path = self._build_converted_audio_path(target_path)
        convert_audio(
            target_path,
            output_path=converted_path,
            format=self.settings.audio_convert_format,
            codec=self.settings.audio_convert_codec,
            bitrate=self.settings.audio_convert_bitrate,
            sample_rate=self.settings.audio_convert_sample_rate,
            channels=self.settings.audio_convert_channels,
        )
        return DownloadArtifact(
            "audio_converted",
            converted_path,
            str(target_path),
            converted_path.stat().st_size,
        )

    def _write_manifest(
        self,
        result: DownloadResult,
        video_view: VideoView,
        page_index: int,
        playinfo: PlayInfo | None = None,
        snapshot_info: SnapshotInfo | None = None,
    ) -> Path:
        manifest_path = result.output_dir / "manifest.json"
        page = video_view.get_page(page_index)
        manifest = {
            "bvid": video_view.bvid,
            "aid": video_view.aid,
            "title": video_view.title,
            "desc": video_view.desc,
            "owner_name": video_view.owner_name,
            "owner_mid": video_view.owner_mid,
            "page": {
                "page": page.page,
                "cid": page.cid,
                "part": page.part,
                "duration": page.duration,
                "width": page.width,
                "height": page.height,
            },
            "artifacts": [
                {
                    "kind": artifact.kind,
                    "path": str(artifact.path),
                    "source_url": artifact.source_url,
                    "bytes_written": artifact.bytes_written,
                }
                for artifact in result.artifacts
            ],
        }
        if playinfo is not None:
            manifest["accepted_quality"] = playinfo.accepted_quality
            manifest["timelength_ms"] = playinfo.timelength_ms
        if snapshot_info is not None:
            manifest["snapshot"] = {
                "pvdata_url": snapshot_info.pvdata_url,
                "image_urls": snapshot_info.image_urls,
                "index_points": snapshot_info.index_points,
                "img_x_len": snapshot_info.img_x_len,
                "img_y_len": snapshot_info.img_y_len,
                "img_x_size": snapshot_info.img_x_size,
                "img_y_size": snapshot_info.img_y_size,
            }
        with open(manifest_path, "w", encoding="utf-8") as file:
            json.dump(manifest, file, ensure_ascii=False, indent=2)
        result.manifest_path = manifest_path
        return manifest_path

    def download(
        self,
        bvid: str,
        targets: set[str],
        page_index: int | None = None,
        output_root: Path | None = None,
        video_qn: int | None = None,
        resume: bool | None = None,
    ) -> DownloadResult:
        resolved_page = page_index or self.settings.page_index
        resolved_qn = video_qn or self.settings.video_qn
        should_resume = self.settings.resume if resume is None else resume

        video_view = self.client.fetch_video_view(bvid)
        output_dir = self._build_output_dir(
            video_view, resolved_page, output_root=output_root
        )
        output_dir.mkdir(parents=True, exist_ok=True)
        result = DownloadResult(
            bvid=video_view.bvid,
            title=video_view.title,
            page_index=resolved_page,
            output_dir=output_dir,
        )

        referer = f"https://www.bilibili.com/video/{video_view.bvid}"
        playinfo: PlayInfo | None = None
        snapshot_info: SnapshotInfo | None = None

        if {"video", "audio"} & targets:
            playinfo = self.client.fetch_playinfo(
                video_view,
                page_index=resolved_page,
                video_qn=resolved_qn,
            )

        if "video" in targets:
            if playinfo is None:
                raise RuntimeError("Playinfo is required for video downloads")
            stream = self._select_video_stream(playinfo, preferred_qn=resolved_qn)
            target_path = output_dir / f"video_{stream.id}{stream.suffix}"
            source_url, bytes_written = self.client.stream_to_path(
                stream.candidate_urls,
                target_path,
                referer=referer,
                resume=should_resume,
            )
            result.add_artifact(
                DownloadArtifact("video", target_path, source_url, bytes_written)
            )

        if "audio" in targets:
            if playinfo is None:
                raise RuntimeError("Playinfo is required for audio downloads")
            stream = self._select_audio_stream(playinfo)
            target_path = output_dir / f"audio_{stream.id}{stream.suffix}"
            source_url, bytes_written = self.client.stream_to_path(
                stream.candidate_urls,
                target_path,
                referer=referer,
                resume=should_resume,
            )
            converted_artifact = self._convert_downloaded_audio(target_path)
            if converted_artifact is None or self.settings.keep_original_audio:
                result.add_artifact(
                    DownloadArtifact("audio", target_path, source_url, bytes_written)
                )
            if converted_artifact is not None:
                if not self.settings.keep_original_audio:
                    target_path.unlink(missing_ok=True)
                    converted_artifact = DownloadArtifact(
                        "audio",
                        converted_artifact.path,
                        converted_artifact.source_url,
                        converted_artifact.bytes_written,
                    )
                result.add_artifact(converted_artifact)

        if "snapshot" in targets:
            snapshot_info = self.client.fetch_snapshot_info(
                video_view,
                page_index=resolved_page,
                include_index=True,
            )
            if snapshot_info.pvdata_url:
                pvdata_path = (
                    output_dir
                    / f"snapshot_pvdata{suffix_from_url(snapshot_info.pvdata_url)}"
                )
                pvdata_bytes = self.client.download_bytes(snapshot_info.pvdata_url)
                pvdata_path.write_bytes(pvdata_bytes)
                result.add_artifact(
                    DownloadArtifact(
                        "snapshot_pvdata",
                        pvdata_path,
                        snapshot_info.pvdata_url,
                        len(pvdata_bytes),
                    )
                )

            index_path = output_dir / "snapshot_index.json"
            index_payload = {
                "index_points": snapshot_info.index_points,
                "img_x_len": snapshot_info.img_x_len,
                "img_y_len": snapshot_info.img_y_len,
                "img_x_size": snapshot_info.img_x_size,
                "img_y_size": snapshot_info.img_y_size,
                "frame_count": snapshot_info.frame_count,
            }
            index_bytes = json.dumps(
                index_payload, ensure_ascii=False, indent=2
            ).encode("utf-8")
            index_path.write_bytes(index_bytes)
            result.add_artifact(
                DownloadArtifact(
                    "snapshot_index",
                    index_path,
                    snapshot_info.pvdata_url,
                    len(index_bytes),
                )
            )

            for image_index, image_url in enumerate(snapshot_info.image_urls, start=1):
                image_path = (
                    output_dir
                    / f"snapshot_{image_index:03d}{suffix_from_url(image_url, default='.jpg')}"
                )
                image_bytes = self.client.download_bytes(image_url)
                image_path.write_bytes(image_bytes)
                result.add_artifact(
                    DownloadArtifact(
                        "snapshot_image",
                        image_path,
                        image_url,
                        len(image_bytes),
                    )
                )

        if "cover" in targets:
            target_path = (
                output_dir
                / f"cover{suffix_from_url(video_view.cover_url, default='.jpg')}"
            )
            cover_bytes = self.client.download_bytes(video_view.cover_url)
            target_path.write_bytes(cover_bytes)
            result.add_artifact(
                DownloadArtifact(
                    "cover", target_path, video_view.cover_url, len(cover_bytes)
                )
            )

        if "danmaku" in targets:
            page = video_view.get_page(resolved_page)
            target_path = output_dir / "danmaku.xml"
            source_url = f"https://comment.bilibili.com/{page.cid}.xml"
            xml_bytes = self.client.fetch_danmaku_xml(page.cid)
            target_path.write_bytes(xml_bytes)
            result.add_artifact(
                DownloadArtifact(
                    "danmaku",
                    target_path,
                    source_url,
                    len(xml_bytes),
                )
            )

        self._write_manifest(
            result,
            video_view,
            resolved_page,
            playinfo=playinfo,
            snapshot_info=snapshot_info,
        )
        return result

    def download_many(
        self,
        bvids: list[str],
        targets: set[str],
        workers: int | None = None,
        page_index: int | None = None,
        output_root: Path | None = None,
        video_qn: int | None = None,
        resume: bool | None = None,
    ) -> list[DownloadResult]:
        if not bvids:
            return []
        max_workers = min(max(1, workers or self.settings.workers), len(bvids))
        results: list[DownloadResult] = []
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(
                    self.download,
                    bvid,
                    targets,
                    page_index=page_index,
                    output_root=output_root,
                    video_qn=video_qn,
                    resume=resume,
                ): bvid
                for bvid in bvids
            }
            for future in as_completed(futures):
                results.append(future.result())
        return sorted(results, key=lambda item: bvids.index(item.bvid))
