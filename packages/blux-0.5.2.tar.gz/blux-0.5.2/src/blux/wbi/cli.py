import argparse
import json

from .signer import WbiSigner


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="blux wbi", description="WBI signing helpers")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("keys", help="Fetch current WBI keys")

    sign_parser = subparsers.add_parser("sign", help="Sign key=value request params")
    sign_parser.add_argument("params", nargs="+", help="Parameters in key=value form")
    sign_parser.add_argument("--wts", type=int)
    return parser


def parse_key_value_pairs(items: list[str]) -> dict:
    parsed = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"Expected key=value pair, got: {item}")
        key, value = item.split("=", 1)
        parsed[key] = value
    return parsed


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    signer = WbiSigner()
    if args.command == "keys":
        img_key, sub_key = signer.fetch_wbi_keys()
        print(
            json.dumps(
                {"img_key": img_key, "sub_key": sub_key}, ensure_ascii=False, indent=2
            )
        )
        return 0
    if args.command == "sign":
        signed = signer.sign(parse_key_value_pairs(args.params), wts=args.wts)
        print(json.dumps(signed, ensure_ascii=False, indent=2))
        return 0
    raise ValueError(f"Unsupported command: {args.command}")
