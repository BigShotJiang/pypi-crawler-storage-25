import json
import math
import random
import time
import urllib.parse

from functools import reduce
from hashlib import md5

import requests

REQUESTS_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/123.0.0.0 Safari/537.36"
    ),
}


class WbiSigner:
    MAGIC_KEYS = [
        46,
        47,
        18,
        2,
        53,
        8,
        23,
        32,
        15,
        50,
        10,
        31,
        58,
        3,
        45,
        35,
        27,
        43,
        5,
        49,
        33,
        9,
        42,
        19,
        29,
        28,
        14,
        39,
        12,
        38,
        41,
        13,
        37,
        48,
        7,
        16,
        24,
        55,
        40,
        61,
        26,
        17,
        0,
        1,
        60,
        51,
        30,
        4,
        22,
        25,
        54,
        21,
        56,
        59,
        6,
        63,
        57,
        62,
        11,
        36,
        20,
        34,
        44,
        52,
    ]
    NAV_URL = "https://api.bilibili.com/x/web-interface/nav"

    def __init__(self, referer: str = "https://www.bilibili.com"):
        self.headers = {**REQUESTS_HEADERS, "Referer": referer}
        self.img_key: str | None = None
        self.sub_key: str | None = None

    def _get_magic_key(self, text: str) -> str:
        return reduce(lambda acc, index: acc + text[index], self.MAGIC_KEYS, "")[:32]

    def fetch_wbi_keys(self) -> tuple[str, str]:
        response = requests.get(self.NAV_URL, headers=self.headers, timeout=15)
        response.raise_for_status()
        data = response.json()
        wbi_image = data["data"]["wbi_img"]
        img_url = wbi_image["img_url"]
        sub_url = wbi_image["sub_url"]
        self.img_key = img_url.rsplit("/", 1)[1].split(".")[0]
        self.sub_key = sub_url.rsplit("/", 1)[1].split(".")[0]
        return self.img_key, self.sub_key

    def sign(self, params: dict, wts: int | None = None) -> dict:
        if self.img_key is None or self.sub_key is None:
            self.fetch_wbi_keys()

        magic_key = self._get_magic_key(self.img_key + self.sub_key)
        signed = dict(params)
        signed["wts"] = wts if wts is not None else round(time.time())
        signed = dict(sorted(signed.items()))
        signed = {
            key: (
                json.dumps(value, separators=(",", ":"))
                if isinstance(value, dict)
                else str(value)
            )
            for key, value in signed.items()
        }
        query = urllib.parse.urlencode(signed, quote_via=urllib.parse.quote)
        signed["w_rid"] = md5((query + magic_key).encode()).hexdigest()
        return signed


class DmImgParams:
    def __init__(self, dm_img_str: str = "XXcXXXVXXX"):
        self.dm_img_str = dm_img_str

    @staticmethod
    def _calc_wh(win_width: int = 1920, win_height: int = 1080) -> list[int]:
        rnd = math.floor(114 * random.random())
        return [
            2 * win_width + 2 * win_height + 3 * rnd,
            4 * win_width - win_height + rnd,
            rnd,
        ]

    @staticmethod
    def _calc_of(scroll_top: int = 10, scroll_left: int = 10) -> list[int]:
        rnd = math.floor(514 * random.random())
        return [
            3 * scroll_top + 2 * scroll_left + rnd,
            4 * scroll_top - 4 * scroll_left + 2 * rnd,
            rnd,
        ]

    def get(self) -> dict:
        return {
            "dm_img_list": [],
            "dm_img_str": self.dm_img_str,
            "dm_cover_img_str": self.dm_img_str,
            "dm_img_inter": {
                "wh": self._calc_wh(),
                "of": self._calc_of(),
            },
        }
