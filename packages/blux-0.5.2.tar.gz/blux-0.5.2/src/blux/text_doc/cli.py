import argparse

from .builder import build_sentence, calc_md5


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="blux text", description="Text document helpers"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    sentence_parser = subparsers.add_parser(
        "sentence", help="Build a sentence from document fields"
    )
    sentence_parser.add_argument("--title", default="")
    sentence_parser.add_argument("--tags", default="")
    sentence_parser.add_argument("--desc", default="")
    sentence_parser.add_argument("--owner-name", default="")
    sentence_parser.add_argument("--max-len", type=int)

    md5_parser = subparsers.add_parser("md5", help="Calculate the stable md5 summary")
    md5_parser.add_argument("--title", default="")
    md5_parser.add_argument("--tags", default="")
    md5_parser.add_argument("--desc", default="")
    md5_parser.add_argument("--owner-name", default="")
    md5_parser.add_argument("--chars-length", type=int, default=4)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "sentence":
        print(
            build_sentence(
                title=args.title,
                tags=args.tags,
                desc=args.desc,
                owner_name=args.owner_name,
                max_len=args.max_len,
            )
        )
        return 0
    if args.command == "md5":
        print(
            calc_md5(
                title=args.title,
                tags=args.tags,
                desc=args.desc,
                owner_name=args.owner_name,
                chars_length=args.chars_length,
            )
        )
        return 0
    raise ValueError(f"Unsupported command: {args.command}")
