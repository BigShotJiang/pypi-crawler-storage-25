from dataclasses import dataclass

from tclogger import dict_get

from .builder import build_sentence, calc_md5


@dataclass
class TextDocItem:
    bvid: str
    title: str
    tags: str
    owner_name: str
    desc: str
    sentence: str = ""
    md5_hash: str = ""

    @staticmethod
    def from_doc(doc: dict) -> "TextDocItem":
        return TextDocItem(
            bvid=doc.get("bvid", ""),
            title=dict_get(doc, "title", ""),
            tags=dict_get(doc, "tags", ""),
            owner_name=dict_get(doc, "owner.name", ""),
            desc=dict_get(doc, "desc", ""),
        )

    def calc_md5_hash(self) -> str:
        self.md5_hash = calc_md5(
            title=self.title,
            tags=self.tags,
            desc=self.desc,
            owner_name=self.owner_name,
        )
        return self.md5_hash

    def build_sentence(self, max_len: int | None = None) -> str:
        self.sentence = build_sentence(
            title=self.title,
            tags=self.tags,
            desc=self.desc,
            owner_name=self.owner_name,
            max_len=max_len,
        )
        return self.sentence
