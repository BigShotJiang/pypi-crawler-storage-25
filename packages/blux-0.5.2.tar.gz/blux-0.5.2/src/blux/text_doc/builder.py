from hashlib import md5


def build_sentence(
    title: str = "",
    tags: str = "",
    desc: str = "",
    owner_name: str = "",
    max_len: int | None = None,
) -> str:
    sentence = ""

    owner_name_strip = (owner_name or "").strip()
    if owner_name_strip:
        sentence += f"【{owner_name_strip}】"

    title_strip = (title or "").strip()
    if title_strip:
        if sentence:
            sentence += " "
        sentence += title_strip

    tags_strip = (tags or "").strip()
    if tags_strip:
        if sentence:
            sentence += " "
        sentence += f"({tags_strip})"

    desc_strip = (desc or "").strip()
    if desc_strip and desc_strip != "-":
        if sentence:
            sentence += " "
        sentence += desc_strip

    if max_len and len(sentence) > max_len:
        sentence = sentence[:max_len]
    return sentence


def build_sentence_for_md5(
    title: str = "",
    tags: str = "",
    desc: str = "",
    owner_name: str = "",
) -> str:
    return build_sentence(
        title=title,
        tags=tags,
        desc=desc,
        owner_name=owner_name,
        max_len=None,
    )


def calc_md5(
    title: str = "",
    tags: str = "",
    desc: str = "",
    owner_name: str = "",
    chars_length: int = 4,
) -> str:
    text = build_sentence_for_md5(
        title=title,
        tags=tags,
        desc=desc,
        owner_name=owner_name,
    )
    return md5(text.encode("utf-8")).hexdigest()[:chars_length]
