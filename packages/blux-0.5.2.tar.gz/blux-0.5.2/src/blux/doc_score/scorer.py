import math


class DocScorer:
    STAT_CONFIGS = {
        "view": {"weight": 1.0, "alpha": 8.0},
        "like": {"weight": 2.0, "alpha": 5.5},
        "coin": {"weight": 3.0, "alpha": 4.5},
        "favorite": {"weight": 3.0, "alpha": 4.5},
        "danmaku": {"weight": 2.0, "alpha": 5.5},
        "reply": {"weight": 2.0, "alpha": 5.0},
    }
    STAT_FIELDS = list(STAT_CONFIGS.keys())
    TOTAL_WEIGHT = sum(config["weight"] for config in STAT_CONFIGS.values())

    SECONDS_1H = 3600
    SECONDS_1D = 86400
    SECONDS_3D = 259200
    SECONDS_7D = 604800
    SECONDS_15D = 1296000
    SECONDS_30D = 2592000

    TIME_ANCHORS = [
        (SECONDS_1H, 1.30),
        (SECONDS_1D, 1.10),
        (SECONDS_3D, 0.90),
        (SECONDS_7D, 0.70),
        (SECONDS_15D, 0.55),
        (SECONDS_30D, 0.45),
    ]

    TIME_FACTOR_MAX = TIME_ANCHORS[0][1]
    TIME_FACTOR_MIN = TIME_ANCHORS[-1][1]

    ANOMALY_MIN_LOG_SCALE = 0.5
    ANOMALY_CONSISTENCY_THRESHOLD = 0.5
    ANOMALY_MIN_FACTOR = 0.3

    BASE_SCORE = 0.01

    @staticmethod
    def _saturate(value: float, alpha: float) -> float:
        if value <= 0:
            return 0.0
        log_value = math.log1p(value)
        return log_value / (log_value + alpha)

    def _calc_stat_score(self, stats: dict) -> float:
        weighted_sum = 0.0
        for field, config in self.STAT_CONFIGS.items():
            value = max(0, stats.get(field, 0) or 0)
            weighted_sum += config["weight"] * self._saturate(value, config["alpha"])
        return weighted_sum / self.TOTAL_WEIGHT

    def _calc_anomaly_factor(self, stats: dict) -> float:
        log_scales = []
        for field, config in self.STAT_CONFIGS.items():
            value = max(0, stats.get(field, 0) or 0)
            half_saturation = math.expm1(config["alpha"])
            relative = value / half_saturation
            log_scales.append(math.log1p(relative))

        max_log = max(log_scales)
        if max_log < self.ANOMALY_MIN_LOG_SCALE:
            return 1.0

        mean_log = sum(log_scales) / len(log_scales)
        consistency = mean_log / max_log
        if consistency >= self.ANOMALY_CONSISTENCY_THRESHOLD:
            return 1.0

        ratio = consistency / self.ANOMALY_CONSISTENCY_THRESHOLD
        return self.ANOMALY_MIN_FACTOR + (1.0 - self.ANOMALY_MIN_FACTOR) * math.sqrt(
            ratio
        )

    def _calc_time_factor(self, pub_to_insert: int) -> float:
        elapsed = max(0, pub_to_insert)
        if elapsed <= self.TIME_ANCHORS[0][0]:
            return self.TIME_ANCHORS[0][1]
        if elapsed >= self.TIME_ANCHORS[-1][0]:
            return self.TIME_ANCHORS[-1][1]

        log_elapsed = math.log(elapsed)
        for index in range(len(self.TIME_ANCHORS) - 1):
            start_time, start_factor = self.TIME_ANCHORS[index]
            end_time, end_factor = self.TIME_ANCHORS[index + 1]
            if elapsed <= end_time:
                ratio = (log_elapsed - math.log(start_time)) / (
                    math.log(end_time) - math.log(start_time)
                )
                return start_factor + ratio * (end_factor - start_factor)
        return self.TIME_ANCHORS[-1][1]

    def calc_score(self, doc: dict) -> float:
        stats = doc.get("stats", {}) or {}
        stat_score = self._calc_stat_score(stats)
        anomaly_factor = self._calc_anomaly_factor(stats)
        pub_to_insert = doc.get("pub_to_insert")
        if pub_to_insert is None:
            pub_to_insert = (doc.get("insert_at", 0) or 0) - (
                doc.get("pubdate", 0) or 0
            )
        time_factor = self._calc_time_factor(pub_to_insert)
        return (self.BASE_SCORE + stat_score * anomaly_factor) * time_factor

    def calc_score_detail(self, doc: dict) -> dict:
        stats = doc.get("stats", {}) or {}
        field_scores = {}
        for field, config in self.STAT_CONFIGS.items():
            value = max(0, stats.get(field, 0) or 0)
            field_scores[field] = self._saturate(value, config["alpha"])

        stat_score = self._calc_stat_score(stats)
        anomaly_factor = self._calc_anomaly_factor(stats)
        pub_to_insert = doc.get("pub_to_insert")
        if pub_to_insert is None:
            pub_to_insert = (doc.get("insert_at", 0) or 0) - (
                doc.get("pubdate", 0) or 0
            )
        time_factor = self._calc_time_factor(pub_to_insert)
        score = (self.BASE_SCORE + stat_score * anomaly_factor) * time_factor
        return {
            "score": score,
            "stat_score": stat_score,
            "anomaly_factor": anomaly_factor,
            "time_factor": time_factor,
            "field_scores": field_scores,
            "pub_to_insert": pub_to_insert,
        }


doc_scorer = DocScorer()
calc_doc_score = doc_scorer.calc_score
calc_doc_score_detail = doc_scorer.calc_score_detail
