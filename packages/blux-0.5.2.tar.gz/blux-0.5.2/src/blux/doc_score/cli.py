import argparse
import json

from .scorer import calc_doc_score, calc_doc_score_detail


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="blux score", description="Score Bilibili-style documents"
    )
    parser.add_argument(
        "--doc-file", help="Path to a JSON file containing the document payload"
    )
    parser.add_argument("--pubdate", type=int, default=0)
    parser.add_argument("--insert-at", type=int, default=0)
    parser.add_argument("--pub-to-insert", type=int)
    parser.add_argument("--view", type=int, default=0)
    parser.add_argument("--like", type=int, default=0)
    parser.add_argument("--coin", type=int, default=0)
    parser.add_argument("--favorite", type=int, default=0)
    parser.add_argument("--danmaku", type=int, default=0)
    parser.add_argument("--reply", type=int, default=0)
    parser.add_argument(
        "--detail", action="store_true", help="Print the detailed score breakdown"
    )
    return parser


def build_doc(args: argparse.Namespace) -> dict:
    if args.doc_file:
        with open(args.doc_file, "r", encoding="utf-8") as file:
            return json.load(file)
    return {
        "pubdate": args.pubdate,
        "insert_at": args.insert_at,
        "pub_to_insert": args.pub_to_insert,
        "stats": {
            "view": args.view,
            "like": args.like,
            "coin": args.coin,
            "favorite": args.favorite,
            "danmaku": args.danmaku,
            "reply": args.reply,
        },
    }


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    doc = build_doc(args)
    if args.detail:
        print(json.dumps(calc_doc_score_detail(doc), ensure_ascii=False, indent=2))
    else:
        print(calc_doc_score(doc))
    return 0
