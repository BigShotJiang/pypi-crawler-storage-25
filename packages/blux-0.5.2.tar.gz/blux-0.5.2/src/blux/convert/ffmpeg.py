import json
import shutil
import subprocess

from dataclasses import asdict, dataclass
from pathlib import Path


AUDIO_FORMAT_CHOICES = ("wav", "mp3", "m4a", "flac", "opus")


@dataclass
class AudioProbe:
    path: Path
    format_name: str = ""
    duration_sec: float | None = None
    size_bytes: int | None = None
    bit_rate: int | None = None
    codec_name: str = ""
    sample_rate: int | None = None
    channels: int | None = None

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["path"] = str(self.path)
        return payload


def ensure_ffmpeg_binary(binary_name: str) -> str:
    resolved = shutil.which(binary_name)
    if resolved:
        return resolved
    raise RuntimeError(
        f"Required binary '{binary_name}' was not found in PATH. Install ffmpeg first."
    )


def _default_audio_codec(format_name: str) -> str | None:
    normalized = format_name.strip().lower().lstrip(".")
    if normalized == "wav":
        return "pcm_s16le"
    if normalized == "mp3":
        return "libmp3lame"
    if normalized == "m4a":
        return "aac"
    if normalized == "flac":
        return "flac"
    if normalized == "opus":
        return "libopus"
    return None


def probe_media(path: str | Path, ffprobe_bin: str = "ffprobe") -> AudioProbe:
    input_path = Path(path).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError(f"Media file not found: {input_path}")

    ffprobe_path = ensure_ffmpeg_binary(ffprobe_bin)
    result = subprocess.run(
        [
            ffprobe_path,
            "-v",
            "error",
            "-select_streams",
            "a:0",
            "-show_entries",
            "format=format_name,duration,size,bit_rate",
            "-show_entries",
            "stream=codec_name,sample_rate,channels",
            "-of",
            "json",
            str(input_path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "ffprobe failed")

    payload = json.loads(result.stdout or "{}")
    format_info = payload.get("format", {}) or {}
    streams = payload.get("streams", []) or []
    stream_info = streams[0] if streams else {}

    def as_float(value: str | None) -> float | None:
        if value in (None, "", "N/A"):
            return None
        return float(value)

    def as_int(value: str | None) -> int | None:
        if value in (None, "", "N/A"):
            return None
        return int(value)

    return AudioProbe(
        path=input_path,
        format_name=str(format_info.get("format_name", "")),
        duration_sec=as_float(format_info.get("duration")),
        size_bytes=as_int(format_info.get("size")),
        bit_rate=as_int(format_info.get("bit_rate")),
        codec_name=str(stream_info.get("codec_name", "")),
        sample_rate=as_int(stream_info.get("sample_rate")),
        channels=as_int(stream_info.get("channels")),
    )


def convert_audio(
    input_path: str | Path,
    *,
    output_path: str | Path | None = None,
    format: str | None = None,
    codec: str | None = None,
    bitrate: str | None = None,
    sample_rate: int | None = None,
    channels: int | None = None,
    overwrite: bool = True,
    ffmpeg_bin: str = "ffmpeg",
) -> Path:
    source_path = Path(input_path).expanduser().resolve()
    if not source_path.exists():
        raise FileNotFoundError(f"Media file not found: {source_path}")

    resolved_format = (format or source_path.suffix.lstrip(".") or "wav").lower()
    if resolved_format not in AUDIO_FORMAT_CHOICES:
        raise ValueError(
            f"Unsupported audio format '{resolved_format}'. Expected one of {AUDIO_FORMAT_CHOICES}."
        )

    target_path = (
        Path(output_path).expanduser().resolve()
        if output_path is not None
        else source_path.with_suffix(f".{resolved_format}")
    )
    target_path.parent.mkdir(parents=True, exist_ok=True)

    ffmpeg_path = ensure_ffmpeg_binary(ffmpeg_bin)
    command = [
        ffmpeg_path,
        "-y" if overwrite else "-n",
        "-i",
        str(source_path),
        "-vn",
        "-map",
        "0:a:0",
    ]

    resolved_codec = codec or _default_audio_codec(resolved_format)
    if resolved_codec:
        command.extend(["-c:a", resolved_codec])
    if bitrate:
        command.extend(["-b:a", bitrate])
    if sample_rate is not None:
        command.extend(["-ar", str(sample_rate)])
    if channels is not None:
        command.extend(["-ac", str(channels)])
    command.append(str(target_path))

    result = subprocess.run(command, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        raise RuntimeError(stderr or "ffmpeg conversion failed")
    return target_path
