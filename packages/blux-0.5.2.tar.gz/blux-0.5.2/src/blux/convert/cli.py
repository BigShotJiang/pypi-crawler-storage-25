import argparse
import json

from pathlib import Path

from .ffmpeg import AUDIO_FORMAT_CHOICES, convert_audio, probe_media


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="blux convert",
        description="Audio probing and conversion helpers powered by ffmpeg",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    probe_parser = subparsers.add_parser("probe", help="Inspect local media files")
    probe_parser.add_argument("paths", nargs="+")

    audio_parser = subparsers.add_parser(
        "audio", help="Convert audio into a target format"
    )
    audio_parser.add_argument("inputs", nargs="+")
    audio_parser.add_argument(
        "--format",
        required=True,
        choices=AUDIO_FORMAT_CHOICES,
    )
    audio_parser.add_argument("--codec", default=None)
    audio_parser.add_argument("--bitrate", default=None)
    audio_parser.add_argument("--sample-rate", type=int, default=None)
    audio_parser.add_argument("--channels", type=int, default=None)
    audio_parser.add_argument("--output", type=Path, default=None)
    audio_parser.add_argument("--output-dir", type=Path, default=None)
    audio_parser.add_argument("--no-overwrite", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "probe":
        payload = [probe_media(path).to_dict() for path in args.paths]
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    if args.output is not None and len(args.inputs) > 1:
        raise SystemExit("--output only supports a single input file")

    payload = []
    for input_path in args.inputs:
        source = Path(input_path).expanduser().resolve()
        if args.output is not None:
            output_path = args.output
        elif args.output_dir is not None:
            output_path = args.output_dir / f"{source.stem}.{args.format}"
        else:
            output_path = source.with_suffix(f".{args.format}")
        converted = convert_audio(
            source,
            output_path=output_path,
            format=args.format,
            codec=args.codec,
            bitrate=args.bitrate,
            sample_rate=args.sample_rate,
            channels=args.channels,
            overwrite=not args.no_overwrite,
        )
        payload.append(
            {
                "input": str(source),
                "output": str(converted),
                "probe": probe_media(converted).to_dict(),
            }
        )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0
