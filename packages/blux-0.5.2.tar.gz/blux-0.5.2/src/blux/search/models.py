import re
import time

from dataclasses import dataclass, field
from typing import Any

from .enums import SearchType


def strip_html_tags(text: str | None) -> str | None:
    if not text:
        return text
    return re.sub(r"<[^>]+>", "", text)


def safe_int(value: Any, default: int = 0) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


@dataclass
class VideoItem:
    type: str = "video"
    aid: int = 0
    bvid: str = ""
    title: str = ""
    title_raw: str = ""
    description: str = ""
    author: str = ""
    mid: int = 0
    typeid: str = ""
    typename: str = ""
    arcurl: str = ""
    pic: str = ""
    play: int = 0
    video_review: int = 0
    favorites: int = 0
    tag: str = ""
    review: int = 0
    pubdate: int = 0
    senddate: int = 0
    duration: str = ""
    hit_columns: list[str] = field(default_factory=list)
    rank_score: int = 0
    is_pay: int = 0
    is_union_video: int = 0
    like: int = 0
    coin: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "VideoItem":
        title_raw = data.get("title", "")
        return cls(
            type=data.get("type", "video"),
            aid=safe_int(data.get("aid", data.get("id", 0))),
            bvid=data.get("bvid", ""),
            title=strip_html_tags(title_raw) or "",
            title_raw=title_raw,
            description=data.get("description", ""),
            author=data.get("author", ""),
            mid=safe_int(data.get("mid", 0)),
            typeid=str(data.get("typeid", "")),
            typename=data.get("typename", ""),
            arcurl=data.get("arcurl", ""),
            pic=data.get("pic", ""),
            play=safe_int(data.get("play", 0)),
            video_review=safe_int(data.get("video_review", 0)),
            favorites=safe_int(data.get("favorites", 0)),
            tag=data.get("tag", ""),
            review=safe_int(data.get("review", 0)),
            pubdate=safe_int(data.get("pubdate", 0)),
            senddate=safe_int(data.get("senddate", 0)),
            duration=data.get("duration", ""),
            hit_columns=data.get("hit_columns", []) or [],
            rank_score=safe_int(data.get("rank_score", 0)),
            is_pay=safe_int(data.get("is_pay", 0)),
            is_union_video=safe_int(data.get("is_union_video", 0)),
            like=safe_int(data.get("like", 0)),
            coin=safe_int(data.get("coin", 0)),
        )

    def summary(self) -> str:
        return (
            f"[{self.bvid}] {self.title}\n"
            f"  UP: {self.author} (mid={self.mid})  分区: {self.typename}\n"
            f"  播放: {self.play}  弹幕: {self.video_review}  收藏: {self.favorites}  评论: {self.review}\n"
            f"  时长: {self.duration}  发布: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.pubdate))}"
        )


@dataclass
class MediaItem:
    type: str = ""
    media_id: int = 0
    season_id: int = 0
    title: str = ""
    title_raw: str = ""
    org_title: str = ""
    cover: str = ""
    media_type: int = 0
    areas: str = ""
    styles: str = ""
    cv: str = ""
    staff: str = ""
    goto_url: str = ""
    desc: str = ""
    pubtime: int = 0
    media_score: dict | None = None
    season_type_name: str = ""
    ep_size: int = 0
    eps: list[dict] = field(default_factory=list)
    hit_columns: list[str] = field(default_factory=list)
    url: str = ""
    badges: list[dict] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "MediaItem":
        title_raw = data.get("title", "")
        return cls(
            type=data.get("type", ""),
            media_id=safe_int(data.get("media_id", 0)),
            season_id=safe_int(data.get("season_id", 0)),
            title=strip_html_tags(title_raw) or "",
            title_raw=title_raw,
            org_title=strip_html_tags(data.get("org_title", "")) or "",
            cover=data.get("cover", ""),
            media_type=safe_int(data.get("media_type", 0)),
            areas=data.get("areas", ""),
            styles=data.get("styles", ""),
            cv=data.get("cv", ""),
            staff=data.get("staff", ""),
            goto_url=data.get("goto_url", ""),
            desc=data.get("desc", ""),
            pubtime=safe_int(data.get("pubtime", 0)),
            media_score=data.get("media_score"),
            season_type_name=data.get("season_type_name", ""),
            ep_size=safe_int(data.get("ep_size", 0)),
            eps=data.get("eps", []) or [],
            hit_columns=data.get("hit_columns", []) or [],
            url=data.get("url", ""),
            badges=data.get("badges", []) or [],
        )

    @property
    def media_type_name(self) -> str:
        media_types = {1: "番剧", 2: "电影", 3: "纪录片", 4: "国创", 5: "电视剧", 7: "综艺"}
        return media_types.get(self.media_type, f"未知({self.media_type})")

    @property
    def score(self) -> float | None:
        if self.media_score and isinstance(self.media_score, dict):
            return self.media_score.get("score")
        return None

    @property
    def score_count(self) -> int:
        if self.media_score and isinstance(self.media_score, dict):
            return safe_int(self.media_score.get("user_count", 0))
        return 0

    def summary(self) -> str:
        score_str = f"  评分: {self.score} ({self.score_count}人)" if self.score else ""
        return (
            f"[{self.media_type_name}] {self.title}\n"
            f"  ssid={self.season_id}  地区: {self.areas}  风格: {self.styles}\n"
            f"  集数: {self.ep_size}  类型: {self.season_type_name}{score_str}"
        )


@dataclass
class LiveRoomItem:
    type: str = "live_room"
    roomid: int = 0
    uid: int = 0
    title: str = ""
    title_raw: str = ""
    uname: str = ""
    uface: str = ""
    cover: str = ""
    user_cover: str = ""
    online: int = 0
    attentions: int = 0
    cate_name: str = ""
    live_time: str = ""
    tags: str = ""
    hit_columns: list[str] = field(default_factory=list)
    rank_score: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "LiveRoomItem":
        title_raw = data.get("title", "")
        return cls(
            type=data.get("type", "live_room"),
            roomid=safe_int(data.get("roomid", 0)),
            uid=safe_int(data.get("uid", 0)),
            title=strip_html_tags(title_raw) or "",
            title_raw=title_raw,
            uname=data.get("uname", ""),
            uface=data.get("uface", ""),
            cover=data.get("cover", ""),
            user_cover=data.get("user_cover", ""),
            online=safe_int(data.get("online", 0)),
            attentions=safe_int(data.get("attentions", 0)),
            cate_name=data.get("cate_name", ""),
            live_time=data.get("live_time", ""),
            tags=data.get("tags", ""),
            hit_columns=data.get("hit_columns", []) or [],
            rank_score=safe_int(data.get("rank_score", 0)),
        )

    def summary(self) -> str:
        return (
            f"[直播间 {self.roomid}] {self.title}\n"
            f"  主播: {self.uname} (uid={self.uid})  分区: {self.cate_name}\n"
            f"  在线: {self.online}  粉丝: {self.attentions}"
        )


@dataclass
class LiveUserItem:
    type: str = "live_user"
    uid: int = 0
    uname: str = ""
    uname_raw: str = ""
    uface: str = ""
    is_live: bool = False
    live_status: int = 0
    roomid: int = 0
    attentions: int = 0
    tags: str = ""
    live_time: str = ""
    hit_columns: list[str] = field(default_factory=list)
    rank_score: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "LiveUserItem":
        uname_raw = data.get("uname", "")
        return cls(
            type=data.get("type", "live_user"),
            uid=safe_int(data.get("uid", 0)),
            uname=strip_html_tags(uname_raw) or "",
            uname_raw=uname_raw,
            uface=data.get("uface", ""),
            is_live=bool(data.get("is_live", False)),
            live_status=safe_int(data.get("live_status", 0)),
            roomid=safe_int(data.get("roomid", 0)),
            attentions=safe_int(data.get("attentions", 0)),
            tags=data.get("tags", ""),
            live_time=data.get("live_time", ""),
            hit_columns=data.get("hit_columns", []) or [],
            rank_score=safe_int(data.get("rank_score", 0)),
        )

    def summary(self) -> str:
        status = "直播中" if self.is_live else "未开播"
        return (
            f"[主播] {self.uname} (uid={self.uid})\n"
            f"  状态: {status}  房间: {self.roomid}  粉丝: {self.attentions}"
        )


@dataclass
class ArticleItem:
    type: str = "article"
    id: int = 0
    title: str = ""
    title_raw: str = ""
    mid: int = 0
    desc: str = ""
    image_urls: list[str] = field(default_factory=list)
    view: int = 0
    like: int = 0
    reply: int = 0
    pub_time: int = 0
    category_name: str = ""
    category_id: int = 0
    rank_score: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "ArticleItem":
        title_raw = data.get("title", "")
        return cls(
            type=data.get("type", "article"),
            id=safe_int(data.get("id", 0)),
            title=strip_html_tags(title_raw) or "",
            title_raw=title_raw,
            mid=safe_int(data.get("mid", 0)),
            desc=data.get("desc", ""),
            image_urls=data.get("image_urls", []) or [],
            view=safe_int(data.get("view", 0)),
            like=safe_int(data.get("like", 0)),
            reply=safe_int(data.get("reply", 0)),
            pub_time=safe_int(data.get("pub_time", 0)),
            category_name=data.get("category_name", ""),
            category_id=safe_int(data.get("category_id", 0)),
            rank_score=safe_int(data.get("rank_score", 0)),
        )

    def summary(self) -> str:
        return (
            f"[专栏 cv{self.id}] {self.title}\n"
            f"  分区: {self.category_name}  阅读: {self.view}  点赞: {self.like}  评论: {self.reply}"
        )


@dataclass
class TopicItem:
    type: str = "topic"
    tp_id: int = 0
    title: str = ""
    title_raw: str = ""
    description: str = ""
    author: str = ""
    cover: str = ""
    arcurl: str = ""
    click: int = 0
    pubdate: int = 0
    update: int = 0
    hit_columns: list[str] = field(default_factory=list)
    rank_score: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "TopicItem":
        title_raw = data.get("title", "")
        return cls(
            type=data.get("type", "topic"),
            tp_id=safe_int(data.get("tp_id", 0)),
            title=strip_html_tags(title_raw) or "",
            title_raw=title_raw,
            description=data.get("description", ""),
            author=data.get("author", ""),
            cover=data.get("cover", ""),
            arcurl=data.get("arcurl", ""),
            click=safe_int(data.get("click", 0)),
            pubdate=safe_int(data.get("pubdate", 0)),
            update=safe_int(data.get("update", 0)),
            hit_columns=data.get("hit_columns", []) or [],
            rank_score=safe_int(data.get("rank_score", 0)),
        )

    def summary(self) -> str:
        return f"[话题 tp{self.tp_id}] {self.title}\n  作者: {self.author}  点击: {self.click}"


@dataclass
class UserItem:
    type: str = "bili_user"
    mid: int = 0
    uname: str = ""
    usign: str = ""
    fans: int = 0
    videos: int = 0
    upic: str = ""
    level: int = 0
    gender: int = 0
    is_upuser: int = 0
    is_live: int = 0
    room_id: int = 0
    official_verify: dict | None = None
    res: list[dict] = field(default_factory=list)
    hit_columns: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "UserItem":
        return cls(
            type=data.get("type", "bili_user"),
            mid=safe_int(data.get("mid", 0)),
            uname=data.get("uname", ""),
            usign=data.get("usign", ""),
            fans=safe_int(data.get("fans", 0)),
            videos=safe_int(data.get("videos", 0)),
            upic=data.get("upic", ""),
            level=safe_int(data.get("level", 0)),
            gender=safe_int(data.get("gender", 0)),
            is_upuser=safe_int(data.get("is_upuser", 0)),
            is_live=safe_int(data.get("is_live", 0)),
            room_id=safe_int(data.get("room_id", 0)),
            official_verify=data.get("official_verify"),
            res=data.get("res", []) or [],
            hit_columns=data.get("hit_columns", []) or [],
        )

    @property
    def gender_str(self) -> str:
        return {1: "男", 2: "女", 3: "私密"}.get(self.gender, "未知")

    @property
    def verify_desc(self) -> str:
        if self.official_verify and isinstance(self.official_verify, dict):
            return self.official_verify.get("desc", "")
        return ""

    def summary(self) -> str:
        verify = f"  认证: {self.verify_desc}" if self.verify_desc else ""
        return (
            f"[用户] {self.uname} (mid={self.mid})\n"
            f"  等级: {self.level}  粉丝: {self.fans}  投稿: {self.videos}{verify}"
        )


@dataclass
class PhotoItem:
    type: str = "photo"
    id: int = 0
    title: str = ""
    title_raw: str = ""
    cover: str = ""
    count: int = 0
    mid: int = 0
    uname: str = ""
    view: int = 0
    like: int = 0
    hit_columns: list[str] = field(default_factory=list)
    rank_score: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "PhotoItem":
        title_raw = data.get("title", "")
        return cls(
            type=data.get("type", "photo"),
            id=safe_int(data.get("id", 0)),
            title=strip_html_tags(title_raw) or "",
            title_raw=title_raw,
            cover=data.get("cover", ""),
            count=safe_int(data.get("count", 0)),
            mid=safe_int(data.get("mid", 0)),
            uname=data.get("uname", ""),
            view=safe_int(data.get("view", 0)),
            like=safe_int(data.get("like", 0)),
            hit_columns=data.get("hit_columns", []) or [],
            rank_score=safe_int(data.get("rank_score", 0)),
        )

    def summary(self) -> str:
        return (
            f"[相簿 {self.id}] {self.title}\n"
            f"  UP: {self.uname}  图片: {self.count}  浏览: {self.view}  收藏: {self.like}"
        )


_ITEM_PARSERS: dict[str, type] = {
    "video": VideoItem,
    "media_bangumi": MediaItem,
    "media_ft": MediaItem,
    "live_room": LiveRoomItem,
    "live_user": LiveUserItem,
    "article": ArticleItem,
    "topic": TopicItem,
    "bili_user": UserItem,
    "photo": PhotoItem,
}


def parse_result_items(result_type: str, data_list: list[dict]) -> list:
    parser_class = _ITEM_PARSERS.get(result_type)
    if parser_class is None:
        return data_list
    return [parser_class.from_dict(item) for item in data_list if item]


@dataclass
class PageInfo:
    num_results: int = 0
    total: int = 0
    pages: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "PageInfo":
        return cls(
            num_results=safe_int(data.get("numResults", 0)),
            total=safe_int(data.get("total", 0)),
            pages=safe_int(data.get("pages", 0)),
        )


class SearchAllResult:
    def __init__(self, raw: dict):
        self.raw = raw
        self.code = raw.get("code", -1)
        self.message = raw.get("message", "")

        data = raw.get("data") or {}
        self.seid = str(data.get("seid", ""))
        self.page = safe_int(data.get("page", 1))
        self.page_size = safe_int(data.get("pagesize", 20))
        self.num_results = safe_int(data.get("numResults", 0))
        self.num_pages = safe_int(data.get("numPages", 0))
        self.suggest_keyword = data.get("suggest_keyword", "")
        self.cost_time = data.get("cost_time", {})
        self.top_tlist = data.get("top_tlist", {}) or {}
        self.pageinfo: dict[str, PageInfo] = {}
        raw_pageinfo = data.get("pageinfo", {}) or {}
        for key, value in raw_pageinfo.items():
            if isinstance(value, dict):
                self.pageinfo[key] = PageInfo.from_dict(value)

        self.videos: list[VideoItem] = []
        self.media_bangumi: list[MediaItem] = []
        self.media_ft: list[MediaItem] = []
        self.live_rooms: list[LiveRoomItem] = []
        self.live_users: list[LiveUserItem] = []
        self.articles: list[ArticleItem] = []
        self.topics: list[TopicItem] = []
        self.users: list[UserItem] = []
        self.photos: list[PhotoItem] = []
        self.other_results: dict[str, list] = {}
        self._parse_results(data.get("result", []) or [])

    def _parse_results(self, results: list[dict]) -> None:
        attr_map = {
            "video": "videos",
            "media_bangumi": "media_bangumi",
            "media_ft": "media_ft",
            "live_room": "live_rooms",
            "live_user": "live_users",
            "article": "articles",
            "topic": "topics",
            "bili_user": "users",
            "photo": "photos",
        }
        for group in results:
            if not isinstance(group, dict):
                continue
            result_type = group.get("result_type", "")
            data_list = group.get("data", []) or []
            if not data_list:
                continue
            items = parse_result_items(result_type, data_list)
            attr_name = attr_map.get(result_type)
            if attr_name:
                setattr(self, attr_name, items)
            else:
                self.other_results[result_type] = items

    @property
    def ok(self) -> bool:
        return self.code == 0

    def summary(self) -> str:
        lines = [f"搜索结果 (code={self.code}, num_results={self.num_results}, pages={self.num_pages})"]
        if self.top_tlist:
            counts = {key: value for key, value in self.top_tlist.items() if isinstance(value, (int, float)) and value > 0}
            if counts:
                lines.append(f"  各类数量: {counts}")

        type_counts = {
            "视频": len(self.videos),
            "番剧": len(self.media_bangumi),
            "影视": len(self.media_ft),
            "直播间": len(self.live_rooms),
            "主播": len(self.live_users),
            "专栏": len(self.articles),
            "话题": len(self.topics),
            "用户": len(self.users),
            "相簿": len(self.photos),
        }
        visible_counts = {key: value for key, value in type_counts.items() if value > 0}
        if visible_counts:
            lines.append(f"  本次返回: {visible_counts}")
        return "\n".join(lines)


class SearchTypeResult:
    def __init__(self, raw: dict, search_type: str):
        self.raw = raw
        self.search_type = search_type
        self.code = raw.get("code", -1)
        self.message = raw.get("message", "")
        data = raw.get("data") or {}
        self.seid = str(data.get("seid", ""))
        self.page = safe_int(data.get("page", 1))
        self.page_size = safe_int(data.get("pagesize", 20))
        self.num_results = safe_int(data.get("numResults", 0))
        self.num_pages = safe_int(data.get("numPages", 0))
        self.cost_time = data.get("cost_time", {})
        self.items: list = []
        self.live_rooms: list[LiveRoomItem] = []
        self.live_users: list[LiveUserItem] = []
        self._parse_results(data)

    def _parse_results(self, data: dict) -> None:
        raw_result = data.get("result")
        if raw_result is None:
            return
        if self.search_type == SearchType.LIVE.value:
            if isinstance(raw_result, dict):
                rooms = raw_result.get("live_room", []) or []
                users = raw_result.get("live_user", []) or []
                self.live_rooms = parse_result_items("live_room", rooms)
                self.live_users = parse_result_items("live_user", users)
                self.items = self.live_rooms + self.live_users
            return
        if isinstance(raw_result, list):
            self.items = parse_result_items(self.search_type, raw_result)

    @property
    def ok(self) -> bool:
        return self.code == 0

    def summary(self) -> str:
        return (
            f"分类搜索 [{self.search_type}] (code={self.code}, page={self.page}, "
            f"num_results={self.num_results}, pages={self.num_pages}, items={len(self.items)})"
        )