import argparse
import json

from .client import BiliSearcher
from .enums import SearchType


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="blux search", description="Bilibili search helpers"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    all_parser = subparsers.add_parser("all", help="Run a comprehensive search")
    all_parser.add_argument("keyword")

    type_parser = subparsers.add_parser("type", help="Run a typed search")
    type_parser.add_argument("keyword")
    type_parser.add_argument(
        "--type",
        default=SearchType.VIDEO.value,
        choices=[item.value for item in SearchType],
    )
    type_parser.add_argument("--page", type=int, default=1)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    searcher = BiliSearcher()
    if args.command == "all":
        result = searcher.search_all(args.keyword)
        print(result.summary())
        return 0
    if args.command == "type":
        result = searcher.search_by_type(
            args.keyword, search_type=args.type, page=args.page
        )
        print(result.summary())
        items = [
            item.__dict__ if hasattr(item, "__dict__") else item
            for item in result.items[:5]
        ]
        print(json.dumps(items, ensure_ascii=False, indent=2))
        return 0
    raise ValueError(f"Unsupported command: {args.command}")
