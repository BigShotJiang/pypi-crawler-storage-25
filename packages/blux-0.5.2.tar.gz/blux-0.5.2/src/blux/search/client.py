from typing import Any

import requests
from tclogger import logger, logstr

from blux.wbi import DmImgParams, REQUESTS_HEADERS, WbiSigner

from .enums import SearchOrder, SearchType, UserType, VideoDuration
from .models import SearchAllResult, SearchTypeResult


class BiliSearcher:
    SEARCH_ALL_URL = "https://api.bilibili.com/x/web-interface/wbi/search/all/v2"
    SEARCH_TYPE_URL = "https://api.bilibili.com/x/web-interface/wbi/search/type"
    BILIBILI_HOME = "https://www.bilibili.com"

    def __init__(self, sessdata: str = "", session: requests.Session | None = None, timeout: int = 15):
        self.timeout = timeout
        self.wbi_signer = WbiSigner(referer=self.BILIBILI_HOME)
        self.dm_params = DmImgParams()
        self.session = session or requests.Session()
        self.session.headers.update({**REQUESTS_HEADERS, "Referer": self.BILIBILI_HOME})
        if sessdata:
            self.session.cookies.set("SESSDATA", sessdata, domain=".bilibili.com")
        self._cookies_initialized = False

    def _ensure_cookies(self) -> None:
        if self._cookies_initialized:
            return
        try:
            response = self.session.get(self.BILIBILI_HOME, timeout=self.timeout)
            response.raise_for_status()
            self._cookies_initialized = True
            cookie_names = list(self.session.cookies.keys())
            logger.success(f"获取 Cookie 成功: {logstr.mesg(', '.join(cookie_names))}")
        except Exception as exc:
            logger.warn(f"获取 Cookie 失败: {exc}")

    def _build_signed_params(self, params: dict) -> dict:
        full_params = {**params, **self.dm_params.get()}
        return self.wbi_signer.sign(full_params)

    def _request_json(self, url: str, params: dict) -> dict:
        try:
            response = self.session.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except Exception as exc:
            logger.err(f"搜索请求失败: {exc}")
            return {"code": -1, "message": str(exc)}

    def search_all(self, keyword: str, **extra_params) -> SearchAllResult:
        self._ensure_cookies()
        signed = self._build_signed_params({"keyword": keyword, **extra_params})
        logger.note(f"> 综合搜索: keyword={logstr.mesg(keyword)}")
        result = SearchAllResult(self._request_json(self.SEARCH_ALL_URL, signed))
        if result.ok:
            logger.success(f"  {result.summary()}")
        else:
            logger.warn(f"  搜索失败: code={result.code}, message={result.message}")
        return result

    def search_by_type(
        self,
        keyword: str,
        search_type: str | SearchType = SearchType.VIDEO,
        order: str | SearchOrder = "",
        page: int = 1,
        duration: int | VideoDuration = 0,
        tids: int = 0,
        order_sort: int = 0,
        user_type: int | UserType = 0,
        category_id: int = 0,
        **extra_params,
    ) -> SearchTypeResult:
        self._ensure_cookies()
        resolved_type = search_type.value if isinstance(search_type, SearchType) else search_type
        params: dict[str, Any] = {"keyword": keyword, "search_type": resolved_type, "page": page}
        if order:
            params["order"] = order.value if isinstance(order, SearchOrder) else order
        if duration:
            params["duration"] = duration.value if isinstance(duration, VideoDuration) else duration
        if tids:
            params["tids"] = tids
        if order_sort:
            params["order_sort"] = order_sort
        if user_type:
            params["user_type"] = user_type.value if isinstance(user_type, UserType) else user_type
        if category_id:
            params["category_id"] = category_id
        params.update(extra_params)
        signed = self._build_signed_params(params)

        logger.note(
            f"> 分类搜索: keyword={logstr.mesg(keyword)}, type={logstr.mesg(resolved_type)}, page={page}"
        )

        result = SearchTypeResult(self._request_json(self.SEARCH_TYPE_URL, signed), resolved_type)
        if result.ok:
            logger.success(f"  {result.summary()}")
        else:
            logger.warn(f"  搜索失败: code={result.code}, message={result.message}")
        return result

    def search_videos(
        self,
        keyword: str,
        order: str | SearchOrder = SearchOrder.TOTALRANK,
        page: int = 1,
        duration: int | VideoDuration = VideoDuration.ALL,
        tids: int = 0,
        **extra_params,
    ) -> SearchTypeResult:
        return self.search_by_type(
            keyword=keyword,
            search_type=SearchType.VIDEO,
            order=order,
            page=page,
            duration=duration,
            tids=tids,
            **extra_params,
        )

    def search_users(
        self,
        keyword: str,
        order: str | SearchOrder = SearchOrder.DEFAULT,
        order_sort: int = 0,
        user_type: int | UserType = UserType.ALL,
        page: int = 1,
        **extra_params,
    ) -> SearchTypeResult:
        return self.search_by_type(
            keyword=keyword,
            search_type=SearchType.BILI_USER,
            order=order,
            order_sort=order_sort,
            user_type=user_type,
            page=page,
            **extra_params,
        )

    def search_media_bangumi(self, keyword: str, page: int = 1, **extra_params) -> SearchTypeResult:
        return self.search_by_type(
            keyword=keyword,
            search_type=SearchType.MEDIA_BANGUMI,
            page=page,
            **extra_params,
        )

    def search_media_ft(self, keyword: str, page: int = 1, **extra_params) -> SearchTypeResult:
        return self.search_by_type(
            keyword=keyword,
            search_type=SearchType.MEDIA_FT,
            page=page,
            **extra_params,
        )

    def search_articles(self, keyword: str, page: int = 1, **extra_params) -> SearchTypeResult:
        return self.search_by_type(
            keyword=keyword,
            search_type=SearchType.ARTICLE,
            page=page,
            **extra_params,
        )