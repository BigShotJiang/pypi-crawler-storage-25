from enum import Enum


class SearchType(str, Enum):
    VIDEO = "video"
    MEDIA_BANGUMI = "media_bangumi"
    MEDIA_FT = "media_ft"
    LIVE = "live"
    LIVE_ROOM = "live_room"
    LIVE_USER = "live_user"
    ARTICLE = "article"
    TOPIC = "topic"
    BILI_USER = "bili_user"
    PHOTO = "photo"


class SearchOrder(str, Enum):
    TOTALRANK = "totalrank"
    CLICK = "click"
    PUBDATE = "pubdate"
    DM = "dm"
    STOW = "stow"
    SCORES = "scores"
    ATTENTION = "attention"
    ONLINE = "online"
    LIVE_TIME = "live_time"
    DEFAULT = "0"
    FANS = "fans"
    LEVEL = "level"


class VideoDuration(int, Enum):
    ALL = 0
    UNDER_10MIN = 1
    TEN_TO_30MIN = 2
    THIRTY_TO_60MIN = 3
    OVER_60MIN = 4


class UserType(int, Enum):
    ALL = 0
    UP = 1
    NORMAL = 2
    VERIFIED = 3