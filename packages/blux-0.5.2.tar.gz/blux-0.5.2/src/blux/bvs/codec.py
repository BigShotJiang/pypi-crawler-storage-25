XOR_CODE = 23442827791579
MASK_CODE = 2251799813685247

MIN_AID = 1
MAX_AID = 1 << 51

BASE = 58
BV_LEN = 12
PREFIX = "BV1"

ALPHABET = "FcwAPNKTMug3GV5Lj7EJnHpWsx4tb8haYeviqBz6rkCy12mUSDQX9RdoZf"
REV = {ch: index for index, ch in enumerate(ALPHABET)}


def check_aid_range(aid: int) -> None:
    if aid < MIN_AID or aid >= MAX_AID:
        raise ValueError(f"Invalid aid: {aid}, must be in range [{MIN_AID}, {MAX_AID})")


def check_bv_format(bv: str) -> None:
    if not bv:
        raise ValueError("Invalid bv: got empty")
    if len(bv) != BV_LEN:
        raise ValueError(f"Invalid bv: got str length {len(bv)}, must be {BV_LEN}")
    if bv[:3].upper() != PREFIX:
        raise ValueError(f"Invalid bv: got prefix '{bv[:3]}', must be '{PREFIX}'")


def check_bv_chars(bv: str) -> None:
    for char in bv:
        if char not in REV:
            raise ValueError(f"Invalid bv: got char {char}")


def check_bv_int_len(bv_int: int) -> None:
    bit_length = bv_int.bit_length()
    if bit_length != 52:
        raise ValueError(f"Invalid bv: got bits in binary: {bit_length}, must be 52")


def swap_bv_chars(chars: list[str]) -> None:
    chars[3], chars[9] = chars[9], chars[3]
    chars[4], chars[7] = chars[7], chars[4]


def av_to_bv(aid: int) -> str:
    check_aid_range(aid)
    chars = list("BV1000000000")
    index = BV_LEN - 1
    value = (MAX_AID | aid) ^ XOR_CODE
    while value != 0:
        table_index = value % BASE
        chars[index] = ALPHABET[table_index]
        value //= BASE
        index -= 1
    swap_bv_chars(chars)
    return "".join(chars)


def bv_to_av(bv: str) -> int:
    check_bv_format(bv)
    check_bv_chars(bv)
    chars = list(bv)
    swap_bv_chars(chars)
    value = 0
    for char in chars[3:]:
        value = value * BASE + REV[char]
    check_bv_int_len(value)
    aid = (value & MASK_CODE) ^ XOR_CODE
    check_aid_range(aid)
    return aid
