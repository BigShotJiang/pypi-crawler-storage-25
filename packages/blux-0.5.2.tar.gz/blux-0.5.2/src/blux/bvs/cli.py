import argparse

from .codec import av_to_bv, bv_to_av


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="blux bv", description="AV/BV conversion tools"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    av_parser = subparsers.add_parser("av-to-bv", help="Convert AV id to BV id")
    av_parser.add_argument("aid", type=int)

    bv_parser = subparsers.add_parser("bv-to-av", help="Convert BV id to AV id")
    bv_parser.add_argument("bvid")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "av-to-bv":
        print(av_to_bv(args.aid))
        return 0
    if args.command == "bv-to-av":
        print(bv_to_av(args.bvid))
        return 0
    raise ValueError(f"Unsupported command: {args.command}")
