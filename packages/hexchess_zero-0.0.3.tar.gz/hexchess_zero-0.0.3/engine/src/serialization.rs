//! Board-to-tensor encoding, move-to-index bijection, and training record
//! serialization for the hexagonal chess neural network pipeline.

use std::collections::BTreeSet;
use std::sync::LazyLock;

use crate::board::{
    CARDINAL_DIRS, Color, DIAGONAL_DIRS, HexCoord, KNIGHT_OFFSETS, PROMOTION_PIECES, PieceKind,
};
use crate::game::GameState;
use crate::movegen::{self, Move};

// ---------------------------------------------------------------------------
// Board-to-tensor encoding
// ---------------------------------------------------------------------------

pub const NUM_CHANNELS: usize = 22;
pub const BOARD_DIM: usize = 11;
pub const TENSOR_SIZE: usize = NUM_CHANNELS * BOARD_DIM * BOARD_DIM;

/// Encode a game state as a flat f32 tensor in CHW layout, in **side-to-move
/// frame**.
///
/// The 91-cell hex grid is embedded into an 11x11 rectangular array using
/// `col = q + 5`, `row = r + 5`. Invalid cells are zero-padded.
///
/// ## Side-to-move frame
///
/// The position is always encoded from the perspective of the player whose
/// turn it is ("STM"):
///
/// - Piece planes 0-5 are **STM pieces** (my side), planes 6-11 are **opponent
///   pieces**. When white is to move this matches the absolute layout; when
///   black is to move the color roles are swapped.
/// - When black is to move, every spatial coordinate is additionally passed
///   through the central-inversion involution `(q, r) → (-q, -r)` before
///   embedding into the 11x11 grid. This is the unique hex symmetry that
///   maps white pawn directions to black pawn directions and white promotion
///   cells to black promotion cells (see `mirror_coord`). Combined with the
///   color swap, the result is a board where the network always sees "my
///   pawns moving in +r toward my promotion edge", regardless of absolute
///   color.
///
/// This means the encoder absorbs the entire color symmetry of the game —
/// the network does not need to learn that white and black are equivalent,
/// and mirror augmentation becomes unnecessary (the symmetry is already
/// baked into the encoding).
///
/// Policy vector semantics are defined in the same frame: see
/// [`stm_policy_index`] for converting an absolute `Move` to its STM-relative
/// move index.
///
/// Channels:
///  0: STM Pawn      1: STM Knight     2: STM Bishop
///  3: STM Rook      4: STM Queen      5: STM King
///  6: Opp Pawn      7: Opp Knight     8: Opp Bishop
///  9: Opp Rook     10: Opp Queen     11: Opp King
/// 12: Absolute side-to-move (1.0 = white, 0.0 = black; constant plane).
///     Redundant in STM frame but kept as a cheap signal for the network.
/// 13: Move count (fullmove_number / 100.0; constant plane)
/// 14: Halfmove clock (halfmove_clock / 100.0; constant plane)
/// 15: En passant target (1.0 on the target cell, 0.0 elsewhere; STM-framed)
/// 16: Repetition count (0.0 / 1.0 / 2.0; constant plane)
/// 17: Validity mask (1.0 on 91 valid hex cells, 0.0 on padding). Invariant
///     under central inversion, so identical in both frames.
/// 18: In check (1.0 if side to move is in check; constant plane)
/// 19: Last move from-square (1.0 at source of most recent move; STM-framed)
/// 20: Last move to-square (1.0 at destination of most recent move; STM-framed)
/// 21: Plies-since-pawn-move (halfmove_clock / 50, clamped to [0, 1]; constant
///     plane). NOTE: we reuse the board's halfmove clock, which in this engine
///     resets on pawn moves OR captures (standard halfmove-clock semantics).
///     The plan specifies "plies since pawn move" but we deliberately reuse
///     halfmove_clock here rather than adding new state — the two signals are
///     highly correlated and the net can learn the difference if it matters.
pub fn encode_board(state: &GameState) -> [f32; TENSOR_SIZE] {
    let board = &state.board;
    let mut tensor = [0.0f32; TENSOR_SIZE];
    let stm = board.side_to_move;

    // Helper: index into the flat CHW tensor.
    let idx = |channel: usize, col: usize, row: usize| -> usize {
        channel * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col
    };

    // Helper: transform an absolute hex coord into STM frame.
    // Identity for white-to-move; central inversion for black-to-move.
    let to_stm = |c: HexCoord| -> HexCoord {
        match stm {
            Color::White => c,
            Color::Black => mirror_coord(c),
        }
    };

    // Piece planes (channels 0-11) and validity mask (channel 17).
    for q in -5i8..=5 {
        for r in -5i8..=5 {
            let coord = HexCoord::new(q, r);
            if !coord.is_valid() {
                continue;
            }
            let stm_coord = to_stm(coord);
            let col = (stm_coord.q + 5) as usize;
            let row = (stm_coord.r + 5) as usize;

            // Validity mask (channel 17). Central inversion preserves
            // is_valid() for every cell, so this is identical in both frames.
            tensor[idx(17, col, row)] = 1.0;

            if let Some(piece) = board.get(coord) {
                let channel = stm_piece_channel(piece.color, piece.kind, stm);
                tensor[idx(channel, col, row)] = 1.0;
            }
        }
    }

    // Absolute side-to-move (channel 12): constant plane. Redundant in STM
    // frame but kept as a cheap signal — 1.0 for white-to-move, 0.0 for black.
    let side_val = match stm {
        Color::White => 1.0f32,
        Color::Black => 0.0f32,
    };
    for row in 0..BOARD_DIM {
        for col in 0..BOARD_DIM {
            tensor[idx(12, col, row)] = side_val;
        }
    }

    // Move count (channel 13): constant plane.
    let move_val = board.fullmove_number as f32 / 100.0;
    for row in 0..BOARD_DIM {
        for col in 0..BOARD_DIM {
            tensor[idx(13, col, row)] = move_val;
        }
    }

    // Halfmove clock (channel 14): constant plane.
    let half_val = board.halfmove_clock as f32 / 100.0;
    for row in 0..BOARD_DIM {
        for col in 0..BOARD_DIM {
            tensor[idx(14, col, row)] = half_val;
        }
    }

    // En passant (channel 15): single cell, mapped through STM frame.
    if let Some(ep) = board.en_passant
        && ep.is_valid()
    {
        let stm_ep = to_stm(ep);
        let col = (stm_ep.q + 5) as usize;
        let row = (stm_ep.r + 5) as usize;
        tensor[idx(15, col, row)] = 1.0;
    }

    // Repetition count (channel 16): constant plane.
    let rep_val = state.repetition_count().min(2) as f32;
    if rep_val > 0.0 {
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                tensor[idx(16, col, row)] = rep_val;
            }
        }
    }

    // In check (channel 18): constant plane. "STM in check" is invariant
    // under the STM-frame transformation (both kings and attackers are
    // inverted and color-swapped together).
    if movegen::is_in_check(board, stm) {
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                tensor[idx(18, col, row)] = 1.0;
            }
        }
    }

    // Last-move from/to (channels 19, 20), mapped through STM frame.
    if let Some(mv) = state.last_move() {
        if mv.from.is_valid() {
            let stm_from = to_stm(mv.from);
            let col = (stm_from.q + 5) as usize;
            let row = (stm_from.r + 5) as usize;
            tensor[idx(19, col, row)] = 1.0;
        }
        if mv.to.is_valid() {
            let stm_to = to_stm(mv.to);
            let col = (stm_to.q + 5) as usize;
            let row = (stm_to.r + 5) as usize;
            tensor[idx(20, col, row)] = 1.0;
        }
    }

    // Plies-since-pawn-move (channel 21): constant plane, halfmove_clock / 50
    // clamped to [0, 1]. See the channel doc comment above for why we reuse
    // halfmove_clock directly.
    let pspm = (board.halfmove_clock as f32 / 50.0).clamp(0.0, 1.0);
    if pspm > 0.0 {
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                tensor[idx(21, col, row)] = pspm;
            }
        }
    }

    tensor
}

/// Map `(piece_color, piece_kind, side_to_move)` to a channel index 0..11
/// in STM frame: channels 0-5 are "my" pieces (same color as `stm`), 6-11
/// are opponent pieces.
fn stm_piece_channel(piece_color: Color, kind: PieceKind, stm: Color) -> usize {
    let rel = if piece_color == stm { 0 } else { 1 };
    rel * 6 + kind.index()
}

// ---------------------------------------------------------------------------
// Move-to-index bijection
// ---------------------------------------------------------------------------

/// A canonical (from, to, promotion) tuple for the move index table.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
struct MoveEntry {
    from_idx: u8,                 // 0..90  (cell index of source)
    to_idx: u8,                   // 0..90  (cell index of destination)
    promotion: Option<PieceKind>, // None for non-promotion moves
}

/// Maximum ray length on the board (diameter is 10, so max 10 steps).
const MAX_RAY_LEN: usize = 10;

/// Returns true if `coord` sits on a promotion rank for the given color.
///
/// In Glinski's variant:
/// - White promotes on the far edge (the cells with maximal s = -(q+r) = 5,
///   i.e. q + r == -5). But actually promotion happens on the opponent's back
///   rank. The back rank for black (where white promotes) is the set of cells
///   with r == 5 - max(0, q), essentially the top edge of the hex.
///
/// For white, promotion cells are those on the "top" edge:
///   r = min(5, 5 - q) when q >= 0, i.e. the cells where r is at its maximum
///   for that column.
///
/// For black, promotion cells are those on the "bottom" edge.
///
/// Specifically, a cell (q, r) is on white's promotion rank iff it's valid and
/// there is no valid cell at (q, r+1). Similarly for black at (q, r-1).
///
/// But for move-table generation we just need to know WHICH destination cells
/// are promotion squares for EITHER color. A pawn of either color that reaches
/// the far edge must promote.
fn is_promotion_cell_for_white(coord: HexCoord) -> bool {
    // White promotes on the cells at the maximum r for each column.
    // A valid cell (q, r) is on white's promotion rank if (q, r+1) is invalid.
    coord.is_valid() && !HexCoord::new(coord.q, coord.r + 1).is_valid()
}

fn is_promotion_cell_for_black(coord: HexCoord) -> bool {
    // Black promotes on the cells at the minimum r for each column.
    coord.is_valid() && !HexCoord::new(coord.q, coord.r - 1).is_valid()
}

/// Returns true if `coord` is a promotion cell for either color.
pub fn is_promotion_cell(coord: HexCoord) -> bool {
    is_promotion_cell_for_white(coord) || is_promotion_cell_for_black(coord)
}

/// Build the complete, sorted list of all move entries.
fn build_move_table() -> Vec<MoveEntry> {
    use crate::board::ALL_COORDS;

    // Collect all unique (from, to) pairs reachable by any piece.
    let mut pairs: BTreeSet<(u8, u8)> = BTreeSet::new();
    // Track which (from, to) pairs are pawn moves to promotion cells.
    // Only these get expanded to 4 promotion entries; other moves to
    // promotion cells keep a single non-promotion entry.
    let mut pawn_promo_pairs: BTreeSet<(u8, u8)> = BTreeSet::new();

    for (from_idx, &from_coord) in ALL_COORDS.iter().enumerate() {
        let fi = from_idx as u8;

        // --- Knight jumps ---
        for &(dq, dr) in &KNIGHT_OFFSETS {
            let to = HexCoord::new(from_coord.q + dq, from_coord.r + dr);
            if to.is_valid() {
                let ti = crate::board::coord_to_index(to).unwrap() as u8;
                pairs.insert((fi, ti));
            }
        }

        // --- Sliding rays (cardinal directions for rook/queen) ---
        for &(dq, dr) in &CARDINAL_DIRS {
            for dist in 1..=MAX_RAY_LEN {
                let to = HexCoord::new(
                    from_coord.q + dq * dist as i8,
                    from_coord.r + dr * dist as i8,
                );
                if !to.is_valid() {
                    break;
                }
                let ti = crate::board::coord_to_index(to).unwrap() as u8;
                pairs.insert((fi, ti));
            }
        }

        // --- Sliding rays (diagonal directions for bishop/queen) ---
        for &(dq, dr) in &DIAGONAL_DIRS {
            for dist in 1..=MAX_RAY_LEN {
                let to = HexCoord::new(
                    from_coord.q + dq * dist as i8,
                    from_coord.r + dr * dist as i8,
                );
                if !to.is_valid() {
                    break;
                }
                let ti = crate::board::coord_to_index(to).unwrap() as u8;
                pairs.insert((fi, ti));
            }
        }

        // --- Pawn moves (both colors from this cell) ---
        // White pawn forward: (0, 1), captures: (1, 0) and (-1, 1), double: (0, 2).
        let white_pawn_dests: [(i8, i8); 4] = [(0, 1), (0, 2), (1, 0), (-1, 1)];
        for &(dq, dr) in &white_pawn_dests {
            let to = HexCoord::new(from_coord.q + dq, from_coord.r + dr);
            if to.is_valid() {
                let ti = crate::board::coord_to_index(to).unwrap() as u8;
                pairs.insert((fi, ti));
                if is_promotion_cell_for_white(to) {
                    pawn_promo_pairs.insert((fi, ti));
                }
            }
        }

        // Black pawn forward: (0, -1), captures: (-1, 0) and (1, -1), double: (0, -2).
        let black_pawn_dests: [(i8, i8); 4] = [(0, -1), (0, -2), (-1, 0), (1, -1)];
        for &(dq, dr) in &black_pawn_dests {
            let to = HexCoord::new(from_coord.q + dq, from_coord.r + dr);
            if to.is_valid() {
                let ti = crate::board::coord_to_index(to).unwrap() as u8;
                pairs.insert((fi, ti));
                if is_promotion_cell_for_black(to) {
                    pawn_promo_pairs.insert((fi, ti));
                }
            }
        }
    }

    // Expand (from, to) pairs into MoveEntry values.
    // Pawn promotion pairs get 4 entries (one per promotion piece) instead of
    // the base non-promotion entry. All other pairs get a single non-promotion
    // entry, even if the destination is an edge cell (since non-pawn pieces
    // don't promote).
    let mut entries: Vec<MoveEntry> = Vec::new();

    for &(from_idx, to_idx) in &pairs {
        // Every pair gets a non-promotion entry (for non-pawn pieces that
        // can also reach promotion cells without promoting).
        entries.push(MoveEntry {
            from_idx,
            to_idx,
            promotion: None,
        });
        // Pawn promotion pairs additionally get 4 promotion entries.
        if pawn_promo_pairs.contains(&(from_idx, to_idx)) {
            for &pk in &PROMOTION_PIECES {
                entries.push(MoveEntry {
                    from_idx,
                    to_idx,
                    promotion: Some(pk),
                });
            }
        }
    }

    // Sort deterministically.
    entries.sort();
    entries
}

struct MoveIndex {
    /// Sorted list of all move entries; the index in this vec IS the move index.
    entries: Vec<MoveEntry>,
    /// Reverse lookup: (from_idx, to_idx, promotion_ordinal) -> move index.
    /// promotion_ordinal: 0=None, 1=Queen, 2=Rook, 3=Bishop, 4=Knight
    reverse: std::collections::HashMap<(u8, u8, u8), usize>,
}

fn promotion_ordinal(p: Option<PieceKind>) -> u8 {
    match p {
        None => 0,
        Some(PieceKind::Queen) => 1,
        Some(PieceKind::Rook) => 2,
        Some(PieceKind::Bishop) => 3,
        Some(PieceKind::Knight) => 4,
        Some(_) => unreachable!("only Q/R/B/N are valid promotion pieces"),
    }
}

static MOVE_INDEX: LazyLock<MoveIndex> = LazyLock::new(|| {
    let entries = build_move_table();
    let mut reverse = std::collections::HashMap::with_capacity(entries.len());
    for (i, e) in entries.iter().enumerate() {
        let key = (e.from_idx, e.to_idx, promotion_ordinal(e.promotion));
        reverse.insert(key, i);
    }
    MoveIndex { entries, reverse }
});

/// Total number of move indices in the policy vector.
///
/// This is computed once at startup and cached.
pub fn num_move_indices() -> usize {
    MOVE_INDEX.entries.len()
}

/// Convert a `Move` to a policy-vector index.
///
/// Returns `None` if the move is not in the table.
pub fn move_to_index(mv: &Move) -> Option<usize> {
    let fi = crate::board::coord_to_index(mv.from)? as u8;
    let ti = crate::board::coord_to_index(mv.to)? as u8;
    let po = promotion_ordinal(mv.promotion);
    MOVE_INDEX.reverse.get(&(fi, ti, po)).copied()
}

/// Involution on hex coords used for move-table mirroring: the 180-degree
/// rotation `(q, r) → (-q, -r)`.
///
/// We use central inversion rather than a pure left-right reflection because
/// the move table distinguishes pawn-promotion pairs (which expand to four
/// indices) from non-promotion pairs. Central inversion is the unique hex
/// symmetry that maps white pawn directions to black pawn directions AND
/// white promotion cells to black promotion cells, so a white-promo pair
/// mirrors cleanly to a black-promo pair (both have the 4 promotion
/// entries). A left-right reflection does NOT preserve the set of
/// pawn-promotion pairs because promotion cells live on the top/bottom
/// edges of the hex, which reflections across a vertical axis do not map
/// onto each other.
///
/// Involution: applying it twice yields the original coord.
/// Validity-preserving: negating both `q` and `r` also negates `s = -q - r`,
/// so `max(|q|, |r|, |s|)` is unchanged.
pub fn mirror_coord(c: HexCoord) -> HexCoord {
    HexCoord::new(-c.q, -c.r)
}

/// Move-index → mirrored move-index lookup table.
///
/// Built once at startup from `MOVE_INDEX`: each entry `MIRROR_INDEX[i]` is
/// the index of the move obtained by applying central inversion
/// `(q, r) → (-q, -r)` to both the `from` and `to` cells of move `i`, with
/// the promotion piece unchanged. See [`mirror_coord`] for why central
/// inversion (rather than a pure reflection) is the correct involution
/// here.
static MIRROR_INDEX: LazyLock<Vec<usize>> = LazyLock::new(|| {
    let n = MOVE_INDEX.entries.len();
    let mut out = vec![0usize; n];
    for (i, e) in MOVE_INDEX.entries.iter().enumerate() {
        let from = crate::board::index_to_coord(e.from_idx as usize);
        let to = crate::board::index_to_coord(e.to_idx as usize);
        let mfrom = mirror_coord(from);
        let mto = mirror_coord(to);
        let mfi = crate::board::coord_to_index(mfrom)
            .expect("mirror_coord must land on a valid cell") as u8;
        let mti = crate::board::coord_to_index(mto).expect("mirror_coord must land on a valid cell")
            as u8;
        let key = (mfi, mti, promotion_ordinal(e.promotion));
        out[i] = *MOVE_INDEX
            .reverse
            .get(&key)
            .expect("mirrored move must also be in the move table");
    }
    out
});

/// Return the mirrored move index corresponding to `idx`.
pub fn mirror_move_index(idx: usize) -> usize {
    MIRROR_INDEX[idx]
}

/// Return the full mirror-index lookup table as a slice.
pub fn mirror_indices() -> &'static [usize] {
    &MIRROR_INDEX
}

/// Return the **STM-relative** policy-vector index for a move in a position
/// with the given side-to-move.
///
/// This is the correct helper to pair with [`encode_board`], which produces
/// tensors in STM frame. When white is to move the result is identical to
/// [`move_to_index`]; when black is to move the result is the mirrored
/// index, so that a black pawn push `(q, r) → (q, r-1)` lands on the same
/// policy slot as the corresponding white pawn push under central inversion.
///
/// Returns `None` if the absolute move is not in the move-index table.
pub fn stm_policy_index(mv: &Move, stm: Color) -> Option<usize> {
    let abs = move_to_index(mv)?;
    Some(match stm {
        Color::White => abs,
        Color::Black => MIRROR_INDEX[abs],
    })
}

/// Convert a policy-vector index back to `(from, to, promotion)`.
///
/// Panics if `index >= num_move_indices()`.
pub fn index_to_move(index: usize) -> (HexCoord, HexCoord, Option<PieceKind>) {
    let e = &MOVE_INDEX.entries[index];
    let from = crate::board::index_to_coord(e.from_idx as usize);
    let to = crate::board::index_to_coord(e.to_idx as usize);
    (from, to, e.promotion)
}

// ---------------------------------------------------------------------------
// Training record serialization
// ---------------------------------------------------------------------------

pub struct TrainingRecord {
    pub board_tensor: [f32; TENSOR_SIZE],
    pub policy_target: Vec<f32>,
    /// WDL target: [win, draw, loss] probabilities.
    pub wdl_target: [f32; 3],
}

impl TrainingRecord {
    /// Size of one record in bytes.
    ///
    /// Layout: `[f32 x TENSOR_SIZE] [f32 x num_move_indices()] [f32 x 3]`
    pub fn record_size() -> usize {
        (TENSOR_SIZE + num_move_indices() + 3) * std::mem::size_of::<f32>()
    }

    /// Serialize to flat binary (f32 little-endian).
    pub fn to_bytes(&self) -> Vec<u8> {
        let n_move = num_move_indices();
        let total_floats = TENSOR_SIZE + n_move + 3;
        let mut buf = Vec::with_capacity(total_floats * 4);

        for &v in &self.board_tensor {
            buf.extend_from_slice(&v.to_le_bytes());
        }
        assert_eq!(
            self.policy_target.len(),
            n_move,
            "policy_target length mismatch"
        );
        for &v in &self.policy_target {
            buf.extend_from_slice(&v.to_le_bytes());
        }
        for &v in &self.wdl_target {
            buf.extend_from_slice(&v.to_le_bytes());
        }

        buf
    }

    /// Deserialize from flat binary (f32 little-endian).
    ///
    /// Panics if `data.len() != Self::record_size()`.
    pub fn from_bytes(data: &[u8]) -> Self {
        let expected = Self::record_size();
        assert_eq!(
            data.len(),
            expected,
            "TrainingRecord::from_bytes: expected {} bytes, got {}",
            expected,
            data.len()
        );

        let n_move = num_move_indices();

        let mut offset = 0;

        let read_f32 = |off: &mut usize| -> f32 {
            let bytes: [u8; 4] = data[*off..*off + 4].try_into().unwrap();
            *off += 4;
            f32::from_le_bytes(bytes)
        };

        let mut board_tensor = [0.0f32; TENSOR_SIZE];
        for slot in board_tensor.iter_mut() {
            *slot = read_f32(&mut offset);
        }

        let mut policy_target = vec![0.0f32; n_move];
        for slot in policy_target.iter_mut() {
            *slot = read_f32(&mut offset);
        }

        let wdl_target = [
            read_f32(&mut offset),
            read_f32(&mut offset),
            read_f32(&mut offset),
        ];

        TrainingRecord {
            board_tensor,
            policy_target,
            wdl_target,
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::board::{Board, Color, HexCoord, Piece, PieceKind};
    use crate::game::GameState;
    use crate::movegen::Move;

    #[test]
    fn test_tensor_shape() {
        assert_eq!(NUM_CHANNELS, 22);
        assert_eq!(TENSOR_SIZE, 22 * 11 * 11);
        assert_eq!(TENSOR_SIZE, 2662);
    }

    fn plane_sum(tensor: &[f32; TENSOR_SIZE], ch: usize) -> f32 {
        let base = ch * BOARD_DIM * BOARD_DIM;
        tensor[base..base + BOARD_DIM * BOARD_DIM].iter().sum()
    }

    #[test]
    fn test_last_move_planes_zero_on_initial_position() {
        let state = GameState::new();
        let tensor = encode_board(&state);
        assert_eq!(plane_sum(&tensor, 19), 0.0);
        assert_eq!(plane_sum(&tensor, 20), 0.0);
        assert_eq!(plane_sum(&tensor, 21), 0.0);
    }

    #[test]
    fn test_last_move_planes_after_pawn_move() {
        let mut state = GameState::new();
        // Pick any legal pawn move from the starting position.
        let legal = state.legal_moves();
        // b1-b2 style: find a move whose source piece is a pawn.
        let pawn_move = legal
            .into_iter()
            .find(|m| {
                state
                    .board
                    .get(m.from)
                    .map(|p| p.kind == PieceKind::Pawn)
                    .unwrap_or(false)
            })
            .expect("starting position has pawn moves");
        let from = pawn_move.from;
        let to = pawn_move.to;
        state.apply_move(pawn_move);

        // After white's pawn move it is black-to-move, so encode_board
        // centrally inverts all spatial coordinates for the STM frame.
        let tensor = encode_board(&state);
        let stm_from = mirror_coord(from);
        let stm_to = mirror_coord(to);
        let from_col = (stm_from.q + 5) as usize;
        let from_row = (stm_from.r + 5) as usize;
        let to_col = (stm_to.q + 5) as usize;
        let to_row = (stm_to.r + 5) as usize;
        assert_eq!(
            tensor[19 * BOARD_DIM * BOARD_DIM + from_row * BOARD_DIM + from_col],
            1.0,
            "last-move from-plane should mark STM-framed source cell"
        );
        assert_eq!(
            tensor[20 * BOARD_DIM * BOARD_DIM + to_row * BOARD_DIM + to_col],
            1.0,
            "last-move to-plane should mark STM-framed destination cell"
        );
        // Exactly one 1.0 in each plane.
        assert_eq!(plane_sum(&tensor, 19), 1.0);
        assert_eq!(plane_sum(&tensor, 20), 1.0);
        // Pawn move resets the halfmove clock.
        assert_eq!(plane_sum(&tensor, 21), 0.0);
    }

    #[test]
    fn test_plies_since_pawn_move_plane() {
        let mut board = Board::starting_position();
        board.halfmove_clock = 10;
        let state = GameState::from_board(board);
        let tensor = encode_board(&state);
        // 10 / 50 = 0.2 on every valid (and padding) cell.
        let val = tensor[21 * BOARD_DIM * BOARD_DIM];
        assert!((val - 0.2).abs() < 1e-6);
        // Sum over the full 11x11 plane.
        let expected = 0.2 * (BOARD_DIM * BOARD_DIM) as f32;
        assert!((plane_sum(&tensor, 21) - expected).abs() < 1e-4);
    }

    #[test]
    fn test_plies_since_pawn_move_plane_clamped() {
        let mut board = Board::starting_position();
        board.halfmove_clock = 200; // way past 50
        let state = GameState::from_board(board);
        let tensor = encode_board(&state);
        let val = tensor[21 * BOARD_DIM * BOARD_DIM];
        assert!((val - 1.0).abs() < 1e-6);
    }

    #[test]
    fn test_promotion_resets_halfmove_derived_planes() {
        let mut board = Board::empty();
        // Minimal legal-ish setup: kings + one pawn ready to promote.
        board.set(
            HexCoord::new(0, -4),
            Some(Piece::new(PieceKind::King, Color::White)),
        );
        board.white_king = HexCoord::new(0, -4);
        board.set(
            HexCoord::new(3, 2),
            Some(Piece::new(PieceKind::King, Color::Black)),
        );
        board.black_king = HexCoord::new(3, 2);
        board.set(
            HexCoord::new(0, 4),
            Some(Piece::new(PieceKind::Pawn, Color::White)),
        );
        board.halfmove_clock = 99;
        board.side_to_move = Color::White;

        let mut state = GameState::from_board(board);
        state.apply_move(Move {
            from: HexCoord::new(0, 4),
            to: HexCoord::new(0, 5),
            promotion: Some(PieceKind::Queen),
            captured: None,
            is_en_passant: false,
        });

        let tensor = encode_board(&state);
        // Channel 14 = halfmove_clock / 100
        assert_eq!(tensor[14 * BOARD_DIM * BOARD_DIM], 0.0);
        // Channel 21 = halfmove_clock / 50 clamped
        assert_eq!(tensor[21 * BOARD_DIM * BOARD_DIM], 0.0);
    }

    #[test]
    fn test_encode_board_starting_position_piece_planes() {
        let state = GameState::new();
        let tensor = encode_board(&state);

        let mut piece_count = 0;
        for ch in 0..12 {
            for row in 0..BOARD_DIM {
                for col in 0..BOARD_DIM {
                    let val = tensor[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col];
                    if val > 0.5 {
                        piece_count += 1;
                    }
                }
            }
        }
        // Glinski: 9 pawns + 2 rooks + 2 knights + 3 bishops + 1 queen + 1 king = 18 per side.
        assert_eq!(piece_count, 36, "expected 36 pieces in starting position");
    }

    #[test]
    fn test_encode_board_side_to_move_plane() {
        let state = GameState::new();
        let tensor = encode_board(&state);

        // Channel 12 should be all 1.0 (white to move).
        let ch = 12;
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                let val = tensor[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col];
                assert_eq!(val, 1.0, "side-to-move plane should be 1.0 for white");
            }
        }

        // Flip side to move.
        let mut board2 = Board::starting_position();
        board2.side_to_move = Color::Black;
        let state2 = GameState::from_board(board2);
        let tensor2 = encode_board(&state2);
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                let val = tensor2[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col];
                assert_eq!(val, 0.0, "side-to-move plane should be 0.0 for black");
            }
        }
    }

    #[test]
    fn test_encode_board_en_passant_plane() {
        let mut board = Board::starting_position();
        let ep = HexCoord::new(0, 0);
        board.en_passant = Some(ep);
        let state = GameState::from_board(board);
        let tensor = encode_board(&state);

        let ch = 15;
        let col = (ep.q + 5) as usize;
        let row = (ep.r + 5) as usize;
        assert_eq!(
            tensor[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col],
            1.0,
            "en passant cell should be 1.0"
        );

        let mut count = 0;
        for r in 0..BOARD_DIM {
            for c in 0..BOARD_DIM {
                if tensor[ch * BOARD_DIM * BOARD_DIM + r * BOARD_DIM + c] > 0.5 {
                    count += 1;
                }
            }
        }
        assert_eq!(count, 1, "only one cell should be set in en passant plane");
    }

    #[test]
    fn test_encode_board_move_count_plane() {
        let mut board = Board::starting_position();
        board.fullmove_number = 50;
        board.halfmove_clock = 10;
        let state = GameState::from_board(board);
        let tensor = encode_board(&state);

        // Channel 13: fullmove / 100 = 0.5
        let val = tensor[13 * BOARD_DIM * BOARD_DIM]; // first cell
        assert!((val - 0.5).abs() < 1e-6);

        // Channel 14: halfmove / 100 = 0.1
        let val = tensor[14 * BOARD_DIM * BOARD_DIM];
        assert!((val - 0.1).abs() < 1e-6);
    }

    #[test]
    fn test_validity_mask_plane() {
        let state = GameState::new();
        let tensor = encode_board(&state);

        let ch = 17;
        let mut valid_count = 0;
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                let val = tensor[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col];
                if val > 0.5 {
                    valid_count += 1;
                }
            }
        }
        assert_eq!(valid_count, 91, "validity mask should have exactly 91 ones");
    }

    #[test]
    fn test_repetition_count_plane() {
        let state = GameState::new();
        let tensor = encode_board(&state);

        // Starting position: no repetitions, channel 16 should be all 0.
        let ch = 16;
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                assert_eq!(
                    tensor[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col],
                    0.0,
                    "repetition plane should be 0.0 for new game"
                );
            }
        }
    }

    #[test]
    fn test_repetition_count_plane_after_repeat() {
        // Set up a position where we can shuttle rooks to create a repetition.
        let mut board = Board::empty();
        board.set(
            HexCoord::new(0, -4),
            Some(Piece::new(PieceKind::King, Color::White)),
        );
        board.set(
            HexCoord::new(0, 4),
            Some(Piece::new(PieceKind::King, Color::Black)),
        );
        board.set(
            HexCoord::new(2, -5),
            Some(Piece::new(PieceKind::Rook, Color::White)),
        );
        board.set(
            HexCoord::new(-2, 5),
            Some(Piece::new(PieceKind::Rook, Color::Black)),
        );
        board.white_king = HexCoord::new(0, -4);
        board.black_king = HexCoord::new(0, 4);

        let mut state = GameState::from_board(board);

        // Shuttle rooks to repeat the starting position.
        state.apply_move(Move::new(HexCoord::new(2, -5), HexCoord::new(2, -3), None));
        state.apply_move(Move::new(HexCoord::new(-2, 5), HexCoord::new(-2, 3), None));
        state.apply_move(Move::new(HexCoord::new(2, -3), HexCoord::new(2, -5), None));
        state.apply_move(Move::new(HexCoord::new(-2, 3), HexCoord::new(-2, 5), None));
        // Now at repetition count 1.
        assert_eq!(state.repetition_count(), 1);

        let tensor = encode_board(&state);
        let ch = 16;
        // Check a valid cell has rep count 1.0
        let val = tensor[ch * BOARD_DIM * BOARD_DIM + 5 * BOARD_DIM + 5]; // center cell
        assert_eq!(val, 1.0, "repetition plane should be 1.0 after one repeat");
    }

    #[test]
    fn test_in_check_plane_starting_position() {
        let state = GameState::new();
        let tensor = encode_board(&state);

        // Starting position: not in check, channel 18 should be all 0.
        let ch = 18;
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                assert_eq!(
                    tensor[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col],
                    0.0,
                    "in-check plane should be 0.0 for starting position"
                );
            }
        }
    }

    #[test]
    fn test_in_check_plane_when_checked() {
        // Set up a position where white king is in check.
        // White king at (0, -4), black rook on same file at (0, 0).
        let mut board = Board::empty();
        board.set(
            HexCoord::new(0, -4),
            Some(Piece::new(PieceKind::King, Color::White)),
        );
        board.set(
            HexCoord::new(0, 4),
            Some(Piece::new(PieceKind::King, Color::Black)),
        );
        board.set(
            HexCoord::new(0, 0),
            Some(Piece::new(PieceKind::Rook, Color::Black)),
        );
        board.white_king = HexCoord::new(0, -4);
        board.black_king = HexCoord::new(0, 4);
        board.side_to_move = Color::White;

        let state = GameState::from_board(board);
        let tensor = encode_board(&state);

        // Channel 18 should be a constant 1.0 plane (white is in check).
        let ch = 18;
        for row in 0..BOARD_DIM {
            for col in 0..BOARD_DIM {
                assert_eq!(
                    tensor[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col],
                    1.0,
                    "in-check plane should be 1.0 when in check"
                );
            }
        }
    }

    #[test]
    fn test_num_move_indices_reasonable() {
        let n = num_move_indices();
        eprintln!("NUM_MOVE_INDICES = {}", n);
        assert!(
            n >= 3000 && n <= 5000,
            "NUM_MOVE_INDICES = {} is outside the expected range [3000, 5000]",
            n
        );
    }

    #[test]
    fn test_move_to_index_roundtrip() {
        let from = HexCoord::new(0, 0);
        let to = HexCoord::new(3, -2); // knight jump
        let mv = Move::new(from, to, None);

        let idx = move_to_index(&mv).expect("move should be in table");
        let (f2, t2, p2) = index_to_move(idx);
        assert_eq!(f2, from);
        assert_eq!(t2, to);
        assert_eq!(p2, None);
    }

    #[test]
    fn test_move_to_index_roundtrip_sliding() {
        let from = HexCoord::new(-5, 0);
        let to = HexCoord::new(-5, 5);
        let mv = Move::new(from, to, None);
        let idx = move_to_index(&mv).expect("move should be in table");
        let (f2, t2, p2) = index_to_move(idx);
        assert_eq!(f2, from);
        assert_eq!(t2, to);
        assert_eq!(p2, None);
    }

    #[test]
    fn test_promotion_moves_get_distinct_indices() {
        let from = HexCoord::new(0, 4);
        let to = HexCoord::new(0, 5);
        assert!(is_promotion_cell(to), "target should be a promotion cell");

        let idx_q =
            move_to_index(&Move::new(from, to, None).with_promotion(PieceKind::Queen)).unwrap();
        let idx_r =
            move_to_index(&Move::new(from, to, None).with_promotion(PieceKind::Rook)).unwrap();
        let idx_b =
            move_to_index(&Move::new(from, to, None).with_promotion(PieceKind::Bishop)).unwrap();
        let idx_n =
            move_to_index(&Move::new(from, to, None).with_promotion(PieceKind::Knight)).unwrap();

        let mut indices = vec![idx_q, idx_r, idx_b, idx_n];
        indices.sort();
        indices.dedup();
        assert_eq!(
            indices.len(),
            4,
            "each promotion piece should get a distinct index"
        );
    }

    /// Golden hash guarding the move-index bijection against accidental changes.
    ///
    /// The move table must stay byte-identical across commits — any change
    /// invalidates every existing training sample and every trained model
    /// (policy head outputs are indexed by this table). If this test fails,
    /// you almost certainly did not mean to change the move encoding. If you
    /// really do need to change it, bump a run_id / model version and update
    /// this constant deliberately.
    #[test]
    fn test_move_table_hash_is_stable() {
        let n = num_move_indices();
        // Simple deterministic FNV-1a-style 64-bit rolling hash over the
        // full (from_idx, to_idx, promotion_ordinal) sequence.
        let mut h: u64 = 0xcbf29ce484222325;
        for i in 0..n {
            let e = &MOVE_INDEX.entries[i];
            for byte in [e.from_idx, e.to_idx, promotion_ordinal(e.promotion)] {
                h ^= byte as u64;
                h = h.wrapping_mul(0x100000001b3);
            }
        }
        const EXPECTED_COUNT: usize = 4206;
        const EXPECTED_HASH: u64 = 0x84d424aff5f7c2fd;
        // Print on failure so an intentional update is a one-line change.
        assert_eq!(
            (n, h),
            (EXPECTED_COUNT, EXPECTED_HASH),
            "move table drift detected: got count={}, hash=0x{:016x} — \
             if this change is intentional, update EXPECTED_COUNT/EXPECTED_HASH \
             and bump the training run_id",
            n,
            h
        );
    }

    #[test]
    fn test_mirror_symmetry_exhaustive() {
        use crate::board::ALL_COORDS;

        // 1. mirror_coord preserves validity for all 91 valid coords.
        for &c in ALL_COORDS.iter() {
            let m = mirror_coord(c);
            assert!(
                m.is_valid(),
                "mirror of valid coord {:?} is invalid: {:?}",
                c,
                m
            );
            // 2. Involution.
            assert_eq!(mirror_coord(m), c);
        }

        // 3. For every move in the move table, its mirrored version is in
        //    the table (implicitly verified by MIRROR_INDEX's LazyLock init,
        //    which panics otherwise; re-check here for test clarity).
        let n = num_move_indices();
        for i in 0..n {
            let j = mirror_move_index(i);
            assert!(j < n);
        }

        // 4. Involution at move-index level.
        for i in 0..n {
            assert_eq!(
                mirror_move_index(mirror_move_index(i)),
                i,
                "mirror is not an involution at index {}",
                i
            );
        }
    }

    #[test]
    fn test_all_indices_are_unique() {
        let n = num_move_indices();
        for i in 0..n {
            let (from, to, promo) = index_to_move(i);
            let mv = Move::new(from, to, None).with_promotion_opt(promo);
            let j = move_to_index(&mv).expect("move should be in table");
            assert_eq!(i, j, "index round-trip failed for index {}", i);
        }
    }

    #[test]
    fn test_training_record_serialization_roundtrip() {
        let state = GameState::new();
        let tensor = encode_board(&state);
        let n = num_move_indices();

        let mut policy = vec![0.0f32; n];
        policy[0] = 0.5;
        policy[n - 1] = 0.3;
        if n > 100 {
            policy[100] = 0.2;
        }

        let record = TrainingRecord {
            board_tensor: tensor,
            policy_target: policy.clone(),
            wdl_target: [0.8, 0.15, 0.05],
        };

        let bytes = record.to_bytes();
        assert_eq!(bytes.len(), TrainingRecord::record_size());

        let restored = TrainingRecord::from_bytes(&bytes);
        assert_eq!(restored.board_tensor, tensor);
        assert_eq!(restored.policy_target, policy);
        assert!((restored.wdl_target[0] - 0.8).abs() < 1e-7);
        assert!((restored.wdl_target[1] - 0.15).abs() < 1e-7);
        assert!((restored.wdl_target[2] - 0.05).abs() < 1e-7);
    }

    #[test]
    fn test_training_record_size() {
        let n = num_move_indices();
        let expected = (TENSOR_SIZE + n + 3) * 4;
        assert_eq!(TrainingRecord::record_size(), expected);
    }

    #[test]
    fn test_encode_board_en_passant_plane_black_to_move_is_stm_framed() {
        // Place an EP target at an asymmetric cell and encode both as
        // white-to-move and black-to-move. The EP plane must move to
        // the centrally-inverted coord in the black-to-move encoding,
        // proving channel 15 is STM-framed rather than absolute.
        let ep = HexCoord::new(2, -1); // asymmetric under (q,r) → (-q,-r)
        let mut board = Board::starting_position();
        board.en_passant = Some(ep);

        let mut board_w = board.clone();
        board_w.side_to_move = Color::White;
        let t_w = encode_board(&GameState::from_board(board_w));

        let mut board_b = board.clone();
        board_b.side_to_move = Color::Black;
        let t_b = encode_board(&GameState::from_board(board_b));

        let ch = 15;
        // White STM: cell at absolute coord.
        let w_col = (ep.q + 5) as usize;
        let w_row = (ep.r + 5) as usize;
        assert_eq!(
            t_w[ch * BOARD_DIM * BOARD_DIM + w_row * BOARD_DIM + w_col],
            1.0
        );
        // Black STM: cell at centrally-inverted coord.
        let inv = mirror_coord(ep);
        let b_col = (inv.q + 5) as usize;
        let b_row = (inv.r + 5) as usize;
        assert_eq!(
            t_b[ch * BOARD_DIM * BOARD_DIM + b_row * BOARD_DIM + b_col],
            1.0
        );
        // No leakage: exactly one 1.0 in each encoding's EP plane.
        assert_eq!(plane_sum(&t_w, ch), 1.0);
        assert_eq!(plane_sum(&t_b, ch), 1.0);
        // And the two single-cell locations differ (asymmetric coord).
        assert_ne!((w_col, w_row), (b_col, b_row));
    }

    #[test]
    fn test_encode_board_stm_frame_piece_swap_and_invert() {
        // Place two pieces on a board and encode it twice: once with white
        // to move, once with black to move. Verify that flipping STM:
        //   (a) swaps piece channels 0-5 ↔ 6-11,
        //   (b) centrally inverts spatial coordinates.
        // This is the core invariant that makes the STM frame consistent
        // with the MIRROR_INDEX policy remap used by MCTS.
        let mut board = Board::empty();
        // White pawn at (0, -4): q=0, r=-4 → col=5, row=1.
        board.set(
            HexCoord::new(0, -4),
            Some(Piece::new(PieceKind::Pawn, Color::White)),
        );
        // Black knight at (2, 3): q=2, r=3 → col=7, row=8.
        board.set(
            HexCoord::new(2, 3),
            Some(Piece::new(PieceKind::Knight, Color::Black)),
        );
        // Kings to keep the position well-formed; park them at the edges.
        board.set(
            HexCoord::new(-5, 0),
            Some(Piece::new(PieceKind::King, Color::White)),
        );
        board.white_king = HexCoord::new(-5, 0);
        board.set(
            HexCoord::new(5, 0),
            Some(Piece::new(PieceKind::King, Color::Black)),
        );
        board.black_king = HexCoord::new(5, 0);

        let mut board_w = board.clone();
        board_w.side_to_move = Color::White;
        let t_white = encode_board(&GameState::from_board(board_w));

        let mut board_b = board.clone();
        board_b.side_to_move = Color::Black;
        let t_black = encode_board(&GameState::from_board(board_b));

        let idx =
            |c: usize, col: usize, row: usize| c * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col;

        // White-to-move: white pawn in STM pawn plane (ch 0) at (0,-4),
        // black knight in opponent knight plane (ch 7) at (2, 3).
        assert_eq!(t_white[idx(0, 5, 1)], 1.0, "white pawn in ch 0 (STM pawn)");
        assert_eq!(
            t_white[idx(7, 7, 8)],
            1.0,
            "black knight in ch 7 (opp knight)"
        );
        assert_eq!(plane_sum(&t_white, 0), 1.0);
        assert_eq!(plane_sum(&t_white, 7), 1.0);

        // Black-to-move: channels swap and coords invert centrally.
        //   white pawn (0,-4) → ch 6 (opp pawn) at (0,+4) → col=5, row=9
        //   black knight (2,3) → ch 1 (STM knight) at (-2,-3) → col=3, row=2
        assert_eq!(
            t_black[idx(6, 5, 9)],
            1.0,
            "white pawn swaps to opp channel and inverts to (0,+4)"
        );
        assert_eq!(
            t_black[idx(1, 3, 2)],
            1.0,
            "black knight swaps to STM channel and inverts to (-2,-3)"
        );
        assert_eq!(plane_sum(&t_black, 1), 1.0);
        assert_eq!(plane_sum(&t_black, 6), 1.0);
        // Kings must also obey the swap: black king was in ch 11 (absolute),
        // and in the black-to-move STM frame lands in ch 5 (STM king).
        assert_eq!(plane_sum(&t_black, 5), 1.0, "STM king plane");
        assert_eq!(plane_sum(&t_black, 11), 1.0, "opponent king plane");
        // Opponent non-king, non-pawn planes stay empty (nothing leaks).
        assert_eq!(plane_sum(&t_black, 7), 0.0);
        assert_eq!(plane_sum(&t_black, 8), 0.0);
    }

    #[test]
    fn test_stm_policy_index_white_is_identity_black_is_mirror() {
        // White to move: stm_policy_index == move_to_index (identity).
        // Black to move: stm_policy_index == mirror_move_index(move_to_index).
        // Exercise this for every move in the table to catch any drift
        // between the helper and the MIRROR_INDEX table.
        let n = num_move_indices();
        for i in 0..n {
            let (from, to, promo) = index_to_move(i);
            let mv = Move::new(from, to, None).with_promotion_opt(promo);

            let white_idx = stm_policy_index(&mv, Color::White)
                .expect("every table move must map under stm_policy_index");
            assert_eq!(
                white_idx, i,
                "white STM index must equal the absolute move index for move {i}"
            );

            let black_idx = stm_policy_index(&mv, Color::Black)
                .expect("every table move must map under stm_policy_index");
            assert_eq!(
                black_idx,
                mirror_move_index(i),
                "black STM index must equal mirror_move_index(i) for move {i}"
            );
        }
    }

    #[test]
    fn test_encode_board_stm_frame_validity_and_constants() {
        // Validity mask is invariant under central inversion, and the
        // "absolute" STM plane (ch 12) differs between white and black
        // encodings of the same board while all other constant planes
        // (fullmove / halfmove / etc.) stay the same.
        let mut board = Board::starting_position();
        board.fullmove_number = 42;
        board.halfmove_clock = 10;
        let mut w = board.clone();
        w.side_to_move = Color::White;
        let t_w = encode_board(&GameState::from_board(w));
        let mut b = board.clone();
        b.side_to_move = Color::Black;
        let t_b = encode_board(&GameState::from_board(b));

        // Validity mask identical.
        for i in 0..BOARD_DIM * BOARD_DIM {
            let base = 17 * BOARD_DIM * BOARD_DIM;
            assert_eq!(t_w[base + i], t_b[base + i]);
        }
        // Fullmove / halfmove / pspm identical.
        for ch in [13usize, 14, 21] {
            for i in 0..BOARD_DIM * BOARD_DIM {
                let base = ch * BOARD_DIM * BOARD_DIM;
                assert_eq!(t_w[base + i], t_b[base + i]);
            }
        }
        // Channel 12 differs: 1.0 when white to move, 0.0 when black.
        assert_eq!(t_w[12 * BOARD_DIM * BOARD_DIM], 1.0);
        assert_eq!(t_b[12 * BOARD_DIM * BOARD_DIM], 0.0);
    }

    #[test]
    fn test_encode_board_known_piece_placement() {
        // Place a single white rook at (0, 0) and verify exactly that cell is
        // set in channel 3 (White Rook).
        let mut board = Board::empty();
        let coord = HexCoord::new(0, 0);
        board.set(coord, Some(Piece::new(PieceKind::Rook, Color::White)));
        board.white_king = HexCoord::new(-5, 0); // dummy king off to the side
        board.black_king = HexCoord::new(5, 0);

        let state = GameState::from_board(board);
        let tensor = encode_board(&state);
        let ch = 3; // White Rook
        let col = 5;
        let row = 5;
        assert_eq!(
            tensor[ch * BOARD_DIM * BOARD_DIM + row * BOARD_DIM + col],
            1.0
        );

        let mut count = 0;
        for r in 0..BOARD_DIM {
            for c in 0..BOARD_DIM {
                if tensor[ch * BOARD_DIM * BOARD_DIM + r * BOARD_DIM + c] > 0.5 {
                    count += 1;
                }
            }
        }
        assert_eq!(count, 1);
    }
}
