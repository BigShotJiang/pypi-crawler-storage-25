# walkindb

Disposable SQLite databases for LLM agents. No signup, 10-minute TTL.

This PyPI package is currently a **name reservation**. The real SDK will ship soon.

Learn more at https://walkindb.com
