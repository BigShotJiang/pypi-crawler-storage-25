"""walkindb — disposable SQLite for LLM agents.

This is a placeholder release that reserves the package name.
The real SDK will ship at https://walkindb.com
"""

__version__ = "0.0.1"
