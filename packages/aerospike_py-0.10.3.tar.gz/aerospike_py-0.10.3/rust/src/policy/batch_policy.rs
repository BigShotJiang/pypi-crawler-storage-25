//! Batch policy parsing from Python dicts.

use aerospike_core::{
    BatchDeletePolicy, BatchPolicy, BatchReadPolicy, BatchUDFPolicy, BatchWritePolicy, Concurrency,
    GenerationPolicy,
};
use log::trace;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyDict;

use super::write_policy::parse_ttl;
use super::{
    extract_filter_expression, extract_policy_fields, parse_commit_level, parse_consistency_level,
    parse_generation_policy, parse_read_touch_ttl, parse_record_exists_action, parse_replica,
};

/// Parse a Python policy dict into a BatchPolicy
pub fn parse_batch_policy(policy_dict: Option<&Bound<'_, PyDict>>) -> PyResult<BatchPolicy> {
    trace!("Parsing batch policy");
    let mut policy = BatchPolicy::default();

    let dict = match policy_dict {
        Some(d) => d,
        None => return Ok(policy),
    };

    extract_policy_fields!(dict, {
        "socket_timeout" => policy.base_policy.socket_timeout;
        "total_timeout" => policy.base_policy.total_timeout;
        "max_retries" => policy.base_policy.max_retries;
        "timeout_delay" => policy.base_policy.timeout_delay;
        "allow_inline" => policy.allow_inline;
        "allow_inline_ssd" => policy.allow_inline_ssd;
        "respond_all_keys" => policy.respond_all_keys
    });

    if let Some(val) = dict.get_item("replica")? {
        policy.replica = parse_replica(val.extract::<i32>()?);
    }
    if let Some(val) = dict.get_item("read_mode_ap")? {
        policy.base_policy.consistency_level = parse_consistency_level(val.extract::<i32>()?);
    }
    if let Some(val) = dict.get_item("read_touch_ttl_percent")? {
        policy.base_policy.read_touch_ttl = parse_read_touch_ttl(val.extract::<i64>()?)?;
    }

    if let Some(val) = dict.get_item("concurrency")? {
        policy.concurrency = parse_concurrency(val.extract::<i64>()?)?;
    }

    policy.filter_expression = extract_filter_expression(dict)?;

    Ok(policy)
}

/// Map a Python ``int`` to an [`aerospike_core::Concurrency`] variant.
///
/// Mapping: ``0 -> Sequential``, ``1 -> Parallel``. Any other value
/// (including negatives and ``n >= 2``) is rejected with [`PyValueError`].
/// Note that aerospike-core 2.0's ``Concurrency`` enum only supports the
/// two variants — there is no ``MaxThreads(n)`` variant in this version.
fn parse_concurrency(value: i64) -> PyResult<Concurrency> {
    match value {
        0 => Ok(Concurrency::Sequential),
        1 => Ok(Concurrency::Parallel),
        _ => Err(PyValueError::new_err(format!(
            "Invalid concurrency value: {value}. Use BATCH_CONCURRENCY_SEQUENTIAL (0) or BATCH_CONCURRENCY_PARALLEL (1)"
        ))),
    }
}

/// Parse the batch-level policy dict into a [`BatchWritePolicy`].
///
/// Mirrors [`super::write_policy::parse_write_policy`] for the write-related
/// fields exposed by `aerospike-core`'s `BatchWritePolicy` struct. Per-record
/// overrides are applied later via [`apply_record_meta`].
pub fn parse_batch_write_policy(
    policy_dict: Option<&Bound<'_, PyDict>>,
) -> PyResult<BatchWritePolicy> {
    trace!("Parsing batch write policy");
    let mut policy = BatchWritePolicy::default();

    let dict = match policy_dict {
        Some(d) => d,
        None => return Ok(policy),
    };

    extract_policy_fields!(dict, {
        "durable_delete" => policy.durable_delete
    });

    // Key (send_key) — POLICY_KEY_DIGEST(0) | POLICY_KEY_SEND(1)
    if let Some(val) = dict.get_item("key")? {
        policy.send_key = val.extract::<i32>()? == 1;
    }

    // Exists (record_exists_action) — POLICY_EXISTS_*
    if let Some(val) = dict.get_item("exists")? {
        policy.record_exists_action = parse_record_exists_action(val.extract::<i32>()?);
    }

    // Generation policy — POLICY_GEN_*
    if let Some(val) = dict.get_item("gen")? {
        policy.generation_policy = parse_generation_policy(val.extract::<i32>()?);
    }

    // Commit level — POLICY_COMMIT_LEVEL_*
    if let Some(val) = dict.get_item("commit_level")? {
        policy.commit_level = parse_commit_level(val.extract::<i32>()?);
    }

    // TTL / expiration
    if let Some(val) = dict.get_item("ttl")? {
        policy.expiration = parse_ttl(val.extract::<i64>()?)?;
    }

    // Filter expression
    policy.filter_expression = extract_filter_expression(dict)?;

    Ok(policy)
}

/// Parse the per-record-policy dict into a [`BatchReadPolicy`].
///
/// Mirrors [`parse_batch_write_policy`] but covers only the read-side
/// fields exposed by `aerospike-core`'s `BatchReadPolicy`:
/// `read_touch_ttl_percent` (user-facing key) and `filter_expression`.
pub fn parse_batch_read_policy(
    policy_dict: Option<&Bound<'_, PyDict>>,
) -> PyResult<BatchReadPolicy> {
    trace!("Parsing batch read policy");
    let mut policy = BatchReadPolicy::default();

    let dict = match policy_dict {
        Some(d) => d,
        None => return Ok(policy),
    };

    if let Some(val) = dict.get_item("read_touch_ttl_percent")? {
        policy.read_touch_ttl = parse_read_touch_ttl(val.extract::<i64>()?)?;
    }

    policy.filter_expression = extract_filter_expression(dict)?;

    Ok(policy)
}

/// Parse the per-record-policy dict into a [`BatchDeletePolicy`].
///
/// Covers `gen` (generation_policy), `commit_level`, `key` (send_key),
/// `durable_delete`, and `filter_expression`. Mirrors the write-side
/// parser but omits TTL and `exists` (deletes don't write expiration
/// or care about record-exists semantics).
pub fn parse_batch_delete_policy(
    policy_dict: Option<&Bound<'_, PyDict>>,
) -> PyResult<BatchDeletePolicy> {
    trace!("Parsing batch delete policy");
    let mut policy = BatchDeletePolicy::default();

    let dict = match policy_dict {
        Some(d) => d,
        None => return Ok(policy),
    };

    extract_policy_fields!(dict, {
        "durable_delete" => policy.durable_delete
    });

    if let Some(val) = dict.get_item("key")? {
        policy.send_key = val.extract::<i32>()? == 1;
    }
    if let Some(val) = dict.get_item("gen")? {
        policy.generation_policy = parse_generation_policy(val.extract::<i32>()?);
    }
    if let Some(val) = dict.get_item("commit_level")? {
        policy.commit_level = parse_commit_level(val.extract::<i32>()?);
    }

    policy.filter_expression = extract_filter_expression(dict)?;

    Ok(policy)
}

/// Apply per-record meta to a [`BatchDeletePolicy`], overriding the batch-level
/// default. Per-record settings always win.
///
/// Supported meta keys: `gen` (sets `generation` + `GenerationPolicy::
/// ExpectGenEqual`, mirroring `apply_record_meta` for writes), `key`
/// (send_key), `commit_level`, `durable_delete`. Unknown keys are
/// silently ignored, matching the batch_write meta convention.
pub fn apply_record_meta_for_delete(
    base: &BatchDeletePolicy,
    meta: &Bound<'_, PyDict>,
) -> PyResult<BatchDeletePolicy> {
    let mut policy = base.clone();

    if let Some(gen) = meta.get_item("gen")? {
        policy.generation = gen.extract::<u32>()?;
        policy.generation_policy = GenerationPolicy::ExpectGenEqual;
    }
    if let Some(key) = meta.get_item("key")? {
        policy.send_key = key.extract::<i32>()? == 1;
    }
    if let Some(commit_level) = meta.get_item("commit_level")? {
        policy.commit_level = parse_commit_level(commit_level.extract::<i32>()?);
    }
    if let Some(durable_delete) = meta.get_item("durable_delete")? {
        policy.durable_delete = durable_delete.extract::<bool>()?;
    }

    Ok(policy)
}

/// Parse the per-record-policy dict into a [`BatchUDFPolicy`].
///
/// Covers `commit_level`, `expiration` (via the user-facing `ttl` key,
/// matching the `WritePolicy` parser convention), `key` (send_key),
/// `durable_delete`, and `filter_expression`. UDFs may write — keeping
/// the same field surface as `BatchWritePolicy` minus `gen`/`exists`
/// keeps the parsers consistent for downstream `apply_record_meta_for_apply`.
pub fn parse_batch_udf_policy(policy_dict: Option<&Bound<'_, PyDict>>) -> PyResult<BatchUDFPolicy> {
    trace!("Parsing batch UDF policy");
    let mut policy = BatchUDFPolicy::default();

    let dict = match policy_dict {
        Some(d) => d,
        None => return Ok(policy),
    };

    extract_policy_fields!(dict, {
        "durable_delete" => policy.durable_delete
    });

    if let Some(val) = dict.get_item("key")? {
        policy.send_key = val.extract::<i32>()? == 1;
    }
    if let Some(val) = dict.get_item("commit_level")? {
        policy.commit_level = parse_commit_level(val.extract::<i32>()?);
    }
    if let Some(val) = dict.get_item("ttl")? {
        policy.expiration = parse_ttl(val.extract::<i64>()?)?;
    }

    policy.filter_expression = extract_filter_expression(dict)?;

    Ok(policy)
}

/// Apply per-record meta to a [`BatchUDFPolicy`], overriding the batch-level
/// default. Per-record settings always win.
///
/// Supported meta keys (single flat `BatchUDFMeta` dict, mirroring
/// `BatchDeleteMeta`): `ttl`, `key` (send_key), `commit_level`,
/// `durable_delete`. Note that `module`, `function`, and `args` are
/// extracted separately by `prepare_batch_apply_args` — they affect
/// the UDF call shape, not the policy.
pub fn apply_record_meta_for_apply(
    base: &BatchUDFPolicy,
    meta: &Bound<'_, PyDict>,
) -> PyResult<BatchUDFPolicy> {
    let mut policy = base.clone();

    if let Some(ttl) = meta.get_item("ttl")? {
        policy.expiration = parse_ttl(ttl.extract::<i64>()?)?;
    }
    if let Some(key) = meta.get_item("key")? {
        policy.send_key = key.extract::<i32>()? == 1;
    }
    if let Some(commit_level) = meta.get_item("commit_level")? {
        policy.commit_level = parse_commit_level(commit_level.extract::<i32>()?);
    }
    if let Some(durable_delete) = meta.get_item("durable_delete")? {
        policy.durable_delete = durable_delete.extract::<bool>()?;
    }

    Ok(policy)
}

/// Apply per-record meta to a [`BatchWritePolicy`], overriding the batch-level
/// default. Per-record settings always win.
///
/// Supported meta keys mirror the write fields of `BatchWritePolicy`: `ttl`,
/// `gen` (sets `generation` + `GenerationPolicy::ExpectGenEqual`, matching
/// the existing `WriteMeta` semantics for `put`), `key`, `exists`,
/// `commit_level`, `durable_delete`.
pub fn apply_record_meta(
    base: &BatchWritePolicy,
    meta: &Bound<'_, PyDict>,
) -> PyResult<BatchWritePolicy> {
    let mut policy = base.clone();

    if let Some(ttl) = meta.get_item("ttl")? {
        policy.expiration = parse_ttl(ttl.extract::<i64>()?)?;
    }
    if let Some(gen) = meta.get_item("gen")? {
        policy.generation = gen.extract::<u32>()?;
        policy.generation_policy = GenerationPolicy::ExpectGenEqual;
    }
    if let Some(key) = meta.get_item("key")? {
        policy.send_key = key.extract::<i32>()? == 1;
    }
    if let Some(exists) = meta.get_item("exists")? {
        policy.record_exists_action = parse_record_exists_action(exists.extract::<i32>()?);
    }
    if let Some(commit_level) = meta.get_item("commit_level")? {
        policy.commit_level = parse_commit_level(commit_level.extract::<i32>()?);
    }
    if let Some(durable_delete) = meta.get_item("durable_delete")? {
        policy.durable_delete = durable_delete.extract::<bool>()?;
    }

    Ok(policy)
}

#[cfg(test)]
mod tests {
    use super::*;
    use aerospike_core::{CommitLevel, Expiration, RecordExistsAction};

    /// Build a Python dict from `(key, value)` pairs for testing.
    fn build_dict<'py>(
        py: Python<'py>,
        build: impl FnOnce(&Bound<'py, PyDict>),
    ) -> Bound<'py, PyDict> {
        let d = PyDict::new(py);
        build(&d);
        d
    }

    #[test]
    fn parse_batch_write_policy_with_send_key() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("key", 1i32).unwrap();
            });
            let p = parse_batch_write_policy(Some(&d)).expect("parse ok");
            assert!(p.send_key, "key=1 must enable send_key");
        });
    }

    #[test]
    fn parse_batch_write_policy_send_key_zero_means_digest() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("key", 0i32).unwrap();
            });
            let p = parse_batch_write_policy(Some(&d)).expect("parse ok");
            assert!(!p.send_key, "key=0 must keep digest-only behavior");
        });
    }

    #[test]
    fn parse_batch_write_policy_with_exists_create_only() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("exists", 4i32).unwrap();
            });
            let p = parse_batch_write_policy(Some(&d)).expect("parse ok");
            assert_eq!(p.record_exists_action, RecordExistsAction::CreateOnly);
        });
    }

    #[test]
    fn parse_batch_write_policy_with_commit_level_master() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("commit_level", 1i32).unwrap();
            });
            let p = parse_batch_write_policy(Some(&d)).expect("parse ok");
            assert_eq!(p.commit_level, CommitLevel::CommitMaster);
        });
    }

    #[test]
    fn parse_batch_write_policy_with_durable_delete() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("durable_delete", true).unwrap();
            });
            let p = parse_batch_write_policy(Some(&d)).expect("parse ok");
            assert!(p.durable_delete);
        });
    }

    #[test]
    fn parse_batch_write_policy_default_when_dict_is_none() {
        let p = parse_batch_write_policy(None).expect("parse ok");
        assert!(!p.send_key);
        assert!(!p.durable_delete);
        assert_eq!(p.record_exists_action, RecordExistsAction::Update);
        assert_eq!(p.commit_level, CommitLevel::CommitAll);
        assert!(matches!(p.expiration, Expiration::NamespaceDefault));
    }

    #[test]
    fn apply_record_meta_overrides_send_key() {
        Python::initialize();
        Python::attach(|py| {
            let base = BatchWritePolicy::default(); // send_key = false
            let meta = build_dict(py, |d| {
                d.set_item("key", 1i32).unwrap();
            });
            let overridden = apply_record_meta(&base, &meta).expect("apply ok");
            assert!(overridden.send_key);
        });
    }

    #[test]
    fn apply_record_meta_overrides_exists() {
        Python::initialize();
        Python::attach(|py| {
            let base = BatchWritePolicy::default();
            let meta = build_dict(py, |d| {
                d.set_item("exists", 4i32).unwrap();
            });
            let overridden = apply_record_meta(&base, &meta).expect("apply ok");
            assert_eq!(
                overridden.record_exists_action,
                RecordExistsAction::CreateOnly
            );
        });
    }

    #[test]
    fn apply_record_meta_preserves_unrelated_fields() {
        Python::initialize();
        Python::attach(|py| {
            let base = BatchWritePolicy {
                send_key: true,
                commit_level: CommitLevel::CommitMaster,
                ..BatchWritePolicy::default()
            };

            // Meta only sets ttl — other fields must come from base.
            let meta = build_dict(py, |d| {
                d.set_item("ttl", 3600i64).unwrap();
            });
            let overridden = apply_record_meta(&base, &meta).expect("apply ok");
            assert!(overridden.send_key, "send_key must be inherited from base");
            assert_eq!(overridden.commit_level, CommitLevel::CommitMaster);
            assert!(matches!(overridden.expiration, Expiration::Seconds(3600)));
        });
    }

    #[test]
    fn parse_batch_policy_with_replica_master() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("replica", 0i32).unwrap();
            });
            let p = parse_batch_policy(Some(&d)).unwrap();
            assert_eq!(p.replica, aerospike_core::policy::Replica::Master);
        });
    }

    #[test]
    fn parse_batch_policy_with_timeout_delay() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("timeout_delay", 500u32).unwrap();
            });
            let p = parse_batch_policy(Some(&d)).unwrap();
            assert_eq!(p.base_policy.timeout_delay, 500);
        });
    }

    #[test]
    fn parse_batch_policy_default_concurrency_is_parallel() {
        let p = parse_batch_policy(None).expect("parse ok");
        assert!(matches!(p.concurrency, Concurrency::Parallel));
    }

    #[test]
    fn parse_batch_policy_concurrency_sequential() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("concurrency", 0i64).unwrap();
            });
            let p = parse_batch_policy(Some(&d)).expect("parse ok");
            assert!(matches!(p.concurrency, Concurrency::Sequential));
        });
    }

    #[test]
    fn parse_batch_policy_concurrency_parallel() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("concurrency", 1i64).unwrap();
            });
            let p = parse_batch_policy(Some(&d)).expect("parse ok");
            assert!(matches!(p.concurrency, Concurrency::Parallel));
        });
    }

    #[test]
    fn parse_batch_policy_concurrency_rejects_negative() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("concurrency", -1i64).unwrap();
            });
            assert!(parse_batch_policy(Some(&d)).is_err());
        });
    }

    #[test]
    fn parse_batch_policy_concurrency_rejects_unsupported_max_threads() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("concurrency", 4i64).unwrap();
            });
            assert!(parse_batch_policy(Some(&d)).is_err());
        });
    }

    #[test]
    fn parse_batch_policy_with_read_mode_and_ttl() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("read_mode_ap", 1i32).unwrap();
                d.set_item("read_touch_ttl_percent", 80i64).unwrap();
            });
            let p = parse_batch_policy(Some(&d)).unwrap();
            assert_eq!(
                p.base_policy.consistency_level,
                aerospike_core::ConsistencyLevel::ConsistencyAll
            );
            assert!(matches!(
                p.base_policy.read_touch_ttl,
                aerospike_core::ReadTouchTTL::Percent(80)
            ));
        });
    }

    #[test]
    fn apply_record_meta_per_record_wins_over_base() {
        Python::initialize();
        Python::attach(|py| {
            let base = BatchWritePolicy {
                send_key: false, // batch policy = DIGEST
                ..BatchWritePolicy::default()
            };

            // Per-record meta = SEND must override.
            let meta = build_dict(py, |d| {
                d.set_item("key", 1i32).unwrap();
            });
            let overridden = apply_record_meta(&base, &meta).expect("apply ok");
            assert!(overridden.send_key, "per-record key must override base");
        });
    }

    // ── BatchReadPolicy ──────────────────────────────────────────────────

    #[test]
    fn parse_batch_read_policy_default_when_dict_is_none() {
        let p = parse_batch_read_policy(None).expect("parse ok");
        assert!(matches!(
            p.read_touch_ttl,
            aerospike_core::ReadTouchTTL::ServerDefault
        ));
        assert!(p.filter_expression.is_none());
    }

    #[test]
    fn parse_batch_read_policy_with_read_touch_ttl_percent_80() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("read_touch_ttl_percent", 80i32).unwrap();
            });
            let p = parse_batch_read_policy(Some(&d)).expect("parse ok");
            assert!(matches!(
                p.read_touch_ttl,
                aerospike_core::ReadTouchTTL::Percent(80)
            ));
        });
    }

    #[test]
    fn parse_batch_read_policy_rejects_out_of_range() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("read_touch_ttl_percent", 150i32).unwrap();
            });
            assert!(parse_batch_read_policy(Some(&d)).is_err());
        });
    }

    // ── BatchDeletePolicy ────────────────────────────────────────────────

    #[test]
    fn parse_batch_delete_policy_default_when_dict_is_none() {
        let p = parse_batch_delete_policy(None).expect("parse ok");
        assert!(!p.send_key);
        assert!(!p.durable_delete);
        assert_eq!(p.generation_policy, GenerationPolicy::None);
        assert_eq!(p.commit_level, aerospike_core::CommitLevel::CommitAll);
        assert_eq!(p.generation, 0);
    }

    #[test]
    fn parse_batch_delete_policy_with_durable_delete_and_send_key() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("durable_delete", true).unwrap();
                d.set_item("key", 1i32).unwrap();
            });
            let p = parse_batch_delete_policy(Some(&d)).expect("parse ok");
            assert!(p.durable_delete);
            assert!(p.send_key);
        });
    }

    #[test]
    fn apply_record_meta_for_delete_sets_gen_and_policy() {
        Python::initialize();
        Python::attach(|py| {
            let base = aerospike_core::BatchDeletePolicy::default();
            let meta = build_dict(py, |d| {
                d.set_item("gen", 42u32).unwrap();
            });
            let overridden = apply_record_meta_for_delete(&base, &meta).expect("apply ok");
            assert_eq!(overridden.generation, 42);
            assert_eq!(
                overridden.generation_policy,
                GenerationPolicy::ExpectGenEqual
            );
        });
    }

    #[test]
    fn apply_record_meta_for_delete_per_record_wins_over_base() {
        Python::initialize();
        Python::attach(|py| {
            let base = aerospike_core::BatchDeletePolicy {
                send_key: false,
                ..Default::default()
            };
            let meta = build_dict(py, |d| {
                d.set_item("key", 1i32).unwrap();
                d.set_item("durable_delete", true).unwrap();
            });
            let overridden = apply_record_meta_for_delete(&base, &meta).expect("apply ok");
            assert!(overridden.send_key);
            assert!(overridden.durable_delete);
        });
    }

    // ── BatchUDFPolicy ───────────────────────────────────────────────────

    #[test]
    fn parse_batch_udf_policy_default_when_dict_is_none() {
        let p = parse_batch_udf_policy(None).expect("parse ok");
        assert!(!p.send_key);
        assert!(!p.durable_delete);
        assert_eq!(p.commit_level, CommitLevel::CommitAll);
        assert!(matches!(p.expiration, Expiration::NamespaceDefault));
        assert!(p.filter_expression.is_none());
    }

    #[test]
    fn parse_batch_udf_policy_with_ttl_and_send_key() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("ttl", 60i64).unwrap();
                d.set_item("key", 1i32).unwrap();
            });
            let p = parse_batch_udf_policy(Some(&d)).expect("parse ok");
            assert!(p.send_key);
            assert!(matches!(p.expiration, Expiration::Seconds(60)));
        });
    }

    #[test]
    fn parse_batch_udf_policy_with_commit_level_and_durable_delete() {
        Python::initialize();
        Python::attach(|py| {
            let d = build_dict(py, |d| {
                d.set_item("commit_level", 1i32).unwrap();
                d.set_item("durable_delete", true).unwrap();
            });
            let p = parse_batch_udf_policy(Some(&d)).expect("parse ok");
            assert_eq!(p.commit_level, CommitLevel::CommitMaster);
            assert!(p.durable_delete);
        });
    }

    #[test]
    fn apply_record_meta_for_apply_overrides_ttl_and_send_key() {
        Python::initialize();
        Python::attach(|py| {
            let base = BatchUDFPolicy::default();
            let meta = build_dict(py, |d| {
                d.set_item("ttl", 3600i64).unwrap();
                d.set_item("key", 1i32).unwrap();
            });
            let overridden = apply_record_meta_for_apply(&base, &meta).expect("apply ok");
            assert!(overridden.send_key);
            assert!(matches!(overridden.expiration, Expiration::Seconds(3600)));
        });
    }

    #[test]
    fn apply_record_meta_for_apply_per_record_wins_over_base() {
        Python::initialize();
        Python::attach(|py| {
            let base = BatchUDFPolicy {
                send_key: false,
                commit_level: CommitLevel::CommitAll,
                ..Default::default()
            };
            let meta = build_dict(py, |d| {
                d.set_item("commit_level", 1i32).unwrap();
                d.set_item("durable_delete", true).unwrap();
            });
            let overridden = apply_record_meta_for_apply(&base, &meta).expect("apply ok");
            assert_eq!(overridden.commit_level, CommitLevel::CommitMaster);
            assert!(overridden.durable_delete);
            assert!(!overridden.send_key, "send_key inherited from base");
        });
    }
}
