"""Farchive SQLite schema: DDL, version detection, initialization."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

SCHEMA_VERSION = 3
_GENERATOR = "farchive 3.1.0"


def _now_ms() -> int:
    """Current UTC time as Unix milliseconds."""
    return int(datetime.now(timezone.utc).timestamp() * 1000)


_SCHEMA_V3 = """
CREATE TABLE IF NOT EXISTS schema_info (
    version         INTEGER NOT NULL,
    created_at      INTEGER NOT NULL,
    migrated_at     INTEGER,
    generator       TEXT
);

CREATE TABLE IF NOT EXISTS dict (
    dict_id         INTEGER PRIMARY KEY,
    storage_class   TEXT NOT NULL DEFAULT '',
    trained_at      INTEGER NOT NULL,
    sample_count    INTEGER NOT NULL,
    dict_bytes      BLOB NOT NULL,
    dict_size       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS blob (
    digest              TEXT PRIMARY KEY,
    payload             BLOB,
    raw_size            INTEGER NOT NULL,
    stored_self_size    INTEGER NOT NULL,
    codec               TEXT NOT NULL CHECK (codec IN (
                            'raw', 'zstd', 'zstd_dict', 'zstd_delta', 'chunked'
                        )),
    codec_dict_id       INTEGER REFERENCES dict(dict_id),
    base_digest         TEXT REFERENCES blob(digest),
    storage_class       TEXT,
    created_at          INTEGER NOT NULL,
    CHECK (
        (codec = 'chunked' AND payload IS NULL)
        OR
        (codec <> 'chunked' AND payload IS NOT NULL)
    ),
    CHECK (
        (codec = 'zstd_dict' AND codec_dict_id IS NOT NULL)
        OR
        (codec <> 'zstd_dict')
    ),
    CHECK (
        (codec = 'zstd_delta' AND base_digest IS NOT NULL)
        OR
        (codec <> 'zstd_delta' AND base_digest IS NULL)
    )
);

CREATE TABLE IF NOT EXISTS chunk (
    chunk_digest        TEXT PRIMARY KEY,
    payload             BLOB NOT NULL,
    raw_size            INTEGER NOT NULL,
    stored_size         INTEGER NOT NULL,
    codec               TEXT NOT NULL CHECK (codec IN (
                            'raw', 'zstd', 'zstd_dict'
                        )),
    codec_dict_id       INTEGER REFERENCES dict(dict_id),
    created_at          INTEGER NOT NULL,
    CHECK (
        (codec = 'zstd_dict' AND codec_dict_id IS NOT NULL)
        OR
        (codec <> 'zstd_dict')
    )
);

CREATE TABLE IF NOT EXISTS blob_chunk (
    blob_digest         TEXT NOT NULL REFERENCES blob(digest),
    ordinal             INTEGER NOT NULL,
    raw_offset          INTEGER NOT NULL,
    chunk_digest        TEXT NOT NULL REFERENCES chunk(chunk_digest),
    PRIMARY KEY (blob_digest, ordinal)
);

CREATE TABLE IF NOT EXISTS locator_span (
    span_id             INTEGER PRIMARY KEY,
    locator             TEXT NOT NULL,
    digest              TEXT NOT NULL REFERENCES blob(digest),
    observed_from       INTEGER NOT NULL,
    observed_until      INTEGER,
    last_confirmed_at   INTEGER NOT NULL,
    observation_count   INTEGER NOT NULL DEFAULT 1,
    series_key          TEXT,
    last_metadata_json  TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_span_one_open
    ON locator_span(locator) WHERE observed_until IS NULL;
CREATE INDEX IF NOT EXISTS idx_span_locator
    ON locator_span(locator, observed_from DESC);
CREATE INDEX IF NOT EXISTS idx_span_locator_time
    ON locator_span(locator, observed_from, observed_until);
CREATE INDEX IF NOT EXISTS idx_blob_base
    ON blob(base_digest);
CREATE INDEX IF NOT EXISTS idx_blob_chunk_ref
    ON blob_chunk(chunk_digest);
"""

_EVENT_TABLE = """
CREATE TABLE IF NOT EXISTS event (
    event_id        INTEGER PRIMARY KEY,
    occurred_at     INTEGER NOT NULL,
    locator         TEXT NOT NULL,
    digest          TEXT,
    kind            TEXT NOT NULL,
    metadata_json   TEXT
);

CREATE INDEX IF NOT EXISTS idx_event_locator_time
    ON event(locator, occurred_at DESC);
"""


# ---------------------------------------------------------------------------
# Schema detection and initialization
# ---------------------------------------------------------------------------


def detect_schema_version(conn: sqlite3.Connection) -> int:
    """O(1) schema version detection. Returns 0 for empty/unknown DB."""
    try:
        row = conn.execute("SELECT version FROM schema_info").fetchone()
        return row[0] if row else 0
    except sqlite3.OperationalError:
        return 0


def _ensure_v3_indexes(conn: sqlite3.Connection) -> None:
    """Ensure all canonical v3 indexes exist on the base tables."""
    conn.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_span_one_open "
        "ON locator_span(locator) WHERE observed_until IS NULL"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_span_locator "
        "ON locator_span(locator, observed_from DESC)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_span_locator_time "
        "ON locator_span(locator, observed_from, observed_until)"
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_blob_base ON blob(base_digest)")
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_blob_chunk_ref ON blob_chunk(chunk_digest)"
    )


def _ensure_v3_series_key_column(conn: sqlite3.Connection) -> None:
    """Best-effort migration for legacy v3 tables missing locator_span.series_key."""
    cols = {r[1] for r in conn.execute("PRAGMA table_info(locator_span)").fetchall()}
    if "series_key" not in cols:
        conn.execute("ALTER TABLE locator_span ADD COLUMN series_key TEXT")


def _migrate_v1_to_v2(conn: sqlite3.Connection) -> None:
    """Migrate schema v1 to v2: add zstd_delta support.

    v1: codec IN ('raw', 'zstd'), no base_digest
    v2: codec IN ('raw', 'zstd', 'zstd_dict', 'zstd_delta'), adds base_digest

    Existing 'zstd' + codec_dict_id rows become 'zstd_dict'.
    """
    now = _now_ms()

    # Idempotency: check actual target shape, not temp tables.
    # v2 means the live blob table has base_digest.
    cols = {r[1] for r in conn.execute("PRAGMA table_info(blob)").fetchall()}
    if "base_digest" in cols:
        conn.execute(
            "UPDATE schema_info SET version=?, migrated_at=?, generator=?",
            (2, now, _GENERATOR),
        )
        conn.commit()
        return

    # Detect leaked temp tables from a failed prior migration.
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    if "blob_v2" in tables:
        raise RuntimeError(
            "Incomplete v1->v2 migration detected: blob_v2 table exists. "
            "Restore from backup and retry."
        )

    # Disable FK checks during table rebuild (locator_span references blob).
    # Use explicit BEGIN IMMEDIATE so DDL is inside a real transaction.
    conn.execute("PRAGMA foreign_keys=OFF")
    try:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("""
            CREATE TABLE blob_v2 (
                digest              TEXT PRIMARY KEY,
                payload             BLOB NOT NULL,
                raw_size            INTEGER NOT NULL,
                stored_size         INTEGER NOT NULL,
                codec               TEXT NOT NULL CHECK (codec IN (
                                        'raw', 'zstd', 'zstd_dict', 'zstd_delta'
                                    )),
                codec_dict_id       INTEGER REFERENCES dict(dict_id),
                base_digest         TEXT REFERENCES blob_v2(digest),
                storage_class       TEXT,
                created_at          INTEGER NOT NULL,
                CHECK (
                    (codec = 'zstd_delta' AND base_digest IS NOT NULL)
                    OR
                    (codec <> 'zstd_delta' AND base_digest IS NULL)
                )
            )
        """)
        conn.execute("""
            INSERT INTO blob_v2 (digest, payload, raw_size, stored_size, codec,
                                 codec_dict_id, base_digest, storage_class, created_at)
                SELECT
                    digest, payload, raw_size, stored_size,
                    CASE
                        WHEN codec = 'raw' THEN 'raw'
                        WHEN codec = 'zstd' AND codec_dict_id IS NOT NULL
                            THEN 'zstd_dict'
                        WHEN codec = 'zstd' THEN 'zstd'
                    END,
                    codec_dict_id,
                    NULL,
                    storage_class,
                    created_at
                FROM blob
        """)
        conn.execute("DROP TABLE blob")
        conn.execute("ALTER TABLE blob_v2 RENAME TO blob")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_blob_base ON blob(base_digest)")
        conn.execute(
            "UPDATE schema_info SET version=?, migrated_at=?, generator=?",
            (2, now, _GENERATOR),
        )
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except Exception:
            pass
        raise
    finally:
        conn.execute("PRAGMA foreign_keys=ON")


def _migrate_v2_to_v3(conn: sqlite3.Connection) -> None:
    """Migrate schema v2 to v3: add chunked representation support.

    v2: codec IN ('raw', 'zstd', 'zstd_dict', 'zstd_delta')
    v3: codec IN ('raw', 'zstd', 'zstd_dict', 'zstd_delta', 'chunked'),
        adds chunk and blob_chunk tables, blob.payload allows NULL.
    """
    now = _now_ms()

    # Idempotency: check actual target shape.
    # v3 means blob has stored_self_size AND chunk table exists.
    cols = {r[1] for r in conn.execute("PRAGMA table_info(blob)").fetchall()}
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    if "stored_self_size" in cols and "chunk" in tables and "blob_chunk" in tables:
        _ensure_v3_series_key_column(conn)
        _ensure_v3_indexes(conn)
        conn.execute(
            "UPDATE schema_info SET version=?, migrated_at=?, generator=?",
            (3, now, _GENERATOR),
        )
        conn.commit()
        return

    # Detect leaked temp tables from a failed prior migration.
    if "blob_v3" in tables:
        raise RuntimeError(
            "Incomplete v2->v3 migration detected: blob_v3 table exists. "
            "Restore from backup and retry."
        )

    # Detect the size column name — v2 may have stored_size or stored_self_size
    size_col = "stored_self_size" if "stored_self_size" in cols else "stored_size"

    conn.execute("PRAGMA foreign_keys=OFF")
    try:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("""
            CREATE TABLE blob_v3 (
                digest              TEXT PRIMARY KEY,
                payload             BLOB,
                raw_size            INTEGER NOT NULL,
                stored_self_size    INTEGER NOT NULL,
                codec               TEXT NOT NULL CHECK (codec IN (
                                        'raw', 'zstd', 'zstd_dict',
                                        'zstd_delta', 'chunked'
                                    )),
                codec_dict_id       INTEGER REFERENCES dict(dict_id),
                base_digest         TEXT REFERENCES blob_v3(digest),
                storage_class       TEXT,
                created_at          INTEGER NOT NULL,
                CHECK (
                    (codec = 'chunked' AND payload IS NULL)
                    OR
                    (codec <> 'chunked' AND payload IS NOT NULL)
                ),
                CHECK (
                    (codec = 'zstd_dict' AND codec_dict_id IS NOT NULL)
                    OR
                    (codec <> 'zstd_dict')
                ),
                CHECK (
                    (codec = 'zstd_delta' AND base_digest IS NOT NULL)
                    OR
                    (codec <> 'zstd_delta' AND base_digest IS NULL)
                )
            )
        """)
        conn.execute(f"""
            INSERT INTO blob_v3 (
                digest, payload, raw_size, stored_self_size, codec,
                codec_dict_id, base_digest, storage_class, created_at
            )
                SELECT digest, payload, raw_size, {size_col}, codec,
                       codec_dict_id, base_digest, storage_class, created_at
                FROM blob
        """)
        conn.execute("DROP TABLE blob")
        conn.execute("ALTER TABLE blob_v3 RENAME TO blob")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_blob_base ON blob(base_digest)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS chunk (
                chunk_digest        TEXT PRIMARY KEY,
                payload             BLOB NOT NULL,
                raw_size            INTEGER NOT NULL,
                stored_size         INTEGER NOT NULL,
                codec               TEXT NOT NULL CHECK (codec IN (
                                        'raw', 'zstd', 'zstd_dict'
                                    )),
                codec_dict_id       INTEGER REFERENCES dict(dict_id),
                created_at          INTEGER NOT NULL,
                CHECK (
                    (codec = 'zstd_dict' AND codec_dict_id IS NOT NULL)
                    OR
                    (codec <> 'zstd_dict')
                )
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS blob_chunk (
                blob_digest         TEXT NOT NULL REFERENCES blob(digest),
                ordinal             INTEGER NOT NULL,
                raw_offset          INTEGER NOT NULL,
                chunk_digest        TEXT NOT NULL REFERENCES chunk(chunk_digest),
                PRIMARY KEY (blob_digest, ordinal)
            )
        """)
        _ensure_v3_series_key_column(conn)
        _ensure_v3_indexes(conn)
        conn.execute(
            "UPDATE schema_info SET version=?, migrated_at=?, generator=?",
            (3, now, _GENERATOR),
        )
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except Exception:
            pass
        raise
    finally:
        conn.execute("PRAGMA foreign_keys=ON")


def init_schema(conn: sqlite3.Connection, *, enable_events: bool = False) -> None:
    """Create or verify schema. Raises on incompatible future version."""
    version = detect_schema_version(conn)
    if version > SCHEMA_VERSION:
        raise RuntimeError(
            f"Farchive DB version {version} > max supported "
            f"{SCHEMA_VERSION}. Upgrade farchive."
        )
    if version == 0:
        now = _now_ms()
        conn.executescript(_SCHEMA_V3)
        if enable_events:
            conn.executescript(_EVENT_TABLE)
        conn.execute(
            "INSERT OR IGNORE INTO schema_info VALUES (?, ?, NULL, ?)",
            (SCHEMA_VERSION, now, _GENERATOR),
        )
        conn.commit()
    elif version == 1:
        _migrate_v1_to_v2(conn)
        _migrate_v2_to_v3(conn)
    elif version == 2:
        _migrate_v2_to_v3(conn)
    # version == SCHEMA_VERSION: ensure canonical normalization (indexes)
    _ensure_v3_indexes(conn)
    if enable_events:
        tables = {
            r[0]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        if "event" not in tables:
            conn.executescript(_EVENT_TABLE)
    _ensure_v3_series_key_column(conn)

    conn.commit()
