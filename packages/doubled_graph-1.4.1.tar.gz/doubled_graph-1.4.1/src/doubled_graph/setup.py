"""`doubled-graph setup` — single-shot onboarding.

Runs the steps a first-time user would otherwise do by hand:

  1. Install/verify `@osovv/grace-cli` via the first available JS package
     manager (bun → npm → yarn → pnpm). When Bun isn't on PATH, the
     installer auto-falls back to running grace via `tsx` (Node-based
     TypeScript runner) — see `integrations/grace_cli.py`.
  2. Self-heal codegraphcontext transitive deps (e.g. tree-sitter-language-pack)
     so the first analyze doesn't fail on a missing import.
  3. Copy bundled methodology *content* (prompts/ + methodology/) into the
     repo. Loaded from `doubled_graph/data/...` via `importlib.resources`,
     so no separate methodology-repo clone is needed.
  4. Install bundled doubled-graph *skills* (the discovery layer) into
     every known IDE-native path simultaneously. We don't know which IDE
     the user will run — see `_install_skills` for the matrix:
       - Claude Code → `.claude/skills/<name>/SKILL.md` (canonical format)
       - Cursor      → `.cursor/rules/<name>.mdc` (frontmatter rewritten)
       - Continue, Roo, Kilo, OpenCode → `<dir>/rules/<name>.md` (frontmatter stripped)
       - Windsurf    → single `.windsurfrules` concat block, marker-fenced
       - OpenCode    → also adds `.opencode/rules/*.md` glob to opencode.json
     Idempotent: existing files are not overwritten.
  5. Ensure `.gitignore` excludes `.doubled-graph/cache/` and
     `.doubled-graph/logs/`. Always runs (even with `--skip-hooks`): the
     runtime dirs are populated by `analyze` and the MCP server, so the
     user's `git status` would otherwise stay polluted on first use.
     `config.json` and `drafts/` stay tracked (decision-history audit trail).
  6. Detect the user's IDE and register the MCP server:
       - Claude Code → `.mcp.json`
       - Cursor      → `.cursor/mcp.json`
       - Continue    → `.continue/config.json`
       - fallback    → print a manual instruction
  7. Install the `git post-commit` hook (`doubled-graph analyze --mode incremental`).
  8. Run the first full analyze pass (`doubled-graph analyze --mode full`).

Every step returns a structured record. Failures on optional steps (grace-cli,
skills, analyze) are reported but do not fail the whole run — `ok` flips to
False only when a step that blocks usefulness (no IDE register, no hooks)
errors out.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
from importlib import resources
from pathlib import Path
from typing import Any, Callable


def _have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _log(msg: str) -> None:
    """Emit a progress line on stderr so it doesn't mix with the JSON report on stdout."""
    print(msg, file=sys.stderr, flush=True)


def _summary(result: dict[str, Any]) -> str:
    """Short human-readable one-liner for a step result.

    For failures, prefer the classified `error_type` + `hint` over raw stderr —
    the full stderr tail is still in the JSON report for bug reports.
    """
    status = result.get("status", "?")
    if status == "installed":
        via = result.get("via")
        runtime = result.get("runtime")
        suffix = f" via {via}" + (f", runtime={runtime}" if runtime else "")
        return f"done (installed{suffix})" if via else "done (installed)"
    if status == "installed_via_tsx":
        # Node-based fallback for grace-cli when Bun isn't available.
        return f"done (installed via {result.get('via', '?')}, runtime=tsx)"
    if status == "already_installed":
        runtime = result.get("runtime")
        return (
            f"done (already installed, runtime={runtime})"
            if runtime else "done (already installed)"
        )
    if status == "dry_run":
        command = result.get("command") or result.get("cmd")
        return f"dry-run ({command})" if command else "dry-run"
    if status == "no_package_manager":
        return "skipped — no JS package manager (bun/npm/yarn/pnpm) found"
    if status == "failed":
        via = result.get("via", "?")
        error_type = result.get("error_type")
        hint = result.get("hint")
        if error_type and hint:
            return f"failed via {via} ({error_type}): {hint}"
        err = (result.get("stderr") or result.get("detail") or "")[:160]
        return f"failed via {via}: {err}" if err else f"failed via {via}"
    if status == "skipped":
        return "skipped"
    if status == "ok":
        return "done"
    if status == "manual":
        return "manual step required — see JSON report"
    if status == "registered":
        return f"done (wrote {result.get('path','')})"
    if status == "already_registered":
        return f"done (already present in {result.get('path','')})"
    if status == "not_a_git_repo":
        return "skipped (not a git repo)"
    if status == "healed":
        healed = result.get("healed") or []
        return f"done (auto-installed missing dep(s): {', '.join(healed)})"
    if status == "heal_failed":
        pkg = result.get("package") or result.get("missing", "?")
        hint = result.get("hint", "")
        return f"failed to install '{pkg}': {hint}"
    if status == "import_broken":
        pkg = result.get("package", "?")
        py = result.get("python_version", "?")
        return (
            f"package '{pkg}' is installed but Python {py} can't import it — "
            f"likely no wheel for this Python version. See `cgc_deps.hint` for fix."
        )
    if status == "cgc_broken":
        return f"codegraphcontext is broken — {result.get('detail', 'see report')}"
    if status == "still_broken_after_iters":
        return result.get("hint") or "CGC still broken after several heal attempts — see report"
    return status


def _detect_ide(repo: Path) -> str:
    """Best-effort IDE detection.

    Order: explicit markers in the repo win; otherwise check `which` for
    known IDE CLIs. Falls back to "none".
    """
    if (repo / ".claude").is_dir() or (repo / ".mcp.json").exists():
        return "claude-code"
    if (repo / ".cursor").is_dir():
        return "cursor"
    if (repo / ".continue").is_dir():
        return "continue"
    # CLI heuristics — last resort, user can override via --ide.
    if _have("claude"):
        return "claude-code"
    if _have("cursor"):
        return "cursor"
    return "none"


# ---------------------------------------------------------------------------
# bundled assets
# ---------------------------------------------------------------------------


def _copy_bundle(subdir: str, dest: Path, dry_run: bool) -> dict[str, Any]:
    """Copy a directory from `doubled_graph.data.<subdir>` into `dest`.

    Uses importlib.resources so this works both from an installed wheel and
    from an editable checkout. Missing bundle → surface, don't crash.
    """
    try:
        root = resources.files("doubled_graph").joinpath("data").joinpath(subdir)
    except (ModuleNotFoundError, AttributeError):
        return {"status": "skipped", "reason": f"bundle '{subdir}' not found in package"}

    if not root.is_dir():
        return {"status": "skipped", "reason": f"bundle '{subdir}' not present"}

    copied: list[str] = []
    skipped: list[str] = []

    def _walk(r, d: Path) -> None:
        for entry in r.iterdir():
            target = d / entry.name
            if entry.is_dir():
                if not dry_run:
                    target.mkdir(parents=True, exist_ok=True)
                _walk(entry, target)
            else:
                if target.exists():
                    skipped.append(str(target.relative_to(dest.parent)))
                    continue
                if not dry_run:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(entry.read_bytes())
                copied.append(str(target.relative_to(dest.parent)))

    if not dry_run:
        dest.mkdir(parents=True, exist_ok=True)
    _walk(root, dest)
    return {"status": "ok", "copied": copied, "skipped_existing": skipped, "dest": str(dest)}


# ---------------------------------------------------------------------------
# bundled skills — install per-IDE, native format per tool
# ---------------------------------------------------------------------------


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """Parse YAML-style `---` frontmatter into (dict, body).

    Minimal — only single-line `key: value` pairs, with optional surrounding
    quotes on the value. We don't need a full YAML parser for our 5 skills,
    and pulling pyyaml in just for this would inflate the install. If a future
    skill needs multi-line frontmatter, switch to a proper parser then.
    """
    lines = text.split("\n")
    if not lines or lines[0].strip() != "---":
        return {}, text
    end: int | None = None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end = i
            break
    if end is None:
        return {}, text
    fm: dict[str, str] = {}
    for line in lines[1:end]:
        if ":" not in line:
            continue
        k, _, v = line.partition(":")
        v = v.strip()
        if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
            v = v[1:-1]
        fm[k.strip()] = v
    body = "\n".join(lines[end + 1:]).lstrip("\n")
    return fm, body


def _strip_frontmatter(content: str) -> str:
    """Body only — for tools that read plain markdown rules (Roo, Kilo, OpenCode, Continue)."""
    _, body = _parse_frontmatter(content)
    return body


def _to_cursor_mdc(content: str) -> str:
    """Rewrite Claude Code SKILL.md frontmatter into Cursor `.mdc` form.

    `alwaysApply: false` keeps the rule on-demand — Cursor uses the description
    to decide when to surface it, mirroring Claude Code's skill discovery.
    Tools that auto-load every rule (Roo, Kilo, Windsurf) get the body without
    frontmatter via `_strip_frontmatter`; only Cursor needs this conversion.
    """
    fm, body = _parse_frontmatter(content)
    description = fm.get("description", "").replace('"', '\\"')
    return f'---\ndescription: "{description}"\nalwaysApply: false\n---\n\n{body}'


# (config_key, path_template_relative_to_repo, content_transformer)
# Each skill gets written to one file per entry. Path uses `{name}` for the
# skill folder name (e.g. `doubled-graph-before-edit`).
_PER_FILE_IDE_TARGETS: list[tuple[str, str, Callable[[str], str]]] = [
    ("claude-code", ".claude/skills/{name}/SKILL.md", lambda c: c),
    ("cursor", ".cursor/rules/{name}.mdc", _to_cursor_mdc),
    ("continue", ".continue/rules/{name}.md", _strip_frontmatter),
    ("roo-code", ".roo/rules/{name}.md", _strip_frontmatter),
    ("kilo-code", ".kilocode/rules/{name}.md", _strip_frontmatter),
    ("opencode", ".opencode/rules/{name}.md", _strip_frontmatter),
]

_WINDSURF_MARKER_START = "<!-- doubled-graph-skills:start -->"
_WINDSURF_MARKER_END = "<!-- doubled-graph-skills:end -->"


def _write_skill_file(
    repo: Path, rel_path: str, content: str, dry_run: bool
) -> dict[str, str]:
    """Write a single skill file, idempotent: existing files are not overwritten."""
    target = repo / rel_path
    rel = str(target.relative_to(repo))
    if target.exists():
        return {"path": rel, "status": "skipped_existing"}
    if not dry_run:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    return {"path": rel, "status": "written"}


def _install_skills_windsurf(
    repo: Path, skills: list[tuple[str, str]], dry_run: bool
) -> dict[str, str]:
    """Append all skills as a single marked block to `.windsurfrules`.

    Windsurf reads only one rules file at the repo root, so we concat all
    skills with section headers. The `<!-- doubled-graph-skills:start -->`
    marker makes the block recognizable for idempotent re-runs and easy
    manual removal — if a user wants to drop our rules, they delete the
    marked block and the rest of `.windsurfrules` survives.
    """
    target = repo / ".windsurfrules"
    rel = str(target.relative_to(repo))
    existing = target.read_text(encoding="utf-8") if target.exists() else ""
    if _WINDSURF_MARKER_START in existing:
        return {"path": rel, "status": "already_present"}

    parts: list[str] = [_WINDSURF_MARKER_START, ""]
    for name, content in skills:
        body = _strip_frontmatter(content).strip()
        parts.append(f"# {name}")
        parts.append("")
        parts.append(body)
        parts.append("")
    parts.append(_WINDSURF_MARKER_END)
    block = "\n".join(parts) + "\n"

    new_content = (existing.rstrip() + "\n\n" + block) if existing else block
    if not dry_run:
        target.write_text(new_content, encoding="utf-8")
    return {"path": rel, "status": "appended" if existing else "written"}


def _merge_opencode_instructions(repo: Path, dry_run: bool) -> dict[str, str]:
    """Add `.opencode/rules/*.md` to opencode.json's `instructions` glob list.

    OpenCode auto-discovers `AGENTS.md` but not `.opencode/rules/`; the glob
    in `opencode.json` is what teaches it to load our rule files. We don't
    touch `AGENTS.md` itself — the methodology already manages that file via
    `doubled-graph init` (phase block + module index), and silently appending
    skill content there would conflict with that ownership.
    """
    cfg = repo / "opencode.json"
    rel = "opencode.json"
    glob = ".opencode/rules/*.md"
    data: dict[str, Any] = {}
    if cfg.exists():
        try:
            data = json.loads(cfg.read_text(encoding="utf-8") or "{}")
        except json.JSONDecodeError as e:
            return {"path": rel, "status": "skipped_invalid_json", "detail": str(e)}
    instructions = data.get("instructions")
    if instructions is None:
        instructions = []
    if not isinstance(instructions, list):
        return {"path": rel, "status": "skipped_instructions_not_list"}
    if glob in instructions:
        return {"path": rel, "status": "already_present"}
    instructions.append(glob)
    data["instructions"] = instructions
    if not dry_run:
        cfg.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {"path": rel, "status": "merged"}


def _install_skills(repo: Path, dry_run: bool) -> dict[str, Any]:
    """Install bundled skills into all known per-IDE skill paths.

    Per-tool format conversion:
      - Claude Code: SKILL.md verbatim (canonical format).
      - Cursor: `.mdc` with rewritten frontmatter (description + alwaysApply).
      - Continue / Roo Code / Kilo Code / OpenCode: plain `.md`, frontmatter stripped.
      - Windsurf: single `.windsurfrules` concat block, marker-fenced.
      - OpenCode also gets `.opencode/rules/*.md` glob added to opencode.json.

    We write to ALL of these unconditionally — we don't know which IDE the
    user will end up running, and the cost of an unused `.roo/rules/` dir
    is far lower than the cost of the user discovering their IDE doesn't
    pick up our skills. Existing files are not overwritten (idempotent).
    """
    try:
        skills_root = resources.files("doubled_graph").joinpath("data").joinpath("skills")
    except (ModuleNotFoundError, AttributeError):
        return {"status": "skipped", "reason": "skills bundle not found in package"}

    if not skills_root.is_dir():
        return {"status": "skipped", "reason": "skills bundle not present"}

    skills: list[tuple[str, str]] = []
    for entry in sorted(skills_root.iterdir(), key=lambda e: e.name):
        if not entry.is_dir():
            continue
        skill_md = entry.joinpath("SKILL.md")
        if not skill_md.is_file():
            continue
        skills.append((entry.name, skill_md.read_text(encoding="utf-8")))

    if not skills:
        return {"status": "skipped", "reason": "no skills found in bundle"}

    per_ide: dict[str, list[dict[str, str]]] = {}
    for ide_key, path_template, transformer in _PER_FILE_IDE_TARGETS:
        results: list[dict[str, str]] = []
        for name, content in skills:
            rel_path = path_template.format(name=name)
            transformed = transformer(content)
            results.append(_write_skill_file(repo, rel_path, transformed, dry_run))
        per_ide[ide_key] = results

    per_ide["windsurf"] = [_install_skills_windsurf(repo, skills, dry_run)]
    per_ide["opencode_config"] = [_merge_opencode_instructions(repo, dry_run)]

    return {
        "status": "ok",
        "skill_count": len(skills),
        "skills": [name for name, _ in skills],
        "per_ide": per_ide,
    }


# ---------------------------------------------------------------------------
# grace CLI (upstream Bun package)
# ---------------------------------------------------------------------------


def _install_grace_cli(dry_run: bool) -> dict[str, Any]:
    """Delegate to the shared installer so setup and lazy-install stay in sync.

    `log_to_stderr=True` surfaces "installing via npm…" on stderr — without it the
    user stares at a blank terminal for 10–30s while the package manager works.
    """
    from doubled_graph.integrations.grace_cli import try_install_grace_cli

    return try_install_grace_cli(dry_run=dry_run, log_to_stderr=True)


# ---------------------------------------------------------------------------
# MCP registration per IDE
# ---------------------------------------------------------------------------


def _mcp_server_entry() -> dict[str, Any]:
    # `command: sys.executable` pins the exact Python that ran `setup` (the
    # pipx venv interpreter, or whatever else doubled-graph is installed in).
    # Earlier versions wrote `command: "doubled-graph"`, but GUI apps on macOS
    # (Claude Desktop, Cursor, Continue) inherit a stripped PATH from launchd
    # that doesn't include ~/.local/bin — the shim wasn't found, and tools
    # failed with errors that looked like missing-dependency bugs. Going via
    # an absolute python path bypasses PATH entirely.
    return {
        "command": sys.executable,
        "args": ["-m", "doubled_graph", "serve"],
    }


def _register_mcp(repo: Path, ide: str, dry_run: bool) -> dict[str, Any]:
    if ide == "none":
        return {
            "status": "manual",
            "hint": (
                "No supported IDE detected. Register doubled-graph manually as an "
                "MCP server with `command=doubled-graph args=['serve']`."
            ),
        }

    if ide == "claude-code":
        cfg = repo / ".mcp.json"
        return _merge_json_mcp(cfg, key="mcpServers", name="doubled-graph", dry_run=dry_run)
    if ide == "cursor":
        cfg = repo / ".cursor" / "mcp.json"
        return _merge_json_mcp(cfg, key="mcpServers", name="doubled-graph", dry_run=dry_run)
    if ide == "continue":
        cfg = repo / ".continue" / "config.json"
        return _merge_json_mcp(cfg, key="mcpServers", name="doubled-graph", dry_run=dry_run)
    return {"status": "unknown_ide", "ide": ide}


def _merge_json_mcp(cfg_path: Path, key: str, name: str, dry_run: bool) -> dict[str, Any]:
    data: dict[str, Any] = {}
    if cfg_path.exists():
        try:
            data = json.loads(cfg_path.read_text(encoding="utf-8") or "{}")
        except json.JSONDecodeError as e:
            return {"status": "failed", "reason": f"invalid existing JSON at {cfg_path}: {e}"}
    servers = data.setdefault(key, {})
    if not isinstance(servers, dict):
        return {"status": "failed", "reason": f"{cfg_path}:{key} is not an object"}

    if name in servers:
        return {"status": "already_registered", "path": str(cfg_path)}
    servers[name] = _mcp_server_entry()
    if dry_run:
        return {"status": "dry_run", "path": str(cfg_path), "entry": servers[name]}
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {"status": "registered", "path": str(cfg_path)}


# ---------------------------------------------------------------------------
# hooks + first analyze
# ---------------------------------------------------------------------------


def _install_hooks(repo: Path, dry_run: bool) -> dict[str, Any]:
    if not (repo / ".git").exists():
        return {"status": "not_a_git_repo", "hint": "Run `git init` first."}
    from doubled_graph.hooks_installer import install_hooks

    report = install_hooks(repo_path=repo, post_commit=True, dry_run=dry_run)
    return {"status": "ok", "report": report}


def _first_analyze(repo: Path, dry_run: bool) -> dict[str, Any]:
    if dry_run:
        return {"status": "dry_run", "cmd": "doubled-graph analyze --mode full"}
    from doubled_graph.tools.analyze import analyze

    try:
        res = analyze(repo_path=repo, mode="full", force=True)
    except Exception as e:  # noqa: BLE001
        return {"status": "failed", "detail": f"{type(e).__name__}: {e}"}
    return {
        "status": "ok",
        "mode_used": res.mode_used,
        "duration_ms": res.duration_ms,
        "warnings": [w.code for w in res.warnings],
    }


# ---------------------------------------------------------------------------
# CGC dependency self-heal
# ---------------------------------------------------------------------------


def _try_import_cgc() -> tuple[bool, str | None]:
    """Try the same imports CGC._ensure() does. Return (ok, missing_module_or_None)."""
    try:
        # Match the import set in integrations/cgc.py:_ensure exactly so we
        # catch the same failure modes the runtime hits.
        from codegraphcontext.core import get_database_manager  # type: ignore  # noqa: F401
        from codegraphcontext.tools.code_finder import CodeFinder  # type: ignore  # noqa: F401
        from codegraphcontext.tools.graph_builder import GraphBuilder  # type: ignore  # noqa: F401
    except ModuleNotFoundError as e:
        return False, e.name
    except Exception:
        # Not a missing-module problem — return ok=False with no name so caller
        # surfaces a generic CGC error rather than trying to install something.
        return False, None
    return True, None


def _heal_cgc_deps(dry_run: bool, max_iter: int = 5) -> dict[str, Any]:
    """Detect and self-install CGC's missing transitive runtime deps.

    Why this exists: older CGC releases (0.1.x / 0.2.x) didn't pin all their
    tree-sitter transitive deps. A fresh `pipx install doubled-graph` could
    succeed, then `doubled-graph analyze` fail with ModuleNotFoundError. We
    pre-empt that by importing CGC here and, on failure, running
    `<sys.executable> -m pip install <missing-pkg>` — which works in pipx
    venvs (pipx venvs ship pip), in regular venvs, and in conda envs alike.

    Failure modes we handle explicitly:
      - "module truly absent" → pip install, retry.
      - "module looks installed but Python can't import it" (pip says
        'Requirement already satisfied' twice in a row for the same name) →
        bail with a Python-version diagnosis. This is the cutting-edge-Python
        case where wheels for the user's interpreter don't exist or don't
        load (e.g. native ABI3 .so unsupported on Python 3.14).
      - bounded by `max_iter` to be safe against truly degenerate cases.
    """
    if dry_run:
        return {
            "status": "dry_run",
            "note": "would import codegraphcontext and pip-install any missing transitive deps",
        }

    healed: list[str] = []
    last_attempted_pkg: str | None = None
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}"

    for _ in range(max_iter):
        ok, missing = _try_import_cgc()
        if ok:
            return {"status": "healed", "healed": healed} if healed else {"status": "ok"}
        if missing is None:
            return {
                "status": "cgc_broken",
                "detail": "codegraphcontext failed to import for a reason other than a missing module",
                "healed_before_failure": healed,
            }
        if missing.startswith("codegraphcontext"):
            return {
                "status": "cgc_broken",
                "detail": f"codegraphcontext itself is not importable (missing: {missing})",
                "hint": "Reinstall: `pipx reinstall doubled-graph` (or `pip install --force-reinstall doubled-graph`).",
                "healed_before_failure": healed,
            }

        pkg = missing.replace("_", "-")  # PyPI canonical name

        # Same package missing again right after we just "installed" it? Then
        # pip is saying 'Requirement already satisfied' but Python can't load
        # the module. Looping won't help — diagnose Python version mismatch
        # and bail.
        if pkg == last_attempted_pkg:
            return {
                "status": "import_broken",
                "missing_module": missing,
                "package": pkg,
                "python_version": py_ver,
                "hint": (
                    f"`{pkg}` is installed in this environment but Python {py_ver} "
                    f"can't import it. The most common cause is a Python version "
                    f"unsupported by the available wheels (cutting-edge Pythons "
                    f"like 3.14 often lack native-extension wheels for many months). "
                    f"Recreate the install on a supported interpreter, e.g.:\n"
                    f"    pipx install --python python3.12 --force doubled-graph\n"
                    f"    pipx install --python python3.13 --force doubled-graph"
                ),
                "healed_before_failure": healed,
            }

        last_attempted_pkg = pkg
        cmd = [sys.executable, "-m", "pip", "install", pkg]
        _log(f"         missing transitive dep '{missing}' — installing {pkg}…")
        # Stream output live so the user sees pip's progress, but also capture
        # for the structured error report on failure.
        import subprocess as _sp
        proc = _sp.Popen(
            cmd, stdout=_sp.PIPE, stderr=_sp.STDOUT, text=True, bufsize=1
        )
        assert proc.stdout is not None
        captured: list[str] = []
        for line in proc.stdout:
            sys.stderr.write(line)
            sys.stderr.flush()
            captured.append(line)
        proc.wait()
        if proc.returncode != 0:
            return {
                "status": "heal_failed",
                "missing": missing,
                "package": pkg,
                "command": " ".join(cmd),
                "exit_code": proc.returncode,
                "stderr_tail": "".join(captured)[-1500:],
                "hint": (
                    f"Could not install {pkg} into the doubled-graph environment. "
                    "If you're on a system Python with PEP 668, the install was likely "
                    "blocked — switch to `pipx install doubled-graph` and retry."
                ),
                "healed_before_failure": healed,
            }
        healed.append(pkg)

    return {
        "status": "still_broken_after_iters",
        "healed": healed,
        "hint": (
            f"Healed {len(healed)} transitive dep(s) but CGC still fails to import after "
            f"{max_iter} iterations. Likely upstream regression — file an issue."
        ),
    }


# ---------------------------------------------------------------------------
# entry
# ---------------------------------------------------------------------------


def _summary_gitignore(result: dict[str, Any]) -> str:
    """One-liner for the `gitignore` step."""
    status = result.get("status", "?")
    if status == "appended":
        return f"appended {result.get('appended', [])}"
    if status == "already_present":
        return "already covers .doubled-graph runtime dirs"
    if status == "dry_run":
        return f"would-append {result.get('would_append', [])}"
    return status


def _summary_skills(result: dict[str, Any]) -> str:
    """One-liner for the `skills` step: count writes vs. existing skips."""
    if result.get("status") != "ok":
        reason = result.get("reason") or result.get("status", "?")
        return f"skipped ({reason})"
    written = 0
    skipped = 0
    for ide_results in result.get("per_ide", {}).values():
        for r in ide_results:
            s = r.get("status", "")
            if s in ("written", "appended", "merged"):
                written += 1
            elif s in ("skipped_existing", "already_present"):
                skipped += 1
    return f"done ({result['skill_count']} skills × {len(result['per_ide'])} IDE targets; {written} written, {skipped} kept existing)"


def run_setup(
    repo_path: Path,
    ide: str = "auto",
    skip_grace_cli: bool = False,
    skip_hooks: bool = False,
    skip_analyze: bool = False,
    skip_skills: bool = False,
    dry_run: bool = False,
) -> dict[str, Any]:
    report: dict[str, Any] = {"repo": str(repo_path), "dry_run": dry_run}
    total = 8
    prefix = "[dry-run] " if dry_run else ""

    # 1. Grace CLI — slow: subprocess to a JS package manager can take 10–30s.
    _log(f"{prefix}[1/{total}] Installing @osovv/grace-cli (may take 10–30s)…")
    report["grace_cli"] = (
        {"status": "skipped"} if skip_grace_cli else _install_grace_cli(dry_run)
    )
    _log(f"         {_summary(report['grace_cli'])}")

    # 2. CGC dep self-heal — protects against upstream's transitive-dep gaps
    # (e.g. tree-sitter-language-pack), so step 7 doesn't fail on import.
    # Skipped if --skip-analyze (no point if we won't use CGC anyway).
    _log(f"{prefix}[2/{total}] Verifying codegraphcontext backend imports…")
    report["cgc_deps"] = (
        {"status": "skipped"} if skip_analyze else _heal_cgc_deps(dry_run)
    )
    _log(f"         {_summary(report['cgc_deps'])}")

    # 3. Bundled prompts + methodology — fast. These are our methodology
    # *content* (markdown). Discovery (i.e. "skills" — telling the IDE
    # skill-system when to apply them) is step 4.
    _log(f"{prefix}[3/{total}] Copying bundled prompts/ and methodology/ into the repo…")
    report["prompts"] = _copy_bundle("prompts", repo_path / "prompts", dry_run)
    report["methodology"] = _copy_bundle("methodology", repo_path / "methodology", dry_run)
    _log(
        f"         prompts: {_summary(report['prompts'])}; "
        f"methodology: {_summary(report['methodology'])}"
    )

    # 4. Bundled skills — install our own SKILL.md files into every known
    # IDE skill path. Self-contained: skills don't reference prompts/ or
    # methodology/, so they keep working even if the user deletes those.
    # Written to all 7 IDE-native paths unconditionally — we don't know
    # which IDE the user will run with.
    _log(f"{prefix}[4/{total}] Installing doubled-graph skills for all known IDEs…")
    report["skills"] = (
        {"status": "skipped"} if skip_skills else _install_skills(repo_path, dry_run)
    )
    _log(f"         {_summary_skills(report['skills'])}")

    # 5. .gitignore — fast. Always runs (even with --skip-hooks): the runtime
    # dirs `.doubled-graph/cache/` and `.doubled-graph/logs/` are populated by
    # `analyze` and the MCP server, not by hooks, so the user's `git status`
    # would otherwise stay polluted even if they opted out of hooks.
    from doubled_graph.hooks_installer import ensure_gitignore_entries
    _log(f"{prefix}[5/{total}] Ensuring .gitignore covers .doubled-graph runtime dirs…")
    report["gitignore"] = ensure_gitignore_entries(repo_path, dry_run)
    _log(f"         {_summary_gitignore(report['gitignore'])}")

    # 6. IDE MCP registration — fast.
    resolved_ide = ide if ide != "auto" else _detect_ide(repo_path)
    report["ide_detected"] = resolved_ide
    _log(f"{prefix}[6/{total}] Registering MCP server (IDE: {resolved_ide})…")
    report["mcp_register"] = _register_mcp(repo_path, resolved_ide, dry_run)
    _log(f"         {_summary(report['mcp_register'])}")

    # 7. Hooks — fast.
    _log(f"{prefix}[7/{total}] Installing git post-commit hook…")
    report["hooks"] = {"status": "skipped"} if skip_hooks else _install_hooks(repo_path, dry_run)
    _log(f"         {_summary(report['hooks'])}")

    # 8. First analyze — slow: AST scan of the whole repo, size-dependent.
    _log(f"{prefix}[8/{total}] Running first full analyze (slow on large repos)…")
    report["analyze"] = (
        {"status": "skipped"} if skip_analyze else _first_analyze(repo_path, dry_run)
    )
    _log(f"         {_summary(report['analyze'])}")

    # Overall ok: MCP registered (or manual hint returned) + hooks installed
    # (or skipped). Grace-cli and skills failures are non-fatal (skills are
    # discovery hints — methodology still works without them; grace-cli only
    # affects gateway subcommands `lint`/`module show`/`file show`).
    mcp_ok = report["mcp_register"]["status"] in (
        "registered", "already_registered", "manual", "dry_run"
    )
    hooks_ok = report["hooks"]["status"] in ("ok", "skipped")
    report["ok"] = mcp_ok and hooks_ok
    _log("Setup complete." if report["ok"] else "Setup finished with errors — see JSON report.")
    return report
