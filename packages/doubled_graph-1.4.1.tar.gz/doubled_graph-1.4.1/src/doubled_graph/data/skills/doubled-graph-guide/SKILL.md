---
name: doubled-graph-guide
description: "Use when the user asks about the doubled-graph methodology itself — what MCP tools are available, how impact analysis or drift detection works, what the dual-graph approach is, or which workflow skill to pick. Examples: 'what can doubled-graph do', 'how do I check impact', 'what is the drift workflow', 'what tools does doubled-graph give me'."
---

# doubled-graph — обзор и навигация

doubled-graph — MCP-сервер, который держит **два графа кода одновременно**:

- **computed graph** — то, что AST-парсер реально находит в коде (через CodeGraphContext);
- **declared graph** — то, что зафиксировано в `docs/*.xml` артефактах (план, контракты, верификация).

Расхождение этих графов — **дрейф**. Цель методологии — нулевой дрейф между кодом и документацией.

---

## MCP-инструменты (все — реальные, делают работу в-процессе)

Сервер `doubled-graph` зарегистрирован в IDE — все операции через MCP, не через Bash. MCP быстрее (без subprocess), возвращает типизированный JSON, экономит approval-prompty.

### Native (computed × declared graph operations)

| Tool | Когда вызывать |
|---|---|
| `doubled-graph.analyze` | построить или обновить computed graph (`mode="full"` или `mode="incremental"`) |
| `doubled-graph.impact` | **до** правки символа — узнать blast radius (callers, affected modules, risk level) |
| `doubled-graph.context` | 360° view: символ + контракт + входящие/исходящие вызовы |
| `doubled-graph.detect_changes` | **до** коммита — обнаружить дрейф между кодом и `docs/*.xml` |
| `doubled-graph.health` | health-отчёт: модули без `V-M-*`, drift count, open `DRIFT.md` entries |

### Wrappers (тонкие обёртки над `grace` CLI)

| Tool | Назначение |
|---|---|
| `doubled-graph.lint` | проверка парности якорей `START_*` / `END_*`, целостности ID-ссылок |
| `doubled-graph.module_show` / `doubled-graph.module_find` | прочитать / найти `M-*` модуль |
| `doubled-graph.file_show` | извлечь `MODULE_CONTRACT` / `CONTRACT:fn` / `BLOCK_*` секции из файла |

**Это ВСЕ MCP-tools.** Раньше в namespace были «gateway» tools (`refresh`/`plan`/`execute`/`fix`/`refactor`/...) — они возвращали директиву к несуществующим upstream skills и не делали работу. С 1.4.0 они **удалены**. Их функции теперь — workflow-инструкции в наших skills (см. ниже), исполняемые агентом своими `Read`/`Edit`/`Write`/`Bash` tools.

---

## CLI-команды (только install-time, через Bash, для человека не AI)

| Команда | Назначение |
|---|---|
| `doubled-graph setup` | онбординг репо: установка skills, MCP, hooks, первый analyze |
| `doubled-graph init-hooks --all` | git/Claude Code hooks |
| `doubled-graph phase get` / `doubled-graph phase set <val>` | прочитать / переключить режим методологии |
| `doubled-graph status` | quick дамп текущего состояния (фаза + freshness) |

---

## Семейство skills (workflows для агента)

| Skill | Когда |
|---|---|
| `doubled-graph-before-edit` | до любой правки кода — обязательный impact-gate |
| `doubled-graph-after-edit` | после правки, до коммита — drift / lint / tests / contract-check |
| `doubled-graph-drift` | `detect_changes` вернул непустой drift |
| `doubled-graph-manual-edit` | человек поправил код вручную, без участия ИИ |
| `doubled-graph-refactor` | rename/move/split/extract — координация code + XML + V-M-* |
| `doubled-graph-verify` | модуль без `V-M-*` тестов — добавить покрытие |

**Workflow'ы — markdown в системном промпте**, не tool calls. Агент читает skill, исполняет шаги через свои `Read`/`Edit`/`Write`/`Bash` + наши `doubled-graph.*` MCP tools.

---

## Режим методологии

В корне репо есть `AGENTS.md` с блоком `<!-- doubled-graph:phase:start -->`:

- **`migration`** — код = ground-truth, артефакты догоняют. После любой семантической правки — обновить `docs/*.xml` через `Edit` (см. `doubled-graph-after-edit` шаг 2). Контракты можно нарушать (фиксируются как факт).
- **`post_migration`** — артефакты = ground-truth. Дрейф — подозрение на баг или неодобренное требование. Контракты НЕЛЬЗЯ нарушать без планирования (см. `prompts/new-project/02-04*.md` или ad-hoc workflow).

Прочитай этот блок до любой нетривиальной работы. Если `AGENTS.md` нет — default `post_migration`.

---

## Базовый цикл

```
1. Намерение править X
   → doubled-graph-before-edit (impact + risk-gate)
2. Правка
3. Перед коммитом
   → doubled-graph-after-edit (drift + lint + tests)
4. Если drift найден
   → doubled-graph-drift
5. Если правил человек, не ИИ
   → doubled-graph-manual-edit
6. Если нужен рефакторинг (rename/move)
   → doubled-graph-refactor
7. Если модуль без V-M-* тестов
   → doubled-graph-verify
```

---

## Пять принципов в одной строке

1. Любая правка = с `impact` до и `detect_changes` после.
2. HIGH/CRITICAL risk → стоп, ждём подтверждения пользователя.
3. Якоря (`START_CONTRACT`, `START_BLOCK_*`, `MODULE_CONTRACT`) — священны: правка их ломать не должна.
4. Дрейф решается типизированно (per-type), нерешённый — в `docs/DRIFT.md`.
5. Ручные правки человека уважаются, но размечаются `(DG-Authored: human)` в `CHANGE_SUMMARY`.

---

## One-off scenarios (через `prompts/`, не через MCP)

Эти жизненные сценарии — **одноразовые**, не часть day-to-day workflow. Они в `prompts/`, не в skills:

| Сценарий | Где |
|---|---|
| Новый проект с нуля | `prompts/new-project/00-entry-prompt.md` |
| Миграция legacy кодбазы под методологию | `prompts/migrate-existing-project/00-entry-prompt.md` |

Если `prompts/` нет — `doubled-graph setup` их скопирует из bundle.

---

## Если что-то не работает

- **MCP сервер не отвечает**: проверь `.mcp.json` в корне репо (Claude Code) или эквивалент для другой IDE. Запуск `doubled-graph setup` пересоздаёт регистрацию.
- **MCP недоступен в текущей IDE** (degraded mode): все наши tools имеют CLI-форму через Bash — `doubled-graph analyze --mode incremental --paths X`, `doubled-graph impact <symbol> --direction upstream`, и т.д. См. `doubled-graph --help`. Это медленнее (subprocess), но работает.
- **`grace` CLI не установлен** (нужен для wrapper-tools `lint` / `file_show` / `module_show`): `bun add -g @osovv/grace-cli` или установится сам через `doubled-graph setup`.
- **`AGENTS.md` нет**: запусти one-off prompt из `prompts/new-project/` для bootstrap, либо сразу установи phase: `doubled-graph phase set post_migration` (создаст `AGENTS.md` с phase-блоком, но без модуль-индекса).
- **`docs/*.xml` нет** (миграция legacy): запусти reverse-engineering промпт `prompts/migrate-existing-project/00-entry-prompt.md`.
