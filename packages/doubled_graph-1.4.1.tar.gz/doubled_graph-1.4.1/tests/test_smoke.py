"""Smoke tests — exercise module imports, phase parsing, declared-graph parsing,
analyze stub path, hook-installer dry-run. No CGC/grace-cli required.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest


def test_package_imports():
    import doubled_graph

    assert doubled_graph.__version__


def test_phase_default_when_no_agents_md(tmp_path: Path):
    from doubled_graph.policy.phase import read_phase

    assert read_phase(tmp_path) == "post_migration"


def test_phase_migration_parsed(tmp_path: Path):
    from doubled_graph.policy.phase import read_phase

    (tmp_path / "AGENTS.md").write_text(
        """
# Project

<!-- doubled-graph:phase:start -->
## doubled-graph phase
phase: migration
updated: 2026-04-18
<!-- doubled-graph:phase:end -->
""",
        encoding="utf-8",
    )
    assert read_phase(tmp_path) == "migration"


def test_phase_invalid_value_falls_back_to_default(tmp_path: Path):
    from doubled_graph.policy.phase import read_phase

    (tmp_path / "AGENTS.md").write_text(
        """
<!-- doubled-graph:phase:start -->
phase: gibberish
<!-- doubled-graph:phase:end -->
""",
        encoding="utf-8",
    )
    assert read_phase(tmp_path) == "post_migration"


def test_declared_graph_empty_when_no_docs(tmp_path: Path):
    from doubled_graph.graphs.declared import load_declared_graph

    g = load_declared_graph(tmp_path)
    assert g.modules == {}
    assert g.verification == {}
    assert g.loaded_from == []


def test_declared_graph_tolerates_malformed_xml(tmp_path: Path):
    from doubled_graph.graphs.declared import load_declared_graph

    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "development-plan.xml").write_text("<Plan><Module id='", encoding="utf-8")
    g = load_declared_graph(tmp_path)
    assert any(item.startswith("!") for item in g.loaded_from)


def test_analyze_runs_without_cgc(tmp_path: Path, monkeypatch):
    """analyze() must return a structured result even when CGC import fails."""
    from doubled_graph.tools import analyze as analyze_mod
    from doubled_graph.integrations.cgc import CGCUnavailable

    class _FakeCGC:
        def __init__(self, *_args, **_kw):
            pass

        def analyze_full(self):
            raise CGCUnavailable("simulated missing CGC for smoke test")

        def analyze_incremental(self, _files):
            raise CGCUnavailable("simulated missing CGC for smoke test")

    monkeypatch.setattr(analyze_mod, "CGC", _FakeCGC)

    result = analyze_mod.analyze(repo_path=tmp_path, mode="full")
    assert result.mode_used == "full"
    assert any(w.code == "CGC_BACKEND_FAIL" for w in result.warnings)
    # Log event written.
    logs = list((tmp_path / ".doubled-graph" / "logs").iterdir())
    assert logs, "analyze should write a log event"


def test_analyze_writes_fingerprint_on_success(tmp_path: Path, monkeypatch):
    """Successful analyze must persist the fingerprint so next auto-mode picks
    incremental. Regression guard for task 3 in TODO_DEV.
    """
    from doubled_graph.integrations.cgc import AnalyzeStats
    from doubled_graph.storage import paths as sp
    from doubled_graph.tools import analyze as analyze_mod

    class _OKCGC:
        def __init__(self, *_args, **_kw):
            pass

        def analyze_full(self):
            return AnalyzeStats(files_processed=3, symbols_added=7)

        def analyze_incremental(self, _files):
            return AnalyzeStats(files_processed=1)

    monkeypatch.setattr(analyze_mod, "CGC", _OKCGC)

    res = analyze_mod.analyze(repo_path=tmp_path, mode="full")
    assert res.stats.files_processed == 3
    assert res.stats.symbols_added == 7
    assert sp.fingerprint_path(tmp_path).exists()


def test_impact_shape_without_cgc(tmp_path: Path, monkeypatch):
    """impact() must return a structurally valid result even when CGC errors."""
    from doubled_graph.integrations import cgc as cgc_mod
    from doubled_graph.tools import impact as impact_mod

    class _FailCGC:
        def __init__(self, *_a, **_k):
            pass

        def find_symbol(self, _n):
            raise cgc_mod.CGCUnavailable("simulated")

        def find_callers(self, _t, depth=3):
            raise cgc_mod.CGCUnavailable("simulated")

        def find_callees(self, _t, depth=3):
            raise cgc_mod.CGCUnavailable("simulated")

    monkeypatch.setattr(impact_mod, "CGC", _FailCGC)
    res = impact_mod.impact(repo_path=tmp_path, target="foo")
    assert res.target_resolved.name == "foo"
    assert res.risk.level in ("LOW", "MEDIUM", "HIGH", "CRITICAL", "NONE")
    assert any(w.code == "CGC_BACKEND_FAIL" for w in res.warnings)


def test_impact_classifies_by_caller_count(tmp_path: Path, monkeypatch):
    """risk.level must escalate with direct-caller count. Guard for task 4."""
    from doubled_graph.integrations.cgc import Callsite, SymbolRecord
    from doubled_graph.tools import impact as impact_mod

    class _ManyCallersCGC:
        def __init__(self, *_a, **_k):
            pass

        def find_symbol(self, name):
            return [SymbolRecord(name=name, file="src/x.py", line=10)]

        def find_callers(self, _t, depth=3):
            return [
                Callsite(name=f"c{i}", file=f"src/c{i}.py", line=i, depth=1)
                for i in range(5)
            ]

        def find_callees(self, _t, depth=3):
            return []

    monkeypatch.setattr(impact_mod, "CGC", _ManyCallersCGC)
    res = impact_mod.impact(repo_path=tmp_path, target="foo")
    assert len(res.direct) == 5
    # 5 direct callers → HIGH band per _classify_risk
    assert res.risk.level == "HIGH"


def test_context_returns_contract_and_module(tmp_path: Path, monkeypatch):
    """context() must join CGC symbol, declared module, and source contract."""
    from doubled_graph.integrations.cgc import SymbolRecord, Callsite
    from doubled_graph.tools import context as ctx_mod

    # Declared graph: one module that owns src/
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "development-plan.xml").write_text(
        "<Plan><Module id='M-FOO'><purpose>Foo logic</purpose><path>src</path></Module></Plan>",
        encoding="utf-8",
    )
    (docs / "knowledge-graph.xml").write_text(
        "<Graph><Module id='M-FOO'><Export name='bar'/><CrossLink to='M-OTHER'/></Module></Graph>",
        encoding="utf-8",
    )
    src = tmp_path / "src"
    src.mkdir()
    (src / "a.py").write_text(
        "# MODULE_CONTRACT\n# purpose: demo\n# links: M-OTHER\n# END_MODULE_CONTRACT\n\ndef bar():\n    pass\n",
        encoding="utf-8",
    )

    class _CGC:
        def __init__(self, *_a, **_k):
            pass

        def find_symbol(self, name):
            return [SymbolRecord(name=name, file=str(src / "a.py"), line=6, kind="function")]

        def find_callers(self, _t, depth=2):
            return [Callsite(name="caller", file=str(src / "b.py"), line=3, depth=1)]

        def find_callees(self, _t, depth=2):
            return []

    monkeypatch.setattr(ctx_mod, "CGC", _CGC)
    res = ctx_mod.context(repo_path=tmp_path, name="bar")
    assert res.symbol.file == "src/a.py"
    assert res.module.id == "M-FOO"
    assert res.module.purpose == "Foo logic"
    assert "MODULE_CONTRACT" in res.contract.text
    assert "M-OTHER" in res.contract.links
    assert any(c.name == "caller" for c in res.callers)


def test_detect_changes_finds_drift(tmp_path: Path, monkeypatch):
    """detect_changes must surface code_without_module, markup_missing,
    module_without_code, missing_verification.
    """
    from doubled_graph.tools import detect_changes as dc_mod

    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "development-plan.xml").write_text(
        "<Plan>"
        "<Module id='M-ALIVE'><path>src/alive</path></Module>"
        "<Module id='M-ORPHAN'><path>src/gone</path></Module>"
        "</Plan>",
        encoding="utf-8",
    )
    src = tmp_path / "src" / "alive"
    src.mkdir(parents=True)
    (src / "x.py").write_text("def a(): pass\n", encoding="utf-8")
    new_area = tmp_path / "src" / "uncovered"
    new_area.mkdir()
    (new_area / "y.py").write_text("def b(): pass\n", encoding="utf-8")

    # Make files_for_scope return the two files (bypass git).
    monkeypatch.setattr(
        dc_mod,
        "_files_for_scope",
        lambda _r, _s, _b, _sr: ["src/alive/x.py", "src/uncovered/y.py"],
    )

    # Stub CGC so symbols_in_file returns something useful for the uncovered file.
    from doubled_graph.integrations.cgc import SymbolsInFile, SymbolRecord

    class _CGC:
        def __init__(self, *_a, **_k):
            pass

        def symbols_in_file(self, path):
            return SymbolsInFile(
                path=path,
                functions=[SymbolRecord(name="b", file=path, line=1)],
            )

    monkeypatch.setattr(dc_mod, "CGC", _CGC)

    res = dc_mod.detect_changes(repo_path=tmp_path, scope="all")
    assert any(c.file == "src/uncovered/y.py" for c in res.drift.code_without_module)
    assert any(
        c.file == "src/uncovered/y.py" and "b" in c.functions
        for c in res.drift.code_without_module
    )
    assert any(m.module_id == "M-ORPHAN" for m in res.drift.module_without_code)
    assert any(mv.module_id == "M-ALIVE" for mv in res.drift.missing_verification)
    assert any(mm.file in ("src/alive/x.py", "src/uncovered/y.py") for mm in res.drift.markup_missing)


def test_cli_impact_invokes_tool(tmp_path: Path, capsys, monkeypatch):
    """`doubled-graph impact <target>` must dispatch into tools/impact."""
    from doubled_graph import cli
    from doubled_graph.tools import impact as impact_mod

    class _CGC:
        def __init__(self, *_a, **_k):
            pass

        def find_symbol(self, _n):
            return []

        def find_callers(self, _t, depth=3):
            return []

        def find_callees(self, _t, depth=3):
            return []

    monkeypatch.setattr(impact_mod, "CGC", _CGC)
    rc = cli.main(argv=["impact", "foo", "--repo", str(tmp_path)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["target_resolved"]["name"] == "foo"
    assert payload["risk"]["level"] in ("LOW", "MEDIUM", "HIGH", "CRITICAL", "NONE")


def test_cli_detect_changes_runs(tmp_path: Path, capsys, monkeypatch):
    from doubled_graph import cli
    from doubled_graph.tools import detect_changes as dc_mod

    monkeypatch.setattr(dc_mod, "_files_for_scope", lambda *_a: [])
    rc = cli.main(argv=["detect-changes", "--scope", "all", "--repo", str(tmp_path)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["scope_used"] == "all"


def test_setup_dry_run_produces_plan(tmp_path: Path):
    """`doubled-graph setup --dry-run` must not touch fs/network but must
    return a structured plan including each stage. Regression guard for task 1.
    """
    from doubled_graph.setup import run_setup

    (tmp_path / ".git").mkdir()
    report = run_setup(repo_path=tmp_path, ide="claude-code", dry_run=True)
    assert report["dry_run"] is True
    assert report["mcp_register"]["status"] == "dry_run"
    assert report["analyze"]["status"] == "dry_run"
    # Since 1.3.0: setup ships our own SKILL.md files. The skills step runs
    # in dry-run too, just doesn't write to disk.
    assert report["skills"]["status"] == "ok"
    assert report["skills"]["skill_count"] >= 1
    # No .mcp.json should have been created.
    assert not (tmp_path / ".mcp.json").exists()
    # No skill files either.
    assert not (tmp_path / ".claude").exists()
    assert not (tmp_path / ".cursor").exists()


def test_setup_registers_claude_code_mcp(tmp_path: Path, monkeypatch):
    """Setup must add doubled-graph entry to .mcp.json without clobbering it."""
    from doubled_graph.setup import run_setup

    (tmp_path / ".git" / "hooks").mkdir(parents=True)
    (tmp_path / ".mcp.json").write_text(
        json.dumps({"mcpServers": {"existing": {"command": "x"}}}),
        encoding="utf-8",
    )
    # Avoid running real analyze / bun add.
    from doubled_graph import setup as setup_mod

    monkeypatch.setattr(setup_mod, "_install_grace_cli", lambda _dry: {"status": "skipped"})
    monkeypatch.setattr(setup_mod, "_first_analyze", lambda _r, _d: {"status": "skipped"})

    report = run_setup(repo_path=tmp_path, ide="claude-code")
    assert report["ok"] is True
    data = json.loads((tmp_path / ".mcp.json").read_text())
    assert "existing" in data["mcpServers"]  # preserved
    # Since 1.0.11: command points at sys.executable + `python -m doubled_graph`
    # so the entry survives GUI-launcher PATH stripping (e.g. macOS launchd).
    entry = data["mcpServers"]["doubled-graph"]
    assert entry["command"] == sys.executable
    assert entry["args"] == ["-m", "doubled_graph", "serve"]


def test_hooks_installer_dry_run(tmp_path: Path):
    from doubled_graph.hooks_installer import install_hooks

    (tmp_path / ".git" / "hooks").mkdir(parents=True)
    report = install_hooks(repo_path=tmp_path, post_commit=True, dry_run=True)
    assert report["post_commit"] == "dry-run"


def test_hooks_installer_actually_installs_post_commit(tmp_path: Path):
    from doubled_graph.hooks_installer import install_hooks

    (tmp_path / ".git" / "hooks").mkdir(parents=True)
    report = install_hooks(repo_path=tmp_path, post_commit=True)
    assert report["post_commit"] == "installed"
    hook = tmp_path / ".git" / "hooks" / "post-commit"
    assert hook.exists()
    assert "doubled-graph analyze" in hook.read_text()
    # executable bit set
    assert hook.stat().st_mode & 0o111


def test_claude_code_hook_json_merge(tmp_path: Path):
    from doubled_graph.hooks_installer import install_hooks

    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text(
        json.dumps({"theme": "dark", "hooks": {"PreToolUse": []}}), encoding="utf-8"
    )
    install_hooks(repo_path=tmp_path, claude_code=True)
    data = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert "PreToolUse" in data["hooks"]  # existing preserved
    assert data["theme"] == "dark"
    assert data["hooks"]["PostToolUse"]
    assert "doubled-graph" in data["hooks"]["PostToolUse"][0]["hooks"][0]["command"]


def test_cli_status_runs(tmp_path: Path, capsys, monkeypatch):
    from doubled_graph import cli

    monkeypatch.chdir(tmp_path)
    rc = cli.main(argv=["status", "--repo", str(tmp_path)])
    assert rc == 0
    out = capsys.readouterr().out
    payload = json.loads(out)
    assert "config" in payload
    assert payload["phase"] in ("migration", "post_migration")


def test_phantom_gateway_subcommands_removed(tmp_path: Path):
    """1.4.0 dropped the 11 phantom gateway subcommands (init/plan/execute/...).
    They delegated to upstream grace-marketplace skills that aren't installed
    by `doubled-graph setup` since 1.2.0 — so the directives pointed nowhere
    and methodology workflows stalled. They now live as agent-side workflows
    in our own SKILL.md files, not as CLI subcommands.

    Regression guard: nobody re-introduces `doubled-graph refresh`/`plan`/etc.
    Real ones (`analyze`/`impact`/`context`/`detect-changes`/`lint`/`module`/
    `file`/`health`/`phase`/`status`/`init-hooks`/`setup`/`serve`) still work.
    """
    from doubled_graph import cli

    phantom_subcommands = [
        "refresh", "init", "plan", "execute", "multiagent-execute",
        "verification", "reviewer", "fix", "ask", "refactor",
    ]
    for cmd in phantom_subcommands:
        with pytest.raises(SystemExit):  # argparse rejects unknown subcommand
            cli.main(argv=[cmd, "--repo", str(tmp_path)])


def test_cli_health_returns_real_report(tmp_path: Path):
    """`doubled-graph health` is now a REAL native command (not a gateway).
    Returns counts of modules / verified / drift / open DRIFT.md entries.
    Exit 0 if everything is clean, exit 1 if any health check fails.
    """
    from doubled_graph import cli
    from doubled_graph.integrations import cgc as cgc_mod
    from doubled_graph.tools import detect_changes as dc_mod

    # Empty repo: no modules → ok=true (nothing to be unverified).
    monkey_cgc = type("_CGC", (), {
        "__init__": lambda s, *a, **k: None,
        "find_symbol": lambda s, n: [],
        "find_callers": lambda s, t, depth=3: [],
        "find_callees": lambda s, t, depth=3: [],
        "symbols_in_file": lambda s, p: [],
    })
    # detect_changes scope="all" needs CGC; mock it via the dc_mod module attr.
    import unittest.mock as mock
    with mock.patch.object(dc_mod, "CGC", monkey_cgc):
        rc = cli.main(argv=["health", "--repo", str(tmp_path)])
    # Empty repo with no modules and no drift → ok=true → exit 0.
    assert rc == 0


def test_mcp_dispatch_rejects_phantom_tools(tmp_path: Path):
    """MCP server dispatch must return UNKNOWN_TOOL for the dropped gateway
    tools. Same scope reduction as the CLI, on the MCP surface.
    """
    from doubled_graph.server import _dispatch

    for phantom in [
        "refresh", "init", "plan", "execute", "multiagent_execute",
        "verification", "reviewer", "fix", "ask", "refactor",
    ]:
        result = _dispatch(phantom, {}, tmp_path)
        assert result.get("error") == "UNKNOWN_TOOL", f"{phantom} must be removed"


def test_phase_set_creates_agents_md_if_absent(tmp_path: Path):
    """`doubled-graph phase set` on an empty repo must create AGENTS.md with
    the phase-block — otherwise the first migration setup breaks.
    """
    from doubled_graph.policy.phase import read_phase, set_phase

    result = set_phase(tmp_path, "migration", reason="starting migration")
    assert result["current"] == "migration"
    assert result["created_file"] is True
    assert result["appended_block"] is True
    assert read_phase(tmp_path) == "migration"


def test_phase_set_patches_existing_block(tmp_path: Path):
    """Switching phase on a repo with existing AGENTS.md must preserve
    surrounding content byte-for-byte and update only the block.
    """
    from doubled_graph.policy.phase import read_phase, set_phase

    original = (
        "# Project\n\n"
        "Some intro paragraph.\n\n"
        "<!-- doubled-graph:phase:start -->\n"
        "## doubled-graph phase\n"
        "phase: migration\n"
        "updated: 2026-04-18\n"
        "<!-- doubled-graph:phase:end -->\n\n"
        "## Other section\nContent.\n"
    )
    (tmp_path / "AGENTS.md").write_text(original, encoding="utf-8")

    result = set_phase(tmp_path, "post_migration", reason="migration complete")
    assert result["previous"] == "migration"
    assert result["current"] == "post_migration"
    assert result["created_file"] is False
    assert result["appended_block"] is False

    new = (tmp_path / "AGENTS.md").read_text(encoding="utf-8")
    assert "# Project" in new and "## Other section" in new  # preserved
    assert read_phase(tmp_path) == "post_migration"


def test_cli_phase_set(tmp_path: Path, capsys):
    from doubled_graph import cli

    rc = cli.main(
        argv=["phase", "set", "post_migration", "--reason", "test", "--repo", str(tmp_path)]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["current"] == "post_migration"


def test_cli_lint_accepts_path_and_verbose(tmp_path: Path, capsys, monkeypatch):
    """`doubled-graph lint --path . --verbose` must work as-typed in docs —
    `--path` is an alias for `--repo`, `--verbose` forwards to upstream.
    """
    from doubled_graph import cli
    from doubled_graph.integrations import grace_cli as gc_mod

    called = {}

    def fake_lint(self, verbose=False):
        called["verbose"] = verbose
        called["repo"] = str(self.repo_path)
        return {"ok": True}

    monkeypatch.setattr(gc_mod.GraceCLI, "lint", fake_lint)
    monkeypatch.setattr(gc_mod.shutil, "which", lambda _c: "/fake/grace")

    rc = cli.main(argv=["lint", "--path", str(tmp_path), "--verbose"])
    assert rc == 0
    assert called["verbose"] is True
    assert called["repo"] == str(tmp_path.resolve())


def test_cli_phase_get(tmp_path: Path, capsys):
    """`doubled-graph phase get` must print current phase — default post_migration
    when no AGENTS.md block exists. Agents rely on this for drift decisions.
    """
    from doubled_graph import cli

    rc = cli.main(argv=["phase", "get", "--repo", str(tmp_path)])
    assert rc == 0
    assert capsys.readouterr().out.strip() == "post_migration"


def test_cli_lint_gateway_surfaces_missing_grace(tmp_path: Path, capsys, monkeypatch):
    """`doubled-graph lint` must fail cleanly (GRACE_CLI_MISSING) when grace is
    not on PATH — the user gets a useful install hint instead of a traceback.
    """
    from doubled_graph import cli

    # Force "not on PATH" by replacing shutil.which in the integration module.
    from doubled_graph.integrations import grace_cli as gc_mod

    monkeypatch.setattr(gc_mod.shutil, "which", lambda _cmd: None)
    rc = cli.main(argv=["lint", "--repo", str(tmp_path)])
    assert rc == 3
    err = capsys.readouterr().err
    payload = json.loads(err)
    assert payload["error"] == "GRACE_CLI_MISSING"


def test_grace_cli_check_caches_tsx_when_already_installed_via_tsx(tmp_path: Path, monkeypatch):
    """Regression: `try_install_grace_cli` returns `status=already_installed`
    BOTH when bun-direct works AND when tsx-fallback was wired up by a prior
    setup. Pre-1.4.1 the GraceCLI._check method only looked at `status` and
    cached `("bun", [grace])` for either case — the tsx-fallback case then
    failed on next exec with rc=127 `env: bun: No such file or directory`.

    This test pins the fixed dispatch: when `runtime=tsx` is in the install
    report, _check must cache the tsx invocation, regardless of `status`.
    """
    from doubled_graph.integrations import grace_cli as gc_mod

    fake_entry = "/fake/global/node_modules/@osovv/grace-cli/src/grace.ts"
    fake_tsx = "/fake/bin/tsx"

    def fake_try_install(*_a, **_kw):
        return {
            "status": "already_installed",
            "runtime": "tsx",
            "entry": fake_entry,
            "tsx": fake_tsx,
        }

    monkeypatch.setattr(gc_mod, "try_install_grace_cli", fake_try_install)

    cli = gc_mod.GraceCLI(tmp_path)
    cli._check()
    assert cli._invocation == ("tsx", [fake_tsx, fake_entry])

    # And confirm the build_cmd uses the tsx invocation, not bun.
    cmd = cli._build_cmd(["lint", "--path", str(tmp_path)])
    assert cmd[0] == fake_tsx
    assert cmd[1] == fake_entry
    assert "grace" not in cmd[0]  # not the bun-shebang binary


# ---------------------------------------------------------------------------
# 1.3.0: bundled skills installed per-IDE
# ---------------------------------------------------------------------------


def test_install_skills_writes_all_ide_targets(tmp_path: Path):
    """Every bundled skill lands in every IDE-native path with the right format.

    Acts as the contract test for the matrix in CHANGELOG 1.3.0: if a target
    is added/removed or a path changes, this test surfaces it.
    """
    from doubled_graph.setup import _install_skills

    report = _install_skills(tmp_path, dry_run=False)
    assert report["status"] == "ok"
    assert report["skill_count"] >= 5
    assert "doubled-graph-before-edit" in report["skills"]

    # Per-file IDE targets — one file per skill, paths exact.
    for skill in report["skills"]:
        assert (tmp_path / ".claude" / "skills" / skill / "SKILL.md").is_file()
        assert (tmp_path / ".cursor" / "rules" / f"{skill}.mdc").is_file()
        assert (tmp_path / ".continue" / "rules" / f"{skill}.md").is_file()
        assert (tmp_path / ".roo" / "rules" / f"{skill}.md").is_file()
        assert (tmp_path / ".kilocode" / "rules" / f"{skill}.md").is_file()
        assert (tmp_path / ".opencode" / "rules" / f"{skill}.md").is_file()

    # Windsurf concat — single file, marker-fenced.
    rules = (tmp_path / ".windsurfrules").read_text(encoding="utf-8")
    assert "<!-- doubled-graph-skills:start -->" in rules
    assert "<!-- doubled-graph-skills:end -->" in rules
    for skill in report["skills"]:
        assert f"# {skill}" in rules

    # OpenCode opencode.json glob merge.
    cfg = json.loads((tmp_path / "opencode.json").read_text(encoding="utf-8"))
    assert ".opencode/rules/*.md" in cfg["instructions"]


def test_install_skills_format_conversions(tmp_path: Path):
    """Verify per-IDE frontmatter handling: Cursor mdc rewritten, Roo/Kilo/etc stripped."""
    from doubled_graph.setup import _install_skills

    _install_skills(tmp_path, dry_run=False)
    name = "doubled-graph-before-edit"

    # Claude Code: original YAML frontmatter preserved verbatim.
    claude = (tmp_path / ".claude" / "skills" / name / "SKILL.md").read_text(encoding="utf-8")
    assert claude.startswith("---\n")
    assert f"name: {name}" in claude

    # Cursor mdc: rewritten frontmatter (description + alwaysApply).
    cursor = (tmp_path / ".cursor" / "rules" / f"{name}.mdc").read_text(encoding="utf-8")
    assert cursor.startswith("---\n")
    assert "alwaysApply: false" in cursor
    assert "name:" not in cursor.split("---", 2)[1]  # `name` field stripped

    # Roo / Kilo / OpenCode / Continue: frontmatter fully stripped.
    for path in [
        tmp_path / ".roo" / "rules" / f"{name}.md",
        tmp_path / ".kilocode" / "rules" / f"{name}.md",
        tmp_path / ".opencode" / "rules" / f"{name}.md",
        tmp_path / ".continue" / "rules" / f"{name}.md",
    ]:
        body = path.read_text(encoding="utf-8")
        assert not body.startswith("---")
        assert "doubled-graph — перед правкой кода" in body  # H1 from skill body


def test_install_skills_idempotent(tmp_path: Path):
    """Re-running setup must not overwrite existing skill files or duplicate Windsurf block."""
    from doubled_graph.setup import _install_skills

    _install_skills(tmp_path, dry_run=False)
    # User edits a skill — install must respect it.
    skill_file = tmp_path / ".claude" / "skills" / "doubled-graph-guide" / "SKILL.md"
    user_content = "---\nname: user-edited\n---\n\nuser content\n"
    skill_file.write_text(user_content, encoding="utf-8")

    report = _install_skills(tmp_path, dry_run=False)
    assert skill_file.read_text(encoding="utf-8") == user_content

    # Windsurf block also not duplicated.
    rules = (tmp_path / ".windsurfrules").read_text(encoding="utf-8")
    assert rules.count("<!-- doubled-graph-skills:start -->") == 1

    # OpenCode glob not duplicated either.
    cfg = json.loads((tmp_path / "opencode.json").read_text(encoding="utf-8"))
    assert cfg["instructions"].count(".opencode/rules/*.md") == 1

    # Status field surfaces what actually happened on the second run.
    claude_results = report["per_ide"]["claude-code"]
    statuses = {r["status"] for r in claude_results}
    assert "skipped_existing" in statuses


def test_install_skills_preserves_existing_opencode_config(tmp_path: Path):
    """Merging into opencode.json must keep user's other keys + instruction globs."""
    from doubled_graph.setup import _install_skills

    (tmp_path / "opencode.json").write_text(
        json.dumps({"theme": "dark", "instructions": ["AGENTS.md"]}),
        encoding="utf-8",
    )
    _install_skills(tmp_path, dry_run=False)
    cfg = json.loads((tmp_path / "opencode.json").read_text(encoding="utf-8"))
    assert cfg["theme"] == "dark"
    assert "AGENTS.md" in cfg["instructions"]
    assert ".opencode/rules/*.md" in cfg["instructions"]


def test_setup_updates_gitignore_even_with_skip_hooks(tmp_path: Path, monkeypatch):
    """`.gitignore` must list `.doubled-graph/{cache,logs}/` after setup,
    regardless of `--skip-hooks`. The runtime dirs are populated by analyze
    and the MCP server, so skipping hooks shouldn't leave `git status` dirty.
    """
    from doubled_graph.setup import run_setup
    from doubled_graph import setup as setup_mod

    (tmp_path / ".git" / "hooks").mkdir(parents=True)
    monkeypatch.setattr(setup_mod, "_install_grace_cli", lambda _dry: {"status": "skipped"})
    monkeypatch.setattr(setup_mod, "_first_analyze", lambda _r, _d: {"status": "skipped"})

    report = run_setup(repo_path=tmp_path, ide="claude-code", skip_hooks=True)
    assert report["hooks"]["status"] == "skipped"
    # gitignore must be a top-level concern, not nested in hooks.
    assert report["gitignore"]["status"] == "appended"
    body = (tmp_path / ".gitignore").read_text(encoding="utf-8")
    assert ".doubled-graph/cache/" in body
    assert ".doubled-graph/logs/" in body


def test_ensure_gitignore_entries_idempotent(tmp_path: Path):
    """Running ensure_gitignore_entries twice must not duplicate lines."""
    from doubled_graph.hooks_installer import ensure_gitignore_entries

    first = ensure_gitignore_entries(tmp_path)
    assert first["status"] == "appended"
    second = ensure_gitignore_entries(tmp_path)
    assert second["status"] == "already_present"
    body = (tmp_path / ".gitignore").read_text(encoding="utf-8")
    assert body.count(".doubled-graph/cache/") == 1
    assert body.count(".doubled-graph/logs/") == 1


def test_ensure_gitignore_entries_preserves_existing_content(tmp_path: Path):
    """Pre-existing `.gitignore` content stays intact; our lines are appended."""
    from doubled_graph.hooks_installer import ensure_gitignore_entries

    (tmp_path / ".gitignore").write_text("node_modules/\n*.pyc\n", encoding="utf-8")
    ensure_gitignore_entries(tmp_path)
    body = (tmp_path / ".gitignore").read_text(encoding="utf-8")
    assert "node_modules/" in body
    assert "*.pyc" in body
    assert ".doubled-graph/cache/" in body


def test_install_skills_dry_run_makes_no_changes(tmp_path: Path):
    from doubled_graph.setup import _install_skills

    report = _install_skills(tmp_path, dry_run=True)
    assert report["status"] == "ok"
    # Nothing on disk.
    assert not (tmp_path / ".claude").exists()
    assert not (tmp_path / ".cursor").exists()
    assert not (tmp_path / ".roo").exists()
    assert not (tmp_path / ".windsurfrules").exists()
    assert not (tmp_path / "opencode.json").exists()
    # But the report still describes what would have happened.
    assert all(
        any(r["status"] in ("written", "appended", "merged") for r in results)
        for results in report["per_ide"].values()
    )


def test_skill_descriptions_are_single_line_and_nonempty():
    """Defensive guard: Cursor's `.mdc` parser doesn't tolerate `\\n` in the
    description value. `_to_cursor_mdc` does no newline-escape — if a future
    SKILL.md authoring this field with a literal newline slips in, Cursor's
    rule parser would silently fail. Catch it at test time, in the bundle.
    """
    from importlib import resources

    from doubled_graph.setup import _parse_frontmatter

    skills_root = resources.files("doubled_graph").joinpath("data").joinpath("skills")
    assert skills_root.is_dir(), "bundled skills missing"
    found_any = False
    for entry in skills_root.iterdir():
        if not entry.is_dir():
            continue
        skill_md = entry.joinpath("SKILL.md")
        assert skill_md.is_file(), f"{entry.name}: missing SKILL.md"
        fm, _ = _parse_frontmatter(skill_md.read_text(encoding="utf-8"))
        description = fm.get("description", "")
        assert "\n" not in description, (
            f"{entry.name}: description contains newline — would break Cursor mdc"
        )
        assert description.strip(), f"{entry.name}: empty description"
        found_any = True
    assert found_any, "no skills discovered in bundle"
