# Инструменты: лёгкий tool-surface, методология в skills

Методология **не работает** без обоих. Это — precondition, не рекомендация (см. `README.md`).

**Ключевой принцип (с 1.4.0):** `doubled-graph` — это **9 реальных tool'ов** для работы с дуальным графом плюс CLI-обёртки над `grace`. Всё остальное — **методологические workflow'ы в SKILL.md**, исполняемые агентом своими `Read`/`Edit`/`Write`/`Bash` tools, а не фантом-команды через delegation directives. До 1.4.0 был «gateway pattern» с `delegated_to: upstream-skill:grace-X` — он указывал на upstream-skills, которых `doubled-graph setup` не устанавливает с 1.2.0, и тупиково ломал workflow. Удалён.

---

## 1. doubled-graph — наш инструмент

- **Автор:** этот репозиторий. MIT.
- **Роль:** дуальный граф + drift detection + obвёртки над `grace` CLI. Не оркестратор методологии — это делают skills.
- **Исходник:** `../docs/SPEC.md`, `../docs/TOOLS.md`, `../docs/HOOKS.md`.

### MCP-tools (всё, что есть)

**Native** (computed × declared graph operations, in-process):

| MCP-tool | CLI | Назначение |
|---|---|---|
| `analyze` | `doubled-graph analyze [--mode ...]` | индексировать/обновить computed graph через CGC |
| `impact` | `doubled-graph impact <target>` | blast-radius перед правкой (mandatory-gate) |
| `context` | `doubled-graph context <name>` | 360-view на символ |
| `detect_changes` | `doubled-graph detect-changes` | drift computed×declared |
| `health` | `doubled-graph health` | health-отчёт: модули без `V-M-*`, drift count, open `DRIFT.md` (для CI) |

**Wrappers** над upstream `grace` CLI (subprocess, прозрачные):

| MCP-tool | CLI | Проксирует в |
|---|---|---|
| `lint` | `doubled-graph lint` | `grace lint` — валидация якорей и ссылок |
| `module_show` | `doubled-graph module show <id>` | `grace module show` |
| `module_find` | `doubled-graph module find <q>` | `grace module find` |
| `file_show` | `doubled-graph file show <path>` | `grace file show` — MODULE_CONTRACT/BLOCK_*/CHANGE_SUMMARY |

**Это весь публичный MCP-периметр** — 9 tool'ов. Никаких `refresh`/`plan`/`execute`/`fix`/`refactor`/`verification`/`reviewer`/`ask`/`init`/`multiagent_execute` как MCP-tools нет (см. ниже § «Что было удалено»).

### CLI-only (для человека, не AI)

| Команда | Назначение |
|---|---|
| `doubled-graph setup` | онбординг репо: prompts + skills + MCP + hooks + первый analyze |
| `doubled-graph init-hooks [--all]` | git/Claude Code hooks |
| `doubled-graph phase get` | прочитать текущий phase из `AGENTS.md` |
| `doubled-graph phase set <val> [--reason "..."]` | переключить phase (atomic rewrite `AGENTS.md` phase-блока) |
| `doubled-graph status` | диагностика: config + phase + freshness |
| `doubled-graph serve` | старт MCP-сервера на stdio (используется IDE автоматически) |

### Skills (workflows для агента)

`doubled-graph setup` ставит наши SKILL.md в `.claude/skills/`, `.cursor/rules/`, `.continue/rules/`, `.roo/rules/`, `.kilocode/rules/`, `.opencode/rules/`, `.windsurfrules` (per-IDE format). Семейство:

| Skill | Когда |
|---|---|
| `doubled-graph-guide` | overview методологии и навигация |
| `doubled-graph-before-edit` | до любой правки кода — обязательный impact-gate |
| `doubled-graph-after-edit` | после правки, до коммита — drift / lint / tests / contract-check |
| `doubled-graph-drift` | `detect_changes` вернул непустой drift |
| `doubled-graph-manual-edit` | человек поправил код вручную |
| `doubled-graph-refactor` | rename/move/split/extract — координация code + XML + V-M-* |
| `doubled-graph-verify` | модуль без `V-M-*` тестов — добавить покрытие |

### Что было удалено (1.4.0)

11 «gateway» команд (`init`/`plan`/`execute`/`multiagent_execute`/`refresh`/`verification`/`reviewer`/`fix`/`ask`/`health`/`refactor`) удалены из MCP и CLI. Они возвращали `delegated_to: upstream-skill:grace-X` директиву к skills, которые `doubled-graph setup` не устанавливает с 1.2.0. На практике директива летела в никуда, методологический workflow застревал.

Их функции теперь живут как:
- **agent-side workflows** в наших SKILL.md (см. семейство выше);
- **inline Edit/Write** на `docs/*.xml` под руководством skill (вместо `refresh()` — `Edit docs/knowledge-graph.xml`);
- **one-off prompts** в `prompts/new-project/` и `prompts/migrate-existing-project/` (для `init`/`plan`/`execute` сценариев);
- **`doubled-graph health`** — единственное исключение, переродился из gateway в реальный native MCP-tool с конкретным JSON-отчётом.

### Почему такое разделение

1. **Честность.** Tool делает работу, skill описывает workflow. До 1.4.0 «gateway» делал вид, что делает работу, но возвращал директиву в никуда — фикция, ломавшая доверие.
2. **Когнитивная нагрузка.** 9 реальных tools проще, чем 20 (половина из которых не работает). Локальные модели не путаются.
3. **Расширяемость.** Новые workflow'ы — это новые SKILL.md (markdown, легко аудитировать через git), не код в `tools/*.py`.
4. **Универсальность.** Skills работают во всех 7 IDE (Claude/Cursor/Continue/Roo/Kilo/OpenCode/Windsurf). Gateway требовал Skill API, которого нет в Cursor/Roo/Kilo/Continue/Windsurf/OpenCode.

---

## 2. grace-marketplace (upstream, не наш)

- **Автор:** osovv. GitHub: `osovv/grace-marketplace`. MIT.
- **Версия** на момент написания методологии: v3.7.0 (апрель 2026, сверять актуальность).
- **Что даёт:**
  - 14 **skills** для Claude Code (агентные процедуры, не CLI).
  - CLI `grace` на Bun — `lint`, `module show/find`, `file show`.

**Как мы к ним обращаемся — через gateway:**
- **Skills** (`grace-init`, `grace-plan`, `grace-execute`, `grace-multiagent-execute`, `grace-verification`, `grace-reviewer`, `grace-refresh`, `grace-fix`, `grace-ask`, `grace-status`, `grace-refactor`) — **агент НЕ триггерит их напрямую**. Вместо этого вызывает gateway: `doubled-graph init`, `doubled-graph plan`, … (маппинг — в §1). Gateway логирует intent и возвращает структурированную директиву, по которой агент активирует upstream-skill через IDE skill system. `grace-explainer`, `grace-cli`, `grace-setup-subagents` — вспомогательные upstream-skills, методология их не использует в основном workflow.
- **CLI `grace`** — **агент НЕ вызывает напрямую**. Все вызовы идут через `doubled-graph lint / module / file` gateway.

**Что это даёт:** один namespace `doubled-graph.*` в промптах, единая точка логирования (`.doubled-graph/logs/`), возможность enforcement'а policy (phase, risk-level) до фактического запуска upstream-skill или CLI.

**Подключение (для Claude Code):**
```bash
claude --skills github:osovv/grace-marketplace
```

Для Cursor / Codex / etc — skills копируются в runtime-специфичные места, детали в `runtime-adapters/*.md`.

---

## 3. CodeGraphContext — внешняя зависимость, не трогаем

- **Автор:** внешний, MIT.
- **Что используем:** Python-библиотека (`GraphBuilder`, `CodeFinder`, `DatabaseManager`). Импортируется в `src/doubled_graph/integrations/cgc.py`.
- **Что НЕ используем:** MCP-сервер CGC (`cgc mcp start`) — чтобы агент не видел 14 tool'ов.
- **Поддержка 19 языков** (Python, JS, TS, Go, Java, C/C++/C#, Rust, Ruby, PHP, Kotlin, Scala, Swift, Dart, Elixir, Perl, Haskell).
- **Backends:** FalkorDB Lite (Unix default), KùzuDB (Windows/fallback), Neo4j (remote). Выбор автоматический, переопределяется `CGC_RUNTIME_DB_TYPE`.

Известные ограничения CGC — см. `../QUESTIONS_FOR_REVIEW.md § B` (верификация на Фазе 5):
- Haskell-парсер помечен как unstable в исходнике.
- FalkorDB Lite требует Python 3.12+.
- Windows Neo4j driver 6.x имеет баги — workaround `pip install "neo4j<6"`.

---

## 4. BlackboxBook — источник обоснований, не процесс

Используется как **ссылочный материал**, не как source-of-truth:

- гл. 7 (семантическая разметка) — обоснование для принципа 3.
- гл. 9 (декомпозиция) — обоснование для принципа 1.
- гл. 13 (LDD + антигаллюцинационный контур) — обоснование для принципов 7 и 8.
- гл. 14 (eval-дисциплина) — `approval-checkpoints.md § 4`.
- гл. 17 (OTel GenAI) — **не** применяем как обязательное (см. memory `project_otel_dropped.md`).

Главы 5 и 24 — не используются (спекулятивные места).

---

## 5. GitNexus — почему не используется

GitNexus — граф-анализатор кода, функционально близкий к CGC. На вид — удобнее (больше tools, richer MCP surface). **Лицензия:** PolyForm Noncommercial.

**Решение 2026-04-17:** исключён. PolyForm NC запрещает коммерческое использование; методология, претендующая на публичную публикацию и применимость в enterprise, не может опираться на NC-лицензированные зависимости. Это не техническое решение, а лицензионное.

**Что заменяет:** CodeGraphContext (MIT) + наш `doubled-graph` (MIT). Не даёт всех фич GitNexus (например, embeddings и cluster detection по Leiden), но закрывает базовые потребности методологии.

`doubled-graph` не импортирует ни строки кода из GitNexus. Проверяется commit-time test: `grep -r "gitnexus" src/ | wc -l` == 0.

---

## 6. Взаимодействие инструментов — картина целиком

```
                   ┌─────────────┐
                   │ Пользователь│
                   └──────┬──────┘
                          │
                   IDE (с MCP+tools)
                          │
         ┌────────────────┴────────────────┐
         │                                 │
    [ via skills ]                  [ via MCP ]
         │                                 │
    grace skills                    doubled-graph MCP
    (inline в IDE)                  (4 tools: analyze,
         │                           impact, context,
         │                           detect_changes)
         │                                 │
         ▼                                 ▼
    CLI `grace`                    CGC (Python lib)
    (валидация,                    + grace CLI subprocess
    navigation)                           │
                                          ▼
                                  .doubled-graph/ logs
                                  CGC DB (FalkorDB/Kùzu/Neo4j)
```

- **grace skills** — agent-level расширения поведения в IDE.
- **doubled-graph MCP** — agent видит 4 tool'а.
- **grace CLI** — dialected text-UI, инструмент для человека и hook'ов; doubled-graph шеллит его для `module show` / `file show` / `lint`.
- **CGC backend** — хранилище computed graph; пользователь обычно не трогает.

---

## 7. Установка одной командой

`for-humans/getting-started.md` (Phase 4) будет содержать финальную команду. Ожидаемая форма (черновик):

```bash
# Python tooling
pipx install doubled-graph

# Bun tooling
bun add -g @osovv/grace-cli

# hooks
doubled-graph init-hooks --all
```

Отдельно для Claude Code — настройка MCP-сервера в `~/.claude/config.json`. Пример — `runtime-adapters/claude-code.md`.
