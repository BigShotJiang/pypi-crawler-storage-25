from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Mapping, TypeAlias, cast

import torch
import torch.nn as nn

from .config import CELMoEConfig, HierarchyLevelConfig

ExpertMetadata: TypeAlias = Mapping[str, object]
ExpertContextMap: TypeAlias = Mapping[str, object]
ExpertContext: TypeAlias = torch.Tensor | ExpertContextMap | None
ExpertAux: TypeAlias = dict[str, object]
LossMap: TypeAlias = Mapping[str, torch.Tensor]
LossResult: TypeAlias = torch.Tensor | LossMap
LevelRouting: TypeAlias = dict[str, list[str]]


def _empty_str_dict() -> dict[str, str]:
    return {}


def _empty_tensor_dict() -> dict[str, torch.Tensor]:
    return {}


def _empty_object_dict() -> dict[str, object]:
    return {}


def _empty_float_dict() -> dict[str, float]:
    return {}


def _empty_level_output_dict() -> dict[str, LevelOutput]:
    return {}


def _empty_global_losses() -> list[tuple[str, float, LossCallable]]:
    return []


def _empty_bridge_losses() -> list[tuple[str, str, str, float, BridgeLossCallable]]:
    return []


@dataclass
class ExpertBatch:
    hidden: torch.Tensor
    context: ExpertContext = None
    mask: torch.Tensor | None = None
    state: dict[str, str] = field(default_factory=_empty_str_dict)


@dataclass
class ExpertResult:
    hidden: torch.Tensor
    losses: dict[str, torch.Tensor] = field(default_factory=_empty_tensor_dict)
    aux: ExpertAux = field(default_factory=_empty_object_dict)


class ExpertModule(nn.Module):
    def forward(self, batch: ExpertBatch) -> ExpertResult:
        raise NotImplementedError


@dataclass
class LevelOutput:
    name: str
    hidden: torch.Tensor
    routes: list[str]
    losses: dict[str, torch.Tensor] = field(default_factory=_empty_tensor_dict)
    aux: ExpertAux = field(default_factory=_empty_object_dict)


@dataclass
class CELMoEOutput:
    levels: dict[str, LevelOutput]
    fused_hidden: torch.Tensor
    losses: dict[str, torch.Tensor] = field(default_factory=_empty_tensor_dict)
    aux: ExpertAux = field(default_factory=_empty_object_dict)


@dataclass
class LossTerm:
    name: str
    value: torch.Tensor
    weight: float = 1.0
    scope: str = "global"


class LossBundle:
    def __init__(self, terms: list[LossTerm] | None = None) -> None:
        self.terms = list(terms) if terms is not None else []

    def add(self, name: str, value: torch.Tensor, weight: float = 1.0, scope: str = "global") -> None:
        self.terms.append(LossTerm(name=name, value=value, weight=weight, scope=scope))

    @property
    def total(self) -> torch.Tensor:
        if not self.terms:
            raise ValueError("No loss terms were registered")
        total = self.terms[0].value.new_zeros(())
        for term in self.terms:
            total = total + term.weight * term.value
        return total

    def as_dict(self) -> dict[str, float]:
        values = _empty_float_dict()
        for term in self.terms:
            values[term.name] = float(term.value.detach().cpu())
        return values


class LearnedFusion(nn.Module):
    def __init__(self, hidden_size: int, num_levels: int, dropout: float) -> None:
        super().__init__()
        self.gates = nn.ModuleList([nn.Linear(hidden_size, hidden_size, bias=False) for _ in range(num_levels)])
        self.norm = nn.LayerNorm(hidden_size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, level_hiddens: list[torch.Tensor]) -> torch.Tensor:
        fused = sum(gate(hidden) for gate, hidden in zip(self.gates, level_hiddens)) / max(1, len(level_hiddens))
        return self.dropout(self.norm(fused))


class HierarchicalCELMoE(nn.Module):
    def __init__(
        self,
        config: CELMoEConfig,
        expert_factory: Callable[[str, str, ExpertMetadata], ExpertModule],
        fusion_module: nn.Module | None = None,
    ) -> None:
        super().__init__()
        self.config = config
        self.levels = [level for level in config.levels if level.enabled]
        self.level_modules = nn.ModuleDict(
            {
                level.name: nn.ModuleDict(
                    {
                        expert_name: expert_factory(level.name, expert_name, expert_config.metadata)
                        for expert_name, expert_config in level.experts.items()
                    }
                )
                for level in self.levels
            }
        )
        self.fusion = fusion_module or LearnedFusion(
            hidden_size=config.hidden_size,
            num_levels=max(1, len(self.levels)),
            dropout=config.fusion_dropout,
        )

    def _level_registry(self, level_name: str) -> nn.ModuleDict:
        return cast(nn.ModuleDict, self.level_modules[level_name])

    def _expert_module(self, level_name: str, expert_name: str) -> ExpertModule:
        registry = self._level_registry(level_name)
        return cast(ExpertModule, registry[expert_name])

    def _normalize_routing(self, batch_size: int, routing: LevelRouting | None) -> LevelRouting:
        normalized = routing.copy() if routing is not None else {}
        for level in self.levels:
            if level.name not in normalized:
                if len(level.experts) == 1:
                    only_name = next(iter(level.experts))
                    normalized[level.name] = [only_name] * batch_size
                elif level.fallback_expert is not None:
                    normalized[level.name] = [level.fallback_expert] * batch_size
                else:
                    raise KeyError(f"Missing routing for level '{level.name}'")
            if len(normalized[level.name]) != batch_size:
                raise ValueError(f"Routing size mismatch for level '{level.name}'")
        return normalized

    def _select_context(self, context: ExpertContext, indices: torch.Tensor) -> ExpertContext:
        if context is None:
            return None
        if isinstance(context, torch.Tensor):
            return context.index_select(0, indices)
        selected = _empty_object_dict()
        for key, value in context.items():
            if isinstance(value, torch.Tensor) and value.size(0) == indices.numel():
                selected[key] = value
            elif isinstance(value, torch.Tensor):
                selected[key] = value.index_select(0, indices)
            else:
                selected[key] = value
        return selected

    def _run_level(
        self,
        level: HierarchyLevelConfig,
        hidden: torch.Tensor,
        routes: list[str],
        context: ExpertContext,
        mask: torch.Tensor | None,
    ) -> LevelOutput:
        level_hidden = torch.zeros_like(hidden)
        level_losses = _empty_tensor_dict()
        level_aux = _empty_object_dict()
        registry = self._level_registry(level.name)
        for expert_name in sorted(set(routes)):
            if expert_name not in registry:
                raise KeyError(f"Expert '{expert_name}' is not registered in level '{level.name}'")
            indices = [i for i, current in enumerate(routes) if current == expert_name]
            batch_index = torch.tensor(indices, device=hidden.device, dtype=torch.long)
            expert_input = hidden.detach() if level.experts[expert_name].stop_gradient_from_parent else hidden
            batch = ExpertBatch(
                hidden=expert_input.index_select(0, batch_index),
                context=self._select_context(context, batch_index),
                mask=None if mask is None else mask.index_select(0, batch_index),
                state={"level": level.name, "expert": expert_name},
            )
            expert_module = self._expert_module(level.name, expert_name)
            result = expert_module(batch)
            level_hidden.index_copy_(0, batch_index, result.hidden)
            for loss_name, loss_value in result.losses.items():
                scoped_name = f"{level.name}.{expert_name}.{loss_name}"
                level_losses[scoped_name] = loss_value
            if result.aux:
                level_aux[expert_name] = result.aux
        return LevelOutput(
            name=level.name,
            hidden=level_hidden,
            routes=routes,
            losses=level_losses,
            aux=level_aux,
        )

    def forward(
        self,
        hidden: torch.Tensor,
        routing: LevelRouting | None = None,
        context: ExpertContext = None,
        mask: torch.Tensor | None = None,
    ) -> CELMoEOutput:
        normalized_routing = self._normalize_routing(hidden.size(0), routing)
        current_hidden = hidden
        level_outputs = _empty_level_output_dict()
        collected_losses = _empty_tensor_dict()

        for level in self.levels:
            level_output = self._run_level(
                level,
                hidden=current_hidden,
                routes=normalized_routing[level.name],
                context=context,
                mask=mask,
            )
            level_outputs[level.name] = level_output
            collected_losses.update(level_output.losses)
            current_hidden = level_output.hidden

        fused_hidden = self.fusion([level_output.hidden for level_output in level_outputs.values()])
        return CELMoEOutput(
            levels=level_outputs,
            fused_hidden=fused_hidden,
            losses=collected_losses,
        )


LossCallable = Callable[[CELMoEOutput, object | None, ExpertContext], LossResult]
LevelLossCallable = Callable[[LevelOutput, CELMoEOutput, object | None, ExpertContext], LossResult]
BridgeLossCallable = Callable[[LevelOutput, LevelOutput, CELMoEOutput, object | None, ExpertContext], LossResult]
LevelLossSpecs: TypeAlias = list[tuple[str, float, LevelLossCallable]]


def _empty_loss_specs() -> LevelLossSpecs:
    return []


class CELMoELossAPI:
    def __init__(self) -> None:
        self.global_losses = _empty_global_losses()
        self.level_losses: dict[str, LevelLossSpecs] = {}
        self.bridge_losses = _empty_bridge_losses()

    def add_global(self, name: str, fn: LossCallable, weight: float = 1.0) -> None:
        self.global_losses.append((name, weight, fn))

    def add_level(self, level_name: str, name: str, fn: LevelLossCallable, weight: float = 1.0) -> None:
        specs = self.level_losses.setdefault(level_name, _empty_loss_specs())
        specs.append((name, weight, fn))

    def add_bridge(
        self,
        parent_level: str,
        child_level: str,
        name: str,
        fn: BridgeLossCallable,
        weight: float = 1.0,
    ) -> None:
        self.bridge_losses.append((parent_level, child_level, name, weight, fn))

    def _append_result(self, bundle: LossBundle, scope: str, name: str, weight: float, result: LossResult) -> None:
        if isinstance(result, Mapping):
            for item_name, item_value in result.items():
                bundle.add(f"{scope}.{name}.{item_name}", item_value, weight=weight, scope=scope)
        else:
            bundle.add(f"{scope}.{name}", result, weight=weight, scope=scope)

    def compute(self, output: CELMoEOutput, targets: object | None = None, context: ExpertContext = None) -> LossBundle:
        bundle = LossBundle()

        for loss_name, loss_value in output.losses.items():
            bundle.add(loss_name, loss_value, scope="expert")

        for name, weight, fn in self.global_losses:
            self._append_result(bundle, "global", name, weight, fn(output, targets, context))

        for level_name, specs in self.level_losses.items():
            level_output = output.levels[level_name]
            for name, weight, fn in specs:
                self._append_result(bundle, level_name, name, weight, fn(level_output, output, targets, context))

        for parent_level, child_level, name, weight, fn in self.bridge_losses:
            parent_output = output.levels[parent_level]
            child_output = output.levels[child_level]
            self._append_result(
                bundle,
                f"{parent_level}->{child_level}",
                name,
                weight,
                fn(parent_output, child_output, output, targets, context),
            )

        return bundle
