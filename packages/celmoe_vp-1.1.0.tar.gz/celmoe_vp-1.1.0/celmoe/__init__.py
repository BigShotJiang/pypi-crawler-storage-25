"""Public API for the celmoe package."""

from .config import CELMoEConfig, ExpertConfig, HierarchyLevelConfig
from .model import (
    CELMoEOutput,
    CELMoELossAPI,
    ExpertBatch,
    ExpertModule,
    ExpertResult,
    HierarchicalCELMoE,
    LevelOutput,
    LossBundle,
    LossTerm,
)

__all__: list[str] = [
    "CELMoEConfig",
    "CELMoEOutput",
    "CELMoELossAPI",
    "ExpertBatch",
    "ExpertConfig",
    "ExpertModule",
    "ExpertResult",
    "HierarchicalCELMoE",
    "HierarchyLevelConfig",
    "LevelOutput",
    "LossBundle",
    "LossTerm",
]

__version__: str = "1.1.0"
