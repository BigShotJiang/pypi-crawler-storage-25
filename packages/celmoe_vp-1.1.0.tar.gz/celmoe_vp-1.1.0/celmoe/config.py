from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping


def _empty_metadata() -> dict[str, object]:
    return {}


def _empty_levels() -> list[HierarchyLevelConfig]:
    return []


@dataclass
class ExpertConfig:
    name: str
    loss_weight: float = 1.0
    stop_gradient_from_parent: bool = False
    metadata: Mapping[str, object] = field(default_factory=_empty_metadata)


@dataclass
class HierarchyLevelConfig:
    name: str
    experts: dict[str, ExpertConfig]
    fallback_expert: str | None = None
    enabled: bool = True


@dataclass
class CELMoEConfig:
    hidden_size: int
    levels: list[HierarchyLevelConfig] = field(default_factory=_empty_levels)
    use_learned_fusion: bool = True
    fusion_dropout: float = 0.1
