"""Formulas of cvcqv."""

# --------------------------- Import libraries and functions --------------------------
from typing import Any, cast

import math

import numpy as np  # To handle numeric infinity values.
import pandas as pd  # Data analysis and manipulation library.

from pycvcqv.types import NumArrayLike  # custom numeric array defined in types.py.


# -------------------------------- function definition --------------------------------
def _cv(
    data: NumArrayLike,
    ddof: int | None = 1,
    skipna: bool | None = True,
    ndigits: int | None = 4,
    correction: bool | None = False,
    multiplier: int | None = 1,
) -> float:
    """Internal function to calculate cv."""
    _data: pd.Series = pd.Series(data)
    if _data.mean(skipna=skipna) == 0 or (  # check if the mean is 0
        _data.mean(skipna=skipna) < 0.000001  # check if the mean is close to 0
        # ----------------- also, check if the std is higher than mean ----------------
        and _data.std(skipna=skipna, ddof=ddof) > _data.mean(skipna=skipna)
    ):  # ------- The Inf value which comes from numpy to handle infinity cases -------
        return float(np.inf)  # to ensure that the returned infinity value is 'float'
    # ------------------ the basic coefficient of variation function ------------------
    _cv = _data.std(skipna=skipna, ddof=ddof) / _data.mean(skipna=skipna)
    _length = len(_data)  # ------------ calculate the length of input array ----------
    if correction:  # -------------------- return the corrected cv --------------------
        corrected_rounded_cv: float = round(  # ----------- round the result ----------
            multiplier  # ----------- multiply the cv e.g, 100 for percentage ---------
            * (
                _cv
                * (  # --- this is the coefficient for the correction of sample size --
                    1  # ----------- the coefficient should be less than zero ----------
                    - ((4 * (_length - 1)) ** (-1))  # ------------ 1/(4n-1) -----------
                    + ((_cv**2) * (_length ** (-1)))  # ----------- (cv^2/n) -----------
                    + (2 * ((_length - 1) ** (2))) ** (-1)  # ----- 1/2*(n-1)^2 --------
                )
            ),
            ndigits=ndigits,  # --------------- decimals for the round ----------------
        )
        return corrected_rounded_cv
    rounded_cv: float = round(  # ---------------- return the basic cv ----------------
        multiplier * (_cv),  # -------- multiply the cv e.g, 100 for percentage -------
        ndigits=ndigits,  # ------------------ decimals for the round -----------------
    )
    return rounded_cv


def _noncentral_t_parameter(
    data: NumArrayLike,
    ddof: int | None = 1,
    skipna: bool | None = True,
    ndigits: int | None = 4,
    correction: bool | None = False,
) -> float:
    """Internal function to calculate noncentral t parameter (NCP)."""
    _data: pd.Series = pd.Series(data)
    # -------------------- calculates cv based on the _cv function --------------------
    _calculated_cv = _cv(data, ddof, skipna, ndigits, correction)
    _data_length = len(_data)  # --------- calculate the length of input array --------
    ncp: float = math.sqrt(_data_length) / _calculated_cv
    return ncp


def _cqv(
    data: NumArrayLike,
    ndigits: int | None = 4,
    interpolation: str | None = "linear",
    multiplier: int | None = 1,
) -> float:
    """Internal function to calculate cqv."""
    _data: pd.Series = pd.Series(data)
    # ---------------------- calculate the quantiles of the data ----------------------
    quantile1 = _data.quantile(0.25, interpolation=interpolation)  # q1 = p25
    quantile3 = _data.quantile(0.75, interpolation=interpolation)  # q3 = p75
    # ------------------- raise warning for 0 divisor when q3+q1 = 0 ------------------
    if quantile1 + quantile3 == 0:
        raise Warning("cqv is NaN because q3 and q1 are 0")
    _cqv = (quantile3 - quantile1) / (quantile3 + quantile1)  # ---- the basic cqv ----
    rounded_cqv: float = round(  # ------------------ return the cqv ------------------
        multiplier * _cqv,  # -------- multiply the cqv e.g, 100 for percentage -------
        ndigits=ndigits,  # ------------------ decimals for the round -----------------
    )
    return rounded_cqv


def _central_moment(data: pd.Series, order: int) -> float:
    """Compute the order-`order` central moment.

    Returns m_k = (1/n) * sum((X_i - mean)**k), matching the
    `m_2`, `m_4` definitions in Abu-Shawiesh, Aky & Kibria (2019),
    Eq. 10 footer (no Bessel correction).

    Args:
        data: A pandas Series of numeric values (NaN-free).
        order: The moment order (an integer >= 1).

    Returns:
        The central moment as a float.

    References:
        Abu-Shawiesh, M. O. A., Aky, H. E., & Kibria, B. G. (2019).
        Performance of Some Confidence Intervals for Estimating the
        Population Coefficient of Variation under both Symmetric and
        Skewed Distributions. Statistics, Optimization & Information
        Computing, 7(2), 277-290. https://doi.org/10.19139/soic.v7i2.630
    """
    mean = float(data.mean())
    return float(((data - mean) ** order).mean())


def _g2_excess_kurtosis(data: pd.Series) -> float:
    """Compute the sample excess kurtosis g_2 = m_4 / m_2**2 - 3.

    Matches the expression for g_2 under Abu-Shawiesh, Aky & Kibria
    (2019), Eq. 10 footer.

    Args:
        data: A pandas Series of numeric values (NaN-free).

    Returns:
        The sample excess kurtosis as a float.
    """
    m_2 = _central_moment(data, 2)
    m_4 = _central_moment(data, 4)
    return m_4 / (m_2**2) - 3.0


def _g2_bias_corrected(data: pd.Series) -> float:
    """Compute the bias-adjusted kurtosis estimator G_2.

    From Abu-Shawiesh, Aky & Kibria (2019), Eq. 10:

        G_2 = (n - 1) / ((n - 2)(n - 3)) * [(n - 1) * g_2 + 6]

    Args:
        data: A pandas Series of numeric values (NaN-free). Requires
            at least 4 observations.

    Returns:
        The G_2 estimator as a float.

    Raises:
        ValueError: If `data` has fewer than 4 observations.
    """
    n = len(data)
    if n < 4:
        raise ValueError("G_2 requires at least 4 observations.")
    g_2 = _g2_excess_kurtosis(data)
    return (n - 1) / ((n - 2) * (n - 3)) * ((n - 1) * g_2 + 6.0)


def _kappa_e5(data: pd.Series) -> float:
    """Compute the modified kurtosis estimator kappa_e5.

    From Abu-Shawiesh, Aky & Kibria (2019), Eq. 13:

        kappa_e5 = ((n + 1) / (n - 1)) * G_2 * (1 + 5 * G_2 / n)

    Used by the AA&K-ALS confidence interval for the coefficient of
    variation. Inherits `_g2_bias_corrected`'s `ValueError` when n < 4.

    Args:
        data: A pandas Series of numeric values (NaN-free). Requires
            at least 4 observations.

    Returns:
        The kappa_e5 estimator as a float.
    """
    n = len(data)
    big_g2 = _g2_bias_corrected(data)
    return ((n + 1.0) / (n - 1.0)) * big_g2 * (1.0 + 5.0 * big_g2 / n)


def _gamma_hat_hummel(data: pd.Series, ddof: int = 1) -> float:
    """Compute the Hummel-style adjusted-kurtosis estimator.

    From Abu-Shawiesh, Aky & Kibria (2019), Eq. 5:

        gamma_hat = [n(n + 1) / ((n - 1)(n - 2)(n - 3))]
                    * sum((X_i - mean)**4) / S**4
                    - 3(n - 1)**2 / ((n - 2)(n - 3))

    Used by the AA&K-ADJ confidence interval for the coefficient of
    variation. `S` is the Bessel-corrected sample standard deviation
    (ddof=1 by default, matching Abu-Shawiesh, Aky & Kibria, 2019).

    Args:
        data: A pandas Series of numeric values (NaN-free). Requires
            at least 4 observations.
        ddof: Delta degrees of freedom for the sample variance used in
            S**4. Defaults to 1 to match Abu-Shawiesh, Aky & Kibria
            (2019).

    Returns:
        The gamma_hat estimator as a float.

    Raises:
        ValueError: If `data` has fewer than 4 observations.
    """
    n = len(data)
    if n < 4:
        raise ValueError("gamma_hat requires at least 4 observations.")
    mean = float(data.mean())
    sum_fourth = float(((data - mean) ** 4).sum())
    sample_var = float(data.var(ddof=ddof))
    first_term = (n * (n + 1.0) / ((n - 1.0) * (n - 2.0) * (n - 3.0))) * (
        sum_fourth / (sample_var**2)
    )
    second_term = 3.0 * (n - 1.0) ** 2 / ((n - 2.0) * (n - 3.0))
    return first_term - second_term


def _cqv_statistic(
    sample: np.ndarray,
    interpolation: str | None = "linear",
) -> float:
    """Compute the (unscaled) coefficient of quartile variation for one sample.

    Mirrors `_cqv` but skips rounding and the percentage multiplier so the
    bootstrap distribution stays at full float precision.

    Args:
        sample: 1-D float array of observations.
        interpolation: numpy/pandas quantile interpolation mode (default
            "linear", which matches R's `type=7`).

    Returns:
        The CQV (q3 - q1) / (q3 + q1), or NaN if `q3 + q1 == 0`.
    """
    if sample.size < 2:
        return float("nan")
    method = cast(Any, interpolation or "linear")
    quantile1 = float(np.quantile(sample, 0.25, method=method))
    quantile3 = float(np.quantile(sample, 0.75, method=method))
    denom = quantile3 + quantile1
    if denom == 0:
        return float("nan")
    return (quantile3 - quantile1) / denom
