"""The multithread module."""

# --------------------------- Import libraries and functions --------------------------
import multiprocessing as mp

import numpy as np
import pandas as pd

from pycvcqv.prepare_output import prepare_cqv_datafame, prepare_cv_datafame


# -------------------------------- function definition --------------------------------
def multithread_cv_processor(
    data: pd.DataFrame,
    method: str = "kelley",
    num_threads: int | None = 1,
    ddof: int | None = 1,
    skipna: bool | None = True,
    ndigits: int | None = 4,
    correction: bool | None = False,
    multiplier: int | None = 1,
    conf_level: float | None = None,
    alpha_lower: float | None = None,
    alpha_upper: float | None = None,
    tol: float | None = 1e-9,
    max_iter: int | None = 10000,
    num_replicates: int | None = None,
    random_state: int | np.random.Generator | None = None,
) -> pd.DataFrame:
    """Performs multiprocessing cv for pd.DataFrame."""
    print(num_threads)
    with mp.Pool(mp.cpu_count()) as pool:
        result = prepare_cv_datafame(
            pool=pool,
            data=data,
            method=method,
            ddof=ddof,
            skipna=skipna,
            ndigits=ndigits,
            correction=correction,
            multiplier=multiplier,
            conf_level=conf_level,
            alpha_lower=alpha_lower,
            alpha_upper=alpha_upper,
            tol=tol,
            max_iter=max_iter,
            num_replicates=num_replicates,
            random_state=random_state,
        )
    pool.close()
    return result


def multithread_cqv_processor(
    data: pd.DataFrame,
    method: str | None = None,
    ndigits: int | None = 4,
    interpolation: str | None = "linear",
    multiplier: int | None = 1,
    num_threads: int | None = 1,
    skipna: bool | None = True,
    conf_level: float | None = None,
    alpha_lower: float | None = None,
    alpha_upper: float | None = None,
    num_replicates: int | None = None,
    random_state: int | np.random.Generator | None = None,
) -> pd.DataFrame:
    """Performs multiprocessing cqv for pd.DataFrame."""
    print(num_threads)
    with mp.Pool(mp.cpu_count()) as pool:
        result = prepare_cqv_datafame(
            data=data,
            method=method,
            ndigits=ndigits,
            interpolation=interpolation,
            multiplier=multiplier,
            pool=pool,
            skipna=skipna,
            conf_level=conf_level,
            alpha_lower=alpha_lower,
            alpha_upper=alpha_upper,
            num_replicates=num_replicates,
            random_state=random_state,
        )
    pool.close()
    return result
