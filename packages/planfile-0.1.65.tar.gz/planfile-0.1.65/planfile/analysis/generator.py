
CONSTANT_3 = 3
CONSTANT_4 = 4
CONSTANT_5 = 5
CONSTANT_20 = 20
CONSTANT_50 = 50
CONSTANT_60 = 60



"""
Main planfile generator from code analysis.
Integrates file analysis and sprint generation to create complete strategies.
"""

import json
from pathlib import Path
from typing import Any

from planfile.analysis.external_tools import AnalysisResults, ExternalToolRunner
from planfile.analysis.file_analyzer import FileAnalyzer
from planfile.analysis.generators import (
    extract_key_metrics,
    generate_goal,
    generate_goals,
    generate_quality_gates,
    generate_risks,
    generate_success_criteria,
    generate_target_metrics,
    generate_tasks,
    parse_effort,
)
from planfile.analysis.sprint_generator import SprintGenerator
from planfile.models import Strategy


class PlanfileGenerator:
    """Generate comprehensive planfile from file analysis."""

    def __init__(self):
        self.analyzer = FileAnalyzer()
        self.generator = SprintGenerator()
        self.external_runner: ExternalToolRunner | None = None

    def _default_limits(self) -> dict[str, int]:
        return {
            'max_tickets_per_priority': SprintGenerator.MAX_TICKETS_PER_PRIORITY,
            'max_total_tickets': SprintGenerator.MAX_TOTAL_TICKETS,
        }

    def generate_with_external_tools(self,
                                     project_path: str = ".",
                                     project_name: str = None,
                                     max_sprints: int = CONSTANT_4,
                                     focus_area: str = None,
                                     compact: bool = False) -> Strategy:
        """Generate planfile using external analysis tools (code2llm, vallm, redup)."""
        print("=" * CONSTANT_60)
        print("GENERATING PLANFILE WITH EXTERNAL TOOLS")
        print("=" * CONSTANT_60)

        # Run external tools
        self.external_runner = ExternalToolRunner(Path(project_path))
        external_results = self.external_runner.run_all()

        # Convert external results to internal format
        analysis_result = self._external_to_internal_analysis(external_results)

        # Generate strategy from combined analysis
        return self.generate_from_analysis(
            analysis_path=str(self.external_runner.output_dir),
            project_name=project_name,
            max_sprints=max_sprints,
            focus_area=focus_area,
            external_metrics=self._extract_external_metrics(external_results, compact),
            compact=compact
        )

    def _external_to_internal_analysis(self, results: AnalysisResults) -> dict[str, Any]:
        """Convert external tool results to internal analysis format."""
        issues = []
        metrics = []

        # Create issues from high CC functions
        for func in results.high_cc_functions:
            issues.append({
                'title': f"Refactor {func['name']} (CC={func['cc']})",
                'description': "Function has high cyclomatic complexity",
                'priority': 'critical' if func['cc'] > CONSTANT_20 else 'high',
                'category': 'refactor',
                'effort_estimate': f"{max(2, func['cc'] // CONSTANT_5)}h",
                'file_path': 'analysis.toon.yaml'
            })

        if results.validation_errors > 0:
            issues.append({
                'title': f"Fix {results.validation_errors} validation errors",
                'description': "Resolve all validation errors found in project",
                'priority': 'critical',
                'category': 'bug',
                'effort_estimate': f"{max(1, results.validation_errors // CONSTANT_5)}d",
                'file_path': 'validation.toon.yaml'
            })

        if results.validation_warnings > 0:
            issues.append({
                'title': f"Address {results.validation_warnings} validation warnings",
                'description': "Fix all validation warnings",
                'priority': 'medium',
                'category': 'refactor',
                'effort_estimate': f"{max(1, results.validation_warnings // CONSTANT_3)}d",
                'file_path': 'validation.toon.yaml'
            })

        if results.duplication_groups > 0:
            issues.append({
                'title': f"Remove {results.duplication_groups} code duplication groups",
                'description': "Extract duplicated code into reusable functions",
                'priority': 'medium',
                'category': 'refactor',
                'effort_estimate': f"{results.duplication_groups * 2}h",
                'file_path': 'duplication.toon.yaml'
            })

        return {
            'issues': issues,
            'metrics': metrics,
            'summary': {
                'total_issues': len(issues),
                'priority_breakdown': {
                    'critical': len([i for i in issues if i['priority'] == 'critical']),
                    'high': len([i for i in issues if i['priority'] == 'high']),
                    'medium': len([i for i in issues if i['priority'] == 'medium']),
                    'low': len([i for i in issues if i['priority'] == 'low']),
                },
                'category_breakdown': {},
                'total_metrics': len(metrics),
                'critical_metrics': 0,
                'total_tasks': 0
            }
        }

    def _extract_external_metrics(self, results: AnalysisResults, compact: bool = False) -> dict[str, Any]:
        """Extract metrics from external tool results, keeping only essential data."""
        if compact:
            # In compact mode, only keep summary metrics
            return {
                'average_cc': results.cc_average,
                'critical_functions': results.critical_functions,
                'high_cc_count': len(results.high_cc_functions),
                'validation_errors': results.validation_errors,
                'validation_warnings': results.validation_warnings,
                'duplication_groups': results.duplication_groups,
                'saved_lines': results.saved_lines,
                'pass_rate': results.pass_rate
            }
        else:
            # Strip down high_cc_functions to essential fields only
            compact_high_cc = []
            for func in results.high_cc_functions[:CONSTANT_50]:  # Limit to top CONSTANT_50 functions
                compact_func = {
                    'name': func.get('name', 'unknown'),
                    'cc': func.get('cc', 0)
                }
                # Only include file path if available
                if 'file' in func:
                    compact_func['file'] = func['file']
                compact_high_cc.append(compact_func)

            return {
                'average_cc': results.cc_average,
                'critical_functions': results.critical_functions,
                'high_cc_functions': compact_high_cc,  # Now limited and stripped
                'high_cc_count': len(results.high_cc_functions),  # Keep total count
                'validation_errors': results.validation_errors,
                'validation_warnings': results.validation_warnings,
                'duplication_groups': results.duplication_groups,
                'saved_lines': results.saved_lines,
                'pass_rate': results.pass_rate
            }

    def generate_from_analysis(self,
                             analysis_path: str,
                             project_name: str = None,
                             max_sprints: int = CONSTANT_4,
                             focus_area: str = None,
                             external_metrics: dict[str, Any] | None = None,
                             compact: bool = False) -> Strategy:
        """Generate planfile from analyzed files."""
        # Analyze files
        analysis_result = self.analyzer.analyze_directory(Path(analysis_path))
        summary = analysis_result['summary']
        sprints = self.generator.generate_sprints(analysis_result, max_sprints)
        tickets = self.generator.generate_tickets(analysis_result)

        metrics = self._extract_key_metrics(analysis_result, external_metrics)
        project_name = project_name or Path(analysis_path).name

        strategy_data = {
            'name': f'{project_name.title()} Improvement Plan',
            'project_name': project_name,
            'project_type': 'improvement',
            'domain': 'software',
            'goal': self._generate_goal(summary, metrics, focus_area),
            'goals': self._generate_goals(summary, metrics, focus_area),
            'quality_gates': self._generate_quality_gates(metrics),
            'limits': self._default_limits(),
            'sprints': sprints,
            'tasks': self._generate_tasks(analysis_result),
            'metrics': {
                'current': metrics,
                'target': self._generate_target_metrics(metrics)
            },
            'tickets': tickets,
            'risks': self._generate_risks(analysis_result),
            'success_criteria': self._generate_success_criteria(metrics)
        }

        return self._create_strategy_object(strategy_data)

    def generate_from_current_project(self,
                                    project_path: str = ".",
                                    patterns: list[str] = None,
                                    compact: bool = False,
                                    **kwargs) -> Strategy:
        """Generate planfile by analyzing current project files."""
        if patterns is None:
            patterns = ['*.yaml', '*.yml', '*.json', '*.toon.yaml', '*.toon.yml', '*.py']

        analysis_result = self.analyzer.analyze_directory(Path(project_path), patterns)

        temp_dir = Path(project_path) / ".planfile_analysis"
        temp_dir.mkdir(exist_ok=True)

        # Only save analysis summary if not in compact mode
        if not compact:
            with open(temp_dir / "analysis_summary.json", 'w') as f:
                serializable_result = self._make_serializable(analysis_result)
                json.dump(serializable_result, f, indent=2, default=str)

        return self.generate_from_analysis(
            analysis_path=str(temp_dir),
            compact=compact,
            **kwargs
        )

    def _extract_key_metrics(self, analysis_result: dict[str, Any], external_metrics: dict[str, Any] | None = None) -> dict[str, Any]:
        return extract_key_metrics(analysis_result, external_metrics)

    def _generate_goal(self, summary: dict[str, Any], metrics: dict[str, Any], focus_area: str | None) -> str:
        return generate_goal(summary, metrics, focus_area)

    def _generate_goals(self, summary: dict[str, Any], metrics: dict[str, Any], focus_area: str | None) -> list[str]:
        return generate_goals(summary, metrics, focus_area)

    def _generate_quality_gates(self, metrics: dict[str, Any]) -> list[dict[str, Any]]:
        return generate_quality_gates(metrics)

    def _generate_tasks(self, analysis_result: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
        return generate_tasks(analysis_result)

    def _parse_effort(self, effort: str | None) -> int:
        return parse_effort(effort)

    def _generate_target_metrics(self, current: dict[str, Any]) -> dict[str, Any]:
        return generate_target_metrics(current)

    def _generate_risks(self, analysis_result: dict[str, Any]) -> list[dict[str, str]]:
        return generate_risks(analysis_result)

    def _generate_success_criteria(self, metrics: dict[str, Any]) -> list[str]:
        return generate_success_criteria(metrics)

    def _create_strategy_object(self, strategy_data: dict[str, Any]) -> Strategy:
        return strategy_data

    _SKIP_ATTRS = frozenset({'content', 'file_contents', 'raw_data'})
    _MAX_STR_LEN = 1000
    _MAX_LIST_LEN = 100

    def _is_primitive(self, obj: Any) -> bool:
        """Check if object is a primitive type that doesn't need serialization."""
        return isinstance(obj, (int, float, bool, str)) or obj is None

    def _serialize_primitive(self, obj: Any) -> Any:
        """Serialize a primitive value, truncating long strings."""
        if isinstance(obj, str) and len(obj) > self._MAX_STR_LEN:
            return f"<string_length_{len(obj)}>"
        return obj

    def _check_circular_ref(self, obj: Any, visited: set) -> str | None:
        """Check for circular reference. Returns marker string if circular, None otherwise."""
        obj_id = id(obj)
        if obj_id in visited:
            return f"<circular_reference_{obj_id}>"
        return None

    def _serialize_object_attrs(self, obj: Any, visited: set) -> dict:
        """Serialize an object's public __dict__ attributes."""
        result = {}
        for k, v in obj.__dict__.items():
            if k.startswith('_') or k in self._SKIP_ATTRS:
                continue
            result[k] = self._make_serializable(v, visited)
        return result

    def _serialize_dict_items(self, obj: dict, visited: set) -> dict:
        """Serialize a dict, truncating oversized string values."""
        result = {}
        for k, v in obj.items():
            result[k] = self._serialize_primitive(v) if isinstance(v, str) and len(v) > self._MAX_STR_LEN else self._make_serializable(v, visited)
        return result

    def _serialize_list_items(self, obj: list, visited: set) -> list | str:
        """Serialize list items. Returns truncated marker if list is too long."""
        if len(obj) > self._MAX_LIST_LEN:
            return f"<list_length_{len(obj)}>"
        return [self._make_serializable(item, visited) for item in obj]

    def _make_serializable(self, obj: Any, visited: set = None) -> Any:
        """Convert object to serializable format with cycle detection."""
        if visited is None:
            visited = set()

        # Handle primitives
        if self._is_primitive(obj):
            return self._serialize_primitive(obj)

        # Check for circular reference
        circular = self._check_circular_ref(obj, visited)
        if circular:
            return circular
        visited.add(id(obj))

        # Handle complex types
        if hasattr(obj, '__dict__'):
            return self._serialize_object_attrs(obj, visited)
        if isinstance(obj, dict):
            return self._serialize_dict_items(obj, visited)
        if isinstance(obj, list):
            return self._serialize_list_items(obj, visited)
        if hasattr(obj, '__name__'):
            return str(obj)
        return f"<type_{type(obj).__name__}>"


generator = PlanfileGenerator()
