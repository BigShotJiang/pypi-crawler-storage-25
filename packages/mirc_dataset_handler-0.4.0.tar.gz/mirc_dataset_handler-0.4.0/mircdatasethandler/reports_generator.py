from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any
from .models_utils import get_model

import pandas as pd


class ReportsGenerator:
    REQUIRED_COLUMNS = [
        "epoch",
        "loss_train",
        "loss_val",
        "avg_dice_val",
        "avg_iou_val",
        "dice_class_0_val",
        "iou_class_0_val",
        "dice_class_1_val",
        "iou_class_1_val",
        "dice_class_2_val",
        "iou_class_2_val",
    ]

    def __init__(self, input_folder: str | Path, dataloader, images_indexes) -> None:
        self.input_folder = Path(input_folder).expanduser().resolve()
        self.execution_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.output_folder: Path | None = None
        self.dataloader = dataloader
        self.images_indexes = images_indexes

        # Stores everything grouped by (experiment_timestamp, backbone, architecture)
        self.reports_data: dict[tuple[str, str, str], dict[str, Any]] = {}

        # Stores the chosen execution for reporting, grouped by (backbone, architecture)
        self.selected_reports_for_output: dict[tuple[str, str], dict[str, Any]] = {}

    def execute(self) -> Path:
        self.__validate_input_folder()
        self.__create_output_folder()
        self.__load_reports()
        self.__select_latest_execution_per_experiment()
        self.__generate_table_results()
        self.__generate_boxplots()
        self.__generate_qualitative_grid()
        self.__generate_latex_tabulars()
        self.__generate_friedman_tests()
        self.__generate_wilcoxon_tests(top_k=2)
        return self.output_folder

    def __validate_input_folder(self) -> None:
        if not self.input_folder.exists():
            raise FileNotFoundError(f"Input folder not found: {self.input_folder}")

        if not self.input_folder.is_dir():
            raise NotADirectoryError(f"Input path is not a directory: {self.input_folder}")

    def __create_output_folder(self) -> None:
        output_name = f"{self.input_folder.name}_analysis_{self.execution_timestamp}"
        self.output_folder = self.input_folder.parent / output_name
        self.output_folder.mkdir(parents=True, exist_ok=True)

    def __load_reports(self) -> None:
        csv_paths = self.__discover_report_files()

        if not csv_paths:
            raise FileNotFoundError(
                f"No '*_report.csv' files were found under: {self.input_folder}"
            )

        for csv_path in csv_paths:
            metadata = self.__extract_metadata_from_report_path(csv_path)
            dataframe = self.__read_report_dataframe(csv_path)
            best_row = self.__extract_best_validation_row(dataframe)
            self.__store_report(metadata=metadata, csv_path=csv_path, dataframe=dataframe, best_row=best_row)

    def __discover_report_files(self) -> list[Path]:
        csv_paths = sorted(self.input_folder.rglob("*_report.csv"))
        return [path for path in csv_paths if path.is_file()]

    def __extract_metadata_from_report_path(self, csv_path: Path) -> dict[str, str]:
        """
        Expected path pattern:
        input_folder / experiment_timestamp / backbone / architecture / foldX_report.csv
        """
        relative_parts = csv_path.relative_to(self.input_folder).parts

        if len(relative_parts) < 4:
            raise ValueError(
                f"Invalid report path structure for file: {csv_path}\n"
                f"Expected at least: <timestamp>/<backbone>/<architecture>/<fold_report.csv>"
            )

        experiment_timestamp = relative_parts[0]
        backbone = relative_parts[1]
        architecture = relative_parts[2]
        fold_name = self.__extract_fold_name(csv_path.name)

        return {
            "experiment_timestamp": experiment_timestamp,
            "backbone": backbone,
            "architecture": architecture,
            "fold_name": fold_name,
        }

    def __extract_fold_name(self, filename: str) -> str:
        match = re.match(r"^(fold\d+)_report\.csv$", filename)
        if not match:
            raise ValueError(
                f"Invalid report filename: {filename}. Expected pattern like 'fold1_report.csv'."
            )
        return match.group(1)

    def __read_report_dataframe(self, csv_path: Path) -> pd.DataFrame:
        df = pd.read_csv(csv_path)
        df.columns = [col.strip() for col in df.columns]

        self.__validate_required_columns(df, csv_path)
        df = self.__coerce_numeric_columns(df)

        if df.empty:
            raise ValueError(f"CSV file is empty: {csv_path}")

        return df

    def __validate_required_columns(self, df: pd.DataFrame, csv_path: Path) -> None:
        missing_columns = [col for col in self.REQUIRED_COLUMNS if col not in df.columns]
        if missing_columns:
            raise ValueError(
                f"Missing required columns in file {csv_path}:\n{missing_columns}"
            )

    def __coerce_numeric_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        for column in self.REQUIRED_COLUMNS:
            df[column] = pd.to_numeric(df[column], errors="raise")
        return df

    def __extract_best_validation_row(self, df: pd.DataFrame) -> dict[str, Any]:
        best_index = df["loss_val"].idxmin()
        best_row_series = df.loc[best_index].copy()

        best_row = best_row_series.to_dict()
        best_row["epoch"] = int(best_row["epoch"])
        return best_row

    def __store_report(
        self,
        metadata: dict[str, str],
        csv_path: Path,
        dataframe: pd.DataFrame,
        best_row: dict[str, Any],
    ) -> None:
        execution_key = (
            metadata["experiment_timestamp"],
            metadata["backbone"],
            metadata["architecture"],
        )

        if execution_key not in self.reports_data:
            self.reports_data[execution_key] = {
                "experiment_timestamp": metadata["experiment_timestamp"],
                "backbone": metadata["backbone"],
                "architecture": metadata["architecture"],
                "experiment_folder": str(csv_path.parent),
                "folds": {},
            }

        fold_name = metadata["fold_name"]

        if fold_name in self.reports_data[execution_key]["folds"]:
            raise ValueError(
                f"Duplicated fold '{fold_name}' found for execution {execution_key}."
            )

        self.reports_data[execution_key]["folds"][fold_name] = {
            "csv_path": str(csv_path),
            "dataframe": dataframe,
            "best_row": best_row,
            "best_epoch": best_row["epoch"],
            "best_loss_val": float(best_row["loss_val"]),
        }

    def __select_latest_execution_per_experiment(self) -> None:
        """
        If there are multiple timestamps for the same (backbone, architecture),
        the latest timestamp is selected for the final reports.
        """
        grouped_by_experiment: dict[tuple[str, str], list[dict[str, Any]]] = {}

        for execution_data in self.reports_data.values():
            experiment_key = (
                execution_data["backbone"],
                execution_data["architecture"],
            )
            grouped_by_experiment.setdefault(experiment_key, []).append(execution_data)

        self.selected_reports_for_output = {}

        for experiment_key, executions in grouped_by_experiment.items():
            latest_execution = max(executions, key=lambda item: item["experiment_timestamp"])
            self.selected_reports_for_output[experiment_key] = latest_execution

    def __generate_table_results(self) -> None:
        general_rows: list[dict[str, str]] = []
        class_rows: list[dict[str, str]] = []

        for (backbone, architecture), execution_data in sorted(
            self.selected_reports_for_output.items(),
            key=lambda item: (item[0][0].lower(), item[0][1].lower())
        ):
            best_rows_df = self.__build_best_rows_dataframe(execution_data)

            general_rows.append({
                "backbone": backbone,
                "architecture": architecture,
                "Avg. Dice": self.__format_mean_std(best_rows_df["avg_dice_val"]),
                "Avg. IoU": self.__format_mean_std(best_rows_df["avg_iou_val"]),
            })

            class_rows.append({
                "backbone": backbone,
                "architecture": architecture,
                "dice_human": self.__format_mean_std(best_rows_df["dice_class_1_val"]),
                "iou_human": self.__format_mean_std(best_rows_df["iou_class_1_val"]),
                "dice_robot": self.__format_mean_std(best_rows_df["dice_class_2_val"]),
                "iou_robot": self.__format_mean_std(best_rows_df["iou_class_2_val"]),
            })

        general_df = pd.DataFrame(general_rows)
        class_df = pd.DataFrame(class_rows)

        self.__write_table_report(
            filename="general_report.txt",
            title="GENERAL REPORT",
            description=(
                "Best row per fold selected by minimum loss_val. "
                "Reported values are mean ± std across folds."
            ),
            dataframe=general_df,
        )

        self.__write_table_report(
            filename="class_report.txt",
            title="CLASS REPORT",
            description=(
                "Background was ignored. Best row per fold selected by minimum loss_val. "
                "Reported values are mean ± std across folds."
            ),
            dataframe=class_df,
        )

    def __build_best_rows_dataframe(self, execution_data: dict[str, Any]) -> pd.DataFrame:
        ordered_folds = sorted(
            execution_data["folds"].items(),
            key=lambda item: self.__extract_fold_number(item[0]),
        )

        best_rows = []
        for fold_name, fold_data in ordered_folds:
            row = {"fold": fold_name, **fold_data["best_row"]}
            best_rows.append(row)

        return pd.DataFrame(best_rows)

    def __extract_fold_number(self, fold_name: str) -> int:
        match = re.search(r"(\d+)", fold_name)
        return int(match.group(1)) if match else 10**9

    def __format_mean_std(self, series: pd.Series) -> str:
        mean_value = float(series.mean())
        std_value = float(series.std(ddof=1)) if len(series) > 1 else 0.0
        return f"{mean_value:.4f} ± {std_value:.4f}"

    def __write_table_report(
        self,
        filename: str,
        title: str,
        description: str,
        dataframe: pd.DataFrame,
    ) -> None:
        if self.output_folder is None:
            raise RuntimeError("Output folder was not created before writing reports.")

        output_path = self.output_folder / filename

        lines = [
            title,
            "=" * len(title),
            "",
            f"Input folder: {self.input_folder}",
            f"Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            description,
            "If multiple timestamps existed for the same (backbone, architecture), the latest one was used.",
            "",
            dataframe.to_string(index=False),
            "",
        ]

        output_path.write_text("\n".join(lines), encoding="utf-8")
    
    def __generate_boxplots(self) -> None:
        if self.output_folder is None:
            raise RuntimeError("Output folder was not created before generating boxplots.")

        if not self.selected_reports_for_output:
            self.__select_latest_execution_per_experiment()

        import matplotlib.pyplot as plt

        def normalize_backbone(backbone_name: str) -> tuple[str, str]:
            name = backbone_name.strip().lower().replace("_", "").replace("-", "")
            if "resnet34" in name:
                return "ResNet-34", "R34"
            if "regnetx" in name or "regnet" in name:
                return "RegNetX-4.0GF", "RGX"
            return backbone_name, backbone_name.upper()

        def normalize_architecture(architecture_name: str) -> tuple[str, str]:
            name = architecture_name.strip().lower().replace("_", "").replace("-", "")
            if "deeplabv3" in name or name == "dlv3":
                return "DeepLabV3", "DLV3"
            if name == "fpn":
                return "FPN", "FPN"
            if name == "pan":
                return "PAN", "PAN"
            if name == "unet" or name == "u":
                return "U-Net", "U"
            return architecture_name, architecture_name.upper()

        def fold_number(fold_name: str) -> int:
            match = re.search(r"(\d+)", fold_name)
            return int(match.group(1)) if match else 10**9

        def make_center(values: list[float]) -> float:
            return sum(values) / len(values) if values else 0.0

        backbone_order = ["ResNet-34", "RegNetX-4.0GF"]
        architecture_order = ["DeepLabV3", "FPN", "PAN", "U-Net"]

        metric_configs = [
            {
                "metric_key": "avg_iou_val",
                "ylabel": "IoU (avg)",
                "center_label": None,
                "basename": "figA_avg_iou_foldwise_boxpoints",
            },
            {
                "metric_key": "iou_class_1_val",
                "ylabel": "IoU (human, class 1)",
                "center_label": "(a) Human",
                "basename": "figB_iou_human_foldwise_boxpoints",
            },
            {
                "metric_key": "iou_class_2_val",
                "ylabel": "IoU (robot, class 2)",
                "center_label": "(b) Robot",
                "basename": "figC_iou_robot_foldwise_boxpoints",
            },
        ]

        prepared_experiments = []
        for (_, _), execution_data in self.selected_reports_for_output.items():
            backbone_full, backbone_short = normalize_backbone(execution_data["backbone"])
            architecture_full, architecture_short = normalize_architecture(execution_data["architecture"])

            ordered_folds = sorted(
                execution_data["folds"].items(),
                key=lambda item: fold_number(item[0])
            )

            prepared_experiments.append(
                {
                    "backbone_full": backbone_full,
                    "backbone_short": backbone_short,
                    "architecture_full": architecture_full,
                    "architecture_short": architecture_short,
                    "execution_data": execution_data,
                    "sort_key": (
                        backbone_order.index(backbone_full) if backbone_full in backbone_order else 999,
                        architecture_order.index(architecture_full) if architecture_full in architecture_order else 999,
                    ),
                    "ordered_folds": ordered_folds,
                }
            )

        prepared_experiments = sorted(prepared_experiments, key=lambda item: item["sort_key"])

        if not prepared_experiments:
            raise RuntimeError("No experiments available to generate boxplots.")

        for metric_config in metric_configs:
            metric_key = metric_config["metric_key"]
            ylabel = metric_config["ylabel"]
            center_label = metric_config["center_label"]
            basename = metric_config["basename"]

            boxplot_values = []
            x_labels = []
            group_positions = {"ResNet-34": [], "RegNetX-4.0GF": []}

            for index, experiment in enumerate(prepared_experiments, start=1):
                fold_values = [
                    float(fold_data["best_row"][metric_key])
                    for _, fold_data in experiment["ordered_folds"]
                ]

                if not fold_values:
                    continue

                boxplot_values.append(fold_values)
                model_label = f"{experiment['backbone_short']}-{experiment['architecture_short']}"
                x_labels.append(model_label)

                if experiment["backbone_full"] in group_positions:
                    group_positions[experiment["backbone_full"]].append(index)

            if not boxplot_values:
                continue

            fig, ax = plt.subplots(figsize=(12.8, 6.8))

            box = ax.boxplot(
                boxplot_values,
                patch_artist=True,
                widths=0.55,
                showfliers=False,
                medianprops={"color": "#f28e2b", "linewidth": 1.8},
                boxprops={"facecolor": "none", "edgecolor": "black", "linewidth": 1.6},
                whiskerprops={"color": "black", "linewidth": 1.6},
                capprops={"color": "black", "linewidth": 1.6},
            )

            cmap = plt.get_cmap("tab10")
            colors = [cmap(i % 10) for i in range(len(boxplot_values))]

            for x_pos, values, color in zip(range(1, len(boxplot_values) + 1), boxplot_values, colors):
                ax.scatter(
                    [x_pos] * len(values),
                    values,
                    s=60,
                    color=color,
                    alpha=0.85,
                    zorder=3,
                    edgecolors="none",
                )

            ax.set_xticks(range(1, len(x_labels) + 1))
            ax.set_xticklabels(x_labels, fontsize=16)
            ax.set_xlabel("Model ID", fontsize=20)
            ax.set_ylabel(ylabel, fontsize=20)
            ax.tick_params(axis="y", labelsize=14)

            ax.grid(axis="y", linestyle="--", alpha=0.4)
            ax.set_axisbelow(True)

            if group_positions["ResNet-34"] and group_positions["RegNetX-4.0GF"]:
                divider_x = max(group_positions["ResNet-34"]) + 0.5
                ax.axvline(
                    divider_x,
                    linestyle="--",
                    linewidth=1.5,
                    color="#5DA5DA",
                    alpha=0.8,
                )

            xaxis_transform = ax.get_xaxis_transform()

            if group_positions["ResNet-34"]:
                ax.text(
                    make_center(group_positions["ResNet-34"]),
                    1.02,
                    "ResNet-34",
                    transform=xaxis_transform,
                    ha="center",
                    va="bottom",
                    fontsize=22,
                )

            if center_label is not None:
                ax.text(
                    (len(boxplot_values) + 1) / 2,
                    1.02,
                    center_label,
                    transform=xaxis_transform,
                    ha="center",
                    va="bottom",
                    fontsize=22,
                )

            if group_positions["RegNetX-4.0GF"]:
                ax.text(
                    make_center(group_positions["RegNetX-4.0GF"]),
                    1.02,
                    "RegNetX-4.0GF",
                    transform=xaxis_transform,
                    ha="center",
                    va="bottom",
                    fontsize=22,
                )

            ax.set_xlim(0.5, len(boxplot_values) + 0.5)

            fig.tight_layout(rect=[0.02, 0.02, 0.98, 0.95])

            png_path = self.output_folder / f"{basename}.png"
            pdf_path = self.output_folder / f"{basename}.pdf"

            fig.savefig(png_path, dpi=300, bbox_inches="tight")
            fig.savefig(pdf_path, dpi=300, bbox_inches="tight")
            plt.close(fig)

    def __generate_qualitative_grid(self) -> None:
        if self.output_folder is None:
            raise RuntimeError("Output folder was not created before generating the qualitative grid.")

        if not hasattr(self, "dataloader") or self.dataloader is None:
            raise RuntimeError("self.dataloader was not provided.")

        if not hasattr(self, "images_indexes") or not self.images_indexes:
            raise RuntimeError("self.images_indexes was not provided or is empty.")

        if not self.selected_reports_for_output:
            self.__select_latest_execution_per_experiment()

        import re
        from pathlib import Path

        import matplotlib.pyplot as plt
        import numpy as np
        import torch

        device = torch.device(
            getattr(self, "device", "cuda" if torch.cuda.is_available() else "cpu")
        )

        def normalize_backbone(backbone_name: str) -> tuple[str, str]:
            name = backbone_name.strip().lower().replace("_", "").replace("-", "")
            if "resnet34" in name:
                return "ResNet-34", "R34"
            if "regnetx" in name or "regnet" in name:
                return "RegNetX-4.0GF", "RGX"
            return backbone_name, backbone_name.upper()

        def normalize_architecture(architecture_name: str) -> tuple[str, str]:
            name = architecture_name.strip().lower().replace("_", "").replace("-", "")
            if "deeplabv3" in name or name == "dlv3":
                return "DeepLabV3", "DLV3"
            if name == "fpn":
                return "FPN", "FPN"
            if name == "pan":
                return "PAN", "PAN"
            if name == "unet" or name == "u":
                return "U-Net", "U"
            return architecture_name, architecture_name.upper()

        def extract_state_dict(checkpoint):
            if isinstance(checkpoint, dict):
                if "state_dict" in checkpoint:
                    state_dict = checkpoint["state_dict"]
                elif "model_state_dict" in checkpoint:
                    state_dict = checkpoint["model_state_dict"]
                else:
                    is_state_dict = all(isinstance(v, torch.Tensor) for v in checkpoint.values())
                    if is_state_dict:
                        state_dict = checkpoint
                    else:
                        raise ValueError("Could not identify a valid state_dict inside the checkpoint.")
            else:
                raise ValueError("Checkpoint format is not supported.")

            cleaned_state_dict = {}
            for key, value in state_dict.items():
                new_key = key[7:] if key.startswith("module.") else key
                cleaned_state_dict[new_key] = value

            return cleaned_state_dict

        def build_ranking():
            ranking = []

            for (_, _), execution_data in self.selected_reports_for_output.items():
                best_rows_df = self.__build_best_rows_dataframe(execution_data)

                mean_avg_iou = float(best_rows_df["avg_iou_val"].mean())
                mean_avg_dice = float(best_rows_df["avg_dice_val"].mean())
                std_avg_iou = (
                    float(best_rows_df["avg_iou_val"].std(ddof=1))
                    if len(best_rows_df) > 1
                    else 0.0
                )

                ranking.append(
                    {
                        "backbone": execution_data["backbone"],
                        "architecture": execution_data["architecture"],
                        "execution_data": execution_data,
                        "mean_avg_iou": mean_avg_iou,
                        "mean_avg_dice": mean_avg_dice,
                        "std_avg_iou": std_avg_iou,
                    }
                )

            ranking = sorted(
                ranking,
                key=lambda item: (
                    -item["mean_avg_iou"],
                    -item["mean_avg_dice"],
                    item["std_avg_iou"],
                ),
            )

            return ranking

        def choose_models(ranking):
            if len(ranking) < 2:
                raise RuntimeError("At least two experiments are required to build the qualitative comparison.")

            model_a = ranking[0]
            model_b = None

            for candidate in ranking[1:]:
                if (
                    candidate["backbone"] != model_a["backbone"]
                    and candidate["architecture"] != model_a["architecture"]
                ):
                    model_b = candidate
                    break

            if model_b is None:
                raise RuntimeError(
                    "Could not select model B without repeating both backbone and architecture."
                )

            return model_a, model_b

        def get_model_checkpoint_path(model_info) -> Path:
            experiment_folder = Path(model_info["execution_data"]["experiment_folder"])
            checkpoint_path = experiment_folder / "fold1" / "best_val_loss.pth"

            if not checkpoint_path.exists():
                raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

            return checkpoint_path

        def load_model_for_inference(model_info):
            checkpoint_path = get_model_checkpoint_path(model_info)

            model = get_model(
                model_name=model_info["architecture"],
                backbone=model_info["backbone"],
            )

            checkpoint = torch.load(checkpoint_path, map_location="cpu")
            state_dict = extract_state_dict(checkpoint)
            model.load_state_dict(state_dict, strict=False)
            model.to(device)
            model.eval()

            return model

        def get_sample_from_index(sample_index: int):
            dataset = getattr(self.dataloader, "dataset", None)

            if dataset is not None:
                return dataset[sample_index]

            current_index = 0
            for batch in self.dataloader:
                images = batch["image"]
                masks = batch["mask"]

                if not torch.is_tensor(images):
                    images = torch.as_tensor(images)
                if not torch.is_tensor(masks):
                    masks = torch.as_tensor(masks)

                if images.ndim == 3:
                    batch_size = 1
                else:
                    batch_size = images.shape[0]

                if current_index + batch_size > sample_index:
                    local_index = sample_index - current_index

                    if batch_size == 1:
                        image_tensor = images if images.ndim == 3 else images[0]
                        mask_tensor = masks if masks.ndim == 2 else masks[0]
                    else:
                        image_tensor = images[local_index]
                        mask_tensor = masks[local_index]

                    return {"image": image_tensor, "mask": mask_tensor}

                current_index += batch_size

            raise IndexError(f"Sample index {sample_index} is out of range.")

        def to_image_numpy(image_tensor) -> np.ndarray:
            if not torch.is_tensor(image_tensor):
                image_tensor = torch.as_tensor(image_tensor)

            image_tensor = image_tensor.detach().cpu().float()

            if image_tensor.ndim == 4:
                image_tensor = image_tensor[0]

            image_np = image_tensor.permute(1, 2, 0).numpy()
            image_np = np.clip(image_np, 0.0, 1.0)

            return image_np

        def to_mask_numpy(mask_tensor) -> np.ndarray:
            if not torch.is_tensor(mask_tensor):
                mask_tensor = torch.as_tensor(mask_tensor)

            mask_tensor = mask_tensor.detach().cpu()

            if mask_tensor.ndim == 3:
                if mask_tensor.shape[0] == 1:
                    mask_tensor = mask_tensor[0]
                elif mask_tensor.shape[-1] == 1:
                    mask_tensor = mask_tensor[..., 0]

            return mask_tensor.numpy().astype(np.uint8)

        def predict_mask(model, image_tensor) -> np.ndarray:
            if not torch.is_tensor(image_tensor):
                image_tensor = torch.as_tensor(image_tensor)

            image_tensor = image_tensor.float()

            if image_tensor.ndim == 3:
                image_tensor = image_tensor.unsqueeze(0)

            image_tensor = image_tensor.to(device)

            with torch.no_grad():
                output = model(image_tensor)

                if isinstance(output, dict):
                    if "out" in output:
                        output = output["out"]
                    elif "mask" in output:
                        output = output["mask"]
                    elif "masks" in output:
                        output = output["masks"]
                    else:
                        output = next(iter(output.values()))
                elif isinstance(output, (list, tuple)):
                    output = output[0]

                pred_mask = torch.argmax(output, dim=1).squeeze(0).detach().cpu().numpy().astype(np.uint8)

            return pred_mask

        def colorize_mask(mask_np: np.ndarray) -> np.ndarray:
            h, w = mask_np.shape
            color_mask = np.zeros((h, w, 3), dtype=np.float32)

            # class 1 -> human -> red
            color_mask[mask_np == 1] = np.array([1.0, 0.0, 0.0], dtype=np.float32)

            # class 2 -> robot -> green
            color_mask[mask_np == 2] = np.array([0.0, 1.0, 0.0], dtype=np.float32)

            return color_mask

        def build_overlay(image_np: np.ndarray, mask_np: np.ndarray, alpha: float = 0.45) -> np.ndarray:
            overlay = image_np.copy()
            color_mask = colorize_mask(mask_np)
            foreground = mask_np > 0

            overlay[foreground] = (
                (1.0 - alpha) * overlay[foreground] + alpha * color_mask[foreground]
            )

            return np.clip(overlay, 0.0, 1.0)

        ranking = build_ranking()
        model_a_info, model_b_info = choose_models(ranking)

        model_a = load_model_for_inference(model_a_info)
        model_b = load_model_for_inference(model_b_info)

        model_a_backbone_full, model_a_backbone_short = normalize_backbone(model_a_info["backbone"])
        model_a_arch_full, model_a_arch_short = normalize_architecture(model_a_info["architecture"])

        model_b_backbone_full, model_b_backbone_short = normalize_backbone(model_b_info["backbone"])
        model_b_arch_full, model_b_arch_short = normalize_architecture(model_b_info["architecture"])

        print(
            f"Model A selected: {model_a_backbone_full} + {model_a_arch_full} | "
            f"mean Avg IoU = {model_a_info['mean_avg_iou']:.4f}, "
            f"mean Avg Dice = {model_a_info['mean_avg_dice']:.4f}, "
            f"std Avg IoU = {model_a_info['std_avg_iou']:.4f}"
        )
        print(
            f"Model B selected: {model_b_backbone_full} + {model_b_arch_full} | "
            f"mean Avg IoU = {model_b_info['mean_avg_iou']:.4f}, "
            f"mean Avg Dice = {model_b_info['mean_avg_dice']:.4f}, "
            f"std Avg IoU = {model_b_info['std_avg_iou']:.4f}"
        )

        num_rows = len(self.images_indexes)
        num_cols = 6

        fig, axes = plt.subplots(
            num_rows,
            num_cols,
            figsize=(18, 3.2 * num_rows),
        )

        if num_rows == 1:
            axes = np.expand_dims(axes, axis=0)

        titles = [
            "Image",
            "GT (person/robot)",
            "Pred mask (A)",
            "Overlay (A)",
            "Pred mask (B)",
            "Overlay (B)",
        ]

        for row_idx, sample_index in enumerate(self.images_indexes):
            sample = get_sample_from_index(sample_index)

            image_tensor = sample["image"]
            gt_mask_tensor = sample["mask"]

            image_np = to_image_numpy(image_tensor)
            gt_mask_np = to_mask_numpy(gt_mask_tensor)

            pred_mask_a_np = predict_mask(model_a, image_tensor)
            pred_mask_b_np = predict_mask(model_b, image_tensor)

            gt_mask_vis = colorize_mask(gt_mask_np)
            pred_mask_a_vis = colorize_mask(pred_mask_a_np)
            pred_mask_b_vis = colorize_mask(pred_mask_b_np)

            overlay_a = build_overlay(image_np, pred_mask_a_np)
            overlay_b = build_overlay(image_np, pred_mask_b_np)

            panels = [
                image_np,
                gt_mask_vis,
                pred_mask_a_vis,
                overlay_a,
                pred_mask_b_vis,
                overlay_b,
            ]

            for col_idx, panel in enumerate(panels):
                ax = axes[row_idx, col_idx]
                ax.imshow(panel)
                ax.axis("off")

                if row_idx == 0:
                    ax.set_title(titles[col_idx], fontsize=14)

        fig.suptitle(
            f"A = {model_a_backbone_short}-{model_a_arch_short} ({model_a_backbone_full} + {model_a_arch_full})    |    "
            f"B = {model_b_backbone_short}-{model_b_arch_short} ({model_b_backbone_full} + {model_b_arch_full})",
            fontsize=14,
            y=0.995,
        )

        fig.tight_layout(rect=[0.0, 0.0, 1.0, 0.985])

        output_png = self.output_folder / "qualitative_grid_selected_models.png"
        output_pdf = self.output_folder / "qualitative_grid_selected_models.pdf"

        fig.savefig(output_png, dpi=300, bbox_inches="tight")
        fig.savefig(output_pdf, dpi=300, bbox_inches="tight")
        plt.close(fig)

    def __generate_latex_tabulars(self) -> None:
        if self.output_folder is None:
            raise RuntimeError("Output folder was not created before generating LaTeX tabulars.")

        if not self.selected_reports_for_output:
            self.__select_latest_execution_per_experiment()

        def normalize_backbone(backbone_name: str) -> str:
            name = backbone_name.strip().lower().replace("_", "").replace("-", "")
            if "resnet34" in name:
                return "ResNet-34"
            if "regnetx" in name or "regnet" in name:
                return "RegNetX-4.0GF"
            return backbone_name

        def normalize_architecture(architecture_name: str) -> str:
            name = architecture_name.strip().lower().replace("_", "").replace("-", "")
            if "deeplabv3" in name or name == "dlv3":
                return "DeepLabV3"
            if name == "fpn":
                return "FPN"
            if name == "pan":
                return "PAN"
            if name == "unet" or name == "u":
                return "U-Net"
            return architecture_name

        def mean_std(series: pd.Series) -> tuple[float, float]:
            mean_value = float(series.mean())
            std_value = float(series.std(ddof=1)) if len(series) > 1 else 0.0
            return mean_value, std_value

        def fmt_pm(mean_value: float, std_value: float, bold: bool = False) -> str:
            value = f"{mean_value:.4f} $\\pm$ {std_value:.4f}"
            return f"\\textbf{{{value}}}" if bold else value

        backbone_order = {"ResNet-34": 0, "RegNetX-4.0GF": 1}
        architecture_order = {"DeepLabV3": 0, "FPN": 1, "PAN": 2, "U-Net": 3}

        general_rows = []
        class_rows = []

        for (_, _), execution_data in self.selected_reports_for_output.items():
            best_rows_df = self.__build_best_rows_dataframe(execution_data)

            backbone = normalize_backbone(execution_data["backbone"])
            architecture = normalize_architecture(execution_data["architecture"])

            avg_dice_mean, avg_dice_std = mean_std(best_rows_df["avg_dice_val"])
            avg_iou_mean, avg_iou_std = mean_std(best_rows_df["avg_iou_val"])

            dice_human_mean, dice_human_std = mean_std(best_rows_df["dice_class_1_val"])
            iou_human_mean, iou_human_std = mean_std(best_rows_df["iou_class_1_val"])
            dice_robot_mean, dice_robot_std = mean_std(best_rows_df["dice_class_2_val"])
            iou_robot_mean, iou_robot_std = mean_std(best_rows_df["iou_class_2_val"])

            general_rows.append(
                {
                    "backbone": backbone,
                    "architecture": architecture,
                    "avg_dice_mean": avg_dice_mean,
                    "avg_dice_std": avg_dice_std,
                    "avg_iou_mean": avg_iou_mean,
                    "avg_iou_std": avg_iou_std,
                }
            )

            class_rows.append(
                {
                    "backbone": backbone,
                    "architecture": architecture,
                    "dice_human_mean": dice_human_mean,
                    "dice_human_std": dice_human_std,
                    "iou_human_mean": iou_human_mean,
                    "iou_human_std": iou_human_std,
                    "dice_robot_mean": dice_robot_mean,
                    "dice_robot_std": dice_robot_std,
                    "iou_robot_mean": iou_robot_mean,
                    "iou_robot_std": iou_robot_std,
                }
            )

        general_rows = sorted(
            general_rows,
            key=lambda row: (
                backbone_order.get(row["backbone"], 999),
                architecture_order.get(row["architecture"], 999),
            ),
        )

        class_rows = sorted(
            class_rows,
            key=lambda row: (
                backbone_order.get(row["backbone"], 999),
                architecture_order.get(row["architecture"], 999),
            ),
        )

        best_general_avg_dice = max(row["avg_dice_mean"] for row in general_rows)
        best_general_avg_iou = max(row["avg_iou_mean"] for row in general_rows)

        best_class_dice_human = max(row["dice_human_mean"] for row in class_rows)
        best_class_iou_human = max(row["iou_human_mean"] for row in class_rows)
        best_class_dice_robot = max(row["dice_robot_mean"] for row in class_rows)
        best_class_iou_robot = max(row["iou_robot_mean"] for row in class_rows)

        general_lines = [
            "\\begin{tabular}{l l l l}",
            "\\hline",
            "\\textbf{Backbone} & \\textbf{Architecture} & \\textbf{Avg. Dice} & \\textbf{Avg. IoU} \\\\",
            "\\hline",
        ]

        for row in general_rows:
            avg_dice_text = fmt_pm(
                row["avg_dice_mean"],
                row["avg_dice_std"],
                bold=abs(row["avg_dice_mean"] - best_general_avg_dice) < 1e-12,
            )
            avg_iou_text = fmt_pm(
                row["avg_iou_mean"],
                row["avg_iou_std"],
                bold=abs(row["avg_iou_mean"] - best_general_avg_iou) < 1e-12,
            )

            general_lines.append(
                f"{row['backbone']} & {row['architecture']} & {avg_dice_text} & {avg_iou_text} \\\\"
            )

        general_lines.extend(
            [
                "\\hline",
                "\\end{tabular}",
            ]
        )

        class_lines = [
            "\\begin{tabular}{llllll}",
            "\\hline",
            "\\textbf{Backbone} & \\textbf{Architecture} &",
            "\\textbf{Dice$_{\\mathrm{human}}$} & \\textbf{IoU$_{\\mathrm{human}}$} &",
            "\\textbf{Dice$_{\\mathrm{robot}}$} & \\textbf{IoU$_{\\mathrm{robot}}$} \\\\",
            "\\hline",
        ]

        for row in class_rows:
            dice_human_text = fmt_pm(
                row["dice_human_mean"],
                row["dice_human_std"],
                bold=abs(row["dice_human_mean"] - best_class_dice_human) < 1e-12,
            )
            iou_human_text = fmt_pm(
                row["iou_human_mean"],
                row["iou_human_std"],
                bold=abs(row["iou_human_mean"] - best_class_iou_human) < 1e-12,
            )
            dice_robot_text = fmt_pm(
                row["dice_robot_mean"],
                row["dice_robot_std"],
                bold=abs(row["dice_robot_mean"] - best_class_dice_robot) < 1e-12,
            )
            iou_robot_text = fmt_pm(
                row["iou_robot_mean"],
                row["iou_robot_std"],
                bold=abs(row["iou_robot_mean"] - best_class_iou_robot) < 1e-12,
            )

            class_lines.append(
                f"{row['backbone']} & {row['architecture']} & "
                f"{dice_human_text} & {iou_human_text} & "
                f"{dice_robot_text} & {iou_robot_text} \\\\"
            )

        class_lines.extend(
            [
                "\\hline",
                "\\end{tabular}",
            ]
        )

        (self.output_folder / "general_report_tabular.txt").write_text(
            "\n".join(general_lines),
            encoding="utf-8",
        )

        (self.output_folder / "class_report_tabular.txt").write_text(
            "\n".join(class_lines),
            encoding="utf-8",
        )

    def __generate_friedman_tests(self) -> None:
        if self.output_folder is None:
            raise RuntimeError("Output folder was not created before generating Friedman tests.")

        if not self.selected_reports_for_output:
            self.__select_latest_execution_per_experiment()

        from scipy.stats import friedmanchisquare

        def normalize_backbone(backbone_name: str) -> str:
            name = backbone_name.strip().lower().replace("_", "").replace("-", "")
            if "resnet34" in name:
                return "ResNet-34"
            if "regnetx" in name or "regnet" in name:
                return "RegNetX-4.0GF"
            return backbone_name

        def normalize_architecture(architecture_name: str) -> str:
            name = architecture_name.strip().lower().replace("_", "").replace("-", "")
            if "deeplabv3" in name or name == "dlv3":
                return "DeepLabV3"
            if name == "fpn":
                return "FPN"
            if name == "pan":
                return "PAN"
            if name == "unet" or name == "u":
                return "U-Net"
            return architecture_name

        def format_p_value_latex(p_value: float) -> str:
            if p_value == 0:
                return "$< 10^{-16}$"

            if p_value < 1e-3:
                exponent = int(f"{p_value:.0e}".split("e")[1])
                mantissa = p_value / (10 ** exponent)
                return f"${mantissa:.2f} \\times 10^{{{exponent}}}$"

            if p_value < 1e-2:
                exponent = int(f"{p_value:.0e}".split("e")[1])
                mantissa = p_value / (10 ** exponent)
                return f"${mantissa:.2f} \\times 10^{{{exponent}}}$"

            return f"{p_value:.4f}"

        backbone_order = {"ResNet-34": 0, "RegNetX-4.0GF": 1}
        architecture_order = {"DeepLabV3": 0, "FPN": 1, "PAN": 2, "U-Net": 3}

        ordered_experiments = []
        for (_, _), execution_data in self.selected_reports_for_output.items():
            backbone = normalize_backbone(execution_data["backbone"])
            architecture = normalize_architecture(execution_data["architecture"])

            best_rows_df = self.__build_best_rows_dataframe(execution_data).copy()
            if "fold" not in best_rows_df.columns:
                raise RuntimeError("Best rows dataframe must contain a 'fold' column.")

            ordered_experiments.append(
                {
                    "backbone": backbone,
                    "architecture": architecture,
                    "best_rows_df": best_rows_df,
                }
            )

        ordered_experiments = sorted(
            ordered_experiments,
            key=lambda item: (
                backbone_order.get(item["backbone"], 999),
                architecture_order.get(item["architecture"], 999),
            ),
        )

        if len(ordered_experiments) < 3:
            raise RuntimeError("Friedman test requires at least three model conditions.")

        common_folds = None
        for item in ordered_experiments:
            folds = set(item["best_rows_df"]["fold"].tolist())
            common_folds = folds if common_folds is None else common_folds.intersection(folds)

        if not common_folds:
            raise RuntimeError("No common folds were found across the selected experiments.")

        def fold_sort_key(fold_name: str) -> int:
            match = re.search(r"(\d+)", str(fold_name))
            return int(match.group(1)) if match else 10**9

        common_folds = sorted(common_folds, key=fold_sort_key)

        metric_configs = [
            ("Avg IoU", "avg_iou_val"),
            ("IoU$_{\\mathrm{human}}$", "iou_class_1_val"),
            ("IoU$_{\\mathrm{robot}}$", "iou_class_2_val"),
        ]

        results = []

        for metric_label, metric_column in metric_configs:
            model_vectors = []

            for item in ordered_experiments:
                df = item["best_rows_df"]
                df = df[df["fold"].isin(common_folds)].copy()
                df["__fold_order__"] = df["fold"].apply(fold_sort_key)
                df = df.sort_values("__fold_order__")

                if len(df) != len(common_folds):
                    raise RuntimeError(
                        f"Experiment {item['backbone']} + {item['architecture']} does not contain all common folds."
                    )

                model_vectors.append(df[metric_column].astype(float).tolist())

            statistic, p_value = friedmanchisquare(*model_vectors)

            n_blocks = len(common_folds)
            k_conditions = len(model_vectors)
            dof = k_conditions - 1
            kendalls_w = statistic / (n_blocks * (k_conditions - 1))

            results.append(
                {
                    "metric": metric_label,
                    "chi2": float(statistic),
                    "dof": int(dof),
                    "p_value": float(p_value),
                    "kendalls_w": float(kendalls_w),
                }
            )

        lines = [
            "\\begin{tabular}{l l l l l}",
            "\\hline",
            "\\textbf{Metric} & \\textbf{$\\chi^2$} & \\textbf{dof} & \\textbf{p-value} & \\textbf{Kendall's $W$} \\\\",
            "\\hline",
        ]

        for row in results:
            lines.append(
                f"{row['metric']} & "
                f"{row['chi2']:.3f} & "
                f"{row['dof']} & "
                f"{format_p_value_latex(row['p_value'])} & "
                f"{row['kendalls_w']:.3f} \\\\"
            )

        lines.extend(
            [
                "\\hline",
                "\\end{tabular}",
            ]
        )

        (self.output_folder / "friedman_tests.txt").write_text(
            "\n".join(lines),
            encoding="utf-8",
        )
    
    def __generate_wilcoxon_tests(self, top_k: int = 2) -> None:
        if self.output_folder is None:
            raise RuntimeError("Output folder was not created before generating Wilcoxon tests.")

        if not self.selected_reports_for_output:
            self.__select_latest_execution_per_experiment()

        if top_k < 2:
            raise ValueError("top_k must be at least 2.")

        import re
        import numpy as np
        from scipy.stats import wilcoxon, rankdata

        def normalize_backbone(backbone_name: str) -> str:
            name = backbone_name.strip().lower().replace("_", "").replace("-", "")
            if "resnet34" in name:
                return "ResNet-34"
            if "regnetx" in name or "regnet" in name:
                return "RegNetX-4.0GF"
            return backbone_name

        def normalize_architecture(architecture_name: str) -> str:
            name = architecture_name.strip().lower().replace("_", "").replace("-", "")
            if "deeplabv3" in name or name == "dlv3":
                return "DeepLabV3"
            if name == "fpn":
                return "FPN"
            if name == "pan":
                return "PAN"
            if name == "unet" or name == "u":
                return "U-Net"
            return architecture_name

        def backbone_short(backbone_name: str) -> str:
            backbone_name = normalize_backbone(backbone_name)
            if backbone_name == "ResNet-34":
                return "R34"
            if backbone_name == "RegNetX-4.0GF":
                return "RGX"
            return backbone_name

        def architecture_short(architecture_name: str) -> str:
            architecture_name = normalize_architecture(architecture_name)
            if architecture_name == "DeepLabV3":
                return "DLV3"
            if architecture_name == "U-Net":
                return "U-Net"
            return architecture_name

        def model_compact_tag(model_info: dict) -> str:
            return f"{backbone_short(model_info['backbone'])}+{architecture_short(model_info['architecture'])}"

        def fold_sort_key(fold_name: str) -> int:
            match = re.search(r"(\d+)", str(fold_name))
            return int(match.group(1)) if match else 10**9

        def ordinal_name(n: int) -> str:
            mapping = {
                1: "1st",
                2: "2nd",
                3: "3rd",
                4: "4th",
                5: "5th",
                6: "6th",
                7: "7th",
                8: "8th",
                9: "9th",
                10: "10th",
            }
            return mapping.get(n, f"{n}th")

        def holm_adjust(p_values: list[float]) -> list[float]:
            m = len(p_values)
            indexed = sorted(enumerate(p_values), key=lambda x: x[1])

            adjusted_sorted = [0.0] * m
            running_max = 0.0

            for rank, (original_idx, p_value) in enumerate(indexed, start=1):
                adjusted = min(1.0, (m - rank + 1) * p_value)
                running_max = max(running_max, adjusted)
                adjusted_sorted[rank - 1] = running_max

            adjusted_final = [0.0] * m
            for rank, (original_idx, _) in enumerate(indexed, start=1):
                adjusted_final[original_idx] = adjusted_sorted[rank - 1]

            return adjusted_final

        def compute_wilcoxon_statistics(values_a: list[float], values_b: list[float]) -> dict:
            diffs = np.array(values_a, dtype=float) - np.array(values_b, dtype=float)

            mean_delta = float(np.mean(diffs))
            median_delta = float(np.median(diffs))

            nonzero_diffs = diffs[diffs != 0]
            n_nonzero = int(len(nonzero_diffs))

            if n_nonzero == 0:
                return {
                    "n": 0,
                    "mean_delta": mean_delta,
                    "median_delta": median_delta,
                    "w_min": 0.0,
                    "p_value": 1.0,
                    "rrb": 0.0,
                }

            ranks = rankdata(np.abs(nonzero_diffs), method="average")
            w_plus = float(np.sum(ranks[nonzero_diffs > 0]))
            w_minus = float(np.sum(ranks[nonzero_diffs < 0]))
            denom = w_plus + w_minus
            rrb = (w_plus - w_minus) / denom if denom > 0 else 0.0

            wilcoxon_result = wilcoxon(
                nonzero_diffs,
                zero_method="wilcox",
                correction=False,
                alternative="two-sided",
                method="auto",
            )

            return {
                "n": n_nonzero,
                "mean_delta": mean_delta,
                "median_delta": median_delta,
                "w_min": float(wilcoxon_result.statistic),
                "p_value": float(wilcoxon_result.pvalue),
                "rrb": float(rrb),
            }

        backbone_order = {"ResNet-34": 0, "RegNetX-4.0GF": 1}
        architecture_order = {"DeepLabV3": 0, "FPN": 1, "PAN": 2, "U-Net": 3}

        ordered_experiments = []
        for (_, _), execution_data in self.selected_reports_for_output.items():
            backbone = normalize_backbone(execution_data["backbone"])
            architecture = normalize_architecture(execution_data["architecture"])

            best_rows_df = self.__build_best_rows_dataframe(execution_data).copy()
            if "fold" not in best_rows_df.columns:
                raise RuntimeError("Best rows dataframe must contain a 'fold' column.")

            ordered_experiments.append(
                {
                    "backbone": backbone,
                    "architecture": architecture,
                    "best_rows_df": best_rows_df,
                }
            )

        ordered_experiments = sorted(
            ordered_experiments,
            key=lambda item: (
                backbone_order.get(item["backbone"], 999),
                architecture_order.get(item["architecture"], 999),
            ),
        )

        if len(ordered_experiments) < 2:
            raise RuntimeError("At least two experiments are required to compute Wilcoxon tests.")

        common_folds = None
        for item in ordered_experiments:
            folds = set(item["best_rows_df"]["fold"].tolist())
            common_folds = folds if common_folds is None else common_folds.intersection(folds)

        if not common_folds:
            raise RuntimeError("No common folds were found across the selected experiments.")

        common_folds = sorted(common_folds, key=fold_sort_key)

        metric_configs = [
            ("Avg IoU", "avg_iou_val"),
            ("IoU$_{\\mathrm{human}}$", "iou_class_1_val"),
            ("IoU$_{\\mathrm{robot}}$", "iou_class_2_val"),
        ]

        results_by_metric = []

        for metric_label, metric_column in metric_configs:
            metric_models = []

            for item in ordered_experiments:
                df = item["best_rows_df"]
                df = df[df["fold"].isin(common_folds)].copy()
                df["__fold_order__"] = df["fold"].apply(fold_sort_key)
                df = df.sort_values("__fold_order__")

                if len(df) != len(common_folds):
                    raise RuntimeError(
                        f"Experiment {item['backbone']} + {item['architecture']} does not contain all common folds."
                    )

                values = df[metric_column].astype(float).tolist()

                metric_models.append(
                    {
                        "backbone": item["backbone"],
                        "architecture": item["architecture"],
                        "values": values,
                        "mean_metric": float(np.mean(values)),
                        "std_metric": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
                    }
                )

            metric_models_sorted = sorted(
                metric_models,
                key=lambda item: (-item["mean_metric"], item["std_metric"]),
            )

            metric_results = []
            seen_ordered_pairs = set()

            for backbone_name in ["ResNet-34", "RegNetX-4.0GF"]:
                model_u = next(
                    (
                        model for model in metric_models
                        if model["backbone"] == backbone_name and model["architecture"] == "U-Net"
                    ),
                    None,
                )
                model_fpn = next(
                    (
                        model for model in metric_models
                        if model["backbone"] == backbone_name and model["architecture"] == "FPN"
                    ),
                    None,
                )

                if model_u is not None and model_fpn is not None:
                    pair_key = (
                        model_u["backbone"], model_u["architecture"],
                        model_fpn["backbone"], model_fpn["architecture"],
                    )

                    if pair_key not in seen_ordered_pairs:
                        stats = compute_wilcoxon_statistics(model_u["values"], model_fpn["values"])
                        metric_results.append(
                            {
                                "metric": metric_label,
                                "comparison": f"U-Net vs FPN ({backbone_name})",
                                **stats,
                            }
                        )
                        seen_ordered_pairs.add(pair_key)

            best_model = metric_models_sorted[0]
            max_rank_to_compare = min(top_k, len(metric_models_sorted))

            for rank_position in range(2, max_rank_to_compare + 1):
                other_model = metric_models_sorted[rank_position - 1]

                pair_key = (
                    best_model["backbone"], best_model["architecture"],
                    other_model["backbone"], other_model["architecture"],
                )

                if pair_key in seen_ordered_pairs:
                    continue

                stats = compute_wilcoxon_statistics(best_model["values"], other_model["values"])
                comparison_label = (
                    f"Best vs {ordinal_name(rank_position)} best "
                    f"({model_compact_tag(best_model)} vs {model_compact_tag(other_model)})"
                )

                metric_results.append(
                    {
                        "metric": metric_label,
                        "comparison": comparison_label,
                        **stats,
                    }
                )
                seen_ordered_pairs.add(pair_key)

            if metric_results:
                raw_p_values = [row["p_value"] for row in metric_results]
                holm_p_values = holm_adjust(raw_p_values)

                for row, p_holm in zip(metric_results, holm_p_values):
                    row["p_holm"] = float(p_holm)

            results_by_metric.append(metric_results)

        lines = [
            "\\begin{tabular}{l l r r r r r r r}",
            "\\hline",
            "\\textbf{Metric} & \\textbf{Comparison} & \\textbf{$n$} & \\textbf{Mean $\\Delta$} & \\textbf{Median $\\Delta$} & \\textbf{$W_{\\min}$} & \\textbf{$p$} & \\textbf{$p_{\\mathrm{Holm}}$} & \\textbf{$r_{\\mathrm{rb}}$} \\\\",
            "\\hline",
        ]

        for metric_index, metric_rows in enumerate(results_by_metric):
            for row in metric_rows:
                w_min_value = row["w_min"]
                if float(w_min_value).is_integer():
                    w_min_text = str(int(w_min_value))
                else:
                    w_min_text = f"{w_min_value:.6f}"

                lines.append(
                    f"{row['metric']} & "
                    f"{row['comparison']} & "
                    f"{row['n']} & "
                    f"{row['mean_delta']:.6f} & "
                    f"{row['median_delta']:.6f} & "
                    f"{w_min_text} & "
                    f"{row['p_value']:.6f} & "
                    f"{row['p_holm']:.6f} & "
                    f"{row['rrb']:.6f} \\\\"
                )

            if metric_index < len(results_by_metric) - 1:
                lines.append("\\hline")

        lines.extend(
            [
                "\\hline",
                "\\end{tabular}",
            ]
        )

        (self.output_folder / "wilcoxon_tests.txt").write_text(
            "\n".join(lines),
            encoding="utf-8",
        )
