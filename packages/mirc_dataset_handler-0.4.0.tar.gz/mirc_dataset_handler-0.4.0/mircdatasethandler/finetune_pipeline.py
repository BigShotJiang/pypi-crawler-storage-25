from pathlib import Path
from typing import List, Tuple
import re
import torch

from mircdatasethandler.train_utils import finetune

class FinetunePipeline:
    def __init__(self, subset_pruned_root_path: Path, all_dataloaders: List[Tuple[torch.utils.data.DataLoader, torch.utils.data.DataLoader]]):
        self.all_dataloaders = all_dataloaders
        self.models_root_paths = self.__find_pruned_model_dirs(subset_pruned_root_path)
        
    def execute(self):
        for model_root_path in self.models_root_paths:
            fold_id = self.__get_fold_id(model_root_path)
            dataloaders = self.all_dataloaders[fold_id-1]
            models_filepaths = self.__find_all_pth_files(model_root_path)
            
            for model_filepath in models_filepaths:
                finetune(model_filepath, dataloaders, fold_id, epochs=5)
        
    def __find_pruned_model_dirs(self, root: Path) -> List[Path]:
        root = root.resolve()

        if not root.exists():
            raise FileNotFoundError(f"Root path does not exist: {root}")

        if not root.is_dir():
            raise NotADirectoryError(f"Root path is not a directory: {root}")

        return sorted(
            [
                path.resolve()
                for path in root.rglob("pruned-model")
                if path.is_dir()
            ]
        )
    
    def __get_fold_id(self, model_root_path: Path) -> int:
        fold_name = model_root_path.parts[-2]
        return int(re.search(r"\d+", fold_name).group())
    
    def __find_all_pth_files(self, root: Path) -> List[Path]:
        root = root.resolve()

        if not root.exists():
            raise FileNotFoundError(f"Root path does not exist: {root}")

        if not root.is_dir():
            raise NotADirectoryError(f"Root path is not a directory: {root}")

        return sorted(
            [
                path.resolve()
                for path in root.rglob("*.pth")
                if path.is_file()
            ]
        )