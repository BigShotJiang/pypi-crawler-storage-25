import torch
import torch.optim as optim
from tqdm import tqdm
from pathlib import Path
from typing import Tuple

from .checkpoints_utils import save_checkpoint, save_metrics_to_csv
from .eval_utils import evaluation
from .models_utils import get_model, load_pruned_model

def train_pipeline(model_name, backbone_name, dataloaders, checkpoint_dir, epochs, learning_rate):
    
    start_epoch, start_fold, best_loss = 0, 0, 32000000
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    criterion = torch.nn.CrossEntropyLoss()

    for fold in range(start_fold, len(dataloaders)):
        
        best_loss = 32000000
        net = get_model(model_name, backbone_name).to(device)
        optimizer = optim.RMSprop(net.parameters(), lr=learning_rate, weight_decay=1e-8, momentum=0.9)
        
        train_loader, val_loader = dataloaders[fold]
        global_step = 0
        
        for epoch in range(start_epoch, epochs):
            net.train()

            epoch_loss = 0
            with tqdm(total=len(train_loader.dataset), desc=f'{model_name} | Fold {fold+1}/{len(dataloaders)} | Epoch {epoch + 1}/{epochs}', unit='img') as pbar:
                for batch in train_loader:
                    optimizer.zero_grad(set_to_none=True)

                    imgs = batch['image']
                    true_masks = batch['mask']

                    imgs = imgs.to(device=device, dtype=torch.float32)
                    mask_type = torch.long
                    true_masks = true_masks.to(device=device, dtype=mask_type)

                    masks_pred = net(imgs)

                    loss = criterion(masks_pred, true_masks)
                    epoch_loss += loss.item() * imgs.size(0)

                    pbar.set_postfix(**{'loss (batch)': loss.item()})
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
                    optimizer.step()

                    pbar.update(imgs.shape[0])
                    global_step += 1
                    
                val_lss, val_metrics = evaluation(net, val_loader, device, pbar)

            if val_lss < best_loss:
                best_loss = val_lss
                save_checkpoint(net, optimizer, epoch, fold, True, checkpoint_dir, best_val_loss=best_loss)

            save_checkpoint(net, optimizer, epoch, fold, False, checkpoint_dir, best_val_loss=best_loss)
            save_metrics_to_csv(epoch_loss/len(train_loader.dataset), val_lss, val_metrics, checkpoint_dir, fold, epoch)


def finetune(
    model_filepath: Path, 
    dataloaders: Tuple[torch.utils.data.DataLoader, torch.utils.data.DataLoader], 
    fold_id: int, 
    epochs: int, 
    learning_rate:float = 0.0001
) -> None:
    
    current_path = model_filepath.parent / "finetune" / model_filepath.stem
    current_path.mkdir(parents=True, exist_ok = True)
    start_epoch, best_loss = 0, float("inf")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    criterion = torch.nn.CrossEntropyLoss()
    model = load_pruned_model(model_filepath, map_location=device).to(device)
    optimizer = optim.RMSprop(model.parameters(), lr=learning_rate, weight_decay=1e-8, momentum=0.9)
    train_loader, val_loader = dataloaders
    global_step = 0
        
    for epoch in range(start_epoch, epochs):
        model.train()
        epoch_loss = 0
        with tqdm(total=len(train_loader.dataset), desc=f'Fine tune training | Epoch {epoch + 1}/{epochs}', unit='img') as pbar:
            for batch in train_loader:
                optimizer.zero_grad(set_to_none=True)

                imgs = batch['image']
                true_masks = batch['mask']

                imgs = imgs.to(device=device, dtype=torch.float32)
                mask_type = torch.long
                true_masks = true_masks.to(device=device, dtype=mask_type)

                masks_pred = model(imgs)
                loss = criterion(masks_pred, true_masks)
                epoch_loss += loss.item() * imgs.size(0)

                pbar.set_postfix(**{'loss (batch)': loss.item()})
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()

                pbar.update(imgs.shape[0])
                global_step += 1
                    
            val_loss, val_metrics = evaluation(model, val_loader, device, pbar)

        if val_loss < best_loss:
            best_loss = val_loss
            save_checkpoint(model, optimizer, epoch, fold_id-1, True, current_path, best_val_loss=best_loss)

        save_checkpoint(model, optimizer, epoch, fold_id-1, False, str(current_path), best_val_loss=best_loss)
        save_metrics_to_csv(epoch_loss/len(train_loader.dataset), val_loss, val_metrics, str(current_path), fold_id-1, epoch)