import torch, numpy
from tqdm import tqdm
from torch.nn import functional as torch_functional

def evaluation(net, loader, device, pbar, num_classes=3, smooth=1e-6):
    was_training = net.training
    net.eval()

    loss_sum = 0.0
    n_imgs = 0

    metrics = []

    with torch.no_grad():
        val_pbar = tqdm(loader, desc="Validation...", leave=False)

        for batch_idx, batch in enumerate(val_pbar):
            imgs = batch["image"].to(device=device, dtype=torch.float32)
            true_masks = batch["mask"].to(device=device, dtype=torch.long)

            bs = imgs.size(0)
            n_imgs += bs

            logits = net(imgs)
            loss = torch_functional.cross_entropy(logits, true_masks).item()
            loss_sum += loss * bs

            mean_dice, mean_iou, dice_pc, iou_pc = calculate_metrics_batch(
                logits, true_masks, num_classes=num_classes, smooth=smooth
            )
            metrics.append((mean_dice, mean_iou, dice_pc, iou_pc))

            pbar.set_postfix(**{"Evaluating...": f"batch {batch_idx}/{len(loader)}"})

    avg_loss = loss_sum / max(1, n_imgs)

    if was_training:
        net.train()

    return avg_loss, metrics

def calculate_metrics_batch(outputs, targets, num_classes=3, smooth=1e-6):
    pred = outputs.argmax(dim=1)

    dice_pc = []
    iou_pc = []

    for c in range(num_classes):
        gt_c = (targets == c)
        pr_c = (pred == c)

        if gt_c.sum().item() == 0:
            dice_pc.append(float("nan"))
            iou_pc.append(float("nan"))
            continue

        inter = (gt_c & pr_c).float().sum()
        union_dice = gt_c.float().sum() + pr_c.float().sum()
        union_iou  = (gt_c | pr_c).float().sum()

        dice = (2.0 * inter + smooth) / (union_dice + smooth)
        iou  = (inter + smooth) / (union_iou + smooth)

        dice_pc.append(dice.item())
        iou_pc.append(iou.item())

    if all(numpy.isnan(x) for x in dice_pc):
        mean_dice = 0.0
    else:
        mean_dice = float(numpy.nanmean(dice_pc))

    if all(numpy.isnan(x) for x in iou_pc):
        mean_iou = 0.0
    else:
        mean_iou = float(numpy.nanmean(iou_pc))

    return mean_dice, mean_iou, dice_pc, iou_pc