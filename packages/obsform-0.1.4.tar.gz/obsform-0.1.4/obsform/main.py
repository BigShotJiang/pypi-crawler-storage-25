import os
import typer
import difflib
import json
from rich.console import Console
from pathlib import Path
from google import genai
from google.genai import types

app = typer.Typer(help="CLI tool to format, correct and improve Obsidian notes")
console = Console()

CONFIG_FILE = Path.home() / ".obsidian_tutor.json"

SYSTEM_PROMPT = """
You are an expert editor and Obsidian note optimizer. Your task is to process the user's raw notes and return a polished version.
If a file is in txt format convert it to markdown and then process it. 
Strictly adhere to the following rules:
1. Fix any spelling, grammar, and punctuation mistakes.
2. Fact-check the content. If a statement is factually incorrect, (Do not change the original statement) add a note of the correct statement.
3. Format the document cleanly using Markdown (headers, bullet points, bold text).
4. **Formulas:** Convert all mathematical formulas into Obsidian-compatible LaTeX. Use `$` for inline math and `$$` for block math.
5. Preserve any existing Obsidian internal links (e.g., [[Link]]) and tags (e.g., #tag).
6. Output ONLY the final processed Markdown content. Do not include introductory or concluding conversational text.
"""

@app.command()
def setup():
    console.print("[cyan]Set up your Obsidian Tutor[/cyan]")
    console.print("You can get a free API key from: https://aistudio.google.com/app/apikey")
    
    api_key = typer.prompt("Enter your Gemini API Key", hide_input=True)
    config_data = {"GEMINI_API_KEY": api_key}
    
    with open(CONFIG_FILE, "w") as f:
        json.dump(config_data, f)
        
    console.print(f"[green]Success! API Key saved to {CONFIG_FILE}[/green]")

def setupLLM(): 
    """Returns an authenticated Client using the new google-genai SDK."""
    api_key = os.environ.get("GEMINI_API_KEY")

    if not api_key and CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
                api_key = config.get("GEMINI_API_KEY")
        except json.JSONDecodeError:
            console.print("[red]Error reading config file. Try running setup again.[/red]")
            raise typer.Exit(code=1)

    if not api_key:
        console.print("[red]Error: API key not found.[/red]")
        console.print("Please run [bold cyan]obsform setup[/bold cyan] to configure your tool.")
        raise typer.Exit(code=1)
    
    # New SDK Initialization
    return genai.Client(api_key=api_key)

def show_diff(original: str, processed: str, filename: str):
    diff = list(difflib.unified_diff(
        original.splitlines(keepends=True),
        processed.splitlines(keepends=True),
        fromfile=f"Original: {filename}",
        tofile=f"Processed: {filename}",
        n=3
    )) 
    
    if not diff: 
        console.print("[dim]No changes were made by LLM.[/dim]")
        return False
    
    console.print("\n[bold cyan]--- Diff View ---[/bold cyan]")
    for line in diff: 
        if line.startswith("+") and not line.startswith("+++"):
            console.print(f"[green]{line.strip()}[/green]")
        elif line.startswith("-") and not line.startswith("---"): 
            console.print(f"[red]{line.strip()}[/red]")
        elif line.startswith("@@"):
            console.print(f"[cyan]{line.strip()}[/cyan]")
        else:
            console.print(line.strip())
    console.print("[bold cyan]-----------------[/bold cyan]\n")
    return True

def processSingleFile(file_path: Path, client: genai.Client, replace: bool, skip_diff: bool = False):
    console.print(f"[cyan]Reading '{file_path.name}'...[/cyan]")
    with open(file_path, "r", encoding="utf-8") as f: 
        content = f.read()

    try:
        console.print("[yellow]Processing with LLM...[/yellow]") 
        
        # New SDK Generation Call
        response = client.models.generate_content(
            model='gemini-1.5-flash',
            contents=content,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
            )
        )
        proText = response.text

        if replace: 
            outputPath = file_path.with_suffix('.md')
        else: 
            outputPath = file_path.with_name(f'{file_path.stem}_processed.md')

        if not skip_diff:
            has_changes = show_diff(content, proText, file_path.name)
            if has_changes:
                if not typer.confirm("Do you want to save these changes?"):
                    console.print(f"[yellow]Skipped saving {file_path.name}.[/yellow]")
                    return
       
        with open(outputPath, "w", encoding="utf-8") as f: 
            f.write(proText)

        if replace and file_path.suffix == '.txt' and outputPath != file_path: 
            file_path.unlink()

        console.print(f"[green]Saved successfully to: {outputPath.name}[/green]")

    except Exception as e: 
        console.print(f"[red]An error occurred during LLM processing: {e}[/red]")


@app.command()
def process(
    file_path: Path = typer.Argument(..., help="Path to file or folder"),
    replace: bool = typer.Option(False, "--replace", "-r", help="Overwrite the file instead of creating a new one"),
    auto_approve: bool = typer.Option(False, "--auto-approve", "-y", help="Skip the diff view and automatically save changes")
):
    """
    Reads a note, uses an LLM to fix spelling, format content, and format formulas, then saves it as an Obsidian .md file.
    """
    if not file_path.exists(): 
        console.print(f"[red]Error: Path '{file_path}' does not exist[/red]")
        raise typer.Exit(code=1)

    client = setupLLM()
    
    if file_path.is_dir(): 
        files_to_process = list(file_path.rglob("*.md")) + list(file_path.rglob("*.txt"))
    
        if not files_to_process:
            console.print("[yellow]No .md or .txt files found in the directory.[/yellow]")
            raise typer.Exit(0)

        typer.confirm(f"Found {len(files_to_process)} files. Are you sure you want to process all of them?", abort=True)
        
        for file in files_to_process:
            processSingleFile(file, client, replace, skip_diff=auto_approve)

    elif file_path.is_file(): 
        if file_path.suffix not in ['.md','.txt']:
            console.print("[red]Only folders, .md and .txt files are supported[/red]")
            raise typer.Exit(code=1)
        processSingleFile(file_path, client, replace, skip_diff=auto_approve)

        
if __name__ == "__main__": 
    app()