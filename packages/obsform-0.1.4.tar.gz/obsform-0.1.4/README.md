# obsform 

**obsform** (Obsidian Formatter) is an LLM-powered CLI tool designed to automatically clean, correct, and perfectly format your Obsidian notes. 

Powered by Google's Gemini 1.5 Flash model, `obsform` acts as your personal editor. It fixes typos, corrects grammar, converts raw text into clean Markdown, and ensures all your mathematical formulas are perfectly rendered in Obsidian's specific LaTeX format.

## Features

* **Smart Formatting:** Fixes spelling, grammar, and punctuation without losing your personal voice.
* **Obsidian Native:** Preserves your `[[Internal Links]]` and `#tags`.
* **Math Formatter:** Automatically identifies mathematical equations and wraps them in Obsidian-compatible LaTeX (`$` for inline, `$$` for blocks).
* **Batch Processing:** Pass a whole folder of notes, and it will process all `.md` and `.txt` files inside.
* **Interactive Diff View:** See exactly what the LLM changed with a color-coded terminal diff before saving.
* **Format Conversion:** Seamlessly converts plain `.txt` files into properly formatted `.md` Obsidian notes.
* **Secure & Local Setup:** Stores your API key securely in a local config file so you only have to enter it once.

## Installation

Install `obsform` globally using pip:

```bash
pip install obsform
```

## Setup

Before using the tool, you need to provide a free Google Gemini API key. You can get one from [Google AI Studio](https://aistudio.google.com/app/apikey).

Run the setup command to save your key securely:

```bash
obsform setup
```

## Usage

### Processing a Single File

Process a note and save the output as a new file (e.g., `note_processed.md`):

```bash
obsform process my_note.md
```

Overwrite the original file with the corrected version:

```bash
obsform process my_note.md --replace
```

### Batch Processing

Pass a directory to process all `.md` and `.txt` files inside it:

```bash
obsform process path/to/my/vault/folder/
```

### Bypassing the Diff View

If you are batch-processing dozens of files and trust the LLM, use the `--auto-approve` (or `-y`) flag to skip the confirmation prompt:

```bash
obsform process path/to/folder/ --replace -y
```

## Requirements
* Python 3.9+
* A valid Google Gemini API Key

## License
MIT License