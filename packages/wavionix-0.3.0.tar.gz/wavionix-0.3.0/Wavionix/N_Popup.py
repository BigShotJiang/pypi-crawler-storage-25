from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Popup:

    _Registered = False
    _Instance = []

    def __init__(self, Main=False, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Popup'
            try:
                self._Config = [
                    'Background',
                    'Foreground',
                    'Border_Color',
                    'Border_Size',
                    'Border_Radius',
                    'Width',
                    'Height',
                    'Left',
                    'Top',
                    'Animate_Left',
                    'Animate_Top',
                    'Animate_Width',
                    'Animate_Height',
                    'Animate_Time',
                    'Animate_Ease',
                    'Display',
                    'Draggable',
                    'Padding',
                    'Gap',
                    'Z_Index',
                    'Shadow_X',
                    'Shadow_Y',
                    'Shadow_Blur',
                    'Shadow_Spread',
                    'Shadow_Color',
                    'Handle_Foreground',
                    'Handle_Size',
                    'Handle_Mark',
                    'Handle_Left',
                    'Handle_Top',
                    'Handle_Position',
                    'Handle_Display',
                    'Modal',
                    'Modal_Blur',
                    'Modal_Background',
                    'Modal_Close',
                    'Scroll',
                    'Scroll_X',
                    'Scroll_Y',
                ]
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Overlay = None
                self._Frame = None
                self._Handle = None
                self._Handle_Label = None
                self._Body = None
                self._Background = '#ffffff'
                self._Foreground = '#000000'
                self._Border_Color = '#000000'
                self._Border_Size = 1
                self._Border_Radius = 12
                self._Width = 420
                self._Height = 220
                self._Left = 240
                self._Top = 160
                self._Animate_Left = 0
                self._Animate_Top = 0
                self._Animate_Width = 0
                self._Animate_Height = 0
                self._Animate_Time = 1.0
                self._Animate_Ease = 'cubic-bezier(0.22, 1, 0.36, 1)'
                self._Animating = False
                self._Animate_Box = None
                self._Animate_Transition = False
                self._Anim_Start_Timer = None
                self._Anim_Finish_Timer = None
                self._Display = False
                self._Draggable = True
                self._Padding = 12
                self._Gap = 10
                self._Z_Index = 3000
                self._Shadow_X = 0
                self._Shadow_Y = 12
                self._Shadow_Blur = 30
                self._Shadow_Spread = 0
                self._Shadow_Color = 'rgba(0,0,0,0.18)'
                self._Handle_Foreground = '#666666'
                self._Handle_Size = 18
                self._Handle_Mark = '✥'
                self._Handle_Left = 8
                self._Handle_Top = 6
                self._Handle_Position = 'NW'
                self._Handle_Display = True
                self._Modal = False
                self._Modal_Blur = 6
                self._Modal_Background = 'rgba(0,0,0,0.25)'
                self._Modal_Close = False
                self._Dragging = False
                self._Drag_Start_X = 0.0
                self._Drag_Start_Y = 0.0
                self._Start_Left = 0.0
                self._Start_Top = 0.0
                self._Scroll = True
                self._Scroll_X = None
                self._Scroll_Y = None
                self._Start_Left_CSS = '0px'
                self._Start_Top_CSS = '0px'
                self._On_Show = False
                self._On_Hide = False
                self._On_Close = False
                self._On_Animate = False
                if kwargs:
                    self.Config(**kwargs)
                if self not in Popup._Instance:
                    Popup._Instance.append(self)
                self._Register_Global()
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
                raise
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return f'Nucleon_Wavionix_Popup[{self._Left},{self._Top},{self._Width},{self._Height}]'

    def __repr__(self):
        return f'Nucleon_Wavionix_Popup[{self._Left},{self._Top},{self._Width},{self._Height}]'

    @classmethod
    def _Register_Global(cls):
        if cls._Registered:
            return

        def _Mouse_Move(Event):
            for Each in list(cls._Instance):
                try:
                    Each._Update_Drag(Event)
                except Exception:
                    pass

        def _Mouse_Up(Event=None):
            for Each in list(cls._Instance):
                try:
                    Each._Stop_Drag(Event)
                except Exception:
                    pass

        ui.on('mousemove', _Mouse_Move)
        ui.on('mouseup', _Mouse_Up)
        cls._Registered = True

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Get_Event_Value(self, Event, Name_List, Default_Value=0.0):
        for Name in Name_List:
            Value = getattr(Event, Name, None)
            if Value is not None:
                return Value

        Event_Args = getattr(Event, 'args', None)
        if isinstance(Event_Args, dict):
            for Name in Name_List:
                if Name in Event_Args and Event_Args[Name] is not None:
                    return Event_Args[Name]

        return Default_Value

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Scroll_Mode(self, Value, Default='auto'):
        try:
            if Value is None:
                return Default
            if Value is True:
                return 'auto'
            if Value is False:
                return 'hidden'
            return str(Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Scroll_Mode -> {E}')
            return Default
            
    def _Overlay_Style(self):
        try:
            Display = self._Modal and (self._Display or self._Animating)
            Z_Index = int(self._Z_Index) - 1
            if Z_Index < 0:
                Z_Index = 0
            return '; '.join([
                'position: fixed',
                'left: 0',
                'top: 0',
                'width: 100vw',
                'height: 100vh',
                f'display: {"block" if Display else "none"}',
                f'z-index: {Z_Index}',
                f'background: {self._Modal_Background}',
                f'backdrop-filter: blur({self._Unit(self._Modal_Blur) or "6px"})',
                f'-webkit-backdrop-filter: blur({self._Unit(self._Modal_Blur) or "6px"})',
                'pointer-events: auto',
                'touch-action: none',
                'box-sizing: border-box',
                'margin: 0',
                'padding: 0',
            ])
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Overlay_Style -> {E}')
            return 'display: none'
            
    def _Frame_Style(self):
        Box = self._Animate_Current_Box()
        Transition = 'left 0.2s ease, top 0.2s ease, width 0.2s ease, height 0.2s ease, opacity 0.2s ease, background 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease'
        if self._Animate_Transition:
            Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}'
        return '; '.join([
            'position: fixed',
            f'left: {self._Unit(Box["Left"]) or "0px"}',
            f'top: {self._Unit(Box["Top"]) or "0px"}',
            f'width: {self._Unit(Box["Width"]) or "420px"}',
            f'height: {self._Unit(Box["Height"]) or "220px"}',
            f'display: {"block" if self._Display or self._Animating else "none"}',
            f'z-index: {self._Z_Index}',
            f'background: {self._Background}',
            f'color: {self._Foreground}',
            f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Border_Color}',
            f'border-radius: {self._Unit(self._Border_Radius) or "12px"}',
            f'box-shadow: {self._Build_Shadow()}',
            f'transition: {Transition}',
            'overflow: hidden',
            'box-sizing: border-box',
            'padding: 0',
            'margin: 0',
        ])

    def _Handle_Position_Value(self):
        try:
            Value = str(self._Handle_Position).strip().upper()
            Map = {
                'TOP': 'N',
                'BOTTOM': 'S',
                'LEFT': 'W',
                'RIGHT': 'E',
                'CENTER': 'C',
                'CENTRE': 'C',
                'NORTH': 'N',
                'SOUTH': 'S',
                'WEST': 'W',
                'EAST': 'E',
                'NORTH_WEST': 'NW',
                'NORTH_EAST': 'NE',
                'SOUTH_WEST': 'SW',
                'SOUTH_EAST': 'SE',
                'TOP_LEFT': 'NW',
                'TOP_RIGHT': 'NE',
                'BOTTOM_LEFT': 'SW',
                'BOTTOM_RIGHT': 'SE',
            }
            if Value in Map:
                Value = Map[Value]
            if Value not in ['NW', 'N', 'NE', 'W', 'C', 'E', 'SW', 'S', 'SE']:
                Value = 'NW'
            return Value
        except Exception:
            return 'NW'
            
    def _Handle_Safe_Offset(self, Value):
        try:
            Radius_Number, Radius_Unit = self._CSS_Number_Unit(self._Border_Radius)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Radius_Number is not None and Value_Number is not None and Radius_Unit == Value_Unit:
                Safe = max(float(Value_Number), float(Radius_Number) * 0.35)
                return self._CSS_Format(Safe, Radius_Unit)
            return self._CSS_Add(Value, self._CSS_Scale(self._Border_Radius, 0.35))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Safe_Offset -> {E}')
            return Value

    def _Handle_Style(self):
        Position = self._Handle_Position_Value()
        Left = self._Unit(self._Handle_Left) or '8px'
        Top = self._Unit(self._Handle_Top) or '6px'
        Safe_Left = self._Unit(self._Handle_Safe_Offset(self._Handle_Left)) or Left
        Safe_Top = self._Unit(self._Handle_Safe_Offset(self._Handle_Top)) or Top
        Size = self._Unit(self._Handle_Size) or '18px'
        Style = [
            'position: absolute',
            f'display: {"flex" if self._Handle_Display else "none"}',
            'align-items: center',
            'justify-content: center',
            'background: transparent',
            'border: none',
            'padding: 0',
            'margin: 0',
            f'width: {Size}',
            f'height: {Size}',
            f'min-width: {Size}',
            f'min-height: {Size}',
            'line-height: 1',
            'user-select: none',
            'pointer-events: auto',
            'touch-action: none',
            f'cursor: {"move" if self._Draggable and self._Handle_Display else "default"}',
            'z-index: 50',
        ]
        if Position == 'NW':
            Style.append(f'left: {Safe_Left}')
            Style.append(f'top: {Safe_Top}')
        elif Position == 'N':
            Style.append('left: 50%')
            Style.append(f'top: {Top}')
            Style.append('transform: translateX(-50%)')
        elif Position == 'NE':
            Style.append(f'right: {Safe_Left}')
            Style.append(f'top: {Safe_Top}')
        elif Position == 'W':
            Style.append(f'left: {Left}')
            Style.append('top: 50%')
            Style.append('transform: translateY(-50%)')
        elif Position == 'C':
            Style.append('left: 50%')
            Style.append('top: 50%')
            Style.append('transform: translate(-50%, -50%)')
        elif Position == 'E':
            Style.append(f'right: {Left}')
            Style.append('top: 50%')
            Style.append('transform: translateY(-50%)')
        elif Position == 'SW':
            Style.append(f'left: {Safe_Left}')
            Style.append(f'bottom: {Safe_Top}')
        elif Position == 'S':
            Style.append('left: 50%')
            Style.append(f'bottom: {Top}')
            Style.append('transform: translateX(-50%)')
        elif Position == 'SE':
            Style.append(f'right: {Safe_Left}')
            Style.append(f'bottom: {Safe_Top}')
        return '; '.join(Style)

    def _Body_Style(self):
        Pad = self._Unit(self._Padding) or '12px'
        Handle_Size = self._Unit(self._Handle_Size) or '18px'
        Position = self._Handle_Position_Value()
        Overflow = self._Scroll_Mode(self._Scroll, 'auto')
        Top_Pad = Pad
        Right_Pad = Pad
        Bottom_Pad = Pad
        Left_Pad = Pad
        if self._Handle_Display and Position in ['NW', 'N', 'NE']:
            Top_Pad = f'calc({Pad} + {Handle_Size} + 2px)'
        if self._Handle_Display and Position in ['SW', 'S', 'SE']:
            Bottom_Pad = f'calc({Pad} + {Handle_Size} + 2px)'
        if self._Handle_Display and Position == 'W':
            Left_Pad = f'calc({Pad} + {Handle_Size} + 2px)'
        if self._Handle_Display and Position == 'E':
            Right_Pad = f'calc({Pad} + {Handle_Size} + 2px)'
        Style = [
            'width: 100%',
            'height: 100%',
            f'overflow: {Overflow}',
            'box-sizing: border-box',
            f'padding-top: {Top_Pad}',
            f'padding-right: {Right_Pad}',
            f'padding-bottom: {Bottom_Pad}',
            f'padding-left: {Left_Pad}',
            f'background: {self._Background}',
            f'color: {self._Foreground}',
        ]
        if self._Scroll_X is not None:
            Style.append(f'overflow-x: {self._Scroll_Mode(self._Scroll_X, Overflow)}')
        if self._Scroll_Y is not None:
            Style.append(f'overflow-y: {self._Scroll_Mode(self._Scroll_Y, Overflow)}')
        return '; '.join(Style)

    def _Apply(self):
        try:
            if self._Frame is None:
                return
            if self._Overlay is not None:
                if hasattr(self._Overlay, '_style'):
                    self._Overlay._style.clear()
                self._Overlay.style(self._Overlay_Style())
            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            self._Frame.style(self._Frame_Style())
            if self._Handle is not None:
                if hasattr(self._Handle, '_style'):
                    self._Handle._style.clear()
                self._Handle.style(self._Handle_Style())
            if self._Handle_Label is not None:
                if hasattr(self._Handle_Label, '_style'):
                    self._Handle_Label._style.clear()
                self._Handle_Label.set_text(self._Handle_Mark)
                self._Handle_Label.style(
                    f'color: {self._Handle_Foreground}; '
                    f'font-size: {self._Unit(self._Handle_Size) or "18px"}; '
                    'font-weight: 700; line-height: 1; margin: 0; padding: 0;'
                )
            if self._Body is not None:
                if hasattr(self._Body, '_style'):
                    self._Body._style.clear()
                self._Body.style(self._Body_Style())
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')
            raise

    def _Css_Unit(self, Value, Default='0px'):
        try:
            Unit = self._Unit(Value)
            if Unit is None:
                return Default
            return Unit
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Css_Unit -> {E}')
            return Default

    def _Css_Calc(self, Base, Delta):
        try:
            Delta = round(float(Delta), 3)
            if Delta == 0:
                return Base
            return f'calc({Base} + {Delta}px)'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Css_Calc -> {E}')
            return Base

    def _Start_Drag(self, Event):
        try:
            if not self._Display:
                return
            if not self._Draggable:
                return
            if not self._Handle_Display:
                return
            self._Dragging = True
            self._Drag_Start_X = float(self._Get_Event_Value(Event, ['client_x', 'clientX', 'x'], 0.0))
            self._Drag_Start_Y = float(self._Get_Event_Value(Event, ['client_y', 'clientY', 'y'], 0.0))
            self._Start_Left_CSS = self._Css_Unit(self._Left, '0px')
            self._Start_Top_CSS = self._Css_Unit(self._Top, '0px')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Start_Drag -> {E}')

    def _Update_Drag(self, Event):
        try:
            if not self._Dragging:
                return
            Current_X = float(self._Get_Event_Value(Event, ['client_x', 'clientX', 'x'], self._Drag_Start_X))
            Current_Y = float(self._Get_Event_Value(Event, ['client_y', 'clientY', 'y'], self._Drag_Start_Y))
            Delta_X = Current_X - self._Drag_Start_X
            Delta_Y = Current_Y - self._Drag_Start_Y
            self._Left = self._Css_Calc(self._Start_Left_CSS, Delta_X)
            self._Top = self._Css_Calc(self._Start_Top_CSS, Delta_Y)
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Update_Drag -> {E}')

    def _Stop_Drag(self, Event=None):
        try:
            self._Dragging = False
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Stop_Drag -> {E}')

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}
            
    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception:
            return '1s'
            
    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception:
            return 1000
            
    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False
            
    def _Animate_Target_Box(self):
        try:
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}
            
    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}
            
    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')
            
    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')
            
    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def _Modal_Click(self, Event=None):
        try:
            if not self._Modal:
                return
            if not self._Modal_Close:
                return
            self.Close()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Modal_Click -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True

            if self._Initialized and Run:
                self._Apply()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')
            raise

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')
            raise

    def Create(self):
        try:
            if self._Widget is None:
                self._Widget = ui.element('div')
                self._Widget.style('display: contents')
                with self._Widget:
                    self._Overlay = ui.element('div')
                    self._Frame = ui.card()
                    self._Frame.style('padding: 0; margin: 0;')
                    with self._Frame:
                        self._Handle = ui.row().classes('items-center justify-center')
                        with self._Handle:
                            self._Handle_Label = ui.label(self._Handle_Mark)
                        self._Body = ui.column().classes('w-full')
                self._Handle.on('mousedown', self._Start_Drag)
                self._Handle_Label.on('mousedown', self._Start_Drag)
                if self._Overlay is not None:
                    self._Overlay.on('mousedown', self._Modal_Click)
                ui.on('mousemove', self._Update_Drag)
                ui.on('mouseup', self._Stop_Drag)
                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)
                self._Initialized = True
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')
            raise

    def Delete(self):
        try:
            self.Animate_Cancel()
            if self in Popup._Instance:
                Popup._Instance.remove(self)
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
            self._Widget = None
            self._Overlay = None
            self._Frame = None
            self._Handle = None
            self._Handle_Label = None
            self._Body = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')
            raise

    def Show(self):
        try:
            self.Animate_Cancel()
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')
            raise

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Dragging = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')
            raise

    def Toggle(self):
        try:
            if self._Display:
                self.Hide()
            else:
                self.Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Toggle -> {E}')
            raise

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Frame is None:
                self.Create()
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Dragging = False
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()
            
    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Frame is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Close(self):
        try:
            self.Animate_Cancel()
            if self._On_Close:
                self._On_Close()
            self.Delete()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Close -> {E}')
            raise

    def Scroll(self, Value=None, X=None, Y=None):
        try:
            if Value is not None:
                self._Scroll = Value
            if X is not None:
                self._Scroll_X = X
            if Y is not None:
                self._Scroll_Y = Y

            self._Apply()
            return [self._Scroll, self._Scroll_X, self._Scroll_Y]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Scroll -> {E}')

    def After(self, Delay, Function):
        try:
            ui.timer(float(Delay) / 1000.0, Function, once=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> After -> {E}')
            raise

    def Widget(self):
        try:
            return self._Body
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')
            raise

    def Body(self):
        try:
            return self._Body
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Body -> {E}')
            raise

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Close' in Input:
                self._On_Close = Input['On_Close']
                del Input['On_Close']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
                del Input['On_Animate']
            if self._Frame is not None and len(Input) > 0:
                Event_Bind(self._Frame, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')
            raise

    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return Number
            return f'{Number}px'
        except Exception:
            return '0px'

    def _CSS_Value(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return 0
            if isinstance(Value, (int, float)):
                return Value
            Text = str(Value).strip()
            if Text.endswith('%') or Text.endswith('px') or Text.startswith('calc('):
                return Text
            return float(Text)
        except Exception:
            return Value

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def _CSS_Ratio(self, Value, Base):
        try:
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            if Value_Number is None or Base_Number is None or Base_Number == 0:
                return 0
            if Value_Unit != Base_Unit:
                return 0
            return round((Value_Number / Base_Number) * 100, 3)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Ratio -> {E}')
            return 0
			
    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._CSS_Add(self._Left, self._CSS_Scale(Width, 0.5)), self._CSS_Add(self._Top, self._CSS_Scale(Height, 0.5))]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Value(Left)
            if Top is not None:
                self._Top = self._CSS_Value(Top)
            if Right is not None:
                self._Right = self._CSS_Value(Right)
            if Bottom is not None:
                self._Bottom = self._CSS_Value(Bottom)
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = self._CSS_Value(Width)
            if Height is not False:
                self._Height = self._CSS_Value(Height)
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Add(self._Width, Value)
                self._Height = self._CSS_Add(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Subtract(self._Width, Value)
                self._Height = self._CSS_Subtract(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')
            