from copy import deepcopy
from html import escape
from math import cos, pi, sin
from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind

class Chart:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is None:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')
            return
        self._Type = 'Chart'
        try:
            self._Main = Main
            self._Config = {
                'Name': False,
                'Background': '#ffffff',
                'Foreground': '#000000',
                'Border_Color': '#000000',
                'Border_Size': 0,
                'Border_Radius': 0,
                'Display': True,
                'Left': None,
                'Top': None,
                'Right': None,
                'Bottom': None,
                'Width': 900,
                'Height': 500,
                'Canvas_Width': 900,
                'Canvas_Height': 500,
                'Animate_Left': 0,
                'Animate_Top': 0,
                'Animate_Width': 0,
                'Animate_Height': 0,
                'Animate_Time': 1.0,
                'Animate_Ease': 'cubic-bezier(0.22, 1, 0.36, 1)',
                'Chart_Type': 'Bar',
                'Direction': 'Bottom_To_Top',
                'Title': '',
                'Labels': [],
                'Series': [],
                'Pie': [],
                'Axis': True,
                'Axis_X': True,
                'Axis_Y': True,
                'Axis_Text': True,
                'Value_Ticks': False,
                'Y_Ticks': False,
                'Tick_Count': 5,
                'Grid': True,
                'Legend': True,
                'Tooltip': True,
                'Text': False,
                'Text_Size': 12,
                'Title_Size': 18,
                'Legend_Size': 12,
                'Axis_Size': 11,
                'Font_Family': 'Helvetica',
                'Bar_Gap': 0.18,
                'Group_Gap': 0.18,
                'Line_Width': 3,
                'Point_Size': 5,
                'Pie_Donut': 0,
                'Pie_Start_Angle': -90,
                'Margin_Left': 70,
                'Margin_Right': 30,
                'Margin_Top': 55,
                'Margin_Bottom': 60,
                'Grid_Color': '#e5e7eb',
                'Axis_Color': '#111827',
                'Text_Color': '#111827',
                'Tooltip_Delay': 0.4,
                'Palette': ['#2563eb', '#16a34a', '#dc2626', '#ca8a04', '#9333ea', '#0891b2', '#be185d', '#0f172a'],
                'Padding': 0,
                'Margin': 0,
                'Mode': 'Flow',
                'Classes': '',
                'Style': '',
                'Z_Index': None,
                'Shadow_X': 0,
                'Shadow_Y': 0,
                'Shadow_Blur': 0,
                'Shadow_Spread': 0,
                'Shadow_Color': 'transparent',
                'Aspect_Ratio': True,
            }
            for Each, Value in self._Config.items():
                setattr(self, '_' + Each, deepcopy(Value))
            self._Initialized = False
            self._Widget = None
            self._Body = None
            self._Svg = None
            self._Name = False
            self._Last_Name = False
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._On_Show = False
            self._On_Hide = False
            self._On_Animate = False
            if kwargs:
                self.Config(**kwargs)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Init -> {E}')

    def __str__(self):
        return 'Nucleon_Wavionix_Chart[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Chart[]'

    def _Hive_Color(self, Value):
        Hive = {
            'Hive_Yellow': '#F4C430',
            'Hive_Gold': '#D4A017',
            'Hive_Honey': '#FFBF00',
            'Hive_Amber': '#FFB000',
            'Hive_Orange': '#F28C28',
            'Hive_Brown': '#6B4F1D',
            'Hive_Dark': '#1F1B16',
            'Hive_Light': '#FFF8E1',
            'Hive_Cream': '#FFF3BF',
            'Hive_White': '#FFFFFF',
            'Hive_Black': '#000000',
        }
        if isinstance(Value, str) and Value in Hive:
            return Hive[Value]
        return Value

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Number(self, Value):
        try:
            if Value in [None, False, '']:
                return 0.0
            if isinstance(Value, str) and Value.endswith('px'):
                return float(Value[:-2])
            return float(Value)
        except Exception:
            return 0.0

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Get_Background(self):
        if self._Background in [False, None, '']:
            if hasattr(self._Main, '_Background'):
                return self._Hive_Color(self._Main._Background)
            return 'transparent'
        return self._Hive_Color(self._Background)

    def _Get_Foreground(self):
        return self._Hive_Color(self._Foreground)

    def _Get_Border_Color(self):
        return self._Hive_Color(self._Border_Color)

    def _Get_Shadow_Color(self):
        return self._Hive_Color(self._Shadow_Color)

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Get_Shadow_Color() or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Build_Frame_Style(self):
        try:
            Box = self._Animate_Current_Box()
            Transition = 'none'
            if self._Animate_Transition:
                Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, right {self._Animate_Time_CSS()} {self._Animate_Ease}, bottom {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}'
            Style = []
            Style.append('box-sizing:border-box')
            Style.append(f'display:{"block" if self._Display or self._Animating else "none"}')
            Style.append('overflow:hidden')
            Style.append('position:relative')
            Style.append(f'background:{self._Get_Background()}')
            Style.append(f'color:{self._Get_Foreground()}')
            Style.append(f'border:{self._Unit(self._Border_Size) or "0px"} solid {self._Get_Border_Color()}')
            Style.append(f'border-radius:{self._Unit(self._Border_Radius) or "0px"}')
            Style.append(f'box-shadow:{self._Build_Shadow()}')
            Style.append(f'padding:{self._Unit(self._Padding) or "0px"}')
            Style.append(f'margin:{self._Unit(self._Margin) or "0px"}')
            Style.append(f'transition:{Transition}')
            if self._Mode == 'Place':
                Style.append('position:absolute')
                if Box['Left'] is not None:
                    Style.append(f'left:{self._Unit(Box["Left"])}')
                if Box['Top'] is not None:
                    Style.append(f'top:{self._Unit(Box["Top"])}')
                if self._Right is not None:
                    Style.append(f'right:{self._Unit(self._Right)}')
                if self._Bottom is not None:
                    Style.append(f'bottom:{self._Unit(self._Bottom)}')
            if Box['Width'] is not None:
                Style.append(f'width:{self._Unit(Box["Width"])}')
            if Box['Height'] is not None:
                Style.append(f'height:{self._Unit(Box["Height"])}')
            if self._Z_Index is not None:
                Style.append(f'z-index:{self._Z_Index}')
            if self._Style:
                Style.append(str(self._Style))
            return '; '.join(Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Frame_Style -> {E}')
            return ''

    def _Build_Body_Style(self):
        try:
            Style = []
            Style.append('width:100%')
            Style.append('height:100%')
            Style.append('overflow:hidden')
            Style.append('box-sizing:border-box')
            Style.append('position:relative')
            Style.append('outline:none')
            Style.append('display:flex')
            Style.append('align-items:center')
            Style.append('justify-content:center')
            return '; '.join(Style)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Build_Body_Style -> {E}')
            return 'width:100%; height:100%; overflow:hidden; display:flex; align-items:center; justify-content:center;'

    def _Chart_Type_Value(self, Value=None):
        try:
            Text = str(self._Chart_Type if Value is None else Value).strip().lower().replace('-', '_').replace(' ', '_')
            if Text in ['line', 'lines']:
                return 'Line'
            if Text in ['pie', 'donut', 'doughnut']:
                return 'Pie'
            return 'Bar'
        except Exception:
            return 'Bar'

    def _Direction_Value(self, Value=None):
        try:
            Text = str(self._Direction if Value is None else Value).strip().lower().replace('-', '_').replace(' ', '_')
            Map = {'left_to_right': 'Left_To_Right', 'right_to_left': 'Right_To_Left', 'top_to_bottom': 'Top_To_Bottom', 'bottom_to_top': 'Bottom_To_Top', 'horizontal': 'Left_To_Right', 'vertical': 'Bottom_To_Top'}
            return Map.get(Text, 'Bottom_To_Top')
        except Exception:
            return 'Bottom_To_Top'

    def _Palette_Color(self, Index):
        try:
            Palette = self._Palette if isinstance(self._Palette, (list, tuple)) and len(self._Palette) > 0 else self._Config['Palette']
            return self._Hive_Color(Palette[int(Index) % len(Palette)])
        except Exception:
            return '#2563eb'

    def _Normalize_Labels(self, Labels=None):
        try:
            Value = self._Labels if Labels is None else Labels
            if Value in [None, False]:
                return []
            return [str(Each) for Each in list(Value)]
        except Exception:
            return []

    def _Normalize_Series(self, Series=None):
        try:
            Value = self._Series if Series is None else Series
            Result = []
            if Value in [None, False, '']:
                return Result
            if isinstance(Value, dict):
                for Index, Key in enumerate(Value):
                    Result.append({'Name': str(Key), 'Values': self._Normalize_Values(Value[Key]), 'Color': self._Palette_Color(Index)})
                return Result
            if isinstance(Value, (list, tuple)):
                if len(Value) == 0:
                    return Result
                if all(isinstance(Each, (int, float)) for Each in Value):
                    return [{'Name': 'Value', 'Values': self._Normalize_Values(Value), 'Color': self._Palette_Color(0)}]
                for Index, Item in enumerate(Value):
                    if isinstance(Item, dict):
                        Name = Item.get('Name', Item.get('name', f'Series {Index + 1}'))
                        Values = Item.get('Values', Item.get('values', []))
                        Color = Item.get('Color', Item.get('color', self._Palette_Color(Index)))
                        Result.append({'Name': str(Name), 'Values': self._Normalize_Values(Values), 'Color': self._Hive_Color(Color)})
                    elif isinstance(Item, (list, tuple)):
                        Result.append({'Name': f'Series {Index + 1}', 'Values': self._Normalize_Values(Item), 'Color': self._Palette_Color(Index)})
            return Result
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Normalize_Series -> {E}')
            return []

    def _Normalize_Values(self, Values):
        try:
            Result = []
            if Values in [None, False, '']:
                return Result
            for Each in list(Values):
                try:
                    Result.append(float(Each))
                except Exception:
                    Result.append(0.0)
            return Result
        except Exception:
            return []

    def _Normalize_Pie(self, Pie=None):
        try:
            Value = self._Pie if Pie is None else Pie
            Result = []
            if Value in [None, False, '']:
                Series = self._Normalize_Series()
                Labels = self._Normalize_Labels()
                if len(Series) > 0:
                    for Index, Number in enumerate(Series[0]['Values']):
                        Label = Labels[Index] if Index < len(Labels) else f'Item {Index + 1}'
                        Result.append({'Name': Label, 'Value': float(Number), 'Color': self._Palette_Color(Index)})
                return Result
            if isinstance(Value, dict):
                for Index, Key in enumerate(Value):
                    Result.append({'Name': str(Key), 'Value': float(Value[Key]), 'Color': self._Palette_Color(Index)})
                return Result
            if isinstance(Value, (list, tuple)):
                for Index, Item in enumerate(Value):
                    if isinstance(Item, dict):
                        Name = Item.get('Name', Item.get('name', f'Item {Index + 1}'))
                        Number = Item.get('Value', Item.get('value', 0))
                        Color = Item.get('Color', Item.get('color', self._Palette_Color(Index)))
                        Result.append({'Name': str(Name), 'Value': float(Number), 'Color': self._Hive_Color(Color)})
                    else:
                        Result.append({'Name': f'Item {Index + 1}', 'Value': float(Item), 'Color': self._Palette_Color(Index)})
            return Result
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Normalize_Pie -> {E}')
            return []

    def _All_Values(self, Series):
        try:
            Result = []
            for Item in Series:
                Result.extend(Item.get('Values', []))
            return Result
        except Exception:
            return []

    def _Domain(self, Values):
        try:
            Tick_List = self._Custom_Tick_List()
            if len(Tick_List) >= 2:
                Minimum = min(Tick_List)
                Maximum = max(Tick_List)
                if Minimum == Maximum:
                    Maximum = Minimum + 1.0
                return [Minimum, Maximum]
            if len(Tick_List) == 1:
                Minimum = float(Tick_List[0])
                return [Minimum, Minimum + 1.0]
            if len(Values) == 0:
                return [0.0, 1.0]
            Minimum = min(min(Values), 0.0)
            Maximum = max(max(Values), 0.0)
            if Minimum == Maximum:
                Maximum = Minimum + 1.0
            Padding = (Maximum - Minimum) * 0.08
            return [Minimum - Padding if Minimum < 0 else 0.0, Maximum + Padding if Maximum > 0 else 1.0]
        except Exception:
            return [0.0, 1.0]

    def _Plot_Box(self):
        try:
            Width = float(max(1, self._Canvas_Width))
            Height = float(max(1, self._Canvas_Height))
            Left = float(self._Margin_Left)
            Right = Width - float(self._Margin_Right)
            Top = float(self._Margin_Top)
            Bottom = Height - float(self._Margin_Bottom)
            if Right <= Left:
                Right = Left + 1
            if Bottom <= Top:
                Bottom = Top + 1
            return [Width, Height, Left, Top, Right, Bottom]
        except Exception:
            return [900.0, 500.0, 70.0, 55.0, 870.0, 440.0]

    def _Custom_Tick_List(self):
        try:
            Value = self._Value_Ticks
            if Value in [False, None, '']:
                Value = self._Y_Ticks
            if Value in [False, None, '']:
                return []
            Result = []
            for Each in list(Value):
                try:
                    Result.append(float(Each))
                except Exception:
                    pass
            return Result
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Custom_Tick_List -> {E}')
            return []

    def _Tick_List(self, Minimum, Maximum, Count=None):
        try:
            Custom = self._Custom_Tick_List()
            if len(Custom) > 0:
                return Custom
            Result = []
            if Count is None:
                Count = self._Tick_Count
            Count = max(2, int(Count))
            for Index in range(Count):
                Result.append(Minimum + ((Maximum - Minimum) * Index / (Count - 1)))
            return Result
        except Exception:
            return [0, 1]

    def _Format_Number(self, Value):
        try:
            Number = float(Value)
            if abs(Number - int(Number)) < 0.00001:
                return str(int(Number))
            return str(round(Number, 2))
        except Exception:
            return str(Value)

    def _Title_Svg(self, Width):
        try:
            if self._Title in [False, None, '']:
                return ''
            return f'<text x="{round(Width / 2, 2)}" y="26" text-anchor="middle" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Title_Size)}" font-weight="700" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(str(self._Title))}</text>'
        except Exception:
            return ''

    def _Legend_Svg(self, Series, Width):
        try:
            if not self._Legend or len(Series) <= 0:
                return ''
            X = Width - float(self._Margin_Right) - 120
            Y = 18
            Items = []
            for Index, Item in enumerate(Series):
                Color = self._Hive_Color(Item.get('Color', self._Palette_Color(Index)))
                Item_Y = Y + Index * 18
                Items.append(f'<rect x="{round(X, 2)}" y="{round(Item_Y - 6, 2)}" width="10" height="10" rx="2" fill="{escape(str(Color))}" />')
                Items.append(f'<text x="{round(X + 16, 2)}" y="{round(Item_Y, 2)}" text-anchor="start" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Legend_Size)}" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(str(Item.get("Name", "")))}</text>')
            return ''.join(Items)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Legend_Svg -> {E}')
            return ''

    def _Axis_Vertical_Svg(self, Labels, Minimum, Maximum, Left, Top, Right, Bottom):
        try:
            Items = []
            Height = Bottom - Top
            Width = Right - Left
            for Tick in self._Tick_List(Minimum, Maximum):
                Ratio = (Tick - Minimum) / (Maximum - Minimum)
                Y = Bottom - Ratio * Height
                if self._Grid:
                    Items.append(f'<line x1="{round(Left, 2)}" y1="{round(Y, 2)}" x2="{round(Right, 2)}" y2="{round(Y, 2)}" stroke="{escape(str(self._Hive_Color(self._Grid_Color)))}" stroke-width="1" />')
                if self._Axis and self._Axis_Text and self._Axis_Y:
                    Items.append(f'<text x="{round(Left - 8, 2)}" y="{round(Y, 2)}" text-anchor="end" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Axis_Size)}" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(self._Format_Number(Tick))}</text>')
            if self._Axis:
                if self._Axis_Y:
                    Items.append(f'<line x1="{round(Left, 2)}" y1="{round(Top, 2)}" x2="{round(Left, 2)}" y2="{round(Bottom, 2)}" stroke="{escape(str(self._Hive_Color(self._Axis_Color)))}" stroke-width="1.5" />')
                if self._Axis_X:
                    Items.append(f'<line x1="{round(Left, 2)}" y1="{round(Bottom, 2)}" x2="{round(Right, 2)}" y2="{round(Bottom, 2)}" stroke="{escape(str(self._Hive_Color(self._Axis_Color)))}" stroke-width="1.5" />')
            if self._Axis_Text and self._Axis_X and len(Labels) > 0:
                Step = Width / max(1, len(Labels))
                for Index, Label in enumerate(Labels):
                    X = Left + Step * (Index + 0.5)
                    Items.append(f'<text x="{round(X, 2)}" y="{round(Bottom + 20, 2)}" text-anchor="middle" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Axis_Size)}" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(str(Label))}</text>')
            return ''.join(Items)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Axis_Vertical_Svg -> {E}')
            return ''

    def _Axis_Horizontal_Svg(self, Labels, Minimum, Maximum, Left, Top, Right, Bottom, Direction):
        try:
            Items = []
            Height = Bottom - Top
            Width = Right - Left
            for Tick in self._Tick_List(Minimum, Maximum):
                Ratio = (Tick - Minimum) / (Maximum - Minimum)
                X = Left + Ratio * Width if Direction == 'Left_To_Right' else Right - Ratio * Width
                if self._Grid:
                    Items.append(f'<line x1="{round(X, 2)}" y1="{round(Top, 2)}" x2="{round(X, 2)}" y2="{round(Bottom, 2)}" stroke="{escape(str(self._Hive_Color(self._Grid_Color)))}" stroke-width="1" />')
                if self._Axis and self._Axis_Text and self._Axis_X:
                    Items.append(f'<text x="{round(X, 2)}" y="{round(Bottom + 20, 2)}" text-anchor="middle" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Axis_Size)}" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(self._Format_Number(Tick))}</text>')
            if self._Axis:
                if self._Axis_Y:
                    Items.append(f'<line x1="{round(Left, 2)}" y1="{round(Top, 2)}" x2="{round(Left, 2)}" y2="{round(Bottom, 2)}" stroke="{escape(str(self._Hive_Color(self._Axis_Color)))}" stroke-width="1.5" />')
                if self._Axis_X:
                    Items.append(f'<line x1="{round(Left, 2)}" y1="{round(Bottom, 2)}" x2="{round(Right, 2)}" y2="{round(Bottom, 2)}" stroke="{escape(str(self._Hive_Color(self._Axis_Color)))}" stroke-width="1.5" />')
            if self._Axis_Text and self._Axis_Y and len(Labels) > 0:
                Step = Height / max(1, len(Labels))
                for Index, Label in enumerate(Labels):
                    Y = Top + Step * (Index + 0.5)
                    Items.append(f'<text x="{round(Left - 8, 2)}" y="{round(Y, 2)}" text-anchor="end" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Axis_Size)}" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(str(Label))}</text>')
            return ''.join(Items)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Axis_Horizontal_Svg -> {E}')
            return ''

    def _Tooltip_Title(self, Text):
        try:
            if not self._Tooltip:
                return ''
            return f'<title>{escape(str(Text))}</title>'
        except Exception:
            return ''

    def _Render_Bar(self):
        try:
            Width, Height, Left, Top, Right, Bottom = self._Plot_Box()
            Labels = self._Normalize_Labels()
            Series = self._Normalize_Series()
            if len(Series) == 0:
                Series = [{'Name': 'Value', 'Values': [], 'Color': self._Palette_Color(0)}]
            Label_Count = max(len(Labels), max([len(Item.get('Values', [])) for Item in Series] + [0]))
            if len(Labels) < Label_Count:
                Labels = Labels + [f'Item {Index + 1}' for Index in range(len(Labels), Label_Count)]
            Minimum, Maximum = self._Domain(self._All_Values(Series))
            Direction = self._Direction_Value()
            Items = [self._Title_Svg(Width)]
            Horizontal = Direction in ['Left_To_Right', 'Right_To_Left']
            if Horizontal:
                Items.append(self._Axis_Horizontal_Svg(Labels, Minimum, Maximum, Left, Top, Right, Bottom, Direction))
                Items.append(self._Render_Bar_Horizontal(Labels, Series, Minimum, Maximum, Left, Top, Right, Bottom, Direction))
            else:
                Items.append(self._Axis_Vertical_Svg(Labels, Minimum, Maximum, Left, Top, Right, Bottom))
                Items.append(self._Render_Bar_Vertical(Labels, Series, Minimum, Maximum, Left, Top, Right, Bottom, Direction))
            Items.append(self._Legend_Svg(Series, Width))
            return ''.join(Items)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Bar -> {E}')
            return ''

    def _Base_Value(self, Minimum, Maximum):
        try:
            if Minimum <= 0 <= Maximum:
                return 0.0
            if Minimum > 0:
                return Minimum
            return Maximum
        except Exception:
            return 0.0

    def _Render_Bar_Vertical(self, Labels, Series, Minimum, Maximum, Left, Top, Right, Bottom, Direction):
        try:
            Items = []
            Plot_Width = Right - Left
            Plot_Height = Bottom - Top
            Label_Count = max(1, len(Labels))
            Series_Count = max(1, len(Series))
            Group_Width = Plot_Width / Label_Count
            Inner_Width = Group_Width * (1 - float(self._Group_Gap))
            Bar_Width = Inner_Width / Series_Count * (1 - float(self._Bar_Gap))
            Span = Maximum - Minimum
            Map_Y = lambda Value: Bottom - ((Value - Minimum) / Span) * Plot_Height if Direction == 'Bottom_To_Top' else Top + ((Value - Minimum) / Span) * Plot_Height
            Zero_Y = Map_Y(self._Base_Value(Minimum, Maximum))
            for Label_Index, Label in enumerate(Labels):
                Group_Left = Left + Label_Index * Group_Width + (Group_Width - Inner_Width) / 2
                for Series_Index, Item in enumerate(Series):
                    Values = Item.get('Values', [])
                    Value = Values[Label_Index] if Label_Index < len(Values) else 0.0
                    Value_Y = Map_Y(Value)
                    X = Group_Left + Series_Index * (Inner_Width / Series_Count) + ((Inner_Width / Series_Count) - Bar_Width) / 2
                    Y = min(Value_Y, Zero_Y)
                    H = max(1, abs(Zero_Y - Value_Y))
                    Color = self._Hive_Color(Item.get('Color', self._Palette_Color(Series_Index)))
                    Tool = f'{Item.get("Name", "Value")} | {Label}: {self._Format_Number(Value)}'
                    Items.append(f'<rect class="wx-chart-item" x="{round(X, 2)}" y="{round(Y, 2)}" width="{round(Bar_Width, 2)}" height="{round(H, 2)}" rx="3" fill="{escape(str(Color))}">{self._Tooltip_Title(Tool)}</rect>')
                    if self._Text:
                        Text_Y = Y - 8 if Direction == 'Bottom_To_Top' else Y + H + 12
                        Items.append(f'<text x="{round(X + Bar_Width / 2, 2)}" y="{round(Text_Y, 2)}" text-anchor="middle" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Text_Size)}" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(self._Format_Number(Value))}</text>')
            return ''.join(Items)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Bar_Vertical -> {E}')
            return ''

    def _Render_Bar_Horizontal(self, Labels, Series, Minimum, Maximum, Left, Top, Right, Bottom, Direction):
        try:
            Items = []
            Plot_Width = Right - Left
            Plot_Height = Bottom - Top
            Label_Count = max(1, len(Labels))
            Series_Count = max(1, len(Series))
            Group_Height = Plot_Height / Label_Count
            Inner_Height = Group_Height * (1 - float(self._Group_Gap))
            Bar_Height = Inner_Height / Series_Count * (1 - float(self._Bar_Gap))
            Span = Maximum - Minimum
            Map_X = lambda Value: Left + ((Value - Minimum) / Span) * Plot_Width if Direction == 'Left_To_Right' else Right - ((Value - Minimum) / Span) * Plot_Width
            Zero_X = Map_X(self._Base_Value(Minimum, Maximum))
            for Label_Index, Label in enumerate(Labels):
                Group_Top = Top + Label_Index * Group_Height + (Group_Height - Inner_Height) / 2
                for Series_Index, Item in enumerate(Series):
                    Values = Item.get('Values', [])
                    Value = Values[Label_Index] if Label_Index < len(Values) else 0.0
                    Value_X = Map_X(Value)
                    X = min(Value_X, Zero_X)
                    W = max(1, abs(Zero_X - Value_X))
                    Y = Group_Top + Series_Index * (Inner_Height / Series_Count) + ((Inner_Height / Series_Count) - Bar_Height) / 2
                    Color = self._Hive_Color(Item.get('Color', self._Palette_Color(Series_Index)))
                    Tool = f'{Item.get("Name", "Value")} | {Label}: {self._Format_Number(Value)}'
                    Items.append(f'<rect class="wx-chart-item" x="{round(X, 2)}" y="{round(Y, 2)}" width="{round(W, 2)}" height="{round(Bar_Height, 2)}" rx="3" fill="{escape(str(Color))}">{self._Tooltip_Title(Tool)}</rect>')
                    if self._Text:
                        Text_X = X + W + 8 if Direction == 'Left_To_Right' else X - 8
                        Anchor = 'start' if Direction == 'Left_To_Right' else 'end'
                        Items.append(f'<text x="{round(Text_X, 2)}" y="{round(Y + Bar_Height / 2, 2)}" text-anchor="{Anchor}" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Text_Size)}" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(self._Format_Number(Value))}</text>')
            return ''.join(Items)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Bar_Horizontal -> {E}')
            return ''

    def _Render_Line(self):
        try:
            Width, Height, Left, Top, Right, Bottom = self._Plot_Box()
            Labels = self._Normalize_Labels()
            Series = self._Normalize_Series()
            Label_Count = max(len(Labels), max([len(Item.get('Values', [])) for Item in Series] + [0]))
            if len(Labels) < Label_Count:
                Labels = Labels + [f'Item {Index + 1}' for Index in range(len(Labels), Label_Count)]
            Minimum, Maximum = self._Domain(self._All_Values(Series))
            Items = [self._Title_Svg(Width), self._Axis_Vertical_Svg(Labels, Minimum, Maximum, Left, Top, Right, Bottom)]
            Plot_Width = Right - Left
            Plot_Height = Bottom - Top
            Span = Maximum - Minimum
            Step = Plot_Width / max(1, Label_Count - 1) if Label_Count > 1 else Plot_Width
            for Series_Index, Item in enumerate(Series):
                Values = Item.get('Values', [])
                Color = self._Hive_Color(Item.get('Color', self._Palette_Color(Series_Index)))
                Points = []
                for Index, Value in enumerate(Values):
                    X = Left + Step * Index if Label_Count > 1 else Left + Plot_Width / 2
                    Y = Bottom - ((Value - Minimum) / Span) * Plot_Height
                    Points.append([X, Y, Value])
                if len(Points) > 0:
                    Text = ' '.join([f'{round(Point[0], 2)},{round(Point[1], 2)}' for Point in Points])
                    Items.append(f'<polyline points="{Text}" fill="none" stroke="{escape(str(Color))}" stroke-width="{round(float(self._Line_Width), 2)}" stroke-linecap="round" stroke-linejoin="round" />')
                    for Index, Point in enumerate(Points):
                        Label = Labels[Index] if Index < len(Labels) else f'Item {Index + 1}'
                        Tool = f'{Item.get("Name", "Value")} | {Label}: {self._Format_Number(Point[2])}'
                        Items.append(f'<circle class="wx-chart-item" cx="{round(Point[0], 2)}" cy="{round(Point[1], 2)}" r="{round(float(self._Point_Size), 2)}" fill="{escape(str(Color))}" stroke="#ffffff" stroke-width="2">{self._Tooltip_Title(Tool)}</circle>')
                        if self._Text:
                            Items.append(f'<text x="{round(Point[0], 2)}" y="{round(Point[1] - 12, 2)}" text-anchor="middle" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Text_Size)}" fill="{escape(str(self._Hive_Color(self._Text_Color)))}">{escape(self._Format_Number(Point[2]))}</text>')
            Items.append(self._Legend_Svg(Series, Width))
            return ''.join(Items)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Line -> {E}')
            return ''

    def _Pie_Point(self, CX, CY, Radius, Angle):
        Radian = (Angle - 90) * pi / 180.0
        return [CX + Radius * cos(Radian), CY + Radius * sin(Radian)]

    def _Render_Pie(self):
        try:
            Width, Height, Left, Top, Right, Bottom = self._Plot_Box()
            Data = self._Normalize_Pie()
            Total = sum([max(0, Item.get('Value', 0)) for Item in Data])
            Items = [self._Title_Svg(Width)]
            if Total <= 0:
                return ''.join(Items)
            CX = (Left + Right) / 2
            CY = (Top + Bottom) / 2
            Radius = max(1, min(Right - Left, Bottom - Top) / 2 - 10)
            Inner = max(0, min(float(self._Pie_Donut), Radius - 1))
            Angle = float(self._Pie_Start_Angle)
            Legend_Data = []
            for Index, Item in enumerate(Data):
                Value = max(0, float(Item.get('Value', 0)))
                Sweep = 360.0 * Value / Total
                Start = Angle
                End = Angle + Sweep
                Large = 1 if Sweep > 180 else 0
                P1 = self._Pie_Point(CX, CY, Radius, Start)
                P2 = self._Pie_Point(CX, CY, Radius, End)
                Color = self._Hive_Color(Item.get('Color', self._Palette_Color(Index)))
                Tool = f'{Item.get("Name", f"Item {Index + 1}")}: {self._Format_Number(Value)} ({round(Value / Total * 100, 1)}%)'
                if Inner > 0:
                    I2 = self._Pie_Point(CX, CY, Inner, End)
                    I1 = self._Pie_Point(CX, CY, Inner, Start)
                    Path = f'M {round(P1[0], 2)} {round(P1[1], 2)} A {round(Radius, 2)} {round(Radius, 2)} 0 {Large} 1 {round(P2[0], 2)} {round(P2[1], 2)} L {round(I2[0], 2)} {round(I2[1], 2)} A {round(Inner, 2)} {round(Inner, 2)} 0 {Large} 0 {round(I1[0], 2)} {round(I1[1], 2)} Z'
                else:
                    Path = f'M {round(CX, 2)} {round(CY, 2)} L {round(P1[0], 2)} {round(P1[1], 2)} A {round(Radius, 2)} {round(Radius, 2)} 0 {Large} 1 {round(P2[0], 2)} {round(P2[1], 2)} Z'
                Items.append(f'<path class="wx-chart-item" d="{Path}" fill="{escape(str(Color))}" stroke="#ffffff" stroke-width="2">{self._Tooltip_Title(Tool)}</path>')
                if self._Text and Sweep > 8:
                    Mid = Start + Sweep / 2
                    Text_Point = self._Pie_Point(CX, CY, (Radius + Inner) / 2 if Inner > 0 else Radius * 0.62, Mid)
                    Items.append(f'<text x="{round(Text_Point[0], 2)}" y="{round(Text_Point[1], 2)}" text-anchor="middle" dominant-baseline="middle" font-family="{escape(str(self._Font_Family))}" font-size="{int(self._Text_Size)}" fill="#ffffff">{escape(str(Item.get("Name", "")))}</text>')
                Legend_Data.append({'Name': str(Item.get('Name', f'Item {Index + 1}')), 'Color': Color})
                Angle = End
            Items.append(self._Legend_Svg(Legend_Data, Width))
            return ''.join(Items)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Pie -> {E}')
            return ''

    def _Render_Svg_Text(self):
        try:
            Width = float(max(1, self._Canvas_Width))
            Height = float(max(1, self._Canvas_Height))
            Chart_Type = self._Chart_Type_Value()
            Content = self._Render_Pie() if Chart_Type == 'Pie' else (self._Render_Line() if Chart_Type == 'Line' else self._Render_Bar())
            Preserve = 'xMidYMid meet' if getattr(self, '_Aspect_Ratio', True) else 'none'
            Style = '<style>.wx-chart-item{transition:opacity 0.12s ease,filter 0.12s ease}.wx-chart-item:hover{opacity:0.82;filter:brightness(1.05)}</style>'
            return f'<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 {round(Width, 2)} {round(Height, 2)}" preserveAspectRatio="{Preserve}" style="display:block; width:100%; height:100%; max-width:100%; max-height:100%; user-select:none; background:transparent; overflow:visible;">{Style}{Content}</svg>'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render_Svg_Text -> {E}')
            return ''

    def _Render(self):
        try:
            if self._Svg is None:
                return
            self._Svg.content = self._Render_Svg_Text()
            if hasattr(self._Svg, '_style'):
                self._Svg._style.clear()
            if hasattr(self._Svg, '_classes'):
                self._Svg._classes.clear()
            self._Svg.style('display:block; width:100%; height:100%; max-width:100%; max-height:100%; overflow:hidden;')
            self._Svg.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render -> {E}')

    def _Apply(self):
        try:
            if self._Widget is None:
                return
            if hasattr(self._Widget, '_style'):
                self._Widget._style.clear()
            if hasattr(self._Widget, '_classes'):
                self._Widget._classes.clear()
            self._Widget.style(self._Build_Frame_Style())
            if self._Classes not in [False, None, '']:
                self._Widget.classes(str(self._Classes))
            if self._Body is not None:
                if hasattr(self._Body, '_style'):
                    self._Body._style.clear()
                self._Body.style(self._Build_Body_Style())
            self._Widget.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception:
            return '1s'

    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception:
            return 1000

    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False

    def _Animate_Target_Box(self):
        try:
            Left = self._Left if self._Left is not None else 0
            Top = self._Top if self._Top is not None else 0
            Width = self._Width if self._Width is not None else 0
            Height = self._Height if self._Height is not None else 0
            return {'Left': Left, 'Top': Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')

    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')

    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'
                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div').props('tabindex=0')
                else:
                    self._Widget = ui.element('div').props('tabindex=0')
                with self._Widget:
                    self._Body = ui.element('div')
                    with self._Body:
                        self._Svg = ui.html('').style('display:block; width:100%; height:100%; max-width:100%; max-height:100%; overflow:hidden;')
                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)
                self._Initialized = True
            self._Apply()
            self._Render()
            if self._Name != self._Last_Name:
                if self._Last_Name and self._Last_Name in self._Main.__dict__:
                    del self._Main.__dict__[self._Last_Name]
                if self._Name:
                    self._Main.__dict__[self._Name] = self
                self._Last_Name = self._Name
            if not self._Display:
                self.Hide()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, deepcopy(getattr(self, '_' + Key)))
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            self.Animate_Cancel()
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
            self._Widget = None
            self._Body = None
            self._Svg = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            if self._Animating:
                return
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if not self._Display:
                return False
            if self._Widget is None:
                return False
            self._Widget.run_method('focus')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')
            return False

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Widget is None:
                self.Create()
            if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                self._Mode = 'Place'
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()

    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Widget is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Refresh(self):
        try:
            self._Apply()
            self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Widget(self):
        try:
            return self._Widget
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Ticks(self, Value=None):
        try:
            if Value is None:
                return deepcopy(self._Value_Ticks)
            self._Value_Ticks = deepcopy(Value)
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ticks -> {E}')
            return self

    def Y_Ticks(self, Value=None):
        try:
            if Value is None:
                return deepcopy(self._Y_Ticks)
            self._Y_Ticks = deepcopy(Value)
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Y_Ticks -> {E}')
            return self

    def Set(self, Labels=None, Series=None, Pie=None, Type=None, Direction=None):
        try:
            if Labels is not None:
                self._Labels = deepcopy(Labels)
            if Series is not None:
                self._Series = deepcopy(Series)
            if Pie is not None:
                self._Pie = deepcopy(Pie)
            if Type is not None:
                self._Chart_Type = self._Chart_Type_Value(Type)
            if Direction is not None:
                self._Direction = self._Direction_Value(Direction)
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Type(self, Value=None):
        try:
            if Value is None:
                return self._Chart_Type_Value()
            self._Chart_Type = self._Chart_Type_Value(Value)
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Type -> {E}')

    def Direction(self, Value=None):
        try:
            if Value is None:
                return self._Direction_Value()
            self._Direction = self._Direction_Value(Value)
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Direction -> {E}')

    def Labels(self, Value=None):
        try:
            if Value is None:
                return deepcopy(self._Labels)
            self._Labels = deepcopy(Value)
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Labels -> {E}')

    def Series(self, Value=None):
        try:
            if Value is None:
                return deepcopy(self._Series)
            self._Series = deepcopy(Value)
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Series -> {E}')

    def Pie(self, Value=None):
        try:
            if Value is None:
                return deepcopy(self._Pie)
            self._Pie = deepcopy(Value)
            self._Chart_Type = 'Pie'
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pie -> {E}')

    def Add_Series(self, Name='Series', Values=None, Color=None):
        try:
            if Values is None:
                Values = []
            if not isinstance(self._Series, list):
                self._Series = []
            self._Series.append({'Name': str(Name), 'Values': self._Normalize_Values(Values), 'Color': Color if Color is not None else self._Palette_Color(len(self._Series))})
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Add_Series -> {E}')

    def Clear(self):
        try:
            self._Labels = []
            self._Series = []
            self._Pie = []
            if self._Initialized:
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Export(self):
        try:
            return {'Type': self._Chart_Type_Value(), 'Direction': self._Direction_Value(), 'Labels': deepcopy(self._Labels), 'Series': deepcopy(self._Series), 'Pie': deepcopy(self._Pie), 'Config': self.Config_Get(*self._Config.keys())}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Export -> {E}')
            return {}

    def Import(self, Data):
        try:
            if not isinstance(Data, dict):
                return False
            if 'Config' in Data and isinstance(Data['Config'], dict):
                self.Config(**Data['Config'])
            if 'Type' in Data:
                self._Chart_Type = self._Chart_Type_Value(Data['Type'])
            if 'Direction' in Data:
                self._Direction = self._Direction_Value(Data['Direction'])
            if 'Labels' in Data:
                self._Labels = deepcopy(Data['Labels'])
            if 'Series' in Data:
                self._Series = deepcopy(Data['Series'])
            if 'Pie' in Data:
                self._Pie = deepcopy(Data['Pie'])
            if self._Initialized:
                self._Apply()
                self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Import -> {E}')
            return False

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
                del Input['On_Animate']
            if self._Widget is not None and len(Input) > 0:
                Event_Bind(self._Widget, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = deepcopy(getattr(self, '_' + Each))
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    Value = Input[Each]
                    if Each == 'Chart_Type':
                        Value = self._Chart_Type_Value(Value)
                    if Each == 'Direction':
                        Value = self._Direction_Value(Value)
                    setattr(self, '_' + Each, deepcopy(Value))
                    Run = True
            if self._Initialized and Run:
                self._Apply()
                self._Render()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return Number
            return f'{Number}px'
        except Exception:
            return '0px'

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def _CSS_Ratio(self, Value, Base):
        try:
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            if Value_Number is None or Base_Number is None or Base_Number == 0:
                return 0
            if Value_Unit != Base_Unit:
                return 0
            return round((Value_Number / Base_Number) * 100, 3)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Ratio -> {E}')
            return 0

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width
            Height = self._Height
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Scale(self, Scale=1, Width=True, Height=True, Left=False, Top=False):
        try:
            if Width:
                self._Width = self._CSS_Scale(self._Width, Scale)
            if Height:
                self._Height = self._CSS_Scale(self._Height, Scale)
            if Left:
                self._Left = self._CSS_Scale(self._Left, Scale)
            if Top:
                self._Top = self._CSS_Scale(self._Top, Scale)
            self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Scale -> {E}')

    def Grab(self, Path=False):
        try:
            if hasattr(self._GUI, 'Grab_Widget'):
                return self._GUI.Grab_Widget(Path=Path, Widget=self)
            return False
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Grab -> {E}')
