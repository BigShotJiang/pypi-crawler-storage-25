from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Button:

    def __init__(self, Main, *Args, **Kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Button'
            try:
                self._Config = {'Name': False, 'Background': False, 'Foreground': '#000000', 'Border_Color': 'transparent', 'Border_Size': 0, 'Border_Radius': 0, 'Shadow_X': 0, 'Shadow_Y': 0, 'Shadow_Blur': 0, 'Shadow_Spread': 0, 'Shadow_Color': 'transparent', 'Display': True, 'Left': None, 'Top': None, 'Right': None, 'Bottom': None, 'Width': None, 'Height': None, 'Animate_Left': 0, 'Animate_Top': 0, 'Animate_Width': 0, 'Animate_Height': 0, 'Animate_Time': 1.0, 'Animate_Ease': 'cubic-bezier(0.22, 1, 0.36, 1)', 'Font_Size': 12, 'Font_Weight': 'normal', 'Font_Family': 'Helvetica', 'Align': 'center', 'Value': '', 'Hover_Background': False, 'Hover_Foreground': False, 'Hover_Border_Color': False, 'Padding': 0, 'Margin': 0, 'Mode': 'Flow', 'Classes': '', 'Style': '', 'Z_Index': None, 'Disable': False}
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Name = self._Config['Name']
                self._Background = self._Config['Background']
                self._Foreground = self._Config['Foreground']
                self._Border_Color = self._Config['Border_Color']
                self._Border_Size = self._Config['Border_Size']
                self._Border_Radius = self._Config['Border_Radius']
                self._Shadow_X = self._Config['Shadow_X']
                self._Shadow_Y = self._Config['Shadow_Y']
                self._Shadow_Blur = self._Config['Shadow_Blur']
                self._Shadow_Spread = self._Config['Shadow_Spread']
                self._Shadow_Color = self._Config['Shadow_Color']
                self._Display = self._Config['Display']
                self._Left = self._Config['Left']
                self._Top = self._Config['Top']
                self._Right = self._Config['Right']
                self._Bottom = self._Config['Bottom']
                self._Width = self._Config['Width']
                self._Height = self._Config['Height']
                self._Animate_Left = self._Config['Animate_Left']
                self._Animate_Top = self._Config['Animate_Top']
                self._Animate_Width = self._Config['Animate_Width']
                self._Animate_Height = self._Config['Animate_Height']
                self._Animate_Time = self._Config['Animate_Time']
                self._Animate_Ease = self._Config['Animate_Ease']
                self._Animating = False
                self._Animate_Box = None
                self._Animate_Transition = False
                self._Anim_Start_Timer = None
                self._Anim_Finish_Timer = None
                self._Font_Size = self._Config['Font_Size']
                self._Font_Weight = self._Config['Font_Weight']
                self._Font_Family = self._Config['Font_Family']
                self._Align = self._Config['Align']
                self._Value = self._Config['Value']
                self._Hover_Background = self._Config['Hover_Background']
                self._Hover_Foreground = self._Config['Hover_Foreground']
                self._Hover_Border_Color = self._Config['Hover_Border_Color']
                self._Padding = self._Config['Padding']
                self._Margin = self._Config['Margin']
                self._Mode = self._Config['Mode']
                self._Classes = self._Config['Classes']
                self._Style = self._Config['Style']
                self._Z_Index = self._Config['Z_Index']
                self._Disable = self._Config['Disable']
                self._On_Change = False
                self._On_Show = False
                self._On_Hide = False
                self._On_Animate = False
                if Kwargs:
                    self.Config(**Kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Button[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Button[]'

    def _Hive_Color(self, Value):
        Hive = {
            'Hive_Yellow': '#F4C430',
            'Hive_Gold': '#D4A017',
            'Hive_Honey': '#FFBF00',
            'Hive_Amber': '#FFB000',
            'Hive_Orange': '#F28C28',
            'Hive_Brown': '#6B4F1D',
            'Hive_Dark': '#1F1B16',
            'Hive_Light': '#FFF8E1',
            'Hive_Cream': '#FFF3BF',
            'Hive_White': '#FFFFFF',
            'Hive_Black': '#000000',
        }
        if isinstance(Value, str) and Value in Hive:
            return Hive[Value]
        return Value

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Number(self, Value):
        if Value is None or Value is False:
            return 0
        try:
            return float(Value)
        except Exception:
            return 0

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Get_Background(self):
        if self._Background is False or self._Background is None or self._Background == '':
            if hasattr(self._Main, '_Background'):
                return self._Hive_Color(self._Main._Background)
            return 'transparent'
        return self._Hive_Color(self._Background)

    def _Get_Foreground(self):
        return self._Hive_Color(self._Foreground)

    def _Get_Border_Color(self):
        return self._Hive_Color(self._Border_Color)

    def _Get_Shadow_Color(self):
        return self._Hive_Color(self._Shadow_Color)

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Get_Shadow_Color() or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Build_Style(self):
        Box = self._Animate_Current_Box()
        Transition = 'all 0.2s ease'
        if self._Animate_Transition:
            Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, right {self._Animate_Time_CSS()} {self._Animate_Ease}, bottom {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}'
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"inline-flex" if self._Display or self._Animating else "none"}')
        Style.append('align-items: center')
        Style.append('justify-content: center')
        Style.append(f'background: {self._Get_Background()}')
        Style.append(f'color: {self._Get_Foreground()}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Get_Border_Color()}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'font-size: {self._Unit(self._Font_Size) or "12px"}')
        Style.append(f'font-weight: {self._Font_Weight}')
        Style.append(f'font-family: {self._Font_Family}')
        Style.append(f'text-align: {self._Align}')
        Style.append(f'padding: {self._Unit(self._Padding) or "0px"}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append('white-space: pre-wrap')
        Style.append('overflow-wrap: break-word')
        Style.append('text-transform: none')
        Style.append(f'transition: {Transition}')
        Style.append('min-height: auto')
        Style.append('min-width: auto')
        if self._Mode == 'Place':
            Style.append('position: absolute')
            if Box['Left'] is not None:
                Style.append(f'left: {self._Unit(Box["Left"])}')
            if Box['Top'] is not None:
                Style.append(f'top: {self._Unit(Box["Top"])}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')
        if Box['Width'] is not None:
            Style.append(f'width: {self._Unit(Box["Width"])}')
        if Box['Height'] is not None:
            Style.append(f'height: {self._Unit(Box["Height"])}')
        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')
        if self._Disable:
            Style.append('pointer-events: none')
            Style.append('opacity: 0.55')
            Style.append('cursor: default')
        else:
            Style.append('cursor: pointer')
        if self._Style:
            Style.append(self._Style)
        return '; '.join(Style)

    def _Apply(self):
        try:
            if self._Widget is None:
                return

            if hasattr(self._Widget, '_style'):
                self._Widget._style.clear()

            if hasattr(self._Widget, '_classes'):
                self._Widget._classes.clear()

            self._Widget.set_text(str(self._Value))
            self._Widget.style(self._Build_Style())

            Classes = []
            if self._Classes:
                Classes.append(self._Classes)

            if self._Hover_Background and not self._Disable:
                Classes.append(f'hover:!bg-[{self._Hive_Color(self._Hover_Background)}]')

            if self._Hover_Foreground and not self._Disable:
                Classes.append(f'hover:!text-[{self._Hive_Color(self._Hover_Foreground)}]')

            if self._Hover_Border_Color and not self._Disable:
                Classes.append(f'hover:!border-[{self._Hive_Color(self._Hover_Border_Color)}]')

            if len(Classes) > 0:
                self._Widget.classes(' '.join(Classes))

            if self._Disable:
                self._Widget.disable()
            else:
                self._Widget.enable()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception:
            return '1s'

    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception:
            return 1000

    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False

    def _Animate_Target_Box(self):
        try:
            Left = self._Left if self._Left is not None else 0
            Top = self._Top if self._Top is not None else 0
            Width = self._Width if self._Width is not None else 0
            Height = self._Height if self._Height is not None else 0
            return {'Left': Left, 'Top': Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')

    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')

    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            self.Animate_Cancel()
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            if self._Animating:
                return
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if not self._Display:
                return False
            if hasattr(self, '_Disable') and self._Disable:
                return False
            if self._Widget is None:
                return False
            self._Widget.run_method('focus')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')
            return False

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Widget is None:
                self.Create()
            if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                self._Mode = 'Place'
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()

    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Widget is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Set(self, Value=''):
        try:
            Changed = Value != self._Value
            self._Value = Value
            self._Apply()
            if Changed and self._On_Change:
                self._On_Change()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Get(self):
        try:
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Widget(self):
        try:
            return self._Widget
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
                del Input['On_Animate']
            if self._Widget is not None and len(Input) > 0:
                Event_Bind(self._Widget, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if self._Initialized and Run:
                self._Apply()
                if self._On_Change:
                    self._On_Change()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')
            
    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return Number
            return f'{Number}px'
        except Exception:
            return '0px'

    def _CSS_Value(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return 0
            if isinstance(Value, (int, float)):
                return Value
            Text = str(Value).strip()
            if Text.endswith('%') or Text.endswith('px') or Text.startswith('calc('):
                return Text
            return float(Text)
        except Exception:
            return Value

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def _CSS_Ratio(self, Value, Base):
        try:
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            if Value_Number is None or Base_Number is None or Base_Number == 0:
                return 0
            if Value_Unit != Base_Unit:
                return 0
            return round((Value_Number / Base_Number) * 100, 3)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Ratio -> {E}')
            return 0
			
    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._CSS_Add(self._Left, self._CSS_Scale(Width, 0.5)), self._CSS_Add(self._Top, self._CSS_Scale(Height, 0.5))]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Value(Left)
            if Top is not None:
                self._Top = self._CSS_Value(Top)
            if Right is not None:
                self._Right = self._CSS_Value(Right)
            if Bottom is not None:
                self._Bottom = self._CSS_Value(Bottom)
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = self._CSS_Value(Width)
            if Height is not False:
                self._Height = self._CSS_Value(Height)
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Add(self._Width, Value)
                self._Height = self._CSS_Add(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Subtract(self._Width, Value)
                self._Height = self._CSS_Subtract(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')
            
    def Font(self, Size=None, Weight=None, Family=None, Align=None):
        try:
            if Size is not None:
                self._Font_Size = Size
            if Weight is not None:
                self._Font_Weight = Weight
            if Family is not None:
                self._Font_Family = Family
            if Align is not None:
                self._Align = Align
            self._Apply()
            return [self._Font_Size, self._Font_Weight, self._Font_Family, self._Align]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Font -> {E}')

    def Colors(self, Background=None, Foreground=None, Border_Color=None):
        try:
            if Background is not None:
                self._Background = Background
            if Foreground is not None:
                self._Foreground = Foreground
            if Border_Color is not None:
                self._Border_Color = Border_Color
            self._Apply()
            return [self._Background, self._Foreground, self._Border_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Colors -> {E}')

    def Radius(self, Value=None):
        try:
            if Value is not None:
                self._Border_Radius = Value
                self._Apply()
            return self._Border_Radius
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Radius -> {E}')

    def Shadow(self, X=None, Y=None, Blur=None, Spread=None, Color=None):
        try:
            if X is not None:
                self._Shadow_X = X
            if Y is not None:
                self._Shadow_Y = Y
            if Blur is not None:
                self._Shadow_Blur = Blur
            if Spread is not None:
                self._Shadow_Spread = Spread
            if Color is not None:
                self._Shadow_Color = Color
            self._Apply()
            return [self._Shadow_X, self._Shadow_Y, self._Shadow_Blur, self._Shadow_Spread, self._Shadow_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shadow -> {E}')

    def Disable(self, Value=True):
        try:
            self._Disable = Value
            self._Apply()
            return self._Disable
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Disable -> {E}')

    def Enable(self):
        try:
            self._Disable = False
            self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enable -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.button(str(self._Value), color=None)
                else:
                    self._Widget = ui.button(str(self._Value), color=None)

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')