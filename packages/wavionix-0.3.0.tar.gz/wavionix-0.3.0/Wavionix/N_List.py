from types import SimpleNamespace
from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class List:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'List'
            try:
                self._Config = {
                    'Name': False,
                    'Background': '#ffffff',
                    'Foreground': '#000000',
                    'Border_Color': '#000000',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': 160,
                    'Animate_Left': 0,
                    'Animate_Top': 0,
                    'Animate_Width': 0,
                    'Animate_Height': 0,
                    'Animate_Time': 1.0,
                    'Animate_Ease': 'cubic-bezier(0.22, 1, 0.36, 1)',
                    'Font_Size': 12,
                    'Font_Weight': 'normal',
                    'Font_Family': 'Helvetica',
                    'Disable': False,
                    'Scrollbar_Size': 12,
                    'Select_Foreground': '#000000',
                    'Select_Background': '#ffffff',
                    'Multiple': False,
                    'Values': [],
                    'Value': '',
                    'Hover_Background': False,
                    'Hover_Foreground': False,
                    'Hover_Border_Color': False,
                    'Padding': 4,
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Frame = None
                self._Body = None
                self._Items = []
                self._Labels = []
                self._Selected = set()
                self._Hover_Index = None
                self._Name = False
                self._Values = []
                self._Value = ''
                self._Background = '#ffffff'
                self._Foreground = '#000000'
                self._Border_Color = '#000000'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = 160
                self._Animate_Left = 0
                self._Animate_Top = 0
                self._Animate_Width = 0
                self._Animate_Height = 0
                self._Animate_Time = 1.0
                self._Animate_Ease = 'cubic-bezier(0.22, 1, 0.36, 1)'
                self._Animating = False
                self._Animate_Box = None
                self._Animate_Transition = False
                self._Anim_Start_Timer = None
                self._Anim_Finish_Timer = None
                self._Font_Size = 12
                self._Font_Weight = 'normal'
                self._Font_Family = 'Helvetica'
                self._Disable = False
                self._Scrollbar_Size = 12
                self._Select_Foreground = '#000000'
                self._Select_Background = '#ffffff'
                self._Multiple = False
                self._Hover_Background = False
                self._Hover_Foreground = False
                self._Hover_Border_Color = False
                self._Padding = 4
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._On_Show = False
                self._On_Hide = False
                self._On_Change = False
                self._On_Animate = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_List[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_List[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Build_Frame_Style(self):
        Box = self._Animate_Current_Box()
        Transition = 'all 0.2s ease'
        if self._Animate_Transition:
            Transition = f'left {self._Animate_Time_CSS()} {self._Animate_Ease}, top {self._Animate_Time_CSS()} {self._Animate_Ease}, right {self._Animate_Time_CSS()} {self._Animate_Ease}, bottom {self._Animate_Time_CSS()} {self._Animate_Ease}, width {self._Animate_Time_CSS()} {self._Animate_Ease}, height {self._Animate_Time_CSS()} {self._Animate_Ease}, opacity {self._Animate_Time_CSS()} {self._Animate_Ease}'
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if self._Display or self._Animating else "none"}')
        Style.append('flex-direction: column')
        Style.append('position: relative')
        Style.append('overflow: hidden')
        Style.append('user-select: none')
        Style.append(f'background: {self._Background}')
        Style.append(f'color: {self._Foreground}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Border_Color}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append('min-width: 0')
        Style.append('min-height: 0')
        Style.append(f'transition: {Transition}')
        if self._Mode == 'Place':
            Style.append('position: absolute')
            if Box['Left'] is not None:
                Style.append(f'left: {self._Unit(Box["Left"])}')
            if Box['Top'] is not None:
                Style.append(f'top: {self._Unit(Box["Top"])}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')
        if Box['Width'] is not None:
            Style.append(f'width: {self._Unit(Box["Width"])}')
        if Box['Height'] is not None:
            Height = self._Unit(Box['Height'])
            Style.append(f'height: {Height}')
            Style.append(f'min-height: {Height}')
        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')
        if self._Disable:
            Style.append('pointer-events: none')
            Style.append('opacity: 0.55')
        if self._Style:
            Style.append(self._Style)
        return '; '.join(Style)

    def _Build_Body_Style(self):
        Style = []
        Style.append('width: 100%')
        Style.append('height: 100%')
        Style.append('flex: 1 1 auto')
        Style.append('display: flex')
        Style.append('flex-direction: column')
        Style.append('gap: 4px')
        Style.append('box-sizing: border-box')
        Style.append(f'padding: {self._Unit(self._Padding) or "0px"}')
        Style.append('overflow-x: hidden')
        Style.append('overflow-y: auto')
        Style.append('min-width: 0')
        Style.append('min-height: 0')
        Style.append('scrollbar-gutter: stable')
        return '; '.join(Style)

    def _Build_Label_Style(self):
        Style = []
        Style.append('margin: 0')
        Style.append('width: 100%')
        Style.append('pointer-events: none')
        Style.append('color: inherit')
        Style.append('font: inherit')
        Style.append('white-space: nowrap')
        Style.append('overflow: hidden')
        Style.append('text-overflow: ellipsis')
        return '; '.join(Style)

    def _Build_Item_Style(self, Index):
        Selected = Index in self._Selected
        Hover = Index == self._Hover_Index

        Background = 'transparent'
        Foreground = self._Foreground
        Border_Color = 'transparent'

        if Selected:
            Background = self._Select_Background
            Foreground = self._Select_Foreground
            Border_Color = 'transparent'
        elif Hover:
            if self._Hover_Background:
                Background = self._Hover_Background
            if self._Hover_Foreground:
                Foreground = self._Hover_Foreground
            if self._Hover_Border_Color:
                Border_Color = self._Hover_Border_Color

        Radius = self._Unit(self._Border_Radius) or '0px'

        Style = []
        Style.append('display: flex')
        Style.append('align-items: center')
        Style.append('width: 100%')
        Style.append('min-height: 32px')
        Style.append('box-sizing: border-box')
        Style.append('min-width: 0')
        Style.append('cursor: not-allowed' if self._Disable else 'cursor: pointer')
        Style.append(f'background: {Background}')
        Style.append(f'color: {Foreground}')
        Style.append(f'border: 1px solid {Border_Color}')
        Style.append(f'border-radius: {Radius}')
        Style.append(f'font-size: {self._Unit(self._Font_Size) or "12px"}')
        Style.append(f'font-weight: {self._Font_Weight}')
        Style.append(f'font-family: {self._Font_Family}')
        Style.append('padding: 6px 10px')
        Style.append('transition: all 0.12s ease')

        Style.append('outline: none')
        Style.append('box-shadow: none')
        Style.append('-webkit-tap-highlight-color: transparent')

        return '; '.join(Style)

    def _Selected_Values(self):
        Result = []
        for Index in sorted(self._Selected):
            if 0 <= Index < len(self._Values):
                Result.append(self._Values[Index])
        return Result

    def _Apply_Item_Styles(self):
        try:
            for Index, Item in enumerate(self._Items):
                if hasattr(Item, '_style'):
                    Item._style.clear()
                if hasattr(Item, '_classes'):
                    Item._classes.clear()
                Item.style(self._Build_Item_Style(Index))
                Item.props(
                    f'tabindex="-1" '
                    f'role=option '
                    f'aria-selected={"true" if Index in self._Selected else "false"}'
                )
                Item.update()

            for Label in self._Labels:
                if hasattr(Label, '_style'):
                    Label._style.clear()
                if hasattr(Label, '_classes'):
                    Label._classes.clear()
                Label.style(self._Build_Label_Style())
                Label.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply_Item_Styles -> {E}')

    def _Emit_Change(self):
        try:
            if self._On_Change:
                self._On_Change(SimpleNamespace(value=self.Get(), sender=self, indices=sorted(self._Selected)))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Emit_Change -> {E}')

    def _Set_Hover(self, Index=None):
        try:
            self._Hover_Index = Index
            self._Apply_Item_Styles()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Set_Hover -> {E}')

    def _Select_Index(self, Index):
        try:
            if self._Disable:
                return
            if not 0 <= Index < len(self._Values):
                return

            if self._Multiple:
                if Index in self._Selected:
                    self._Selected.remove(Index)
                else:
                    self._Selected.add(Index)
            else:
                self._Selected = {Index}

            self._Apply_Item_Styles()
            self._Emit_Change()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Select_Index -> {E}')

    def _Rebuild(self):
        try:
            if self._Body is None:
                return

            Fixed = set()
            for Index in self._Selected:
                if 0 <= Index < len(self._Values):
                    Fixed.add(Index)
            self._Selected = Fixed

            if self._Hover_Index is not None:
                if not 0 <= self._Hover_Index < len(self._Values):
                    self._Hover_Index = None

            self._Body.clear()
            self._Items = []
            self._Labels = []

            with self._Body:
                for Index, Each in enumerate(self._Values):
                    Item = ui.element('div')
                    with Item:
                        Label = ui.label(str(Each))

                    Item.on('click', lambda E, Index=Index: self._Select_Index(Index))
                    Item.on('keydown.enter', lambda E, Index=Index: self._Select_Index(Index))
                    Item.on('keydown.space', lambda E, Index=Index: self._Select_Index(Index))
                    Item.on('mouseenter', lambda E, Index=Index: self._Set_Hover(Index))
                    Item.on('mouseleave', lambda E: self._Set_Hover(None))

                    self._Items.append(Item)
                    self._Labels.append(Label)

            self._Apply_Item_Styles()
            self._Body.update()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Rebuild -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def _Apply(self):
        try:
            if self._Frame is None or self._Body is None:
                return

            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()

            if hasattr(self._Body, '_style'):
                self._Body._style.clear()
            if hasattr(self._Body, '_classes'):
                self._Body._classes.clear()

            self._Frame.style(self._Build_Frame_Style())

            Classes = []
            if self._Classes:
                Classes.append(self._Classes)
            if len(Classes) > 0:
                self._Frame.classes(' '.join(Classes))

            self._Body.style(self._Build_Body_Style())

            self._Frame.update()
            self._Body.update()

            self._Rebuild()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Values_From_Input(self, Value):
        try:
            if Value is None or Value is False:
                return []
            if isinstance(Value, str):
                Text = Value.strip()
                if Text == '':
                    return []
                return [Each.strip() for Each in Text.split('/') if Each.strip() != '']
            if isinstance(Value, (list, tuple, set)):
                return [Each for Each in list(Value) if Each is not None and Each is not False and str(Each).strip() != '']
            return [Value]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Values_From_Input -> {E}')
            return []

    def _Animate_Current_Box(self):
        try:
            if self._Animate_Box is not None:
                return self._Animate_Box
            return {'Left': self._Left, 'Top': self._Top, 'Width': self._Width, 'Height': self._Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Current_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Time_CSS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return f'{Time}ms'
                return f'{Time}s'
            return str(Time)
        except Exception:
            return '1s'

    def _Animate_Time_MS(self):
        try:
            Time = self._Animate_Time
            if isinstance(Time, (int, float)):
                if Time > 10:
                    return int(Time)
                return int(Time * 1000)
            Text = str(Time).strip()
            if Text.endswith('ms'):
                return int(float(Text[:-2]))
            if Text.endswith('s'):
                return int(float(Text[:-1]) * 1000)
            return int(float(Text) * 1000)
        except Exception:
            return 1000

    def _Animate_Is_Zero(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return True
            if isinstance(Value, (int, float)):
                return float(Value) == 0
            Text = str(Value).strip()
            if Text.endswith('%'):
                return float(Text[:-1]) == 0
            if Text.endswith('px'):
                return float(Text[:-2]) == 0
            return float(Text) == 0
        except Exception:
            return False

    def _Animate_Target_Box(self):
        try:
            Left = self._Left if self._Left is not None else 0
            Top = self._Top if self._Top is not None else 0
            Width = self._Width if self._Width is not None else 0
            Height = self._Height if self._Height is not None else 0
            return {'Left': Left, 'Top': Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Target_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Start_Box(self):
        try:
            Target = self._Animate_Target_Box()
            Size_Anim = not (self._Animate_Is_Zero(self._Animate_Width) and self._Animate_Is_Zero(self._Animate_Height))
            Width = self._Animate_Width if Size_Anim else Target['Width']
            Height = self._Animate_Height if Size_Anim else Target['Height']
            return {'Left': self._Animate_Left, 'Top': self._Animate_Top, 'Width': Width, 'Height': Height}
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start_Box -> {E}')
            return {'Left': 0, 'Top': 0, 'Width': 0, 'Height': 0}

    def _Animate_Set_Box(self, Box, Transition=False):
        try:
            self._Animate_Box = Box
            self._Animate_Transition = Transition
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Set_Box -> {E}')

    def _Animate_Start(self, End):
        try:
            self._Animate_Set_Box(End, Transition=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Start -> {E}')

    def _Animate_Finish(self, Hide=False):
        try:
            self._Animating = False
            self._Animate_Box = None
            self._Animate_Transition = False
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Display = False if Hide else True
            self._Apply()
            if Hide and self._On_Hide:
                self._On_Hide()
            if self._On_Animate:
                self._On_Animate()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Animate_Finish -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            Instance._Value = self._Value
            Instance._Values = list(self._Values)
            Instance._Selected = set(self._Selected)
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            self.Animate_Cancel()
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Frame = None
                self._Body = None
                self._Items = []
                self._Labels = []
                self._Selected = set()
                self._Hover_Index = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self.Animate_Cancel()
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            if self._Animating:
                return
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if not self._Display:
                return False
            if hasattr(self, '_Disable') and self._Disable:
                return False
            if self._Frame is None:
                return False
            self._Frame.run_method('focus')
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')
            return False

    def Animate(self, Widget=None, Hide=False, Thread=True):
        try:
            if self._Anim_Start_Timer is not None or self._Anim_Finish_Timer is not None or self._Animating:
                self.Animate_Cancel()
            if self._Frame is None:
                self.Create()
            if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                self._Mode = 'Place'
            Target = self._Animate_Target_Box()
            Start = self._Animate_Start_Box()
            self._Animating = True
            self._Display = True
            if Hide:
                self._Animate_Set_Box(Target, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Start), once=True)
            else:
                self._Animate_Set_Box(Start, Transition=False)
                self._Anim_Start_Timer = ui.timer(0.03, lambda: self._Animate_Start(Target), once=True)
            self._Anim_Finish_Timer = ui.timer((self._Animate_Time_MS() + 120) / 1000, lambda: self._Animate_Finish(Hide=Hide), once=True)
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')
            self.Animate_Cancel()

    def Animate_Cancel(self):
        try:
            self._Animating = False
            if self._Anim_Start_Timer is not None:
                try:
                    self._Anim_Start_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Start_Timer.deactivate()
                    except Exception:
                        pass
            if self._Anim_Finish_Timer is not None:
                try:
                    self._Anim_Finish_Timer.cancel()
                except Exception:
                    try:
                        self._Anim_Finish_Timer.deactivate()
                    except Exception:
                        pass
            self._Anim_Start_Timer = None
            self._Anim_Finish_Timer = None
            self._Animate_Box = None
            self._Animate_Transition = False
            if self._Frame is not None:
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Focus(self):
        try:
            if len(self._Items) > 0:
                self._Items[0].run_method('focus')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')

    def Top(self):
        try:
            if self._Body is not None:
                self._Body.run_method('scrollTo', 0, 0)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Top -> {E}')

    def Get(self):
        try:
            Values = self._Selected_Values()
            if self._Multiple:
                return Values
            if len(Values) == 1:
                return Values[0]
            return None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value):
        try:
            New_Selected = set()
            if isinstance(Value, str) and '/' in Value:
                Values = self._Values_From_Input(Value)
            else:
                Values = Value
            if isinstance(Values, (list, tuple, set)):
                for Each in Values:
                    if isinstance(Each, int):
                        if 0 <= Each < len(self._Values):
                            New_Selected.add(Each)
                    elif Each in self._Values:
                        New_Selected.add(self._Values.index(Each))
            else:
                if isinstance(Values, int):
                    if 0 <= Values < len(self._Values):
                        New_Selected.add(Values)
                elif Values in self._Values:
                    New_Selected.add(self._Values.index(Values))
            if not self._Multiple and len(New_Selected) > 1:
                New_Selected = {sorted(New_Selected)[0]}
            self._Selected = New_Selected
            self._Apply_Item_Styles()
            return self.Get()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Reset(self):
        try:
            self._Selected = set()
            self._Apply_Item_Styles()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Reset -> {E}')

    def Add(self, Value):
        try:
            Values = self._Values_From_Input(Value)
            for Each in Values:
                if Each not in self._Values:
                    self._Values.append(Each)
            self._Value = '/'.join([str(Each) for Each in self._Values])
            self._Apply()
            return self._Values
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Add -> {E}')

    def Remove(self, Value):
        try:
            Values = self._Values_From_Input(Value)
            Selected = self._Selected_Values()
            for Each in Values:
                if Each in self._Values:
                    self._Values.remove(Each)
            self._Value = '/'.join([str(Each) for Each in self._Values])
            self._Selected = set()
            for Each in Selected:
                if Each in self._Values:
                    self._Selected.add(self._Values.index(Each))
            if not self._Multiple and len(self._Selected) > 1:
                self._Selected = {sorted(self._Selected)[0]}
            self._Apply()
            return self._Values
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Remove -> {E}')

    def Clear(self):
        try:
            self._Value = ''
            self._Values = []
            self._Selected = set()
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Sort(self):
        try:
            Selected = self._Selected_Values()
            self._Values = sorted(self._Values, key=lambda X: str(X))
            self._Selected = set()
            for Each in Selected:
                if Each in self._Values:
                    self._Selected.add(self._Values.index(Each))
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Sort -> {E}')

    def Refresh(self, Value=False):
        try:
            self._Apply()
            if Value is not False:
                self.Set(Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Widget(self):
        try:
            return self._Frame
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if 'On_Animate' in Input:
                self._On_Animate = Input['On_Animate']
                del Input['On_Animate']
            if self._Frame is not None and len(Input) > 0:
                Event_Bind(self._Frame, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if 'Value' in Input:
                self._Value = Input['Value']
                self._Values = self._Values_From_Input(Input['Value'])
                self._Selected = {Index for Index in self._Selected if 0 <= Index < len(self._Values)}
            if 'Values' in Input:
                self._Values = self._Values_From_Input(Input['Values'])
                self._Value = Input['Values']
                self._Selected = {Index for Index in self._Selected if 0 <= Index < len(self._Values)}
            if not self._Multiple and len(self._Selected) > 1:
                self._Selected = {sorted(self._Selected)[0]}
            if self._Initialized and Run:
                self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def _CSS_Number_Unit(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return [0.0, 'px']
            if isinstance(Value, (int, float)):
                return [float(Value), 'px']
            Text = str(Value).strip()
            if Text.endswith('%'):
                return [float(Text[:-1]), '%']
            if Text.endswith('px'):
                return [float(Text[:-2]), 'px']
            return [float(Text), 'px']
        except Exception:
            return [None, 'css']

    def _CSS_Format(self, Number, Unit):
        try:
            if Number is None:
                return '0px'
            Number = round(float(Number), 3)
            if Unit == '%':
                return f'{Number}%'
            if Unit == 'px':
                return Number
            return f'{Number}px'
        except Exception:
            return '0px'

    def _CSS_Value(self, Value):
        try:
            if Value is None or Value is False or Value == '':
                return 0
            if isinstance(Value, (int, float)):
                return Value
            Text = str(Value).strip()
            if Text.endswith('%') or Text.endswith('px') or Text.startswith('calc('):
                return Text
            return float(Text)
        except Exception:
            return Value

    def _CSS_Add(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number + Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} + {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Add -> {E}')
            return Base

    def _CSS_Subtract(self, Base, Value):
        try:
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            if Base_Number is not None and Value_Number is not None and Base_Unit == Value_Unit:
                return self._CSS_Format(Base_Number - Value_Number, Base_Unit)
            Base_Value = self._Unit(Base) or '0px'
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Base_Value} - {Value_Value})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Subtract -> {E}')
            return Base

    def _CSS_Scale(self, Value, Scale):
        try:
            Number, Unit = self._CSS_Number_Unit(Value)
            if Number is not None:
                return self._CSS_Format(Number * float(Scale), Unit)
            Value_Value = self._Unit(Value) or '0px'
            return f'calc({Value_Value} * {float(Scale)})'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Scale -> {E}')
            return Value

    def _CSS_Ratio(self, Value, Base):
        try:
            Value_Number, Value_Unit = self._CSS_Number_Unit(Value)
            Base_Number, Base_Unit = self._CSS_Number_Unit(Base)
            if Value_Number is None or Base_Number is None or Base_Number == 0:
                return 0
            if Value_Unit != Base_Unit:
                return 0
            return round((Value_Number / Base_Number) * 100, 3)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _CSS_Ratio -> {E}')
            return 0
			
    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Add(self._Left, Left)
            if Top is not None:
                self._Top = self._CSS_Add(self._Top, Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = self._CSS_Subtract(Left, self._CSS_Scale(Width, 0.5))
            if Top is not None:
                self._Top = self._CSS_Subtract(Top, self._CSS_Scale(Height, 0.5))
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._CSS_Add(self._Left, self._CSS_Scale(Width, 0.5)), self._CSS_Add(self._Top, self._CSS_Scale(Height, 0.5))]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = self._CSS_Value(Left)
            if Top is not None:
                self._Top = self._CSS_Value(Top)
            if Right is not None:
                self._Right = self._CSS_Value(Right)
            if Bottom is not None:
                self._Bottom = self._CSS_Value(Bottom)
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = self._CSS_Value(Width)
            if Height is not False:
                self._Height = self._CSS_Value(Height)
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Add(self._Width, Value)
                self._Height = self._CSS_Add(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._CSS_Subtract(self._Width, Value)
                self._Height = self._CSS_Subtract(self._Height, Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')
            
    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'
                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')
                        self._Frame = ui.element('div').props('tabindex=0')
                        with self._Frame:
                            self._Body = ui.element('div')
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')
                    self._Frame = ui.element('div')
                    with self._Frame:
                        self._Body = ui.element('div')
                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)
                self._Initialized = True
            self._Apply()
            if self._Name:
                self._Main.__dict__[self._Name] = self
            if not self._Display:
                self.Hide()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')